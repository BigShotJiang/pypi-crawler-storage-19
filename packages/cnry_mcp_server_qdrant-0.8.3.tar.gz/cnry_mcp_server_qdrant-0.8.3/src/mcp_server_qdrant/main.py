import argparse


def main():
    """
    Main entry point for the mcp-server-qdrant script defined
    in pyproject.toml. It runs the MCP server with a specific transport
    protocol.
    """

    # Parse the command-line arguments to determine the transport protocol.
    parser = argparse.ArgumentParser(description="mcp-server-qdrant")
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse", "streamable-http"],
        default="stdio",
    )
    parser.add_argument(
        "--port",
        default="8000",
        type=int,
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
    )
    args = parser.parse_args()

    # Import is done here to make sure environment variables are loaded
    # only after we make the changes.
    from mcp_server_qdrant.server import mcp

    extra_args = dict()
    if args.transport != "stdio":
        extra_args = {"port": args.port, "host": args.host}

    mcp.run(transport=args.transport, **extra_args)
