# LeetCode X (Twitter) Thread Poster

Automatically post your daily LeetCode solutions to X as a threaded learning journal!

## Example

Like [this thread](https://x.com/Ifihan_/status/1874828803754193336) - posts your daily coding progress with links to your GitHub Gists.

## Features

- Automatic day counter
- Creates a continuous thread on X
- Write solutions in your editor
- Automatically creates Github Gists
- Tracks your progress
- Links to your detailed Gist writeups
- Simple command-line interface

---

## Setup Instructions

### Step 1: Prerequisites

- Python 3.10 or higher
- X (Twitter) account
- GitHub account
- uv recommended

### Step 2: Clone/Download This Project

```bash
git clone https://github.com/plainsight16/lc-thread-posts.git
cd lc-thread-posts
```

### Step 3: Install Dependencies
```bash
uv venv
source .venv/bin/activate
```

### Step 4: Install the project

```bash
uv pip install -e
```
This also registers the CLI command:
```bash
leetcode-post
```

### Step 5: Get X API Credentials

#### 5.1: Apply for X Developer Account

1. Go to https://developer.twitter.com
2. Click **"Sign up"** or **"Sign in"**
3. Click **"Apply for a developer account"**
4. Choose **"Hobbyist"** → **"Making a bot"**
5. Fill out the application form:
   - **What will you use the X API for?** 
     > "I want to create a bot that automatically posts my daily coding practice solutions to X as a learning journal. Each day, I solve algorithm problems on LeetCode to improve my programming skills and share my solutions with detailed explanations on GitHub Gist. My bot will post these solutions as a thread to track my progress and help other learners."
6. Accept terms and verify your email
7. Wait for approval (usually instant to a few hours)

#### 5.2: Create an App

Once approved:

1. Go to https://developer.twitter.com/en/portal/dashboard
2. Click **"+ Create Project"**
3. **Project Name:** "LeetCode Poster" (or any name)
4. **Use Case:** "Making a bot"
5. **Project Description:** "Posts my daily coding solutions"
6. Click **"Next"**
7. **App Name:** "leetcode-bot-yourname" (must be unique)
8. **Copy and save** your API Key, API Secret, and Bearer Token immediately!

#### 5.3: Set Up Authentication

1. Click on your app name
2. Go to **"Settings"** tab
3. Scroll to **"User authentication settings"**
4. Click **"Set up"**
5. Configure:
   - **App permissions:** Select **"Read and Write"**
   - **Type of App:** Select **"Web App, Automated App or Bot"**
   - **Callback URI:** `http://localhost:3000`
   - **Website URL:** `https://github.com` (or your website)
6. Click **"Save"**

#### 5.4: Generate Access Tokens

1. Go to **"Keys and tokens"** tab
2. Under **"Access Token and Secret"**, click **"Generate"**
3. **Copy and save** your Access Token and Access Token Secret

You should now have:
- API Key
- API Secret Key
- Bearer Token
- Access Token
- Access Token Secret

### Step 6: Get Github API Credentials
- Go to settings on your github profile menu
- Select Developer settings
- Select Personal Access tokens
- Then Fine-grained tokens
- Add permissions for managing gists

### Step 7: Configure Environment Variables

1. Copy the example file:
   ```bash
   cp .env.example .env
   ```

2. Open `.env` in a text editor

3. Fill in your credentials (remove the placeholder text):
   ```
   TWITTER_API_KEY=your_actual_api_key_here
   TWITTER_API_SECRET=your_actual_api_secret_here
   TWITTER_ACCESS_TOKEN=your_actual_access_token_here
   TWITTER_ACCESS_TOKEN_SECRET=your_actual_access_token_secret_here
   TWITTER_BEARER_TOKEN=your_actual_bearer_token_here
   GITHUB_TOKEN=your_actual_github_token
   ```

4. Save the file

**IMPORTANT:** Never commit or share your `.env` file. It contains your API credentials.

---

## Usage

### Daily Workflow

1. Solve a LeetCode problem
2. Run `leetcode-post post <problem-name>`
3. Confirm and post

### First Time Setup

If this is your first post, run:

```bash
leetcode-post start-thread
```

This posts your introduction tweet and initializes the thread.




### Gist Format

Create your Gist at https://gist.github.com with this structure:

```markdown
# Problem Name

[Question Link](https://leetcode.com/problems/...)

## Approach

Explain your approach here...

## Implementation

```python
class Solution:
    def problemName(self, params):
        # Your code here
        pass
```

## Results

![Screenshot](your-imgur-link)

**Runtime:** X ms (Beats Y%)
**Memory:** X MB (Beats Y%)

## Complexity

- **Time:** O(n)
- **Space:** O(1)
```
Project Structure

```text
lc-thread-posts/
├── pyproject.toml
├── README.md
├── .env.example
├── .venv/
│
└── leetcode_post/
    ├── __init__.py
    ├── cli.py
    ├── twitter.py
    ├── gist.py
    ├── editor.py
    ├── progress.py
    └── templates.py
```
---

## Troubleshooting

**Error: "pip is not recognized"**
```bash
python -m pip install -r requirements.txt
```

**Error: "401 Unauthorized"**
- Ensure app has "Read and Write" permissions in X Developer Portal
- Regenerate Access Token and Access Token Secret
- Update `.env` with new credentials

**Error: "Module not found: imghdr"**
```bash
python -m pip install --upgrade tweepy
```

**Test your credentials:**
```bash
python test_credentials.py
```

**Start a new thread:**
Delete `progress.json` and run the script again.

---

## How It Works

The script maintains a `progress.json` file that tracks:
- Current day number
- Thread ID (your first tweet)

This ensures all posts are connected in one continuous thread.

---

## Customization

Edit the tweet format in `post_leetcode.py`:

```python
# Default format
tweet_text = f"Day {day}\n\n{problem_name}\n\n{gist_url}"

# Add hashtags
tweet_text = f"Day {day}\n\n{problem_name}\n\n{gist_url}\n\n#LeetCode #100DaysOfCode"
```

---

## Contributing

Contributions are welcome! Feel free to:
- Report bugs
- Suggest features
- Submit pull requests

---

## Important Notes

### Rate Limits

Twitter Free tier limits:
- **1,500 tweets per month**
- **50 tweets per day**

For daily posting, you're well within limits!

### Privacy

- Your `.env` file contains sensitive credentials
- Never commit it to GitHub
- Never share it with anyone
- The `.gitignore` protects it automatically

### Best Practices

1. **Backup your `progress.json`** occasionally
2. **Keep your credentials secure**
3. **Test with a test tweet first**
4. **Check Twitter's automation rules**: https://help.twitter.com/en/rules-and-policies/twitter-automation

---

## Support

For issues:
1. Check the troubleshooting section
2. Verify your `.env` credentials
3. Ensure app has "Read and Write" permissions
4. Open an issue on GitHub

---

## License

MIT License

---

## Acknowledgments

Inspired by [@Ifihan_](https://x.com/Ifihan_)'s daily LeetCode thread.

---

**Resources:**
- [X Developer Portal](https://developer.twitter.com)
- [LeetCode](https://leetcode.com)
- [GitHub Gist](https://gist.github.com)