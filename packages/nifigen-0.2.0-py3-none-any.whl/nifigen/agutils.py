import json
import os
from pathlib import Path




def validate_python(code: str):
    """Fail fast if generated code is invalid"""
    try:
        compile(code, "<generated_agent>", "exec")
    except SyntaxError as e:
        raise RuntimeError(
            f"❌ Generated Python is invalid:\n{e.msg} (line {e.lineno})"
        )


def generate_tools(tools):
    lines = []
    tool_names = []

    for t in tools:
        name = t["name"]
        ttype = t["type"]
        tool_names.append(name)

        if ttype == "http_get":
            lines.extend([
                "@tool",
                f"def {name}(url: str = {json.dumps(t.get('default_url', ''))}) -> str:",
                f'    """{t.get("description", "")}"""',
                f"    headers = {json.dumps(t.get('headers', {}), indent=4)}",
                "    r = requests.get(url, headers=headers, timeout=60)",
                "    r.raise_for_status()",
                "    return r.text",
                "",
            ])

        elif ttype == "file_read":
            lines.extend([
                "@tool",
                f"def {name}(path: str = {json.dumps(t.get('default_path', ''))}) -> str:",
                f'    """{t.get("description", "")}"""',
                '    with open(path, "r", encoding="utf-8") as f:',
                "        return f.read()",
                "",
            ])

    return lines, tool_names


def generate_agent(input_payload: dict,pg_id) -> str:
    code = []

    # ================= Imports =================
    code.extend([
        "import sys",
        "import json",
        "import os",
        "import yaml",
        "import requests",
        "from typing import List",
        "from dotenv import load_dotenv",
        "from pydantic import BaseModel, Field",
        "",
        "from langchain_openai import AzureChatOpenAI",
        "from langchain.tools import tool",
        "from langchain_core.prompts import ChatPromptTemplate",
        "from langchain_core.output_parsers import PydanticOutputParser",
        "",
        'p_id="{0}"'.format(pg_id),
        "",
        'with open("/work/progs/nifi_aut/json_repos/{0}/{0}.json", "r") as f:'.format(pg_id),
        "   config = yaml.safe_load(f)"



    ])

    # ================= Env =================
    code.extend([
        "# =====================================================",
        "# 1️⃣ Load Azure credentials",
        "# =====================================================",
        "load_dotenv()",
        "",
        'AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")',
        'AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")',
        'AZURE_OPENAI_MODEL = os.getenv("AZURE_OPENAI_MODEL")',
        'AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_API_KEY")',
        "",
    ])

    # ================= Schema =================
    code.extend([
        "# =====================================================",
        "# 2️⃣ Output Schema",
        "# =====================================================",
        "class LLMResponse(BaseModel):",
        "    #session_id: str",
        "    #timestamp: str",
        "    #agent: List[str]",
        "    #sources: List[str] = Field(default_factory=list)",
        "    #status: str",
        "    question: str",
        "    selected_agents: List[str]",
        "    reason: str",
        "",
        "parser = PydanticOutputParser(pydantic_object=LLMResponse)",
        "",
    ])

    # ================= Tools =================
    code.extend([
        "# =====================================================",
        "# 3️⃣ Tools",
        "# =====================================================",
    ])

    tool_lines, tool_names = generate_tools(input_payload.get("tools", []))
    code.extend(tool_lines)
    code.append(f"TOOLS = [{', '.join(tool_names)}]")
    code.append("")

    # ================= LLM =================
    code.extend([
        "# =====================================================",
        "# 4️⃣ LLM",
        "# =====================================================",
        "llm = AzureChatOpenAI(",
        "    azure_endpoint=AZURE_OPENAI_ENDPOINT,",
        "    api_key=AZURE_OPENAI_KEY,",
        "    api_version=AZURE_OPENAI_API_VERSION,",
        "    deployment_name=AZURE_OPENAI_MODEL,",
        "    temperature=0",
        ")",
        "",
        "llm_with_tools = llm.bind_tools(TOOLS)",
        "",
    ])

    # ================= Prompt =================
    code.extend([
        "# =====================================================",
        "# 5️⃣ Prompt",
        "# =====================================================",
        'ag="""No agent regesterd.',
        'any request or question will redirect to no_agent."""',
        "if config[0]['agents_prompte'] is not None:",
        "    ag =config[0]['agents_prompte']",
        "",
        "",
        "prompt = ChatPromptTemplate.from_messages([",
        "    (",
        '        "system",str(config[0]["orch_prompte"]).replace("{{AVAILABLE_AGENTS}}",ag)',
        "    ),",
        '    ("human", "{question}  - session id={session_id}")',
        "]).partial(format_instructions=parser.get_format_instructions())",
        "",
    ])

    # ================= Main =================
    code.extend([
        "# =====================================================",
        "# 6️⃣ Main",
        "# =====================================================",
        "def main():",
        "    try:",
        "        input_data = json.loads(sys.stdin.read())",
        "",
        "        question = input_data['question']",
        "        session_id = input_data['session_id']",
        "        timestamp = input_data['timestamp']",
        "",
        "        chain = prompt | llm_with_tools | parser",
        "        result = chain.invoke({'question': question,'session_id':session_id})",
        "",
        "        output = result.model_dump(exclude_none=True)",
        "        output['session_id'] = session_id",
        "        output['timestamp'] = timestamp",
        "        output['status'] = 'SUCCESS'",
        "        output['question'] = input_data['question']",
        "",
        "        print(json.dumps(output, ensure_ascii=False))",
        "",
        "    except Exception as e:",
        "        print(json.dumps({",
        "            'session_id': input_data.get('session_id', 'UNKNOWN'),",
        "            'timestamp': input_data.get('timestamp', ''),",
        "            'agent': [],",
        "            'sources': [],",
        "            'status': f'ERROR: {str(e)}'",
        "        }))",
        "",
        "",
        "if __name__ == '__main__':",
        "    main()",
    ])

    generated_code = "\n".join(code)
    print(generated_code)
    validate_python(generated_code)
    return generated_code


def agent_generate_mcp_script(tool_names: list[str], mcp_url: str, output_file: str,system_prompts:str):
    """
    Generate a Python script that wraps MCP tools with LangChain and Azure OpenAI.
    Robustly handles tools missing args_schema.

    Args:
        tool_names (List[str]): List of MCP tool names to include.
        mcp_url (str): URL of the MCP server (e.g., "http://192.168.1.220:8333").
        output_file (str): File path to save the generated script.
    """

    script_template = f'''import os
import json
import asyncio
from typing import List
from dotenv import load_dotenv
from pydantic import BaseModel
import sys
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import AzureChatOpenAI
from langchain.tools import tool
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser

# =====================================================
# 1️⃣ Load environment variables
# =====================================================
load_dotenv()
AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")
AZURE_OPENAI_MODEL = os.getenv("AZURE_OPENAI_MODEL")

# =====================================================
# 2️⃣ MCP helper class (robust)
# =====================================================
class SyncStringMCPTool:
    \"\"\"Wrap a MCP tool so it always returns a string.\"\"\"
    def __init__(self, tool):
        self.tool = tool
        self.name = tool.name

    def run(self, text: str) -> str:
        return asyncio.run(self.arun(text))

    async def arun(self, text: str) -> str:
        # Check if the tool has args_schema
        if hasattr(self.tool, "args_schema") and self.tool.args_schema.get("properties"):
            arg_name = list(self.tool.args_schema["properties"].keys())[0]
            payload = {{arg_name: text}}
        else:
            # Fallback: assume tool takes single argument called "input"
            payload = {{"input": text}}

        result = await self.tool.arun(payload)

        # Convert dict or list output to string safely
        if isinstance(result, dict):
            return result.get("res", str(result))
        if isinstance(result, list):
            return " ".join(item.get("text", str(item)) for item in result)
        return str(result)

# =====================================================
# 3️⃣ Load MCP tools dynamically
# =====================================================
def load_mcp_tools_sync(url: str, tool_names: List[str]):
    tools = []

    async def _load():
        client = MultiServerMCPClient({{
            "main": {{"transport": "sse", "url": f"{{url}}/sse"}}
        }})
        available_tools = await client.get_tools()
        #print("Available tools on MCP server:", [t.name for t in available_tools])
        for t in available_tools:
            if t.name in tool_names:
                tools.append(t)
        return tools

    return asyncio.run(_load())

# =====================================================
# 4️⃣ Define strict output schema
# =====================================================
class LLMResponse(BaseModel):
    session_id: str
    timestamp: str
    status: str
    answer: str

parser = PydanticOutputParser(pydantic_object=LLMResponse)

# =====================================================
# 5️⃣ Helper to wrap MCP tool as LangChain tool
# =====================================================
def make_generic_mcp_tool(sync_tool: SyncStringMCPTool):
    @tool(return_direct=True)
    def generic_mcp_tool(question: str) -> str:
        \"\"\"Call the MCP tool and return its string output\"\"\"
        return sync_tool.run(question)
    return generic_mcp_tool

# =====================================================
# 6️⃣ Load MCP tools and wrap them
# =====================================================
TOOL_NAMES = {tool_names}
mcp_tools = load_mcp_tools_sync("{mcp_url}", TOOL_NAMES)
wrapped_tools = [make_generic_mcp_tool(SyncStringMCPTool(t)) for t in mcp_tools]

#print("Wrapped MCP tools for LangChain:", [t.name for t in wrapped_tools])

# =====================================================
# 7️⃣ Initialize Azure OpenAI LLM
# =====================================================
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
    api_key=AZURE_OPENAI_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
    deployment_name=AZURE_OPENAI_MODEL,
    temperature=0
)
llm_with_tools = llm.bind_tools(wrapped_tools)

# =====================================================
# 8️⃣ Create prompt with schema instructions
# =====================================================
prompt = ChatPromptTemplate.from_messages([
    (
        "system",
        """>>>system_prompts<<<.
Return output strictly in JSON format following this schema:
{{format_instructions}}"""
    ),
    ("human", "{{question}}")
]).partial(format_instructions=parser.get_format_instructions())

# =====================================================
# 9️⃣ Main execution
# =====================================================
def main():
    input_data = json.loads(sys.stdin.read())
    try:
        chain = prompt | llm_with_tools | parser
        result = chain.invoke({{"question": input_data["question"]}})
        output = result.model_dump(exclude_none=True)
        output["session_id"] = input_data["session_id"]
        output["timestamp"] = input_data["timestamp"]
        output["status"] = "SUCCESS"
        output["question"] = input_data["question"]
        print(json.dumps(output, ensure_ascii=False))

    except Exception as e:
        #print("LLM chain failed, falling back to first MCP tool:", e)
        fallback_tool = SyncStringMCPTool(mcp_tools[0])
        answer_text = fallback_tool.run(input_data["question"])
        output = {{
            "session_id": input_data["session_id"],
            "timestamp": input_data["timestamp"],
            "status": "SUCCESS",
            "answer": answer_text
        }}
        print(json.dumps(output, ensure_ascii=False))

if __name__ == "__main__":
    main()
'''
    script_template=script_template.replace(">>>system_prompts<<<",system_prompts)
    print(f"""script_template

    {script_template}

""")
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(script_template)
    print(f"Script generated and saved to {output_file}")

