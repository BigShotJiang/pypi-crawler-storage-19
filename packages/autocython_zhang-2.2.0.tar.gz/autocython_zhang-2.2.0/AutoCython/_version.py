#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""版本号模块，从 pyproject.toml 中读取版本号"""
import sys
from pathlib import Path

# Python 3.11+ 使用内置 tomllib，否则使用 tomli
if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None


def _get_version() -> str:
    """从 pyproject.toml 中获取版本号"""
    if tomllib is None:
        return "0.0.0"
    toml_path = Path(__file__).parent.parent / "pyproject.toml"
    if toml_path.exists():
        with open(toml_path, "rb") as f:
            data = tomllib.load(f)
            return data.get("project", {}).get("version", "0.0.0")
    return "0.0.0"


__version__ = _get_version()
