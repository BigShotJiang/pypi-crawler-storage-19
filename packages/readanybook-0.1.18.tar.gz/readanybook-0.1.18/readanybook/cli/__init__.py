"""
Command-line interface for ReadAnyBook cheat sheet generator.
"""

from .main import app, main

__all__ = ["app", "main"]
