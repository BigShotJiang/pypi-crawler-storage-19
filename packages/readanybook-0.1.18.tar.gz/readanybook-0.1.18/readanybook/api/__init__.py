"""
FastAPI application for ReadAnyBook.
"""

from .main import app, create_app

__all__ = ["app", "create_app"]
