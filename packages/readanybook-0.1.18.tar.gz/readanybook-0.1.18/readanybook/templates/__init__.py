"""
LaTeX templates for cheat sheet generation.
"""

from pathlib import Path

TEMPLATES_DIR = Path(__file__).parent


def get_template(name: str) -> str:
    """
    Get a template by name.
    
    Args:
        name: Template name (without .tex extension)
        
    Returns:
        Template string
    """
    template_path = TEMPLATES_DIR / f"{name}.tex"
    if template_path.exists():
        return template_path.read_text(encoding='utf-8')
    
    raise ValueError(f"Template not found: {name}")


def list_templates():
    """List available templates."""
    return [p.stem for p in TEMPLATES_DIR.glob("*.tex")]


__all__ = ["get_template", "list_templates", "TEMPLATES_DIR"]
