"""
ReadAnyBook: A RAG-based cheat sheet generator for books and papers.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_directory = Path(__file__).parent
long_description = ""
readme_path = this_directory / "README.md"
if readme_path.exists():
    long_description = readme_path.read_text(encoding="utf-8")

# Core dependencies
install_requires = [
    # Configuration
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
    "PyYAML>=6.0",
    
    # Document processing
    "pypdf>=3.0.0",
    "ebooklib>=0.18",
    "beautifulsoup4>=4.12.0",
    "lxml>=4.9.0",
    "chardet>=5.0.0",
    
    # Embeddings and ML
    "sentence-transformers>=2.2.0",
    "transformers>=4.30.0",
    "torch>=2.0.0",
    
    # Vector stores
    "chromadb>=0.4.0",
    
    # Text processing
    "tiktoken>=0.5.0",
    "rank-bm25>=0.2.2",
    
    # Templating
    "jinja2>=3.1.0",
    
    # Utilities
    "tqdm>=4.65.0",
    "numpy>=1.24.0",
]

# Optional dependencies
extras_require = {
    # CLI and API
    "cli": [
        "typer>=0.9.0",
        "rich>=13.0.0",
    ],
    "api": [
        "fastapi>=0.100.0",
        "uvicorn>=0.23.0",
        "python-multipart>=0.0.6",
    ],
    
    # Additional vector stores
    "qdrant": [
        "qdrant-client>=1.6.0",
    ],
    "weaviate": [
        "weaviate-client>=3.24.0",
    ],
    
    # Additional LLM backends
    "ollama": [
        "ollama>=0.1.0",
    ],
    "openai": [
        "openai>=1.0.0",
    ],
    "vllm": [
        "vllm>=0.2.0",
    ],
    
    # Quantization
    "quantization": [
        "bitsandbytes>=0.41.0",
        "accelerate>=0.24.0",
    ],
    
    # Evaluation
    "eval": [
        "nltk>=3.8.0",
        "rouge-score>=0.1.2",
        "ragas>=0.1.0",
    ],
    
    # Observability
    "observability": [
        "opentelemetry-api>=1.20.0",
        "opentelemetry-sdk>=1.20.0",
        "opentelemetry-exporter-otlp>=1.20.0",
    ],
    
    # Reranking
    "rerank": [
        "sentence-transformers>=2.2.0",  # Already included, but explicit
    ],
    
    # Development
    "dev": [
        "pytest>=7.0.0",
        "pytest-cov>=4.0.0",
        "pytest-asyncio>=0.21.0",
        "black>=23.0.0",
        "isort>=5.12.0",
        "mypy>=1.5.0",
        "ruff>=0.1.0",
    ],
    
    # All optional dependencies
    "all": [
        "typer>=0.9.0",
        "rich>=13.0.0",
        "fastapi>=0.100.0",
        "uvicorn>=0.23.0",
        "python-multipart>=0.0.6",
        "qdrant-client>=1.6.0",
        "weaviate-client>=3.24.0",
        "ollama>=0.1.0",
        "openai>=1.0.0",
        "bitsandbytes>=0.41.0",
        "accelerate>=0.24.0",
        "nltk>=3.8.0",
        "rouge-score>=0.1.2",
        "opentelemetry-api>=1.20.0",
        "opentelemetry-sdk>=1.20.0",
        "opentelemetry-exporter-otlp>=1.20.0",
    ],
}

setup(
    name="readanybook",
    version="0.1.14",
    author="ReadAnyBook Team",
    author_email="team@readanybook.dev",
    description="A RAG-based cheat sheet generator for books and papers",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/readanybook/readanybook",
    project_urls={
        "Bug Tracker": "https://github.com/readanybook/readanybook/issues",
        "Documentation": "https://readanybook.dev/docs",
    },
    license="MIT",
    
    packages=find_packages(exclude=["tests", "tests.*", "examples", "examples.*"]),
    package_data={
        "readanybook": [
            "config/*.yaml",
            "templates/*.tex",
        ],
    },
    include_package_data=True,
    
    python_requires=">=3.10",
    install_requires=install_requires,
    extras_require=extras_require,
    
    entry_points={
        "console_scripts": [
            "read-any-book=readanybook.cli.main:main",
            "rab=readanybook.cli.main:main",  # Short alias
        ],
    },
    
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Text Processing :: General",
        "Topic :: Education",
    ],
    
    keywords=[
        "rag",
        "retrieval-augmented-generation",
        "cheat-sheet",
        "pdf",
        "summarization",
        "llm",
        "nlp",
        "education",
    ],
)
