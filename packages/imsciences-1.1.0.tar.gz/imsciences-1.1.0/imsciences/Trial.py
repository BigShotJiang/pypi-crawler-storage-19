import pandas as pd
import requests
import xml.etree.ElementTree as ET
from datetime import datetime


class OECDDataPuller:
    """
    Class to fetch and process time series data from the OECD API.
    Includes built-in testing functionality.
    """

    # Configuration for all OECD indicators
    INDICATOR_CONFIG = [
        {
            "name": "Business Confidence Index",
            "series": "BCICP",
            "dataset": "SDD.STES,DSD_STES@DF_CLI,",
            "filter": ".....",
            "col_name": "macro_business_confidence_index",
        },
        {
            "name": "Consumer Confidence Index",
            "series": "CCICP",
            "dataset": "SDD.STES,DSD_STES@DF_CLI,",
            "filter": ".....",
            "col_name": "macro_consumer_confidence_index",
        },
        {
            "name": "CPI Total",
            "series": "N.CPI",
            "dataset": "SDD.TPS,DSD_PRICES@DF_PRICES_ALL,",
            "filter": "PA._T.N.GY",
            "col_name": "macro_cpi_total",
        },
        {
            "name": "CPI Housing",
            "series": "N.CPI",
            "dataset": "SDD.TPS,DSD_PRICES@DF_PRICES_ALL,",
            "filter": "PA.CP041T043.N.GY",
            "col_name": "macro_cpi_housing",
        },
        {
            "name": "CPI Food",
            "series": "N.CPI",
            "dataset": "SDD.TPS,DSD_PRICES@DF_PRICES_ALL,",
            "filter": "PA.CP01.N.GY",
            "col_name": "macro_cpi_food",
        },
        {
            "name": "CPI Energy",
            "series": "N.CPI",
            "dataset": "SDD.TPS,DSD_PRICES@DF_PRICES_ALL,",
            "filter": "PA.CP045_0722.N.GY",
            "col_name": "macro_cpi_energy",
        },
        {
            "name": "Unemployment Rate",
            "series": "UNE_LF_M",
            "dataset": "SDD.TPS,DSD_LFS@DF_IALFS_UNE_M,",
            "filter": "._Z.Y._T.Y_GE15.",
            "col_name": "macro_unemployment_rate",
            "special": "SPECIAL_UNE",
        },
        {
            "name": "Real House Prices",
            "series": "RHP",
            "dataset": "ECO.MPD,DSD_AN_HOUSE_PRICES@DF_HOUSE_PRICES,1.0",
            "filter": "",
            "col_name": "macro_real_house_prices",
        },
        {
            "name": "Manufacturing Production",
            "series": "PRVM",
            "dataset": "SDD.STES,DSD_KEI@DF_KEI,4.0",
            "filter": "IX.C..",
            "col_name": "macro_manufacturing_production_volume",
        },
        {
            "name": "Retail Trade Volume",
            "series": "TOVM",
            "dataset": "SDD.STES,DSD_KEI@DF_KEI,4.0",
            "filter": "IX...",
            "col_name": "macro_retail_trade_volume",
        },
        {
            "name": "Interbank Rate",
            "series": "IRSTCI",
            "dataset": "SDD.STES,DSD_KEI@DF_KEI,4.0",
            "filter": "PA...",
            "col_name": "macro_interbank_rate",
        },
        {
            "name": "Long-term Interest Rate",
            "series": "IRLT",
            "dataset": "SDD.STES,DSD_KEI@DF_KEI,4.0",
            "filter": "PA...",
            "col_name": "macro_long_term_interest_rate",
        },
        {
            "name": "GDP Growth",
            "series": "B1GQ",
            "dataset": "SDD.NAD,DSD_NAMAIN1@DF_QNA,1.1",
            "filter": "._Z....GY.T0102",
            "col_name": "macro_gdp_growth_yoy",
            "special": "SPECIAL_GDP",
        },
    ]

    @staticmethod
    def parse_quarter(date_str):
        """Parses a string in 'YYYY-Q#' format into a datetime object."""
        year, quarter = date_str.split("-")
        quarter_number = int(quarter[1])
        month = (quarter_number - 1) * 3 + 1
        return pd.Timestamp(f"{year}-{month:02d}-01")

    def _build_url(self, country, series, dataset_id, filter_val, freq, special_flag=None):
        """Build the appropriate OECD API URL based on indicator type."""
        if special_flag == "SPECIAL_GDP":
            return f"https://sdmx.oecd.org/public/rest/data/OECD.{dataset_id}/{freq}..{country}...{series}.{filter_val}?startPeriod=1950-01"
        elif special_flag == "SPECIAL_UNE":
            return f"https://sdmx.oecd.org/public/rest/data/OECD.{dataset_id}/{country}.{series}.{filter_val}.{freq}?startPeriod=1950-01"
        else:
            return f"https://sdmx.oecd.org/public/rest/data/OECD.{dataset_id}/{country}.{freq}.{series}.{filter_val}?startPeriod=1950-01"

    def _extract_observations(self, xml_content):
        """Extract dates and values from OECD API XML response."""
        root = ET.fromstring(xml_content)
        namespaces = {
            "generic": "http://www.sdmx.org/resources/sdmxml/schemas/v2_1/data/generic",
        }

        dates = []
        values = []

        for obs in root.findall(".//generic:Obs", namespaces):
            time_period = obs.find(".//generic:ObsDimension", namespaces).get("value")
            value = obs.find(".//generic:ObsValue", namespaces).get("value")

            if time_period and value:
                dates.append(time_period)
                values.append(float(value))

        return dates, values

    def _fetch_indicator_data(self, country, series, dataset_id, filter_val, col_name, special_flag=None):
        """
        Attempt to fetch data for a single indicator across different frequencies.
        
        Returns:
            tuple: (DataFrame or None, frequency_used, success_flag)
        """
        for freq in ["M", "Q", "A"]:
            url = self._build_url(country, series, dataset_id, filter_val, freq, special_flag)

            try:
                response = requests.get(url, timeout=15)

                if response.status_code != 200:
                    continue

                dates, values = self._extract_observations(response.content)

                if len(dates) == 0:
                    continue

                # Create DataFrame
                data = pd.DataFrame({"OBS": dates, col_name: values})

                # Convert dates based on frequency
                if freq == "Q":
                    data["OBS"] = data["OBS"].apply(self.parse_quarter)
                else:
                    data["OBS"] = data["OBS"].apply(lambda x: datetime.strptime(x, "%Y-%m"))

                data.sort_values(by="OBS", inplace=True)

                return data, freq, True

            except Exception as e:
                continue

        return None, None, False

    def pull_oecd(
        self,
        country: str = "GBR",
        week_commencing: str = "mon",
        start_date: str = "2020-01-01",
    ) -> pd.DataFrame:
        """
        Fetch and process time series data from the OECD API.

        Args:
            country (str): A string containing a 3-letter code of the country of interest 
                          (E.g: "GBR", "FRA", "USA", "DEU")
            week_commencing (str): The starting day of the week for aggregation.
                                  Options are "mon", "tue", "wed", "thu", "fri", "sat", "sun".
            start_date (str): Dataset start date in the format "YYYY-MM-DD"

        Returns:
            pd.DataFrame: A DataFrame with weekly aggregated OECD data. The 'OBS' column contains 
                         the week commencing dates, and other columns contain the aggregated 
                         time series values.
        """
        # Generate a date range from start_date to today
        date_range = pd.date_range(start=start_date, end=datetime.today(), freq="D")

        # Create empty final dataframe
        daily_df = pd.DataFrame({"OBS": date_range})
        value_columns = []

        # Iterate for each variable of interest
        for indicator in self.INDICATOR_CONFIG:
            series = indicator["series"]
            dataset_id = indicator["dataset"]
            filter_val = indicator["filter"]
            col_name = indicator["col_name"]
            special_flag = indicator.get("special")

            # Attempt to fetch data
            data, freq_used, success = self._fetch_indicator_data(
                country, series, dataset_id, filter_val, col_name, special_flag
            )

            if not success:
                print(f"Failed to fetch data for {col_name}")
                continue

            # Add variable name to list
            value_columns.append(col_name)

            # Merge the data based on observation date
            daily_df = pd.merge_asof(
                daily_df,
                data[["OBS", col_name]],
                on="OBS",
                direction="backward",
            )

        # Ensure columns are numeric
        for col in value_columns:
            if col in daily_df.columns:
                daily_df[col] = pd.to_numeric(daily_df[col], errors="coerce").fillna(0)
            else:
                print(f"Column {col} not found in daily_df")

        # Aggregate results by week (requires ims_proc module)
        # Uncomment when ims_proc is available:
        country_df = ims_proc.aggregate_daily_to_wc_wide(
            df=daily_df,
            date_column="OBS",
            group_columns=[],
            sum_columns=value_columns,
            wc=week_commencing,
            aggregation="average",
        )
        return country_df

        #return daily_df

    def test_all_indicators(self, country: str = "GBR", start_date: str = "2020-01-01"):
        """
        Standalone test script for OECD API - tests each indicator individually.
        
        Args:
            country (str): Country code (default: "GBR")
            start_date (str): Start date for filtering (default: "2020-01-01")
            
        Returns:
            tuple: (results_dataframe, data_dictionary)
        """
        print("=" * 80)
        print(f"OECD API TEST - Testing All Indicators for {country}")
        print("=" * 80)
        print()

        results = []
        all_data = {}

        for idx, indicator in enumerate(self.INDICATOR_CONFIG, 1):
            series = indicator["series"]
            dataset_id = indicator["dataset"]
            filter_val = indicator["filter"]
            col_name = indicator["col_name"]
            special_flag = indicator.get("special")

            print(f"[{idx}/13] Testing: {indicator['name']}")
            print(f"        Series: {series}")

            # Attempt to fetch data
            data, freq_used, success = self._fetch_indicator_data(
                country, series, dataset_id, filter_val, col_name, special_flag
            )

            if success:
                # Store successful results
                all_data[col_name] = data

                print(f"        ✓ SUCCESS! Got {len(data)} observations ({freq_used})")
                print(f"          Date range: {data['OBS'].min().strftime('%Y-%m')} to {data['OBS'].max().strftime('%Y-%m')}")
                print(f"          Latest value: {data[col_name].iloc[-1]:.2f}")

                results.append({
                    "indicator": indicator["name"],
                    "series": series,
                    "frequency": freq_used,
                    "observations": len(data),
                    "status": "SUCCESS",
                    "latest_date": data['OBS'].max(),
                    "latest_value": data[col_name].iloc[-1],
                })
            else:
                print(f"        ✗ FAILED - Could not retrieve data")
                results.append({
                    "indicator": indicator["name"],
                    "series": series,
                    "frequency": "-",
                    "observations": 0,
                    "status": "FAILED",
                    "latest_date": None,
                    "latest_value": None,
                })

            print()

        # Summary
        print("=" * 80)
        print("SUMMARY")
        print("=" * 80)

        df_results = pd.DataFrame(results)
        success_count = (df_results["status"] == "SUCCESS").sum()
        total_count = len(df_results)

        print(f"\nSuccessful: {success_count}/{total_count} indicators")
        print()
        print(df_results[["indicator", "frequency", "observations", "status"]].to_string(index=False))

        # Show sample data from first successful indicator
        if all_data:
            first_indicator = list(all_data.keys())[0]
            print(f"\n{'='*80}")
            print(f"SAMPLE DATA: {first_indicator}")
            print(f"{'='*80}")
            print(all_data[first_indicator].head(10).to_string(index=False))
            print("...")
            print(all_data[first_indicator].tail(5).to_string(index=False))

        return df_results, all_data


if __name__ == "__main__":
    # Initialize the puller
    puller = OECDDataPuller()

    # Run the test
    results_df, data_dict = puller.test_all_indicators(country="GBR")

    # Optional: Save results to CSV
    results_df.to_csv("oecd_test_results.csv", index=False)
    print(f"\n✓ Test results saved to: oecd_test_results.csv")

    # Example: Fetch actual data
    print("\n" + "=" * 80)
    print("FETCHING OECD DATA")
    print("=" * 80)
    oecd_data = puller.pull_oecd(country="GBR", week_commencing="mon", start_date="2020-01-01")
    print(oecd_data.head(10))
