import socket, threading, time
from queue import Queue
from typing import Tuple, Optional, Set
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .. import Node

from . import Route, Message
from .processors.incoming import (
    process_incoming_messages,
    populate_incoming_messages,
)
from .processors.outgoing import process_outgoing_messages
from .processors.peer import manage_peer
from .outgoing_queue import enqueue_outgoing
from .util import address_str_to_host_and_port
from ..utils.bytes import hex_to_bytes

def load_x25519(hex_key: Optional[str]) -> X25519PrivateKey:
    """DH key for relaying (always X25519)."""
    if hex_key:
        return X25519PrivateKey.from_private_bytes(bytes.fromhex(hex_key))
    return X25519PrivateKey.generate()

def load_ed25519(hex_key: Optional[str]) -> Optional[ed25519.Ed25519PrivateKey]:
    """Signing key for validation (Ed25519), or None if absent."""
    return ed25519.Ed25519PrivateKey.from_private_bytes(bytes.fromhex(hex_key)) \
           if hex_key else None

def make_routes(
    relay_pk: X25519PublicKey,
    val_sk: Optional[ed25519.Ed25519PrivateKey]
) -> Tuple[Route, Optional[Route]]:
    """Peer route (DH pubkey) + optional validation route (ed pubkey)."""
    peer_rt = Route(relay_pk)
    val_rt  = Route(val_sk.public_key()) if val_sk else None
    return peer_rt, val_rt

def make_maps():
    """Empty lookup maps: peers and addresses."""
    return


def _resolve_default_seed_ips(node: "Node", default_seed: Optional[str]) -> Set[str]:
    if default_seed is None:
        return set()
    try:
        host, port = address_str_to_host_and_port(default_seed)
    except Exception as exc:
        node.logger.warning("Invalid default seed %s: %s", default_seed, exc)
        return set()
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_DGRAM)
    except Exception as exc:
        node.logger.warning("Failed resolving default seed %s:%s: %s", host, port, exc)
        return set()
    resolved = {info[4][0] for info in infos if info[4]}
    if resolved:
        resolved_list = ", ".join(sorted(resolved))
        node.logger.info("Default seed resolved to %s", resolved_list)
    else:
        node.logger.warning("No IPs resolved for default seed %s:%s", host, port)
    return resolved


def advertise_atoms(node: "Node") -> None:
    """Advertise tracked atom ids to the closest known peer."""
    node_logger = node.logger
    adverts = getattr(node, "atom_advertisments", None)
    if adverts is None:
        node_logger.debug("Atom advertisements unavailable; skipping advertisement")
        return

    now = time.time()
    expired = 0
    to_advertise = []
    lock = getattr(node, "atom_advertisments_lock", None)
    if lock is None:
        if not adverts:
            node_logger.debug("No atom advertisements configured; skipping advertisement")
            return
        remaining = []
        for entry in adverts:
            try:
                atom_id, payload_type, expires_at = entry
            except (TypeError, ValueError):
                node_logger.warning("Invalid atom advertisement entry: %r", entry)
                remaining.append(entry)
                continue
            if expires_at is not None:
                try:
                    if expires_at <= now:
                        expired += 1
                        continue
                except TypeError:
                    node_logger.warning(
                        "Invalid atom advertisement expiry for %s: %r",
                        atom_id.hex(),
                        expires_at,
                    )
                    remaining.append(entry)
                    continue
            to_advertise.append(entry)
            remaining.append(entry)
        if len(remaining) != len(adverts):
            node.atom_advertisments = remaining
    else:
        with lock:
            if not node.atom_advertisments:
                node_logger.debug("No atom advertisements configured; skipping advertisement")
                return
            remaining = []
            for entry in node.atom_advertisments:
                try:
                    atom_id, payload_type, expires_at = entry
                except (TypeError, ValueError):
                    node_logger.warning("Invalid atom advertisement entry: %r", entry)
                    remaining.append(entry)
                    continue
                if expires_at is not None:
                    try:
                        if expires_at <= now:
                            expired += 1
                            continue
                    except TypeError:
                        node_logger.warning(
                            "Invalid atom advertisement expiry for %s: %r",
                            atom_id.hex(),
                            expires_at,
                        )
                        remaining.append(entry)
                        continue
                to_advertise.append(entry)
                remaining.append(entry)
            if len(remaining) != len(node.atom_advertisments):
                node.atom_advertisments = remaining

    advertised = 0
    for atom_id, payload_type, _expires_at in to_advertise:
        node._network_set(atom_id, payload_type=payload_type)
        advertised += 1

    node_logger.info(
        "Atom advertisement complete (advertised=%s, expired=%s)",
        advertised,
        expired,
    )


def manage_storage_index(node: "Node") -> None:
    interval = node.config.get("storage_index_interval", 0)
    if not interval:
        node.logger.info("Storage index advertiser disabled")
        return
    node.logger.info("Storage index advertiser started (interval=%ss)", interval)
    stop = getattr(node, "communication_stop_event", None)
    while stop is None or not stop.is_set():
        if stop is not None and stop.wait(interval):
            break
        try:
            advertise_atoms(node)
        except Exception:
            node.logger.exception("Storage index advertisement failed")
    node.logger.info("Storage index advertiser stopped")


def communication_setup(node: "Node", config: dict):
    node.logger.info("Setting up node communication")
    node.use_ipv6              = config.get('use_ipv6', False)
    node.peers_lock = threading.RLock()
    node.communication_stop_event = threading.Event()
    default_seed = config.get("default_seed")
    node.default_seed_ips = _resolve_default_seed_ips(node, default_seed)

    # key loading
    node.relay_secret_key      = load_x25519(config.get('relay_secret_key'))
    node.validation_secret_key = load_ed25519(config.get('validation_secret_key'))

    # derive pubs + routes
    node.relay_public_key      = node.relay_secret_key.public_key()
    node.relay_public_key_bytes = node.relay_public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    node.validation_public_key = (
        node.validation_secret_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        if node.validation_secret_key
        else None
    )
    node.peer_route, node.validation_route = make_routes(
        node.relay_public_key,
        node.validation_secret_key
    )

    # connection state & atom request tracking
    node.is_connected = False
    node.atom_requests = {}
    node.atom_requests_lock = threading.RLock()

    # sockets + queues + threads
    incoming_port = config.get("incoming_port")
    if incoming_port is None:
        raise ValueError("incoming_port must be configured before communication setup")
    fam = socket.AF_INET6 if node.use_ipv6 else socket.AF_INET
    node.incoming_socket = socket.socket(fam, socket.SOCK_DGRAM)
    if node.use_ipv6:
        node.incoming_socket.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
    node.incoming_socket.bind(("::" if node.use_ipv6 else "0.0.0.0", incoming_port))
    bound_port = node.incoming_socket.getsockname()[1]
    if incoming_port != 0 and bound_port != incoming_port:
        raise OSError(
            f"incoming_port mismatch: requested {incoming_port}, got {bound_port}"
        )
    node.config["incoming_port"] = bound_port if incoming_port == 0 else incoming_port
    node.incoming_socket.settimeout(0.5)
    node.logger.info(
        "Incoming UDP socket bound to %s:%s",
        "::" if node.use_ipv6 else "0.0.0.0",
        node.config["incoming_port"],
    )
    node.incoming_queue = Queue()
    node.incoming_queue_size = 0
    node.incoming_queue_size_lock = threading.RLock()
    node.incoming_queue_size_limit = node.config.get("incoming_queue_size_limit", 0)
    node.incoming_queue_timeout = node.config.get("incoming_queue_timeout", 0)
    node.incoming_populate_thread = threading.Thread(
        target=populate_incoming_messages,
        args=(node,),
        daemon=True,
    )
    node.incoming_process_thread = threading.Thread(
        target=process_incoming_messages,
        args=(node,),
        daemon=True,
    )
    node.incoming_populate_thread.start()
    node.incoming_process_thread.start()

    node.outgoing_socket = socket.socket(
        socket.AF_INET6 if node.use_ipv6 else socket.AF_INET,
        socket.SOCK_DGRAM,
    )
    node.outgoing_socket.settimeout(0.5)
    node.outgoing_queue = Queue()
    node.outgoing_queue_size = 0
    node.outgoing_queue_size_lock = threading.RLock()
    node.outgoing_queue_size_limit = node.config.get("outgoing_queue_size_limit", 0)
    node.outgoing_queue_timeout = node.config.get("outgoing_queue_timeout", 0)

    node.outgoing_thread = threading.Thread(
        target=process_outgoing_messages,
        args=(node,),
        daemon=True,
    )
    node.outgoing_thread.start()

    # other workers & maps
    # track atom requests we initiated; guarded by atom_requests_lock on the node
    node.peer_manager_thread  = threading.Thread(
        target=manage_peer,
        args=(node,),
        daemon=True
    )
    node.peer_manager_thread.start()

    with node.peers_lock:
        node.peers = {} # Dict[bytes,Peer]

    latest_block_hex = config.get("latest_block_hash")
    if latest_block_hex:
        try:
            node.latest_block_hash = hex_to_bytes(latest_block_hex, expected_length=32)
        except Exception as exc:
            node.logger.warning("Invalid latest_block_hash in config: %s", exc)
            node.latest_block_hash = None
    else:
        node.latest_block_hash = None

    node.logger.info(
        "Communication ready (incoming_port=%s, outgoing_socket_initialized=%s, bootstrap_count=%s)",
        node.config["incoming_port"],
        node.outgoing_socket is not None,
        len(node.bootstrap_peers),
    )
    node.is_connected = True

    # bootstrap pings (requires connected state for enqueue_outgoing)
    for addr in node.bootstrap_peers:
        try:
            host, port = address_str_to_host_and_port(addr)  # type: ignore[arg-type]
        except Exception as exc:
            node.logger.warning("Invalid bootstrap address %s: %s", addr, exc)
            continue

        handshake_message = Message(
            handshake=True,
            sender=node.relay_public_key,
            content=int(node.config["incoming_port"]).to_bytes(2, "big", signed=False),
        )
        enqueue_outgoing(
            node,
            (host, port),
            message=handshake_message,
            difficulty=1,
        )
        node.logger.info("Sent bootstrap handshake to %s:%s", host, port)
    if node.bootstrap_peers:
        node._bootstrap_last_attempt = time.time()
    advertise_atoms(node)
    node.storage_index_thread = threading.Thread(
        target=manage_storage_index,
        args=(node,),
        daemon=True,
    )
    node.storage_index_thread.start()
