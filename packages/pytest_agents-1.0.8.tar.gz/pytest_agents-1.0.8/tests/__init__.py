"""Test suite for SuperClaude."""
