"""Unit tests for SuperClaude."""
