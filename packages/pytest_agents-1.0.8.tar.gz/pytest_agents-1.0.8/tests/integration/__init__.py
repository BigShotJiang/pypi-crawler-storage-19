"""Integration tests for SuperClaude."""
