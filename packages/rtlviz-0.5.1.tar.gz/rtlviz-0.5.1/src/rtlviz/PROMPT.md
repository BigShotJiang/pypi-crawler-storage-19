# RTL Diagram Generation Guidelines

## Overview
This resource provides guidelines for AI agents to generate high-quality RTL block diagrams using Graphviz DOT code.

## Graph Attributes (MANDATORY)

```dot
digraph "Design_Name" {
    graph [
        rankdir=LR,           // Left-to-right flow (data flows left → right)
        splines=ortho,        // Orthogonal (right-angle) routing
        nodesep=0.8,          // Minimum horizontal spacing between nodes
        ranksep=1.5,          // Minimum vertical spacing between ranks
        fontname="Arial",
        compound=true,        // Allow edges between clusters
        overlap=false,        // Prevent node overlaps
        sep="+20"             // Additional separation to avoid overlaps
    ];
    node [fontname="Arial", shape=record, style="filled,rounded", penwidth=1.2];
    edge [
        fontname="Arial", 
        fontsize=9, 
        penwidth=1.2, 
        arrowsize=0.7,
        labeldistance=1.5,    // Keep labels close to edges
        labelangle=0          // Horizontal label orientation
    ];
}
```

## Clustering Rules

### 1. Clock Domain Clustering
Every clock domain MUST be in its own cluster:
```dot
subgraph cluster_write_domain {
    label="Write Clock Domain (wclk)";
    style="filled,rounded";
    fillcolor="#E3F2FD";  // Light Blue
    color="#90CAF9";
    margin=20;
    // ... nodes in this domain
}

subgraph cluster_read_domain {
    label="Read Clock Domain (rclk)";
    fillcolor="#FFEBEE";  // Light Red
    // ...
}
```

### 2. Module Clustering
Each instantiated module should be in a nested cluster:
```dot
subgraph cluster_wptr_full {
    label="wptr_full";
    style="filled,rounded";
    fillcolor="#E1F5FE";  // Lighter shade
    // internal nodes
}
```

## Node Shapes

| Component Type | Shape | Example |
|---------------|-------|---------|
| I/O Ports | `parallelogram` | `[shape=parallelogram, fillcolor="#B2DFDB"]` |
| Registers | `record` or `box3d` | `[shape=record, fillcolor="#FFF9C4"]` |
| MUX | `trapezium` | `[shape=trapezium, orientation=90, fillcolor="#CFD8DC"]` |
| Comparators | `diamond` | `[shape=diamond, fillcolor="#FFF9C4"]` |
| Logic | `record` | `[shape=record, fillcolor="#E8F5E9"]` |
| Memory | `record` with width | `[shape=record, fillcolor="#FFF9C4", width=2.0]` |

## Color Palette

### Domain Colors (Background)
- Write Domain: `#E3F2FD` (Light Blue)
- Read Domain: `#FFEBEE` (Light Red)
- Shared/Memory: `#FFF8E1` (Light Yellow)
- Control: `#F3E5F5` (Light Purple)

### Node Colors
- Registers: `#FFF9C4` (Light Yellow)
- Logic: `#E8F5E9` (Light Green)
- I/O: `#B2DFDB` (Teal)
- Flags: `#FFCCBC` (Light Orange)
- CDC Sync: `#FFE0B2` (Light Orange)

## Edge Styling

### Data Paths
```dot
node1 -> node2 [label="data[7:0]", penwidth=2.0];
```

### Control Signals
```dot
clk -> reg [style=dashed, color="#1565C0", label="clk"];
```

### CDC Crossings
```dot
wptr -> sync [label="Gray Code", color="#388E3C", penwidth=2.0];
```

### Feedback Paths
```dot
output -> input [constraint=false, style=dashed];
```

## Label Positioning (IMPORTANT)

**DO NOT** use `xlabel` - it causes wires to cut through labels.

**USE** `taillabel` or `headlabel` with spacing for offset:
```dot
// Label at source node (with trailing spaces for offset)
a -> b [taillabel="signal  ", labeldistance=2.5];

// Label at destination node (with leading spaces for offset)
a -> b [headlabel="  signal", labeldistance=2.5];
```

Key attributes:
- `labeldistance=2.0-3.0` - Distance from edge endpoint
- Add trailing/leading spaces to text for additional offset
- Avoid `xlabel` which places labels on top of edges

## Preventing Overlaps

1. **Graph Level**: `overlap=false`, `sep="+20"`
2. **Generous Margins**: `margin=20` on clusters
3. **Node Spacing**: `nodesep=0.8`, `ranksep=1.5`
4. **Explicit Widths**: Set `width=2.0` on wide nodes (memory, modules)

## White-Box Detail

Include internal state in node labels:
```dot
wbin_reg [label="{ wbin | { Binary Ptr | [ASIZE:0] } }"];
wfull_logic [label="{ Full Detection | wgray_next == ~wq2_rptr[MSB] }"];
```

## Example: Async FIFO Structure

```
cluster_write_domain
├── cluster_wptr_full (write pointer + full logic)
└── cluster_sync_r2w (CDC synchronizer)

cluster_read_domain
├── cluster_rptr_empty (read pointer + empty logic)
└── cluster_sync_w2r (CDC synchronizer)

cluster_fifomem (dual-port memory)
```

## Checklist Before Rendering

- [ ] All nodes in clusters (no floating nodes)
- [ ] Clock domains clearly separated
- [ ] Edge labels include signal names and bit widths
- [ ] Pastel colors used consistently
- [ ] `splines=ortho` set
- [ ] `overlap=false` set
- [ ] MUX shapes are trapezium with orientation=90
