"""FlukeBase Connect - MCP client for AI-assisted development.

This is the open-source client that communicates with the FlukeBase
platform for AI memory, task management, and environment sync.
"""

__version__ = "0.2.0"
__all__ = ["__version__"]
