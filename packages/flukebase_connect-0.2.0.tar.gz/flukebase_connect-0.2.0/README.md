# FlukeBase Connect

MCP client for AI-assisted development with the FlukeBase platform.

## Installation

```bash
# Recommended: one-line install
curl -sSL https://flukebase.me/install | sh

# Or with pip
pip install https://flukebase.me/releases/flukebase_connect-0.2.0-py3-none-any.whl
```

## Quick Start

```bash
# Authenticate
fbc login

# Check status
fbc status

# List projects
fbc projects

# List available tools
fbc tools
```

## MCP Integration

Add to your Claude Code settings:

```json
{
  "mcpServers": {
    "flukebase": {
      "command": "fbc",
      "args": ["mcp"]
    }
  }
}
```

## Documentation

Full documentation at: https://flukebase.me/docs

## License

MIT License - See LICENSE for details.
