import os
import platform
import subprocess
from prompt_toolkit import prompt
from prompt_toolkit.completion import FuzzyCompleter, WordCompleter
from prompt_toolkit.shortcuts import CompleteStyle
from envvm.validators.validators import (
    EnvVarValidator,
    EnvVarNameValidator,
    OperationValidator,
    PathValidator
)

from .othersenv import others_dict
from .uvenv import uv_dict
from .vagrantenv import vagrant_dict
from .gitenv import git_dict


class ENVVM():
    # region 平台检测
    
    @staticmethod
    def _is_windows() -> bool:
        """检测当前系统是否为 Windows"""
        return platform.system() == 'Windows'
    
    @staticmethod
    def _is_linux() -> bool:
        """检测当前系统是否为 Linux"""
        return platform.system() == 'Linux'
    
    @staticmethod
    def _get_shell_config_file() -> str:
        """获取当前用户的 shell 配置文件路径
        
        根据用户当前使用的 shell 类型，返回对应的配置文件路径。
        该配置文件用于存储环境变量的 export 语句，使环境变量在新终端会话中持久生效。
        
        检测逻辑:
            1. 从 SHELL 环境变量获取当前 shell 路径，默认为 /bin/bash
            2. 根据 shell 类型返回对应配置文件:
               - zsh  -> ~/.zshrc
               - fish -> ~/.config/fish/config.fish
               - bash -> ~/.bashrc (如果存在) 或 ~/.profile (作为后备)
        
        Returns:
            str: shell 配置文件的绝对路径
        
        Note:
            - 对于 bash，优先使用 ~/.bashrc，因为它在交互式 shell 启动时自动加载
            - ~/.profile 作为后备选项，适用于 ~/.bashrc 不存在的情况
            - fish shell 的配置文件位于 XDG 规范目录下
        """
        shell = os.environ.get('SHELL', '/bin/bash')
        home = os.path.expanduser('~')
        
        if 'zsh' in shell:
            return os.path.join(home, '.zshrc')
        elif 'fish' in shell:
            return os.path.join(home, '.config', 'fish', 'config.fish')
        else:
            # 默认使用 bash
            bashrc = os.path.join(home, '.bashrc')
            if os.path.exists(bashrc):
                return bashrc
            return os.path.join(home, '.profile')
    
    # endregion
    def list(self, x=False):
        """列出系统中所有环境变量
        
        Args:
            x: 如果为True，则通过prompt_toolkit的FuzzyCompleter让用户选择需要查看的变量并查看其值
        
        如果x为False，直接打印所有环境变量及其值。
        如果x为True，提供交互式模糊搜索界面让用户选择特定环境变量查看。
        """
        if x:
            env_keys = sorted(os.environ.keys())
            completer = FuzzyCompleter(WordCompleter(env_keys))
            validator = EnvVarValidator()
            selected = prompt("选择环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
            print(f"{selected}={os.environ[selected]}")
        else:
            for key, value in sorted(os.environ.items()):
                print(f"{key}={value}")

    def setenv(self, custom_env_name=None):
        """永久添加环境变量，支持从预定义字典中模糊选择
        
        Args:
            custom_env_name: 可选的环境变量名，如果指定则直接设置该变量，否则从字典中选择
        
        如果指定了custom_env_name，直接使用该名称；否则提供交互式模糊搜索界面选择。
        如果环境变量已存在，会提示用户确认是否覆盖。
        Windows: 使用setx命令永久设置环境变量到注册表。
        Linux: 将export语句写入shell配置文件。
        
        Raises:
            subprocess.CalledProcessError: 当命令执行失败时
        """
        # 合并三个字典
        merged_dict = {**uv_dict, **vagrant_dict, **others_dict, **git_dict}
        
        # 如果用户指定了环境变量名，直接使用
        if custom_env_name:
            selected_key = custom_env_name
        else:
            # 获取所有环境变量名作为提示选项
            env_keys = sorted(merged_dict.keys())
            completer = FuzzyCompleter(WordCompleter(env_keys))
            validator = EnvVarNameValidator(env_keys)
            
            # 让用户选择环境变量名
            selected_key = prompt("选择要设置的环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
        
        # 如果 selected_key 为PATH 则直接退出 并提示用户 使用 update_path 进行操作
        if selected_key.upper() == 'PATH':
            print("错误: PATH 环境变量不能通过此方法设置")
            print("请使用 update_path 方法来操作 PATH 环境变量")
            return
        
        # 检查环境变量是否已经设置
        if selected_key in os.environ:
            current_value = os.environ[selected_key]
            print(f"警告: 环境变量 {selected_key} 已经设置")
            print(f"当前值: {current_value}")
            confirm = prompt("是否要覆盖现有值? (y/n): ")
            if confirm.lower() != 'y':
                print("操作已取消")
                return
        
        # 获取该环境变量的配置（如果存在于字典中）
        env_config = merged_dict.get(selected_key, {})
        templates = env_config.get("templates", []) if env_config else []
        
        # 如果有模板值，提供模糊选择
        if templates:
            template_completer = FuzzyCompleter(WordCompleter(templates))
            selected_value = prompt(f"输入 {selected_key} 的值: ", completer=template_completer, complete_style=CompleteStyle.MULTI_COLUMN)
        else:
            # 如果环境变量不在字典中或没有模板，直接输入
            selected_value = prompt(f"输入 {selected_key} 的值: ")
        
        # 根据平台选择不同的设置方式
        if self._is_windows():
            self._setenv_windows(selected_key, selected_value)
        else:
            self._setenv_linux(selected_key, selected_value)
    
    def _setenv_windows(self, key: str, value: str):
        """Windows 平台设置环境变量"""
        try:
            subprocess.run(['setx', key, value], 
                         check=True, capture_output=True, text=True)
            os.environ[key] = value
            print(f"成功设置环境变量: {key}={value}")
            print("注意: 需要重启终端或重新登录才能在新进程中生效")
        except subprocess.CalledProcessError as e:
            print(f"设置失败: {e.stderr}")
        except Exception as e:
            print(f"设置失败: {str(e)}")
    
    def _setenv_linux(self, key: str, value: str):
        """Linux 平台设置环境变量"""
        config_file = self._get_shell_config_file()
        export_line = f'export {key}="{value}"'
        
        try:
            # 读取现有配置文件内容
            existing_lines = []
            if os.path.exists(config_file):
                with open(config_file, 'r', encoding='utf-8') as f:
                    existing_lines = f.readlines()
            
            # 检查是否已存在该变量的设置，如果存在则替换
            pattern = f'export {key}='
            new_lines = []
            replaced = False
            for line in existing_lines:
                if line.strip().startswith(pattern):
                    new_lines.append(export_line + '\n')
                    replaced = True
                else:
                    new_lines.append(line)
            
            # 如果没有替换，则追加到文件末尾
            if not replaced:
                if new_lines and not new_lines[-1].endswith('\n'):
                    new_lines.append('\n')
                new_lines.append(export_line + '\n')
            
            # 写入配置文件
            with open(config_file, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
            
            # 同时在当前进程环境中设置
            os.environ[key] = value
            
            print(f"成功设置环境变量: {key}={value}")
            print(f"已写入配置文件: {config_file}")
            print("注意: 需要执行 'source " + config_file + "' 或重启终端才能在新进程中生效")
        except Exception as e:
            print(f"设置失败: {str(e)}")
    
    def delenv(self):
        """通过模糊补全让用户选择需要操作的环境变量，然后永久删除这个环境变量
        
        提供交互式模糊搜索界面让用户选择要删除的环境变量。
        显示当前值并要求用户确认删除操作。
        Windows: 使用reg delete命令从注册表中永久删除环境变量。
        Linux: 从shell配置文件中移除export语句。
        PATH环境变量不可删除，会直接返回错误提示。
        
        Raises:
            subprocess.CalledProcessError: 当命令执行失败时
        """
        # 获取所有环境变量名作为提示选项
        env_keys = sorted(os.environ.keys())
        completer = FuzzyCompleter(WordCompleter(env_keys))
        validator = EnvVarValidator()
        
        # 让用户选择要删除的环境变量
        selected_key = prompt("选择要删除的环境变量: ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
        
        # 如果 selected_key 为PATH 则直接退出 并告诉用户不可删除
        if selected_key.upper() == 'PATH':
            print("错误: PATH 环境变量不可删除")
            print("PATH 是系统关键环境变量，删除后可能导致系统无法正常工作")
            return
        
        # 检查环境变量是否存在
        if selected_key not in os.environ:
            print(f"错误: 环境变量 {selected_key} 不存在")
            return
        
        # 显示当前值并确认删除
        current_value = os.environ[selected_key]
        print(f"环境变量: {selected_key}")
        print(f"当前值: {current_value}")
        confirm = prompt("确认删除此环境变量? (y/n): ")
        
        if confirm.lower() != 'y':
            print("操作已取消")
            return
        
        # 根据平台选择不同的删除方式
        if self._is_windows():
            self._delenv_windows(selected_key)
        else:
            self._delenv_linux(selected_key)
    
    def _delenv_windows(self, key: str):
        """Windows 平台删除环境变量"""
        try:
            subprocess.run(['reg', 'delete', 'HKCU\\Environment', '/v', key, '/f'], 
                         check=True, capture_output=True, text=True)
            if key in os.environ:
                del os.environ[key]
            print(f"成功删除环境变量: {key}")
            print("注意: 需要重启终端或重新登录才能在新进程中生效")
        except subprocess.CalledProcessError as e:
            print(f"删除失败: {e.stderr}")
        except Exception as e:
            print(f"删除失败: {str(e)}")
    
    def _delenv_linux(self, key: str):
        """Linux 平台删除环境变量"""
        config_file = self._get_shell_config_file()
        
        try:
            if not os.path.exists(config_file):
                print(f"配置文件不存在: {config_file}")
                print("无法永久删除环境变量，但已从当前进程中移除")
                if key in os.environ:
                    del os.environ[key]
                return
            
            # 读取配置文件
            with open(config_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # 移除包含该环境变量的 export 语句
            pattern = f'export {key}='
            new_lines = [line for line in lines if not line.strip().startswith(pattern)]
            
            if len(new_lines) == len(lines):
                print(f"警告: 在配置文件 {config_file} 中未找到 {key} 的设置")
                print("可能该变量是在其他位置设置的")
            else:
                # 写回配置文件
                with open(config_file, 'w', encoding='utf-8') as f:
                    f.writelines(new_lines)
                print(f"已从配置文件 {config_file} 中移除 {key}")
            
            # 从当前进程环境中删除
            if key in os.environ:
                del os.environ[key]
            
            print(f"成功删除环境变量: {key}")
            print("注意: 需要执行 'source " + config_file + "' 或重启终端才能在新进程中生效")
        except Exception as e:
            print(f"删除失败: {str(e)}")
            

    def list_path(self):
        """获取PATH的值并使用人类可读的方式输出
        
        读取PATH环境变量的值，按分隔符拆分后逐行显示。
        每行显示序号和对应的路径，便于用户查看和管理。
        """
        path_value = os.environ.get('PATH', '')
        if not path_value:
            print("PATH 环境变量未设置")
            return
        
        paths = path_value.split(os.pathsep)
        print(f"PATH 包含 {len(paths)} 个路径:\n")
        for i, path in enumerate(paths, 1):
            print(f"{i:3d}. {path}")
            
    def update_path(self):
        """更新PATH环境变量，支持添加和删除路径
        
        提供交互式界面让用户选择操作类型（add或del）。
        添加操作：输入新路径后添加到PATH末尾，自动检查重复。
        删除操作：提供模糊搜索选择要删除的路径，需要确认后执行。
        Windows: 使用reg命令直接操作注册表中的用户PATH环境变量。
        Linux: 修改shell配置文件中的PATH设置。
        
        Raises:
            subprocess.CalledProcessError: 当命令执行失败时
        """
        # 让用户选择操作类型
        operations = ['add', 'del']
        completer = FuzzyCompleter(WordCompleter(operations))
        validator = OperationValidator(operations)
        operation = prompt("选择操作 (add/del): ", completer=completer, validator=validator, complete_style=CompleteStyle.MULTI_COLUMN)
        
        if self._is_windows():
            self._update_path_windows(operation)
        else:
            self._update_path_linux(operation)
    
    def _update_path_windows(self, operation: str):
        """Windows 平台更新 PATH"""
        if operation == 'add':
            new_path = prompt("输入要添加的路径: ").strip()
            
            if not new_path:
                print("错误: 路径不能为空")
                return
            
            # 获取当前用户的PATH值
            try:
                result = subprocess.run(['reg', 'query', 'HKCU\\Environment', '/v', 'Path'],
                                      capture_output=True, text=True, check=True)
                
                for line in result.stdout.split('\n'):
                    if 'Path' in line and 'REG_' in line:
                        current_path = line.split('REG_EXPAND_SZ', 1)[-1].strip() if 'REG_EXPAND_SZ' in line else line.split('REG_SZ', 1)[-1].strip()
                        break
                else:
                    current_path = ''
            except subprocess.CalledProcessError:
                current_path = ''
            
            paths = [p.strip() for p in current_path.split(';') if p.strip()]
            
            if new_path in paths:
                print(f"路径已存在于PATH中: {new_path}")
                return
            
            paths.append(new_path)
            new_path_value = ';'.join(paths)
            
            try:
                subprocess.run(['reg', 'add', 'HKCU\\Environment', '/v', 'Path', '/t', 'REG_EXPAND_SZ', '/d', new_path_value, '/f'],
                             check=True, capture_output=True, text=True)
                print(f"成功添加路径到PATH: {new_path}")
                print("注意: 需要重启终端或重新登录才能在新进程中生效")
            except subprocess.CalledProcessError as e:
                print(f"添加失败: {e.stderr}")
            except Exception as e:
                print(f"添加失败: {str(e)}")
                
        elif operation == 'del':
            try:
                result = subprocess.run(['reg', 'query', 'HKCU\\Environment', '/v', 'Path'],
                                      capture_output=True, text=True, check=True)
                
                for line in result.stdout.split('\n'):
                    if 'Path' in line and 'REG_' in line:
                        current_path = line.split('REG_EXPAND_SZ', 1)[-1].strip() if 'REG_EXPAND_SZ' in line else line.split('REG_SZ', 1)[-1].strip()
                        break
                else:
                    print("错误: 无法读取PATH环境变量")
                    return
            except subprocess.CalledProcessError:
                print("错误: 无法读取PATH环境变量")
                return
            
            paths = [p.strip() for p in current_path.split(';') if p.strip()]
            
            if not paths:
                print("PATH为空，没有可删除的路径")
                return
            
            path_completer = FuzzyCompleter(WordCompleter(paths))
            path_validator = PathValidator(paths)
            selected_path = prompt("选择要删除的路径: ", completer=path_completer, validator=path_validator, complete_style=CompleteStyle.MULTI_COLUMN)
            
            if selected_path not in paths:
                print(f"错误: 路径不存在于PATH中: {selected_path}")
                return
            
            confirm = prompt(f"确认删除路径: {selected_path}? (y/n): ")
            if confirm.lower() != 'y':
                print("操作已取消")
                return
            
            paths.remove(selected_path)
            new_path_value = ';'.join(paths)
            
            try:
                subprocess.run(['reg', 'add', 'HKCU\\Environment', '/v', 'Path', '/t', 'REG_EXPAND_SZ', '/d', new_path_value, '/f'],
                             check=True, capture_output=True, text=True)
                print(f"成功从PATH中删除路径: {selected_path}")
                print("注意: 需要重启终端或重新登录才能在新进程中生效")
            except subprocess.CalledProcessError as e:
                print(f"删除失败: {e.stderr}")
            except Exception as e:
                print(f"删除失败: {str(e)}")
        else:
            print("错误: 无效的操作，请选择 add 或 del")
    
    def _update_path_linux(self, operation: str):
        """Linux 平台更新 PATH"""
        config_file = self._get_shell_config_file()
        
        # 获取当前 PATH
        current_path = os.environ.get('PATH', '')
        paths = [p.strip() for p in current_path.split(':') if p.strip()]
        
        if operation == 'add':
            new_path = prompt("输入要添加的路径: ").strip()
            
            if not new_path:
                print("错误: 路径不能为空")
                return
            
            if new_path in paths:
                print(f"路径已存在于PATH中: {new_path}")
                return
            
            # 写入配置文件
            export_line = f'export PATH="$PATH:{new_path}"'
            
            try:
                with open(config_file, 'a', encoding='utf-8') as f:
                    f.write('\n' + export_line + '\n')
                
                print(f"成功添加路径到PATH: {new_path}")
                print(f"已写入配置文件: {config_file}")
                print("注意: 需要执行 'source " + config_file + "' 或重启终端才能在新进程中生效")
            except Exception as e:
                print(f"添加失败: {str(e)}")
                
        elif operation == 'del':
            if not paths:
                print("PATH为空，没有可删除的路径")
                return
            
            path_completer = FuzzyCompleter(WordCompleter(paths))
            path_validator = PathValidator(paths)
            selected_path = prompt("选择要删除的路径: ", completer=path_completer, validator=path_validator, complete_style=CompleteStyle.MULTI_COLUMN)
            
            if selected_path not in paths:
                print(f"错误: 路径不存在于PATH中: {selected_path}")
                return
            
            confirm = prompt(f"确认删除路径: {selected_path}? (y/n): ")
            if confirm.lower() != 'y':
                print("操作已取消")
                return
            
            # 尝试从配置文件中移除
            try:
                if os.path.exists(config_file):
                    with open(config_file, 'r', encoding='utf-8') as f:
                        lines = f.readlines()
                    
                    # 移除包含该路径的 PATH 设置行
                    new_lines = []
                    removed = False
                    for line in lines:
                        # 检查是否是添加该路径的行
                        if selected_path in line and 'PATH' in line and 'export' in line.lower():
                            removed = True
                            continue
                        new_lines.append(line)
                    
                    if removed:
                        with open(config_file, 'w', encoding='utf-8') as f:
                            f.writelines(new_lines)
                        print(f"已从配置文件 {config_file} 中移除路径: {selected_path}")
                    else:
                        print("警告: 在配置文件中未找到该路径的设置")
                        print("该路径可能是系统默认PATH或在其他位置设置的")
                        print("建议手动编辑相关配置文件")
                
                print(f"成功从PATH中删除路径: {selected_path}")
                print("注意: 需要执行 'source " + config_file + "' 或重启终端才能在新进程中生效")
            except Exception as e:
                print(f"删除失败: {str(e)}")
        else:
            print("错误: 无效的操作，请选择 add 或 del")