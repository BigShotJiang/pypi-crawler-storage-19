"""Miscellaneous utility functions."""
