"""Recipes for EMT."""
