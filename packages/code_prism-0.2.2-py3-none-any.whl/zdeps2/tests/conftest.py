"""
Pytest fixtures for zdeps2 tests.

Creates isolated temporary directory structures to test dependency analysis
without affecting the real codebase.
"""

import pytest
import tempfile
import shutil
from pathlib import Path


@pytest.fixture
def temp_project(tmp_path):
    """
    Creates a minimal Python project structure for testing.

    Structure:
        project/
            main.py          - imports from pkg_a
            pkg_a/
                __init__.py
                module_a.py  - imports from pkg_b
                util.py      - no imports
            pkg_b/
                __init__.py
                module_b.py  - imports util from pkg_a
                helper.py    - no imports
            orphan.py        - not imported by anything, imports nothing
    """
    project = tmp_path / "project"
    project.mkdir()

    # main.py - entry point
    (project / "main.py").write_text("""
import pkg_a.module_a
from pkg_a import util

def main():
    pkg_a.module_a.do_something()
    util.helper()

if __name__ == "__main__":
    main()
""")

    # pkg_a/
    pkg_a = project / "pkg_a"
    pkg_a.mkdir()
    (pkg_a / "__init__.py").write_text("from .module_a import do_something\n")

    (pkg_a / "module_a.py").write_text("""
from pkg_b.module_b import process

def do_something():
    return process()
""")

    (pkg_a / "util.py").write_text("""
def helper():
    return "helping"
""")

    # pkg_b/
    pkg_b = project / "pkg_b"
    pkg_b.mkdir()
    (pkg_b / "__init__.py").write_text("")

    (pkg_b / "module_b.py").write_text("""
from pkg_a.util import helper

def process():
    return helper()
""")

    (pkg_b / "helper.py").write_text("""
def standalone():
    return "standalone"
""")

    # orphan.py - not connected to anything
    (project / "orphan.py").write_text("""
def orphan_func():
    return "I am alone"
""")

    return project


@pytest.fixture
def temp_project_with_dynamic_imports(tmp_path):
    """
    Creates a project with dynamic imports for testing dynamic import detection.
    """
    project = tmp_path / "dynamic_project"
    project.mkdir()

    (project / "loader.py").write_text("""
import importlib

def load_plugin(name):
    return importlib.import_module(f"plugins.{name}")

def load_with_import(name):
    return __import__(f"plugins.{name}")
""")

    plugins = project / "plugins"
    plugins.mkdir()
    (plugins / "__init__.py").write_text("")

    (plugins / "plugin_a.py").write_text("""
def activate():
    return "Plugin A activated"
""")

    (plugins / "plugin_b.py").write_text("""
def activate():
    return "Plugin B activated"
""")

    return project


@pytest.fixture
def temp_project_with_string_refs(tmp_path):
    """
    Creates a project with string references to modules.
    """
    project = tmp_path / "string_ref_project"
    project.mkdir()

    (project / "config.py").write_text("""
HANDLER_MODULE = "handlers.user_handler"
PROCESSOR_MODULE = "handlers.data_processor"
""")

    handlers = project / "handlers"
    handlers.mkdir()
    (handlers / "__init__.py").write_text("")

    (handlers / "user_handler.py").write_text("""
def handle_user():
    return "handled"
""")

    (handlers / "data_processor.py").write_text("""
def process_data():
    return "processed"
""")

    return project


@pytest.fixture
def simple_forward_index(temp_project):
    """
    Pre-computed forward index for temp_project fixture.
    Maps each file to the files it imports.
    """
    project = temp_project

    main = (project / "main.py").resolve()
    module_a = (project / "pkg_a" / "module_a.py").resolve()
    util = (project / "pkg_a" / "util.py").resolve()
    module_b = (project / "pkg_b" / "module_b.py").resolve()
    helper = (project / "pkg_b" / "helper.py").resolve()
    orphan = (project / "orphan.py").resolve()

    return {
        main: {module_a, util},
        module_a: {module_b},
        util: set(),
        module_b: {util},
        helper: set(),
        orphan: set(),
    }


@pytest.fixture
def simple_reverse_index(simple_forward_index):
    """
    Pre-computed reverse index (who imports each file).
    """
    reverse = {f: set() for f in simple_forward_index.keys()}

    for file_path, imports in simple_forward_index.items():
        for imported in imports:
            if imported in reverse:
                reverse[imported].add(file_path)

    return reverse


@pytest.fixture
def temp_config_file(tmp_path):
    """
    Creates a temporary config file for testing config module.
    """
    config_file = tmp_path / "test_config.json"
    return config_file


@pytest.fixture
def sample_entry_points(temp_project):
    """
    Sample entry point configuration for testing.
    """
    return [
        {
            "path": "main.py",
            "label": "MAIN",
            "color": "#58a6ff",
            "emoji": "🔵",
        }
    ]
