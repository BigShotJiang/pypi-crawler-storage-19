import pytest
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from zdeps.zdeps2.api.app import create_app
from zdeps.zdeps2.core.analyzer import invalidate_cache


@pytest.fixture
def app(temp_project):
    with patch("zdeps.zdeps2.core.config.PROJECT_ROOT", temp_project):
        with patch(
            "zdeps.zdeps2.core.config.CONFIG_FILE", temp_project / "config.json"
        ):
            with patch("zdeps.zdeps2.core.analyzer.PROJECT_ROOT", temp_project):
                with patch("zdeps.zdeps2.api.routes.PROJECT_ROOT", temp_project):
                    app = create_app()
                    app.config["TESTING"] = True
                    invalidate_cache()
                    yield app


@pytest.fixture
def client(app):
    return app.test_client()


class TestIndexRoute:
    def test_index_returns_html(self, client):
        response = client.get("/")
        assert response.status_code == 200
        assert b"<!DOCTYPE html>" in response.data or b"<html" in response.data


class TestDataRoute:
    def test_api_data_returns_json(self, client, temp_project):
        config = {
            "entry_points": [
                {"path": "main.py", "label": "MAIN", "color": "#58a6ff", "emoji": "X"}
            ],
            "exclude_patterns": [".venv"],
            "exclude_files": ["__init__.py"],
            "available_colors": [
                {"id": "blue", "hex": "#58a6ff", "emoji": "X", "name": "Blue"}
            ],
        }

        with patch("zdeps.zdeps2.core.analyzer.load_config", return_value=config):
            response = client.get("/api/data")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert "tree" in data or "stats" in data


class TestRefreshRoute:
    def test_api_refresh_returns_status(self, client, temp_project):
        config = {
            "entry_points": [],
            "exclude_patterns": [".venv"],
            "exclude_files": ["__init__.py"],
            "available_colors": [],
        }

        with patch("zdeps.zdeps2.core.analyzer.load_config", return_value=config):
            response = client.get("/api/refresh")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["status"] == "refreshed"


class TestEntryPointsRoute:
    def test_add_entry_point_no_data(self, client):
        response = client.post(
            "/api/entry-points", data=None, content_type="application/json"
        )
        assert response.status_code == 400

    def test_add_entry_point_success(self, client, temp_project):
        config = {
            "entry_points": [],
            "exclude_patterns": [],
            "exclude_files": [],
            "available_colors": [],
        }

        with patch("zdeps.zdeps2.api.routes.load_config", return_value=config):
            with patch("zdeps.zdeps2.api.routes.save_config") as mock_save:
                response = client.post(
                    "/api/entry-points",
                    data=json.dumps(
                        {
                            "path": "new.py",
                            "label": "NEW",
                            "color": "#fff",
                            "emoji": "X",
                        }
                    ),
                    content_type="application/json",
                )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["status"] == "added"

    def test_add_duplicate_entry_point(self, client, temp_project):
        config = {
            "entry_points": [
                {"path": "existing.py", "label": "EXIST", "color": "#fff"}
            ],
            "exclude_patterns": [],
            "exclude_files": [],
        }

        with patch("zdeps.zdeps2.api.routes.load_config", return_value=config):
            response = client.post(
                "/api/entry-points",
                data=json.dumps(
                    {"path": "existing.py", "label": "NEW", "color": "#fff"}
                ),
                content_type="application/json",
            )

        assert response.status_code == 400
        data = json.loads(response.data)
        assert "error" in data

    def test_remove_entry_point_no_data(self, client):
        response = client.delete(
            "/api/entry-points", data=None, content_type="application/json"
        )
        assert response.status_code == 400

    def test_remove_entry_point_success(self, client, temp_project):
        config = {
            "entry_points": [{"path": "remove.py", "label": "REMOVE", "color": "#fff"}],
            "exclude_patterns": [],
            "exclude_files": [],
        }

        with patch("zdeps.zdeps2.api.routes.load_config", return_value=config):
            with patch("zdeps.zdeps2.api.routes.save_config"):
                response = client.delete(
                    "/api/entry-points",
                    data=json.dumps({"path": "remove.py"}),
                    content_type="application/json",
                )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["status"] == "removed"


class TestConfigRoute:
    def test_get_config(self, client):
        config = {"entry_points": [], "test_key": "test_value"}

        with patch("zdeps.zdeps2.api.routes.load_config", return_value=config):
            response = client.get("/api/config")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["test_key"] == "test_value"


class TestCopySnapshotRoute:
    def test_copy_snapshot_no_data(self, client):
        response = client.post(
            "/api/copy-snapshot", data=None, content_type="application/json"
        )
        assert response.status_code == 400

    def test_copy_snapshot_no_path(self, client):
        response = client.post(
            "/api/copy-snapshot", data=json.dumps({}), content_type="application/json"
        )
        assert response.status_code == 400

    def test_copy_snapshot_file_not_found(self, client, temp_project):
        config = {
            "entry_points": [],
            "exclude_patterns": [],
            "exclude_files": [],
            "available_colors": [],
        }

        with patch("zdeps.zdeps2.core.analyzer.load_config", return_value=config):
            response = client.post(
                "/api/copy-snapshot",
                data=json.dumps({"path": "nonexistent.py"}),
                content_type="application/json",
            )

        assert response.status_code == 404

    def test_copy_snapshot_success(self, client, temp_project):
        config = {
            "entry_points": [
                {"path": "main.py", "label": "MAIN", "color": "#58a6ff", "emoji": "X"}
            ],
            "exclude_patterns": [],
            "exclude_files": ["__init__.py"],
            "available_colors": [],
        }

        with patch("zdeps.zdeps2.core.analyzer.load_config", return_value=config):
            invalidate_cache()
            response = client.post(
                "/api/copy-snapshot",
                data=json.dumps({"path": "main.py", "parent_depth": 1}),
                content_type="application/json",
            )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert "content" in data
        assert "metrics" in data


class TestPreviewChildrenRoute:
    def test_preview_children_no_data(self, client):
        response = client.post(
            "/api/preview-children", data=None, content_type="application/json"
        )
        assert response.status_code == 400

    def test_preview_children_no_path(self, client):
        response = client.post(
            "/api/preview-children",
            data=json.dumps({}),
            content_type="application/json",
        )
        assert response.status_code == 400

    def test_preview_children_file_not_found(self, client, temp_project):
        config = {
            "entry_points": [],
            "exclude_patterns": [],
            "exclude_files": [],
            "available_colors": [],
        }

        with patch("zdeps.zdeps2.core.analyzer.load_config", return_value=config):
            response = client.post(
                "/api/preview-children",
                data=json.dumps({"path": "nonexistent.py"}),
                content_type="application/json",
            )

        assert response.status_code == 404

    def test_preview_children_success(self, client, temp_project):
        config = {
            "entry_points": [
                {"path": "main.py", "label": "MAIN", "color": "#58a6ff", "emoji": "X"}
            ],
            "exclude_patterns": [],
            "exclude_files": ["__init__.py"],
            "available_colors": [],
        }

        with patch("zdeps.zdeps2.core.analyzer.load_config", return_value=config):
            invalidate_cache()
            response = client.post(
                "/api/preview-children",
                data=json.dumps({"path": "main.py"}),
                content_type="application/json",
            )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert "tree" in data or "children" in data
