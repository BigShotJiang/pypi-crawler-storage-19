import pytest
import json
from pathlib import Path
from unittest.mock import patch

import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from zdeps.zdeps2.core.config import load_config, save_config, DEFAULT_GLOBAL_SETTINGS
from zdeps.zdeps2.core.tokenizer import count_tokens, count_lines, read_file_content
from zdeps.zdeps2.core.scanner import (
    get_git_submodules,
    detect_project_packages,
    should_exclude,
    scan_all_python_files,
)
from zdeps.zdeps2.core.parser import (
    ImportExtractor,
    get_all_imports,
    module_to_possible_paths,
    expand_init_imports,
    clear_parser_cache,
)
from zdeps.zdeps2.core.index import (
    build_forward_index,
    build_reverse_index,
    build_indexes,
)
from zdeps.zdeps2.core.tracer import trace_dependencies, trace_all_entry_points
from zdeps.zdeps2.core.parents import find_immediate_parents, find_parents_to_depth
from zdeps.zdeps2.core.children import (
    find_children,
    get_all_children_recursive,
    get_children_by_depth,
    get_children_with_token_limit,
    get_children_to_depth,
    build_children_tree,
    flatten_tree_with_totals,
)
from zdeps.zdeps2.core.chains import get_chain_to_entry_points
from zdeps.zdeps2.core.snapshot import generate_snapshot, SnapshotOptions
from zdeps.zdeps2.core.tree import (
    build_file_tree,
    calculate_folder_contents,
    finalize_tree,
    build_analysis_result,
)
from zdeps.zdeps2.core.analyzer import (
    AnalysisCache,
    get_cache,
    invalidate_cache,
    run_full_analysis,
    get_analysis_result,
    get_children_preview,
)


class TestConfig:
    def test_default_config_has_required_keys(self):
        # DEFAULT_GLOBAL_SETTINGS contains global settings, not per-project entry_points
        assert "exclude_patterns" in DEFAULT_GLOBAL_SETTINGS
        assert "exclude_files" in DEFAULT_GLOBAL_SETTINGS
        assert "available_colors" in DEFAULT_GLOBAL_SETTINGS

    def test_load_config_returns_defaults_when_no_file(self, tmp_path):
        with patch(
            "zdeps.zdeps2.core.config.CONFIG_FILE", tmp_path / "nonexistent.json"
        ):
            with patch("zdeps.zdeps2.core.config._config_cache", None):
                config = load_config()
                # New config structure returns project_root, entry_points, and global settings
                assert "project_root" in config
                assert "entry_points" in config
                assert "exclude_patterns" in config

    def test_save_and_load_config(self, tmp_path):
        config_file = tmp_path / "test_config.json"
        test_config = {
            "entry_points": [
                {"path": "test.py", "label": "TEST", "color": "#fff", "emoji": "X"}
            ]
        }

        with patch("zdeps.zdeps2.core.config.CONFIG_FILE", config_file):
            save_config(test_config)
            assert config_file.exists()

            loaded = load_config()
            assert loaded["entry_points"] == test_config["entry_points"]
            assert "exclude_patterns" in loaded


class TestTokenizer:
    def test_count_tokens_empty_string(self):
        assert count_tokens("") == 0

    def test_count_tokens_simple_text(self):
        result = count_tokens("hello world")
        assert result > 0

    def test_count_tokens_code(self):
        code = "def foo():\n    return 42"
        result = count_tokens(code)
        assert result > 0

    def test_count_lines_nonexistent_file(self, tmp_path):
        assert count_lines(tmp_path / "nonexistent.py") == 0

    def test_count_lines_file(self, tmp_path):
        test_file = tmp_path / "test.py"
        test_file.write_text("line1\nline2\nline3")
        assert count_lines(test_file) == 3

    def test_read_file_content(self, tmp_path):
        test_file = tmp_path / "test.py"
        test_file.write_text("content here")
        assert read_file_content(test_file) == "content here"

    def test_read_file_content_nonexistent(self, tmp_path):
        result = read_file_content(tmp_path / "nonexistent.py")
        assert "Error" in result


class TestScanner:
    def test_get_git_submodules_no_file(self, tmp_path):
        assert get_git_submodules(tmp_path) == []

    def test_get_git_submodules_with_file(self, tmp_path):
        gitmodules = tmp_path / ".gitmodules"
        gitmodules.write_text(
            '[submodule "vendor/lib"]\n\tpath = vendor/lib\n\turl = https://example.com'
        )
        result = get_git_submodules(tmp_path)
        assert "vendor/lib" in result

    def test_detect_project_packages(self, temp_project):
        packages = detect_project_packages(temp_project)
        assert "pkg_a" in packages
        assert "pkg_b" in packages

    def test_should_exclude_pattern(self):
        assert should_exclude(Path("/project/.venv/lib.py"), [".venv"], [])
        assert not should_exclude(Path("/project/src/lib.py"), [".venv"], [])

    def test_should_exclude_file(self):
        assert should_exclude(Path("/project/__init__.py"), [], ["__init__.py"])
        assert not should_exclude(Path("/project/main.py"), [], ["__init__.py"])

    def test_scan_all_python_files(self, temp_project):
        config = {"exclude_patterns": [".venv"], "exclude_files": ["__init__.py"]}
        files = scan_all_python_files(temp_project, config)

        file_names = {f.name for f in files}
        assert "main.py" in file_names
        assert "module_a.py" in file_names
        assert "orphan.py" in file_names
        assert "__init__.py" not in file_names


class TestParser:
    def setup_method(self):
        clear_parser_cache()

    def test_import_extractor_simple_import(self):
        import ast

        code = "import os"
        tree = ast.parse(code)
        extractor = ImportExtractor(frozenset())
        extractor.visit(tree)
        assert "os" in extractor.imports

    def test_import_extractor_from_import(self):
        import ast

        code = "from pathlib import Path"
        tree = ast.parse(code)
        extractor = ImportExtractor(frozenset())
        extractor.visit(tree)
        assert "pathlib" in extractor.imports

    def test_import_extractor_dynamic_import(self):
        import ast

        code = 'importlib.import_module("mymodule")'
        tree = ast.parse(code)
        extractor = ImportExtractor(frozenset())
        extractor.visit(tree)
        assert "mymodule" in extractor.dynamic_imports

    def test_get_all_imports(self, temp_project):
        main_file = temp_project / "main.py"
        static, dynamic, potential = get_all_imports(main_file, ["pkg_a", "pkg_b"])
        assert "pkg_a.module_a" in static
        assert "pkg_a" in static

    def test_module_to_possible_paths(self, temp_project):
        source = temp_project / "main.py"
        paths = module_to_possible_paths("pkg_a.module_a", source, temp_project)
        path_strs = [str(p) for p in paths]
        assert any("pkg_a/module_a.py" in p for p in path_strs)

    def test_expand_init_imports(self, temp_project):
        init_file = temp_project / "pkg_a" / "__init__.py"
        expanded = expand_init_imports(init_file, ["pkg_a", "pkg_b"])
        names = [p.name for p in expanded]
        assert "module_a.py" in names


class TestIndex:
    def test_build_forward_index(self, temp_project):
        config = {"exclude_patterns": [], "exclude_files": ["__init__.py"]}
        all_files = scan_all_python_files(temp_project, config)
        packages = detect_project_packages(temp_project)

        forward = build_forward_index(all_files, temp_project, packages, parallel=False)

        main_file = (temp_project / "main.py").resolve()
        assert main_file in forward

        imported_names = {f.name for f in forward[main_file]}
        assert "module_a.py" in imported_names or "util.py" in imported_names

    def test_build_reverse_index(self, simple_forward_index):
        reverse = build_reverse_index(simple_forward_index)

        for file_path in simple_forward_index:
            assert file_path in reverse

    def test_build_indexes_returns_both(self, temp_project):
        config = {"exclude_patterns": [], "exclude_files": ["__init__.py"]}
        all_files = scan_all_python_files(temp_project, config)
        packages = detect_project_packages(temp_project)

        forward, reverse = build_indexes(
            all_files, temp_project, packages, parallel=False
        )

        assert len(forward) > 0
        assert len(reverse) > 0
        assert len(forward) == len(reverse)


class TestTracer:
    def test_trace_dependencies_from_entry(self, temp_project):
        config = {"exclude_patterns": [], "exclude_files": ["__init__.py"]}
        all_files = scan_all_python_files(temp_project, config)
        packages = detect_project_packages(temp_project)
        entry = temp_project / "main.py"

        visited, conn_paths, import_types = trace_dependencies(
            entry, all_files, temp_project, packages
        )

        assert entry.resolve() in visited
        assert len(visited) > 1

    def test_trace_all_entry_points(self, temp_project, sample_entry_points):
        config = {"exclude_patterns": [], "exclude_files": ["__init__.py"]}
        all_files = scan_all_python_files(temp_project, config)
        packages = detect_project_packages(temp_project)

        results = trace_all_entry_points(
            sample_entry_points, all_files, temp_project, packages, parallel=False
        )

        assert "MAIN" in results
        assert "connected" in results["MAIN"]
        assert "connection_paths" in results["MAIN"]


class TestParents:
    def test_find_immediate_parents(self, simple_forward_index, simple_reverse_index):
        files = list(simple_forward_index.keys())
        util_file = [f for f in files if f.name == "util.py"][0]

        parents = find_immediate_parents(util_file, simple_reverse_index)
        parent_names = {p.name for p in parents}

        assert "main.py" in parent_names or "module_b.py" in parent_names

    def test_find_parents_to_depth(self, simple_forward_index, simple_reverse_index):
        files = list(simple_forward_index.keys())
        util_file = [f for f in files if f.name == "util.py"][0]

        parents = find_parents_to_depth(util_file, simple_reverse_index, None, depth=2)

        assert len(parents) >= 1


class TestChildren:
    def test_find_children(self, simple_forward_index):
        files = list(simple_forward_index.keys())
        main_file = [f for f in files if f.name == "main.py"][0]

        children = find_children(main_file, simple_forward_index)
        child_names = {c.name for c in children}

        assert len(children) > 0

    def test_get_all_children_recursive(self, simple_forward_index):
        files = list(simple_forward_index.keys())
        main_file = [f for f in files if f.name == "main.py"][0]

        all_children = get_all_children_recursive(main_file, simple_forward_index)

        assert len(all_children) > 0

    def test_get_children_by_depth(self, simple_forward_index):
        files = list(simple_forward_index.keys())
        main_file = [f for f in files if f.name == "main.py"][0]

        levels = get_children_by_depth(main_file, simple_forward_index, max_depth=2)

        assert 1 in levels

    def test_get_children_to_depth(self, simple_forward_index):
        files = list(simple_forward_index.keys())
        main_file = [f for f in files if f.name == "main.py"][0]

        children = get_children_to_depth(main_file, simple_forward_index, max_depth=1)

        assert len(children) > 0

    def test_build_children_tree(self, temp_project, simple_forward_index):
        files = list(simple_forward_index.keys())
        main_file = [f for f in files if f.name == "main.py"][0]

        tree = build_children_tree(main_file, simple_forward_index, temp_project)

        assert "name" in tree
        assert "children" in tree
        assert tree["is_root"] is True

    def test_flatten_tree_with_totals(self, temp_project, simple_forward_index):
        files = list(simple_forward_index.keys())
        main_file = [f for f in files if f.name == "main.py"][0]

        tree = build_children_tree(main_file, simple_forward_index, temp_project)
        flat_list, totals = flatten_tree_with_totals(tree)

        assert "files" in totals
        assert "lines" in totals
        assert "tokens" in totals


class TestChains:
    def test_get_chain_to_entry_points(self, temp_project, sample_entry_points):
        config = {"exclude_patterns": [], "exclude_files": ["__init__.py"]}
        all_files = scan_all_python_files(temp_project, config)
        packages = detect_project_packages(temp_project)

        traces = trace_all_entry_points(
            sample_entry_points, all_files, temp_project, packages, parallel=False
        )

        module_a = temp_project / "pkg_a" / "module_a.py"
        chains = get_chain_to_entry_points(module_a, traces, temp_project)

        if chains:
            assert "MAIN" in chains
            assert "chain" in chains["MAIN"]


class TestSnapshot:
    def test_snapshot_options_defaults(self):
        opts = SnapshotOptions()
        assert opts.parent_depth == 1
        assert opts.include_chain is False
        assert opts.child_depth == 0
        assert opts.excluded_children == set()

    def test_generate_snapshot_file_not_found(self, temp_project):
        opts = SnapshotOptions()
        result = generate_snapshot(
            "nonexistent.py", opts, temp_project, {}, {}, set(), {}
        )
        assert "error" in result

    def test_generate_snapshot_basic(self, temp_project):
        config = {"exclude_patterns": [], "exclude_files": ["__init__.py"]}
        all_files = scan_all_python_files(temp_project, config)
        packages = detect_project_packages(temp_project)
        forward, reverse = build_indexes(
            all_files, temp_project, packages, parallel=False
        )

        opts = SnapshotOptions(parent_depth=1, child_depth=1)
        result = generate_snapshot(
            "main.py", opts, temp_project, reverse, forward, set(all_files), {}
        )

        assert "content" in result
        assert "metrics" in result
        assert "DEPENDENCY SNAPSHOT" in result["content"]
        assert "main.py" in result["content"]


class TestTree:
    def test_build_file_tree(self, temp_project):
        config = {"exclude_patterns": [], "exclude_files": ["__init__.py"]}
        all_files = scan_all_python_files(temp_project, config)
        packages = detect_project_packages(temp_project)
        traces = trace_all_entry_points(
            [{"path": "main.py", "label": "MAIN", "color": "#fff", "emoji": "X"}],
            all_files,
            temp_project,
            packages,
            parallel=False,
        )

        file_connections = {}
        all_connection_paths = {}
        all_import_types = {}

        for label, data in traces.items():
            all_connection_paths[label] = data["connection_paths"]
            all_import_types[label] = data["import_types"]
            for rel_path in data["connected"]:
                if rel_path not in file_connections:
                    file_connections[rel_path] = []
                file_connections[rel_path].append(
                    {
                        "label": label,
                        "color": "#fff",
                        "emoji": "X",
                        "entry": data["entry_info"]["path"],
                    }
                )

        tree, orphans = build_file_tree(
            all_files,
            file_connections,
            all_connection_paths,
            all_import_types,
            [{"path": "main.py", "label": "MAIN", "color": "#fff", "emoji": "X"}],
            temp_project,
        )

        assert "pkg_a" in tree or "main.py" in tree
        assert isinstance(orphans, set)

    def test_finalize_tree(self, temp_project):
        simple_tree = {
            "folder": {
                "_type": "folder",
                "_children": {
                    "file.py": {
                        "_type": "file",
                        "_path": "folder/file.py",
                        "_orphan": True,
                        "_entry_point": False,
                        "_connections": [],
                        "_connection_paths": {},
                    }
                },
            }
        }

        finalize_tree(simple_tree)
        assert "_contains" in simple_tree["folder"]

    def test_build_analysis_result(self, temp_project):
        all_files = {temp_project / "main.py", temp_project / "orphan.py"}
        file_connections = {"main.py": [{"label": "MAIN"}]}
        orphans = {"orphan.py"}
        entry_point_info = {"MAIN": {"path": "main.py", "color": "#fff"}}
        entry_points = [{"path": "main.py", "label": "MAIN", "color": "#fff"}]
        available_colors = [{"id": "blue", "hex": "#58a6ff"}]

        result = build_analysis_result(
            {},
            all_files,
            file_connections,
            orphans,
            entry_point_info,
            entry_points,
            available_colors,
        )

        assert "tree" in result
        assert "stats" in result
        assert "entry_points" in result
        assert "config" in result
        assert result["stats"]["total"] == 2
        assert result["stats"]["orphans"] == 1


class TestAnalyzer:
    def test_analysis_cache_is_valid(self):
        cache = AnalysisCache()
        assert cache.is_valid() is False

        cache.all_py_files = {Path("/test.py")}
        cache.last_updated = 1.0
        assert cache.is_valid() is True

    def test_get_cache_returns_same_instance(self):
        invalidate_cache()
        cache1 = get_cache()
        cache2 = get_cache()
        assert cache1 is cache2

    def test_invalidate_cache(self):
        cache1 = get_cache()
        cache1.last_updated = 1.0

        invalidate_cache()
        cache2 = get_cache()

        assert cache2.last_updated == 0.0


class TestIntegration:
    def test_full_analysis_workflow(self, temp_project):
        with patch("zdeps.zdeps2.core.config.PROJECT_ROOT", temp_project):
            with patch(
                "zdeps.zdeps2.core.config.CONFIG_FILE", temp_project / "config.json"
            ):
                invalidate_cache()

                config = {
                    "entry_points": [
                        {
                            "path": "main.py",
                            "label": "MAIN",
                            "color": "#58a6ff",
                            "emoji": "X",
                        }
                    ],
                    "exclude_patterns": [".venv"],
                    "exclude_files": ["__init__.py"],
                    "available_colors": [
                        {"id": "blue", "hex": "#58a6ff", "emoji": "X", "name": "Blue"}
                    ],
                }

                with patch(
                    "zdeps.zdeps2.core.analyzer.load_config", return_value=config
                ):
                    with patch("zdeps.zdeps2.core.analyzer.PROJECT_ROOT", temp_project):
                        result = run_full_analysis(config)

                assert "tree" in result
                assert "stats" in result
                assert result["stats"]["total"] > 0

    def test_children_preview_workflow(self, temp_project):
        with patch("zdeps.zdeps2.core.config.PROJECT_ROOT", temp_project):
            with patch("zdeps.zdeps2.core.analyzer.PROJECT_ROOT", temp_project):
                invalidate_cache()

                config = {
                    "entry_points": [
                        {
                            "path": "main.py",
                            "label": "MAIN",
                            "color": "#58a6ff",
                            "emoji": "X",
                        }
                    ],
                    "exclude_patterns": [".venv"],
                    "exclude_files": ["__init__.py"],
                    "available_colors": [],
                }

                with patch(
                    "zdeps.zdeps2.core.analyzer.load_config", return_value=config
                ):
                    run_full_analysis(config)
                    result = get_children_preview("main.py")

                assert "tree" in result or "error" in result
