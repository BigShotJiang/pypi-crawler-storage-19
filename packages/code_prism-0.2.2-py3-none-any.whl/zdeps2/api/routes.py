import os
from pathlib import Path
from flask import Blueprint, jsonify, request, render_template
from ..core.config import (
    load_config,
    save_config,
    get_project_root,
    reload_config,
    toggle_entry_point,
    switch_project,
    get_recent_projects,
    get_enabled_entry_points,
    get_excluded_submodules,
    toggle_submodule,
)
from ..core.scanner import get_git_submodules
from ..core.analyzer import (
    run_full_analysis,
    get_analysis_result,
    get_children_preview,
    get_full_dependency_info,
    invalidate_cache,
    get_cache,
    suggest_entry_points,
    get_frontend_preview,
)
from ..core.frontend_children import get_frontend_files_from_tree
from ..core.snapshot import generate_snapshot, SnapshotOptions

api = Blueprint("api", __name__)


@api.route("/")
def index():
    return render_template("index.html")


@api.route("/api/data")
def get_data():
    return jsonify(get_analysis_result())


@api.route("/api/refresh")
def refresh_data():
    reload_config()
    invalidate_cache()
    run_full_analysis()
    return jsonify({"status": "refreshed"})


@api.route("/api/entry-points", methods=["POST"])
def add_entry_point():
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400

    config = load_config()

    for ep in config["entry_points"]:
        if ep["path"] == data["path"]:
            return jsonify({"error": "Entry point already exists"}), 400

    config["entry_points"].append(
        {
            "path": data["path"],
            "label": data["label"],
            "color": data["color"],
            "emoji": data.get("emoji", "🔵"),
            "enabled": True,
        }
    )

    save_config(config)
    invalidate_cache()
    return jsonify({"status": "added"})


@api.route("/api/entry-points", methods=["DELETE"])
def remove_entry_point():
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400

    config = load_config()
    config["entry_points"] = [
        ep for ep in config["entry_points"] if ep["path"] != data["path"]
    ]

    save_config(config)
    invalidate_cache()
    return jsonify({"status": "removed"})


@api.route("/api/entry-points/toggle", methods=["POST"])
def toggle_entry_point_route():
    data = request.json
    if not data or "path" not in data:
        return jsonify({"error": "No path provided"}), 400

    new_state = toggle_entry_point(data["path"])
    invalidate_cache()
    return jsonify({"status": "toggled", "enabled": new_state})


@api.route("/api/config")
def get_config():
    return jsonify(load_config())


@api.route("/api/copy-snapshot", methods=["POST"])
def copy_snapshot():
    data = request.json
    if not data or "path" not in data:
        return jsonify({"error": "No file path provided"}), 400

    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    options = SnapshotOptions(
        parent_depth=data.get("parent_depth", 1),
        include_chain=data.get("include_chain", False),
        chain_length=data.get("chain_length"),
        child_depth=data.get("child_depth", 0),
        child_max_tokens=data.get("child_max_tokens", 0),
        excluded_children=set(data.get("excluded_children", [])),
        include_frontend=data.get("include_frontend", False),
        excluded_frontend=set(data.get("excluded_frontend", [])),
    )

    project_root = get_project_root()

    # Get frontend files if requested
    frontend_files = None
    if options.include_frontend:
        frontend_result = get_frontend_preview(data["path"])
        if "tree" in frontend_result and frontend_result["tree"].get("children"):
            frontend_files = get_frontend_files_from_tree(
                frontend_result["tree"], project_root
            )

    result = generate_snapshot(
        data["path"],
        options,
        project_root,
        cache.reverse_index,
        cache.forward_index,
        cache.connected_files,
        cache.entry_point_traces,
        frontend_files=frontend_files,
    )

    if "error" in result:
        return jsonify(result), 404

    return jsonify(result)


@api.route("/api/preview-children", methods=["POST"])
def preview_children():
    data = request.json
    if not data or "path" not in data:
        return jsonify({"error": "No file path provided"}), 400

    result = get_children_preview(data["path"])

    if "error" in result:
        return jsonify(result), 404

    return jsonify(result)


@api.route("/api/preview-frontend", methods=["POST"])
def preview_frontend():
    """Preview front-end dependencies for a Python file that uses templates."""
    data = request.json
    if not data or "path" not in data:
        return jsonify({"error": "No file path provided"}), 400

    result = get_frontend_preview(data["path"])

    if "error" in result:
        return jsonify(result), 404

    return jsonify(result)


@api.route("/api/full-dependencies", methods=["POST"])
def full_dependencies():
    data = request.json
    if not data or "path" not in data:
        return jsonify({"error": "No file path provided"}), 400

    result = get_full_dependency_info(data["path"])

    if "error" in result:
        return jsonify(result), 404

    return jsonify(result)


@api.route("/api/project-root", methods=["POST"])
def set_project_root():
    data = request.json
    if not data or "path" not in data:
        return jsonify({"error": "No path provided"}), 400

    new_root = Path(data["path"]).expanduser().resolve()
    if not new_root.exists():
        return jsonify({"error": f"Path does not exist: {new_root}"}), 400
    if not new_root.is_dir():
        return jsonify({"error": f"Path is not a directory: {new_root}"}), 400

    switch_project(str(new_root))
    reload_config()
    invalidate_cache()
    run_full_analysis()

    return jsonify({"status": "updated", "project_root": str(new_root)})


@api.route("/api/suggest-entry-points")
def get_suggested_entry_points():
    top_n = request.args.get("limit", 500, type=int)
    include_tests = request.args.get("include_tests", "false").lower() == "true"
    suggestions = suggest_entry_points(top_n, include_tests)
    return jsonify({"suggestions": suggestions, "count": len(suggestions)})


@api.route("/api/recent-projects")
def get_recent_projects_route():
    projects = get_recent_projects()
    result = []
    for project_path in projects:
        path = Path(project_path)
        result.append(
            {
                "path": project_path,
                "name": path.name,
                "exists": path.exists(),
            }
        )
    return jsonify({"projects": result})


@api.route("/api/browse-directory", methods=["POST"])
def browse_directory():
    data = request.json or {}
    target_path = data.get("path", str(Path.home()))

    path = Path(target_path).expanduser().resolve()
    if not path.exists():
        path = Path.home()
    if not path.is_dir():
        path = path.parent

    folders = []
    files_count = 0

    try:
        for item in sorted(path.iterdir(), key=lambda x: x.name.lower()):
            if item.name.startswith("."):
                continue
            if item.is_dir():
                folders.append(
                    {
                        "name": item.name,
                        "path": str(item),
                    }
                )
            else:
                files_count += 1
    except PermissionError:
        pass

    parent = str(path.parent) if path.parent != path else None

    return jsonify(
        {
            "current": str(path),
            "parent": parent,
            "folders": folders,
            "files_count": files_count,
        }
    )


@api.route("/api/autocomplete-path", methods=["POST"])
def autocomplete_path():
    data = request.json or {}
    partial_path = data.get("path", "")

    if not partial_path:
        return jsonify({"suggestions": []})

    path = Path(partial_path).expanduser()

    if partial_path.endswith("/") or partial_path.endswith(os.sep):
        search_dir = path
        prefix = ""
    else:
        search_dir = path.parent
        prefix = path.name.lower()

    if not search_dir.exists():
        return jsonify({"suggestions": []})

    suggestions = []
    try:
        for item in sorted(search_dir.iterdir(), key=lambda x: x.name.lower()):
            if item.name.startswith("."):
                continue
            if item.is_dir() and item.name.lower().startswith(prefix):
                suggestions.append(
                    {
                        "name": item.name,
                        "path": str(item),
                    }
                )
                if len(suggestions) >= 10:
                    break
    except PermissionError:
        pass

    return jsonify({"suggestions": suggestions})


@api.route("/api/orphans/list")
def list_orphans():
    from ..core.cleaner import get_orphan_files

    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    project_root = get_project_root()
    files = get_orphan_files(cache.orphans, project_root)

    return jsonify({"files": files, "count": len(files)})


@api.route("/api/orphans/preview-delete", methods=["POST"])
def preview_orphan_delete():
    from ..core.cleaner import preview_deletion

    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    project_root = get_project_root()
    result = preview_deletion(cache.orphans, project_root)

    return jsonify(result)


@api.route("/api/orphans/delete", methods=["POST"])
def delete_orphans_route():
    from ..core.cleaner import delete_orphans

    data = request.json or {}
    if data.get("confirmation") != "DELETE":
        return jsonify(
            {"error": "Confirmation required. Send confirmation: 'DELETE'"}
        ), 400

    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    project_root = get_project_root()
    result = delete_orphans(cache.orphans, project_root)

    if result["errors"]:
        result["error"] = "; ".join(result["errors"][:5])

    return jsonify(result)


@api.route("/api/submodules")
def get_submodules():
    project_root = get_project_root()
    all_submodules = get_git_submodules(project_root)
    excluded = get_excluded_submodules()

    result = []
    for submodule in all_submodules:
        if excluded is None:
            is_included = False
        else:
            is_included = submodule not in excluded
        result.append(
            {
                "path": submodule,
                "included": is_included,
            }
        )

    return jsonify({"submodules": result, "count": len(result)})


@api.route("/api/submodules/toggle", methods=["POST"])
def toggle_submodule_route():
    data = request.json
    if not data or "path" not in data:
        return jsonify({"error": "No path provided"}), 400

    project_root = get_project_root()
    all_submodules = get_git_submodules(project_root)

    if data["path"] not in all_submodules:
        return jsonify({"error": "Not a valid submodule"}), 400

    now_included = toggle_submodule(data["path"], all_submodules)
    invalidate_cache()

    return jsonify({"status": "toggled", "included": now_included})


@api.route("/api/analyze", methods=["POST"])
def analyze_snapshot_route():
    """Analyze a code snapshot using Claude AI and return tiered summaries."""
    import os
    from ..core.ai.analyzer import analyze_snapshot
    from ..core.ai.cache import SemanticCache

    data = request.json
    if not data or "snapshot_content" not in data:
        return jsonify({"error": "No snapshot content provided"}), 400

    # Use API key from request, or fall back to environment variable
    api_key = data.get("api_key") or os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        return jsonify({"error": "API key required (provide in request or set ANTHROPIC_API_KEY env var)"}), 400

    snapshot_content = data["snapshot_content"]

    try:
        result = analyze_snapshot(snapshot_content, api_key=api_key)

        if "error" in result:
            return jsonify(result), 500

        # Save to cache
        project_root = get_project_root()
        cache = SemanticCache(project_root)
        cache.update_analysis(result)

        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@api.route("/api/ai-config")
def get_ai_config():
    """Get AI configuration (API key availability)."""
    import os
    api_key = os.getenv("ANTHROPIC_API_KEY")
    return jsonify({
        "has_api_key": bool(api_key),
        "api_key_prefix": api_key[:10] + "..." if api_key else None
    })


@api.route("/api/analysis-cache")
def get_analysis_cache():
    """Get cached analysis results."""
    from ..core.ai.cache import SemanticCache

    project_root = get_project_root()
    cache = SemanticCache(project_root)
    analysis = cache.get_analysis()

    return jsonify(analysis)


@api.route("/api/analysis-cache/stats")
def get_cache_stats():
    """Get cache statistics."""
    from ..core.ai.cache import SemanticCache

    project_root = get_project_root()
    cache = SemanticCache(project_root)
    stats = cache.get_stats()

    return jsonify(stats)


@api.route("/api/analysis-cache/clear", methods=["POST"])
def clear_analysis_cache():
    """Clear all cached analysis."""
    from ..core.ai.cache import SemanticCache

    project_root = get_project_root()
    cache = SemanticCache(project_root)
    cache.clear()

    return jsonify({"status": "cleared"})


@api.route("/api/query-snapshot", methods=["POST"])
def query_snapshot_route():
    """Ask questions about a snapshot using Claude AI.

    The snapshot content and analysis are provided as context,
    allowing Claude to answer questions without reading raw code.
    """
    import os
    from ..core.ai.client import ClaudeClient

    data = request.json
    if not data or "question" not in data:
        return jsonify({"error": "No question provided"}), 400

    if "snapshot_content" not in data:
        return jsonify({"error": "No snapshot content provided"}), 400

    # Use API key from request, or fall back to environment variable
    api_key = data.get("api_key") or os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        return jsonify({"error": "API key required"}), 400

    question = data["question"]
    snapshot_content = data["snapshot_content"]
    analysis_data = data.get("analysis", {})

    # Build context message with snapshot + analysis
    context_parts = []

    # Add system overview if available
    if analysis_data.get("overview"):
        overview = analysis_data["overview"]
        context_parts.append("# SYSTEM OVERVIEW\n")
        context_parts.append(f"Architecture: {overview.get('architecture', 'N/A')}\n")
        context_parts.append(f"Entry Points: {', '.join(overview.get('entry_points', []))}\n")
        context_parts.append(f"Key Patterns: {', '.join(overview.get('key_patterns', []))}\n")
        if overview.get('warnings'):
            context_parts.append(f"Warnings: {', '.join(overview.get('warnings', []))}\n")
        context_parts.append("\n")

    # Add file analyses if available
    if analysis_data.get("files"):
        context_parts.append("# FILE ANALYSES\n\n")
        for file_path, file_analysis in analysis_data["files"].items():
            context_parts.append(f"## {file_path}\n")
            context_parts.append(f"Layer: {file_analysis.get('layer', 'unknown')}\n")
            context_parts.append(f"Summary: {file_analysis.get('tier1', 'N/A')}\n")
            context_parts.append(f"Details: {file_analysis.get('tier2', 'N/A')}\n\n")

    # Add full snapshot
    context_parts.append("# FULL CODE SNAPSHOT\n\n")
    context_parts.append(snapshot_content)

    context_message = "".join(context_parts)

    # Build messages for Claude
    system_prompt = """You are a codebase assistant. You have been provided with:
1. A dependency snapshot showing related files
2. AI-generated analysis of each file (Tier 1 & 2 summaries)
3. The full source code of all files in the snapshot

Your job is to answer questions about how the codebase works based on this context.
Focus on explaining structure, relationships, and flow rather than implementation details.
Be concise and specific."""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"{context_message}\n\n---\n\nQuestion: {question}"}
    ]

    try:
        client = ClaudeClient(api_key=api_key)

        # Extract system message
        system_message = None
        user_messages = []
        for msg in messages:
            if msg['role'] == 'system':
                system_message = msg['content']
            else:
                user_messages.append(msg)

        # Call Claude
        response = client.client.messages.create(
            model=client.model,
            max_tokens=4000,
            system=system_message if system_message else None,
            messages=user_messages
        )

        # Extract text
        answer = ""
        for block in response.content:
            if hasattr(block, 'text'):
                answer += block.text

        return jsonify({
            "question": question,
            "answer": answer
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500
