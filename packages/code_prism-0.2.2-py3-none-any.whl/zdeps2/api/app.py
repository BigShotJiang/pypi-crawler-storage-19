from pathlib import Path
from flask import Flask, send_from_directory
from .routes import api
from dotenv import load_dotenv

# Load .env file from project root
project_root = Path(__file__).parent.parent.parent
dotenv_path = project_root / ".env"
if dotenv_path.exists():
    load_dotenv(dotenv_path)

# Get the zdeps2 package directory
PACKAGE_DIR = Path(__file__).parent.parent


def create_app():
    app = Flask(
        __name__,
        static_folder=str(PACKAGE_DIR / "static"),
        static_url_path="/static",
    )

    # Serve static index.html at root
    @app.route("/")
    def index():
        return app.send_static_file('index.html')

    # Serve Prism UI
    @app.route("/prism")
    def prism():
        return app.send_static_file('prism.html')

    # Serve Simple UI
    @app.route("/simple")
    def simple():
        return app.send_static_file('simple.html')

    # Serve V2 UI
    @app.route("/v2")
    def v2():
        return app.send_static_file('v2.html')

    app.register_blueprint(api)
    return app


app = create_app()

