"""Prompt templates for tiered code analysis."""

SYSTEM_PROMPT = """You are a code analysis assistant. Your job is to analyze Python code and provide structured summaries at different levels of detail.

You will receive a code snapshot containing multiple files. For each file, provide:
1. Tier 1 (one sentence): A concise summary of what the file does
2. Tier 2 (paragraph): A more detailed explanation including key functions, classes, and how it fits into the system

Additionally, provide a system-level overview that explains the high-level architecture.

Return your analysis as valid JSON in this exact format:
{
  "overview": {
    "architecture": "High-level description of the system architecture and how components work together",
    "entry_points": ["List", "of", "main entry point files"],
    "key_patterns": ["Important", "patterns", "or", "conventions", "to", "know"],
    "warnings": ["Things", "to", "watch", "out", "for"]
  },
  "files": {
    "path/to/file.py": {
      "tier1": "One sentence summary here",
      "tier2": "Detailed paragraph here including key functions: func1(), func2(). Explains relationships and purpose.",
      "layer": "api|core|frontend|utility"
    }
  }
}

Be concise but informative. Focus on WHAT the code does and WHY it exists, not HOW it's implemented line-by-line."""


def create_analysis_prompt(snapshot_content: str) -> str:
    """Create the user prompt for code analysis.

    Args:
        snapshot_content: The full snapshot text from generate_snapshot()

    Returns:
        Formatted prompt string
    """
    return f"""Analyze the following code snapshot and provide Tier 1 and Tier 2 summaries for each file.

{snapshot_content}

Return ONLY valid JSON with no additional text or markdown formatting."""


def create_messages(snapshot_content: str):
    """Create message list for Claude API.

    Args:
        snapshot_content: The full snapshot text

    Returns:
        List of message dicts
    """
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": create_analysis_prompt(snapshot_content)}
    ]
