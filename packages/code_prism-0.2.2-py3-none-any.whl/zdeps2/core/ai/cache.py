"""Persistent cache for AI analysis results."""
import json
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime


class SemanticCache:
    """Manages persistent storage of AI analysis results."""

    def __init__(self, project_root: Path):
        """Initialize cache for a project.

        Args:
            project_root: Root directory of the project being analyzed
        """
        self.project_root = project_root
        self.cache_dir = project_root / ".zdeps_cache"
        self.cache_file = self.cache_dir / "semantic_cache.json"
        self.cache_data = self._load_cache()

    def _load_cache(self) -> Dict[str, Any]:
        """Load cache from disk."""
        if not self.cache_file.exists():
            return {
                "version": "1.0",
                "project_root": str(self.project_root),
                "last_updated": None,
                "overview": None,
                "files": {}
            }

        try:
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Warning: Could not load semantic cache: {e}")
            return {
                "version": "1.0",
                "project_root": str(self.project_root),
                "last_updated": None,
                "overview": None,
                "files": {}
            }

    def save(self) -> None:
        """Save cache to disk."""
        # Create cache directory if it doesn't exist
        self.cache_dir.mkdir(exist_ok=True)

        # Update timestamp
        self.cache_data["last_updated"] = datetime.now().isoformat()

        try:
            with open(self.cache_file, 'w', encoding='utf-8') as f:
                json.dump(self.cache_data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Warning: Could not save semantic cache: {e}")

    def update_analysis(self, analysis_result: Dict[str, Any]) -> None:
        """Update cache with new analysis results.

        Args:
            analysis_result: Analysis result from Claude with 'overview' and 'files' keys
        """
        # Update overview
        if "overview" in analysis_result:
            self.cache_data["overview"] = analysis_result["overview"]

        # Update file analyses
        if "files" in analysis_result:
            for file_path, file_analysis in analysis_result["files"].items():
                self.cache_data["files"][file_path] = {
                    **file_analysis,
                    "analyzed_at": datetime.now().isoformat()
                }

        self.save()

    def get_analysis(self) -> Dict[str, Any]:
        """Get all cached analysis results.

        Returns:
            Dict with 'overview' and 'files' keys
        """
        return {
            "overview": self.cache_data.get("overview"),
            "files": self.cache_data.get("files", {})
        }

    def get_file_analysis(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Get cached analysis for a specific file.

        Args:
            file_path: Relative path to file from project root

        Returns:
            File analysis dict or None if not cached
        """
        return self.cache_data.get("files", {}).get(file_path)

    def clear(self) -> None:
        """Clear all cached analysis."""
        self.cache_data = {
            "version": "1.0",
            "project_root": str(self.project_root),
            "last_updated": None,
            "overview": None,
            "files": {}
        }
        self.save()

    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics.

        Returns:
            Dict with cache stats
        """
        return {
            "total_files_analyzed": len(self.cache_data.get("files", {})),
            "has_overview": self.cache_data.get("overview") is not None,
            "last_updated": self.cache_data.get("last_updated"),
            "cache_file": str(self.cache_file),
            "cache_exists": self.cache_file.exists()
        }
