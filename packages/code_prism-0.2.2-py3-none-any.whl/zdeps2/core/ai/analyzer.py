"""Main orchestrator for AI-powered code analysis."""
import json
from typing import Dict, Any
from .client import ClaudeClient
from .prompts import create_messages


def analyze_snapshot(snapshot_content: str, api_key: str = None) -> Dict[str, Any]:
    """Analyze a code snapshot and return tiered summaries.

    Args:
        snapshot_content: The full snapshot text from generate_snapshot()
        api_key: Optional Anthropic API key

    Returns:
        Dict with structure:
        {
            "files": {
                "path/to/file.py": {
                    "tier1": "One sentence summary",
                    "tier2": "Detailed paragraph"
                }
            }
        }

    Raises:
        ValueError: If API key is missing
        json.JSONDecodeError: If Claude returns invalid JSON
    """
    client = ClaudeClient(api_key=api_key)
    messages = create_messages(snapshot_content)

    # Request analysis from Claude
    response_text = client.analyze(messages, max_tokens=4000)

    # Parse JSON response
    # Strip markdown code blocks if present
    cleaned = response_text.strip()
    if cleaned.startswith('```json'):
        cleaned = cleaned[7:]
    if cleaned.startswith('```'):
        cleaned = cleaned[3:]
    if cleaned.endswith('```'):
        cleaned = cleaned[:-3]
    cleaned = cleaned.strip()

    try:
        result = json.loads(cleaned)
        return result
    except json.JSONDecodeError as e:
        # Return error info for debugging
        return {
            "error": f"Failed to parse JSON: {str(e)}",
            "raw_response": response_text[:500]  # First 500 chars for debugging
        }
