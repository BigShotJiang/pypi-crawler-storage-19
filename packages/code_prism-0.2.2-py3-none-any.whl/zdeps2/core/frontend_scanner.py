"""Front-end file scanner for detecting HTML, JS, CSS served by Flask/FastAPI."""
import ast
import os
from pathlib import Path
from typing import Set, Dict, List, Any, Optional, Tuple


FRONTEND_EXTENSIONS = {
    ".html", ".htm", ".jinja", ".jinja2",
    ".js", ".jsx", ".ts", ".tsx",
    ".css", ".scss", ".less",
}

DEFAULT_TEMPLATE_DIRS = ["templates", "template"]
DEFAULT_STATIC_DIRS = ["static", "public", "assets", "frontend"]


class FlaskPatternExtractor(ast.NodeVisitor):
    """AST visitor to extract Flask/FastAPI template patterns."""

    def __init__(self):
        self.render_template_calls: List[str] = []
        self.render_template_string_calls: List[str] = []
        self.file_response_calls: List[str] = []  # FastAPI FileResponse
        self.static_folder: Optional[str] = None
        self.template_folder: Optional[str] = None
        self.static_url_path: Optional[str] = None

    def visit_Call(self, node):
        func = node.func

        # Detect render_template('template.html')
        if isinstance(func, ast.Name) and func.id == "render_template":
            if node.args and isinstance(node.args[0], ast.Constant):
                self.render_template_calls.append(node.args[0].value)

        # Detect render_template_string(...)
        if isinstance(func, ast.Name) and func.id == "render_template_string":
            if node.args and isinstance(node.args[0], ast.Constant):
                self.render_template_string_calls.append(node.args[0].value)

        # Detect FileResponse('path/to/file.html') - FastAPI pattern
        if isinstance(func, ast.Name) and func.id == "FileResponse":
            if node.args:
                html_path = self._extract_html_path(node.args[0])
                if html_path:
                    self.file_response_calls.append(html_path)

        # Detect Flask(static_folder='...', template_folder='...')
        if isinstance(func, ast.Name) and func.id in ("Flask", "FastAPI"):
            for keyword in node.keywords:
                if keyword.arg == "static_folder" and isinstance(
                    keyword.value, ast.Constant
                ):
                    self.static_folder = keyword.value.value
                elif keyword.arg == "template_folder" and isinstance(
                    keyword.value, ast.Constant
                ):
                    self.template_folder = keyword.value.value
                elif keyword.arg == "static_url_path" and isinstance(
                    keyword.value, ast.Constant
                ):
                    self.static_url_path = keyword.value.value

        # Detect Jinja2Templates(directory='...')
        if isinstance(func, ast.Name) and func.id == "Jinja2Templates":
            for keyword in node.keywords:
                if keyword.arg == "directory" and isinstance(
                    keyword.value, ast.Constant
                ):
                    self.template_folder = keyword.value.value
            if node.args and isinstance(node.args[0], ast.Constant):
                self.template_folder = node.args[0].value

        # Detect StaticFiles(directory='...')
        if isinstance(func, ast.Name) and func.id == "StaticFiles":
            for keyword in node.keywords:
                if keyword.arg == "directory" and isinstance(
                    keyword.value, ast.Constant
                ):
                    self.static_folder = keyword.value.value
            if node.args and isinstance(node.args[0], ast.Constant):
                self.static_folder = node.args[0].value

        self.generic_visit(node)

    def _extract_html_path(self, node) -> Optional[str]:
        """Extract HTML file path from AST node, handling str() and Path / operations."""
        # Simple string constant: FileResponse("index.html")
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            if node.value.endswith(('.html', '.htm')):
                return node.value
            return None

        # str(path): FileResponse(str(frontend_path / "index.html"))
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == "str":
                if node.args:
                    return self._extract_html_path(node.args[0])

        # Path / operation: frontend_path / "index.html"
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
            # Get the rightmost part (the filename)
            right = node.right
            if isinstance(right, ast.Constant) and isinstance(right.value, str):
                if right.value.endswith(('.html', '.htm')):
                    return right.value
            # Could be chained: path / "subdir" / "file.html"
            if isinstance(right, ast.BinOp):
                return self._extract_html_path(right)

        return None


def detect_flask_patterns(py_file: Path) -> Dict[str, Any]:
    """Detect Flask/FastAPI template patterns in a Python file using AST."""
    try:
        content = py_file.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(content)
        extractor = FlaskPatternExtractor()
        extractor.visit(tree)

        return {
            "render_template_calls": extractor.render_template_calls,
            "render_template_string_calls": extractor.render_template_string_calls,
            "file_response_calls": extractor.file_response_calls,
            "static_folder": extractor.static_folder,
            "template_folder": extractor.template_folder,
            "static_url_path": extractor.static_url_path,
        }
    except (SyntaxError, UnicodeDecodeError):
        return {
            "render_template_calls": [],
            "render_template_string_calls": [],
            "file_response_calls": [],
            "static_folder": None,
            "template_folder": None,
            "static_url_path": None,
        }


def find_static_and_template_folders(
    project_root: Path, config: Dict[str, Any]
) -> Tuple[Optional[Path], Optional[Path]]:
    """Find templates/ and static/ directories in the project (including subdirs)."""
    template_folder: Optional[Path] = None
    static_folder: Optional[Path] = None
    exclude_patterns = config.get("exclude_patterns", [])
    exclude_patterns.extend(["node_modules", ".venv", "venv", "__pycache__", ".git"])

    # Check root level first
    for name in DEFAULT_TEMPLATE_DIRS:
        candidate = project_root / name
        if candidate.exists() and candidate.is_dir():
            template_folder = candidate
            break

    for name in DEFAULT_STATIC_DIRS:
        candidate = project_root / name
        if candidate.exists() and candidate.is_dir():
            static_folder = candidate
            break

    # If not found at root, search subdirectories (max 3 levels deep)
    if not template_folder or not static_folder:
        for root, dirs, _ in os.walk(project_root):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if not any(p in d for p in exclude_patterns)]

            root_path = Path(root)
            depth = len(root_path.relative_to(project_root).parts)
            if depth > 3:
                dirs.clear()
                continue

            if not template_folder:
                for name in DEFAULT_TEMPLATE_DIRS:
                    candidate = root_path / name
                    if candidate.exists() and candidate.is_dir():
                        template_folder = candidate
                        break

            if not static_folder:
                for name in DEFAULT_STATIC_DIRS:
                    candidate = root_path / name
                    if candidate.exists() and candidate.is_dir():
                        static_folder = candidate
                        break

            if template_folder and static_folder:
                break

    return template_folder, static_folder


def scan_frontend_files(
    project_root: Path,
    config: Dict[str, Any],
    template_folder: Optional[Path] = None,
    static_folder: Optional[Path] = None,
) -> Set[Path]:
    """Scan for HTML, JS, CSS files in templates/ and static/ directories."""
    exclude_patterns = config.get("exclude_patterns", [])
    exclude_patterns.extend(["node_modules", ".venv", "venv", "__pycache__"])

    frontend_files: Set[Path] = set()

    # Determine folders to search
    search_folders: List[Path] = []

    if template_folder and template_folder.exists():
        search_folders.append(template_folder)
    if static_folder and static_folder.exists():
        search_folders.append(static_folder)

    # Also check default locations if not already found
    if not template_folder:
        for name in DEFAULT_TEMPLATE_DIRS:
            candidate = project_root / name
            if candidate.exists() and candidate not in search_folders:
                search_folders.append(candidate)

    if not static_folder:
        for name in DEFAULT_STATIC_DIRS:
            candidate = project_root / name
            if candidate.exists() and candidate not in search_folders:
                search_folders.append(candidate)

    # Scan each folder
    for search_folder in search_folders:
        for root, dirs, files in os.walk(search_folder):
            root_path = Path(root)

            # Filter out excluded directories
            dirs[:] = [
                d
                for d in dirs
                if not any(pattern in d for pattern in exclude_patterns)
            ]

            for f in files:
                file_path = root_path / f
                if file_path.suffix.lower() in FRONTEND_EXTENSIONS:
                    frontend_files.add(file_path.resolve())

    return frontend_files


def get_file_type(file_path: Path) -> str:
    """Get the front-end file type based on extension."""
    ext = file_path.suffix.lower()
    if ext in {".html", ".htm", ".jinja", ".jinja2"}:
        return "html"
    elif ext in {".js", ".jsx"}:
        return "js"
    elif ext in {".ts", ".tsx"}:
        return "ts"
    elif ext in {".css", ".scss", ".less"}:
        return "css"
    return "unknown"
