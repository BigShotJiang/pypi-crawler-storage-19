from pathlib import Path
from typing import Set, Dict, List, Any, Optional
from dataclasses import dataclass, field
import threading
import time

from .config import load_config, get_project_root, DEFAULT_GLOBAL_SETTINGS
from .scanner import scan_all_python_files, detect_project_packages
from .tracer import trace_all_entry_points
from .index import build_indexes
from .tree import build_file_tree, finalize_tree, build_analysis_result
from .children import (
    build_children_tree,
    flatten_tree_with_totals,
    get_all_children_recursive,
)
from .parents import find_parents_to_depth
from .chains import get_chain_to_entry_points
from .tokenizer import count_tokens, count_lines, read_file_content
from .frontend_scanner import (
    scan_frontend_files,
    detect_flask_patterns,
    find_static_and_template_folders,
)
from .frontend_parser import build_frontend_index
from .frontend_children import (
    build_frontend_dependency_tree,
    flatten_frontend_tree,
)


@dataclass
class AnalysisCache:
    all_py_files: Set[Path] = field(default_factory=set)
    project_packages: List[str] = field(default_factory=list)
    forward_index: Dict[Path, Set[Path]] = field(default_factory=dict)
    reverse_index: Dict[Path, Set[Path]] = field(default_factory=dict)
    entry_point_traces: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    file_connections: Dict[str, List[Dict[str, Any]]] = field(default_factory=dict)
    all_connection_paths: Dict[str, Dict[str, List[str]]] = field(default_factory=dict)
    all_import_types: Dict[str, Dict[str, str]] = field(default_factory=dict)
    entry_point_info: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    connected_files: Set[Path] = field(default_factory=set)
    tree: Dict[str, Any] = field(default_factory=dict)
    orphans: Set[str] = field(default_factory=set)
    analysis_result: Dict[str, Any] = field(default_factory=dict)
    last_updated: float = 0.0
    # Frontend fields
    frontend_files: Set[Path] = field(default_factory=set)
    template_folder: Optional[Path] = None
    static_folder: Optional[Path] = None
    python_to_templates: Dict[Path, List[str]] = field(default_factory=dict)
    frontend_forward_index: Dict[Path, Set[Path]] = field(default_factory=dict)
    frontend_reverse_index: Dict[Path, Set[Path]] = field(default_factory=dict)

    def is_valid(self) -> bool:
        return self.last_updated > 0 and len(self.all_py_files) > 0


_cache: Optional[AnalysisCache] = None
_cache_lock = threading.Lock()


def get_cache() -> AnalysisCache:
    global _cache
    if _cache is None:
        _cache = AnalysisCache()
    return _cache


def invalidate_cache() -> None:
    global _cache
    with _cache_lock:
        _cache = AnalysisCache()


def run_full_analysis(config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    global _cache

    with _cache_lock:
        if config is None:
            config = load_config()

        project_root = get_project_root()
        cache = AnalysisCache()

        cache.all_py_files = scan_all_python_files(project_root, config)
        cache.project_packages = detect_project_packages(project_root)

        cache.forward_index, cache.reverse_index = build_indexes(
            cache.all_py_files, project_root, cache.project_packages, parallel=True
        )

        all_entry_points = config.get("entry_points", [])
        entry_points = [ep for ep in all_entry_points if ep.get("enabled", True)]
        cache.entry_point_traces = trace_all_entry_points(
            entry_points,
            cache.all_py_files,
            project_root,
            cache.project_packages,
            parallel=True,
        )

        for label, data in cache.entry_point_traces.items():
            cache.entry_point_info[label] = data["entry_info"]
            cache.all_connection_paths[label] = data["connection_paths"]
            cache.all_import_types[label] = data["import_types"]

            for rel_path in data["connected"]:
                full_path = project_root / rel_path
                cache.connected_files.add(full_path)

                if rel_path not in cache.file_connections:
                    cache.file_connections[rel_path] = []
                cache.file_connections[rel_path].append(
                    {
                        "entry": data["entry_info"]["path"],
                        "color": data["entry_info"]["color"],
                        "label": label,
                        "emoji": data["entry_info"]["emoji"],
                    }
                )

        # Frontend scanning
        cache.template_folder, cache.static_folder = find_static_and_template_folders(
            project_root, config
        )
        cache.frontend_files = scan_frontend_files(
            project_root, config, cache.template_folder, cache.static_folder
        )

        # Detect Flask/FastAPI template patterns in Python files
        for py_file in cache.all_py_files:
            patterns = detect_flask_patterns(py_file)
            # Combine render_template and FileResponse calls
            all_template_calls = (
                patterns["render_template_calls"] + patterns["file_response_calls"]
            )
            if all_template_calls:
                cache.python_to_templates[py_file] = all_template_calls
            # Update template/static folders from Flask config if found
            if patterns["template_folder"] and not cache.template_folder:
                candidate = (py_file.parent / patterns["template_folder"]).resolve()
                if candidate.exists():
                    cache.template_folder = candidate
            if patterns["static_folder"] and not cache.static_folder:
                candidate = (py_file.parent / patterns["static_folder"]).resolve()
                if candidate.exists():
                    cache.static_folder = candidate

        # Build frontend indexes
        if cache.frontend_files:
            cache.frontend_forward_index, cache.frontend_reverse_index = build_frontend_index(
                cache.frontend_files,
                cache.template_folder,
                cache.static_folder,
                project_root,
            )

        cache.tree, cache.orphans = build_file_tree(
            cache.all_py_files,
            cache.file_connections,
            cache.all_connection_paths,
            cache.all_import_types,
            entry_points,
            project_root,
        )
        finalize_tree(cache.tree)

        cache.analysis_result = build_analysis_result(
            cache.tree,
            cache.all_py_files,
            cache.file_connections,
            cache.orphans,
            cache.entry_point_info,
            all_entry_points,
            config.get("available_colors", DEFAULT_GLOBAL_SETTINGS["available_colors"]),
        )

        cache.last_updated = time.time()
        _cache = cache

        return cache.analysis_result


def get_analysis_result() -> Dict[str, Any]:
    cache = get_cache()
    if not cache.is_valid():
        return run_full_analysis()
    return cache.analysis_result


def get_children_preview(target_path: str) -> Dict[str, Any]:
    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    project_root = get_project_root()
    target_full = project_root / target_path
    if not target_full.exists():
        return {"error": f"File not found: {target_path}"}

    tree = build_children_tree(target_full, cache.forward_index, project_root)
    flat_list, totals = flatten_tree_with_totals(tree)

    return {"tree": tree, "children": flat_list, "totals": totals}


def suggest_entry_points(
    top_n: int = 500, include_tests: bool = False
) -> List[Dict[str, Any]]:
    """Find all files sorted by dependency tree size (most deps = peaks)."""
    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    project_root = get_project_root()
    config = load_config()
    existing_eps = {ep["path"] for ep in config.get("entry_points", [])}

    # External repo patterns to always exclude
    exclude_dirs = {
        "authlib",
        "authlib_repo",
        "google-auth",
        "oauthlib",
        "google_auth_lib",
        "google-auth-library-python",
        "google-auth-library-nodejs",
        "temp_google_auth",
        "node_modules",
        "site-packages",
        ".venv",
        "venv",
    }

    # Test patterns (optional exclusion)
    test_patterns = ["/tests/", "/test/", "test_", "_test.py", "conftest.py"]

    candidates: List[Dict[str, Any]] = []

    for file_path in cache.all_py_files:
        try:
            rel_path = str(file_path.relative_to(project_root))
        except ValueError:
            continue

        if rel_path in existing_eps:
            continue

        # Skip external repo directories
        parts = rel_path.split("/")
        if parts and parts[0] in exclude_dirs:
            continue

        # Optionally skip test files
        if not include_tests:
            rel_lower = rel_path.lower()
            if any(pat in rel_lower for pat in test_patterns):
                continue

        direct_children = cache.forward_index.get(file_path, set())
        if not direct_children:
            continue  # Skip files with no imports

        # Count recursive children (full dependency tree)
        recursive_children = get_all_children_recursive(file_path, cache.forward_index)
        recursive_count = len(recursive_children)

        if recursive_count < 3:
            continue  # Skip tiny trees

        candidates.append(
            {
                "path": rel_path,
                "name": file_path.name,
                "deps": recursive_count,
            }
        )

    # Sort by most dependencies first
    candidates.sort(key=lambda x: -x["deps"])
    return candidates[:top_n]


def get_full_dependency_info(target_path: str) -> Dict[str, Any]:
    """Get complete dependency info: parents, chain to entry points, and children."""
    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    project_root = get_project_root()
    target_full = project_root / target_path
    if not target_full.exists():
        return {"error": f"File not found: {target_path}"}

    def get_file_info(file_path: Path) -> Dict[str, Any]:
        try:
            rel_path = str(file_path.relative_to(project_root))
        except ValueError:
            rel_path = str(file_path)
        content = read_file_content(file_path)
        return {
            "path": rel_path,
            "name": file_path.name,
            "lines": count_lines(file_path),
            "tokens": count_tokens(content),
        }

    # Get target file info
    target_info = get_file_info(target_full)
    target_info["is_target"] = True

    # Get parents (files that import this file)
    parent_files = find_parents_to_depth(
        target_full, cache.reverse_index, cache.connected_files, depth=10
    )
    parents = []
    for i, p in enumerate(parent_files):
        info = get_file_info(p)
        info["depth"] = i + 1
        info["type"] = "parent"
        parents.append(info)

    # Get chain to entry points
    chain_data = get_chain_to_entry_points(
        target_full, cache.entry_point_traces, project_root, max_depth=None
    )
    chains = []
    for label, info in chain_data.items():
        chain_files = []
        for i, chain_path in enumerate(info["chain"][:-1]):  # Exclude target itself
            chain_full = project_root / chain_path
            if chain_full.exists():
                file_info = get_file_info(chain_full)
                file_info["depth"] = i
                file_info["type"] = "chain"
                file_info["entry_label"] = label
                file_info["entry_color"] = info["color"]
                file_info["entry_emoji"] = info["emoji"]
                chain_files.append(file_info)
        chains.append(
            {
                "label": label,
                "color": info["color"],
                "emoji": info["emoji"],
                "files": chain_files,
            }
        )

    # Get children tree
    children_tree = build_children_tree(target_full, cache.forward_index, project_root)

    return {
        "target": target_info,
        "parents": parents,
        "chains": chains,
        "children_tree": children_tree,
    }


def get_frontend_preview(target_path: str) -> Dict[str, Any]:
    """Get front-end dependencies for a Python file that uses templates.

    If the file doesn't directly use render_template, traces through its imports
    to find any files that do and aggregates their templates.
    """
    cache = get_cache()
    if not cache.is_valid():
        run_full_analysis()
        cache = get_cache()

    project_root = get_project_root()
    target_full = (project_root / target_path).resolve()

    if not target_full.exists():
        return {"error": f"File not found: {target_path}"}

    # Check if this Python file uses any templates directly
    template_names = list(cache.python_to_templates.get(target_full, []))

    # If no direct templates, trace through imports to find files that use templates
    if not template_names:
        visited: Set[Path] = set()
        to_check = [target_full]

        while to_check:
            current = to_check.pop()
            if current in visited:
                continue
            visited.add(current)

            # Check if this file uses templates
            file_templates = cache.python_to_templates.get(current, [])
            for tmpl in file_templates:
                if tmpl not in template_names:
                    template_names.append(tmpl)

            # Add its imports to check
            children = cache.forward_index.get(current, set())
            for child in children:
                if child not in visited:
                    to_check.append(child)

    if not template_names:
        return {
            "tree": {"path": target_path, "name": target_full.name, "is_root": True, "children": []},
            "children": [],
            "totals": {"files": 0, "lines": 0, "tokens": 0},
        }

    # Build the frontend dependency tree
    tree = build_frontend_dependency_tree(
        target_full,
        template_names,
        cache.template_folder,
        cache.static_folder,
        project_root,
        cache.frontend_forward_index,
    )

    flat_list, totals = flatten_frontend_tree(tree)

    return {
        "tree": tree,
        "children": flat_list,
        "totals": totals,
    }
