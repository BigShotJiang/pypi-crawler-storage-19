"""Front-end dependency tree building functions."""
from pathlib import Path
from typing import Set, Dict, List, Any, Optional

from .tokenizer import count_tokens, count_lines, read_file_content
from .frontend_scanner import get_file_type
from .frontend_parser import parse_frontend_file


def get_all_frontend_children_recursive(
    target_path: Path,
    frontend_forward_index: Dict[Path, Set[Path]],
    visited: Optional[Set[Path]] = None,
) -> List[Path]:
    """Get all recursive front-end dependencies of a file."""
    if visited is None:
        visited = set()

    target_resolved = target_path.resolve()
    if target_resolved in visited:
        return []

    visited.add(target_resolved)
    all_children: List[Path] = []

    direct_children = frontend_forward_index.get(target_resolved, set())
    for child in direct_children:
        if child not in visited:
            all_children.append(child)
            nested = get_all_frontend_children_recursive(
                child, frontend_forward_index, visited
            )
            all_children.extend(nested)

    return all_children


def build_frontend_tree_for_file(
    file_path: Path,
    template_folder: Optional[Path],
    static_folder: Optional[Path],
    project_root: Path,
    frontend_forward_index: Dict[Path, Set[Path]],
    visited: Optional[Set[Path]] = None,
    depth: int = 0,
    max_depth: int = 10,
) -> Optional[Dict[str, Any]]:
    """Build a tree node for a front-end file with its dependencies."""
    if visited is None:
        visited = set()

    if depth > max_depth:
        return None

    file_resolved = file_path.resolve()
    if file_resolved in visited:
        return None

    visited.add(file_resolved)

    try:
        rel_path = str(file_resolved.relative_to(project_root))
    except ValueError:
        rel_path = str(file_resolved)

    content = read_file_content(file_resolved)
    file_type = get_file_type(file_resolved)

    node: Dict[str, Any] = {
        "path": rel_path,
        "name": file_resolved.name,
        "file_type": file_type,
        "lines": count_lines(file_resolved),
        "tokens": count_tokens(content),
        "depth": depth,
        "children": [],
    }

    # Get dependencies from index
    direct_deps = frontend_forward_index.get(file_resolved, set())

    for dep_path in direct_deps:
        child_node = build_frontend_tree_for_file(
            dep_path,
            template_folder,
            static_folder,
            project_root,
            frontend_forward_index,
            visited,
            depth + 1,
            max_depth,
        )
        if child_node:
            node["children"].append(child_node)

    return node


def build_frontend_dependency_tree(
    py_file: Path,
    template_names: List[str],
    template_folder: Optional[Path],
    static_folder: Optional[Path],
    project_root: Path,
    frontend_forward_index: Dict[Path, Set[Path]],
) -> Dict[str, Any]:
    """Build a tree of front-end dependencies starting from templates used by a Python file."""
    try:
        rel_path = str(py_file.relative_to(project_root))
    except ValueError:
        rel_path = str(py_file)

    root_node: Dict[str, Any] = {
        "path": rel_path,
        "name": py_file.name,
        "file_type": "python",
        "is_root": True,
        "depth": 0,
        "children": [],
    }

    visited: Set[Path] = set()

    # Find and add all templates used by this Python file
    for template_name in template_names:
        template_path = None

        # Try to find the template
        if template_folder:
            candidate = template_folder / template_name
            if candidate.exists():
                template_path = candidate.resolve()

        if not template_path:
            # Try relative to project root
            candidate = project_root / template_name
            if candidate.exists():
                template_path = candidate.resolve()

        if not template_path:
            # Try in templates/ subdirectory
            candidate = project_root / "templates" / template_name
            if candidate.exists():
                template_path = candidate.resolve()

        if not template_path:
            # Try in static folder (FastAPI FileResponse pattern)
            if static_folder:
                candidate = static_folder / template_name
                if candidate.exists():
                    template_path = candidate.resolve()

        if not template_path:
            # Try relative to py_file's parent (e.g., frontend/ sibling folder)
            candidate = py_file.parent.parent / "frontend" / template_name
            if candidate.exists():
                template_path = candidate.resolve()

        if template_path and template_path not in visited:
            child_node = build_frontend_tree_for_file(
                template_path,
                template_folder,
                static_folder,
                project_root,
                frontend_forward_index,
                visited,
                depth=1,
            )
            if child_node:
                child_node["dependency_type"] = "template"
                root_node["children"].append(child_node)

    return root_node


def flatten_frontend_tree(
    tree_node: Dict[str, Any],
    flat_list: Optional[List[Dict[str, Any]]] = None,
    totals: Optional[Dict[str, int]] = None,
) -> tuple[List[Dict[str, Any]], Dict[str, int]]:
    """Flatten a front-end tree into a list and calculate totals."""
    if flat_list is None:
        flat_list = []
    if totals is None:
        totals = {"files": 0, "lines": 0, "tokens": 0}

    # Don't include root Python file in totals
    if not tree_node.get("is_root") and tree_node.get("file_type") != "python":
        flat_list.append({
            "path": tree_node["path"],
            "name": tree_node["name"],
            "file_type": tree_node.get("file_type", "unknown"),
            "depth": tree_node.get("depth", 0),
            "lines": tree_node.get("lines", 0),
            "tokens": tree_node.get("tokens", 0),
        })
        totals["files"] += 1
        totals["lines"] += tree_node.get("lines", 0)
        totals["tokens"] += tree_node.get("tokens", 0)

    for child in tree_node.get("children", []):
        flatten_frontend_tree(child, flat_list, totals)

    return flat_list, totals


def get_frontend_files_from_tree(
    tree_node: Dict[str, Any],
    project_root: Path,
    files: Optional[List[Path]] = None,
) -> List[Path]:
    """Extract all file paths from a front-end tree."""
    if files is None:
        files = []

    # Don't include root Python file
    if not tree_node.get("is_root") and tree_node.get("file_type") != "python":
        path = tree_node.get("path", "")
        if path:
            full_path = project_root / path
            if full_path.exists():
                files.append(full_path.resolve())

    for child in tree_node.get("children", []):
        get_frontend_files_from_tree(child, project_root, files)

    return files
