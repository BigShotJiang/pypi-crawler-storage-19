from pathlib import Path
from typing import Set, Dict, List, Optional


def find_immediate_parents(
    target_path: Path,
    reverse_index: Dict[Path, Set[Path]],
    connected_files: Optional[Set[Path]] = None,
) -> List[Path]:
    target_resolved = target_path.resolve()
    parents = reverse_index.get(target_resolved, set())

    if connected_files is not None:
        parents = parents & connected_files

    return list(parents)


def find_parents_to_depth(
    target_path: Path,
    reverse_index: Dict[Path, Set[Path]],
    connected_files: Optional[Set[Path]],
    depth: int = 1,
) -> List[Path]:
    all_parents: List[Path] = []
    seen: Set[Path] = {target_path.resolve()}
    current_level: List[Path] = [target_path.resolve()]

    for _ in range(depth):
        next_level: List[Path] = []
        for file_path in current_level:
            parents = find_immediate_parents(file_path, reverse_index, connected_files)
            for p in parents:
                if p not in seen:
                    seen.add(p)
                    all_parents.append(p)
                    next_level.append(p)
        current_level = next_level
        if not current_level:
            break

    return all_parents
