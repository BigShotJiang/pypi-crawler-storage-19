from pathlib import Path
from collections import deque
from typing import Set, Dict, List, Tuple, Any
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp

from .parser import get_all_imports, module_to_possible_paths, expand_init_imports


def _get_short_path(filepath: Path, project_root: Path) -> str:
    try:
        return str(filepath.relative_to(project_root))
    except ValueError:
        return filepath.name


def trace_dependencies(
    entry_point: Path,
    all_py_files: Set[Path],
    project_root: Path,
    project_packages: List[str],
) -> Tuple[Set[Path], Dict[Path, List[str]], Dict[Path, str]]:
    visited: Set[Path] = set()
    connection_paths: Dict[Path, List[str]] = {}
    import_types: Dict[Path, str] = {}

    ep_resolved = entry_point.resolve()
    ep_short = _get_short_path(ep_resolved, project_root)
    queue = deque([(ep_resolved, [ep_short], "entry")])

    while queue:
        current, path_so_far, imp_type = queue.popleft()
        if current in visited:
            continue
        visited.add(current)
        connection_paths[current] = path_so_far.copy()
        import_types[current] = imp_type

        static_imports, dynamic_imports, potential_modules = get_all_imports(
            current, project_packages
        )
        all_imports = static_imports | dynamic_imports | potential_modules

        for imp in all_imports:
            for possible_path in module_to_possible_paths(imp, current, project_root):
                try:
                    resolved = possible_path.resolve()

                    if resolved.name == "__init__.py" and resolved.exists():
                        expanded = expand_init_imports(resolved, project_packages)
                        for exp_path in expanded:
                            if exp_path in all_py_files and exp_path not in visited:
                                import_type = "static"
                                if imp in dynamic_imports:
                                    import_type = "dynamic"
                                new_path = path_so_far + [
                                    _get_short_path(exp_path, project_root)
                                ]
                                queue.append((exp_path, new_path, import_type))

                    if resolved in all_py_files and resolved not in visited:
                        import_type = "static"
                        if imp in dynamic_imports:
                            import_type = "dynamic"
                        elif imp in potential_modules:
                            import_type = "string_ref"

                        new_path = path_so_far + [
                            _get_short_path(resolved, project_root)
                        ]
                        queue.append((resolved, new_path, import_type))
                except (ValueError, OSError):
                    pass

    return visited, connection_paths, import_types


def _trace_single_entry_point(args) -> Tuple[str, Dict[str, Any] | None]:
    ep_config, all_py_files_list, project_root_str, project_packages = args
    project_root = Path(project_root_str)
    all_py_files = set(Path(p) for p in all_py_files_list)

    ep_path = project_root / ep_config["path"]
    if not ep_path.exists():
        return ep_config["label"], None

    label = ep_config["label"]
    connected, connection_paths, import_types = trace_dependencies(
        ep_path, all_py_files, project_root, project_packages
    )

    connection_paths_str = {
        str(k.relative_to(project_root)): v for k, v in connection_paths.items()
    }
    import_types_str = {
        str(k.relative_to(project_root)): v for k, v in import_types.items()
    }
    connected_str = [str(f.relative_to(project_root)) for f in connected]

    return label, {
        "connected": connected_str,
        "connection_paths": connection_paths_str,
        "import_types": import_types_str,
        "entry_info": {
            "path": ep_config["path"],
            "color": ep_config["color"],
            "emoji": ep_config.get("emoji", "🔵"),
        },
    }


def trace_all_entry_points(
    entry_points: List[Dict[str, Any]],
    all_py_files: Set[Path],
    project_root: Path,
    project_packages: List[str],
    parallel: bool = True,
) -> Dict[str, Dict[str, Any]]:
    results = {}
    all_py_files_list = [str(p) for p in all_py_files]
    project_root_str = str(project_root)

    args_list = [
        (ep, all_py_files_list, project_root_str, project_packages)
        for ep in entry_points
    ]

    if parallel and len(entry_points) > 1:
        max_workers = min(len(entry_points), mp.cpu_count())
        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            for label, data in executor.map(_trace_single_entry_point, args_list):
                if data is not None:
                    results[label] = data
    else:
        for args in args_list:
            label, data = _trace_single_entry_point(args)
            if data is not None:
                results[label] = data

    return results
