from pathlib import Path
from typing import Set, Dict, List, Any


def build_file_tree(
    all_py_files: Set[Path],
    file_connections: Dict[str, List[Dict[str, Any]]],
    all_connection_paths: Dict[str, Dict[str, List[str]]],
    all_import_types: Dict[str, Dict[str, str]],
    entry_points: List[Dict[str, Any]],
    project_root: Path,
) -> tuple[Dict[str, Any], Set[str]]:
    tree: Dict[str, Any] = {}
    orphans: Set[str] = set()

    for f in sorted(all_py_files, key=lambda x: str(x)):
        try:
            rel = str(f.relative_to(project_root))
        except ValueError:
            continue

        parts = rel.split("/")
        current = tree

        for part in parts[:-1]:
            if part not in current:
                current[part] = {"_type": "folder", "_children": {}}
            current = current[part]["_children"]

        filename = parts[-1]
        connections = file_connections.get(rel, [])
        is_orphan = len(connections) == 0

        if is_orphan:
            orphans.add(rel)

        paths_info: Dict[str, Dict[str, Any]] = {}
        for label, paths in all_connection_paths.items():
            if rel in paths:
                paths_info[label] = {
                    "path": paths[rel],
                    "type": all_import_types.get(label, {}).get(rel, "static"),
                }

        is_entry = any(ep["path"] == rel for ep in entry_points)

        current[filename] = {
            "_type": "file",
            "_path": rel,
            "_orphan": is_orphan,
            "_entry_point": is_entry,
            "_connections": connections,
            "_connection_paths": paths_info,
        }

    return tree, orphans


def calculate_folder_contents(node: Dict[str, Any]) -> Set[str]:
    if node.get("_type") == "file":
        labels: Set[str] = set()
        if node.get("_orphan"):
            labels.add("ORPHAN")
        for conn in node.get("_connections", []):
            labels.add(conn["label"])
        return labels

    all_labels: Set[str] = set()
    children = node.get("_children", {})
    for name, child in children.items():
        if name.startswith("_"):
            continue
        child_labels = calculate_folder_contents(child)
        all_labels.update(child_labels)

    node["_contains"] = sorted(list(all_labels))
    return all_labels


def finalize_tree(tree: Dict[str, Any]) -> None:
    for name, node in tree.items():
        if not name.startswith("_"):
            calculate_folder_contents(node)


def build_analysis_result(
    tree: Dict[str, Any],
    all_py_files: Set[Path],
    file_connections: Dict[str, List[Dict[str, Any]]],
    orphans: Set[str],
    entry_point_info: Dict[str, Dict[str, Any]],
    entry_points: List[Dict[str, Any]],
    available_colors: List[Dict[str, str]],
) -> Dict[str, Any]:
    return {
        "tree": tree,
        "stats": {
            "total": len(all_py_files),
            "connected": len(file_connections),
            "orphans": len(orphans),
            "orphan_rate": round(len(orphans) / len(all_py_files) * 100, 1)
            if all_py_files
            else 0,
        },
        "entry_points": entry_point_info,
        "config": {
            "entry_points": entry_points,
            "available_colors": available_colors,
        },
    }
