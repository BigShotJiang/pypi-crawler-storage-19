from pathlib import Path
from typing import Dict, List, Any, Optional


def get_chain_to_entry_points(
    target_path: Path,
    entry_point_traces: Dict[str, Dict[str, Any]],
    project_root: Path,
    max_depth: Optional[int] = None,
) -> Dict[str, Dict[str, Any]]:
    chains: Dict[str, Dict[str, Any]] = {}

    try:
        target_rel = str(target_path.resolve().relative_to(project_root))
    except ValueError:
        return chains

    for label, trace_data in entry_point_traces.items():
        connection_paths = trace_data.get("connection_paths", {})
        entry_info = trace_data.get("entry_info", {})

        if target_rel in connection_paths:
            chain = connection_paths[target_rel]
            if max_depth is not None and len(chain) > max_depth + 1:
                chain = chain[-(max_depth + 1) :]

            chains[label] = {
                "chain": chain,
                "color": entry_info.get("color", "#8b949e"),
                "emoji": entry_info.get("emoji", "🔵"),
            }

    return chains
