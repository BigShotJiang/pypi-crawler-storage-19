from pathlib import Path
from typing import Set, Dict, List, Tuple
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp

from .parser import get_all_imports, module_to_possible_paths, expand_init_imports


def _resolve_imports_for_file(args) -> Tuple[str, List[str]]:
    filepath_str, all_py_files_list, project_root_str, project_packages = args
    filepath = Path(filepath_str)
    project_root = Path(project_root_str)
    all_py_files = set(Path(p) for p in all_py_files_list)

    resolved_imports = []
    static_imports, dynamic_imports, potential_modules = get_all_imports(
        filepath, project_packages
    )
    all_imports = static_imports | dynamic_imports | potential_modules

    for imp in all_imports:
        for possible_path in module_to_possible_paths(imp, filepath, project_root):
            try:
                resolved = possible_path.resolve()

                if resolved.name == "__init__.py" and resolved.exists():
                    expanded = expand_init_imports(resolved, project_packages)
                    for exp_path in expanded:
                        if exp_path in all_py_files:
                            resolved_imports.append(str(exp_path))

                if resolved in all_py_files:
                    resolved_imports.append(str(resolved))
            except (ValueError, OSError):
                pass

    return filepath_str, list(set(resolved_imports))


def build_forward_index(
    all_py_files: Set[Path],
    project_root: Path,
    project_packages: List[str],
    parallel: bool = True,
) -> Dict[Path, Set[Path]]:
    forward_index: Dict[Path, Set[Path]] = {f: set() for f in all_py_files}
    all_py_files_list = [str(p) for p in all_py_files]
    project_root_str = str(project_root)

    args_list = [
        (str(f), all_py_files_list, project_root_str, project_packages)
        for f in all_py_files
    ]

    if parallel and len(all_py_files) > 50:
        max_workers = min(mp.cpu_count(), 8)
        with ProcessPoolExecutor(max_workers=max_workers) as executor:
            for filepath_str, imports in executor.map(
                _resolve_imports_for_file, args_list
            ):
                filepath = Path(filepath_str)
                forward_index[filepath] = set(Path(p) for p in imports)
    else:
        for args in args_list:
            filepath_str, imports = _resolve_imports_for_file(args)
            filepath = Path(filepath_str)
            forward_index[filepath] = set(Path(p) for p in imports)

    return forward_index


def build_reverse_index(forward_index: Dict[Path, Set[Path]]) -> Dict[Path, Set[Path]]:
    reverse_index: Dict[Path, Set[Path]] = {f: set() for f in forward_index.keys()}

    for file_path, imports in forward_index.items():
        for imported in imports:
            if imported in reverse_index:
                reverse_index[imported].add(file_path)

    return reverse_index


def build_indexes(
    all_py_files: Set[Path],
    project_root: Path,
    project_packages: List[str],
    parallel: bool = True,
) -> Tuple[Dict[Path, Set[Path]], Dict[Path, Set[Path]]]:
    forward_index = build_forward_index(
        all_py_files, project_root, project_packages, parallel
    )
    reverse_index = build_reverse_index(forward_index)
    return forward_index, reverse_index
