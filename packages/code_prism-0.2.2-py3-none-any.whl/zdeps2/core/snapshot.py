from pathlib import Path
from typing import Dict, List, Any, Set, Optional
from dataclasses import dataclass

from .tokenizer import count_tokens, count_lines, read_file_content
from .parents import find_parents_to_depth
from .children import (
    get_all_children_recursive,
    get_children_to_depth,
    get_children_with_token_limit,
)
from .chains import get_chain_to_entry_points


@dataclass
class SnapshotOptions:
    parent_depth: int = 1
    include_chain: bool = False
    chain_length: Optional[int] = None
    child_depth: int = 0
    child_max_tokens: int = 0
    excluded_children: Optional[Set[str]] = None
    # Frontend options
    include_frontend: bool = False
    excluded_frontend: Optional[Set[str]] = None

    def __post_init__(self):
        if self.excluded_children is None:
            self.excluded_children = set()
        if self.excluded_frontend is None:
            self.excluded_frontend = set()


def generate_snapshot(
    target_path: str,
    options: SnapshotOptions,
    project_root: Path,
    reverse_index: Dict[Path, Set[Path]],
    forward_index: Dict[Path, Set[Path]],
    connected_files: Set[Path],
    entry_point_traces: Dict[str, Dict[str, Any]],
    frontend_files: Optional[List[Path]] = None,
) -> Dict[str, Any]:
    target_full = project_root / target_path
    if not target_full.exists():
        return {"error": f"File not found: {target_path}"}

    def get_rel_path(p: Path) -> str:
        try:
            return str(Path(p).relative_to(project_root))
        except ValueError:
            return str(p)

    parent_files: List[Path] = []
    chain_files: Dict[str, Any] = {}
    child_files: List[Path] = []
    child_tokens_used = 0

    if options.parent_depth > 0:
        parent_files = find_parents_to_depth(
            target_full, reverse_index, connected_files, options.parent_depth
        )

    if options.include_chain:
        chain_files = get_chain_to_entry_points(
            target_full, entry_point_traces, project_root, options.chain_length
        )

    excluded_paths = {
        (project_root / p).resolve() for p in (options.excluded_children or set())
    }

    if options.child_max_tokens > 0:
        selected, child_tokens_used = get_children_with_token_limit(
            target_full, forward_index, options.child_max_tokens, excluded_paths
        )
        child_files = [s["path"] for s in selected]
    elif options.child_depth > 0:
        child_files = get_children_to_depth(
            target_full, forward_index, options.child_depth
        )
        child_files = [f for f in child_files if f not in excluded_paths]
    else:
        child_files = get_all_children_recursive(target_full, forward_index)
        child_files = [f for f in child_files if f not in excluded_paths]

    output_parts: List[str] = []
    total_lines = 0
    file_metrics: List[Dict[str, Any]] = []

    include_children = (
        len(child_files) > 0 or options.child_depth > 0 or options.child_max_tokens > 0
    )

    header_lines = []
    header_lines.append("=" * 70)
    header_lines.append("DEPENDENCY SNAPSHOT")
    header_lines.append("=" * 70)
    header_lines.append("")
    header_lines.append(f"Target File: {target_path}")
    header_lines.append(
        f"Parent Depth: {options.parent_depth} ({len(parent_files)} files)"
    )
    if options.include_chain:
        header_lines.append(f"Chain to Entry Points: Yes ({len(chain_files)} chains)")

    child_info = f"Children: {len(child_files)} files"
    if options.child_max_tokens > 0:
        child_info += (
            f" (token limit: {options.child_max_tokens:,}, used: {child_tokens_used:,})"
        )
    elif options.child_depth > 0:
        child_info += f" (depth: {options.child_depth})"
    header_lines.append(child_info)
    header_lines.append("")

    if parent_files:
        header_lines.append(f"PARENTS (depth {options.parent_depth}):")
        for p in parent_files:
            rel = get_rel_path(p)
            lines = count_lines(p)
            header_lines.append(f"  <- {rel} ({lines} lines)")
        header_lines.append("")

    if chain_files:
        header_lines.append("CHAINS TO ENTRY POINTS:")
        for label, info in chain_files.items():
            chain_str = " -> ".join(info["chain"])
            header_lines.append(f"  {info['emoji']} {label}: {chain_str}")
        header_lines.append("")

    if child_files:
        header_lines.append("CHILDREN (recursive):")
        for c in child_files:
            rel = get_rel_path(c)
            lines = count_lines(c)
            header_lines.append(f"  -> {rel} ({lines} lines)")
        header_lines.append("")

    header_lines.append("=" * 70)
    header_lines.append("")

    output_parts.append("\n".join(header_lines))

    if parent_files:
        output_parts.append("# " + "=" * 68)
        output_parts.append("# PARENT FILES")
        output_parts.append("# " + "=" * 68)
        output_parts.append("")

        for p in parent_files:
            rel = get_rel_path(p)
            content = read_file_content(p)
            lines = count_lines(p)
            total_lines += lines
            file_metrics.append({"path": rel, "lines": lines, "type": "parent"})

            output_parts.append(f"# --- START FILE: {rel} ({lines} lines) ---")
            output_parts.append(content)
            output_parts.append(f"# --- END FILE: {rel} ---")
            output_parts.append("")

    output_parts.append("# " + "=" * 68)
    output_parts.append("# TARGET FILE")
    output_parts.append("# " + "=" * 68)
    output_parts.append("")

    main_content = read_file_content(target_full)
    main_lines = count_lines(target_full)
    total_lines += main_lines
    file_metrics.append({"path": target_path, "lines": main_lines, "type": "target"})

    output_parts.append(f"# --- START FILE: {target_path} ({main_lines} lines) ---")
    output_parts.append(main_content)
    output_parts.append(f"# --- END FILE: {target_path} ---")
    output_parts.append("")

    if include_children and child_files:
        output_parts.append("# " + "=" * 68)
        output_parts.append("# CHILD FILES (DEPENDENCIES)")
        output_parts.append("# " + "=" * 68)
        output_parts.append("")

        for c in child_files:
            rel = get_rel_path(c)
            content = read_file_content(c)
            lines = count_lines(c)
            total_lines += lines
            file_metrics.append({"path": rel, "lines": lines, "type": "child"})

            output_parts.append(f"# --- START FILE: {rel} ({lines} lines) ---")
            output_parts.append(content)
            output_parts.append(f"# --- END FILE: {rel} ---")
            output_parts.append("")

    # Frontend files section
    if options.include_frontend and frontend_files:
        excluded_frontend_paths = {
            (project_root / p).resolve() for p in (options.excluded_frontend or set())
        }
        included_frontend = [
            f for f in frontend_files if f.resolve() not in excluded_frontend_paths
        ]

        if included_frontend:
            output_parts.append("# " + "=" * 68)
            output_parts.append("# FRONT-END FILES (HTML/JS/CSS)")
            output_parts.append("# " + "=" * 68)
            output_parts.append("")

            for f in included_frontend:
                rel = get_rel_path(f)
                content = read_file_content(f)
                lines = count_lines(f)
                total_lines += lines
                file_metrics.append({"path": rel, "lines": lines, "type": "frontend"})

                output_parts.append(f"# --- START FILE: {rel} ({lines} lines) ---")
                output_parts.append(content)
                output_parts.append(f"# --- END FILE: {rel} ---")
                output_parts.append("")

    full_content = "\n".join(output_parts)
    token_count = count_tokens(full_content)

    footer_lines = []
    footer_lines.append("# " + "=" * 68)
    footer_lines.append("# SNAPSHOT METRICS")
    footer_lines.append("# " + "=" * 68)
    footer_lines.append(f"# Total Files: {len(file_metrics)}")
    footer_lines.append(f"# Total Lines: {total_lines}")
    footer_lines.append(f"# Estimated Tokens: ~{token_count:,}")
    footer_lines.append("# " + "=" * 68)

    full_content = full_content + "\n" + "\n".join(footer_lines)

    return {
        "content": full_content,
        "metrics": {
            "total_files": len(file_metrics),
            "total_lines": total_lines,
            "token_estimate": token_count,
            "files": file_metrics,
        },
    }
