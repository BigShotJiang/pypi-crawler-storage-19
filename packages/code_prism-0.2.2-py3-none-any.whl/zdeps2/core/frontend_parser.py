"""Front-end file dependency parser for HTML, JS, and CSS files."""
import re
from pathlib import Path
from typing import Dict, List, Any, Set, Optional


def parse_html_dependencies(html_path: Path, project_root: Path) -> Dict[str, Any]:
    """Parse HTML/Jinja2 file for dependencies.

    Extracts:
    - <script src="..."> tags
    - <link href="..."> stylesheet links
    - {% include '...' %} Jinja includes
    - {% extends '...' %} Jinja extends
    - Flask url_for('static', filename='...') references
    """
    try:
        content = html_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {"scripts": [], "stylesheets": [], "includes": [], "extends": []}

    # Script tags: <script src="...">
    script_pattern = r'<script[^>]+src=["\']([^"\']+)["\']'
    scripts = re.findall(script_pattern, content, re.IGNORECASE)

    # Link tags for stylesheets: <link ... href="...">
    # Must have rel="stylesheet" or type="text/css" or end in .css
    link_pattern = r'<link[^>]+href=["\']([^"\']+)["\']'
    all_links = re.findall(link_pattern, content, re.IGNORECASE)

    # Filter to CSS files
    stylesheets = [
        link for link in all_links
        if link.endswith(".css") or "stylesheet" in content[max(0, content.find(link)-100):content.find(link)]
    ]

    # Flask/Jinja2 url_for patterns: {{ url_for('static', filename='path/file.ext') }}
    url_for_pattern = r'{{\s*url_for\s*\(\s*["\']static["\']\s*,\s*filename\s*=\s*["\']([^"\']+)["\']\s*\)\s*}}'
    url_for_refs = re.findall(url_for_pattern, content)

    # Categorize url_for references by file type
    for ref in url_for_refs:
        if ref.endswith(('.js', '.jsx', '.ts', '.tsx')):
            scripts.append(f"static/{ref}")
        elif ref.endswith(('.css', '.scss', '.less')):
            stylesheets.append(f"static/{ref}")

    # Jinja includes: {% include '...' %} or {% include "..." %}
    include_pattern = r'{%\s*include\s+["\']([^"\']+)["\']\s*%}'
    includes = re.findall(include_pattern, content)

    # Jinja extends: {% extends '...' %} or {% extends "..." %}
    extends_pattern = r'{%\s*extends\s+["\']([^"\']+)["\']\s*%}'
    extends = re.findall(extends_pattern, content)

    # Also look for Jinja block imports
    # {% from '...' import ... %}
    from_import_pattern = r'{%\s*from\s+["\']([^"\']+)["\']\s+import'
    from_imports = re.findall(from_import_pattern, content)

    # Filter out external URLs
    scripts = _filter_local_refs(scripts)
    stylesheets = _filter_local_refs(stylesheets)

    return {
        "scripts": scripts,
        "stylesheets": stylesheets,
        "includes": includes + from_imports,
        "extends": extends,
    }


def parse_js_dependencies(js_path: Path, project_root: Path) -> Dict[str, Any]:
    """Parse JS file for dependencies.

    Extracts:
    - ES6 imports: import ... from '...'
    - Dynamic imports: import('...')
    - CommonJS requires: require('...')
    """
    try:
        content = js_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {"imports": [], "requires": []}

    # ES6 imports: import ... from '...' or import '...'
    import_from_pattern = r'import\s+.*?\s+from\s+["\']([^"\']+)["\']'
    import_direct_pattern = r'import\s+["\']([^"\']+)["\']'
    imports = re.findall(import_from_pattern, content)
    imports.extend(re.findall(import_direct_pattern, content))

    # Dynamic imports: import('...')
    dynamic_pattern = r'import\s*\(\s*["\']([^"\']+)["\']\s*\)'
    dynamic = re.findall(dynamic_pattern, content)
    imports.extend(dynamic)

    # CommonJS requires: require('...')
    require_pattern = r'require\s*\(\s*["\']([^"\']+)["\']\s*\)'
    requires = re.findall(require_pattern, content)

    # Filter to local files only (start with ./ or ../ or are relative)
    imports = _filter_local_refs(imports, allow_relative=True)
    requires = _filter_local_refs(requires, allow_relative=True)

    return {
        "imports": imports,
        "requires": requires,
    }


def parse_css_dependencies(css_path: Path, project_root: Path) -> Dict[str, Any]:
    """Parse CSS file for dependencies.

    Extracts:
    - @import rules: @import '...' or @import url('...')
    - url() references for fonts, images, etc.
    """
    try:
        content = css_path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return {"imports": [], "urls": []}

    # @import rules: @import '...' or @import url('...')
    import_pattern = r'@import\s+(?:url\s*\(\s*)?["\']?([^"\')\s;]+)["\']?\s*\)?'
    imports = re.findall(import_pattern, content)

    # url() references: url('...')
    url_pattern = r'url\s*\(\s*["\']?([^"\')\s]+)["\']?\s*\)'
    urls = re.findall(url_pattern, content)

    # Filter out data: URLs and external URLs
    imports = _filter_local_refs(imports)
    urls = _filter_local_refs(urls)

    # Filter urls to CSS files only for imports
    css_imports = [u for u in imports if u.endswith(".css")]

    return {
        "imports": css_imports,
        "urls": urls,
    }


def _filter_local_refs(refs: List[str], allow_relative: bool = False) -> List[str]:
    """Filter out external URLs and keep only local references."""
    local_refs = []
    for ref in refs:
        # Skip external URLs
        if ref.startswith(("http://", "https://", "//", "data:", "blob:")):
            continue
        # Skip node_modules imports (bare imports)
        if not allow_relative and not ref.startswith((".", "/")):
            # Check if it looks like a node_modules import
            if "/" not in ref or not ref.endswith((".js", ".css", ".json")):
                continue
        local_refs.append(ref)
    return local_refs


def resolve_frontend_path(
    ref: str,
    source_file: Path,
    template_folder: Optional[Path],
    static_folder: Optional[Path],
    project_root: Path,
) -> Optional[Path]:
    """Resolve a front-end reference to an actual file path.

    Handles:
    - Relative paths (./foo.js, ../bar.css)
    - Absolute paths (/static/foo.js)
    - Template names (base.html)
    - Static URL paths (/static/js/app.js)
    """
    if not ref:
        return None

    # Try relative to source file
    if ref.startswith("."):
        candidate = (source_file.parent / ref).resolve()
        if candidate.exists():
            return candidate

    # Try as template name
    if template_folder:
        candidate = (template_folder / ref).resolve()
        if candidate.exists():
            return candidate

    # Try as static file path (strip /static/ prefix if present)
    if static_folder:
        # Remove common static prefixes
        clean_ref = ref
        for prefix in ["/static/", "static/", "/assets/", "assets/", "/public/", "public/"]:
            if ref.startswith(prefix):
                clean_ref = ref[len(prefix):]
                break

        candidate = (static_folder / clean_ref).resolve()
        if candidate.exists():
            return candidate

    # Try relative to project root
    candidate = (project_root / ref.lstrip("/")).resolve()
    if candidate.exists():
        return candidate

    # Try relative to source file directory for absolute-looking paths
    if ref.startswith("/"):
        candidate = (source_file.parent / ref.lstrip("/")).resolve()
        if candidate.exists():
            return candidate

    return None


def parse_frontend_file(
    file_path: Path,
    template_folder: Optional[Path],
    static_folder: Optional[Path],
    project_root: Path,
) -> Dict[str, Any]:
    """Parse a front-end file and return its dependencies."""
    ext = file_path.suffix.lower()

    if ext in {".html", ".htm", ".jinja", ".jinja2"}:
        deps = parse_html_dependencies(file_path, project_root)
        dep_type = "html"
    elif ext in {".js", ".jsx", ".ts", ".tsx"}:
        deps = parse_js_dependencies(file_path, project_root)
        dep_type = "js"
    elif ext in {".css", ".scss", ".less"}:
        deps = parse_css_dependencies(file_path, project_root)
        dep_type = "css"
    else:
        return {"type": "unknown", "dependencies": []}

    # Resolve all references to actual paths
    resolved_deps: List[Dict[str, Any]] = []

    if dep_type == "html":
        for script in deps.get("scripts", []):
            resolved = resolve_frontend_path(
                script, file_path, template_folder, static_folder, project_root
            )
            if resolved:
                resolved_deps.append({
                    "path": resolved,
                    "ref": script,
                    "type": "script",
                })

        for stylesheet in deps.get("stylesheets", []):
            resolved = resolve_frontend_path(
                stylesheet, file_path, template_folder, static_folder, project_root
            )
            if resolved:
                resolved_deps.append({
                    "path": resolved,
                    "ref": stylesheet,
                    "type": "stylesheet",
                })

        for include in deps.get("includes", []):
            resolved = resolve_frontend_path(
                include, file_path, template_folder, static_folder, project_root
            )
            if resolved:
                resolved_deps.append({
                    "path": resolved,
                    "ref": include,
                    "type": "include",
                })

        for extends in deps.get("extends", []):
            resolved = resolve_frontend_path(
                extends, file_path, template_folder, static_folder, project_root
            )
            if resolved:
                resolved_deps.append({
                    "path": resolved,
                    "ref": extends,
                    "type": "extends",
                })

    elif dep_type == "js":
        for imp in deps.get("imports", []) + deps.get("requires", []):
            resolved = resolve_frontend_path(
                imp, file_path, template_folder, static_folder, project_root
            )
            if resolved:
                resolved_deps.append({
                    "path": resolved,
                    "ref": imp,
                    "type": "import",
                })

    elif dep_type == "css":
        for imp in deps.get("imports", []):
            resolved = resolve_frontend_path(
                imp, file_path, template_folder, static_folder, project_root
            )
            if resolved:
                resolved_deps.append({
                    "path": resolved,
                    "ref": imp,
                    "type": "css-import",
                })

    return {
        "type": dep_type,
        "dependencies": resolved_deps,
    }


def build_frontend_index(
    frontend_files: Set[Path],
    template_folder: Optional[Path],
    static_folder: Optional[Path],
    project_root: Path,
) -> tuple[Dict[Path, Set[Path]], Dict[Path, Set[Path]]]:
    """Build forward and reverse indexes for front-end file dependencies."""
    forward_index: Dict[Path, Set[Path]] = {f: set() for f in frontend_files}
    reverse_index: Dict[Path, Set[Path]] = {f: set() for f in frontend_files}

    for file_path in frontend_files:
        parsed = parse_frontend_file(
            file_path, template_folder, static_folder, project_root
        )

        for dep in parsed.get("dependencies", []):
            dep_path = dep["path"]
            if dep_path in frontend_files:
                forward_index[file_path].add(dep_path)
                reverse_index[dep_path].add(file_path)

    return forward_index, reverse_index
