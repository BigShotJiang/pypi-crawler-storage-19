from pathlib import Path
from typing import Set, List, Dict, Any
from concurrent.futures import ProcessPoolExecutor
import os


def get_git_submodules(project_root: Path) -> List[str]:
    import subprocess

    submodules = set()

    try:
        result = subprocess.run(
            ["git", "config", "--file", ".gitmodules", "--get-regexp", "path"],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            for line in result.stdout.strip().split("\n"):
                if line:
                    parts = line.split(None, 1)
                    if len(parts) == 2:
                        submodules.add(parts[1])
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    if not submodules:
        gitmodules_path = project_root / ".gitmodules"
        if gitmodules_path.exists():
            try:
                with open(gitmodules_path, "r") as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith("path"):
                            parts = line.split("=", 1)
                            if len(parts) == 2:
                                submodules.add(parts[1].strip())
            except Exception:
                pass

    for item in project_root.iterdir():
        if item.is_dir() and not item.name.startswith("."):
            git_marker = item / ".git"
            if git_marker.exists():
                submodules.add(item.name)

    return sorted(submodules)


def detect_project_packages(project_root: Path) -> List[str]:
    packages = []
    for item in project_root.iterdir():
        if item.is_dir() and not item.name.startswith("."):
            if (item / "__init__.py").exists() or any(item.glob("*.py")):
                packages.append(item.name)
    return packages


def should_exclude(
    path: Path, exclude_patterns: List[str], exclude_files: List[str]
) -> bool:
    # Check if the file name itself should be excluded
    if path.name in exclude_files:
        return True
    # Check if any path component matches an exclude pattern
    # This prevents "build" from matching "system_prompt_builder.py"
    path_parts = path.parts
    for pattern in exclude_patterns:
        if pattern in path_parts:
            return True
    return False


def _scan_directory(args) -> List[Path]:
    directory, exclude_patterns, exclude_files = args
    results = []
    try:
        for root, dirs, files in os.walk(directory):
            root_path = Path(root)
            dirs[:] = [
                d
                for d in dirs
                if not should_exclude(root_path / d, exclude_patterns, exclude_files)
            ]
            for f in files:
                if f.endswith(".py"):
                    file_path = root_path / f
                    if not should_exclude(file_path, exclude_patterns, exclude_files):
                        results.append(file_path.resolve())
    except Exception:
        pass
    return results


def scan_all_python_files(project_root: Path, config: Dict[str, Any]) -> Set[Path]:
    exclude_patterns = config.get("exclude_patterns", [])
    exclude_files = config.get("exclude_files", [])
    all_submodules = get_git_submodules(project_root)
    excluded_submodules = config.get("excluded_submodules", None)

    if excluded_submodules is None:
        submodules_to_exclude = all_submodules
    else:
        submodules_to_exclude = excluded_submodules

    all_excludes = exclude_patterns + submodules_to_exclude

    all_py_files: Set[Path] = set()

    top_level_dirs = [
        d
        for d in project_root.iterdir()
        if d.is_dir() and not should_exclude(d, all_excludes, [])
    ]

    if len(top_level_dirs) > 4:
        with ProcessPoolExecutor(max_workers=min(8, len(top_level_dirs))) as executor:
            args_list = [(d, all_excludes, exclude_files) for d in top_level_dirs]
            for result in executor.map(_scan_directory, args_list):
                all_py_files.update(result)
    else:
        for d in top_level_dirs:
            all_py_files.update(_scan_directory((d, all_excludes, exclude_files)))

    for f in project_root.glob("*.py"):
        if not should_exclude(f, all_excludes, exclude_files):
            all_py_files.add(f.resolve())

    return all_py_files
