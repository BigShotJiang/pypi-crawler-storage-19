import ast
from pathlib import Path
from typing import Set, Tuple, List, FrozenSet
from functools import lru_cache


class ImportExtractor(ast.NodeVisitor):
    def __init__(self, project_packages: FrozenSet[str]):
        self.imports: Set[str] = set()
        self.dynamic_imports: Set[str] = set()
        self.potential_modules: Set[str] = set()
        self.project_packages = project_packages

    def visit_Import(self, node):
        for alias in node.names:
            self.imports.add(alias.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module:
            self.imports.add(node.module)
            # Also add "module.name" for each imported name - they might be submodules
            # e.g., "from backend.routers import auth" -> also add "backend.routers.auth"
            for alias in node.names:
                if alias.name != "*":
                    full_path = f"{node.module}.{alias.name}"
                    self.imports.add(full_path)
        if node.level > 0:
            for alias in node.names:
                self.imports.add(alias.name)
        self.generic_visit(node)

    def visit_Call(self, node):
        func = node.func
        is_import_module = False

        if isinstance(func, ast.Attribute) and func.attr == "import_module":
            if isinstance(func.value, ast.Name) and func.value.id == "importlib":
                is_import_module = True

        if isinstance(func, ast.Name) and func.id in ("import_module", "__import__"):
            is_import_module = True

        func_name = None
        if isinstance(func, ast.Name):
            func_name = func.id
        elif isinstance(func, ast.Attribute):
            func_name = func.attr

        loader_functions = [
            "load_tools_from_toolbox",
            "import_module",
            "load_module",
            "__import__",
        ]

        if (is_import_module or func_name in loader_functions) and node.args:
            first_arg = node.args[0]
            if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
                self.dynamic_imports.add(first_arg.value)

        self.generic_visit(node)

    def visit_Constant(self, node):
        if isinstance(node.value, str):
            value = node.value
            if "." in value and not value.startswith("."):
                for pkg in self.project_packages:
                    if value.startswith(pkg + ".") or value == pkg:
                        self.potential_modules.add(value)
                        break
        self.generic_visit(node)


@lru_cache(maxsize=2048)
def _parse_file_cached(filepath: str) -> Tuple[str, bool]:
    try:
        with open(filepath, encoding="utf-8", errors="ignore") as f:
            content = f.read()
        ast.parse(content)
        return content, True
    except (SyntaxError, UnicodeDecodeError, FileNotFoundError):
        return "", False


def get_all_imports(
    filepath: Path, project_packages: List[str]
) -> Tuple[Set[str], Set[str], Set[str]]:
    content, success = _parse_file_cached(str(filepath))
    if not success:
        return set(), set(), set()

    try:
        tree = ast.parse(content)
    except SyntaxError:
        return set(), set(), set()

    extractor = ImportExtractor(frozenset(project_packages))
    extractor.visit(tree)
    return extractor.imports, extractor.dynamic_imports, extractor.potential_modules


def module_to_possible_paths(
    module: str, source_file: Path, project_root: Path
) -> List[Path]:
    parts = module.split(".")
    possibilities = []

    possibilities.append(project_root / "/".join(parts) / "__init__.py")
    possibilities.append(project_root / (("/".join(parts)) + ".py"))

    source_dir = source_file.parent
    possibilities.append(source_dir / "/".join(parts) / "__init__.py")
    possibilities.append(source_dir / (("/".join(parts)) + ".py"))

    if len(parts) == 1:
        possibilities.append(source_dir / f"{parts[0]}.py")

    for i in range(1, min(5, len(source_dir.parts))):
        parent = source_dir.parents[i - 1] if i <= len(source_dir.parents) else None
        if parent:
            possibilities.append(parent / "/".join(parts) / "__init__.py")
            possibilities.append(parent / (("/".join(parts)) + ".py"))

    return possibilities


def expand_init_imports(init_path: Path, project_packages: List[str]) -> List[Path]:
    expanded = []
    if not init_path.exists() or init_path.name != "__init__.py":
        return expanded

    content, success = _parse_file_cached(str(init_path))
    if not success:
        return expanded

    try:
        tree = ast.parse(content)
    except SyntaxError:
        return expanded

    package_dir = init_path.parent

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.level > 0 and node.module:
                rel_path = package_dir / (node.module.replace(".", "/") + ".py")
                if rel_path.exists():
                    expanded.append(rel_path.resolve())
            elif node.level > 0 and not node.module:
                for alias in node.names:
                    rel_path = package_dir / (alias.name.replace(".", "/") + ".py")
                    if rel_path.exists():
                        expanded.append(rel_path.resolve())

    return expanded


def clear_parser_cache():
    _parse_file_cached.cache_clear()
