from pathlib import Path
from typing import Set, Dict, List, Optional, Any
from .tokenizer import count_tokens, count_lines, read_file_content


def find_children(
    target_path: Path, forward_index: Dict[Path, Set[Path]]
) -> List[Path]:
    target_resolved = target_path.resolve()
    return list(forward_index.get(target_resolved, set()))


def get_all_children_recursive(
    target_path: Path,
    forward_index: Dict[Path, Set[Path]],
    visited: Optional[Set[Path]] = None,
) -> List[Path]:
    if visited is None:
        visited = set()

    target_resolved = target_path.resolve()
    if target_resolved in visited:
        return []

    visited.add(target_resolved)
    all_children: List[Path] = []

    direct_children = find_children(target_path, forward_index)
    for child in direct_children:
        if child not in visited:
            all_children.append(child)
            nested = get_all_children_recursive(child, forward_index, visited)
            all_children.extend(nested)

    return all_children


def get_children_by_depth(
    target_path: Path,
    forward_index: Dict[Path, Set[Path]],
    max_depth: Optional[int] = None,
) -> Dict[int, List[Path]]:
    levels: Dict[int, List[Path]] = {}
    visited: Set[Path] = {target_path.resolve()}
    current_level: List[Path] = [target_path.resolve()]
    depth = 1

    while current_level:
        if max_depth is not None and depth > max_depth:
            break

        next_level: List[Path] = []
        level_files: List[Path] = []

        for file_path in current_level:
            children = find_children(file_path, forward_index)
            for child in children:
                if child not in visited:
                    visited.add(child)
                    level_files.append(child)
                    next_level.append(child)

        if level_files:
            levels[depth] = level_files

        current_level = next_level
        depth += 1

    return levels


def get_children_with_token_limit(
    target_path: Path,
    forward_index: Dict[Path, Set[Path]],
    max_tokens: int,
    excluded: Optional[Set[Path]] = None,
) -> tuple[List[Dict[str, Any]], int]:
    if excluded is None:
        excluded = set()

    levels = get_children_by_depth(target_path, forward_index)
    selected: List[Dict[str, Any]] = []
    total_tokens = 0

    for depth in sorted(levels.keys()):
        level_files = levels[depth]
        for f in level_files:
            if f in excluded:
                continue

            content = read_file_content(f)
            file_tokens = count_tokens(content)

            if total_tokens + file_tokens <= max_tokens:
                selected.append({"path": f, "tokens": file_tokens, "depth": depth})
                total_tokens += file_tokens
            elif max_tokens > 0:
                break

        if total_tokens >= max_tokens and max_tokens > 0:
            break

    return selected, total_tokens


def get_children_to_depth(
    target_path: Path, forward_index: Dict[Path, Set[Path]], max_depth: int
) -> List[Path]:
    levels = get_children_by_depth(target_path, forward_index, max_depth)
    result: List[Path] = []
    for depth in sorted(levels.keys()):
        result.extend(levels[depth])
    return result


def build_children_tree(
    target_path: Path, forward_index: Dict[Path, Set[Path]], project_root: Path
) -> Dict[str, Any]:
    target_resolved = target_path.resolve()
    visited: Set[Path] = {target_resolved}

    def get_node_data(file_path: Path) -> Dict[str, Any]:
        try:
            rel_path = str(file_path.relative_to(project_root))
        except ValueError:
            rel_path = str(file_path)
        content = read_file_content(file_path)
        return {
            "path": rel_path,
            "name": file_path.name,
            "lines": count_lines(file_path),
            "tokens": count_tokens(content),
            "children": [],
        }

    def build_subtree(
        file_path: Path, depth: int, max_depth: int = 10
    ) -> Optional[Dict[str, Any]]:
        if depth > max_depth:
            return None

        node = get_node_data(file_path)
        node["depth"] = depth

        direct_children = find_children(file_path, forward_index)
        for child in direct_children:
            if child not in visited:
                visited.add(child)
                child_node = build_subtree(child, depth + 1, max_depth)
                if child_node:
                    node["children"].append(child_node)

        return node

    root_node = get_node_data(target_resolved)
    root_node["depth"] = 0
    root_node["is_root"] = True

    direct_children = find_children(target_resolved, forward_index)
    for child in direct_children:
        if child not in visited:
            visited.add(child)
            child_node = build_subtree(child, 1)
            if child_node:
                root_node["children"].append(child_node)

    return root_node


def flatten_tree_with_totals(
    tree_node: Dict[str, Any],
    flat_list: Optional[List[Dict[str, Any]]] = None,
    totals: Optional[Dict[str, int]] = None,
) -> tuple[List[Dict[str, Any]], Dict[str, int]]:
    if flat_list is None:
        flat_list = []
    if totals is None:
        totals = {"files": 0, "lines": 0, "tokens": 0}

    if not tree_node.get("is_root"):
        flat_list.append(
            {
                "path": tree_node["path"],
                "name": tree_node["name"],
                "depth": tree_node["depth"],
                "lines": tree_node["lines"],
                "tokens": tree_node["tokens"],
            }
        )
        totals["files"] += 1
        totals["lines"] += tree_node["lines"]
        totals["tokens"] += tree_node["tokens"]

    for child in tree_node.get("children", []):
        flatten_tree_with_totals(child, flat_list, totals)

    return flat_list, totals
