# DEPRECATED: HTML/CSS/JS have been moved to separate files
# - templates/index.html
# - static/css/style.css
# - static/js/app.js

# This file is kept for backwards compatibility but should not be used.
HTML_TEMPLATE = "<!-- Deprecated: Use render_template('index.html') instead -->"
