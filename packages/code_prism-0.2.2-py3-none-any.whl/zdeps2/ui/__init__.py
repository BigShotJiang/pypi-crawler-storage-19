# UI package - templates and static files are now in templates/ and static/ directories
