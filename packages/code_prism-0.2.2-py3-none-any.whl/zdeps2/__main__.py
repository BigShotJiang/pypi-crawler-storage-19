#!/usr/bin/env python3
from .api.app import app
from .core.config import get_project_root, get_config_path


def main():
    print()
    print("=" * 55)
    print("  ZDEPS2 - Modular Dependency Viewer")
    print("=" * 55)
    print(f"\n  Project Root: {get_project_root()}")
    print(f"  Config File:  {get_config_path()}")
    print(f"\n  V2 UI:       http://localhost:5082/v2   <- TRY THIS")
    print(f"  Classic UI:  http://localhost:5082")
    print(f"  Simple UI:   http://localhost:5082/simple")
    print("\n  Press Ctrl+C to stop\n")
    app.run(host="0.0.0.0", port=5082, debug=False)


if __name__ == "__main__":
    main()
