"""
VasperaGuard exceptions.
"""


class VasperaError(Exception):
    """Base exception for VasperaGuard errors."""

    def __init__(self, message: str, status_code: int = None, details: dict = None):
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)


class AuthenticationError(VasperaError):
    """Raised when authentication fails."""

    def __init__(self, message: str = "Invalid API key"):
        super().__init__(message, status_code=401)


class RateLimitError(VasperaError):
    """Raised when rate limit is exceeded."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: int = None):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class ValidationError(VasperaError):
    """Raised when request validation fails."""

    def __init__(self, message: str, field: str = None):
        super().__init__(message, status_code=400)
        self.field = field


class ApprovalTimeoutError(VasperaError):
    """Raised when approval request times out."""

    def __init__(self, approval_id: str):
        super().__init__(f"Approval {approval_id} timed out", status_code=408)
        self.approval_id = approval_id


class CommandBlockedError(VasperaError):
    """Raised when a command is blocked."""

    def __init__(self, command: str, reason: str):
        super().__init__(f"Command blocked: {reason}", status_code=403)
        self.command = command
        self.reason = reason
