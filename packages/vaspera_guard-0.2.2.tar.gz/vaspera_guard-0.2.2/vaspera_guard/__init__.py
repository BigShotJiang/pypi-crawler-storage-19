"""
VasperaGuard Python SDK

The safety & governance layer for AI agents.

Usage:
    from vaspera_guard import Guard

    guard = Guard(api_key="vg_...")

    # Check if a command is safe
    result = guard.check("rm -rf /tmp/cache")

    if result.allowed:
        execute(command)
    elif result.requires_approval:
        guard.request_approval(result.check_id)
    else:
        print(f"Blocked: {result.reason}")
"""

from .client import Guard, GuardConfig
from .models import (
    CheckResult,
    ApprovalResult,
    Policy,
    PolicyRule,
    AgentContext,
    AuditEntry,
)
from .exceptions import (
    VasperaError,
    AuthenticationError,
    RateLimitError,
    ValidationError,
)

__version__ = "0.1.0"
__all__ = [
    "Guard",
    "GuardConfig",
    "CheckResult",
    "ApprovalResult",
    "Policy",
    "PolicyRule",
    "AgentContext",
    "AuditEntry",
    "VasperaError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
]
