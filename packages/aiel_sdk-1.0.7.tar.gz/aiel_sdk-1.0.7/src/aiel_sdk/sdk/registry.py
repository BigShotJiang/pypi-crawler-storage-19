from __future__ import annotations
from typing import Any, Callable, ClassVar, Dict, List, Tuple

from .exports import ToolExport, AgentExport, FlowExport, HttpHandlerExport, McpServerExport

class ExportRegistry:
    # Global registry shared across decorators and runtime loaders.
    tools: ClassVar[Dict[str, ToolExport]] = {}
    agents: ClassVar[Dict[str, AgentExport]] = {}
    flows: ClassVar[Dict[str, FlowExport]] = {}
    http_handlers: ClassVar[List[HttpHandlerExport]] = []
    mcp_servers: ClassVar[Dict[str, McpServerExport]] = {}
    mcp_tool_fns: ClassVar[Dict[Tuple[str, str], Callable[..., Any]]] = {}
