"""Contains tests for structures."""
