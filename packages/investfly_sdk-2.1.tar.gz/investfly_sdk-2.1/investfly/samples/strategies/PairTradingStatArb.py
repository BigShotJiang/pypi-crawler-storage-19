from typing import List, Optional

from investfly.models import *


class PairTradingStatArb(TradingStrategy):
    """
    Pair trading statistical arbitrage strategy that:
    1. Monitors the spread between two correlated securities
    2. Computes spread statistics (mean and std) daily
    3. Enters mean-reversion trades when spread deviates significantly
    4. Closes positions when spread returns to mean
    
    The strategy assumes two securities (e.g., AAPL and MSFT) move together
    and trades on temporary divergences.
    """
    
    SYMBOL_A = "AAPL"
    SYMBOL_B = "MSFT"
    LOOKBACK = 100
    Z_THRESHOLD = 2.0
    POSITION_SIZE = 0.02  # 2% of portfolio
    
    # Spread statistics (computed daily)
    spread_mean = None
    spread_std = None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromSymbols(SecurityType.STOCK, [self.SYMBOL_A, self.SYMBOL_B])

    @time_trigger(interval=ScheduleInterval.DAY, hourOfDay=9)
    def onSchedule(self) -> Optional[List[TradeOrder]]:
        security_a = Security.createStock(self.SYMBOL_A)
        security_b = Security.createStock(self.SYMBOL_B)
        
        try:
            bars_a = self.dataService.getBars(security_a, BarInterval.ONE_DAY, numBars=self.LOOKBACK)
            bars_b = self.dataService.getBars(security_b, BarInterval.ONE_DAY, numBars=self.LOOKBACK)
        except NoDataException:
            return []
        
        closes_a = [bar["close"] for bar in bars_a[-self.LOOKBACK:]]
        closes_b = [bar["close"] for bar in bars_b[-self.LOOKBACK:]]
        
        spread = [a - b for a, b in zip(closes_a, closes_b)]
        
        self.spread_mean = sum(spread) / len(spread)
        variance = sum((x - self.spread_mean) ** 2 for x in spread) / len(spread)
        self.spread_std = variance ** 0.5
        
        return []

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        if self.spread_mean is None or self.spread_std is None:
            return []
        
        orders = []
        
        security_a = Security.createStock(self.SYMBOL_A)
        security_b = Security.createStock(self.SYMBOL_B)
        
        try:
            quote_a = self.dataService.getQuote(security_a)
            quote_b = self.dataService.getQuote(security_b)
        except NoDataException:
            return []
        
        spread = quote_a.lastPrice - quote_b.lastPrice
        
        upper = self.spread_mean + self.Z_THRESHOLD * self.spread_std
        lower = self.spread_mean - self.Z_THRESHOLD * self.spread_std
        
        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE
        
        if spread > upper:
            orders.append(TradeOrder(security=security_a, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
            orders.append(TradeOrder(security=security_b, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
        elif spread < lower:
            orders.append(TradeOrder(security=security_a, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
            orders.append(TradeOrder(security=security_b, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
        
        return orders

