from typing import List, Optional

from investfly.models import *


class ForexBreakoutStrategy(TradingStrategy):
    """
    Forex breakout strategy that:
    1. Monitors forex pairs for breakout patterns
    2. Identifies key support/resistance levels using SMAs
    3. Waits for volume confirmation on breakouts
    4. Uses 15-minute bars for medium-term holds
    
    This strategy is useful for forex breakout trading, support/resistance
    analysis, and medium-term forex positions.
    """
    
    POSITION_SIZE = 0.25  # 25% of portfolio

    def _evaluate_exit(self, position: OpenPosition, current_price: float, sma_20: float, rsi: float) -> Optional[TradeOrder]:
        if position.position == PositionType.LONG:
            if current_price < sma_20 * 0.98 or rsi > 80 or rsi < 20:
                return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        elif position.position == PositionType.SHORT:
            if current_price > sma_20 * 1.02 or rsi < 20 or rsi > 80:
                return TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, trend_score: float, momentum_score: float, volatility_score: float, volume_score: float, sma_20: float, sma_50: float, position_amount: float) -> Optional[TradeOrder]:
        if trend_score > 0.6 and momentum_score > 0.5 and volatility_score > 0.4 and volume_score > 1.3:
            if sma_20 > sma_50:
                return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
            else:
                return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.FIFTEEN_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.FIFTEEN_MINUTE, numBars=60)
                
                current_price = bars[-1]["close"]
                current_volume = bars[-1]["volume"]
                
                sma_20_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 20, StandardParams.BARINTERVAL: BarInterval.FIFTEEN_MINUTE})
                sma_50_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 50, StandardParams.BARINTERVAL: BarInterval.FIFTEEN_MINUTE})
                rsi_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: 14, StandardParams.BARINTERVAL: BarInterval.FIFTEEN_MINUTE})
                atr_series = self.dataService.computeIndicatorSeries(IndicatorId.ATR, security, {IndicatorParam.ATR.PERIOD: 14, StandardParams.BARINTERVAL: BarInterval.FIFTEEN_MINUTE})
                
                current_sma_20 = sma_20_series.last.value
                current_sma_50 = sma_50_series.last.value
                current_rsi = rsi_series.last.value
                current_atr = atr_series.last.value
                
                volumes = [bar["volume"] for bar in bars]
                avg_volume = sum(volumes) / len(volumes) if volumes else 1
                volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
                
                trend_score = self._calculate_trend_score(current_sma_20, current_sma_50)
                momentum_score = self._calculate_momentum_score(current_rsi)
                volatility_score = self._calculate_volatility_score(current_atr, current_price)
                volume_score = self._calculate_volume_score(volume_ratio)
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, current_price, current_sma_20, current_rsi)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, trend_score, momentum_score, volatility_score, volume_score, current_sma_20, current_sma_50, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def _calculate_trend_score(self, sma_20: float, sma_50: float) -> float:
        if sma_50 == 0:
            return 0.0
        
        trend_ratio = sma_20 / sma_50
        if trend_ratio > 1.0:
            return min(1.0, (trend_ratio - 1.0) * 10 + 0.5)
        else:
            return max(0.0, trend_ratio - 0.9) * 5

    def _calculate_momentum_score(self, rsi: float) -> float:
        if 25 <= rsi <= 75:
            return 1.0 - abs(rsi - 50) / 25
        elif rsi > 75:
            return max(0.0, 1.0 - (rsi - 75) / 25)
        else:
            return max(0.0, 1.0 - (25 - rsi) / 25)

    def _calculate_volatility_score(self, atr: float, price: float) -> float:
        if price == 0:
            return 0.0
        
        atr_percent = atr / price
        if 0.005 <= atr_percent <= 0.02:
            return 1.0
        elif atr_percent < 0.005:
            return atr_percent * 200
        else:
            return max(0.0, 1.0 - (atr_percent - 0.02) * 50)

    def _calculate_volume_score(self, volume_ratio: float) -> float:
        if volume_ratio >= 1.5:
            return min(2.0, volume_ratio)
        elif volume_ratio >= 1.3:
            return volume_ratio
        else:
            return max(0.0, volume_ratio)

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=3.0, stopLoss=-2.0, trailingStop=-1.5, timeOut=TimeDelta(value=8, unit=TimeUnit.HOURS))

