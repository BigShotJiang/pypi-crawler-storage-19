from typing import List, Optional

from investfly.models import *


class IchimokuCloudStrategy(TradingStrategy):
    """
    Ichimoku Cloud strategy that:
    1. Uses cloud position for trend direction
    2. Identifies Tenkan-sen/Kijun-sen crossovers
    3. Uses cloud thickness for trend strength
    4. Closes positions when price reverses through cloud
    
    This is a complex trend-following strategy that provides comprehensive
    market analysis using the Ichimoku Cloud system.
    """
    
    POSITION_SIZE = 0.33  # 33% of portfolio

    def _evaluate_exit(self, position: OpenPosition, current_price: float, cloud_top: float, cloud_bottom: float) -> Optional[TradeOrder]:
        if position.position == PositionType.LONG and current_price < cloud_bottom:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        elif position.position == PositionType.SHORT and current_price > cloud_top:
            return TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, current_price: float, cloud_top: float, cloud_bottom: float, tenkan_sen: float, kijun_sen: float, prev_tenkan_sen: float, prev_kijun_sen: float, cloud_thickness: float, volume_ratio: float, position_amount: float) -> Optional[TradeOrder]:
        if current_price > cloud_top and prev_tenkan_sen <= prev_kijun_sen and tenkan_sen > kijun_sen and volume_ratio > 1.2:
            return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if current_price < cloud_bottom and prev_tenkan_sen >= prev_kijun_sen and tenkan_sen < kijun_sen and volume_ratio > 1.2:
            return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if cloud_thickness > 5.0 and volume_ratio > 1.5:
            if current_price > cloud_top * 1.02:
                return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
            elif current_price < cloud_bottom * 0.98:
                return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_DAY)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_DAY, numBars=60)
                
                current_price = bars[-1]["close"]
                current_volume = bars[-1]["volume"]
                
                tenkan_sen = self._calculate_tenkan_sen(bars[-9:])
                prev_tenkan_sen = self._calculate_tenkan_sen(bars[-10:-1]) if len(bars) >= 10 else tenkan_sen
                
                kijun_sen = self._calculate_kijun_sen(bars[-26:])
                prev_kijun_sen = self._calculate_kijun_sen(bars[-27:-1]) if len(bars) >= 27 else kijun_sen
                
                senkou_span_a = (tenkan_sen + kijun_sen) / 2
                prev_senkou_span_a = (prev_tenkan_sen + prev_kijun_sen) / 2
                
                senkou_span_b = self._calculate_senkou_span_b(bars[-52:])
                
                cloud_top = max(senkou_span_a, senkou_span_b)
                cloud_bottom = min(senkou_span_a, senkou_span_b)
                cloud_color = "green" if senkou_span_a > senkou_span_b else "red"
                
                cloud_thickness = (cloud_top - cloud_bottom) / cloud_bottom * 100 if cloud_bottom != 0 else 0
                
                volumes = [bar["volume"] for bar in bars]
                avg_volume = sum(volumes) / len(volumes) if volumes else 1
                volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, current_price, cloud_top, cloud_bottom)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, current_price, cloud_top, cloud_bottom, tenkan_sen, kijun_sen, prev_tenkan_sen, prev_kijun_sen, cloud_thickness, volume_ratio, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def _calculate_tenkan_sen(self, bars: List) -> float:
        if len(bars) < 9:
            return 0.0
        
        highs = [bar["high"] for bar in bars]
        lows = [bar["low"] for bar in bars]
        
        highest_high = max(highs)
        lowest_low = min(lows)
        
        return (highest_high + lowest_low) / 2

    def _calculate_kijun_sen(self, bars: List) -> float:
        if len(bars) < 26:
            return 0.0
        
        highs = [bar["high"] for bar in bars]
        lows = [bar["low"] for bar in bars]
        
        highest_high = max(highs)
        lowest_low = min(lows)
        
        return (highest_high + lowest_low) / 2

    def _calculate_senkou_span_b(self, bars: List) -> float:
        if len(bars) < 52:
            return 0.0
        
        highs = [bar["high"] for bar in bars]
        lows = [bar["low"] for bar in bars]
        
        highest_high = max(highs)
        lowest_low = min(lows)
        
        return (highest_high + lowest_low) / 2

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=7.0, stopLoss=-3.5, trailingStop=-2.0, timeOut=TimeDelta(value=10, unit=TimeUnit.DAYS))

