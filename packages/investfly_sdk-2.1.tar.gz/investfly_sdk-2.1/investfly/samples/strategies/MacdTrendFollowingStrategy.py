from typing import List, Optional

from investfly.models import *


class MacdTrendFollowingStrategy(TradingStrategy):
    """
    MACD trend following strategy that:
    1. Uses MACD indicator to identify trend momentum
    2. Generates buy signals when MACD line crosses above signal line (bullish momentum)
    3. Generates sell signals when MACD line crosses below signal line (bearish momentum)
    
    This is a trend-following strategy that capitalizes on momentum shifts
    when MACD crosses its signal line.
    """
    
    FAST_PERIOD = 12
    SLOW_PERIOD = 26
    SIGNAL_PERIOD = 9
    POSITION_SIZE = 0.05  # 5% of portfolio

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_DAY)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                macd_series = self.dataService.computeIndicatorSeries(IndicatorId.MACD, security, {IndicatorParam.MACD.FAST_PERIOD: self.FAST_PERIOD, IndicatorParam.MACD.SLOW_PERIOD: self.SLOW_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                macd_signal_series = self.dataService.computeIndicatorSeries(IndicatorId.MACDS, security, {IndicatorParam.MACDS.FAST_PERIOD: self.FAST_PERIOD, IndicatorParam.MACDS.SLOW_PERIOD: self.SLOW_PERIOD, IndicatorParam.MACDS.SIGNAL_PERIOD: self.SIGNAL_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    if macd_series.cross_under(macd_signal_series) and position.position == PositionType.LONG:
                        orders.append(TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity))
                else:
                    if macd_series.cross_over(macd_signal_series):
                        orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=5.0, stopLoss=-3.0, trailingStop=None, timeOut=TimeDelta(value=10, unit=TimeUnit.DAYS))

