from typing import List, Optional, Dict, cast

from investfly.models import *


class ForexCarryTradeStrategy(TradingStrategy):
    """
    Forex carry trade strategy that:
    1. Identifies high-yielding vs low-yielding currency pairs
    2. Uses trend indicators for entry confirmation
    3. Implements volatility-based position sizing
    4. Closes positions when trend reverses
    
    This is a fundamental strategy that capitalizes on interest rate differentials
    while using technical analysis for entry/exit timing.
    """
    
    POSITION_SIZE = 0.20  # 20% of portfolio
    
    CARRY_PAIRS = {
        "AUDUSD": {"high_yield": "AUD", "low_yield": "USD", "carry_score": 2.5},
        "NZDUSD": {"high_yield": "NZD", "low_yield": "USD", "carry_score": 3.0},
        "GBPUSD": {"high_yield": "GBP", "low_yield": "USD", "carry_score": 1.5},
        "EURUSD": {"high_yield": "EUR", "low_yield": "USD", "carry_score": 0.5},
        "USDJPY": {"high_yield": "USD", "low_yield": "JPY", "carry_score": 2.0}
    }

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)

    def _should_exit_long(self, sma_20: float, sma_50: float, rsi: float) -> bool:
        return sma_20 < sma_50 or rsi > 70

    def _should_exit_short(self, sma_20: float, sma_50: float, rsi: float) -> bool:
        return sma_20 > sma_50 or rsi < 30

    def _should_enter_long(self, sma_20: float, sma_50: float, sma_20_slope: float, sma_50_slope: float, rsi: float, carry_score: float, current_price: float) -> bool:
        if sma_20 > sma_50 and sma_20_slope > 0 and sma_50_slope > 0 and rsi < 40 and carry_score > 1.0:
            return True
        if abs(sma_20_slope) > abs(sma_50_slope) * 2 and sma_20_slope > 0 and carry_score > 0.5 and current_price > sma_20:
            return True
        return False

    def _should_enter_short(self, sma_20: float, sma_50: float, sma_20_slope: float, sma_50_slope: float, rsi: float, carry_score: float, current_price: float) -> bool:
        if sma_20 < sma_50 and sma_20_slope < 0 and sma_50_slope < 0 and rsi > 60 and carry_score < 0:
            return True
        if abs(sma_20_slope) > abs(sma_50_slope) * 2 and sma_20_slope < 0 and carry_score < 0 and current_price < sma_20:
            return True
        return False

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []
        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_MINUTE, numBars=60)
                current_price = bars[-1]["close"]
                
                sma_20_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 20, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                sma_50_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 50, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                rsi_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: 14, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                
                sma_20_list = sma_20_series.toList()
                sma_50_list = sma_50_series.toList()
                if len(sma_20_list) < 3 or len(sma_50_list) < 3:
                    continue
                
                current_sma_20 = sma_20_list[-1].value
                prev_sma_20 = sma_20_list[-2].value
                current_sma_50 = sma_50_list[-1].value
                prev_sma_50 = sma_50_list[-2].value
                current_rsi = rsi_series.last.value
                sma_20_slope = current_sma_20 - prev_sma_20
                sma_50_slope = current_sma_50 - prev_sma_50
                
                carry_info = self.CARRY_PAIRS.get(security.symbol, {"carry_score": 0})
                carry_score = cast(float, carry_info.get("carry_score", 0))
                
                position = portfolio.findPosition(security, PositionType.LONG)
                if position is None:
                    position = portfolio.findPosition(security, PositionType.SHORT)
                
                if position:
                    if position.position == PositionType.LONG and self._should_exit_long(current_sma_20, current_sma_50, current_rsi):
                        orders.append(TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity))
                    elif position.position == PositionType.SHORT and self._should_exit_short(current_sma_20, current_sma_50, current_rsi):
                        orders.append(TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity))
                else:
                    if self._should_enter_long(current_sma_20, current_sma_50, sma_20_slope, sma_50_slope, current_rsi, carry_score, current_price):
                        orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
                    elif self._should_enter_short(current_sma_20, current_sma_50, sma_20_slope, sma_50_slope, current_rsi, carry_score, current_price):
                        orders.append(TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=4.0, stopLoss=-2.5, trailingStop=-1.5, timeOut=TimeDelta(value=10, unit=TimeUnit.DAYS))

