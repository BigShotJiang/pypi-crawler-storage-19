from typing import List, Optional

from investfly.models import *


class EtfSectorRotationStrategy(TradingStrategy):
    """
    ETF Sector Rotation strategy that:
    1. Monitors multiple sector ETFs for relative strength
    2. Calculates momentum and trend indicators for each sector
    3. Rotates into sectors showing strongest momentum
    4. Exits positions when sector momentum weakens
    
    This strategy is useful for sector rotation, ETF-focused portfolios,
    and swing trading with daily timeframes.
    """
    
    POSITION_SIZE = 0.20  # 20% of portfolio
    MAX_SECTORS = 5

    def _evaluate_exit(self, position: OpenPosition, current_price: float, sma_20: float, rsi: float) -> Optional[TradeOrder]:
        if current_price < sma_20 * 0.95 or rsi > 80 or rsi < 25:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ETFS)

    @time_trigger(interval=ScheduleInterval.DAY, hourOfDay=10)
    def onSchedule(self) -> Optional[List[TradeOrder]]:
        """Rank all ETFs by momentum/trend scores and select top performers."""
        orders = []
        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        # Use runMarketQuery to get all ETFs in the universe
        # We can use an empty filter to get all securities, or add basic filters
        filter_expr = SecurityFilterExpression()
        query_request = MarketQueryRequest(securityFilterExpression=filter_expr)
        all_etfs = self.dataService.runMarketQuery(query_request)

        etf_scores = []
        
        for security in all_etfs:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_DAY, numBars=60)
                
                current_price = bars[-1]["close"]
                current_volume = bars[-1]["volume"]
                
                sma_20_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 20, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                sma_50_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 50, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                rsi_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: 14, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                macd_series = self.dataService.computeIndicatorSeries(IndicatorId.MACD, security, {IndicatorParam.MACD.FAST_PERIOD: 12, IndicatorParam.MACD.SLOW_PERIOD: 26, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                macd_signal_series = self.dataService.computeIndicatorSeries(IndicatorId.MACDS, security, {IndicatorParam.MACDS.FAST_PERIOD: 12, IndicatorParam.MACDS.SLOW_PERIOD: 26, IndicatorParam.MACDS.SIGNAL_PERIOD: 9, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                
                current_sma_20 = sma_20_series.last.value
                current_sma_50 = sma_50_series.last.value
                current_rsi = rsi_series.last.value
                current_macd = macd_series.last.value
                current_macd_signal = macd_signal_series.last.value
                
                volumes = [bar["volume"] for bar in bars]
                avg_volume = sum(volumes) / len(volumes) if volumes else 1
                volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1
                
                trend_score = self._calculate_trend_score(current_sma_20, current_sma_50)
                momentum_score = self._calculate_momentum_score(current_rsi, current_macd, current_macd_signal)
                volume_score = self._calculate_volume_score(volume_ratio)
                
                combined_score = (trend_score + momentum_score + volume_score) / 3
                
                etf_scores.append((security, combined_score))
            except NoDataException:
                continue
        
        etf_scores.sort(key=lambda x: x[1], reverse=True)
        top_etfs = etf_scores[:self.MAX_SECTORS]
        
        # Close positions in ETFs that are no longer in top performers
        current_positions = {pos.security.symbol: pos for pos in portfolio.openPositions}
        top_etf_symbols = {security.symbol for security, _ in top_etfs if _ > 0.6}
        
        for symbol, position in current_positions.items():
            if symbol not in top_etf_symbols:
                orders.append(TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity))
        
        # Open positions in top ETFs that we don't already own
        for security, score in top_etfs:
            if score > 0.6:
                if not portfolio.findPosition(security, PositionType.LONG):
                    orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))

        return orders if orders else None

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_DAY)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        """Handle exit conditions when market data updates."""
        orders = []
        portfolio = self.context.portfolio

        for security in updatedSecurities:
            try:
                position = portfolio.findPosition(security, PositionType.LONG)
                if not position:
                    continue
                
                bars = self.dataService.getBars(security, BarInterval.ONE_DAY, numBars=60)
                current_price = bars[-1]["close"]
                
                sma_20_series = self.dataService.computeIndicatorSeries(IndicatorId.SMA, security, {IndicatorParam.SMA.PERIOD: 20, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                rsi_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: 14, StandardParams.BARINTERVAL: BarInterval.ONE_DAY})
                
                current_sma_20 = sma_20_series.last.value
                current_rsi = rsi_series.last.value
                
                exit_order = self._evaluate_exit(position, current_price, current_sma_20, current_rsi)
                if exit_order:
                    orders.append(exit_order)
            except NoDataException:
                continue

        return orders if orders else None

    def _calculate_trend_score(self, sma_20: float, sma_50: float) -> float:
        if sma_50 == 0:
            return 0.0
        
        trend_ratio = sma_20 / sma_50
        if trend_ratio > 1.0:
            return min(1.0, (trend_ratio - 1.0) * 5 + 0.5)
        else:
            return max(0.0, trend_ratio - 0.8) * 2.5

    def _calculate_momentum_score(self, rsi: float, macd: float, macd_signal: float) -> float:
        rsi_score = 0.0
        if 30 <= rsi <= 70:
            rsi_score = 1.0 - abs(rsi - 50) / 20
        elif rsi > 70:
            rsi_score = max(0.0, 1.0 - (rsi - 70) / 30)
        else:
            rsi_score = max(0.0, 1.0 - (30 - rsi) / 30)
        
        macd_score = 0.0
        if macd > macd_signal:
            macd_score = min(1.0, (macd - macd_signal) / abs(macd_signal) if macd_signal != 0 else 0.5)
        
        return (rsi_score + macd_score) / 2

    def _calculate_volume_score(self, volume_ratio: float) -> float:
        if volume_ratio >= 1.2:
            return min(1.0, volume_ratio / 2.0)
        else:
            return max(0.0, volume_ratio)

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=15.0, stopLoss=-8.0, trailingStop=-5.0, timeOut=TimeDelta(value=14, unit=TimeUnit.DAYS))

