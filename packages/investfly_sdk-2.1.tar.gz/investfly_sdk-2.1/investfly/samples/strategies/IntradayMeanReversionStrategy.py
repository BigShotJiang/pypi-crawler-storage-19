from typing import List, Optional

from investfly.models import *


class IntradayMeanReversionStrategy(TradingStrategy):
    """
    Intraday mean reversion strategy that:
    1. Monitors price deviations from recent mean using z-score
    2. Enters positions when z-score exceeds threshold (oversold/overbought)
    3. Exits positions when z-score returns to normal range
    
    This strategy is designed for intraday trading and should not use
    standard close conditions (TP/SL) as positions are managed by z-score logic.
    """
    
    Z_ENTRY = 2.0  # Enter when |z| > 2.0
    Z_EXIT = 0.2   # Exit when |z| < 0.2
    POSITION_SIZE = 0.02  # 2% of portfolio

    def _evaluate_exit(self, position: OpenPosition, z: float) -> Optional[TradeOrder]:
        if abs(z) < self.Z_EXIT:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL if position.position == PositionType.LONG else TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, z: float) -> Optional[TradeOrder]:
        if abs(z) > self.Z_ENTRY:
            trade_type = TradeType.BUY if z < 0 else TradeType.SELL
            return TradeOrder(security=security, tradeType=trade_type, orderType=OrderType.MARKET_ORDER, maxAmount=self.POSITION_SIZE)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.SP_500)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.FIVE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        portfolio = self.context.portfolio
        orders = []

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.FIVE_MINUTE, numBars=50)

                close_prices = [bar["close"] for bar in bars]
                mean = sum(close_prices) / len(close_prices)
                variance = sum((x - mean) ** 2 for x in close_prices) / len(close_prices)
                std = variance ** 0.5
                if std == 0:
                    continue
                current_price = close_prices[-1]
                z = (current_price - mean) / std

                position = portfolio.findPosition(security, PositionType.LONG)

                if position:
                    exit_order = self._evaluate_exit(position, z)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, z)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders

