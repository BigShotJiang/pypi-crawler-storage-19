from typing import List, Optional

from investfly.models import *


class CryptoMomentumStrategy(TradingStrategy):
    """
    Crypto momentum strategy that:
    1. Analyzes multiple timeframes for momentum confirmation
    2. Uses RSI and MACD for signal generation
    3. Includes volume confirmation for crypto markets
    4. Implements volatility-adjusted position sizing
    5. Closes positions when momentum reverses
    
    This is a momentum strategy optimized for cryptocurrency markets
    that exhibit high volatility and strong trending behavior.
    """
    
    RSI_PERIOD = 14
    MACD_FAST = 12
    MACD_SLOW = 26
    MACD_SIGNAL = 9
    POSITION_SIZE = 0.25  # 25% of portfolio

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.USD_CRYPTO)

    def _should_exit_long(self, rsi_1min: float, macd_histogram: float) -> bool:
        return rsi_1min > 70 or macd_histogram < 0

    def _should_exit_short(self, rsi_1min: float, macd_histogram: float) -> bool:
        return rsi_1min < 30 or macd_histogram > 0

    def _should_enter_long(self, rsi_momentum_1min: float, rsi_momentum_5min: float, macd_momentum: float, macd: float, macd_signal: float, volume_ratio: float, rsi_1min: float, rsi_5min: float) -> bool:
        if rsi_momentum_1min > 5 and rsi_momentum_5min > 3 and macd_momentum > 0 and macd > macd_signal and volume_ratio > 1.3:
            return True
        if volume_ratio > 2.0 and rsi_1min < 20 and rsi_5min < 25:
            return True
        return False

    def _should_enter_short(self, rsi_momentum_1min: float, rsi_momentum_5min: float, macd_momentum: float, macd: float, macd_signal: float, volume_ratio: float, rsi_1min: float, rsi_5min: float) -> bool:
        if rsi_momentum_1min < -5 and rsi_momentum_5min < -3 and macd_momentum < 0 and macd < macd_signal and volume_ratio > 1.3:
            return True
        if volume_ratio > 2.0 and rsi_1min > 80 and rsi_5min > 75:
            return True
        return False

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []
        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_MINUTE, numBars=50)
                current_volume = bars[-1]["volume"]
                volumes = [bar["volume"] for bar in bars]
                volume_ratio = current_volume / (sum(volumes) / len(volumes)) if volumes else 1
                
                rsi_1min_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: self.RSI_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                rsi_5min_series = self.dataService.computeIndicatorSeries(IndicatorId.RSI, security, {IndicatorParam.RSI.PERIOD: self.RSI_PERIOD, StandardParams.BARINTERVAL: BarInterval.FIVE_MINUTE})
                macd_series = self.dataService.computeIndicatorSeries(IndicatorId.MACD, security, {IndicatorParam.MACD.FAST_PERIOD: self.MACD_FAST, IndicatorParam.MACD.SLOW_PERIOD: self.MACD_SLOW, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                macd_signal_series = self.dataService.computeIndicatorSeries(IndicatorId.MACDS, security, {IndicatorParam.MACDS.FAST_PERIOD: self.MACD_FAST, IndicatorParam.MACDS.SLOW_PERIOD: self.MACD_SLOW, IndicatorParam.MACDS.SIGNAL_PERIOD: self.MACD_SIGNAL, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                
                rsi_1min_list = rsi_1min_series.toList()
                rsi_5min_list = rsi_5min_series.toList()
                macd_list = macd_series.toList()
                signal_list = macd_signal_series.toList()
                if len(rsi_1min_list) < 3 or len(rsi_5min_list) < 3 or len(macd_list) < 3 or len(signal_list) < 3:
                    continue
                
                current_rsi_1min = rsi_1min_list[-1].value
                prev_rsi_1min = rsi_1min_list[-2].value
                current_rsi_5min = rsi_5min_list[-1].value
                prev_rsi_5min = rsi_5min_list[-2].value
                current_macd = macd_list[-1].value
                prev_macd = macd_list[-2].value
                current_macd_signal = signal_list[-1].value
                prev_macd_signal = signal_list[-2].value
                
                rsi_momentum_1min = current_rsi_1min - prev_rsi_1min
                rsi_momentum_5min = current_rsi_5min - prev_rsi_5min
                macd_histogram = current_macd - current_macd_signal
                macd_momentum = macd_histogram - (prev_macd - prev_macd_signal)
                
                position = portfolio.findPosition(security, PositionType.LONG)
                if position is None:
                    position = portfolio.findPosition(security, PositionType.SHORT)
                
                if position:
                    if position.position == PositionType.LONG and self._should_exit_long(current_rsi_1min, macd_histogram):
                        orders.append(TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity))
                    elif position.position == PositionType.SHORT and self._should_exit_short(current_rsi_1min, macd_histogram):
                        orders.append(TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity))
                else:
                    if self._should_enter_long(rsi_momentum_1min, rsi_momentum_5min, macd_momentum, current_macd, current_macd_signal, volume_ratio, current_rsi_1min, current_rsi_5min):
                        orders.append(TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
                    elif self._should_enter_short(rsi_momentum_1min, rsi_momentum_5min, macd_momentum, current_macd, current_macd_signal, volume_ratio, current_rsi_1min, current_rsi_5min):
                        orders.append(TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount))
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=6.0, stopLoss=-3.0, trailingStop=-1.5, timeOut=TimeDelta(value=5, unit=TimeUnit.DAYS))

