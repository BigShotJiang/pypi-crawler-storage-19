from typing import List, Optional

from investfly.models import *


class MacdHistogramStrategy(TradingStrategy):
    """
    MACD histogram momentum strategy that:
    1. Uses MACD histogram (MACD - signal line) to identify momentum shifts
    2. Generates buy signals when histogram turns positive (bullish momentum)
    3. Generates sell signals when histogram turns negative (bearish momentum)
    4. Uses histogram slope for momentum confirmation
    
    This is a trend-following strategy that capitalizes on momentum shifts
    when MACD histogram crosses the zero line.
    """
    
    FAST_PERIOD = 12
    SLOW_PERIOD = 26
    SIGNAL_PERIOD = 9
    POSITION_SIZE = 0.25  # 25% of portfolio

    def _evaluate_exit(self, position: OpenPosition, current_histogram: float, prev_histogram: float) -> Optional[TradeOrder]:
        if position.position == PositionType.LONG and current_histogram < 0 and prev_histogram > 0:
            return TradeOrder(security=position.security, tradeType=TradeType.SELL, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        elif position.position == PositionType.SHORT and current_histogram > 0 and prev_histogram < 0:
            return TradeOrder(security=position.security, tradeType=TradeType.COVER, orderType=OrderType.MARKET_ORDER, quantity=position.quantity)
        return None

    def _evaluate_entry(self, security: Security, current_histogram: float, prev_histogram: float, histogram_slope: float, prev_histogram_slope: float, position_amount: float) -> Optional[TradeOrder]:
        if prev_histogram <= 0 and current_histogram > 0 and histogram_slope > 0:
            return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if prev_histogram >= 0 and current_histogram < 0 and histogram_slope < 0:
            return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        if abs(histogram_slope) > abs(prev_histogram_slope) * 1.5:
            if current_histogram > 0 and histogram_slope > 0:
                return TradeOrder(security=security, tradeType=TradeType.BUY, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
            elif current_histogram < 0 and histogram_slope < 0:
                return TradeOrder(security=security, tradeType=TradeType.SHORT, orderType=OrderType.MARKET_ORDER, maxAmount=position_amount)
        return None

    def getSecurityUniverseSelector(self) -> SecurityUniverseSelector:
        return SecurityUniverseSelector.fromStandardList(StandardSymbolsList.ALL_FOREX)

    @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
    def onMarketData(self, updatedSecurities: List[Security]) -> Optional[List[TradeOrder]]:
        orders = []

        portfolio = self.context.portfolio
        portfolio_value = portfolio.balances.currentValue
        position_amount = portfolio_value * self.POSITION_SIZE

        for security in updatedSecurities:
            try:
                bars = self.dataService.getBars(security, BarInterval.ONE_MINUTE, numBars=50)
                
                macd_series = self.dataService.computeIndicatorSeries(IndicatorId.MACD, security, {IndicatorParam.MACD.FAST_PERIOD: self.FAST_PERIOD, IndicatorParam.MACD.SLOW_PERIOD: self.SLOW_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                macd_signal_series = self.dataService.computeIndicatorSeries(IndicatorId.MACDS, security, {IndicatorParam.MACDS.FAST_PERIOD: self.FAST_PERIOD, IndicatorParam.MACDS.SLOW_PERIOD: self.SLOW_PERIOD, IndicatorParam.MACDS.SIGNAL_PERIOD: self.SIGNAL_PERIOD, StandardParams.BARINTERVAL: BarInterval.ONE_MINUTE})
                
                macd_list = macd_series.toList()
                signal_list = macd_signal_series.toList()
                
                if len(macd_list) < 3 or len(signal_list) < 3:
                    continue
                
                current_histogram = macd_list[-1].value - signal_list[-1].value
                prev_histogram = macd_list[-2].value - signal_list[-2].value
                prev_prev_histogram = macd_list[-3].value - signal_list[-3].value
                
                histogram_slope = current_histogram - prev_histogram
                prev_histogram_slope = prev_histogram - prev_prev_histogram
                
                position = portfolio.findPosition(security, PositionType.LONG)
                
                if position:
                    exit_order = self._evaluate_exit(position, current_histogram, prev_histogram)
                    if exit_order:
                        orders.append(exit_order)
                else:
                    entry_order = self._evaluate_entry(security, current_histogram, prev_histogram, histogram_slope, prev_histogram_slope, position_amount)
                    if entry_order:
                        orders.append(entry_order)
            except NoDataException:
                continue

        return orders if orders else None

    def getStandardCloseCondition(self) -> StandardCloseCriteria:
        return StandardCloseCriteria(targetProfit=6.0, stopLoss=-3.0, trailingStop=-1.5, timeOut=TimeDelta(value=7, unit=TimeUnit.DAYS))

