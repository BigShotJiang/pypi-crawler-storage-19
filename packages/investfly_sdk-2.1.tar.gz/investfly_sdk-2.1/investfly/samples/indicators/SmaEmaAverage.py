from typing import Any, List, Dict

import numpy as np
import talib  # type: ignore

from investfly.models import *
from investfly.utils import *

# This sample show how you can use pandas_ta module at https://github.com/twopirllc/pandas-ta
# to compute over 100 technical indicators
# This indicator computes average of SMA and EMA for given period

class SmaEmaAverage(Indicator):
    # In this method, you must construct and return IndicatorSpec object that specifies
    # indicator name, description and any parameters it needs. Stanard parameters like (barinterval, count, lookback)
    #  are automatically added
    def getIndicatorSpec(self) -> IndicatorSpec:
        indicator = IndicatorSpec("SMA EMA Average")
        indicator.addParam('period', IndicatorParamSpec(ParamType.INTEGER, True, 5, IndicatorParamSpec.PERIOD_VALUES))
        return indicator

    def computeSeries(self, params: Dict[str, Any]) -> List[DatedValue]:
        numBars = SmaEmaAverage.calculateRequiredBars(params)
        bars = self.dataService.getBars(numBars)
        
        # Load the bars into Pandas dataframe
        dates, close = CommonUtils.extractCloseSeries(bars)
        # Get supplied period
        period = params['period']
        # Call pandas_ta module to compute sma and ema
        # see https://github.com/twopirllc/pandas-ta
        smaSeries = talib.SMA(np.array(close), timeperiod=period)
        emaSeries = talib.EMA(np.array(close), timeperiod=period)
        avgSeries = (smaSeries + emaSeries) / 2
        return CommonUtils.createListOfDatedValue(dates, avgSeries)


    @staticmethod
    def calculateRequiredBars(params: Dict[str, Any]) -> int:
        """
        This indicator uses both SMA and EMA, which require at least 'period' data points.
        """
        period = params.get('period', 5)
        count = params.get(StandardParams.COUNT)

        if count is None:

            return IndicatorDataService.ALL_BARS
        return period + (count - 1)
