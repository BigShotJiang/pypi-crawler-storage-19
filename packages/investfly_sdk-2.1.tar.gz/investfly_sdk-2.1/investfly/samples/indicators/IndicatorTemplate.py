from investfly.models import *
from investfly.utils import *
from typing import Any, List, Dict

# Allowed imports for numeric analysis
import math
import statistics
import numpy as np
import talib  # type: ignore
import pandas

# Class name becomes the IndicatorId (must be globally unique)
class SMAHeikin_CHANGE_ME(Indicator):
    """SMA calculated using Heikin Ashi candles - template example."""
    
    def getIndicatorSpec(self) -> IndicatorSpec:
        """Define indicator metadata and parameters for UI display.
        
        See Indicator.getIndicatorSpec() for detailed documentation.
        """
        indicator = IndicatorSpec("[Change Me]: SMA Heikin Ashi")
        indicator.description = "[ChangeMe]: SMA based on Heikin Ashi Candles"
        indicator.valueType = IndicatorValueType.PRICE  # PRICE, NUMBER, PERCENT, RATIO, or BOOLEAN
        
        indicator.addParam("period", IndicatorParamSpec(paramType=ParamType.INTEGER, options=IndicatorParamSpec.PERIOD_VALUES))
        return indicator
        
    def computeSeries(self, params: Dict[str, Any]) -> List[DatedValue]:
        """Compute indicator series. Must return full series for charting and backtesting.
        
        Use self.dataService to access bars, quotes, financials, or news.
        Always call calculateRequiredBars() to determine minimum data needed.
        See Indicator.computeSeries() for detailed documentation.
        """
        numBars = SMAHeikin_CHANGE_ME.calculateRequiredBars(params)
        bars = self.dataService.getBars(numBars)
        
        heikinCandles = CommonUtils.toHeikinAshi(bars)
        dates, close = CommonUtils.extractCloseSeries(heikinCandles)
        sma_period = params['period']
        
        smaSeries = talib.SMA(np.array(close), timeperiod=sma_period)
        return CommonUtils.createListOfDatedValue(dates, smaSeries)

    @staticmethod
    def calculateRequiredBars(params: Dict[str, Any]) -> int:
        """Return minimum number of bars needed for accurate calculation.
        
        Formula: base_requirement + (count - 1)
        where count = params.get(StandardParams.COUNT, 1)
        """
        period = params.get("period", 5)
        count = params.get(StandardParams.COUNT)

        if count is None:

            return IndicatorDataService.ALL_BARS
        return period + (count - 1)

