"""
Hull Moving Average (HMA) Indicator

The Hull Moving Average is a type of moving average that was developed by Alan Hull
and is designed to be more responsive to current price activity while maintaining
smoothness. It reduces lag while maintaining smoothness.

Formula:
    1. Calculate WMA(period/2) of the price
2. Calculate WMA(period) of the price  
3. Calculate 2 * WMA(period/2) - WMA(period)
4. Calculate WMA(sqrt(period)) of the result from step 3

This indicator is particularly useful for:
    - Trend identification
- Entry/exit timing
- Reducing lag in moving average crossovers
"""

from investfly.models import *
from investfly.utils import *
from typing import Any, List, Dict
import math
import numpy as np
import talib  # type: ignore


class HullMovingAverage(Indicator):
    """Hull Moving Average indicator implementation.
    
    This indicator provides a fast, smooth moving average that reduces lag
    while maintaining the smoothness of traditional moving averages.
    """

    def getIndicatorSpec(self) -> IndicatorSpec:
        indicator = IndicatorSpec("Hull Moving Average")
        indicator.description = "Hull Moving Average - Fast, smooth moving average that reduces lag"
        indicator.valueType = IndicatorValueType.PRICE
        
        # Add period parameter
        indicator.addParam("period", IndicatorParamSpec(
            paramType=ParamType.INTEGER, 
            required=True, 
            defaultValue=20, 
            options=IndicatorParamSpec.PERIOD_VALUES
        ))
        
        return indicator
    def computeSeries(self, params: Dict[str, Any]) -> List[DatedValue]:
        """Compute the Hull Moving Average series."""
        numBars = HullMovingAverage.calculateRequiredBars(params)
        bars = self.dataService.getBars(numBars)
        dates, close = CommonUtils.extractCloseSeries(bars)
        period = params['period']
        
        if len(close) < period:
            return []
        
        # Convert to numpy array
        close_array = np.array(close)
        
        # Calculate HMA using the formula
        hma_series = self._calculate_hma(close_array, period)
        
        # Convert to DatedValue list
        return CommonUtils.createListOfDatedValue(dates, hma_series)

    @staticmethod
    def calculateRequiredBars(params: Dict[str, Any]) -> int:
        """
        HMA uses WMA calculations with period, period/2, and sqrt(period). Needs at least 'period' bars.
        """
        period = params.get('period', 14)
        count = params.get('count')

        if count is None:

            return IndicatorDataService.ALL_BARS
        return period + (count - 1)

    def _calculate_hma(self, prices: np.ndarray, period: int) -> np.ndarray:
        # Step 1: Calculate WMA(period/2)
        half_period = max(1, period // 2)
        wma_half = talib.WMA(prices, timeperiod=half_period)
        
        # Step 2: Calculate WMA(period)
        wma_full = talib.WMA(prices, timeperiod=period)
        
        # Step 3: Calculate 2 * WMA(period/2) - WMA(period)
        raw_hma = 2 * wma_half - wma_full
        
        # Step 4: Calculate WMA(sqrt(period)) of the result
        sqrt_period = max(1, int(math.sqrt(period)))
        hma = talib.WMA(raw_hma, timeperiod=sqrt_period)
        
        return hma
