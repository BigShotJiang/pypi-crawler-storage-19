from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any


class SecurityType(str, Enum):
    """
    Enum representing Security Type (STOCK, ETF, CRYPTO, FOREX, OPTION)
    """

    STOCK = "STOCK"
    ETF = "ETF"
    CRYPTO = "CRYPTO"
    FOREX = "FOREX"
    OPTION = "OPTION"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


@dataclass(frozen=True, eq=True)
class Security:
    """
    Class representing a security instrument that is traded in the market
    """

    symbol: str
    """ Security Symbol """

    securityType: SecurityType
    """ Security Type """

    @staticmethod
    def createStock(symbol: str):
        return Security(symbol, SecurityType.STOCK)

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> Security:
        return Security(jsonDict["symbol"], SecurityType[jsonDict["securityType"]])

    def toDict(self) -> Dict[str, Any]:
        return self.__dict__.copy()

