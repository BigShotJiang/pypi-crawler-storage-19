from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from investfly.models.marketdata.Security import Security
from investfly.models.portfolio.TradeEnums import TradeType
from investfly.models.common.ModelUtils import ModelUtils
from typing import Dict, Any


@dataclass
class CompletedTrade:
    security: Security
    date: datetime
    price: float
    quantity: float
    tradeType: TradeType

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> CompletedTrade:
        security = Security.fromDict(jsonDict["security"])
        date = ModelUtils.parseZonedDatetime(jsonDict["date"])
        return CompletedTrade(security, date, jsonDict["price"], jsonDict["quantity"], TradeType[jsonDict["tradeType"]])

