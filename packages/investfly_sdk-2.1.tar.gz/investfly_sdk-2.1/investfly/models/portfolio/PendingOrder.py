from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Any, cast

from investfly.models.portfolio.TradeOrder import TradeOrder
from investfly.models.marketdata.Security import Security
from investfly.models.portfolio.TradeEnums import TradeType
from investfly.models.common.ModelUtils import ModelUtils


@dataclass
class PendingOrder(TradeOrder):
    orderId: str | None = None
    status: str | None = None
    scheduledDate: datetime | None = None

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> Any:
        security = Security.fromDict(jsonDict["security"])
        pendingOrder = PendingOrder(security, TradeType(jsonDict["tradeType"]))
        pendingOrder.quantity = jsonDict.get("quantity")
        pendingOrder.maxAmount = jsonDict.get("maxAmount")
        pendingOrder.orderId = jsonDict.get("orderId")
        pendingOrder.status = jsonDict.get("status")
        pendingOrder.scheduledDate = ModelUtils.parseZonedDatetime(cast(str, jsonDict.get("scheduledDate")))
        return pendingOrder

