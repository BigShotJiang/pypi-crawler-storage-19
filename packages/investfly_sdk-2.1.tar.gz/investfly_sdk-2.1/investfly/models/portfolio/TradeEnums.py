from enum import Enum


class PositionType(str, Enum):
    """ PositionType Enum """

    LONG = "LONG",
    SHORT = "SHORT"
    CLOSE = "CLOSE"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


class TradeType(str, Enum):
    """Trade Type Enum """

    BUY = "BUY"
    SELL = "SELL"
    SHORT = "SHORT"
    COVER = "COVER"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


class OrderType(str, Enum):
    """Order Type Enum """

    MARKET_ORDER = "MARKET_ORDER"
    LIMIT_ORDER = "LIMIT_ORDER"
    STOP_ORDER = "STOP_ORDER"
    ONE_CANCEL_OTHER = "ONE_CANCEL_OTHER"
    CUSTOM_CONDITION = "CUSTOM_CONDITION"

