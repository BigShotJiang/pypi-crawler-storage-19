from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any

from investfly.models.marketdata.Security import Security
from investfly.models.portfolio.TradeEnums import TradeType, OrderType


@dataclass
class TradeOrder:
    """ A class that represents a Trade Order """
    security: Security
    tradeType: TradeType
    orderType: OrderType = OrderType.MARKET_ORDER
    quantity: float | None = None
    maxAmount: float | None = None
    limitPrice: float | None = None  # If left empty, will use latest quote as limit price

    def toDict(self) -> Dict[str, Any]:
        jsonDict = self.__dict__.copy()
        jsonDict["security"] = self.security.toDict()
        return jsonDict

    def validate(self) -> None:
        """Validate that required fields are provided"""
        if self.security is None:
            raise Exception("TradeOrder.security is required")
        if self.tradeType is None:
            raise Exception("TradeOrder.tradeType is required")


@dataclass
class OrderStatus:
    """ Trade Order Status"""
    orderId: int
    status: str
    message: str | None = None

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> OrderStatus:
        status = OrderStatus(jsonDict["orderId"], jsonDict["status"])
        status.message = jsonDict.get("message")
        return status

