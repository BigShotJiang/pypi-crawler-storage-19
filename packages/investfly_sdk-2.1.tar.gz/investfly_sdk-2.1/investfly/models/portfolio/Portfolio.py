from __future__ import annotations

from typing import List, Dict, Tuple

from investfly.models.marketdata.Security import Security
from investfly.models.portfolio.Broker import Broker
from investfly.models.portfolio.Balances import Balances
from investfly.models.portfolio.Position import OpenPosition
from investfly.models.portfolio.PendingOrder import PendingOrder
from investfly.models.portfolio.CompletedTrade import CompletedTrade
from investfly.models.portfolio.TradeEnums import PositionType


class Portfolio:
    def __init__(self, portfolioId: str, broker: Broker, balances: Balances) -> None:
        self.portfolioId = portfolioId
        self.broker = broker
        self.balances: Balances = balances
        self.openPositions: List[OpenPosition] = []
        self.pendingOrders: List[PendingOrder] = []
        self.completedTrades: List[CompletedTrade] = []
        self._positionCache: Dict[Tuple[Security, PositionType], OpenPosition] = {}

    def findPosition(self, security: Security, positionType: PositionType) -> OpenPosition | None:
        # Populate cache on first call if empty
        if not self._positionCache:
            for position in self.openPositions:
                key = (position.security, position.position)
                self._positionCache[key] = position
        
        # Lookup in cache
        key = (security, positionType)
        return self._positionCache.get(key)

    def __str__(self) -> str:
        json_dict = self.__dict__.copy()
        json_dict["openPositions"] = len(self.openPositions)
        json_dict["completedTrades"] = len(self.completedTrades)
        json_dict["pendingOrders"] = len(self.pendingOrders)
        return str(json_dict)

    def __repr__(self):
        return self.__str__()

