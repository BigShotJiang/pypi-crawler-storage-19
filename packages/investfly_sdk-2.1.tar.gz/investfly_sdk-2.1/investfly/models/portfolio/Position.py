from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Any

from investfly.models.marketdata.Security import Security
from investfly.models.portfolio.TradeEnums import PositionType
from investfly.models.common.ModelUtils import ModelUtils


@dataclass
class OpenPosition:
    security: Security
    position: PositionType
    avgPrice: float
    quantity: float
    purchaseDate: datetime
    currentPrice: float | None = None
    currentValue: float | None = None
    profitLoss: float | None = None
    percentChange: float | None = None

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> OpenPosition:
        security = Security.fromDict(jsonDict["security"])
        openPos = OpenPosition(security,
                               PositionType(jsonDict["position"]),
                               jsonDict["avgPrice"],
                               jsonDict["quantity"],
                               ModelUtils.parseZonedDatetime(jsonDict["purchaseDate"])
                               )
        openPos.currentPrice = jsonDict.get("currentPrice")
        openPos.currentValue = jsonDict.get("currentValue")
        openPos.profitLoss = jsonDict.get("profitLoss")
        openPos.percentChange = jsonDict.get("percentChange")
        return openPos

    def toDict(self) -> Dict[str, Any]:
        jsonDict = self.__dict__.copy()
        jsonDict["security"] = self.security.toDict()
        jsonDict["purchaseDate"] = ModelUtils.formatZonedDatetime(self.purchaseDate)
        return jsonDict


@dataclass
class ClosedPosition:
    security: Security
    position: PositionType
    openDate: datetime
    closeDate: datetime
    openPrice: float
    closePrice: float
    quantity: float
    profitLoss: float | None = None
    percentChange: float | None = None

    @staticmethod
    def fromDict(jsonDict: Dict[str, Any]) -> ClosedPosition:
        security = Security.fromDict(jsonDict['security'])
        position = PositionType[jsonDict['position']]
        openDate = ModelUtils.parseZonedDatetime(jsonDict['openDate'])
        closeDate = ModelUtils.parseZonedDatetime((jsonDict['closeDate']))
        openPrice = jsonDict['openPrice']
        closePrice = jsonDict['closePrice']
        quantity = jsonDict['quantity']

        closedPosition = ClosedPosition(security, position, openDate, closeDate, openPrice, closePrice, quantity)
        if "profitLoss" in jsonDict:
            closedPosition.profitLoss = jsonDict['profitLoss']
        if "percentChange" in jsonDict:
            closedPosition.percentChange = jsonDict['percentChange']

        return closedPosition

    def toDict(self) -> Dict[str, Any]:
        jsonDict = self.__dict__.copy()
        jsonDict["security"] = self.security.toDict()
        jsonDict["position"] = self.position.value
        jsonDict["openDate"] = ModelUtils.formatZonedDatetime(self.openDate)
        jsonDict["closeDate"] = ModelUtils.formatZonedDatetime((self.closeDate))
        return jsonDict

