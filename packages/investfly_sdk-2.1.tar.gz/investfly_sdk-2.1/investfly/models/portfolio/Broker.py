from enum import Enum


class Broker(str, Enum):

    """Broker Type Enum"""

    TRADIER = "TRADIER"
    INVESTFLY = "INVESTFLY"
    TASTYTRADE = "TASTYTRADE"
    ALPACA = "ALPACA"
    BACKTEST = "BACKTEST"
    OANDA = "OANDA"
    COINBASE = "COINBASE"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value

