from __future__ import annotations

from typing import List, Dict, Any

from investfly.models.marketdata.Bar import BarInterval
from investfly.models.strategy.DataParams import DataParam, DataType, ConstUnit
from investfly.models.marketdata.QuoteField import QuoteField
from investfly.models.marketdata.FinancialData import FinancialField
from investfly.models.strategy.SecurityUniverseSelector import ComparisonOperator
from investfly.models.indicator.IndicatorEnums import StandardParams


class SecurityFilterExpression:
    def __init__(self, expression: str = "") -> None:
        self.dataParams: Dict[str, DataParam] = {}
        self.filterGroups: List[Dict[str, Any]] = []

    def addDataParam(self, key: str, dataParam: DataParam) -> None:
        self.dataParams[key] = dataParam

    @staticmethod
    def createSimpleExpression(leftCondition: str, op: ComparisonOperator, rightCondition: str) -> 'SecurityFilterExpression':
        operator_name = op.name
        
        filter_condition = {
            "leftCondition": [leftCondition],
            "operator": operator_name,
            "rightCondition": [rightCondition]
        }
        
        filter_group = {
            "filterConditions": [filter_condition]
        }
        
        expr = SecurityFilterExpression()
        expr.filterGroups = [filter_group]
        return expr

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> 'SecurityFilterExpression':
        filtergroups: List[Dict[str, Any]] = json_dict['filterGroups']

        securityFilterExpression = SecurityFilterExpression()
        securityFilterExpression.filterGroups = filtergroups

        jsonDataParams: Dict[str, Dict[str, Any]] = json_dict['dataParams']
        for dataParamKey in jsonDataParams.keys():
            jsonDataParamDict = jsonDataParams[dataParamKey]
            dataParam: DataParam = DataParam.fromDict(jsonDataParamDict)
            securityFilterExpression.addDataParam(dataParamKey, dataParam)

        return securityFilterExpression

    @staticmethod
    def filterGroupToString(fg: Dict[str, Any]):
        filterConditions: List[Dict[str, Any]] = fg["filterConditions"]
        expr = ""
        if len(filterConditions) == 0:
            return expr
        if len(filterConditions) > 1:
            expr = expr + "("
        for fc in filterConditions:
            expr = expr + SecurityFilterExpression.filterConditionToString(fc)
            expr = expr + " or "
        expr = expr[:len(expr)-4]
        if len(filterConditions) > 1:
            expr = expr + ")"
        return expr


    @staticmethod
    def filterConditionToString(fc: Dict[str, Any]) -> str:
        fcExpr = "( "
        leftCondition: List[str] = fc['leftCondition']
        fcExpr = fcExpr+" ".join(leftCondition)
        operator = SecurityFilterExpression.__getOperatorValue(fc['operator'])
        fcExpr += " " + operator + " "
        rightCondition: List[str] = fc['rightCondition']
        fcExpr += " ".join(rightCondition) + " )"
        return fcExpr

    @staticmethod
    def __getOperatorValue(operator: str) -> str:
        if operator == "GREATER_THAN":
            return ">"
        elif operator == "LESS_THAN":
            return "<"
        elif operator == "GREATER_OR_EQUAL":
            return ">="
        elif operator == "LESS_OR_EQUAL":
            return "<="
        elif operator == "EQUAL_TO":
            return "=="
        else:
            raise Exception("Unsupported operator " + operator)

    def __str__(self) -> str:
        return self.__repr__()
    
    def __repr__(self) -> str:
        expr_str = self.toExpressionString() if len(self.filterGroups) > 0 else ""
        return f"SecurityFilterExpression(expression={expr_str!r}, dataParams={self.dataParams!r})"



    def toDict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            'dataParams': {k: v for k, v in self.dataParams.items()}
        }
        if hasattr(self, 'filterGroups') and len(self.filterGroups) > 0:
            result['filterGroups'] = self.filterGroups
            result['expression'] = self.toExpressionString()
        return result

    def validate(self) -> None:
        if not hasattr(self, 'filterGroups') or len(self.filterGroups) == 0:
            raise Exception("SecurityFilterExpression must have at least one filterGroup")
        for dataParam in self.dataParams.values():
            dataParam.validate()
    
    def toExpressionString(self) -> str:
        if not hasattr(self, 'filterGroups') or len(self.filterGroups) == 0:
            return ""
        return self._buildExpressionFromFilterGroups(self.filterGroups)
    
    def toMySQLExpression(self) -> str:
        expression = self.toExpressionString()
        expression = expression.replace("&&", "AND")
        expression = expression.replace("||", "OR")
        expression = expression.replace("==", "=")
        return expression
    
    def toEvalExpression(self) -> str:
        expression = self.toExpressionString()
        expression = expression.replace("&&", "and")
        expression = expression.replace("||", "or")
        return expression

    def _analyzeFilterConditionDataTypes(self, filterCondition: Dict[str, Any]) -> tuple[bool, bool, bool]:
        """
        Analyze data types in a filter condition.
        Returns: (containsOnlyQuotesAndConst, containsOnlyFinancialsAndConst, containsOnlyIndicatorsAndConst)
        """
        containsOnlyQuotesAndConst = True
        containsOnlyFinancialsAndConst = True
        containsOnlyIndicatorsAndConst = True
        
        containsQuotes = False
        containsFinancials = False
        containsIndicators = False
        
        leftCondition: List[str] = filterCondition.get('leftCondition', [])
        rightCondition: List[str] = filterCondition.get('rightCondition', [])
        allItems = leftCondition + rightCondition
        
        for exprItem in allItems:
            dataParam = self.dataParams.get(exprItem)
            if dataParam is not None:
                dataType = dataParam.getDataType()
                if dataType == DataType.QUOTE:
                    containsQuotes = True
                    containsOnlyIndicatorsAndConst = False
                    containsOnlyFinancialsAndConst = False
                elif dataType == DataType.FINANCIAL:
                    containsFinancials = True
                    containsOnlyQuotesAndConst = False
                    containsOnlyIndicatorsAndConst = False
                elif dataType == DataType.INDICATOR:
                    containsIndicators = True
                    containsOnlyQuotesAndConst = False
                    containsOnlyFinancialsAndConst = False
        
        return (
            containsOnlyQuotesAndConst and containsQuotes,
            containsOnlyFinancialsAndConst and containsFinancials,
            containsOnlyIndicatorsAndConst and containsIndicators
        )

    def _analyzeFilterGroupDataTypes(self, filterGroup: Dict[str, Any]) -> tuple[bool, bool, bool]:
        """
        Analyze data types in a filter group.
        Returns: (onlyQuotes, onlyFinancials, onlyIndicators)
        """
        onlyQuotes = True
        onlyFinancials = True
        onlyIndicators = True
        
        filterConditions: List[Dict[str, Any]] = filterGroup.get('filterConditions', [])
        for fc in filterConditions:
            fcQuotes, fcFinancials, fcIndicators = self._analyzeFilterConditionDataTypes(fc)
            onlyQuotes = onlyQuotes and fcQuotes
            onlyFinancials = onlyFinancials and fcFinancials
            onlyIndicators = onlyIndicators and fcIndicators
        
        return onlyQuotes, onlyFinancials, onlyIndicators

    def breakByDataType(self) -> tuple['SecurityFilterExpression | None', 'SecurityFilterExpression | None', 'SecurityFilterExpression | None']:
        """
        Break the expression by data type.
        Returns: (quoteExpression, financialExpression, indicatorExpression)
        FilterGroups containing only financial fields and constants go to financialExpression.
        FilterGroups containing only quote fields and constants go to quoteExpression.
        All other FilterGroups (containing indicators) go to indicatorExpression.
        """
        # If filterGroups is not initialized, return None for all
        if not hasattr(self, 'filterGroups') or len(self.filterGroups) == 0:
            return (None, None, None)
        
        quoteExpression = SecurityFilterExpression("")
        financialExpression = SecurityFilterExpression("")
        indicatorExpression = SecurityFilterExpression("")
        
        for fg in self.filterGroups:
            onlyQuotes, onlyFinancials, onlyIndicators = self._analyzeFilterGroupDataTypes(fg)
            
            # Deep copy the filter group
            fgCopy = {
                'filterConditions': [
                    {
                        'leftCondition': fc['leftCondition'].copy(),
                        'rightCondition': fc['rightCondition'].copy(),
                        'operator': fc['operator']
                    }
                    for fc in fg.get('filterConditions', [])
                ]
            }
            
            if onlyQuotes:
                quoteExpression.filterGroups.append(fgCopy)
            elif onlyFinancials:
                financialExpression.filterGroups.append(fgCopy)
            else:
                # All other FilterGroups (containing indicators or mixed types) go to indicatorExpression
                indicatorExpression.filterGroups.append(fgCopy)
        
        # Build expressions and dataParams for each
        quoteResult: SecurityFilterExpression | None = None
        financialResult: SecurityFilterExpression | None = None
        indicatorResult: SecurityFilterExpression | None = None
        
        if len(quoteExpression.filterGroups) > 0:
            quoteExpression.dataParams = self._extractDataParams(quoteExpression.filterGroups)
            quoteResult = quoteExpression
        
        if len(financialExpression.filterGroups) > 0:
            financialExpression.dataParams = self._extractDataParams(financialExpression.filterGroups)
            financialResult = financialExpression
        
        if len(indicatorExpression.filterGroups) > 0:
            indicatorExpression.dataParams = self._extractDataParams(indicatorExpression.filterGroups)
            indicatorResult = indicatorExpression
        
        return (quoteResult, financialResult, indicatorResult)

    def _buildExpressionFromFilterGroups(self, filterGroups: List[Dict[str, Any]]) -> str:
        """Build expression string from filter groups"""
        expr = ""
        for fg in filterGroups:
            expr += SecurityFilterExpression.filterGroupToString(fg)
            expr += " and "
        if len(filterGroups) > 0:
            expr = expr[:len(expr) - 5]  # Remove trailing " and "
        return expr

    def _extractDataParams(self, filterGroups: List[Dict[str, Any]]) -> Dict[str, DataParam]:
        """Extract dataParams used in the given filter groups"""
        usedVars: set[str] = set()
        for fg in filterGroups:
            for fc in fg.get('filterConditions', []):
                usedVars.update(fc.get('leftCondition', []))
                usedVars.update(fc.get('rightCondition', []))
        
        result: Dict[str, DataParam] = {}
        for var in usedVars:
            if var in self.dataParams:
                result[var] = self.dataParams[var]
        return result

    def replaceVarInWithField(self) -> None:
        """
        Replace variable names with field names in the expression for financial and quote queries.
        This allows direct computation without variable resolution.
        """
        for fg in self.filterGroups:
            for fc in fg.get('filterConditions', []):
                fc['leftCondition'] = self._modifyExpression(fc.get('leftCondition', []))
                fc['rightCondition'] = self._modifyExpression(fc.get('rightCondition', []))

    def _modifyExpression(self, originalExpression: List[str]) -> List[str]:
        """Replace variables with field names or constant values"""
        modifiedExpression: List[str] = []
        for exprItem in originalExpression:
            dataParam = self.dataParams.get(exprItem)
            if dataParam is not None:
                dataType = dataParam.getDataType()
                if dataType == DataType.FINANCIAL:
                    financialField = dataParam.getFinancialField()
                    if financialField is not None:
                        modifiedExpression.append(financialField.name)
                    else:
                        modifiedExpression.append(exprItem)
                elif dataType == DataType.QUOTE:
                    quoteField = dataParam.getQuoteField()
                    if quoteField is not None:
                        modifiedExpression.append(quoteField.name)
                    else:
                        modifiedExpression.append(exprItem)
                elif dataType == DataType.CONST:
                    value = dataParam.getConstValue()
                    # Format to avoid scientific notation
                    if isinstance(value, float):
                        if value.is_integer():
                            modifiedExpression.append(str(int(value)))
                        else:
                            modifiedExpression.append(str(value))
                    else:
                        modifiedExpression.append(str(value))
                else:
                    modifiedExpression.append(exprItem)
            else:
                modifiedExpression.append(exprItem)
        return modifiedExpression

    def newFilterGroup(self) -> 'FilterGroupBuilder':
        filter_group: Dict[str, Any] = {"filterConditions": []}
        self.filterGroups.append(filter_group)
        return FilterGroupBuilder(filter_group, self)

    def addQuoteParam(self, quote_field: QuoteField, alias: str | None = None) -> DataParam:
        data_param = DataParam()
        data_param[DataParam.DATATYPE] = DataType.QUOTE
        data_param[StandardParams.FIELD] = quote_field
        key = alias if alias else quote_field.name
        self.dataParams[key] = data_param
        return data_param

    def addConstParam(self, value: int | float, unit: ConstUnit | None = None, alias: str | None = None) -> DataParam:
        data_param = DataParam()
        data_param[DataParam.DATATYPE] = DataType.CONST
        data_param[DataParam.VALUE] = value
        if unit is not None:
            data_param[DataParam.UNIT] = unit
        key = alias if alias else str(value) + (unit.value if unit else "")
        self.dataParams[key] = data_param
        return data_param

    def addFinancialParam(self, financial_field: FinancialField, alias: str | None = None) -> DataParam:
        data_param = DataParam()
        data_param[DataParam.DATATYPE] = DataType.FINANCIAL
        data_param[StandardParams.FIELD] = financial_field
        key = alias if alias else financial_field.name
        self.dataParams[key] = data_param
        return data_param

    def addIndicatorParam(self, indicator_id: str, bar_interval: BarInterval, alias: str | None = None, **kwargs) -> DataParam:
        data_param = DataParam()
        data_param[DataParam.DATATYPE] = DataType.INDICATOR
        data_param[DataParam.INDICATOR] = indicator_id
        data_param[StandardParams.BARINTERVAL] = bar_interval
        for key, value in kwargs.items():
            data_param[key] = value
        key = alias if alias else indicator_id
        self.dataParams[key] = data_param
        return data_param

    def addBarPriceParam(self, bar_interval: BarInterval, bar_price: str, lookback: int, alias: str | None = None) -> DataParam:
        data_param = DataParam()
        data_param[DataParam.DATATYPE] = DataType.BARS
        data_param[StandardParams.BARINTERVAL] = bar_interval
        data_param["price"] = bar_price
        data_param[StandardParams.LOOKBACK] = lookback
        key = alias if alias else f"{bar_price}_{bar_interval.name}_{lookback}"
        self.dataParams[key] = data_param
        return data_param


class FilterGroupBuilder:
    def __init__(self, filter_group: Dict[str, Any], parent: SecurityFilterExpression):
        self.filter_group = filter_group
        self.parent = parent

    def newFilterCondition(self) -> 'FilterConditionBuilder':
        filter_condition: Dict[str, Any] = {
            "leftCondition": [],
            "operator": None,
            "rightCondition": []
        }
        self.filter_group["filterConditions"].append(filter_condition)
        return FilterConditionBuilder(filter_condition, self)

    def done(self) -> SecurityFilterExpression:
        return self.parent


class FilterConditionBuilder:
    def __init__(self, filter_condition: Dict[str, Any], parent: FilterGroupBuilder):
        self.filter_condition = filter_condition
        self.parent = parent

    def addToLeftCondition(self, expr: str) -> 'FilterConditionBuilder':
        self.filter_condition["leftCondition"].append(expr)
        return self

    def addToRightCondition(self, expr: str) -> 'FilterConditionBuilder':
        self.filter_condition["rightCondition"].append(expr)
        return self

    def setOperator(self, op: ComparisonOperator) -> 'FilterConditionBuilder':
        self.filter_condition["operator"] = op.name
        return self

    def done(self) -> FilterGroupBuilder:
        return self.parent

