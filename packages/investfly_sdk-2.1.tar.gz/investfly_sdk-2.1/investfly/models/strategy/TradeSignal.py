from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any

from investfly.models.marketdata.Security import Security
from investfly.models.portfolio.TradeEnums import PositionType


@dataclass
class TradeSignal:
    security: Security
    position: PositionType
    strength: int = 1
    data: Dict[str, Any] | None = None  # Any other data besides strength that could be useful to generate TradeOrder

