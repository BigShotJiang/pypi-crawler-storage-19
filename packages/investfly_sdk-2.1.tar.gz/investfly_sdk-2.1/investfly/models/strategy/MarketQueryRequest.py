from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from enum import Enum

from investfly.models.strategy.DataParams import DataParam
from investfly.models.strategy.SecurityFilterExpression import SecurityFilterExpression


class SortOrder(str, Enum):
    ASC = "ASC"
    DSC = "DSC"


@dataclass
class SortBySpec:
    alias: str
    dataParam: DataParam
    order: SortOrder
    limit: Optional[int] = None


@dataclass
class MarketQueryRequest:
    securityFilterExpression: SecurityFilterExpression
    sortBy: Optional[SortBySpec] = None

