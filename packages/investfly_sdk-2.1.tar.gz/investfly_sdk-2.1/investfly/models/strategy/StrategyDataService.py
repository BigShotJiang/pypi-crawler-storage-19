"""Strategy data service interface.

This module defines the StrategyDataService abstract base class that provides
the interface for accessing market data, indicators, and financial information
from within trading strategies.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, Any, List

from investfly.models.marketdata.Security import Security
from investfly.models.marketdata.Bar import Bar, BarInterval
from investfly.models.marketdata.Quote import Quote
from investfly.models.marketdata.StockNews import StockNews
from investfly.models.marketdata.FinancialData import FinancialField
from investfly.models.indicator.IndicatorSeries import IndicatorSeries
from investfly.models.strategy.MarketQueryRequest import MarketQueryRequest


class StrategyDataService(ABC):
    """Interface for accessing market data and indicators from strategies.

    StrategyDataService provides indicator computation and market query capabilities
    specifically for trading strategies, as well as market data access.

    This service provides access to:
    - Technical indicators (SMA, RSI, MACD, etc.)
    - Market data (quotes, bars, financials)
    - News and fundamental data
    - Market queries (screeners)

    The service is implemented by the execution engine and injected into
    strategy instances via `TradingStrategy.setDataService()`.

    Example:
        Strategies access the data service via `self.dataService`:

        ```python
        # Compute indicators
        sma = self.dataService.computeIndicatorSeries(
            "SMA", security, {"period": 20, "barInterval": BarInterval.ONE_DAY}
        )

        # Get current quote
        quote = self.dataService.getQuote(security)
        if quote:
            current_price = quote.lastPrice

        # Get historical bars
        bars = self.dataService.getBars(
            security, BarInterval.ONE_DAY, numBars=50
        )
        ```
    """
    
    # Market data access methods (same as MarketDataProvider)
    ALL_BARS: int = -1
    """Constant for retrieving all available bars."""

    @abstractmethod
    def getBars(self, security: Security, barInterval: BarInterval, numBars: int) -> List[Bar]:
        """Retrieve historical bars for a security.
        
        Args:
            security: The Security object for which to fetch bars.
            barInterval: The interval of bars to retrieve (e.g., ONE_MINUTE, ONE_DAY).
            numBars: Number of bars to return. Use StrategyDataService.ALL_BARS 
                to retrieve all available bars.
        
        Returns:
            List of Bar objects containing OHLC data in chronological order (oldest first).
        
        Raises:
            NoDataException: If the requested data is not available.
        """
        pass

    @abstractmethod
    def getFinancials(self, symbol: str) -> Dict[FinancialField, float]:
        """Retrieve fundamental financial metrics for the given symbol.
        
        Args:
            symbol: The stock symbol (e.g., "AAPL", "MSFT").
        
        Returns:
            Dictionary mapping FinancialField enums to their corresponding values.
        """
        pass

    @abstractmethod
    def getQuote(self, security: Security) -> Quote:
        """Retrieve the latest quote for the given security.
        
        Args:
            security: The Security object for which to retrieve the quote.
        
        Returns:
            Quote object containing the latest market data.
        """
        pass

    @abstractmethod
    def getNews(self, security: Security) -> List[StockNews]:
        """Retrieve latest news articles for the given security.
        
        Args:
            security: The Security object for which to retrieve news.
        
        Returns:
            List of StockNews objects containing news articles.
        """
        pass

    @abstractmethod
    def computeIndicatorSeries(self, indicatorId: str, security: Security, params: Dict[str, Any]) -> IndicatorSeries:
        """Compute a technical indicator series for a given security.

        This method computes a technical indicator (e.g., SMA, RSI, MACD) and
        returns a series of indicator values over time. The series can be used
        for analysis, signal generation, and crossover detection.

        The `indicatorId` parameter is declared as a string (not an enum) to
        support both standard indicators provided by Investfly and custom
        indicators defined by users. For standard indicators, the string value
        must match one of the values from the `StandardIndicatorId` enum.

        Args:
            indicatorId: The identifier of the indicator to compute. Must be a
                string value. For standard indicators supported by Investfly,
                use one of the values from `StandardIndicatorId` enum:
                
                **Moving Averages:**
                - "SMA": Simple Moving Average
                - "EMA": Exponential Moving Average
                
                **Momentum Indicators:**
                - "RSI": Relative Strength Index
                - "ROC": Rate of Change
                - "CMO": Chande Momentum Oscillator
                - "CMO_SMOOTHED": Smoothed CMO
                - "PPO": Percentage Price Oscillator
                - "ULTIMATE_OSC": Ultimate Oscillator
                
                **Trend Indicators:**
                - "MACD": Moving Average Convergence Divergence
                - "MACDS": MACD Signal Line
                - "ADX": Average Directional Index
                - "PLUS_DI": Plus Directional Indicator
                - "MINUS_DI": Minus Directional Indicator
                - "PSAR": Parabolic SAR
                
                **Volatility Indicators:**
                - "ATR": Average True Range
                - "STD_DEV": Standard Deviation
                - "UPPER_BBAND": Upper Bollinger Band
                - "LOWER_BBAND": Lower Bollinger Band
                - "BBAND": Bollinger Bands (composite, for charts only)
                
                **Oscillators:**
                - "CCI": Commodity Channel Index
                - "WILLIAM_R": Williams' %R
                - "FAST_STOCHASTIC_OSC": Fast Stochastic Oscillator
                - "SLOW_STOCHASTIC_OSC": Slow Stochastic Oscillator
                - "STOCHASTICS": Stochastic (composite, for charts only)
                
                **Price Indicators:**
                - "MEDIAN_PRICE": Median Price
                - "TYPICAL_PRICE": Typical Price
                - "MAX": Maximum value over period
                - "MIN": Minimum value over period
                
                **Candlestick Patterns:**
                - "DOJI": Doji pattern
                - "HAMMER": Hammer pattern
                - "INVERTED_HAMMER": Inverted Hammer pattern
                - "DRAGONFLY_DOJI": Dragonfly Doji pattern
                - "GRAVESTONE_DOJI": Gravestone Doji pattern
                - "HANGING_MAN": Hanging Man pattern
                - "BULLISH": Bullish pattern
                - "BEARISH": Bearish pattern
                
                **Support/Resistance:**
                - "SUPPORT": Support level
                - "RESISTANCE": Resistance level
                
                **Other:**
                - "AVGVOLUME": Average Volume
                - "HIGH52WEEK": 52-Week High
                - "LOW52WEEK": 52-Week Low
                - "DRAWDOWN": Drawdown
                - "PRICECHANGEPCT": Price Change Percentage
                
                For custom indicators, use the custom indicator ID string as
                defined when the indicator was created.
                
            security: The security for which to compute the indicator.
            params: Dictionary of parameters for the indicator computation.
                Common parameters include:
                - "period" (int): Period for the indicator (e.g., 20 for SMA(20)).
                - "barInterval" (BarInterval): Bar interval for the data source.
                - Indicator-specific parameters (e.g., "fast_period", "slow_period"
                  for MACD).

        Returns:
            IndicatorSeries object containing the computed indicator values.
            The series provides methods for:
            - Accessing the latest value: `series.last.value`
            - Converting to list: `series.toList()`
            - Crossover detection: `series.cross_over(other)`, `series.cross_under(other)`

        Note:
            - The `indicatorId` parameter is a string type (not `StandardIndicatorId`
              enum) to support both standard and custom indicators.
            - When using standard indicators, the string value must exactly match
              one of the `StandardIndicatorId` enum values (see
              `investfly.models.indicator.IndicatorEnums.StandardIndicatorId`).
            - Custom indicators can be referenced by their custom ID string.

        Example:
            ```python
            # Compute 20-period SMA on daily bars (standard indicator)
            sma20 = self.dataService.computeIndicatorSeries(
                "SMA",  # Must match StandardIndicatorId.SMA.value
                security,
                {"period": 20, "barInterval": BarInterval.ONE_DAY}
            )

            # Compute 14-period RSI (standard indicator)
            rsi = self.dataService.computeIndicatorSeries(
                "RSI",  # Must match StandardIndicatorId.RSI.value
                security,
                {"period": 14, "barInterval": BarInterval.ONE_DAY}
            )

            # Compute custom indicator
            custom_indicator = self.dataService.computeIndicatorSeries(
                "MY_CUSTOM_INDICATOR",  # Custom indicator ID
                security,
                {"param1": 10, "barInterval": BarInterval.ONE_DAY}
            )

            # Check for crossover
            if sma20.cross_over(rsi):
                # SMA crossed above RSI - bullish signal
                pass

            # Access latest value
            current_rsi = rsi.last.value
            ```
        """
        pass

    @abstractmethod
    def runMarketQuery(self, request: MarketQueryRequest) -> List[Security]:
        """Run a market query using a market query request.

        This method executes a screener query to find securities that match
        the given filter expression. The query is executed against the universe
        of securities available to this strategy.

        Args:
            request: MarketQueryRequest containing:
                - securityFilterExpression: SecurityFilterExpression with filter criteria.
                    The expression can include filters on:
                    - Quote fields (price, volume, etc.)
                    - Financial data (market cap, P/E ratio, etc.)
                    - Technical indicators (SMA, RSI, etc.)
                - sortBy: Optional SortBySpec for sorting and limiting results.

        Returns:
            List of Security objects that match the filter criteria.
            Returns an empty list if no securities match.

        Example:
            ```python
            from investfly.models.strategy.SecurityFilterExpression import SecurityFilterExpression
            from investfly.models.strategy.MarketQueryRequest import MarketQueryRequest
            from investfly.models.strategy.DataParams import DataParam, DataType
            from investfly.models.marketdata.QuoteField import QuoteField

            # Create a filter expression: price > 100
            filter_expr = SecurityFilterExpression("price > 100")
            price_param = DataParam(DataType.QUOTE, quoteField=QuoteField.LAST_PRICE)
            filter_expr.addDataParam("price", price_param)

            # Create market query request
            query_request = MarketQueryRequest(securityFilterExpression=filter_expr)

            # Run the query
            matching_securities = self.dataService.runMarketQuery(query_request)
            for security in matching_securities:
                print(f"Found: {security.symbol}")
            ```
        """
        pass

