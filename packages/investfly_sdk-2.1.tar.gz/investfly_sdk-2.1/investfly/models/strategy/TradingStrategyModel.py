from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any


class StandardOrCustom(str, Enum):
    STANDARD = "STANDARD"
    CUSTOM = "CUSTOM"


@dataclass
class TradingStrategyModel:
    strategyName: str
    strategyId: int | None = None
    pythonCode: str | None = None
    strategyDesc: str | None = None

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> TradingStrategyModel:
        strategyId = json_dict['strategyId']
        strategyName = json_dict['strategyName']
        pythonCode = json_dict['pythonCode']
        strategyDesc = json_dict.get('strategyDesc')
        return TradingStrategyModel(strategyId=strategyId, strategyName=strategyName, pythonCode=pythonCode, strategyDesc=strategyDesc)

    def toDict(self) -> Dict[str, Any]:
        dict = self.__dict__.copy()
        return dict

