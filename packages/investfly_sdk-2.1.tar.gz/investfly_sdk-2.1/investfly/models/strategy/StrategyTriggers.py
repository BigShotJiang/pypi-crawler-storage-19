from __future__ import annotations

from enum import Enum
from typing import Dict, Any, Optional, TypedDict

from investfly.models.marketdata.Bar import BarInterval
from investfly.models.strategy.DataParams import DataType, DataParam


class ScheduleInterval(str, Enum):
    """Enum for scheduled time-based triggers"""
    MINUTE = "MINUTE"
    FIVE_MINUTE = "FIVE_MINUTE"
    FIFTEEN_MINUTE = "FIFTEEN_MINUTE"
    THIRTY_MINUTE = "THIRTY_MINUTE"
    HOUR = "HOUR"
    DAY = "DAY"
    WEEK = "WEEK"
    MONTH = "MONTH"

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value

    def toMinutes(self) -> int:
        """Convert ScheduleInterval to minutes for comparison purposes."""
        if self == ScheduleInterval.MINUTE:
            return 1
        elif self == ScheduleInterval.FIVE_MINUTE:
            return 5
        elif self == ScheduleInterval.FIFTEEN_MINUTE:
            return 15
        elif self == ScheduleInterval.THIRTY_MINUTE:
            return 30
        elif self == ScheduleInterval.HOUR:
            return 60
        elif self == ScheduleInterval.DAY:
            return 24 * 60  # 1440 minutes
        elif self == ScheduleInterval.WEEK:
            return 7 * 24 * 60  # 10080 minutes
        elif self == ScheduleInterval.MONTH:
            return 30 * 24 * 60  # 43200 minutes (approximate)
        else:
            raise Exception(f"Unsupported ScheduleInterval: {self}")


class DataTriggerInfo(TypedDict):
    """Type definition for data trigger information"""
    type: DataType
    barinterval: Optional[BarInterval]


class TimeTriggerInfo(TypedDict):
    """Type definition for time trigger information"""
    interval: ScheduleInterval
    hourOfDay: Optional[int]  # For DAY, WEEK, MONTH intervals (0-23)
    dayOfWeek: Optional[int]   # For WEEK interval (0=Monday, 6=Sunday)
    dayOfMonth: Optional[int]  # For MONTH interval (1-31)


def data_trigger(type: DataType, barInterval: Optional[BarInterval] = None):
    """
    Decorator to mark a method to run on market data events.
    
    Returns a tuple (wrapper_func, trigger_info).

    Parameters:
        type (DataType): BARS, or other DataType
        barInterval (BarInterval, optional): Interval for BARS events

    Usage:
        @data_trigger(type=DataType.BARS, barInterval=BarInterval.ONE_MINUTE)
        def onMarketData(self):
            ...
    """
    def decorator_func(func):
        def wrapper_func(*args, **kwargs):
            return func(*args, **kwargs)
        
        trigger_info: DataTriggerInfo = {
            "type": type,
            "barinterval": barInterval
        }
        return wrapper_func, trigger_info
    
    return decorator_func


def time_trigger(interval: ScheduleInterval, hourOfDay: Optional[int] = None, dayOfWeek: Optional[int] = None, dayOfMonth: Optional[int] = None):
    """
    Decorator to mark a method to run on scheduled events.
    
    Returns a tuple (wrapper_func, trigger_info).

    Parameters:
        interval (ScheduleInterval): MINUTE, FIVE_MINUTE, FIFTEEN_MINUTE, THIRTY_MINUTE, HOUR, DAY, WEEK, MONTH
        hourOfDay (int, optional): Hour of day in 24-hour format (0-23).
            Applicable for DAY, WEEK, and MONTH intervals.
        dayOfWeek (int, optional): Day of week (0=Monday, 6=Sunday).
            Only applicable for WEEK interval.
        dayOfMonth (int, optional): Day of month (1-31).
            Only applicable for MONTH interval.

    Usage:
        @time_trigger(interval=ScheduleInterval.DAY, hourOfDay=22)
        @time_trigger(interval=ScheduleInterval.WEEK, dayOfWeek=5, hourOfDay=21)  # Saturday at 9 PM
        @time_trigger(interval=ScheduleInterval.MONTH, dayOfMonth=1, hourOfDay=21)  # 1st of month at 9 PM
        def onSchedule(self):
            ...
    """
    def decorator_func(func):
        def wrapper_func(*args, **kwargs):
            return func(*args, **kwargs)
        
        trigger_info: TimeTriggerInfo = {
            "interval": interval,
            "hourOfDay": hourOfDay,
            "dayOfWeek": dayOfWeek,
            "dayOfMonth": dayOfMonth
        }
        return wrapper_func, trigger_info
    
    return decorator_func

