from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Dict, Any

from investfly.models.common.ModelUtils import ModelUtils


class LogLevel(str, Enum):
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"


@dataclass
class DeploymentLog:
    date: datetime
    level: LogLevel
    message: str

    @staticmethod
    def info(message: str) -> DeploymentLog:
        return DeploymentLog(datetime.now(), LogLevel.INFO, message)

    @staticmethod
    def warn(message: str) -> DeploymentLog:
        return DeploymentLog(datetime.now(), LogLevel.WARN, message)

    @staticmethod
    def error(message: str) -> DeploymentLog:
        return DeploymentLog(datetime.now(), LogLevel.ERROR, message)

    def toDict(self) -> Dict[str, Any]:
        dict = self.__dict__.copy()
        dict['date'] = ModelUtils.formatDatetime(self.date)
        return dict

    @staticmethod
    def fromDict(json_dict: Dict[str, Any]) -> DeploymentLog:
        return DeploymentLog(ModelUtils.parseDatetime(json_dict['date']), LogLevel(json_dict['level']), json_dict['message'])

