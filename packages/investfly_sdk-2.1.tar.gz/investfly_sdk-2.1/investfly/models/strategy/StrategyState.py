from __future__ import annotations

from typing import Union, List, Dict

# Primitive types allowed in state
PrimitiveStateValue = Union[int, float, bool, str]

# Allowed value = primitive OR list of primitives
StateValue = Union[PrimitiveStateValue, List[PrimitiveStateValue]]

# The full strategy state structure
StrategyState = Dict[str, StateValue]

