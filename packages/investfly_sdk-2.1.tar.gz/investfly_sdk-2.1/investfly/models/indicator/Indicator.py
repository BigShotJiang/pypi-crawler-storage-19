from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List, TYPE_CHECKING

from investfly.models.common.DatedValue import DatedValue
from investfly.models.indicator.IndicatorDataService import IndicatorDataService
from investfly.models.marketdata.Bar import BarInterval
from investfly.models.indicator.IndicatorSpec import IndicatorSpec
from investfly.models.indicator.IndicatorParamSpec import IndicatorParamSpec
from investfly.models.indicator.IndicatorEnums import ParamType, IndicatorValueType, StandardParams




class Indicator(ABC):
    """
    The primary class to implement a custom Indicator. A Custom Indicator is like standard indicator (e.g SMA, RSI)
    and can be used in any place that standard indicator can be used (e.g screener, charts, strategy etc)
    Investfly comes with a set of standard indicators. If you find that the indicator you want is not supported
    or you can a small variation (e.g SMA but with using Heikin Ashi Candles), then you can use this function
    
    Indicators receive market data through an IndicatorDataService injected via setDataService(). This service
    abstracts away the security context, allowing indicators to be pure mathematical functions.
    """
    
    def __init__(self) -> None:
        """Initialize the indicator.
        
        The data service will be set via setDataService() after instantiation.
        """
        self.dataService: IndicatorDataService
    
    def setDataService(self, dataService: IndicatorDataService) -> None:
        """Set the data service for this indicator.
        
        This method is called by IndicatorService after instantiating the indicator.
        
        Args:
            dataService: The data service for accessing bars, quotes, financials, and news
                for a specific security.
        """
        self.dataService = dataService

    @abstractmethod
    def getIndicatorSpec(self) -> IndicatorSpec:
        """Return IndicatorSpec with name, description, required params, and valuetype.
        
        See IndicatorSpec abstract class for more details.
        
        Returns:
            `IndicatorSpec`: The indicator specification object.
        """

        pass

    @abstractmethod
    def computeSeries(self, params: Dict[str, Any]) -> List[DatedValue]:
        """Compute indicator series based on provided parameters.
        
        This function must return List of indicator values instead of only the most recent single value because indicator
        series is required to plot in the price chart and also to use in backtest.
        
        The indicator should use `self.dataService` to retrieve the data it needs (bars, quotes, financials, news).
        The timestamps in the `DatedValue` must correspond to timestamps in the retrieved data.

        Args:
            params: User supplied indicator parameter values. The keys match the keys from `IndicatorSpec.params`.
        
        Note:
            The `params[StandardParams.COUNT]` parameter specifies how many indicator values the function should return in the list.
            - If COUNT is NOT specified: Compute and return the FULL series based on all available data.
            - If COUNT is specified: Return only the last COUNT values.
            
            For optimal performance, use COUNT to only request the minimum necessary amount of historical data.
            For example: to compute a 20-period SMA and return a single most recent value (`count=1`), you should request 20 bars. 
            If `count=2`, you should request 21 bars; in general, for SMA, the number of bars needed is `period + count - 1`.
            If COUNT is not specified, request ALL_BARS to compute the full series.
            
        Returns:
            List of `DatedValue` representing indicator values for each time unit.
        """

        pass

    def computeCurrent(self, params: Dict[str, Any]) -> DatedValue:
        """Compute the current (most recent) indicator value.
        
        This default implementation calls computeSeries() and returns the last value.
        If computing just the current value is more performant than computing the full series,
        Indicator implementations should override this method.
        
        Args:
            params: User supplied indicator parameter values. Same as computeSeries().
            
        Returns:
            The most recent `DatedValue` from the indicator series.
            
        Raises:
            IndexError: If the indicator series is empty.
        """
        params[StandardParams.COUNT] = 1
        series = self.computeSeries(params)
        if not series:
            raise IndexError("Indicator series is empty, cannot compute current value")
        return series[-1]

    def validateParams(self, paramVals: Dict[str, Any]):
        spec: IndicatorSpec = self.getIndicatorSpec()
        for paramName, paramSpec in spec.params.items():
            paramVal: Any = paramVals.get(paramName)
            expectedParamType = paramSpec.paramType

            if paramVal is not None:
                if expectedParamType == ParamType.INTEGER and not isinstance(paramVal, int):
                    raise Exception(f"Param {paramName} must be of type int. You provided: {paramVal}")
                if expectedParamType == ParamType.FLOAT and not isinstance(paramVal, float) and isinstance(paramVal, int):
                    raise Exception(f"Param {paramName} must be of type float. You provided: {paramVal}")
                if expectedParamType == ParamType.STRING and not isinstance(paramVal, str):
                    raise Exception(f"Param {paramName} must be of type string. You provided: {paramVal}")
                if expectedParamType == ParamType.BOOLEAN and not isinstance(paramVal, bool):
                    raise Exception(f"Param {paramName} must be of type boolean. You provided: {paramVal}")
                if expectedParamType == ParamType.BOOLEAN and not isinstance(paramVal, bool):
                    raise Exception(f"Param {paramName} must be of type boolean. You provided: {paramVal}")
                if expectedParamType == ParamType.BARINTERVAL and not isinstance(paramVal, BarInterval):
                    raise Exception(f"Param {paramName} must be of type BarInterval. You provided: {paramVal}")

                if paramSpec.options is not None:
                    if paramVal not in paramSpec.options:
                        raise Exception(f"Param {paramName} provided value {paramVal} is not one of the allowed value")

    def addStandardParamsToDef(self, indicatorDef: IndicatorSpec):
        from investfly.models.indicator.IndicatorParamSpec import IndicatorParamSpec
        # Note that setting default values for optional params impact alias/key generation for indicator instances (e.g SMA_5_1MIN_1)
        # Hence, its better to leave them as None
        indicatorDef.params[StandardParams.COUNT] = IndicatorParamSpec(ParamType.INTEGER, False, None)
        indicatorDef.params[StandardParams.LOOKBACK] = IndicatorParamSpec(ParamType.INTEGER, False, None, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        indicatorDef.params[StandardParams.SECURITY] = IndicatorParamSpec(ParamType.STRING, False)
        
        # Most indicators are bar-based, so add barInterval as standard param
        # Indicators that use other data sources (quote, financial, news) can override this in their getIndicatorSpec
        indicatorDef.params[StandardParams.BARINTERVAL] = IndicatorParamSpec(ParamType.BARINTERVAL, True, BarInterval.ONE_MINUTE, [v for v in BarInterval])

