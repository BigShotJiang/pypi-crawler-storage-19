"""Indicator data service interface.

This module defines the IndicatorDataService interface that provides market data
access to indicators without requiring them to be aware of the security context.
The security context is captured when the service is instantiated.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict, List

from investfly.models.marketdata.Bar import Bar, BarInterval
from investfly.models.marketdata.Quote import Quote
from investfly.models.marketdata.StockNews import StockNews
from investfly.models.marketdata.FinancialData import FinancialField


class IndicatorDataService(ABC):
    """Interface for accessing market data in indicators.
    
    This interface provides market data access methods without requiring
    a security parameter. The security context is captured when the service
    is instantiated, allowing indicators to remain pure mathematical functions.
    
    Attributes:
        ALL_BARS: Constant value (-1) used to retrieve all available historical bars.
    """
    
    ALL_BARS: int = -1
    """Constant for retrieving all available bars."""

    @abstractmethod
    def getBars(self, numBars: int = ALL_BARS) -> List[Bar]:
        """Retrieve historical bars for the configured security.
        
        The bar interval and lookback are captured when the service is instantiated.
        If lookback > 0, the most recent 'lookback' bars are automatically excluded
        from the result, effectively shifting the time window backwards.
        
        Args:
            numBars: Number of bars to return. Use IndicatorDataService.ALL_BARS 
                to retrieve all available bars.
        
        Returns:
            List of Bar objects containing OHLC data in chronological order (oldest first).
            If lookback > 0, the result excludes the most recent 'lookback' bars.
        
        Raises:
            NoDataException: If the requested data is not available.
        """
        pass


    @abstractmethod
    def getNews(self) -> List[StockNews]:
        """Retrieve latest news articles for the configured security.
        
        This method returns recent news articles related to the configured
        security. News data can be used for sentiment analysis or event-driven
        trading strategies.
        
        Returns:
            List of StockNews objects containing news articles. Returns an
            empty list if no news is available.
        """
        pass

