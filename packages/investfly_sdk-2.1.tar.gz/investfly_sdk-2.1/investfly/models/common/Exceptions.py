from __future__ import annotations

from typing import Dict, Any


class NoDataException(Exception):
    def __init__(self, dataParams: Dict[str, Any]):
        self.dataParams = dataParams
        self.message = f"Data Not Available: {dataParams}"

    def __str__(self) -> str:
        return self.message

    def __repr__(self) -> str:
        return self.message

