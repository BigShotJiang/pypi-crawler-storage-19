import json
import logging
from typing import Iterator

# Import Deployment model when it's defined in models.py
# from ..models import Deployment
from ..exceptions import XenfraAPIError, XenfraError  # Add XenfraError
from ..utils import safe_get_json_field, safe_json_parse
from .base import BaseManager

logger = logging.getLogger(__name__)


class DeploymentsManager(BaseManager):
    def create(self, project_name: str, git_repo: str, branch: str, framework: str, region: str = None, size_slug: str = None) -> dict:
        """Creates a new deployment."""
        try:
            payload = {
                "project_name": project_name,
                "git_repo": git_repo,
                "branch": branch,
                "framework": framework,
            }
            if region:
                payload["region"] = region
            if size_slug:
                payload["size_slug"] = size_slug
            
            response = self._client._request("POST", "/deployments", json=payload)
            # Safe JSON parsing
            return safe_json_parse(response)
        except XenfraAPIError:
            raise
        except Exception as e:
            raise XenfraError(f"Failed to create deployment: {e}")

    def get_status(self, deployment_id: str) -> dict:
        """Get status for a specific deployment.

        Args:
            deployment_id: The unique identifier for the deployment.

        Returns:
            dict: Deployment status information including state, progress, etc.

        Raises:
            XenfraAPIError: If the API returns an error (e.g., 404 not found).
            XenfraError: If there's a network or parsing error.
        """
        try:
            response = self._client._request("GET", f"/deployments/{deployment_id}/status")
            logger.debug(
                f"DeploymentsManager.get_status({deployment_id}) response: {response.status_code}"
            )
            # Safe JSON parsing - _request() already handles status codes
            return safe_json_parse(response)
        except XenfraAPIError:
            raise  # Re-raise API errors
        except Exception as e:
            raise XenfraError(f"Failed to get status for deployment {deployment_id}: {e}")

    def get_logs(self, deployment_id: str) -> str:
        """Get logs for a specific deployment.

        Args:
            deployment_id: The unique identifier for the deployment.

        Returns:
            str: The deployment logs as plain text.

        Raises:
            XenfraAPIError: If the API returns an error (e.g., 404 not found).
            XenfraError: If there's a network or parsing error.
        """
        try:
            response = self._client._request("GET", f"/deployments/{deployment_id}/logs")
            logger.debug(
                f"DeploymentsManager.get_logs({deployment_id}) response: {response.status_code}"
            )

            # Safe JSON parsing with structure validation - _request() already handles status codes
            data = safe_json_parse(response)
            if not isinstance(data, dict):
                raise XenfraError(f"Expected dictionary response, got {type(data).__name__}")

            logs = safe_get_json_field(data, "logs", "")

            if not logs:
                logger.warning(f"No logs found for deployment {deployment_id}")

            return logs

        except XenfraAPIError:
            raise  # Re-raise API errors
        except Exception as e:
            raise XenfraError(f"Failed to get logs for deployment {deployment_id}: {e}")

    def create_stream(self, project_name: str, git_repo: str, branch: str, framework: str, region: str = None, size_slug: str = None) -> Iterator[dict]:
        """
        Creates a new deployment with real-time SSE log streaming.

        Yields SSE events as dictionaries with 'event' and 'data' keys.

        Args:
            project_name: Name of the project
            git_repo: Git repository URL
            branch: Git branch to deploy
            framework: Framework type (fastapi, flask, django)
            region: DigitalOcean region (optional)
            size_slug: DigitalOcean droplet size (optional)

        Yields:
            dict: SSE events with 'event' and 'data' fields

        Example:
            for event in client.deployments.create_stream(...):
                if event['event'] == 'log':
                    print(event['data'])
                elif event['event'] == 'deployment_complete':
                    print("Done!")
        """
        payload = {
            "project_name": project_name,
            "git_repo": git_repo,
            "branch": branch,
            "framework": framework,
        }
        if region:
            payload["region"] = region
        if size_slug:
            payload["size_slug"] = size_slug

        try:
            # Use httpx to stream the SSE response
            import httpx

            headers = {
                "Authorization": f"Bearer {self._client._token}",
                "Accept": "text/event-stream",
                "Content-Type": "application/json",
            }

            url = f"{self._client.api_url}/deployments/stream"

            with httpx.stream(
                "POST",
                url,
                json=payload,
                headers=headers,
                timeout=600.0,  # 10 minute timeout for deployments
            ) as response:
                # Check status before consuming stream
                if response.status_code not in [200, 201, 202]:
                    # For error responses from streaming endpoint, read via iteration
                    error_text = ""
                    try:
                        for chunk in response.iter_bytes():
                            error_text += chunk.decode('utf-8', errors='ignore')
                            if len(error_text) > 1000:  # Limit error message size
                                break
                        if not error_text:
                            error_text = "Unknown error"
                    except Exception as e:
                        error_text = f"Could not read error response: {e}"

                    raise XenfraAPIError(
                        status_code=response.status_code,
                        detail=f"Deployment failed: {error_text}"
                    )

                # Parse SSE events
                for line in response.iter_lines():
                    line = line.strip()
                    if not line:
                        continue

                    # SSE format: "event: eventname" or "data: eventdata"
                    if line.startswith("event:"):
                        current_event = line[6:].strip()
                    elif line.startswith("data:"):
                        data = line[5:].strip()
                        try:
                            # Try to parse as JSON
                            data_parsed = json.loads(data)
                            yield {"event": current_event if 'current_event' in locals() else "message", "data": data_parsed}
                        except json.JSONDecodeError:
                            # If not JSON, yield as plain text
                            yield {"event": current_event if 'current_event' in locals() else "message", "data": data}

                        # Reset current_event
                        if 'current_event' in locals():
                            del current_event

        except httpx.HTTPError as e:
            raise XenfraError(f"HTTP error during streaming deployment: {e}")
        except Exception as e:
            raise XenfraError(f"Failed to create streaming deployment: {e}")
