"""Interesting package."""
