# Heroshot

Screenshot automation CLI tool.

## Status

This Python package is a **placeholder** for the heroshot project. The primary implementation is currently available as:

- **npm**: `npx heroshot` - [npmjs.com/package/heroshot](https://www.npmjs.com/package/heroshot)
- **Docker**: `docker pull heroshot/heroshot`
- **Website**: [heroshot.sh](https://heroshot.sh)

A Python version may be developed in the future.

## About

Heroshot automates browser screenshots with features like:

- Full-page and element-specific captures
- Multiple device viewports
- Dark/light mode switching
- Custom styling injection
- Batch processing

## Links

- [Website](https://heroshot.sh)
- [GitHub](https://github.com/ondrejbase/heroshot)
- [npm package](https://www.npmjs.com/package/heroshot)
