"""
Heroshot - Screenshot automation CLI tool.

This is a placeholder package. The primary implementation is available via npm:
    npx heroshot

For more information, visit https://heroshot.sh
"""

__version__ = "0.0.1"
