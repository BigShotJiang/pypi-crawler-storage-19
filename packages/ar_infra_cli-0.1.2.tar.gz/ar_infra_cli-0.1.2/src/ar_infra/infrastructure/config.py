import os


BOT_ID = os.getenv("BOT_ID", "252012637")
BOT_SLUG = os.getenv("BOT_SLUG", "ar-infra-bot")

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", None)

if BOT_ID == "252012637":
    BOT_ID = "123456789"

if BOT_SLUG == "ar-infra-bot":
    BOT_SLUG = "ar-infra-bot"
