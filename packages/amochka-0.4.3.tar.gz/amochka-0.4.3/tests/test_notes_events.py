import json
import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

import pytest

from amochka import AmoCRMClient, CacheConfig, APIError


def make_client():
    token_data = {"access_token": "token", "expires_at": str(time.time() + 3600)}
    return AmoCRMClient(
        base_url="https://example.amocrm.ru",
        token_file=json.dumps(token_data),
        cache_config=CacheConfig.disabled(),
        disable_logging=True,
    )


def test_get_entity_notes_handles_none_response(monkeypatch):
    client = make_client()
    monkeypatch.setattr(client, "_make_request", lambda *args, **kwargs: None)
    assert client.get_entity_notes("lead", 1, get_all=True) == []


def test_get_entity_events_handles_none_response(monkeypatch):
    client = make_client()
    monkeypatch.setattr(client, "_make_request", lambda *args, **kwargs: None)
    assert client.get_entity_events("lead", 1, get_all=True) == []


def test_get_entity_note_invalid_response_raises(monkeypatch):
    client = make_client()
    monkeypatch.setattr(client, "_make_request", lambda *args, **kwargs: None)
    with pytest.raises(APIError):
        client.get_entity_note("lead", 1, 2)


def test_get_event_invalid_response_raises(monkeypatch):
    client = make_client()
    monkeypatch.setattr(client, "_make_request", lambda *args, **kwargs: None)
    with pytest.raises(APIError):
        client.get_event(123)
