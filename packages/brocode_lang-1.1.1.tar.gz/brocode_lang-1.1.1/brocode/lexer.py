"""
Lexer for Bro Code - Tokenizes source code into tokens.
"""

from typing import List
from .tokens import Token, TokenType, KEYWORDS
from .errors import LexerError


class Lexer:
    def __init__(self, source: str):
        self.source = source
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens: List[Token] = []
    
    @property
    def current_char(self) -> str:
        if self.pos >= len(self.source):
            return '\0'
        return self.source[self.pos]
    
    def peek(self, offset: int = 1) -> str:
        pos = self.pos + offset
        if pos >= len(self.source):
            return '\0'
        return self.source[pos]
    
    def advance(self) -> str:
        char = self.current_char
        self.pos += 1
        if char == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return char
    
    def add_token(self, token_type: TokenType, value=None):
        self.tokens.append(Token(token_type, value, self.line, self.column))
    
    def skip_whitespace(self):
        while self.current_char in ' \t\r\n':
            self.advance()
    
    def skip_comment(self):
        """Skip multi-line /* */ comments."""
        if self.current_char == '/' and self.peek() == '*':
            self.advance()  # /
            self.advance()  # *
            while not (self.current_char == '*' and self.peek() == '/'):
                if self.current_char == '\0':
                    raise LexerError("Unterminated multi-line comment", self.line, self.column)
                self.advance()
            self.advance()  # *
            self.advance()  # /
    
    def skip_single_line_comment(self):
        """Skip single-line // comments."""
        while self.current_char != '\n' and self.current_char != '\0':
            self.advance()
    
    def read_string(self) -> str:
        self.advance()  # Opening quote
        result = ""
        start_line = self.line
        
        while self.current_char != '"':
            if self.current_char == '\0':
                raise LexerError("Unterminated string", start_line, self.column)
            if self.current_char == '\\':
                self.advance()
                escape_chars = {
                    'n': '\n',
                    't': '\t',
                    'r': '\r',
                    '\\': '\\',
                    '"': '"'
                }
                if self.current_char in escape_chars:
                    result += escape_chars[self.current_char]
                else:
                    result += self.current_char
            else:
                result += self.current_char
            self.advance()
        
        self.advance()  # Closing quote
        return result
    
    def read_number(self) -> Token:
        result = ""
        start_col = self.column
        is_float = False
        
        while self.current_char.isdigit() or self.current_char == '.':
            if self.current_char == '.':
                if is_float:
                    break
                is_float = True
            result += self.current_char
            self.advance()
        
        if is_float:
            return Token(TokenType.FLOAT, float(result), self.line, start_col)
        return Token(TokenType.INTEGER, int(result), self.line, start_col)
    
    def read_identifier(self) -> str:
        result = ""
        while self.current_char.isalnum() or self.current_char == '_':
            result += self.current_char
            self.advance()
        return result
    
    def tokenize(self) -> List[Token]:
        while self.current_char != '\0':
            # Skip whitespace
            if self.current_char in ' \t\r\n':
                self.skip_whitespace()
                continue
            
            # Skip multi-line comments /*...*/
            if self.current_char == '/' and self.peek() == '*':
                self.skip_comment()
                continue
            
            # For //, we need to determine if it's a comment or integer division
            # Comment: appears at start of line/statement (after semicolon, brace, etc.)
            # Integer division: appears in expression context
            # Simple heuristic: if last token was a value-producing token, it's division
            if self.current_char == '/' and self.peek() == '/':
                # Check if we're in expression context by looking at last token
                if len(self.tokens) > 0:
                    last_type = self.tokens[-1].type
                    # If last token could produce a value, then // is integer division
                    value_tokens = {
                        TokenType.INTEGER, TokenType.FLOAT, TokenType.STRING,
                        TokenType.IDENTIFIER, TokenType.RPAREN, TokenType.RBRACKET,
                        TokenType.NO_CAP, TokenType.CAP, TokenType.GHOST
                    }
                    if last_type in value_tokens:
                        # This is integer division, not a comment
                        # Don't skip, let the operator handling below catch it
                        pass
                    else:
                        # Likely a comment
                        self.skip_single_line_comment()
                        continue
                else:
                    # No tokens yet, must be a comment at start of file
                    self.skip_single_line_comment()
                    continue
            
            # String literals
            if self.current_char == '"':
                value = self.read_string()
                self.add_token(TokenType.STRING, value)
                continue
            
            # Numbers
            if self.current_char.isdigit():
                token = self.read_number()
                self.tokens.append(token)
                continue
            
            # Identifiers and keywords
            if self.current_char.isalpha() or self.current_char == '_':
                start_col = self.column
                value = self.read_identifier()
                
                if value in KEYWORDS:
                    self.tokens.append(Token(KEYWORDS[value], value, self.line, start_col))
                else:
                    self.tokens.append(Token(TokenType.IDENTIFIER, value, self.line, start_col))
                continue
            
            # Operators and delimiters
            start_col = self.column
            char = self.current_char
            
            # Two-character operators
            if char == '&' and self.peek() == '&':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.AND, '&&', self.line, start_col))
                continue
            
            if char == '|' and self.peek() == '|':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.OR, '||', self.line, start_col))
                continue
            
            if char == '=' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.EQUAL_EQUAL, '==', self.line, start_col))
                continue
            
            if char == '!' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.NOT_EQUAL, '!=', self.line, start_col))
                continue
            
            if char == '<' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.LESS_EQUAL, '<=', self.line, start_col))
                continue
            
            if char == '>' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.GREATER_EQUAL, '>=', self.line, start_col))
                continue
            
            # Increment/Decrement (must be before + and -)
            if char == '+' and self.peek() == '+':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.PLUS_PLUS, '++', self.line, start_col))
                continue
            
            if char == '-' and self.peek() == '-':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.MINUS_MINUS, '--', self.line, start_col))
                continue
            
            # Power operator (must be before * and *=)
            if char == '*' and self.peek() == '*':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.STAR_STAR, '**', self.line, start_col))
                continue
            
            # Integer division (must be before single /)
            if char == '/' and self.peek() == '/':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.SLASH_SLASH, '//', self.line, start_col))
                continue
            
            # Compound assignment operators (must be before single =)
            if char == '+' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.PLUS_EQUAL, '+=', self.line, start_col))
                continue
            
            if char == '-' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.MINUS_EQUAL, '-=', self.line, start_col))
                continue
            
            if char == '*' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.STAR_EQUAL, '*=', self.line, start_col))
                continue
            
            if char == '/' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.SLASH_EQUAL, '/=', self.line, start_col))
                continue
            
            if char == '%' and self.peek() == '=':
                self.advance()
                self.advance()
                self.tokens.append(Token(TokenType.PERCENT_EQUAL, '%=', self.line, start_col))
                continue
            
            # Single-character operators/delimiters
            single_tokens = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.STAR,
                '/': TokenType.SLASH,
                '%': TokenType.PERCENT,
                '=': TokenType.EQUAL,
                '<': TokenType.LESS,
                '>': TokenType.GREATER,
                '!': TokenType.NOT,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
                '{': TokenType.LBRACE,
                '}': TokenType.RBRACE,
                '[': TokenType.LBRACKET,
                ']': TokenType.RBRACKET,
                ',': TokenType.COMMA,
                ';': TokenType.SEMICOLON,
                '.': TokenType.DOT,
            }
            
            if char in single_tokens:
                self.advance()
                self.tokens.append(Token(single_tokens[char], char, self.line, start_col))
                continue
            
            raise LexerError(f"Unexpected character: '{char}'", self.line, self.column)
        
        self.add_token(TokenType.EOF, None)
        return self.tokens


def tokenize(source: str) -> List[Token]:
    """Convenience function to tokenize source code."""
    lexer = Lexer(source)
    return lexer.tokenize()
