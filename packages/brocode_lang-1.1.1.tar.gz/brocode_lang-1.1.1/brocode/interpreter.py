"""
Interpreter for Bro Code - Executes the AST.
"""

from typing import Any, Dict, List, Optional
from .ast_nodes import *
from .builtins import BUILTINS, BroCodeArray
from .errors import RuntimeError, NameError, TypeError, ReturnException, PeaceException, BreakException, ContinueException


class Environment:
    """Variable environment with scope chain."""
    
    def __init__(self, parent: 'Environment' = None):
        self.variables: Dict[str, Any] = {}
        self.constants: set = set()
        self.parent = parent
    
    def define(self, name: str, value: Any, is_const: bool = False):
        """Define a new variable in current scope."""
        self.variables[name] = value
        if is_const:
            self.constants.add(name)
    
    def get(self, name: str) -> Any:
        """Get variable value, searching up the scope chain."""
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.get(name)
        raise NameError(f"Undefined variable: '{name}'")
    
    def set(self, name: str, value: Any):
        """Set variable value, searching up the scope chain."""
        if name in self.constants:
            raise RuntimeError(f"Cannot reassign constant: '{name}'")
        
        if name in self.variables:
            self.variables[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise NameError(f"Undefined variable: '{name}'")
    
    def exists(self, name: str) -> bool:
        """Check if variable exists in any scope."""
        if name in self.variables:
            return True
        if self.parent:
            return self.parent.exists(name)
        return False


class Function:
    """User-defined function."""
    
    def __init__(self, node: FunctionDefNode, closure: Environment):
        self.name = node.name
        self.params = node.params
        self.param_defaults = node.param_defaults
        self.body = node.body
        self.closure = closure


class Interpreter:
    def __init__(self):
        self.global_env = Environment()
        self.functions: Dict[str, Function] = {}
        
        # Register built-in functions
        for name, func in BUILTINS.items():
            self.global_env.define(name, func)
    
    def run(self, program: ProgramNode):
        """Execute the program."""
        # Register all user-defined functions
        for func_node in program.functions:
            self.functions[func_node.name] = Function(func_node, self.global_env)
        
        # Execute sup block
        try:
            self.execute_block(program.sup_block, self.global_env)
        except PeaceException:
            pass  # Normal program exit
    
    def execute_block(self, block: BlockNode, env: Environment):
        """Execute a block of statements."""
        for stmt in block.statements:
            self.execute(stmt, env)
    
    def execute(self, node: ASTNode, env: Environment) -> Any:
        """Execute a single AST node."""
        method_name = f"exec_{type(node).__name__}"
        method = getattr(self, method_name, None)
        
        if method is None:
            raise RuntimeError(f"Unknown node type: {type(node).__name__}")
        
        return method(node, env)
    
    # Statement execution methods
    
    def exec_VarDeclNode(self, node: VarDeclNode, env: Environment):
        value = None
        if node.value:
            value = self.evaluate(node.value, env)
        env.define(node.name, value, node.is_const)
    
    def exec_AssignNode(self, node: AssignNode, env: Environment):
        value = self.evaluate(node.value, env)
        env.set(node.name, value)
    
    def exec_IndexAssignNode(self, node: IndexAssignNode, env: Environment):
        array = self.evaluate(node.array, env)
        index = self.evaluate(node.index, env)
        value = self.evaluate(node.value, env)
        array[int(index)] = value
    
    def exec_IfNode(self, node: IfNode, env: Environment):
        condition = self.evaluate(node.condition, env)
        
        if self.is_truthy(condition):
            self.execute_block(node.then_block, Environment(env))
        else:
            # Check elif blocks
            for elif_cond, elif_block in node.elif_blocks:
                if self.is_truthy(self.evaluate(elif_cond, env)):
                    self.execute_block(elif_block, Environment(env))
                    return
            
            # Execute else block
            if node.else_block:
                self.execute_block(node.else_block, Environment(env))
    
    def exec_WhileNode(self, node: WhileNode, env: Environment):
        while self.is_truthy(self.evaluate(node.condition, env)):
            try:
                self.execute_block(node.body, Environment(env))
            except ContinueException:
                continue
            except BreakException:
                break
    
    def exec_ForNode(self, node: ForNode, env: Environment):
        iterable = self.evaluate(node.iterable, env)
        
        for item in iterable:
            loop_env = Environment(env)
            loop_env.define(node.var_name, item)
            try:
                self.execute_block(node.body, loop_env)
            except ContinueException:
                continue
            except BreakException:
                break
    
    def exec_ReturnNode(self, node: ReturnNode, env: Environment):
        value = None
        if node.value:
            value = self.evaluate(node.value, env)
        raise ReturnException(value)
    
    def exec_PeaceNode(self, node: PeaceNode, env: Environment):
        raise PeaceException()
    
    def exec_BreakNode(self, node: BreakNode, env: Environment):
        raise BreakException()
    
    def exec_ContinueNode(self, node: ContinueNode, env: Environment):
        raise ContinueException()
    
    def exec_CompoundAssignNode(self, node: CompoundAssignNode, env: Environment):
        current = env.get(node.name)
        operand = self.evaluate(node.value, env)
        
        ops = {
            '+': lambda a, b: a + b,
            '-': lambda a, b: a - b,
            '*': lambda a, b: a * b,
            '/': lambda a, b: a / b,
            '%': lambda a, b: a % b,
        }
        
        new_value = ops[node.operator](current, operand)
        env.set(node.name, new_value)
    
    def exec_IndexCompoundAssignNode(self, node: IndexCompoundAssignNode, env: Environment):
        array = self.evaluate(node.array, env)
        index = int(self.evaluate(node.index, env))
        current = array[index]
        operand = self.evaluate(node.value, env)
        
        ops = {
            '+': lambda a, b: a + b,
            '-': lambda a, b: a - b,
            '*': lambda a, b: a * b,
            '/': lambda a, b: a / b,
            '%': lambda a, b: a % b,
        }
        
        array[index] = ops[node.operator](current, operand)
    
    def exec_IncrementNode(self, node: IncrementNode, env: Environment):
        current = env.get(node.name)
        env.set(node.name, current + 1)
    
    def exec_DecrementNode(self, node: DecrementNode, env: Environment):
        current = env.get(node.name)
        env.set(node.name, current - 1)
    
    def exec_TryNode(self, node: TryNode, env: Environment):
        try:
            self.execute_block(node.try_block, Environment(env))
        except Exception as e:
            catch_env = Environment(env)
            catch_env.define(node.error_name, str(e))
            self.execute_block(node.catch_block, catch_env)
    
    # Expression execution (also handle as statements)
    
    def exec_FunctionCallNode(self, node: FunctionCallNode, env: Environment):
        return self.evaluate(node, env)
    
    def exec_MethodCallNode(self, node: MethodCallNode, env: Environment):
        return self.evaluate(node, env)
    
    # Expression evaluation methods
    
    def evaluate(self, node: ASTNode, env: Environment) -> Any:
        """Evaluate an expression and return its value."""
        method_name = f"eval_{type(node).__name__}"
        method = getattr(self, method_name, None)
        
        if method is None:
            raise RuntimeError(f"Cannot evaluate node type: {type(node).__name__}")
        
        return method(node, env)
    
    def eval_IntegerNode(self, node: IntegerNode, env: Environment) -> int:
        return node.value
    
    def eval_FloatNode(self, node: FloatNode, env: Environment) -> float:
        return node.value
    
    def eval_StringNode(self, node: StringNode, env: Environment) -> str:
        return node.value
    
    def eval_BooleanNode(self, node: BooleanNode, env: Environment) -> bool:
        return node.value
    
    def eval_NullNode(self, node: NullNode, env: Environment) -> None:
        return None
    
    def eval_IdentifierNode(self, node: IdentifierNode, env: Environment) -> Any:
        # Check user-defined functions first
        if node.name in self.functions:
            return self.functions[node.name]
        return env.get(node.name)
    
    def eval_ArrayNode(self, node: ArrayNode, env: Environment) -> BroCodeArray:
        elements = [self.evaluate(elem, env) for elem in node.elements]
        return BroCodeArray(elements)
    
    def eval_IndexAccessNode(self, node: IndexAccessNode, env: Environment) -> Any:
        array = self.evaluate(node.array, env)
        index = self.evaluate(node.index, env)
        return array[int(index)]
    
    def eval_MethodCallNode(self, node: MethodCallNode, env: Environment) -> Any:
        obj = self.evaluate(node.object, env)
        args = [self.evaluate(arg, env) for arg in node.arguments]
        
        method = getattr(obj, node.method, None)
        if method is None:
            raise RuntimeError(f"Unknown method: '{node.method}'")
        
        return method(*args)
    
    def eval_FunctionCallNode(self, node: FunctionCallNode, env: Environment) -> Any:
        # Check for built-in functions
        if node.name in BUILTINS:
            args = [self.evaluate(arg, env) for arg in node.arguments]
            return BUILTINS[node.name](*args)
        
        # Check for user-defined functions
        if node.name not in self.functions:
            raise NameError(f"Undefined function: '{node.name}'")
        
        func = self.functions[node.name]
        args = [self.evaluate(arg, env) for arg in node.arguments]
        
        # Calculate required parameters (those without defaults)
        required_count = sum(1 for d in func.param_defaults if d is None)
        
        if len(args) < required_count:
            raise RuntimeError(
                f"Function '{node.name}' requires at least {required_count} arguments, got {len(args)}"
            )
        
        if len(args) > len(func.params):
            raise RuntimeError(
                f"Function '{node.name}' accepts at most {len(func.params)} arguments, got {len(args)}"
            )
        
        # Create new environment for function call
        func_env = Environment(func.closure)
        
        for i, param in enumerate(func.params):
            if i < len(args):
                # Argument was provided
                func_env.define(param, args[i])
            else:
                # Use default value
                default_node = func.param_defaults[i]
                if default_node is not None:
                    default_value = self.evaluate(default_node, env)
                    func_env.define(param, default_value)
                else:
                    raise RuntimeError(f"Missing required argument: '{param}'")
        
        try:
            self.execute_block(func.body, func_env)
        except ReturnException as e:
            return e.value
        
        return None
    
    def eval_BinaryOpNode(self, node: BinaryOpNode, env: Environment) -> Any:
        left = self.evaluate(node.left, env)
        right = self.evaluate(node.right, env)
        
        ops = {
            '+': lambda a, b: a + b,
            '-': lambda a, b: a - b,
            '*': lambda a, b: a * b,
            '/': lambda a, b: a / b,
            '%': lambda a, b: a % b,
            '**': lambda a, b: a ** b,
            '//': lambda a, b: int(a // b),
            '==': lambda a, b: a == b,
            '!=': lambda a, b: a != b,
            '<': lambda a, b: a < b,
            '>': lambda a, b: a > b,
            '<=': lambda a, b: a <= b,
            '>=': lambda a, b: a >= b,
            '&&': lambda a, b: self.is_truthy(a) and self.is_truthy(b),
            '||': lambda a, b: self.is_truthy(a) or self.is_truthy(b),
        }
        
        if node.operator not in ops:
            raise RuntimeError(f"Unknown operator: '{node.operator}'")
        
        try:
            return ops[node.operator](left, right)
        except Exception as e:
            raise RuntimeError(str(e))
    
    def eval_UnaryOpNode(self, node: UnaryOpNode, env: Environment) -> Any:
        operand = self.evaluate(node.operand, env)
        
        if node.operator == '-':
            return -operand
        if node.operator == '!':
            return not self.is_truthy(operand)
        
        raise RuntimeError(f"Unknown unary operator: '{node.operator}'")
    
    def is_truthy(self, value: Any) -> bool:
        """Determine if a value is truthy."""
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, str):
            return len(value) > 0
        if isinstance(value, (list, BroCodeArray)):
            return len(value) > 0
        return True


def interpret(program: ProgramNode) -> Interpreter:
    """Convenience function to interpret a program."""
    interpreter = Interpreter()
    interpreter.run(program)
    return interpreter
