"""
Custom exception classes for Bro Code.
"""


class BroCodeError(Exception):
    """Base exception for all Bro Code errors."""
    
    def __init__(self, message: str, line: int = None, column: int = None):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        if self.line is not None:
            return f"Line {self.line}: {self.message}"
        return self.message


class LexerError(BroCodeError):
    """Error during tokenization."""
    pass


class ParserError(BroCodeError):
    """Error during parsing."""
    pass


class RuntimeError(BroCodeError):
    """Error during execution."""
    pass


class NameError(RuntimeError):
    """Undefined variable or function."""
    pass


class TypeError(RuntimeError):
    """Type mismatch error."""
    pass


class ReturnException(Exception):
    """Used to propagate return values from functions."""
    
    def __init__(self, value):
        self.value = value
        super().__init__()


class PeaceException(Exception):
    """Used to exit the program with peace statement."""
    pass


class BreakException(Exception):
    """Used to break out of loops with dip statement."""
    pass


class ContinueException(Exception):
    """Used to continue to next iteration with skip statement."""
    pass
