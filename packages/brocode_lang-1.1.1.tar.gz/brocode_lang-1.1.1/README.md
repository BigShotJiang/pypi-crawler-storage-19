# Bro Code 🤙

> The Ultimate Vibe Check Programming Language

**Bro Code** is a high-level, dynamically typed esoteric programming language designed for the ultimate vibe check. It combines the block structure of C++ with the simplicity of Python.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyPI](https://img.shields.io/pypi/v/brocode-lang)](https://pypi.org/project/brocode-lang/)

## Installation

### Via pip

```bash
pip install brocode-lang
```

### Manual Installation

```bash
# Clone the repository
git clone https://github.com/Prashithshetty/Bro-CODE.git
cd Bro-CODE

# Install in development mode
pip install -e .

# Or just run directly without installing
python -m brocode examples/hello.homie
```

## Quick Start

```bash
# Run a .homie file
brocode examples/hello.homie

# Or use the Python module directly
python -m brocode examples/hello.homie

# Or use the wrapper script
chmod +x bro
./bro examples/hello.homie
```

## Hello World

Create `hello.homie`:

```cpp
sup {
    spit("Hello World!");
    peace;
}
```

Run it:
```bash
python -m brocode hello.homie
```

## Language Features

### Variables & Data Types

```cpp
var name = "Bro";           // String
var age = 21;               // Integer
var price = 4.20;           // Float
var isAwesome = no_cap;     // Boolean (true)
var isBoring = cap;         // Boolean (false)
var nothing = ghost;        // Null
const PI = 3.14;            // Constant
```

### Input/Output

```cpp
spit("Hello!");                         // Print to console
var name = listen("Enter your name: "); // Read input
```

### Conditionals

```cpp
fr (energy > 80) {
    spit("Hyper mode");
} 
meh (energy > 20) {
    spit("Chilling");
} 
nah {
    spit("Need coffee");
}

// Equality check with is_vibe
fr (score is_vibe 100) {
    spit("Perfect!");
}
```

### Loops

```cpp
// While loop
var i = 0;
hold_up (i < 5) {
    spit(i);
    i = i + 1;
}

// For loop
cycle (var i in range(0, 10)) {
    spit(i);
}
```

### Functions

```cpp
gig add(a, b) {
    pay a + b;
}

sup {
    var result = add(5, 3);
    spit(result);  // Outputs: 8
    peace;
}
```

### Arrays (Squads)

```cpp
var squad = [1, 2, 3];
spit(squad[0]);        // Access: 1
squad.push(4);         // Add: [1, 2, 3, 4]
var last = squad.pop(); // Remove & return: 4
spit(len(squad));      // Length: 3
```

### Error Handling

```cpp
shoot {
    var result = 10 / 0;
} 
fumble (error) {
    spit("Error: " + error);
}
```

## Quick Reference

| Feature | Bro Code | Python |
|---------|----------|--------|
| **Main block** | `sup { }` | `if __name__ == "__main__":` |
| **Exit** | `peace;` | `exit()` |
| **Print** | `spit(x)` | `print(x)` |
| **Input** | `listen(prompt)` | `input(prompt)` |
| **Variable** | `var x = 1;` | `x = 1` |
| **Constant** | `const X = 1;` | `X = 1` (by convention) |
| **True/False** | `no_cap` / `cap` | `True` / `False` |
| **Null** | `ghost` | `None` |
| **If** | `fr (cond) { }` | `if cond:` |
| **Else if** | `meh (cond) { }` | `elif cond:` |
| **Else** | `nah { }` | `else:` |
| **While** | `hold_up (cond) { }` | `while cond:` |
| **For** | `cycle (var i in range(0, n)) { }` | `for i in range(n):` |
| **Break** | `dip;` | `break` |
| **Continue** | `skip;` | `continue` |
| **Function** | `gig name(x = 10) { }` | `def name(x=10):` |
| **Return** | `pay x;` | `return x` |
| **Equality** | `is_vibe` or `==` | `==` |
| **Try** | `shoot { }` | `try:` |
| **Catch** | `fumble (e) { }` | `except Exception as e:` |

## Operators

- **Arithmetic:** `+`, `-`, `*`, `/`, `%`, `**` (power), `//` (integer division)
- **Comparison:** `>`, `<`, `>=`, `<=`, `!=`, `==`, `is_vibe`
- **Logical:** `&&` (AND), `||` (OR), `!` (NOT)
- **Assignment:** `=`, `+=`, `-=`, `*=`, `/=`, `%=`
- **Increment/Decrement:** `++`, `--`

## Built-in Functions

| Category | Functions |
|----------|----------|
| **I/O** | `spit(value)`, `listen(prompt)` |
| **Type** | `int(v)`, `float(v)`, `str(v)`, `type(v)` |
| **Math** | `abs(x)`, `min(a,b)`, `max(a,b)`, `pow(x,y)`, `sqrt(x)`, `floor(x)`, `ceil(x)`, `round(x)` |
| **String** | `upper(s)`, `lower(s)`, `trim(s)`, `split(s,d)`, `join(arr,d)`, `replace(s,old,new)`, `contains(s,sub)`, `starts_with(s,p)`, `ends_with(s,p)`, `char_at(s,i)`, `substring(s,start,end)` |
| **Array** | `len(arr)`, `range(start,end,step)`, `sort(arr)`, `reverse(arr)`, `slice(arr,s,e)`, `index_of(arr,v)`, `includes(arr,v)`, `concat(a,b)` |
| **Utility** | `random()`, `random_int(min,max)`, `time()` |

## CLI Options

```bash
python -m brocode <file.homie>     # Run a file
python -m brocode --version        # Show version
python -m brocode --tokens file    # Debug: show tokens
python -m brocode --ast file       # Debug: show AST
```

## Examples

Check out the `examples/` directory for sample programs:

- `hello.homie` - Hello World
- `variables.homie` - Data types and operations
- `conditionals.homie` - fr/meh/nah
- `loops.homie` - hold_up and cycle
- `functions.homie` - gig/pay with recursion
- `squads.homie` - Array operations
- `fibonacci.homie` - Fibonacci sequence
- `fizzbuzz.homie` - Classic FizzBuzz
- `error_handling.homie` - shoot/fumble
- `input.homie` - Interactive input

## Project Structure

```
Bro-CODE/
├── brocode/
│   ├── __init__.py      # Package info
│   ├── __main__.py      # CLI entry point
│   ├── tokens.py        # Token definitions
│   ├── lexer.py         # Tokenizer
│   ├── parser.py        # AST builder
│   ├── ast_nodes.py     # AST node classes
│   ├── interpreter.py   # Executor
│   ├── builtins.py      # Built-in functions
│   └── errors.py        # Exception classes
├── examples/            # Sample programs
├── docs/                # Documentation
├── bro                  # CLI wrapper script
└── README.md
```

## Requirements

- Python 3.8+

No external dependencies required!

## License

MIT License - See [LICENSE](LICENSE) file.

---

*Created for CSI Code Wars* 🎮
