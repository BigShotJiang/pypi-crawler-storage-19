# Bro-CODE Adaptability Contest - Coding Questions

## Instructions for Contestants
1.  **Language**: All solutions must be written in **Bro-CODE**. Refer to the provided documentation for syntax and features.
2.  **Input/Output**:
    *   Use `listen("")` with an *empty string* for input to avoid printing prompts that might mess up the automated grading.
    *   Use `spit(value)` for output.
    *   Strictly follow the **Output Format**. Extra whitespace, newlines, or text (like "The answer is:") will cause the test case to fail.
3.  **Strict Format**: The automated server verifies your output against the expected output character-by-character.

---

## Difficulty: Easy (1-10)

### 1. The Vibe Check
**Description**: Write a program that simply prints "Vibe Check Passed" to the console. This verifies you can run a basic program.
**Input**: None
**Output**: A single line: `Vibe Check Passed`
**Example Input**: (None)
**Example Output**:
```
Vibe Check Passed
```

### 2. Echo Chamber
**Description**: Read a single line of text and print it back exactly as received.
**Input**: A single string.
**Output**: The same string.
**Example Input**:
```
Hello Bro
```
**Example Output**:
```
Hello Bro
```

### 3. Simple Sum
**Description**: Read two integers (on separate lines) and print their sum.
**Input**: Two integers, each on a new line.
**Output**: The sum of the two integers.
**Example Input**:
```
5
10
```
**Example Output**:
```
15
```

### 4. Adulting
**Description**: Read an integer representing age. If age is 18 or greater, print "Adult". Otherwise, print "Minor".
**Input**: A single integer.
**Output**: "Adult" or "Minor".
**Example Input**:
```
20
```
**Example Output**:
```
Adult
```

### 5. Count the Hype
**Description**: Read an integer N. Print all numbers from 1 to N (inclusive), each on a new line.
**Input**: A single integer N.
**Output**: N lines, each containing a number.
**Example Input**:
```
3
```
**Example Output**:
```
1
2
3
```

### 6. The Multiplier
**Description**: Read an integer N. Print the result of N multiplied by 10.
**Input**: A single integer.
**Output**: The result.
**Example Input**:
```
5
```
**Example Output**:
```
50
```

### 7. Mood Swing
**Description**: Read an integer. If it's positive, print "Positive". If negative, print "Negative". If zero, print "Zero".
**Input**: A single integer.
**Output**: "Positive", "Negative", or "Zero".
**Example Input**:
```
-5
```
**Example Output**:
```
Negative
```

### 8. Squad Goal: First
**Description**: Read a line containing comma-separated numbers (e.g., "1,2,3"). Parse this into a squad (array) and print the first element.
**Input**: A string of comma-separated values.
**Output**: The first value.
**Example Input**:
```
10,20,30
```
**Example Output**:
```
10
```

### 9. String Length
**Description**: Read a string and print its length.
**Input**: A string.
**Output**: An integer representing the length.
**Example Input**:
```
BroCode
```
**Example Output**:
```
7
```

### 10. Last Digit
**Description**: Read an integer and print its last digit.
**Input**: A single integer.
**Output**: The last digit.
**Example Input**:
```
1234
```
**Example Output**:
```
4
```

---

## Difficulty: Medium (11-20)

### 11. Factorial Fun
**Description**: Read an integer N. Calculate and print its factorial (N!).
**Input**: An integer N (0 <= N <= 10).
**Output**: The factorial of N.
**Example Input**:
```
5
```
**Example Output**:
```
120
```

### 12. Vowel Counter
**Description**: Read a string and print the count of vowels (a, e, i, o, u) in it (case-insensitive).
**Input**: A string.
**Output**: An integer count.
**Example Input**:
```
Bro Code
```
**Example Output**:
```
3
```

### 13. Reverse Squad
**Description**: Read a comma-separated string of numbers. Convert it to a squad, reverse it, and print the resulting numbers separated by spaces.
**Input**: Comma-separated integers.
**Output**: Space-separated integers in reverse order.
**Example Input**:
```
1,2,3,4
```
**Example Output**:
```
4 3 2 1
```

### 14. Palindrome Vibe
**Description**: Read a string. Check if it is a palindrome (reads the same forward and backward). Print "Yes" or "No".
**Input**: A string.
**Output**: "Yes" or "No".
**Example Input**:
```
racecar
```
**Example Output**:
```
Yes
```

### 15. FizzBuzz
**Description**: Read an integer N. For numbers 1 to N: if divisible by 3 print "Fizz", by 5 "Buzz", both "FizzBuzz", else the number. Each on a new line.
**Input**: Integer N.
**Output**: N lines of FizzBuzz output.
**Example Input**:
```
5
```
**Example Output**:
```
1
2
Fizz
4
Buzz
```

### 16. Prime Time
**Description**: Read an integer N. Print "Prime" if it is a prime number, else "Not Prime".
**Input**: Integer N.
**Output**: "Prime" or "Not Prime".
**Example Input**:
```
7
```
**Example Output**:
```
Prime
```

### 17. Sum of Digits
**Description**: Read a positive integer and print the sum of its individual digits.
**Input**: Integer.
**Output**: Sum of digits.
**Example Input**:
```
123
```
**Example Output**:
```
6
```

### 18. Max in Squad
**Description**: Read a comma-separated list of numbers. Find and print the largest number.
**Input**: Comma-separated numbers.
**Output**: The largest number.
**Example Input**:
```
5,1,9,2
```
**Example Output**:
```
9
```

### 19. Capitalize It
**Description**: Read a string and print it in all uppercase letters.
**Input**: A string.
**Output**: Uppercase string.
**Example Input**:
```
bro code
```
**Example Output**:
```
BRO CODE
```

### 20. Power Up
**Description**: Read two integers A and B from separate lines. Print A raised to the power of B.
**Input**:
First line: A
Second line: B
**Output**: A^B
**Example Input**:
```
2
3
```
**Example Output**:
```
8
```

---

## Difficulty: Hard (21-30)

### 21. Anagram Check
**Description**: Read two lines. Check if they are anagrams of each other (contain same characters in any order). Print "True" or "False".
**Input**: Two strings on separate lines.
**Output**: "True" or "False".
**Example Input**:
```
listen
silent
```
**Example Output**:
```
True
```

### 22. GCD (Greatest Common Divisor)
**Description**: Read two integers A and B. Print their greatest common divisor.
**Input**: Two integers on separate lines.
**Output**: The GCD.
**Example Input**:
```
48
18
```
**Example Output**:
```
6
```

### 23. Second Largest
**Description**: Read a comma-separated list of distinct integers. Find and print the second largest number.
**Input**: Comma-separated integers (at least 2).
**Output**: The second largest integer.
**Example Input**:
```
10,5,20,8
```
**Example Output**:
```
10
```

### 24. Sort the Squad
**Description**: Read a comma-separated list of integers. Sort them in ascending order and print them separated by spaces.
**Input**: Comma-separated integers.
**Output**: Space-separated sorted integers.
**Example Input**:
```
3,1,4,2
```
**Example Output**:
```
1 2 3 4
```

### 25. Collatz Conjecture
**Description**: Read an integer N. Print the number of steps to reach 1 using the Collatz rules: if even, divide by 2; if odd, multiply by 3 and add 1.
**Input**: Integer N > 0.
**Output**: Number of steps.
**Example Input**:
```
6
```
**Example Output**:
```
8
```
*(Explanation: 6->3->10->5->16->8->4->2->1 is 8 steps)*

### 26. Binary to Decimal
**Description**: Read a binary string (0s and 1s). Convert it to a decimal integer and print it.
**Input**: A binary string.
**Output**: Decimal integer.
**Example Input**:
```
1010
```
**Example Output**:
```
10
```

### 27. Remove Duplicates
**Description**: Read a comma-separated list of integers (sorted or unsorted). Print the unique numbers in order of appearance, separated by spaces.
**Input**: Comma-separated integers.
**Output**: Space-separated unique integers.
**Example Input**:
```
1,2,2,3,1
```
**Example Output**:
```
1 2 3
```

### 28. Missing Number
**Description**: Read N (first line) and then a comma-separated list of N-1 unique integers from the range 1 to N. Find the missing number.
**Input**: Integer N, then comma-separated list.
**Output**: The missing number.
**Example Input**:
```
5
1,2,4,5
```
**Example Output**:
```
3
```

### 29. Valid Parentheses
**Description**: Read a string containing just `(` and `)`. Determine if the input string is valid (properly nested and closed). Print "Valid" or "Invalid".
**Input**: A string of parentheses.
**Output**: "Valid" or "Invalid".
**Example Input**:
```
(()())
```
**Example Output**:
```
Valid
```

### 30. Pascal's Row
**Description**: Read an integer N (0-indexed). Print the Nth row of Pascal's Triangle (integers separated by single spaces).
**Input**: Integer N.
**Output**: Space-separated integers of the Nth row.
**Example Input**:
```
3
```
**Example Output**:
```
1 3 3 1
```
