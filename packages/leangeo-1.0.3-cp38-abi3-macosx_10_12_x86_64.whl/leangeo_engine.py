import json
import leangeo
import logging
import atexit
import time
import threading
import math
import gc
from typing import Union, List, Tuple, Optional, Any

# Set up basic logging
logger = logging.getLogger(__name__)

class LeanGeoEngine:
    """
    An enhanced Python wrapper for the Rust-based LeanGeo geospatial database.
    Includes auto-persistence, background maintenance, and metadata sanitization.
    """

    def __init__(self, storage_path: str, auto_persist: bool = True):
        self._inner = leangeo.LeanGeo(storage_path)
        self.base_path = storage_path
        
        # Maintenance state
        self.last_access_time = time.time()
        self.start_time = time.time()
        self.maintenance_interval = 86400  # 24 hours
        self.idle_threshold = 3600         # 1 hour
        self.stop_maintenance = False

        # Start background maintenance thread
        self.m_thread = threading.Thread(target=self._maintenance_loop, daemon=True)
        self.m_thread.start()

        # Register exit handler
        if auto_persist:
            atexit.register(self.persist)

    def _ensure_json_string(self, data: Union[str, dict, None]) -> Optional[str]:
        """Sanitizes and converts dict to JSON string for Rust consumption."""
        if data is None:
            return None
        if isinstance(data, dict):
            # Sanitize to handle NaN/Inf before serialization
            sanitized = self._sanitize_metadata(data)
            return json.dumps(sanitized, allow_nan=False)
        return data

    def _sanitize_metadata(self, meta: Any) -> Any:
        """Recursively cleans metadata to ensure JSON compatibility (NaN -> None)."""
        if isinstance(meta, float):
            if math.isnan(meta) or math.isinf(meta):
                return None
        elif isinstance(meta, dict):
            return {k: self._sanitize_metadata(v) for k, v in meta.items()}
        elif isinstance(meta, list):
            return [self._sanitize_metadata(v) for v in meta]
        return meta

    def _parse_json_result(self, metadata_str: str) -> dict:
        """Safely converts a JSON string from Rust back to a Python dict."""
        if not metadata_str:
            return {}
        try:
            return json.loads(metadata_str)
        except (json.JSONDecodeError, TypeError) as e:
            logger.error(f"Failed to parse metadata: {metadata_str}. Error: {e}")
            return {"raw_error": str(e), "raw_data": metadata_str}

    def _update_access_time(self):
        self.last_access_time = time.time()

    def _maintenance_loop(self):
        """Background loop to persist data during idle periods."""
        while not self.stop_maintenance:
            time.sleep(60) # Check every minute
            uptime = time.time() - self.start_time
            idle_time = time.time() - self.last_access_time
            
            # If system has been up long enough and is currently idle
            if uptime > self.maintenance_interval and idle_time > self.idle_threshold:
                try:
                    self.persist()
                    # Reset maintenance clock
                    self.start_time = time.time()
                except Exception as e:
                    logger.error(f"Background maintenance failed: {e}")

    def add(self, id: str, lat: float, lon: float, metadata: Union[str, dict]) -> None:
        self._update_access_time()
        meta_str = self._ensure_json_string(metadata)
        self._inner.add(id, float(lat), float(lon), meta_str)

    def persist(self) -> None:
        """Explicitly save data to disk."""
        try:
            gc.collect() # Trigger GC before heavy IO/Persistence like base.py
            self._inner.persist()
        except Exception as e:
            logger.error(f"Persist failed: {e}")

    def vacuum(self) -> None:
        """Stop-the-world compaction to optimize storage."""
        self._update_access_time()
        self._inner.vacuum()

    def count(self) -> int:
        return self._inner.count()

    def delete(self, id: str) -> None:
        self._update_access_time()
        self._inner.delete(id)

    def delete_by_filter(self, filter_json: Union[str, dict]) -> int:
        self._update_access_time()
        f_str = self._ensure_json_string(filter_json)
        return self._inner.delete_by_filter(f_str)

    # --- Search Methods ---

    def search_knn(self, lat: float, lon: float, k: int, filter_json: Union[str, dict, None] = None) -> List[Tuple[str, float, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filter_json)
        results = self._inner.search_knn(float(lat), float(lon), int(k), f_str)
        return [(r[0], r[1], self._parse_json_result(r[2])) for r in results]

    def search_radius(self, lat: float, lon: float, radius_m: float, filter_json: Union[str, dict, None] = None) -> List[Tuple[str, float, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filter_json)
        results = self._inner.search_radius(float(lat), float(lon), float(radius_m), f_str)
        return [(r[0], r[1], self._parse_json_result(r[2])) for r in results]

    def search_box(self, top_left: Tuple[float, float], bottom_right: Tuple[float, float], filter_json: Union[str, dict, None] = None) -> List[Tuple[str, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filter_json)
        results = self._inner.search_box(top_left, bottom_right, f_str)
        return [(r[0], self._parse_json_result(r[1])) for r in results]

    def search_bbox(self, min_lat: float, max_lat: float, min_lon: float, max_lon: float, filter_json: Union[str, dict, None] = None) -> List[str]:
        top_left = (max_lat, min_lon)
        bottom_right = (min_lat, max_lon)
        results = self.search_box(top_left, bottom_right, filter_json)
        return [r[0] for r in results]

    def search_polygon(self, points: List[Tuple[float, float]], filter_json: Union[str, dict, None] = None) -> List[Tuple[str, dict]]:
        self._update_access_time()
        f_str = self._ensure_json_string(filter_json)
        results = self._inner.search_polygon(points, f_str)
        return [(r[0], self._parse_json_result(r[1])) for r in results]
