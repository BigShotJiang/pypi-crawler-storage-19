"""Custom exceptions for YAML validation in the obra package.

This module re-exports the shared YamlValidationError used by the orchestrator
(`src.validation.exceptions`) so both obra and src paths raise the same
exception type for compatibility with existing tests.
"""

from src.validation.exceptions import YamlValidationError

__all__ = ["YamlValidationError"]
