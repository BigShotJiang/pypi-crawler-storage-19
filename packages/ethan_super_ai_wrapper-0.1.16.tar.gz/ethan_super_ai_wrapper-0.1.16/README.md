# Documentation: ethan-super-ai-wrapper (v0.1.10+)

Welcome! ethan-super-ai-wrapper is a simple, unified Python library designed to make integrating different AI models into your projects as easy as possible.

Instead of learning separate libraries for OpenAI, Google, Anthropic, and HuggingFace, you only need to learn one set of simple commands. The library automatically handles the different API formats in the background.

# 1. Installation

Install the library directly from PyPI using pip. This will also install its required dependencies (requests and huggingface_hub).


pip install ethan-super-ai-wrapper

# 2. Quick Start (30 Seconds)

This is the fastest way to get a response.

1. Import the global 'ai' object
from ez_ai import ai

2. Set your API key
ai.openai_key = "YOUR_OPENAI_API_KEY_HERE"

3. Ask a question!
response = ai.ask("Write a short poem about Python code.")
print(response)



# 3. Core Commands: The API Reference

All commands are accessed through the imported ai object.



# Authentication (Setting API Keys)

Setting a key automatically activates that provider and sets a recommended default model. You only need to set the key for the provider you want to use.




# Command	Description	Default Model Set

ai.openai_key = "sk-..."	Activates OpenAI (GPT models).	gpt-4o


ai.gemini_key = "AIza..."	Activates Google Gemini.	gemini-1.5-flash


ai.anthropic_key = "sk-..."	Activates Anthropic (Claude models).	claude-3-5-sonnet


ai.hf_key = "hf_..."	Activates HuggingFace (Open Source).	mistralai/Mistral-7B...




# Generating Text

This is the primary function for all text-based tasks.

ai.ask(prompt)

   Description: Sends a prompt to the currently active AI provider and returns the text response.

Parameters:

prompt (string): Your question or instruction for the AI.

   Returns: A string containing the AI's answer.

# Model Selection

You can manually override the default model at any time.

ai.model = "model-name"

   Description: Sets the specific model to be used for the next ai.ask() call. The library will automatically switch to the correct provider's logic based on the name.

# Examples:

 Use a cheaper OpenAI model
ai.model = "gpt-3.5-turbo"

 Use Google's most powerful model
ai.model = "gemini-1.5-pro"

 Use a specific open-source model
ai.model = "google/flan-t5-large"




# Advanced Chat Features

These commands give you more control over the conversation.

ai.set_personality(text)

   Description: Sets a "system prompt" to define the AI's character or give it specific instructions for the entire conversation.

Example:

ai.set_personality("You are a sarcastic robot from the future.")
print(ai.ask("What do you think of humans?"))

ai.clear_memory()

   Description: The library remembers the last few turns of conversation. Use this command to clear the history and start a fresh conversation.




# Image Generation

ai.generate_image(prompt)

   Description: Creates an image based on a text prompt.

   Note: This feature currently requires an OpenAI key (ai.openai_key) and uses the DALL-E 3 model.

   Returns: A string containing the URL of the generated image.




# 4. Usage Examples by Provider

See how easy it is to switch between different AI companies.

Example: OpenAI (GPT)

from ez_ai import ai

ai.openai_key = "YOUR_KEY"

print(ai.ask("Why is the sky blue?"))

Example: Google (Gemini)

from ez_ai import ai

ai.gemini_key = "YOUR_KEY"

Let's use the stable model

ai.model = "gemini-1.5-flash"
print(ai.ask("Why is the sky blue?"))

Example: Anthropic (Claude)

from ez_ai import ai

ai.anthropic_key = "YOUR_KEY"

print(ai.ask("Why is the sky blue?"))

Example: HuggingFace (Open Source)

from ez_ai import ai

ai.hf_key = "YOUR_KEY"

Use a reliable, small model for testing

ai.model = "gpt2"
print(ai.ask("Why is the sky blue?"))