# rusty_add — Rust (PyO3) extension for Python

Минимальный пример **Python extension-модуля, полностью реализованного на Rust** (через PyO3),
сборка/публикация — через **maturin**.

> Про репозиторий пакетов: публиковать нужно на **PyPI (pypi.org)**. PyPy — это интерпретатор, не индекс пакетов.

## Структура

- `src/lib.rs` — экспортируемые в Python функции/модуль
- `pyproject.toml` — метаданные Python-пакета + build-backend `maturin`
- `Cargo.toml` — crate с `crate-type = ["cdylib"]`
- `example.py` — быстрый тест импорта/вызова

## Требования

- Rust toolchain (stable)
- Python 3.10+ (CPython)
- `uv` (рекомендовано) или `pip`

## Локальный запуск (editable install)

```bash
uv venv
uv pip install -U maturin

# соберёт extension и поставит пакет в editable-режиме
uv pip install -e .

python example.py
# или:
python -c "import rusty_add; print(rusty_add.add(2, 40)); print(rusty_add.hello('Dmitry'))"
```

## Сборка артефактов

Wheel + sdist в `dist/`:

```bash
uv pip install -U maturin
maturin build --release
# добавь --sdist если хочешь явный sdist
# maturin sdist
```

## Публикация на PyPI

1) Создай аккаунт на PyPI и **API Token**.
2) Опубликуй релиз:

```bash
export PYPI_TOKEN="pypi-***"
uv pip install -U maturin
maturin publish --release -u __token__ -p "$PYPI_TOKEN"
```

### TestPyPI (опционально)

```bash
export TEST_PYPI_TOKEN="pypi-***"
maturin publish --release -r testpypi -u __token__ -p "$TEST_PYPI_TOKEN"
```

## Использование в других проектах

```bash
uv pip install rusty_add
# или: pip install rusty_add
```

```python
import rusty_add

print(rusty_add.add(1, 2))
print(rusty_add.hello("world"))
```

## Notes

- В `Cargo.toml` включён `pyo3` с `abi3-py310`, поэтому получаются ABI3-wheels для Python 3.10+ (на одной платформе).
- Для Linux “на всех дистрибутивах” обычно собирают `manylinux` wheels в CI (GitHub Actions).
