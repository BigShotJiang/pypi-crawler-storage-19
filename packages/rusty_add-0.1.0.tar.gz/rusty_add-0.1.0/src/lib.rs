use pyo3::prelude::*;

/// Add two integers.
///
/// This is a tiny example function exported to Python.
#[pyfunction]
fn add(a: i64, b: i64) -> i64 {
    a + b
}

/// Return a friendly greeting.
#[pyfunction]
fn hello(name: &str) -> String {
    format!("Hello, {name}! (from Rust)")
}

/// The Python module definition.
/// The name here must match `module-name` in `pyproject.toml`.
#[pymodule]
fn rusty_add(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(add, m)?)?;
    m.add_function(wrap_pyfunction!(hello, m)?)?;
    Ok(())
}
