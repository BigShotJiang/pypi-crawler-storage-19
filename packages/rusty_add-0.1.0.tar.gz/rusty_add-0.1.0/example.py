import rusty_add

print("2 + 40 =", rusty_add.add(2, 40))
print(rusty_add.hello("Dmitry"))
