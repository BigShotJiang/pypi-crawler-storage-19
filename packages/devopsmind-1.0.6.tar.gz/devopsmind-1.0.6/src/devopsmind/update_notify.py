from rich.panel import Panel
from rich.text import Text
from rich.console import Console

from devopsmind.update_check import check_for_update
from devopsmind.state import load_state, save_state
from devopsmind.constants import VERSION

console = Console()


def maybe_notify_update():
    state = load_state() or {}

    local_version = state.get("local_version")
    last_notified = state.get("last_notified_version")

    # Always persist the running version
    if local_version != VERSION:
        state["local_version"] = VERSION
        save_state(state)

    update_available, latest, notes = check_for_update()

    if not update_available:
        return

    # Already notified for this version
    if latest == last_notified:
        return

    # Mark notified
    state["last_notified_version"] = latest
    save_state(state)

    console.print(
        Panel(
            Text(
                f"⬆ Update available: v{latest}\n\n"
                f"{notes}\n\n"
                "Run `pipx upgrade devopsmind` to update.",
                style="cyan",
            ),
            title="What's New",
            border_style="cyan",
        )
    )
