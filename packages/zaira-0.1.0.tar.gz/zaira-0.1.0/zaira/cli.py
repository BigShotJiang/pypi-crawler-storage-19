"""Zaira CLI - Main entry point."""

import argparse
import sys

from zaira import __version__
from zaira.boards import boards_command
from zaira.export import export_command
from zaira.init import init_command
from zaira.report import report_command
from zaira.sync import sync_command


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="zaira",
        description="Jira CLI tool for offline ticket management",
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Export command
    export_parser = subparsers.add_parser(
        "export",
        help="Export Jira tickets to markdown",
    )
    export_parser.add_argument(
        "tickets",
        nargs="*",
        help="Ticket keys (e.g., AC-1409)",
    )
    export_parser.add_argument(
        "--jql",
        help="JQL query to find tickets",
    )
    export_parser.add_argument(
        "-o",
        "--output",
        help="Output directory (default: tickets/)",
    )
    export_parser.add_argument(
        "--board",
        type=int,
        help="Export tickets from board ID",
    )
    export_parser.add_argument(
        "--sprint",
        type=int,
        help="Export tickets from sprint ID",
    )
    export_parser.set_defaults(func=export_command)

    # Report command
    report_parser = subparsers.add_parser(
        "report",
        help="Generate markdown report from JQL query",
    )
    report_parser.add_argument(
        "name",
        nargs="?",
        help="Named report from project.toml",
    )
    report_parser.add_argument(
        "-q",
        "--query",
        help="Named query from project.toml",
    )
    report_parser.add_argument(
        "--jql",
        help="JQL query to find tickets",
    )
    report_parser.add_argument(
        "--board",
        help="Board ID or name from project.toml",
    )
    report_parser.add_argument(
        "--sprint",
        type=int,
        help="Generate report from sprint ID",
    )
    report_parser.add_argument(
        "-o",
        "--output",
        help="Output file path (default: reports/{title}.md)",
    )
    report_parser.add_argument(
        "-t",
        "--title",
        help="Report title (default: 'Jira Report')",
    )
    report_parser.add_argument(
        "-g",
        "--group-by",
        choices=["status", "priority", "issuetype", "assignee", "labels"],
        help="Group tickets by field",
    )
    report_parser.add_argument(
        "-l",
        "--label",
        help="Filter tickets by label",
    )
    report_parser.set_defaults(func=report_command)

    # Boards command
    boards_parser = subparsers.add_parser(
        "boards",
        help="List Jira boards",
    )
    boards_parser.add_argument(
        "-p",
        "--project",
        help="Filter boards by project key (e.g., AC)",
    )
    boards_parser.set_defaults(func=boards_command)

    # Sync command
    sync_parser = subparsers.add_parser(
        "sync",
        help="Re-sync a report from its front matter",
    )
    sync_parser.add_argument(
        "report",
        help="Report file path or name (e.g., documenthub-new.md)",
    )
    sync_parser.add_argument(
        "-f",
        "--full",
        action="store_true",
        help="Also export tickets from the report",
    )
    sync_parser.add_argument(
        "--force",
        action="store_true",
        help="Re-export tickets even if they already exist",
    )
    sync_parser.set_defaults(func=sync_command)

    # Init command
    init_parser = subparsers.add_parser(
        "init",
        help="Initialize project configuration",
    )
    init_parser.add_argument(
        "-p",
        "--project",
        help="Project key (e.g., AC)",
    )
    init_parser.add_argument(
        "-s",
        "--site",
        help="Jira site (e.g., company.atlassian.net)",
    )
    init_parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="Overwrite existing project.toml",
    )
    init_parser.set_defaults(func=init_command)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
