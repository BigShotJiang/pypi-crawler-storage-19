"""Utilities for benchmark framework."""
