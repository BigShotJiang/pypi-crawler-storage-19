"""
Throttle service for evaluating execution rate limits.

Evaluates current metrics against throttle configuration to determine
whether to allow, throttle, or reject execution requests.

Geek Cafe, LLC
MIT License. See Project Root for the license information.
"""

import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Dict, Any, List

from aws_lambda_powertools import Logger

from geek_cafe_saas_sdk.core.service_result import ServiceResult
from geek_cafe_saas_sdk.core.request_context import RequestContext

from ..models.throttle_config import ThrottleConfig
from .execution_metrics_service import ExecutionMetricsService
from .throttle_config_service import ThrottleConfigService

logger = Logger()


class ThrottleDecision(Enum):
    """Throttle evaluation decision."""
    ALLOW = "allow"          # Proceed to primary queue
    THROTTLE = "throttle"    # Send to throttle/delay queue
    REJECT = "reject"        # Hard reject (429)


@dataclass
class ThrottleResult:
    """Result of throttle evaluation."""
    decision: ThrottleDecision
    reason: str
    delay_seconds: int = 0
    details: Optional[Dict[str, Any]] = None
    
    @property
    def is_allowed(self) -> bool:
        """Check if execution is allowed."""
        return self.decision == ThrottleDecision.ALLOW
    
    @property
    def is_throttled(self) -> bool:
        """Check if execution should be throttled."""
        return self.decision == ThrottleDecision.THROTTLE
    
    @property
    def is_rejected(self) -> bool:
        """Check if execution should be rejected."""
        return self.decision == ThrottleDecision.REJECT


class ThrottleService:
    """
    Service for evaluating throttle decisions.
    
    Evaluates current execution metrics against throttle configuration
    to determine whether to allow, throttle, or reject new executions.
    
    This service does NOT extend DatabaseService as it doesn't directly
    manage database records - it uses ExecutionMetricsService and
    ThrottleConfigService for data access.
    """

    def __init__(
        self,
        metrics_service: ExecutionMetricsService,
        config_service: ThrottleConfigService,
        request_context: Optional[RequestContext] = None,
    ):
        """
        Initialize throttle service.
        
        Args:
            metrics_service: Service for accessing execution metrics
            config_service: Service for accessing throttle configs
            request_context: Security context
        """
        self._metrics_service = metrics_service
        self._config_service = config_service
        self._request_context = request_context

    @property
    def request_context(self) -> RequestContext:
        """Get the request context."""
        return self._request_context

    @request_context.setter
    def request_context(self, value: RequestContext):
        """Set the request context."""
        self._request_context = value

    def evaluate(
        self,
        user_id: str,
        metric_type: str = "execution",
        estimated_profiles: Optional[int] = None,
    ) -> ServiceResult[ThrottleResult]:
        """
        Evaluate whether a new execution should be allowed, throttled, or rejected.
        
        Checks in order:
        1. Throttling enabled check
        2. Rate limit check (min interval between submissions)
        3. Hourly/daily submission limits
        4. User concurrent/queued limits
        5. Tenant concurrent/queued limits
        6. Profile count limits (if estimated_profiles provided)
        7. Throttle queue depth check
        
        Args:
            user_id: User ID submitting the execution
            metric_type: Type of execution
            estimated_profiles: Optional estimated profile count for pre-check
            
        Returns:
            ServiceResult with ThrottleResult
        """
        try:
            # Get effective config
            config_result = self._config_service.get_effective_config(user_id, metric_type)
            if not config_result.success:
                # If we can't get config, allow by default (fail open)
                logger.warning("Could not get throttle config, allowing by default")
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.ALLOW,
                    reason="Config unavailable, allowing by default"
                ))
            
            config = config_result.data
            
            # Check if throttling is enabled
            if not config.throttling_enabled:
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.ALLOW,
                    reason="Throttling disabled"
                ))
            
            # Get current metrics
            counts_result = self._metrics_service.get_current_counts(user_id, metric_type)
            if not counts_result.success:
                # If we can't get metrics, allow by default (fail open)
                logger.warning("Could not get metrics, allowing by default")
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.ALLOW,
                    reason="Metrics unavailable, allowing by default"
                ))
            
            counts = counts_result.data
            now = time.time()
            
            # Build details for debugging
            details = {
                "config_type": config.config_type,
                "user_id": user_id,
                "counts": counts,
                "estimated_profiles": estimated_profiles,
            }
            
            # Check 1: Rate limit (min interval between submissions)
            if config.rate_limit_enabled:
                last_submission = counts.get("user_last_submission_ts")
                if last_submission:
                    elapsed = now - last_submission
                    if elapsed < config.min_submission_interval_seconds:
                        return ServiceResult.success_result(ThrottleResult(
                            decision=ThrottleDecision.THROTTLE,
                            reason=f"Rate limit: {elapsed:.1f}s since last submission, minimum is {config.min_submission_interval_seconds}s",
                            delay_seconds=config.throttle_delay_seconds,
                            details=details
                        ))
            
            # Check 2: Hourly submission limit
            if config.rate_limit_enabled:
                submissions_this_hour = counts.get("user_submissions_this_hour", 0)
                if submissions_this_hour >= config.max_submissions_per_hour:
                    return ServiceResult.success_result(ThrottleResult(
                        decision=ThrottleDecision.THROTTLE,
                        reason=f"Hourly limit reached: {submissions_this_hour}/{config.max_submissions_per_hour}",
                        delay_seconds=config.throttle_delay_seconds,
                        details=details
                    ))
            
            # Check 3: Daily submission limit
            if config.rate_limit_enabled:
                submissions_this_day = counts.get("user_submissions_this_day", 0)
                if submissions_this_day >= config.max_submissions_per_day:
                    return ServiceResult.success_result(ThrottleResult(
                        decision=ThrottleDecision.REJECT,
                        reason=f"Daily limit reached: {submissions_this_day}/{config.max_submissions_per_day}",
                        details=details
                    ))
            
            # Check 4: User concurrent limit
            user_active = counts.get("user_active", 0)
            if user_active >= config.max_concurrent_per_user:
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.THROTTLE,
                    reason=f"User concurrent limit: {user_active}/{config.max_concurrent_per_user}",
                    delay_seconds=config.throttle_delay_seconds,
                    details=details
                ))
            
            # Check 5: User queued limit
            user_queued = counts.get("user_queued", 0)
            user_throttled = counts.get("user_throttled", 0)
            user_total_queued = user_queued + user_throttled
            if user_total_queued >= config.max_queued_per_user:
                if config.reject_when_throttle_full:
                    return ServiceResult.success_result(ThrottleResult(
                        decision=ThrottleDecision.REJECT,
                        reason=f"User queue full: {user_total_queued}/{config.max_queued_per_user}",
                        details=details
                    ))
                else:
                    return ServiceResult.success_result(ThrottleResult(
                        decision=ThrottleDecision.THROTTLE,
                        reason=f"User queue limit: {user_total_queued}/{config.max_queued_per_user}",
                        delay_seconds=config.throttle_delay_seconds,
                        details=details
                    ))
            
            # Check 6: Tenant concurrent limit
            tenant_active = counts.get("tenant_active", 0)
            if tenant_active >= config.max_concurrent_per_tenant:
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.THROTTLE,
                    reason=f"Tenant concurrent limit: {tenant_active}/{config.max_concurrent_per_tenant}",
                    delay_seconds=config.throttle_delay_seconds,
                    details=details
                ))
            
            # Check 7: Tenant queued limit
            tenant_queued = counts.get("tenant_queued", 0)
            tenant_throttled = counts.get("tenant_throttled", 0)
            tenant_total_queued = tenant_queued + tenant_throttled
            if tenant_total_queued >= config.max_queued_per_tenant:
                if config.reject_when_throttle_full:
                    return ServiceResult.success_result(ThrottleResult(
                        decision=ThrottleDecision.REJECT,
                        reason=f"Tenant queue full: {tenant_total_queued}/{config.max_queued_per_tenant}",
                        details=details
                    ))
                else:
                    return ServiceResult.success_result(ThrottleResult(
                        decision=ThrottleDecision.THROTTLE,
                        reason=f"Tenant queue limit: {tenant_total_queued}/{config.max_queued_per_tenant}",
                        delay_seconds=config.throttle_delay_seconds,
                        details=details
                    ))
            
            # Check 8: Profile count limit (if provided and enabled)
            if config.profile_limit_enabled and estimated_profiles:
                if estimated_profiles > config.max_profiles_per_submission:
                    return ServiceResult.success_result(ThrottleResult(
                        decision=ThrottleDecision.REJECT,
                        reason=f"Profile limit exceeded: {estimated_profiles}/{config.max_profiles_per_submission}",
                        details=details
                    ))
            
            # All checks passed - allow
            return ServiceResult.success_result(ThrottleResult(
                decision=ThrottleDecision.ALLOW,
                reason="All checks passed",
                details=details
            ))
            
        except Exception as e:
            logger.exception(f"Error evaluating throttle: {e}")
            # Fail open - allow on error
            return ServiceResult.success_result(ThrottleResult(
                decision=ThrottleDecision.ALLOW,
                reason=f"Error during evaluation, allowing by default: {str(e)}"
            ))

    def evaluate_profile_count(
        self,
        user_id: str,
        actual_profiles: int,
        metric_type: str = "execution",
    ) -> ServiceResult[ThrottleResult]:
        """
        Secondary evaluation after profile count is known.
        
        Called after profile splitting to check if actual profile count
        exceeds limits. Can trigger re-queue to throttle queue.
        
        Args:
            user_id: User ID
            actual_profiles: Actual profile count from profile split
            metric_type: Type of execution
            
        Returns:
            ServiceResult with ThrottleResult
        """
        try:
            # Get effective config
            config_result = self._config_service.get_effective_config(user_id, metric_type)
            if not config_result.success or not config_result.data:
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.ALLOW,
                    reason="Config unavailable"
                ))
            
            config = config_result.data
            
            if not config.profile_limit_enabled:
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.ALLOW,
                    reason="Profile limits disabled"
                ))
            
            # Check profile count
            if actual_profiles > config.max_profiles_per_submission:
                return ServiceResult.success_result(ThrottleResult(
                    decision=ThrottleDecision.REJECT,
                    reason=f"Profile limit exceeded: {actual_profiles}/{config.max_profiles_per_submission}",
                    details={"actual_profiles": actual_profiles}
                ))
            
            return ServiceResult.success_result(ThrottleResult(
                decision=ThrottleDecision.ALLOW,
                reason="Profile count within limits",
                details={"actual_profiles": actual_profiles}
            ))
            
        except Exception as e:
            logger.exception(f"Error evaluating profile count: {e}")
            return ServiceResult.success_result(ThrottleResult(
                decision=ThrottleDecision.ALLOW,
                reason=f"Error during evaluation: {str(e)}"
            ))
