from typing import ClassVar

from textual.binding import Binding, BindingType
from textual.message import Message
from textual.widgets import Static

from models import BlockState


class BaseBlockWidget(Static):
    """Base class for all block widgets."""

    BINDINGS: ClassVar[list[BindingType]] = [
        Binding("c", "copy_content", "Copy", show=False),
        Binding("y", "copy_content", "Copy", show=False),  # vim-style yank
        Binding("r", "retry_block", "Retry", show=False),
        Binding("e", "edit_block", "Edit", show=False),
        Binding("f", "fork_block", "Fork", show=False),
    ]

    class RetryRequested(Message):
        """Sent when user clicks retry button."""

        def __init__(self, block_id: str):
            self.block_id = block_id
            super().__init__()

    class EditRequested(Message):
        """Sent when user clicks edit button."""

        def __init__(self, block_id: str, content: str):
            self.block_id = block_id
            self.content = content
            super().__init__()

    class CopyRequested(Message):
        """Sent when user clicks copy button."""

        def __init__(self, block_id: str, content: str):
            self.block_id = block_id
            self.content = content
            super().__init__()

    class ForkRequested(Message):
        """Sent when user clicks fork button to create a conversation branch."""

        def __init__(self, block_id: str):
            self.block_id = block_id
            super().__init__()

    class ViewRequested(Message):
        def __init__(self, block_id: str, view_type: str):
            self.block_id = block_id
            self.view_type = view_type
            super().__init__()

    def __init__(self, block: BlockState):
        super().__init__()
        self.block = block

    def update_output(self, new_content: str = ""):
        """Update the block's output display. Override in subclasses."""
        pass

    def update_metadata(self):
        """Refresh the header and metadata widgets. Override in subclasses."""
        pass

    def set_loading(self, loading: bool):
        """Set the loading state. Override in subclasses."""
        self.block.is_running = loading

    def set_exit_code(self, code: int):
        """Set exit code and stop loading."""
        self.block.exit_code = code
        self.set_loading(False)

    def action_copy_content(self) -> None:
        content = self.block.content_output or ""
        if content:
            self.post_message(self.CopyRequested(self.block.id, content))

    def action_retry_block(self) -> None:
        self.post_message(self.RetryRequested(self.block.id))

    def action_edit_block(self) -> None:
        content = self.block.content_input or ""
        self.post_message(self.EditRequested(self.block.id, content))

    def action_fork_block(self) -> None:
        self.post_message(self.ForkRequested(self.block.id))
