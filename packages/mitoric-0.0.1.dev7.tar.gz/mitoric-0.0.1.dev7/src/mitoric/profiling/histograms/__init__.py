"""Histogram builders and configuration."""
