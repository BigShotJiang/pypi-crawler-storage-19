"""Comparison profiling helpers."""
