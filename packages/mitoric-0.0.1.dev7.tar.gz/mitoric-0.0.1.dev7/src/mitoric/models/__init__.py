"""Domain model types."""
