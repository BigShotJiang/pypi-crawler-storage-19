"""HTML rendering utilities."""
