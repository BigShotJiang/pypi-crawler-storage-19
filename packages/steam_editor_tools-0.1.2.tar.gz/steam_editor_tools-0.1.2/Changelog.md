# Steam Editor Tools: Help You Write Guides and Reviews

{:toc}

## CHANGELOG

### 0.1.2 @ 01/07/2026

#### :wrench: Fix

1. Fix: Correct a severe bug causing the pip wheel package to miss the sub-packages.
2. Fix: Correct the text of the `examples/create_logo.py`.

### 0.1.1 @ 01/06/2026

#### :mega: New

1. Support multi-line equation rendering and provide an example.

#### :wrench: Fix

1. Fix: The property `price_overview` of `stet.steaminfo.AppInfo` should be optional because some delisted apps can be queried but do not have a price.
2. Fix: Some complicated LaTeX equation may be truncated by a little bit. Now, it has been corrected by adding paddings.

### 0.1.0 @ 01/06/2026

#### :mega: New

1. Create this project.
2. Finish the first vesion of `bbcode`, `improc`, and `steaminfo` modules.
3. Add configurations `pyproject.toml`.
4. Add the devloper's environment folder `./docker` and the `Dockerfile`.
5. Add the community guideline files: `CODE_OF_CONDUCT.md`, `CONTRIBUTING.md`, and `SECURITY.md`.
6. Add the issue and pull request templates.
7. Configure the github workflows for publishing the package.
8. Add the banner and adjust the format in the readme.

#### :wrench: Fix

1. Fix: Fix the warning caused by `enum.Enum`.
2. Fix: Correct the bad usage of the font.
3. Fix: Correct the styles of logo and reference images.

#### :floppy_disk: Change

1. Drop the support of `python 3.9` because it is incompatible with the typing system.
2. Finish the docker test and update the display image.
