"""Allow running as: python -m capraisis"""
from .cli import main

if __name__ == "__main__":
    main()
