"""
CapraISIS — Modern CDS/ISIS Implementation
==========================================

A Python implementation of CDS/ISIS inverted file indexing principles
using SQLite FTS5 as the storage backend.

CDS/ISIS was UNESCO's revolutionary text database system (1985-2005) that
pioneered inverted file indexing for bibliographic records. CapraISIS
brings these proven principles to modern Python with SQLite FTS5.

Key Features:
- Inverted file index (FTS5 virtual table)
- B-tree hierarchy (SQLite native)
- Porter stemming and Unicode tokenization
- O(log k) retrieval complexity
- Single-file portable database

Usage:
    from capraisis import CapraIndex

    # Create or open an index
    index = CapraIndex("my_corpus.db")

    # Add records
    index.add("10.1234/example", "Title of the work", "Description text", 2024)

    # Search
    results = index.search("quantum mechanics")

    # Bulk operations
    index.bulk_add(records)  # List of tuples

Reference:
    - UNESCO CDS/ISIS: https://www.unesco.org/isis
    - Caprazli (2025): "The Authority of Neural Scale"

License: MIT (use at your own risk)
"""

__version__ = "0.1.1"
__author__ = "Caprazli"

from .core import CapraIndex
from .builder import IndexBuilder
from .search import SearchInterface

__all__ = ["CapraIndex", "IndexBuilder", "SearchInterface"]
