"""
CapraISIS Builder — Large-Scale Index Construction
==================================================

Handles construction of inverted file indices from large datasets.

Design principles (inherited from CDS/ISIS):
    - Stream processing: Never load entire dataset into memory
    - Batch commits: Balance transaction overhead vs memory
    - Resume capability: Track progress, recover from interruption
    - Progress reporting: Visibility into long-running builds

Typical usage:
    builder = IndexBuilder("corpus.db")
    builder.add_jsonl_files("data/*.jsonl", extractor=my_extractor)
"""

import json
import time
from pathlib import Path
from datetime import datetime
from typing import Callable, Optional, Iterator, Tuple, Any
from .core import CapraIndex


# Type alias for record extractor function
RecordExtractor = Callable[[dict], Optional[Tuple[str, str, str, str, str]]]


def default_extractor(rec: dict) -> Optional[Tuple[str, str, str, str, str]]:
    """
    Default record extractor for DataCite JSONL format.

    Args:
        rec: Raw JSON record

    Returns:
        Tuple of (id, title, content, year, prefix) or None if invalid
    """
    try:
        doi = rec.get('id', '')
        attrs = rec.get('attributes', {})

        # Combine all titles
        titles = ' '.join(
            t.get('title', '') for t in attrs.get('titles', [])
        )

        # Combine all descriptions
        descs = ' '.join(
            d.get('description', '') for d in attrs.get('descriptions', [])
        )

        year = str(attrs.get('publicationYear', ''))
        prefix = attrs.get('prefix', '')

        return (doi, titles, descs, year, prefix)
    except Exception:
        return None


class IndexBuilder:
    """
    Builder for constructing CapraISIS indices from large datasets.

    Features:
        - Resumable builds via file tracking
        - Batch commits for performance
        - Progress reporting
        - Error counting and logging
    """

    def __init__(self, db_path: str, batch_size: int = 100_000,
                 progress_interval: int = 1_000_000):
        """
        Initialize the builder.

        Args:
            db_path: Path to output database
            batch_size: Records per commit batch
            progress_interval: Records between progress reports
        """
        self.db_path = Path(db_path)
        self.batch_size = batch_size
        self.progress_interval = progress_interval

        self.index = CapraIndex(db_path)
        self._processed_files: set = set()
        self._load_progress()

    def _load_progress(self):
        """Load set of already processed files (for resume)."""
        files_json = self.index.get_meta('processed_files')
        if files_json:
            self._processed_files = set(json.loads(files_json))

    def _save_progress(self):
        """Save processed files list."""
        self.index.set_meta(
            'processed_files',
            json.dumps(list(self._processed_files))
        )

    def add_jsonl_files(self, pattern: str,
                        extractor: RecordExtractor = default_extractor,
                        test_limit: Optional[int] = None,
                        resume: bool = True) -> dict:
        """
        Add records from JSONL files matching pattern.

        Args:
            pattern: Glob pattern for files (e.g., "data/**/*.jsonl")
            extractor: Function to extract (id, title, content, year, prefix)
            test_limit: Stop after N records (for testing)
            resume: Skip already processed files

        Returns:
            Build statistics dict
        """
        # Find all matching files
        base_path = Path(pattern).parent
        glob_pattern = Path(pattern).name

        if '**' in pattern:
            files = sorted(Path(pattern.split('**')[0]).rglob(
                pattern.split('**/')[-1]
            ))
        else:
            files = sorted(base_path.glob(glob_pattern))

        print(f"Found {len(files)} files matching pattern")

        # Counters
        total_records = 0
        total_errors = 0
        batch = []
        start_time = time.time()

        # Process files
        for file_idx, filepath in enumerate(files):
            file_key = str(filepath)

            # Resume support
            if resume and file_key in self._processed_files:
                continue

            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    for line in f:
                        try:
                            rec = json.loads(line)
                            extracted = extractor(rec)

                            if extracted:
                                batch.append(extracted)
                                total_records += 1

                                # Batch commit
                                if len(batch) >= self.batch_size:
                                    self.index.bulk_add(batch, batch_size=len(batch))
                                    batch = []

                                # Progress report
                                if total_records % self.progress_interval == 0:
                                    elapsed = time.time() - start_time
                                    rate = total_records / elapsed
                                    print(
                                        f"[{datetime.now().strftime('%H:%M:%S')}] "
                                        f"{total_records:,} records | "
                                        f"{rate:,.0f} rec/sec | "
                                        f"File {file_idx + 1}/{len(files)}"
                                    )

                                # Test limit
                                if test_limit and total_records >= test_limit:
                                    break

                        except json.JSONDecodeError:
                            total_errors += 1

            except Exception as e:
                print(f"Error processing {filepath}: {e}")
                total_errors += 1
                continue

            # Mark file complete
            self._processed_files.add(file_key)

            # Periodic progress save
            if len(self._processed_files) % 100 == 0:
                self._save_progress()

            if test_limit and total_records >= test_limit:
                break

        # Final batch
        if batch:
            self.index.bulk_add(batch, batch_size=len(batch))

        # Save final progress
        self._save_progress()

        # Build statistics
        elapsed = time.time() - start_time
        stats = {
            "total_records": total_records,
            "total_errors": total_errors,
            "elapsed_seconds": elapsed,
            "elapsed_hours": elapsed / 3600,
            "rate_per_second": total_records / elapsed if elapsed > 0 else 0,
            "files_processed": len(self._processed_files),
            "index_size_gb": self.db_path.stat().st_size / 1e9
        }

        self._print_summary(stats)
        return stats

    def add_records(self, records: Iterator[Tuple],
                    total_hint: Optional[int] = None) -> dict:
        """
        Add records from any iterator.

        Args:
            records: Iterator yielding (id, title, content, year, prefix) tuples
            total_hint: Expected total count (for progress)

        Returns:
            Build statistics
        """
        total_records = 0
        batch = []
        start_time = time.time()

        for rec in records:
            batch.append(rec)
            total_records += 1

            if len(batch) >= self.batch_size:
                self.index.bulk_add(batch, batch_size=len(batch))
                batch = []

            if total_records % self.progress_interval == 0:
                elapsed = time.time() - start_time
                rate = total_records / elapsed
                pct = f" ({100*total_records/total_hint:.1f}%)" if total_hint else ""
                print(
                    f"[{datetime.now().strftime('%H:%M:%S')}] "
                    f"{total_records:,} records{pct} | "
                    f"{rate:,.0f} rec/sec"
                )

        if batch:
            self.index.bulk_add(batch, batch_size=len(batch))

        elapsed = time.time() - start_time
        return {
            "total_records": total_records,
            "elapsed_seconds": elapsed,
            "rate_per_second": total_records / elapsed if elapsed > 0 else 0
        }

    def _print_summary(self, stats: dict):
        """Print build summary."""
        print()
        print("=" * 60)
        print("BUILD COMPLETE")
        print("=" * 60)
        print(f"Total records: {stats['total_records']:,}")
        print(f"Total errors: {stats['total_errors']:,}")
        print(f"Time elapsed: {stats['elapsed_hours']:.2f} hours")
        print(f"Average rate: {stats['rate_per_second']:,.0f} records/second")
        print(f"Index size: {stats['index_size_gb']:.2f} GB")
        print("=" * 60)

    def close(self):
        """Close the index."""
        self.index.close()
