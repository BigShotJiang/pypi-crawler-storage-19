"""
CapraISIS Search Interface — Query and Retrieval
================================================

Provides search functionality following CDS/ISIS query semantics:
    - Boolean operators: AND, OR, NOT
    - Phrase search: "exact phrase"
    - Field-specific search: title:quantum
    - Prefix matching: quantum*
    - Proximity search: NEAR(word1, word2, N)

FTS5 Query Syntax Reference:
    quantum mechanics     → implicit AND
    quantum OR mechanics  → either term
    quantum NOT classical → exclude term
    "quantum mechanics"   → exact phrase
    title:quantum         → field-specific
    quant*                → prefix match
    NEAR(a b, 5)          → within 5 tokens
"""

import time
from typing import Optional, List
from .core import CapraIndex


class SearchInterface:
    """
    High-level search interface for CapraISIS indices.

    Provides convenient search methods and result formatting.
    """

    def __init__(self, db_path: str):
        """
        Open an index for searching.

        Args:
            db_path: Path to CapraISIS database
        """
        self.index = CapraIndex(db_path, read_only=True)

    def search(self, query: str, limit: int = 20,
               year: Optional[int] = None,
               output_format: str = 'list') -> dict:
        """
        Execute a search query.

        Args:
            query: FTS5 search query
            limit: Maximum results
            year: Optional year filter
            output_format: 'list', 'json', or 'table'

        Returns:
            Dict with query, results, timing
        """
        start = time.time()
        results = self.index.search(query, limit=limit, year=year)
        elapsed_ms = (time.time() - start) * 1000

        return {
            "query": query,
            "year_filter": year,
            "count": len(results),
            "time_ms": round(elapsed_ms, 2),
            "results": results
        }

    def search_doi(self, doi_pattern: str, limit: int = 20) -> dict:
        """
        Search by DOI pattern.

        Args:
            doi_pattern: Partial DOI to match
            limit: Maximum results

        Returns:
            Search results dict
        """
        start = time.time()
        results = self.index.search_id(doi_pattern, limit=limit)
        elapsed_ms = (time.time() - start) * 1000

        return {
            "doi_pattern": doi_pattern,
            "count": len(results),
            "time_ms": round(elapsed_ms, 2),
            "results": results
        }

    def count_matches(self, query: str) -> dict:
        """
        Count matching records without retrieving them.

        Args:
            query: FTS5 search query

        Returns:
            Count and timing info
        """
        start = time.time()
        count = self.index.count(query)
        elapsed_ms = (time.time() - start) * 1000

        return {
            "query": query,
            "count": count,
            "time_ms": round(elapsed_ms, 2)
        }

    def benchmark(self, queries: Optional[List[str]] = None) -> dict:
        """
        Run benchmark searches to measure performance.

        Args:
            queries: List of test queries (uses defaults if None)

        Returns:
            Benchmark statistics
        """
        if queries is None:
            queries = [
                "polysemanticity",
                "hallucination language model",
                "orthogonal regularization",
                "mechanistic interpretability",
                "sparse autoencoder",
                "climate change",
                "machine learning",
                "neural network",
            ]

        results = []
        for query in queries:
            result = self.count_matches(query)
            results.append({
                "query": query,
                "count": result["count"],
                "time_ms": result["time_ms"]
            })

        times = [r["time_ms"] for r in results]
        return {
            "queries": results,
            "avg_ms": sum(times) / len(times),
            "max_ms": max(times),
            "min_ms": min(times),
            "target_ms": 100,
            "pass": max(times) < 100
        }

    def stats(self) -> dict:
        """Get index statistics."""
        return self.index.stats()

    def print_results(self, search_result: dict):
        """
        Print search results in table format.

        Args:
            search_result: Result from search() method
        """
        query = search_result.get('query', search_result.get('doi_pattern', ''))
        year = search_result.get('year_filter')

        print()
        print(f"Query: '{query}'" + (f" (year={year})" if year else ""))
        print(f"Found: {search_result['count']} results in {search_result['time_ms']:.1f}ms")
        print("-" * 80)

        for r in search_result['results']:
            title = r['title']
            if len(title) > 70:
                title = title[:70] + '...'
            print(f"{r['year']} | {r['id']} | {title}")

    def print_stats(self):
        """Print index statistics."""
        stats = self.stats()

        print()
        print("=" * 60)
        print("CapraISIS Index Statistics")
        print("=" * 60)
        print(f"Total records: {stats['total_records']:,}")
        print(f"Index size: {stats['size_gb']:.2f} GB")

        print("\nTop 10 Years:")
        for year, count in list(stats['top_years'].items())[:10]:
            print(f"  {year}: {count:,}")

        print("\nTop 10 Prefixes:")
        for prefix, count in list(stats['top_prefixes'].items())[:10]:
            print(f"  {prefix}: {count:,}")

    def print_benchmark(self, benchmark_result: dict):
        """Print benchmark results."""
        print()
        print("=" * 60)
        print("Benchmark Results")
        print("=" * 60)

        for r in benchmark_result['queries']:
            print(f"'{r['query']}': {r['count']:,} results in {r['time_ms']:.1f}ms")

        print()
        print("=" * 60)
        print(f"Average: {benchmark_result['avg_ms']:.1f}ms")
        print(f"Max: {benchmark_result['max_ms']:.1f}ms")
        print(f"Min: {benchmark_result['min_ms']:.1f}ms")
        target = benchmark_result['target_ms']
        passed = benchmark_result['pass']
        print(f"Target: <{target}ms {'PASS' if passed else 'FAIL'}")

    def close(self):
        """Close the index."""
        self.index.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
