"""
CapraISIS Core — Inverted File Index Implementation
====================================================

This module implements CDS/ISIS principles using SQLite FTS5:

CDS/ISIS Architecture (1985):
    Master File (.MST) → Inverted File (.IFX) → Cross-Reference (.XRF)

CapraISIS Architecture (2026):
    SQLite DB → FTS5 Virtual Table → B-tree Index

The fundamental insight: FTS5 IS an inverted file index with B-tree
organization. We're not emulating CDS/ISIS — we're using its successor.

Complexity guarantees:
    - INSERT: O(n log k) where n=tokens, k=vocabulary
    - SEARCH: O(log k + m) where m=matching documents
    - This matches original CDS/ISIS performance characteristics
"""

import sqlite3
from pathlib import Path
from typing import Optional, List, Tuple, Iterator
from contextlib import contextmanager


class CapraIndex:
    """
    CDS/ISIS-style inverted file index using SQLite FTS5.

    The index stores:
        - id: Unique identifier (DOI, ISBN, URI, or any string)
        - title: Searchable title field
        - content: Searchable content/description field
        - year: Publication year (UNINDEXED for filtering, not search)
        - prefix: DOI prefix or category (UNINDEXED for filtering)

    Example:
        index = CapraIndex("corpus.db")
        index.add("10.5281/zenodo.123", "Quantum Mechanics", "A paper about...", 2024)
        results = index.search("quantum")
    """

    # FTS5 schema — mirrors CDS/ISIS field structure
    SCHEMA = """
        CREATE VIRTUAL TABLE IF NOT EXISTS corpus_fts USING fts5(
            id,
            title,
            content,
            year UNINDEXED,
            prefix UNINDEXED,
            tokenize='porter unicode61'
        )
    """

    # Metadata table for index statistics and resume capability
    META_SCHEMA = """
        CREATE TABLE IF NOT EXISTS index_meta (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """

    def __init__(self, db_path: str, read_only: bool = False):
        """
        Open or create a CapraISIS index.

        Args:
            db_path: Path to SQLite database file
            read_only: If True, open in read-only mode (faster for search)
        """
        self.db_path = Path(db_path)
        self.read_only = read_only

        if read_only:
            uri = f"file:{db_path}?mode=ro"
            self._conn = sqlite3.connect(uri, uri=True)
        else:
            self._conn = sqlite3.connect(str(db_path))
            self._init_schema()

    def _init_schema(self):
        """Initialize database schema if not exists."""
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute(self.SCHEMA)
        self._conn.execute(self.META_SCHEMA)
        self._conn.commit()

    @contextmanager
    def transaction(self):
        """Context manager for explicit transactions."""
        try:
            yield self._conn
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

    def add(self, id: str, title: str, content: str = "",
            year: Optional[int] = None, prefix: str = "") -> None:
        """
        Add a single record to the index.

        Args:
            id: Unique identifier (DOI, ISBN, etc.)
            title: Title of the work
            content: Description or abstract
            year: Publication year
            prefix: DOI prefix or category
        """
        year_str = str(year) if year else ""
        self._conn.execute(
            "INSERT INTO corpus_fts VALUES (?, ?, ?, ?, ?)",
            (id, title, content, year_str, prefix)
        )
        self._conn.commit()

    def bulk_add(self, records: List[Tuple], batch_size: int = 10000) -> int:
        """
        Add multiple records efficiently.

        Args:
            records: List of tuples (id, title, content, year, prefix)
            batch_size: Commit every N records

        Returns:
            Number of records added
        """
        count = 0
        batch = []

        for rec in records:
            # Normalize year to string
            if len(rec) >= 4 and rec[3] is not None:
                rec = (rec[0], rec[1], rec[2], str(rec[3]),
                       rec[4] if len(rec) > 4 else "")
            batch.append(rec)
            count += 1

            if len(batch) >= batch_size:
                self._conn.executemany(
                    "INSERT INTO corpus_fts VALUES (?, ?, ?, ?, ?)",
                    batch
                )
                self._conn.commit()
                batch = []

        # Final batch
        if batch:
            self._conn.executemany(
                "INSERT INTO corpus_fts VALUES (?, ?, ?, ?, ?)",
                batch
            )
            self._conn.commit()

        return count

    def search(self, query: str, limit: int = 20,
               year: Optional[int] = None) -> List[dict]:
        """
        Full-text search using FTS5 MATCH.

        Args:
            query: Search query (supports FTS5 syntax: AND, OR, NOT, phrases)
            limit: Maximum results to return
            year: Optional year filter

        Returns:
            List of matching records as dicts
        """
        if year:
            cursor = self._conn.execute("""
                SELECT id, title, content, year, prefix
                FROM corpus_fts
                WHERE corpus_fts MATCH ? AND year = ?
                LIMIT ?
            """, (query, str(year), limit))
        else:
            cursor = self._conn.execute("""
                SELECT id, title, content, year, prefix
                FROM corpus_fts
                WHERE corpus_fts MATCH ?
                LIMIT ?
            """, (query, limit))

        return [
            {"id": r[0], "title": r[1], "content": r[2],
             "year": r[3], "prefix": r[4]}
            for r in cursor.fetchall()
        ]

    def search_id(self, id_pattern: str, limit: int = 20) -> List[dict]:
        """
        Search by identifier pattern (LIKE query).

        Args:
            id_pattern: Pattern to match (e.g., "10.5281%" for Zenodo DOIs)
            limit: Maximum results

        Returns:
            List of matching records
        """
        cursor = self._conn.execute("""
            SELECT id, title, content, year, prefix
            FROM corpus_fts
            WHERE id LIKE ?
            LIMIT ?
        """, (f"%{id_pattern}%", limit))

        return [
            {"id": r[0], "title": r[1], "content": r[2],
             "year": r[3], "prefix": r[4]}
            for r in cursor.fetchall()
        ]

    def count(self, query: Optional[str] = None) -> int:
        """
        Count records (total or matching query).

        Args:
            query: Optional search query

        Returns:
            Record count
        """
        if query:
            cursor = self._conn.execute(
                "SELECT COUNT(*) FROM corpus_fts WHERE corpus_fts MATCH ?",
                (query,)
            )
        else:
            cursor = self._conn.execute("SELECT COUNT(*) FROM corpus_fts")

        return cursor.fetchone()[0]

    def stats(self) -> dict:
        """
        Get index statistics.

        Returns:
            Dict with count, size, year distribution, prefix distribution
        """
        count = self.count()

        # Year distribution
        years = self._conn.execute("""
            SELECT year, COUNT(*) as cnt
            FROM corpus_fts
            WHERE year != ''
            GROUP BY year
            ORDER BY cnt DESC
            LIMIT 10
        """).fetchall()

        # Prefix distribution
        prefixes = self._conn.execute("""
            SELECT prefix, COUNT(*) as cnt
            FROM corpus_fts
            WHERE prefix != ''
            GROUP BY prefix
            ORDER BY cnt DESC
            LIMIT 10
        """).fetchall()

        # File size
        size_bytes = self.db_path.stat().st_size if self.db_path.exists() else 0

        return {
            "total_records": count,
            "size_bytes": size_bytes,
            "size_gb": size_bytes / 1e9,
            "top_years": dict(years),
            "top_prefixes": dict(prefixes)
        }

    def get_meta(self, key: str) -> Optional[str]:
        """Get metadata value by key."""
        cursor = self._conn.execute(
            "SELECT value FROM index_meta WHERE key = ?", (key,)
        )
        row = cursor.fetchone()
        return row[0] if row else None

    def set_meta(self, key: str, value: str) -> None:
        """Set metadata key-value pair."""
        self._conn.execute(
            "INSERT OR REPLACE INTO index_meta (key, value) VALUES (?, ?)",
            (key, value)
        )
        self._conn.commit()

    def close(self):
        """Close database connection."""
        self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
