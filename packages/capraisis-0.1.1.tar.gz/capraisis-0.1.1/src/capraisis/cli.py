#!/usr/bin/env python3
"""
CapraISIS CLI — Command Line Interface
=====================================

Usage:
    python -m capraisis search "quantum mechanics" --limit 20
    python -m capraisis build data/*.jsonl --output corpus.db
    python -m capraisis stats corpus.db
    python -m capraisis benchmark corpus.db
"""

import argparse
import json
import sys
from pathlib import Path


def cmd_search(args):
    """Execute search command."""
    from .search import SearchInterface

    with SearchInterface(args.database) as search:
        if args.doi:
            result = search.search_doi(args.query, limit=args.limit)
        else:
            result = search.search(
                args.query,
                limit=args.limit,
                year=args.year
            )

        if args.json:
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            search.print_results(result)


def cmd_build(args):
    """Execute build command."""
    from .builder import IndexBuilder

    builder = IndexBuilder(
        args.output,
        batch_size=args.batch_size,
        progress_interval=args.progress_interval
    )

    try:
        stats = builder.add_jsonl_files(
            args.pattern,
            test_limit=args.test_limit,
            resume=args.resume
        )

        if args.json:
            print(json.dumps(stats, indent=2))

    finally:
        builder.close()


def cmd_stats(args):
    """Show index statistics."""
    from .search import SearchInterface

    with SearchInterface(args.database) as search:
        if args.json:
            print(json.dumps(search.stats(), indent=2))
        else:
            search.print_stats()


def cmd_benchmark(args):
    """Run benchmark tests."""
    from .search import SearchInterface

    with SearchInterface(args.database) as search:
        result = search.benchmark()

        if args.json:
            print(json.dumps(result, indent=2))
        else:
            search.print_benchmark(result)


def main():
    parser = argparse.ArgumentParser(
        description='CapraISIS — Modern CDS/ISIS Implementation',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Search for terms
    python -m capraisis search corpus.db "quantum mechanics"
    python -m capraisis search corpus.db "neural network" --year 2024

    # Build index from JSONL files
    python -m capraisis build "data/*.jsonl" --output corpus.db
    python -m capraisis build "data/**/*.jsonl" --output corpus.db --test 1000000

    # Show statistics
    python -m capraisis stats corpus.db

    # Run benchmark
    python -m capraisis benchmark corpus.db
        """
    )

    subparsers = parser.add_subparsers(dest='command', required=True)

    # Search command
    search_parser = subparsers.add_parser('search', help='Search the index')
    search_parser.add_argument('database', help='Path to database file')
    search_parser.add_argument('query', help='Search query')
    search_parser.add_argument('-l', '--limit', type=int, default=20,
                               help='Maximum results (default: 20)')
    search_parser.add_argument('-y', '--year', type=int,
                               help='Filter by publication year')
    search_parser.add_argument('--doi', action='store_true',
                               help='Search by DOI pattern instead of full-text')
    search_parser.add_argument('--json', action='store_true',
                               help='Output as JSON')
    search_parser.set_defaults(func=cmd_search)

    # Build command
    build_parser = subparsers.add_parser('build', help='Build index from JSONL')
    build_parser.add_argument('pattern', help='Glob pattern for input files')
    build_parser.add_argument('-o', '--output', required=True,
                              help='Output database path')
    build_parser.add_argument('--batch-size', type=int, default=100000,
                              help='Records per commit (default: 100000)')
    build_parser.add_argument('--progress-interval', type=int, default=1000000,
                              help='Records between progress reports (default: 1000000)')
    build_parser.add_argument('--test-limit', type=int,
                              help='Stop after N records (for testing)')
    build_parser.add_argument('--resume', action='store_true',
                              help='Resume interrupted build')
    build_parser.add_argument('--json', action='store_true',
                              help='Output stats as JSON')
    build_parser.set_defaults(func=cmd_build)

    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show index statistics')
    stats_parser.add_argument('database', help='Path to database file')
    stats_parser.add_argument('--json', action='store_true',
                              help='Output as JSON')
    stats_parser.set_defaults(func=cmd_stats)

    # Benchmark command
    bench_parser = subparsers.add_parser('benchmark', help='Run benchmark tests')
    bench_parser.add_argument('database', help='Path to database file')
    bench_parser.add_argument('--json', action='store_true',
                              help='Output as JSON')
    bench_parser.set_defaults(func=cmd_benchmark)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
