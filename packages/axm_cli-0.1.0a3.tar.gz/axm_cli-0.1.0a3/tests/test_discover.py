"""Tests for the axm discover command (Pure Function Standard)."""

from pathlib import Path
from textwrap import dedent

from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


def test_discover_finds_pure_function_operations(tmp_path: Path) -> None:
    """Test that discover finds pure functions by naming convention.

    Convention: operations/{name}/src/{name}/main.py with function {name}.
    """
    # Create operation package structure
    op_src = tmp_path / "operations" / "clean_data" / "src" / "clean_data"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Clean data operation."""


        def clean_data(inputs: dict, parameters: dict) -> dict:
            """Clean the data."""
            return {}
    ''')
    )

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    assert "clean_data" in result.stdout
    assert "1" in result.stdout  # 1 item discovered


def test_discover_generates_axm_file(tmp_path: Path) -> None:
    """Test that discover generates colocated .axm file."""
    # Create operation package structure
    op_src = tmp_path / "operations" / "process" / "src" / "process"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Process data operation."""


        def process(inputs: dict, parameters: dict) -> dict:
            """Process the data."""
            return {}
    ''')
    )

    result = runner.invoke(app, ["discover", str(tmp_path / "operations")])

    assert result.exit_code == 0
    # Check colocated .axm was created next to main.py
    axm_file = op_src / "main.axm"
    assert axm_file.exists()

    content = axm_file.read_text()
    assert "kind: operation" in content
    assert "name: process" in content


def test_discover_dry_run_does_not_write(tmp_path: Path) -> None:
    """Test that --dry-run doesn't create files."""
    # Create operation package structure
    op_src = tmp_path / "operations" / "demo" / "src" / "demo"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Demo operation."""


        def demo(inputs: dict, parameters: dict) -> dict:
            """Demo."""
            return {}
    ''')
    )

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    assert not (op_src / "main.axm").exists()


def test_discover_shows_help(tmp_path: Path) -> None:
    """Test that discover command has help."""
    result = runner.invoke(app, ["discover", "--help"])

    assert result.exit_code == 0
    assert "discover" in result.stdout.lower()


def test_discover_empty_operations(tmp_path: Path) -> None:
    """Test discover with empty operations folder shows message."""
    (tmp_path / "operations").mkdir()

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    assert "No operations found" in result.stdout or "0" in result.stdout


def test_discover_with_parse_error(tmp_path: Path) -> None:
    """Test discover continues on parse errors in Python files."""
    op_src = tmp_path / "operations" / "broken" / "src" / "broken"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text("def broken( invalid syntax")

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    # Should not crash, just skip the broken file
    assert result.exit_code == 0


def test_discover_with_data_flag(tmp_path: Path) -> None:
    """Test discover with --data flag scans data files."""
    # Create operation
    op_src = tmp_path / "operations" / "proc" / "src" / "proc"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Process."""


        def proc(inputs: dict, parameters: dict) -> dict:
            """Process."""
            return {}
    ''')
    )

    # Create data file
    (tmp_path / "data.csv").write_text("a,b\n1,2")

    result = runner.invoke(
        app, ["discover", str(tmp_path / "operations"), "--data", "--dry-run"]
    )

    assert result.exit_code == 0


def test_discover_ignores_pycache(tmp_path: Path) -> None:
    """Test that discover ignores __pycache__ directories."""
    # Create a valid operation
    op_src = tmp_path / "operations" / "valid_op" / "src" / "valid_op"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """Valid operation."""


        def valid_op(inputs: dict, parameters: dict) -> dict:
            """Valid."""
            return {}
    ''')
    )

    # Create a __pycache__ with main.py (should be ignored)
    pycache = tmp_path / "operations" / "__pycache__"
    pycache.mkdir(parents=True)
    (pycache / "main.py").write_text("# cache file")

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    # Should find only the valid operation, not the cache
    assert "valid_op" in result.stdout
    assert "1" in result.stdout  # exactly 1 item


def test_discover_with_data_writes_files(tmp_path: Path) -> None:
    """Test that discover --data without --dry-run writes axm files."""
    # Create data file
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    csv_file = data_dir / "users.csv"
    csv_file.write_text("id,name\n1,Alice\n2,Bob")

    result = runner.invoke(app, ["discover", str(data_dir), "--data"])

    assert result.exit_code == 0
    # Check that .axm file was created
    axm_file = data_dir / "users.axm"
    assert axm_file.exists()
    content = axm_file.read_text()
    assert "kind: data" in content
    assert "name: users" in content


def test_discover_data_no_files_found(tmp_path: Path) -> None:
    """Test that discover --data with no data files shows message."""
    empty_dir = tmp_path / "empty"
    empty_dir.mkdir()

    result = runner.invoke(app, ["discover", str(empty_dir), "--data", "--dry-run"])

    assert result.exit_code == 0
    assert "No data files found" in result.stdout or "0" in result.stdout


def test_generate_operation_contract_with_inputs_outputs(tmp_path: Path) -> None:
    """Test contract generation with inputs and outputs."""
    from axm_cli.commands.discover import generate_operation_contract

    op = {
        "entrypoint": "transform_data",
        "description": "Transform data operation.",
        "inputs": ["raw_data", "config"],
        "outputs": ["cleaned_data"],
        "domain": "etl",
        "source_file": str(tmp_path / "main.py"),
    }

    content = generate_operation_contract(op, tmp_path / "main.py")

    assert "name: transform_data" in content
    assert "inputs:" in content
    assert "- name: raw_data" in content
    assert "- name: config" in content
    assert "outputs:" in content
    assert "- name: cleaned_data" in content
    assert 'domain: "etl"' in content


def test_discover_function_not_matching_folder_name(tmp_path: Path) -> None:
    """Test that functions not matching folder name are skipped."""
    op_src = tmp_path / "operations" / "my_op" / "src" / "my_op"
    op_src.mkdir(parents=True)
    # Function name doesn't match folder name
    (op_src / "main.py").write_text(
        dedent('''\
        """Operation."""


        def different_name(inputs: dict, parameters: dict) -> dict:
            """Different."""
            return {}
    ''')
    )

    result = runner.invoke(app, ["discover", str(tmp_path / "operations"), "--dry-run"])

    assert result.exit_code == 0
    # Should not find any operations
    assert "0" in result.stdout or "No operations found" in result.stdout


def test_discover_fallback_to_parent_folder_name(tmp_path: Path) -> None:
    """Test fallback when operations folder is not in path."""
    # Create structure without 'operations' in path
    op_src = tmp_path / "custom_folder" / "my_func"
    op_src.mkdir(parents=True)
    (op_src / "main.py").write_text(
        dedent('''\
        """My function."""


        def my_func(inputs: dict, parameters: dict) -> dict:
            """My function."""
            return {}
    ''')
    )

    result = runner.invoke(
        app, ["discover", str(tmp_path / "custom_folder"), "--dry-run"]
    )

    assert result.exit_code == 0
    # Should find using parent folder name fallback
    assert "my_func" in result.stdout
