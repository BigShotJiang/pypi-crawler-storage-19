"""Tests for axm audit report command."""

from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


class TestAuditReportCommand:
    """Tests for `axm audit report` subcommand."""

    def test_audit_report_shows_metrics(self):
        """Report should display accumulated metrics."""
        # Pre-populate auditor with some data
        from axm_audit import auditor
        from axm_audit.auditor import AuditMetrics

        auditor.metrics = AuditMetrics(
            total_validations=10,
            total_duration_ns=5_000_000,  # 5ms
            quality_checks=3,
            function_calls=5,
        )

        result = runner.invoke(app, ["audit", "report"])

        assert result.exit_code == 0
        assert "10" in result.stdout  # total validations
        assert "5" in result.stdout or "5.0" in result.stdout  # duration

    def test_audit_report_json_format(self):
        """Report should output JSON when requested."""
        from axm_audit import auditor
        from axm_audit.auditor import AuditMetrics

        auditor.metrics = AuditMetrics(
            total_validations=5,
            quality_checks=2,
        )

        result = runner.invoke(app, ["audit", "report", "--format", "json"])

        assert result.exit_code == 0
        assert '"total_validations": 5' in result.stdout
