"""Tests for axm audit CLI command."""

from pathlib import Path

import polars as pl
from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


class TestAuditCommand:
    """Tests for `axm audit` command."""

    def test_audit_parquet_file_passes(self, tmp_path: Path):
        """Audit command should pass with valid data."""
        # Create test parquet file
        df = pl.DataFrame(
            {
                "age": [25, 30, 45],
                "status": ["active", "inactive", "active"],
            }
        )
        parquet_path = tmp_path / "data.parquet"
        df.write_parquet(parquet_path)

        # Create simple contract
        contract = tmp_path / "contract.axm"
        contract.write_text("""
axm: "1.0"
kind: data
name: test_data
schema:
  format: tabular
  columns:
    - name: age
      type: int
      rules:
        - rule: range
          min: 0
          max: 120
    - name: status
      type: string
      rules:
        - rule: in_set
          allowed: ["active", "inactive"]
""")

        result = runner.invoke(
            app, ["audit", "file", str(parquet_path), "--contract", str(contract)]
        )

        assert result.exit_code == 0
        assert "passed" in result.stdout.lower() or "✅" in result.stdout

    def test_audit_parquet_file_fails(self, tmp_path: Path):
        """Audit command should fail with invalid data."""
        # Create test parquet with violations
        df = pl.DataFrame({"age": [25, -5, 150]})  # 2 violations
        parquet_path = tmp_path / "data.parquet"
        df.write_parquet(parquet_path)

        # Create contract
        contract = tmp_path / "contract.axm"
        contract.write_text("""
axm: "1.0"
kind: data
name: test_data
schema:
  format: tabular
  columns:
    - name: age
      type: int
      rules:
        - rule: range
          min: 0
          max: 120
          severity: error
""")

        result = runner.invoke(
            app, ["audit", "file", str(parquet_path), "--contract", str(contract)]
        )

        assert result.exit_code == 1
        assert "violation" in result.stdout.lower() or "❌" in result.stdout
