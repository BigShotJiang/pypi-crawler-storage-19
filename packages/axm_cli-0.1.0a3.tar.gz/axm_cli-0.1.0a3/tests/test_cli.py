import pytest
from typer.testing import CliRunner

# We expect this import to might fail if we haven't created the file yet,
# but for TDD we write the test assuming the interface exists.
try:
    from axm_cli.main import app
except ImportError:
    app = None

runner = CliRunner()


def test_version_flag():
    if app is None:
        pytest.fail("axm_cli.main module not found")

    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "AXM CLI" in result.stdout


def test_help_flag():
    """Test that --help shows available commands."""
    if app is None:
        pytest.fail("axm_cli.main module not found")

    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "check" in result.stdout
    assert "discover" in result.stdout
    assert "init" in result.stdout
    assert "run" in result.stdout


def test_get_version_fallback():
    """Test get_version returns 'unknown' when package not found."""
    import importlib.metadata
    from unittest.mock import patch

    from axm_cli.main import get_version

    with patch(
        "importlib.metadata.version",
        side_effect=importlib.metadata.PackageNotFoundError("axm-cli"),
    ):
        version = get_version()
        assert version == "unknown"


def test_main_callback_passes():
    """Test that main callback runs without error."""
    result = runner.invoke(app, [])
    # When no command provided, typer may exit with 0 or 2 and show help
    # We just verify it doesn't crash unexpectedly
    assert result.exit_code in (0, 2)
