from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


def test_check_command_no_args():
    """Test that axm check runs and defaults to current directory."""
    result = runner.invoke(app, ["check"])
    # Should fail if command doesn't exist (exit_code 2) or succeed if implemented
    # We assert success here to define our verification criteria
    assert result.exit_code == 0
    assert "Checking contracts in ." in result.stdout


def test_check_command_specific_path():
    """Test that axm check accepts a path argument."""
    result = runner.invoke(app, ["check", "src/catalogs"])
    assert result.exit_code == 0
    assert "Checking contracts in src/catalogs" in result.stdout
