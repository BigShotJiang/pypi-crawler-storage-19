"""Tests for pipeline inference from I/O matching."""

from axm_cli.commands.pipeline_infer import infer_pipeline


class TestPipelineInference:
    """Tests for pipeline inference from operations."""

    def test_infer_single_operation(self) -> None:
        """Test inferring pipeline with single operation."""
        operations = [
            {
                "name": "clean_users",
                "inputs": ["raw_users"],
                "outputs": ["clean_users"],
            }
        ]

        pipeline = infer_pipeline(operations)

        assert pipeline["name"] == "auto_pipeline"
        assert len(pipeline["dag"]["steps"]) == 1
        assert pipeline["dag"]["steps"][0]["operation"] == "clean_users"

    def test_infer_chain_of_operations(self) -> None:
        """Test inferring pipeline with chained operations (A -> B -> C)."""
        operations = [
            {"name": "op_c", "inputs": ["data_b"], "outputs": ["data_c"]},
            {"name": "op_a", "inputs": ["raw"], "outputs": ["data_a"]},
            {"name": "op_b", "inputs": ["data_a"], "outputs": ["data_b"]},
        ]

        pipeline = infer_pipeline(operations)

        # Should be sorted: op_a -> op_b -> op_c
        steps = pipeline["dag"]["steps"]
        assert len(steps) == 3

        step_order = [s["operation"] for s in steps]
        assert step_order.index("op_a") < step_order.index("op_b")
        assert step_order.index("op_b") < step_order.index("op_c")

    def test_infer_parallel_operations(self) -> None:
        """Test inferring pipeline with parallel operations."""
        operations = [
            {"name": "op_a", "inputs": ["raw"], "outputs": ["data_a"]},
            {"name": "op_b", "inputs": ["raw"], "outputs": ["data_b"]},
        ]

        pipeline = infer_pipeline(operations)

        # Both can run independently
        assert len(pipeline["dag"]["steps"]) == 2

    def test_generates_valid_pipeline_structure(self) -> None:
        """Test that generated pipeline has valid AXM structure."""
        operations = [{"name": "transform", "inputs": ["input"], "outputs": ["output"]}]

        pipeline = infer_pipeline(operations)

        assert pipeline["axm"] == "1.0"
        assert pipeline["kind"] == "pipeline"
        assert "identity" in pipeline
        assert "dag" in pipeline
