"""Tests for axm add operation command."""

from pathlib import Path

from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


class TestAddOperationCommand:
    """Tests for axm add operation command."""

    def test_add_operation_creates_package_structure(self, tmp_path: Path) -> None:
        """Test that add operation creates the expected package structure."""
        import os

        # Arrange: init a project first
        result = runner.invoke(app, ["init", str(tmp_path / "my-project")])
        assert result.exit_code == 0

        project_path = tmp_path / "my-project"
        os.chdir(project_path)

        # Act: add an operation
        result = runner.invoke(
            app, ["add", "operation", "resize_image"], catch_exceptions=False
        )

        # Assert: package structure created
        op_dir = project_path / "operations" / "resize_image"
        assert op_dir.exists(), f"Expected {op_dir} to exist"
        assert (op_dir / "pyproject.toml").exists()
        assert (op_dir / "src" / "resize_image" / "__init__.py").exists()
        assert (op_dir / "src" / "resize_image" / "main.py").exists()

    def test_add_operation_pyproject_has_correct_name(self, tmp_path: Path) -> None:
        """Test that generated pyproject.toml has correct package name."""
        # Arrange
        runner.invoke(app, ["init", str(tmp_path / "test-proj")])
        project_path = tmp_path / "test-proj"

        # Act
        import os

        os.chdir(project_path)
        runner.invoke(app, ["add", "operation", "my_transform"])

        # Assert
        pyproject = project_path / "operations" / "my_transform" / "pyproject.toml"
        content = pyproject.read_text()
        assert 'name = "my_transform"' in content or "name = 'my_transform'" in content

    def test_add_operation_py_is_pure_function(self, tmp_path: Path) -> None:
        """Test that generated .py file is a pure function (no decorator)."""
        # Arrange
        runner.invoke(app, ["init", str(tmp_path / "proj")])
        project_path = tmp_path / "proj"

        # Act
        import os

        os.chdir(project_path)
        runner.invoke(app, ["add", "operation", "clean_data"])

        # Assert
        op_dir = project_path / "operations" / "clean_data"
        py_file = op_dir / "src" / "clean_data" / "main.py"
        content = py_file.read_text()
        assert "@operation" not in content  # No decorator
        assert "def clean_data" in content

    def test_add_operation_fails_if_already_exists(self, tmp_path: Path) -> None:
        """Test that add operation fails if operation already exists."""
        # Arrange
        runner.invoke(app, ["init", str(tmp_path / "proj")])
        project_path = tmp_path / "proj"

        import os

        os.chdir(project_path)
        runner.invoke(app, ["add", "operation", "my_op"])

        # Act: try to add again
        result = runner.invoke(app, ["add", "operation", "my_op"])

        # Assert
        assert result.exit_code != 0 or "already exists" in result.output.lower()

    def test_add_operation_fails_outside_axm_project(self, tmp_path: Path) -> None:
        """Test that add operation fails if not in an AXM project."""
        # Arrange: no axm.toml
        import os

        os.chdir(tmp_path)

        # Act
        result = runner.invoke(app, ["add", "operation", "some_op"])

        # Assert
        assert result.exit_code != 0 or "axm.toml" in result.output.lower()
