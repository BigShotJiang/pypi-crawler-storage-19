"""Tests for the axm run command."""

from pathlib import Path
from textwrap import dedent

import pytest
from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


@pytest.fixture
def sample_project(tmp_path: Path) -> Path:
    """Create a minimal project structure for testing."""
    # Create directories
    (tmp_path / "contracts" / "data").mkdir(parents=True)
    (tmp_path / "contracts" / "operations").mkdir(parents=True)
    (tmp_path / "contracts" / "pipelines").mkdir(parents=True)
    (tmp_path / "src").mkdir(parents=True)

    # Data contract
    (tmp_path / "contracts" / "data" / "message.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: message
        version: "1.0.0"
        identity:
          display_name: "Message"
          domain: "demo"
          owner: {team: "dev", contact: "dev@example.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "message"
    """)
    )

    # Operation contract
    (tmp_path / "contracts" / "operations" / "greet.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: operation
        name: greet
        version: "1.0.0"
        identity:
          display_name: "Greet"
          domain: "demo"
          owner: {team: "dev", contact: "dev@example.com"}
        spec:
          type: python_file
          source: "src/hello.py"
          entrypoint: "say_hello"
        inputs: []
        outputs:
          - name: message
            data_ref: message
            version: "1.0"
    """)
    )

    # Pipeline contract
    (tmp_path / "contracts" / "pipelines" / "hello.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: hello_pipeline
        version: "1.0.0"
        identity:
          display_name: "Hello Pipeline"
          domain: "demo"
          owner: {team: "dev", contact: "dev@example.com"}
        dag:
          steps:
            - id: greet
              operation: greet
    """)
    )

    # Python implementation
    (tmp_path / "src" / "hello.py").write_text(
        dedent("""\
        def say_hello(inputs: dict, parameters: dict) -> dict:
            return {"message": "Hello from AXM!"}
    """)
    )

    return tmp_path


def test_run_command_displays_panel(sample_project: Path) -> None:
    """Test that 'axm run' displays a run panel."""
    pipeline_path = sample_project / "contracts" / "pipelines" / "hello.axm"
    result = runner.invoke(app, ["run", str(pipeline_path)])

    assert "Running pipeline" in result.stdout or "AXM Run" in result.stdout


def test_run_command_requires_pipeline_path() -> None:
    """Test that 'axm run' requires a pipeline path argument."""
    result = runner.invoke(app, ["run"])
    assert result.exit_code != 0


def test_run_command_fails_on_missing_file(tmp_path: Path) -> None:
    """Test that 'axm run' fails gracefully on missing file."""
    result = runner.invoke(app, ["run", str(tmp_path / "nonexistent.axm")])
    assert result.exit_code != 0


def test_run_command_pipeline_not_found(tmp_path: Path) -> None:
    """Test that 'axm run' fails when pipeline is not in catalog."""
    # Create minimal catalog with only data entry (no pipeline)
    (tmp_path / "data").mkdir()
    (tmp_path / "data" / "users.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: users
        version: "1.0.0"
        identity:
          display_name: "Users"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "users"
    """)
    )

    # Create empty pipeline file (will fail to parse as pipeline)
    (tmp_path / "pipelines").mkdir()
    pipeline_file = tmp_path / "pipelines" / "missing.axm"
    pipeline_file.write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: not_a_pipeline
        version: "1.0.0"
        identity:
          display_name: "Not a Pipeline"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "data"
    """)
    )

    result = runner.invoke(app, ["run", str(pipeline_file)])
    assert result.exit_code == 1
    assert "not found" in result.stdout.lower() or result.exit_code != 0


def test_run_command_successful_execution(sample_project: Path) -> None:
    """Test successful pipeline execution displays outputs."""
    pipeline_path = sample_project / "contracts" / "pipelines" / "hello.axm"
    result = runner.invoke(app, ["run", str(pipeline_path)])

    # Pipeline should complete (may succeed or fail depending on env)
    # But should show "Executing" message
    assert "Executing" in result.stdout or "Pipeline" in result.stdout


def test_run_command_catalog_load_failure(tmp_path: Path) -> None:
    """Test that 'axm run' fails when catalog cannot be loaded."""
    # Create a pipeline file but no valid contracts directory
    pipeline_file = tmp_path / "invalid.axm"
    pipeline_file.write_text("invalid yaml: :")

    result = runner.invoke(app, ["run", str(pipeline_file)])
    # Should fail with exit code 1 due to catalog load error
    assert result.exit_code != 0


def test_run_command_with_parent_contracts_dir(tmp_path: Path) -> None:
    """Test that catalog is loaded from parent directory of pipeline file."""
    # Create contracts/pipelines structure
    pipelines_dir = tmp_path / "contracts" / "pipelines"
    pipelines_dir.mkdir(parents=True)

    # Create a data contract in parent
    data_dir = tmp_path / "contracts" / "data"
    data_dir.mkdir(parents=True)
    (data_dir / "sample.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: sample
        version: "1.0.0"
        identity:
          display_name: "Sample"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "sample"
    """)
    )

    # Create a pipeline
    (pipelines_dir / "test_pipe.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: test_pipe
        version: "1.0.0"
        identity:
          display_name: "Test"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        dag:
          steps: []
    """)
    )

    result = runner.invoke(app, ["run", str(pipelines_dir / "test_pipe.axm")])
    # Should load catalog from contracts/ (parent of pipelines/)
    assert "Loaded" in result.stdout or "entries" in result.stdout.lower()


def test_run_command_execution_failure(tmp_path: Path) -> None:
    """Test that pipeline execution failure is reported correctly."""
    # Create a pipeline that will fail during execution
    contracts_dir = tmp_path / "contracts"
    (contracts_dir / "operations").mkdir(parents=True)
    (contracts_dir / "pipelines").mkdir(parents=True)

    # Operation that references a missing file
    (contracts_dir / "operations" / "broken.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: operation
        name: broken_op
        version: "1.0.0"
        identity:
          display_name: "Broken"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        spec:
          type: python_file
          source: "missing_file.py"
          entrypoint: "missing_func"
    """)
    )

    # Pipeline referencing the broken operation
    (contracts_dir / "pipelines" / "fail_pipe.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: fail_pipe
        version: "1.0.0"
        identity:
          display_name: "Failing Pipeline"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        dag:
          steps:
            - id: step1
              operation: broken_op
    """)
    )

    result = runner.invoke(
        app, ["run", str(contracts_dir / "pipelines" / "fail_pipe.axm")]
    )
    # Should fail with exit code 1
    assert result.exit_code == 1


def test_run_command_pipeline_fallback_match(tmp_path: Path) -> None:
    """Test that fallback matching works when pipeline name doesn't match."""
    contracts_dir = tmp_path / "contracts"
    pipelines_dir = contracts_dir / "pipelines"
    pipelines_dir.mkdir(parents=True)

    # Pipeline with a different name than the filename
    (pipelines_dir / "different_name.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: actual_pipeline_name
        version: "1.0.0"
        identity:
          display_name: "Different Name Pipeline"
          domain: "test"
          owner: {team: "t", contact: "t@t.com"}
        dag:
          steps: []
    """)
    )

    result = runner.invoke(app, ["run", str(pipelines_dir / "different_name.axm")])
    # Should use fallback matching (any PipelineEntry)
    # The pipeline has no steps so it should complete successfully
    # But only if found in catalog - check for pipeline found or not found message
    assert result.exit_code == 0 or "not found" in result.stdout.lower()
