"""Tests for axm check logic verification (cycles, references)."""

from pathlib import Path
from textwrap import dedent

import pytest
from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


@pytest.fixture
def valid_project(tmp_path: Path) -> Path:
    """Create a valid project with matching references."""
    (tmp_path / "contracts" / "data").mkdir(parents=True)
    (tmp_path / "contracts" / "operations").mkdir(parents=True)
    (tmp_path / "contracts" / "pipelines").mkdir(parents=True)

    # Data entry
    (tmp_path / "contracts" / "data" / "users.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: data
        name: users
        version: "1.0.0"
        identity:
          display_name: "Users"
          description: "Test data entry"
          domain: "demo"
          owner: {team: "dev", contact: "dev@ex.com"}
        schema:
          format: json
          spec: {}
        location:
          storage: memory
          path_template: "users"
    """)
    )

    # Operation entry
    (tmp_path / "contracts" / "operations" / "process.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: operation
        name: process_users
        version: "1.0.0"
        identity:
          display_name: "Process Users"
          description: "Test operation"
          domain: "demo"
          owner: {team: "dev", contact: "dev@ex.com"}
        spec:
          type: python_file
          source: "demo.py"
          entrypoint: "process"
        inputs:
          - name: input
            data_ref: users
            version: "*"
        outputs: []
    """)
    )

    # Valid pipeline
    (tmp_path / "contracts" / "pipelines" / "valid.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: valid_pipeline
        version: "1.0.0"
        identity:
          display_name: "Valid Pipeline"
          description: "Test pipeline"
          domain: "demo"
          owner: {team: "dev", contact: "dev@ex.com"}
        dag:
          steps:
            - id: step1
              operation: process_users
    """)
    )

    return tmp_path


@pytest.fixture
def project_with_missing_operation(tmp_path: Path) -> Path:
    """Create a project with a pipeline referencing non-existent operation."""
    (tmp_path / "contracts" / "pipelines").mkdir(parents=True)

    (tmp_path / "contracts" / "pipelines" / "broken.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: broken_pipeline
        version: "1.0.0"
        identity:
          display_name: "Broken Pipeline"
          description: "Pipeline with missing op ref"
          domain: "demo"
          owner: {team: "dev", contact: "dev@ex.com"}
        dag:
          steps:
            - id: step1
              operation: nonexistent_operation
    """)
    )

    return tmp_path


@pytest.fixture
def project_with_cycle(tmp_path: Path) -> Path:
    """Create a project with a cyclic dependency in pipeline."""
    (tmp_path / "contracts" / "operations").mkdir(parents=True)
    (tmp_path / "contracts" / "pipelines").mkdir(parents=True)

    # Operations
    (tmp_path / "contracts" / "operations" / "op_a.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: operation
        name: op_a
        version: "1.0.0"
        identity:
          display_name: "Op A"
          description: "Operation A"
          domain: "demo"
          owner: {team: "dev", contact: "dev@ex.com"}
        spec:
          type: python_file
          source: "demo.py"
          entrypoint: "op_a"
    """)
    )

    (tmp_path / "contracts" / "operations" / "op_b.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: operation
        name: op_b
        version: "1.0.0"
        identity:
          display_name: "Op B"
          description: "Operation B"
          domain: "demo"
          owner: {team: "dev", contact: "dev@ex.com"}
        spec:
          type: python_file
          source: "demo.py"
          entrypoint: "op_b"
    """)
    )

    # Pipeline with cycle
    (tmp_path / "contracts" / "pipelines" / "cyclic.axm").write_text(
        dedent("""\
        axm: "1.0"
        kind: pipeline
        name: cyclic_pipeline
        version: "1.0.0"
        identity:
          display_name: "Cyclic Pipeline"
          description: "Pipeline with cycle"
          domain: "demo"
          owner: {team: "dev", contact: "dev@ex.com"}
        dag:
          steps:
            - id: step_a
              operation: op_a
              dependencies: [step_b]
            - id: step_b
              operation: op_b
              dependencies: [step_a]
    """)
    )

    return tmp_path


def test_check_valid_project_passes(valid_project: Path) -> None:
    """Test that check passes for a valid project."""
    result = runner.invoke(app, ["check", str(valid_project / "contracts")])
    assert result.exit_code == 0
    assert "valid" in result.stdout.lower() or "✓" in result.stdout


def test_check_detects_missing_operation(project_with_missing_operation: Path) -> None:
    """Test that check fails when pipeline references non-existent operation."""
    result = runner.invoke(
        app, ["check", str(project_with_missing_operation / "contracts")]
    )
    assert result.exit_code == 1
    assert "nonexistent_operation" in result.stdout or "not found" in result.stdout


def test_check_detects_cycle(project_with_cycle: Path) -> None:
    """Test that check fails when pipeline has cyclic dependencies."""
    result = runner.invoke(app, ["check", str(project_with_cycle / "contracts")])
    assert result.exit_code == 1
    assert "cycle" in result.stdout.lower() or "invalid" in result.stdout.lower()
