"""Tests for the axm init command with multi-package operations structure."""

from pathlib import Path

from typer.testing import CliRunner

from axm_cli.main import app

runner = CliRunner()


def test_init_creates_directory_structure(tmp_path: Path) -> None:
    """Test that 'axm init' creates multi-package directory structure."""
    result = runner.invoke(app, ["init", str(tmp_path)])
    assert result.exit_code == 0
    assert "Initializing AXM project" in result.stdout

    # Core directories (multi-package structure)
    assert (tmp_path / "operations").is_dir()
    assert (tmp_path / "data").is_dir()
    assert (tmp_path / "pipelines").is_dir()
    assert (tmp_path / "schemas").is_dir()
    assert (tmp_path / ".vscode").is_dir()


def test_init_creates_workspace_pyproject(tmp_path: Path) -> None:
    """Test that 'axm init' creates workspace pyproject.toml."""
    runner.invoke(app, ["init", str(tmp_path)])

    pyproject = tmp_path / "pyproject.toml"
    assert pyproject.exists()

    content = pyproject.read_text()
    assert "[tool.uv.workspace]" in content
    assert "operations/*" in content


def test_init_creates_config_files(tmp_path: Path) -> None:
    """Test that 'axm init' creates configuration files."""
    runner.invoke(app, ["init", str(tmp_path)])

    assert (tmp_path / "axm.toml").exists()
    assert (tmp_path / "pyproject.toml").exists()
    assert (tmp_path / "README.md").exists()
    assert (tmp_path / ".gitignore").exists()
    assert (tmp_path / ".vscode" / "settings.json").exists()
    assert (tmp_path / "schemas" / "axm.schema.json").exists()


def test_init_creates_sample_operation_as_package(tmp_path: Path) -> None:
    """Test that sample operation is created as micro-package."""
    runner.invoke(app, ["init", str(tmp_path)])

    # Operation as package structure with src layout
    op_dir = tmp_path / "operations" / "clean_users"
    assert op_dir.is_dir()
    assert (op_dir / "pyproject.toml").exists()
    assert (op_dir / "src" / "clean_users" / "__init__.py").exists()
    assert (op_dir / "src" / "clean_users" / "main.py").exists()


def test_init_sample_operation_is_pure_function(tmp_path: Path) -> None:
    """Test that sample operation is a pure function (no decorator)."""
    runner.invoke(app, ["init", str(tmp_path)])

    op_dir = tmp_path / "operations" / "clean_users"
    main_py = op_dir / "src" / "clean_users" / "main.py"
    content = main_py.read_text()
    assert "@operation" not in content  # No decorator
    assert "def clean_users" in content


def test_init_creates_colocated_data(tmp_path: Path) -> None:
    """Test that data file and .axm are side by side."""
    runner.invoke(app, ["init", str(tmp_path)])

    # Colocated: raw_users.csv + raw_users.axm
    assert (tmp_path / "data" / "raw_users.csv").exists()
    assert (tmp_path / "data" / "raw_users.axm").exists()


def test_init_creates_pipeline(tmp_path: Path) -> None:
    """Test that pipeline is in dedicated folder."""
    runner.invoke(app, ["init", str(tmp_path)])

    assert (tmp_path / "pipelines" / "daily_etl.axm").exists()


def test_init_data_contract_structure(tmp_path: Path) -> None:
    """Test data contract follows AXM schema."""
    runner.invoke(app, ["init", str(tmp_path)])

    content = (tmp_path / "data" / "raw_users.axm").read_text()
    assert 'axm: "1.0"' in content
    assert "kind: data" in content
    assert "schema:" in content
    assert "location:" in content


def test_init_pipeline_contract_structure(tmp_path: Path) -> None:
    """Test pipeline contract follows AXM schema."""
    runner.invoke(app, ["init", str(tmp_path)])

    content = (tmp_path / "pipelines" / "daily_etl.axm").read_text()
    assert 'axm: "1.0"' in content
    assert "kind: pipeline" in content
    assert "dag:" in content
    assert "steps:" in content
