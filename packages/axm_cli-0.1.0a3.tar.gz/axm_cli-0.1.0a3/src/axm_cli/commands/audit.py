"""Audit command - Run data quality checks on data files."""

from pathlib import Path
from typing import TYPE_CHECKING, Annotated

import typer
from rich.console import Console
from rich.table import Table

if TYPE_CHECKING:
    from axm.catalog.rules.engine import DataQualityReport

console = Console()


def audit_file(
    data_path: Annotated[
        Path,
        typer.Argument(
            help="Path to data file (parquet, csv, json)",
            exists=True,
        ),
    ],
    contract: Annotated[
        Path | None,
        typer.Option(
            "--contract",
            "-c",
            help="Path to .axm contract file with schema rules",
        ),
    ] = None,
    format: Annotated[
        str,
        typer.Option(
            "--format",
            "-f",
            help="Output format: table, json, markdown",
        ),
    ] = "table",
) -> None:
    """Run data quality audit on a data file.

    Validates data against rules defined in the contract.

    Examples:
        axm audit data.parquet --contract users.axm
        axm audit sales.csv --format json
    """
    import polars as pl
    import yaml

    from axm.catalog.entries.column import Column, ColumnRuleConfig, TabularSchema
    from axm.catalog.rules.engine import RuleEngine

    # Load data based on file extension
    suffix = data_path.suffix.lower()
    try:
        if suffix == ".parquet":
            df = pl.read_parquet(data_path)
        elif suffix == ".csv":
            df = pl.read_csv(data_path)
        elif suffix == ".json":
            df = pl.read_json(data_path)
        else:
            console.print(f"[red]Unsupported file format: {suffix}[/red]")
            raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[red]Error loading data: {e}[/red]")
        raise typer.Exit(code=1) from None

    console.print(f"[blue]Loaded {len(df):,} rows from {data_path.name}[/blue]")

    # Load contract if provided
    if contract:
        try:
            with open(contract) as f:
                contract_data = yaml.safe_load(f)

            # Parse columns with rules
            columns = []
            schema_spec = contract_data.get("schema", {})
            for col_spec in schema_spec.get("columns", []):
                rules = []
                for rule_spec in col_spec.get("rules", []):
                    rules.append(ColumnRuleConfig(**rule_spec))
                columns.append(
                    Column(
                        name=col_spec["name"],
                        type=col_spec.get("type", "string"),
                        rules=rules,
                    )
                )
            schema = TabularSchema(columns=columns)
        except Exception as e:
            console.print(f"[red]Error loading contract: {e}[/red]")
            raise typer.Exit(code=1) from None
    else:
        console.print("[yellow]No contract provided. Running basic checks.[/yellow]")
        schema = TabularSchema(columns=[])

    # Run validation with timing for auditor
    import time

    from axm_audit import auditor

    engine = RuleEngine()
    start = time.perf_counter_ns()
    report = engine.validate(df, schema)
    duration_ns = time.perf_counter_ns() - start

    # Record in global auditor
    auditor.on_quality_check(report, duration_ns)

    # Output results
    if format == "table":
        _print_table(report)
    elif format == "json":
        import json

        console.print(json.dumps(report.model_dump(), indent=2, default=str))
    elif format == "markdown":
        _print_markdown(report)

    # Exit with error if validation failed
    if report.has_errors:
        console.print("\n[red]❌ Data quality check FAILED[/red]")
        raise typer.Exit(code=1)
    else:
        console.print("\n[green]✅ Data quality check PASSED[/green]")


def _print_table(report: "DataQualityReport") -> None:
    """Print report as rich table."""

    table = Table(title="Data Quality Report")
    table.add_column("Column", style="cyan")
    table.add_column("Rule", style="magenta")
    table.add_column("Violations", justify="right")
    table.add_column("Threshold", justify="right")
    table.add_column("Status", justify="center")

    for result in report.results:
        if result.passed:
            status = "[green]✅[/green]"
        elif result.severity.value == "error":
            status = "[red]❌[/red]"
        else:
            status = "[yellow]⚠️[/yellow]"
        table.add_row(
            result.column,
            result.rule,
            f"{result.violations} ({result.violation_percent:.1%})",
            f"{result.threshold:.1%}",
            status,
        )

    console.print(table)


def _print_markdown(report: "DataQualityReport") -> None:
    """Print report as markdown."""

    console.print("# Data Quality Report\n")
    console.print("| Column | Rule | Violations | Status |")
    console.print("|--------|------|------------|--------|")
    for result in report.results:
        status = "✅" if result.passed else "❌"
        console.print(
            f"| {result.column} | {result.rule} | "
            f"{result.violations} ({result.violation_percent:.1%}) | {status} |"
        )


def audit_report(
    format: Annotated[
        str,
        typer.Option(
            "--format",
            "-f",
            help="Output format: table, json",
        ),
    ] = "table",
) -> None:
    """Display accumulated audit metrics.

    Shows Trust Tax metrics and quality check statistics.

    Examples:
        axm audit report
        axm audit report --format json
    """
    import json as json_module

    from axm_audit import auditor

    m = auditor.metrics

    if format == "json":
        data = {
            "total_validations": m.total_validations,
            "total_duration_ms": m.total_ms,
            "quality_checks": m.quality_checks,
            "quality_violations": m.quality_violations,
            "function_calls": m.function_calls,
            "function_duration_ms": m.function_duration_ns / 1_000_000,
        }
        console.print(json_module.dumps(data, indent=2))
    else:
        table = Table(title="Audit Metrics Report")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right", style="green")

        table.add_row("Total Validations", str(m.total_validations))
        table.add_row("Validation Time", f"{m.total_ms:.2f} ms")
        table.add_row("Quality Checks", str(m.quality_checks))
        table.add_row("Quality Violations", str(m.quality_violations))
        table.add_row("Function Calls", str(m.function_calls))
        table.add_row("Function Time", f"{m.function_duration_ns / 1_000_000:.2f} ms")

        console.print(table)
