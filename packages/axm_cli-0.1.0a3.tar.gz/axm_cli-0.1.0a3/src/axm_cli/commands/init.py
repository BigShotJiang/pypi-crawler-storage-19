"""AXM Init command - Initialize a new AXM project structure."""

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel

console = Console()


# ═══════════════════════════════════════════════════════════════════════════════
# TEMPLATE: Project Configuration
# ═══════════════════════════════════════════════════════════════════════════════

AXM_TOML = """\
[project]
name = "{name}"
version = "0.1.0"

[axm]
schema_version = "1.0"
"""

WORKSPACE_PYPROJECT = """\
# AXM Workspace Root (managed by uv)

[tool.uv.workspace]
members = ["operations/*"]

[dependency-groups]
dev = [
    "pytest>=8.0",
    "ruff>=0.14",
]
"""

GITIGNORE = """\
# AXM
.axm_cache/

# Python
__pycache__/
*.py[cod]
.venv/
.DS_Store
uv.lock
"""

VSCODE_SETTINGS = """\
{{
  "files.associations": {{
    "*.axm": "yaml"
  }},
  "yaml.schemas": {{
    "./schemas/axm.schema.json": "**/*.axm"
  }}
}}
"""

AXM_SCHEMA = """\
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "AXM Contract",
  "type": "object",
  "properties": {
    "axm": { "type": "string", "description": "Schema version" },
    "kind": { "type": "string", "enum": ["data", "operation", "pipeline"] },
    "name": { "type": "string" },
    "version": { "type": "string" },
    "identity": {
      "type": "object",
      "properties": {
        "display_name": { "type": "string" },
        "description": { "type": "string" },
        "domain": { "type": "string" },
        "owner": {
          "type": "object",
          "properties": {
            "team": { "type": "string" },
            "contact": { "type": "string" }
          }
        }
      }
    },
    "schema": { "type": "object" },
    "location": { "type": "object" },
    "spec": { "type": "object" },
    "dag": { "type": "object" }
  },
  "required": ["axm", "kind", "name", "version", "identity"]
}
"""

# ═══════════════════════════════════════════════════════════════════════════════
# TEMPLATE: Sample Operation (micro-package)
# ═══════════════════════════════════════════════════════════════════════════════

OPERATION_PYPROJECT = """\
[project]
name = "clean_users"
version = "0.1.0"
description = "AXM Operation: Clean Users"
requires-python = ">=3.12"
dependencies = []

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
"""

SAMPLE_OPERATION_INIT = '''\
"""Sample operation: clean users data."""

from .main import clean_users

__all__ = ["clean_users"]
'''

SAMPLE_OPERATION_MAIN = '''\
"""Sample operation: clean users data."""


def clean_users(inputs: dict, parameters: dict) -> dict:
    """Clean and normalize user data.

    Args:
        inputs: Dictionary with input data (e.g., DataFrames).
        parameters: Runtime parameters.

    Returns:
        Dictionary with output data.
    """
    # TODO: Implement operation logic
    return {"clean_users": "processed_data"}
'''

# ═══════════════════════════════════════════════════════════════════════════════
# TEMPLATE: Sample Data
# ═══════════════════════════════════════════════════════════════════════════════

SAMPLE_DATA_CSV = """\
id,name,email,score
1,Alice,alice@example.com,0.85
2,Bob,bob@example.com,0.42
3,Charlie,charlie@example.com,0.91
"""

SAMPLE_DATA_AXM = """\
axm: "1.0"
kind: data
name: raw_users
version: "1.0.0"

identity:
  display_name: "Raw Users"
  description: "Raw user data from source system."
  domain: "demo"
  owner:
    team: "data-team"
    contact: "data@example.com"

schema:
  format: tabular
  spec:
    columns:
      - name: id
        type: integer
        nullable: false
      - name: name
        type: string
        nullable: false
      - name: email
        type: string
        nullable: true
      - name: score
        type: float
        nullable: true

location:
  storage: file
  path_template: "data/raw_users.csv"
"""

# ═══════════════════════════════════════════════════════════════════════════════
# TEMPLATE: Sample Pipeline
# ═══════════════════════════════════════════════════════════════════════════════

SAMPLE_PIPELINE_AXM = """\
axm: "1.0"
kind: pipeline
name: daily_etl
version: "1.0.0"

identity:
  display_name: "Daily ETL"
  description: "Daily data processing pipeline."
  domain: "demo"
  owner:
    team: "data-team"
    contact: "data@example.com"

inputs:
  - name: raw_users
    data_ref: raw_users

dag:
  steps:
    - id: clean
      operation: clean_users

execution:
  timeout_seconds: 3600
  retry_policy:
    max_retries: 2
"""

# ═══════════════════════════════════════════════════════════════════════════════
# TEMPLATE: README
# ═══════════════════════════════════════════════════════════════════════════════

README_MD = """\
# {name}

AXM-powered data project with isolated operations.

## Structure

```
{name}/
├── operations/             # Operations as micro-packages
│   └── clean_users/        # Each operation = 1 package
│       ├── pyproject.toml  # Isolated dependencies
│       └── clean_users.py  # Implementation with @operation
├── data/                   # Data files + contracts
│   ├── raw_users.csv
│   └── raw_users.axm
├── pipelines/              # Pipeline definitions
│   └── daily_etl.axm
├── pyproject.toml          # Workspace configuration
└── axm.toml                # Project config
```

## Commands

```bash
# Validate contracts
axm check .

# Add a new operation
axm add operation my_transform

# Discover and generate contracts
axm discover operations/

# Run a pipeline
axm run pipelines/daily_etl.axm
```
"""


def init(
    path: Annotated[
        Path,
        typer.Argument(
            help="Directory to initialize the project in", show_default=True
        ),
    ],
) -> None:
    """Initialize a new AXM project with micro-package operations."""
    console.print(
        Panel(
            f"Initializing AXM project in [bold cyan]{path}[/bold cyan]",
            title="AXM Init",
            expand=False,
        )
    )

    path = Path(path)
    project_name = path.name

    # Create directories (multi-package structure)
    directories = [
        path / "operations" / "clean_users" / "src" / "clean_users",  # Sample operation
        path / "data",
        path / "pipelines",
        path / "schemas",
        path / ".vscode",
    ]
    for d in directories:
        d.mkdir(parents=True, exist_ok=True)
        console.print(f"  [dim]Created[/dim] {d.relative_to(path.parent)}/")

    # Write config files
    # Build paths (avoid long lines)
    op_src = path / "operations" / "clean_users" / "src" / "clean_users"

    files = {
        # Root config
        path / "axm.toml": AXM_TOML.format(name=project_name),
        path / "pyproject.toml": WORKSPACE_PYPROJECT,
        path / ".gitignore": GITIGNORE,
        path / ".vscode" / "settings.json": VSCODE_SETTINGS,
        path / "schemas" / "axm.schema.json": AXM_SCHEMA,
        path / "README.md": README_MD.format(name=project_name),
        # Sample operation as micro-package with src layout
        path / "operations" / "clean_users" / "pyproject.toml": OPERATION_PYPROJECT,
        op_src / "__init__.py": SAMPLE_OPERATION_INIT,
        op_src / "main.py": SAMPLE_OPERATION_MAIN,
        # Data with colocated contract
        path / "data" / "raw_users.csv": SAMPLE_DATA_CSV,
        path / "data" / "raw_users.axm": SAMPLE_DATA_AXM,
        # Pipeline
        path / "pipelines" / "daily_etl.axm": SAMPLE_PIPELINE_AXM,
    }

    for filepath, content in files.items():
        filepath.write_text(content)
        console.print(f"  [green]✓[/green] {filepath.relative_to(path.parent)}")

    console.print(
        Panel(
            f"[bold green]✨ Project '{project_name}' initialized![/bold green]\n\n"
            f"[dim]Next steps:[/dim]\n"
            f"  cd {project_name}\n"
            f"  axm add operation my_transform\n"
            f"  axm check .",
            title="Success",
            expand=False,
        )
    )
