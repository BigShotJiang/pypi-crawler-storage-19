"""Schema inference from data files.

Provides utilities to infer AXM schemas from data files like CSV and Parquet.
"""

from collections.abc import Iterator
from pathlib import Path
from typing import Any

import polars as pl

# Polars dtype to AXM type mapping
DTYPE_MAP: dict[str, str] = {
    "Int8": "integer",
    "Int16": "integer",
    "Int32": "integer",
    "Int64": "integer",
    "UInt8": "integer",
    "UInt16": "integer",
    "UInt32": "integer",
    "UInt64": "integer",
    "Float32": "float",
    "Float64": "float",
    "Boolean": "boolean",
    "String": "string",
    "Utf8": "string",
    "Date": "date",
    "Datetime": "datetime",
    "Time": "time",
    "Null": "string",  # Default fallback
}


def infer_tabular_schema(file_path: Path) -> dict[str, Any]:
    """Infer tabular schema from a data file.

    Reads the file and extracts column names and types using Polars.

    Args:
        file_path: Path to the data file (CSV, Parquet).

    Returns:
        Schema dictionary with 'columns' list containing
        {name, type, nullable} for each column.
    """
    # Read file based on extension
    suffix = file_path.suffix.lower()
    if suffix == ".csv":
        df = pl.read_csv(file_path, n_rows=100)
    elif suffix == ".parquet":
        df = pl.read_parquet(file_path, n_rows=100)
    else:
        raise ValueError(f"Unsupported file format: {suffix}")

    columns = []
    for col_name in df.columns:
        dtype_str = str(df[col_name].dtype)
        axm_type = DTYPE_MAP.get(dtype_str, "string")
        columns.append({"name": col_name, "type": axm_type, "nullable": True})

    return {"format": "tabular", "columns": columns}


def discover_data(path: Path) -> Iterator[dict[str, Any]]:
    """Discover data files and generate contract metadata.

    Scans a directory for data files (CSV, Parquet) and generates
    AXM contract metadata for each.

    Args:
        path: Directory to scan for data files.

    Yields:
        Contract metadata dictionaries for each discovered file.
    """
    for file_path in path.rglob("*.csv"):
        yield _generate_data_contract(file_path)

    for file_path in path.rglob("*.parquet"):
        yield _generate_data_contract(file_path)


def _generate_data_contract(file_path: Path) -> dict[str, Any]:
    """Generate contract metadata for a data file.

    Args:
        file_path: Path to the data file.

    Returns:
        Contract metadata dictionary.
    """
    name = file_path.stem
    schema = infer_tabular_schema(file_path)

    return {
        "axm": "1.0",
        "kind": "data",
        "name": name,
        "version": "1.0.0",
        "identity": {
            "display_name": name.replace("_", " ").title(),
            "description": f"Auto-discovered from {file_path.name}",
            "domain": "default",
            "owner": {"team": "dev", "contact": "dev@example.com"},
        },
        "schema": schema,
        "location": {
            "storage": "file",
            "path_template": str(file_path),
        },
    }


def generate_data_contract_yaml(contract: dict[str, Any]) -> str:
    """Generate YAML content for a data contract.

    Args:
        contract: Contract metadata dictionary.

    Returns:
        YAML-formatted contract string.
    """
    columns_yaml = ""
    for col in contract["schema"]["columns"]:
        columns_yaml += f"""
      - name: {col["name"]}
        type: {col["type"]}
        nullable: {str(col["nullable"]).lower()}"""

    return f"""axm: "1.0"
kind: data
name: {contract["name"]}
version: "{contract["version"]}"

identity:
  display_name: "{contract["identity"]["display_name"]}"
  description: "{contract["identity"]["description"]}"
  domain: "{contract["identity"]["domain"]}"
  owner:
    team: "{contract["identity"]["owner"]["team"]}"
    contact: "{contract["identity"]["owner"]["contact"]}"

schema:
  format: {contract["schema"]["format"]}
  spec:
    columns:{columns_yaml}

location:
  storage: {contract["location"]["storage"]}
  path_template: "{contract["location"]["path_template"]}"
"""
