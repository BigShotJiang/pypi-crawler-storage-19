"""AXM Add Operation command - Create a new operation as micro-package."""

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel

console = Console()

# ═══════════════════════════════════════════════════════════════════════════════
# TEMPLATES
# ═══════════════════════════════════════════════════════════════════════════════

OPERATION_PYPROJECT = """\
[project]
name = "{name}"
version = "0.1.0"
description = "AXM Operation: {display_name}"
requires-python = ">=3.12"
dependencies = []

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
"""

OPERATION_INIT = '''\
"""AXM Operation: {display_name}."""

from .main import {name}

__all__ = ["{name}"]
'''

OPERATION_MAIN = '''\
"""AXM Operation: {display_name}."""


def {name}(inputs: dict, parameters: dict) -> dict:
    """Execute the {display_name} operation.

    Args:
        inputs: Dictionary with input data (e.g., DataFrames).
        parameters: Runtime parameters.

    Returns:
        Dictionary with output data.
    """
    # TODO: Implement operation logic
    return {{}}
'''


def find_project_root() -> Path | None:
    """Find the AXM project root by looking for axm.toml."""
    current = Path.cwd()
    for parent in [current, *current.parents]:
        if (parent / "axm.toml").exists():
            return parent
    return None


def add_operation(
    name: Annotated[
        str,
        typer.Argument(help="Name of the operation (snake_case)"),
    ],
) -> None:
    """Add a new operation as an isolated micro-package."""
    # Check we're in an AXM project
    project_root = find_project_root()
    if project_root is None:
        console.print("[red]Error: Not in an AXM project. No axm.toml found.[/red]")
        raise typer.Exit(1)

    # Create operations directory if needed
    operations_dir = project_root / "operations"
    operations_dir.mkdir(exist_ok=True)

    # Check if operation already exists
    op_dir = operations_dir / name
    if op_dir.exists():
        console.print(f"[red]Error: Operation '{name}' already exists.[/red]")
        raise typer.Exit(1)

    # Create operation package with src layout
    op_dir.mkdir(parents=True)
    src_pkg_dir = op_dir / "src" / name
    src_pkg_dir.mkdir(parents=True)

    display_name = name.replace("_", " ").title()

    # Write pyproject.toml
    pyproject_path = op_dir / "pyproject.toml"
    pyproject_path.write_text(
        OPERATION_PYPROJECT.format(name=name, display_name=display_name)
    )

    # Write __init__.py
    init_path = src_pkg_dir / "__init__.py"
    init_path.write_text(OPERATION_INIT.format(name=name, display_name=display_name))

    # Write main.py
    main_path = src_pkg_dir / "main.py"
    main_path.write_text(OPERATION_MAIN.format(name=name, display_name=display_name))

    console.print(
        Panel(
            f"[green]✓[/green] Created operation [bold cyan]{name}[/bold cyan]\n\n"
            f"[dim]Files created:[/dim]\n"
            f"  • operations/{name}/pyproject.toml\n"
            f"  • operations/{name}/src/{name}/__init__.py\n"
            f"  • operations/{name}/src/{name}/main.py\n\n"
            f"[dim]Next steps:[/dim]\n"
            f"  1. Edit operations/{name}/src/{name}/main.py\n"
            f"  2. Add dependencies to pyproject.toml\n"
            f"  3. Run: axm discover operations/{name}",
            title="Operation Created",
            expand=False,
        )
    )
