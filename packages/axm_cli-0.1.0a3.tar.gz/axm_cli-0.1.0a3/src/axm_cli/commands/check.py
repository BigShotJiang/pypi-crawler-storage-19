"""AXM Check command - Validate contracts."""

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel

from axm.catalog.entries import OperationEntry, PipelineEntry
from axm.catalog.loading.catalog import DataCatalog
from axm_engine.context import RuntimeContext
from axm_engine.planning import PipelinePlanner

console = Console()


class ValidationError(Exception):
    """Custom error for validation failures."""

    pass


def validate_pipeline_references(
    pipeline: PipelineEntry, catalog: DataCatalog
) -> list[str]:
    """Validate that all pipeline references exist in the catalog.

    Returns:
        List of error messages (empty if valid).
    """
    errors: list[str] = []
    operation_names = {e.name for e in catalog if isinstance(e, OperationEntry)}

    for step in pipeline.dag.steps:
        if step.operation not in operation_names:
            errors.append(
                f"Step '{step.id}': operation '{step.operation}' not found in catalog"
            )

    return errors


def check(
    path: Annotated[
        Path,
        typer.Argument(
            exists=False,
            help="Path to the directory containing .axm contracts",
            show_default=True,
        ),
    ] = Path("."),
) -> None:
    """Validate all .axm contracts in the specified directory."""
    console.print(
        Panel(
            f"Checking contracts in [bold cyan]{path}[/bold cyan]",
            title="AXM Checker",
            expand=False,
        )
    )

    # 1. Load Catalog
    try:
        catalog = DataCatalog.from_directory(path)
    except Exception as e:
        console.print(f"[bold red]❌ Failed to load catalog:[/bold red] {e}")
        raise typer.Exit(code=1) from None

    console.print(f"[dim]Found {len(catalog)} entries loaded.[/dim]")

    # 2. Find pipelines
    pipelines = [e for e in catalog if isinstance(e, PipelineEntry)]

    if not pipelines:
        console.print("[yellow]⚠️  No pipelines found to check.[/yellow]")
        return

    # 3. Validate each pipeline
    context = RuntimeContext()
    context.set_catalog(catalog)
    planner = PipelinePlanner(context)

    has_errors = False
    for pipe in pipelines:
        pipe_errors: list[str] = []

        # Check 1: Reference validation
        ref_errors = validate_pipeline_references(pipe, catalog)
        pipe_errors.extend(ref_errors)

        # Check 2: DAG validation (cycles + operation resolution)
        if not ref_errors:
            try:
                planner.plan(pipe)
            except ValueError as e:
                # Cycle detected
                pipe_errors.append(f"DAG error: {e}")
            except KeyError as e:
                # Missing operation (should be caught by ref check)
                pipe_errors.append(f"Missing reference: {e}")
            except Exception as e:
                pipe_errors.append(f"Unexpected error: {e}")

        # Report results
        if pipe_errors:
            console.print(f"[bold red]❌ Pipeline '{pipe.name}' invalid:[/bold red]")
            for err in pipe_errors:
                console.print(f"   • {err}")
            has_errors = True
        else:
            console.print(f"[green]✓ Pipeline '{pipe.name}' is valid[/green]")

    if has_errors:
        raise typer.Exit(code=1)

    console.print("\n[bold green]✨ All contracts are valid![/bold green]")
