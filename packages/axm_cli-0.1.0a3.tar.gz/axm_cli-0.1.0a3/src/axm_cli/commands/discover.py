"""AXM Discover command - Auto-generate contracts from code."""

import ast
from pathlib import Path
from typing import Annotated, Any

import typer
from rich.console import Console
from rich.panel import Panel

console = Console()


def scan_operations(path: Path) -> list[dict[str, Any]]:
    """Scan operations/ folder for pure functions by naming convention.

    Convention: operations/{name}/src/{name}/main.py contains function '{name}'.

    Args:
        path: Directory to scan (typically 'operations/').

    Returns:
        List of operation metadata dicts.
    """
    operations: list[dict[str, Any]] = []

    # Look for main.py files in operation packages
    for main_py in path.rglob("main.py"):
        if "__pycache__" in str(main_py):
            continue

        # Extract operation name from path structure
        # Expected: operations/{op_name}/src/{op_name}/main.py
        parts = main_py.parts
        try:
            # Find 'operations' in path and get the next part
            if "operations" in parts:
                op_idx = parts.index("operations")
                if op_idx + 1 < len(parts):
                    op_name = parts[op_idx + 1]
                else:
                    continue
            else:
                # Fallback: use grandparent folder name
                op_name = main_py.parent.name
        except (ValueError, IndexError):
            continue

        try:
            tree = ast.parse(main_py.read_text())
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    # Match function with same name as operation folder
                    if node.name == op_name:
                        operations.append(
                            {
                                "kind": "operation",
                                "entrypoint": node.name,
                                "description": ast.get_docstring(node) or "",
                                "inputs": [],  # Infer from function signature later
                                "outputs": [],
                                "domain": "default",
                                "source_file": str(main_py),
                            }
                        )
                        break  # Found the main function, move to next file
        except Exception as e:
            console.print(f"[red]Error parsing {main_py}: {e}[/red]")
            continue

    return operations


def generate_operation_contract(op: dict[str, Any], source_path: Path) -> str:
    """Generate .axm contract content for an operation.

    Args:
        op: Operation metadata from decorator.
        source_path: Path to the source Python file.

    Returns:
        YAML content for the .axm file.
    """
    inputs_yaml = ""
    for inp in op.get("inputs", []):
        inputs_yaml += f"""
  - name: {inp}
    data_ref: {inp}
    version: "*\""""

    outputs_yaml = ""
    for out in op.get("outputs", []):
        outputs_yaml += f"""
  - name: {out}
    data_ref: {out}
    version: "*\""""

    return f"""axm: "1.0"
kind: operation
name: {op["entrypoint"]}
version: "1.0.0"

identity:
  display_name: "{op["entrypoint"].replace("_", " ").title()}"
  description: "{op.get("description", "").split(chr(10))[0].strip()}"
  domain: "{op.get("domain", "default")}"
  owner:
    team: "dev"
    contact: "dev@example.com"

spec:
  type: python_file
  source: "{source_path.resolve()}"
  entrypoint: "{op["entrypoint"]}"

inputs:{inputs_yaml if inputs_yaml else " []"}

outputs:{outputs_yaml if outputs_yaml else " []"}
"""


def discover(
    path: Annotated[
        Path,
        typer.Argument(
            help="Directory to scan for operations",
            exists=True,
        ),
    ],
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Preview without writing files"),
    ] = False,
    data: Annotated[
        bool,
        typer.Option("--data", help="Also discover data files (CSV, Parquet)"),
    ] = False,
) -> None:
    """Discover operations from decorated Python functions and generate contracts."""
    console.print(
        Panel(
            f"Scanning [bold cyan]{path}[/bold cyan] for operations...",
            title="AXM Discover",
            expand=False,
        )
    )

    # Scan for operations
    operations = scan_operations(path)
    total_discovered = 0

    if operations:
        console.print(f"[dim]Found {len(operations)} operation(s)[/dim]")

        for op in operations:
            source_file = Path(op["source_file"])
            axm_file = source_file.with_suffix(".axm")

            console.print(f"  [green]✓[/green] {op['entrypoint']} → {axm_file.name}")

            if not dry_run:
                content = generate_operation_contract(op, source_file)
                axm_file.write_text(content)

        total_discovered += len(operations)
    else:
        console.print(
            "[yellow]No operations found "
            "(expected main.py with matching function name).[/yellow]"
        )

    # Discover data files if --data flag is set
    if data:
        from axm_cli.commands.infer import discover_data, generate_data_contract_yaml

        console.print("\n[dim]Scanning for data files...[/dim]")
        data_contracts = list(discover_data(path))

        if data_contracts:
            console.print(f"[dim]Found {len(data_contracts)} data file(s)[/dim]")

            for contract in data_contracts:
                source_path = Path(contract["location"]["path_template"])
                axm_file = source_path.with_suffix(".axm")

                console.print(
                    f"  [green]✓[/green] {contract['name']} → {axm_file.name}"
                )

                if not dry_run:
                    content = generate_data_contract_yaml(contract)
                    axm_file.write_text(content)

            total_discovered += len(data_contracts)
        else:
            console.print("[yellow]No data files found.[/yellow]")

    mode = "[dim](dry run)[/dim]" if dry_run else ""
    console.print(f"\n[bold green]✨ {total_discovered} item(s) discovered[/] {mode}")
