"""AXM Run command - Execute a pipeline locally."""

from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel

from axm.catalog.entries.pipeline import PipelineEntry
from axm.catalog.loading.catalog import DataCatalog
from axm_engine.context import RuntimeContext
from axm_engine.orchestration import PipelineRunner

console = Console()


def run(
    pipeline_path: Annotated[
        Path,
        typer.Argument(
            exists=True,
            help="Path to the pipeline .axm file to run",
        ),
    ],
) -> None:
    """Execute a pipeline locally."""
    console.print(
        Panel(
            f"Running pipeline: [bold cyan]{pipeline_path.stem}[/bold cyan]",
            title="AXM Run",
            expand=False,
        )
    )

    # 1. Load Catalog from project root (parent of pipelines/)
    contracts_dir = pipeline_path.parent.parent
    if not contracts_dir.exists():
        contracts_dir = pipeline_path.parent

    try:
        catalog = DataCatalog.from_directory(contracts_dir)
    except Exception as e:
        console.print(f"[bold red]❌ Failed to load catalog:[/bold red] {e}")
        raise typer.Exit(code=1) from None

    console.print(f"[dim]Loaded {len(catalog)} entries from catalog.[/dim]")

    # 2. Find the pipeline entry
    pipeline_name = pipeline_path.stem
    pipeline_entry = None
    for entry in catalog:
        if isinstance(entry, PipelineEntry) and entry.name == pipeline_name:
            pipeline_entry = entry
            break

    # Fallback: try to match by file
    if pipeline_entry is None:
        for entry in catalog:
            if isinstance(entry, PipelineEntry):
                pipeline_entry = entry
                break

    if pipeline_entry is None:
        console.print(
            f"[bold red]❌ Pipeline '{pipeline_name}' not found in catalog[/bold red]"
        )
        raise typer.Exit(code=1)

    # 3. Register audit hook (if axm-audit is installed)
    try:
        from axm.observability.hooks import set_audit_hook
        from axm_audit import auditor

        set_audit_hook(auditor)
    except ImportError:
        pass  # axm-audit not installed, continue without metrics

    # 4. Execute pipeline
    context = RuntimeContext()
    context.set_catalog(catalog)
    runner = PipelineRunner(context)

    console.print(
        f"\n[bold]Executing:[/bold] {pipeline_entry.name} v{pipeline_entry.version}"
    )

    total_steps = len(pipeline_entry.dag.steps)
    for i, step in enumerate(pipeline_entry.dag.steps, 1):
        console.print(f"  → Step [{i}/{total_steps}]: [cyan]{step.id}[/cyan]")

    try:
        results = runner.run(pipeline_entry)
        console.print("\n[bold green]✨ Pipeline completed successfully![/bold green]")

        if results:
            console.print("[dim]Outputs:[/dim]")
            for key, value in results.items():
                raw = repr(value)
                value_repr = raw[:80] + "..." if len(raw) > 80 else raw
                console.print(f"  • {key}: {value_repr}")

        # Display Trust Tax metrics (if auditor was registered)
        try:
            from rich.table import Table

            from axm_audit import auditor

            m = auditor.metrics
            if m.total_validations > 0:
                table = Table(title="Trust Tax", show_header=True)
                table.add_column("Metric", style="cyan")
                table.add_column("Value", justify="right", style="green")

                table.add_row("Validations", str(m.total_validations))
                table.add_row("Validation Time", f"{m.total_ms:.2f} ms")

                if m.pipeline_duration_ns > 0:
                    table.add_row("Total Execution", f"{m.pipeline_ms:.2f} ms")
                    table.add_row("Trust Tax", f"{m.trust_tax_percent:.2f}%")

                console.print()
                console.print(table)
        except ImportError:
            pass  # axm-audit not installed

    except Exception as e:
        console.print(f"\n[bold red]❌ Pipeline failed:[/bold red] {e}")
        raise typer.Exit(code=1) from None
