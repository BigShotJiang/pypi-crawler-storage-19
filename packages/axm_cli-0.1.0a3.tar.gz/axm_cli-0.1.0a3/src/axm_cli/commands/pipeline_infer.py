"""Pipeline inference from operation I/O matching.

Analyzes operations and their inputs/outputs to automatically
generate a pipeline DAG with proper execution order.
"""

from collections import defaultdict
from typing import Any


def infer_pipeline(
    operations: list[dict[str, Any]],
    pipeline_name: str = "auto_pipeline",
) -> dict[str, Any]:
    """Infer a pipeline from operations by matching outputs to inputs.

    Performs topological sorting to determine execution order based
    on data dependencies.

    Args:
        operations: List of operation metadata dicts with inputs/outputs.
        pipeline_name: Name for the generated pipeline.

    Returns:
        Pipeline contract dictionary with DAG steps in execution order.
    """
    # Build dependency graph
    # output_map: output_name -> operation_name
    output_map: dict[str, str] = {}
    for op in operations:
        for output in op.get("outputs", []):
            output_map[output] = op["name"]

    # dependencies: operation_name -> set of prerequisite operation names
    dependencies: dict[str, set[str]] = defaultdict(set)
    op_names = {op["name"] for op in operations}

    for op in operations:
        for inp in op.get("inputs", []):
            if inp in output_map:
                producer = output_map[inp]
                if producer in op_names and producer != op["name"]:
                    dependencies[op["name"]].add(producer)

    # Topological sort (Kahn's algorithm)
    in_degree: dict[str, int] = {op["name"]: 0 for op in operations}
    for op_name, deps in dependencies.items():
        in_degree[op_name] = len(deps)

    queue = [name for name, degree in in_degree.items() if degree == 0]
    sorted_ops: list[str] = []

    while queue:
        current = queue.pop(0)
        sorted_ops.append(current)

        # Reduce in-degree for dependent operations
        for op_name, deps in dependencies.items():
            if current in deps:
                in_degree[op_name] -= 1
                if in_degree[op_name] == 0:
                    queue.append(op_name)

    # Build steps
    steps = [
        {"id": f"step_{i + 1}", "operation": op} for i, op in enumerate(sorted_ops)
    ]

    return {
        "axm": "1.0",
        "kind": "pipeline",
        "name": pipeline_name,
        "version": "1.0.0",
        "identity": {
            "display_name": pipeline_name.replace("_", " ").title(),
            "description": "Auto-inferred pipeline from operation I/O matching",
            "domain": "default",
            "owner": {"team": "dev", "contact": "dev@example.com"},
        },
        "dag": {"steps": steps},
    }
