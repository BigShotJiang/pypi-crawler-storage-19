"""
Communications service test package.
"""
