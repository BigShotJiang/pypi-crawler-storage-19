"""
Communications service API package.
"""
