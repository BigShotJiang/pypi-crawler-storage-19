# riyadhai-plugin-silero

Meta-package that installs Silero VAD runtime dependencies for the RiyadhAI SDK.
