"""Multi-file support tests."""
