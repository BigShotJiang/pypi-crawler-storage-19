"""Bundle instruction tests."""
