"""Code generator tests."""
