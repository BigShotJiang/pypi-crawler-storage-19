"""TriCore ISA tests."""


