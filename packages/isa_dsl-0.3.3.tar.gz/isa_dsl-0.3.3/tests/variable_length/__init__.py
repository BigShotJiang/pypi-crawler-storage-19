"""Variable length instruction tests."""
