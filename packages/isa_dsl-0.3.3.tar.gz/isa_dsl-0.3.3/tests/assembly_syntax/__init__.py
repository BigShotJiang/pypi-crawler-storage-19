"""Assembly syntax tests."""
