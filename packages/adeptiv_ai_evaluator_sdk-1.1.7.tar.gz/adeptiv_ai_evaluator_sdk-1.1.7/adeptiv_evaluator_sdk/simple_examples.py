from config import config
from decorator import trace_llm, trace_agent

config.service_name = "customer-support-bot"
config.capture_inputs = False
config.capture_outputs = False

# @observe(model="gpt-4.1")
# def generate_answer(prompt: str):
#     return f"Answer for: {prompt}"



    
@trace_llm(name="support_agent_workflow")
def run_support_agents(query):

    plan = planner_agent(query)
    docs = retriever_agent(plan)
    answer = responder_agent(query, docs)

    return answer


@trace_agent(agent_name="planner", model="gpt-4.1")
def planner_agent(query):
    return f"Plan for: {query}"


@trace_agent(agent_name="retriever", model="gpt-4.1")
def retriever_agent(plan):
    return f"Docs for: {plan}"


@trace_agent(agent_name="responder", model="gpt-4.1")
def responder_agent(query, docs):
    return f"Final answer using {docs}"

if __name__ == "__main__":
    run_support_agents("What is OpenTelemetry?")
    