class SDKConfig:
    service_name = "genai-app"
    environment = "prod"
    otlp_endpoint = "https://nlxs8f2etf.execute-api.us-east-1.amazonaws.com"
    capture_inputs = False
    capture_outputs = False
    redact = True


config = SDKConfig()