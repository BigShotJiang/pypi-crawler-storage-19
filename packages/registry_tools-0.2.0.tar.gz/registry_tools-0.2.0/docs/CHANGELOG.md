# RegistryTools 变更日志

本文件记录 RegistryTools 项目的所有重要变更。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

---

## [Unreleased]

---

## [0.2.0] - 2026-01-10

### 新增
- **Phase 35 搜索引擎全局配置** (2026-01-10)
  - 新增 `REGISTRYTOOLS_SEARCH_METHOD` 环境变量，支持配置全局默认搜索引擎
  - `search_tools()` 和 `search_hot_tools()` 的 `search_method` 参数改为可选
  - 未指定 `search_method` 时，自动使用环境变量配置的默认值
  - 支持三种搜索引擎：`regex`（最快）、`bm25`（推荐默认）、`embedding`（最准确）
  - `search_hot_tools()` 自动回退机制：不支持 `embedding` 时自动使用 `bm25`

### 修复
- **REGISTRYTOOLS_DESCRIPTION 描述不一致** (2026-01-10)
  - 修复 README.md 和 __main__.py 中使用占位符"官方描述"的问题
  - 统一所有文档中的默认描述内容为完整值
  - 描述一致性从 71.4% 提升至 100%

### 改进
- **搜索引擎选择指南** (2026-01-10)
  - 在 CONFIGURATION.md 添加 `REGISTRYTOOLS_SEARCH_METHOD` 详细说明
  - 在 USER_GUIDE.md 添加搜索引擎选择指南和使用场景示例
  - 提供三种搜索引擎的详细对比表（速度、准确率、中文支持、语义理解）

### 测试
- **新增搜索引擎配置测试** (2026-01-10)
  - 新增 `tests/test_search_method_config.py`，13个测试用例
  - 测试覆盖：环境变量未设置、有效值、无效值、大小写不敏感、空格处理等
  - 所有测试通过，测试覆盖率保持 82%

### 变更
- **版本号更新**: 0.1.1 → 0.2.0
- **向后兼容**: 完全兼容，未指定 `search_method` 参数时行为与之前一致（默认使用 `bm25`）

---

## [0.1.1] - 2026-01-09

### 新增
- **Phase 24 EMBEDDING 语义搜索实现** (2026-01-09)
  - 实现 EmbeddingSearch 类，使用 sentence-transformers
  - 支持中英文双语语义搜索
  - 使用余弦相似度进行向量比较
  - 实现索引缓存和哈希值检测机制
  - 分层索引支持（热工具优先）
  - 218 行代码，97% 测试覆盖率

- **Phase 25 审核报告与版本发布** (2026-01-09)
  - 完成全面功能审核报告（docs/AUDIT_REPORT_V0.1.0.md）
  - 验证所有功能实现与文档描述一致
  - 版本号从 v0.1.0 更新至 v0.1.1
  - 清理旧版本 wheel 包，构建最新版本
  - 远端版本清理（删除旧版本 tag）

- **Phase 26 版本号修正与文档一致性审核** (2026-01-09)
  - 修正 pyproject.toml 版本号为 0.1.1
  - 修正 __init__.py 版本号为 0.1.1
  - 更新所有用户面向文档版本号
  - 完善 CHANGELOG.md 版本历史

### 修复
- **$HOME 环境变量展开 bug** (2026-01-09)
  - 修复 Path.expanduser() 前 $HOME 未展开的问题
  - 修复位置: __main__.py:172, 241
  - 防止创建字面量 '$HOME' 目录

### 变更
- **版本号更新**: 0.1.0 → 0.1.1
- **wheel 包**: registry_tools-0.1.0 → registry_tools-0.1.1
- **文档版本**: 所有用户面向文档更新至 v0.1.1

---

## [0.1.0] - 2026-01-05

### 新增
- **Phase 21 MCP 配置参数完善** (2026-01-07)
  - 修复 expanduser bug：环境变量 `REGISTRYTOOLS_DATA_PATH` 现在支持波浪号（`~`）自动展开
  - 新增 MCP 配置参数说明文档（`description` 和 `priority` 参数）
  - 新增路径配置说明章节（波浪号、$HOME、绝对路径、相对路径对比）
  - 更新 CLAUDE_CONFIG.md、IDE_CONFIG.md、README.md
  - 完善配置示例，解决用户使用 `claude mcp add-json` 配置连接失败问题
- **Phase 18.3 配置文档本地/PyPI差异化说明** (2026-01-06)
  - 所有配置文档添加本地开发环境 vs PyPI 发布后的配置区分
  - 解决 `uvx registry-tools` 在本地开发环境无法连接的问题
  - 更新 README.md、CLAUDE_CONFIG.md、IDE_CONFIG.md、INSTALLATION.md
  - 新增故障排除章节，说明 uvx 连接失败的原因和解决方案
  - 所有配置示例明确标注"本地开发环境配置"和"PyPI 发布后配置"
- **Phase 18.2 命名规范完全统一** (2026-01-06)
  - PyPI 包名从 `Registry_Tools` 改为 `registry-tools`（符合 Python 最佳实践）
  - 统一所有文档中的安装命令引用（`pip install registry-tools`）
  - wheel 文件名自动规范化为 `registry_tools-0.1.0-py3-none-any.whl`
  - pip list 显示统一为 `registry-tools`
- **Phase 18 命名规范统一** (2026-01-06)
  - PyPI 包名从 `Registry-Tools` 改为 `Registry_Tools`
  - 统一 pip list 显示与 wheel 文件名（`Registry_Tools`）
  - 更新所有文档中的安装命令引用
  - wheel 文件名从 `registry_tools-0.1.0-py3-none-any.whl` 改为 `registry_tools-0.1.1-py3-none-any.whl`
- **Phase 15 API Key 认证功能** (2026-01-05)
  - 实现 API Key 生成、存储、认证中间件
  - 支持 READ/WRITE/ADMIN 三级权限
  - 提供 api-key CLI 子命令管理 API Key
  - API Key 格式: `rtk_<64-char-hex>`
  - 支持 HTTP Header 认证 (X-API-Key / Authorization Bearer)

- **Phase 14.2 日志功能** (2026-01-05)
  - 实现 Python logging 模块集成
  - 支持动态日志级别配置 (DEBUG/INFO/WARNING/ERROR)
  - 日志格式: `YYYY-MM-DD HH:MM:SS - registrytools - LEVEL - Message`
  - 支持 --log-level CLI 参数
  - 支持 REGISTRYTOOLS_LOG_LEVEL 环境变量

- **Phase 14.1 环境变量支持** (2026-01-05)
  - 支持 REGISTRYTOOLS_DATA_PATH 环境变量
  - 支持 REGISTRYTOOLS_TRANSPORT 环境变量
  - 支持 REGISTRYTOOLS_LOG_LEVEL 环境变量
  - 支持 REGISTRYTOOLS_ENABLE_AUTH 环境变量
  - 配置优先级: 环境变量 > CLI 参数 > 默认值

- **Phase 13 IDE 配置文档补充** (2026-01-05)
  - 创建 docs/IDE_CONFIG.md
  - 添加 Claude Desktop 配置方式 (STDIO/HTTP)
  - 添加 Claude Code CLI 命令配置方式（推荐）
  - 添加 Cursor 配置方式
  - 添加 Continue.dev 和 Cline 配置方式
  - 添加环境变量配置说明

- **Phase 12 文档体系完善** (2026-01-05)
  - 创建 docs/PUBLISHING.md 发布指南
  - 创建 docs/INSTALLATION.md 安装指南
  - 创建 docs/USER_GUIDE.md 用户指南
  - 创建 docs/CLAUDE_CONFIG.md 配置指南

- **Phase 10 Streamable HTTP 传输支持** (2026-01-05)
  - 实现 --transport http CLI 参数
  - 支持 --host, --port, --path 配置
  - 创建 fastmcp.json 配置文件
  - 支持 STDIO 和 Streamable HTTP 双模式

- **Phase 11 项目结构标准化重构** (TASK-1101 至 TASK-1114)
  - 迁移到标准 Python `src/` 布局
  - 包名从 `RegistryTools` 改为小写 `registrytools` (PEP 8)
  - 源代码从 `RegistryTools/` 移动到 `src/registrytools/`

### 变更
- **项目结构** (Phase 11)
  - 采用标准 `src/` 布局，符合 Python 社区最佳实践
  - 更新所有导入语句: `from RegistryTools` → `from registrytools`
  - 更新 pyproject.toml 配置以支持 src/ 布局
  - 更新 fastmcp.json 配置文件路径
  - 更新所有文档中的路径引用

- **Phase 8.5 质量修复** (TASK-851 至 TASK-860)
  - 新增 `tests/test_mcp_integration.py` FastMCP 集成测试（27个测试）
  - 新增 `docs/README.md` 文档索引
  - 总测试数量: 217 → 244 (+27)
  - server.py 测试覆盖率: 46% → 97%

### 修复
- **pytest 配置问题验证** (TASK-2101 至 TASK-2105, 2026-01-07)
  - 验证 pytest-benchmark 和 pytest-cov 依赖正确安装
  - 确认所有 331 个测试通过（包括 14 个性能测试）
  - 测试覆盖率保持 87%
  - 性能基准测试正常运行
- **Pydantic V2 废弃警告** (TASK-854)
  - 移除 `json_encoders` 配置
  - 使用 `field_serializer` 替代
- **server.py 测试覆盖率** (TASK-852)
  - 添加 FastMCP 工具层集成测试
  - 覆盖所有 MCP 工具和资源接口

### 变更
- **冷热工具分离机制** (TASK-802)
  - 新增 `ToolTemperature` 枚举（HOT/WARM/COLD）
  - 新增 `defaults.py` 配置文件，包含分类阈值常量
  - 新增三层存储字典和温度锁
  - 新增工具温度自动分类和升降级机制
  - 新增存储层 `load_by_temperature()` 接口

### 变更
- **RegexSearch 缓存修复** (TASK-801-FIX)
  - 统一使用基类的哈希值检测方法
  - 添加 6 个 RegexSearch 缓存测试

### 改进
- `ToolRegistry.register()`: 自动分类工具温度
- `ToolRegistry.update_usage()`: 自动升级温度 + 检查降级
- `ToolRegistry.unregister()`: 从温度层移除
- `ToolMetadata`: 新增 `temperature` 字段
- `JSONStorage`: 实现按温度加载工具（过滤模式）
- `SQLiteStorage`: 实现按温度加载工具（SQL 优化）

### 计划中
- 语义搜索支持 (Embedding)
- Web UI 管理界面
- 分布式工具索引

---

## [0.1.0] - 2026-01-04

### 新增
- 项目初始化
- 核心文档创建
  - CONTRIBUTING.md (贡献指南)
  - DEVELOPMENT_WORKFLOW.md (开发流程规范)
  - TASK.md (任务追踪文档)
  - ARCHITECTURE.md (架构设计文档)
  - API.md (API 文档)
  - CHANGELOG.md (变更日志)
- 目录结构创建
  - RegistryTools/ (主包)
  - docs/ (文档)
  - scripts/ (脚本工具)
  - tests/ (测试)
  - examples/ (示例)

### 计划
- ToolMetadata 数据模型
- BM25 搜索算法
- 工具注册表实现
- JSON/SQLite 存储层
- MCP 工具接口
- FastMCP 服务器入口

---

## 版本说明

### [0.1.0] - 初始版本
首次发布，包含基础的工具注册和搜索功能。

---

## 变更类型说明

- **新增**: 新功能
- **变更**: 现有功能的变更
- **弃用**: 即将移除的功能
- **移除**: 已移除的功能
- **修复**: 问题修复
- **安全**: 安全相关的修复

---

**维护者**: Maric
**文档版本**: v0.1.1
