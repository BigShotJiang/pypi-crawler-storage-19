"""Protocol handlers for DataFrame server commands."""
from __future__ import annotations

import json
import struct
import threading
import time
from typing import TYPE_CHECKING, Any

import pyarrow as pa
from pyspark.sql import functions as F

if TYPE_CHECKING:
    from pyspark.sql import DataFrame

STATUS_OK = 0
STATUS_ERROR = 1

# Cache for computed stats (cleared when DataFrame is re-registered)
_stats_cache: dict[str, dict] = {}

# Cache for prefetched Arrow data: name -> (limit, payload_bytes)
_arrow_cache: dict[str, tuple[int, bytes]] = {}
_arrow_cache_lock = threading.Lock()


def clear_stats_cache(name: str | None = None) -> None:
    """Clear cached stats for a DataFrame or all DataFrames."""
    if name is None:
        _stats_cache.clear()
    elif name in _stats_cache:
        del _stats_cache[name]


def clear_arrow_cache(name: str | None = None) -> None:
    """Clear cached Arrow data for a DataFrame or all DataFrames."""
    with _arrow_cache_lock:
        if name is None:
            _arrow_cache.clear()
        elif name in _arrow_cache:
            del _arrow_cache[name]


def _serialize_arrow_ipc(table: pa.Table) -> tuple[bytes, int]:
    """Serialize Arrow table to IPC format, returning bytes and timing in ms."""
    start = time.perf_counter()
    sink = pa.BufferOutputStream()
    with pa.ipc.RecordBatchStreamWriter(sink, table.schema) as writer:
        for batch in table.to_batches():
            writer.write_batch(batch)
    ipc_ms = int((time.perf_counter() - start) * 1000)
    return sink.getvalue().to_pybytes(), ipc_ms


def prefetch_frame(registry: dict[str, DataFrame], name: str, limit: int = 10000) -> bool:
    """Prefetch DataFrame as Arrow IPC bytes in background.

    Returns True if prefetch succeeded, False otherwise.
    """
    if name not in registry:
        return False

    try:
        df = registry[name]
        start = time.perf_counter()
        limited_df = df.limit(limit) if limit > 0 else df
        table = limited_df.toArrow()
        spark_ms = int((time.perf_counter() - start) * 1000)
        total_rows = table.num_rows

        arrow_bytes, ipc_ms = _serialize_arrow_ipc(table)
        # 24-byte header: spark_ms, ipc_ms, total_rows (all little-endian u64)
        payload = struct.pack("<QQQ", spark_ms, ipc_ms, total_rows) + arrow_bytes

        with _arrow_cache_lock:
            _arrow_cache[name] = (limit, payload)

        return True
    except Exception:
        return False


def encode_response(status: int, payload: bytes) -> bytes:
    """Encode response with status and length prefix."""
    return struct.pack(">II", status, len(payload)) + payload


def encode_json_response(data: Any) -> bytes:
    """Encode JSON data as successful response."""
    return encode_response(STATUS_OK, json.dumps(data).encode("utf-8"))


def encode_error(message: str) -> bytes:
    """Encode error message response."""
    return encode_response(STATUS_ERROR, message.encode("utf-8"))


def handle_list(registry: dict[str, DataFrame]) -> bytes:
    """Return list of registered DataFrame names."""
    return encode_json_response(list(registry.keys()))


def handle_schema(registry: dict[str, DataFrame], name: str) -> bytes:
    """Return schema of a DataFrame as JSON."""
    if name not in registry:
        return encode_error(f"DataFrame '{name}' not found")

    df = registry[name]
    columns = [
        {"name": field.name, "type": str(field.dataType), "nullable": field.nullable}
        for field in df.schema.fields
    ]
    return encode_json_response({"name": name, "columns": columns})


def handle_get(registry: dict[str, DataFrame], name: str, limit: int) -> bytes:
    """Return DataFrame data as Arrow IPC stream with timing info."""
    if name not in registry:
        return encode_error(f"DataFrame '{name}' not found")

    # Check cache first - return cached data if limit is sufficient
    with _arrow_cache_lock:
        if name in _arrow_cache:
            cached_limit, cached_payload = _arrow_cache[name]
            if cached_limit >= limit:
                return encode_response(STATUS_OK, cached_payload)

    # Cache miss or insufficient limit - materialize from Spark
    df = registry[name]

    start = time.perf_counter()
    limited_df = df.limit(limit) if limit > 0 else df
    table = limited_df.toArrow()
    spark_ms = int((time.perf_counter() - start) * 1000)
    total_rows = table.num_rows

    arrow_bytes, ipc_ms = _serialize_arrow_ipc(table)
    # 24-byte header: spark_ms, ipc_ms, total_rows (all little-endian u64)
    payload = struct.pack("<QQQ", spark_ms, ipc_ms, total_rows) + arrow_bytes

    # Cache result for future requests
    with _arrow_cache_lock:
        _arrow_cache[name] = (limit, payload)

    return encode_response(STATUS_OK, payload)


def _is_numeric_type(dtype_str: str) -> bool:
    """Check if a Spark type string represents a numeric type."""
    dtype_lower = dtype_str.lower()
    return any(t in dtype_lower for t in ["int", "long", "double", "float", "decimal"])


def handle_stats(registry: dict[str, DataFrame], name: str) -> bytes:
    """Return basic statistics for a DataFrame using single aggregation."""
    if name not in registry:
        return encode_error(f"DataFrame '{name}' not found")

    # Return cached stats if available
    if name in _stats_cache:
        return encode_json_response(_stats_cache[name])

    df = registry[name]
    fields = df.schema.fields

    # Build all aggregation expressions in one pass
    agg_exprs = [F.count(F.lit(1)).alias("__total")]
    for field in fields:
        col_name = field.name
        agg_exprs.append(
            F.sum(F.when(F.col(col_name).isNull(), 1).otherwise(0)).alias(f"{col_name}__nulls")
        )
        if _is_numeric_type(str(field.dataType)):
            agg_exprs.append(F.min(col_name).alias(f"{col_name}__min"))
            agg_exprs.append(F.max(col_name).alias(f"{col_name}__max"))

    # Single Spark action
    result = df.agg(*agg_exprs).collect()[0]
    row_count = result["__total"]

    # Extract stats from result
    column_stats = []
    for field in fields:
        col_name = field.name
        dtype_str = str(field.dataType)
        stats = {"name": col_name, "type": dtype_str, "nullable": field.nullable}
        stats["null_count"] = result[f"{col_name}__nulls"] or 0

        if _is_numeric_type(dtype_str):
            min_val = result[f"{col_name}__min"]
            max_val = result[f"{col_name}__max"]
            stats["min"] = str(min_val) if min_val is not None else None
            stats["max"] = str(max_val) if max_val is not None else None

        column_stats.append(stats)

    stats_data = {"name": name, "row_count": row_count, "columns": column_stats}
    _stats_cache[name] = stats_data  # Cache for future requests

    return encode_json_response(stats_data)


def handle_count(registry: dict[str, DataFrame], name: str) -> bytes:
    """Return total row count without transferring data."""
    if name not in registry:
        return encode_error(f"DataFrame '{name}' not found")

    df = registry[name]
    start = time.perf_counter()
    count = df.count()
    count_ms = int((time.perf_counter() - start) * 1000)

    return encode_json_response({"name": name, "count": count, "count_ms": count_ms})


def dispatch_command(
    registry: dict[str, DataFrame], command: str
) -> bytes:
    """Parse and dispatch a command to the appropriate handler."""
    command = command.strip()

    if command == "LIST":
        return handle_list(registry)

    if command.startswith("SCHEMA:"):
        name = command[7:]
        return handle_schema(registry, name)

    if command.startswith("GET:"):
        parts = command[4:].split(":")
        if len(parts) != 2:
            return encode_error("Invalid GET format. Use GET:name:limit")
        name, limit_str = parts
        try:
            limit = int(limit_str)
        except ValueError:
            return encode_error(f"Invalid limit: {limit_str}")
        return handle_get(registry, name, limit)

    if command.startswith("STATS:"):
        name = command[6:]
        return handle_stats(registry, name)

    if command.startswith("COUNT:"):
        name = command[6:]
        return handle_count(registry, name)

    return encode_error(f"Unknown command: {command}")
