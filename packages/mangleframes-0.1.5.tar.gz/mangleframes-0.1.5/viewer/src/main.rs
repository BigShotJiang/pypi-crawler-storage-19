//! MangleFrames Viewer - Web-based PySpark DataFrame viewer.

mod arrow_reader;
mod export;
mod handlers;
mod perf;
mod query_engine;
mod socket_client;
mod stats;
mod web_server;
mod websocket;

use std::path::PathBuf;
use std::sync::Arc;

use clap::Parser;
use tracing::info;
use tracing_subscriber::EnvFilter;

use crate::arrow_reader::batches_to_json_bytes;
use crate::socket_client::SocketClient;
use crate::web_server::{AppState, CachedFrame, JsonCacheKey};

#[derive(Parser)]
#[command(name = "mangleframes-viewer")]
#[command(about = "Web-based PySpark DataFrame viewer")]
struct Args {
    #[arg(short, long)]
    socket: PathBuf,

    #[arg(short, long, default_value = "8765")]
    port: u16,

    #[arg(long)]
    no_browser: bool,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env())
        .init();

    let args = Args::parse();

    info!("Connecting to Python server at {:?}", args.socket);
    let client = Arc::new(SocketClient::new(&args.socket));
    let state = AppState::new(client.clone());

    // Preload first frame into cache for instant display
    if let Ok(frames) = client.list_frames() {
        if let Some(first) = frames.first() {
            info!("Preloading frame: {}", first);
            if let Ok(response) = client.get_frame(first, 10000) {
                if let Ok(batches) = arrow_reader::parse_arrow_stream(&response.data) {
                    // Pre-warm JSON cache for common offset/limit combinations
                    let common_limits = [100, 500, 1000, 5000, 10000];
                    {
                        let mut json_cache = state.json_cache.write().await;
                        for &limit in &common_limits {
                            let (rows_bytes, _) = batches_to_json_bytes(&batches, 0, limit);
                            let total = batches.iter().map(|b| b.num_rows()).sum::<usize>();
                            let body = build_prewarm_response(&rows_bytes, total, 0, limit);
                            let key = JsonCacheKey { frame: first.clone(), offset: 0, limit };
                            json_cache.insert(key, body);
                        }
                        info!("Pre-warmed JSON cache for {} limits", common_limits.len());
                    }

                    let mut cache = state.cache.write().await;
                    cache.insert(first.clone(), CachedFrame { batches, stats: None });
                }
            }
        }
    }

    if !args.no_browser {
        let url = format!("http://localhost:{}", args.port);
        info!("Opening browser at {}", url);
        let _ = webbrowser::open(&url);
    }

    info!("Starting web server on port {}", args.port);
    web_server::run(state, args.port).await
}

/// Build pre-warm response JSON (cached timing values are zeros)
fn build_prewarm_response(rows_bytes: &[u8], total: usize, offset: usize, limit: usize) -> Vec<u8> {
    let timing = r#"{"spark_ms":0,"ipc_ms":0,"socket_ms":0,"parse_ms":0,"json_ms":0,"total_ms":0,"rows_fetched":0,"bytes_transferred":0,"cached":true}"#;
    let mut result = Vec::with_capacity(rows_bytes.len() + 200);
    result.extend_from_slice(b"{\"rows\":");
    result.extend_from_slice(rows_bytes);
    result.extend_from_slice(b",\"total\":");
    result.extend_from_slice(total.to_string().as_bytes());
    result.extend_from_slice(b",\"offset\":");
    result.extend_from_slice(offset.to_string().as_bytes());
    result.extend_from_slice(b",\"timing\":");
    result.extend_from_slice(timing.as_bytes());
    result.extend_from_slice(b"}");
    result
}
