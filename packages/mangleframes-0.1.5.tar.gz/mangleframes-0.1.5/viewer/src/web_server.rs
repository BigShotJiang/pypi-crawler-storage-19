//! Axum web server setup and state management.

use std::collections::HashMap;
use std::sync::Arc;

use arrow::record_batch::RecordBatch;
use axum::Router;
use axum::routing::{get, post};
use tokio::sync::{RwLock, broadcast};
use tower_http::cors::{Any, CorsLayer};

use crate::handlers;
use crate::perf::PerfCollector;
use crate::socket_client::SocketClient;
use crate::websocket;

pub struct CachedFrame {
    pub batches: Vec<RecordBatch>,
    pub stats: Option<serde_json::Value>,
}

/// Cache key for JSON response bytes
#[derive(Hash, Eq, PartialEq, Clone)]
pub struct JsonCacheKey {
    pub frame: String,
    pub offset: usize,
    pub limit: usize,
}

pub struct AppState {
    pub client: Arc<SocketClient>,
    pub cache: RwLock<HashMap<String, CachedFrame>>,
    pub json_cache: RwLock<HashMap<JsonCacheKey, Vec<u8>>>,
    pub broadcast_tx: broadcast::Sender<String>,
    pub perf: Arc<PerfCollector>,
}

impl AppState {
    pub fn new(client: Arc<SocketClient>) -> Arc<Self> {
        let (tx, _) = broadcast::channel(16);
        Arc::new(Self {
            client,
            cache: RwLock::new(HashMap::new()),
            json_cache: RwLock::new(HashMap::new()),
            broadcast_tx: tx,
            perf: Arc::new(PerfCollector::new()),
        })
    }
}

pub async fn run(state: Arc<AppState>, port: u16) -> anyhow::Result<()> {
    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any);

    let app = Router::new()
        .route("/", get(handlers::serve_index))
        .route("/app.js", get(handlers::serve_js))
        .route("/style.css", get(handlers::serve_css))
        .route("/api/frames", get(handlers::list_frames))
        .route("/api/frames/{name}/schema", get(handlers::get_schema))
        .route("/api/frames/{name}/data", get(handlers::get_data))
        .route("/api/frames/{name}/stats", get(handlers::get_stats))
        .route("/api/frames/{name}/export", post(handlers::export_frame))
        .route("/api/query", post(handlers::execute_query))
        .route("/api/perf", get(handlers::get_perf_stats))
        .route("/api/perf/benchmark", post(handlers::run_benchmark))
        .route("/api/perf/stream", post(handlers::stream_benchmark))
        .route("/ws", get(websocket::ws_handler))
        .layer(cors)
        .with_state(state);

    let addr = std::net::SocketAddr::from(([0, 0, 0, 0], port));
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;

    Ok(())
}
