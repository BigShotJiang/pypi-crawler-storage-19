"""Tests for Synkro."""

