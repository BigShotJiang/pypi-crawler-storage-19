# COS 图片转 AVIF 格式 MCP工具

这是一个基于腾讯云COS（对象存储）的图片批量转换MCP工具，可将COS存储桶中的图片批量转换为高效的AVIF格式。AVIF格式具有更高的压缩效率，在保持高质量的同时显著减小文件大小。

## 功能特性

- **批量转换**: 将COS存储桶中的图片批量转换为AVIF格式
- **上传到COS支持多种输入方式**: 支持URL列表、本地文件路径、COS存储桶前缀等多种输入方式
- **动态GIF支持**: 保留GIF动画效果，转换为动态AVIF
- **文件管理**: 提供删除COS文件（可以排除指定后缀）、重命名COS"文件夹"等功能
- **MCP集成**: 集成FastMCP框架，可与其他AI工具集成

## 技术栈

- [Python](https://www.python.org/downloads/) 3.13.3
- [FastMCP](https://github.com/fastmcp/fastmcp) - MCP协议实现
- [Pillow](https://python-pillow.org/) - 图像处理
- [pillow-avif-plugin](https://github.com/fdintino/pillow-avif-plugin) - AVIF格式支持
- [cos-python-sdk-v5](https://github.com/tencentyun/cos-python-sdk-v5) - 腾讯云COS SDK
- [Requests](https://docs.python-requests.org/) - HTTP请求处理



## 要求

提前安装[uv](https://uv.oaix.tech/getting-started/installation/)

## MCP配置说明

在支持MCP的ide中，请将MCP配置文件配置为如下格式

```json
{
  "mcpServers": {
    "cos-img-converter-avif": {
      "command": "uv",
      "args": [
        "tool",
        "run",
        "cos-img-converter-avif"
      ],
      "env": {
        "COS_SECRET_ID": "...",
        "COS_SECRET_KEY": "...",
        "COS_REGION": "...",
        "COS_BUCKET": "...",
        "COS_CUSTOM_DOMAIN": "..." //腾讯云cos自定义域名
      }
    }
  }
}
```

## 主要功能详解

### 1. convert_cos_images_to_avif
- 支持同时处理远程URL和本地文件路径
- 自动识别输入类型并采用相应的处理方式
- 将图片转换为AVIF格式并上传到COS
- 支持自定义输出前缀

### 2. convert_cos_bucket_images_to_avif
- 批量处理COS存储桶中的图片
- 自动跳过已为AVIF格式的文件
- 支持指定前缀和最大处理数量
- 保留原始文件结构，转换后文件名为 `avif_原文件夹名/原文件名.avif`

### 3. delete_non_avif_cos_images
- 批量删除文件
- 支持排除特定扩展名的文件
- 可选择仅处理图片文件
- 自动分页处理大量文件

### 4. rename_cos_folder
- 重命名COS中的"文件夹"（对象键名前缀）
- 实际上是复制对象到新键名并可选择是否删除原对象
- 支持跨层级重命名

## 注意事项

1. **密钥安全**: 生产环境中请勿将密钥硬编码在代码中，使用环境变量或密钥管理系统
2. **成本考虑**: 大量文件处理会产生COS请求费用，请注意成本控制
3. **网络要求**: 需要能够访问腾讯云COS服务
4. **权限设置**: 确保COS密钥具有足够的权限（读取、写入、删除等）
5. **文件大小**: 单个文件大小不能超过COS限制

## 故障排除

### 常见问题

1. **COS认证失败**
   - 检查密钥是否正确
   - 检查区域是否匹配
   - 检查密钥是否有足够权限
2. **图片转换失败**
   - 检查图片格式是否支持
   - 检查文件是否损坏
   - 检查内存是否充足

### 错误日志

程序会在控制台输出详细的处理信息和错误日志，便于调试问题。

## 许可证

本项目为开源项目，遵循MIT许可证。