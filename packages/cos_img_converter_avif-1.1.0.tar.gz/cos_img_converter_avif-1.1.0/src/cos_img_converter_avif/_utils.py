import io
import os

import requests
from urllib.parse import urlparse
from PIL import Image, ImageSequence
from qcloud_cos import CosS3Client

COS_SECRET_ID = os.getenv("COS_SECRET_ID", "")
COS_SECRET_KEY = os.getenv("COS_SECRET_KEY", "")
COS_REGION = os.getenv("COS_REGION", "")
COS_BUCKET = os.getenv("COS_BUCKET", "")
COS_CUSTOM_DOMAIN = os.getenv("COS_CUSTOM_DOMAIN", "")

# 配置你的所有COS域名（包括自定义+默认）
COS_DOMAINS = [
    COS_CUSTOM_DOMAIN,  # 你的自定义域名
    f"{COS_BUCKET}.cos.{COS_REGION}.myqcloud.com"  # 默认COS域名（自动拼接）
]


def gif_to_avif(gif_path, avif_path, quality=80, speed=4):
    """
    将 GIF 转换为动态 AVIF（支持文件路径和内存字节流）
    :param gif_path: 输入 GIF 路径 或 GIF 字节数据
    :param avif_path: 输出 AVIF 路径 或 输出字节流对象
    :param quality: 压缩质量 (0-100，越高质量越好)
    :param speed: 编码速度 (0-10，越快压缩率越低)
    """
    # 检查 gif_path 是否为字节数据
    if isinstance(gif_path, bytes):
        # 如果是字节数据，使用 BytesIO 创建流
        gif_stream = io.BytesIO(gif_path)
        im = Image.open(gif_stream)
        # 重新创建流以遍历所有帧，因为 seek() 在某些情况下可能不可靠
        gif_stream = io.BytesIO(gif_path)
        im = Image.open(gif_stream)
    else:
        # 如果是文件路径，直接打开文件
        im = Image.open(gif_path)

    # 获取所有帧和延迟时间
    frames = []
    durations = []
    
    # 使用 ImageSequence 来遍历所有帧（适用于 GIF 等多帧图像）
    for i, frame in enumerate(ImageSequence.Iterator(im)):
        # 复制当前帧（避免帧数据共享导致的问题）
        frame_copy = frame.copy()
        # 转换为 RGBA（AVIF 支持透明通道）
        if frame_copy.mode != 'RGBA':
            frame_copy = frame_copy.convert('RGBA')
        frames.append(frame_copy)
        # 获取帧延迟时间（单位：毫秒）
        # 从原始图像信息或当前帧获取持续时间
        duration = frame.info.get('duration')
        if duration is None and hasattr(im, 'info'):
            # 如果当前帧没有持续时间信息，尝试从图像对象获取
            duration = im.info.get('duration', 100)
        else:
            duration = duration or 100
        durations.append(duration)
    
    # 保存为动态 AVIF
    # 注意：Pillow 的 AVIF 插件通过 save_all 支持序列帧，duration 控制每帧延迟
    if isinstance(avif_path, io.BytesIO):
        # 如果输出是内存流
        frames[0].save(
            avif_path,
            format='AVIF',
            save_all=True,
            append_images=frames[1:],
            duration=durations,  # 每帧延迟时间（列表）
            loop=0,  # 0 = 无限循环，与 GIF 一致
            quality=quality,
            speed=speed,
            lossless=False,  # 是否无损压缩（True 会大幅增加文件体积）
            disposal=1,  # 处理帧间差异的方式
            interleave=True, # 启用交错编码
        )
    else:
        # 如果输出是文件路径
        frames[0].save(
            avif_path,
            format='AVIF',
            save_all=True,
            append_images=frames[1:],
            duration=durations,  # 每帧延迟时间（列表）
            loop=0,  # 0 = 无限循环，与 GIF 一致
            quality=quality,
            speed=speed,
            lossless=False,  # 是否无损压缩（True 会大幅增加文件体积）
            disposal=1,  # 处理帧间差异的方式
            interleave=True, # 启用交错编码
        )
        print(f"转换完成：{avif_path}")


def read_cos_image_pure_complete(cos_client, bucket, key):
    """
    从腾讯云COS读取图片，返回【纯净+完整】的二进制字节数据
    根治：静态图异常、动态GIF误判、数据不完整三大问题
    """
    response = cos_client.get_object(Bucket=bucket, Key=key)
    # 1. 获取原生流对象（保证数据完整）
    raw_stream = response['Body'].get_raw_stream()
    # 2. 分块读取+拼接（剔除脏数据，保证纯净），分块大小8192是最优值
    chunk_size = 8192
    image_data = b''
    while True:
        chunk = raw_stream.read(chunk_size)
        if not chunk:
            break
        image_data += chunk
    return image_data

def convert_image_to_avif(image_data: bytes) -> bytes:
    """
    功能描述: 将图片数据转换为AVIF格式，✅ 保留GIF完整动态效果，兼容静态图(JPG/PNG)
    参数说明:
    - image_data (bytes): 必须。原始图片的二进制数据（支持GIF/PNG/JPG等主流格式）
    返回值:
    - bytes: 转换后的AVIF格式图片二进制数据（GIF转完仍是动态AVIF）
    异常处理: 当图片格式不支持或转换失败时抛出ValueError异常
    """
    try:
        # 验证图片数据是否有效
        if not image_data or len(image_data) == 0:
            raise ValueError("图片数据为空")

        # 尝试创建BytesIO流并验证是否为有效图片
        temp_image_stream = io.BytesIO(image_data)

        # 先尝试打开图片以检查格式
        try:
            image = Image.open(temp_image_stream)
        except Exception:
            raise ValueError("无法识别的图片格式或损坏的图片数据")

        # 不再限制特定格式，让PIL自己判断是否支持
        # 重新创建流对象以确保可以多次使用
        temp_image_stream = io.BytesIO(image_data)
        image = Image.open(temp_image_stream)
        
        # 检查是否是 GIF 格式，如果是则强制使用 gif_to_avif 函数
        # 因为有些 GIF 可能 is_animated 属性不准确
        image_format = image.format
        is_gif = (image_format and image_format.upper() == 'GIF') or image_data[:6].startswith(b'GIF8')

        avif_buffer = io.BytesIO()

        # ========== 核心改动：区分「静态图」和「动态GIF」处理 ==========
        if is_gif:
            # 处理前的图片（GIF）: image 对象包含了原始GIF的所有帧
            # 使用现有的 gif_to_avif 函数处理 GIF 数据
            gif_to_avif(gif_path=image_data, avif_path=avif_buffer)
            # 处理后的图片（AVIF）: 包含相同动画效果的AVIF格式数据
        else:
            # 处理前的图片（静态图）: JPG/PNG等静态图片
            image.save(avif_buffer, format="AVIF", quality=80)
            # 处理后的图片（AVIF）: 转换为AVIF格式的静态图片

        # 返回二进制数据
        return avif_buffer.getvalue()
    except Exception as e:
        raise ValueError(f"图片转换失败: {str(e)}")


def is_url(path: str) -> bool:
    """
    【通用函数】判断输入字符串是否为URL | 所有人可用，无配置
    适配: http/https开头的所有链接(公网/云存储/自定义域名)
   """
    return isinstance(path, str) and path.strip().startswith(('http://', 'https://'))


def is_cos_url(url: str) -> bool:
    """
    ✅ 修复：兼容自定义域名的COS URL判断
    判断URL是否属于配置的COS域名（自定义/默认）
    """
    if not is_url(url):
        return False
    # 解析URL的域名部分
    parsed_url = urlparse(url)
    domain = parsed_url.netloc
    # 检查域名是否在配置的COS_DOMAINS中
    return domain in COS_DOMAINS


def download_image_from_url(url: str, cos_client: CosS3Client = None) -> bytes:
    """
    ✅ 核心修复：重构下载函数，兼容「私有COS图片+普通公网图片」双模式
    功能描述: 从指定URL下载图片数据，优先COS鉴权下载，兼容普通URL
    参数说明:
    - url (str): 必须。图片的URL地址
    - cos_client: 可选。COS客户端对象，传入则用鉴权方式下载私有COS图片
    返回值:
    - bytes: 下载的图片二进制数据
    异常处理: 当下载失败或不是有效图片时抛出ValueError异常
    """
    try:
        # ========== 关键修复：私有COS图片下载逻辑 ==========
        if is_cos_url(url) and cos_client is not None:
            # ✅ 通用化提取COS对象Key（适配所有COS域名）
            parsed_url = urlparse(url)
            # 提取域名后的路径作为Key（例如：url是https://img.xiaoying.org.cn/img/xxx.gif → Key是img/xxx.gif）
            key = parsed_url.path.lstrip('/')  # 去掉路径开头的/，得到正确的Key
            # 用COS客户端鉴权下载
            # response = cos_client.get_object(Bucket=COS_BUCKET, Key=key)
            # image_data = response['Body'].get_raw_stream().read()
            image_data = read_cos_image_pure_complete(cos_client, COS_BUCKET, key)
            print(f"从COS下载图片: {key}")
        else:
            # ========== 原有逻辑：普通公网图片下载 ==========
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            if not response.headers.get('content-type', '').startswith('image/'):
                print(
                    f"警告: URL {url} 的Content-Type为 {response.headers.get('content-type', 'unknown')}，但仍尝试作为图片处理")
            image_data = response.content

        # 验证下载的数据是否为空
        if not image_data or len(image_data) == 0:
            raise ValueError(f"从URL {url} 下载的图片数据为空")

        return image_data
    except Exception as e:
        raise ValueError(f"图片下载失败: {str(e)}")


def read_local_image(file_path: str) -> bytes:
    """
    功能描述: 读取本地图片文件数据
    参数说明:
    - file_path (str): 必须。本地图片文件路径
    返回值:
    - bytes: 读取的图片二进制数据
    异常处理: 当文件不存在或不是有效图片时抛出ValueError异常
    """
    try:
        if not os.path.exists(file_path):
            raise ValueError(f"文件不存在: {file_path}")

        # 检查文件扩展名是否为图片格式
        _, ext = os.path.splitext(file_path)
        if ext.lower() not in ['.jpg', '.jpeg', '.png', '.bmp', '.webp', '.gif', '.tiff']:
            raise ValueError(f"不支持的图片格式: {ext}")

        with open(file_path, 'rb') as f:
            return f.read()
    except Exception as e:
        raise ValueError(f"读取本地图片失败: {str(e)}")


def upload_to_cos(client: CosS3Client, bucket: str, region: str, key: str, data: bytes) -> str:
    """
    功能描述: 上传数据到COS存储桶
    参数说明:
    - client (CosS3Client): 必须。COS客户端实例
    - bucket (str): 必须。存储桶名称
    - region (str): 必须。存储桶区域
    - key (str): 必须。存储的文件键名
    - data (bytes): 必须。要上传的二进制数据
    返回值:
    - str: 上传后的文件URL
    异常处理: 当上传失败时抛出ValueError异常
    """
    try:
        response = client.put_object(
            Bucket=bucket,
            Key=key,
            Body=data
        )
        return f"https://{bucket}.cos.{region}.myqcloud.com/{key}"
    except Exception as e:
        raise ValueError(f"COS上传失败: {str(e)}")