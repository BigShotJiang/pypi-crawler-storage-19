from typing import Dict, List, Optional, Any
from qcloud_cos import CosConfig
from ._utils import *

# 添加一个虚拟的 cgi 模块以解决导入问题
try:
    import cgi
except ImportError:
    # 如果 cgi 模块不存在（在较新版本的 Python 中），我们创建一个空的模拟模块
    import sys
    import types
    cgi_module = types.ModuleType('cgi')
    sys.modules['cgi'] = cgi_module

from fastmcp import FastMCP

COS_SECRET_ID = os.getenv("COS_SECRET_ID", "")
COS_SECRET_KEY = os.getenv("COS_SECRET_KEY", "")
COS_REGION = os.getenv("COS_REGION", "")
COS_BUCKET = os.getenv("COS_BUCKET", "")
COS_CUSTOM_DOMAIN = os.getenv("COS_CUSTOM_DOMAIN", "")

# 检查必要的环境变量
if not COS_SECRET_ID or not COS_SECRET_KEY or not COS_REGION or not COS_BUCKET:
    raise ValueError("缺少必要的COS认证信息，请设置环境变量COS_SECRET_ID, COS_SECRET_KEY, COS_REGION, COS_BUCKET")

mcp = FastMCP("CosImageToAvifConverter", instructions="提供将腾讯云COS中的图片批量转换为AVIF格式的功能，支持指定图片URL列表或存储桶内图片批量处理")

"""
   *********  MCP 工具 ******************
"""

"""
    功能描述: 将指定URL列表中的图片批量转换为AVIF格式并上传到COS
    参数说明:
    - image_urls (List[str]): 必须。需要转换的图片URL列表
    - output_prefix (Optional[str]): 可选。输出文件的前缀，默认为'converted'
    返回值:
    - Dict[str, Any]: 包含原始URL和转换后AVIF URL映射的字典
    异常处理: 当图片下载或转换失败时，对应条目会包含错误信息
"""
def _convert_cos_images_to_avif_impl(image_urls: List[str], output_prefix: Optional[str] = "converted") -> Dict[
    str, Any]:
    """
    核心修改：支持传入【本地图片路径】+【远程URL】，自动识别并处理，保留所有原有逻辑
    """
    if not image_urls:
        return {"error": "图片路径/URL列表不能为空"}

    result = {}
    cos_config = CosConfig(Region=COS_REGION, SecretId=COS_SECRET_ID, SecretKey=COS_SECRET_KEY)
    cos_client = CosS3Client(cos_config)

    for path in image_urls:  # 变量名改为path更贴合，兼容url/本地路径，不影响功能
        try:
            # ========== 核心新增：区分【远程URL】和【本地图片路径】 ==========
            if is_url(path):
                # 逻辑1：是远程URL → 下载图片二进制数据
                original_key = path.split('/')[-1].split('?')[0]
                image_data = download_image_from_url(path, cos_client)
            else:
                # 逻辑2：是本地路径 → 读取本地图片二进制数据
                original_key = os.path.basename(path)  # 提取本地文件的文件名(含后缀)
                image_data = read_local_image(path)

            # ========== 原有公共逻辑：转换+上传 完全不变 ==========
            avif_data = convert_image_to_avif(image_data)
            # 生成avif文件名：原文件名去除后缀 + .avif
            avif_filename = ".".join(original_key.split('.')[:-1]) + ".avif"
            output_key = f"{output_prefix}/{avif_filename}"
            # 上传到COS并获取地址
            avif_url = upload_to_cos(cos_client, COS_BUCKET, COS_REGION, output_key, avif_data)
            result[path] = avif_url

        except Exception as e:
            # 统一异常捕获：无论本地读取/URL下载/转换/上传失败，都记录错误信息
            result[path] = f"转换失败: {str(e)}"

    return {"conversions": result}


@mcp.tool()
def convert_cos_images_to_avif(image_urls: List[str], output_prefix: Optional[str] = "converted") -> Dict[str, Any]:
    """将指定URL/本地路径列表中的图片批量转换为AVIF格式并上传到COS"""
    return _convert_cos_images_to_avif_impl(image_urls, output_prefix)


# 使基础实现也可供外部使用
convert_cos_images_to_avif_func = _convert_cos_images_to_avif_impl

"""
   功能描述: 批量转换COS存储桶中指定前缀的图片为AVIF格式
   参数说明:
   - prefix (Optional[str]): 可选。COS存储桶中的文件前缀，默认为空
   - max_files (Optional[int]): 可选。最大处理文件数量
   返回值:
   - Dict[str, Any]: 包含处理结果和统计信息的字典
   异常处理: 当COS操作失败时抛出ValueError异常
"""
def _convert_cos_bucket_images_to_avif_impl(prefix: Optional[str] = "", max_files: Optional[int] = 100000) -> Dict[str, Any]:
    if not prefix:
        prefix = ""
    
    result = {"converted": [], "failed": [], "total_processed": 0}
    cos_config = CosConfig(Region=COS_REGION, SecretId=COS_SECRET_ID, SecretKey=COS_SECRET_KEY)
    cos_client = CosS3Client(cos_config)
    
    try:
        marker = ""
        file_count = 0
        # 添加标志来跟踪是否已经打印过"处理完毕"消息
        contents_not_found_printed = False
        is_truncated_false_printed = False
        
        while file_count < max_files:
            response = cos_client.list_objects(
                Bucket=COS_BUCKET,
                Prefix=prefix,
                Marker=marker,
                MaxKeys=100
            )
            
            if 'Contents' not in response:
                if not contents_not_found_printed:
                    print("所有图片都转成avif，处理完毕")
                    contents_not_found_printed = True
                break
                
            for content in response['Contents']:
                if file_count >= max_files:
                    print("图片处理数量已到最大值，强制结束")
                    break
                key = content['Key']
                # 如果文件已经是AVIF格式，则跳过处理
                if key.lower().endswith('.avif'):
                    print(f"文件 {key} 已经是AVIF格式，跳过处理")
                    continue
                if not any(key.lower().endswith(ext) for ext in ['.jpg', '.jpeg', '.png', '.bmp', '.webp', '.gif']):
                    continue
                    
                try:
                    response = cos_client.get_object(
                        Bucket=COS_BUCKET,
                        Key=key
                    )
                    image_data = response['Body'].get_raw_stream().read()
                    avif_data = convert_image_to_avif(image_data)
                    output_key = f"avif_{key.rsplit('.', 1)[0]}.avif"
                    avif_url = upload_to_cos(cos_client, COS_BUCKET, COS_REGION, output_key, avif_data)
                    result["converted"].append({"original": key, "avif": avif_url})
                    file_count += 1
                except Exception as e:
                    result["failed"].append({"file": key, "error": str(e)})
                    file_count += 1
                    
            # 修复：COS API返回的IsTruncated是字符串，需要正确处理
            is_truncated = response.get('IsTruncated', 'false')
            if is_truncated == 'false' or is_truncated == False:
                if not is_truncated_false_printed:
                    print("所有图片已处理完，无分页")
                    is_truncated_false_printed = True
                break
            # 修复：NextMarker可能不存在，需要检查后再获取
            marker = response.get('NextMarker', '')
            # 如果NextMarker为空或None，也应结束循环
            if not marker:
                break
            
        result["total_processed"] = len(result["converted"]) + len(result["failed"])
        return result
    except Exception as e:
        raise ValueError(f"COS批量处理失败: {str(e)}")

@mcp.tool()
def convert_cos_bucket_images_to_avif(prefix: Optional[str] = "", max_files: Optional[int] =100000) -> Dict[str, Any]:
    """批量转换COS存储桶中指定前缀的图片为AVIF格式"""
    return _convert_cos_bucket_images_to_avif_impl(prefix, max_files)

# 使基础实现也可供外部使用
convert_cos_bucket_images_to_avif_func = _convert_cos_bucket_images_to_avif_impl

"""
    功能描述: 批量删除COS存储桶中指定前缀下的文件，支持排除特定扩展名
    参数说明:
    - bucket (str): 必须。COS存储桶名称
    - exclude_extensions (List[str]): 必须。要排除（不删除）的文件扩展名列表
    - prefix (str): 可选。要清理的文件前缀，默认为空
    - images_only (bool): 可选。是否只处理图片文件，默认False
    返回值:
    - Dict[str, Any]: 包含删除文件列表和统计信息的字典
    异常处理: 当COS操作失败时抛出ValueError异常
"""
def _delete_non_avif_cos_images_impl(bucket: str, exclude_extensions: List[str], prefix: str = "", max_files: Optional[int] = 100000, images_only: bool = True) -> Dict[
    str, Any]:
    # 1. 初始化返回结果，skipped用集合自动去重（核心去重方案）
    result = { "deleted": [], "failed": [], "skipped": set(), "total_processed": 0, "total_file": 0 }
    # 2. 使用传入的排除扩展名列表，转换为小写集合以便快速查找
    exclude_extensions_set = {ext.lower() for ext in exclude_extensions}
    # 3. 定义图片扩展名列表
    image_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.gif', '.tiff', '.svg', '.avif'}

    cos_config = CosConfig(Region=COS_REGION, SecretId=COS_SECRET_ID, SecretKey=COS_SECRET_KEY)
    cos_client = CosS3Client(cos_config)

    try:
        marker = ""
        file_count = 0
        # 添加标志来跟踪是否已经打印过相应消息
        contents_not_found_printed = False
        is_truncated_false_printed = False
        
        while file_count < max_files:
            response = cos_client.list_objects(
                Bucket=bucket,
                Prefix=prefix,
                Marker=marker,
                MaxKeys=100
            )

            if 'Contents' not in response:
                if not contents_not_found_printed:
                    print("指定文件都删除完毕，自动结束")
                    contents_not_found_printed = True
                break

            for content in response['Contents']:
                # 修复BUG1：先计数，再判断是否超限，杜绝超限后继续计数
                file_count += 1
                if file_count >= max_files:
                    print("文件删除处理数量已到最大值，提前结束")
                    break

                key = content['Key']
                key_lower = key.lower()
                # 获取文件扩展名
                file_ext = '.' + key_lower.split('.')[-1] if '.' in key_lower else ''
                
                # 根据images_only参数决定是否只处理图片
                should_process = True
                if images_only:
                    # 如果只处理图片，则检查是否为图片格式
                    is_image = any(key_lower.endswith(img_ext) for img_ext in image_extensions)
                    if not is_image:
                        should_process = False
                
                # 检查是否在排除列表中
                is_excluded = file_ext in exclude_extensions_set
                
                # 不在排除列表中，且应该处理，则删除
                if not is_excluded and should_process:
                    # 非排除的文件，执行删除操作
                    try:
                        cos_client.delete_object(Bucket=bucket, Key=key)
                        result["deleted"].append(key)
                    except Exception as e:
                        result["failed"].append({"file": key, "error": str(e)})
                elif is_excluded:
                    # 排除的文件跳过
                    result["skipped"].add(key)
                elif images_only and not any(key_lower.endswith(img_ext) for img_ext in image_extensions):
                    # 非图片文件（当images_only为True时）跳过
                    result["skipped"].add(key)

            # 修复：COS API返回的IsTruncated是字符串，需要正确处理
            is_truncated = response.get('IsTruncated', 'false')
            if is_truncated == 'false' or is_truncated == False:
                if not is_truncated_false_printed:
                    print("所有文件已无分页，自动结束")
                    is_truncated_false_printed = True
                break
            # 修复：NextMarker可能不存在，需要检查后再获取
            marker = response.get('NextMarker', '')
            # 如果NextMarker为空或None，也应结束循环
            if not marker:
                print("marker为空")
                break

        # 关键1：集合转列表，保证返回格式和原代码一致，无兼容问题
        result["skipped"] = list(result["skipped"])
        # 总数统计用真实处理的文件数，精准无误
        result["total_file"] = file_count
        result["total_processed"] = len(result["deleted"]) + len(result["skipped"]) + len(result["failed"])

        return result
    except Exception as e:
        raise ValueError(f"COS批量删除失败: {str(e)}")


@mcp.tool()
def delete_non_avif_cos_images(bucket: str, exclude_extensions: List[str], prefix: str = "", max_files: Optional[int] = 100000, images_only: bool = True) -> Dict[str, Any]:
    """批量删除COS存储桶中指定前缀下的文件，支持排除特定扩展名"""
    return _delete_non_avif_cos_images_impl(bucket, exclude_extensions, prefix, max_files, images_only)

# 使基础实现也可供外部使用
delete_non_avif_cos_images_func = _delete_non_avif_cos_images_impl


"""
    功能描述: 重命名COS中的"文件夹"（实际上是更改对象键名的前缀）
    参数说明:
    - old_prefix (str): 必须。原前缀（相当于原文件夹名）
    - new_prefix (str): 必须。新前缀（相当于新文件夹名）
    返回值:
    - Dict[str, Any]: 包含重命名操作结果和统计信息的字典
    异常处理: 当操作失败时抛出ValueError异常
"""
def _rename_cos_folder_impl(old_prefix: str, new_prefix: str, is_delete_old_object: bool = True) -> Dict[str, Any]:

    if not old_prefix:
        raise ValueError("原前缀不能为空")
    if not new_prefix:
        raise ValueError("新前缀不能为空")
    
    result = {"renamed": [], "failed": [], "total_processed": 0}
    cos_config = CosConfig(Region=COS_REGION, SecretId=COS_SECRET_ID, SecretKey=COS_SECRET_KEY)
    cos_client = CosS3Client(cos_config)
    
    try:
        marker = ""
        while True:
            response = cos_client.list_objects(
                Bucket=COS_BUCKET,
                Prefix=old_prefix,
                Marker=marker,
                MaxKeys=100
            )
            
            if 'Contents' not in response:
                break
            
            for content in response['Contents']:
                old_key = content['Key']
                
                # 构造新键名：将旧前缀替换为新前缀
                if old_key.startswith(old_prefix):
                    new_key = new_prefix + old_key[len(old_prefix):]
                    
                    try:
                        # 复制对象到新键名
                        cos_client.copy_object(
                            Bucket=COS_BUCKET,
                            Key=new_key,
                            CopySource={
                                'Bucket': COS_BUCKET,
                                'Region': COS_REGION,
                                'Key': old_key
                            }
                        )

                        if is_delete_old_object:
                            # 删除原对象
                            cos_client.delete_object(
                                Bucket=COS_BUCKET,
                                Key=old_key
                            )
                        
                        result["renamed"].append({"old": old_key, "new": new_key})
                    except Exception as e:
                        result["failed"].append({"file": old_key, "error": str(e)})
                else:
                    # 这种情况不应该发生，但为了安全起见处理
                    continue
            
            # 检查是否还有更多结果
            is_truncated = response.get('IsTruncated', 'false')
            if is_truncated == 'false' or is_truncated == False:
                break
            # 修复：NextMarker可能不存在，需要检查后再获取
            marker = response.get('NextMarker', '')
            # 如果NextMarker为空或None，也应结束循环
            if not marker:
                print("marker为空")
                break

        result["total_processed"] = len(result["renamed"]) + len(result["failed"])
        print("重命名结果:" + str(result["total_processed"]))
        return result
    except Exception as e:
        raise ValueError(f"重命名操作失败: {str(e)}")

@mcp.tool()
def rename_cos_folder(old_prefix: str, new_prefix: str, is_delete_old_object: bool = True) -> Dict[str, Any]:
    """重命名COS中的"文件夹"（实际上是更改对象键名的前缀）"""
    return _rename_cos_folder_impl(old_prefix, new_prefix, is_delete_old_object)

# 使基础实现也可供外部使用
rename_cos_folder_func = _rename_cos_folder_impl

def main():
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()
