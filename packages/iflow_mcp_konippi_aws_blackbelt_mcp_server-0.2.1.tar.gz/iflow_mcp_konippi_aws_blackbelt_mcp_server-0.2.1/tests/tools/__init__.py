"""Tests for tools module."""
