[![PyPI - Python](https://img.shields.io/badge/python-v3.7+-blue.svg)](https://pypi.org/project/kptopic/)
[![docs](https://img.shields.io/badge/docs-Passing-green.svg)](https://github.com/pengKiina/KPTopic/)
[![PyPI - PyPi](https://img.shields.io/pypi/v/kptopic)](https://pypi.org/project/kptopic/)
[![PyPI - License](https://img.shields.io/badge/license-MIT-green.svg)](https://github.com/pengKiina/KPTopic/blob/main/LICENSE)



# KPTopic
<img src="https://github.com/Atsaniik/kptopic/blob/main/images/kptLogo.png" width="40%" height="20%" align="right" />

*  No more Topic Modeling
*  No need Training 
*  Text Big + Small
*  Emoji + Sentiment Score 

KPTopic: a graph-based approach to represent perception (text in general) by key parts of speech. KPTopic solved the coherence crux that current topic modeling algorithms are trying to deal with but failed. KPTopic extracts the topics from text corpus syntactically, semantically and pragmatically instead of a meaningless combination of words from topic modeling.


## Key Parts: Noun, Adjective, Verb and Emoji 

KPTopic Vs Topic Modeling results from the following text:

``` “Thai food was great we loved it. Thiland also has beautiful beach resorts, we will come to Thailand again👍” ```

* KPTopic Result 

<img style="border:1px solid black"
src="https://github.com/pengKiina/KPTopic/raw/main/images/keyparts_sent_network.png" width="40%" height="40%" align="center" />

* Topic Modeling Result

```['food','thailand','resort','great','love', 'beautiful']```


## Installation

```bash
 # pip install kptopic
 # pip install git+https://github.com/Atsaniik/kptopic.git  
```


## Getting Started
For an in-depth overview of the features of KPTopic
you can check the [**Documents**](https://medium.com/@egalitrans/topic-modeling-is-dad-long-live-kptopic-a1998a94a0b0) or you can follow along 
with one of the examples as follows:

| Name  | Link  |
|---|---|
| KPTopic Quick Start | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1hjAU-_RP7GGMm6rnpdJZR7LSY0KS81E?usp=sharing) |

## Visualization Examples 
* 1 NLP Target  

Original sentence: """Thai food was great,delicousr and not expensive, we loved it. We visited 3 beach resorts, they are higly recommened... We had "Fire-Vodka" !!!"""

<img src="https://github.com/pengKiina/KPTopic/raw/main/images/nlp_target.png" width="70%" height="35%" align="center" />

* 2 Keyparts Wordclouds

The following wordclouds are generated from a real example of corpus comprised of reviews by those who visit Thailand.

<img src="https://github.com/pengKiina/KPTopic/raw/main/images/keypart_wrdcloud.png" width="35%" height="35%" align="center" />

* 3 Community and Gray Perceptual Unit Networks 

<img src="https://github.com/pengKiina/KPTopic/raw/main/images/communit_gray.gif" width="70%" height="50%" align="center" />



## Citation
To cite the [KPTopic paper](https://arxiv.org/abs/29.11844), please use the following bibtex reference:

```bibtext
@article{pengyang,
  title={KPTopic},
  author={Peng, Yang},
  journal={a1},
  year={202}
}
```





