# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AppStatisticResponseInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'app_name': 'str',
        'num': 'int'
    }

    attribute_map = {
        'app_name': 'app_name',
        'num': 'num'
    }

    def __init__(self, app_name=None, num=None):
        r"""AppStatisticResponseInfo

        The model defined in huaweicloud sdk

        :param app_name: **参数解释**: 软件名称 **取值范围**: 字符长度1-128位 
        :type app_name: str
        :param num: **参数解释**: 进程数量 **取值范围**: 字符长度0-100000位 
        :type num: int
        """
        
        

        self._app_name = None
        self._num = None
        self.discriminator = None

        if app_name is not None:
            self.app_name = app_name
        if num is not None:
            self.num = num

    @property
    def app_name(self):
        r"""Gets the app_name of this AppStatisticResponseInfo.

        **参数解释**: 软件名称 **取值范围**: 字符长度1-128位 

        :return: The app_name of this AppStatisticResponseInfo.
        :rtype: str
        """
        return self._app_name

    @app_name.setter
    def app_name(self, app_name):
        r"""Sets the app_name of this AppStatisticResponseInfo.

        **参数解释**: 软件名称 **取值范围**: 字符长度1-128位 

        :param app_name: The app_name of this AppStatisticResponseInfo.
        :type app_name: str
        """
        self._app_name = app_name

    @property
    def num(self):
        r"""Gets the num of this AppStatisticResponseInfo.

        **参数解释**: 进程数量 **取值范围**: 字符长度0-100000位 

        :return: The num of this AppStatisticResponseInfo.
        :rtype: int
        """
        return self._num

    @num.setter
    def num(self, num):
        r"""Sets the num of this AppStatisticResponseInfo.

        **参数解释**: 进程数量 **取值范围**: 字符长度0-100000位 

        :param num: The num of this AppStatisticResponseInfo.
        :type num: int
        """
        self._num = num

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AppStatisticResponseInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
