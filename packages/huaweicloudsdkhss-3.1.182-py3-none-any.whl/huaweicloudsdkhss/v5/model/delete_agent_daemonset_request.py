# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteAgentDaemonsetRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'region': 'str',
        'enterprise_project_id': 'str',
        'cluster_id': 'str',
        'invoked_service': 'str'
    }

    attribute_map = {
        'region': 'region',
        'enterprise_project_id': 'enterprise_project_id',
        'cluster_id': 'cluster_id',
        'invoked_service': 'invoked_service'
    }

    def __init__(self, region=None, enterprise_project_id=None, cluster_id=None, invoked_service=None):
        r"""DeleteAgentDaemonsetRequest

        The model defined in huaweicloud sdk

        :param region: **参数解释**: 区域ID，用于查询目的区域内的资产。获取方式请参见[获取区域ID](hss_02_0026.xml)。 **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 
        :type region: str
        :param enterprise_project_id: **参数解释**: 企业项目ID，用于过滤不同企业项目下的资产。获取方式请参见[获取企业项目ID](hss_02_0027.xml)。 如需查询所有企业项目下的资产请传参“all_granted_eps”。 **约束限制**: 开通企业项目功能后才需要配置企业项目ID参数。 **取值范围**: 字符长度1-256位 **默认取值**: 0，表示默认企业项目（default）。 
        :type enterprise_project_id: str
        :param cluster_id: **参数解释**:  集群id **约束限制**: 不涉及 **取值范围**: 长度范围1-256位 **默认取值**: 不涉及 
        :type cluster_id: str
        :param invoked_service: **参数解释**: 调用服务，cce集成防护调用场景使用。 **约束限制**: 不涉及 **取值范围**: 包含以下两种： - hss：hss服务。 - cce：cce服务，cce集成防护调用需要传参cce。  **默认取值**: hss 
        :type invoked_service: str
        """
        
        

        self._region = None
        self._enterprise_project_id = None
        self._cluster_id = None
        self._invoked_service = None
        self.discriminator = None

        if region is not None:
            self.region = region
        if enterprise_project_id is not None:
            self.enterprise_project_id = enterprise_project_id
        self.cluster_id = cluster_id
        if invoked_service is not None:
            self.invoked_service = invoked_service

    @property
    def region(self):
        r"""Gets the region of this DeleteAgentDaemonsetRequest.

        **参数解释**: 区域ID，用于查询目的区域内的资产。获取方式请参见[获取区域ID](hss_02_0026.xml)。 **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 

        :return: The region of this DeleteAgentDaemonsetRequest.
        :rtype: str
        """
        return self._region

    @region.setter
    def region(self, region):
        r"""Sets the region of this DeleteAgentDaemonsetRequest.

        **参数解释**: 区域ID，用于查询目的区域内的资产。获取方式请参见[获取区域ID](hss_02_0026.xml)。 **约束限制**: 不涉及 **取值范围**: 字符长度1-128位 **默认取值**: 不涉及 

        :param region: The region of this DeleteAgentDaemonsetRequest.
        :type region: str
        """
        self._region = region

    @property
    def enterprise_project_id(self):
        r"""Gets the enterprise_project_id of this DeleteAgentDaemonsetRequest.

        **参数解释**: 企业项目ID，用于过滤不同企业项目下的资产。获取方式请参见[获取企业项目ID](hss_02_0027.xml)。 如需查询所有企业项目下的资产请传参“all_granted_eps”。 **约束限制**: 开通企业项目功能后才需要配置企业项目ID参数。 **取值范围**: 字符长度1-256位 **默认取值**: 0，表示默认企业项目（default）。 

        :return: The enterprise_project_id of this DeleteAgentDaemonsetRequest.
        :rtype: str
        """
        return self._enterprise_project_id

    @enterprise_project_id.setter
    def enterprise_project_id(self, enterprise_project_id):
        r"""Sets the enterprise_project_id of this DeleteAgentDaemonsetRequest.

        **参数解释**: 企业项目ID，用于过滤不同企业项目下的资产。获取方式请参见[获取企业项目ID](hss_02_0027.xml)。 如需查询所有企业项目下的资产请传参“all_granted_eps”。 **约束限制**: 开通企业项目功能后才需要配置企业项目ID参数。 **取值范围**: 字符长度1-256位 **默认取值**: 0，表示默认企业项目（default）。 

        :param enterprise_project_id: The enterprise_project_id of this DeleteAgentDaemonsetRequest.
        :type enterprise_project_id: str
        """
        self._enterprise_project_id = enterprise_project_id

    @property
    def cluster_id(self):
        r"""Gets the cluster_id of this DeleteAgentDaemonsetRequest.

        **参数解释**:  集群id **约束限制**: 不涉及 **取值范围**: 长度范围1-256位 **默认取值**: 不涉及 

        :return: The cluster_id of this DeleteAgentDaemonsetRequest.
        :rtype: str
        """
        return self._cluster_id

    @cluster_id.setter
    def cluster_id(self, cluster_id):
        r"""Sets the cluster_id of this DeleteAgentDaemonsetRequest.

        **参数解释**:  集群id **约束限制**: 不涉及 **取值范围**: 长度范围1-256位 **默认取值**: 不涉及 

        :param cluster_id: The cluster_id of this DeleteAgentDaemonsetRequest.
        :type cluster_id: str
        """
        self._cluster_id = cluster_id

    @property
    def invoked_service(self):
        r"""Gets the invoked_service of this DeleteAgentDaemonsetRequest.

        **参数解释**: 调用服务，cce集成防护调用场景使用。 **约束限制**: 不涉及 **取值范围**: 包含以下两种： - hss：hss服务。 - cce：cce服务，cce集成防护调用需要传参cce。  **默认取值**: hss 

        :return: The invoked_service of this DeleteAgentDaemonsetRequest.
        :rtype: str
        """
        return self._invoked_service

    @invoked_service.setter
    def invoked_service(self, invoked_service):
        r"""Sets the invoked_service of this DeleteAgentDaemonsetRequest.

        **参数解释**: 调用服务，cce集成防护调用场景使用。 **约束限制**: 不涉及 **取值范围**: 包含以下两种： - hss：hss服务。 - cce：cce服务，cce集成防护调用需要传参cce。  **默认取值**: hss 

        :param invoked_service: The invoked_service of this DeleteAgentDaemonsetRequest.
        :type invoked_service: str
        """
        self._invoked_service = invoked_service

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteAgentDaemonsetRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
