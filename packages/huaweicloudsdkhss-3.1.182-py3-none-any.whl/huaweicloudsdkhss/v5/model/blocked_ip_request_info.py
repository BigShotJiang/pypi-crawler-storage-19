# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BlockedIpRequestInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'host_id': 'str',
        'src_ip': 'str',
        'login_type': 'str'
    }

    attribute_map = {
        'host_id': 'host_id',
        'src_ip': 'src_ip',
        'login_type': 'login_type'
    }

    def __init__(self, host_id=None, src_ip=None, login_type=None):
        r"""BlockedIpRequestInfo

        The model defined in huaweicloud sdk

        :param host_id: **参数解释**： 服务器（主机）的唯一标识ID **取值范围**： 字符长度1-64位 
        :type host_id: str
        :param src_ip: 攻击源IP
        :type src_ip: str
        :param login_type: **参数解释**： 登录类型 **约束限制**: 不涉及 **取值范围**: - mysql：mysql服务。 - rdp：rdp服务。 - ssh：ssh服务。 - vsftp：vsftp服务。  **默认取值**: 不涉及 
        :type login_type: str
        """
        
        

        self._host_id = None
        self._src_ip = None
        self._login_type = None
        self.discriminator = None

        self.host_id = host_id
        self.src_ip = src_ip
        self.login_type = login_type

    @property
    def host_id(self):
        r"""Gets the host_id of this BlockedIpRequestInfo.

        **参数解释**： 服务器（主机）的唯一标识ID **取值范围**： 字符长度1-64位 

        :return: The host_id of this BlockedIpRequestInfo.
        :rtype: str
        """
        return self._host_id

    @host_id.setter
    def host_id(self, host_id):
        r"""Sets the host_id of this BlockedIpRequestInfo.

        **参数解释**： 服务器（主机）的唯一标识ID **取值范围**： 字符长度1-64位 

        :param host_id: The host_id of this BlockedIpRequestInfo.
        :type host_id: str
        """
        self._host_id = host_id

    @property
    def src_ip(self):
        r"""Gets the src_ip of this BlockedIpRequestInfo.

        攻击源IP

        :return: The src_ip of this BlockedIpRequestInfo.
        :rtype: str
        """
        return self._src_ip

    @src_ip.setter
    def src_ip(self, src_ip):
        r"""Sets the src_ip of this BlockedIpRequestInfo.

        攻击源IP

        :param src_ip: The src_ip of this BlockedIpRequestInfo.
        :type src_ip: str
        """
        self._src_ip = src_ip

    @property
    def login_type(self):
        r"""Gets the login_type of this BlockedIpRequestInfo.

        **参数解释**： 登录类型 **约束限制**: 不涉及 **取值范围**: - mysql：mysql服务。 - rdp：rdp服务。 - ssh：ssh服务。 - vsftp：vsftp服务。  **默认取值**: 不涉及 

        :return: The login_type of this BlockedIpRequestInfo.
        :rtype: str
        """
        return self._login_type

    @login_type.setter
    def login_type(self, login_type):
        r"""Sets the login_type of this BlockedIpRequestInfo.

        **参数解释**： 登录类型 **约束限制**: 不涉及 **取值范围**: - mysql：mysql服务。 - rdp：rdp服务。 - ssh：ssh服务。 - vsftp：vsftp服务。  **默认取值**: 不涉及 

        :param login_type: The login_type of this BlockedIpRequestInfo.
        :type login_type: str
        """
        self._login_type = login_type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BlockedIpRequestInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
