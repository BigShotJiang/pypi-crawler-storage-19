# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeleteBackupHostRequestInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'backup_host_id_list': 'list[str]'
    }

    attribute_map = {
        'backup_host_id_list': 'backup_host_id_list'
    }

    def __init__(self, backup_host_id_list=None):
        r"""DeleteBackupHostRequestInfo

        The model defined in huaweicloud sdk

        :param backup_host_id_list: **参数解释**: 需要删除的备份服务器ID列表，填写的备份服务器ID必须是已运行中的备份服务器ID **约束限制**: 需要使用 ListBackupHostsInfo 接口查询已运行中的远端备份服务器，在 ListBackupHostsInfo 接口的响应体中，backup_host_status 等于 1 的 backup_host_id 是已运行的远端备份服务器ID **取值范围**: 不超过100条 **默认取值**: 不涉及 
        :type backup_host_id_list: list[str]
        """
        
        

        self._backup_host_id_list = None
        self.discriminator = None

        self.backup_host_id_list = backup_host_id_list

    @property
    def backup_host_id_list(self):
        r"""Gets the backup_host_id_list of this DeleteBackupHostRequestInfo.

        **参数解释**: 需要删除的备份服务器ID列表，填写的备份服务器ID必须是已运行中的备份服务器ID **约束限制**: 需要使用 ListBackupHostsInfo 接口查询已运行中的远端备份服务器，在 ListBackupHostsInfo 接口的响应体中，backup_host_status 等于 1 的 backup_host_id 是已运行的远端备份服务器ID **取值范围**: 不超过100条 **默认取值**: 不涉及 

        :return: The backup_host_id_list of this DeleteBackupHostRequestInfo.
        :rtype: list[str]
        """
        return self._backup_host_id_list

    @backup_host_id_list.setter
    def backup_host_id_list(self, backup_host_id_list):
        r"""Sets the backup_host_id_list of this DeleteBackupHostRequestInfo.

        **参数解释**: 需要删除的备份服务器ID列表，填写的备份服务器ID必须是已运行中的备份服务器ID **约束限制**: 需要使用 ListBackupHostsInfo 接口查询已运行中的远端备份服务器，在 ListBackupHostsInfo 接口的响应体中，backup_host_status 等于 1 的 backup_host_id 是已运行的远端备份服务器ID **取值范围**: 不超过100条 **默认取值**: 不涉及 

        :param backup_host_id_list: The backup_host_id_list of this DeleteBackupHostRequestInfo.
        :type backup_host_id_list: list[str]
        """
        self._backup_host_id_list = backup_host_id_list

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteBackupHostRequestInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
