# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ChangeClusterEventsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total_num': 'int',
        'last_update_time': 'int',
        'data_list': 'list[ClusterEventResponseInfo]'
    }

    attribute_map = {
        'total_num': 'total_num',
        'last_update_time': 'last_update_time',
        'data_list': 'data_list'
    }

    def __init__(self, total_num=None, last_update_time=None, data_list=None):
        r"""ChangeClusterEventsResponse

        The model defined in huaweicloud sdk

        :param total_num: **参数解释**: 总数 **取值范围**: 最小值0，最大值10000 
        :type total_num: int
        :param last_update_time: **参数解释**: 最近更新时间 **取值范围**: 最小值0，最大值9223372036854775807 
        :type last_update_time: int
        :param data_list: **参数解释**: 集群安全事件列表 **取值范围**: 取值0-10000个ClusterEventResponseInfo对象 
        :type data_list: list[:class:`huaweicloudsdkhss.v5.ClusterEventResponseInfo`]
        """
        
        super().__init__()

        self._total_num = None
        self._last_update_time = None
        self._data_list = None
        self.discriminator = None

        if total_num is not None:
            self.total_num = total_num
        if last_update_time is not None:
            self.last_update_time = last_update_time
        if data_list is not None:
            self.data_list = data_list

    @property
    def total_num(self):
        r"""Gets the total_num of this ChangeClusterEventsResponse.

        **参数解释**: 总数 **取值范围**: 最小值0，最大值10000 

        :return: The total_num of this ChangeClusterEventsResponse.
        :rtype: int
        """
        return self._total_num

    @total_num.setter
    def total_num(self, total_num):
        r"""Sets the total_num of this ChangeClusterEventsResponse.

        **参数解释**: 总数 **取值范围**: 最小值0，最大值10000 

        :param total_num: The total_num of this ChangeClusterEventsResponse.
        :type total_num: int
        """
        self._total_num = total_num

    @property
    def last_update_time(self):
        r"""Gets the last_update_time of this ChangeClusterEventsResponse.

        **参数解释**: 最近更新时间 **取值范围**: 最小值0，最大值9223372036854775807 

        :return: The last_update_time of this ChangeClusterEventsResponse.
        :rtype: int
        """
        return self._last_update_time

    @last_update_time.setter
    def last_update_time(self, last_update_time):
        r"""Sets the last_update_time of this ChangeClusterEventsResponse.

        **参数解释**: 最近更新时间 **取值范围**: 最小值0，最大值9223372036854775807 

        :param last_update_time: The last_update_time of this ChangeClusterEventsResponse.
        :type last_update_time: int
        """
        self._last_update_time = last_update_time

    @property
    def data_list(self):
        r"""Gets the data_list of this ChangeClusterEventsResponse.

        **参数解释**: 集群安全事件列表 **取值范围**: 取值0-10000个ClusterEventResponseInfo对象 

        :return: The data_list of this ChangeClusterEventsResponse.
        :rtype: list[:class:`huaweicloudsdkhss.v5.ClusterEventResponseInfo`]
        """
        return self._data_list

    @data_list.setter
    def data_list(self, data_list):
        r"""Sets the data_list of this ChangeClusterEventsResponse.

        **参数解释**: 集群安全事件列表 **取值范围**: 取值0-10000个ClusterEventResponseInfo对象 

        :param data_list: The data_list of this ChangeClusterEventsResponse.
        :type data_list: list[:class:`huaweicloudsdkhss.v5.ClusterEventResponseInfo`]
        """
        self._data_list = data_list

    def to_dict(self):
        import warnings
        warnings.warn("ChangeClusterEventsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ChangeClusterEventsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
