# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ChangeAgentAutoUpgradeStatusRequestInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'enabled': 'bool'
    }

    attribute_map = {
        'enabled': 'enabled'
    }

    def __init__(self, enabled=None):
        r"""ChangeAgentAutoUpgradeStatusRequestInfo

        The model defined in huaweicloud sdk

        :param enabled: **参数解释**： Agent自动升级配置开关状态 **约束限制**: 不涉及 **取值范围**： - true：开启 - false：关闭  **默认取值**: false 
        :type enabled: bool
        """
        
        

        self._enabled = None
        self.discriminator = None

        if enabled is not None:
            self.enabled = enabled

    @property
    def enabled(self):
        r"""Gets the enabled of this ChangeAgentAutoUpgradeStatusRequestInfo.

        **参数解释**： Agent自动升级配置开关状态 **约束限制**: 不涉及 **取值范围**： - true：开启 - false：关闭  **默认取值**: false 

        :return: The enabled of this ChangeAgentAutoUpgradeStatusRequestInfo.
        :rtype: bool
        """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled):
        r"""Sets the enabled of this ChangeAgentAutoUpgradeStatusRequestInfo.

        **参数解释**： Agent自动升级配置开关状态 **约束限制**: 不涉及 **取值范围**： - true：开启 - false：关闭  **默认取值**: false 

        :param enabled: The enabled of this ChangeAgentAutoUpgradeStatusRequestInfo.
        :type enabled: bool
        """
        self._enabled = enabled

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ChangeAgentAutoUpgradeStatusRequestInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
