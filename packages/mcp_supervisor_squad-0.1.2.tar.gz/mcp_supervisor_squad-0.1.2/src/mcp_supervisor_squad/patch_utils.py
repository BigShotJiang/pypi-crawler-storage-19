from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def _extract_text(obj: Any) -> str | None:
    if obj is None:
        return None
    if isinstance(obj, str):
        return obj
    if isinstance(obj, list):
        for item in obj:
            text = _extract_text(item)
            if text:
                return text
        return None
    if isinstance(obj, dict):
        if "item" in obj and isinstance(obj.get("item"), dict):
            item = obj.get("item") or {}
            for key in ("text", "content", "message"):
                if isinstance(item.get(key), str):
                    return item.get(key)
            nested = _extract_text(item)
            if nested:
                return nested
        for key in ("text", "content", "message"):
            if isinstance(obj.get(key), str):
                return obj.get(key)
        return None
    return None


def extract_patch_from_stdout_jsonl(stdout_path: Path, *, max_bytes: int = 5_000_000) -> str | None:
    """
    Extract a git-style patch from Codex JSONL stdout.

    Heuristic: find the longest text segment that contains 'diff --git ' and return from the
    first occurrence onward.
    """
    try:
        raw = stdout_path.read_bytes()
    except FileNotFoundError:
        return None
    if max_bytes > 0 and len(raw) > max_bytes:
        raw = raw[-max_bytes:]
    best: str | None = None
    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line.decode("utf-8", errors="replace"))
        except Exception:
            continue
        text = _extract_text(obj)
        if not text or "diff --git " not in text:
            continue
        start = text.find("diff --git ")
        candidate = text[start:].strip("\n") + "\n"
        if not best or len(candidate) > len(best):
            best = candidate
    return best


def touched_files_from_patch(patch_text: str) -> list[str]:
    files: list[str] = []
    for line in (patch_text or "").splitlines():
        if not line.startswith("diff --git "):
            continue
        parts = line.split()
        if len(parts) >= 4:
            a_path = parts[2]
            b_path = parts[3]
            files.append(f"{a_path}->{b_path}")
    return files


def detect_patch_conflicts(patch_a: str, patch_b: str) -> list[str]:
    """
    Detect overlapping file targets between two patches via 'diff --git' headers.
    Returns a list of conflicting b/ paths (without the 'b/' prefix).
    """
    def b_paths(p: str) -> set[str]:
        out: set[str] = set()
        for line in (p or "").splitlines():
            if not line.startswith("diff --git "):
                continue
            parts = line.split()
            if len(parts) >= 4:
                b = parts[3]
                if b.startswith("b/"):
                    out.add(b[2:])
                else:
                    out.add(b)
        return out

    a = b_paths(patch_a)
    b = b_paths(patch_b)
    return sorted(a.intersection(b))

