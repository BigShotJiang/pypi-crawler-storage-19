"""mcp-supervisor-squad MCP server package (v5 minimal supervisor-squad)."""

from .server import APP_ID, build_server, run_server

__all__ = ["APP_ID", "build_server", "run_server"]
