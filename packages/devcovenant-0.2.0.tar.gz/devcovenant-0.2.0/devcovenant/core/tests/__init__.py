"""Tests for devcovenant."""
