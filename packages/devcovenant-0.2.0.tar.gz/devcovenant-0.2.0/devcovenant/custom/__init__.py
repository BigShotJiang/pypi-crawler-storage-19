"""Repo-specific DevCovenant extensions."""
