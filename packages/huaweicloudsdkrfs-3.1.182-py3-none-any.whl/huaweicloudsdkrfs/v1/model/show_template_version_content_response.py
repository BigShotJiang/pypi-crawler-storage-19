# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowTemplateVersionContentResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'body': 'str',
        'location': 'str'
    }

    attribute_map = {
        'body': 'body',
        'location': 'Location'
    }

    def __init__(self, body=None, location=None):
        r"""ShowTemplateVersionContentResponse

        The model defined in huaweicloud sdk

        :param body: 空响应体
        :type body: str
        :param location: 
        :type location: str
        """
        
        super().__init__()

        self._body = None
        self._location = None
        self.discriminator = None

        if body is not None:
            self.body = body
        if location is not None:
            self.location = location

    @property
    def body(self):
        r"""Gets the body of this ShowTemplateVersionContentResponse.

        空响应体

        :return: The body of this ShowTemplateVersionContentResponse.
        :rtype: str
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ShowTemplateVersionContentResponse.

        空响应体

        :param body: The body of this ShowTemplateVersionContentResponse.
        :type body: str
        """
        self._body = body

    @property
    def location(self):
        r"""Gets the location of this ShowTemplateVersionContentResponse.

        :return: The location of this ShowTemplateVersionContentResponse.
        :rtype: str
        """
        return self._location

    @location.setter
    def location(self, location):
        r"""Sets the location of this ShowTemplateVersionContentResponse.

        :param location: The location of this ShowTemplateVersionContentResponse.
        :type location: str
        """
        self._location = location

    def to_dict(self):
        import warnings
        warnings.warn("ShowTemplateVersionContentResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowTemplateVersionContentResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
