# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdatePrivateProviderMetadataRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'provider_description': 'str',
        'provider_id': 'str'
    }

    attribute_map = {
        'provider_description': 'provider_description',
        'provider_id': 'provider_id'
    }

    def __init__(self, provider_description=None, provider_id=None):
        r"""UpdatePrivateProviderMetadataRequestBody

        The model defined in huaweicloud sdk

        :param provider_description: 私有provider（private-provider）的描述。可用于客户识别被管理的私有provider。
        :type provider_description: str
        :param provider_id: 私有provider（private-provider）的唯一Id。  此Id由资源编排服务在生成provider的时候生成，为UUID。  由于私有provider名仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的私有provider，删除，再重新创建一个同名私有provider。  对于团队并行开发，用户可能希望确保，当前我操作的私有provider就是我以为的那个，而不是其他队友删除后创建的同名私有provider。因此，使用Id就可以做到强匹配。  资源编排服务保证每次创建的私有provider所对应的Id都不相同，更新不会影响Id。如果给予的provider_id和当前provider的Id不一致，则返回400
        :type provider_id: str
        """
        
        

        self._provider_description = None
        self._provider_id = None
        self.discriminator = None

        if provider_description is not None:
            self.provider_description = provider_description
        if provider_id is not None:
            self.provider_id = provider_id

    @property
    def provider_description(self):
        r"""Gets the provider_description of this UpdatePrivateProviderMetadataRequestBody.

        私有provider（private-provider）的描述。可用于客户识别被管理的私有provider。

        :return: The provider_description of this UpdatePrivateProviderMetadataRequestBody.
        :rtype: str
        """
        return self._provider_description

    @provider_description.setter
    def provider_description(self, provider_description):
        r"""Sets the provider_description of this UpdatePrivateProviderMetadataRequestBody.

        私有provider（private-provider）的描述。可用于客户识别被管理的私有provider。

        :param provider_description: The provider_description of this UpdatePrivateProviderMetadataRequestBody.
        :type provider_description: str
        """
        self._provider_description = provider_description

    @property
    def provider_id(self):
        r"""Gets the provider_id of this UpdatePrivateProviderMetadataRequestBody.

        私有provider（private-provider）的唯一Id。  此Id由资源编排服务在生成provider的时候生成，为UUID。  由于私有provider名仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的私有provider，删除，再重新创建一个同名私有provider。  对于团队并行开发，用户可能希望确保，当前我操作的私有provider就是我以为的那个，而不是其他队友删除后创建的同名私有provider。因此，使用Id就可以做到强匹配。  资源编排服务保证每次创建的私有provider所对应的Id都不相同，更新不会影响Id。如果给予的provider_id和当前provider的Id不一致，则返回400

        :return: The provider_id of this UpdatePrivateProviderMetadataRequestBody.
        :rtype: str
        """
        return self._provider_id

    @provider_id.setter
    def provider_id(self, provider_id):
        r"""Sets the provider_id of this UpdatePrivateProviderMetadataRequestBody.

        私有provider（private-provider）的唯一Id。  此Id由资源编排服务在生成provider的时候生成，为UUID。  由于私有provider名仅仅在同一时间下唯一，即用户允许先生成一个叫HelloWorld的私有provider，删除，再重新创建一个同名私有provider。  对于团队并行开发，用户可能希望确保，当前我操作的私有provider就是我以为的那个，而不是其他队友删除后创建的同名私有provider。因此，使用Id就可以做到强匹配。  资源编排服务保证每次创建的私有provider所对应的Id都不相同，更新不会影响Id。如果给予的provider_id和当前provider的Id不一致，则返回400

        :param provider_id: The provider_id of this UpdatePrivateProviderMetadataRequestBody.
        :type provider_id: str
        """
        self._provider_id = provider_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdatePrivateProviderMetadataRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
