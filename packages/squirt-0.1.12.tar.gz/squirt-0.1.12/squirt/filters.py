"""
Metric Filtering Utilities

Provides helpers to conditionally include/exclude metrics by namespace,
enabling flexible configuration for different environments or testing scenarios.

Runtime Filtering (Pytest):
    # Skip LLM metrics in CI
    pytest tests/ --skip-metrics-namespaces=llm,vector

    # Only collect core metrics
    pytest tests/ --only-metrics-namespaces=m

Manual Filtering:
    from squirt import m, track
    from squirt.contrib.llm import llm
    from squirt.filters import skip_namespaces, only_namespaces

    # Exclude expensive LLM metrics
    metrics = skip_namespaces([llm], [
        m.runtime_ms.from_output("metadata.runtime_ms"),
        llm.cost.from_output("usage.cost"),  # Skipped
    ])

    @track(metrics=metrics)
    def my_component(text: str) -> dict:
        ...
"""

from collections.abc import Sequence
from typing import Any, Optional

from .core.types import Metric
from .plugins.base import MetricNamespace

# Runtime namespace filter configuration (global, not contextvar)
# This is session-wide configuration that should persist across all tests
_namespace_filters: dict[str, list[str] | None] = {
    "skip": None,
    "only": None,
}


def configure_namespace_filters(
    skip: list[str] | None = None,
    only: list[str] | None = None,
) -> None:
    """
    Configure runtime namespace filtering.

    This is called automatically by pytest plugin when using CLI options.
    Can also be called manually for programmatic configuration.

    Args:
        skip: List of namespace names to skip (e.g., ['llm', 'vector'])
        only: List of namespace names to include exclusively (e.g., ['m', 'data'])

    Example:
        from squirt.filters import configure_namespace_filters

        # Skip expensive metrics in CI
        configure_namespace_filters(skip=['llm', 'vector'])
    """
    global _namespace_filters
    _namespace_filters["skip"] = skip
    _namespace_filters["only"] = only


def get_namespace_filters() -> dict:
    """Get currently configured namespace filters."""
    return _namespace_filters.copy()


def apply_runtime_filters(metrics: Sequence[Metric | Any]) -> list[Metric]:
    """
    Apply runtime namespace filters to a list of metrics.

    This is called automatically by the @track decorator before collecting metrics.

    Args:
        metrics: List of metrics to filter

    Returns:
        Filtered list based on runtime configuration
    """
    skip_names = _namespace_filters.get("skip")
    only_names = _namespace_filters.get("only")

    metrics_list = list(metrics)

    if not skip_names and not only_names:
        return metrics_list

    # Helper to check if a namespace matches a name filter
    def matches_name(namespace: Any, name: str) -> bool:
        """Check if namespace matches the given name filter."""
        if namespace is None:
            return False

        ns_type = type(namespace)
        ns_class_name = ns_type.__name__.lower()
        ns_module = ns_type.__module__
        name_lower = name.lower()

        # Special case: "m" matches BuiltinMetrics
        if name_lower == "m" and "builtin" in ns_class_name:
            return True

        # Match by class name (e.g., "AzureMetrics" matches "azure")
        # Remove "Metrics" suffix and compare
        class_name_base = ns_class_name.replace("metrics", "").strip("_")
        if class_name_base == name_lower:
            return True

        # Match by last part of module name (e.g., "squirt.contrib.azure" matches "azure")
        module_parts = ns_module.split(".")
        if module_parts and module_parts[-1] == name_lower:
            return True

        # Exact type name match
        if ns_class_name == name_lower:
            return True

        return False

    # Apply filters
    if only_names:
        return [
            m
            for m in metrics_list
            if any(
                matches_name(getattr(m, "_namespace", None), name)
                for name in only_names
            )
        ]
    elif skip_names:
        return [
            m
            for m in metrics
            if not any(
                matches_name(getattr(m, "_namespace", None), name)
                for name in skip_names
            )
        ]

    return metrics_list


def skip_namespaces(
    namespaces: list[MetricNamespace | Any],
    metrics: list[Metric],
) -> list[Metric]:
    """
    Filter out metrics that belong to specified namespaces.

    Args:
        namespaces: List of namespace objects to exclude (e.g., [llm, vector])
        metrics: List of metrics to filter

    Returns:
        Filtered list of metrics excluding those from specified namespaces

    Example:
        from squirt import m
        from squirt.contrib.llm import llm
        from squirt.filters import skip_namespaces

        # Skip all LLM metrics (cost, tokens, etc.)
        filtered = skip_namespaces([llm], [
            m.runtime_ms.from_output("metadata.runtime_ms"),
            llm.cost.from_output("usage.cost"),  # Excluded
        ])
    """
    # Get namespace types to check against
    namespace_types = [type(ns) for ns in namespaces]

    filtered_metrics = []
    for metric in metrics:
        # Get the namespace of this metric by checking its _namespace attribute
        metric_namespace = getattr(metric, "_namespace", None)

        # Keep metric if its namespace is not in the skip list
        if metric_namespace is None or type(metric_namespace) not in namespace_types:
            filtered_metrics.append(metric)

    return filtered_metrics


def only_namespaces(
    namespaces: list[MetricNamespace | Any],
    metrics: list[Metric],
) -> list[Metric]:
    """
    Filter to only include metrics from specified namespaces.

    Args:
        namespaces: List of namespace objects to include (e.g., [m, data])
        metrics: List of metrics to filter

    Returns:
        Filtered list of metrics including only those from specified namespaces

    Example:
        from squirt import m
        from squirt.contrib.llm import llm
        from squirt.filters import only_namespaces

        # Only keep built-in metrics
        filtered = only_namespaces([m], [
            m.runtime_ms.from_output("metadata.runtime_ms"),  # Kept
            llm.cost.from_output("usage.cost"),  # Excluded
        ])
    """
    # Get namespace types to check against
    namespace_types = [type(ns) for ns in namespaces]

    filtered_metrics = []
    for metric in metrics:
        # Get the namespace of this metric
        metric_namespace = getattr(metric, "_namespace", None)

        # Keep metric if its namespace is in the include list
        if metric_namespace is not None and type(metric_namespace) in namespace_types:
            filtered_metrics.append(metric)

    return filtered_metrics


def when_env(
    var: str,
    value: str = "true",
    metrics: Optional[list[Metric]] = None,
) -> list[Metric]:
    """
    Conditionally include metrics based on environment variable.

    Args:
        var: Environment variable name to check
        value: Value to match (default: "true")
        metrics: Metrics to include if condition is met

    Returns:
        Metrics list if condition is met, empty list otherwise

    Example:
        import os
        from squirt.filters import when_env

        # Only collect expensive metrics when explicitly enabled
        expensive_metrics = when_env("COLLECT_LLM_METRICS", metrics=[
            llm.cost.from_output("usage.cost"),
            llm.total_tokens.from_output("usage.tokens"),
        ])
    """
    import os

    if metrics is None:
        metrics = []

    return metrics if os.environ.get(var, "").lower() == value.lower() else []


__all__ = [
    "skip_namespaces",
    "only_namespaces",
    "when_env",
    "configure_namespace_filters",
    "get_namespace_filters",
    "apply_runtime_filters",
]
