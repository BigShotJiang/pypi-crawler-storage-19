"""
ReadAnyBook - A RAG-based cheat sheet generator for books and papers.

This package provides a modular pipeline for:
1. Ingesting books/papers (PDF, EPUB, HTML)
2. Building structured knowledge stores (chunks + embeddings + metadata)
3. Running specialized generation passes (concepts, formulas, models, pseudocode)
4. Assembling comprehensive LaTeX cheat sheets
5. Compiling to PDF

Example usage:
    from readanybook import build_cheatsheet
    
    # Using HuggingFace backend (works on Kaggle)
    build_cheatsheet("book.pdf", llm_backend="huggingface", llm_model="microsoft/phi-2")
    
    # Using Ollama backend (requires local Ollama server)
    build_cheatsheet("book.pdf", llm_backend="ollama", llm_model="llama3.2")
"""

__version__ = "0.1.12"
__author__ = "ReadAnyBook Team"

from .core.pipeline import CheatSheetPipeline, build_cheatsheet
from .infra.settings import Settings

__all__ = [
    "CheatSheetPipeline",
    "Settings",
    "build_cheatsheet",
    "__version__",
]
