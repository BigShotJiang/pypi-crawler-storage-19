"""LLM prompt templates for intent generation.

This module provides prompt templates for generating structured intents
from user objectives. Prompts guide the LLM to extract or expand objectives
into problem statements, assumptions, requirements, acceptance criteria,
and explicit non-goals.

Project state awareness (FEAT-AUTO-INTENT-002):
    - EMPTY projects get "Foundation Proposals" section with tech recommendations
    - EXISTING projects get "Questions for Derivation" section for investigation

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - docs/design/briefs/AUTO_INTENT_POLISH_BRIEF.md
    - obra/intent/models.py
    - obra/hybrid/handlers/intent.py
"""

from obra.intent.models import InputType


# Lazy import to avoid circular dependency
def _get_project_state():
    from obra.intent.detection import ProjectState  # noqa: PLC0415
    return ProjectState


def build_intent_generation_prompt(
    objective: str,
    input_type: InputType,
    project_state: str | None = None,
) -> str:
    """Build LLM prompt for intent generation.

    Args:
        objective: User objective or input text
        input_type: Classification of input type
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Formatted prompt string for LLM

    Example:
        >>> prompt = build_intent_generation_prompt("add auth", InputType.VAGUE_NL, "EMPTY")
        >>> # Prompt includes Foundation Proposals section...
    """
    if input_type == InputType.VAGUE_NL:
        return _build_vague_nl_prompt(objective, project_state)
    if input_type == InputType.RICH_NL:
        return _build_rich_nl_prompt(objective, project_state)
    if input_type == InputType.PRD:
        return _build_prd_extraction_prompt(objective, project_state)
    if input_type == InputType.PROSE_PLAN:
        return _build_prose_plan_extraction_prompt(objective, project_state)

    # Fallback to vague NL
    return _build_vague_nl_prompt(objective, project_state)


def _build_vague_nl_prompt(objective: str, project_state: str | None = None) -> str:
    """Build prompt for expanding vague natural language objectives.

    Args:
        objective: Short, underspecified objective
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Prompt template for vague NL expansion
    """
    # Add context-aware section based on project state
    context_section = ""
    if project_state == "EMPTY":
        context_section = """
6. **Foundation Proposals**: Since this is a new/minimal project, propose 3-5 foundational technology choices:
   - Core framework or language (if not specified)
   - Database or data storage approach
   - Key libraries or tools for the objective
   - Deployment or hosting considerations
   Include brief rationale for each proposal.
"""
    elif project_state == "EXISTING":
        context_section = """
6. **Questions for Derivation**: Since this is an existing codebase, list 3-5 questions that need investigation:
   - What is the current technology stack?
   - How is [relevant component] currently implemented?
   - Are there existing patterns or conventions to follow?
   - What dependencies or integrations exist?
   These questions will guide the derivation process.
"""

    json_section = ""
    if project_state == "EMPTY":
        json_section = """  "foundation_proposals": [
    "Proposal with rationale",
    "Second proposal with rationale"
  ],"""
    elif project_state == "EXISTING":
        json_section = """  "derivation_questions": [
    "First investigation question",
    "Second investigation question"
  ],"""

    return f"""You are an AI assistant helping to clarify and structure a software development objective.

The user provided this brief objective:
"{objective}"

Your task is to expand this into a structured intent with the following sections:

1. **Problem Statement**: A clear, detailed description of what the user wants to achieve (2-3 sentences)

2. **Assumptions**: List 2-4 reasonable assumptions about:
   - Technology choices (if not specified)
   - User experience expectations
   - Integration requirements
   - Performance/scale considerations

3. **Requirements**: List 4-8 specific functional requirements that would satisfy this objective

4. **Acceptance Criteria**: List 3-5 verifiable criteria that indicate successful completion

5. **Non-Goals**: Explicitly list 2-3 things that are OUT OF SCOPE for this objective
{context_section}
Return your response as valid JSON with this exact structure:
{{
  "problem_statement": "Clear description of the problem...",
  "assumptions": [
    "First assumption",
    "Second assumption"
  ],
  "requirements": [
    "First requirement",
    "Second requirement"
  ],
  "acceptance_criteria": [
    "First criterion",
    "Second criterion"
  ],
  "non_goals": [
    "First non-goal",
    "Second non-goal"
  ],
{json_section}
}}

Be specific and concrete. Avoid vague language. Make reasonable assumptions when details are missing."""


def _build_rich_nl_prompt(objective: str, project_state: str | None = None) -> str:
    """Build prompt for extracting structure from rich natural language.

    Args:
        objective: Detailed natural language description
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Prompt template for rich NL extraction
    """
    context_section = ""
    if project_state == "EMPTY":
        context_section = """
6. **Foundation Proposals**: Since this is a new/minimal project, propose foundational technology choices based on the objective.
"""
    elif project_state == "EXISTING":
        context_section = """
6. **Questions for Derivation**: Since this is an existing codebase, list questions that need investigation to implement this objective.
"""

    json_section = ""
    if project_state == "EMPTY":
        json_section = """  "foundation_proposals": [
    "Proposal with rationale"
  ],"""
    elif project_state == "EXISTING":
        json_section = """  "derivation_questions": [
    "Investigation question"
  ],"""

    return f"""You are an AI assistant helping to structure and enrich a software development objective.

The user provided this detailed objective:
"{objective}"

Your task is to extract, expand, and enrich this information into a structured intent with these sections:

1. **Problem Statement**: Extract or synthesize the core problem being solved (2-3 sentences), adding clarity where needed

2. **Assumptions**: Identify stated assumptions AND infer reasonable technical assumptions:
   - Technology versions (e.g., Python 3.12+, Node 18+)
   - Encoding/charset expectations (e.g., UTF-8)
   - Error handling approach
   - Performance/scale assumptions
   - User context or constraints

3. **Requirements**: Extract explicit requirements AND infer implicit ones:
   - What's directly stated
   - What's implied by the objective
   - Edge cases that should be handled
   - Standard features for this type of system

4. **Acceptance Criteria**: Derive verifiable criteria even when not explicitly stated:
   - Success conditions for the stated goal
   - Quality standards implied by the objective
   - Testing or validation requirements

5. **Non-Goals**: Infer scope boundaries based on the focus:
   - What's explicitly excluded
   - What would be out of scope given the objective's focus
   - Future enhancements that aren't part of this work
{context_section}
Return your response as valid JSON with this exact structure:
{{
  "problem_statement": "Clear description of the problem...",
  "assumptions": [
    "First assumption",
    "Second assumption"
  ],
  "requirements": [
    "First requirement",
    "Second requirement"
  ],
  "acceptance_criteria": [
    "First criterion",
    "Second criterion"
  ],
  "non_goals": [
    "First non-goal",
    "Second non-goal"
  ],
{json_section}
}}

Extract the explicit information, then expand with reasonable inferences for assumptions, implicit requirements, acceptance criteria, and non-goals. The goal is to add clarity and structure beyond what's explicitly stated, making the intent document more valuable for planning and implementation."""


def _build_prd_extraction_prompt(prd_content: str, project_state: str | None = None) -> str:
    """Build prompt for extracting intent from PRD documents.

    Args:
        prd_content: Full PRD document content
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Prompt template for PRD extraction
    """
    context_section = ""
    json_section = ""
    if project_state == "EMPTY":
        context_section = "\n6. **Foundation Proposals**: Propose foundational technology choices."
        json_section = """  "foundation_proposals": ["Proposal"],"""
    elif project_state == "EXISTING":
        context_section = "\n6. **Questions for Derivation**: List questions for investigation."
        json_section = """  "derivation_questions": ["Question"],"""

    return f"""You are an AI assistant helping to extract a structured intent from a Product Requirements Document (PRD).

Below is the PRD content:

---
{prd_content}
---

Your task is to extract the key information and structure it as an intent with these sections:

1. **Problem Statement**: Extract the problem or opportunity the PRD addresses (from Overview, Background, or Problem Statement sections)

2. **Assumptions**: Extract any stated assumptions, constraints, or context from the PRD

3. **Requirements**: Extract all functional requirements (from Functional Requirements, Features, or User Stories sections)

4. **Acceptance Criteria**: Extract success criteria, acceptance tests, or verification methods

5. **Non-Goals**: Extract any explicitly mentioned out-of-scope items, future work, or non-requirements
{context_section}
Return your response as valid JSON with this exact structure:
{{
  "problem_statement": "Clear description of the problem...",
  "assumptions": [
    "First assumption",
    "Second assumption"
  ],
  "requirements": [
    "First requirement",
    "Second requirement"
  ],
  "acceptance_criteria": [
    "First criterion",
    "Second criterion"
  ],
  "non_goals": [
    "First non-goal",
    "Second non-goal"
  ],
{json_section}
}}

Extract information directly from the PRD. Preserve important details and technical specifics."""


def _build_prose_plan_extraction_prompt(plan_content: str, project_state: str | None = None) -> str:
    """Build prompt for extracting intent from prose plan documents.

    Args:
        plan_content: Full prose plan content
        project_state: Optional project state (EMPTY or EXISTING)

    Returns:
        Prompt template for prose plan extraction
    """
    context_section = ""
    json_section = ""
    if project_state == "EMPTY":
        context_section = "\n6. **Foundation Proposals**: Propose foundational technology choices."
        json_section = """  "foundation_proposals": ["Proposal"],"""
    elif project_state == "EXISTING":
        context_section = "\n6. **Questions for Derivation**: List questions for investigation."
        json_section = """  "derivation_questions": ["Question"],"""

    return f"""You are an AI assistant helping to extract a structured intent from an implementation plan document.

Below is the plan content:

---
{plan_content}
---

Your task is to extract the underlying objective and structure it as an intent with these sections:

1. **Problem Statement**: Synthesize what problem this plan is trying to solve (look for objective, goal, or purpose statements)

2. **Assumptions**: Extract any stated assumptions, prerequisites, or constraints

3. **Requirements**: Extract the key deliverables or outcomes this plan aims to produce

4. **Acceptance Criteria**: Extract how success will be measured (from verification, testing, or completion sections)

5. **Non-Goals**: Extract any explicitly mentioned scope boundaries or future work items
{context_section}
Return your response as valid JSON with this exact structure:
{{
  "problem_statement": "Clear description of the problem...",
  "assumptions": [
    "First assumption",
    "Second assumption"
  ],
  "requirements": [
    "First requirement",
    "Second requirement"
  ],
  "acceptance_criteria": [
    "First criterion",
    "Second criterion"
  ],
  "non_goals": [
    "First non-goal",
    "Second non-goal"
  ],
{json_section}
}}

Extract the intent behind the plan, not just the plan steps. Focus on WHAT needs to be achieved, not HOW."""


__all__ = ["build_intent_generation_prompt"]
