"""Documentation review agent for documentation quality analysis.

This module provides DocsAgent, which analyzes code for documentation
quality, including docstring coverage, README completeness, and API
documentation using LLM-powered semantic analysis.

Checks Performed:
    - Module/file documentation presence
    - Function/class docstring coverage
    - Parameter and return documentation
    - README file presence and completeness
    - API documentation quality

Scoring Dimensions:
    - docstring_coverage: Percentage of public items with documentation
    - readme_complete: README file presence and completeness
    - api_documented: Public API documentation quality

Related:
    - obra/agents/base.py
    - obra/agents/registry.py
    - obra/agents/prompts/docs_analysis.txt
"""

import logging
import time
from pathlib import Path

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.registry import register_agent
from obra.agents.tier_config import load_agent_tier_config
from obra.api.protocol import AgentType, Priority
from obra.config.llm import resolve_tier_config

logger = logging.getLogger(__name__)

# Prompt template directory
PROMPTS_DIR = Path(__file__).parent / "prompts"


def _load_prompt_template(name: str) -> str:
    """Load a prompt template from the prompts directory.

    Args:
        name: Template filename (e.g., "docs_analysis.txt")

    Returns:
        Template content as string

    Raises:
        FileNotFoundError: If template doesn't exist
    """
    template_path = PROMPTS_DIR / name
    return template_path.read_text(encoding="utf-8")


# Required sections for a complete README (with alternative phrasings)
# Each entry is a tuple of (canonical_name, list_of_patterns)
README_REQUIRED_SECTIONS = [
    (
        "installation",
        [
            "install",
            "installation",
            "installing",
            "setup",
            "getting started",
            "quick start",
            "quickstart",
        ],
    ),
    ("usage", ["usage", "how to use", "using", "basic usage", "example", "examples"]),
]

README_OPTIONAL_SECTIONS = [
    ("contributing", ["contributing", "contribute", "development", "how to contribute"]),
    ("license", ["license", "licensing"]),
    ("requirements", ["requirements", "prerequisites", "dependencies", "deps"]),
    ("features", ["features", "capabilities", "what it does"]),
    ("api", ["api", "api reference", "reference", "documentation", "docs"]),
]


@register_agent(AgentType.DOCS)
class DocsAgent(BaseAgent):
    """Documentation review agent with LLM-powered analysis.

    Uses LLM-based analysis for comprehensive documentation quality review.
    Works with any programming language (Python, JavaScript, Go, etc.).

    When no LLMInvoker is provided, returns empty result with warning.

    Example:
        >>> agent = DocsAgent(Path("/workspace"), invoker=llm_invoker)
        >>> result = agent.analyze(
        ...     item_id="T1",
        ...     changed_files=["src/auth.py"],
        ...     timeout_ms=60000
        ... )
        >>> print(f"Docstring coverage: {result.scores['docstring_coverage']}")
    """

    agent_type = AgentType.DOCS

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Analyze code for documentation quality.

        Uses LLM-based analysis when invoker is available. Analyzes
        any programming language, not just Python.

        Parameter Contracts (ADR-042):
            item_id: MUST be non-empty string. Typically matches [A-Z]+-[0-9]+ format.
            changed_files: If None, analyzes all files in working_dir.
                          If provided, only analyzes specified files.
                          Uses blocklist approach to analyze all code files.
            timeout_ms: If None, uses config-based timeout via get_review_agent_timeout().
                       If provided, MUST be positive integer. Typical range: [5000-300000].

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed
            timeout_ms: Maximum execution time (None = use config default)

        Returns:
            AgentResult with documentation issues and scores
        """
        # Resolve timeout from config if not provided
        timeout_ms = self._resolve_timeout_ms(timeout_ms)

        # Validate parameters (ADR-042)
        self._validate_analyze_params(item_id, timeout_ms)

        start_time = time.time()
        logger.info(f"DocsAgent analyzing {item_id}")

        # Get files to analyze - use blocklist approach for language-agnostic analysis
        files = self.get_files_to_analyze(changed_files=changed_files)
        logger.debug(f"Analyzing {len(files)} files for documentation")

        # Use LLM-based analysis if invoker is available
        if self._invoker is not None:
            return self._analyze_with_llm(
                item_id=item_id,
                files=files,
                start_time=start_time,
                timeout_ms=timeout_ms,
            )

        # Fallback: No invoker available, return empty result with warning
        logger.warning("DocsAgent: No LLMInvoker available, skipping analysis")
        execution_time = int((time.time() - start_time) * 1000)
        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=[],
            scores={
                "docstring_coverage": 1.0,
                "readme_complete": 1.0,
                "api_documented": 1.0,
            },
            execution_time_ms=execution_time,
            metadata={
                "files_analyzed": 0,
                "mode": "no_invoker",
            },
        )

    def _analyze_with_llm(
        self,
        item_id: str,
        files: list[Path],
        start_time: float,
        timeout_ms: int,
    ) -> AgentResult:
        """Perform LLM-based documentation analysis.

        Args:
            item_id: Plan item ID
            files: List of files to analyze
            start_time: Analysis start time
            timeout_ms: Maximum execution time

        Returns:
            AgentResult with issues from LLM analysis
        """
        deadline = start_time + (timeout_ms / 1000)
        all_issues: list[AgentIssue] = []

        # Load tier configuration
        tier_config = load_agent_tier_config("docs")
        start_tier = tier_config.get("start_tier", "fast")

        # Load prompt template
        try:
            docs_template = _load_prompt_template("docs_analysis.txt")
        except FileNotFoundError as e:
            logger.error(f"Failed to load prompt template: {e}")
            return AgentResult(
                agent_type=self.agent_type,
                status="error",
                error=f"Missing prompt template: {e}",
                execution_time_ms=int((time.time() - start_time) * 1000),
            )

        # Resolve LLM config
        llm_config = resolve_tier_config(start_tier, role="implementation")

        # Check README (quick, non-LLM based)
        readme_issues, readme_score = self._check_readme(deadline)
        all_issues.extend(readme_issues)

        # Collect file contents for analysis
        files_content: dict[str, str] = {}
        for file_path in files:
            if time.time() > deadline:
                logger.warning("DocsAgent timed out during file collection")
                break

            # Skip test files, __init__.py, and infrastructure files
            if self.is_test_file(file_path):
                continue
            if file_path.name == "__init__.py":
                continue
            if self.is_excluded_file(file_path):
                continue

            content = self.read_file(file_path)
            if content:
                try:
                    rel_path = str(file_path.relative_to(self._working_dir))
                except ValueError:
                    rel_path = str(file_path)
                files_content[rel_path] = content

        if not files_content:
            # No files to analyze with LLM, but README may have issues
            logger.info(
                f"DocsAgent: 0 files remain after filtering from {len(files)} candidates. "
                "Skipping LLM analysis (README check still performed)."
            )
            execution_time = int((time.time() - start_time) * 1000)
            return AgentResult(
                agent_type=self.agent_type,
                status="complete",
                issues=all_issues,
                scores={
                    "docstring_coverage": 1.0,
                    "readme_complete": readme_score,
                    "api_documented": 1.0,
                },
                execution_time_ms=execution_time,
                metadata={"files_analyzed": 0, "mode": "llm", "skipped_reason": "no_files_after_filter"},
            )

        # Format code content for prompt
        code_content = self._format_code_for_prompt(files_content)

        # Run LLM analysis
        logger.info(f"Running docs analysis with {llm_config['provider']}/{llm_config['model']}")
        analysis_prompt = docs_template.format(code_content=code_content)

        try:
            result = self._invoke_with_logging(
                call_site="docs_analysis",
                prompt=analysis_prompt,
                provider=llm_config["provider"],
                model=llm_config["model"],
                temperature=0.0,  # Deterministic for analysis
            )

            if not result.success:
                logger.error(f"LLM invocation failed: {result.error_message}")
                return AgentResult(
                    agent_type=self.agent_type,
                    status="error",
                    error=f"LLM invocation failed: {result.error_message}",
                    execution_time_ms=int((time.time() - start_time) * 1000),
                )

            # Parse results
            issues = self.parse_structured_response(result.content, prefix="DOC")
            all_issues.extend(issues)
            logger.info(f"Found {len(issues)} documentation issues from LLM")

        except Exception as e:
            logger.exception(f"Documentation analysis failed: {e}")
            return AgentResult(
                agent_type=self.agent_type,
                status="error",
                error=f"Analysis failed: {e}",
                execution_time_ms=int((time.time() - start_time) * 1000),
            )

        # Calculate scores based on findings
        scores = self._calculate_scores_from_issues(all_issues, readme_score)

        execution_time = int((time.time() - start_time) * 1000)
        logger.info(f"DocsAgent complete: {len(all_issues)} issues found in {execution_time}ms")

        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=all_issues,
            scores=scores,
            execution_time_ms=execution_time,
            metadata={
                "files_analyzed": len(files_content),
                "mode": "llm",
                "provider": llm_config["provider"],
                "model": llm_config["model"],
                # Observability fields (ADR-043)
                "issues_found": len(all_issues),
                "scores": scores,
            },
        )

    def _format_code_for_prompt(self, files_content: dict[str, str]) -> str:
        """Format file contents for LLM prompt.

        Args:
            files_content: Dict mapping file paths to contents

        Returns:
            Formatted string with file headers
        """
        parts = []
        for file_path, content in files_content.items():
            # Limit content size to avoid token limits
            if len(content) > 50000:
                content = content[:50000] + "\n... (truncated)"
            parts.append(f"=== FILE: {file_path} ===\n{content}")
        return "\n\n".join(parts)

    def _check_readme(
        self,
        deadline: float,
    ) -> tuple[list[AgentIssue], float]:
        """Check README file presence and completeness.

        Args:
            deadline: Timeout deadline

        Returns:
            Tuple of (issues, score)
        """
        issues: list[AgentIssue] = []
        issue_index = 0

        # Look for README
        readme_files = list(self._working_dir.glob("README*"))
        if not readme_files:
            issues.append(
                AgentIssue(
                    id=self._generate_issue_id("DOC", issue_index + 1),
                    title="Missing README file",
                    description="Project should have a README.md file with installation and usage instructions.",
                    priority=Priority.P1,
                    dimension="readme_complete",
                    suggestion="Create README.md with project description, installation, and usage sections",
                )
            )
            return issues, 0.0

        readme_files_sorted = sorted(
            readme_files,
            key=lambda path: (path.name.lower() != "readme.md", path.name.lower()),
        )
        readme_path = readme_files_sorted[0]
        content = self.read_file(readme_path).lower()

        # Check required sections using fuzzy matching
        found_sections: set[str] = set()
        for section_name, patterns in README_REQUIRED_SECTIONS:
            for pattern in patterns:
                if pattern in content:
                    found_sections.add(section_name)
                    break

        # Find missing required sections
        required_section_names = {name for name, _ in README_REQUIRED_SECTIONS}
        missing_sections = required_section_names - found_sections
        for section in missing_sections:
            issue_index += 1
            issues.append(
                AgentIssue(
                    id=self._generate_issue_id("DOC", issue_index),
                    title=f"README missing '{section}' section",
                    description=f"README should include a '{section}' section.",
                    priority=Priority.P2,
                    file_path="README.md",
                    dimension="readme_complete",
                    suggestion=f"Add a '{section}' section to README.md",
                )
            )

        # Calculate score
        required_found = len(found_sections)
        required_total = len(README_REQUIRED_SECTIONS)

        # Check optional sections for bonus using fuzzy matching
        optional_found = 0
        for _, patterns in README_OPTIONAL_SECTIONS:
            if any(pattern in content for pattern in patterns):
                optional_found += 1
        optional_bonus = min(optional_found / len(README_OPTIONAL_SECTIONS) * 0.2, 0.2)

        score = (required_found / required_total * 0.8) + optional_bonus

        return issues, score

    def _calculate_scores_from_issues(
        self,
        issues: list[AgentIssue],
        readme_score: float,
    ) -> dict[str, float]:
        """Calculate dimension scores based on issues.

        Args:
            issues: All issues found
            readme_score: README completeness score from _check_readme

        Returns:
            Dict of dimension scores
        """
        docstring_issues = 0
        api_issues = 0

        for issue in issues:
            dim = issue.dimension
            if dim == "docstring_coverage":
                docstring_issues += 1
            elif dim == "api_documented":
                api_issues += 1
            elif dim == "readme_complete":
                # README issues counted via readme_score
                pass
            else:
                # Map priority to dimension for LLM issues without explicit dimension
                if issue.priority in (Priority.P0, Priority.P1):
                    docstring_issues += 1
                else:
                    api_issues += 1

        def score(issue_count: int) -> float:
            if issue_count == 0:
                return 1.0
            if issue_count == 1:
                return 0.8
            if issue_count == 2:
                return 0.6
            if issue_count <= 5:
                return 0.4
            return 0.2

        return {
            "docstring_coverage": score(docstring_issues),
            "readme_complete": round(readme_score, 2),
            "api_documented": score(api_issues),
        }


__all__ = ["DocsAgent"]
