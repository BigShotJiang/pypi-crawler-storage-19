"""Intent generation handler for Hybrid Orchestrator.

This module handles intent generation from user objectives using LLM.
It classifies the input type and generates a structured intent with
problem statement, assumptions, requirements, acceptance criteria, and non-goals.

The intent generation process:
    1. Classify input type (vague_nl, rich_nl, prd, prose_plan, structured_plan)
    2. For vague inputs: invoke LLM to expand into structured intent
    3. For rich inputs: parse directly or use LLM for extraction
    4. Return IntentModel with all required fields

Architecture (ADR-027):
    - Client-side LLM invocation (privacy-preserving)
    - Two-tier prompting: strategic prompts can come from server or local templates
    - Intent stored locally in ~/.obra/intents/{project}/

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - docs/decisions/ADR-027-two-tier-prompting-architecture.md
    - obra/intent/models.py
    - obra/intent/storage.py
"""

import json
import logging
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.intent.detection import detect_input_type
from obra.intent.models import InputType, IntentModel
from obra.llm.cli_runner import invoke_llm_via_cli

logger = logging.getLogger(__name__)


class IntentHandler:
    """Handler for intent generation from user objectives.

    Takes a user objective (vague or detailed) and generates a structured
    intent using LLM. The intent captures problem statement, assumptions,
    requirements, acceptance criteria, and explicit non-goals.

    ## Client-Side LLM (ADR-027)

    Intent generation happens client-side to preserve privacy. User objectives
    and project context never leave the local machine during intent generation.

    ## Input Classification

    The handler classifies inputs into:
    - vague_nl: Short, underspecified ("add auth")
    - rich_nl: Detailed description with requirements
    - prd: Product requirements document (file)
    - prose_plan: Unstructured plan document (file)
    - structured_plan: MACHINE_PLAN JSON/YAML (file)

    Example:
        >>> handler = IntentHandler(Path("/path/to/project"))
        >>> intent = handler.generate("add user authentication")
        >>> print(intent.problem_statement)
    """

    def __init__(
        self,
        working_dir: Path,
        project: str | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> None:
        """Initialize IntentHandler.

        Args:
            working_dir: Working directory for file access
            project: Optional project identifier (defaults to working_dir name)
            on_stream: Optional callback for LLM streaming chunks
            llm_config: Optional LLM configuration
            log_event: Optional logger for hybrid events
            trace_id: Optional trace ID for monitoring
            parent_span_id: Optional parent span ID for monitoring
        """
        self._working_dir = working_dir
        self._project = project or working_dir.name
        self._on_stream = on_stream
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id

    def generate(
        self,
        objective: str,
        *,
        input_type: InputType | None = None,
        base_prompt: str | None = None,
        force_empty: bool = False,
        force_existing: bool = False,
        detect_project_state_flag: bool = False,
    ) -> IntentModel:
        """Generate a structured intent from user objective.

        Args:
            objective: User objective (natural language)
            input_type: Optional pre-classified input type (auto-detects if None)
            base_prompt: Optional base prompt from server (two-tier prompting)
            force_empty: Force EMPTY project state (new/minimal project)
            force_existing: Force EXISTING project state (established codebase)
            detect_project_state_flag: Enable detection for PRD/plan inputs (skipped by default)

        Returns:
            IntentModel with structured intent data

        Raises:
            ValueError: If objective is empty or invalid

        Example:
            >>> handler = IntentHandler(Path.cwd())
            >>> intent = handler.generate("add authentication system")
            >>> print(intent.requirements)
            ['User can register', 'User can login', ...]
        """
        if not objective or not objective.strip():
            msg = "Objective cannot be empty"
            raise ValueError(msg)

        objective = objective.strip()
        logger.info("Generating intent for objective: %s...", objective[:50])

        # Classify input type
        detected_type = input_type or detect_input_type(objective)
        logger.debug("Detected input type: %s", detected_type)

        # Emit input_type_classified event (S4.T2)
        if self._log_event:
            self._log_event(
                "input_type_classified",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                detected_type=detected_type.value,
                objective_length=len(objective),
            )

        # Detect project state (FEAT-AUTO-INTENT-002 S1)
        from obra.config import (  # noqa: PLC0415
            get_project_detection_empty_threshold,
            get_project_detection_enabled,
            get_project_detection_existing_threshold,
        )
        from obra.intent.detection import ProjectState, detect_project_state  # noqa: PLC0415

        project_state_result = None

        # Determine if detection should run
        should_detect = False
        if detected_type in {InputType.VAGUE_NL, InputType.RICH_NL}:
            # Always detect for natural language inputs
            should_detect = True
        elif detected_type in {InputType.PRD, InputType.PROSE_PLAN}:
            # For PRD/plan, only detect if flag is set
            should_detect = detect_project_state_flag
        # STRUCTURED_PLAN: never detect (not applicable)

        # Run detection if enabled and applicable
        if should_detect and get_project_detection_enabled():
            # Determine force state
            force_state = None
            if force_empty:
                force_state = ProjectState.EMPTY
            elif force_existing:
                force_state = ProjectState.EXISTING

            # Get thresholds from config
            empty_threshold = get_project_detection_empty_threshold()
            existing_threshold = get_project_detection_existing_threshold()

            # Run detection
            project_state_result = detect_project_state(
                project_dir=self._working_dir,
                empty_threshold=empty_threshold,
                existing_threshold=existing_threshold,
                llm_config=self._llm_config,
                force_state=force_state,
            )

            logger.info(
                "Project state detected: %s (via %s)",
                project_state_result.state.value,
                project_state_result.method,
            )

            # Emit project_state_detected event (S4.T1)
            if self._log_event:
                self._log_event(
                    "project_state_detected",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    state=project_state_result.state.value,
                    method=project_state_result.method,
                    file_count=project_state_result.file_count,
                    empty_threshold=empty_threshold,
                    existing_threshold=existing_threshold,
                )

        # Generate intent based on input type
        if detected_type == InputType.VAGUE_NL:
            intent_data = self._generate_from_vague_nl(objective, base_prompt)
        elif detected_type == InputType.RICH_NL:
            intent_data = self._generate_from_rich_nl(objective, base_prompt)
        elif detected_type == InputType.PRD:
            intent_data = self._generate_from_prd(objective, base_prompt)
        elif detected_type == InputType.PROSE_PLAN:
            intent_data = self._generate_from_prose_plan(objective, base_prompt)
        elif detected_type == InputType.STRUCTURED_PLAN:
            intent_data = self._generate_from_structured_plan(objective)
        else:
            # Fallback to vague_nl handling
            intent_data = self._generate_from_vague_nl(objective, base_prompt)

        # Create IntentModel
        slug = IntentModel.slugify(intent_data.get("problem_statement", objective))
        intent_id = IntentModel.generate_id(slug)

        intent = IntentModel(
            id=intent_id,
            project=self._project,
            slug=slug,
            created=datetime.now(UTC).isoformat(),
            input_type=detected_type,
            problem_statement=intent_data["problem_statement"],
            assumptions=intent_data.get("assumptions", []),
            requirements=intent_data.get("requirements", []),
            acceptance_criteria=intent_data.get("acceptance_criteria", []),
            non_goals=intent_data.get("non_goals", []),
            raw_objective=objective,
        )

        logger.info("Generated intent: %s", intent.id)
        return intent

    def _generate_from_vague_nl(
        self,
        objective: str,
        base_prompt: str | None,
    ) -> dict[str, Any]:
        """Generate intent from vague natural language input using LLM.

        Args:
            objective: Vague user objective
            base_prompt: Optional base prompt from server

        Returns:
            Dict with intent fields
        """
        # Import prompt template here to avoid circular import
        from obra.intent.prompts import build_intent_generation_prompt  # noqa: PLC0415

        prompt = base_prompt or build_intent_generation_prompt(
            objective,
            input_type=InputType.VAGUE_NL,
        )

        provider, model, thinking_level, auth_method = self._resolve_llm_config()
        raw_response = self._invoke_llm(
            prompt,
            provider=provider,
            model=model,
            thinking_level=thinking_level,
            auth_method=auth_method,
        )

        return self._parse_intent_response(raw_response, objective)

    def _generate_from_rich_nl(
        self,
        objective: str,
        base_prompt: str | None,
    ) -> dict[str, Any]:
        """Generate intent from rich natural language input.

        For rich NL, we use LLM to extract structure from the detailed input.

        Args:
            objective: Rich user objective with details
            base_prompt: Optional base prompt from server

        Returns:
            Dict with intent fields
        """
        # Import prompt template here
        from obra.intent.prompts import build_intent_generation_prompt  # noqa: PLC0415

        prompt = base_prompt or build_intent_generation_prompt(
            objective,
            input_type=InputType.RICH_NL,
        )

        provider, model, thinking_level, auth_method = self._resolve_llm_config()
        raw_response = self._invoke_llm(
            prompt,
            provider=provider,
            model=model,
            thinking_level=thinking_level,
            auth_method=auth_method,
        )

        return self._parse_intent_response(raw_response, objective)

    def _generate_from_prd(
        self,
        prd_path: str,
        base_prompt: str | None,
    ) -> dict[str, Any]:
        """Generate intent from PRD file.

        Args:
            prd_path: Path to PRD file
            base_prompt: Optional base prompt from server

        Returns:
            Dict with intent fields

        Raises:
            FileNotFoundError: If PRD file doesn't exist
            ValueError: If PRD file is empty or unreadable
        """
        # Resolve path relative to working directory
        file_path = Path(prd_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"PRD file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read PRD content
        try:
            prd_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read PRD file: {e}"
            raise ValueError(msg) from e

        if not prd_content.strip():
            msg = f"PRD file is empty: {file_path}"
            raise ValueError(msg)

        logger.info("Extracting intent from PRD: %s (%d chars)", file_path.name, len(prd_content))

        # Import prompt template
        from obra.intent.prompts import build_intent_generation_prompt  # noqa: PLC0415

        prompt = base_prompt or build_intent_generation_prompt(
            prd_content,
            input_type=InputType.PRD,
        )

        provider, model, thinking_level, auth_method = self._resolve_llm_config()
        raw_response = self._invoke_llm(
            prompt,
            provider=provider,
            model=model,
            thinking_level=thinking_level,
            auth_method=auth_method,
        )

        return self._parse_intent_response(raw_response, prd_content[:100])

    def _generate_from_prose_plan(
        self,
        plan_path: str,
        base_prompt: str | None,
    ) -> dict[str, Any]:
        """Generate intent from prose plan file.

        Args:
            plan_path: Path to prose plan file
            base_prompt: Optional base prompt from server

        Returns:
            Dict with intent fields

        Raises:
            FileNotFoundError: If plan file doesn't exist
            ValueError: If plan file is empty or unreadable
        """
        # Resolve path relative to working directory
        file_path = Path(plan_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"Plan file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read plan content
        try:
            plan_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read plan file: {e}"
            raise ValueError(msg) from e

        if not plan_content.strip():
            msg = f"Plan file is empty: {file_path}"
            raise ValueError(msg)

        logger.info("Extracting intent from prose plan: %s (%d chars)", file_path.name, len(plan_content))

        # Import prompt template
        from obra.intent.prompts import build_intent_generation_prompt  # noqa: PLC0415

        prompt = base_prompt or build_intent_generation_prompt(
            plan_content,
            input_type=InputType.PROSE_PLAN,
        )

        provider, model, thinking_level, auth_method = self._resolve_llm_config()
        raw_response = self._invoke_llm(
            prompt,
            provider=provider,
            model=model,
            thinking_level=thinking_level,
            auth_method=auth_method,
        )

        return self._parse_intent_response(raw_response, plan_content[:100])

    def _generate_from_structured_plan(self, plan_path: str) -> dict[str, Any]:
        """Generate intent from structured plan file (mechanical extraction).

        This is a fast (~0ms) mechanical extraction that doesn't use LLM.
        Extracts intent from MACHINE_PLAN JSON/YAML structure.

        Args:
            plan_path: Path to structured MACHINE_PLAN file

        Returns:
            Dict with intent fields

        Raises:
            FileNotFoundError: If plan file doesn't exist
            ValueError: If file is not a valid MACHINE_PLAN
        """
        # Resolve path relative to working directory
        file_path = Path(plan_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"Plan file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read and parse plan file
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read plan file: {e}"
            raise ValueError(msg) from e

        # Parse JSON or YAML
        import yaml  # noqa: PLC0415

        try:
            if file_path.suffix == ".json":
                data = json.loads(content)
            else:  # YAML
                data = yaml.safe_load(content)
        except Exception as e:
            msg = f"Failed to parse plan file: {e}"
            raise ValueError(msg) from e

        # Validate structure
        from obra.intent.detection import is_valid_machine_plan  # noqa: PLC0415

        if not is_valid_machine_plan(data):
            msg = f"Invalid MACHINE_PLAN structure in: {file_path}"
            raise ValueError(msg)

        logger.info(
            "Mechanically extracting intent from structured plan: %s",
            file_path.name,
        )

        # Extract intent fields mechanically
        work_id = data.get("work_id", "Unknown")
        context = data.get("context", {})
        stories = data.get("stories", [])
        completion_checklist = data.get("completion_checklist", [])

        # Problem statement: from work_id and context
        if isinstance(context, dict) and "objective" in context:
            problem_statement = str(context["objective"])
        elif stories:
            first_story = stories[0]
            story_title = first_story.get("title", first_story.get("desc", ""))
            problem_statement = f"{work_id}: {story_title}"
        else:
            problem_statement = work_id

        # Assumptions: from context.assumptions
        assumptions = []
        if isinstance(context, dict) and "assumptions" in context:
            context_assumptions = context["assumptions"]
            if isinstance(context_assumptions, list):
                assumptions = [str(a) for a in context_assumptions]

        # Requirements: from stories
        requirements = []
        for story in stories:
            if isinstance(story, dict):
                story_title = story.get("title", story.get("desc", ""))
                if story_title:
                    requirements.append(story_title)

        # Acceptance criteria: from completion_checklist
        acceptance_criteria = []
        if isinstance(completion_checklist, list):
            acceptance_criteria = [str(c) for c in completion_checklist]

        # Non-goals: from context or flags
        non_goals = []
        if isinstance(context, dict) and "non_goals" in context:
            context_non_goals = context["non_goals"]
            if isinstance(context_non_goals, list):
                non_goals = [str(ng) for ng in context_non_goals]

        return {
            "problem_statement": problem_statement,
            "assumptions": assumptions,
            "requirements": requirements if requirements else ["Complete all stories in plan"],
            "acceptance_criteria": acceptance_criteria if acceptance_criteria else ["All tasks completed"],
            "non_goals": non_goals,
        }

    def _invoke_llm(
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        thinking_level: str,
        auth_method: str = "oauth",
    ) -> str:
        """Invoke LLM to generate intent.

        Args:
            prompt: Intent generation prompt
            provider: LLM provider name
            model: LLM model name
            thinking_level: LLM thinking level
            auth_method: Authentication method

        Returns:
            Raw LLM response
        """
        logger.debug(
            "Invoking LLM for intent: provider=%s model=%s thinking=%s",
            provider,
            model,
            thinking_level,
        )

        def _stream(chunk: str) -> None:
            if self._on_stream:
                self._on_stream("llm_streaming", chunk)

        try:
            return str(
                invoke_llm_via_cli(
                    prompt=prompt,
                    cwd=self._working_dir,
                    provider=provider,
                    model=model,
                    thinking_level=thinking_level,
                    auth_method=auth_method,
                    on_stream=_stream if self._on_stream else None,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site="intent_generation",
                )
            )
        except Exception:
            logger.exception("LLM invocation failed for intent generation")
            # Return minimal fallback structure
            return json.dumps(
                {
                    "problem_statement": "Error generating intent",
                    "assumptions": [],
                    "requirements": [],
                    "acceptance_criteria": [],
                    "non_goals": [],
                }
            )

    def _parse_intent_response(
        self,
        raw_response: str,
        objective: str,
    ) -> dict[str, Any]:
        """Parse LLM response into intent data structure.

        Args:
            raw_response: Raw LLM response
            objective: Original user objective

        Returns:
            Dict with problem_statement, assumptions, requirements, etc.
        """
        try:
            # Try to parse as JSON
            response = raw_response.strip()

            # Handle markdown code blocks
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            data = json.loads(response)

            # Extract intent fields
            return {
                "problem_statement": data.get("problem_statement", objective),
                "assumptions": data.get("assumptions", []),
                "requirements": data.get("requirements", []),
                "acceptance_criteria": data.get("acceptance_criteria", []),
                "non_goals": data.get("non_goals", []),
            }

        except json.JSONDecodeError:
            logger.warning("Failed to parse intent response as JSON, using fallback")
            # Fallback: create minimal intent from objective
            return {
                "problem_statement": objective,
                "assumptions": [],
                "requirements": [],
                "acceptance_criteria": ["Implementation complete and verified"],
                "non_goals": [],
            }

    def _resolve_llm_config(self) -> tuple[str, str, str, str]:
        """Resolve LLM configuration from stored config.

        Returns:
            Tuple of (provider, model, thinking_level, auth_method)
        """
        provider = self._llm_config.get("provider", "claude")
        model = self._llm_config.get("model", "default")
        thinking_level = self._llm_config.get("thinking_level", "medium")
        auth_method = self._llm_config.get("auth_method", "oauth")
        return provider, model, thinking_level, auth_method


__all__ = ["IntentHandler"]
