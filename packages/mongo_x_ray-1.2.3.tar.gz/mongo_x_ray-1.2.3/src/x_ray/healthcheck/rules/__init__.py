"""Package for healthcheck rules."""
