from dataclasses import dataclass, field
from typing import List

from .chunks import AIChunk
from .roles import AIRoles


@dataclass(frozen=True)
class AIMessage:

    role: AIRoles
    chunks: List[AIChunk] = field(default_factory=list)