"""Version information for amcp.

This file is auto-generated during release builds.
The __git_commit__ will be set by CI/CD during package build.
"""

__version__ = "0.8.0"
# This will be replaced by CI/CD during release build
# Set to None for development, or a commit hash string for releases
__git_commit__: str | None = "7a598b6"
