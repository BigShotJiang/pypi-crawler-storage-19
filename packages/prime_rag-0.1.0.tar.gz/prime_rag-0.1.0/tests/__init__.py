"""Test suite for PRIME."""
