"""SSM unit test package."""
