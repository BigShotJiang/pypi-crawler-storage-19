"""SSM benchmark tests."""
