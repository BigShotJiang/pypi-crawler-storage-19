"""Benchmark tests for PRIME."""
