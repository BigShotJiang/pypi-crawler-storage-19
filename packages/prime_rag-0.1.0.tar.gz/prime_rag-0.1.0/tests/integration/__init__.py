"""Integration tests for PRIME."""
