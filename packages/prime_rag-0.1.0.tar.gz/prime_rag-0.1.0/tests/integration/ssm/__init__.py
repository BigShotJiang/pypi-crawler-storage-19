"""SSM integration tests."""
