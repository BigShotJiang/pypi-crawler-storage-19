from setuptools import setup, find_packages

setup(
    name="spgui",
    version="0.1.0",
    author="Hafiz Daffa W",
    author_email="hafizdaffaw+dev@gmail.com",
    description="A premium, grid-based Python GUI library built on CustomTkinter.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/HafizDaffa01/SulvionPiGUI",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "customtkinter",
        "matplotlib",
        "pillow",
    ],
)
