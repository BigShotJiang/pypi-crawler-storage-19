""" ae unit tests. """
from ae.ae import __version__


def test_version():
    assert __version__
