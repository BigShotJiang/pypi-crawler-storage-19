# -*- coding: utf-8 -*-
"""Fallback for all_logs_list.json."""
import datetime

import dateutil.parser

UPDATED: str = "2022-02-15 20:54:41.901119+00:00"
FALLBACK_UPDATED: datetime.datetime = dateutil.parser.parse(UPDATED)
FALLBACK_JSON: str = """{
  "operators": [
    {
      "name": "Google",
      "email": [
        "google-ct-logs@googlegroups.com"
      ],
      "logs": [
        {
          "description": "Google 'Argon2017' log",
          "log_id": "+tTJfMSe4vishcXqXOoJ0CINu/TknGtQZi/4aPhrjCg=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEVG18id3qnfC6X/RtYHo3TwIlvxz2b4WurxXfaW7t26maKZfymXYe5jNGHif0vnDdWde6z/7Qco6wVw+dN4liow==",
          "url": "https://ct.googleapis.com/logs/argon2017/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2018-02-27T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2017-01-01T00:00:00Z",
            "end_exclusive": "2018-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Argon2018' log",
          "log_id": "pFASaQVaFVReYhGrN7wQP2KuVXakXksXFEU+GyIQaiU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE0gBVBa3VR7QZu82V+ynXWD14JM3ORp37MtRxTmACJV5ZPtfUA7htQ2hofuigZQs+bnFZkje+qejxoyvk2Q1VaA==",
          "url": "https://ct.googleapis.com/logs/argon2018/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2019-05-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2018-01-01T00:00:00Z",
            "end_exclusive": "2019-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Argon2019' log",
          "log_id": "Y/Lbzeg7zCzPC3KEJ1drM6SNYXePvXWmOLHHaFRL2I0=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEI3MQm+HzXvaYa2mVlhB4zknbtAT8cSxakmBoJcBKGqGwYS0bhxSpuvABM1kdBTDpQhXnVdcq+LSiukXJRpGHVg==",
          "url": "https://ct.googleapis.com/logs/argon2019/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-02-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Argon2020' log",
          "log_id": "sh4FzIuizYogTodm+Su5iiUgZ2va+nDnsklTLe+LkF4=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE6Tx2p1yKY4015NyIYvdrk36es0uAc1zA4PQ+TGRY+3ZjUTIYY9Wyu+3q/147JG4vNVKLtDWarZwVqGkg6lAYzA==",
          "url": "https://ct.googleapis.com/logs/argon2020/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2021-04-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Argon2021' log",
          "log_id": "9lyUL9F3MCIUVBgIMJRWjuNNExkzv98MLyALzE7xZOM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAETeBmZOrzZKo4xYktx9gI2chEce3cw/tbr5xkoQlmhB18aKfsxD+MnILgGNl0FOm0eYGilFVi85wLRIOhK8lxKw==",
          "url": "https://ct.googleapis.com/logs/argon2021/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2018-06-15T02:30:13Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Argon2022' log",
          "log_id": "KXm+8J45OSHwVnOfY6V35b5XfZxgCvj5TV0mXCVdx4Q=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEeIPc6fGmuBg6AJkv/z7NFckmHvf/OqmjchZJ6wm2qN200keRDg352dWpi7CHnSV51BpQYAj1CQY5JuRAwrrDwg==",
          "url": "https://ct.googleapis.com/logs/argon2022/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-12-17T18:38:01Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Argon2023' log",
          "log_id": "6D7Q2j71BjUy51covIlryQPTy9ERa+zraeF3fW0GvW4=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE0JCPZFJOQqyEti5M8j13ALN3CAVHqkVM4yyOcKWCu2yye5yYeqDpEXYoALIgtM3TmHtNlifmt+4iatGwLpF3eA==",
          "url": "https://ct.googleapis.com/logs/argon2023/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-12-17T18:38:01Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Argon2024' log",
          "log_id": "7s3QZNXbGs7FXLedtM0TojKHRny87N7DUUhZRnEftZs=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEHblsqctplMVc5ramA7vSuNxUQxcomQwGAVAdnWTAWUYr3MgDHQW0LagJ95lB7QT75Ve6JgT2EVLOFGU7L3YrwA==",
          "url": "https://ct.googleapis.com/logs/argon2024/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2024-01-01T00:00:00Z",
            "end_exclusive": "2025-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Xenon2018' log",
          "log_id": "sQzVWabWeEaBH335pRUyc5rEjXA76gMj2l04dVvArU4=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1syJvwQdrv0a8dM2VAnK/SmHJNw/+FxC+CncFcnXMX2jNH9Xs7Q56FiV3taG5G2CokMsizhpcm7xXzuR3IHmag==",
          "url": "https://ct.googleapis.com/logs/xenon2018/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2019-02-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2018-01-01T00:00:00Z",
            "end_exclusive": "2019-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Xenon2019' log",
          "log_id": "CEEUmABxUywWGQRgvPxH/cJlOvopLHKzf/hjrinMyfA=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE/XyDwqzXL9i2GTjMYkqaEyiRL0Dy9sHq/BTebFdshbvCaXXEh6mjUK0Yy+AsDcI4MpzF1l7Kded2MD5zi420gA==",
          "url": "https://ct.googleapis.com/logs/xenon2019/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-02-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Xenon2020' log",
          "log_id": "B7dcG+V9aP/xsMYdIxXHuuZXfFeUt2ruvGE6GmnTohw=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEZU75VqjyzSTgFZKAnWg1QeYfFFIRZTMK7q3kWWZsmHhQdrBYnHRZ3OA4kUeUx0JN+xX+dSgt1ruqUhhl7jOvmw==",
          "url": "https://ct.googleapis.com/logs/xenon2020/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2021-04-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Xenon2021' log",
          "log_id": "fT7y+I//iFVoJMLAyp5SiXkrxQ54CX8uapdomX4i8Nc=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAER+1MInu8Q39BwDZ5Rp9TwXhwm3ktvgJzpk/r7dDgGk7ZacMm3ljfcoIvP1E72T8jvyLT1bvdapylajZcTH6W5g==",
          "url": "https://ct.googleapis.com/logs/xenon2021/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-06-17T21:23:01Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Xenon2022' log",
          "log_id": "RqVV63X6kSAwtaKJafTzfREsQXS+/Um4havy/HD+bUc=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE+WS9FSxAYlCVEzg8xyGwOrmPonoV14nWjjETAIdZvLvukPzIWBMKv6tDNlQjpIHNrUcUt1igRPpqoKDXw2MeKw==",
          "url": "https://ct.googleapis.com/logs/xenon2022/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-06-17T21:23:01Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Xenon2023' log",
          "log_id": "rfe++nz/EMiLnT2cHj4YarRnKV3PsQwkyoWGNOvcgoo=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEchY+C+/vzj5g3ZXLY3q5qY1Kb2zcYYCmRV4vg6yU84WI0KV00HuO/8XuQqLwLZPjwtCymeLhQunSxgAnaXSuzg==",
          "url": "https://ct.googleapis.com/logs/xenon2023/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-12-17T18:38:01Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Xenon2024' log",
          "log_id": "dv+IPwq2+5VRwmHM9Ye6NLSkzbsp3GhCCp/mZ0xaOnQ=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEuWDgNB415GUAk0+QCb1a7ETdjA/O7RE+KllGmjG2x5n33O89zY+GwjWlPtwpurvyVOKoDIMIUQbeIW02UI44TQ==",
          "url": "https://ct.googleapis.com/logs/xenon2024/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2024-01-01T00:00:00Z",
            "end_exclusive": "2025-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Aviator' log",
          "log_id": "aPaY+B9kgr46jO65KB1M/HFRXWeT1ETRCmesu09P+8Q=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1/TMabLkDpCjiupacAlP7xNi0I1JYP8bQFAHDG1xhtolSY1l4QgNRzRrvSe8liE+NPWHdjGxfx3JhTsN9x8/6Q==",
          "url": "https://ct.googleapis.com/aviator/",
          "mmd": 86400,
          "state": {
            "readonly": {
              "timestamp": "2016-11-30T13:24:18Z",
              "final_tree_head": {
                "sha256_root_hash": "LcGcZRsm+LGYmrlyC5LXhV1T6OD8iH5dNlb0sEJl9bA=",
                "tree_size": 46466472
              }
            }
          }
        },
        {
          "description": "Google 'Icarus' log",
          "log_id": "KTxRllTIOWW6qlD8WAfUt2+/WHopctykwwz05UVH9Hg=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAETtK8v7MICve56qTHHDhhBOuV4IlUaESxZryCfk9QbG9co/CqPvTsgPDbCpp6oFtyAHwlDhnvr7JijXRD9Cb2FA==",
          "url": "https://ct.googleapis.com/icarus/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2017-03-06T19:35:01Z"
            }
          }
        },
        {
          "description": "Google 'Pilot' log",
          "log_id": "pLkJkLQYWBSHuxOizGdwCjw1mAT5G9+443fNDsgN3BA=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEfahLEimAoz2t01p3uMziiLOl/fHTDM0YDOhBRuiBARsV4UvxG2LdNgoIGLrtCzWE0J5APC2em4JlvR8EEEFMoA==",
          "url": "https://ct.googleapis.com/pilot/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2014-09-02T20:41:44Z"
            }
          }
        },
        {
          "description": "Google 'Rocketeer' log",
          "log_id": "7ku9t3XOYLrhQmkfq+GeZqMPfl+wctiDAMR7iXqo/cs=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEIFsYyDzBi7MxCAC/oJBXK7dHjG+1aLCOkHjpoHPqTyghLpzA9BYbqvnV16mAw04vUjyYASVGJCUoI3ctBcJAeg==",
          "url": "https://ct.googleapis.com/rocketeer/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2015-08-04T19:00:05Z"
            }
          }
        },
        {
          "description": "Google 'Skydiver' log",
          "log_id": "u9nfvB+KcbWTlCOXqpJ7RzhXlQqrUugakJZkNo4e0YU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEEmyGDvYXsRJsNyXSrYc9DjHsIa2xzb4UR7ZxVoV6mrc9iZB7xjI6+NrOiwH+P/xxkRmOFG6Jel20q37hTh58rA==",
          "url": "https://ct.googleapis.com/skydiver/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2017-03-06T19:35:01Z"
            }
          }
        },
        {
          "description": "Google 'Submariner' log",
          "log_id": "qJnYeAySkKr0YvMYgMz71SRR6XDQ+/WR73Ww2ZtkVoE=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEOfifIGLUV1Voou9JLfA5LZreRLSUMOCeeic8q3Dw0fpRkGMWV0Gtq20fgHQweQJeLVmEByQj9p81uIW4QkWkTw==",
          "url": "https://ct.googleapis.com/submariner/",
          "mmd": 86400
        },
        {
          "description": "Google 'Daedalus' log",
          "log_id": "HQJLjrFJizRN/YfqPvwJlvdQbyNdHUlwYaR3PEOcJfs=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEbgwcuu4rakGFYB17fqsILPwMCqUIsz7VcCTRbR0ttrfzizbcI02VYxK75IaNzOnR7qFAot8LowYKMMqNrKQpVg==",
          "url": "https://ct.googleapis.com/daedalus/",
          "mmd": 604800
        },
        {
          "description": "Google 'Testtube' log",
          "log_id": "sMyD5aX5fWuvfAnMKEkEhyrH6IsTLGNQt8b9JuFsbHc=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEw8i8S7qiGEs9NXv0ZJFh6uuOmR2Q7dPprzk9XNNGkUXjzqx2SDvRfiwKYwBljfWujozHESVPQyydGaHhkaSz/g==",
          "url": "https://ct.googleapis.com/testtube/",
          "mmd": 86400
        },
        {
          "description": "Google 'Crucible' log",
          "log_id": "w78Dp+HKiEHGB7rj/0Jw/KXsRbGG675OLPP8d4Yw9fY=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEKATl2B3SAbxyzGOfNRB+AytNTGvdF/FFY6HzWb+/HPE4lJ37vx2nEm99KYUy9SoNzF5VyTwCQG5nL/c5Q77yQQ==",
          "url": "https://ct.googleapis.com/logs/crucible/",
          "mmd": 86400
        },
        {
          "description": "Google 'Solera2018' log",
          "log_id": "UutLIl7IlpdIUGdfI+Q7wdAh4yFM5S7NX6h8IDzfygM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEEuFqn5cy1nACARlWIUjeJaRDKl0mcf9gvFZXpPhHsyykizXvULF5GZNGfucWIyUccBRfmYJZTTrXqw0mVts7hA==",
          "url": "https://ct.googleapis.com/logs/solera2018/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2018-01-01T00:00:00Z",
            "end_exclusive": "2019-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Solera2019' log",
          "log_id": "C3YOmouaaC+ImFsV6UdQGlZEa7qIMHhcOEKZQ4ZFDAA=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEJUwGinXUWVNaBiK2Vl/rdyMkxKaWJHR8dj9yD5AlZEtEbfvAMQQ8o7DQyXVm7TX+eAA9wL2Vtt6DpoMEL0q/rw==",
          "url": "https://ct.googleapis.com/logs/solera2019/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Solera2020' log",
          "log_id": "H8cs5aG3mfQAw1m/+WyjkTVI6GRCIGEJUum6F3T3usc=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEiKfWtuoWCPMEzSKySjMjXpo38WOdZr6Yq0WYa2JQOv1uVMxkqHywf9Gz1kGeRLq/Rz3tVVvXgqb4jQ1UqKVKnw==",
          "url": "https://ct.googleapis.com/logs/solera2020/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Solera2021' log",
          "log_id": "o8mYRegKt84AFXs3Qt8CB90nKytgLs+Y7iwS25xa5+c=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1glwxqXsw2VqlAbHSeWbTthMGNIuACVn8Jj/jrnY2iN2uVUrEEwLj5VUCb+WF2XY44+mfUVYY7R/d8TIZ4olnw==",
          "url": "https://ct.googleapis.com/logs/solera2021/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Solera2022' log",
          "log_id": "aXqvyhprU2+uISBQRt661+Dq6hPSQy5unY+zefK5qvM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEFWj6UQDxzHWmgzQtQQ7REDC0nxnU9mpOmA0lv5trA0t7IRzSkh4DOznPe+nkxmaC8iS1capCtKjyYhUNRrvWqA==",
          "url": "https://ct.googleapis.com/logs/solera2022/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "Google 'Solera2023' log",
          "log_id": "+X6XuNM+96FZAqU6GeF5kOXcQGoDGCW6rZPpj5ucacs=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEK9Y56IP6DGQy2d9moYGJChZPoktXoYwaG0MBN/4X5MSFmBaYJfNm3mCwzLVefkjh2wz8Q6q2S75hS/OeHGiZUg==",
          "url": "https://ct.googleapis.com/logs/solera2023/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        }
      ]
    },
    {
      "name": "Cloudflare",
      "email": [
        "ct-logs@cloudflare.com",
        "brendan@cloudflare.com",
        "nick@cloudflare.com",
        "pat@cloudflare.com",
        "zi@cloudflare.com",
        "ivan@cloudflare.com"
      ],
      "logs": [
        {
          "description": "Cloudflare 'Nimbus2017' Log",
          "log_id": "H7w24ALt6X9AGZ6Gs1c7ikIX2AGHdGrQ2gOgYFTSDfQ=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE15ypB40iQe6ToFJB2vSA8CW86/rzPNJ+kdg/LNpRvcjuKnLj/xhW5DoiDyI8xtUws5toLqtWwkFf1mRXFLFarw==",
          "url": "https://ct.cloudflare.com/logs/nimbus2017/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2017-11-13T19:42:25Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2017-01-01T00:00:00Z",
            "end_exclusive": "2018-01-01T00:00:00Z"
          }
        },
        {
          "description": "Cloudflare 'Nimbus2018' Log",
          "log_id": "23Sv7ssp7LH+yj5xbSzluaq7NveEcYPHXZ1PN7Yfv2Q=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEAsVpWvrH3Ke0VRaMg9ZQoQjb5g/xh1z3DDa6IuxY5DyPsk6brlvrUNXZzoIg0DcvFiAn2kd6xmu4Obk5XA/nRg==",
          "url": "https://ct.cloudflare.com/logs/nimbus2018/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2019-05-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2018-01-01T00:00:00Z",
            "end_exclusive": "2019-01-01T00:00:00Z"
          }
        },
        {
          "description": "Cloudflare 'Nimbus2019' Log",
          "log_id": "dH7agzGtMxCRIZzOJU9CcMK//V5CIAjGNzV55hB7zFY=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEkZHz1v5r8a9LmXSMegYZAg4UW+Ug56GtNfJTDNFZuubEJYgWf4FcC5D+ZkYwttXTDSo4OkanG9b3AI4swIQ28g==",
          "url": "https://ct.cloudflare.com/logs/nimbus2019/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-02-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-01T00:00:00Z"
          }
        },
        {
          "description": "Cloudflare 'Nimbus2020' Log",
          "log_id": "Xqdz+d9WwOe1Nkh90EngMnqRmgyEoRIShBh1loFxRVg=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE01EAhx4o0zPQrXTcYjgCt4MVFsT0Pwjzb1RwrM0lhWDlxAYPP6/gyMCXNkOn/7KFsjL7rwk78tHMpY8rXn8AYg==",
          "url": "https://ct.cloudflare.com/logs/nimbus2020/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2021-04-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "Cloudflare 'Nimbus2021' Log",
          "log_id": "RJRlLrDuzq/EQAfYqP4owNrmgr7YyzG1P9MzlrW2gag=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAExpon7ipsqehIeU1bmpog9TFo4Pk8+9oN8OYHl1Q2JGVXnkVFnuuvPgSo2Ep+6vLffNLcmEbxOucz03sFiematg==",
          "url": "https://ct.cloudflare.com/logs/nimbus2021/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2018-06-15T02:30:13Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Cloudflare 'Nimbus2022' Log",
          "log_id": "QcjKsd8iRkoQxqE6CUKHXk4xixsD6+tLx2jwkGKWBvY=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESLJHTlAycmJKDQxIv60pZG8g33lSYxYpCi5gteI6HLevWbFVCdtZx+m9b+0LrwWWl/87mkNN6xE0M4rnrIPA/w==",
          "url": "https://ct.cloudflare.com/logs/nimbus2022/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-10-31T19:22:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "Cloudflare 'Nimbus2023' Log",
          "log_id": "ejKMVNi3LbYg6jjgUh7phBZwMhOFTTvSK8E6V6NS61I=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEi/8tkhjLRp0SXrlZdTzNkTd6HqmcmXiDJz3fAdWLgOhjmv4mohvRhwXul9bgW0ODgRwC9UGAgH/vpGHPvIS1qA==",
          "url": "https://ct.cloudflare.com/logs/nimbus2023/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-10-31T19:22:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        }
      ]
    },
    {
      "name": "DigiCert",
      "email": [
        "ctops@digicert.com"
      ],
      "logs": [
        {
          "description": "DigiCert Log Server",
          "log_id": "VhQGmi/XwuzT9eG9RLI+x0Z2ubyZEVzA75SYVdaJ0N0=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEAkbFvhu7gkAW6MHSrBlpE1n4+HCFRkC5OLAjgqhkTH+/uzSfSl8ois8ZxAD2NgaTZe1M9akhYlrYkes4JECs6A==",
          "url": "https://ct1.digicert-ct.com/log/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2022-01-24T00:00:00Z"
            }
          }
        },
        {
          "description": "DigiCert Log Server 2",
          "log_id": "h3W/51l8+IxDmV+9827/Vo1HVjb/SrVgwbTq/16ggw8=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEzF05L2a4TH/BLgOhNKPoioYCrkoRxvcmajeb8Dj4XQmNY+gxa4Zmz3mzJTwe33i0qMVp+rfwgnliQ/bM/oFmhA==",
          "url": "https://ct2.digicert-ct.com/log/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2020-05-04T00:00:40Z"
            }
          }
        },
        {
          "description": "DigiCert Yeti2018 Log",
          "log_id": "wRZK4Kdy0tQ5LcgKwQdw1PDEm96ZGkhAwfoHUWT2M2A=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESYlKFDLLFmA9JScaiaNnqlU8oWDytxIYMfswHy9Esg0aiX+WnP/yj4O0ViEHtLwbmOQeSWBGkIu9YK9CLeer+g==",
          "url": "https://yeti2018.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2019-05-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2017-12-12T00:00:00Z",
            "end_exclusive": "2019-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Yeti2019 Log",
          "log_id": "4mlLribo6UAJ6IYbtjuD1D7n/nSI+6SPKJMBnd3x2/4=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEkZd/ow8X+FSVWAVSf8xzkFohcPph/x6pS1JHh7g1wnCZ5y/8Hk6jzJxs6t3YMAWz2CPd4VkCdxwKexGhcFxD9A==",
          "url": "https://yeti2019.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-02-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Yeti2020 Log",
          "log_id": "8JWkWfIA0YJAEC0vk4iOrUv+HUfjmeHQNKawqKqOsnM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEURAG+Zo0ac3n37ifZKUhBFEV6jfcCzGIRz3tsq8Ca9BP/5XUHy6ZiqsPaAEbVM0uI3Tm9U24RVBHR9JxDElPmg==",
          "url": "https://yeti2020.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2021-04-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Yeti2021 Log",
          "log_id": "XNxDkv7mq0VEsV6a1FbmEDf71fpH3KFzlLJe5vbHDso=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE6J4EbcpIAl1+AkSRsbhoY5oRTj3VoFfaf1DlQkfi7Rbe/HcjfVtrwN8jaC+tQDGjF+dqvKhWJAQ6Q6ev6q9Mew==",
          "url": "https://yeti2021.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2018-08-24T00:53:07Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Yeti2022 Log",
          "log_id": "IkVFB1lVJFaWP6Ev8fdthuAjJmOtwEt/XcaDXG7iDwI=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEn/jYHd77W1G1+131td5mEbCdX/1v/KiYW5hPLcOROvv+xA8Nw2BDjB7y+RGyutD2vKXStp/5XIeiffzUfdYTJg==",
          "url": "https://yeti2022.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2021-07-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Yeti2022-2 Log",
          "log_id": "BZwB0yDgB4QTlYBJjRF8kDJmr69yULWvO0akPhGEDUo=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEHWlePwrycXfNnV3DNEkA7mB34XJ2dKh8XH0J8jIdBX4u/lsx1Tr9czRuSRROUFiWWsTH9L4FZKT31+WxbTMMww==",
          "url": "https://yeti2022-2.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "pending": {
              "timestamp": "2021-07-20T07:41:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Yeti2023 Log",
          "log_id": "Nc8ZG7+xbFe/D61MbULLu7YnICZR6j/hKu+oA8M71kw=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEfQ0DsdWYitzwFTvG3F4Nbj8Nv5XIVYzQpkyWsU4nuSYlmcwrAp6m092fsdXEw6w1BAeHlzaqrSgNfyvZaJ9y0Q==",
          "url": "https://yeti2023.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-10-31T19:22:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Nessie2018 Log",
          "log_id": "b/FBtWR+QiL37wUs7658If1gjifSr1pun0uKN9ZjPuU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEVqpLa2W+Rz1XDZPBIyKJO+KKFOYZTj9MpJWnZeFUqzc5aivOiWEVhs8Gy2AlH3irWPFjIZPZMs3Dv7M+0LbPyQ==",
          "url": "https://nessie2018.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2019-05-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2017-12-12T00:00:00Z",
            "end_exclusive": "2019-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Nessie2019 Log",
          "log_id": "/kRhCLHQGreKYsz+q2qysrq/86va2ApNizDfLQAIgww=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEX+0nudCKImd7QCtelhMrDW0OXni5RE10tiiClZesmrwUk2iHLCoTHHVV+yg5D4n/rxCRVyRhikPpVDOLMLxJaA==",
          "url": "https://nessie2019.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-02-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Nessie2020 Log",
          "log_id": "xlKg7EjOs/yrFwmSxDqHQTMJ6ABlomJSQBujNioXxWU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE4hHIyMVIrR9oShgbQMYEk8WX1lmkfFKB448Gn93KbsZnnwljDHY6MQqEnWfKGgMOq0gh3QK48c5ZB3UKSIFZ4g==",
          "url": "https://nessie2020.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2021-04-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Nessie2021 Log",
          "log_id": "7sCV7o1yZA+S48O5G8cSo2lqCXtLahoUOOZHssvtxfk=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE9o7AiwrbGBIX6Lnc47I6OfLMdZnRzKoP5u072nBi6vpIOEooktTi1gNwlRPzGC2ySGfuc1xLDeaA/wSFGgpYFg==",
          "url": "https://nessie2021.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-05-09T22:11:02Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Nessie2022 Log",
          "log_id": "UaOw9f0BeZxWbbg3eI8MpHrMGyfL956IQpoN/tSLBeU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEJyTdaAMoy/5jvg4RR019F2ihEV1McclBKMe2okuX7MCv/C87v+nxsfz1Af+p+0lADGMkmNd5LqZVqxbGvlHYcQ==",
          "url": "https://nessie2022.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-05-09T22:11:02Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "DigiCert Nessie2023 Log",
          "log_id": "s3N3B+GEUPhjhtYFqdwRCUp5LbFnDAuH3PADDnk2pZo=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEEXu8iQwSCRSf2CbITGpUpBtFVt8+I0IU0d1C36Lfe1+fbwdaI0Z5FktfM2fBoI1bXBd18k2ggKGYGgdZBgLKTg==",
          "url": "https://nessie2023.ct.digicert.com/log/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2019-10-31T19:22:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        },
        {
          "description": "Symantec log",
          "log_id": "3esdK3oNT6Ygi4GtgWhwfi6OnQHVXIiNPRHEzbbsvsw=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEluqsHEYMG1XcDfy1lCdGV0JwOmkY4r87xNuroPS2bMBTP01CEDPwWJePa75y9CrsHEKqAy8afig1dpkIPSEUhg==",
          "url": "https://ct.ws.symantec.com/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2019-02-16T00:00:00Z"
            }
          }
        },
        {
          "description": "Symantec 'Vega' log",
          "log_id": "vHjh38X2PGhGSTNNoQ+hXwl5aSAJwIG08/aRfz7ZuKU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE6pWeAv/u8TNtS4e8zf0ZF2L/lNPQWQc/Ai0ckP7IRzA78d0NuBEMXR2G3avTK0Zm+25ltzv9WWis36b4ztIYTQ==",
          "url": "https://vega.ws.symantec.com/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2019-02-16T00:00:00Z"
            }
          }
        },
        {
          "description": "Symantec Deneb",
          "log_id": "p85KTmIH4K3e5f2qSx+GdodntdACpV1HMQ5+ZwqV6rI=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEloIeo806gIQel7i3BxmudhoO+FV2nRIzTpGI5NBIUFzBn2py1gH1FNbQOG7hMrxnDTfouiIQ0XKGeSiW+RcemA==",
          "url": "https://deneb.ws.symantec.com/",
          "mmd": 86400
        },
        {
          "description": "Symantec 'Sirius' log",
          "log_id": "FZcEiNe5l6Bb61JRKt7o0ui0oxZSZBIan6v71fha2T8=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEowJkhCK7JewN47zCyYl93UXQ7uYVhY/Z5xcbE4Dq7bKFN61qxdglnfr0tPNuFiglN+qjN2Syxwv9UeXBBfQOtQ==",
          "url": "https://sirius.ws.symantec.com/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2019-02-16T00:00:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "Certly",
      "email": [
        "ian@certly.io"
      ],
      "logs": [
        {
          "description": "Certly.IO log",
          "log_id": "zbUXm3/BwEb+6jETaj+PAC5hgvr4iW/syLL1tatgSQA=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAECyPLhWKYYUgEc+tUXfPQB4wtGS2MNvXrjwFCCnyYJifBtd2Sk7Cu+Js9DNhMTh35FftHaHu6ZrclnNBKwmbbSA==",
          "url": "https://log.certly.io/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2016-04-15T00:00:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "Izenpe",
      "email": [
        "atecnica@izenpe.net"
      ],
      "logs": [
        {
          "description": "Izenpe log",
          "log_id": "dGG0oJz7PUHXUVlXWy52SaRFqNJ3CbDMVkpkgrfrQaM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEJ2Q5DC3cUBj4IQCiDu0s6j51up+TZAkAEcQRF6tczw90rLWXkJMAW7jr9yc92bIKgV8vDXU4lDeZHvYHduDuvg==",
          "url": "https://ct.izenpe.com/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2016-05-30T00:00:00Z"
            }
          }
        },
        {
          "description": "Izenpe 'Argi' log",
          "log_id": "iUFEnHB0Lga5/JznsRa6ACSqNtWa9E8CBEBPAPfqhWY=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE18gOIz6eAjyauAdKKgX/SkuI1IpNOc73xfK2N+mj7eT1RQkOZxT9UyTVOpTy6rUT2R2LXKfD82vYPy07ZXJY1g==",
          "url": "https://ct.izenpe.eus/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2016-08-25T11:36:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "WoSign",
      "email": [
        "ctlog@wosign.com"
      ],
      "logs": [
        {
          "description": "WoSign CT log #1",
          "log_id": "nk/3PcPOIgtpIXyJnkaAdqv414Y21cz8haMadWKLqIs=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1+wvK3VPN7yjQ7qLZWY8fWrlDCqmwuUm/gx9TnzwOrzi0yLcAdAfbkOcXG6DrZwV9sSNYLUdu6NiaX7rp6oBmw==",
          "url": "https://ct.wosign.com/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2016-04-02T01:27:00Z"
            }
          }
        },
        {
          "description": "WoSign log",
          "log_id": "QbLcLonmPOSvG6e7Kb9oxt7m+fHMBH4w3/rjs7olkmM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEzBGIey1my66PTTBmJxklIpMhRrQvAdPG+SvVyLpzmwai8IoCnNBrRhgwhbrpJIsO0VtwKAx+8TpFf1rzgkJgMQ==",
          "url": "https://ctlog.wosign.com/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2018-02-12T23:59:59Z"
            }
          }
        },
        {
          "description": "WoSign log 2",
          "log_id": "Y9AAYCbd4QuwYB9FJEaWXuK26izU+8layGalUK+Qdbc=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEpYzoNS6O5Wp1rVxLMWEpnTBXjgITX+nKu1KoQwVgvw1zV3eyBdhn9vAzyflE3rZTc6oMVcKDCkvOXhrHFx2zzQ==",
          "url": "https://ctlog2.wosign.com/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2017-09-04T13:30:58Z"
            }
          }
        }
      ]
    },
    {
      "name": "Wang Shengnan",
      "email": [
        "capoc@gdca.com.cn"
      ],
      "logs": [
        {
          "description": "GDCA CT log #1",
          "log_id": "yc+JCiEQnGZswXo+0GXJMNDgE1qf66ha8UIQuAckIao=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAErQ8wrZ55pDiJJlSGq0FykG/7yhemrO7Gn30CBexBqMdBnTJJrbA5vTqHPnzuaGxg0Ucqk67hQPQLyDU8HQ9l0w==",
          "url": "https://ct.gdca.com.cn/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2016-07-12T13:03:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "GDCA",
      "email": [
        "capoc@gdca.com.cn"
      ],
      "logs": [
        {
          "description": "GDCA CT log #2",
          "log_id": "kkow+Qkzb/Q11pk6EKx1osZBco5/wtZZrmGI/61AzgE=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEW0rHAbd0VLpAnEN1lD+s77NxVrjT4nuuobE+U6qXM6GCu19dHAv6hQ289+Wg4CLwoInZCn9fJpTTJOOZLuQVjQ==",
          "url": "https://ctlog.gdca.com.cn/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2017-01-11T10:46:00Z"
            }
          }
        },
        {
          "description": "GDCA Log 1",
          "log_id": "cX6nQgl1voSicjVT8Xd8Jt1Rr04QIUQJTZAZtGL7Zmg=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEzVH/qe+rgr/Mo+owQ00I6aegDSjHttgqQBmg+hBdTXXLgJT/+8LdSgjfY/8lOBtfivndJzQlTNQ9Le1cU6wXNQ==",
          "url": "https://log.gdca.com.cn/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2018-11-05T22:18:14Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2018-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "GDCA Log 2",
          "log_id": "FDCNkMzQMBNQBcAcpSbYHoTodiTjm2JI4I9ySuo7tCo=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEx6zC8wCbMs3fpQWnSCeo2RvG827AEssGkMa+5RVIpRF0SDO4hFsn2Ph1l8marSCuwVLhv0JIN3arSzbUieX6HA==",
          "url": "https://log2.gdca.com.cn/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2018-11-08T05:47:34Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2018-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        }
      ]
    },
    {
      "name": "Sectigo",
      "email": [
        "ctops@sectigo.com"
      ],
      "logs": [
        {
          "description": "Sectigo 'Dodo' CT log",
          "log_id": "23b9raxl59CVCIhuIVm9i5A1L1/q0+PcXiLrNQrMe5g=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAELPXCMfVjQ2oWSgrewu4fIW4Sfh3lco90CwKZ061pvAI1eflh6c8ACE90pKM0muBDHCN+j0HV7scco4KKQPqq4A==",
          "url": "https://dodo.ct.comodo.com/",
          "mmd": 86400
        },
        {
          "description": "Sectigo 'Sabre' CT log",
          "log_id": "VYHUwhaQNgFK6gubVzxT8MDkOHhwJQgXL6OqHQcT0ww=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE8m/SiQ8/xfiHHqtls9m7FyOMBg4JVZY9CgiixXGz0akvKD6DEL8S0ERmFe9U4ZiA0M4kbT5nmuk3I85Sk4bagA==",
          "url": "https://sabre.ct.comodo.com/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2017-10-10T00:38:10Z"
            }
          }
        },
        {
          "description": "Sectigo 'Mammoth' CT log",
          "log_id": "b1N2rDHwMRnYmQCkURX/dxUcEdkCwQApBo2yCJo32RM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE7+R9dC4VFbbpuyOL+yy14ceAmEf7QGlo/EmtYU6DRzwat43f/3swtLr/L8ugFOOt1YU/RFmMjGCL17ixv66MZw==",
          "url": "https://mammoth.ct.comodo.com/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2017-10-10T00:38:10Z"
            }
          }
        }
      ]
    },
    {
      "name": "Venafi",
      "email": [
        "ctlog-admin@venafi.com"
      ],
      "logs": [
        {
          "description": "Venafi log",
          "log_id": "rDua7X+pZ0dXFZ5tfVdWcvnZgQCUHpve/+yhMTt1eC0=",
          "keys": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAolpIHxdSlTXLo1s6H1OCdpSj/4DyHDc8wLG9wVmLqy1lk9fz4ATVmm+/1iN2Nk8jmctUKK2MFUtlWXZBSpym97M7frGlSaQXUWyA3CqQUEuIJOmlEjKTBEiQAvpfDjCHjlV2Be4qTM6jamkJbiWtgnYPhJL6ONaGTiSPm7Byy57iaz/hbckldSOIoRhYBiMzeNoA0DiRZ9KmfSeXZ1rB8y8X5urSW+iBzf2SaOfzBvDpcoTuAaWx2DPazoOl28fP1hZ+kHUYvxbcMjttjauCFx+JII0dmuZNIwjfeG/GBb9frpSX219k1O4Wi6OEbHEr8at/XQ0y7gTikOxBn/s5wQIDAQAB",
          "url": "https://ctlog.api.venafi.com/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2017-02-28T18:42:26Z"
            }
          }
        },
        {
          "description": "Venafi Gen2 CT log",
          "log_id": "AwGd8/2FppqOvR+sxtqbpz5Gl3T+d/V5/FoIuDKMHWs=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEjicnerZVCXTrbEuUhGW85BXx6lrYfA43zro/bAna5ymW00VQb94etBzSg4j/KS/Oqf/fNN51D8DMGA2ULvw3AQ==",
          "url": "https://ctlog-gen2.api.venafi.com/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-05-08T00:00:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "CNNIC",
      "email": [
        "ctlog-admin@cnnic.cn"
      ],
      "logs": [
        {
          "description": "CNNIC CT log",
          "log_id": "pXesnO11SN2PAltnokEInfhuD0duwgPC7L7bGF8oJjg=",
          "keys": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAv7UIYZopMgTTJWPp2IXhhuAf1l6a9zM7gBvntj5fLaFm9pVKhKYhVnno94XuXeN8EsDgiSIJIj66FpUGvai5samyetZhLocRuXhAiXXbDNyQ4KR51tVebtEq2zT0mT9liTtGwiksFQccyUsaVPhsHq9gJ2IKZdWauVA2Fm5x9h8B9xKn/L/2IaMpkIYtd967TNTP/dLPgixN1PLCLaypvurDGSVDsuWabA3FHKWL9z8wr7kBkbdpEhLlg2H+NAC+9nGKx+tQkuhZ/hWR65aX+CNUPy2OB9/u2rNPyDydb988LENXoUcMkQT0dU3aiYGkFAY0uZjD2vH97TM20xYtNQIDAQAB",
          "url": "https://ctserver.cnnic.cn/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2018-09-18T00:00:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "StartCom",
      "email": [
        "ct@startssl.com"
      ],
      "logs": [
        {
          "description": "StartCom log",
          "log_id": "NLtq1sPfnAPuqKSZ/3iRSGydXlysktAfe/0bzhnbSO8=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESPNZ8/YFGNPbsu1Gfs/IEbVXsajWTOaft0oaFIZDqUiwy1o/PErK38SCFFWa+PeOQFXc9NKv6nV0+05/YIYuUQ==",
          "url": "https://ct.startssl.com/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2018-02-12T23:59:59Z"
            }
          }
        }
      ]
    },
    {
      "name": "Beijing PuChuangSiDa Technology Ltd.",
      "email": [
        "certificatetransparency@outlook.com"
      ],
      "logs": [
        {
          "description": "PuChuangSiDa CT log",
          "log_id": "4BJ2KekEllZOPQFHmESYqkj4rbFmAOt5AqHvmQmQYnM=",
          "keys": "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArM8vS3Cs8Q2Wv+gK/kSd1IwXncOaEBGEE+2M+Tdtg+QAb7FLwKaJx2GPmjS7VlLKA1ZQ7yR/S0npNYHd8OcX9XLSI8XjE3/Xjng1j0nemASKY6+tojlwlYRoS5Ez/kzhMhfC8mG4Oo05f9WVgj5WGVBFb8sIMw3VGUIIGkhCEPFow8NBE8sNHtsCtyR6UZZuvAjqaa9t75KYjlXzZeXonL4aR2AwfXqArVaDepPDrpMraiiKpl9jGQy+fHshY0E4t/fodnNrhcy8civBUtBbXTFOnSrzTZtkFJkmxnH4e/hE1eMjIPMK14tRPnKA0nh4NS1K50CZEZU01C9/+V81NwIDAQAB",
          "url": "https://www.certificatetransparency.cn/ct/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2017-06-08T00:00:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "NORDUnet",
      "email": [
        "linus@nordu.net"
      ],
      "logs": [
        {
          "description": "Nordu 'flimsy' log",
          "log_id": "U3tpo1ZDNanASQTjlZOywpjrjXpugwI2NcYnJIzWtEA=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE4qWq6afhBUi0OdcWUYhyJLNXTkGqQ9PMS5lqoCgkV2h1ZvpNjBH2u8UbgcOQwqDo66z6BWQJGolozZYmNHE2kQ==",
          "url": "https://flimsy.ct.nordu.net:8080/",
          "mmd": 86400
        },
        {
          "description": "Nordu 'plausible' log",
          "log_id": "qucLfzy41WbIbC8Wl5yfRF9pqw60U1WJsvd6AwEE880=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE9UV9+jO2MCTzkabodO2F7LM03MUBc8MrdAtkcW6v6GA9taTTw9QJqofm0BbdAsbtJL/unyEf0zIkRgXjjzaYqQ==",
          "url": "https://plausible.ct.nordu.net/",
          "mmd": 86400
        }
      ]
    },
    {
      "name": "SHECA",
      "email": [
        "CTLS@sheca.com"
      ],
      "logs": [
        {
          "description": "SHECA CT log 1",
          "log_id": "z1XiiSNJfDQNUgbQU1Ouslg0tS8fjclSaAnyEu/dfKY=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEEalgK7RxRWbgLt7VhzvV/vCSN/RoxpLdPxrivAwi1pljKW4yKBTAdiyAqCJRkdbrptjx7PAHfrD8dnB2cnyR6Q==",
          "url": "http://ctlog.sheca.com/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2017-03-22T14:16:19Z"
            }
          }
        },
        {
          "description": "SHECA CT log 2",
          "log_id": "MtxZwtTEGWjVbhS8YayPDkXbOfrzwVWqQlL1AB+gxiM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEsY4diqo6rM6Gy1N26KidWb4XiAMH8ifggr6x/Gc7Ru7T8Y3Wd+ijtNsJXKAJQ/xf0Gg0IyQIwk/Y0rad7dWM2w==",
          "url": "https://ct.sheca.com/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2017-12-01T20:22:23Z"
            }
          }
        }
      ]
    },
    {
      "name": "Akamai",
      "email": [
        "ct-help@akamai.com"
      ],
      "logs": [
        {
          "description": "Akamai CT Log",
          "log_id": "lgbALGkAM6odFF9ZxuJkjQVJ8N+WqrjbkVpw2OzzkKU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEQ3nrSVxQKkpqj1mTvMNCdsKZ+CeBPAZs0sgEj3R7tLUh8uOo3DO5/iXpPQT8P7SuQONFfoSSKthS6x8/cxPQyA==",
          "url": "https://ct.akamai.com/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2015-11-27T15:37:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "Matt Palmer",
      "email": [
        "ops@ctlogs.org"
      ],
      "logs": [
        {
          "description": "Alpha CT Log",
          "log_id": "OTdvVF97Rgf1l0LXaM1dJDe/NHO2U0pINLz3Lmgcg8k=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEovftE+HTXAIIxI6Lm4s7OWjHkmo4oU8jxaVvb9dlgfjBm/SfqYtF9LlOG8miaReleIfZzohvQQO7oyrjd5eNeA==",
          "url": "https://alpha.ctlogs.org/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2015-01-27T14:38:00Z"
            }
          }
        }
      ]
    },
    {
      "name": "Let's Encrypt",
      "email": [
        "sre@letsencrypt.org"
      ],
      "logs": [
        {
          "description": "Let's Encrypt 'Oak2019' log",
          "log_id": "ZZszUPQ7EsxepatOx2XT/ebIgkN3d3jnIAP56yuMMSk=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEFkqNKRuZ+Z8IOsnNJrUZ8gwp+KKGOdQrJ/HKhSadK/SJuoCc9+dxQ7awpmWIMr9SKcQeG5uRzG1kVSyFN4Wfcw==",
          "url": "https://oak.ct.letsencrypt.org/2019/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-02-07T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Oak2020' log",
          "log_id": "5xLysDd+GmL7jskMYYTx6ns3y1YdESZb8+DzS/JBVG4=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEfzb42Zdr/h7hgqgDCo1vrNJqGqbcUvJGJEER9DDqp19W/wFSB0l166hD+U5cAXchpH8ZkBNUuvOHS0OnJ4oJrQ==",
          "url": "https://oak.ct.letsencrypt.org/2020/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2021-04-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Oak2021' log",
          "log_id": "lCC8Ho7VjWyIcx+CiyIsDdHaTV5sT5Q9YdtOL1hNosI=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAELsYzGMNwo8rBIlaklBIdmD2Ofn6HkfrjK0Ukz1uOIUC6Lm0jTITCXhoIdjs7JkyXnwuwYiJYiH7sE1YeKu8k9w==",
          "url": "https://oak.ct.letsencrypt.org/2021/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2020-01-27T18:18:26Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Oak2022' log",
          "log_id": "36Veq2iCTx9sre64X04+WurNohKkal6OOxLAIERcKnM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEhjyxDVIjWt5u9sB/o2S8rcGJ2pdZTGA8+IpXhI/tvKBjElGE5r3de4yAfeOPhqTqqc+o7vPgXnDgu/a9/B+RLg==",
          "url": "https://oak.ct.letsencrypt.org/2022/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2020-01-27T18:18:26Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Oak2023' log",
          "log_id": "tz77JN+cTbp18jnFulj0bF38Qs96nzXEnh0JgSXttJk=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEsz0OeL7jrVxEXJu+o4QWQYLKyokXHiPOOKVUL3/TNFFquVzDSer7kZ3gijxzBp98ZTgRgMSaWgCmZ8OD74mFUQ==",
          "url": "https://oak.ct.letsencrypt.org/2023/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2021-03-01T19:24:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Testflume2019' log",
          "log_id": "hJ9ff1jSv3tU7L10YRzqRcScmPHWSBvG9p6MF08k888=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEAg3+vFOesFW51rKECekioAt9Zo50atRoOJ0qLxF7DIEHsHneXLEpgO1WMreleRy1vEbUJD7TXoH9r8qSDGvyew==",
          "url": "https://testflume.ct.letsencrypt.org/2019/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2019-01-01T00:00:00Z",
            "end_exclusive": "2020-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Testflume2020' log",
          "log_id": "xj8iGMN9VqaqBrWW2o5T1NcVbR6brI5E0iAt5k1p2dw=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEjdjcoKpeBShHgHvRm3BxD5+l+eHZudv3KmD5SDcLcI01Vj5TDTmxanQKCgpvm9pfnfB6URMQV3hhU1I02jRoRw==",
          "url": "https://testflume.ct.letsencrypt.org/2020/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Testflume2021' log",
          "log_id": "A+3x2pd2tvOMNB457Z1wenVwNpz5hE8yf+nhQTg2G2A=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEdCLoJNt1QcNa7sNDp7g7oTJ+o/UIYEM6N/IZWT+dhdqtJZC+AODJ/4exdOwG04B4K6WrN1VB2ELKQIc/wU1lCw==",
          "url": "https://testflume.ct.letsencrypt.org/2021/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Testflume2022' log",
          "log_id": "Iyfv2jUlENvAGe9JGuP/HMWkebzjeHg2DuMYz/tk+Mg=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEjy/rXcABuf0yhrm1+XgjDnh4XPD7vfMoyJOyT+KA+c2zuXVR98yQmp/Bl5ZFdGFwJuFcVrCw7IDo0EGKs7UCww==",
          "url": "https://testflume.ct.letsencrypt.org/2022/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Testflume2023' log",
          "log_id": "VTS3q1pqw6fL66ZUh7Ki1xtI9lD6F8UZfJegyyB288Y=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE8aLpnumqeISmQEB3hKPgtPJQG3jP2IftfaUQ4WPUihNBwUOEk1R9BMg5RGQwebWSsRlGIRiCvtE97Q45Vh3mqA==",
          "url": "https://testflume.ct.letsencrypt.org/2023/",
          "mmd": 86400,
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-07T00:00:00Z"
          }
        },
        {
          "description": "Let's Encrypt 'Clicky' log",
          "log_id": "KWr6LVaLyg0uqESVaulyH8Nfo1Xs2plpOq/UWKca790=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEHxoVg3cAdWK5n/YGBe2ViYNBgZfn4NQz/na6O8lJws3xz/4ScNe+qCJfsqRnAntxrh2sqOnRCNXO7zN6w18A3A==",
          "url": "https://clicky.ct.letsencrypt.org/",
          "mmd": 86400
        }
      ]
    },
    {
      "name": "Up In The Air Consulting",
      "email": [
        "filippo@cloudflare.com"
      ],
      "logs": [
        {
          "description": "Up In The Air 'Behind the Sofa' log",
          "log_id": "sLeEvIHA3cR1ROiD8FmFu5B30TTYq4iysuUzmAuOUIs=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEWTmyppTGMrn+Y2keMDujW9WwQ8lQHpWlLadMSkmOi4+3+MziW5dy1eo/sSFI6ERrf+rvIv/f9F87bXcEsa+Qjw==",
          "url": "https://ct.filippo.io/behindthesofa/",
          "mmd": 86400
        }
      ]
    },
    {
      "name": "Qihoo 360",
      "email": [
        "yanshousheng@360.cn"
      ],
      "logs": [
        {
          "description": "Qihoo 360 2020",
          "log_id": "R0RHfHXeQm1cRO/UqSyWd1l/ZXqP4MrbxtYW7aSXxCU=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE+nuP0XjE36o+HfjS9IKnDItCnp3Tn9NafZpJ/8GHvLm+Z/AXY7FuN3L4LPXRrlTydBLt60OqzktHoJ4t4fNodg==",
          "url": "https://ct.browser.360.cn/2020/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-04-30T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "Qihoo 360 2021",
          "log_id": "xtftntuOdPCnG01KmEvL66u9KMwf12Mp6IcmzUwlRmM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEYFtlqKC59Iy+N1sWaUktnSNpbhrrL4VMiaqdDrQu/3hOnxOJiXFlkSYQjBoHDCVA5iC9pu8+1DsrmNsv5FIMDw==",
          "url": "https://ct.browser.360.cn/2021/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-04-30T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Qihoo 360 2022",
          "log_id": "ZjywnB/Nm6pidjzLU07sgFgSKAUHrGmkX804z0zHTPE=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEQ4UlFLE3vxDHtsqO5s6kNURSyaLK9bHV5+zDXTQzwiUJdTFKxE85L5uvYvobuyZpySo7GXYyopL4Exsrm4HJMA==",
          "url": "https://ct.browser.360.cn/2022/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-04-30T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "Qihoo 360 2023",
          "log_id": "4mR/bto0BQPGTU4QqGloH96cWizzsy1fIAuWNgWQiCM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEBQLIGtQH3merk2OMO2LbKU2TFroKxaChr4+FxB5UMLYTspqEJKcD7mRXEObHJ6PI/39UvEI98N4Cyf9x2rKvqg==",
          "url": "https://ct.browser.360.cn/2023/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-04-30T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        },
        {
          "description": "Qihoo 360 v1 2020",
          "log_id": "xc/lS2FRtJsULtJjvecykzY3mXmVUK5ENc0aaZfJw8M=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEDkQZn1WqxqWyWHG86i14qbZ+yk/17Q8SWeubOJw6jQdNJRh4zJwD3mGTZIQge3T6QOgzChWUJA3wYztSx+M/gg==",
          "url": "https://ct.browser.360.cn/v1/2020/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-10-06T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "Qihoo 360 v1 2021",
          "log_id": "SBRYfPKLCP5oP9K82UWZTC63TIroyH/OQpt80x1RvcQ=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEB1OT52y/+wSUqaHfJh6/BvTD27mlZr6qZddkis7McckOaXx5cU3I/fBx90p3j1tWqEArVuiKmHHAvu82l9Uz2w==",
          "url": "https://ct.browser.360.cn/v1/2021/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-10-06T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Qihoo 360 v1 2022",
          "log_id": "SRG41hTP09mfFtN2VF7huMz8UR9QnwgLoKCH2R367qk=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEAvqcteHHGEZCE5kSvEpQIPD4fXsEFHYt1/EViSMv7QDtBHTpK94IZSScZLOWk5fpvGIB/6ibVzR5MCW/NSMd/A==",
          "url": "https://ct.browser.360.cn/v1/2022/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-10-06T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "Qihoo 360 v1 2023",
          "log_id": "tnQLEgAuAz/Q5+lB9Lo+4b/BSbUktM9ijVPv6h9AOo0=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEpvIPBkpPfcg4boasja6srvBflgDAznTytKjNWPX151jP/EaRZmNOFBavgBI2oxlQabgYG11YHdwH+FHnyVTaNw==",
          "url": "https://ct.browser.360.cn/v1/2023/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-10-06T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        }
      ]
    },
    {
      "name": "TrustAsia",
      "email": [
        "trustasia-ct-logs@trustasia.com"
      ],
      "logs": [
        {
          "description": "Trust Asia Log1",
          "log_id": "RTWUmNk6ieAoAwjTfWJtxCN1R1jc4DcANvurDt+Ka88=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEeUeY0SDoUdASOMgFwOFUSkaZ8NoKnknjtbakmBDUJJhPVn9L/adnExZBXl46ZBT701qUixfqd/s3BpuMyWWUdw==",
          "url": "https://ct.trustasia.com/log1/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2020-04-28T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2025-01-01T00:00:00Z"
          }
        },
        {
          "description": "Trust Asia Log2020",
          "log_id": "pZWUO1NwvukG4AUNH7W7xqQOZfJlroUsdjY/rbIzNu0=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEbsWC7ukn2WYOMxTAcqL8gMRZEQTZF9+Ho1MB9WLhHIaCHpHsJSx0DjJdVILW9mtM5xZtWywMWMQ9/R3OBgQEXQ==",
          "url": "https://ct.trustasia.com/log2020/",
          "mmd": 86400,
          "state": {
            "rejected": {
              "timestamp": "2021-04-21T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2020-01-01T00:00:00Z",
            "end_exclusive": "2021-01-01T00:00:00Z"
          }
        },
        {
          "description": "Trust Asia CT2021",
          "log_id": "qNxS9j1rJCXlMeN89ORKcU8UKiCAOw0E0uLuBmR5SiM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAESdAfC+h1SZNsSARs188n/dCiNYjGSgkT7avLYe1mmXJzzHhsmxmAorHtOzhDkFgaCSCrUPrXdunK946eyIeSmA==",
          "url": "https://ct2021.trustasia.com/log2021/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2021-10-16T01:46:32Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Trust Asia Log2021",
          "log_id": "Z422Wz50Q7bzo3DV4TqxtDvgoNNR98p0IlDHxvpRqIo=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEjwlzYzssDEG4DpPoOS73Ewsdohc0MzaohzRmUz9dih7Z8SHyyviKmnQL1KKfY6VGFnt0ulbVupzGXSaYUAoupA==",
          "url": "https://ct.trustasia.com/log2021/",
          "mmd": 86400,
          "state": {
            "retired": {
              "timestamp": "2020-12-01T00:00:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2021-01-01T00:00:00Z",
            "end_exclusive": "2022-01-01T00:00:00Z"
          }
        },
        {
          "description": "Trust Asia Log2022",
          "log_id": "w2X5s2VPMoPHnamOk9dBj1ure+MlLJjh0vBLuetCfSM=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEu1LyFs+SC8555lRtwjdTpPX5OqmzBewdvRbsMKwu+HliNRWOGtgWLuRIa/bGE/GWLlwQ/hkeqBi4Dy3DpIZRlw==",
          "url": "https://ct.trustasia.com/log2022/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2021-03-01T19:24:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2022-01-01T00:00:00Z",
            "end_exclusive": "2023-01-01T00:00:00Z"
          }
        },
        {
          "description": "Trust Asia Log2023",
          "log_id": "6H6nZgvCbPYALvVyXT/g4zG5OTu5L79Y6zuQSdr1Q1o=",
          "keys": "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEpBFS2xdBTpDUVlESMFL4mwPPTJ/4Lji18Vq6+ji50o8agdqVzDPsIShmxlY+YDYhINnUrF36XBmhBX3+ICP89Q==",
          "url": "https://ct.trustasia.com/log2023/",
          "mmd": 86400,
          "state": {
            "usable": {
              "timestamp": "2021-03-01T19:24:00Z"
            }
          },
          "temporal_interval": {
            "start_inclusive": "2023-01-01T00:00:00Z",
            "end_exclusive": "2024-01-01T00:00:00Z"
          }
        }
      ]
    }
  ]
}
"""  # noqa: E501
