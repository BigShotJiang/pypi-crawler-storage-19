# Antch

End-to-end encrypted messaging client.

**Status: Demo / Pre-alpha**

This project is in early development. Expect breaking changes and incomplete features.

## Installation

```bash
pipx install .
```

Or for development:

```bash
pip install -e .
```

## Usage

### Client

```bash
antch
```

The client will open a launcher screen where you can create or select an account.

### Server

```bash
antch-server --host 0.0.0.0 --port 8765
```

Options:
- `--host` - Bind address (default: 0.0.0.0)
- `--port` - Port number (default: 8765)
- `--db` - Database file path (default: server.db)
- `--cert` - SSL certificate file (optional)
- `--key` - SSL key file (optional)

### Node (Distributed Storage)

```bash
antch-node
```

The node reads configuration from `~/.antch/node.conf`. See `node_config.example.conf` for format.

## Configuration

Client data is stored in:
- Linux/macOS: `~/.antch/`
- Windows: `%APPDATA%/antch/`

## Dependencies

- Python 3.10+
- SQLCipher (for encrypted database)
- See `requirements.txt` for full list

## License

GPL-3.0-or-later



## git
radicle repo: rad:z23mnPF8GfNnndXua4McwYNyEtRUW
```bash
rad auth && rad clone rad:z23mnPF8GfNnndXua4McwYNyEtRUW
```