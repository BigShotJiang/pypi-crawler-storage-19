from setuptools import setup, find_packages

setup(
    name="drevixhub",
    version="6.0.0",
    author="Drevix Dev",
    description="A mediator library for Drevix Bot System",
    long_description=open("README.md").read() if "README.md" in "".join(find_packages()) else "Drevix Bridge",
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=["requests"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)
