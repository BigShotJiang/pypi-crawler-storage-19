import requests
import time

class DrevixBot:
    def __init__(self, db_url, bot_token):
        """
        db_url: رابط قاعدة بياناتك (Firebase URL)
        bot_token: معرف البوت (مثل D0iiElKzhIVdrevixbot)
        """
        self.db_url = db_url.rstrip('/')
        self.bot_token = bot_token

    def send_reply(self, user_id, message, owner_token):
        """
        إرسال الرد من المطور إلى شات التطبيق
        """
        msg_id = f"msg_bot_{int(time.time()*1000)}"
        url = f"{self.db_url}/chat_rooms/{self.bot_token}/{user_id}/{msg_id}.json?auth={owner_token}"
        
        data = {
            "msg": message,
            "sender": "bot", # يظهر في جهة البوت داخل التطبيق
            "timestamp": int(time.time() * 1000),
            "type": "text",
            "status": "unread"
        }
        try:
            res = requests.put(url, json=data)
            return res.status_code == 200
        except:
            return False

    def start_listening(self, owner_token, callback):
        """
        مراقبة الرسائل الجديدة التي يرسلها المستخدمون
        """
        print(f"📡 Bridge active for bot: {self.bot_token}")
        last_processed_time = int(time.time() * 1000)
        
        while True:
            try:
                url = f"{self.db_url}/chat_rooms/{self.bot_token}.json?auth={owner_token}"
                res = requests.get(url)
                if res.status_code == 200 and res.json():
                    all_chats = res.json()
                    for user_id, messages in all_chats.items():
                        for m_id, m_data in messages.items():
                            # معالجة الرسائل التي أرسلها المستخدم فقط ولم يتم الرد عليها
                            m_time = int(m_data.get('timestamp', 0))
                            if m_data.get('sender') == 'user' and m_time > last_processed_time:
                                callback(user_id, m_data.get('msg'))
                                last_processed_time = m_time
            except Exception as e:
                print(f"⚠️ Connection error: {e}")
            
            time.sleep(2) # فحص كل ثانيتين لتقليل الضغط
