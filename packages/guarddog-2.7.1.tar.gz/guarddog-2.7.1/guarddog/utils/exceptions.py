class MissingEnvironmentVariable(Exception):
    pass
