# Assistant API router initialization
