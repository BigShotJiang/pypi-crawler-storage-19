# Chat module using langchain
