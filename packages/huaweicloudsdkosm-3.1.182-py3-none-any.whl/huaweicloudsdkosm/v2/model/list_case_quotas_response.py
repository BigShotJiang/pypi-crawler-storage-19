# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListCaseQuotasResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'total': 'int',
        'un_used': 'int'
    }

    attribute_map = {
        'total': 'total',
        'un_used': 'un_used'
    }

    def __init__(self, total=None, un_used=None):
        r"""ListCaseQuotasResponse

        The model defined in huaweicloud sdk

        :param total: 总配额
        :type total: int
        :param un_used: 未使用
        :type un_used: int
        """
        
        super().__init__()

        self._total = None
        self._un_used = None
        self.discriminator = None

        if total is not None:
            self.total = total
        if un_used is not None:
            self.un_used = un_used

    @property
    def total(self):
        r"""Gets the total of this ListCaseQuotasResponse.

        总配额

        :return: The total of this ListCaseQuotasResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListCaseQuotasResponse.

        总配额

        :param total: The total of this ListCaseQuotasResponse.
        :type total: int
        """
        self._total = total

    @property
    def un_used(self):
        r"""Gets the un_used of this ListCaseQuotasResponse.

        未使用

        :return: The un_used of this ListCaseQuotasResponse.
        :rtype: int
        """
        return self._un_used

    @un_used.setter
    def un_used(self, un_used):
        r"""Sets the un_used of this ListCaseQuotasResponse.

        未使用

        :param un_used: The un_used of this ListCaseQuotasResponse.
        :type un_used: int
        """
        self._un_used = un_used

    def to_dict(self):
        import warnings
        warnings.warn("ListCaseQuotasResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListCaseQuotasResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
