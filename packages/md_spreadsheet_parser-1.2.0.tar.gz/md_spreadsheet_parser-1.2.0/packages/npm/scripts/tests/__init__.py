# Tests for generator modules
