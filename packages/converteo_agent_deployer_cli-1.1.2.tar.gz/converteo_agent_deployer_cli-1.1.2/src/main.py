from __future__ import annotations

from pathlib import Path

import typer
import vertexai
from rich.progress import Progress, SpinnerColumn, TextColumn

from . import (
    FILE,
    LOCATION,
    MODULE,
    PROJECT_ID,
    ROOT_AGENT,
    STAGING_BUCKET,
)
from .utils import (
    _create_adk_app,
    _create_labels,
    _load_dependencies,
    _load_pyproject_dependencies,
    _parse_env_file,
)

# --- Typer App Initialization ---

app = typer.Typer(
    help="A CLI to intelligently create or update Vertex AI Agent Engines, mirroring `adk deploy` arguments.",
    add_completion=True,
)
# --- ADKUtils Command ---


@app.callback()
def init_agent(
    ctx: typer.Context,
    project_id: str = typer.Option(
        PROJECT_ID,
        "--project",
        help="Google Cloud project ID. Ensure you have set PROJECT_ID in your .env file.",
    ),
    location: str = typer.Option(
        LOCATION,
        "--location",
        help="Vertex AI region. Ensure you have set LOCATION in your .env file.",
    ),
    staging_bucket: str = typer.Option(
        STAGING_BUCKET,
        "--staging-bucket",
        help="GCS bucket for staging. Ensure you have set STAGING_BUCKET in your .env file.",
    ),
    module: str = typer.Option(
        MODULE,
        "--module",
        help="Module path to the agent definition. Ensure you have set MODULE in your .env file.",
    ),
    file: str = typer.Option(
        FILE,
        "--file",
        help="Attribute name of the agent in the module. Ensure you have set FILE in your .env file.",
    ),
    root_agent: str = typer.Option(
        ROOT_AGENT,
        "--root-agent",
        help="Attribute name of the root agent. Ensure you have set ROOT_AGENT in your .env file.",
    ),
) -> None:
    """Initialize the agent application and store shared client state."""
    if not project_id or not location:
        raise typer.BadParameter(
            "Project ID and location must be set. Please set them in your .env file."
        )

    if not module or not file or not root_agent:
        raise typer.BadParameter(
            "Module, file, and root agent must be set. Please set them in your .env file."
        )

    try:
        client = vertexai.Client(
            project=project_id,
            location=location,
        )
    except Exception as e:
        typer.secho(f"Error initializing agent application: {e}", fg=typer.colors.RED)
        raise

    ctx.ensure_object(dict)
    ctx.obj["agent_engines"] = client.agent_engines
    ctx.obj["project_id"] = project_id
    ctx.obj["location"] = location
    ctx.obj["staging_bucket"] = staging_bucket
    ctx.obj["app"] = _create_adk_app(project_id, location, module, file, root_agent)


@app.command(name="create")
def create_agent(
    ctx: typer.Context,
    display_name: str = typer.Option(..., "--display-name", help="Display name of the agent."),
    description: str = typer.Option(..., "--description", help="Description for the agent."),
    env_file: str | None = typer.Option(".env", "--env-file", help="Path to environment file."),
    requirements_file: str | None = typer.Option(
        "requirements.txt", "--requirements", help="Path to requirements file."
    ),
    extra_packages: list[str] | None = typer.Option(
        None, "--extra-package", help="Additional packages or wheels to include."
    ),
) -> None:
    """Create the agent as a Vertex AI remote app with build-time install scripts."""
    engines = ctx.obj.get("agent_engines") if ctx.obj else None
    if engines is None:
        raise typer.BadParameter(
            "Initialization missing. Run via the CLI so the callback executes."
        )

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            requirements = (
                _load_dependencies(Path(requirements_file), Path("pyproject.toml"))
                if requirements_file
                else _load_pyproject_dependencies(Path("pyproject.toml"))
            )
            env_vars = _parse_env_file(Path(env_file)) if env_file else {}
            progress.add_task(description="Deploying agent application to Vertex AI...", total=None)

            remote = engines.create(
                agent=ctx.obj.get("app"),
                config={
                    "staging_bucket": ctx.obj.get("staging_bucket"),
                    "requirements": requirements,
                    "display_name": display_name,
                    "description": description,
                    "extra_packages": extra_packages,
                    "env_vars": env_vars,
                    "labels": _create_labels(),
                },
            )

            resource_name = remote.api_resource.name
    except Exception as e:
        typer.secho(f"Error deploying agent application: {e}", fg=typer.colors.RED)
        raise

    typer.secho(f"Agent application deployed at: {resource_name}", fg=typer.colors.GREEN)


@app.command(name="list")
def list_agent(
    ctx: typer.Context,
    display_name: str | None = typer.Option(None, "--display-name", help="Filter by display name."),
) -> None:
    """List deployed agent applications."""
    engines = ctx.obj.get("agent_engines") if ctx.obj else None
    if engines is None:
        raise typer.BadParameter(
            "Initialization missing. Run via the CLI so the callback executes."
        )

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            progress.add_task(
                description="Listing agent applications from Vertex AI...", total=None
            )

            filter_expr = {"filter": f'display_name="{display_name}"'} if display_name else None
            apps = list(engines.list(config=filter_expr))

        if apps:
            typer.secho(f"Found {len(apps)} agent application(s):", fg=typer.colors.GREEN)
            for app in apps:
                typer.secho(
                    f" - {app.api_resource.display_name} ({app.api_resource.name})",
                    fg=typer.colors.GREEN,
                )
        if not apps:
            typer.secho("No agent applications found.", fg=typer.colors.YELLOW)

    except Exception as e:
        typer.secho(f"Error listing agent applications: {e}", fg=typer.colors.RED)
        raise


@app.command(name="update")
def update_agent(
    ctx: typer.Context,
    resource_name: str = typer.Argument(..., help="Resource name of the agent to update."),
    display_name: str = typer.Option(None, "--display-name", help="Display name of the agent."),
    description: str = typer.Option(None, "--description", help="Description for the agent."),
    env_file: str | None = typer.Option(".env", "--env-file", help="Path to environment file."),
    requirements_file: str | None = typer.Option(
        "requirements.txt", "--requirements", help="Path to requirements file."
    ),
    extra_packages: list[str] | None = typer.Option(
        None, "--extra-package", help="Additional packages or wheels to include."
    ),
) -> None:
    """Update the deployed agent application."""
    engines = ctx.obj.get("agent_engines") if ctx.obj else None
    if engines is None:
        raise typer.BadParameter(
            "Initialization missing. Run via the CLI so the callback executes."
        )

    if not resource_name:
        raise ValueError("Resource name is not set. Cannot update the agent application.")
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            requirements = (
                _load_dependencies(Path(requirements_file), Path("pyproject.toml"))
                if requirements_file
                else _load_pyproject_dependencies(Path("pyproject.toml"))
            )
            env_vars = _parse_env_file(Path(env_file)) if env_file else {}

            progress.add_task(description="Updating agent application on Vertex AI...", total=None)

            app = engines.update(
                name=resource_name,
                agent=ctx.obj.get("app"),
                config={
                    "staging_bucket": ctx.obj.get("staging_bucket"),
                    "requirements": requirements,
                    "display_name": display_name,
                    "description": description,
                    "extra_packages": extra_packages,
                    "env_vars": env_vars,
                    "labels": _create_labels(),
                },
            )

    except Exception as e:
        typer.secho(f"Error updating agent application: {e}", fg=typer.colors.RED)
        raise
    typer.secho("Agent application updated on Vertex AI.", fg=typer.colors.GREEN)
    return app


@app.command(name="delete")
def delete_agent(
    ctx: typer.Context,
    resource_name: str = typer.Argument(..., help="Resource name of the agent to delete."),
) -> None:
    """Delete the deployed agent application."""
    engines = ctx.obj.get("agent_engines") if ctx.obj else None
    if engines is None:
        raise typer.BadParameter(
            "Initialization missing. Run via the CLI so the callback executes."
        )

    if not resource_name:
        raise ValueError("Resource name is not set. Cannot delete the agent application.")
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            progress.add_task(
                description="Deleting agent application from Vertex AI...", total=None
            )
            engines.delete(
                name=resource_name,
                force=True,
            )
    except Exception as e:
        typer.secho(f"Error deleting agent application: {e}", fg=typer.colors.RED)
        raise
    typer.secho("Agent application deleted from Vertex AI.", fg=typer.colors.GREEN)


if __name__ == "__main__":
    app()
