import os

from dotenv import load_dotenv

load_dotenv()

DEPLOYMENT_TYPE = os.getenv("DEPLOYMENT_TYPE", "local")
DEPLOYMENT_VERSION = os.getenv("DEPLOYMENT_VERSION", "unknown")
PROJECT_ID = os.getenv("DEPLOYMENT_PROJECT_ID")
LOCATION = os.getenv("DEPLOYMENT_LOCATION")
STAGING_BUCKET = os.getenv("DEPLOYMENT_STAGING_BUCKET")
MODULE = os.getenv("DEPLOYMENT_MODULE")
FILE = os.getenv("DEPLOYMENT_FILE")
ROOT_AGENT = os.getenv("DEPLOYMENT_ROOT_AGENT")
