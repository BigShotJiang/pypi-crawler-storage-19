from __future__ import annotations

from importlib import import_module
from pathlib import Path

import tomllib
import typer
import vertexai
from vertexai.agent_engines import AdkApp

from . import DEPLOYMENT_TYPE, DEPLOYMENT_VERSION


def _create_adk_app(project: str, location: str, module: str, file: str, root_agent: str) -> AdkApp:
    """Create and return the ADK application wrapping the HubSpot agent."""
    vertexai.init(project=project, location=location)

    module = import_module(module)
    file = getattr(module, file)
    root_agent = getattr(file, root_agent)

    return AdkApp(
        agent=root_agent,
        enable_tracing=True,
    )


def _sanitize_label_key(key: str) -> str | None:
    """Normalize a label key to meet Vertex requirements."""
    if key is None:
        return None
    normalized = "".join(
        ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in str(key).strip().lower()
    )
    while normalized and not normalized[0].isalnum():
        normalized = normalized[1:]
    normalized = normalized[:63]
    return normalized or None


def _sanitize_label_value(value: str) -> str | None:
    """Normalize a label value to meet Vertex requirements."""
    if value is None:
        return None
    normalized = "".join(
        ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in str(value).strip().lower()
    )
    normalized = normalized[:63]
    return normalized or None


def _create_labels() -> dict[str, str]:
    """Return the fixed labels for deployments."""
    labels = {
        "deployment_type": DEPLOYMENT_TYPE,
        "deployment_version": DEPLOYMENT_VERSION,
    }
    sanitized: dict[str, str] = {}
    for key, value in labels.items():
        if value is None:
            continue
        safe_key = _sanitize_label_key(key)
        safe_value = _sanitize_label_value(str(value))
        if safe_key and safe_value:
            sanitized[safe_key] = safe_value
    return sanitized


def _parse_env_file(env_file: Path) -> dict[str, str]:
    """Parse environment variables from a .env file."""
    env_path = Path(env_file)
    if not env_path.exists():
        typer.secho(
            ".env file not found; continuing without loading environment variables.",
            fg=typer.colors.YELLOW,
        )
        return {}

    env_vars: dict[str, str | dict[str, str]] = {}
    vars_keys: list[str] = []
    secret_keys: list[str] = []

    with env_path.open() as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip()
                if key.startswith("SECRET_") and value:
                    env_vars[key[7:]] = {"secret": value, "version": "latest"}
                    secret_keys.append(key)
                elif key and value:
                    env_vars[key] = value
                    vars_keys.append(key)

        typer.secho(f"Environment variable set: {vars_keys}", fg=typer.colors.BRIGHT_BLACK)
        typer.secho(
            f"Secret environment variables set: {secret_keys}", fg=typer.colors.BRIGHT_BLACK
        )
    return env_vars


def _load_pyproject_dependencies(pyproject_file: Path) -> list[str]:
    """Read dependencies from pyproject.toml or return an empty list."""
    pyproject_path = Path(pyproject_file)
    if not pyproject_path.exists():
        return []

    try:
        with pyproject_path.open("rb") as f:
            pyproject = tomllib.load(f)
    except OSError as exc:
        typer.secho(
            f"Failed to read {pyproject_path}: {exc}; continuing without dependencies.",
            fg=typer.colors.YELLOW,
        )
        return []

    dependencies = pyproject.get("project", {}).get("dependencies", [])
    if not dependencies:
        typer.secho(
            f"No dependencies found in {pyproject_path}; continuing without dependencies.",
            fg=typer.colors.YELLOW,
        )
        return []

    typer.secho(
        f"Loaded dependencies from {pyproject_path}: {dependencies}",
        fg=typer.colors.BRIGHT_BLACK,
    )
    return list(dependencies)


def _load_requirements(requirements_file: Path) -> list[str]:
    """Read requirements.txt lines or return an empty list."""
    requirement_path = Path(requirements_file)
    if not requirement_path.exists():
        typer.secho(
            "requirements.txt not found; continuing without requirements.", fg=typer.colors.YELLOW
        )
        return []

    requirements: list[str] = []

    with requirement_path.open() as f:
        for line in f:
            line = line.strip()
            if line:
                requirements.append(line)

    typer.secho(f"Loaded requirements: {requirements}", fg=typer.colors.BRIGHT_BLACK)
    return requirements


def _load_dependencies(requirements_file: Path, pyproject_file: Path) -> list[str]:
    """Prefer pyproject.toml dependencies when present; otherwise use requirements.txt."""
    if pyproject_file.exists():
        return _load_pyproject_dependencies(pyproject_file)

    return _load_requirements(requirements_file)
