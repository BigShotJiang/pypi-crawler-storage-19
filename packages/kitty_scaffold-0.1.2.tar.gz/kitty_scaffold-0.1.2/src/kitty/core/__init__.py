"""Core utilities for Kitty."""
