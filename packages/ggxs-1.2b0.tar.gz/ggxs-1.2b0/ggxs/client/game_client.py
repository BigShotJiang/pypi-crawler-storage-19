import asyncio
import orjson
import random
import re
import inspect
from collections import deque
from typing import Any, Callable, Dict, List, Optional, Union, Awaitable, Deque

import aiohttp
from loguru import logger
from websockets.asyncio.client import connect, ClientConnection
from websockets.exceptions import ConnectionClosed, InvalidStatus, InvalidMessage

from ._cfg import *  

Handler = Callable[[Any], Union[Any, Awaitable[Any]]]
JobFn = Callable[..., Awaitable[Any]]






class GameClient:
    """
    Websocket engine for Goodgame Empire.
    """
    
    def __init__(
        self,
        url: str,
        server_header: str,
        username: str,
        password: str,
    ) -> None:
        
        
        ## login
        self.url = url
        self.server_header = server_header
        self.username = username
        self.password = password

        ## ws
        self.ws: Optional[ClientConnection] = None
        self.connected = asyncio.Event()
        self._tasks: List[asyncio.Task] = []
        self._stop_event = asyncio.Event()
        self._logged = asyncio.Event()

        ## ws data management
        self._pending_futures: Dict[str, Deque[asyncio.Future]] = {}
        self.user_agent = random.choice(DEFAULT_UA_LIST)

        # HTTP session
        self._http_session: Optional[aiohttp.ClientSession] = None
        
        ## jobs management
        self._job_registry: dict[str, JobFn] = {}
        self._job_tasks: Dict[str, asyncio.Task] = {}
        self._job_queue: asyncio.Queue[dict] = asyncio.Queue()
        

        
# ─────────────────────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────────────────────
    async def connect(self) -> None:
        """Connect the socket to ggs servers."""
        
        delay, max_delay = 5.0, 60.0
        max_retries = 3
        failures = 0
        
        while not self._stop_event.is_set():
            try:
                await self._run_connection_session()
                failures = 0
                delay = 5.0 
                
            except (ConnectionClosed, asyncio.CancelledError):
                self.connected.clear()
                if self._stop_event.is_set():
                    break
                
                failures += 1
                logger.warning(f"Session closed ({failures}/{max_retries})")
                  
            except Exception as e:
                logger.error(f"Error during connection session: {e}")
                self.connected.clear()
                if self._stop_event.is_set():
                    break
                failures += 1
                
            if failures >= max_retries:
                logger.error("Max retries reached. Shutting down client.")
                await self.shutdown()
                break
            
            
            if not self._stop_event.is_set():
                logger.info(f"Attempting to reconnect in {delay:.1f} seconds...")
                await asyncio.sleep(delay)
                delay = min(delay * 1.5, max_delay)
        logger.info("Client shutdown complete.")  
        
        
    async def shutdown(self) -> None:
        """
        Shutdown the ws engine.
        """
        self._stop_event.set()
        await self.disconnect()
        current_task = asyncio.current_task()
        tasks_to_cancel = [t for t in self._tasks if t is not current_task and not t.done()]
        
        for task in tasks_to_cancel:
            task.cancel()
            
        if tasks_to_cancel:
            await asyncio.gather(*tasks_to_cancel, return_exceptions=True)
        
        if self._http_session is not None:
            try:
                await self._http_session.close()
            except Exception:
                pass
            self._http_session = None


    async def disconnect(self) -> None:
        """
        Disconnect ws engine from game server.
        """
        self._logged.clear()
        self.connected.clear()
        self._cancel_pending_futures()
        if self.ws:
            try:
                await self.ws.close()
            except Exception as e:
                logger.error(f"Error closing connection: {e}")
            finally:
                self.ws = None
        logger.info("Disconnected!")
        
    # ─────────────────────────────────────────────────────────────
    # Session (WS handshake + tasks)
    # ─────────────────────────────────────────────────────────────

    async def _run_connection_session(self) -> None:
        """WS engine connection handler."""
        try:
            async with connect(
                self.url,
                origin=CLIENT_ORIGIN,
                user_agent_header=self.user_agent,
                additional_headers=WS_HEADERS,  
                compression=None,              
                max_size=8 * 1024 * 1024,
                open_timeout=20,
                close_timeout=10,
            ) as ws:
                self.ws = ws
                self.connected.set()
                logger.info(f"GGClient connected! {VERSION}")

                tasks = [
                    asyncio.create_task(self._listener(), name="listener"),
                    asyncio.create_task(self.keep_alive(), name="keep_alive"),
                    asyncio.create_task(self._nch(), name="nch"),
                ]

                if not await self._init():
                    await self._cancel_tasks(tasks)
                    await self.disconnect()
                    return
                
                tasks.append(asyncio.create_task(self._jobman_loop(), name="jobman"))
                tasks.append(asyncio.create_task(self.run_jobs(), name="run_jobs"))
                self._tasks = tasks

                try:
                    done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
                    for t in done:
                        if t.exception():
                            for p in pending:
                                if not p.done():
                                    p.cancel()
                            if pending:
                                await asyncio.gather(*pending, return_exceptions=True)
                            raise t.exception()
                except Exception as e:
                    logger.error(f"Task error: {e}")
                    await self._cancel_tasks(tasks)
                    raise
                finally:
                    for t in tasks:
                        if not t.done():
                            t.cancel()
                    await asyncio.gather(*tasks, return_exceptions=True)


        except (InvalidStatus, InvalidMessage) as e:
            logger.error(f"WS handshake failed: {e}")
            raise

    async def _cancel_tasks(self, tasks: List[asyncio.Task]) -> None:
        for task in tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)

    async def run_jobs(self):
        """Add your jobs here"""
        pass
    
    
    # ─────────────────────────────────────────────────────────────
    # Protocol helpers
    # ─────────────────────────────────────────────────────────────
    
    async def send(self, message: str) -> None:
        if not self.ws or not self.connected.is_set():
            raise RuntimeError("GGClient not connected!")
        await self.ws.send(message)
        
    async def send_message(self, parts: List[str]) -> None:
        msg = "%".join(["", *parts, ""])  
        await self.send(msg)

    async def send_raw_message(self, command: str, data: List[Any]) -> None:
        parts: List[str] = []
        for x in data:
            if isinstance(x, (dict, list)):
                parts.append(orjson.dumps(x).decode("utf-8"))
            else:
                parts.append(self._to_text(x))
        await self.send_message(["xt", self.server_header, command, "1", *parts])


    async def send_json_message(self, command: str, data: Dict[str, Any]) -> None:
        payload = orjson.dumps(data).decode("utf-8")
        await self.send_message(["xt", self.server_header, command, "1", payload])

    async def send_xml_message(self, t: str, action: str, r: str, data: str) -> None:
        await self.send(f"<msg t='{t}'><body action='{action}' r='{r}'>{data}</body></msg>")
    
    async def send_xt(self, command: str, r: int = 1) -> None:
        await self.send_message(["xt", self.server_header, command, str(r)])
    
    # ─────────────────────────────────────────────────────────────
    # WS IO
    # ─────────────────────────────────────────────────────────────
    
    async def _listener(self) -> None:
        try:
            async for raw in self.ws:
                if self._stop_event.is_set():
                    break
                text = raw.decode("utf-8", errors="ignore") if isinstance(raw, bytes) else raw
                msg = self._parse_message(text)
                await self._handle_message_callbacks(msg)
                
        except ConnectionClosed:
            self._cancel_pending_futures()
            self.connected.clear()
            return
            
        except asyncio.CancelledError:
            self._cancel_pending_futures()
            raise
            
        except Exception as e:
            self._cancel_pending_futures()
            logger.error(f"Unexpected error in listener: {e}")
            raise   
    
    def _cancel_pending_futures(self) -> None:
        for cmd, q in list(self._pending_futures.items()):
            while q:
                fut = q.popleft()
                if not fut.done():
                    fut.set_exception(ConnectionError("Connection lost"))
            self._pending_futures.pop(cmd, None)

    def _register_future(self, command: str) -> asyncio.Future:
        fut = asyncio.get_running_loop().create_future()
        q = self._pending_futures.setdefault(command, deque())
        q.append(fut)
        return fut
    
    
        
    def _parse_message(self, message: str) -> Dict[str, Any]:
        # XML path
        if message.startswith("<"):
            m = re.search(r"<msg t='(.*?)'><body action='(.*?)' r='(.*?)'>(.*?)</body></msg>", message)
            if not m:
                return {"type": "xml", "payload": {"t": None, "action": None, "r": None, "data": message}}
            t_val, action, r_val, data = m.groups()
            return {"type": "xml", "payload": {"t": t_val, "action": action, "r": int(r_val), "data": data}}

    
        # JSON path
        parts = message.strip("%").split("%")
        if len(parts) < 4:
            return {"type": "raw", "payload": {"command": None, "status": None, "data": message}}
        cmd = parts[1]
        try:
            status = int(parts[3])
        except ValueError:
            status = None
            
        error_code = None    
        data_start_index = 4
        if len(parts) > 4 and parts[4].isdigit():
            error_code = int(parts[4])
            data_start_index = 5
         
        raw = "%".join(parts[data_start_index:])
        try:
            data = orjson.loads(raw)
        except Exception:
            data = raw
        return {"type": "json", "payload": {"command": cmd, "status": status, "error_code": error_code, "data": data}}

    
    async def _handle_message_callbacks(self, msg: Dict[str, Any]) -> None:
        
        if not msg:
            return
        
        payload = msg.get("payload", {})
        cmd_raw = payload.get("command") or payload.get("action")
        cmd = str(cmd_raw).lower() if cmd_raw else None 
        
        if not cmd:
            return
        
        data = payload.get("data")
        status = payload.get("status")
        error_code = payload.get("error_code")
        
        if cmd in self._pending_futures and self._pending_futures[cmd]:
            if status is None or status != 1: ## de verificat conditia
                q = self._pending_futures[cmd]
                while q:
                    fut = q.popleft()
                    if not fut.done():
                        if error_code is not None:
                            fut.set_result({"error": error_code, "data": data})
                        
                        else:
                            fut.set_result(data)
                        break
                
                if not q:
                    del self._pending_futures[cmd]
                return

        method_name = f"on_{cmd}"
        if hasattr(self, method_name):
            handler: Handler = getattr(self, method_name)
            try:
                if inspect.iscoroutinefunction(handler):
                    asyncio.create_task(handler(data))
                else:
                    handler(data)
            except Exception as e:
                logger.error(f"Error in handler {method_name}: {e}")      
                    
    async def send_rpc(self, command: str, data: Dict[str, Any], timeout: float = 5.0) -> Any:

        fut = self._register_future(command)  
        await self.send_json_message(command, data)
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            q = self._pending_futures.get(command)
            if q and fut in q:
                try:
                    q.remove(fut)
                except ValueError:
                    pass
                if not q:
                    self._pending_futures.pop(command, None)
            if not fut.done():
                fut.cancel()
            raise

    async def send_crpc(self, command: str, data: Dict[str, Any], expect: str, timeout: float = 5.0) -> Any:
        fut = self._register_future(expect)
        await self.send_json_message(command, data)
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            q = self._pending_futures.get(expect)
            if q and fut in q:
                try:
                    q.remove(fut)
                except ValueError:
                    pass
                if not q:
                    self._pending_futures.pop(expect, None)
            if not fut.done():
                fut.cancel()
            logger.error(f"Timeout waiting for response '{expect}' after sending '{command}'")
            return False

    async def send_hrpc(self, command: str, data: Dict[str, Any], handler: Handler, timeout: float = 5.0) -> Any:
        fut = self._register_future(command)
        await self.send_json_message(command, data)
        resp_data = await asyncio.wait_for(fut, timeout)
        result = handler(resp_data)
        if inspect.isawaitable(result):
            await result
        return result           
                
    async def send_xt_rpc(
        self,
        command: str,
        expect: str | None = None,
        timeout: float = 5.0,
        r: int = 1
    ) -> Any:
        
        expect_cmd = (expect or command).lower()
        fut = self._register_future(expect_cmd)
        await self.send_xt(command, r)
        
        try:
            return await asyncio.wait_for(fut, timeout)
        
        except asyncio.TimeoutError:
            q = self._pending_futures.get(expect_cmd)
            if q and fut in q:
                try:
                    q.remove(fut)
                except ValueError:
                    pass
                if not q:
                    self._pending_futures.pop(expect_cmd, None)
            
            if not fut.done():
                fut.cancel()
            
            raise
         
# ─────────────────────────────────────────────────────────────
# Protocol specifics (WS): init + login on WS
# ─────────────────────────────────────────────────────────────

    async def _init(self) -> bool:
        """Init autologin process."""
        await self._init_socket()
        return await self.login(self.username, self.password)

    async def _init_socket(self) -> None:
        try:
            await self.send_xml_message("sys", "verChk", "0", "<ver v='166' />")
            await self.send_xml_message(
                "sys", "login", "0",
                f"<login z='{self.server_header}'><nick><![CDATA[]]></nick><pword><![CDATA[1123010%fr%0]]></pword></login>"
            )
            await self.send_xml_message("sys", "autoJoin", "-1", "")
            await self.send_xml_message("sys", "roundTrip", "1", "")
        except Exception as e:
            logger.error(f"Error during socket initialization: {e}")
            raise


    async def login(self, username: str, password: str) -> bool:
        
        if not self.connected.is_set():
            logger.error("Not connected yet!")
            return False
        
        while not self._stop_event.is_set():
            
            try:
                payload = {
                    "CONM": 175,
                    "RTM": 24,
                    "ID": 0,
                    "PL": 1,
                    "NOM": username,
                    "PW": password,
                    "LT": None,
                    "LANG": "fr",
                    "DID": "0",
                    "AID": "1674256959939529708",
                    "KID": "",
                    "REF": "https://empire.goodgamestudios.com",
                    "GCI": "",
                    "SID": 9,
                    "PLFID": 1,
                }
                resp = await self.send_rpc("lli", payload, timeout=5.0)

                
                if not isinstance(resp, dict):
                    logger.success("Login successful!")
                    self._logged.set()
                    return True
                if isinstance(resp, dict) and not resp:
                    logger.warning("Wrong username or password!")
                    return False
                if isinstance(resp, dict) and "CD" in resp:
                    cooldown_value = resp["CD"]
                    logger.debug(f"Connection locked by the server! Reconnect in {cooldown_value} sec!")
                    await asyncio.sleep(cooldown_value)
                    continue
                
                logger.info("Login successful!")
                self._logged.set()
                return True
            except asyncio.TimeoutError:
                logger.error("Login timeout - server not responding")
                return False
            except Exception as e:
                logger.error(f"Error during login: {e}")
                return False

    # ─────────────────────────────────────────────────────────────
    # Periodic tasks (special ping + nch)
    # ─────────────────────────────────────────────────────────────
    async def keep_alive(self, interval: int = 60) -> None:
        
        try:
            await self.connected.wait()
            while self.connected.is_set() and not self._stop_event.is_set():
                await asyncio.sleep(interval)
                try:
                    await self.send_raw_message("pin", ["<RoundHouseKick>"])
                except Exception as e:
                    logger.error(f"Error sending keep-alive: {e}")
                    break
        except asyncio.CancelledError:
            pass

    async def _nch(self, interval: int = 360) -> None:
        try:
            await self.connected.wait()
            while self.connected.is_set() and not self._stop_event.is_set():
                await asyncio.sleep(interval)
                try:
                    await self.send(f"%xt%{self.server_header}%nch%1%")
                except Exception as e:
                    logger.error(f"Error sending NCH: {e}")
                    break
        except asyncio.CancelledError:
            pass

# ─────────────────────────────────────────────────────────────
# HTTP helpers 
# ─────────────────────────────────────────────────────────────

    async def _get_http_session(self) -> aiohttp.ClientSession:
        if self._http_session is None or self._http_session.closed:
            self._http_session = aiohttp.ClientSession(
                auto_decompress=False,
                raise_for_status=False,
                headers=AD_HEADERS,
                )
        return self._http_session

    async def fetch_game_db(self) -> Dict[str, Any]:
        """Fetch all id data from Goodgame Empire"""
        session = await self._get_http_session()
        async with session.get(GAME_VERSION_URL) as resp:
            resp.raise_for_status()
            text = await resp.text()
            _, version = text.strip().split("=", 1)
            version = version.strip()
        db_url = f"https://empire-html5.goodgamestudios.com/default/items/items_v{version}.json"
        async with session.get(db_url) as db_resp:
            db_resp.raise_for_status()
            return await db_resp.json()


    # ─────────────────────────────────────────────────────────────
    # Live job manager methods
    # ─────────────────────────────────────────────────────────────
    
    def register_job(
        self,
        name: str,
        fn: JobFn
    ) -> None:
        """
        Register a job with job manager.

        Args:
            name (str): Name of your job.
            fn (JobFn): function/method for your job.
        """
        
        self._job_registry[name] = fn
        
    
    async def start_job(
        self,
        name: str,
        **kwargs
    ) -> None:
        """
        Start a long-running job with job manager.

        Args:
            name (str): Name of job.

        Raises:
            KeyError: if job is not registered.
        """
        
        if name not in self._job_registry:
            raise KeyError(f"Unknown job: {name}")
        
        task = self._job_tasks.get(name)
        if task and not task.done():
            return
        
        self._job_tasks[name] = asyncio.create_task(
            self._job_registry[name](self, **kwargs),
            name=f"job:{name}",
        )
        self._job_tasks[name] = task
        task.add_done_callback(lambda t: self._job_tasks.pop(name, None))
            
    async def stop_job(
        self,
        name: str
    ) -> None:
        """
        Stop a regitered jobs with job manager.

        Args:
            name (str): Name of job.
        """
        task = self._job_tasks.get(name)
        if not task or task.done():
            return
        task.cancel()
        try:
            await task
        
        except asyncio.CancelledError:
            pass
        
    async def run_once(
        self,
        name: str,
        **kwargs
    ) -> Any:
        """
        Run jobs one-shot.

        Args:
            name (str): Name of job.

        Raises:
            KeyError: For unknown job.
        """
        if name not in self._job_registry:
            raise KeyError(f"Unknown job: {name}")
        return await self._job_registry[name](self, **kwargs)
              
    async def push_job_cmd(
        self,
        cmd: Dict
    ) -> None:
        await self._job_queue.put(cmd)
    
    
    def _swallow_task_exec(self, t: asyncio.Task) -> None:
        try:
            _ = t.exception()
        
        except asyncio.CancelledError:
            pass
    
    
     
    async def _jobman_loop(self) -> None:
        
        try:
    
            while not self._stop_event.is_set():
                cmd = await self._job_queue.get()
                action = cmd.get("action")
                
                try:
                    
                    if action == "start":
                        await self.start_job(
                            cmd["job"],
                            **cmd.get("kwargs", {})
                        )
            
                    elif action == "stop":
                        await self.stop_job(cmd["job"])
                
                    elif action == "once":
                        await self.run_once(
                            cmd["job"],
                            **cmd.get("kwargs", {})
                        )
                        
                    elif action == "once_io":
                        t = asyncio.create_task(
                            self.run_once(cmd["job"], **cmd.get("kwargs", {})),
                            name=f"once:{cmd['job']}",
                        )
                        t.add_done_callback(self._swallow_task_exec)
                        
                except Exception as e:
                    logger.error(f"Error processing job command '{action}': {e}")
                    
                finally:
                    self._job_queue.task_done()   
                
                
        except asyncio.CancelledError:
            return 
        
        
