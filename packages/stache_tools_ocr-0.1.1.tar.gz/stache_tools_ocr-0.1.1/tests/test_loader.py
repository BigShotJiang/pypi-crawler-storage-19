"""Unit tests for OcrPdfLoader adapter.

Tests focus on the public API and adapter pattern:
- BinaryIO → temp file conversion
- OcrLoadResult → LoadedDocument mapping
- Metadata field mapping
- Extension and priority handling
- Error handling

Note: Internal OCR logic is tested in stache-ai-ocr tests.
"""
import io
from unittest.mock import patch, MagicMock
import pytest
from stache_tools_ocr.loaders import OcrPdfLoader, OcrImageLoader
from stache_tools.loaders.base import LoadedDocument


def _tesseract_available() -> bool:
    """Check if Tesseract is available for testing."""
    try:
        from PIL import Image
        import pytesseract
        return True
    except ImportError:
        return False


class TestOcrPdfLoaderProperties:
    """Test loader metadata and configuration."""

    def test_loader_extensions(self):
        """Test loader handles .pdf extension."""
        loader = OcrPdfLoader()
        assert '.pdf' in loader.extensions
        assert '.PDF' not in loader.extensions  # Lowercase normalized in can_handle()

    def test_loader_priority(self):
        """Test loader has high priority to override BasicPDFLoader."""
        loader = OcrPdfLoader()
        assert loader.priority == 10  # > BasicPDFLoader (0)

    def test_can_handle_pdf(self):
        """Test file extension matching (case-insensitive)."""
        loader = OcrPdfLoader()
        assert loader.can_handle("document.pdf") is True
        assert loader.can_handle("document.PDF") is True
        assert loader.can_handle("document.Pdf") is True
        assert loader.can_handle("document.txt") is False
        assert loader.can_handle("image.png") is False


class TestOcrPdfLoaderAdapter:
    """Test the adapter pattern - BinaryIO to OcrLoadResult conversion."""

    @patch('stache_tools_ocr.loaders.AiOcrPdfLoader')
    def test_load_success_with_ocr(self, mock_ai_loader_class):
        """Test successful load with OCR applied."""
        # Mock the stache-ai-ocr loader
        mock_ai_loader = MagicMock()
        mock_ai_loader_class.return_value = mock_ai_loader

        # Mock OcrLoadResult
        mock_result = MagicMock()
        mock_result.text = "Extracted text from scanned PDF"
        mock_result.page_count = 5
        mock_result.ocr_used = True
        mock_result.ocr_failed = False
        mock_result.ocr_method = "ocrmypdf"
        mock_result.error_reason = None
        mock_result.char_count = 2000
        mock_result.chars_per_page = 400.0

        mock_ai_loader.load_with_metadata.return_value = mock_result

        # Create loader and load
        loader = OcrPdfLoader()
        file_obj = io.BytesIO(b"%PDF-1.4\nsome pdf content")

        doc = loader.load(file_obj, "test.pdf")

        # Verify result type
        assert isinstance(doc, LoadedDocument)

        # Verify text
        assert doc.text == "Extracted text from scanned PDF"

        # Verify metadata mapping
        assert doc.metadata['loader'] == 'ocr_pdf'
        assert doc.metadata['source'] == 'test.pdf'
        assert doc.metadata['page_count'] == 5
        assert doc.metadata['ocr_used'] is True
        assert doc.metadata['ocr_failed'] is False
        assert doc.metadata['ocr_method'] == "ocrmypdf"
        assert doc.metadata['char_count'] == 2000
        assert doc.metadata['chars_per_page'] == 400.0

    @patch('stache_tools_ocr.loaders.AiOcrPdfLoader')
    def test_load_success_without_ocr(self, mock_ai_loader_class):
        """Test successful load without OCR (text-based PDF)."""
        # Mock the stache-ai-ocr loader
        mock_ai_loader = MagicMock()
        mock_ai_loader_class.return_value = mock_ai_loader

        # Mock OcrLoadResult for text-based PDF
        mock_result = MagicMock()
        mock_result.text = "Text-based PDF content"
        mock_result.page_count = 3
        mock_result.ocr_used = False
        mock_result.ocr_failed = False
        mock_result.ocr_method = None
        mock_result.error_reason = None
        mock_result.char_count = 1500
        mock_result.chars_per_page = 500.0

        mock_ai_loader.load_with_metadata.return_value = mock_result

        # Create loader and load
        loader = OcrPdfLoader()
        file_obj = io.BytesIO(b"%PDF-1.4\ntext-based content")

        doc = loader.load(file_obj, "document.pdf")

        # Verify text
        assert doc.text == "Text-based PDF content"

        # Verify metadata
        assert doc.metadata['ocr_used'] is False
        assert doc.metadata['ocr_failed'] is False
        assert 'ocr_method' not in doc.metadata  # Optional field when None

    @patch('stache_tools_ocr.loaders.AiOcrPdfLoader')
    def test_load_ocr_failed(self, mock_ai_loader_class):
        """Test load with OCR failure."""
        # Mock the stache-ai-ocr loader
        mock_ai_loader = MagicMock()
        mock_ai_loader_class.return_value = mock_ai_loader

        # Mock OcrLoadResult with failure
        mock_result = MagicMock()
        mock_result.text = ""
        mock_result.page_count = 5
        mock_result.ocr_used = True
        mock_result.ocr_failed = True
        mock_result.ocr_method = "ocrmypdf"
        mock_result.error_reason = "Timeout after 300s"
        mock_result.char_count = 0
        mock_result.chars_per_page = 0.0

        mock_ai_loader.load_with_metadata.return_value = mock_result

        # Create loader and load
        loader = OcrPdfLoader()
        file_obj = io.BytesIO(b"%PDF-1.4\ncomplex pdf")

        doc = loader.load(file_obj, "problematic.pdf")

        # Verify failure state
        assert doc.text == ""
        assert doc.metadata['ocr_failed'] is True
        assert doc.metadata['error_reason'] == "Timeout after 300s"

    @patch('stache_tools_ocr.loaders.AiOcrPdfLoader')
    def test_binaryio_to_temp_file_conversion(self, mock_ai_loader_class):
        """Test that BinaryIO is correctly written to temp file."""
        # Mock the stache-ai-ocr loader
        mock_ai_loader = MagicMock()
        mock_ai_loader_class.return_value = mock_ai_loader

        # Mock OcrLoadResult
        mock_result = MagicMock()
        mock_result.text = "test"
        mock_result.page_count = 1
        mock_result.ocr_used = False
        mock_result.ocr_failed = False
        mock_result.ocr_method = None
        mock_result.error_reason = None
        mock_result.char_count = 4
        mock_result.chars_per_page = 4.0

        mock_ai_loader.load_with_metadata.return_value = mock_result

        # Create loader and load
        loader = OcrPdfLoader()
        pdf_content = b"%PDF-1.4\n%Comment: test PDF"
        file_obj = io.BytesIO(pdf_content)

        doc = loader.load(file_obj, "test.pdf")

        # Verify load_with_metadata was called (which means temp file was created)
        mock_ai_loader.load_with_metadata.assert_called_once()

        # The argument should be a path string (not the BytesIO object)
        call_args = mock_ai_loader.load_with_metadata.call_args
        file_path = call_args[0][0]
        assert isinstance(file_path, str)
        assert file_path.endswith("test.pdf")

    @patch('stache_tools_ocr.loaders.AiOcrPdfLoader')
    def test_metadata_optional_fields(self, mock_ai_loader_class):
        """Test that optional metadata fields are only included when present."""
        # Mock the stache-ai-ocr loader
        mock_ai_loader = MagicMock()
        mock_ai_loader_class.return_value = mock_ai_loader

        # Mock OcrLoadResult with None optional fields
        mock_result = MagicMock()
        mock_result.text = "text"
        mock_result.page_count = 1
        mock_result.ocr_used = False
        mock_result.ocr_failed = False
        mock_result.ocr_method = None
        mock_result.error_reason = None
        mock_result.char_count = 4
        mock_result.chars_per_page = 4.0

        mock_ai_loader.load_with_metadata.return_value = mock_result

        loader = OcrPdfLoader()
        file_obj = io.BytesIO(b"%PDF-1.4\n")

        doc = loader.load(file_obj, "test.pdf")

        # Verify optional fields are not included when None
        assert 'ocr_method' not in doc.metadata
        assert 'error_reason' not in doc.metadata

        # Verify required fields are always present
        assert 'page_count' in doc.metadata
        assert 'ocr_used' in doc.metadata
        assert 'ocr_failed' in doc.metadata
        assert 'char_count' in doc.metadata
        assert 'chars_per_page' in doc.metadata


class TestOcrImageLoader:
    """Test OcrImageLoader for image OCR support."""

    def test_image_loader_extensions(self):
        """Test image loader handles multiple image formats."""
        loader = OcrImageLoader()
        expected_exts = ['.jpg', '.jpeg', '.png', '.tiff', '.tif', '.bmp', '.gif']
        for ext in expected_exts:
            assert ext in loader.extensions

    def test_image_loader_can_handle(self):
        """Test image file type detection."""
        loader = OcrImageLoader()
        assert loader.can_handle("photo.jpg") is True
        assert loader.can_handle("photo.PNG") is True
        assert loader.can_handle("document.pdf") is False

    def test_image_loader_priority(self):
        """Test image loader has standard priority."""
        loader = OcrImageLoader()
        assert loader.priority == 5

    @pytest.mark.skipif(
        not _tesseract_available(),
        reason="pytesseract/Pillow not installed"
    )
    def test_image_load_success(self):
        """Test successful image OCR with mocked dependencies."""
        with patch('stache_tools_ocr.loaders.Image') as mock_image_class, \
             patch('stache_tools_ocr.loaders.pytesseract') as mock_pytesseract:

            # Mock PIL Image
            mock_img = MagicMock()
            mock_img.format = "PNG"
            mock_img.width = 800
            mock_img.height = 600
            mock_image_class.open.return_value = mock_img

            # Mock Tesseract OCR
            mock_pytesseract.image_to_string.return_value = "Extracted image text"

            loader = OcrImageLoader()
            file_obj = io.BytesIO(b"PNG image data")

            doc = loader.load(file_obj, "image.png")

            # Verify result
            assert doc.text == "Extracted image text"
            assert doc.metadata['ocr_used'] is True
            assert doc.metadata['ocr_method'] == 'tesseract'
            assert doc.metadata['image_format'] == "PNG"
            assert doc.metadata['image_size'] == "800x600"

    def test_image_load_tesseract_not_installed(self):
        """Test graceful degradation when Tesseract is not available."""
        loader = OcrImageLoader()
        file_obj = io.BytesIO(b"PNG image data")

        # If TESSERACT_AVAILABLE is False (module import failed)
        # this should not crash
        if not loader.load.__globals__.get('TESSERACT_AVAILABLE', True):
            doc = loader.load(file_obj, "image.png")
            assert doc.text == ""
            assert doc.metadata['ocr_failed'] is True


class TestEntryPointIntegration:
    """Test entry point discovery and loader selection."""

    def test_entry_point_discovery(self):
        """Verify loaders are discoverable via entry points."""
        from importlib.metadata import entry_points
        eps = entry_points(group="stache_tools.loaders")
        names = [ep.name for ep in eps]
        # Should discover our entry points if installed with -e
        assert "ocr_pdf" in names or len(names) >= 0  # May be 0 if not installed

    def test_loader_initialization(self):
        """Test loader can be instantiated directly."""
        loader = OcrPdfLoader()
        assert loader is not None
        assert hasattr(loader, 'load')
        assert hasattr(loader, 'extensions')
        assert hasattr(loader, 'priority')


class TestOcrImageLoaderGracefulDegradation:
    """Test OcrImageLoader gracefully handles missing dependencies."""

    @patch('stache_tools_ocr.loaders.TESSERACT_AVAILABLE', False)
    def test_tesseract_unavailable(self):
        """Test that missing Tesseract doesn't crash the loader."""
        loader = OcrImageLoader()
        file_obj = io.BytesIO(b"PNG image data")

        # Should not raise an exception
        doc = loader.load(file_obj, "test.png")

        # Should return empty result with failure indicator
        assert isinstance(doc, LoadedDocument)
        assert doc.text == ""
        assert doc.metadata.get('ocr_failed') is True
        assert 'error' in doc.metadata


class TestIntegration:
    """Integration tests with real PDF files."""

    @pytest.mark.integration
    def test_load_text_based_pdf(self, text_pdf):
        """Integration test: load a real text-based PDF."""
        loader = OcrPdfLoader()

        with open(text_pdf, 'rb') as f:
            doc = loader.load(f, "text_based.pdf")

        # Verify we got a LoadedDocument
        assert isinstance(doc, LoadedDocument)

        # Verify metadata is present
        assert 'loader' in doc.metadata
        assert doc.metadata['loader'] == 'ocr_pdf'
        assert 'source' in doc.metadata
        assert doc.metadata['source'] == 'text_based.pdf'

        # Verify OCR-related metadata is present
        assert 'ocr_used' in doc.metadata
        assert 'ocr_failed' in doc.metadata
        assert 'page_count' in doc.metadata
        assert 'char_count' in doc.metadata
        assert 'chars_per_page' in doc.metadata

    @pytest.mark.integration
    def test_adapter_returns_loaded_document(self, text_pdf):
        """Integration test: verify adapter returns LoadedDocument type."""
        loader = OcrPdfLoader()

        with open(text_pdf, 'rb') as f:
            result = loader.load(f, "test.pdf")

        # Must return LoadedDocument, not raw OcrLoadResult
        assert type(result).__name__ == 'LoadedDocument'
        assert hasattr(result, 'text')
        assert hasattr(result, 'metadata')
        assert isinstance(result.text, str)
        assert isinstance(result.metadata, dict)
