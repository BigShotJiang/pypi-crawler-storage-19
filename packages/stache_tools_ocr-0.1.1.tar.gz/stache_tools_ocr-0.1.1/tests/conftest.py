import sys
from pathlib import Path

import pytest

# Add src directory to path for running tests without installation
src_path = Path(__file__).parent.parent / "src"
if src_path.exists():
    sys.path.insert(0, str(src_path))


@pytest.fixture
def fixtures_dir():
    return Path(__file__).parent / "fixtures"


@pytest.fixture
def text_pdf(fixtures_dir):
    """Text-based PDF (should NOT trigger OCR)."""
    path = fixtures_dir / "text_based.pdf"
    if not path.exists():
        pytest.skip("Test fixture text_based.pdf not found")
    return path


@pytest.fixture
def scanned_pdf(fixtures_dir):
    """Scanned PDF (should trigger OCR)."""
    path = fixtures_dir / "scanned.pdf"
    if not path.exists():
        pytest.skip("Test fixture scanned.pdf not found")
    return path
