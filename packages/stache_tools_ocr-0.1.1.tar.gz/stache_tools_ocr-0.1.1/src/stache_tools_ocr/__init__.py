"""OCR support for stache-tools CLI using Tesseract/ocrmypdf."""
__version__ = "0.1.1"
