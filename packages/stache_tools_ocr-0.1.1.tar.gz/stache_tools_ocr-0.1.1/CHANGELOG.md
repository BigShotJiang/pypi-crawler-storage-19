# Changelog

## [0.1.1] - 2026-01-11

### Changed
- **Architecture Refactor**: Now wraps stache-ai-ocr>=0.1.1 as a thin adapter pattern
- User-facing API unchanged (fully backward compatible)
- Installation simplified: `pip install stache-tools-ocr` now includes all dependencies automatically

### Added
- Metadata enrichment: `char_count`, `chars_per_page`, `ocr_method` fields in results
- Support for OCR failure states with `error_reason` metadata field
- Graceful degradation when OCR fails (returns partial text with error metadata)

### Removed
- Internal OCR implementation (now delegated to stache-ai-ocr for better maintenance)
- Direct dependencies on pdfplumber, pypdf (pulled transitively via stache-ai-ocr)

### Fixed
- Improved OCR detection heuristic (now uses >50 chars/page threshold via stache-ai-ocr)
- Better timeout handling (configurable via STACHE_OCR_TIMEOUT environment variable)
- Enhanced error messages for missing system dependencies

### Testing
- Updated 17 tests to work with new adapter pattern
- All tests passing
- Better coverage of error scenarios and metadata enrichment

## [0.1.0] - 2026-01-10

### Added
- Initial release
- OCR support via Tesseract/ocrmypdf
- Smart detection (only OCR when needed)
- Graceful fallback on missing binary
- Thread-safe parallel processing

### Fixed
- (PE Review) Return empty text on OCR failure to prevent silent data loss
- (PE Review) Use TemporaryDirectory for robust cleanup
- (PE Review) Explicit shell=False for security

### Testing
- 12 unit tests with >90% coverage
- Entry point discovery tests
- Priority override tests
- Integration test for real OCR
