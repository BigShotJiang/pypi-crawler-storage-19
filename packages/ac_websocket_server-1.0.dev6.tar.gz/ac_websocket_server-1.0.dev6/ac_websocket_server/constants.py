'''Constants for AC websocket proof of concept.'''

VERSION = '1.0-dev6'
PROTOCOL = '0.7dev4'
PROG = 'ac_websocket_server'
PORT = 7890
HOST = 'localhost'
