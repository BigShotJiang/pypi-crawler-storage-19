from ajet.task_judge.base_judge import BaseJudge
from ajet.workflow import WorkflowOutput, WorkflowTask


class EnvServiceJudge(BaseJudge):
    def __init__(self, config):
        self.config = config

    def compute_reward(self, workflow_task: WorkflowTask, workflow_output: WorkflowOutput) -> tuple:
        raw_reward = 0

        env = workflow_task.gym_env
        raw_reward = env.evaluate(workflow_task.episode_uuid, params={"sparse": False})
        if raw_reward >= 1:
            is_success = True
        else:
            is_success = False

        if is_success:
            raw_reward = 1.0 + raw_reward * 0.5
        else:
            raw_reward = 0.0 + raw_reward * 0.5

        return raw_reward, is_success
