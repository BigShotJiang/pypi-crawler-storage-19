from typing import TYPE_CHECKING, Any, Literal, Type

from agentscope._utils._common import _create_tool_from_base_model
from agentscope.model import ChatModelBase, ChatResponse, DashScopeChatModel
from loguru import logger
from pydantic import BaseModel

from ajet.context_tracker.multiagent_tracking import (
    MultiAgentContextTracker,
)
from ajet.task_rollout.async_llm_bridge import AgentScopeLlmProxyWithTracker

if TYPE_CHECKING:
    from ajet import Workflow


class AgentScopeModelTuner(DashScopeChatModel):
    """
    ModelTuner for Agentscope workflow.
    It keeps record of all registered agent types (by their target names),
    And when request comes, it calls `self.llm_proxy` to handle the request.
    """

    def __init__(
        self,
        config,
        context_tracker: MultiAgentContextTracker,
        user_workflow: "Workflow",
        agent_name: str,
        debug_model: DashScopeChatModel | None,
        use_debug_model: bool = False,
        llm_inference_fn=None,
    ) -> None:
        self.config = config
        self.context_tracker = context_tracker
        self.user_workflow = user_workflow

        self.agent_name = agent_name
        self.debug_model = debug_model
        self.use_debug_model = use_debug_model
        self.llm_proxy = AgentScopeLlmProxyWithTracker(
            context_tracker=context_tracker, config=config, llm_inference_fn=llm_inference_fn
        )
        super().__init__(
            model_name="ajet",
            api_key="dummy-api-key",
            stream=False,
        )


    async def __call__(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict] | None = None,
        tool_choice: Literal["auto", "none", "any", "required"] | str | None = None,
        structured_model: Type[BaseModel] | None = None,
        **kwargs: Any,
    ) -> ChatResponse:

        # route first
        if self.use_debug_model and self.debug_model is not None:
            chatresponse = await self.debug_model(messages, tools, tool_choice, structured_model, **kwargs)
            assert isinstance(chatresponse, ChatResponse)
            return chatresponse


        # For qvq and qwen-vl models, the content field cannot be `None` or
        # `[{"text": None}]`, so we need to convert it to an empty list.
        if self.model_name.startswith("qvq") or "-vl" in self.model_name:
            raise NotImplementedError("Not implemented for qvq and qwen-vl models yet.")

        kwargs = {
            "messages": messages,
            "model": self.model_name,
            "stream": self.stream,
            **self.generate_kwargs,
            **kwargs,
            "result_format": "message",
            # In agentscope, the `incremental_output` must be `True` when
            # `self.stream` is True
            "incremental_output": self.stream,
        }

        if tools:
            kwargs["tools"] = self._format_tools_json_schemas(tools)

        if tool_choice:
            self._validate_tool_choice(tool_choice, tools)
            kwargs["tool_choice"] = self._format_tool_choice(tool_choice)

        if self.enable_thinking is not None and "enable_thinking" not in kwargs:
            kwargs["enable_thinking"] = self.enable_thinking

        if structured_model:
            if tools or tool_choice:
                logger.warning(
                    "structured_model is provided. Both 'tools' and "
                    "'tool_choice' parameters will be overridden and "
                    "ignored. The model will only perform structured output "
                    "generation without calling any other tools.",
                )
            format_tool = _create_tool_from_base_model(structured_model)
            kwargs["tools"] = self._format_tools_json_schemas(
                [format_tool],
            )
            kwargs["tool_choice"] = self._format_tool_choice(
                format_tool["function"]["name"],
            )

        # call llm model ✨
        response_gen = await self.llm_proxy(
            api_key=self.api_key,
            structured_model=structured_model,
            **kwargs,
        )

        # Return the AsyncGenerator directly
        return response_gen
