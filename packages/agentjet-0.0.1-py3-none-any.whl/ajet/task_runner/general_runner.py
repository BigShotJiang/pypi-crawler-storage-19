import asyncio

from ajet import AjetTuner
from ajet import Workflow, WorkflowOutput
from ajet.context_tracker.multiagent_tracking import (
    MultiAgentContextTracker,
)
from ajet.context_tracker.basic_tracker import BaseContextTracker
from ajet.schema.task import WorkflowTask
from ajet.schema.trajectory import Reward
from ajet.task_runner.base_runner import BaseAgentRunner
from ajet.utils.dynamic_import import dynamic_import


class GeneralRunner(BaseAgentRunner):
    def execute(self, workflow_task: WorkflowTask) -> BaseContextTracker:
        observation_window = workflow_task.observation_window
        task_thread_index = workflow_task.task_thread_index
        task_batch_index = workflow_task.task_batch_index
        task_tag = workflow_task.task_tag
        task_id = workflow_task.task_id

        workflow_import = self.config.ajet.rollout.user_workflow
        workflow_cls = dynamic_import(workflow_import)
        user_workflow: Workflow = workflow_cls(name="ajet-trinity")

        hooks = self.runner_hooks(
            observation_window=observation_window,
            task_thread_index=task_thread_index,
            workflow_task=workflow_task,
        )
        context_tracker = MultiAgentContextTracker(
            llm_inference_fn=self.llm_inference_fn,
            tokenizer=self.tokenizer,
            config=self.config,
            task_batch_index=task_batch_index,
            task_tag=task_tag,
            task_id=task_id,
            episode_uuid=workflow_task.episode_uuid,
            **hooks,
        )
        tuner = AjetTuner(
            context_tracker=context_tracker,
            llm_inference_fn=self.llm_inference_fn,
            user_workflow=user_workflow,
            config=self.config,
        )

        workflow_output: WorkflowOutput = asyncio.run(
            user_workflow.execute(workflow_task, tuner)
        )
        if workflow_output.reward is not None:
            raw_reward, is_success = (
                workflow_output.reward,
                workflow_output.is_success,
            )
        else:
            raw_reward, is_success = self.get_judge().compute_reward(workflow_task, workflow_output)
        workflow_task.gym_env = None  # clear gym env client reference to avoid serialization issue

        assert not isinstance(
            raw_reward, list
        ), "AgentJet will support step reward in future versions."

        # register reward
        # TODO: support multi-step reward
        reward = Reward(
            raw_reward=raw_reward,
            raw_step_reward=None,  # "AgentJet will support step reward in future versions."
            success_rate=1.0 if is_success else 0.0,
            madness=0,
            description="",
        )
        context_tracker.process_reward(reward)
        # generate token before merging
        context_tracker.task_id = task_id
        context_tracker.task_tag = task_tag
        context_tracker.group_merge()
        # after merging, process and align reward again
        context_tracker.process_reward(reward)
        # mark the thread as ended
        observation_window["step"][task_thread_index] = -1
        tuner.terminate_episode()
        return context_tracker
