"""Package for query module."""
