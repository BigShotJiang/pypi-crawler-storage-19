# Copyright 2014-2016 Numérigraphe SARL
# Copyright 2017 ForgeFlow, S.L.
# Copyright 2021 Jacques-Etienne Baudoux (BCIM) <je@bcim.be>
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

{
    "name": "Purchase Delivery Split Date",
    "version": "18.0.2.0.3",
    "summary": "Allows Purchase Order you confirm to generate one Incoming "
    "Shipment for each expected date indicated in the Purchase Order Lines",
    "author": (
        "Numerigraphe, ForgeFlow, Camptocamp, BCIM, Odoo Community Association (OCA)"
    ),
    "website": "https://github.com/OCA/purchase-workflow",
    "category": "Purchase Management",
    "license": "AGPL-3",
    "depends": ["purchase_stock"],
    "installable": True,
    "application": False,
}
