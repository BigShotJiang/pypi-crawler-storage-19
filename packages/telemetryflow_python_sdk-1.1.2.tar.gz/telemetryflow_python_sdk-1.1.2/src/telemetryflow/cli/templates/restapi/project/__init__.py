"""Project templates."""
