"""TelemetryFlow CLI Templates."""
