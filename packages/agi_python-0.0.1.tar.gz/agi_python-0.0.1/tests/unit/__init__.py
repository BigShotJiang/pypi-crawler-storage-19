"""Unit tests for agi."""
