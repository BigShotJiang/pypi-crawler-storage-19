"""Tests for agi SDK."""
