"""Integration tests for agi."""
