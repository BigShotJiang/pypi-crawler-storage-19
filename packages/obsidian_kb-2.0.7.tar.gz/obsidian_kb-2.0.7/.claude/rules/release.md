# Правила выпуска релизов

## Процедура выпуска релиза

**ОБЯЗАТЕЛЬНО:** После каждой завершённой фазы разработки выполнять процедуру релиза:

### 1. Проверка и обновление документации

```bash
# Проверить актуальность
- README.md (features, installation, usage)
- CHANGELOG.md (добавить изменения)
- DATABASE_SCHEMA.md (если схема менялась)
- docs/SEARCH_ARCHITECTURE.md (если архитектура менялась)
```

### 2. Обновление версии

**Файлы для обновления:**
- `pyproject.toml` — поле `version`
- `src/obsidian_kb/__init__.py` — `__version__`

**Формат версии:** Semantic Versioning (MAJOR.MINOR.PATCH)
- MAJOR: breaking changes
- MINOR: новые фичи (backward compatible)
- PATCH: bug fixes

### 3. Запуск тестов

```bash
.venv/bin/pytest tests/ -x -q
```

**Все тесты должны проходить перед релизом!**

### 4. Коммит изменений

```bash
git add -A
git commit -m "release: v{VERSION}

Changes:
- [список изменений]

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

### 5. Создание тега

```bash
git tag -a v{VERSION} -m "Release v{VERSION}"
```

### 6. Публикация на GitHub

```bash
git push origin main
git push origin v{VERSION}
```

### 7. Публикация на PyPI

```bash
# Сборка
.venv/bin/python -m build

# Публикация (требует TWINE_USERNAME и TWINE_PASSWORD)
.venv/bin/python -m twine upload dist/*
```

---

## Важные моменты для разработки

### Обратная совместимость

- **Данные:** НЕ требуется сохранять совместимость на уровне данных
- **API:** Внутренние контракты можно менять вместе со связанной логикой
- **MCP tools:** Сохранять совместимость для пользователей

### Контрольные точки

После каждой фазы проверять:
- [ ] Все тесты проходят
- [ ] Документация актуальна
- [ ] Версия обновлена
- [ ] CHANGELOG дополнен
- [ ] Коммит создан с правильным сообщением

### Текущий roadmap

См. `ROADMAP_v2_REVISED.md` для актуального плана разработки.
