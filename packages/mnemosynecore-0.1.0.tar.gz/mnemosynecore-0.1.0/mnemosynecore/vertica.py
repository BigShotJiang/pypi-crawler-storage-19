from sqlalchemy import create_engine
from .vault import get_secret


def vertica_engine(
    *,
    login: str | None = None,
    password: str | None = None,
    host: str = "localhost",
    port: int = 5433,
    database: str | None = None,
    vault_conn_id: str | None = None,
):
    """
    Создание SQLAlchemy engine для Vertica.

    Можно:
    - напрямую передать логин/пароль
    - или взять всё из Vault
    """

    if vault_conn_id:
        cfg = get_secret(vault_conn_id)
        login = cfg["login"]
        password = cfg["password"]
        host = cfg["host"]
        port = int(cfg["port"])
        database = cfg["schema"]

    if not all([login, password, database]):
        raise ValueError("Не хватает параметров для подключения к Vertica")

    url = (
        f"vertica+vertica_python://{login}:{password}"
        f"@{host}:{port}/{database}"
    )

    return create_engine(url, pool_pre_ping=True)