import json
from modules.get_connection import get_connection_as_json


def get_secret(conn_id: str) -> dict:
    raw = get_connection_as_json(conn_id)
    return json.loads(raw)
