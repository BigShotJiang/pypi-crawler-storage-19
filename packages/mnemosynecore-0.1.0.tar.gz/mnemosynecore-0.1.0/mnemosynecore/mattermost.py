import logging
from mattermostdriver import Driver
from .vault import get_secret


def send_message(
    *,
    channel_id: str,
    message: str,
    vault_conn_id: str
):

    cfg = get_secret(vault_conn_id)

    driver = Driver({
        "url": cfg["host"],
        "token": cfg["password"],
        "scheme": cfg.get("schema", "https"),
        "port": int(cfg.get("port", 443)),
        "basepath": "/api/v4",
    })

    driver.login()

    try:
        driver.posts.create_post({
            "channel_id": channel_id,
            "message": message
        })
    except Exception as e:
        logging.error(f"Mattermost error: {e}")
