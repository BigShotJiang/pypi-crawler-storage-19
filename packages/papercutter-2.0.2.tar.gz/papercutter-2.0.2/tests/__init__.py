"""Tests for Papercutter."""
