"""Unit tests for Papercutter."""
