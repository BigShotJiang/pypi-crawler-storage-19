# mcp-server-stock-hedge

一个基于 **Model Context Protocol (MCP)** 的金融量化工具包，专门用于计算 **Black-Scholes-Merton (BSM)** 模型下的期权 Delta 及其对应的股票与期货对冲配比。

---

## 🌟 功能特性

* **BSM 定价引擎**：精确计算欧式期权的理论 Delta 值。
* **对冲比例建议**：直接输出为实现 Delta 中性所需的标的资产（股票或期货）操作数量。
* **灵活参数**：支持自定义执行价、到期时间、波动率、无风险利率及合约乘数。
* **AI 友好**：深度优化了工具描述，方便大模型（如 Claude, GPT）进行函数调用（Tool Calling）。

---

## 🛠 技术原理

工具核心使用 BSM 模型计算 Delta ($\Delta$)：

$$d_1 = \frac{\ln(S/K) + (r + \sigma^2/2)T}{\sigma\sqrt{T}}$$

对于看涨期权（Call）：
$$\Delta = N(d_1)$$

对于看跌期权（Put）：
$$\Delta = N(d_1) - 1$$

对冲比例依据 $\Delta$ 与合约乘数（Contract Size）动态生成。

---

## 🚀 安装与准备

本工具推荐使用 [uv](https://astral.sh/uv) 进行管理。

### 1. 环境要求
* Python 3.10+
* 安装 `uv`:
    ```bash
    curl -LsSf [https://astral.sh/uv/install.sh](https://astral.sh/uv/install.sh) | sh
    ```

### 2. 本地测试
在发布到 PyPI 前，你可以在本地运行以下命令验证：
```bash
uvx --from . mcp-server-stock-hedge