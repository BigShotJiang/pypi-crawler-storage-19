# src/mcp_server_stock_hedge/server.py
import numpy as np
from scipy.stats import norm
from mcp.server.fastmcp import FastMCP

# 初始化 MCP 服务
mcp = FastMCP("StockHedge")

def bsm_delta(S, K, T, r, sigma, option_type="call"):
    d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    if option_type.lower() == "call":
        return norm.cdf(d1)
    else:
        return norm.cdf(d1) - 1

@mcp.tool()
def calculate_hedge_ratio(S: float, K: float, T_days: float, r: float, sigma: float, 
                           option_type: str = "call", contract_size: int = 100):
    """
    计算 BSM Delta 及其对应的股票对冲配比。
    T_days: 距离到期天数
    contract_size: 每手期权对应的标的资产数量（默认100）
    """
    T = T_days / 365.0
    delta = bsm_delta(S, K, T, r, sigma, option_type)
    
    # 计算对冲 1 手期权所需的股票数量
    stock_shares = -delta * contract_size
    
    return {
        "delta": round(delta, 4),
        "shares_to_hedge_per_contract": round(stock_shares, 2),
        "instruction": f"为实现 Delta 中性，每持有 1 手期权，请操作 {abs(round(stock_shares, 2))} 股标的股票。"
    }

if __name__ == "__main__":
    mcp.run()