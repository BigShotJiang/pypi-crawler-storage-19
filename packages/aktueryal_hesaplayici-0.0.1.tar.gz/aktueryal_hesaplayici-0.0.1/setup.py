from setuptools import setup, find_packages

setup(
    name="aktueryal_hesaplayici_ebru", # Benzersiz bir isim seçtik
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy",
        "openpyxl",
    ],
    author="Ebru Kayran",
    description="Aktueryal mortalite ve sigorta hesaplayici",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.7",
)
