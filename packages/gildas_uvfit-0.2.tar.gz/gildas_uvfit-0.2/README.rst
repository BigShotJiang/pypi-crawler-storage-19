Helper function to read IRAM GILDAS uvfit fits file
---------------------------------------------------

gildas_uvfit is a set of helper function to read uv-fit files procuded 
by `GILDAS MAPPING/uv_fit task <https://www.iram.fr/IRAMFR/GILDAS/doc/html/map-html/node90.html>`_ 
exported to the fits format by using the `GILDAS CLIC/fits <https://www.iram.fr/IRAMFR/GILDAS/doc/html/clic-html/node103.html>`_ command

.. code-block:: console

    fits "blah.fits" from "blah.uvfit" /style standard /overwrite /bits -32

Then you can access the fitted values as astropy Table using python with


.. code-block:: python
    
    from astropy.table import Table
    import gildas_uvfit

    data = Table.read('data.fits', format='gildas_uvfit')


If you fixed the position and size of the source in the `GILDAS MAPPING/uv_fit task <https://www.iram.fr/IRAMFR/GILDAS/doc/html/map-html/node90.html>`_ 
then you can use `specutils.Spectrum1D <https://specutils.readthedocs.io/en/stable/api/specutils.Spectrum1D.html>`_ object to read the data directly

.. code-block:: python
    
    from specutils import Spectrum1D
    from gildas_uvfit import specutils_custom_loader

    spec = Spectrum1D.read('data.fits')



License
-------

This project is Copyright (c) Alexandre Beelen and licensed under
the terms of the BSD 3-Clause license. This package is based upon
the `Openastronomy packaging guide <https://github.com/OpenAstronomy/packaging-guide>`_
which is licensed under the BSD 3-clause licence. See the licenses folder for
more information.

Contributing
------------

We love contributions! gildas-uvfit is open source,
built on open source, and we'd love to have you hang out in our community.

**Imposter syndrome disclaimer**: We want your help. No, really.

There may be a little voice inside your head that is telling you that you're not
ready to be an open source contributor; that your skills aren't nearly good
enough to contribute. What could you possibly offer a project like this one?

We assure you - the little voice in your head is wrong. If you can write code at
all, you can contribute code to open source. Contributing to open source
projects is a fantastic way to advance one's coding skills. Writing perfect code
isn't the measure of a good developer (that would disqualify all of us!); it's
trying to create something, making mistakes, and learning from those
mistakes. That's how we all improve, and we are happy to help others learn.

Being an open source contributor doesn't just mean writing code, either. You can
help out by writing documentation, tests, or even giving feedback about the
project (and yes - that includes giving feedback about the contribution
process). Some of these contributions may be the most valuable to the project as
a whole, because you're coming to the project with fresh eyes, so you can see
the errors and assumptions that seasoned contributors have glossed over.

Note: This disclaimer was originally written by
`Adrienne Lowe <https://github.com/adriennefriend>`_ for a
`PyCon talk <https://www.youtube.com/watch?v=6Uj746j9Heo>`_, and was adapted by
gildas-uvfit based on its use in the README file for the
`MetPy project <https://github.com/Unidata/MetPy>`_.
