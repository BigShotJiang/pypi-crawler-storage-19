from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="pyipatool",
    version="1.0.0",
    author="pjp",
    author_email="pjp385334338@gmail.com",
    description="Apple App Store search and download tool",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/a55509432/ipatool",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "ipatool": ["data/*"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "requests",
        "click",
        "pyyaml",
    ],
    entry_points={
        "console_scripts": [
            "ipatool=main:cli",
        ],
    },
)