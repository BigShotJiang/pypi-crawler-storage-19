"""Version information"""
__version__ = "0.1.8.2"
