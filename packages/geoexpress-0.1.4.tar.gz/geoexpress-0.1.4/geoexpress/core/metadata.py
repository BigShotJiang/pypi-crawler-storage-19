from geoexpress.core.base import GeoExpressCommand

_meta = GeoExpressCommand("mrsidgeometa")


def set_metadata(image: str, key: str, value: str):
    return _meta.run([
        image,
        "-set", key, value
    ])


def get_metadata(image: str):
    return _meta.run([
        image,
        "-list"
    ])
