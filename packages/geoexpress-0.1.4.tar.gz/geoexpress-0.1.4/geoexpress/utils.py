import subprocess
from geoexpress.exceptions import GeoExpressCommandError


def run_cmd(cmd: list[str]) -> str:
    proc = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    if proc.returncode != 0:
        raise GeoExpressCommandError(proc.stderr.strip())

    return proc.stdout.strip()
