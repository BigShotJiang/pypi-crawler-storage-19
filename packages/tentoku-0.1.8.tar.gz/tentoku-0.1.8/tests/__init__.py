"""
Tests for tentoku module.
"""

