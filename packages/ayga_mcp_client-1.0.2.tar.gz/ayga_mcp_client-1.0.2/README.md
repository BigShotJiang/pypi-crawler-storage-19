# ayga-mcp-client

MCP server for Redis API with 21+ AI parsers.

<!-- MCP Registry identifier -->
mcp-name: io.github.ozand/ayga-mcp-client

## Quick Start

```bash
pip install ayga-mcp-client
```

### Claude Desktop

Add to `~/.config/Claude/claude_desktop_config.json` (Linux/macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

```json
{
  "mcpServers": {
    "redis-api": {
      "command": "python",
      "args": ["-m", "ayga_mcp_client"],
      "env": {
        "REDIS_API_KEY": "YOUR_API_KEY"
      }
    }
  }
}
```

### VS Code Copilot

Add to your MCP config file (`%APPDATA%\Code\User\mcp.json` on Windows):

```json
{
  "servers": {
    "redis-api": {
      "type": "stdio",
      "command": "python",
      "args": ["-m", "ayga_mcp_client"],
      "env": {
        "REDIS_API_KEY": "YOUR_API_KEY"
      }
    }
  }
}
```

## Available Tools

### AI Parsers (11+)
- `search_perplexity` - Perplexity AI search
- `search_chatgpt` - ChatGPT with web search
- `search_claude` - Claude AI
- `search_gemini` - Google Gemini
- `search_copilot` - Microsoft Copilot
- `search_grok` - xAI Grok
- `search_deepseek` - DeepSeek AI
- `search_google_search` - Google web search
- `search_bing_search` - Bing search
- `search_duckduckgo` - DuckDuckGo
- `search_youtube_search` - YouTube search

### Metadata Tools
- `list_parsers` - List all available parsers
- `get_parser_info` - Get parser details
- `health_check` - API health status

## Authentication

Get your API key from https://redis.ayga.tech or contact support@ayga.tech

The client automatically exchanges your API key for a JWT token on first request.

## Example Usage

Once configured, use tools in Claude Desktop or VS Code Copilot:

```
@redis-api search_perplexity query="latest AI trends 2025" timeout=90
@redis-api search_chatgpt query="explain quantum computing" timeout=60
@redis-api list_parsers
```

## Environment Variables

- `REDIS_API_KEY` - Your API key (required)
- `REDIS_API_URL` - API URL (default: https://redis.ayga.tech)

## Development

```bash
git clone https://github.com/ozand/ayga-mcp-client.git
cd ayga-mcp-client
pip install -e ".[dev]"

# Run tests
pytest

# Run locally
python -m ayga_mcp_client --username USER --password PASS
```

## License

MIT License - see [LICENSE](LICENSE)

## Links

- [Redis API Documentation](https://redis.ayga.tech/docs)
- [GitHub Repository](https://github.com/ozand/ayga-mcp-client)
- [Report Issues](https://github.com/ozand/ayga-mcp-client/issues)
