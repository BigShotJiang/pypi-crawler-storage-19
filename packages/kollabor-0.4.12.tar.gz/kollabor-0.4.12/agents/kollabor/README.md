kollabor meta-agent

meta-agent for building new agents and skills within the kollabor cli system


purpose

the kollabor meta-agent specializes in:
  - designing and creating new specialized agents
  - implementing new skills and slash commands
  - enhancing existing agents with new capabilities
  - architecting agent system prompts
  - understanding agent composition and collaboration


when to use this agent

use kollabor meta-agent when you need to:
  [ok] create a new specialized agent (e.g., python-cli-llm-dev)
  [ok] design a new skill/slash command (e.g., /deploy, /analyze)
  [ok] enhance existing agent capabilities
  [ok] understand agent architecture patterns
  [ok] validate agent design decisions


core capabilities

agent creation:
  - define agent purpose and scope
  - design comprehensive system prompts
  - implement dynamic context via <trender> tags
  - create response patterns and workflows
  - validate against best practices

skill development:
  - identify workflow automation needs
  - design skill interfaces and arguments
  - implement skill execution logic
  - register with command system
  - test and verify functionality

agent enhancement:
  - analyze existing agent capabilities
  - identify improvement opportunities
  - integrate new features cohesively
  - maintain consistent voice and style


example usage

create new agent:
  "create a python cli llm dev agent that specializes in building
   command-line tools with llm api integration"

create new skill:
  "create a /deploy skill that handles deployment workflows with
   validation and rollback capabilities"

enhance agent:
  "add database migration expertise to the coder agent"


agent design principles

followed by this meta-agent:

  single responsibility:
    each agent focuses on ONE domain expertise

  clear boundaries:
    agents know what they do AND what they dont do

  composability:
    agents work well together in multi-agent workflows

  context awareness:
    dynamic context via <trender> for relevant information

  practical examples:
    concrete, copy-pasteable examples over abstract descriptions

  terminal-first:
    plain text output optimized for terminal display


deliverables

when creating an agent, kollabor provides:
  [ok] complete system_prompt.md following templates
  [ok] directory structure (agents/<name>/)
  [ok] documentation (README.md)
  [ok] validation against checklist
  [ok] integration guidance

when creating a skill, kollabor provides:
  [ok] plugin implementation following patterns
  [ok] command registration code
  [ok] workflow execution logic
  [ok] error handling
  [ok] testing guidance


collaboration patterns

kollabor works with other agents:

  with coder:
    kollabor designs the agent
    coder implements supporting code

  with technical-writer:
    kollabor creates agent
    technical-writer documents usage

  with researcher:
    researcher validates approach
    kollabor implements agent design


validation standards

every agent must pass:
  [ ] clear purpose and scope
  [ ] comprehensive system prompt
  [ ] concrete examples
  [ ] terminal-friendly formatting
  [ ] no overlap with existing agents
  [ ] proper <trender> context
  [ ] response templates
  [ ] validation checklist complete


meta-knowledge

kollabor understands:
  [ok] kollabor cli architecture
  [ok] event-driven design patterns
  [ok] plugin system mechanics
  [ok] hook system integration
  [ok] slash command registration
  [ok] agent collaboration workflows
  [ok] system prompt conventions


limitations

what kollabor does NOT do:
  [x] general coding (use coder agent)
  [x] documentation writing (use technical-writer)
  [x] research and investigation (use research agent)

kollabor focuses exclusively on agent and skill design and creation.


version history

v0.1 (initial):
  - agent creation methodology
  - skill development patterns
  - system prompt templates
  - validation checklists
  - example implementations
