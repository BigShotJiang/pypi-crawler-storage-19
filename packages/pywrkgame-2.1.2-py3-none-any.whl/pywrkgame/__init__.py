# pywrkgame/__init__.py

"""
PyWRKGame Framework

Профессиональный движок для мобильных игр на Python
Теперь с поддержкой WebGL для браузеров! (Этап 1 Roadmap)
"""

__version__ = "2.1.2"

# Основные компоненты (всегда доступны)
try:
    from .core.engine import Engine, GameConfig
    from .core.scene import Scene
    from .core.assets import assets
    from .core.wrk_parser import WRKParser
except ImportError as e:
    print(f"Warning: Core modules not available: {e}")
    # Создаем полные заглушки для основных классов
    class Engine:
        def __init__(self, config=None): 
            self.config = config
            self._scenes = {}
            self._current_scene = None
        
        def init(self): 
            print("🎮 PyWRKGame Engine initialized (mobile mode)")
            return self
        
        def register_scene(self, name, scene):
            """Регистрирует сцену"""
            self._scenes[name] = scene
            return self
        
        def run(self, scene_or_name):
            """Запускает игру"""
            if isinstance(scene_or_name, str):
                scene = self._scenes.get(scene_or_name)
            else:
                scene = scene_or_name
            
            if scene:
                print(f"🚀 Running scene: {scene.__class__.__name__}")
                if hasattr(scene, 'on_enter'):
                    scene.on_enter()
                
                # Простая симуляция игрового цикла
                import time
                for i in range(3):
                    if hasattr(scene, 'update'):
                        scene.update(0.016)  # ~60 FPS
                    if hasattr(scene, 'render'):
                        scene.render(Renderer())
                    time.sleep(0.1)
                
                if hasattr(scene, 'on_exit'):
                    scene.on_exit()
                
                print("✅ Game finished (mobile simulation)")
    
    class GameConfig:
        def __init__(self, **kwargs):
            # Устанавливаем значения по умолчанию
            self.width = 800
            self.height = 600
            self.title = "PyWRK Game"
            self.fps = 60
            self.fullscreen = False
            self.vsync = True
            self.show_fps = False
            
            # Применяем переданные параметры
            for k, v in kwargs.items():
                setattr(self, k, v)
    
    class Scene:
        def __init__(self):
            pass
        
        def update(self, dt): 
            pass
        
        def render(self, renderer): 
            pass
        
        def on_enter(self): 
            pass
        
        def on_exit(self): 
            pass
        
        def on_pause(self):
            pass
        
        def on_resume(self):
            pass
    
    # Заглушка для assets
    class AssetManager:
        def set_base_path(self, path):
            pass
        
        def load_texture(self, path):
            print(f"📦 Loading texture: {path} (mobile stub)")
            return None
    
    assets = AssetManager()
    WRKParser = None

# Графика (с fallback)
try:
    from .graphics.renderer import Renderer
    from .graphics.color import Colors, Color
except ImportError:
    print("Warning: Graphics modules not available")
    class Renderer:
        def __init__(self):
            self.draw_calls = 0
        
        def clear(self, color=None): 
            print(f"🎨 Clear screen with color: {color}")
        
        def draw_text(self, text, pos, color=None): 
            print(f"📝 Draw text: '{text}' at {pos} with color {color}")
            self.draw_calls += 1
        
        def draw_rect(self, rect, color):
            print(f"🔲 Draw rect: {rect} with color {color}")
            self.draw_calls += 1
        
        def draw_circle(self, center, radius, color):
            print(f"⭕ Draw circle: center={center}, radius={radius}, color={color}")
            self.draw_calls += 1
        
        def begin_frame(self):
            self.draw_calls = 0
        
        def end_frame(self):
            pass
    
    class Colors:
        WHITE = (255, 255, 255, 255)
        BLACK = (0, 0, 0, 255)
        RED = (255, 0, 0, 255)
        GREEN = (0, 255, 0, 255)
        BLUE = (0, 0, 255, 255)
        YELLOW = (255, 255, 0, 255)
        CYAN = (0, 255, 255, 255)
        MAGENTA = (255, 0, 255, 255)
        DARK_BLUE = (0, 0, 128, 255)
        DARK_GREEN = (0, 128, 0, 255)
        DARK_RED = (128, 0, 0, 255)
        GRAY = (128, 128, 128, 255)
        LIGHT_GRAY = (192, 192, 192, 255)
        DARK_GRAY = (64, 64, 64, 255)
    
    Color = Colors

# Векторы (с fallback)
try:
    from .utils.vector import Vec2, Vec3
except ImportError:
    print("Warning: Vector modules not available")
    class Vec2:
        def __init__(self, x=0, y=0):
            self.x, self.y = x, y
    
    class Vec3:
        def __init__(self, x=0, y=0, z=0):
            self.x, self.y, self.z = x, y, z

# Платформы (опционально)
try:
    from .platforms.platform_detector import PlatformDetector, Platform
except ImportError:
    print("Warning: Platform detection not available")
    PlatformDetector = None
    Platform = None

# WebGL (опционально)
try:
    from .webgl.webgl_renderer import WebGLRenderer
    from .platforms.webgl_platform import WebGLPlatform
except ImportError:
    WebGLRenderer = None
    WebGLPlatform = None

# Консоли (опционально)
try:
    from .console.console_detector import ConsoleDetector, ConsoleType
    from .console.console_renderer import ConsoleRenderer
    from .platforms.console_platform import ConsolePlatform
except ImportError:
    ConsoleDetector = None
    ConsoleType = None
    ConsoleRenderer = None
    ConsolePlatform = None

# Бенчмарки (опционально)
try:
    from .benchmarks.benchmark_runner import BenchmarkRunner, BenchmarkResult
    from .benchmarks.competitor_tests import CompetitorBenchmarks
    from .benchmarks.performance_profiler import PerformanceProfiler
except ImportError:
    BenchmarkRunner = None
    BenchmarkResult = None
    CompetitorBenchmarks = None
    PerformanceProfiler = None


def quick_start(scene_class, width=1280, height=720, title="PyWRK Game", auto_detect_platform=True):
    """
    Запуск игры одной строчкой кода.
    
    Автоматически настраивает конфиг и запускает сцену.
    Теперь с автоматическим определением платформы! (Этап 1 Roadmap)
    
    Args:
        scene_class: Класс сцены или экземпляр Scene для запуска
        width: Ширина окна (по умолчанию 1280)
        height: Высота окна (по умолчанию 720)
        title: Заголовок окна (по умолчанию "PyWRK Game")
        auto_detect_platform: Автоматически определять платформу (по умолчанию True)
    """
    print(f"🚀 PyWRKGame Quick Start: {title}")
    print(f"📱 Resolution: {width}x{height}")
    
    config = GameConfig(
        width=width,
        height=height,
        title=title,
        show_fps=True,
        vsync=True
    )
    
    # Автоматическое определение платформы (если доступно)
    if auto_detect_platform and PlatformDetector:
        try:
            current_platform = PlatformDetector.detect_platform()
            console_type = ConsoleDetector.detect_console() if ConsoleDetector else None
            
            print(f"🔍 Detected platform: {current_platform.name}")
            if console_type and hasattr(console_type, 'name'):
                print(f"🎮 Detected console: {console_type.name}")
            
            # Здесь можно добавить специфичную логику для платформ
        except Exception as e:
            print(f"⚠️ Platform detection failed: {e}")
    
    engine = Engine(config)
    
    # Пытаемся автоматически задать папку ассетов
    if assets:
        try:
            assets.set_base_path("assets")
        except:
            pass
    
    engine.init()
    
    # Если передали класс, создаем экземпляр, если объект - используем его
    scene = scene_class() if isinstance(scene_class, type) else scene_class
    
    # Для совместимости с разными API
    try:
        # Новый API (с register_scene)
        engine.register_scene("main", scene)
        engine.run("main")
    except AttributeError:
        # Старый API (прямой запуск)
        engine.run(scene)


# Глобальный доступ к наиболее важным элементам
__all__ = [
    'Engine', 'GameConfig', 'Scene', 'assets', 
    'WRKParser', 'Renderer', 'Colors', 'Color', 
    'Vec2', 'Vec3', 'quick_start',
    # WebGL поддержка (Этап 1 Roadmap)
    'PlatformDetector', 'Platform', 'WebGLRenderer', 'WebGLPlatform',
    # Консольная поддержка (Этап 1 Roadmap)
    'ConsoleDetector', 'ConsoleType', 'ConsoleRenderer', 'ConsolePlatform',
    # Performance Benchmarking Suite (Этап 1 Roadmap)
    'BenchmarkRunner', 'BenchmarkResult', 'CompetitorBenchmarks', 'PerformanceProfiler'
]
