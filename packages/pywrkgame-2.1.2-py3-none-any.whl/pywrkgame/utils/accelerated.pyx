# cython: language_level=3, boundscheck=False, wraparound=False, nonecheck=False, cdivision=True

"""
Оптимизированное ядро PyWRKGame на Cython.

Вектора, Матрицы и Коллизии.
"""

cimport libc.math as math

# Структура вектора на уровне C
cdef struct Vec2C:
    double x
    double y

cdef struct RectC:
    double x
    double y
    double w
    double h

# --- Векторная математика ---

cpdef tuple vec2_normalize(double x, double y):
    """Нормализация вектора (x, y) -> (nx, ny)"""
    cdef double length = math.sqrt(x*x + y*y)
    if length > 0.000001:
        return (x / length, y / length)
    return (0.0, 0.0)

cpdef double vec2_distance(double x1, double y1, double x2, double y2):
    """Расстояние между двумя точками"""
    cdef double dx = x2 - x1
    cdef double dy = y2 - y1
    return math.sqrt(dx*dx + dy*dy)

cpdef tuple vec2_rotate(double x, double y, double angle):
    """Поворот вектора на угол (в радианах)"""
    cdef double cos_a = math.cos(angle)
    cdef double sin_a = math.sin(angle)
    return (x * cos_a - y * sin_a, x * sin_a + y * cos_a)

# --- Матричные вычисления (4x4) ---

cpdef list mat4_multiply(list a, list b):
    """Быстрое умножение матриц 4x4 на уровне C"""
    cdef double[16] A, B, R
    cdef int i, j, k
    
    # Копируем из Python-листа в C-массив
    for i in range(16):
        A[i] = a[i]
        B[i] = b[i]
        
    for i in range(4):  # Строки
        for j in range(4):  # Колонки
            R[j * 4 + i] = 0
            for k in range(4):
                R[j * 4 + i] += A[k * 4 + i] * B[j * 4 + k]
                
    return [R[0], R[1], R[2], R[3], R[4], R[5], R[6], R[7], 
            R[8], R[9], R[10], R[11], R[12], R[13], R[14], R[15]]

# --- Физика и коллизии ---

cpdef bint intersect_aabb(double ax, double ay, double aw, double ah,
                         double bx, double by, double bw, double bh):
    """Проверка пересечения двух прямоугольников (AABB)"""
    return not (ax + aw < bx or bx + bw < ax or
                ay + ah < by or by + bh < ay)

cpdef tuple resolve_aabb_collision(double ax, double ay, double aw, double ah,
                                  double bx, double by, double bw, double bh):
    """
    Возвращает (normal_x, normal_y, depth) для разрешения коллизии.
    Это 'горячая' функция физического движка.
    """
    cdef double dx = (bx + bw/2.0) - (ax + aw/2.0)
    cdef double dy = (by + bh/2.0) - (ay + ah/2.0)
    
    cdef double overlap_x = (aw/2.0 + bw/2.0) - math.fabs(dx)
    cdef double overlap_y = (ah/2.0 + bh/2.0) - math.fabs(dy)
    
    if overlap_x < overlap_y:
        return (1.0 if dx > 0 else -1.0, 0.0, overlap_x)
    else:
        return (0.0, 1.0 if dy > 0 else -1.0, overlap_y)

