##EasyCode-infinite
**EasyCode-infinite is a python library made specifically so there would be easier and better coding with a lot of simplification added**

EasyCode-infinite simplifies game development in Python by providing high-precision math variables and powerful, easy-to-use base classes for the industry's most popular 2D frameworks.

##Key Features
*it includes of 3 special variables BigDecimal, BigString, and BigVector
*includes of optimizations
*is very fast and can save memory potentially
*has a couple new sprites you can use
*supports arcade, pyglet, and pygame

##Installation
Install EasyCode via `pip` or `uv`:
```bash
pip install easycode_infinite
uv pip install easycode_infinite --system