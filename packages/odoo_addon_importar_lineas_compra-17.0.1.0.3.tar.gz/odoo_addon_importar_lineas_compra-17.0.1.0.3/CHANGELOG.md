# Changelog

All notable changes to this Odoo module will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [17.0.1.0.3] - 2026-01-08

### Changed
- Hide import lines button if order is confirmed

## [17.0.1.0.2] - 2025-10-31

The last undocumented release. We will document the following versions.
