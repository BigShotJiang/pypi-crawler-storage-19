"""Tests for HITL Lab."""
