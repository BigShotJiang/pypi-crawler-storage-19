# NC1709 - AI Coding Assistant

**Version 2.1.4** | 99% Tool-Calling Accuracy with Zero Setup

## 🚀 What Makes NC1709 Special

- **99% Tool-Calling Accuracy**: Outperforms Claude Sonnet 3.5 (80.5%) on coding tasks
- **Zero Setup Required**: No local models, no GPU needed, no configuration
- **Instant Access**: Just `pip install nc1709` and start coding
- **Server-Side Intelligence**: Access our fine-tuned Qwen2.5-Coder-7B via API
- **Enterprise-Grade Performance**: Battle-tested on 800K training examples

## Features

| Tool | Description |
|------|-------------|
| **Read** | Read file contents with line number support |
| **Write** | Create or overwrite files |
| **Edit** | Precise string replacement in files |
| **Glob** | Fast file pattern matching |
| **Grep** | Content search with regex support |
| **Bash** | Safe command execution |
| **WebFetch** | Fetch and process web content |
| **Task** | Spawn sub-agents for complex tasks |
| **TodoWrite** | Task management and tracking |

## Installation

```bash
# Recommended: Global install (requires admin/sudo)
pip install nc1709

# Alternative: User install (automatic PATH setup)
pip install --user nc1709
```

That's it! No local models to download, no GPU required.

**Note:** If commands aren't found after user install, restart your terminal or run:
```bash
source ~/.bashrc  # or ~/.zshrc
```

## Quick Start

```bash
# Start coding with 99% accuracy AI
nc1709

# Example: Analyze your codebase
nc1709 "Find all Python functions with TODO comments"

# Example: Generate code
nc1709 "Create a FastAPI endpoint for user authentication"

# Example: Debug and fix
nc1709 "Fix the TypeError in main.py line 42"
```

## Why Choose NC1709?

| Feature | NC1709 | Claude Sonnet 3.5 | Local Models |
|---------|--------|--------------------|--------------|
| **Tool Accuracy** | 99% | 80.5% | Variable |
| **Setup Time** | 0 minutes | API key setup | Hours |
| **Hardware Needed** | None | None | RTX 3090+ |
| **Storage Required** | 0GB | 0GB | 15GB+ |
| **Cost** | Usage-based | API costs | Hardware costs |

## How It Works

NC1709 connects to our optimized server infrastructure:

1. **Send Request** - Your command goes to our fine-tuned model
2. **Smart Processing** - 7-layer cognitive architecture analyzes your task  
3. **Tool Selection** - AI chooses the right tools with 99% accuracy
4. **Execution** - Commands run on your local system securely
5. **Results** - Get precise outputs faster than any local model

## Behind the Scenes

**Our Training**: 800K examples on DeepFabric infrastructure
**Our Model**: Fine-tuned Qwen2.5-Coder-7B optimized for tool-calling  
**Our Infrastructure**: Enterprise-grade servers for instant responses
**Your Benefit**: 99% accuracy without any local setup

## API Usage

```python
# Simple command execution
import subprocess
result = subprocess.run(['nc1709', 'help me debug this error'], capture_output=True, text=True)
print(result.stdout)

# Or use directly as CLI
# nc1709 "refactor this function to be more efficient"
```

## Use Cases

**Code Analysis**
```bash
nc1709 "Find all security vulnerabilities in my Django app"
nc1709 "List all functions that need documentation"
```

**Code Generation**  
```bash
nc1709 "Create unit tests for the user authentication module"
nc1709 "Generate a REST API client for this OpenAPI spec"
```

**Debugging & Fixes**
```bash 
nc1709 "Debug the memory leak in process.py"
nc1709 "Optimize the database queries in this file"
```

**Project Management**
```bash
nc1709 "Create a requirements.txt from my imports"
nc1709 "Set up GitHub Actions CI/CD for this Python project"
```

## Links

- **Documentation**: https://docs.lafzusa.com/nc1709
- **GitHub**: https://github.com/lafzusa/nc1709
- **PyPI**: https://pypi.org/project/nc1709/
- **Support**: support@lafzusa.com

## License

Proprietary - Lafzusa Corp

## Changelog

### 2.1.4 (2025-01-05)
- **🎉 Enhanced Welcome Screen**: Beautiful onboarding for new users
- **📋 Demo Examples**: Shows what NC1709 can do before requiring API key
- **📧 Clear Instructions**: Step-by-step guide for early access

### 2.1.3 (2025-01-05)
- **🔗 True Zero Setup**: Default server URL configured (nc1709.lafzusa.com)
- **🚀 Instant Connection**: No environment variables needed
- **✅ Auto-Remote Mode**: Always connects to server by default

### 2.1.2 (2025-01-05)
- **⚙️ Automatic PATH Setup**: CLI commands work immediately after install
- **🛠️ Post-Install Fixes**: Shell integration and PATH detection

### 2.1.0 (2025-01-05)
- **🎯 99% Tool-Calling Accuracy**: Outperforms Claude Sonnet 3.5's 80.5%
- **🚀 Zero Setup Experience**: No local models, just `pip install nc1709`
- **⚡ Server-Side Intelligence**: Access fine-tuned Qwen2.5-Coder-7B via API
- **📊 DeepFabric Training**: 800K examples for enterprise-grade performance
- **🔧 Enhanced CLI**: New commands for training monitoring and benchmarking

### 2.0.0 (2024-12-30)
- Initial release with server-side processing
- Core tool implementations
- Basic CLI interface
