"""
Reminix Runtime

A simple framework for building AI agents that conform to the Reminix API contract.

Example usage:
    from reminix.runtime import Agent, serve

    agent = Agent(name="my-agent")

    @agent.invoke
    async def handle_invoke(input: dict):
        return {"output": f"Processed: {input}"}

    @agent.chat
    async def handle_chat(messages: list):
        return {
            "message": {
                "role": "assistant",
                "content": "Hello! How can I help?"
            }
        }

    if __name__ == "__main__":
        serve([agent], port=8080)
"""


# Check for runtime dependencies
def _check_dependencies() -> None:
    """Check that runtime dependencies are installed."""
    import importlib.util

    missing = []
    for pkg in ["fastapi", "uvicorn"]:
        if importlib.util.find_spec(pkg) is None:
            missing.append(pkg)

    if missing:
        raise ImportError(
            f"Runtime dependencies not installed: {', '.join(missing)}. "
            "Install with: pip install reminix[runtime]"
        )


_check_dependencies()

# Import and export public API
from .types import (  # noqa: E402
    # Message types
    ChatMessage,
    AssistantMessage,
    ToolCall,
    ToolCallFunction,
    # Request types
    InvokeRequest,
    ChatRequest,
    # Response types
    InvokeResponse,
    ChatResponse,
    StreamChunk,
    # Handler types
    InvokeHandler,
    ChatHandler,
    InvokeResult,
    ChatResult,
    # Health types
    HealthResponse,
    AgentHealth,
)
from .agent import Agent  # noqa: E402
from .server import serve  # noqa: E402

__all__ = [
    # Main API
    "Agent",
    "serve",
    # Message types
    "ChatMessage",
    "AssistantMessage",
    "ToolCall",
    "ToolCallFunction",
    # Request types
    "InvokeRequest",
    "ChatRequest",
    # Response types
    "InvokeResponse",
    "ChatResponse",
    "StreamChunk",
    # Handler types
    "InvokeHandler",
    "ChatHandler",
    "InvokeResult",
    "ChatResult",
    # Health types
    "HealthResponse",
    "AgentHealth",
]
