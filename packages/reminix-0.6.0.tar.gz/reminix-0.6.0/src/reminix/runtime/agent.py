"""
Reminix Agent

The Agent class for building AI agents that conform to the Reminix API contract.
"""

import asyncio
import inspect
from collections.abc import AsyncGenerator, Callable
from typing import Any, cast

from .types import (
    AgentInfo,
    ChatMessage,
    ChatResponse,
    InvokeResponse,
    StreamChunk,
)


class Agent:
    """
    An AI agent that can handle invoke and chat requests.

    Example::

        agent = Agent(name="my-agent")

        @agent.invoke
        async def handle_invoke(input: dict):
            return {"output": f"Processed: {input}"}

        @agent.chat
        async def handle_chat(messages: list):
            return {
                "message": {
                    "role": "assistant",
                    "content": "Hello!"
                }
            }
    """

    def __init__(
        self,
        name: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize an agent with a name and optional metadata.

        Args:
            name: Unique name for the agent (used in URL routing).
                  Must be URL-safe (alphanumeric, hyphens, underscores).
            metadata: Optional user-defined metadata (e.g., framework, model, description).
        """
        if not name or not isinstance(name, str):
            raise ValueError("Agent name must be a non-empty string")

        # Validate name is URL-safe
        import re

        if not re.match(r"^[a-zA-Z0-9_-]+$", name):
            raise ValueError(
                "Agent name must be URL-safe (alphanumeric, hyphens, underscores only)"
            )

        self.name = name
        self._metadata = metadata or {}
        self._invoke_handler: Callable[..., Any] | None = None
        self._chat_handler: Callable[..., Any] | None = None

    @property
    def metadata(self) -> dict[str, Any]:
        """Get the agent's metadata."""
        return self._metadata

    def to_info(self) -> AgentInfo:
        """
        Return agent information for discovery.

        Returns:
            AgentInfo dict with name, capabilities, and metadata.
        """
        return {
            "name": self.name,
            "invoke": self.has_invoke,
            "chat": self.has_chat,
            "metadata": self._metadata,
        }

    def invoke(self, handler: Callable[[dict[str, Any]], Any]) -> Callable[[dict[str, Any]], Any]:
        """
        Decorator to register an invoke handler.

        The handler receives the input dict and should return either:
        - {"output": ...} for non-streaming responses
        - An async generator yielding {"chunk": "..."} for streaming

        Example::

            @agent.invoke
            async def handle_invoke(input: dict):
                return {"output": f"Result: {input['query']}"}

            # Streaming
            @agent.invoke
            async def handle_invoke(input: dict):
                for word in ["Hello", " ", "world"]:
                    yield {"chunk": word}
        """
        self._invoke_handler = handler
        return handler

    def chat(
        self, handler: Callable[[list[ChatMessage]], Any]
    ) -> Callable[[list[ChatMessage]], Any]:
        """
        Decorator to register a chat handler.

        The handler receives the messages list and should return either:
        - {"message": {"role": "assistant", "content": "..."}} for non-streaming
        - An async generator yielding {"chunk": "..."} for streaming

        Example::

            @agent.chat
            async def handle_chat(messages: list):
                return {
                    "message": {
                        "role": "assistant",
                        "content": "Hello! How can I help?"
                    }
                }

            # Streaming
            @agent.chat
            async def handle_chat(messages: list):
                for word in ["Hello", "!", " How", " can", " I", " help?"]:
                    yield {"chunk": word}
        """
        self._chat_handler = handler
        return handler

    @property
    def has_invoke(self) -> bool:
        """Check if invoke handler is registered."""
        return self._invoke_handler is not None

    @property
    def has_chat(self) -> bool:
        """Check if chat handler is registered."""
        return self._chat_handler is not None

    async def handle_invoke(
        self, input_data: dict[str, Any]
    ) -> InvokeResponse | AsyncGenerator[StreamChunk, None]:
        """
        Execute the invoke handler.

        Args:
            input_data: The input data from the request.

        Returns:
            Either an InvokeResponse or an async generator of StreamChunks.

        Raises:
            NotImplementedError: If no invoke handler is registered.
        """
        if self._invoke_handler is None:
            raise NotImplementedError(f"Agent '{self.name}' does not implement invoke")

        result = self._invoke_handler(input_data)

        # Handle async functions
        if asyncio.iscoroutine(result):
            result = await result

        # Check if result is an async generator (streaming)
        if inspect.isasyncgen(result):
            return result

        # Validate non-streaming response
        if not isinstance(result, dict) or "output" not in result:
            raise ValueError(f"Invoke handler must return {{'output': ...}}, got: {type(result)}")

        return cast(InvokeResponse, result)

    async def handle_chat(
        self, messages: list[ChatMessage]
    ) -> ChatResponse | AsyncGenerator[StreamChunk, None]:
        """
        Execute the chat handler.

        Args:
            messages: The chat messages from the request.

        Returns:
            Either a ChatResponse or an async generator of StreamChunks.

        Raises:
            NotImplementedError: If no chat handler is registered.
        """
        if self._chat_handler is None:
            raise NotImplementedError(f"Agent '{self.name}' does not implement chat")

        result = self._chat_handler(messages)

        # Handle async functions
        if asyncio.iscoroutine(result):
            result = await result

        # Check if result is an async generator (streaming)
        if inspect.isasyncgen(result):
            return result

        # Validate non-streaming response
        if not isinstance(result, dict) or "message" not in result:
            raise ValueError(f"Chat handler must return {{'message': ...}}, got: {type(result)}")

        message = result["message"]
        if not isinstance(message, dict) or message.get("role") != "assistant":
            raise ValueError(
                "Chat handler must return {'message': {'role': 'assistant', 'content': ...}}"
            )

        return cast(ChatResponse, result)

    def __repr__(self) -> str:
        return f"Agent(name={self.name!r}, invoke={self.has_invoke}, chat={self.has_chat})"
