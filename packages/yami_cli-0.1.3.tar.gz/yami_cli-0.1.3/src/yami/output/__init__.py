"""Output formatting."""
