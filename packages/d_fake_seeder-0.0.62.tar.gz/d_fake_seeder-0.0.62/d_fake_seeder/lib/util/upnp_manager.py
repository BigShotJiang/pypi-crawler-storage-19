"""
UPnP Port Forwarding Manager.

Manages automatic port forwarding using UPnP/NAT-PMP protocols
for better peer connectivity through NAT routers.
"""

import threading
from typing import Any, Optional

from d_fake_seeder.domain.app_settings import AppSettings
from d_fake_seeder.lib.logger import logger
from d_fake_seeder.view import View

# Try to import miniupnpc - it's an optional dependency
try:
    import miniupnpc

    UPNP_AVAILABLE = True
except ImportError:
    UPNP_AVAILABLE = False
    miniupnpc = None


class UPnPManager:  # pylint: disable=too-many-instance-attributes
    """
    Manages UPnP/NAT-PMP port forwarding.

    Automatically configures port forwarding on NAT routers when enabled,
    allowing incoming peer connections for better torrent performance.
    """

    def __init__(self) -> None:
        """Initialize the UPnP manager."""
        self.settings = AppSettings.get_instance()
        self.upnp: Optional[Any] = None
        self.mapped_port: Optional[int] = None
        self.external_ip: Optional[str] = None
        self._lock = threading.Lock()
        self._started = False
        self._setup_thread: Optional[threading.Thread] = None
        self._setup_in_progress = False

        if not UPNP_AVAILABLE:
            logger.warning(
                "miniupnpc not installed - UPnP port forwarding disabled. Install with: pip install miniupnpc",
                extra={"class_name": self.__class__.__name__},
            )
        else:
            logger.trace(
                "UPnPManager initialized",
                extra={"class_name": self.__class__.__name__},
            )

    def start_async(self) -> None:
        """
        Start UPnP setup in a background thread (non-blocking).

        This prevents UPnP operations from blocking the UI thread.
        """
        if not UPNP_AVAILABLE:
            return

        if self._started or self._setup_in_progress:
            return

        if not self.settings.get("connection.upnp_enabled", True):
            return

        self._setup_in_progress = True
        self._setup_thread = threading.Thread(
            target=self._background_setup,
            name="UPnP-Setup",
            daemon=True,
        )
        self._setup_thread.start()
        logger.debug(
            "UPnP setup started in background thread",
            extra={"class_name": self.__class__.__name__},
        )

    def _background_setup(self) -> None:
        """Background thread for UPnP setup."""
        try:
            result = self.start()
            if result:
                logger.info(
                    f"UPnP: Background setup completed successfully (port {self.mapped_port})",
                    extra={"class_name": self.__class__.__name__},
                )
            else:
                logger.debug(
                    "UPnP: Background setup completed - no mapping created",
                    extra={"class_name": self.__class__.__name__},
                )
        except (OSError, AttributeError, RuntimeError) as e:
            logger.warning(
                f"UPnP: Background setup failed: {e}",
                extra={"class_name": self.__class__.__name__},
                exc_info=True,
            )
        finally:
            self._setup_in_progress = False

    def start(self) -> bool:
        """
        Initialize UPnP and add port mapping.

        Returns:
            True if port mapping was successful, False otherwise.
        """
        if not UPNP_AVAILABLE:
            return False

        if not self.settings.get("connection.upnp_enabled", True):
            logger.debug(
                "UPnP disabled in settings",
                extra={"class_name": self.__class__.__name__},
            )
            return False

        if self._started:
            return True

        port = self.settings.get("connection.listening_port", 6881)

        try:
            with self._lock:
                self.upnp = miniupnpc.UPnP()
                # Get discover delay from settings
                discover_delay = self.settings.get("upnp_settings.discover_delay_ms", 200)
                self.upnp.discoverdelay = discover_delay

                # Discover UPnP devices
                devices = self.upnp.discover()

                if devices == 0:
                    logger.warning(
                        "No UPnP devices found on the network",
                        extra={"class_name": self.__class__.__name__},
                    )
                    return False

                # Select the Internet Gateway Device
                self.upnp.selectigd()

                # Get external IP address
                self.external_ip = self.upnp.externalipaddress()
                local_ip = self.upnp.lanaddr

                logger.debug(
                    f"UPnP: Found IGD, external IP: {self.external_ip}, " f"local IP: {local_ip}",
                    extra={"class_name": self.__class__.__name__},
                )

                # Add port mapping for TCP
                try:
                    self.upnp.addportmapping(
                        port,  # External port
                        "TCP",  # Protocol
                        local_ip,  # Internal IP
                        port,  # Internal port
                        "DFakeSeeder TCP",  # Description
                        "",  # Remote host (empty = any)
                    )
                    logger.debug(
                        f"UPnP: Added TCP port mapping for port {port}",
                        extra={"class_name": self.__class__.__name__},
                    )
                except (OSError, RuntimeError) as e:
                    logger.warning(
                        f"UPnP: Failed to add TCP port mapping: {e}",
                        extra={"class_name": self.__class__.__name__},
                    )

                # Add port mapping for UDP (for DHT)
                try:
                    self.upnp.addportmapping(
                        port,  # External port
                        "UDP",  # Protocol
                        local_ip,  # Internal IP
                        port,  # Internal port
                        "DFakeSeeder UDP",  # Description
                        "",  # Remote host (empty = any)
                    )
                    logger.debug(
                        f"UPnP: Added UDP port mapping for port {port}",
                        extra={"class_name": self.__class__.__name__},
                    )
                except (OSError, RuntimeError) as e:
                    logger.warning(
                        f"UPnP: Failed to add UDP port mapping: {e}",
                        extra={"class_name": self.__class__.__name__},
                    )

                self.mapped_port = port
                self._started = True

                logger.info(
                    f"UPnP: Successfully mapped port {port} " f"(external IP: {self.external_ip})",
                    extra={"class_name": self.__class__.__name__},
                )

                # Notify user of successful port mapping
                if View.instance:
                    View.instance.notify(
                        f"UPnP: Port {port} mapped (IP: {self.external_ip})",
                        notification_type="success",
                        timeout_ms=3000,
                        translate=False,  # Contains dynamic values
                    )

                return True

        except (OSError, AttributeError, RuntimeError) as e:
            logger.error(
                f"UPnP setup failed: {e}",
                extra={"class_name": self.__class__.__name__},
                exc_info=True,
            )

            # Notify user of failure
            if View.instance:
                View.instance.notify(
                    "UPnP: Port mapping failed",
                    notification_type="warning",
                    timeout_ms=4000,
                    translate=True,
                )

            return False

    def stop(self) -> None:
        """Remove port mapping and cleanup."""
        if not self._started or not self.upnp or not self.mapped_port:
            return

        with self._lock:
            try:
                # Remove TCP port mapping
                self.upnp.deleteportmapping(self.mapped_port, "TCP")
                logger.debug(
                    f"UPnP: Removed TCP port mapping for {self.mapped_port}",
                    extra={"class_name": self.__class__.__name__},
                )
            except (OSError, RuntimeError) as e:
                logger.warning(
                    f"Failed to remove TCP UPnP mapping: {e}",
                    extra={"class_name": self.__class__.__name__},
                )

            try:
                # Remove UDP port mapping
                self.upnp.deleteportmapping(self.mapped_port, "UDP")
                logger.debug(
                    f"UPnP: Removed UDP port mapping for {self.mapped_port}",
                    extra={"class_name": self.__class__.__name__},
                )
            except (OSError, RuntimeError) as e:
                logger.warning(
                    f"Failed to remove UDP UPnP mapping: {e}",
                    extra={"class_name": self.__class__.__name__},
                )

            self.mapped_port = None
            self.external_ip = None
            self._started = False

            logger.info(
                "UPnP: Port mappings removed",
                extra={"class_name": self.__class__.__name__},
            )

    def refresh_mapping(self) -> bool:
        """
        Refresh the port mapping (useful if external IP changed).

        Returns:
            True if refresh was successful.
        """
        self.stop()
        return self.start()

    def get_external_ip(self) -> Optional[str]:
        """
        Get the external IP address from UPnP.

        Returns:
            External IP address string, or None if not available.
        """
        return self.external_ip

    def get_status(self) -> dict:
        """
        Get the current UPnP status.

        Returns:
            Dictionary with UPnP status information.
        """
        return {
            "available": UPNP_AVAILABLE,
            "enabled": self.settings.get("connection.upnp_enabled", True),
            "started": self._started,
            "mapped_port": self.mapped_port,
            "external_ip": self.external_ip,
        }

    def is_available(self) -> bool:
        """Check if UPnP library is available."""
        return UPNP_AVAILABLE

    def is_active(self) -> bool:
        """Check if port mapping is currently active."""
        return self._started and self.mapped_port is not None


# Convenience function to get a singleton instance
_instance: Optional[UPnPManager] = None  # pylint: disable=invalid-name


def get_upnp_manager() -> UPnPManager:
    """Get or create the UPnPManager singleton instance."""
    global _instance  # pylint: disable=global-statement
    if _instance is None:
        _instance = UPnPManager()
    return _instance
