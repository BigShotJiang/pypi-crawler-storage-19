# mlalib

A research-first PyTorch companion for experimenting with intelligence in machines.

## Installation

```bash
pip install mlalib