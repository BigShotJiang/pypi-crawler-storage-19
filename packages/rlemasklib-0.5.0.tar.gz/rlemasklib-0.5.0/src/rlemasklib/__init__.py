"""Library for manipulating masks stored in run-length-encoded format.

This library is an extended version of the pycocotools library's RLE functions, originally developed by Piotr Dollár and
Tsung-Yi Linfor the COCO dataset :footcite:`lin2014coco`.

There are two ways to use this library:

1. with the :class:`RLEMask` class, which is an object-oriented way to manipulate RLE masks (recommended)
2. with global functions, which take RLE masks in a dictionary representation, with the keys 'counts' and 'size'


"""

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.0.0"

__all__ = [
    "RLEMask",
    "encode",
    "decode",
    "compress",
    "complement",
    "decompress",
    "ones",
    "zeros",
    "ones_like",
    "zeros_like",
    "full",
    "empty",
    "any",
    "all",
    "area",
    "centroid",
    "intersection",
    "union",
    "iou",
    "difference",
    "symmetric_difference",
    "from_bbox",
    "to_bbox",
    "from_polygon",
    "crop",
    "pad",
    "connected_components",
    "largest_connected_component",
    "remove_small_components",
    "fill_small_holes",
    "erode",
    "dilate",
    "opening",
    "closing",
    "erode2",
    "dilate2",
    "opening2",
    "closing2",
    "shift",
    "BoolFunc",
    "merge",
]

from .oop import RLEMask


from .rlemasklib import (
    encode,
    decode,
    compress,
    complement,
    decompress,
    ones,
    zeros,
    ones_like,
    zeros_like,
    ones as full,
    zeros as empty,
    any,
    all,
    area,
    centroid,
    intersection,
    union,
    iou,
    difference,
    symmetric_difference,
    from_bbox,
    to_bbox,
    from_polygon,
    crop,
    pad,
    connected_components,
    largest_connected_component,
    remove_small_components,
    fill_small_holes,
    erode,
    dilate,
    opening,
    closing,
    erode2,
    dilate2,
    opening2,
    closing2,
    shift,
    BoolFunc,
    merge,
)

# Set the __module__ attribute of all exported functions/classes to this module.
# This is necessary for sphinx-codeautolink to correctly resolve references like
# `RLEMask` to `rlemasklib.RLEMask` in code blocks. Without this, sphinx-codeautolink
# cannot link names that are imported (e.g., `from rlemasklib import RLEMask`) because
# it doesn't know that `RLEMask` refers to `rlemasklib.RLEMask` rather than
# `rlemasklib.oop.RLEMask`. The _module_original_ attribute preserves the true module
# for use by docs/conf.py's `module_restored` context manager when resolving source links.
for x in __all__:
    obj = globals()[x]
    obj._module_original_ = obj.__module__  # noqa: vulture
    obj.__module__ = __name__
