"""
PromptCanvas Python SDK

High-performance SDK for fetching prompts from PromptCanvas with built-in
caching, prefetching, and variable resolution.

Example:
    >>> from promptcanvas import PromptCanvas
    >>> 
    >>> pc = PromptCanvas(api_key="pc_live_xxx")
    >>> prompt = pc.get("system-prompt")
    >>> print(prompt.content)
    
    # Async usage
    >>> prompt = await pc.aget("system-prompt")
"""

from .client import PromptCanvas
from .models import (
    Prompt,
    PromptMeta,
    SlugSuggestion,
    CacheStats,
    BatchResult,
    ListResult,
)
from .errors import (
    PromptCanvasError,
    PromptNotFoundError,
    NoProductionVersionError,
    AuthenticationError,
    RateLimitError,
    NetworkError,
    TimeoutError,
    MissingVariablesError,
)
from .cache import LRUCache
from .variables import VariableResolver

__version__ = "1.0.0"
__all__ = [
    "PromptCanvas",
    "Prompt",
    "PromptMeta",
    "SlugSuggestion",
    "CacheStats",
    "BatchResult",
    "ListResult",
    "PromptCanvasError",
    "PromptNotFoundError",
    "NoProductionVersionError",
    "AuthenticationError",
    "RateLimitError",
    "NetworkError",
    "TimeoutError",
    "MissingVariablesError",
    "LRUCache",
    "VariableResolver",
]
