"""MCP server for ATT&CK queries via AI assistants."""

__version__ = "0.2.1"
