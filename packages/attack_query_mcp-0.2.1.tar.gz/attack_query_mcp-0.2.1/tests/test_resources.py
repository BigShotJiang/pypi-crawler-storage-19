"""Tests for MCP resource implementations."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


class TestListResources:
    """Tests for the list_resources handler."""

    def test_get_resource_list(self):
        """Test that get_resource_list returns all expected resources."""
        from attack_query_mcp.resources import get_resource_list

        resources = get_resource_list()
        assert len(resources) == 6

        # Check all expected resources are present
        uris = {str(r.uri) for r in resources}
        assert "attack://groups" in uris
        assert "attack://techniques" in uris
        assert "attack://tactics" in uris
        assert "attack://software" in uris
        assert "attack://mitigations" in uris
        assert "attack://campaigns" in uris

    def test_resource_metadata(self):
        """Test that resources have proper metadata."""
        from attack_query_mcp.resources import get_resource_list

        resources = get_resource_list()

        for resource in resources:
            assert resource.name is not None
            assert resource.description is not None
            assert resource.mimeType == "text/plain"
            assert str(resource.uri).startswith("attack://")


class TestReadGroupsResource:
    """Tests for the attack://groups resource."""

    @pytest.fixture
    def mock_store(self):
        """Create a mock store with sample groups."""
        with patch("attack_query_mcp.server.get_store") as mock:
            store = MagicMock()

            # Create sample groups
            group1 = MagicMock()
            group1.id = "G0007"
            group1.name = "APT28"
            group1.aliases = ["Fancy Bear", "Sofacy", "Pawn Storm"]

            group2 = MagicMock()
            group2.id = "G0016"
            group2.name = "APT29"
            group2.aliases = ["Cozy Bear", "The Dukes"]

            store.groups = {"G0007": group1, "G0016": group2}
            mock.return_value = store
            yield store

    @pytest.mark.asyncio
    async def test_read_groups(self, mock_store: MagicMock):
        """Test reading the groups resource."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_groups_resource

        result = await read_groups_resource()

        assert len(result) == 1
        text = result[0].text
        assert "MITRE ATT&CK Threat Groups" in text
        assert "2 groups" in text
        assert "APT28" in text
        assert "APT29" in text
        assert "Fancy Bear" in text
        assert "Cozy Bear" in text


class TestReadTechniquesResource:
    """Tests for the attack://techniques resource."""

    @pytest.fixture
    def mock_store(self):
        """Create a mock store with sample techniques."""
        with patch("attack_query_mcp.server.get_store") as mock:
            store = MagicMock()

            # Create sample techniques
            tech1 = MagicMock()
            tech1.id = "T1566"
            tech1.name = "Phishing"
            tech1.tactics = ["initial-access"]

            tech2 = MagicMock()
            tech2.id = "T1059"
            tech2.name = "Command and Scripting Interpreter"
            tech2.tactics = ["execution"]

            sub1 = MagicMock()
            sub1.id = "T1566.001"
            sub1.name = "Spearphishing Attachment"
            sub1.tactics = ["initial-access"]

            store.techniques = {
                "T1566": tech1,
                "T1059": tech2,
                "T1566.001": sub1,
            }
            mock.return_value = store
            yield store

    @pytest.mark.asyncio
    async def test_read_techniques(self, mock_store: MagicMock):
        """Test reading the techniques resource."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_techniques_resource

        result = await read_techniques_resource()

        assert len(result) == 1
        text = result[0].text
        assert "MITRE ATT&CK Techniques" in text
        assert "2 techniques" in text
        assert "1 sub-techniques" in text
        assert "T1566" in text
        assert "Phishing" in text
        assert "T1059" in text
        assert "T1566.001" in text
        assert "Spearphishing Attachment" in text


class TestReadTacticsResource:
    """Tests for the attack://tactics resource."""

    @pytest.fixture
    def mock_store(self):
        """Create a mock store with sample tactics."""
        with patch("attack_query_mcp.server.get_store") as mock:
            store = MagicMock()

            tactic1 = MagicMock()
            tactic1.shortname = "TA0001"
            tactic1.name = "Initial Access"
            tactic1.description = "The adversary is trying to get into your network."

            tactic2 = MagicMock()
            tactic2.shortname = "TA0002"
            tactic2.name = "Execution"
            tactic2.description = "The adversary is trying to run malicious code."

            store.tactics = {"initial-access": tactic1, "execution": tactic2}
            mock.return_value = store
            yield store

    @pytest.mark.asyncio
    async def test_read_tactics(self, mock_store: MagicMock):
        """Test reading the tactics resource."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_tactics_resource

        result = await read_tactics_resource()

        assert len(result) == 1
        text = result[0].text
        assert "MITRE ATT&CK Tactics" in text
        assert "2 tactics" in text
        assert "Initial Access" in text
        assert "Execution" in text
        assert "TA0001" in text
        assert "TA0002" in text


class TestReadSoftwareResource:
    """Tests for the attack://software resource."""

    @pytest.fixture
    def mock_store(self):
        """Create a mock store with sample software."""
        with patch("attack_query_mcp.server.get_store") as mock:
            store = MagicMock()

            malware1 = MagicMock()
            malware1.id = "S0001"
            malware1.name = "Trojan"
            malware1.software_type = "malware"
            malware1.platforms = ["Windows", "Linux"]

            tool1 = MagicMock()
            tool1.id = "S0002"
            tool1.name = "Mimikatz"
            tool1.software_type = "tool"
            tool1.platforms = ["Windows"]

            store.software = {"S0001": malware1, "S0002": tool1}
            mock.return_value = store
            yield store

    @pytest.mark.asyncio
    async def test_read_software(self, mock_store: MagicMock):
        """Test reading the software resource."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_software_resource

        result = await read_software_resource()

        assert len(result) == 1
        text = result[0].text
        assert "MITRE ATT&CK Software" in text
        assert "1 malware" in text
        assert "1 tools" in text
        assert "Trojan" in text
        assert "Mimikatz" in text


class TestReadMitigationsResource:
    """Tests for the attack://mitigations resource."""

    @pytest.fixture
    def mock_store(self):
        """Create a mock store with sample mitigations."""
        with patch("attack_query_mcp.server.get_store") as mock:
            store = MagicMock()

            mit1 = MagicMock()
            mit1.id = "M1017"
            mit1.name = "User Training"
            mit1.techniques = ["T1566", "T1566.001", "T1566.002"]

            mit2 = MagicMock()
            mit2.id = "M1031"
            mit2.name = "Network Intrusion Prevention"
            mit2.techniques = ["T1566"]

            store.mitigations = {"M1017": mit1, "M1031": mit2}
            mock.return_value = store
            yield store

    @pytest.mark.asyncio
    async def test_read_mitigations(self, mock_store: MagicMock):
        """Test reading the mitigations resource."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_mitigations_resource

        result = await read_mitigations_resource()

        assert len(result) == 1
        text = result[0].text
        assert "MITRE ATT&CK Mitigations" in text
        assert "2 mitigations" in text
        assert "User Training" in text
        assert "Network Intrusion Prevention" in text
        assert "M1017" in text
        assert "M1031" in text
        # Check technique counts are shown
        assert "3" in text  # M1017 has 3 techniques
        assert "1" in text  # M1031 has 1 technique


class TestReadCampaignsResource:
    """Tests for the attack://campaigns resource."""

    @pytest.fixture
    def mock_store(self):
        """Create a mock store with sample campaigns."""
        with patch("attack_query_mcp.server.get_store") as mock:
            store = MagicMock()

            campaign1 = MagicMock()
            campaign1.id = "C0027"
            campaign1.name = "C0027"
            campaign1.first_seen = "2022-01-01T00:00:00.000Z"
            campaign1.last_seen = "2022-12-31T00:00:00.000Z"
            campaign1.groups = {"G0007"}  # set, not list

            campaign2 = MagicMock()
            campaign2.id = "C0028"
            campaign2.name = "Operation Example"
            campaign2.first_seen = "2023-06-01T00:00:00.000Z"
            campaign2.last_seen = None
            campaign2.groups = set()  # empty set

            # Mock get_group for group name lookup
            group = MagicMock()
            group.name = "APT28"
            store.get_group.return_value = group

            store.campaigns = {"C0027": campaign1, "C0028": campaign2}
            mock.return_value = store
            yield store

    @pytest.mark.asyncio
    async def test_read_campaigns(self, mock_store: MagicMock):
        """Test reading the campaigns resource."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_campaigns_resource

        result = await read_campaigns_resource()

        assert len(result) == 1
        text = result[0].text
        assert "MITRE ATT&CK Campaigns" in text
        assert "2 campaigns" in text
        assert "C0027" in text
        assert "Operation Example" in text
        assert "2022-01" in text
        assert "2022-12" in text
        assert "APT28" in text


class TestReadResourceDispatch:
    """Tests for the read_resource dispatch."""

    @pytest.fixture
    def mock_store(self):
        """Create a minimal mock store."""
        with patch("attack_query_mcp.server.get_store") as mock:
            store = MagicMock()
            store.groups = {}
            store.techniques = {}
            store.tactics = {}
            store.software = {}
            store.mitigations = {}
            store.campaigns = {}
            mock.return_value = store
            yield store

    @pytest.mark.asyncio
    async def test_unknown_resource(self, mock_store: MagicMock):
        """Test reading an unknown resource URI."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_resource

        result = await read_resource("attack://unknown")

        assert len(result) == 1
        assert "Unknown resource" in result[0].text

    @pytest.mark.asyncio
    async def test_read_groups_dispatch(self, mock_store: MagicMock):
        """Test that attack://groups URI dispatches correctly."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_resource

        result = await read_resource("attack://groups")

        assert len(result) == 1
        assert "MITRE ATT&CK Threat Groups" in result[0].text

    @pytest.mark.asyncio
    async def test_read_techniques_dispatch(self, mock_store: MagicMock):
        """Test that attack://techniques URI dispatches correctly."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_resource

        result = await read_resource("attack://techniques")

        assert len(result) == 1
        assert "MITRE ATT&CK Techniques" in result[0].text

    @pytest.mark.asyncio
    async def test_read_tactics_dispatch(self, mock_store: MagicMock):
        """Test that attack://tactics URI dispatches correctly."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_resource

        result = await read_resource("attack://tactics")

        assert len(result) == 1
        assert "MITRE ATT&CK Tactics" in result[0].text

    @pytest.mark.asyncio
    async def test_read_software_dispatch(self, mock_store: MagicMock):
        """Test that attack://software URI dispatches correctly."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_resource

        result = await read_resource("attack://software")

        assert len(result) == 1
        assert "MITRE ATT&CK Software" in result[0].text

    @pytest.mark.asyncio
    async def test_read_mitigations_dispatch(self, mock_store: MagicMock):
        """Test that attack://mitigations URI dispatches correctly."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_resource

        result = await read_resource("attack://mitigations")

        assert len(result) == 1
        assert "MITRE ATT&CK Mitigations" in result[0].text

    @pytest.mark.asyncio
    async def test_read_campaigns_dispatch(self, mock_store: MagicMock):
        """Test that attack://campaigns URI dispatches correctly."""
        _ = mock_store  # Fixture used for side effects
        from attack_query_mcp.resources import read_resource

        result = await read_resource("attack://campaigns")

        assert len(result) == 1
        assert "MITRE ATT&CK Campaigns" in result[0].text
