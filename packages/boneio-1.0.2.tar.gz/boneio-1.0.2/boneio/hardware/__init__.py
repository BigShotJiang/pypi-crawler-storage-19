"""BoneIO hardware abstraction layer."""
