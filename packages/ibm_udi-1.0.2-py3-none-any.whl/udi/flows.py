import json
import logging
import traceback
import warnings
import time
from urllib3.exceptions import InsecureRequestWarning

from .constants import DatasiftSDKConstants, JobStatusConstants
from .exception import ElyraGenerationException, DatasiftSDKException
from .rest_client import RestMethod
from .models.pipeline_model import FlowModel
from http import HTTPStatus

# Suppress only the InsecureRequestWarning
warnings.filterwarnings("ignore", category=InsecureRequestWarning)

# Configure logger
logger = logging.getLogger(__name__)

class Flow:
    def __init__(self, udp_client):
        self.udp_client = udp_client
        self.rest_client = udp_client.rest_client
        self.project_id = udp_client.project_id
        self.udp_url = udp_client.udp_url
        self.base_url = udp_client.base_url

        self.flow_id = None
        self.job_id = None
        self.job_run_id = None
        self.flow_name = None
        
        self._local_params = None
        self._parameter_sets = None

    def _generate_elyra_json(self, pipeline):
        try:
            url = f"{self.udp_url}/sdk/generate_elyra"
            response = self.rest_client.call_rest_json(
                    method=RestMethod.POST,
                    action="Generate flow",
                    url=url,
                    request_body= pipeline,
                    expected_statuses= [HTTPStatus.OK.value,HTTPStatus.BAD_REQUEST.value,HTTPStatus.INTERNAL_SERVER_ERROR.value]
                )
            if not response or isinstance(response, str):
                raise ElyraGenerationException(f"An error occurred during elyra generation. Error: {response}")

            if DatasiftSDKConstants.ERRORS_RESPONSE_KEY in response:
                errors = response.get(DatasiftSDKConstants.ERRORS_RESPONSE_KEY, [])
                raise ElyraGenerationException(f"An error occurred during elyra generation. Error: {json.dumps(errors)}")
            return response
        except ElyraGenerationException:
            raise
        except Exception as ex:
            raise DatasiftSDKException(
                message="Elyra pipeline generation failed.",
                traceback_info=traceback.format_exc(),
            ) from ex
    
    def _build_validation_payload_from_existing_flow(self, flow_obj: dict):
        try:
            entity = flow_obj.get("entity", {})
            metadata = flow_obj.get("metadata", {})
            return {
                "name": entity.get("name"),
                "description": entity.get("description", ""),
                "definition": flow_obj.get("definition"),
                "container_id": metadata.get("project_id"),
                "container_kind": metadata.get("container_kind", "project")
            }
        except Exception as ex:
            raise DatasiftSDKException(
                f"Failed to construct validation request from flow: {str(ex)}",
                traceback_info=traceback.format_exc(),
            )
    
    def _get_job_id_from_flow(self, *, flow_id):
        """
        Fetch job_id attached to an existing flow asset.
        """
        try:
            url = f"{self.base_url}/v2/assets/{flow_id}/attributes/ibm_udp_flow?project_id={self.project_id}"
            response = self.rest_client.call_rest_json(
                method=RestMethod.GET,
                action="Get Flow Job ID",
                url=url
            )
            return response.get("job_id")
        except Exception as ex:
            raise DatasiftSDKException(
                message="Failed to fetch job_id from flow",
                traceback_info=traceback.format_exc(),
            )
    
    def _validate_flow(self, *, elyra_json: dict):
        try:
            url = f"{self.udp_url}/validate_flow"
            # Build request model same as FlowPrototype
            request_body = {
                "name": elyra_json.get("name"),
                "description": elyra_json.get("description", ""),
                "definition": elyra_json.get("definition"),
                "container_id": elyra_json.get("container_id"),
                "container_kind": elyra_json.get("container_kind")
            }
            response = self.rest_client.call_rest_json(
                method=RestMethod.POST,
                action="Validate flow",
                url=url,
                request_body=request_body,
                expected_statuses=[201, 200, 400]
            )

            # If error response (400), raise exception
            if isinstance(response, str):
                raise DatasiftSDKException(f"Flow validation failed: {response}")

            if response.get("status") == "FAILED":
                raise DatasiftSDKException(
                    f"Flow validation errors: {json.dumps(response.get('errors', []))}"
                )

            return response

        except Exception as ex:
            raise DatasiftSDKException(
                f"Flow validation encountered an error: {str(ex)}",
                traceback_info=traceback.format_exc(),
            )


    def create(self, *,pipeline: dict):
        try:
            FlowModel.model_validate(pipeline)
            
            # Extract parameters from pipeline (returns None if not provided)
            local_params = pipeline.get("local_parameters")
            parameter_sets = pipeline.get("parameter_sets")
            
            # Store parameters as instance variables for later use in run()
            self._local_params = local_params
            self._parameter_sets = parameter_sets
            
            # Add local parameters and parameter sets to global_config if provided
            if local_params or parameter_sets:
                # Ensure parameters structure exists
                if "parameters" not in pipeline["global_config"]:
                    pipeline["global_config"]["parameters"] = {
                        "local_parameters": [],
                        "parameter_sets": []
                    }
                
                # Add formatted local parameters
                if local_params:
                    formatted_params = self.create_local_parameters(params=local_params)
                    pipeline["global_config"]["parameters"]["local_parameters"] = formatted_params
                    logger.info(f"Local parameters added to global_config: {len(formatted_params)} parameter(s)")
                
                # Add parameter sets - fetch and format them
                if parameter_sets:
                    formatted_param_sets = self._add_parameter_sets(parameter_sets=parameter_sets)
                    pipeline["global_config"]["parameters"]["parameter_sets"] = formatted_param_sets
                    logger.info(f"Parameter sets added to global_config: {len(formatted_param_sets)} set(s)")
            
            elyra_json = self._generate_elyra_json(pipeline)
            val_response = self._validate_flow(elyra_json=elyra_json)
            logger.info(f"validate flow {val_response}")
            flow_name = pipeline.get("flow_name")
            url = f"{self.udp_url}/flows"
            response = self.rest_client.call_rest_json(method = RestMethod.POST, 
                                                    action="Create Flow",
                                                    url=url,
                                                    request_body=elyra_json,
                                                    expected_statuses=[201,400]
                                                    )
            logger.info(f"Create flow response: {response}")
            self.flow_id = response.get("flow_id")

            if not self.flow_id:
                raise DatasiftSDKException("Flow creation failed: Missing flow_id in response")

            # Create job
            logger.info(f'Flow is created: {self.flow_id}')
            job_name = f'{flow_name}_job'
            create_job_url = f'{self.base_url}/v2/jobs?project_id={self.project_id}'
            logger.debug(f"Create job URL: {create_job_url}")
            logger.debug(f"Flow name: {flow_name}")
            create_job_request_body = {
                "job": {
                    "asset_ref": self.flow_id,
                    "name": job_name,
                    "description": " ",
                    "configuration":{
                        "orchestrator": pipeline["orchestrator"],
                        "runtime_parameters": {},
                        "service_instance": {}
                    }
                }
            }
            
            
            job_response = self.rest_client.call_rest_json(
                method= RestMethod.POST,
                action = "Create Job",
                url = create_job_url,
                request_body=create_job_request_body
            )
            logger.info(f"Job response: {job_response}")
            self.job_id = job_response.get("asset_id")

            if not self.job_id:
                raise DatasiftSDKException("Job creation failed: No job_id found in response")

            # Patch job_id into flow
            patch_url = f"{self.base_url}/v2/assets/{self.flow_id}/attributes/ibm_udp_flow?project_id={self.project_id}"
            response = self.rest_client.call_rest_json(method = RestMethod.PATCH, 
                                                    action="Patch Job",
                                                    url=patch_url,
                                                    request_body=[{"op": "add", "path":"/job_id","value": self.job_id}]
                                                    )

        except Exception as ex:
            raise DatasiftSDKException(f"Flow creation failed: {str(ex)}\n{traceback.format_exc()}")


    def get_job_run_config(self):
        """
        Get the job run configuration that will be used when running the job.
        This allows users to see and modify the configuration before running.

        Returns:
            dict: Job run configuration with parameters
        """
        return self._build_job_run_config()

    def run(self, job_id=None, job_run_config=None):
        """
        Run the job with the configured parameters.

        Args:
            job_id: Optional job ID to run. Uses self.job_id if not provided.
            job_run_config: Optional custom job run configuration. If not provided,
                          uses the default configuration built from flow parameters.
                          Use get_job_run_config() to get the default config and modify it.
        """
        try:
            flow_id = self.flow_id
            if not flow_id and not job_id:
                raise DatasiftSDKException("Either flow_id or job_id must be provided to run the flow.")

            # 1. If job_id is missing, derive from flow_id
            if not job_id:
                job_id = self.job_id or self._get_job_id_from_flow(flow_id)
                if not job_id:
                    raise DatasiftSDKException(f"No job_id associated with flow_id={flow_id}")

            # 2. If flow_id is provided, validate before running
            if flow_id:
                flow_obj = self.get_flow(flow_id=flow_id)
                validation_payload = self._build_validation_payload_from_existing_flow(flow_obj)

                # Validate flow before running job
                self._validate_flow(elyra_json=validation_payload)

            job_run_url = f"{self.base_url}/v2/jobs/{job_id}/runs?project_id={self.project_id}"
            # Use provided config or build default one
            if job_run_config is None:
                job_run_config = self._build_job_run_config()
            
            job_run_payload = {
                "job_run": {
                    "configuration": job_run_config
                }
            }
            res = self.rest_client.call_rest_json(
                method = RestMethod.POST, 
                action = "Run Job",
                url = job_run_url,
                request_body= job_run_payload 
                )
            
            logger.info(f"Job run response: {res}")
            self.job_run_id = res["href"].split("/")[-1].split("?")[0]
        except Exception as ex:
            raise DatasiftSDKException(f"Flow run failed: {str(ex)}\n{traceback.format_exc()}")

    def status(self, *,flow_id=None, job_run_id=None):
        try:
            flow_id = flow_id or self.flow_id
            job_run_id = job_run_id or self.job_run_id
            url = f"{self.udp_url}/flows/{flow_id}/runs/{job_run_id}?container_id={self.project_id}"
            return self.rest_client.call_rest_json(method=RestMethod.GET, action="Get Status", url=url)
        except Exception as ex:
            raise DatasiftSDKException(f"Status check failed: {str(ex)}")

    def logs(self, *, job_id=None, job_run_id=None):
        try:
            job_id = job_id or self.job_id
            job_run_id = job_run_id or self.job_run_id
            url = f"{self.udp_url}/flows/get_execution_logs/{self.job_id}/{self.job_run_id}?container_id={self.project_id}"
            return self.rest_client.call_rest_json(method=RestMethod.GET, action="Get Logs", url=url)
        except Exception as ex:
            raise DatasiftSDKException(f"Fetching logs failed: {str(ex)}")

    def cancel(self, *,flow_id=None, job_run_id=None):
        try:
            flow_id = flow_id or self.flow_id
            job_run_id = job_run_id or self.job_run_id
            url = f"{self.udp_url}/flows/{flow_id}/runs/{job_run_id}"
            response = self.rest_client.call_rest_json(method=RestMethod.DELETE, action="Cancel Execution", url=url)
            return {"status": "Cancelled"} if response == "OK" else {"status": "Failed to cancel"}
        except Exception as ex:
            raise DatasiftSDKException(f"Cancellation failed: {str(ex)}")

    def delete(self,*,flow_id=None):
        try:
            flow_id = flow_id or self.flow_id
            url = f"{self.udp_url}/flows/{flow_id}?container_kind=project&container_id={self.project_id}"
            return self.rest_client.call_rest_json(method=RestMethod.DELETE, action="Delete Flow", url=url)
        except Exception as ex:
            raise DatasiftSDKException(f"Flow deletion failed: {str(ex)}")
    
    def get_flow(self, *,flow_id=None):
        try:
            flow_id = flow_id or self.flow_id
            url = f"{self.udp_url}/flows/{flow_id}?container_kind=project&container_id={self.project_id}"
            return self.rest_client.call_rest_json(
                method=RestMethod.GET,
                action="Get Flow",
                url=url
            )
        except Exception as ex:
            raise DatasiftSDKException(f"Get flow failed: {str(ex)}")
    
    def update_flow(self, *,pipeline: dict, flow_id=None):
        """
        Update the flow with a new elyra pipeline definition.
        """
        try:
            
            flow_id = flow_id or self.flow_id
            new_flow = self._generate_elyra_json(pipeline)
            self._validate_flow(elyra_json=new_flow)
            url = f"{self.udp_url}/flows/{flow_id}"
            response = self.rest_client.call_rest_json(
                method=RestMethod.PUT,
                action="Update flow",
                url=url,
                request_body=new_flow
            )
            return response
        except Exception:
            raise DatasiftSDKException(message="Flow not found", traceback_info=traceback.format_exc())

    
    def poll_flow_status(self, *,flow_id=None, job_run_id=None, interval=10, timeout=600):
        flow_id = flow_id or self.flow_id
        job_run_id = job_run_id or self.job_run_id
        elapsed_time = 0
        status_url = f"{self.udp_url}/flows/{flow_id}/runs/{job_run_id}?container_id={self.project_id}"

        while elapsed_time < timeout:
            response = self.rest_client.call_rest_json(
                method="GET",
                action="Poll Flow Execution Status",
                url=status_url
            )

            status = response.get("status", "unknown")
            logger.info(f"[{elapsed_time}s] Current status: {status}")

            if status in [JobStatusConstants.CANCELED, JobStatusConstants.FAILED, JobStatusConstants.COMPLETED,
                          JobStatusConstants.COMPLETED_WITH_ERRORS, JobStatusConstants.COMPLETED_WITH_WARNINGS]:
                logger.info(f"Final status: {status}")
                return status

            time.sleep(interval)
            elapsed_time += interval

        raise TimeoutError("Flow status polling timed out.")
    
    def _get_node_id_from_operator_name(self, *, operator_name, flow_id):
        
        try:
            flow_data = self.get_flow(flow_id=flow_id)
            
            definition = flow_data.get('definition', {})
            pipelines = definition.get('pipelines', [])
            
            if not pipelines:
                raise DatasiftSDKException("No pipelines found in flow definition")
            
            nodes = pipelines[0].get('nodes', [])
            
            if not nodes:
                raise DatasiftSDKException("No nodes found in pipeline")
            
            for node in nodes:
                if node.get('op') == operator_name:
                    return node.get('id')
            
            raise DatasiftSDKException(
                f"Operator '{operator_name}' not found in flow. "
                f"Available operators: {[node.get('op') for node in nodes]}"
            )
            
        except DatasiftSDKException:
            raise
        except Exception as ex:
            raise DatasiftSDKException(
                f"Failed to get node_id for operator '{operator_name}': {str(ex)}\n{traceback.format_exc()}"
            )
    
    def peekin(self, *, operator_name, job_id=None, job_run_id=None, flow_id=None, limit=10, offset=0):

        try:
            job_id = job_id or self.job_id
            job_run_id = job_run_id or self.job_run_id
            flow_id = flow_id or self.flow_id
            
            # Validate required parameters
            if not job_id:
                raise DatasiftSDKException("job_id is required for peekin")
            if not job_run_id:
                raise DatasiftSDKException("job_run_id is required for peekin")
            if not flow_id:
                raise DatasiftSDKException("flow_id is required for peekin")
            
            node_id = self._get_node_id_from_operator_name(operator_name=operator_name, flow_id=flow_id)
            
            url=f"{self.udp_url}/flows/job_run_node_data?container_id={self.project_id}&job_id={job_id}&job_run_id={job_run_id}&node_id={node_id}&container_kind=project&limit={limit}&offset={offset}"
    
            response = self.rest_client.call_rest_json(
                method=RestMethod.GET,
                action="PeekIn Node Data",
                url=url
            )
            
            return response
            
        except DatasiftSDKException:
            raise
        except Exception as ex:
            raise DatasiftSDKException(
                f"PeekIn failed for operator '{operator_name}': {str(ex)}\n{traceback.format_exc()}"
            )
    
    def _add_parameter_sets(self, *, parameter_sets: dict):
        """
        Format parameter sets from user input format to the required structure.
        User provides: {'Parameter_1': '2d9b9cf3-d78c-41cd-b934-c1c472ffe7fe'}
        This method fetches the parameter set details and formats them.

        Args:
            parameter_sets: Dictionary mapping parameter set names to their asset IDs

        Returns:
            list: Formatted parameter sets for global_config
        """
        formatted_sets = []

        for param_name, asset_id in parameter_sets.items():
            try:
                param_set = self.udp_client.get_parameter_set_by_id(asset_id)

                if isinstance(param_set, dict) and "error" in param_set:
                    raise DatasiftSDKException(f"Error fetching parameter set: {param_set['error']}")

                if not param_set:
                    raise DatasiftSDKException(f"Parameter set '{param_name}' with ID '{asset_id}' not found or empty")

                formatted_set = {
                    "id": asset_id,
                    "name": param_set.get("name", param_name),
                    "parameters": param_set.get("parameters", []),
                    "value_sets": param_set.get("value_sets", []),
                    "project_ref": self.project_id,
                    "node_ids": []
                }

                formatted_sets.append(formatted_set)
                logger.info(f"Parameter set '{param_name}' (ID: {asset_id}) fetched and formatted successfully")

            except Exception as ex:
                raise DatasiftSDKException(
                    f"Failed to fetch or format parameter set '{param_name}' with ID '{asset_id}': {str(ex)}\n{traceback.format_exc()}"
                )

        return formatted_sets

    def _build_job_run_config(self):
        """
        Build job run configuration with parameters if they exist.
        Retrieves parameters from the flow's global_config instead of recreating them.

        Returns:
            dict: Job run configuration with parameters
        """
        try:
            # Get the flow to retrieve global_config parameters
            flow_data = self.get_flow()

            # Navigate through the flow structure to get global_config parameters
            definition = flow_data.get('definition', {})
            pipelines = definition.get('pipelines', [])

            if not pipelines:
                return {}

            app_data = pipelines[0].get('app_data', {})
            ds_flow = app_data.get('ds_flow', {})
            global_config = ds_flow.get('global_config', {})
            parameters = global_config.get('parameters', {})

            local_params = parameters.get('local_parameters', [])
            parameter_sets = parameters.get('parameter_sets', [])

            # Filter and simplify local parameters (only those with node_ids)
            simplified_local_params = [
                {"id": param["id"], "name": param["name"], "value": param["value"]}
                for param in local_params if param.get('node_ids', [])
            ]
            
            # Filter and simplify parameter sets (only include parameters with node_ids)
            simplified_param_sets = []
            for param_set in parameter_sets:
                # Filter parameters within the set that have node_ids
                used_params = [
                    {"name": param["name"], "value": param["value"]}
                    for param in param_set.get('parameters', [])
                    if param.get('node_ids', [])
                ]
                
                # Only add parameter set if it has at least one used parameter
                if used_params:
                    simplified_param_sets.append({
                        "id": param_set["id"],
                        "name": param_set["name"],
                        "value_sets": [{"name": "default", "values": used_params}],
                        "project_ref": param_set.get("project_ref")
                    })

            # Build job run configuration if any parameters exist
            if simplified_local_params or simplified_param_sets:
                if simplified_local_params:
                    logger.info(f"Local parameters added to job run configuration: {len(simplified_local_params)} parameter(s)")
                if simplified_param_sets:
                    logger.info(f"Parameter sets added to job run configuration: {len(simplified_param_sets)} set(s)")
                
                return {
                    "parameters": {
                        "local_parameters": simplified_local_params,
                        "parameter_sets": simplified_param_sets
                    }
                }
            
            return {}
        except Exception as ex:
            # If flow retrieval fails or parameters don't exist, return empty config
            logger.warning(f"Could not retrieve parameters from flow: {str(ex)}")
            return {}
    
    def create_local_parameters(self, *, params):
        # Type mapping from user-friendly to internal types
        TYPE_MAPPING = {
            "string": "string",
            "integer": "int64",
            "double": "double",
            "float": "sfloat",
            "json object": "json",
            "instance(crn)": "string",
            "boolean": "boolean",
            "time": "time",
            "date": "date",
            "timestamp": "timestamp"
        }
        
        local_parameters = []
        
        # Convert dict to list format for uniform processing
        if isinstance(params, dict):
            params_list = [
                {"name": name, **config}
                for name, config in params.items()
            ]
        else:
            params_list = params
        
        for param in params_list:
            # Validate required fields
            if "name" not in param or "type" not in param or "value" not in param:
                raise DatasiftSDKException(
                    f"Parameter must have 'name', 'type', and 'value': {param}"
                )
            
            # Normalize type to lowercase for mapping
            user_type = param["type"].lower()
            
            # Map user type to internal type
            if user_type not in TYPE_MAPPING:
                raise DatasiftSDKException(
                    f"Unsupported type '{param['type']}'. Supported types: "
                    f"String, Integer, Double, Float, Boolean, Date, Time, "
                    f"Timestamp, JSON object"
                )
            
            internal_type = TYPE_MAPPING[user_type]
            value = param["value"]
            
            # Determine subtype based on value
            if isinstance(value, list):
                subtype = "list"
            else:
                subtype = "single"
            
            # Validate value type matches declared type
            self._validate_parameter_value(param_type=internal_type, value=value, param_name=param["name"])
            
            # Build formatted parameter
            formatted_param = {
                "id": param["name"],
                "name": param["name"],
                "prompt": param.get("prompt", ""),
                "type": internal_type,
                "subtype": subtype,
                "value": value,
                "node_ids": []
            }
            
            local_parameters.append(formatted_param)
        
        return local_parameters
    
    def _validate_parameter_value(self, *, param_type, value, param_name):
        """
        Validate that the value matches the declared parameter type.
        
        Args:
            param_type: Internal type (int64, float64, string, etc.)
            value: The actual value (can be single value or list)
            param_name: Name of parameter for error messages
        
        Raises:
            DatasiftSDKException: If validation fails
        """
        # Handle list values
        if isinstance(value, list):
            if not value:
                raise DatasiftSDKException(
                    f"Parameter '{param_name}': List value cannot be empty"
                )
            # Validate each item in the list
            for item in value:
                self._validate_single_value(param_type=param_type, value=item, param_name=param_name)
        else:
            self._validate_single_value(param_type=param_type, value=value, param_name=param_name)
    
    def _validate_single_value(self, *, param_type, value, param_name):
        """
        Validate a single value against its type.
        
        Args:
            param_type: Internal type (int64, sfloat, string, etc.)
            value: The actual value to validate
            param_name: Name of parameter for error messages
        
        Raises:
            DatasiftSDKException: If validation fails
        """
        try:
            if param_type == "int64":
                if not isinstance(value, int) or isinstance(value, bool):
                    raise ValueError()
            elif param_type == "sfloat":
                if not isinstance(value, (int, float)) or isinstance(value, bool):
                    raise ValueError()
            elif param_type == "string":
                if not isinstance(value, str):
                    raise ValueError()
            elif param_type == "boolean":
                if not isinstance(value, bool):
                    raise ValueError()
            elif param_type == "json":
                if isinstance(value, str):
                    json.loads(value)  # Validate JSON string
                elif not isinstance(value, dict):
                    raise ValueError()
            elif param_type in ["date", "time", "timestamp"]:
                if not isinstance(value, str):
                    raise ValueError()
        except (ValueError, json.JSONDecodeError):
            raise DatasiftSDKException(
                f"Parameter '{param_name}': Value '{value}' does not match type '{param_type}'"
            )
