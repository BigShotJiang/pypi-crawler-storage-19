"""
SafeKeyLab SDK - Enterprise PII Detection, Data Protection, and LLM Security

Enhanced LLM Guard Features:
- Semantic Attack Graph Detection
- Adversarial Perturbation Detection
- Cross-Modal Injection Detection
- Temporal Attack Sequence Detection
- Threat Actor Fingerprinting
- Attack Tool Signature Detection
- Explainability (Counterfactual, SHAP Attribution)
- Formal Detection Guarantees

Integrations:
- Google ADK (Agent Development Kit)
- LangChain
- OpenAI
- Anthropic

Patent Pending - SafeKey Lab, Inc.
"""

__version__ = "3.2.0"
__author__ = "SafeKey Lab Inc."

from .client import SafeKeyLab
from .client_v2 import (
    SafeKeyLabClient as SafeKeyLabClientV2,
    RateLimitException,
    QuotaExceededException,
    FeatureNotAvailableException,
    create_client,
)
from .scanner import PIIScanner
from .protector import DataProtector
from .exceptions import SafeKeyLabException, APIError, ValidationError

# New unified client with protect() API
from .unified_client import SafeKeyClient, SafeKeyLabClient
from .result_types import (
    PIIEntity,
    ProtectionResult,
    DetectionResult,
    BatchItem,
    BatchResult,
    HealthCheckResult,
    UsageInfo,
)

# Google ADK integration
from .integrations.google_adk import (
    create_pii_protection_tool,
    create_secret_detection_tool,
    create_output_scanner_tool,
    SafeKeyLabADKTools,
    ProtectedRunner,
    protect_input,
    scan_output_decorator,
)

# LangChain integration (conditionally available)
try:
    from .integrations.langchain import (
        SafeKeyLabCallbackHandler,
        SafeKeyLabPIIProtectionTool,
        SafeKeyLabPIIDetectionTool,
        create_protected_chain,
        SafeKeyLabRetrieverWrapper,
        get_langchain_tools,
        PIIDetectedError,
    )
    LANGCHAIN_AVAILABLE = True
except ImportError:
    LANGCHAIN_AVAILABLE = False
from .llm_guard import (
    # Core Client
    LLMGuardClient,
    # High-level interfaces
    ThreatDetector,
    ComplianceManager,
    ThreatIntelligence,
    Explainer,
    # Data classes
    ThreatLevel,
    DetectionMode,
    ThreatDetection,
    DetectionResult,
    ConversationAnalysis,
    ThreatFingerprint,
    # Exceptions
    LLMGuardError,
    RateLimitError,
    SessionError,
    # Convenience function
    guard_prompt,
)

__all__ = [
    # Core clients
    "SafeKeyLab",
    "SafeKeyClient",  # New unified client with protect() API
    "SafeKeyLabClient",
    "SafeKeyLabClientV2",
    "create_client",
    "RateLimitException",
    "QuotaExceededException",
    "FeatureNotAvailableException",
    # Result types
    "PIIEntity",
    "ProtectionResult",
    "DetectionResult",
    "BatchItem",
    "BatchResult",
    "HealthCheckResult",
    "UsageInfo",
    # PII detection
    "PIIScanner",
    "DataProtector",
    # Exceptions
    "SafeKeyLabException",
    "APIError",
    "ValidationError",
    # Google ADK Integration
    "create_pii_protection_tool",
    "create_secret_detection_tool",
    "create_output_scanner_tool",
    "SafeKeyLabADKTools",
    "ProtectedRunner",
    "protect_input",
    "scan_output_decorator",
    # LangChain Integration
    "SafeKeyLabCallbackHandler",
    "SafeKeyLabPIIProtectionTool",
    "SafeKeyLabPIIDetectionTool",
    "create_protected_chain",
    "SafeKeyLabRetrieverWrapper",
    "get_langchain_tools",
    "PIIDetectedError",
    "LANGCHAIN_AVAILABLE",
    # LLM Guard - Core Client
    "LLMGuardClient",
    # LLM Guard - High-level interfaces
    "ThreatDetector",
    "ComplianceManager",
    "ThreatIntelligence",
    "Explainer",
    # LLM Guard - Data classes
    "ThreatLevel",
    "DetectionMode",
    "ThreatDetection",
    "ConversationAnalysis",
    "ThreatFingerprint",
    # LLM Guard - Exceptions
    "LLMGuardError",
    "RateLimitError",
    "SessionError",
    # LLM Guard - Convenience function
    "guard_prompt",
]
