"""Tests for chromium-sync."""
