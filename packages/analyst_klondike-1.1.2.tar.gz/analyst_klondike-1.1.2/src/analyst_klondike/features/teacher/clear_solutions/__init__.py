from dataclasses import dataclass
from analyst_klondike.state.app_state import AppState
from analyst_klondike.state.base_action import BaseAction


@dataclass
class ClearSolutionsAction(BaseAction):
    type = "CLEAR_SOLUTIONS_ACTION"


def apply(state: AppState, action: BaseAction) -> AppState:
    if isinstance(action, ClearSolutionsAction):
        for task in state.data.tasks.values():
            task.code = task.code_template
            task.is_passed = "not_runned"

    return state
