from analyst_klondike.features.code import code_reducer
from analyst_klondike.features.code_explorer import code_explorer_reducer

from analyst_klondike.features.data_context import load_file_reducer
from analyst_klondike.features.app import app_reducer
from analyst_klondike.features.code_import.ui_actions import code_import_reducer
from analyst_klondike.features.events import events_reducer
import analyst_klondike.features.teacher.create_file as create_file_feature
import analyst_klondike.features.teacher.create_quiz as create_quiz_feature
import analyst_klondike.features.teacher.create_task as create_task_feature
import analyst_klondike.features.teacher.edit_task as edit_task_feature
import analyst_klondike.features.teacher.clear_solutions as clear_solutions_feature
from analyst_klondike.state.app_state import dispatch

from analyst_klondike.state.base_action import BaseAction


def app_dispatch(action: BaseAction):
    dispatch(action,
             load_file_reducer.apply,
             code_explorer_reducer.apply,
             code_reducer.apply,
             app_reducer.apply,
             code_import_reducer.apply,
             events_reducer.apply,
             create_quiz_feature.apply,
             create_file_feature.apply,
             create_task_feature.apply,
             edit_task_feature.apply,
             clear_solutions_feature.apply)
