"""
Test suite for Magneto
"""

