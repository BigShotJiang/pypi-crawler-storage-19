"""Tests for mbuzz SDK."""
