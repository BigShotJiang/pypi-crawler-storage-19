"""Go module dependency parser."""
