"""Rust lockfile dependency parser."""
