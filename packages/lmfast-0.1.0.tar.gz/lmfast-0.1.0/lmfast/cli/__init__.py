"""CLI module initialization."""
