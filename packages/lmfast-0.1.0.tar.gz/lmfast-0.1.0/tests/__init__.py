"""
Tests package initialization.
"""
