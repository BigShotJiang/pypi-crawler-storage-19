import polars as pl
from lightgbm import LGBMRegressor
from sklearn.metrics import mean_absolute_error

from examples import get_sub_sample_nba_data
from spforge import FeatureGeneratorPipeline
from spforge.autopipeline import AutoPipeline
from spforge.cross_validator import MatchKFoldCrossValidator
from spforge.data_structures import ColumnNames
from spforge.estimator import (
    NegativeBinomialEstimator,
    SkLearnEnhancerEstimator,
)
from spforge.feature_generator import (
    LagTransformer,
    RollingWindowTransformer,
)
from spforge.scorer import Filter, Operator, OrdinalLossScorer, SklearnScorer
from spforge.transformers import EstimatorTransformer

df = get_sub_sample_nba_data(as_polars=True, as_pandas=False)
column_names = ColumnNames(
    team_id="team_id",
    match_id="game_id",
    start_date="start_date",
    player_id="player_id",
)
df = df.sort(
    [
        column_names.start_date,
        column_names.match_id,
        column_names.team_id,
        column_names.player_id,
    ]
)

df = df.with_columns(pl.col("points").clip(0, 40).alias("points"))

features_generator = FeatureGeneratorPipeline(
    column_names=column_names,
    feature_generators=[
        RollingWindowTransformer(features=["points"], window=15, granularity=["player_id"]),
        LagTransformer(features=["points"], lag_length=3, granularity=["player_id"]),
    ],
)
df = features_generator.fit_transform(df)
predictor = NegativeBinomialEstimator(
    max_value=40,
    point_estimate_pred_column="points_estimate",
    r_specific_granularity=["player_id"],
    predicted_r_weight=1,
    column_names=column_names,
)

pipeline = AutoPipeline(
    estimator=predictor,
    feature_names=features_generator.features_out,
    context_feature_names=[
        column_names.player_id,
        column_names.start_date,
        column_names.team_id,
        column_names.match_id,
    ],
    predictor_transformers=[
        EstimatorTransformer(
            prediction_column_name="points_estimate",
            estimator=SkLearnEnhancerEstimator(
                estimator=LGBMRegressor(verbose=-100, random_state=42),
                date_column=column_names.start_date,
                day_weight_epsilon=0.1,
            ),
        )
    ],
)

cross_validator = MatchKFoldCrossValidator(
    date_column_name=column_names.start_date,
    match_id_column_name=column_names.match_id,
    estimator=pipeline,
    prediction_column_name="points_probabilities",
    target_column="points",
    features=pipeline.context_feature_names + pipeline.feature_names,
)
validation_df = cross_validator.generate_validation_df(df=df)

mean_absolute_scorer = SklearnScorer(
    pred_column=pipeline.predictor_transformers[0].prediction_column_name,
    target=cross_validator.target_column,
    scorer_function=mean_absolute_error,
    validation_column="is_validation",
    filters=[Filter(column_name="minutes", value=0, operator=Operator.GREATER_THAN)],
)

mae_score = mean_absolute_scorer.score(validation_df)
print(f"MAE {mae_score}")

ordinal_scorer = OrdinalLossScorer(
    pred_column=cross_validator.prediction_column_name,
    target=cross_validator.target_column,
    validation_column="is_validation",
    filters=[Filter(column_name="minutes", value=0, operator=Operator.GREATER_THAN)],
    classes=range(0, predictor.max_value + 1),
)
ordinal_loss_score = ordinal_scorer.score(validation_df)

print(f"Ordinal Loss {ordinal_loss_score}")
