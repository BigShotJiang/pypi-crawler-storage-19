"""Claude-tmux: Manage multiple Claude Code instances with tmux."""

__version__ = "0.3.0"
