"""定时任务调度器 - 重构版本

使用新模块：
- ConfigManager 获取配置
- TextProcessor 处理消息文本
- StateStore 持久化任务执行记录

新增功能：
- 任务执行记录（持久化到StateStore）
- 任务执行失败日志
- 支持手动触发任务执行
"""
import logging
import re
import asyncio
import random
from typing import Dict, Any, List, Optional, TYPE_CHECKING
from datetime import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from ..utils.text_processor import TextProcessor

if TYPE_CHECKING:
    from ..clients.qianxun import QianXunClient
    from ..core.config_manager import ConfigManager
    from ..core.state_store import StateStore
    from ..core.log_collector import LogCollector

logger = logging.getLogger(__name__)


class TaskScheduler:
    """定时任务调度器 - 重构版本"""
    
    def __init__(
        self,
        qianxun_client: "QianXunClient",
        config_manager: "ConfigManager",
        state_store: "StateStore",
        log_collector: "LogCollector"
    ):
        """初始化定时任务调度器
        
        Args:
            qianxun_client: 千寻客户端
            config_manager: 配置管理器
            state_store: 状态存储器
            log_collector: 日志收集器
        """
        self.qianxun = qianxun_client
        self.config_manager = config_manager
        self.state_store = state_store
        self.log_collector = log_collector
        self.text_processor = TextProcessor()
        
        self.scheduler = AsyncIOScheduler()
        self.robot_wxid: Optional[str] = None
        
        # 任务执行历史（内存中保留最近100条）
        self._task_history: List[Dict[str, Any]] = []
        self._max_history = 100
    
    @property
    def _config(self) -> Dict[str, Any]:
        """获取当前配置"""
        return self.config_manager.config
    
    @property
    def _rate_limit(self) -> Dict[str, Any]:
        """获取限流配置"""
        return self.config_manager.get_rate_limit_config()
    
    async def _random_delay(self):
        """随机延迟，模拟人工操作"""
        min_interval = self._rate_limit.get('min_interval', 2)
        max_interval = self._rate_limit.get('max_interval', 5)
        delay = random.uniform(min_interval, max_interval)
        await asyncio.sleep(delay)
    
    def set_robot_wxid(self, wxid: str):
        """设置机器人wxid"""
        self.robot_wxid = wxid
        logger.info(f"调度器设置机器人wxid: {wxid}")
    
    def start(self):
        """启动调度器"""
        # 从配置获取机器人wxid
        robot_wxid = self.config_manager.robot_wxid
        if robot_wxid:
            self.robot_wxid = robot_wxid
            logger.info(f"从配置加载机器人wxid: {robot_wxid}")
        
        self._setup_nickname_check_tasks()
        self._setup_scheduled_reminders()
        
        if self.scheduler.get_jobs():
            self.scheduler.start()
            logger.info(f"定时任务调度器已启动，共 {len(self.scheduler.get_jobs())} 个任务")
            for job in self.scheduler.get_jobs():
                try:
                    next_run = job.next_run_time if hasattr(job, 'next_run_time') else None
                    logger.info(f"  - {job.id}: 下次执行 {next_run}")
                except:
                    logger.info(f"  - {job.id}")
        else:
            logger.info("没有启用的定时任务")
    
    def stop(self):
        """停止调度器"""
        self.scheduler.shutdown()
        logger.info("定时任务调度器已停止")

    def _parse_cron(self, cron_expr: str) -> dict:
        """解析Cron表达式"""
        parts = cron_expr.split()
        
        if len(parts) == 6:
            return {
                'second': parts[0],
                'minute': parts[1],
                'hour': parts[2],
                'day': parts[3],
                'month': parts[4],
                'day_of_week': parts[5].replace('?', '*')
            }
        elif len(parts) == 5:
            return {
                'minute': parts[0],
                'hour': parts[1],
                'day': parts[2],
                'month': parts[3],
                'day_of_week': parts[4].replace('?', '*')
            }
        else:
            raise ValueError(f"无效的Cron表达式: {cron_expr}")
    
    def _setup_nickname_check_tasks(self):
        """设置昵称检测任务"""
        nickname_checks = self.config_manager.get_nickname_check_tasks()
        
        for task in nickname_checks:
            if not task.get('enabled', False):
                continue
            
            task_id = task.get('task_id', 'unnamed')
            cron_expr = task.get('cron', '')
            
            if not cron_expr:
                continue
            
            try:
                cron_params = self._parse_cron(cron_expr)
                trigger = CronTrigger(**cron_params)
                
                self.scheduler.add_job(
                    self._run_nickname_check,
                    trigger,
                    args=[task],
                    id=f"nickname_check_{task_id}",
                    replace_existing=True
                )
                logger.info(f"已添加昵称检测任务: {task_id}, cron={cron_expr}")
            except Exception as e:
                logger.error(f"添加昵称检测任务失败 {task_id}: {e}")
    
    def _setup_scheduled_reminders(self):
        """设置定时提醒任务"""
        reminders = self.config_manager.get_scheduled_reminders()
        
        for idx, task in enumerate(reminders):
            if not task.get('enabled', False):
                continue
            
            task_name = task.get('task_name', f'reminder_{idx}')
            cron_expr = task.get('cron', '')
            
            if not cron_expr:
                continue
            
            try:
                cron_params = self._parse_cron(cron_expr)
                trigger = CronTrigger(**cron_params)
                
                self.scheduler.add_job(
                    self._run_scheduled_reminder,
                    trigger,
                    args=[task],
                    id=f"reminder_{task_name}_{idx}",
                    replace_existing=True
                )
                logger.info(f"已添加定时提醒任务: {task_name}, cron={cron_expr}")
            except Exception as e:
                logger.error(f"添加定时提醒任务失败 {task_name}: {e}")
    
    def _record_task_execution(
        self, 
        task_id: str, 
        task_type: str, 
        status: str, 
        details: Optional[str] = None
    ):
        """记录任务执行历史
        
        Args:
            task_id: 任务ID
            task_type: 任务类型（nickname_check, scheduled_reminder）
            status: 执行状态（success, failed）
            details: 详细信息
        """
        record = {
            "task_id": task_id,
            "task_type": task_type,
            "executed_at": datetime.now().isoformat(),
            "status": status,
            "details": details
        }
        
        self._task_history.append(record)
        
        # 限制历史记录数量
        if len(self._task_history) > self._max_history:
            self._task_history = self._task_history[-self._max_history:]
        
        logger.info(f"任务执行记录: {task_id} - {status}")
    
    def get_task_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """获取任务执行历史
        
        Args:
            limit: 返回条数限制
            
        Returns:
            任务执行历史列表（最新的在前）
        """
        return list(reversed(self._task_history))[:limit]
    
    def get_tasks(self) -> List[Dict[str, Any]]:
        """获取所有定时任务信息
        
        Returns:
            任务列表
        """
        tasks = []
        
        # 昵称检测任务
        for task in self.config_manager.get_nickname_check_tasks():
            task_id = task.get('task_id', 'unnamed')
            job = self.scheduler.get_job(f"nickname_check_{task_id}")
            tasks.append({
                "id": f"nickname_check_{task_id}",
                "name": task_id,
                "type": "nickname_check",
                "cron": task.get('cron', ''),
                "enabled": task.get('enabled', False),
                "next_run": job.next_run_time.isoformat() if job and job.next_run_time else None
            })
        
        # 定时提醒任务
        for idx, task in enumerate(self.config_manager.get_scheduled_reminders()):
            task_name = task.get('task_name', f'reminder_{idx}')
            job = self.scheduler.get_job(f"reminder_{task_name}_{idx}")
            tasks.append({
                "id": f"reminder_{task_name}_{idx}",
                "name": task_name,
                "type": "scheduled_reminder",
                "cron": task.get('cron', ''),
                "enabled": task.get('enabled', False),
                "next_run": job.next_run_time.isoformat() if job and job.next_run_time else None
            })
        
        return tasks

    async def run_task_manually(self, task_id: str) -> Dict[str, Any]:
        """手动触发任务执行
        
        Args:
            task_id: 任务ID（如 nickname_check_xxx 或 reminder_xxx_0）
            
        Returns:
            执行结果
        """
        logger.info(f"手动触发任务: {task_id}")
        
        try:
            if task_id.startswith("nickname_check_"):
                # 查找对应的昵称检测任务
                check_id = task_id.replace("nickname_check_", "")
                for task in self.config_manager.get_nickname_check_tasks():
                    if task.get('task_id') == check_id:
                        await self._run_nickname_check(task)
                        return {"status": "success", "message": f"任务 {task_id} 执行完成"}
                return {"status": "error", "message": f"未找到任务: {task_id}"}
            
            elif task_id.startswith("reminder_"):
                # 查找对应的定时提醒任务
                for idx, task in enumerate(self.config_manager.get_scheduled_reminders()):
                    task_name = task.get('task_name', f'reminder_{idx}')
                    if task_id == f"reminder_{task_name}_{idx}":
                        await self._run_scheduled_reminder(task)
                        return {"status": "success", "message": f"任务 {task_id} 执行完成"}
                return {"status": "error", "message": f"未找到任务: {task_id}"}
            
            else:
                return {"status": "error", "message": f"未知任务类型: {task_id}"}
                
        except Exception as e:
            logger.error(f"手动执行任务失败 {task_id}: {e}", exc_info=True)
            return {"status": "error", "message": str(e)}
    
    async def _run_nickname_check(self, task: dict):
        """执行昵称检测任务"""
        if not self.robot_wxid:
            logger.warning("机器人wxid未设置，跳过昵称检测")
            return
        
        task_id = task.get('task_id', 'unnamed')
        target_groups = task.get('target_groups', [])
        exclude_users = task.get('exclude_users', [])
        regex_pattern = task.get('regex', '')
        message_tpl = task.get('message_tpl', '⚠️ @{user} 您的昵称不规范，请及时修改。')
        
        if not target_groups or not regex_pattern:
            return
        
        logger.info(f"开始执行昵称检测任务: {task_id}")
        
        try:
            pattern = re.compile(regex_pattern)
        except re.error as e:
            logger.error(f"正则表达式无效 {task_id}: {e}")
            self._record_task_execution(task_id, "nickname_check", "failed", f"正则表达式无效: {e}")
            return
        
        try:
            for group_id in target_groups:
                await self._check_group_nicknames(
                    group_id, pattern, exclude_users, message_tpl, task_id
                )
            
            self._record_task_execution(task_id, "nickname_check", "success")
            
        except Exception as e:
            logger.error(f"昵称检测任务执行失败 {task_id}: {e}", exc_info=True)
            self._record_task_execution(task_id, "nickname_check", "failed", str(e))
    
    async def _check_group_nicknames(
        self, 
        group_id: str, 
        pattern: re.Pattern, 
        exclude_users: List[str],
        message_tpl: str,
        task_id: str
    ):
        """检测单个群的昵称"""
        logger.info(f"检测群 {group_id} 的昵称")
        
        members = await self.qianxun.get_group_member_list(
            self.robot_wxid, group_id, get_nick=True, refresh=True
        )
        
        if not members:
            logger.warning(f"获取群 {group_id} 成员列表失败或为空")
            return
        
        non_compliant = []
        for member in members:
            wxid = member.get('wxid', '')
            nick = member.get('groupNick', '')
            
            if wxid in exclude_users:
                continue
            
            if nick and not pattern.match(nick):
                non_compliant.append({'wxid': wxid, 'nick': nick})
        
        if not non_compliant:
            logger.info(f"群 {group_id} 所有成员昵称均合规")
            return
        
        logger.info(f"群 {group_id} 有 {len(non_compliant)} 人昵称不合规")
        
        at_codes = [f"[@,wxid={m['wxid']},nick=,isAuto=true]" for m in non_compliant]
        at_str = " ".join(at_codes)
        message = message_tpl.replace('{user}', at_str)
        
        # 使用 TextProcessor 把 \n 字符串转换为真正的换行符
        message = self.text_processor.config_to_text(message)
        
        logger.debug(f"发送消息内容: {repr(message)}")
        
        await self._random_delay()
        await self.qianxun.send_text(self.robot_wxid, group_id, message)
        nicks = ", ".join([m['nick'] for m in non_compliant])
        logger.info(f"已发送昵称提醒: {nicks}")
    
    async def _run_scheduled_reminder(self, task: dict):
        """执行定时提醒任务"""
        if not self.robot_wxid:
            logger.warning("机器人wxid未设置，跳过定时提醒")
            return
        
        task_name = task.get('task_name', 'unnamed')
        target_groups = task.get('target_groups', [])
        mention_users = task.get('mention_users', [])
        content = task.get('content', '')
        
        if not target_groups or not content:
            return
        
        logger.info(f"开始执行定时提醒任务: {task_name}")
        
        try:
            at_prefix = ""
            if mention_users:
                if "all" in mention_users:
                    at_prefix = "[@,wxid=all,nick=,isAuto=true] "
                else:
                    at_codes = [f"[@,wxid={uid},nick=,isAuto=true]" for uid in mention_users]
                    at_prefix = " ".join(at_codes) + " "
            
            message = at_prefix + content
            
            # 使用 TextProcessor 把 \n 转换为真正的换行符
            message = self.text_processor.config_to_text(message)
            
            for group_id in target_groups:
                await self._random_delay()
                await self.qianxun.send_text(self.robot_wxid, group_id, message)
                logger.info(f"已向群 {group_id} 发送定时提醒")
            
            self._record_task_execution(task_name, "scheduled_reminder", "success")
            
        except Exception as e:
            logger.error(f"定时提醒任务执行失败 {task_name}: {e}", exc_info=True)
            self._record_task_execution(task_name, "scheduled_reminder", "failed", str(e))
    
    def reload_tasks(self):
        """重新加载任务（配置变更后调用）"""
        logger.info("重新加载定时任务...")
        
        # 移除所有现有任务
        for job in self.scheduler.get_jobs():
            job.remove()
        
        # 重新设置任务
        self._setup_nickname_check_tasks()
        self._setup_scheduled_reminders()
        
        logger.info(f"定时任务已重新加载，共 {len(self.scheduler.get_jobs())} 个任务")
