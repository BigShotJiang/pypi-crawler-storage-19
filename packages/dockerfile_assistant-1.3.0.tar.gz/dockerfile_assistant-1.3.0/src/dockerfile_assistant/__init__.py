"""Dockerfile Assistant - AI-powered Dockerfile generation and analysis."""

__version__ = "1.3.0"
