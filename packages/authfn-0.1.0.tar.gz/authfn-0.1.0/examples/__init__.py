"""Examples for authfn."""
