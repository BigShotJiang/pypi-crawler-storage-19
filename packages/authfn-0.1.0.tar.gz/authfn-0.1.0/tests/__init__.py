"""Tests for authfn."""
