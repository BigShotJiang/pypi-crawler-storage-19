# `GlobalTrackingTransformer` 
:::dreem.models.GlobalTrackingTransformer