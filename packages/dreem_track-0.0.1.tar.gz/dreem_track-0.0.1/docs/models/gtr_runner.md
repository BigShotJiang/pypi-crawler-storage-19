# `GTRRunner`
:::dreem.models.GTRRunner