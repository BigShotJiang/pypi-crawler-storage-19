# `Config` 
::: dreem.io.Config