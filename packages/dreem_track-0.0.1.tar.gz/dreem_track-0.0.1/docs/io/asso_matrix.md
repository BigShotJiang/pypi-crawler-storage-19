# `AssociationMatrix` 
::: dreem.io.AssociationMatrix