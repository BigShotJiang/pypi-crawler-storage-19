# `Frame` 
::: dreem.io.Frame