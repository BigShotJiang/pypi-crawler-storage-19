"""Initialize training module."""
