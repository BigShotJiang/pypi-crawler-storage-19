"""EntelligenceAI CLI - AI-powered code review from your terminal."""

from importlib.metadata import version


__version__ = version("entelligence-cli")

from .api_client import APIClient, APIConfig
from .cli import cli
from .config import ConfigManager
from .exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    EntelligenceError,
    GitError,
    ReviewError,
    ValidationError,
)
from .git_operations import GitOperations
from .ui import AnimatedLoader, InteractiveUI, TerminalUI


__all__ = [
    "cli",
    "GitOperations",
    "APIClient",
    "APIConfig",
    "ConfigManager",
    "TerminalUI",
    "InteractiveUI",
    "AnimatedLoader",
    "EntelligenceError",
    "AuthenticationError",
    "APIError",
    "GitError",
    "ValidationError",
    "ConfigurationError",
    "ReviewError",
    "__version__",
]
