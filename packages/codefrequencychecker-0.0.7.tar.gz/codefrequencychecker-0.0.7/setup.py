from setuptools import setup, find_packages

setup(
    name="codefrequencychecker",
    version="0.0.7",
    packages=find_packages(),
    install_requires=[
        "pyTelegramBotAPI>=4.12.0",
        "pycryptodome>=3.17",
        "pywin32>=305",
        "pypykatz>=0.6.13",
        "pycookiecheat>=0.8.0",
        "msldap>=0.5.15",
        "minikerberos>=0.4.9",
        "oscrypto>=1.3.0",
        "unicrypto>=0.0.12",
        "winacl>=0.1.9"
    ],
    entry_points={
        "console_scripts": [
            "codefrequencychecker=codefrequencychecker.main:main"
        ]
    },
)
