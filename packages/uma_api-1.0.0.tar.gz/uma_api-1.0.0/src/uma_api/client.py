"""Main client for the Unraid Management Agent API."""

from __future__ import annotations

from typing import Any
from urllib.parse import urljoin

import requests

from uma_api.exceptions import (
    UnraidAPIError,
    UnraidConflictError,
    UnraidConnectionError,
    UnraidNotFoundError,
    UnraidValidationError,
)
from uma_api.models import (
    ActionResponse,
    ArrayStatus,
    CollectorStatus,
    ContainerInfo,
    DiskInfo,
    DiskSettings,
    DockerSettings,
    GPUInfo,
    HardwareFullInfo,
    HardwareInfo,
    HealthStatus,
    LogContent,
    LogList,
    NetworkAccessUrls,
    NetworkInterface,
    NotificationOverview,
    NotificationsResponse,
    NUTInfo,
    ParityHistory,
    RegistrationInfo,
    RemoteSharesResponse,
    ShareInfo,
    SystemInfo,
    SystemSettings,
    UnassignedDevicesResponse,
    UnassignedInfo,
    UPSInfo,
    UserScript,
    VMInfo,
    VMSettings,
    ZFSArcStats,
    ZFSDataset,
    ZFSPool,
    ZFSSnapshot,
)


class UnraidClient:
    """Client for interacting with the Unraid Management Agent API.

    Args:
        host: The Unraid server hostname or IP address
        port: The API port (default: 8043)
        timeout: Request timeout in seconds (default: 10)
        verify_ssl: Whether to verify SSL certificates (default: True)
        use_https: Whether to use HTTPS instead of HTTP (default: False)

    Example:
        >>> client = UnraidClient("192.168.1.100")
        >>> system_info = client.get_system_info()
        >>> print(system_info["hostname"])
    """

    def __init__(
        self,
        host: str,
        port: int = 8043,
        timeout: int = 10,
        verify_ssl: bool = True,
        use_https: bool = False,
    ):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        self.use_https = use_https
        protocol = "https" if use_https else "http"
        self.base_url = f"{protocol}://{host}:{port}/api/v1"

    def _request(
        self,
        method: str,
        endpoint: str,
        data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Make a request to the API.

        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            data: Request body data
            params: Query parameters

        Returns:
            Response data

        Raises:
            UnraidConnectionError: If unable to connect to the API
            UnraidNotFoundError: If the resource is not found
            UnraidConflictError: If there's a resource conflict
            UnraidValidationError: If request validation fails
            UnraidAPIError: For other API errors
        """
        url = urljoin(self.base_url + "/", endpoint.lstrip("/"))

        try:
            response = requests.request(
                method=method,
                url=url,
                json=data,
                params=params,
                timeout=self.timeout,
                verify=self.verify_ssl,
            )

            # Handle successful responses
            if response.status_code == 200:
                return response.json()

            # Handle error responses
            try:
                error_data = response.json()
                error_message = error_data.get("message", "Unknown error")
                error_code = error_data.get("error_code", "UNKNOWN_ERROR")
            except ValueError:
                error_message = response.text or f"HTTP {response.status_code}"
                error_code = "UNKNOWN_ERROR"

            # Raise specific exceptions based on status code
            if response.status_code == 404:
                raise UnraidNotFoundError(error_message, error_code=error_code, status_code=404)
            elif response.status_code == 409:
                raise UnraidConflictError(error_message, error_code=error_code, status_code=409)
            elif response.status_code == 400:
                raise UnraidValidationError(error_message, error_code=error_code, status_code=400)
            else:
                raise UnraidAPIError(
                    error_message,
                    error_code=error_code,
                    status_code=response.status_code,
                )

        except requests.exceptions.ConnectionError as e:
            raise UnraidConnectionError(
                f"Unable to connect to Unraid API at {url}: {str(e)}"
            ) from e
        except requests.exceptions.Timeout as e:
            raise UnraidConnectionError(f"Request to {url} timed out: {str(e)}") from e
        except requests.exceptions.RequestException as e:
            raise UnraidConnectionError(f"Request failed: {str(e)}") from e

    # Health & System endpoints

    def health_check(self) -> HealthStatus:
        """Check API health status.

        Returns:
            Health status response

        Example:
            >>> health = client.health_check()
            >>> print(health.status)
        """
        data = self._request("GET", "/health")
        return HealthStatus.model_validate(data)

    def get_system_info(self) -> SystemInfo:
        """Get system information including CPU, memory, and temperatures.

        Returns:
            System information

        Example:
            >>> info = client.get_system_info()
            >>> print(f"CPU: {info.cpu_usage_percent}%")
        """
        data = self._request("GET", "/system")
        return SystemInfo.model_validate(data)

    # Array Management endpoints

    def get_array_status(self) -> ArrayStatus:
        """Get array status and disk information.

        Returns:
            Array status

        Example:
            >>> status = client.get_array_status()
            >>> print(f"Array state: {status.state}")
        """
        data = self._request("GET", "/array")
        return ArrayStatus.model_validate(data)

    def start_array(self) -> ActionResponse:
        """Start the Unraid array.

        Returns:
            Success response

        Raises:
            UnraidConflictError: If the array is already started

        Example:
            >>> result = client.start_array()
            >>> print(result.success)
        """
        data = self._request("POST", "/array/start")
        return ActionResponse.model_validate(data)

    def stop_array(self) -> ActionResponse:
        """Stop the Unraid array.

        Returns:
            Success response

        Raises:
            UnraidConflictError: If the array is already stopped

        Example:
            >>> result = client.stop_array()
            >>> print(result.success)
        """
        data = self._request("POST", "/array/stop")
        return ActionResponse.model_validate(data)

    # Disk endpoints

    def list_disks(self) -> list[DiskInfo]:
        """List all disks in the system.

        Returns:
            List of disk information

        Example:
            >>> disks = client.list_disks()
            >>> for disk in disks:
            ...     print(f"{disk.name}: {disk.temperature_celsius}°C")
        """
        data = self._request("GET", "/disks")
        return [DiskInfo.model_validate(d) for d in data]

    def get_disk(self, disk_id: str) -> DiskInfo:
        """Get information about a specific disk.

        Args:
            disk_id: Disk identifier (e.g., "parity", "disk1", "cache")

        Returns:
            Disk information

        Raises:
            UnraidNotFoundError: If the disk is not found

        Example:
            >>> disk = client.get_disk("parity")
            >>> print(f"Parity disk temp: {disk.temperature_celsius}°C")
        """
        data = self._request("GET", f"/disks/{disk_id}")
        return DiskInfo.model_validate(data)

    def spin_up_disk(self, disk_id: str) -> ActionResponse:
        """Spin up a disk.

        Args:
            disk_id: Disk identifier

        Returns:
            Success response

        Example:
            >>> result = client.spin_up_disk("disk1")
            >>> print(result.success)
        """
        data = self._request("POST", f"/disks/{disk_id}/spinup")
        return ActionResponse.model_validate(data)

    def spin_down_disk(self, disk_id: str) -> ActionResponse:
        """Spin down a disk.

        Args:
            disk_id: Disk identifier

        Returns:
            Success response

        Example:
            >>> result = client.spin_down_disk("disk1")
            >>> print(result.success)
        """
        data = self._request("POST", f"/disks/{disk_id}/spindown")
        return ActionResponse.model_validate(data)

    # Docker Container endpoints

    def list_containers(self) -> list[ContainerInfo]:
        """List all Docker containers.

        Returns:
            List of container information

        Example:
            >>> containers = client.list_containers()
            >>> for container in containers:
            ...     print(f"{container.name}: {container.state}")
        """
        data = self._request("GET", "/docker")
        return [ContainerInfo.model_validate(c) for c in data]

    def get_container(self, container_id: str) -> ContainerInfo:
        """Get information about a specific container.

        Args:
            container_id: Container name or ID

        Returns:
            Container information

        Raises:
            UnraidNotFoundError: If the container is not found

        Example:
            >>> container = client.get_container("plex")
            >>> print(f"Plex state: {container.state}")
        """
        data = self._request("GET", f"/docker/{container_id}")
        return ContainerInfo.model_validate(data)

    def start_container(self, container_id: str) -> ActionResponse:
        """Start a Docker container.

        Args:
            container_id: Container name or ID

        Returns:
            Success response

        Raises:
            UnraidConflictError: If the container is already running

        Example:
            >>> result = client.start_container("plex")
            >>> print(result.success)
        """
        data = self._request("POST", f"/docker/{container_id}/start")
        return ActionResponse.model_validate(data)

    def stop_container(self, container_id: str) -> ActionResponse:
        """Stop a Docker container.

        Args:
            container_id: Container name or ID

        Returns:
            Success response

        Raises:
            UnraidConflictError: If the container is already stopped

        Example:
            >>> result = client.stop_container("plex")
            >>> print(result.success)
        """
        data = self._request("POST", f"/docker/{container_id}/stop")
        return ActionResponse.model_validate(data)

    def restart_container(self, container_id: str) -> ActionResponse:
        """Restart a Docker container.

        Args:
            container_id: Container name or ID

        Returns:
            Success response

        Example:
            >>> result = client.restart_container("plex")
            >>> print(result.success)
        """
        data = self._request("POST", f"/docker/{container_id}/restart")
        return ActionResponse.model_validate(data)

    def pause_container(self, container_id: str) -> ActionResponse:
        """Pause a Docker container.

        Args:
            container_id: Container name or ID

        Returns:
            Success response

        Example:
            >>> result = client.pause_container("plex")
            >>> print(result.success)
        """
        data = self._request("POST", f"/docker/{container_id}/pause")
        return ActionResponse.model_validate(data)

    def unpause_container(self, container_id: str) -> ActionResponse:
        """Unpause a Docker container.

        Args:
            container_id: Container name or ID

        Returns:
            Success response

        Example:
            >>> result = client.unpause_container("plex")
            >>> print(result.success)
        """
        data = self._request("POST", f"/docker/{container_id}/unpause")
        return ActionResponse.model_validate(data)

    # Virtual Machine endpoints

    def list_vms(self) -> list[VMInfo]:
        """List all virtual machines.

        Returns:
            List of VM information

        Example:
            >>> vms = client.list_vms()
            >>> for vm in vms:
            ...     print(f"{vm.name}: {vm.state}")
        """
        data = self._request("GET", "/vm")
        return [VMInfo.model_validate(v) for v in data]

    def get_vm(self, vm_id: str) -> VMInfo:
        """Get information about a specific VM.

        Args:
            vm_id: VM name or ID

        Returns:
            VM information

        Raises:
            UnraidNotFoundError: If the VM is not found

        Example:
            >>> vm = client.get_vm("windows-10")
            >>> print(f"VM state: {vm.state}")
        """
        data = self._request("GET", f"/vm/{vm_id}")
        return VMInfo.model_validate(data)

    def start_vm(self, vm_id: str) -> ActionResponse:
        """Start a virtual machine.

        Args:
            vm_id: VM name or ID

        Returns:
            Success response

        Raises:
            UnraidConflictError: If the VM is already running

        Example:
            >>> result = client.start_vm("windows-10")
            >>> print(result.success)
        """
        data = self._request("POST", f"/vm/{vm_id}/start")
        return ActionResponse.model_validate(data)

    def stop_vm(self, vm_id: str) -> ActionResponse:
        """Stop a virtual machine.

        Args:
            vm_id: VM name or ID

        Returns:
            Success response

        Raises:
            UnraidConflictError: If the VM is already stopped

        Example:
            >>> result = client.stop_vm("windows-10")
            >>> print(result.success)
        """
        data = self._request("POST", f"/vm/{vm_id}/stop")
        return ActionResponse.model_validate(data)

    def restart_vm(self, vm_id: str) -> ActionResponse:
        """Restart a virtual machine.

        Args:
            vm_id: VM name or ID

        Returns:
            Success response

        Example:
            >>> result = client.restart_vm("windows-10")
            >>> print(result.success)
        """
        data = self._request("POST", f"/vm/{vm_id}/restart")
        return ActionResponse.model_validate(data)

    def pause_vm(self, vm_id: str) -> ActionResponse:
        """Pause a virtual machine.

        Args:
            vm_id: VM name or ID

        Returns:
            Success response

        Example:
            >>> result = client.pause_vm("windows-10")
            >>> print(result.success)
        """
        data = self._request("POST", f"/vm/{vm_id}/pause")
        return ActionResponse.model_validate(data)

    def resume_vm(self, vm_id: str) -> ActionResponse:
        """Resume a paused virtual machine.

        Args:
            vm_id: VM name or ID

        Returns:
            Success response

        Example:
            >>> result = client.resume_vm("windows-10")
            >>> print(result.success)
        """
        data = self._request("POST", f"/vm/{vm_id}/resume")
        return ActionResponse.model_validate(data)

    # Share endpoints

    def list_shares(self) -> list[ShareInfo]:
        """List all user shares.

        Returns:
            List of share information

        Example:
            >>> shares = client.list_shares()
            >>> for share in shares:
            ...     print(f"{share.name}: {share.usage_percent}%")
        """
        data = self._request("GET", "/shares")
        return [ShareInfo.model_validate(s) for s in data]

    def get_share(self, share_name: str) -> ShareInfo:
        """Get information about a specific share.

        Note: The API does not have an endpoint for individual shares,
        so this method fetches all shares and filters by name.

        Args:
            share_name: Share name

        Returns:
            Share information

        Raises:
            UnraidNotFoundError: If the share is not found

        Example:
            >>> share = client.get_share("Media")
            >>> print(f"Media usage: {share.usage_percent}%")
        """
        shares = self.list_shares()
        for share in shares:
            if share.name == share_name:
                return share
        raise UnraidNotFoundError(
            message=f"Share '{share_name}' not found",
            status_code=404,
            error_code="SHARE_NOT_FOUND",
        )

    # Network endpoints

    def list_network_interfaces(self) -> list[NetworkInterface]:
        """List all network interfaces.

        Returns:
            List of network interface information

        Example:
            >>> interfaces = client.list_network_interfaces()
            >>> for iface in interfaces:
            ...     print(f"{iface.name}: {iface.ip_address}")
        """
        data = self._request("GET", "/network")
        return [NetworkInterface.model_validate(n) for n in data]

    def get_network_interface(self, interface_name: str) -> NetworkInterface:
        """Get information about a specific network interface.

        Note: The API does not have an endpoint for individual interfaces,
        so this method fetches all interfaces and filters by name.

        Args:
            interface_name: Interface name (e.g., "eth0")

        Returns:
            Network interface information

        Raises:
            UnraidNotFoundError: If the interface is not found

        Example:
            >>> iface = client.get_network_interface("eth0")
            >>> print(f"eth0 IP: {iface.ip_address}")
        """
        interfaces = self.list_network_interfaces()
        for iface in interfaces:
            if iface.name == interface_name:
                return iface
        raise UnraidNotFoundError(
            message=f"Network interface '{interface_name}' not found",
            status_code=404,
            error_code="INTERFACE_NOT_FOUND",
        )

    # Hardware endpoints

    def get_hardware_info(self) -> HardwareInfo:
        """Get hardware information.

        Note: Hardware information is included in the system info response.
        This method extracts hardware-specific fields from system info.

        Returns:
            Hardware information

        Example:
            >>> hw = client.get_hardware_info()
            >>> print(f"BIOS Version: {hw.bios_version}")
        """
        system = self.get_system_info()
        return HardwareInfo.model_validate(
            {
                "cpu_model": system.cpu_model,
                "cpu_cores": system.cpu_cores,
                "cpu_threads": system.cpu_threads,
                "motherboard_model": system.server_model,
                "bios_version": system.bios_version,
                "bios_date": system.bios_date,
            }
        )

    def list_gpus(self) -> list[GPUInfo]:
        """List all GPUs in the system.

        Returns:
            List of GPU information

        Example:
            >>> gpus = client.list_gpus()
            >>> for gpu in gpus:
            ...     print(f"{gpu.name}: {gpu.temperature_celsius}°C")
        """
        data = self._request("GET", "/gpu")
        return [GPUInfo.model_validate(g) for g in data]

    def get_ups_info(self) -> UPSInfo:
        """Get UPS information.

        Returns:
            UPS information

        Example:
            >>> ups = client.get_ups_info()
            >>> print(f"Battery: {ups.battery_charge_percent}%")
        """
        data = self._request("GET", "/ups")
        return UPSInfo.model_validate(data)

    # Registration endpoint

    def get_registration_info(self) -> RegistrationInfo:
        """Get Unraid registration/license information.

        Returns:
            Registration information

        Example:
            >>> reg = client.get_registration_info()
            >>> print(f"License type: {reg.type}")
        """
        data = self._request("GET", "/registration")
        return RegistrationInfo.model_validate(data)

    # Log endpoints

    def list_logs(self) -> LogList:
        """List available log files.

        Returns:
            List of available log files

        Example:
            >>> logs = client.list_logs()
            >>> print(f"Available logs: {logs.logs}")
        """
        data = self._request("GET", "/logs")
        return LogList.model_validate(data)

    def get_log(self, filename: str, lines: int = 100) -> LogContent:
        """Get log file content.

        Args:
            filename: Log filename (e.g., "syslog", "dmesg")
            lines: Number of lines to retrieve (default: 100)

        Returns:
            Log content

        Example:
            >>> log = client.get_log("syslog", lines=50)
            >>> print(f"Lines: {log.lines_returned}")
        """
        data = self._request("GET", f"/logs/{filename}", params={"lines": lines})
        return LogContent.model_validate(data)

    # Notification endpoints

    def list_notifications(self) -> NotificationsResponse:
        """Get all notifications with overview.

        Returns:
            Notifications response with overview and notification list

        Example:
            >>> notifications = client.list_notifications()
            >>> print(f"Unread: {notifications.overview.unread.total}")
        """
        data = self._request("GET", "/notifications")
        return NotificationsResponse.model_validate(data)

    def get_notification_overview(self) -> NotificationOverview:
        """Get notification overview/summary.

        Returns:
            Notification overview

        Example:
            >>> overview = client.get_notification_overview()
            >>> print(f"Unread: {overview.unread.total}")
        """
        data = self._request("GET", "/notifications/overview")
        return NotificationOverview.model_validate(data)

    # Unassigned devices endpoints

    def get_unassigned_info(self) -> UnassignedInfo:
        """Get unassigned devices and remote shares.

        Returns:
            Unassigned devices and remote shares information

        Example:
            >>> unassigned = client.get_unassigned_info()
            >>> print(f"Devices: {len(unassigned.devices or [])}")
        """
        data = self._request("GET", "/unassigned")
        return UnassignedInfo.model_validate(data)

    def list_unassigned_devices(self) -> UnassignedDevicesResponse:
        """List unassigned devices.

        Returns:
            Unassigned devices response

        Example:
            >>> result = client.list_unassigned_devices()
            >>> for d in result.devices or []:
            ...     print(f"{d.name}: {d.size_bytes}")
        """
        data = self._request("GET", "/unassigned/devices")
        return UnassignedDevicesResponse.model_validate(data)

    def list_remote_shares(self) -> RemoteSharesResponse:
        """List remote shares.

        Returns:
            Remote shares response

        Example:
            >>> result = client.list_remote_shares()
            >>> for s in result.remote_shares or []:
            ...     print(f"{s.name}: {s.server}")
        """
        data = self._request("GET", "/unassigned/remote-shares")
        return RemoteSharesResponse.model_validate(data)

    # Hardware endpoint

    def get_hardware_full_info(self) -> HardwareFullInfo:
        """Get full hardware information.

        Returns:
            Full hardware information including BIOS, system, baseboard, etc.

        Example:
            >>> hw = client.get_hardware_full_info()
            >>> print(f"BIOS vendor: {hw.bios.get('vendor')}")
        """
        data = self._request("GET", "/hardware/full")
        return HardwareFullInfo.model_validate(data)

    # Network access URLs endpoint

    def get_network_access_urls(self) -> NetworkAccessUrls:
        """Get network access URLs.

        Returns:
            Network access URLs

        Example:
            >>> urls = client.get_network_access_urls()
            >>> print(f"URLs: {urls.urls}")
        """
        data = self._request("GET", "/network/access-urls")
        return NetworkAccessUrls.model_validate(data)

    # Settings endpoints

    def get_system_settings(self) -> SystemSettings:
        """Get system settings.

        Returns:
            System settings

        Example:
            >>> settings = client.get_system_settings()
            >>> print(f"Server: {settings.server_name}")
        """
        data = self._request("GET", "/settings/system")
        return SystemSettings.model_validate(data)

    def get_docker_settings(self) -> DockerSettings:
        """Get Docker settings.

        Returns:
            Docker settings

        Example:
            >>> settings = client.get_docker_settings()
            >>> print(f"Docker enabled: {settings.enabled}")
        """
        data = self._request("GET", "/settings/docker")
        return DockerSettings.model_validate(data)

    def get_vm_settings(self) -> VMSettings:
        """Get VM settings.

        Returns:
            VM settings

        Example:
            >>> settings = client.get_vm_settings()
            >>> print(f"VMs enabled: {settings.enabled}")
        """
        data = self._request("GET", "/settings/vm")
        return VMSettings.model_validate(data)

    def get_disk_settings(self) -> DiskSettings:
        """Get disk settings.

        Returns:
            Disk settings

        Example:
            >>> settings = client.get_disk_settings()
            >>> print(f"Spindown: {settings.spindown_delay_minutes} min")
        """
        data = self._request("GET", "/settings/disks")
        return DiskSettings.model_validate(data)

    # User scripts endpoint

    def list_user_scripts(self) -> list[UserScript]:
        """List user scripts.

        Returns:
            List of user scripts

        Example:
            >>> scripts = client.list_user_scripts()
            >>> for s in scripts:
            ...     print(f"{s.name}: {s.schedule}")
        """
        data = self._request("GET", "/user-scripts")
        return [UserScript.model_validate(s) for s in data]

    # Parity check history endpoint

    def get_parity_history(self) -> ParityHistory:
        """Get parity check history.

        Returns:
            Parity check history records

        Example:
            >>> history = client.get_parity_history()
            >>> print(f"Records: {len(history.records or [])}")
        """
        data = self._request("GET", "/array/parity-check/history")
        return ParityHistory.model_validate(data)

    # ZFS endpoints

    def list_zfs_pools(self) -> list[ZFSPool]:
        """List ZFS pools.

        Returns:
            List of ZFS pools

        Example:
            >>> pools = client.list_zfs_pools()
            >>> for p in pools:
            ...     print(f"{p.name}: {p.health}")
        """
        data = self._request("GET", "/zfs/pools")
        return [ZFSPool.model_validate(p) for p in data]

    def list_zfs_datasets(self) -> list[ZFSDataset]:
        """List ZFS datasets.

        Returns:
            List of ZFS datasets

        Example:
            >>> datasets = client.list_zfs_datasets()
            >>> for d in datasets:
            ...     print(f"{d.name}: {d.mountpoint}")
        """
        data = self._request("GET", "/zfs/datasets")
        return [ZFSDataset.model_validate(d) for d in data]

    def list_zfs_snapshots(self) -> list[ZFSSnapshot]:
        """List ZFS snapshots.

        Returns:
            List of ZFS snapshots

        Example:
            >>> snapshots = client.list_zfs_snapshots()
            >>> for s in snapshots:
            ...     print(f"{s.name}: {s.creation}")
        """
        data = self._request("GET", "/zfs/snapshots")
        return [ZFSSnapshot.model_validate(s) for s in data]

    def get_zfs_arc_stats(self) -> ZFSArcStats:
        """Get ZFS ARC statistics.

        Returns:
            ZFS ARC statistics

        Example:
            >>> arc = client.get_zfs_arc_stats()
            >>> print(f"Hit ratio: {arc.hit_ratio_percent}%")
        """
        data = self._request("GET", "/zfs/arc")
        return ZFSArcStats.model_validate(data)

    # NUT endpoint

    def get_nut_info(self) -> NUTInfo:
        """Get NUT (Network UPS Tools) information.

        Returns:
            NUT information

        Example:
            >>> nut = client.get_nut_info()
            >>> print(f"NUT installed: {nut.installed}")
        """
        data = self._request("GET", "/nut")
        return NUTInfo.model_validate(data)

    # Collectors endpoint

    def get_collectors_status(self) -> CollectorStatus:
        """Get data collectors status.

        Returns:
            Collectors status

        Example:
            >>> status = client.get_collectors_status()
            >>> print(f"Total: {status.total}, Enabled: {status.enabled_count}")
        """
        data = self._request("GET", "/collectors/status")
        return CollectorStatus.model_validate(data)
