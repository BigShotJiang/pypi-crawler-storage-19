"""Pydantic models for the Uma API client."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class SystemInfo(BaseModel):
    """System information response from the Unraid server."""

    hostname: str | None = Field(None, description="Server hostname")
    version: str | None = Field(None, description="Unraid version")
    agent_version: str | None = Field(None, description="Agent version")
    uptime_seconds: int | None = Field(None, description="System uptime in seconds")
    cpu_usage_percent: float | None = Field(None, description="CPU usage percentage")
    cpu_model: str | None = Field(None, description="CPU model name")
    cpu_cores: int | None = Field(None, description="Number of CPU cores")
    cpu_threads: int | None = Field(None, description="Number of CPU threads")
    cpu_mhz: float | None = Field(None, description="CPU frequency in MHz")
    cpu_per_core_usage: dict[str, float] | None = Field(None, description="Per-core CPU usage")
    cpu_temp_celsius: float | None = Field(None, description="CPU temperature in Celsius")
    ram_usage_percent: float | None = Field(None, description="RAM usage percentage")
    ram_total_bytes: int | None = Field(None, description="Total RAM in bytes")
    ram_used_bytes: int | None = Field(None, description="Used RAM in bytes")
    ram_free_bytes: int | None = Field(None, description="Free RAM in bytes")
    ram_buffers_bytes: int | None = Field(None, description="RAM buffers in bytes")
    ram_cached_bytes: int | None = Field(None, description="Cached RAM in bytes")
    server_model: str | None = Field(None, description="Server model")
    motherboard_model: str | None = Field(None, description="Motherboard model")
    bios_version: str | None = Field(None, description="BIOS version")
    bios_date: str | None = Field(None, description="BIOS date")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


ArrayState = Literal["STARTED", "STOPPED", "STARTING", "STOPPING"]


class ArrayStatus(BaseModel):
    """Array status response."""

    state: ArrayState | None = Field(None, description="Array state")
    total_disks: int | None = Field(None, description="Total number of disks")
    data_disks: int | None = Field(None, description="Number of data disks")
    parity_disks: int | None = Field(None, description="Number of parity disks")
    cache_disks: int | None = Field(None, description="Number of cache disks")
    size_bytes: int | None = Field(None, description="Total array size in bytes")
    used_bytes: int | None = Field(None, description="Used space in bytes")
    free_bytes: int | None = Field(None, description="Free space in bytes")
    usage_percent: float | None = Field(None, description="Array usage percentage")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


DiskRole = Literal["parity", "parity2", "data", "cache", "pool", "docker_vdisk", "log"]
SpinState = Literal["active", "standby", "idle"]


class DiskInfo(BaseModel):
    """Disk information response."""

    id: str | None = Field(None, description="Disk identifier")
    device: str | None = Field(None, description="Device path")
    name: str | None = Field(None, description="Disk name")
    role: str | None = Field(None, description="Disk role")
    size_bytes: int | None = Field(None, description="Disk size in bytes")
    used_bytes: int | None = Field(None, description="Used space in bytes")
    free_bytes: int | None = Field(None, description="Free space in bytes")
    temperature_celsius: float | None = Field(None, description="Disk temperature in Celsius")
    spin_state: str | None = Field(None, description="Disk spin state")
    serial_number: str | None = Field(None, description="Disk serial number")
    model: str | None = Field(None, description="Disk model")
    filesystem: str | None = Field(None, description="Filesystem type")
    status: str | None = Field(None, description="Disk status")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


ContainerState = Literal["running", "stopped", "paused", "created", "exited", "dead"]


class ContainerInfo(BaseModel):
    """Docker container information response."""

    id: str | None = Field(None, description="Container ID")
    name: str | None = Field(None, description="Container name")
    image: str | None = Field(None, description="Container image")
    state: str | None = Field(None, description="Container state")
    status: str | None = Field(None, description="Container status string")
    cpu_usage_percent: float | None = Field(None, description="CPU usage percentage")
    memory_usage_bytes: int | None = Field(None, description="Memory usage in bytes")
    network_rx_bytes: int | None = Field(None, description="Network bytes received")
    network_tx_bytes: int | None = Field(None, description="Network bytes transmitted")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


VMState = Literal["running", "stopped", "paused", "shut off", "crashed", "suspended"]


class VMInfo(BaseModel):
    """Virtual machine information response."""

    id: str | None = Field(None, description="VM ID")
    name: str | None = Field(None, description="VM name")
    state: str | None = Field(None, description="VM state")
    cpu_count: int | None = Field(None, description="Number of CPUs")
    memory_bytes: int | None = Field(None, description="Memory in bytes")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class ShareInfo(BaseModel):
    """User share information response."""

    name: str | None = Field(None, description="Share name")
    path: str | None = Field(None, description="Share path")
    size_bytes: int | None = Field(None, description="Total size in bytes")
    used_bytes: int | None = Field(None, description="Used space in bytes")
    free_bytes: int | None = Field(None, description="Free space in bytes")
    usage_percent: float | None = Field(None, description="Usage percentage")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class NetworkInterface(BaseModel):
    """Network interface information response."""

    name: str | None = Field(None, description="Interface name")
    mac_address: str | None = Field(None, description="MAC address")
    ip_address: str | None = Field(None, description="IP address")
    netmask: str | None = Field(None, description="Network mask")
    broadcast: str | None = Field(None, description="Broadcast address")
    mtu: int | None = Field(None, description="MTU size")
    state: str | None = Field(None, description="Interface state")
    speed_mbps: int | None = Field(None, description="Link speed in Mbps")
    rx_bytes: int | None = Field(None, description="Bytes received")
    tx_bytes: int | None = Field(None, description="Bytes transmitted")
    rx_packets: int | None = Field(None, description="Packets received")
    tx_packets: int | None = Field(None, description="Packets transmitted")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class HardwareInfo(BaseModel):
    """Hardware information response (extracted from system info)."""

    cpu_model: str | None = Field(None, description="CPU model name")
    cpu_cores: int | None = Field(None, description="Number of CPU cores")
    cpu_threads: int | None = Field(None, description="Number of CPU threads")
    motherboard_model: str | None = Field(None, description="Motherboard model")
    bios_version: str | None = Field(None, description="BIOS version")
    bios_date: str | None = Field(None, description="BIOS date")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class GPUInfo(BaseModel):
    """GPU information response."""

    id: str | None = Field(None, description="GPU ID")
    name: str | None = Field(None, description="GPU name")
    vendor: str | None = Field(None, description="GPU vendor")
    utilization_percent: float | None = Field(None, description="GPU utilization percentage")
    memory_total_bytes: int | None = Field(None, description="Total GPU memory in bytes")
    memory_used_bytes: int | None = Field(None, description="Used GPU memory in bytes")
    temperature_celsius: float | None = Field(None, description="GPU temperature in Celsius")
    fan_speed_percent: float | None = Field(None, description="Fan speed percentage")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class UPSInfo(BaseModel):
    """UPS information response."""

    model: str | None = Field(None, description="UPS model")
    status: str | None = Field(None, description="UPS status")
    battery_charge_percent: float | None = Field(None, description="Battery charge percentage")
    battery_runtime_seconds: int | None = Field(None, description="Battery runtime in seconds")
    load_percent: float | None = Field(None, description="Load percentage")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class HealthStatus(BaseModel):
    """Health check response."""

    status: str = Field(..., description="Health status")

    model_config = {"frozen": True, "extra": "allow"}


class ActionResponse(BaseModel):
    """Response from action endpoints (start, stop, etc.)."""

    success: bool = Field(..., description="Whether the action succeeded")
    message: str | None = Field(None, description="Response message")
    timestamp: str | None = Field(None, description="Action timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class APIError(BaseModel):
    """API error response."""

    success: bool = Field(False, description="Always false for errors")
    error_code: str = Field(..., description="Error code")
    message: str = Field(..., description="Error message")
    details: dict[str, Any] | None = Field(None, description="Additional error details")
    timestamp: str | None = Field(None, description="Error timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class RegistrationInfo(BaseModel):
    """Unraid registration/license information."""

    type: str | None = Field(None, description="License type")
    state: str | None = Field(None, description="Registration state")
    key_file: str | None = Field(None, description="Key file path")
    guid: str | None = Field(None, description="Server GUID")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class LogFile(BaseModel):
    """Log file information."""

    name: str | None = Field(None, description="Log filename")
    path: str | None = Field(None, description="Log file path")
    size_bytes: int | None = Field(None, description="File size in bytes")
    modified_at: str | None = Field(None, description="Last modified timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class LogList(BaseModel):
    """List of available log files."""

    logs: list[LogFile] | None = Field(None, description="Available log files")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class LogContent(BaseModel):
    """Log file content response."""

    path: str | None = Field(None, description="Log file path")
    content: str | None = Field(None, description="Raw log content")
    lines: list[str] | None = Field(None, description="Log content as lines")
    total_lines: int | None = Field(None, description="Total lines in file")
    lines_returned: int | None = Field(None, description="Number of lines returned")
    start_line: int | None = Field(None, description="Start line number")
    end_line: int | None = Field(None, description="End line number")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class Notification(BaseModel):
    """Notification information."""

    id: str | None = Field(None, description="Notification ID")
    subject: str | None = Field(None, description="Notification subject")
    description: str | None = Field(None, description="Notification description")
    importance: str | None = Field(None, description="Importance level")
    timestamp: str | None = Field(None, description="Notification timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class NotificationCounts(BaseModel):
    """Notification counts by type."""

    info: int | None = Field(None, description="Info notifications")
    warning: int | None = Field(None, description="Warning notifications")
    alert: int | None = Field(None, description="Alert notifications")
    total: int | None = Field(None, description="Total notifications")

    model_config = {"frozen": True, "extra": "allow"}


class NotificationOverview(BaseModel):
    """Notification overview/summary."""

    unread: NotificationCounts | None = Field(None, description="Unread counts")
    archive: NotificationCounts | None = Field(None, description="Archive counts")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class NotificationsResponse(BaseModel):
    """Full notifications response."""

    overview: NotificationOverview | None = Field(None, description="Overview")
    notifications: list[Notification] | None = Field(None, description="Notification list")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class UnassignedDevice(BaseModel):
    """Unassigned device information."""

    device: str | None = Field(None, description="Device path")
    name: str | None = Field(None, description="Device name")
    size_bytes: int | None = Field(None, description="Device size in bytes")
    mounted: bool | None = Field(None, description="Whether mounted")
    filesystem: str | None = Field(None, description="Filesystem type")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class RemoteShare(BaseModel):
    """Remote share information."""

    name: str | None = Field(None, description="Share name")
    protocol: str | None = Field(None, description="Protocol (SMB, NFS)")
    server: str | None = Field(None, description="Remote server")
    mounted: bool | None = Field(None, description="Whether mounted")
    mount_point: str | None = Field(None, description="Mount point path")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class UnassignedDevicesResponse(BaseModel):
    """Unassigned devices response."""

    devices: list[UnassignedDevice] | None = Field(None, description="Unassigned devices")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class RemoteSharesResponse(BaseModel):
    """Remote shares response."""

    remote_shares: list[RemoteShare] | None = Field(None, description="Remote shares")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class UnassignedInfo(BaseModel):
    """Full unassigned devices and remote shares response."""

    devices: list[UnassignedDevice] | None = Field(None, description="Unassigned devices")
    remote_shares: list[RemoteShare] | None = Field(None, description="Remote shares")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class HardwareFullInfo(BaseModel):
    """Full hardware information from /hardware/full."""

    bios: dict[str, Any] | None = Field(None, description="BIOS information")
    system: dict[str, Any] | None = Field(None, description="System information")
    baseboard: dict[str, Any] | None = Field(None, description="Baseboard information")
    chassis: dict[str, Any] | None = Field(None, description="Chassis information")
    processor: dict[str, Any] | None = Field(None, description="Processor information")
    memory: dict[str, Any] | None = Field(None, description="Memory information")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class AccessUrl(BaseModel):
    """Network access URL."""

    type: str | None = Field(None, description="URL type (lan, wan, mdns, ipv6)")
    name: str | None = Field(None, description="URL name")
    ipv4: str | None = Field(None, description="IPv4 URL")
    ipv6: str | None = Field(None, description="IPv6 URL")

    model_config = {"frozen": True, "extra": "allow"}


class NetworkAccessUrls(BaseModel):
    """Network access URLs."""

    urls: list[AccessUrl] | None = Field(None, description="Access URLs")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class SystemSettings(BaseModel):
    """System settings."""

    server_name: str | None = Field(None, description="Server name")
    timezone: str | None = Field(None, description="Timezone")
    use_ssl: bool | None = Field(None, description="SSL enabled")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class DockerSettings(BaseModel):
    """Docker settings."""

    enabled: bool | None = Field(None, description="Docker enabled")
    image_path: str | None = Field(None, description="Docker image path")
    auto_start: bool | None = Field(None, description="Auto start enabled")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class VMSettings(BaseModel):
    """VM settings."""

    enabled: bool | None = Field(None, description="VMs enabled")
    default_path: str | None = Field(None, description="Default VM path")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class DiskSettings(BaseModel):
    """Disk settings."""

    spindown_delay_minutes: int | None = Field(None, description="Spindown delay in minutes")
    default_filesystem: str | None = Field(None, description="Default filesystem")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class UserScript(BaseModel):
    """User script information."""

    name: str | None = Field(None, description="Script name")
    description: str | None = Field(None, description="Script description")
    script_path: str | None = Field(None, description="Script path")
    schedule: str | None = Field(None, description="Schedule")
    running: bool | None = Field(None, description="Currently running")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class ParityCheckRecord(BaseModel):
    """Parity check history record."""

    date: str | None = Field(None, description="Check date")
    duration_seconds: int | None = Field(None, description="Duration in seconds")
    errors: int | None = Field(None, description="Errors found")
    status: str | None = Field(None, description="Check status")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class ParityHistory(BaseModel):
    """Parity check history."""

    records: list[ParityCheckRecord] | None = Field(None, description="History records")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class ZFSPool(BaseModel):
    """ZFS pool information."""

    name: str | None = Field(None, description="Pool name")
    state: str | None = Field(None, description="Pool state")
    size_bytes: int | None = Field(None, description="Pool size in bytes")
    used_bytes: int | None = Field(None, description="Used space in bytes")
    free_bytes: int | None = Field(None, description="Free space in bytes")
    health: str | None = Field(None, description="Pool health")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class ZFSDataset(BaseModel):
    """ZFS dataset information."""

    name: str | None = Field(None, description="Dataset name")
    pool: str | None = Field(None, description="Parent pool")
    used_bytes: int | None = Field(None, description="Used space in bytes")
    available_bytes: int | None = Field(None, description="Available space in bytes")
    mountpoint: str | None = Field(None, description="Mount point")
    compression: str | None = Field(None, description="Compression type")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class ZFSSnapshot(BaseModel):
    """ZFS snapshot information."""

    name: str | None = Field(None, description="Snapshot name")
    dataset: str | None = Field(None, description="Parent dataset")
    creation: str | None = Field(None, description="Creation timestamp")
    used_bytes: int | None = Field(None, description="Used space in bytes")
    referenced_bytes: int | None = Field(None, description="Referenced space in bytes")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class ZFSArcStats(BaseModel):
    """ZFS ARC statistics."""

    hit_ratio_percent: float | None = Field(None, description="ARC hit ratio percentage")
    size_bytes: int | None = Field(None, description="ARC size in bytes")
    target_size_bytes: int | None = Field(None, description="ARC target size in bytes")
    hits: int | None = Field(None, description="ARC hits")
    misses: int | None = Field(None, description="ARC misses")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class NUTInfo(BaseModel):
    """NUT (Network UPS Tools) information."""

    installed: bool | None = Field(None, description="NUT installed")
    running: bool | None = Field(None, description="NUT service running")
    config_mode: str | None = Field(None, description="Configuration mode")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}


class CollectorStatus(BaseModel):
    """Collector status information."""

    total: int | None = Field(None, description="Total collectors")
    enabled_count: int | None = Field(None, description="Enabled collectors")
    collectors: list[dict[str, Any]] | None = Field(None, description="Collector details")
    timestamp: str | None = Field(None, description="Data collection timestamp")

    model_config = {"frozen": True, "extra": "allow"}
