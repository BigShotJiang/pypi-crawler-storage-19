"""WebSocket client for real-time event streaming from the Unraid Management Agent."""

import asyncio
import json
from collections.abc import Callable
from typing import Any

import websockets


class UnraidWebSocketClient:
    """WebSocket client for receiving real-time events from the Unraid Management Agent.

    Args:
        host: The Unraid server hostname or IP address
        port: The API port (default: 8043)
        on_message: Callback function for received messages
        on_error: Callback function for errors
        on_close: Callback function for connection close
        use_wss: Whether to use WSS (secure WebSocket) instead of WS (default: False)

    Example:
        >>> async def handle_message(data):
        ...     print(f"Received: {data}")
        >>>
        >>> ws_client = UnraidWebSocketClient(
        ...     "192.168.1.100",
        ...     on_message=handle_message
        ... )
        >>> await ws_client.connect()
    """

    def __init__(
        self,
        host: str,
        port: int = 8043,
        on_message: Callable[[dict[str, Any]], None] | None = None,
        on_error: Callable[[Exception], None] | None = None,
        on_close: Callable[[], None] | None = None,
        use_wss: bool = False,
    ):
        self.host = host
        self.port = port
        protocol = "wss" if use_wss else "ws"
        self.ws_url = f"{protocol}://{host}:{port}/api/v1/ws"
        self.on_message = on_message
        self.on_error = on_error
        self.on_close = on_close
        self._websocket: Any = None  # Type varies by websockets version
        self._running = False

    async def connect(self) -> None:
        """Connect to the WebSocket and start receiving events.

        This method will block and continuously receive events until disconnect() is called.

        Raises:
            ConnectionError: If unable to connect to the WebSocket
        """
        self._running = True
        try:
            async with websockets.connect(self.ws_url) as websocket:
                self._websocket = websocket
                while self._running:
                    try:
                        message = await websocket.recv()
                        # Handle both str and bytes message types
                        if isinstance(message, bytes):
                            message = message.decode("utf-8")
                        data = json.loads(message)

                        if self.on_message:
                            if asyncio.iscoroutinefunction(self.on_message):
                                await self.on_message(data)
                            else:
                                self.on_message(data)

                    except json.JSONDecodeError:
                        error = ValueError(f"Failed to parse message: {message!r}")
                        if self.on_error:
                            if asyncio.iscoroutinefunction(self.on_error):
                                await self.on_error(error)
                            else:
                                self.on_error(error)
                    except websockets.exceptions.ConnectionClosed:
                        break
        except Exception as e:
            if self.on_error:
                if asyncio.iscoroutinefunction(self.on_error):
                    await self.on_error(e)
                else:
                    self.on_error(e)
            raise ConnectionError(f"Failed to connect to WebSocket: {e}") from e
        finally:
            self._websocket = None
            if self.on_close:
                if asyncio.iscoroutinefunction(self.on_close):
                    await self.on_close()
                else:
                    self.on_close()

    async def disconnect(self) -> None:
        """Disconnect from the WebSocket."""
        self._running = False
        if self._websocket:
            await self._websocket.close()

    @property
    def is_connected(self) -> bool:
        """Check if the WebSocket is currently connected."""
        return self._websocket is not None and not self._websocket.closed
