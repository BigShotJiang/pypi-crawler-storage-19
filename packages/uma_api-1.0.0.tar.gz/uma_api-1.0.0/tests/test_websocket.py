"""Tests for the Uma API WebSocket client."""

from unittest.mock import AsyncMock

import pytest

from uma_api.websocket import UnraidWebSocketClient


class TestUnraidWebSocketClient:
    """Test the UnraidWebSocketClient class."""

    def test_client_initialization(self):
        """Test client initialization."""
        client = UnraidWebSocketClient(host="192.168.1.100", port=8043)

        assert client.host == "192.168.1.100"
        assert client.port == 8043
        assert client.ws_url == "ws://192.168.1.100:8043/api/v1/ws"
        assert client.on_message is None
        assert client.on_error is None
        assert client.on_close is None

    def test_client_with_callbacks(self):
        """Test client initialization with callbacks."""

        def on_message(data):
            pass

        def on_error(error):
            pass

        def on_close():
            pass

        client = UnraidWebSocketClient(
            host="192.168.1.100",
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
        )

        assert client.on_message is on_message
        assert client.on_error is on_error
        assert client.on_close is on_close

    @pytest.mark.asyncio
    async def test_is_connected_property(self):
        """Test the is_connected property."""
        client = UnraidWebSocketClient(host="192.168.1.100")

        # Initially not connected
        assert client.is_connected is False

    @pytest.mark.asyncio
    async def test_disconnect(self):
        """Test disconnect method."""
        client = UnraidWebSocketClient(host="192.168.1.100")

        # Create a mock websocket
        mock_ws = AsyncMock()
        client._websocket = mock_ws

        await client.disconnect()

        mock_ws.close.assert_called_once()
        assert client._running is False
