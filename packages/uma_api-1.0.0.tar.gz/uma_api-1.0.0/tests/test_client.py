"""Tests for the Uma API client."""

from unittest.mock import Mock, patch

import pytest
import requests

from uma_api import (
    ActionResponse,
    ArrayStatus,
    ContainerInfo,
    DiskInfo,
    HealthStatus,
    SystemInfo,
    UnraidAPIError,
    UnraidClient,
    UnraidConflictError,
    UnraidConnectionError,
    UnraidNotFoundError,
    UnraidValidationError,
)


@pytest.fixture
def client():
    """Create a test client."""
    return UnraidClient(host="192.168.1.100", port=8043, timeout=5)


@pytest.fixture
def mock_response():
    """Create a mock response."""
    response = Mock(spec=requests.Response)
    response.status_code = 200
    return response


class TestUnraidClient:
    """Test the UnraidClient class."""

    def test_client_initialization(self, client):
        """Test client initialization."""
        assert client.host == "192.168.1.100"
        assert client.port == 8043
        assert client.timeout == 5
        assert client.base_url == "http://192.168.1.100:8043/api/v1"

    def test_client_default_values(self):
        """Test client initialization with default values."""
        client = UnraidClient(host="192.168.1.100")
        assert client.port == 8043
        assert client.timeout == 10
        assert client.verify_ssl is True

    @patch("requests.request")
    def test_health_check(self, mock_request, client, mock_response):
        """Test health check endpoint."""
        mock_response.json.return_value = {"status": "ok"}
        mock_request.return_value = mock_response

        result = client.health_check()

        assert isinstance(result, HealthStatus)
        assert result.status == "ok"
        mock_request.assert_called_once()

    @patch("requests.request")
    def test_get_system_info(self, mock_request, client, mock_response):
        """Test get system info endpoint."""
        mock_response.json.return_value = {
            "hostname": "Cube",
            "cpu_usage_percent": 10.5,
            "ram_usage_percent": 42.0,
        }
        mock_request.return_value = mock_response

        result = client.get_system_info()

        assert isinstance(result, SystemInfo)
        assert result.hostname == "Cube"
        assert result.cpu_usage_percent == 10.5
        assert result.ram_usage_percent == 42.0

    @patch("requests.request")
    def test_get_array_status(self, mock_request, client, mock_response):
        """Test get array status endpoint."""
        mock_response.json.return_value = {
            "state": "STARTED",
            "total_disks": 10,
            "usage_percent": 65.5,
        }
        mock_request.return_value = mock_response

        result = client.get_array_status()

        assert isinstance(result, ArrayStatus)
        assert result.state == "STARTED"
        assert result.total_disks == 10
        assert result.usage_percent == 65.5

    @patch("requests.request")
    def test_start_array(self, mock_request, client, mock_response):
        """Test start array endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Array started"}
        mock_request.return_value = mock_response

        result = client.start_array()

        assert isinstance(result, ActionResponse)
        assert result.success is True
        assert result.message == "Array started"
        mock_request.assert_called_with(
            method="POST",
            url="http://192.168.1.100:8043/api/v1/array/start",
            json=None,
            params=None,
            timeout=5,
            verify=True,
        )

    @patch("requests.request")
    def test_stop_array(self, mock_request, client, mock_response):
        """Test stop array endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Array stopped"}
        mock_request.return_value = mock_response

        result = client.stop_array()

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_list_disks(self, mock_request, client, mock_response):
        """Test list disks endpoint."""
        mock_response.json.return_value = [
            {"name": "parity", "temperature_celsius": 35},
            {"name": "disk1", "temperature_celsius": 32},
        ]
        mock_request.return_value = mock_response

        result = client.list_disks()

        assert len(result) == 2
        assert all(isinstance(d, DiskInfo) for d in result)
        assert result[0].name == "parity"
        assert result[1].temperature_celsius == 32

    @patch("requests.request")
    def test_get_disk(self, mock_request, client, mock_response):
        """Test get disk endpoint."""
        mock_response.json.return_value = {
            "id": "disk1",
            "name": "disk1",
            "temperature_celsius": 35,
            "role": "data",
        }
        mock_request.return_value = mock_response

        result = client.get_disk("disk1")

        assert isinstance(result, DiskInfo)
        assert result.name == "disk1"
        assert result.temperature_celsius == 35

    @patch("requests.request")
    def test_spin_up_disk(self, mock_request, client, mock_response):
        """Test spin up disk endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Disk spinning up"}
        mock_request.return_value = mock_response

        result = client.spin_up_disk("disk1")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_spin_down_disk(self, mock_request, client, mock_response):
        """Test spin down disk endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Disk spinning down"}
        mock_request.return_value = mock_response

        result = client.spin_down_disk("disk1")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_list_containers(self, mock_request, client, mock_response):
        """Test list containers endpoint."""
        mock_response.json.return_value = [
            {"name": "plex", "state": "running"},
            {"name": "nginx", "state": "stopped"},
        ]
        mock_request.return_value = mock_response

        result = client.list_containers()

        assert len(result) == 2
        assert all(isinstance(c, ContainerInfo) for c in result)
        assert result[0].name == "plex"
        assert result[1].state == "stopped"

    @patch("requests.request")
    def test_get_container(self, mock_request, client, mock_response):
        """Test get container endpoint."""
        mock_response.json.return_value = {
            "id": "abc123",
            "name": "plex",
            "state": "running",
            "image": "plexinc/pms-docker",
        }
        mock_request.return_value = mock_response

        result = client.get_container("plex")

        assert isinstance(result, ContainerInfo)
        assert result.name == "plex"
        assert result.state == "running"

    @patch("requests.request")
    def test_start_container(self, mock_request, client, mock_response):
        """Test start container endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Container started"}
        mock_request.return_value = mock_response

        result = client.start_container("plex")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_stop_container(self, mock_request, client, mock_response):
        """Test stop container endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Container stopped"}
        mock_request.return_value = mock_response

        result = client.stop_container("plex")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_restart_container(self, mock_request, client, mock_response):
        """Test restart container endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Container restarted"}
        mock_request.return_value = mock_response

        result = client.restart_container("plex")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_pause_container(self, mock_request, client, mock_response):
        """Test pause container endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Container paused"}
        mock_request.return_value = mock_response

        result = client.pause_container("plex")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_unpause_container(self, mock_request, client, mock_response):
        """Test unpause container endpoint."""
        mock_response.json.return_value = {"success": True, "message": "Container unpaused"}
        mock_request.return_value = mock_response

        result = client.unpause_container("plex")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_list_vms(self, mock_request, client, mock_response):
        """Test list VMs endpoint."""
        mock_response.json.return_value = [
            {"name": "Windows10", "state": "running"},
            {"name": "Ubuntu", "state": "stopped"},
        ]
        mock_request.return_value = mock_response

        result = client.list_vms()

        assert len(result) == 2
        assert result[0].name == "Windows10"
        assert result[1].state == "stopped"

    @patch("requests.request")
    def test_get_vm(self, mock_request, client, mock_response):
        """Test get VM endpoint."""
        mock_response.json.return_value = {
            "id": "vm1",
            "name": "Windows10",
            "state": "running",
            "cpu_count": 4,
        }
        mock_request.return_value = mock_response

        result = client.get_vm("Windows10")

        assert result.name == "Windows10"
        assert result.cpu_count == 4

    @patch("requests.request")
    def test_start_vm(self, mock_request, client, mock_response):
        """Test start VM endpoint."""
        mock_response.json.return_value = {"success": True, "message": "VM started"}
        mock_request.return_value = mock_response

        result = client.start_vm("Windows10")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_stop_vm(self, mock_request, client, mock_response):
        """Test stop VM endpoint."""
        mock_response.json.return_value = {"success": True, "message": "VM stopped"}
        mock_request.return_value = mock_response

        result = client.stop_vm("Windows10")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_restart_vm(self, mock_request, client, mock_response):
        """Test restart VM endpoint."""
        mock_response.json.return_value = {"success": True, "message": "VM restarted"}
        mock_request.return_value = mock_response

        result = client.restart_vm("Windows10")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_pause_vm(self, mock_request, client, mock_response):
        """Test pause VM endpoint."""
        mock_response.json.return_value = {"success": True, "message": "VM paused"}
        mock_request.return_value = mock_response

        result = client.pause_vm("Windows10")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_resume_vm(self, mock_request, client, mock_response):
        """Test resume VM endpoint."""
        mock_response.json.return_value = {"success": True, "message": "VM resumed"}
        mock_request.return_value = mock_response

        result = client.resume_vm("Windows10")

        assert isinstance(result, ActionResponse)
        assert result.success is True

    @patch("requests.request")
    def test_list_shares(self, mock_request, client, mock_response):
        """Test list shares endpoint."""
        mock_response.json.return_value = [
            {"name": "Media", "usage_percent": 75.5},
            {"name": "Backups", "usage_percent": 50.0},
        ]
        mock_request.return_value = mock_response

        result = client.list_shares()

        assert len(result) == 2
        assert result[0].name == "Media"
        assert result[0].usage_percent == 75.5

    @patch("requests.request")
    def test_get_share(self, mock_request, client, mock_response):
        """Test get share filters from list."""
        mock_response.json.return_value = [
            {"name": "Media", "path": "/mnt/user/Media", "usage_percent": 75.5},
            {"name": "Backups", "path": "/mnt/user/Backups", "usage_percent": 50.0},
        ]
        mock_request.return_value = mock_response

        result = client.get_share("Media")

        assert result.name == "Media"
        assert result.path == "/mnt/user/Media"

    @patch("requests.request")
    def test_get_share_not_found(self, mock_request, client, mock_response):
        """Test get share raises error when not found."""
        mock_response.json.return_value = [
            {"name": "Media", "path": "/mnt/user/Media", "usage_percent": 75.5},
        ]
        mock_request.return_value = mock_response

        with pytest.raises(UnraidNotFoundError) as exc_info:
            client.get_share("NonExistent")

        assert exc_info.value.error_code == "SHARE_NOT_FOUND"

    @patch("requests.request")
    def test_list_network_interfaces(self, mock_request, client, mock_response):
        """Test list network interfaces endpoint."""
        mock_response.json.return_value = [
            {"name": "eth0", "ip_address": "192.168.1.100"},
            {"name": "br0", "ip_address": "192.168.1.101"},
        ]
        mock_request.return_value = mock_response

        result = client.list_network_interfaces()

        assert len(result) == 2
        assert result[0].name == "eth0"
        assert result[0].ip_address == "192.168.1.100"

    @patch("requests.request")
    def test_get_network_interface(self, mock_request, client, mock_response):
        """Test get network interface endpoint (filters from list)."""
        mock_response.json.return_value = [
            {"name": "eth0", "ip_address": "192.168.1.100", "mac_address": "00:11:22:33:44:55"},
            {"name": "eth1", "ip_address": "192.168.1.101", "mac_address": "00:11:22:33:44:66"},
        ]
        mock_request.return_value = mock_response

        result = client.get_network_interface("eth0")

        assert result.name == "eth0"
        assert result.mac_address == "00:11:22:33:44:55"
        mock_request.assert_called_with(
            method="GET",
            url="http://192.168.1.100:8043/api/v1/network",
            json=None,
            params=None,
            timeout=5,
            verify=True,
        )

    @patch("requests.request")
    def test_get_network_interface_not_found(self, mock_request, client, mock_response):
        """Test get network interface not found."""
        mock_response.json.return_value = [
            {"name": "eth1", "ip_address": "192.168.1.101"},
        ]
        mock_request.return_value = mock_response

        with pytest.raises(UnraidNotFoundError) as exc_info:
            client.get_network_interface("eth0")

        assert "eth0" in str(exc_info.value)
        assert exc_info.value.error_code == "INTERFACE_NOT_FOUND"

    @patch("requests.request")
    def test_get_hardware_info(self, mock_request, client, mock_response):
        """Test get hardware info endpoint (extracts from system info)."""
        mock_response.json.return_value = {
            "hostname": "unraid",
            "cpu_model": "Intel i7-8700K",
            "cpu_cores": 6,
            "cpu_threads": 12,
            "server_model": "Custom Build",
            "motherboard_model": "ASUS Z370",
        }
        mock_request.return_value = mock_response

        result = client.get_hardware_info()

        assert result.cpu_model == "Intel i7-8700K"
        assert result.cpu_cores == 6
        assert result.cpu_threads == 12
        mock_request.assert_called_with(
            method="GET",
            url="http://192.168.1.100:8043/api/v1/system",
            json=None,
            params=None,
            timeout=5,
            verify=True,
        )

    @patch("requests.request")
    def test_list_gpus(self, mock_request, client, mock_response):
        """Test list GPUs endpoint."""
        mock_response.json.return_value = [
            {"name": "NVIDIA GTX 1080", "temperature_celsius": 65},
        ]
        mock_request.return_value = mock_response

        result = client.list_gpus()

        assert len(result) == 1
        assert result[0].name == "NVIDIA GTX 1080"
        assert result[0].temperature_celsius == 65

    @patch("requests.request")
    def test_get_ups_info(self, mock_request, client, mock_response):
        """Test get UPS info endpoint."""
        mock_response.json.return_value = {
            "model": "APC Smart-UPS",
            "battery_charge_percent": 100.0,
            "status": "ONLINE",
        }
        mock_request.return_value = mock_response

        result = client.get_ups_info()

        assert result.model == "APC Smart-UPS"
        assert result.battery_charge_percent == 100.0

    # New endpoint tests

    @patch("requests.request")
    def test_get_registration_info(self, mock_request, client, mock_response):
        """Test get registration info endpoint."""
        mock_response.json.return_value = {"type": "Pro", "state": "REGISTERED"}
        mock_request.return_value = mock_response

        result = client.get_registration_info()
        assert result.type == "Pro"
        assert result.state == "REGISTERED"

    @patch("requests.request")
    def test_list_logs(self, mock_request, client, mock_response):
        """Test list logs endpoint."""
        mock_response.json.return_value = {"logs": [{"name": "syslog", "path": "/var/log/syslog"}]}
        mock_request.return_value = mock_response

        result = client.list_logs()
        assert len(result.logs) == 1
        assert result.logs[0].name == "syslog"

    @patch("requests.request")
    def test_get_log(self, mock_request, client, mock_response):
        """Test get log content endpoint."""
        mock_response.json.return_value = {
            "path": "/var/log/syslog",
            "lines": ["line1", "line2"],
            "lines_returned": 2,
        }
        mock_request.return_value = mock_response

        result = client.get_log("syslog", lines=2)
        assert result.lines_returned == 2
        assert len(result.lines) == 2

    @patch("requests.request")
    def test_list_notifications(self, mock_request, client, mock_response):
        """Test list notifications endpoint."""
        mock_response.json.return_value = {
            "overview": {"unread": {"total": 0}, "archive": {"total": 0}},
            "notifications": None,
        }
        mock_request.return_value = mock_response

        result = client.list_notifications()
        assert result.overview.unread.total == 0

    @patch("requests.request")
    def test_get_notification_overview(self, mock_request, client, mock_response):
        """Test get notification overview endpoint."""
        mock_response.json.return_value = {
            "unread": {"total": 5},
            "archive": {"total": 10},
        }
        mock_request.return_value = mock_response

        result = client.get_notification_overview()
        assert result.unread.total == 5

    @patch("requests.request")
    def test_get_unassigned_info(self, mock_request, client, mock_response):
        """Test get unassigned info endpoint."""
        mock_response.json.return_value = {"devices": [], "remote_shares": []}
        mock_request.return_value = mock_response

        result = client.get_unassigned_info()
        assert result.devices == []

    @patch("requests.request")
    def test_list_unassigned_devices(self, mock_request, client, mock_response):
        """Test list unassigned devices endpoint."""
        mock_response.json.return_value = {"devices": None}
        mock_request.return_value = mock_response

        result = client.list_unassigned_devices()
        assert result.devices is None

    @patch("requests.request")
    def test_list_remote_shares(self, mock_request, client, mock_response):
        """Test list remote shares endpoint."""
        mock_response.json.return_value = {"remote_shares": None}
        mock_request.return_value = mock_response

        result = client.list_remote_shares()
        assert result.remote_shares is None

    @patch("requests.request")
    def test_get_hardware_full_info(self, mock_request, client, mock_response):
        """Test get hardware full info endpoint."""
        mock_response.json.return_value = {"bios": {"vendor": "AMI"}}
        mock_request.return_value = mock_response

        result = client.get_hardware_full_info()
        assert result.bios["vendor"] == "AMI"

    @patch("requests.request")
    def test_get_network_access_urls(self, mock_request, client, mock_response):
        """Test get network access URLs endpoint."""
        mock_response.json.return_value = {
            "urls": [{"type": "lan", "name": "LAN", "ipv4": "http://192.168.1.1"}]
        }
        mock_request.return_value = mock_response

        result = client.get_network_access_urls()
        assert len(result.urls) == 1
        assert result.urls[0].type == "lan"

    @patch("requests.request")
    def test_get_system_settings(self, mock_request, client, mock_response):
        """Test get system settings endpoint."""
        mock_response.json.return_value = {"server_name": "Unraid"}
        mock_request.return_value = mock_response

        result = client.get_system_settings()
        assert result.server_name == "Unraid"

    @patch("requests.request")
    def test_get_docker_settings(self, mock_request, client, mock_response):
        """Test get docker settings endpoint."""
        mock_response.json.return_value = {"enabled": True}
        mock_request.return_value = mock_response

        result = client.get_docker_settings()
        assert result.enabled is True

    @patch("requests.request")
    def test_get_vm_settings(self, mock_request, client, mock_response):
        """Test get VM settings endpoint."""
        mock_response.json.return_value = {"enabled": True}
        mock_request.return_value = mock_response

        result = client.get_vm_settings()
        assert result.enabled is True

    @patch("requests.request")
    def test_get_disk_settings(self, mock_request, client, mock_response):
        """Test get disk settings endpoint."""
        mock_response.json.return_value = {"spindown_delay_minutes": 30}
        mock_request.return_value = mock_response

        result = client.get_disk_settings()
        assert result.spindown_delay_minutes == 30

    @patch("requests.request")
    def test_list_user_scripts(self, mock_request, client, mock_response):
        """Test list user scripts endpoint."""
        mock_response.json.return_value = [{"name": "backup", "running": False}]
        mock_request.return_value = mock_response

        result = client.list_user_scripts()
        assert len(result) == 1
        assert result[0].name == "backup"

    @patch("requests.request")
    def test_get_parity_history(self, mock_request, client, mock_response):
        """Test get parity history endpoint."""
        mock_response.json.return_value = {"records": [{"date": "2024-01-01"}]}
        mock_request.return_value = mock_response

        result = client.get_parity_history()
        assert len(result.records) == 1

    @patch("requests.request")
    def test_list_zfs_pools(self, mock_request, client, mock_response):
        """Test list ZFS pools endpoint."""
        mock_response.json.return_value = [{"name": "pool1", "health": "ONLINE"}]
        mock_request.return_value = mock_response

        result = client.list_zfs_pools()
        assert len(result) == 1
        assert result[0].name == "pool1"

    @patch("requests.request")
    def test_list_zfs_datasets(self, mock_request, client, mock_response):
        """Test list ZFS datasets endpoint."""
        mock_response.json.return_value = [{"name": "pool1/data"}]
        mock_request.return_value = mock_response

        result = client.list_zfs_datasets()
        assert len(result) == 1

    @patch("requests.request")
    def test_list_zfs_snapshots(self, mock_request, client, mock_response):
        """Test list ZFS snapshots endpoint."""
        mock_response.json.return_value = [{"name": "pool1@snap1"}]
        mock_request.return_value = mock_response

        result = client.list_zfs_snapshots()
        assert len(result) == 1

    @patch("requests.request")
    def test_get_zfs_arc_stats(self, mock_request, client, mock_response):
        """Test get ZFS ARC stats endpoint."""
        mock_response.json.return_value = {"hit_ratio_percent": 95.5}
        mock_request.return_value = mock_response

        result = client.get_zfs_arc_stats()
        assert result.hit_ratio_percent == 95.5

    @patch("requests.request")
    def test_get_nut_info(self, mock_request, client, mock_response):
        """Test get NUT info endpoint."""
        mock_response.json.return_value = {"installed": True, "running": True}
        mock_request.return_value = mock_response

        result = client.get_nut_info()
        assert result.installed is True

    @patch("requests.request")
    def test_get_collectors_status(self, mock_request, client, mock_response):
        """Test get collectors status endpoint."""
        mock_response.json.return_value = {"total": 10, "enabled_count": 8}
        mock_request.return_value = mock_response

        result = client.get_collectors_status()
        assert result.total == 10
        assert result.enabled_count == 8

    @patch("requests.request")
    def test_404_error(self, mock_request, client):
        """Test 404 error handling."""
        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 404
        mock_response.json.return_value = {
            "success": False,
            "error_code": "DISK_NOT_FOUND",
            "message": "Disk not found",
        }
        mock_request.return_value = mock_response

        with pytest.raises(UnraidNotFoundError) as exc_info:
            client.get_disk("nonexistent")

        assert exc_info.value.error_code == "DISK_NOT_FOUND"
        assert exc_info.value.status_code == 404

    @patch("requests.request")
    def test_409_error(self, mock_request, client):
        """Test 409 conflict error handling."""
        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 409
        mock_response.json.return_value = {
            "success": False,
            "error_code": "ARRAY_ALREADY_STARTED",
            "message": "Array is already running",
        }
        mock_request.return_value = mock_response

        with pytest.raises(UnraidConflictError) as exc_info:
            client.start_array()

        assert exc_info.value.error_code == "ARRAY_ALREADY_STARTED"
        assert exc_info.value.status_code == 409

    @patch("requests.request")
    def test_400_error(self, mock_request, client):
        """Test 400 validation error handling."""
        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 400
        mock_response.json.return_value = {
            "success": False,
            "error_code": "VALIDATION_ERROR",
            "message": "Invalid parameters",
        }
        mock_request.return_value = mock_response

        with pytest.raises(UnraidValidationError) as exc_info:
            client.get_disk("invalid")

        assert exc_info.value.error_code == "VALIDATION_ERROR"
        assert exc_info.value.status_code == 400

    @patch("requests.request")
    def test_connection_error(self, mock_request, client):
        """Test connection error handling."""
        mock_request.side_effect = requests.exceptions.ConnectionError("Connection failed")

        with pytest.raises(UnraidConnectionError) as exc_info:
            client.get_system_info()

        assert "Unable to connect" in str(exc_info.value)

    @patch("requests.request")
    def test_timeout_error(self, mock_request, client):
        """Test timeout error handling."""
        mock_request.side_effect = requests.exceptions.Timeout("Request timed out")

        with pytest.raises(UnraidConnectionError) as exc_info:
            client.get_system_info()

        assert "timed out" in str(exc_info.value)

    @patch("requests.request")
    def test_generic_api_error(self, mock_request, client):
        """Test generic API error handling."""
        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 500
        mock_response.json.return_value = {
            "success": False,
            "error_code": "INTERNAL_ERROR",
            "message": "Internal server error",
        }
        mock_request.return_value = mock_response

        with pytest.raises(UnraidAPIError) as exc_info:
            client.get_system_info()

        assert exc_info.value.error_code == "INTERNAL_ERROR"
        assert exc_info.value.status_code == 500

    @patch("requests.request")
    def test_request_exception(self, mock_request, client):
        """Test generic request exception handling."""
        mock_request.side_effect = requests.exceptions.RequestException("Request failed")

        with pytest.raises(UnraidConnectionError) as exc_info:
            client.get_system_info()

        assert "Request failed" in str(exc_info.value)

    @patch("requests.request")
    def test_error_response_without_json(self, mock_request, client):
        """Test error response without valid JSON."""
        mock_response = Mock(spec=requests.Response)
        mock_response.status_code = 500
        mock_response.json.side_effect = ValueError("No JSON")
        mock_response.text = "Internal Server Error"
        mock_request.return_value = mock_response

        with pytest.raises(UnraidAPIError) as exc_info:
            client.get_system_info()

        assert "Internal Server Error" in str(exc_info.value.message)


class TestModels:
    """Test Pydantic models."""

    def test_system_info_model(self):
        """Test SystemInfo model."""
        data = {
            "hostname": "TestServer",
            "cpu_usage_percent": 25.5,
            "ram_usage_percent": 50.0,
            "extra_field": "should be allowed",
        }
        info = SystemInfo.model_validate(data)
        assert info.hostname == "TestServer"
        assert info.cpu_usage_percent == 25.5

    def test_array_status_model(self):
        """Test ArrayStatus model."""
        data = {"state": "STARTED", "total_disks": 10}
        status = ArrayStatus.model_validate(data)
        assert status.state == "STARTED"
        assert status.total_disks == 10

    def test_disk_info_model(self):
        """Test DiskInfo model."""
        data = {"name": "disk1", "temperature_celsius": 35.5}
        disk = DiskInfo.model_validate(data)
        assert disk.name == "disk1"
        assert disk.temperature_celsius == 35.5

    def test_container_info_model(self):
        """Test ContainerInfo model."""
        data = {"name": "plex", "state": "running", "image": "plexinc/pms-docker"}
        container = ContainerInfo.model_validate(data)
        assert container.name == "plex"
        assert container.state == "running"

    def test_action_response_model(self):
        """Test ActionResponse model."""
        data = {"success": True, "message": "Action completed"}
        response = ActionResponse.model_validate(data)
        assert response.success is True
        assert response.message == "Action completed"

    def test_health_status_model(self):
        """Test HealthStatus model."""
        data = {"status": "ok"}
        health = HealthStatus.model_validate(data)
        assert health.status == "ok"
