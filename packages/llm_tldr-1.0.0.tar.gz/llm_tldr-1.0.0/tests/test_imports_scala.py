"""Tests for Scala import parsing.

TDD Tests for Scala import support.

Scala import syntax:
- import package.Module
- import package.{A, B, C}  (selective imports)
- import package._          (wildcard import)
- import package.Module.{member => alias}  (with rename)
"""
import pytest
import tempfile
from pathlib import Path

# Check if tree-sitter-scala is available
try:
    from tldr.cross_file_calls import parse_scala_imports, TREE_SITTER_SCALA_AVAILABLE
    SCALA_AVAILABLE = TREE_SITTER_SCALA_AVAILABLE
except ImportError:
    SCALA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not SCALA_AVAILABLE, reason="tree-sitter-scala not available")


@pytest.fixture
def simple_imports_file(tmp_path):
    """Create a Scala file with simple imports."""
    code = '''
import scala.collection.mutable.ListBuffer
import scala.util.Try

object Example {
  def process(items: ListBuffer[String]): Try[Int] = {
    Try(items.length)
  }
}
'''
    file_path = tmp_path / "Example.scala"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def wildcard_imports_file(tmp_path):
    """Create a Scala file with wildcard imports."""
    code = '''
import scala.collection.mutable._
import scala.util._

object Example {
  def process(): Unit = {}
}
'''
    file_path = tmp_path / "Example.scala"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def selective_imports_file(tmp_path):
    """Create a Scala file with selective imports (multiple from one package)."""
    code = '''
import scala.util.{Try, Success, Failure}
import scala.collection.mutable.{ListBuffer, ArrayBuffer}

object Example {
  def process(): Try[Int] = {
    Success(42)
  }
}
'''
    file_path = tmp_path / "Example.scala"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def aliased_imports_file(tmp_path):
    """Create a Scala file with aliased imports."""
    code = '''
import scala.collection.mutable.{ListBuffer => LB}
import scala.util.{Try => Attempt}

object Example {
  def process(): LB[Int] = {
    LB(1, 2, 3)
  }
}
'''
    file_path = tmp_path / "Example.scala"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create a Scala file with mixed imports."""
    code = '''
package com.example.app

import scala.collection.mutable.ListBuffer
import scala.util.{Try, Success, Failure}
import scala.math._
import java.util.{List => JList}
import com.example.util.Helper

object Example {
  def process(): Unit = {}
}
'''
    file_path = tmp_path / "Example.scala"
    file_path.write_text(code)
    return file_path


class TestSimpleImports:
    """Test basic import parsing."""

    def test_parses_simple_imports(self, simple_imports_file):
        imports = parse_scala_imports(simple_imports_file)
        assert len(imports) == 2
        modules = [imp['module'] for imp in imports]
        assert 'scala.collection.mutable.ListBuffer' in modules
        assert 'scala.util.Try' in modules

    def test_wildcard_imports(self, wildcard_imports_file):
        imports = parse_scala_imports(wildcard_imports_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        assert any('scala.collection.mutable' in m for m in modules)
        assert any('scala.util' in m for m in modules)


class TestSelectiveImports:
    """Test selective import scenarios (curly brace syntax)."""

    def test_selective_imports(self, selective_imports_file):
        imports = parse_scala_imports(selective_imports_file)
        # Should parse the selective imports
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        # Check that items from selective imports are captured
        assert any('Try' in m or 'Success' in m or 'scala.util' in m for m in modules)

    def test_aliased_imports(self, aliased_imports_file):
        imports = parse_scala_imports(aliased_imports_file)
        assert len(imports) >= 2
        # Should capture the original module or the alias
        modules = [imp['module'] for imp in imports]
        assert any('ListBuffer' in m or 'mutable' in m for m in modules)


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_scala_imports(mixed_imports_file)
        # Should have all imports
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('scala.collection' in m for m in modules)
        assert any('Helper' in m or 'com.example' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "Empty.scala"
        file_path.write_text("object Empty {}")
        imports = parse_scala_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "NonExistent.scala"
        imports = parse_scala_imports(file_path)
        assert imports == []

    def test_only_package_declaration(self, tmp_path):
        code = '''
package com.example

object NoImports {
  def test(): Unit = {}
}
'''
        file_path = tmp_path / "NoImports.scala"
        file_path.write_text(code)
        imports = parse_scala_imports(file_path)
        assert imports == []
