"""
Tests for tldr/diagnostics.py
"""

import json
import subprocess
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tldr.diagnostics import (
    get_diagnostics,
    get_project_diagnostics,
    format_diagnostics_for_llm,
    _detect_language,
    _parse_pyright_output,
    _parse_ruff_output,
    _parse_tsc_output,
    _parse_go_vet_output,
    _parse_golangci_lint_output,
    _parse_cargo_check_output,
    _parse_clippy_output,
    _parse_rubocop_output,
    _parse_phpstan_output,
    _parse_ktlint_output,
    _parse_swiftlint_output,
    _parse_cppcheck_output,
    _parse_credo_output,
    LANG_TOOLS,
)


class TestLanguageDetection:
    """Test automatic language detection from file extension."""

    def test_python_extensions(self):
        assert _detect_language("test.py") == "python"
        assert _detect_language("/path/to/module.py") == "python"

    def test_typescript_extensions(self):
        assert _detect_language("test.ts") == "typescript"
        assert _detect_language("test.tsx") == "typescript"
        assert _detect_language("/path/to/component.tsx") == "typescript"

    def test_javascript_extensions(self):
        assert _detect_language("test.js") == "javascript"
        assert _detect_language("test.jsx") == "javascript"

    def test_go_extension(self):
        assert _detect_language("main.go") == "go"

    def test_rust_extension(self):
        assert _detect_language("lib.rs") == "rust"

    def test_unknown_extension(self):
        assert _detect_language("file.xyz") == "unknown"
        assert _detect_language("Makefile") == "unknown"

    def test_java_extension(self):
        assert _detect_language("Main.java") == "java"

    def test_c_cpp_extensions(self):
        assert _detect_language("main.c") == "c"
        assert _detect_language("main.cpp") == "cpp"
        assert _detect_language("main.cc") == "cpp"
        assert _detect_language("main.cxx") == "cpp"
        assert _detect_language("header.h") == "c"
        assert _detect_language("header.hpp") == "cpp"

    def test_ruby_extension(self):
        assert _detect_language("app.rb") == "ruby"

    def test_php_extension(self):
        assert _detect_language("index.php") == "php"

    def test_kotlin_extension(self):
        assert _detect_language("Main.kt") == "kotlin"

    def test_swift_extension(self):
        assert _detect_language("App.swift") == "swift"

    def test_csharp_extension(self):
        assert _detect_language("Program.cs") == "csharp"

    def test_scala_extension(self):
        assert _detect_language("Main.scala") == "scala"

    def test_elixir_extension(self):
        assert _detect_language("app.ex") == "elixir"
        assert _detect_language("app.exs") == "elixir"


class TestPyrightParsing:
    """Test parsing of pyright JSON output."""

    def test_parse_empty_output(self):
        result = _parse_pyright_output("{}")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_pyright_output("not json")
        assert result == []

    def test_parse_diagnostics(self):
        pyright_output = json.dumps({
            "generalDiagnostics": [
                {
                    "file": "/path/test.py",
                    "range": {
                        "start": {"line": 4, "character": 10},
                        "end": {"line": 4, "character": 15},
                    },
                    "severity": 1,
                    "message": "Type mismatch",
                    "rule": "reportArgumentType",
                }
            ]
        })
        result = _parse_pyright_output(pyright_output)
        assert len(result) == 1
        assert result[0]["file"] == "/path/test.py"
        assert result[0]["line"] == 5  # 1-indexed
        assert result[0]["column"] == 11  # 1-indexed
        assert result[0]["message"] == "Type mismatch"
        assert result[0]["source"] == "pyright"


class TestRuffParsing:
    """Test parsing of ruff JSON output."""

    def test_parse_empty_output(self):
        result = _parse_ruff_output("[]")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_ruff_output("not json")
        assert result == []

    def test_parse_diagnostics(self):
        ruff_output = json.dumps([
            {
                "filename": "/path/test.py",
                "location": {"row": 10, "column": 5},
                "message": "Unused import",
                "code": "F401",
            }
        ])
        result = _parse_ruff_output(ruff_output)
        assert len(result) == 1
        assert result[0]["file"] == "/path/test.py"
        assert result[0]["line"] == 10
        assert result[0]["column"] == 5
        assert result[0]["message"] == "Unused import"
        assert result[0]["rule"] == "F401"
        assert result[0]["source"] == "ruff"


class TestTscParsing:
    """Test parsing of tsc output."""

    def test_parse_empty_output(self):
        result = _parse_tsc_output("")
        assert result == []

    def test_parse_error(self):
        tsc_output = "src/main.ts(5,10): error TS2345: Argument of type 'string' is not assignable"
        result = _parse_tsc_output(tsc_output)
        assert len(result) == 1
        assert result[0]["file"] == "src/main.ts"
        assert result[0]["line"] == 5
        assert result[0]["column"] == 10
        assert result[0]["severity"] == "error"
        assert result[0]["rule"] == "TS2345"
        assert result[0]["source"] == "tsc"

    def test_parse_multiple_errors(self):
        tsc_output = """src/a.ts(1,1): error TS1001: First error
src/b.ts(2,3): warning TS2002: Second warning"""
        result = _parse_tsc_output(tsc_output)
        assert len(result) == 2
        assert result[0]["file"] == "src/a.ts"
        assert result[1]["file"] == "src/b.ts"


class TestGoVetParsing:
    """Test parsing of go vet output."""

    def test_parse_empty_output(self):
        result = _parse_go_vet_output("")
        assert result == []

    def test_parse_go_vet_error(self):
        # go vet format: file.go:line:col: message
        go_vet_output = "main.go:10:5: unreachable code"
        result = _parse_go_vet_output(go_vet_output)
        assert len(result) == 1
        assert result[0]["file"] == "main.go"
        assert result[0]["line"] == 10
        assert result[0]["column"] == 5
        assert result[0]["message"] == "unreachable code"
        assert result[0]["source"] == "go vet"

    def test_parse_multiple_go_vet_errors(self):
        go_vet_output = """main.go:10:5: unreachable code
util.go:20:1: suspicious call"""
        result = _parse_go_vet_output(go_vet_output)
        assert len(result) == 2


class TestGolangciLintParsing:
    """Test parsing of golangci-lint JSON output."""

    def test_parse_empty_output(self):
        result = _parse_golangci_lint_output("{}")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_golangci_lint_output("not json")
        assert result == []

    def test_parse_golangci_lint_output(self):
        output = json.dumps({
            "Issues": [
                {
                    "FromLinter": "gosimple",
                    "Text": "should use a simple channel send",
                    "Pos": {
                        "Filename": "main.go",
                        "Line": 42,
                        "Column": 10
                    }
                }
            ]
        })
        result = _parse_golangci_lint_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "main.go"
        assert result[0]["line"] == 42
        assert result[0]["column"] == 10
        assert result[0]["rule"] == "gosimple"
        assert result[0]["source"] == "golangci-lint"


class TestCargoCheckParsing:
    """Test parsing of cargo check JSON output."""

    def test_parse_empty_output(self):
        result = _parse_cargo_check_output("")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_cargo_check_output("not json")
        assert result == []

    def test_parse_cargo_check_output(self):
        # cargo outputs one JSON object per line
        output = json.dumps({
            "reason": "compiler-message",
            "message": {
                "code": {"code": "E0308"},
                "level": "error",
                "message": "mismatched types",
                "spans": [
                    {
                        "file_name": "src/main.rs",
                        "line_start": 10,
                        "column_start": 5
                    }
                ]
            }
        })
        result = _parse_cargo_check_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "src/main.rs"
        assert result[0]["line"] == 10
        assert result[0]["column"] == 5
        assert result[0]["severity"] == "error"
        assert result[0]["rule"] == "E0308"
        assert result[0]["source"] == "cargo"


class TestClippyParsing:
    """Test parsing of cargo clippy JSON output."""

    def test_parse_empty_output(self):
        result = _parse_clippy_output("")
        assert result == []

    def test_parse_clippy_output(self):
        # clippy uses the same format as cargo check
        output = json.dumps({
            "reason": "compiler-message",
            "message": {
                "code": {"code": "clippy::unwrap_used"},
                "level": "warning",
                "message": "used `unwrap()` on a Result value",
                "spans": [
                    {
                        "file_name": "src/lib.rs",
                        "line_start": 25,
                        "column_start": 8
                    }
                ]
            }
        })
        result = _parse_clippy_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "src/lib.rs"
        assert result[0]["line"] == 25
        assert result[0]["severity"] == "warning"
        assert result[0]["source"] == "clippy"


class TestRubocopParsing:
    """Test parsing of rubocop JSON output."""

    def test_parse_empty_output(self):
        result = _parse_rubocop_output("{}")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_rubocop_output("not json")
        assert result == []

    def test_parse_rubocop_output(self):
        output = json.dumps({
            "files": [
                {
                    "path": "app.rb",
                    "offenses": [
                        {
                            "severity": "warning",
                            "message": "Missing magic comment",
                            "cop_name": "Style/FrozenStringLiteralComment",
                            "location": {
                                "line": 1,
                                "column": 1
                            }
                        }
                    ]
                }
            ]
        })
        result = _parse_rubocop_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "app.rb"
        assert result[0]["line"] == 1
        assert result[0]["rule"] == "Style/FrozenStringLiteralComment"
        assert result[0]["source"] == "rubocop"


class TestPhpstanParsing:
    """Test parsing of phpstan JSON output."""

    def test_parse_empty_output(self):
        result = _parse_phpstan_output("{}")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_phpstan_output("not json")
        assert result == []

    def test_parse_phpstan_output(self):
        output = json.dumps({
            "files": {
                "/path/to/index.php": {
                    "messages": [
                        {
                            "message": "Undefined variable: $foo",
                            "line": 15
                        }
                    ]
                }
            }
        })
        result = _parse_phpstan_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "/path/to/index.php"
        assert result[0]["line"] == 15
        assert result[0]["message"] == "Undefined variable: $foo"
        assert result[0]["source"] == "phpstan"


class TestKtlintParsing:
    """Test parsing of ktlint JSON output."""

    def test_parse_empty_output(self):
        result = _parse_ktlint_output("[]")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_ktlint_output("not json")
        assert result == []

    def test_parse_ktlint_output(self):
        output = json.dumps([
            {
                "file": "Main.kt",
                "errors": [
                    {
                        "line": 10,
                        "column": 5,
                        "message": "Missing newline",
                        "rule": "final-newline"
                    }
                ]
            }
        ])
        result = _parse_ktlint_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "Main.kt"
        assert result[0]["line"] == 10
        assert result[0]["rule"] == "final-newline"
        assert result[0]["source"] == "ktlint"


class TestSwiftlintParsing:
    """Test parsing of swiftlint JSON output."""

    def test_parse_empty_output(self):
        result = _parse_swiftlint_output("[]")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_swiftlint_output("not json")
        assert result == []

    def test_parse_swiftlint_output(self):
        output = json.dumps([
            {
                "file": "/path/App.swift",
                "line": 20,
                "column": 1,
                "severity": "Warning",
                "type": "Line Length",
                "rule_id": "line_length",
                "reason": "Line should be 120 characters or less"
            }
        ])
        result = _parse_swiftlint_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "/path/App.swift"
        assert result[0]["line"] == 20
        assert result[0]["severity"] == "warning"
        assert result[0]["rule"] == "line_length"
        assert result[0]["source"] == "swiftlint"


class TestCppcheckParsing:
    """Test parsing of cppcheck XML output."""

    def test_parse_empty_output(self):
        result = _parse_cppcheck_output("")
        assert result == []

    def test_parse_cppcheck_output(self):
        # cppcheck --xml format
        output = '''<?xml version="1.0" encoding="UTF-8"?>
<results version="2">
    <errors>
        <error id="uninitvar" severity="error" msg="Uninitialized variable: x">
            <location file="main.c" line="10" column="5"/>
        </error>
    </errors>
</results>'''
        result = _parse_cppcheck_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "main.c"
        assert result[0]["line"] == 10
        assert result[0]["column"] == 5
        assert result[0]["severity"] == "error"
        assert result[0]["rule"] == "uninitvar"
        assert result[0]["source"] == "cppcheck"


class TestCredoParsing:
    """Test parsing of credo JSON output."""

    def test_parse_empty_output(self):
        result = _parse_credo_output("{}")
        assert result == []

    def test_parse_invalid_json(self):
        result = _parse_credo_output("not json")
        assert result == []

    def test_parse_credo_output(self):
        output = json.dumps({
            "issues": [
                {
                    "category": "readability",
                    "check": "Credo.Check.Readability.ModuleDoc",
                    "message": "Modules should have a @moduledoc tag",
                    "filename": "lib/app.ex",
                    "line_no": 1,
                    "column": 1,
                    "priority": 10
                }
            ]
        })
        result = _parse_credo_output(output)
        assert len(result) == 1
        assert result[0]["file"] == "lib/app.ex"
        assert result[0]["line"] == 1
        assert result[0]["rule"] == "Credo.Check.Readability.ModuleDoc"
        assert result[0]["source"] == "credo"


class TestLangToolsMapping:
    """Test the LANG_TOOLS dictionary mapping."""

    def test_lang_tools_exists(self):
        assert LANG_TOOLS is not None
        assert isinstance(LANG_TOOLS, dict)

    def test_python_tools(self):
        assert "python" in LANG_TOOLS
        assert LANG_TOOLS["python"]["type_checker"] == "pyright"
        assert LANG_TOOLS["python"]["linter"] == "ruff"

    def test_typescript_tools(self):
        assert "typescript" in LANG_TOOLS
        assert LANG_TOOLS["typescript"]["type_checker"] == "tsc"

    def test_go_tools(self):
        assert "go" in LANG_TOOLS
        assert LANG_TOOLS["go"]["type_checker"] == "go vet"
        assert LANG_TOOLS["go"]["linter"] == "golangci-lint"

    def test_rust_tools(self):
        assert "rust" in LANG_TOOLS
        assert LANG_TOOLS["rust"]["type_checker"] == "cargo check"
        assert LANG_TOOLS["rust"]["linter"] == "clippy"

    def test_ruby_tools(self):
        assert "ruby" in LANG_TOOLS
        assert LANG_TOOLS["ruby"]["linter"] == "rubocop"

    def test_php_tools(self):
        assert "php" in LANG_TOOLS
        assert LANG_TOOLS["php"]["linter"] == "phpstan"

    def test_kotlin_tools(self):
        assert "kotlin" in LANG_TOOLS
        assert LANG_TOOLS["kotlin"]["linter"] == "ktlint"

    def test_swift_tools(self):
        assert "swift" in LANG_TOOLS
        assert LANG_TOOLS["swift"]["linter"] == "swiftlint"

    def test_c_cpp_tools(self):
        assert "c" in LANG_TOOLS
        assert "cpp" in LANG_TOOLS
        assert LANG_TOOLS["c"]["linter"] == "cppcheck"
        assert LANG_TOOLS["cpp"]["linter"] == "cppcheck"

    def test_elixir_tools(self):
        assert "elixir" in LANG_TOOLS
        assert LANG_TOOLS["elixir"]["type_checker"] == "mix compile"
        assert LANG_TOOLS["elixir"]["linter"] == "credo"


class TestGetDiagnosticsNewLanguages:
    """Test get_diagnostics for newly added languages."""

    def test_go_diagnostics_with_mocked_tools(self, tmp_path):
        test_file = tmp_path / "main.go"
        test_file.write_text('package main\n\nfunc main() {}')

        go_vet_output = "main.go:3:1: missing return"

        def mock_which(cmd):
            if cmd == "go":
                return "/usr/bin/go"
            return None

        def mock_run(cmd, **kwargs):
            result = MagicMock()
            if "vet" in cmd:
                result.stdout = ""
                result.stderr = go_vet_output
                result.returncode = 1
            else:
                result.stdout = ""
                result.stderr = ""
                result.returncode = 0
            return result

        with patch("tldr.diagnostics.shutil.which", side_effect=mock_which):
            with patch("tldr.diagnostics.subprocess.run", side_effect=mock_run):
                result = get_diagnostics(str(test_file))

        assert result["language"] == "go"
        assert "go vet" in result["tools"]

    def test_rust_diagnostics_with_mocked_tools(self, tmp_path):
        test_file = tmp_path / "lib.rs"
        test_file.write_text('fn main() {}')

        cargo_output = json.dumps({
            "reason": "compiler-message",
            "message": {
                "code": {"code": "E0308"},
                "level": "error",
                "message": "mismatched types",
                "spans": [{"file_name": str(test_file), "line_start": 1, "column_start": 1}]
            }
        })

        def mock_which(cmd):
            if cmd == "cargo":
                return "/usr/bin/cargo"
            return None

        def mock_run(cmd, **kwargs):
            result = MagicMock()
            if "check" in cmd:
                result.stdout = cargo_output
                result.stderr = ""
                result.returncode = 1
            else:
                result.stdout = ""
                result.stderr = ""
                result.returncode = 0
            return result

        with patch("tldr.diagnostics.shutil.which", side_effect=mock_which):
            with patch("tldr.diagnostics.subprocess.run", side_effect=mock_run):
                result = get_diagnostics(str(test_file))

        assert result["language"] == "rust"
        assert "cargo check" in result["tools"]

    def test_ruby_diagnostics_with_mocked_tools(self, tmp_path):
        test_file = tmp_path / "app.rb"
        test_file.write_text('puts "hello"')

        rubocop_output = json.dumps({
            "files": [{"path": str(test_file), "offenses": []}]
        })

        def mock_which(cmd):
            if cmd == "rubocop":
                return "/usr/bin/rubocop"
            return None

        def mock_run(cmd, **kwargs):
            result = MagicMock()
            result.stdout = rubocop_output
            result.stderr = ""
            result.returncode = 0
            return result

        with patch("tldr.diagnostics.shutil.which", side_effect=mock_which):
            with patch("tldr.diagnostics.subprocess.run", side_effect=mock_run):
                result = get_diagnostics(str(test_file))

        assert result["language"] == "ruby"
        assert "rubocop" in result["tools"]


class TestGetDiagnostics:
    """Test get_diagnostics function."""

    def test_file_not_found(self):
        result = get_diagnostics("/nonexistent/file.py")
        assert "error" in result
        assert result["diagnostics"] == []

    def test_with_mocked_pyright(self, tmp_path):
        # Create a test file
        test_file = tmp_path / "test.py"
        test_file.write_text("x: int = 'hello'")

        pyright_output = json.dumps({
            "generalDiagnostics": [
                {
                    "file": str(test_file),
                    "range": {"start": {"line": 0, "character": 0}},
                    "severity": 1,
                    "message": "Type error",
                    "rule": "reportAssignmentType",
                }
            ]
        })

        def mock_which(cmd):
            if cmd == "pyright":
                return "/usr/bin/pyright"
            return None  # ruff not available

        def mock_run(cmd, **kwargs):
            result = MagicMock()
            if "pyright" in cmd:
                result.stdout = pyright_output
                result.stderr = ""
                result.returncode = 1
            else:
                result.stdout = "[]"
                result.stderr = ""
                result.returncode = 0
            return result

        with patch("tldr.diagnostics.shutil.which", side_effect=mock_which):
            with patch("tldr.diagnostics.subprocess.run", side_effect=mock_run):
                result = get_diagnostics(str(test_file))

        assert result["language"] == "python"
        assert "pyright" in result["tools"]
        assert result["error_count"] >= 0

    def test_no_tools_available(self, tmp_path):
        test_file = tmp_path / "test.py"
        test_file.write_text("x = 1")

        with patch("tldr.diagnostics.shutil.which") as mock_which:
            mock_which.return_value = None
            result = get_diagnostics(str(test_file))

        assert result["tools"] == []
        assert result["diagnostics"] == []


class TestGetProjectDiagnostics:
    """Test get_project_diagnostics function."""

    def test_path_not_found(self):
        result = get_project_diagnostics("/nonexistent/project")
        assert "error" in result

    def test_with_mocked_tools(self, tmp_path):
        # Create project structure
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("x = 1")

        with patch("tldr.diagnostics.shutil.which") as mock_which:
            mock_which.return_value = None
            result = get_project_diagnostics(str(tmp_path))

        assert result["project"] == str(tmp_path)
        assert result["tools"] == []


class TestFormatForLLM:
    """Test LLM-friendly formatting."""

    def test_format_error(self):
        result = {"error": "File not found"}
        output = format_diagnostics_for_llm(result)
        assert "Error: File not found" in output

    def test_format_no_diagnostics(self):
        result = {"diagnostics": []}
        output = format_diagnostics_for_llm(result)
        assert "No diagnostics" in output

    def test_format_with_diagnostics(self):
        result = {
            "error_count": 1,
            "warning_count": 1,
            "diagnostics": [
                {
                    "file": "test.py",
                    "line": 5,
                    "column": 10,
                    "severity": "error",
                    "message": "Type error",
                    "rule": "E001",
                },
                {
                    "file": "test.py",
                    "line": 10,
                    "column": 1,
                    "severity": "warning",
                    "message": "Unused var",
                    "rule": "",
                },
            ],
        }
        output = format_diagnostics_for_llm(result)
        assert "1 errors" in output
        assert "1 warnings" in output
        assert "E test.py:5:10: Type error [E001]" in output
        assert "W test.py:10:1: Unused var" in output


class TestCLIIntegration:
    """Test CLI command integration."""

    def test_cli_help(self):
        result = subprocess.run(
            ["python", "-m", "tldr.cli", "diagnostics", "--help"],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0
        assert "diagnostics" in result.stdout
        assert "--project" in result.stdout
        assert "--no-lint" in result.stdout

    def test_cli_file_not_found(self):
        result = subprocess.run(
            ["python", "-m", "tldr.cli", "diagnostics", "/nonexistent/file.py"],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 1
        assert "not found" in result.stderr.lower()

    def test_cli_real_file(self, tmp_path):
        test_file = tmp_path / "test.py"
        test_file.write_text("x = 1")

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "diagnostics", str(test_file)],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert "diagnostics" in output
        assert "language" in output

    def test_cli_text_format(self, tmp_path):
        test_file = tmp_path / "test.py"
        test_file.write_text("x = 1")

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "diagnostics", str(test_file), "--format", "text"],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0
        # Text format should not be JSON
        try:
            json.loads(result.stdout)
            # If it parses as JSON, that's wrong for text format
            # (unless it's "No diagnostics found." which isn't JSON)
            assert "No diagnostics" in result.stdout or "errors" in result.stdout
        except json.JSONDecodeError:
            pass  # Expected for text format
