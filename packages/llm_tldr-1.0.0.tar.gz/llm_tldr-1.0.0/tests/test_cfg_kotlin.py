"""Tests for Kotlin CFG extraction.

TDD Tests for Kotlin CFG support.
Tests mirror the structure of test_cfg_java.py but for Kotlin language support.

Kotlin tree-sitter node types:
- function_declaration (fun keyword)
- call_expression
- if_expression
- when_expression (Kotlin's switch)
- for_statement
- while_statement
- try_expression
"""
import pytest

# Check if tree-sitter-kotlin is available
try:
    from tldr.cfg_extractor import extract_kotlin_cfg, TREE_SITTER_KOTLIN_AVAILABLE
    KOTLIN_AVAILABLE = TREE_SITTER_KOTLIN_AVAILABLE
except ImportError:
    KOTLIN_AVAILABLE = False


pytestmark = pytest.mark.skipif(not KOTLIN_AVAILABLE, reason="tree-sitter-kotlin not available")


@pytest.fixture
def simple_if_code():
    return '''
class Example {
    fun check(x: Int): String {
        if (x > 0) {
            return "positive"
        }
        return "non-positive"
    }
}
'''


@pytest.fixture
def for_loop_code():
    return '''
class Example {
    fun count(n: Int): Int {
        var sum = 0
        for (i in 0 until n) {
            sum += i
        }
        return sum
    }
}
'''


@pytest.fixture
def while_loop_code():
    return '''
class Example {
    fun countdown(n: Int): Int {
        var count = 0
        var remaining = n
        while (remaining > 0) {
            count++
            remaining--
        }
        return count
    }
}
'''


@pytest.fixture
def nested_code():
    return '''
class Example {
    fun process(items: List<Int>): Int {
        var count = 0
        for (item in items) {
            if (item > 0) {
                count++
            } else {
                count--
            }
        }
        return count
    }
}
'''


@pytest.fixture
def try_catch_code():
    return '''
class Example {
    fun divide(a: Int, b: Int): Int {
        return try {
            a / b
        } catch (e: ArithmeticException) {
            0
        }
    }
}
'''


@pytest.fixture
def when_code():
    return '''
class Example {
    fun getDay(day: Int): String {
        return when (day) {
            1 -> "Monday"
            2 -> "Tuesday"
            3 -> "Wednesday"
            else -> "Unknown"
        }
    }
}
'''


@pytest.fixture
def when_no_arg_code():
    return '''
class Example {
    fun classify(x: Int): String {
        return when {
            x < 0 -> "negative"
            x == 0 -> "zero"
            else -> "positive"
        }
    }
}
'''


@pytest.fixture
def elvis_operator_code():
    return '''
class Example {
    fun safeGet(value: String?): String {
        return value ?: "default"
    }
}
'''


class TestBasicCFG:
    """Test basic CFG extraction for Kotlin."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_kotlin_cfg(simple_if_code, "check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_for_loop(self, for_loop_code):
        cfg = extract_kotlin_cfg(for_loop_code, "count")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_kotlin_cfg(while_loop_code, "countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_function_name(self, simple_if_code):
        cfg = extract_kotlin_cfg(simple_if_code, "check")
        assert cfg is not None
        assert cfg.function_name == "check"


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_kotlin_cfg(nested_code, "process")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_try_catch(self, try_catch_code):
        cfg = extract_kotlin_cfg(try_catch_code, "divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_when_expression(self, when_code):
        cfg = extract_kotlin_cfg(when_code, "getDay")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_when_no_argument(self, when_no_arg_code):
        cfg = extract_kotlin_cfg(when_no_arg_code, "classify")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_kotlin_cfg(simple_if_code, "check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, for_loop_code):
        cfg = extract_kotlin_cfg(for_loop_code, "count")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge target {edge.target_id} not in blocks"

    def test_cyclomatic_complexity_simple(self, simple_if_code):
        cfg = extract_kotlin_cfg(simple_if_code, "check")
        # Simple if should have complexity >= 2 (one decision point)
        assert cfg.cyclomatic_complexity >= 2

    def test_cyclomatic_complexity_multiple_branches(self, when_code):
        cfg = extract_kotlin_cfg(when_code, "getDay")
        # when expressions are parsed but not counted as decision points in v1
        # A return-when pattern results in simpler CFG representation
        assert cfg.cyclomatic_complexity >= 1


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_kotlin_cfg(simple_if_code, "nonexistent")

    def test_empty_code(self):
        with pytest.raises((ValueError, Exception)):
            extract_kotlin_cfg("", "any")
