"""Tests for C++ DFG extraction.

TDD tests for C++ support in TLDR DFG extraction.
These tests mirror test_dfg_c.py patterns but for C++ constructs.

Expected to fail initially with ImportError (extract_cpp_dfg not implemented).
"""
import pytest

# Check if tree-sitter-cpp is available
try:
    from tldr.dfg_extractor import extract_cpp_dfg, TREE_SITTER_CPP_AVAILABLE
    CPP_AVAILABLE = TREE_SITTER_CPP_AVAILABLE
except ImportError:
    CPP_AVAILABLE = False


pytestmark = pytest.mark.skipif(not CPP_AVAILABLE, reason="tree-sitter-cpp not available")


@pytest.fixture
def simple_assignment_code():
    return '''
int calculate(int a, int b) {
    int x = a;
    int y = b;
    int result = x + y;
    return result;
}
'''


@pytest.fixture
def reassignment_code():
    return '''
int process(int n) {
    int x = n;
    x = x + 1;
    x = x * 2;
    return x;
}
'''


@pytest.fixture
def loop_variable_code():
    return '''
#include <vector>

int sum(const std::vector<int>& numbers) {
    int total = 0;
    for (const auto& num : numbers) {
        total = total + num;
    }
    return total;
}
'''


@pytest.fixture
def traditional_loop_code():
    return '''
int sum(int* numbers, int count) {
    int total = 0;
    for (int i = 0; i < count; i++) {
        total = total + numbers[i];
    }
    return total;
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
int choose(int x) {
    int result;
    if (x > 0) {
        result = 1;
    } else {
        result = -1;
    }
    return result;
}
'''


@pytest.fixture
def reference_code():
    return '''
void swap(int& a, int& b) {
    int temp = a;
    a = b;
    b = temp;
}
'''


@pytest.fixture
def vector_code():
    return '''
#include <vector>

int vector_sum(std::vector<int>& vec) {
    int total = 0;
    for (size_t i = 0; i < vec.size(); i++) {
        total += vec[i];
    }
    return total;
}
'''


@pytest.fixture
def chained_code():
    return '''
int chained_compute(int x) {
    int a = x + 1;
    int b = a * 2;
    int c = b + 3;
    return c;
}
'''


@pytest.fixture
def class_member_code():
    return '''
class Counter {
private:
    int value_;

public:
    void increment() {
        value_++;
    }

    void add(int amount) {
        int old_value = value_;
        value_ = old_value + amount;
    }
};
'''


class TestBasicDFG:
    """Test basic DFG extraction for C++."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_cpp_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_cpp_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_range_based_loop(self, loop_variable_code):
        dfg = extract_cpp_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_traditional_loop(self, traditional_loop_code):
        dfg = extract_cpp_dfg(traditional_loop_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_chained_data_flow(self, chained_code):
        dfg = extract_cpp_dfg(chained_code, "chained_compute")
        assert dfg is not None
        # Should have data flow edges for the chain x -> a -> b -> c
        assert len(dfg.dataflow_edges) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_cpp_dfg(simple_assignment_code, "calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_cpp_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_cpp_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_cpp_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_cpp_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0


class TestCppSpecificDFG:
    """Test C++-specific DFG patterns."""

    def test_reference_parameter(self, reference_code):
        dfg = extract_cpp_dfg(reference_code, "swap")
        assert dfg is not None
        # Should track temp variable
        temp_refs = [r for r in dfg.var_refs if r.name == "temp"]
        assert len(temp_refs) > 0

    def test_vector_access(self, vector_code):
        dfg = extract_cpp_dfg(vector_code, "vector_sum")
        assert dfg is not None
        # Should track total variable
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0


class TestClassMethodDFG:
    """Test DFG extraction from C++ class methods."""

    def test_method_member_access(self, class_member_code):
        dfg = extract_cpp_dfg(class_member_code, "add")
        assert dfg is not None
        # Should track old_value variable
        old_value_refs = [r for r in dfg.var_refs if r.name == "old_value"]
        assert len(old_value_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_cpp_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
