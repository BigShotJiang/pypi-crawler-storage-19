"""Tests for Java PDG extraction and program slicing (L5).

TDD Tests for Java PDG support.

Tests mirror the structure of test_api_pdg.py but for Java language support.
Java CFG (L3) and DFG (L4) already work - see test_cfg_java.py and test_dfg_java.py.
"""
import os
import pytest

# Check if tree-sitter-java is available
try:
    from tldr.cfg_extractor import TREE_SITTER_JAVA_AVAILABLE
    JAVA_AVAILABLE = TREE_SITTER_JAVA_AVAILABLE
except ImportError:
    JAVA_AVAILABLE = False

# Check if extract_java_pdg is implemented
try:
    from tldr.pdg_extractor import extract_java_pdg
    JAVA_PDG_AVAILABLE = True
except ImportError:
    JAVA_PDG_AVAILABLE = False
    extract_java_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not JAVA_AVAILABLE,
    reason="tree-sitter-java not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_java_path():
    """Path to Sample.java fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "Sample.java")


@pytest.fixture
def sample_java_code(sample_java_path):
    """Load Sample.java fixture code."""
    with open(sample_java_path) as f:
        return f.read()


@pytest.fixture
def chained_java_path():
    """Path to ChainedCompute.java fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "ChainedCompute.java")


@pytest.fixture
def chained_java_code(chained_java_path):
    """Load ChainedCompute.java fixture code."""
    with open(chained_java_path) as f:
        return f.read()


@pytest.fixture
def simple_java_code():
    """Simple Java code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
// =============================================================================
// Simple Java test fixture for PDG extraction
// This code is used to test basic PDG node and edge extraction.
// The add function has simple data flow: a -> c, b -> c, c -> return
// =============================================================================
public class Example {
    public int add(int a, int b) {
        int c = a + b;
        return c;
    }
}
'''


# =============================================================================
# Tests for extract_java_pdg()
# =============================================================================

class TestExtractJavaPDG:
    """Test extract_java_pdg() function."""

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_extract_java_pdg_basic(self, sample_java_code):
        """Test basic PDG extraction from Sample.java calculate function."""
        pdg = extract_java_pdg(sample_java_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_extract_java_pdg_has_nodes(self, sample_java_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_java_pdg(sample_java_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_extract_java_pdg_has_edges(self, sample_java_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_java_pdg(sample_java_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        # Note: PDGEdge uses dep_type attribute (control/data)
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_extract_java_pdg_sum_function(self, sample_java_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_java_pdg(sample_java_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_extract_java_pdg_nonexistent_function(self, sample_java_code):
        """Test that nonexistent function returns None."""
        pdg = extract_java_pdg(sample_java_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for Java Program Slicing
# =============================================================================

class TestJavaProgramSlicing:
    """Test program slicing for Java code."""

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_java_backward_slice(self, sample_java_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_java_pdg(sample_java_code, "sum")

        assert pdg is not None
        # Line 20 is "return total;" in Sample.java
        slice_lines = pdg.backward_slice(line=20)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_java_forward_slice(self, chained_java_code):
        """Test forward slice from first assignment."""
        pdg = extract_java_pdg(chained_java_code, "compute")

        assert pdg is not None
        # Forward slice from "int a = x + 1;" (line 15 in ChainedCompute.java)
        slice_lines = pdg.forward_slice(line=15)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_java_slice_returns_set(self, simple_java_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_java_pdg(simple_java_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=10)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_java_slice_nonexistent_function(self, sample_java_code):
        """Test that slicing nonexistent function returns empty set."""
        pdg = extract_java_pdg(sample_java_code, "nonexistent")

        # Either returns None (no PDG) or empty slice
        if pdg is None:
            # This is acceptable behavior
            pass
        else:
            slice_lines = pdg.backward_slice(line=10)
            assert slice_lines == set()


# =============================================================================
# Tests for Java PDG via API
# =============================================================================

class TestJavaPDGAPI:
    """Test Java PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_java_get_pdg_context(self, sample_java_path):
        """Test get_pdg_context() for Java code via file path."""
        result = get_pdg_context(sample_java_path, "calculate", language="java")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_java_get_slice_backward(self, sample_java_path):
        """Test get_slice() backward for Java code via file path."""
        # Backward slice from return statement in sum function
        lines = get_slice(
            sample_java_path, "sum", line=20,
            direction="backward", language="java"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_java_get_slice_forward(self, chained_java_path):
        """Test get_slice() forward for Java code via file path."""
        lines = get_slice(
            chained_java_path, "compute", line=15,
            direction="forward", language="java"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestJavaPDGIntegration:
    """Integration tests for Java PDG."""

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_pdg_from_file(self, sample_java_path, sample_java_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_java_pdg(sample_java_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not JAVA_PDG_AVAILABLE, reason="extract_java_pdg not implemented")
    def test_pdg_to_dict(self, simple_java_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_java_pdg(simple_java_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
