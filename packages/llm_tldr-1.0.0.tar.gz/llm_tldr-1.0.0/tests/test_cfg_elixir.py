"""Tests for Elixir CFG extraction.

TDD tests for Elixir language support in TLDR CFG extraction.
These tests should FAIL initially until Elixir support is implemented.

Elixir AST node types (tree-sitter-elixir):
- call: function calls (including def, defp, defmodule, if, case, cond)
- identifier: "def" or "defp" indicates function definition
- do_block: function/control structure body
- arguments: function arguments
- binary_operator: comparison, arithmetic
- tuple: tuple literals
"""
import pytest

# Check if tree-sitter-elixir is available
try:
    from tldr.cfg_extractor import extract_elixir_cfg, TREE_SITTER_ELIXIR_AVAILABLE
    ELIXIR_AVAILABLE = TREE_SITTER_ELIXIR_AVAILABLE
except ImportError:
    ELIXIR_AVAILABLE = False


pytestmark = pytest.mark.skipif(not ELIXIR_AVAILABLE, reason="tree-sitter-elixir not available")


@pytest.fixture
def simple_if_code():
    return '''
defmodule Example do
  def check(x) do
    if x > 0 do
      "positive"
    end
  end
end
'''


@pytest.fixture
def if_else_code():
    return '''
defmodule Example do
  def calculate(a, b) do
    if a > b do
      result = a - b
    else
      result = b - a
    end
    result
  end
end
'''


@pytest.fixture
def case_code():
    return '''
defmodule Example do
  def get_day(day) do
    case day do
      1 -> "Monday"
      2 -> "Tuesday"
      3 -> "Wednesday"
      _ -> "Unknown"
    end
  end
end
'''


@pytest.fixture
def cond_code():
    return '''
defmodule Example do
  def classify(n) do
    cond do
      n < 0 -> :negative
      n == 0 -> :zero
      n > 0 -> :positive
    end
  end
end
'''


@pytest.fixture
def enum_each_code():
    return '''
defmodule Example do
  def sum(numbers) do
    Enum.reduce(numbers, 0, fn n, acc ->
      acc + n
    end)
  end
end
'''


@pytest.fixture
def with_code():
    return '''
defmodule Example do
  def validate_and_process(data) do
    with {:ok, validated} <- validate(data),
         {:ok, processed} <- process(validated) do
      {:ok, processed}
    else
      {:error, reason} -> {:error, reason}
    end
  end
end
'''


@pytest.fixture
def nested_code():
    return '''
defmodule Example do
  def process(items) do
    Enum.map(items, fn item ->
      if item > 0 do
        case item do
          1 -> :one
          2 -> :two
          _ -> :other
        end
      else
        :negative
      end
    end)
  end
end
'''


@pytest.fixture
def guard_code():
    return '''
defmodule Example do
  def safe_divide(a, b) when b != 0 do
    a / b
  end

  def safe_divide(_a, _b) do
    {:error, :division_by_zero}
  end
end
'''


class TestBasicCFG:
    """Test basic CFG extraction for Elixir."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_elixir_cfg(simple_if_code, "check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_if_else(self, if_else_code):
        cfg = extract_elixir_cfg(if_else_code, "calculate")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have if-true and if-false branches
        assert len(cfg.blocks) >= 3

    def test_case_statement(self, case_code):
        cfg = extract_elixir_cfg(case_code, "get_day")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # case with 4 branches should produce multiple blocks
        assert len(cfg.blocks) >= 4

    def test_cond_statement(self, cond_code):
        cfg = extract_elixir_cfg(cond_code, "classify")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # cond with 3 conditions should produce multiple blocks
        assert len(cfg.blocks) >= 3


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_enum_iteration(self, enum_each_code):
        cfg = extract_elixir_cfg(enum_each_code, "sum")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have at least entry, body, and exit
        assert len(cfg.edges) >= 1

    def test_with_statement(self, with_code):
        cfg = extract_elixir_cfg(with_code, "validate_and_process")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # with has multiple potential failure branches

    def test_nested_control_flow(self, nested_code):
        cfg = extract_elixir_cfg(nested_code, "process")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Nested if inside case inside map should produce multiple blocks
        assert len(cfg.blocks) >= 4

    def test_guard_clause(self, guard_code):
        cfg = extract_elixir_cfg(guard_code, "safe_divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Guard adds branch - function clause matching


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_elixir_cfg(simple_if_code, "check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, case_code):
        cfg = extract_elixir_cfg(case_code, "get_day")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_elixir_cfg(simple_if_code, "nonexistent")
