"""Tests for semantic indexer enriched metadata extraction.

Tests for P6 semantic search enhancements:
- Actual line numbers (not hardcoded 1)
- CFG summary (complexity, block count)
- DFG summary (variable count, def-use chains)
- Dependencies (imports)
- Code preview (first 10 lines of function body)

Uses TDD approach: write tests first, then implement.
"""

import tempfile
from pathlib import Path

import pytest


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def enrichment_project():
    """Create a Python project with complex functions for enrichment testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create main.py with a function that has interesting CFG/DFG
        Path(tmpdir, "main.py").write_text('''"""Main module for data processing."""

import os
from pathlib import Path
from typing import List, Dict

def process_data(data: List[str], config: Dict) -> Dict:
    """Process input data with configuration.

    Args:
        data: List of strings to process.
        config: Configuration dictionary.

    Returns:
        Dictionary with processed results.
    """
    if not data:
        raise ValueError("Data cannot be empty")

    result = {}
    threshold = config.get("threshold", 0.5)

    for item in data:
        if len(item) > threshold:
            key = item.lower().strip()
            result[key] = item.upper()
        else:
            result[item] = item

    return result

def helper(value: str) -> str:
    """Transform a value.

    Simple helper with no branches.
    """
    return value.strip().lower()

def entry_point():
    """Main entry point."""
    data = ["hello", "world"]
    config = {"threshold": 3}
    return process_data(data, config)
''')

        # Create utils.py with imports
        Path(tmpdir, "utils.py").write_text('''"""Utility functions."""

import json
import re
from collections import defaultdict

def validate(data: list) -> bool:
    """Validate input data."""
    return data is not None and len(data) > 0

def transform(text: str, pattern: str) -> str:
    """Transform text using regex pattern."""
    return re.sub(pattern, "", text)
''')

        yield tmpdir


# ============================================================================
# Test: Actual Line Numbers
# ============================================================================

def test_unit_has_actual_line_number(enrichment_project):
    """Extracted units should have actual line numbers from AST, not hardcoded 1."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # Find process_data - it starts at line 8 in main.py
    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None, "process_data unit not found"

    # Line should NOT be 1 (the old hardcoded value)
    assert process_unit.line != 1, "Line number should not be hardcoded to 1"

    # Line should be around 8 (where def process_data is)
    assert 7 <= process_unit.line <= 10, f"process_data should be around line 8, got {process_unit.line}"


def test_helper_function_has_correct_line(enrichment_project):
    """Helper function should have correct line number."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    helper_unit = next((u for u in units if u.name == "helper"), None)
    assert helper_unit is not None, "helper unit not found"

    # helper is defined after process_data, should be around line 32
    assert helper_unit.line > 25, f"helper should be after line 25, got {helper_unit.line}"
    assert helper_unit.line != 1, "Line should not be hardcoded to 1"


# ============================================================================
# Test: CFG Summary
# ============================================================================

def test_unit_has_cfg_summary(enrichment_project):
    """Extracted units should have CFG summary with complexity info."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # Find process_data - it has branches and loops
    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    # CFG summary should not be empty
    assert process_unit.cfg_summary, "cfg_summary should not be empty"

    # Should contain complexity information
    assert "complexity" in process_unit.cfg_summary.lower() or "blocks" in process_unit.cfg_summary.lower(), \
        f"cfg_summary should mention complexity or blocks: {process_unit.cfg_summary}"


def test_cfg_summary_reflects_complexity(enrichment_project):
    """CFG summary should reflect actual code complexity."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # process_data has if/for/if-else - should have higher complexity
    process_unit = next((u for u in units if u.name == "process_data"), None)

    # helper has no branches - should have lower complexity
    helper_unit = next((u for u in units if u.name == "helper"), None)

    assert process_unit is not None and helper_unit is not None

    # Both should have cfg_summary
    assert process_unit.cfg_summary, "process_data should have cfg_summary"
    assert helper_unit.cfg_summary, "helper should have cfg_summary"

    # Extract complexity numbers if present
    # Format expected: "complexity:N, blocks:M"
    import re

    process_match = re.search(r'complexity[:\s]*(\d+)', process_unit.cfg_summary.lower())
    helper_match = re.search(r'complexity[:\s]*(\d+)', helper_unit.cfg_summary.lower())

    if process_match and helper_match:
        process_complexity = int(process_match.group(1))
        helper_complexity = int(helper_match.group(1))
        assert process_complexity > helper_complexity, \
            f"process_data ({process_complexity}) should have higher complexity than helper ({helper_complexity})"


# ============================================================================
# Test: DFG Summary
# ============================================================================

def test_unit_has_dfg_summary(enrichment_project):
    """Extracted units should have DFG summary with variable info."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # Find process_data - it has multiple variables
    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    # DFG summary should not be empty
    assert process_unit.dfg_summary, "dfg_summary should not be empty"

    # Should contain variable/def-use information
    dfg_lower = process_unit.dfg_summary.lower()
    assert "var" in dfg_lower or "def" in dfg_lower or "use" in dfg_lower or "flow" in dfg_lower, \
        f"dfg_summary should mention variables or data flow: {process_unit.dfg_summary}"


def test_dfg_summary_contains_variable_count(enrichment_project):
    """DFG summary should contain variable count or chains count."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    # Should have some numeric info about variables or chains
    import re
    has_numbers = bool(re.search(r'\d+', process_unit.dfg_summary))
    assert has_numbers, f"dfg_summary should contain numeric info: {process_unit.dfg_summary}"


# ============================================================================
# Test: Dependencies (Imports)
# ============================================================================

def test_unit_has_dependencies(enrichment_project):
    """Extracted units should have file-level import dependencies."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # Find process_data from main.py which has imports
    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    # Dependencies should not be empty for files with imports
    assert process_unit.dependencies, "dependencies should not be empty for files with imports"


def test_dependencies_contain_import_modules(enrichment_project):
    """Dependencies should list imported modules."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # process_data is in main.py which imports os, pathlib, typing
    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    deps_lower = process_unit.dependencies.lower()
    # Should mention at least one of the imports
    assert any(mod in deps_lower for mod in ["os", "pathlib", "typing"]), \
        f"dependencies should mention imports: {process_unit.dependencies}"


def test_dependencies_from_utils_file(enrichment_project):
    """Dependencies from utils.py should include its imports."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # validate is in utils.py which imports json, re, collections
    validate_unit = next((u for u in units if u.name == "validate"), None)
    assert validate_unit is not None

    deps_lower = validate_unit.dependencies.lower()
    # Should mention at least one of utils.py imports
    assert any(mod in deps_lower for mod in ["json", "re", "collections"]), \
        f"dependencies should mention imports: {validate_unit.dependencies}"


# ============================================================================
# Test: Code Preview (NEW FIELD)
# ============================================================================

def test_unit_has_code_preview(enrichment_project):
    """Extracted units should have code_preview field with function body."""
    from tldr.semantic import extract_units_from_project, EmbeddingUnit

    # First check that EmbeddingUnit has code_preview field
    import dataclasses
    field_names = [f.name for f in dataclasses.fields(EmbeddingUnit)]
    assert "code_preview" in field_names, "EmbeddingUnit should have code_preview field"

    units = extract_units_from_project(enrichment_project, lang="python")

    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    # Should have code_preview
    assert hasattr(process_unit, 'code_preview'), "Unit should have code_preview attribute"
    assert process_unit.code_preview, "code_preview should not be empty"


def test_code_preview_contains_function_body(enrichment_project):
    """Code preview should contain actual function body code."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    preview = process_unit.code_preview

    # Should contain code from the function body
    assert "result" in preview or "data" in preview or "config" in preview, \
        f"code_preview should contain function body code: {preview[:200]}"


def test_code_preview_limited_to_10_lines(enrichment_project):
    """Code preview should be limited to first 10 lines max."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    preview = process_unit.code_preview
    line_count = len(preview.strip().split('\n'))

    # Should be at most 10 lines
    assert line_count <= 10, f"code_preview should be max 10 lines, got {line_count}"


# ============================================================================
# Test: Embedding Text Includes New Fields
# ============================================================================

def test_build_embedding_text_includes_code_preview():
    """build_embedding_text should include code_preview in output."""
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="test_func",
        qualified_name="module.test_func",
        file="test.py",
        line=10,
        language="python",
        unit_type="function",
        signature="def test_func(x: int) -> str",
        docstring="Test function.",
        calls=[],
        called_by=[],
        cfg_summary="complexity:2, blocks:3",
        dfg_summary="vars:3, chains:2",
        dependencies="os, sys",
        code_preview="    result = x * 2\n    return str(result)",
    )

    text = build_embedding_text(unit)

    # Should include code preview in embedding text
    assert "result" in text or "code" in text.lower(), \
        f"Embedding text should include code preview content: {text}"


# ============================================================================
# Test: Graceful Handling of Extraction Failures
# ============================================================================

def test_cfg_extraction_handles_errors_gracefully(enrichment_project):
    """CFG extraction should handle errors gracefully (e.g., complex nested functions)."""
    from tldr.semantic import extract_units_from_project

    # Should not raise even if some functions can't have CFG extracted
    units = extract_units_from_project(enrichment_project, lang="python")

    # All units should be valid even if some have empty cfg_summary
    for unit in units:
        assert unit.name, "All units should have names"
        # cfg_summary can be empty but should be a string
        assert isinstance(unit.cfg_summary, str), "cfg_summary should be a string"


def test_dfg_extraction_handles_errors_gracefully(enrichment_project):
    """DFG extraction should handle errors gracefully."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    for unit in units:
        assert isinstance(unit.dfg_summary, str), "dfg_summary should be a string"


# ============================================================================
# Test: Existing Tests Still Pass
# ============================================================================

def test_extract_units_preserves_existing_behavior(enrichment_project):
    """New enrichment should not break existing functionality."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(enrichment_project, lang="python")

    # Should still find all functions
    names = [u.name for u in units]
    assert "process_data" in names
    assert "helper" in names
    assert "entry_point" in names
    assert "validate" in names
    assert "transform" in names

    # Should still have basic fields
    for unit in units:
        assert unit.file
        assert unit.qualified_name
        assert unit.language == "python"
