"""Adversarial UTF-8 tests for tree-sitter extractors.

These tests target UTF-8 handling vulnerabilities discovered through:
1. ICU library UTF-8 validation analysis
2. Tree-sitter byte handling review
3. Security audit of decode() calls without error handling

Test Categories:
- INVALID_SEQUENCE: Malformed UTF-8 byte sequences
- ENCODING_MISMATCH: Wrong encoding passed as UTF-8
- EDGE_CASE: Valid but unusual UTF-8 edge cases
- INJECTION: Potential parser injection via encoding tricks

Attack Vectors Tested:
1. Invalid UTF-8 sequences (overlong, truncated, out-of-range)
2. UTF-8 BOM handling
3. Null bytes embedded in code
4. Mixed encoding attacks (UTF-16, Latin-1 passed as UTF-8)
5. Edge cases (long lines, only invalid bytes)

Reference: ICU U8_IS_VALID_LEAD3_AND_T1, U8_IS_VALID_LEAD4_AND_T1 macros

Usage:
    pytest tests/test_adversarial_utf8.py -v
    pytest tests/test_adversarial_utf8.py -v -x  # Stop on first failure
"""

import tempfile
from pathlib import Path
from typing import Any

import pytest

# =============================================================================
# TEST INFRASTRUCTURE
# =============================================================================


def extract_bytes_file(content: bytes, ext: str) -> dict[str, Any]:
    """Extract structure from binary content written as-is to a file.

    This helper writes raw bytes to avoid Python's encoding transformations.
    """
    from tldr.api import extract_file

    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as f:
        f.write(content)
        f.flush()
        path = Path(f.name)

    try:
        return extract_file(str(path))
    finally:
        path.unlink()


def extract_via_hybrid(content: bytes, ext: str) -> Any:
    """Extract using HybridExtractor directly (tree-sitter path)."""
    from tldr.hybrid_extractor import HybridExtractor

    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as f:
        f.write(content)
        f.flush()
        path = Path(f.name)

    try:
        extractor = HybridExtractor()
        return extractor.extract(str(path))
    finally:
        path.unlink()


def extract_via_ast(content: bytes) -> Any:
    """Extract using PythonASTExtractor directly."""
    from tldr.ast_extractor import extract_python

    with tempfile.NamedTemporaryFile(suffix=".py", delete=False) as f:
        f.write(content)
        f.flush()
        path = Path(f.name)

    try:
        return extract_python(str(path))
    finally:
        path.unlink()


# =============================================================================
# INVALID UTF-8 SEQUENCES
# =============================================================================


class TestInvalidUTF8Sequences:
    """Tests for invalid UTF-8 byte sequences.

    Tree-sitter uses ICU library macros for UTF-8 validation. These tests
    target known invalid sequences that could cause crashes or undefined behavior.
    """

    @pytest.mark.xfail(
        reason="Invalid continuation byte may crash decode() without error handling",
        strict=False,
    )
    def test_invalid_continuation_byte_in_string(self):
        """Invalid continuation byte (0x80) without lead byte.

        Attack: 0x80-0xBF are continuation bytes and must follow a lead byte.
        Passing 0x80 alone triggers UnicodeDecodeError in unprotected decode().
        """
        # \x80 is a continuation byte without a lead byte - invalid UTF-8
        bad_content = b"def foo():\n    x = '\x80invalid'\n    return x\n"

        # Should NOT crash - should either:
        # 1. Raise a specific UTF8Error with clear message
        # 2. Replace invalid bytes with replacement char and continue
        # 3. Fall back to Pygments gracefully
        result = extract_bytes_file(bad_content, ".py")

        # If we get here, parser handled it somehow
        assert result is not None
        # Should still find the function even if string content is mangled
        funcs = [f["name"] for f in result.get("functions", [])]
        assert "foo" in funcs

    @pytest.mark.xfail(
        reason="Truncated multi-byte sequence may crash parser",
        strict=False,
    )
    def test_truncated_2byte_sequence(self):
        """Truncated 2-byte UTF-8 sequence (lead byte without continuation).

        Attack: 0xC2-0xDF require exactly 1 continuation byte.
        0xC2 alone is invalid - exposes missing sequence completion check.
        """
        # \xC2 expects one more byte but we don't provide it
        bad_content = b"def bar():\n    msg = 'test\xC2'\n    return msg\n"

        result = extract_bytes_file(bad_content, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="Truncated 3-byte sequence may crash parser",
        strict=False,
    )
    def test_truncated_3byte_sequence(self):
        """Truncated 3-byte UTF-8 sequence.

        Attack: 0xE0-0xEF require exactly 2 continuation bytes.
        Only providing 1 continuation byte is invalid.
        """
        # \xE0\x80 - lead byte + 1 continuation, missing second continuation
        bad_content = b"def baz():\n    emoji = '\xE0\x80text'\n    return emoji\n"

        result = extract_bytes_file(bad_content, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="Truncated 4-byte sequence may crash parser",
        strict=False,
    )
    def test_truncated_4byte_sequence(self):
        """Truncated 4-byte UTF-8 sequence.

        Attack: 0xF0-0xF4 require exactly 3 continuation bytes.
        Only providing 2 is invalid.
        """
        # \xF0\x90\x80 - needs one more continuation byte
        bad_content = b"def qux():\n    char = '\xF0\x90\x80text'\n    return char\n"

        result = extract_bytes_file(bad_content, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="Overlong encoding may bypass validation",
        strict=False,
    )
    def test_overlong_encoding_slash(self):
        """Overlong encoding of '/' (U+002F).

        Attack: '/' can be encoded as \x2F (valid) or \xC0\xAF (overlong, invalid).
        Overlong encodings were used in path traversal attacks (CVE-2000-0884).
        Tree-sitter should reject these per ICU U8_IS_VALID_LEAD checks.
        """
        # \xC0\xAF is overlong encoding of '/' - security risk
        bad_content = b"def path_func():\n    p = '\xC0\xAFetc\xC0\xAFpasswd'\n    return p\n"

        result = extract_bytes_file(bad_content, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="Overlong null may bypass validation",
        strict=False,
    )
    def test_overlong_encoding_null(self):
        """Overlong encoding of NUL (U+0000).

        Attack: NUL can be encoded as \x00 or \xC0\x80 (overlong, invalid).
        Overlong NUL was used to bypass string termination checks.
        """
        # \xC0\x80 is overlong encoding of NUL
        bad_content = b"def null_func():\n    s = 'before\xC0\x80after'\n    return s\n"

        result = extract_bytes_file(bad_content, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="Out-of-range codepoint may crash parser",
        strict=False,
    )
    def test_out_of_range_codepoint(self):
        """Codepoint above U+10FFFF (Unicode maximum).

        Attack: Valid UTF-8 structure but codepoint > U+10FFFF.
        \xF4\x90\x80\x80 encodes U+110000 which is out of range.
        """
        # \xF4\x90\x80\x80 would encode U+110000 (invalid - max is U+10FFFF)
        bad_content = b"def range_func():\n    x = '\xF4\x90\x80\x80'\n    return x\n"

        result = extract_bytes_file(bad_content, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="Surrogate pair encoding may crash parser",
        strict=False,
    )
    def test_utf8_surrogate_encoding(self):
        """UTF-8 encoding of surrogate codepoints (U+D800-U+DFFF).

        Attack: Surrogates are only valid in UTF-16 pairs.
        UTF-8 encoding of surrogates is explicitly invalid per RFC 3629.
        \xED\xA0\x80 encodes U+D800 (high surrogate).
        """
        # \xED\xA0\x80 is UTF-8 encoding of U+D800 (surrogate - invalid in UTF-8)
        bad_content = b"def surrogate_func():\n    s = '\xED\xA0\x80'\n    return s\n"

        result = extract_bytes_file(bad_content, ".py")
        assert result is not None


# =============================================================================
# UTF-8 BOM HANDLING
# =============================================================================


class TestBOMHandling:
    """Tests for UTF-8 Byte Order Mark handling.

    BOM (U+FEFF, encoded as EF BB BF) at file start is valid but often
    causes issues with parsers that don't expect it.
    """

    @pytest.mark.xfail(
        reason="BOM at file start may confuse parser",
        strict=False,
    )
    def test_bom_at_file_start(self):
        """UTF-8 BOM at start of Python file.

        Attack: BOM before code makes first line look different to parser.
        Some parsers treat BOM as part of the first token.
        """
        # UTF-8 BOM followed by valid Python
        bom_content = b"\xef\xbb\xbfdef bom_func():\n    return 'has bom'\n"

        result = extract_bytes_file(bom_content, ".py")
        assert result is not None
        funcs = [f["name"] for f in result.get("functions", [])]
        assert "bom_func" in funcs

    @pytest.mark.xfail(
        reason="BOM in middle of file is invalid",
        strict=False,
    )
    def test_bom_in_middle_of_file(self):
        """UTF-8 BOM appearing mid-file.

        Attack: BOM mid-file is technically valid ZWNBSP character but
        unusual and may cause parsing issues.
        """
        # BOM appearing after first function
        mid_bom = b"def first():\n    pass\n\xef\xbb\xbfdef second():\n    pass\n"

        result = extract_bytes_file(mid_bom, ".py")
        assert result is not None
        funcs = [f["name"] for f in result.get("functions", [])]
        # Should find both functions
        assert "first" in funcs
        assert "second" in funcs

    @pytest.mark.xfail(
        reason="Multiple BOMs may confuse parser",
        strict=False,
    )
    def test_multiple_boms(self):
        """Multiple UTF-8 BOMs in file.

        Attack: Multiple BOMs could be used to confuse line counting
        or inject invisible characters.
        """
        # Multiple BOMs at various positions
        multi_bom = (
            b"\xef\xbb\xbf"  # BOM at start
            b"def func1():\n"
            b"    return '\xef\xbb\xbf'\n"  # BOM in string
            b"\xef\xbb\xbf"  # BOM between functions
            b"def func2():\n"
            b"    pass\n"
        )

        result = extract_bytes_file(multi_bom, ".py")
        assert result is not None


# =============================================================================
# NULL BYTE HANDLING
# =============================================================================


class TestNullByteHandling:
    """Tests for null byte (0x00) handling.

    Null bytes are valid UTF-8 but cause issues with C-string handling
    since C uses null as string terminator.
    """

    @pytest.mark.xfail(
        reason="Null byte in string may truncate parsing",
        strict=False,
    )
    def test_null_in_string_literal(self):
        """Null byte inside string literal.

        Attack: Tree-sitter is C-based. Null in source could truncate
        the string being parsed if passed to C functions.
        """
        # Null byte inside a string literal
        null_content = b"def null_string():\n    s = 'before\x00after'\n    return s\n"

        result = extract_bytes_file(null_content, ".py")
        assert result is not None
        funcs = [f["name"] for f in result.get("functions", [])]
        assert "null_string" in funcs

    @pytest.mark.xfail(
        reason="Null byte in identifier may crash parser",
        strict=False,
    )
    def test_null_in_comment(self):
        """Null byte inside comment.

        Attack: Comments are typically passed through - null might
        truncate comment or cause issues in output.
        """
        null_comment = b"# Comment with \x00 null byte\ndef commented():\n    pass\n"

        result = extract_bytes_file(null_comment, ".py")
        assert result is not None
        funcs = [f["name"] for f in result.get("functions", [])]
        assert "commented" in funcs

    @pytest.mark.xfail(
        reason="Null at end of file may cause issues",
        strict=False,
    )
    def test_null_at_end_of_file(self):
        """Null byte at end of file.

        Attack: Some parsers expect EOF, null at end might cause
        double-processing or infinite loops.
        """
        null_eof = b"def eof_null():\n    return True\n\x00"

        result = extract_bytes_file(null_eof, ".py")
        assert result is not None
        funcs = [f["name"] for f in result.get("functions", [])]
        assert "eof_null" in funcs

    @pytest.mark.xfail(
        reason="Multiple nulls may cause repeated truncation",
        strict=False,
    )
    def test_multiple_nulls(self):
        """Multiple null bytes throughout file.

        Attack: Multiple nulls could cause repeated truncation points
        or confuse length calculations.
        """
        multi_null = (
            b"def f1():\n    pass\n"
            b"\x00"
            b"def f2():\n    pass\n"
            b"\x00\x00"
            b"def f3():\n    pass\n"
        )

        result = extract_bytes_file(multi_null, ".py")
        assert result is not None
        funcs = [f["name"] for f in result.get("functions", [])]
        # Should find all three functions
        assert len([f for f in funcs if f.startswith("f")]) >= 1


# =============================================================================
# MIXED ENCODING ATTACKS
# =============================================================================


class TestMixedEncodingAttacks:
    """Tests for wrong encoding passed as UTF-8.

    These simulate scenarios where content in other encodings
    is mistakenly read as UTF-8.
    """

    @pytest.mark.xfail(
        reason="UTF-16 LE passed as UTF-8 may crash",
        strict=False,
    )
    def test_utf16_le_as_utf8(self):
        """UTF-16 LE content passed to UTF-8 parser.

        Attack: UTF-16 LE starts with FF FE BOM, content has null bytes
        between ASCII chars. Parser expecting UTF-8 will fail.
        """
        # "def foo(): pass" in UTF-16 LE with BOM
        utf16_le = (
            b"\xff\xfed\x00e\x00f\x00 \x00f\x00o\x00o\x00"
            b"(\x00)\x00:\x00 \x00p\x00a\x00s\x00s\x00\n\x00"
        )

        result = extract_bytes_file(utf16_le, ".py")
        # Should either error gracefully or detect encoding mismatch
        assert result is not None or result is None  # Just shouldn't crash

    @pytest.mark.xfail(
        reason="UTF-16 BE passed as UTF-8 may crash",
        strict=False,
    )
    def test_utf16_be_as_utf8(self):
        """UTF-16 BE content passed to UTF-8 parser.

        Attack: UTF-16 BE starts with FE FF BOM, high bytes first.
        """
        # "def foo(): pass" in UTF-16 BE with BOM
        utf16_be = (
            b"\xfe\xff\x00d\x00e\x00f\x00 \x00f\x00o\x00o"
            b"\x00(\x00)\x00:\x00 \x00p\x00a\x00s\x00s\x00\n"
        )

        result = extract_bytes_file(utf16_be, ".py")
        assert result is not None or result is None  # Just shouldn't crash

    @pytest.mark.xfail(
        reason="Latin-1 high bytes are invalid UTF-8",
        strict=False,
    )
    def test_latin1_as_utf8(self):
        """Latin-1 (ISO-8859-1) content passed as UTF-8.

        Attack: Latin-1 uses 0x80-0xFF as single-byte characters.
        These are invalid as UTF-8 lead bytes followed by ASCII.
        """
        # Latin-1 string with accented characters (invalid as UTF-8)
        # \xe9 is 'e' with acute accent in Latin-1
        latin1_content = b"def caf\xe9():\n    return 'caf\xe9'\n"

        result = extract_bytes_file(latin1_content, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="Windows-1252 special chars are invalid UTF-8",
        strict=False,
    )
    def test_windows1252_as_utf8(self):
        """Windows-1252 content passed as UTF-8.

        Attack: Windows-1252 maps 0x80-0x9F to special characters
        (smart quotes, em dash, etc). These bytes are invalid in UTF-8.
        """
        # Windows-1252 with smart quotes (\x93 \x94) and em dash (\x97)
        win1252 = b"def smart_quotes():\n    return \x93hello\x94\n"

        result = extract_bytes_file(win1252, ".py")
        assert result is not None


# =============================================================================
# EDGE CASES
# =============================================================================


class TestUTF8EdgeCases:
    """Edge cases that are technically valid UTF-8 but unusual."""

    def test_maximum_valid_codepoint(self):
        """Maximum valid Unicode codepoint U+10FFFF.

        This is valid but tests boundary handling.
        """
        # U+10FFFF encoded as UTF-8: F4 8F BF BF
        max_codepoint = b"def max_unicode():\n    x = '\xf4\x8f\xbf\xbf'\n    return x\n"

        result = extract_bytes_file(max_codepoint, ".py")
        assert result is not None

    def test_combining_characters(self):
        """Unicode combining characters (diacritics).

        These modify the previous character and can create
        visual ambiguity (IDN homograph attacks).
        """
        # 'a' followed by combining acute accent (U+0301)
        combining = "def func_a\u0301():\n    return 'a\u0301'\n".encode()

        result = extract_bytes_file(combining, ".py")
        assert result is not None

    def test_zero_width_characters(self):
        """Zero-width characters in identifiers.

        Attack: Zero-width chars are invisible but can make
        visually identical identifiers different.
        """
        # Zero-width space (U+200B) and zero-width joiner (U+200D)
        zwc = "def foo\u200b\u200dbar():\n    return 'looks like foobar'\n".encode()

        result = extract_bytes_file(zwc, ".py")
        assert result is not None

    def test_right_to_left_override(self):
        """Right-to-left override character.

        Attack: RLO (U+202E) reverses text display direction.
        Can hide malicious code in plain sight (CVE-2021-42574).
        """
        # RLO character in comment
        rlo = "# \u202eecudorp\ndef produce():\n    pass\n".encode()

        result = extract_bytes_file(rlo, ".py")
        assert result is not None
        funcs = [f["name"] for f in result.get("functions", [])]
        assert "produce" in funcs

    @pytest.mark.xfail(
        reason="Extremely long line may exhaust memory or timeout",
        strict=False,
    )
    def test_extremely_long_utf8_line(self):
        """Extremely long line with valid UTF-8.

        Attack: Very long lines may cause memory issues or timeouts.
        """
        # 1MB line of valid UTF-8
        long_line = b"def long_func():\n    x = '" + (b"a" * 1_000_000) + b"'\n"

        result = extract_bytes_file(long_line, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="File with only invalid UTF-8 may crash",
        strict=False,
    )
    def test_only_invalid_utf8(self):
        """File containing only invalid UTF-8 bytes.

        Attack: No valid content to fall back on - tests error handling.
        """
        # All invalid UTF-8 continuation bytes
        only_invalid = b"\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89"

        result = extract_bytes_file(only_invalid, ".py")
        # Should return empty result or error, not crash
        assert result is not None or result == {}


# =============================================================================
# CROSS-LANGUAGE UTF-8 TESTS
# =============================================================================


class TestCrossLanguageUTF8:
    """UTF-8 adversarial tests across different languages.

    Each language parser may handle encoding errors differently.
    """

    @pytest.mark.xfail(
        reason="TypeScript parser may not handle invalid UTF-8",
        strict=False,
    )
    def test_typescript_invalid_utf8(self):
        """Invalid UTF-8 in TypeScript file."""
        ts_content = b"function bad\x80func(): string {\n    return '\x80';\n}\n"

        result = extract_bytes_file(ts_content, ".ts")
        assert result is not None

    @pytest.mark.xfail(
        reason="Go parser may not handle invalid UTF-8",
        strict=False,
    )
    def test_go_invalid_utf8(self):
        """Invalid UTF-8 in Go file."""
        go_content = b'package main\n\nfunc bad\x80func() string {\n    return "\x80"\n}\n'

        result = extract_bytes_file(go_content, ".go")
        assert result is not None

    @pytest.mark.xfail(
        reason="Rust parser may not handle invalid UTF-8",
        strict=False,
    )
    def test_rust_invalid_utf8(self):
        """Invalid UTF-8 in Rust file."""
        rust_content = b'fn bad_func() -> &\'static str {\n    "\x80invalid"\n}\n'

        result = extract_bytes_file(rust_content, ".rs")
        assert result is not None

    @pytest.mark.xfail(
        reason="Java parser may not handle invalid UTF-8",
        strict=False,
    )
    def test_java_invalid_utf8(self):
        """Invalid UTF-8 in Java file."""
        java_content = (
            b"public class Bad {\n"
            b"    String s = \"\x80invalid\";\n"
            b"    void bad() {}\n"
            b"}\n"
        )

        result = extract_bytes_file(java_content, ".java")
        assert result is not None

    # -------------------------------------------------------------------------
    # C Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="C parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_c_invalid_utf8_in_string(self):
        """Invalid UTF-8 in C string literal."""
        c_content = b'#include <stdio.h>\nint main() { char* s = "\x80invalid"; return 0; }\n'

        result = extract_bytes_file(c_content, ".c")
        assert result is not None

    @pytest.mark.xfail(
        reason="C parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_c_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in C comment."""
        c_content = b'/* Comment with \x80 invalid byte */\nint func(void) { return 42; }\n'

        result = extract_bytes_file(c_content, ".c")
        assert result is not None

    @pytest.mark.xfail(
        reason="C parser may not handle invalid UTF-8 in char literal",
        strict=False,
    )
    def test_c_invalid_utf8_in_char_literal(self):
        """Invalid UTF-8 in C character literal."""
        c_content = b"char c = '\x80';\nvoid test(void) {}\n"

        result = extract_bytes_file(c_content, ".c")
        assert result is not None

    # -------------------------------------------------------------------------
    # C++ Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="C++ parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_cpp_invalid_utf8_in_string(self):
        """Invalid UTF-8 in C++ string literal."""
        cpp_content = b'#include <string>\nstd::string bad = "\x80invalid";\nvoid func() {}\n'

        result = extract_bytes_file(cpp_content, ".cpp")
        assert result is not None

    @pytest.mark.xfail(
        reason="C++ parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_cpp_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in C++ comment."""
        cpp_content = b'// C++ comment with \x80 invalid byte\nclass Foo { public: void bar(); };\n'

        result = extract_bytes_file(cpp_content, ".cpp")
        assert result is not None

    @pytest.mark.xfail(
        reason="C++ parser may not handle invalid UTF-8 in raw string",
        strict=False,
    )
    def test_cpp_invalid_utf8_in_raw_string(self):
        """Invalid UTF-8 in C++ raw string literal."""
        cpp_content = b'const char* raw = R"(\x80invalid)";\nvoid test() {}\n'

        result = extract_bytes_file(cpp_content, ".cpp")
        assert result is not None

    # -------------------------------------------------------------------------
    # Ruby Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="Ruby parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_ruby_invalid_utf8_in_string(self):
        """Invalid UTF-8 in Ruby string literal."""
        ruby_content = b'def bad_func\n  s = "\x80invalid"\n  s\nend\n'

        result = extract_bytes_file(ruby_content, ".rb")
        assert result is not None

    @pytest.mark.xfail(
        reason="Ruby parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_ruby_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in Ruby comment."""
        ruby_content = b'# Ruby comment with \x80 invalid byte\ndef good_func\n  42\nend\n'

        result = extract_bytes_file(ruby_content, ".rb")
        assert result is not None

    @pytest.mark.xfail(
        reason="Ruby parser may not handle invalid UTF-8 in heredoc",
        strict=False,
    )
    def test_ruby_invalid_utf8_in_heredoc(self):
        """Invalid UTF-8 in Ruby heredoc."""
        ruby_content = b'def heredoc_func\n  <<~HEREDOC\n    \x80invalid content\n  HEREDOC\nend\n'

        result = extract_bytes_file(ruby_content, ".rb")
        assert result is not None

    # -------------------------------------------------------------------------
    # Kotlin Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="Kotlin parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_kotlin_invalid_utf8_in_string(self):
        """Invalid UTF-8 in Kotlin string literal."""
        kotlin_content = b'fun badFunc(): String {\n    return "\x80invalid"\n}\n'

        result = extract_bytes_file(kotlin_content, ".kt")
        assert result is not None

    @pytest.mark.xfail(
        reason="Kotlin parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_kotlin_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in Kotlin comment."""
        kotlin_content = b'// Kotlin comment with \x80 invalid byte\nfun goodFunc() = 42\n'

        result = extract_bytes_file(kotlin_content, ".kt")
        assert result is not None

    @pytest.mark.xfail(
        reason="Kotlin parser may not handle invalid UTF-8 in raw string",
        strict=False,
    )
    def test_kotlin_invalid_utf8_in_raw_string(self):
        """Invalid UTF-8 in Kotlin raw/multiline string."""
        kotlin_content = b'val raw = """\n    \x80invalid content\n"""\nfun test() {}\n'

        result = extract_bytes_file(kotlin_content, ".kt")
        assert result is not None

    # -------------------------------------------------------------------------
    # Swift Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="Swift parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_swift_invalid_utf8_in_string(self):
        """Invalid UTF-8 in Swift string literal."""
        swift_content = b'func badFunc() -> String {\n    return "\x80invalid"\n}\n'

        result = extract_bytes_file(swift_content, ".swift")
        assert result is not None

    @pytest.mark.xfail(
        reason="Swift parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_swift_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in Swift comment."""
        swift_content = (
            b'// Swift comment with \x80 invalid byte\n'
            b'func goodFunc() -> Int { return 42 }\n'
        )

        result = extract_bytes_file(swift_content, ".swift")
        assert result is not None

    @pytest.mark.xfail(
        reason="Swift parser may not handle invalid UTF-8 in multiline string",
        strict=False,
    )
    def test_swift_invalid_utf8_in_multiline_string(self):
        """Invalid UTF-8 in Swift multiline string literal."""
        swift_content = b'let multi = """\n    \x80invalid content\n"""\nfunc test() {}\n'

        result = extract_bytes_file(swift_content, ".swift")
        assert result is not None

    # -------------------------------------------------------------------------
    # C# Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="C# parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_csharp_invalid_utf8_in_string(self):
        """Invalid UTF-8 in C# string literal."""
        csharp_content = (
            b"public class Bad {\n"
            b"    string s = \"\x80invalid\";\n"
            b"    void BadMethod() {}\n"
            b"}\n"
        )

        result = extract_bytes_file(csharp_content, ".cs")
        assert result is not None

    @pytest.mark.xfail(
        reason="C# parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_csharp_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in C# comment."""
        csharp_content = (
            b"// C# comment with \x80 invalid byte\n"
            b"public class Good {\n"
            b"    void GoodMethod() {}\n"
            b"}\n"
        )

        result = extract_bytes_file(csharp_content, ".cs")
        assert result is not None

    @pytest.mark.xfail(
        reason="C# parser may not handle invalid UTF-8 in verbatim string",
        strict=False,
    )
    def test_csharp_invalid_utf8_in_verbatim_string(self):
        """Invalid UTF-8 in C# verbatim string literal."""
        csharp_content = (
            b"public class Verbatim {\n"
            b"    string v = @\"\x80invalid verbatim\";\n"
            b"    void Test() {}\n"
            b"}\n"
        )

        result = extract_bytes_file(csharp_content, ".cs")
        assert result is not None

    # -------------------------------------------------------------------------
    # Scala Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="Scala parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_scala_invalid_utf8_in_string(self):
        """Invalid UTF-8 in Scala string literal."""
        scala_content = b'def badFunc(): String = {\n  "\x80invalid"\n}\n'

        result = extract_bytes_file(scala_content, ".scala")
        assert result is not None

    @pytest.mark.xfail(
        reason="Scala parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_scala_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in Scala comment."""
        scala_content = b'// Scala comment with \x80 invalid byte\ndef goodFunc(): Int = 42\n'

        result = extract_bytes_file(scala_content, ".scala")
        assert result is not None

    @pytest.mark.xfail(
        reason="Scala parser may not handle invalid UTF-8 in triple-quoted string",
        strict=False,
    )
    def test_scala_invalid_utf8_in_triple_quoted_string(self):
        """Invalid UTF-8 in Scala triple-quoted string literal."""
        scala_content = b'val raw = """\n  \x80invalid content\n"""\ndef test(): Unit = {}\n'

        result = extract_bytes_file(scala_content, ".scala")
        assert result is not None

    # -------------------------------------------------------------------------
    # Lua Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="Lua parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_lua_invalid_utf8_in_string(self):
        """Invalid UTF-8 in Lua string literal."""
        lua_content = b'function bad_func()\n    local s = "\x80invalid"\n    return s\nend\n'

        result = extract_bytes_file(lua_content, ".lua")
        assert result is not None

    @pytest.mark.xfail(
        reason="Lua parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_lua_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in Lua comment."""
        lua_content = (
            b'-- Lua comment with \x80 invalid byte\n'
            b'function good_func()\n'
            b'    return 42\n'
            b'end\n'
        )

        result = extract_bytes_file(lua_content, ".lua")
        assert result is not None

    @pytest.mark.xfail(
        reason="Lua parser may not handle invalid UTF-8 in long string",
        strict=False,
    )
    def test_lua_invalid_utf8_in_long_string(self):
        """Invalid UTF-8 in Lua long string literal."""
        lua_content = b'local long = [[\n    \x80invalid content\n]]\nfunction test() end\n'

        result = extract_bytes_file(lua_content, ".lua")
        assert result is not None

    # -------------------------------------------------------------------------
    # Elixir Language Tests
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(
        reason="Elixir parser may not handle invalid UTF-8 in strings",
        strict=False,
    )
    def test_elixir_invalid_utf8_in_string(self):
        """Invalid UTF-8 in Elixir string literal."""
        elixir_content = b'defmodule Bad do\n  def bad_func do\n    "\x80invalid"\n  end\nend\n'

        result = extract_bytes_file(elixir_content, ".ex")
        assert result is not None

    @pytest.mark.xfail(
        reason="Elixir parser may not handle invalid UTF-8 in comments",
        strict=False,
    )
    def test_elixir_invalid_utf8_in_comment(self):
        """Invalid UTF-8 in Elixir comment."""
        elixir_content = (
            b'# Elixir comment with \x80 invalid byte\n'
            b'defmodule Good do\n'
            b'  def good_func, do: 42\n'
            b'end\n'
        )

        result = extract_bytes_file(elixir_content, ".ex")
        assert result is not None

    @pytest.mark.xfail(
        reason="Elixir parser may not handle invalid UTF-8 in heredoc",
        strict=False,
    )
    def test_elixir_invalid_utf8_in_heredoc(self):
        """Invalid UTF-8 in Elixir heredoc."""
        elixir_content = (
            b'defmodule Heredoc do\n'
            b'  @doc """\n'
            b'  \x80invalid content\n'
            b'  """\n'
            b'  def test, do: :ok\n'
            b'end\n'
        )

        result = extract_bytes_file(elixir_content, ".ex")
        assert result is not None


# =============================================================================
# HYBRID EXTRACTOR SPECIFIC TESTS
# =============================================================================


class TestHybridExtractorUTF8:
    """Tests specifically targeting HybridExtractor.extract() and decode() calls.

    HybridExtractor uses source[start:end].decode("utf-8") without error handling
    in multiple places (lines 376, 382, 388, 438, 445, etc).
    """

    @pytest.mark.xfail(
        reason="decode() without errors param crashes on invalid UTF-8",
        strict=False,
    )
    def test_invalid_bytes_in_function_name_region(self):
        """Invalid bytes at position where function name is extracted.

        Attack: _extract_ts_function extracts name via decode("utf-8").
        If the byte range contains invalid UTF-8, it crashes.
        """
        # Invalid bytes right where function name would be parsed
        bad_func_name = b"def \x80\x81\x82():\n    pass\n"

        result = extract_via_hybrid(bad_func_name, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="decode() without errors param crashes on invalid UTF-8",
        strict=False,
    )
    def test_invalid_bytes_in_class_name_region(self):
        """Invalid bytes at position where class name is extracted.

        Attack: _collect_ts_definitions extracts class names via decode("utf-8").
        """
        bad_class = b"class \x80\x81\x82:\n    pass\n"

        result = extract_via_hybrid(bad_class, ".py")
        assert result is not None

    @pytest.mark.xfail(
        reason="decode() on comment text may crash",
        strict=False,
    )
    def test_invalid_bytes_in_docstring(self):
        """Invalid bytes in docstring/comment region.

        Attack: Line 438 extracts comment text via decode("utf-8").
        """
        bad_doc = b'def func():\n    """\x80\x81 bad docstring \x82\x83"""\n    pass\n'

        result = extract_via_hybrid(bad_doc, ".py")
        assert result is not None


# =============================================================================
# AST EXTRACTOR SPECIFIC TESTS
# =============================================================================


class TestASTExtractorUTF8:
    """Tests specifically targeting PythonASTExtractor.

    ast_extractor.py reads files with open(file, "r", encoding="utf-8")
    without error handling at line 199.
    """

    @pytest.mark.xfail(
        reason="Python's ast.parse may fail on invalid UTF-8",
        strict=False,
    )
    def test_ast_extractor_invalid_utf8(self):
        """Invalid UTF-8 passed to Python's ast.parse.

        Attack: ast.parse expects valid UTF-8 strings. Invalid bytes
        in the source will cause UnicodeDecodeError during file read.
        """
        bad_content = b"def func():\n    x = '\x80invalid'\n    return x\n"

        result = extract_via_ast(bad_content)
        assert result is not None

    @pytest.mark.xfail(
        reason="File read with encoding='utf-8' fails on invalid bytes",
        strict=False,
    )
    def test_ast_extractor_truncated_sequence(self):
        """Truncated UTF-8 sequence at file read.

        Attack: open(file, encoding="utf-8").read() will raise
        UnicodeDecodeError on truncated sequences.
        """
        truncated = b"def func():\n    return '\xC2'  # truncated\n"

        result = extract_via_ast(truncated)
        assert result is not None


# =============================================================================
# FUZZING SEEDS
# =============================================================================


class TestFuzzingSeeds:
    """Minimal test cases that can be used as fuzzing seeds.

    These are small inputs designed to trigger specific code paths
    when used with a fuzzer like AFL or libFuzzer.
    """

    @pytest.mark.parametrize("bad_byte", [
        b"\x80",  # Continuation without lead
        b"\xC0",  # Overlong lead
        b"\xC2",  # Truncated 2-byte
        b"\xE0",  # Truncated 3-byte
        b"\xF0",  # Truncated 4-byte
        b"\xF5",  # Invalid lead (> F4)
        b"\xFF",  # Invalid byte
    ])
    @pytest.mark.xfail(
        reason="Single invalid byte may crash parser",
        strict=False,
    )
    def test_single_invalid_byte_seeds(self, bad_byte: bytes):
        """Minimal inputs with single invalid bytes.

        These are the smallest possible inputs to trigger each
        category of UTF-8 validation failure.
        """
        content = b"def f():\n    x = '" + bad_byte + b"'\n"
        extract_bytes_file(content, ".py")  # Should not crash

    @pytest.mark.parametrize("seq", [
        b"\xC0\xAF",      # Overlong /
        b"\xE0\x80\xAF",  # Overlong / (3-byte)
        b"\xED\xA0\x80",  # Surrogate
        b"\xF4\x90\x80\x80",  # Out of range
    ])
    @pytest.mark.xfail(
        reason="Invalid multi-byte sequences may crash parser",
        strict=False,
    )
    def test_invalid_sequence_seeds(self, seq: bytes):
        """Minimal inputs with invalid multi-byte sequences."""
        content = b"def f():\n    x = '" + seq + b"'\n"
        extract_bytes_file(content, ".py")  # Should not crash
