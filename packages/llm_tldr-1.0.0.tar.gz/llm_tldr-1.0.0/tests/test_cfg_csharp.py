"""Tests for C# CFG extraction.

TDD Tests - Expected to fail until C# support is implemented.
C# uses tree-sitter-c-sharp (hyphen in package name, underscore in Python import).
"""
import pytest

# Check if tree-sitter-c-sharp is available
try:
    from tldr.cfg_extractor import extract_csharp_cfg, TREE_SITTER_CSHARP_AVAILABLE
    CSHARP_AVAILABLE = TREE_SITTER_CSHARP_AVAILABLE
except ImportError:
    CSHARP_AVAILABLE = False


pytestmark = pytest.mark.skipif(not CSHARP_AVAILABLE, reason="tree-sitter-c-sharp not available")


@pytest.fixture
def simple_if_code():
    return '''
public class Example {
    public string Check(int x) {
        if (x > 0) {
            return "positive";
        }
        return "non-positive";
    }
}
'''


@pytest.fixture
def for_loop_code():
    return '''
public class Example {
    public int Count(int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += i;
        }
        return sum;
    }
}
'''


@pytest.fixture
def while_loop_code():
    return '''
public class Example {
    public int Countdown(int n) {
        int count = 0;
        while (n > 0) {
            count++;
            n--;
        }
        return count;
    }
}
'''


@pytest.fixture
def foreach_loop_code():
    return '''
using System.Collections.Generic;

public class Example {
    public int Sum(List<int> items) {
        int total = 0;
        foreach (int item in items) {
            total += item;
        }
        return total;
    }
}
'''


@pytest.fixture
def nested_code():
    return '''
using System.Collections.Generic;

public class Example {
    public void Process(List<Item> items) {
        foreach (var item in items) {
            if (item.IsValid) {
                Handle(item);
            } else {
                Skip(item);
            }
        }
    }
}
'''


@pytest.fixture
def try_catch_code():
    return '''
public class Example {
    public int Divide(int a, int b) {
        try {
            return a / b;
        } catch (DivideByZeroException e) {
            return 0;
        }
    }
}
'''


@pytest.fixture
def switch_code():
    return '''
public class Example {
    public string GetDay(int day) {
        switch (day) {
            case 1:
                return "Monday";
            case 2:
                return "Tuesday";
            default:
                return "Unknown";
        }
    }
}
'''


@pytest.fixture
def switch_expression_code():
    """C# 8+ switch expression syntax."""
    return '''
public class Example {
    public string GetDayExpr(int day) => day switch {
        1 => "Monday",
        2 => "Tuesday",
        _ => "Unknown"
    };
}
'''


class TestBasicCFG:
    """Test basic CFG extraction for C#."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_csharp_cfg(simple_if_code, "Check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_for_loop(self, for_loop_code):
        cfg = extract_csharp_cfg(for_loop_code, "Count")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_csharp_cfg(while_loop_code, "Countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_foreach_loop(self, foreach_loop_code):
        cfg = extract_csharp_cfg(foreach_loop_code, "Sum")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Foreach should create loop-like structure
        assert len(cfg.edges) >= 2


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_csharp_cfg(nested_code, "Process")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_try_catch(self, try_catch_code):
        cfg = extract_csharp_cfg(try_catch_code, "Divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_switch(self, switch_code):
        cfg = extract_csharp_cfg(switch_code, "GetDay")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_switch_expression(self, switch_expression_code):
        """Test C# 8+ switch expression."""
        cfg = extract_csharp_cfg(switch_expression_code, "GetDayExpr")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_csharp_cfg(simple_if_code, "Check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, for_loop_code):
        cfg = extract_csharp_cfg(for_loop_code, "Count")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_csharp_cfg(simple_if_code, "NonExistent")

    def test_empty_class(self):
        code = "public class Empty { }"
        with pytest.raises(ValueError, match="not found"):
            extract_csharp_cfg(code, "SomeMethod")
