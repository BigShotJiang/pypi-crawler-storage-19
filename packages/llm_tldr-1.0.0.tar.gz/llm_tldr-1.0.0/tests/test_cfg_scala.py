"""Tests for Scala CFG extraction.

TDD Tests for Scala CFG support.
Scala is JVM-based like Java/Kotlin, using similar patterns.

Node types (tree-sitter-scala):
- Function: function_definition
- Call: call_expression
- If: if_expression
- Match: match_expression
- While: while_expression
- For: for_expression
"""
import pytest

# Check if tree-sitter-scala is available
try:
    from tldr.cfg_extractor import extract_scala_cfg, TREE_SITTER_SCALA_AVAILABLE
    SCALA_AVAILABLE = TREE_SITTER_SCALA_AVAILABLE
except ImportError:
    SCALA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not SCALA_AVAILABLE, reason="tree-sitter-scala not available")


@pytest.fixture
def simple_if_code():
    return '''
object Example {
  def check(x: Int): String = {
    if (x > 0) {
      "positive"
    } else {
      "non-positive"
    }
  }
}
'''


@pytest.fixture
def for_loop_code():
    return '''
object Example {
  def count(n: Int): Int = {
    var sum = 0
    for (i <- 0 until n) {
      sum += i
    }
    sum
  }
}
'''


@pytest.fixture
def while_loop_code():
    return '''
object Example {
  def countdown(n: Int): Int = {
    var count = 0
    var current = n
    while (current > 0) {
      count += 1
      current -= 1
    }
    count
  }
}
'''


@pytest.fixture
def nested_code():
    return '''
object Example {
  def process(items: List[Int]): Unit = {
    for (item <- items) {
      if (item > 0) {
        handle(item)
      } else {
        skip(item)
      }
    }
  }

  def handle(i: Int): Unit = {}
  def skip(i: Int): Unit = {}
}
'''


@pytest.fixture
def try_catch_code():
    return '''
object Example {
  def divide(a: Int, b: Int): Int = {
    try {
      a / b
    } catch {
      case _: ArithmeticException => 0
    }
  }
}
'''


@pytest.fixture
def match_code():
    return '''
object Example {
  def getDay(day: Int): String = {
    day match {
      case 1 => "Monday"
      case 2 => "Tuesday"
      case _ => "Unknown"
    }
  }
}
'''


class TestBasicCFG:
    """Test basic CFG extraction for Scala."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_scala_cfg(simple_if_code, "check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_for_loop(self, for_loop_code):
        cfg = extract_scala_cfg(for_loop_code, "count")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_scala_cfg(while_loop_code, "countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_scala_cfg(nested_code, "process")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_try_catch(self, try_catch_code):
        cfg = extract_scala_cfg(try_catch_code, "divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_match_expression(self, match_code):
        cfg = extract_scala_cfg(match_code, "getDay")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_scala_cfg(simple_if_code, "check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, for_loop_code):
        cfg = extract_scala_cfg(for_loop_code, "count")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"

    def test_cyclomatic_complexity(self, simple_if_code):
        cfg = extract_scala_cfg(simple_if_code, "check")
        # if/else should have cyclomatic complexity >= 2
        assert cfg.cyclomatic_complexity >= 2


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_scala_cfg(simple_if_code, "nonexistent")

    def test_empty_code(self):
        with pytest.raises((ValueError, Exception)):
            extract_scala_cfg("", "anyFunc")
