"""Tests for PHP PDG extraction and program slicing (L5).

TDD Tests for PHP PDG support.

Tests mirror the structure of test_pdg_java.py and test_pdg_c.py but for PHP language support.
PHP CFG (L3) and DFG (L4) must be implemented first.
"""
import os
import pytest

# Check if tree-sitter-php is available
try:
    from tldr.cfg_extractor import TREE_SITTER_PHP_AVAILABLE
    PHP_AVAILABLE = TREE_SITTER_PHP_AVAILABLE
except ImportError:
    PHP_AVAILABLE = False

# Check if extract_php_pdg is implemented
try:
    from tldr.pdg_extractor import extract_php_pdg
    PHP_PDG_AVAILABLE = True
except ImportError:
    PHP_PDG_AVAILABLE = False
    extract_php_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not PHP_AVAILABLE,
    reason="tree-sitter-php not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_php_path():
    """Path to sample.php fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.php")


@pytest.fixture
def sample_php_code(sample_php_path):
    """Load sample.php fixture code."""
    with open(sample_php_path) as f:
        return f.read()


@pytest.fixture
def simple_php_code():
    """Simple PHP code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''<?php
/**
 * =============================================================================
 * Simple PHP test fixture for PDG extraction
 * This code is used to test basic PDG node and edge extraction.
 * The add function has simple data flow: $a -> $c, $b -> $c, $c -> return
 * =============================================================================
 */
function add(int $a, int $b): int {
    $c = $a + $b;
    return $c;
}
'''


@pytest.fixture
def chained_php_code():
    """PHP code with chained dependencies for slicing tests."""
    return '''<?php
/**
 * =============================================================================
 * Chained computation for forward/backward slice testing.
 * $x -> $a -> $b -> $c -> return creates a clear data flow chain.
 * This fixture tests that slicing correctly traces dependencies.
 * =============================================================================
 */
function chainedCompute(int $x): int {
    $a = $x + 1;     // line 10: $a depends on $x
    $b = $a * 2;     // line 11: $b depends on $a
    $c = $b + 3;     // line 12: $c depends on $b
    return $c;       // line 13: return depends on $c
}
'''


# =============================================================================
# Tests for extract_php_pdg()
# =============================================================================

class TestExtractPHPPDG:
    """Test extract_php_pdg() function."""

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_extract_php_pdg_basic(self, sample_php_code):
        """Test basic PDG extraction from sample.php calculate function."""
        pdg = extract_php_pdg(sample_php_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_extract_php_pdg_has_nodes(self, sample_php_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_php_pdg(sample_php_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_extract_php_pdg_has_edges(self, sample_php_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_php_pdg(sample_php_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        # Note: PDGEdge uses dep_type attribute (control/data)
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_extract_php_pdg_sum_function(self, sample_php_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_php_pdg(sample_php_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_extract_php_pdg_nonexistent_function(self, sample_php_code):
        """Test that nonexistent function returns None."""
        pdg = extract_php_pdg(sample_php_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for PHP Program Slicing
# =============================================================================

class TestPHPProgramSlicing:
    """Test program slicing for PHP code."""

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_php_backward_slice(self, sample_php_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_php_pdg(sample_php_code, "sum")

        assert pdg is not None
        # Line 41 is "return $total;" in sample.php
        slice_lines = pdg.backward_slice(line=41)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_php_forward_slice(self, chained_php_code):
        """Test forward slice from first assignment."""
        pdg = extract_php_pdg(chained_php_code, "chainedCompute")

        assert pdg is not None
        # Forward slice from "$a = $x + 1;" (line 10 in chained_php_code)
        slice_lines = pdg.forward_slice(line=10)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_php_slice_returns_set(self, simple_php_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_php_pdg(simple_php_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=11)  # return $c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for PHP PDG via API
# =============================================================================

class TestPHPPDGAPI:
    """Test PHP PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_php_get_pdg_context(self, sample_php_path):
        """Test get_pdg_context() for PHP code via file path."""
        result = get_pdg_context(sample_php_path, "calculate", language="php")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_php_get_slice_backward(self, sample_php_path):
        """Test get_slice() backward for PHP code via file path."""
        # Backward slice from return statement in sum function (line 41)
        lines = get_slice(
            sample_php_path, "sum", line=41,
            direction="backward", language="php"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_php_get_slice_forward(self, sample_php_path):
        """Test get_slice() forward for PHP code via file path."""
        # Forward slice from $a assignment in chainedCompute (line 95)
        lines = get_slice(
            sample_php_path, "chainedCompute", line=95,
            direction="forward", language="php"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestPHPPDGIntegration:
    """Integration tests for PHP PDG."""

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_pdg_from_file(self, sample_php_path, sample_php_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_php_pdg(sample_php_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not PHP_PDG_AVAILABLE, reason="extract_php_pdg not implemented")
    def test_pdg_to_dict(self, simple_php_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_php_pdg(simple_php_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
