"""Tests for Swift DFG extraction.

TDD Tests for Swift language support in TLDR.
These tests are expected to FAIL initially until Swift support is implemented.

Swift tree-sitter node types:
- Function: function_declaration
- Variable declaration: property_declaration, constant_declaration
- Assignment: assignment_expression
"""
import pytest

# Check if tree-sitter-swift is available
try:
    from tldr.dfg_extractor import extract_swift_dfg, TREE_SITTER_SWIFT_AVAILABLE
    SWIFT_AVAILABLE = TREE_SITTER_SWIFT_AVAILABLE
except ImportError:
    SWIFT_AVAILABLE = False


pytestmark = pytest.mark.skipif(not SWIFT_AVAILABLE, reason="tree-sitter-swift not available")


@pytest.fixture
def simple_assignment_code():
    return '''
class Example {
    func calculate(a: Int, b: Int) -> Int {
        let x = a
        let y = b
        let result = x + y
        return result
    }
}
'''


@pytest.fixture
def reassignment_code():
    return '''
class Example {
    func process(n: Int) -> Int {
        var x = n
        x = x + 1
        x = x * 2
        return x
    }
}
'''


@pytest.fixture
def loop_variable_code():
    return '''
class Example {
    func sum(n: Int) -> Int {
        var total = 0
        for i in 0..<n {
            total = total + i
        }
        return total
    }
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
class Example {
    func choose(x: Int) -> Int {
        var result: Int
        if x > 0 {
            result = 1
        } else {
            result = -1
        }
        return result
    }
}
'''


@pytest.fixture
def let_vs_var_code():
    return '''
class Example {
    func constants(a: Int, b: Int) -> Int {
        let constant = a + b    // immutable (let)
        var mutable = constant  // mutable (var)
        mutable += 1
        return mutable
    }
}
'''


@pytest.fixture
def chained_dependencies_code():
    return '''
class Example {
    func compute(x: Int) -> Int {
        let a = x + 1     // a depends on x
        let b = a * 2     // b depends on a
        let c = b + 3     // c depends on b
        return c          // return depends on c
    }
}
'''


class TestBasicDFG:
    """Test basic DFG extraction for Swift."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_swift_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_swift_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_swift_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_let_vs_var(self, let_vs_var_code):
        dfg = extract_swift_dfg(let_vs_var_code, "constants")
        assert dfg is not None
        # Should track both let and var declarations
        constant_refs = [r for r in dfg.var_refs if r.name == "constant"]
        mutable_refs = [r for r in dfg.var_refs if r.name == "mutable"]
        assert len(constant_refs) > 0
        assert len(mutable_refs) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_swift_dfg(simple_assignment_code, "calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_swift_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_swift_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0

    def test_chained_dependencies(self, chained_dependencies_code):
        dfg = extract_swift_dfg(chained_dependencies_code, "compute")
        assert dfg is not None
        # Should have chain: x -> a -> b -> c
        a_refs = [r for r in dfg.var_refs if r.name == "a"]
        b_refs = [r for r in dfg.var_refs if r.name == "b"]
        c_refs = [r for r in dfg.var_refs if r.name == "c"]
        assert len(a_refs) > 0
        assert len(b_refs) > 0
        assert len(c_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_swift_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_swift_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0

    def test_parameter_tracked(self, simple_assignment_code):
        dfg = extract_swift_dfg(simple_assignment_code, "calculate")
        # Parameters a and b should be tracked
        var_names = {r.name for r in dfg.var_refs}
        assert "a" in var_names or len(var_names) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_swift_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
