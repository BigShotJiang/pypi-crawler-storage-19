"""Tests for C# PDG extraction and program slicing (L5).

TDD Tests - Expected to fail until C# support is implemented.
C# uses tree-sitter-c-sharp (hyphen in package name, underscore in Python import).

Tests mirror the structure of test_pdg_java.py but for C# language support.
"""
import os
import pytest

# Check if tree-sitter-c-sharp is available
try:
    from tldr.cfg_extractor import TREE_SITTER_CSHARP_AVAILABLE
    CSHARP_AVAILABLE = TREE_SITTER_CSHARP_AVAILABLE
except ImportError:
    CSHARP_AVAILABLE = False

# Check if extract_csharp_pdg is implemented
try:
    from tldr.pdg_extractor import extract_csharp_pdg
    CSHARP_PDG_AVAILABLE = True
except ImportError:
    CSHARP_PDG_AVAILABLE = False
    extract_csharp_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not CSHARP_AVAILABLE,
    reason="tree-sitter-c-sharp not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_csharp_path():
    """Path to sample.cs fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.cs")


@pytest.fixture
def sample_csharp_code(sample_csharp_path):
    """Load sample.cs fixture code."""
    with open(sample_csharp_path) as f:
        return f.read()


@pytest.fixture
def simple_csharp_code():
    """Simple C# code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
// =============================================================================
// Simple C# test fixture for PDG extraction
// This code is used to test basic PDG node and edge extraction.
// The Add function has simple data flow: a -> c, b -> c, c -> return
// =============================================================================
public class Example {
    public int Add(int a, int b) {
        int c = a + b;
        return c;
    }
}
'''


@pytest.fixture
def chained_csharp_code():
    """Chained computation for slicing tests (> 500 chars)."""
    return '''
// =============================================================================
// Chained C# test fixture for program slicing
// This code demonstrates data dependency chains for forward/backward slicing.
// x -> a -> b -> c -> return creates a clear chain of dependencies.
// =============================================================================
public class ChainedCompute {
    public int Compute(int x) {
        int a = x + 1;     // line 9: a depends on x
        int b = a * 2;     // line 10: b depends on a
        int c = b + 3;     // line 11: c depends on b
        return c;          // line 12: return depends on c
    }
}
'''


# =============================================================================
# Tests for extract_csharp_pdg()
# =============================================================================

class TestExtractCSharpPDG:
    """Test extract_csharp_pdg() function."""

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_extract_csharp_pdg_basic(self, sample_csharp_code):
        """Test basic PDG extraction from sample.cs Calculate function."""
        pdg = extract_csharp_pdg(sample_csharp_code, "Calculate")

        assert pdg is not None
        assert pdg.function_name == "Calculate"

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_extract_csharp_pdg_has_nodes(self, sample_csharp_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_csharp_pdg(sample_csharp_code, "Calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_extract_csharp_pdg_has_edges(self, sample_csharp_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_csharp_pdg(sample_csharp_code, "Calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        # Note: PDGEdge uses dep_type attribute (control/data)
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_extract_csharp_pdg_sum_function(self, sample_csharp_code):
        """Test PDG extraction for the Sum function with loop."""
        pdg = extract_csharp_pdg(sample_csharp_code, "Sum")

        assert pdg is not None
        assert pdg.function_name == "Sum"
        # Sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_extract_csharp_pdg_nonexistent_function(self, sample_csharp_code):
        """Test that nonexistent function returns None."""
        pdg = extract_csharp_pdg(sample_csharp_code, "NonExistent")

        assert pdg is None


# =============================================================================
# Tests for C# Program Slicing
# =============================================================================

class TestCSharpProgramSlicing:
    """Test program slicing for C# code."""

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_csharp_backward_slice(self, chained_csharp_code):
        """Test backward slice from return statement."""
        pdg = extract_csharp_pdg(chained_csharp_code, "Compute")

        assert pdg is not None
        # Line 12 is "return c;" in the fixture
        slice_lines = pdg.backward_slice(line=12)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_csharp_forward_slice(self, chained_csharp_code):
        """Test forward slice from first assignment."""
        pdg = extract_csharp_pdg(chained_csharp_code, "Compute")

        assert pdg is not None
        # Forward slice from "int a = x + 1;" (line 9)
        slice_lines = pdg.forward_slice(line=9)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_csharp_slice_returns_set(self, simple_csharp_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_csharp_pdg(simple_csharp_code, "Add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=10)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_csharp_slice_nonexistent_function(self, sample_csharp_code):
        """Test that slicing nonexistent function returns empty set."""
        pdg = extract_csharp_pdg(sample_csharp_code, "NonExistent")

        # Either returns None (no PDG) or empty slice
        if pdg is None:
            # This is acceptable behavior
            pass
        else:
            slice_lines = pdg.backward_slice(line=10)
            assert slice_lines == set()


# =============================================================================
# Tests for C# PDG via API
# =============================================================================

class TestCSharpPDGAPI:
    """Test C# PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_csharp_get_pdg_context(self, sample_csharp_path):
        """Test get_pdg_context() for C# code via file path."""
        result = get_pdg_context(sample_csharp_path, "Calculate", language="csharp")

        assert result is not None
        assert "function" in result
        assert result["function"] == "Calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_csharp_get_slice_backward(self, sample_csharp_path):
        """Test get_slice() backward for C# code via file path."""
        # Backward slice from return statement in Sum function
        # Sum's return is at line 52 in sample.cs
        lines = get_slice(
            sample_csharp_path, "Sum", line=52,
            direction="backward", language="csharp"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_csharp_get_slice_forward(self, sample_csharp_path):
        """Test get_slice() forward for C# code via file path."""
        # Forward slice from first assignment in ChainedCompute
        # ChainedCompute's "int a = x + 1" is at line 125 in sample.cs
        lines = get_slice(
            sample_csharp_path, "ChainedCompute", line=125,
            direction="forward", language="csharp"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestCSharpPDGIntegration:
    """Integration tests for C# PDG."""

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_pdg_from_file(self, sample_csharp_path, sample_csharp_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for Calculate function
        pdg = extract_csharp_pdg(sample_csharp_code, "Calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "Calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not CSHARP_PDG_AVAILABLE, reason="extract_csharp_pdg not implemented")
    def test_pdg_to_dict(self, simple_csharp_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_csharp_pdg(simple_csharp_code, "Add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "Add"
