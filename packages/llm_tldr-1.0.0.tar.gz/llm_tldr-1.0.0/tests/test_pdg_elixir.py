"""Tests for Elixir PDG extraction and program slicing (L5).

TDD Tests for Elixir PDG support.
These tests should FAIL initially until Elixir support is implemented.

Tests mirror the structure of test_pdg_ruby.py but for Elixir language support.
"""
import os
import pytest

# Check if tree-sitter-elixir is available
try:
    from tldr.cfg_extractor import TREE_SITTER_ELIXIR_AVAILABLE
    ELIXIR_AVAILABLE = TREE_SITTER_ELIXIR_AVAILABLE
except ImportError:
    ELIXIR_AVAILABLE = False

# Check if extract_elixir_pdg is implemented
try:
    from tldr.pdg_extractor import extract_elixir_pdg
    ELIXIR_PDG_AVAILABLE = True
except ImportError:
    ELIXIR_PDG_AVAILABLE = False
    extract_elixir_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not ELIXIR_AVAILABLE,
    reason="tree-sitter-elixir not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_elixir_path():
    """Path to sample.ex fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.ex")


@pytest.fixture
def sample_elixir_code(sample_elixir_path):
    """Load sample.ex fixture code."""
    with open(sample_elixir_path) as f:
        return f.read()


@pytest.fixture
def simple_elixir_code():
    """Simple Elixir code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
# =============================================================================
# Simple Elixir test fixture for PDG extraction
# This code is used to test basic PDG node and edge extraction.
# The add function has simple data flow: a -> c, b -> c, c -> return
# The comments here ensure the code is longer than 500 characters so it is
# not mistakenly treated as a file path by _resolve_source heuristic.
# =============================================================================
defmodule Example do
  def add(a, b) do
    c = a + b
    c
  end
end
'''


@pytest.fixture
def chained_elixir_code():
    """Elixir code with chained dependencies for slice testing."""
    return '''
# =============================================================================
# Chained Elixir test fixture for PDG extraction and slicing
# This tests forward and backward slices through a dependency chain.
# Dependencies: x -> a -> b -> c -> return
# =============================================================================
defmodule ChainedCompute do
  def compute(x) do
    a = x + 1     # line 9: a depends on x
    b = a * 2     # line 10: b depends on a
    c = b + 3     # line 11: c depends on b
    c             # line 12: return depends on c
  end
end
'''


# =============================================================================
# Tests for extract_elixir_pdg()
# =============================================================================

class TestExtractElixirPDG:
    """Test extract_elixir_pdg() function."""

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_extract_elixir_pdg_basic(self, sample_elixir_code):
        """Test basic PDG extraction from sample.ex calculate method."""
        pdg = extract_elixir_pdg(sample_elixir_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_extract_elixir_pdg_has_nodes(self, sample_elixir_code):
        """Verify PDG has nodes extracted from the method."""
        pdg = extract_elixir_pdg(sample_elixir_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_extract_elixir_pdg_has_edges(self, sample_elixir_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_elixir_pdg(sample_elixir_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_extract_elixir_pdg_sum_method(self, sample_elixir_code):
        """Test PDG extraction for the sum method with Enum.reduce."""
        pdg = extract_elixir_pdg(sample_elixir_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum method should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_extract_elixir_pdg_case_method(self, sample_elixir_code):
        """Test PDG extraction for the get_day method with case statement."""
        pdg = extract_elixir_pdg(sample_elixir_code, "get_day")

        assert pdg is not None
        assert pdg.function_name == "get_day"
        # case with multiple branches should have multiple nodes
        assert len(pdg.nodes) >= 3

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_extract_elixir_pdg_nonexistent_method(self, sample_elixir_code):
        """Test that nonexistent method returns None."""
        pdg = extract_elixir_pdg(sample_elixir_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for Elixir Program Slicing
# =============================================================================

class TestElixirProgramSlicing:
    """Test program slicing for Elixir code."""

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_elixir_backward_slice(self, sample_elixir_code):
        """Test backward slice from return statement in sum method."""
        pdg = extract_elixir_pdg(sample_elixir_code, "sum")

        assert pdg is not None
        # Line 32 is inside the Enum.reduce block in sum function (lines 29-33)
        slice_lines = pdg.backward_slice(line=32)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_elixir_forward_slice(self, chained_elixir_code):
        """Test forward slice from first assignment."""
        pdg = extract_elixir_pdg(chained_elixir_code, "compute")

        assert pdg is not None
        # Forward slice from "a = x + 1" (line 9)
        slice_lines = pdg.forward_slice(line=9)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_elixir_slice_returns_set(self, simple_elixir_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_elixir_pdg(simple_elixir_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=12)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for Elixir PDG via API
# =============================================================================

class TestElixirPDGAPI:
    """Test Elixir PDG integration via tldr.api functions."""

    def test_elixir_get_pdg_context(self, sample_elixir_path):
        """Test get_pdg_context() for Elixir code via file path."""
        result = get_pdg_context(sample_elixir_path, "calculate", language="elixir")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_elixir_get_slice_backward(self, sample_elixir_path):
        """Test get_slice() backward for Elixir code via file path."""
        # Backward slice from inside sum method (lines 29-33)
        lines = get_slice(
            sample_elixir_path, "sum", line=32,
            direction="backward", language="elixir"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_elixir_get_slice_forward(self, sample_elixir_path):
        """Test get_slice() forward for Elixir code via file path."""
        lines = get_slice(
            sample_elixir_path, "compute", line=65,
            direction="forward", language="elixir"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestElixirPDGIntegration:
    """Integration tests for Elixir PDG."""

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_pdg_from_file(self, sample_elixir_path, sample_elixir_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate method
        pdg = extract_elixir_pdg(sample_elixir_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not ELIXIR_PDG_AVAILABLE, reason="extract_elixir_pdg not implemented")
    def test_pdg_to_dict(self, simple_elixir_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_elixir_pdg(simple_elixir_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
