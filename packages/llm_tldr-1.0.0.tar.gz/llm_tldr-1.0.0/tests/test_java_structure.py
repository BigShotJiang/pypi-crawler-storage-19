"""Tests for Java structure extraction via tree-sitter."""
import pytest
from pathlib import Path
from tldr.hybrid_extractor import HybridExtractor

# Skip if tree-sitter-java not available
pytest.importorskip("tree_sitter_java")


@pytest.fixture
def extractor():
    return HybridExtractor()


@pytest.fixture
def simple_java_class(tmp_path):
    """Simple Java class with methods."""
    code = '''
package com.example;

public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }
}
'''
    path = tmp_path / "Calculator.java"
    path.write_text(code)
    return path


@pytest.fixture
def java_with_imports(tmp_path):
    """Java file with import statements."""
    code = '''
package com.example;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Sample {
    public void process(List<String> items) {
    }
}
'''
    path = tmp_path / "Sample.java"
    path.write_text(code)
    return path


@pytest.fixture
def java_with_method_calls(tmp_path):
    """Java file with method calls."""
    code = '''
package com.example;

public class Service {
    public void start() {
        initialize();
        run();
    }

    private void initialize() {
        prepare();
    }

    private void prepare() {
    }

    private void run() {
    }
}
'''
    path = tmp_path / "Service.java"
    path.write_text(code)
    return path


@pytest.fixture
def java_with_multiple_classes(tmp_path):
    """Java file with multiple classes (inner class)."""
    code = '''
package com.example;

public class Outer {
    public void outerMethod() {
    }

    public class Inner {
        public void innerMethod() {
        }
    }
}
'''
    path = tmp_path / "Outer.java"
    path.write_text(code)
    return path


class TestJavaStructureExtraction:
    def test_extracts_class_name(self, extractor, simple_java_class):
        """Should extract class declarations."""
        info = extractor.extract(simple_java_class)

        assert info.language == "java"
        assert len(info.classes) >= 1

        class_names = [c.name for c in info.classes]
        assert "Calculator" in class_names

    def test_extracts_methods(self, extractor, simple_java_class):
        """Should extract method declarations."""
        info = extractor.extract(simple_java_class)

        # Methods should be extracted (either as functions or class methods)
        function_names = [f.name for f in info.functions]
        assert "add" in function_names or any("add" in m.name for c in info.classes for m in c.methods)
        assert "subtract" in function_names or any("subtract" in m.name for c in info.classes for m in c.methods)

    def test_extracts_method_params(self, extractor, simple_java_class):
        """Should extract method parameters."""
        info = extractor.extract(simple_java_class)

        # Find the add method
        add_func = None
        for f in info.functions:
            if f.name == "add":
                add_func = f
                break

        if add_func is None:
            # Check in class methods
            for c in info.classes:
                for m in c.methods:
                    if m.name == "add":
                        add_func = m
                        break

        assert add_func is not None, "Should find 'add' method"
        # Should have 2 parameters (a and b)
        assert len(add_func.params) >= 2

    def test_extracts_return_type(self, extractor, simple_java_class):
        """Should extract method return types."""
        info = extractor.extract(simple_java_class)

        # Find the add method
        add_func = None
        for f in info.functions:
            if f.name == "add":
                add_func = f
                break

        if add_func:
            assert add_func.return_type is not None
            assert "int" in add_func.return_type

    def test_extracts_imports(self, extractor, java_with_imports):
        """Should extract import statements."""
        info = extractor.extract(java_with_imports)

        assert len(info.imports) >= 1
        import_modules = [i.module for i in info.imports]
        assert any("java.util.List" in m for m in import_modules)

    def test_extracts_call_graph(self, extractor, java_with_method_calls):
        """Should extract method call relationships."""
        info = extractor.extract(java_with_method_calls)

        # start() calls initialize() and run()
        start_calls = info.call_graph.calls.get("start", [])
        assert "initialize" in start_calls, f"Expected 'initialize' in {start_calls}"
        assert "run" in start_calls, f"Expected 'run' in {start_calls}"

        # initialize() calls prepare()
        init_calls = info.call_graph.calls.get("initialize", [])
        assert "prepare" in init_calls, f"Expected 'prepare' in {init_calls}"

    def test_extracts_line_numbers(self, extractor, simple_java_class):
        """Should extract line numbers for declarations."""
        info = extractor.extract(simple_java_class)

        # Classes and functions should have line numbers
        for c in info.classes:
            assert c.line_number is not None
            assert c.line_number > 0

        for f in info.functions:
            assert f.line_number is not None
            assert f.line_number > 0

    def test_extracts_fixture_file(self, extractor):
        """Should extract from the test fixture file."""
        fixture_path = Path(__file__).parent / "fixtures" / "Sample.java"
        if not fixture_path.exists():
            pytest.skip("Fixture file not found")

        info = extractor.extract(fixture_path)

        assert info.language == "java"
        assert len(info.classes) >= 1
        assert "Sample" in [c.name for c in info.classes]


class TestJavaFileExtensionRouting:
    def test_java_files_use_tree_sitter(self, extractor, simple_java_class):
        """Java files should be routed to tree-sitter extractor."""
        info = extractor.extract(simple_java_class)

        # Should get structured output (not just Pygments fallback)
        assert info.language == "java"
        # Classes extracted means tree-sitter worked
        assert len(info.classes) >= 1


class TestJavaExtensionConstant:
    def test_java_extensions_defined(self):
        """JAVA_EXTENSIONS constant should be defined."""
        assert hasattr(HybridExtractor, "JAVA_EXTENSIONS")
        assert ".java" in HybridExtractor.JAVA_EXTENSIONS
