"""Tests for Lua CFG extraction.

TDD tests for Lua language support in TLDR CFG extraction.
These tests should FAIL initially until Lua support is implemented.

Lua AST node types (tree-sitter-lua):
- function_declaration: named function definition
- function_definition: anonymous function (lambda)
- function_call: function invocation
- if_statement: if/then/elseif/else control flow
- for_statement: for loops (generic and numeric)
- while_statement: while loops
- repeat_statement: repeat-until loops (unique to Lua)
"""
import pytest

# Check if tree-sitter-lua is available
try:
    from tldr.cfg_extractor import extract_lua_cfg, TREE_SITTER_LUA_AVAILABLE
    LUA_AVAILABLE = TREE_SITTER_LUA_AVAILABLE
except ImportError:
    LUA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not LUA_AVAILABLE, reason="tree-sitter-lua not available")


@pytest.fixture
def simple_if_code():
    return '''
function check(x)
    if x > 0 then
        return "positive"
    end
    return "non-positive"
end
'''


@pytest.fixture
def if_else_code():
    return '''
function calculate(a, b)
    local result
    if a > b then
        result = a - b
    else
        result = b - a
    end
    return result
end
'''


@pytest.fixture
def if_elseif_else_code():
    return '''
function get_grade(score)
    if score >= 90 then
        return "A"
    elseif score >= 80 then
        return "B"
    elseif score >= 70 then
        return "C"
    else
        return "F"
    end
end
'''


@pytest.fixture
def numeric_for_code():
    return '''
function count_range(start_val, end_val)
    local count = 0
    for i = start_val, end_val do
        if i % 2 == 0 then
            count = count + 1
        end
    end
    return count
end
'''


@pytest.fixture
def generic_for_code():
    return '''
function sum(numbers)
    local total = 0
    for i, n in ipairs(numbers) do
        total = total + n
    end
    return total
end
'''


@pytest.fixture
def while_loop_code():
    return '''
function countdown(n)
    local count = 0
    while n > 0 do
        count = count + 1
        n = n - 1
    end
    return count
end
'''


@pytest.fixture
def repeat_until_code():
    return '''
function wait_positive(items)
    local i = 1
    local found = nil
    repeat
        if items[i] > 0 then
            found = items[i]
        end
        i = i + 1
    until found ~= nil or i > #items
    return found
end
'''


@pytest.fixture
def nested_code():
    return '''
function process(items)
    local count = 0
    local i = 1
    while i <= #items do
        if items[i] > 0 then
            count = count + 1
        else
            count = count - 1
        end
        i = i + 1
    end
    return count
end
'''


@pytest.fixture
def pcall_code():
    return '''
function safe_divide(a, b)
    local success, result = pcall(function()
        return a / b
    end)
    if success then
        return result
    else
        return 0
    end
end
'''


class TestBasicCFG:
    """Test basic CFG extraction for Lua."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_lua_cfg(simple_if_code, "check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_if_else(self, if_else_code):
        cfg = extract_lua_cfg(if_else_code, "calculate")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have if-true and if-false branches
        assert len(cfg.blocks) >= 3

    def test_if_elseif_else(self, if_elseif_else_code):
        cfg = extract_lua_cfg(if_elseif_else_code, "get_grade")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have multiple branches for each elseif
        assert len(cfg.blocks) >= 4

    def test_numeric_for(self, numeric_for_code):
        cfg = extract_lua_cfg(numeric_for_code, "count_range")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure
        assert len(cfg.edges) >= 2

    def test_generic_for(self, generic_for_code):
        cfg = extract_lua_cfg(generic_for_code, "sum")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure with back edge
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_lua_cfg(while_loop_code, "countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_lua_cfg(nested_code, "process")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Nested if inside while should produce multiple blocks
        assert len(cfg.blocks) >= 4

    def test_repeat_until(self, repeat_until_code):
        cfg = extract_lua_cfg(repeat_until_code, "wait_positive")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # repeat-until has unique structure: body executes at least once

    def test_pcall_with_anonymous_function(self, pcall_code):
        cfg = extract_lua_cfg(pcall_code, "safe_divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should handle pcall with anonymous function inside


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_lua_cfg(simple_if_code, "check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, generic_for_code):
        cfg = extract_lua_cfg(generic_for_code, "sum")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"

    def test_loop_has_back_edge(self, while_loop_code):
        cfg = extract_lua_cfg(while_loop_code, "countdown")
        # Should have at least one back edge for the loop
        assert len(cfg.edges) >= 2


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_lua_cfg(simple_if_code, "nonexistent")

    def test_empty_code(self):
        with pytest.raises((ValueError, AttributeError)):
            extract_lua_cfg("", "any_function")

    def test_syntax_error_code(self):
        bad_code = "function broken( end"
        with pytest.raises((ValueError, AttributeError)):
            extract_lua_cfg(bad_code, "broken")
