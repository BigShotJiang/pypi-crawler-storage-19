"""Tests for tldr.api module - especially get_relevant_context."""
import tempfile
import pytest
from pathlib import Path

from tldr.api import get_relevant_context


class TestQualifiedFunctionLookup:
    """Functions with same name in different files should be distinguishable."""

    def test_same_function_name_different_files_qualified_lookup(self, tmp_path):
        """Two files with 'spawn_agent' function should both be indexed with qualified names."""
        # Create first file with spawn_agent
        file1 = tmp_path / "claude_spawn.py"
        file1.write_text('''
def spawn_agent(name: str, task: str) -> int:
    """Spawn an agent using Claude."""
    return 42
''')

        # Create second file with spawn_agent
        file2 = tmp_path / "native_spawn.py"
        file2.write_text('''
def spawn_agent(config: dict) -> str:
    """Spawn an agent natively."""
    return "agent-id"
''')

        # Should be able to look up with qualified name
        ctx1 = get_relevant_context(tmp_path, "claude_spawn.spawn_agent", depth=0)
        assert len(ctx1.functions) == 1
        assert "claude_spawn" in ctx1.functions[0].file
        assert "name: str" in ctx1.functions[0].signature

        ctx2 = get_relevant_context(tmp_path, "native_spawn.spawn_agent", depth=0)
        assert len(ctx2.functions) == 1
        assert "native_spawn" in ctx2.functions[0].file
        assert "config: dict" in ctx2.functions[0].signature

    def test_unqualified_lookup_single_match(self, tmp_path):
        """Unqualified name works when function exists in only one file."""
        file1 = tmp_path / "module_a.py"
        file1.write_text('''
def unique_function(x: int) -> int:
    """A unique function."""
    return x * 2
''')

        ctx = get_relevant_context(tmp_path, "unique_function", depth=0)
        assert len(ctx.functions) == 1
        # Returns qualified name for clarity
        assert ctx.functions[0].name == "module_a.unique_function"

    def test_unqualified_lookup_ambiguous_returns_all(self, tmp_path):
        """Unqualified name returns ALL matching functions from multiple files."""
        # Create first file
        file1 = tmp_path / "module_a.py"
        file1.write_text('''
def ambiguous_func(x: int) -> int:
    return x
''')

        # Create second file
        file2 = tmp_path / "module_b.py"
        file2.write_text('''
def ambiguous_func(y: str) -> str:
    return y
''')

        # Should return both functions with qualified names
        ctx = get_relevant_context(tmp_path, "ambiguous_func", depth=0)

        assert len(ctx.functions) == 2
        names = {f.name for f in ctx.functions}
        assert "module_a.ambiguous_func" in names
        assert "module_b.ambiguous_func" in names

    def test_qualified_name_not_found(self, tmp_path):
        """Non-existent qualified name should still return context (with unknown marker)."""
        file1 = tmp_path / "module_a.py"
        file1.write_text('''
def existing_func(x: int) -> int:
    return x
''')

        # This should not raise, just return with "?" file marker
        ctx = get_relevant_context(tmp_path, "nonexistent.function", depth=0)
        assert len(ctx.functions) == 1
        assert ctx.functions[0].file == "?"

    def test_first_file_wins_for_backward_compat(self, tmp_path):
        """When indexing, first file encountered stores unqualified name."""
        # Create files in alphabetical order (module_a before module_z)
        file1 = tmp_path / "module_a.py"
        file1.write_text('''
def shared_func() -> str:
    return "from_a"
''')

        file2 = tmp_path / "module_z.py"
        file2.write_text('''
def shared_func() -> str:
    return "from_z"
''')

        # Both should be accessible via qualified names
        ctx_a = get_relevant_context(tmp_path, "module_a.shared_func", depth=0)
        ctx_z = get_relevant_context(tmp_path, "module_z.shared_func", depth=0)

        assert "module_a" in ctx_a.functions[0].file
        assert "module_z" in ctx_z.functions[0].file


class TestCallGraphTraversal:
    """Test that call graph traversal works with qualified names."""

    def test_cross_file_calls_with_qualified_entry(self, tmp_path):
        """Call graph traversal should work when starting from qualified name."""
        # Main file calls helper
        main_file = tmp_path / "main.py"
        main_file.write_text('''
from helper import process_data

def run_pipeline(data: list) -> list:
    """Run the data pipeline."""
    return process_data(data)
''')

        helper_file = tmp_path / "helper.py"
        helper_file.write_text('''
def process_data(items: list) -> list:
    """Process data items."""
    return [x * 2 for x in items]
''')

        # Start from qualified name, should find callee
        ctx = get_relevant_context(tmp_path, "main.run_pipeline", depth=1)

        # Should have run_pipeline and process_data
        func_names = [f.name for f in ctx.functions]
        assert "run_pipeline" in func_names or "main.run_pipeline" in func_names


class TestModuleQueries:
    """Test module-level queries (providers/anthropic style)."""

    def test_module_query_returns_exports(self, tmp_path):
        """Module path query should return all exports from that module."""
        # Create a module structure: providers/anthropic.py
        providers_dir = tmp_path / "providers"
        providers_dir.mkdir()

        anthropic_file = providers_dir / "anthropic.py"
        anthropic_file.write_text('''
def create_client(api_key: str) -> object:
    """Create an Anthropic client."""
    return {}

def send_message(client: object, msg: str) -> str:
    """Send a message via Anthropic."""
    return "response"

class AnthropicProvider:
    """Provider for Anthropic API."""
    def __init__(self, key: str):
        self.key = key

    def call(self, prompt: str) -> str:
        return "result"
''')

        # Query the module path
        ctx = get_relevant_context(tmp_path, "providers/anthropic", depth=0)

        # Should return all exports
        func_names = [f.name for f in ctx.functions]
        assert "create_client" in func_names
        assert "send_message" in func_names
        assert "AnthropicProvider" in func_names

    def test_module_query_nested_path(self, tmp_path):
        """Nested module paths should work (multimodal/video/processor)."""
        # Create nested structure
        multimodal_dir = tmp_path / "multimodal" / "video"
        multimodal_dir.mkdir(parents=True)

        processor_file = multimodal_dir / "processor.py"
        processor_file.write_text('''
def extract_frames(video_path: str) -> list:
    """Extract frames from video."""
    return []

def encode_video(frames: list) -> bytes:
    """Encode frames to video."""
    return b""
''')

        # Query nested module path
        ctx = get_relevant_context(tmp_path, "multimodal/video/processor", depth=0)

        func_names = [f.name for f in ctx.functions]
        assert "extract_frames" in func_names
        assert "encode_video" in func_names

    def test_module_query_nonexistent_raises(self, tmp_path):
        """Non-existent module path should raise ValueError."""
        # Create some file
        file1 = tmp_path / "existing.py"
        file1.write_text('def foo(): pass')

        with pytest.raises(ValueError) as exc_info:
            get_relevant_context(tmp_path, "nonexistent/module", depth=0)

        assert "not found" in str(exc_info.value).lower()

    def test_module_query_with_init(self, tmp_path):
        """Module with __init__.py should also work."""
        pkg_dir = tmp_path / "mypackage"
        pkg_dir.mkdir()

        init_file = pkg_dir / "__init__.py"
        init_file.write_text('''
from .core import main_func
from .utils import helper_func

__all__ = ["main_func", "helper_func"]
''')

        core_file = pkg_dir / "core.py"
        core_file.write_text('def main_func(): pass')

        utils_file = pkg_dir / "utils.py"
        utils_file.write_text('def helper_func(): pass')

        # Query package - should get exports from __init__.py analysis
        ctx = get_relevant_context(tmp_path, "mypackage", depth=0)

        # Should find something (at minimum the package name)
        assert len(ctx.functions) >= 0  # May return empty if only re-exports
