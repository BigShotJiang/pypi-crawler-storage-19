"""Tests for C CFG extraction."""
import pytest

# Check if tree-sitter-c is available
try:
    from tldr.cfg_extractor import extract_c_cfg, TREE_SITTER_C_AVAILABLE
    C_AVAILABLE = TREE_SITTER_C_AVAILABLE
except ImportError:
    C_AVAILABLE = False


pytestmark = pytest.mark.skipif(not C_AVAILABLE, reason="tree-sitter-c not available")


@pytest.fixture
def simple_if_code():
    return '''
int calculate(int a, int b) {
    if (a > b) {
        return a - b;
    }
    return b - a;
}
'''


@pytest.fixture
def if_else_code():
    return '''
int calculate(int a, int b) {
    if (a > b) {
        return a - b;
    } else {
        return b - a;
    }
}
'''


@pytest.fixture
def for_loop_code():
    return '''
int sum(int* numbers, int count) {
    int total = 0;
    for (int i = 0; i < count; i++) {
        total += numbers[i];
    }
    return total;
}
'''


@pytest.fixture
def while_loop_code():
    return '''
int countdown(int n) {
    int steps = 0;
    while (n > 0) {
        steps++;
        n--;
    }
    return steps;
}
'''


@pytest.fixture
def switch_code():
    return '''
const char* get_day(int day) {
    switch (day) {
        case 1:
            return "Monday";
        case 2:
            return "Tuesday";
        default:
            return "Unknown";
    }
}
'''


@pytest.fixture
def nested_code():
    return '''
int process_matrix(int** matrix, int rows, int cols) {
    int total = 0;
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (matrix[i][j] > 0) {
                total += matrix[i][j];
            }
        }
    }
    return total;
}
'''


@pytest.fixture
def do_while_code():
    return '''
int count_up(int n) {
    int i = 0;
    do {
        i++;
    } while (i < n);
    return i;
}
'''


class TestBasicCFG:
    """Test basic CFG extraction for C."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_c_cfg(simple_if_code, "calculate")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_if_else(self, if_else_code):
        cfg = extract_c_cfg(if_else_code, "calculate")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have both branches
        assert len(cfg.blocks) >= 3

    def test_for_loop(self, for_loop_code):
        cfg = extract_c_cfg(for_loop_code, "sum")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure with back edge
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_c_cfg(while_loop_code, "countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_c_cfg(nested_code, "process_matrix")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Nested loops should create more blocks
        assert len(cfg.blocks) >= 4

    def test_switch(self, switch_code):
        cfg = extract_c_cfg(switch_code, "get_day")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Switch should have multiple case blocks
        assert len(cfg.blocks) >= 3

    def test_do_while(self, do_while_code):
        cfg = extract_c_cfg(do_while_code, "count_up")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_c_cfg(simple_if_code, "calculate")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, for_loop_code):
        cfg = extract_c_cfg(for_loop_code, "sum")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_c_cfg(simple_if_code, "nonexistent")
