"""Tests for Ruby CFG extraction.

TDD tests for Ruby language support in TLDR CFG extraction.
These tests should FAIL initially until Ruby support is implemented.

Ruby AST node types (tree-sitter-ruby):
- method: def method_name ... end
- if: if/elsif/else
- while: while loop
- case: case/when statements
- call: method calls
- begin: begin/rescue/end blocks
"""
import pytest

# Check if tree-sitter-ruby is available
try:
    from tldr.cfg_extractor import extract_ruby_cfg, TREE_SITTER_RUBY_AVAILABLE
    RUBY_AVAILABLE = TREE_SITTER_RUBY_AVAILABLE
except ImportError:
    RUBY_AVAILABLE = False


pytestmark = pytest.mark.skipif(not RUBY_AVAILABLE, reason="tree-sitter-ruby not available")


@pytest.fixture
def simple_if_code():
    return '''
class Example
  def check(x)
    if x > 0
      return "positive"
    end
    "non-positive"
  end
end
'''


@pytest.fixture
def if_else_code():
    return '''
class Example
  def calculate(a, b)
    if a > b
      result = a - b
    else
      result = b - a
    end
    result
  end
end
'''


@pytest.fixture
def each_loop_code():
    return '''
class Example
  def sum(numbers)
    total = 0
    numbers.each do |n|
      total += n
    end
    total
  end
end
'''


@pytest.fixture
def while_loop_code():
    return '''
class Example
  def countdown(n)
    count = 0
    while n > 0
      count += 1
      n -= 1
    end
    count
  end
end
'''


@pytest.fixture
def nested_code():
    return '''
class Example
  def process(items)
    count = 0
    i = 0
    while i < items.length
      if items[i] > 0
        count += 1
      else
        count -= 1
      end
      i += 1
    end
    count
  end
end
'''


@pytest.fixture
def begin_rescue_code():
    return '''
class Example
  def divide(a, b)
    begin
      result = a / b
    rescue ZeroDivisionError
      result = 0
    end
    result
  end
end
'''


@pytest.fixture
def case_when_code():
    return '''
class Example
  def get_day(day)
    case day
    when 1
      "Monday"
    when 2
      "Tuesday"
    else
      "Unknown"
    end
  end
end
'''


class TestBasicCFG:
    """Test basic CFG extraction for Ruby."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_ruby_cfg(simple_if_code, "check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_if_else(self, if_else_code):
        cfg = extract_ruby_cfg(if_else_code, "calculate")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have if-true and if-false branches
        assert len(cfg.blocks) >= 3

    def test_each_loop(self, each_loop_code):
        cfg = extract_ruby_cfg(each_loop_code, "sum")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure with back edge
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_ruby_cfg(while_loop_code, "countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_ruby_cfg(nested_code, "process")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Nested if inside while should produce multiple blocks
        assert len(cfg.blocks) >= 4

    def test_begin_rescue(self, begin_rescue_code):
        cfg = extract_ruby_cfg(begin_rescue_code, "divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_case_when(self, case_when_code):
        cfg = extract_ruby_cfg(case_when_code, "get_day")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # case/when with 3 branches should produce multiple blocks


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_ruby_cfg(simple_if_code, "check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, each_loop_code):
        cfg = extract_ruby_cfg(each_loop_code, "sum")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_ruby_cfg(simple_if_code, "nonexistent")
