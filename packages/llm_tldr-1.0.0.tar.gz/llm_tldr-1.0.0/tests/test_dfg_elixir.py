"""Tests for Elixir DFG extraction.

TDD tests for Elixir language support in TLDR DFG extraction.
These tests should FAIL initially until Elixir support is implemented.

Elixir variable reference patterns (tree-sitter-elixir):
- match: identifier = expression (Elixir uses pattern matching for assignment)
- identifier: variable usage
- function parameters: defined in function call head
- anonymous function parameters: fn args -> body end
"""
import pytest

# Check if tree-sitter-elixir is available
try:
    from tldr.dfg_extractor import extract_elixir_dfg, TREE_SITTER_ELIXIR_AVAILABLE
    ELIXIR_AVAILABLE = TREE_SITTER_ELIXIR_AVAILABLE
except ImportError:
    ELIXIR_AVAILABLE = False


pytestmark = pytest.mark.skipif(not ELIXIR_AVAILABLE, reason="tree-sitter-elixir not available")


@pytest.fixture
def simple_assignment_code():
    return '''
defmodule Example do
  def calculate(a, b) do
    x = a
    y = b
    result = x + y
    result
  end
end
'''


@pytest.fixture
def reassignment_code():
    return '''
defmodule Example do
  def process(n) do
    x = n
    x = x + 1
    x = x * 2
    x
  end
end
'''


@pytest.fixture
def enum_variable_code():
    return '''
defmodule Example do
  def sum(numbers) do
    Enum.reduce(numbers, 0, fn n, acc ->
      acc + n
    end)
  end
end
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
defmodule Example do
  def choose(x) do
    if x > 0 do
      result = 1
    else
      result = -1
    end
    result
  end
end
'''


@pytest.fixture
def chained_deps_code():
    return '''
defmodule Example do
  def compute(x) do
    a = x + 1
    b = a * 2
    c = b + 3
    c
  end
end
'''


@pytest.fixture
def multi_path_code():
    return '''
defmodule Example do
  def multi_path(x, y) do
    sum = x + y
    product = x * y
    result = sum + product
    result
  end
end
'''


@pytest.fixture
def anonymous_fn_code():
    return '''
defmodule Example do
  def transform(items) do
    Enum.map(items, fn item ->
      transformed = item * 2
      transformed
    end)
  end
end
'''


@pytest.fixture
def pattern_match_code():
    return '''
defmodule Example do
  def extract({:ok, value, extra}) do
    x = value
    y = extra
    x + y
  end
end
'''


class TestBasicDFG:
    """Test basic DFG extraction for Elixir."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_elixir_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_elixir_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_enum_variable(self, enum_variable_code):
        dfg = extract_elixir_dfg(enum_variable_code, "sum")
        assert dfg is not None
        # Should track 'acc' through the anonymous function
        acc_refs = [r for r in dfg.var_refs if r.name == "acc"]
        assert len(acc_refs) > 0

    def test_chained_dependencies(self, chained_deps_code):
        dfg = extract_elixir_dfg(chained_deps_code, "compute")
        assert dfg is not None
        # Should track the chain x -> a -> b -> c
        a_refs = [r for r in dfg.var_refs if r.name == "a"]
        b_refs = [r for r in dfg.var_refs if r.name == "b"]
        c_refs = [r for r in dfg.var_refs if r.name == "c"]
        assert len(a_refs) > 0
        assert len(b_refs) > 0
        assert len(c_refs) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_elixir_dfg(simple_assignment_code, "calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_elixir_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_elixir_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0

    def test_multi_path_def_use(self, multi_path_code):
        dfg = extract_elixir_dfg(multi_path_code, "multi_path")
        assert dfg is not None
        # x and y are used in two different paths
        assert len(dfg.var_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_elixir_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_elixir_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0

    def test_anonymous_fn_parameter_detected(self, anonymous_fn_code):
        dfg = extract_elixir_dfg(anonymous_fn_code, "transform")
        assert dfg is not None
        # Anonymous function parameter 'item' should be tracked
        item_refs = [r for r in dfg.var_refs if r.name == "item"]
        assert len(item_refs) > 0

    def test_pattern_match_extraction(self, pattern_match_code):
        dfg = extract_elixir_dfg(pattern_match_code, "extract")
        assert dfg is not None
        # Pattern matched 'value' and 'extra' should be tracked
        value_refs = [r for r in dfg.var_refs if r.name == "value"]
        assert len(value_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_elixir_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
