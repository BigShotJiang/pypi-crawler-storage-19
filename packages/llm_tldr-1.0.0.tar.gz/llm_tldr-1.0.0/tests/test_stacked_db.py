"""Tests for tldr.stacked_db module - Stacked Immutable DBs (P5 #19).

This module tests the stacked immutable database pattern (Meta Glean style)
that layers changes as immutable "stacks" for:
- Non-destructive updates (never lose data)
- Concurrent readers (consistent snapshots)
- Cheap branching (fork a stack for speculative work)
- Time travel (query at specific stack/time)

Query semantics: Search all stacks top-to-bottom, first match wins.
"""

import json
import tempfile
import pytest
from pathlib import Path
from datetime import datetime, timedelta
from uuid import uuid4

# Import the module under test - will fail until implemented
from tldr.stacked_db import (
    Edge,
    ImmutableStack,
    StackedDB,
)


class TestEdge:
    """Tests for Edge dataclass."""

    def test_edge_creation(self):
        """Edge should store source and destination file/function."""
        edge = Edge(
            id="edge-1",
            src_file="main.py",
            src_func="main",
            dst_file="utils.py",
            dst_func="helper"
        )
        assert edge.id == "edge-1"
        assert edge.src_file == "main.py"
        assert edge.src_func == "main"
        assert edge.dst_file == "utils.py"
        assert edge.dst_func == "helper"

    def test_edge_to_tuple(self):
        """Edge should be convertible to the standard tuple format."""
        edge = Edge(
            id="edge-1",
            src_file="main.py",
            src_func="main",
            dst_file="utils.py",
            dst_func="helper"
        )
        assert edge.to_tuple() == ("main.py", "main", "utils.py", "helper")

    def test_edge_from_tuple(self):
        """Edge should be creatable from the standard tuple format."""
        edge = Edge.from_tuple("main.py", "main", "utils.py", "helper")
        assert edge.src_file == "main.py"
        assert edge.src_func == "main"
        assert edge.dst_file == "utils.py"
        assert edge.dst_func == "helper"
        assert edge.id is not None  # Auto-generated ID


class TestImmutableStackCreation:
    """Tests for ImmutableStack creation and basic properties."""

    def test_immutable_stack_creation(self):
        """Create new stack with ID, parent, timestamp."""
        stack = ImmutableStack(id="stack-1")
        assert stack.id == "stack-1"
        assert stack.parent is None
        assert stack.created_at is not None
        assert isinstance(stack.created_at, datetime)

    def test_immutable_stack_with_parent(self):
        """Stack can reference a parent stack."""
        parent = ImmutableStack(id="parent")
        child = ImmutableStack(id="child", parent=parent)
        assert child.parent is parent
        assert child.parent.id == "parent"

    def test_immutable_stack_empty_by_default(self):
        """New stack has no edges or deletions."""
        stack = ImmutableStack(id="empty")
        assert len(stack.edges) == 0
        assert len(stack.deletions) == 0


class TestStackAddEdge:
    """Tests for adding edges to a stack."""

    def test_stack_add_edge(self):
        """Add edge to current stack."""
        stack = ImmutableStack(id="stack-1")
        edge = Edge.from_tuple("a.py", "foo", "b.py", "bar")
        stack.add_edge(edge)

        assert len(stack.edges) == 1
        assert stack.edges[0].to_tuple() == ("a.py", "foo", "b.py", "bar")

    def test_stack_add_multiple_edges(self):
        """Add multiple edges to stack."""
        stack = ImmutableStack(id="stack-1")
        stack.add_edge(Edge.from_tuple("a.py", "f1", "b.py", "g1"))
        stack.add_edge(Edge.from_tuple("c.py", "f2", "d.py", "g2"))

        assert len(stack.edges) == 2


class TestStackDeleteEdge:
    """Tests for marking edges as deleted."""

    def test_stack_delete_edge(self):
        """Mark edge as deleted in current stack."""
        stack = ImmutableStack(id="stack-1")
        stack.mark_deleted("edge-to-delete")

        assert "edge-to-delete" in stack.deletions

    def test_stack_delete_multiple_edges(self):
        """Mark multiple edges as deleted."""
        stack = ImmutableStack(id="stack-1")
        stack.mark_deleted("edge-1")
        stack.mark_deleted("edge-2")

        assert "edge-1" in stack.deletions
        assert "edge-2" in stack.deletions


class TestStackQueryFindsInCurrent:
    """Tests for querying edges in the current stack."""

    def test_stack_query_finds_in_current(self):
        """Query finds edge in current stack."""
        stack = ImmutableStack(id="stack-1")
        edge = Edge(id="edge-1", src_file="a.py", src_func="foo",
                    dst_file="b.py", dst_func="bar")
        stack.add_edge(edge)

        result = stack.query_edge("edge-1")
        assert result is not None
        assert result.id == "edge-1"
        assert result.to_tuple() == ("a.py", "foo", "b.py", "bar")

    def test_stack_query_returns_none_for_missing(self):
        """Query returns None for non-existent edge."""
        stack = ImmutableStack(id="stack-1")
        result = stack.query_edge("nonexistent")
        assert result is None


class TestStackQueryFindsInParent:
    """Tests for querying edges that exist in parent stacks."""

    def test_stack_query_finds_in_parent(self):
        """Query finds edge in parent stack when not in current."""
        parent = ImmutableStack(id="parent")
        parent_edge = Edge(id="parent-edge", src_file="p.py", src_func="pf",
                          dst_file="q.py", dst_func="qf")
        parent.add_edge(parent_edge)

        child = ImmutableStack(id="child", parent=parent)

        result = child.query_edge("parent-edge")
        assert result is not None
        assert result.id == "parent-edge"

    def test_stack_query_finds_in_grandparent(self):
        """Query traverses multiple levels to find edge."""
        grandparent = ImmutableStack(id="grandparent")
        gp_edge = Edge(id="gp-edge", src_file="gp.py", src_func="gpf",
                       dst_file="target.py", dst_func="tf")
        grandparent.add_edge(gp_edge)

        parent = ImmutableStack(id="parent", parent=grandparent)
        child = ImmutableStack(id="child", parent=parent)

        result = child.query_edge("gp-edge")
        assert result is not None
        assert result.id == "gp-edge"


class TestStackDeletionShadowsParent:
    """Tests for deletion in child hiding parent's edge."""

    def test_stack_deletion_shadows_parent(self):
        """Deletion in child hides parent's edge."""
        parent = ImmutableStack(id="parent")
        edge = Edge(id="shared-edge", src_file="a.py", src_func="f",
                    dst_file="b.py", dst_func="g")
        parent.add_edge(edge)

        child = ImmutableStack(id="child", parent=parent)
        child.mark_deleted("shared-edge")

        # Child's deletion shadows parent's edge
        result = child.query_edge("shared-edge")
        assert result is None

        # Parent's edge still exists in parent
        parent_result = parent.query_edge("shared-edge")
        assert parent_result is not None

    def test_stack_deletion_doesnt_affect_sibling(self):
        """Deletion in one fork doesn't affect sibling fork."""
        parent = ImmutableStack(id="parent")
        edge = Edge(id="shared-edge", src_file="a.py", src_func="f",
                    dst_file="b.py", dst_func="g")
        parent.add_edge(edge)

        # Two children from same parent
        child1 = ImmutableStack(id="child1", parent=parent)
        child2 = ImmutableStack(id="child2", parent=parent)

        child1.mark_deleted("shared-edge")

        # child1 can't see the edge
        assert child1.query_edge("shared-edge") is None
        # child2 still sees the edge
        assert child2.query_edge("shared-edge") is not None


class TestStackedDBFork:
    """Tests for forking stacks."""

    def test_fork_creates_new_stack(self):
        """Fork creates independent stack with current as parent."""
        db = StackedDB()
        db.add_edge("main.py", "main", "utils.py", "helper")

        forked = db.fork()

        # Forked DB has current as parent
        assert forked.current.parent is db.current
        # Forked DB can see parent's edges
        edges = forked.get_all_edges()
        assert any(e == ("main.py", "main", "utils.py", "helper") for e in edges)

    def test_fork_is_independent(self):
        """Changes in fork don't affect original."""
        db = StackedDB()
        db.add_edge("main.py", "main", "utils.py", "helper")

        forked = db.fork()
        forked.add_edge("new.py", "new_func", "other.py", "other_func")

        # Original doesn't have the new edge
        original_edges = db.get_all_edges()
        assert not any(e[0] == "new.py" for e in original_edges)

        # Forked has both
        forked_edges = forked.get_all_edges()
        assert any(e[0] == "main.py" for e in forked_edges)
        assert any(e[0] == "new.py" for e in forked_edges)


class TestQueryAllEdgesMerged:
    """Tests for get_all_edges merging across stacks."""

    def test_query_all_edges_merged(self):
        """get_all_edges merges all stacks."""
        grandparent = ImmutableStack(id="gp")
        grandparent.add_edge(Edge.from_tuple("gp.py", "gf", "t.py", "tf"))

        parent = ImmutableStack(id="p", parent=grandparent)
        parent.add_edge(Edge.from_tuple("p.py", "pf", "t.py", "tf"))

        child = ImmutableStack(id="c", parent=parent)
        child.add_edge(Edge.from_tuple("c.py", "cf", "t.py", "tf"))

        db = StackedDB(base=child)
        edges = db.get_all_edges()

        # All three edges should be present
        assert len(edges) == 3
        files = {e[0] for e in edges}
        assert files == {"gp.py", "p.py", "c.py"}

    def test_query_all_edges_respects_deletions(self):
        """get_all_edges excludes deleted edges."""
        parent = ImmutableStack(id="parent")
        edge1 = Edge(id="e1", src_file="a.py", src_func="f1",
                     dst_file="t.py", dst_func="tf")
        edge2 = Edge(id="e2", src_file="b.py", src_func="f2",
                     dst_file="t.py", dst_func="tf")
        parent.add_edge(edge1)
        parent.add_edge(edge2)

        child = ImmutableStack(id="child", parent=parent)
        child.mark_deleted("e1")

        db = StackedDB(base=child)
        edges = db.get_all_edges()

        # Only e2 should be present
        assert len(edges) == 1
        assert edges[0][0] == "b.py"


class TestRollbackToParent:
    """Tests for rollback functionality."""

    def test_rollback_to_parent(self):
        """Can rollback to parent stack."""
        db = StackedDB()
        db.add_edge("base.py", "bf", "t.py", "tf")

        forked = db.fork()
        forked.add_edge("forked.py", "ff", "t.py", "tf")

        # Rollback
        rolled_back = forked.rollback()

        edges = rolled_back.get_all_edges()
        # Should only have base edge
        assert len(edges) == 1
        assert edges[0][0] == "base.py"

    def test_rollback_from_root_returns_empty(self):
        """Rollback from root stack returns empty stack."""
        db = StackedDB()
        db.add_edge("base.py", "bf", "t.py", "tf")

        # Can't rollback past root - returns new empty stack
        rolled_back = db.rollback()
        edges = rolled_back.get_all_edges()
        assert len(edges) == 0


class TestStackDepthTracking:
    """Tests for tracking stack chain depth."""

    def test_stack_depth_tracking(self):
        """Track depth of stack chain."""
        db = StackedDB()
        assert db.depth() == 1

        forked1 = db.fork()
        assert forked1.depth() == 2

        forked2 = forked1.fork()
        assert forked2.depth() == 3

    def test_stack_depth_after_rollback(self):
        """Depth decreases after rollback."""
        db = StackedDB()
        forked = db.fork().fork().fork()
        assert forked.depth() == 4

        rolled_back = forked.rollback()
        assert rolled_back.depth() == 3


class TestCompactMergesStacks:
    """Tests for compacting stacks."""

    def test_compact_merges_stacks(self):
        """Compact merges N stacks into 1."""
        db = StackedDB()
        db.add_edge("a.py", "fa", "t.py", "tf")

        forked1 = db.fork()
        forked1.add_edge("b.py", "fb", "t.py", "tf")

        forked2 = forked1.fork()
        forked2.add_edge("c.py", "fc", "t.py", "tf")

        # Depth is 3
        assert forked2.depth() == 3

        # Compact
        compacted = forked2.compact()

        # Depth should be 1
        assert compacted.depth() == 1

        # All edges still present
        edges = compacted.get_all_edges()
        assert len(edges) == 3
        files = {e[0] for e in edges}
        assert files == {"a.py", "b.py", "c.py"}

    def test_compact_respects_deletions(self):
        """Compact properly handles deletions."""
        db = StackedDB()
        edge = Edge(id="e1", src_file="a.py", src_func="fa",
                    dst_file="t.py", dst_func="tf")
        db.current.add_edge(edge)

        forked = db.fork()
        forked.current.mark_deleted("e1")
        forked.add_edge("b.py", "fb", "t.py", "tf")

        compacted = forked.compact()

        # Only b.py edge should exist (a.py was deleted)
        edges = compacted.get_all_edges()
        assert len(edges) == 1
        assert edges[0][0] == "b.py"


class TestPersistenceSaveLoad:
    """Tests for save/load stack chain to disk."""

    def test_persistence_save_load(self, tmp_path):
        """Save/load stack chain to disk."""
        db = StackedDB()
        db.add_edge("a.py", "fa", "t.py", "tf")

        forked = db.fork()
        forked.add_edge("b.py", "fb", "t.py", "tf")

        # Save
        save_path = tmp_path / "stacked.json"
        forked.save(str(save_path))

        # Load into new instance
        loaded = StackedDB.load(str(save_path))

        edges = loaded.get_all_edges()
        assert len(edges) == 2
        files = {e[0] for e in edges}
        assert files == {"a.py", "b.py"}

    def test_persistence_preserves_depth(self, tmp_path):
        """Save/load preserves stack depth."""
        db = StackedDB()
        forked = db.fork().fork()
        assert forked.depth() == 3

        save_path = tmp_path / "stacked.json"
        forked.save(str(save_path))

        loaded = StackedDB.load(str(save_path))
        assert loaded.depth() == 3

    def test_persistence_preserves_deletions(self, tmp_path):
        """Save/load preserves deletion markers."""
        db = StackedDB()
        edge = Edge(id="e1", src_file="a.py", src_func="fa",
                    dst_file="t.py", dst_func="tf")
        db.current.add_edge(edge)

        forked = db.fork()
        forked.current.mark_deleted("e1")

        save_path = tmp_path / "stacked.json"
        forked.save(str(save_path))

        loaded = StackedDB.load(str(save_path))
        # Deletion should be preserved
        assert loaded.current.query_edge("e1") is None


class TestBranchDivergence:
    """Tests for independent branch divergence."""

    def test_branch_divergence(self):
        """Two forks can diverge independently."""
        db = StackedDB()
        db.add_edge("base.py", "bf", "t.py", "tf")

        # Two forks from same base
        fork_a = db.fork()
        fork_b = db.fork()

        # Add different edges
        fork_a.add_edge("a.py", "fa", "t.py", "tf")
        fork_b.add_edge("b.py", "fb", "t.py", "tf")

        # Each fork has base + its own edge
        edges_a = fork_a.get_all_edges()
        edges_b = fork_b.get_all_edges()

        assert len(edges_a) == 2
        assert len(edges_b) == 2

        files_a = {e[0] for e in edges_a}
        files_b = {e[0] for e in edges_b}

        assert files_a == {"base.py", "a.py"}
        assert files_b == {"base.py", "b.py"}

    def test_branch_deletion_independence(self):
        """Deletions in one branch don't affect other branch."""
        db = StackedDB()
        edge = Edge(id="shared", src_file="base.py", src_func="bf",
                    dst_file="t.py", dst_func="tf")
        db.current.add_edge(edge)

        fork_a = db.fork()
        fork_b = db.fork()

        # Delete in fork_a only
        fork_a.current.mark_deleted("shared")

        # fork_a can't see it
        assert len(fork_a.get_all_edges()) == 0
        # fork_b still sees it
        assert len(fork_b.get_all_edges()) == 1


class TestTimeTravelQuery:
    """Tests for querying at specific stack/time."""

    def test_time_travel_query(self):
        """Query at specific stack/time."""
        db = StackedDB()
        db.add_edge("v1.py", "f1", "t.py", "tf")
        stack_v1_id = db.current.id

        forked = db.fork()
        forked.add_edge("v2.py", "f2", "t.py", "tf")
        stack_v2_id = forked.current.id

        # Query at v1 - should only see v1 edge
        v1_edges = forked.query_at_stack(stack_v1_id)
        assert len(v1_edges) == 1
        assert v1_edges[0][0] == "v1.py"

        # Query at v2 - should see both
        v2_edges = forked.query_at_stack(stack_v2_id)
        assert len(v2_edges) == 2

    def test_time_travel_by_timestamp(self):
        """Query by approximate timestamp."""
        db = StackedDB()
        db.add_edge("early.py", "fe", "t.py", "tf")

        # Simulate time passing
        early_time = db.current.created_at

        forked = db.fork()
        # Manually set created_at to simulate later time
        forked.current.created_at = early_time + timedelta(hours=1)
        forked.add_edge("late.py", "fl", "t.py", "tf")

        # Query at early time should only see early edge
        early_edges = forked.query_at_time(early_time + timedelta(minutes=1))
        assert len(early_edges) == 1
        assert early_edges[0][0] == "early.py"


class TestStackedDBConvenience:
    """Tests for StackedDB convenience methods."""

    def test_stacked_db_add_edge_convenience(self):
        """StackedDB.add_edge should add to current stack."""
        db = StackedDB()
        db.add_edge("a.py", "fa", "b.py", "fb")

        edges = db.get_all_edges()
        assert len(edges) == 1
        assert edges[0] == ("a.py", "fa", "b.py", "fb")

    def test_stacked_db_remove_edge_convenience(self):
        """StackedDB.remove_edge should mark as deleted."""
        db = StackedDB()
        edge = Edge(id="e1", src_file="a.py", src_func="fa",
                    dst_file="b.py", dst_func="fb")
        db.current.add_edge(edge)

        db.remove_edge("e1")

        edges = db.get_all_edges()
        assert len(edges) == 0

    def test_stacked_db_get_edges_for_file(self):
        """StackedDB should support querying edges by file."""
        db = StackedDB()
        db.add_edge("a.py", "f1", "b.py", "g1")
        db.add_edge("a.py", "f2", "c.py", "g2")
        db.add_edge("x.py", "fx", "y.py", "fy")

        edges = db.get_edges_for_file("a.py")
        assert len(edges) == 2
        assert all(e[0] == "a.py" for e in edges)
