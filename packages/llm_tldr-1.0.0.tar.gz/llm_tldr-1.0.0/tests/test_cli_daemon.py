"""
Tests for TLDR CLI daemon subcommands.

TDD: Write tests first for daemon management via main CLI:
    tldr daemon start [--project PATH]
    tldr daemon stop [--project PATH]
    tldr daemon status [--project PATH]
    tldr daemon query CMD [--project PATH]
"""

import json
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestDaemonSubcommandGroup:
    """Test that daemon subcommand group exists."""

    def test_daemon_help_available(self):
        """tldr daemon --help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "daemon", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "daemon" in result.stdout.lower() or "daemon" in result.stderr.lower()

    def test_daemon_requires_subcommand(self):
        """tldr daemon without subcommand should show help or error."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "daemon"],
            capture_output=True,
            text=True,
        )
        # Either show help or require subcommand
        assert result.returncode != 0 or "usage" in result.stdout.lower()


class TestDaemonStartCommand:
    """Test tldr daemon start subcommand."""

    def test_daemon_start_help(self):
        """tldr daemon start --help should show options."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "daemon", "start", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--project" in result.stdout or "-p" in result.stdout

    def test_daemon_start_accepts_project_option(self):
        """tldr daemon start --project PATH should accept a path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create .tldr directory so daemon can write files
            tldr_dir = Path(tmpdir) / ".tldr"
            tldr_dir.mkdir()

            # Run with --foreground would block, so we just verify parsing
            # by using mock
            with patch("tldr.daemon.start_daemon") as mock_start:
                # Import and call main directly with args
                import sys
                old_argv = sys.argv
                try:
                    sys.argv = ["tldr", "daemon", "start", "--project", tmpdir]
                    from tldr.cli import main
                    # This will call start_daemon
                    try:
                        main()
                    except SystemExit:
                        pass  # argparse may exit
                finally:
                    sys.argv = old_argv

                # Check start_daemon was called with correct path
                if mock_start.called:
                    call_args = mock_start.call_args
                    assert tmpdir in str(call_args)


class TestDaemonStopCommand:
    """Test tldr daemon stop subcommand."""

    def test_daemon_stop_help(self):
        """tldr daemon stop --help should show options."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "daemon", "stop", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--project" in result.stdout or "-p" in result.stdout

    def test_daemon_stop_when_not_running(self):
        """tldr daemon stop should handle case when daemon not running."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "tldr.cli", "daemon", "stop", "--project", tmpdir],
                capture_output=True,
                text=True,
            )
            # Should not crash, but indicate daemon was not running
            # Exit code 0 or message indicating not running
            assert "not running" in result.stdout.lower() or result.returncode == 0


class TestDaemonStatusCommand:
    """Test tldr daemon status subcommand."""

    def test_daemon_status_help(self):
        """tldr daemon status --help should show options."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "daemon", "status", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "--project" in result.stdout or "-p" in result.stdout

    def test_daemon_status_when_not_running(self):
        """tldr daemon status should report not running."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "tldr.cli", "daemon", "status", "--project", tmpdir],
                capture_output=True,
                text=True,
            )
            # Should indicate daemon is not running
            assert "not running" in result.stdout.lower() or "stopped" in result.stdout.lower()


class TestDaemonQueryCommand:
    """Test tldr daemon query subcommand."""

    def test_daemon_query_help(self):
        """tldr daemon query --help should show options."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "daemon", "query", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        # Should show command argument
        assert "command" in result.stdout.lower() or "cmd" in result.stdout.lower()

    def test_daemon_query_when_not_running(self):
        """tldr daemon query should handle case when daemon not running."""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = subprocess.run(
                [sys.executable, "-m", "tldr.cli", "daemon", "query", "ping", "--project", tmpdir],
                capture_output=True,
                text=True,
            )
            # Should indicate connection failed or daemon not running
            assert result.returncode != 0 or "not running" in result.stdout.lower() or "connection" in result.stderr.lower()


class TestDaemonIntegration:
    """Integration tests for daemon CLI commands with actual daemon."""

    @pytest.mark.slow
    def test_start_status_stop_cycle(self):
        """Test full daemon lifecycle via CLI."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            tldr_dir = project / ".tldr"
            tldr_dir.mkdir()

            # Start daemon in background via fork (Unix only)
            if os.name == "nt":
                pytest.skip("Daemon fork not supported on Windows")

            # Start daemon using Popen to avoid blocking on fork
            start_proc = subprocess.Popen(
                [sys.executable, "-m", "tldr.cli", "daemon", "start", "--project", tmpdir],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                stdin=subprocess.DEVNULL,
            )
            # Wait a bit for the fork to happen
            time.sleep(0.5)

            # The parent should have exited after forking
            try:
                start_proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                start_proc.kill()

            # Give daemon time to start
            time.sleep(0.5)

            # Check status
            status_result = subprocess.run(
                [sys.executable, "-m", "tldr.cli", "daemon", "status", "--project", tmpdir],
                capture_output=True,
                text=True,
                timeout=5,
            )

            # Stop daemon
            stop_result = subprocess.run(
                [sys.executable, "-m", "tldr.cli", "daemon", "stop", "--project", tmpdir],
                capture_output=True,
                text=True,
                timeout=5,
            )

            # Verify at least stop succeeded or daemon was already stopped
            assert "stopped" in stop_result.stdout.lower() or "not running" in stop_result.stdout.lower() or stop_result.returncode == 0


class TestDaemonProjectDefault:
    """Test that --project defaults to current directory."""

    def test_start_defaults_to_cwd(self):
        """tldr daemon start without --project should use current directory."""
        # Verify help shows default
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "daemon", "start", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        # Should show default is current directory
        assert "default" in result.stdout.lower() or "." in result.stdout
