"""Adversarial timeout tests for tree-sitter parsing.

These tests verify that TLDR parsing operations are protected against
inputs that could cause indefinite hangs. Tree-sitter provides
`parser.set_timeout_micros()` but TLDR does NOT currently implement
timeout protection - parsers can hang indefinitely on pathological input.

Test Categories:
- PATHOLOGICAL_NESTING: Deeply nested parentheses/brackets that stress stack
- LARGE_TOKEN_SEQUENCE: Millions of tokens in sequence (1+1+1+...)
- GIANT_LITERALS: Extremely large strings, arrays, dictionaries
- EXTERNAL_SCANNER: Ruby heredocs, Python indentation edge cases

These tests use signal.alarm() to prevent the test suite from hanging.
All tests are marked xfail because timeout protection is NOT implemented.

Usage:
    pytest tests/test_adversarial_timeout.py -v
    pytest tests/test_adversarial_timeout.py -v -k "python"  # Python only
"""

import platform
import signal
import tempfile
from pathlib import Path

import pytest

# Skip all tests on Windows (no signal.SIGALRM)
pytestmark = pytest.mark.skipif(
    platform.system() == "Windows",
    reason="signal.SIGALRM not available on Windows"
)

# =============================================================================
# TEST INFRASTRUCTURE
# =============================================================================


class TimeoutHandler:
    """Context manager for signal-based test timeout."""

    def __init__(self, seconds: int, message: str = "Operation timed out"):
        self.seconds = seconds
        self.message = message
        self._old_handler = None

    def __enter__(self):
        def handler(signum, frame):
            raise TimeoutError(self.message)

        self._old_handler = signal.signal(signal.SIGALRM, handler)
        signal.alarm(self.seconds)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        signal.alarm(0)
        if self._old_handler is not None:
            signal.signal(signal.SIGALRM, self._old_handler)
        return False


def extract_with_timeout(code: str, ext: str, timeout_seconds: int = 5) -> dict:
    """Extract structure from code with signal-based timeout protection.

    Args:
        code: Source code to parse
        ext: File extension (e.g., ".py", ".ts", ".go", ".rs")
        timeout_seconds: Maximum time allowed for parsing

    Returns:
        Extraction result dict

    Raises:
        TimeoutError: If parsing exceeds timeout_seconds
    """
    from tldr.api import extract_file

    with tempfile.NamedTemporaryFile(mode="w", suffix=ext, delete=False) as f:
        f.write(code)
        f.flush()
        path = Path(f.name)

    try:
        with TimeoutHandler(timeout_seconds, f"Parser hung on {ext} file"):
            return extract_file(str(path))
    finally:
        path.unlink()


def cfg_with_timeout(code: str, func: str, lang: str, timeout_seconds: int = 5) -> dict:
    """Get CFG with signal-based timeout protection.

    Args:
        code: Source code containing the function
        func: Function name to analyze
        lang: Language identifier
        timeout_seconds: Maximum time allowed

    Returns:
        CFG result dict

    Raises:
        TimeoutError: If CFG extraction exceeds timeout_seconds
    """
    from tldr.api import get_cfg_context

    with TimeoutHandler(timeout_seconds, f"CFG extraction hung on {lang}"):
        return get_cfg_context(code, func, language=lang)


# =============================================================================
# PATHOLOGICAL INPUT GENERATORS
# =============================================================================


def make_nested_parens(depth: int, lang: str = "python") -> str:
    """Generate deeply nested parentheses that stress parser stack.

    Example (depth=5):
        Python: x = (((((1)))))
        Go: var x = (((((1)))))
        Rust: let x = (((((1)))))
    """
    if lang == "go":
        return "package main\nvar x = " + "(" * depth + "1" + ")" * depth
    elif lang == "rust":
        return "fn main() { let x = " + "(" * depth + "1" + ")" * depth + "; }"
    elif lang in ("typescript", "javascript"):
        return "const x = " + "(" * depth + "1" + ")" * depth + ";"
    else:  # python
        return "x = " + "(" * depth + "1" + ")" * depth


def make_nested_brackets(depth: int, lang: str = "python") -> str:
    """Generate deeply nested array/list brackets.

    Example (depth=5):
        Python: x = [[[[[1]]]]]
        TypeScript: const x = [[[[[1]]]]];
    """
    if lang in ("typescript", "javascript"):
        return "const x = " + "[" * depth + "1" + "]" * depth + ";"
    elif lang == "go":
        # Go requires type annotation
        return "package main\nvar x = " + "[]int{" * depth + "1" + "}" * depth
    elif lang == "rust":
        prefix = "fn main() { let x: Vec<Vec<Vec<i32>>> = vec!"
        inner = "[vec![" * (depth - 1) + "vec![1]" + "]]" * (depth - 1)
        return f"{prefix}{inner}; }}"
    else:  # python
        return "x = " + "[" * depth + "1" + "]" * depth


def make_nested_braces(depth: int, lang: str = "python") -> str:
    """Generate deeply nested dict/object braces.

    Example (depth=3):
        Python: x = {"a": {"a": {"a": 1}}}
        TypeScript: const x = {a: {a: {a: 1}}};
    """
    if lang in ("typescript", "javascript"):
        inner = "1"
        for _ in range(depth):
            inner = "{a: " + inner + "}"
        return f"const x = {inner};"
    elif lang == "go":
        # Go requires explicit type
        inner = "1"
        for _ in range(depth):
            inner = "map[string]interface{}{\"a\": " + inner + "}"
        return f"package main\nvar x = {inner}"
    else:  # python
        inner = "1"
        for _ in range(depth):
            inner = '{"a": ' + inner + "}"
        return f"x = {inner}"


def make_token_chain(count: int, lang: str = "python") -> str:
    """Generate a chain of tokens (1+1+1+...).

    This creates many tokens that must all be parsed without deep nesting.
    """
    chain = "+".join(["1"] * count)
    if lang == "go":
        return f"package main\nvar x = {chain}"
    elif lang == "rust":
        return f"fn main() {{ let x = {chain}; }}"
    elif lang in ("typescript", "javascript"):
        return f"const x = {chain};"
    else:  # python
        return f"x = {chain}"


def make_giant_string(size: int, lang: str = "python") -> str:
    """Generate a giant string literal.

    Args:
        size: Number of characters in the string
    """
    content = "a" * size
    if lang == "go":
        return f'package main\nvar x = "{content}"'
    elif lang == "rust":
        return f'fn main() {{ let x = "{content}"; }}'
    elif lang in ("typescript", "javascript"):
        return f'const x = "{content}";'
    else:  # python
        return f'x = "{content}"'


def make_quadratic_backtrack(depth: int, lang: str = "python") -> str:
    """Generate code that triggers quadratic backtracking in some parsers.

    This creates ambiguous grammar situations where the parser may need
    to try multiple parse paths.
    """
    if lang == "python":
        # Deeply nested ternary expressions
        inner = "x"
        for i in range(depth):
            inner = f"(a{i} if b{i} else {inner})"
        return f"result = {inner}"
    elif lang in ("typescript", "javascript"):
        # Nested ternary expressions
        inner = "x"
        for i in range(depth):
            inner = f"(a{i} ? b{i} : {inner})"
        return f"const result = {inner};"
    elif lang == "go":
        # Go doesn't have ternary, use nested if
        return make_pathological_indent(depth // 10)  # Scale down for Go
    else:
        return make_nested_parens(depth, lang)


def make_expression_ambiguity(count: int, lang: str = "python") -> str:
    """Generate expressions with many operators that could parse multiple ways.

    Tests parser handling of operator precedence and associativity.
    """
    if lang == "python":
        # Mix of operators with different precedence
        ops = ["+", "-", "*", "/", "**", "//", "%", "&", "|", "^", "<<", ">>"]
        expr = "x"
        for i in range(count):
            op = ops[i % len(ops)]
            expr = f"({expr} {op} y{i})"
        return f"result = {expr}"
    elif lang in ("typescript", "javascript"):
        ops = ["+", "-", "*", "/", "%", "&", "|", "^", "<<", ">>", ">>>"]
        expr = "x"
        for i in range(count):
            op = ops[i % len(ops)]
            expr = f"({expr} {op} y{i})"
        return f"const result = {expr};"
    else:
        return make_token_chain(count, lang)


def make_comment_interleaved(count: int, lang: str = "python") -> str:
    """Generate code with many interleaved comments.

    Tests the lexer's handling of comment tokens.
    """
    if lang == "python":
        lines = []
        for i in range(count):
            lines.append(f"x{i} = {i}  # Comment {i} with text")
            lines.append(f"# Another comment line {i}")
        return "\n".join(lines)
    elif lang in ("typescript", "javascript"):
        lines = []
        for i in range(count):
            lines.append(f"const x{i} = {i};  // Comment {i}")
            lines.append(f"/* Block comment {i} */")
        return "\n".join(lines)
    else:
        return make_token_chain(count // 2, lang)


def make_giant_array(elements: int, lang: str = "python") -> str:
    """Generate a giant array literal with many elements.

    Args:
        elements: Number of elements in the array
    """
    items = ", ".join(["1"] * elements)
    if lang == "go":
        return f"package main\nvar x = []int{{{items}}}"
    elif lang == "rust":
        return f"fn main() {{ let x = vec![{items}]; }}"
    elif lang in ("typescript", "javascript"):
        return f"const x = [{items}];"
    else:  # python
        return f"x = [{items}]"


def make_pathological_indent(depth: int) -> str:
    """Generate Python code with pathological indentation depth.

    This stresses the Python tree-sitter external scanner which
    tracks indentation state.
    """
    code = "def f():\n"
    indent = "    "
    for i in range(depth):
        code += indent * (i + 1) + "if True:\n"
    code += indent * (depth + 1) + "pass\n"
    return code


def make_heredoc_chain(count: int) -> str:
    """Generate Ruby code with many heredocs (external scanner stress).

    Ruby heredocs use an external scanner which can have
    pathological behavior with many consecutive heredocs.
    """
    lines = ["def example"]
    for i in range(count):
        lines.append(f"  s{i} = <<~HEREDOC{i}")
        lines.append(f"    Content {i}")
        lines.append(f"  HEREDOC{i}")
    lines.append("end")
    return "\n".join(lines)


def make_fstring_chain(count: int) -> str:
    """Generate Python f-strings with many interpolations.

    f-strings are parsed with special tree-sitter handling that
    can be slow with many interpolations.
    """
    interps = "".join([f"{{x{i}}}" for i in range(count)])
    vars_def = "\n".join([f"x{i} = {i}" for i in range(count)])
    return f'{vars_def}\nresult = f"{interps}"'


def make_regex_chain(count: int, lang: str = "javascript") -> str:
    """Generate code with many regex literals.

    Regex literals use external scanners in JS/TS.
    """
    if lang in ("typescript", "javascript"):
        regexes = "\n".join([f"const r{i} = /pattern{i}/g;" for i in range(count)])
        return regexes
    else:
        return ""


# =============================================================================
# PYTHON TIMEOUT TESTS
# =============================================================================


class TestPythonTimeout:
    """Python parsing timeout tests."""

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_parens_10k(self):
        """10,000 nested parentheses - should complete or timeout gracefully."""
        code = make_nested_parens(10000, "python")
        # This may hang indefinitely without timeout protection
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_quadratic_backtrack_1k(self):
        """1,000 nested ternary expressions - quadratic backtracking risk."""
        code = make_quadratic_backtrack(1000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_expression_ambiguity_5k(self):
        """5,000 mixed operator expressions."""
        code = make_expression_ambiguity(5000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_comment_interleaved_50k(self):
        """50,000 comment-code pairs."""
        code = make_comment_interleaved(50000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_parens_50k(self):
        """50,000 nested parentheses - extreme depth."""
        code = make_nested_parens(50000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_brackets_10k(self):
        """10,000 nested list brackets."""
        code = make_nested_brackets(10000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_dicts_5k(self):
        """5,000 nested dictionaries."""
        code = make_nested_braces(5000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_token_chain_100k(self):
        """100,000 tokens in an expression chain (1+1+1+...)."""
        code = make_token_chain(100000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_token_chain_1m(self):
        """1,000,000 tokens - extreme token count."""
        code = make_token_chain(1000000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_giant_string_10mb(self):
        """10MB string literal."""
        code = make_giant_string(10_000_000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_giant_list_100k_elements(self):
        """100,000 element list literal."""
        code = make_giant_array(100000, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_pathological_indent_1k(self):
        """1,000 levels of indentation (external scanner stress)."""
        code = make_pathological_indent(1000)
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_fstring_1k_interpolations(self):
        """f-string with 1,000 interpolations."""
        code = make_fstring_chain(1000)
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_cfg_nested_loops_deep(self):
        """CFG extraction on deeply nested loops."""
        depth = 100
        code = "def deep_loops():\n"
        indent = "    "
        for i in range(depth):
            code += indent * (i + 1) + f"for i{i} in range(10):\n"
        code += indent * (depth + 1) + "pass"

        result = cfg_with_timeout(code, "deep_loops", "python", timeout_seconds=5)
        assert result is not None


# =============================================================================
# TYPESCRIPT/JAVASCRIPT TIMEOUT TESTS
# =============================================================================


class TestTypeScriptTimeout:
    """TypeScript/JavaScript parsing timeout tests."""

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_parens_10k(self):
        """10,000 nested parentheses in TypeScript."""
        code = make_nested_parens(10000, "typescript")
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_brackets_10k(self):
        """10,000 nested array brackets in TypeScript."""
        code = make_nested_brackets(10000, "typescript")
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_objects_5k(self):
        """5,000 nested object literals."""
        code = make_nested_braces(5000, "typescript")
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_token_chain_100k(self):
        """100,000 tokens in TypeScript."""
        code = make_token_chain(100000, "typescript")
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_giant_string_10mb(self):
        """10MB string in TypeScript."""
        code = make_giant_string(10_000_000, "typescript")
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_regex_chain_10k(self):
        """10,000 regex literals (external scanner stress)."""
        code = make_regex_chain(10000, "javascript")
        result = extract_with_timeout(code, ".js", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_template_literal_chain(self):
        """Template literal with many interpolations."""
        interps = "".join([f"${{x{i}}}" for i in range(1000)])
        var_decls = "\n".join([f"const x{i} = {i};" for i in range(1000)])
        code = f"{var_decls}\nconst result = `{interps}`;"
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None


# =============================================================================
# GO TIMEOUT TESTS
# =============================================================================


class TestGoTimeout:
    """Go parsing timeout tests."""

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_parens_10k(self):
        """10,000 nested parentheses in Go."""
        code = make_nested_parens(10000, "go")
        result = extract_with_timeout(code, ".go", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_token_chain_100k(self):
        """100,000 tokens in Go."""
        code = make_token_chain(100000, "go")
        result = extract_with_timeout(code, ".go", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_giant_string_10mb(self):
        """10MB string in Go."""
        code = make_giant_string(10_000_000, "go")
        result = extract_with_timeout(code, ".go", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_giant_slice_100k(self):
        """100,000 element slice literal."""
        code = make_giant_array(100000, "go")
        result = extract_with_timeout(code, ".go", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_structs(self):
        """Deeply nested struct literals."""
        depth = 1000
        inner = "1"
        for _ in range(depth):
            inner = f"struct{{v interface{{}}}}{{{inner}}}"
        code = f"package main\nvar x = {inner}"
        result = extract_with_timeout(code, ".go", timeout_seconds=5)
        assert result is not None


# =============================================================================
# RUST TIMEOUT TESTS
# =============================================================================


class TestRustTimeout:
    """Rust parsing timeout tests."""

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_parens_10k(self):
        """10,000 nested parentheses in Rust."""
        code = make_nested_parens(10000, "rust")
        result = extract_with_timeout(code, ".rs", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_token_chain_100k(self):
        """100,000 tokens in Rust."""
        code = make_token_chain(100000, "rust")
        result = extract_with_timeout(code, ".rs", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_giant_string_10mb(self):
        """10MB string in Rust."""
        code = make_giant_string(10_000_000, "rust")
        result = extract_with_timeout(code, ".rs", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_macro_invocation_deep(self):
        """Deeply nested macro invocations."""
        depth = 1000
        code = "fn main() { let x = vec!" + "[vec![" * depth + "1" + "]]" * depth + "; }"
        result = extract_with_timeout(code, ".rs", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_turbofish_chain(self):
        """Long chain of turbofish type annotations."""
        # Rust's ::<> syntax can be complex to parse
        inner = "Option::<Option::<" * 100 + "i32" + ">>" * 100
        code = f"fn main() {{ let x = {inner}::None; }}"
        result = extract_with_timeout(code, ".rs", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_lifetime_annotations_deep(self):
        """Many lifetime annotations."""
        lifetimes = ", ".join([f"'a{i}" for i in range(100)])
        code = f"fn example<{lifetimes}>(x: &'a0 str) -> &'a0 str {{ x }}"
        result = extract_with_timeout(code, ".rs", timeout_seconds=5)
        assert result is not None


# =============================================================================
# RUBY TIMEOUT TESTS (External Scanner Stress)
# =============================================================================


class TestRubyTimeout:
    """Ruby parsing timeout tests - external scanner stress."""

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_heredoc_chain_1k(self):
        """1,000 heredocs in sequence (external scanner stress)."""
        code = make_heredoc_chain(1000)
        result = extract_with_timeout(code, ".rb", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_heredoc_nested(self):
        """Heredocs with nested interpolation."""
        code = """
def example
  s = <<~OUTER
    outer text
    #{<<~INNER}
      inner text
    INNER
    more outer
  OUTER
end
"""
        # Repeat this pattern many times
        repeated = code * 100
        result = extract_with_timeout(repeated, ".rb", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_regex_with_interpolation(self):
        """Many regex literals with interpolation."""
        code = "\n".join([
            f"r{i} = /pattern#{{{i}}}/i"
            for i in range(10000)
        ])
        code = f"def example\n{code}\nend"
        result = extract_with_timeout(code, ".rb", timeout_seconds=5)
        assert result is not None


# =============================================================================
# CROSS-LANGUAGE STRESS TESTS
# =============================================================================


class TestCrossLanguageTimeout:
    """Tests that apply pathological patterns across all languages."""

    LANGUAGES = [
        ("python", ".py"),
        ("typescript", ".ts"),
        ("javascript", ".js"),
        ("go", ".go"),
        ("rust", ".rs"),
    ]

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    @pytest.mark.parametrize("lang,ext", LANGUAGES)
    def test_nested_parens_5k(self, lang: str, ext: str):
        """5,000 nested parentheses across all languages."""
        code = make_nested_parens(5000, lang)
        result = extract_with_timeout(code, ext, timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    @pytest.mark.parametrize("lang,ext", LANGUAGES)
    def test_token_chain_50k(self, lang: str, ext: str):
        """50,000 token chain across all languages."""
        code = make_token_chain(50000, lang)
        result = extract_with_timeout(code, ext, timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    @pytest.mark.parametrize("lang,ext", LANGUAGES)
    def test_giant_string_5mb(self, lang: str, ext: str):
        """5MB string across all languages."""
        code = make_giant_string(5_000_000, lang)
        result = extract_with_timeout(code, ext, timeout_seconds=5)
        assert result is not None


# =============================================================================
# COMBINED ATTACK VECTORS
# =============================================================================


class TestCombinedAttacks:
    """Tests combining multiple pathological patterns."""

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_nested_in_giant_array_python(self):
        """Nested structures inside a giant array."""
        # 1000 elements, each deeply nested
        elements = ", ".join(["(" * 100 + "1" + ")" * 100 for _ in range(1000)])
        code = f"x = [{elements}]"
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_wide_and_deep_python(self):
        """Both wide (many siblings) and deep (nested)."""
        # 100 functions, each with 100-deep nesting
        funcs = []
        for i in range(100):
            inner = "pass"
            for _ in range(100):
                inner = f"if True:\n{'    ' * 100}{inner}"
            funcs.append(f"def func{i}():\n{inner}")
        code = "\n\n".join(funcs)
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_many_classes_with_methods_ts(self):
        """Many classes with many methods."""
        classes = []
        for i in range(100):
            methods = "\n".join([
                f"    method{j}() {{ return {j}; }}"
                for j in range(100)
            ])
            classes.append(f"class Class{i} {{\n{methods}\n}}")
        code = "\n\n".join(classes)
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_deeply_nested_generics_ts(self):
        """Deeply nested generic types in TypeScript."""
        # Promise<Promise<Promise<...>>>
        depth = 500
        inner = "number"
        for _ in range(depth):
            inner = f"Promise<{inner}>"
        code = f"const x: {inner} = null as any;"
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_union_type_explosion_ts(self):
        """Many union type members."""
        # type X = A | B | C | ... (10000 members)
        members = " | ".join([f"Type{i}" for i in range(10000)])
        code = f"type BigUnion = {members};"
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None


# =============================================================================
# MEMORY EXHAUSTION VECTORS (Size-based)
# =============================================================================


class TestMemoryExhaustion:
    """Tests targeting memory exhaustion rather than CPU timeout.

    Tree-sitter memory usage is typically 10-200x the file size.
    TLDR has a MAX_FILE_SIZE check but these test edge cases.
    """

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_just_under_size_limit_python(self):
        """File just under the 5MB default limit."""
        # Create a 4.9MB file
        size = 4_900_000
        code = make_giant_string(size, "python")
        result = extract_with_timeout(code, ".py", timeout_seconds=10)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_many_small_functions_python(self):
        """Many small functions (high parse tree node count)."""
        funcs = "\n".join([f"def f{i}(): pass" for i in range(100000)])
        result = extract_with_timeout(funcs, ".py", timeout_seconds=10)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection implemented", strict=False)
    def test_many_imports_python(self):
        """Many import statements."""
        imports = "\n".join([f"import module{i}" for i in range(100000)])
        result = extract_with_timeout(imports, ".py", timeout_seconds=10)
        assert result is not None


# =============================================================================
# GRACEFUL DEGRADATION TESTS
# =============================================================================


class TestGracefulDegradation:
    """Tests that verify TLDR degrades gracefully on bad input.

    These test that even without timeout protection, TLDR should:
    1. Return partial results rather than hang forever
    2. Raise appropriate exceptions (not crash)
    3. Fall back to Pygments when tree-sitter fails
    """

    def test_invalid_syntax_returns_result(self):
        """Invalid syntax should return partial result, not hang."""
        code = "def broken(: pass"  # Invalid Python
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        # Should return something (possibly empty), not timeout
        assert result is not None

    def test_mixed_valid_invalid_python(self):
        """Mix of valid and invalid code."""
        code = """
def valid_func():
    return 42

class Broken(:  # Invalid
    pass

def another_valid():
    return 99
"""
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        # Should still return partial results
        assert result is not None

    def test_binary_content_in_text_file(self):
        """Binary content masquerading as code."""
        # Random bytes that might confuse the parser
        code = bytes([i % 256 for i in range(10000)]).decode("latin-1")
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        # Should handle gracefully
        assert result is not None


# =============================================================================
# VERIFICATION TESTS (should pass even without timeout protection)
# =============================================================================


class TestVerificationSmoke:
    """Smoke tests to verify the test infrastructure works.

    These use small inputs that should always complete quickly.
    If these fail, something is wrong with the test setup.
    """

    def test_simple_python_extraction(self):
        """Simple Python extraction should work."""
        code = "def hello(): pass"
        result = extract_with_timeout(code, ".py", timeout_seconds=5)
        assert result is not None
        assert "functions" in result

    def test_simple_typescript_extraction(self):
        """Simple TypeScript extraction should work."""
        code = "function hello(): void {}"
        result = extract_with_timeout(code, ".ts", timeout_seconds=5)
        assert result is not None

    def test_simple_go_extraction(self):
        """Simple Go extraction should work."""
        code = "package main\nfunc hello() {}"
        result = extract_with_timeout(code, ".go", timeout_seconds=5)
        assert result is not None

    def test_simple_rust_extraction(self):
        """Simple Rust extraction should work."""
        code = "fn hello() {}"
        result = extract_with_timeout(code, ".rs", timeout_seconds=5)
        assert result is not None

    def test_timeout_handler_works(self):
        """Verify the timeout handler actually raises TimeoutError."""
        import time

        with pytest.raises(TimeoutError):
            with TimeoutHandler(1, "Test timeout"):
                time.sleep(5)


# =============================================================================
# TREE-SITTER TIMEOUT API TESTS
# =============================================================================


class TestTreeSitterTimeoutAPI:
    """Tests verifying that tree-sitter timeout API is NOT being used.

    Tree-sitter provides `parser.set_timeout_micros()` for setting a parsing
    timeout. These tests verify that TLDR is NOT currently using this API,
    which means parsers can hang indefinitely.

    When timeout protection is implemented, these tests should be updated
    to verify correct timeout behavior.
    """

    def test_parser_has_no_timeout_set(self):
        """Verify tree-sitter parser does not have timeout configured.

        This test PASSES when timeout is NOT set (current state).
        When timeout protection is implemented, this test should FAIL
        and be updated to verify correct timeout configuration.
        """
        try:
            import tree_sitter_python
            from tree_sitter import Language, Parser
        except ImportError:
            pytest.skip("tree-sitter not available")

        parser = Parser()
        parser.language = Language(tree_sitter_python.language())

        # Tree-sitter Python bindings may not expose timeout_micros getter
        # but we can verify by attempting to parse something that would
        # timeout if a timeout were set
        huge_code = "x = 1"  # Simple code that should always parse fast

        # If timeout were set very low, this would fail
        # Since we don't expect timeout to be set, this should pass
        tree = parser.parse(bytes(huge_code, "utf-8"))
        assert tree is not None
        assert tree.root_node is not None

    def test_hybrid_extractor_no_timeout_protection(self):
        """Verify HybridExtractor doesn't implement timeout protection.

        This documents the current security gap.
        """
        from tldr.hybrid_extractor import HybridExtractor

        # Check that HybridExtractor doesn't have timeout-related attributes
        extractor = HybridExtractor()

        # These would exist if timeout protection were implemented
        assert not hasattr(extractor, 'timeout_micros')
        assert not hasattr(extractor, 'parse_timeout')
        assert not hasattr(extractor, 'max_parse_time')

        # Verify _safe_parse doesn't wrap with timeout
        # (would need code inspection to fully verify)

    @pytest.mark.xfail(
        reason="No timeout protection - test documents vulnerability",
        strict=False
    )
    def test_parser_timeout_would_prevent_hang(self):
        """Demonstrate that parser timeout WOULD prevent hangs if implemented.

        This test shows what timeout protection should look like.
        It's marked xfail because TLDR doesn't implement this.
        """
        try:
            import tree_sitter_python
            from tree_sitter import Language, Parser
        except ImportError:
            pytest.skip("tree-sitter not available")

        parser = Parser()
        parser.language = Language(tree_sitter_python.language())

        # Set a very short timeout (1 millisecond)
        # NOTE: This API exists but TLDR doesn't use it
        # timeout_micros is a property, not a method
        parser.timeout_micros = 1000  # 1ms

        # Try to parse something complex
        code = make_nested_parens(1000, "python")

        # With timeout set, this should either:
        # 1. Return a partial tree
        # 2. Return None
        # 3. Raise an exception
        tree = parser.parse(bytes(code, "utf-8"))

        # If we get here without timeout, the timeout didn't work
        # This test passing means timeout works (xfail becomes xpass)
        # This test timing out means no protection (xfail stays xfail)
        if tree and tree.root_node:
            # Parsing completed - check if it was interrupted
            # A timed-out parse typically has errors
            assert tree.root_node.has_error


# =============================================================================
# SLOW PARSER DETECTION TESTS
# =============================================================================


class TestSlowParserDetection:
    """Tests that measure parsing time to detect slow operations.

    These tests don't rely on timeouts but instead measure actual
    parsing duration to identify problematic inputs.
    """

    def test_measure_nesting_scaling(self):
        """Measure how parsing time scales with nesting depth.

        This helps identify inputs that cause super-linear slowdown.
        """
        import time

        from tldr.api import extract_file

        depths = [100, 500, 1000, 2000]
        times = []

        for depth in depths:
            code = make_nested_parens(depth, "python")

            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
                f.write(code)
                f.flush()
                path = Path(f.name)

            try:
                start = time.perf_counter()
                _ = extract_file(str(path))  # Result unused, measuring time only
                elapsed = time.perf_counter() - start
                times.append((depth, elapsed))
            finally:
                path.unlink()

        # Check for super-linear scaling (potential DoS)
        # If time grows faster than O(n^2), flag as potential issue
        if len(times) >= 2:
            d1, t1 = times[0]
            d2, t2 = times[-1]
            if t1 > 0:
                scaling = (t2 / t1) / ((d2 / d1) ** 2)
                # If scaling > 2, time is growing faster than O(n^2)
                # This would indicate a potential timeout vulnerability
                assert scaling < 2, f"Super-quadratic scaling detected: {scaling:.2f}x"

    def test_measure_token_count_scaling(self):
        """Measure how parsing time scales with token count."""
        import time

        from tldr.api import extract_file

        # Use smaller counts to avoid Python AST recursion limits
        counts = [500, 1000, 2000, 4000]
        times = []

        for count in counts:
            code = make_token_chain(count, "python")

            with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
                f.write(code)
                f.flush()
                path = Path(f.name)

            try:
                start = time.perf_counter()
                _ = extract_file(str(path))  # Result unused, measuring time only
                elapsed = time.perf_counter() - start
                times.append((count, elapsed))
            finally:
                path.unlink()

        # Expect roughly linear scaling for token chains
        if len(times) >= 2 and times[0][1] > 0:
            d1, t1 = times[0]
            d2, t2 = times[-1]
            ratio = (t2 / t1) / (d2 / d1)
            # Allow up to 3x expected linear time (some overhead expected)
            assert ratio < 3, f"Non-linear scaling detected: {ratio:.2f}x expected"


# =============================================================================
# MISSING LANGUAGES TIMEOUT TESTS
# =============================================================================


class TestMissingLanguagesTimeout:
    """Timeout tests for additional languages.

    Tests pathological inputs for: C, C++, Ruby, Kotlin, Swift, C#, Scala, Lua, Elixir.
    Each language has two tests:
    1. Deeply nested structures (braces, parentheses)
    2. Large token chains (e.g., 1+1+1+...)
    """

    # -------------------------------------------------------------------------
    # C Tests (.c)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_c_deeply_nested_braces(self):
        """C with deeply nested braces."""
        depth = 5000
        content = "int main() " + "{" * depth + "return 0;" + "}" * depth
        result = extract_with_timeout(content, ".c", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_c_token_chain_100k(self):
        """C with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"int main() {{ int x = {chain}; return 0; }}"
        result = extract_with_timeout(content, ".c", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # C++ Tests (.cpp)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_cpp_deeply_nested_templates(self):
        """C++ with deeply nested template brackets."""
        depth = 2000
        # std::vector<std::vector<std::vector<...int...>>>
        inner = "int"
        for _ in range(depth):
            inner = f"std::vector<{inner}>"
        content = f"#include <vector>\nint main() {{ {inner} x; return 0; }}"
        result = extract_with_timeout(content, ".cpp", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_cpp_token_chain_100k(self):
        """C++ with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"int main() {{ auto x = {chain}; return 0; }}"
        result = extract_with_timeout(content, ".cpp", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # Ruby Tests (.rb)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_ruby_deeply_nested_blocks(self):
        """Ruby with deeply nested blocks."""
        depth = 3000
        content = "def example\n" + "  begin\n" * depth + "    nil\n" + "  end\n" * depth + "end"
        result = extract_with_timeout(content, ".rb", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_ruby_token_chain_100k(self):
        """Ruby with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"x = {chain}"
        result = extract_with_timeout(content, ".rb", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # Kotlin Tests (.kt)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_kotlin_deeply_nested_lambdas(self):
        """Kotlin with deeply nested lambda expressions."""
        depth = 2000
        # { { { ... } } }
        content = "fun main() { val x = " + "{ " * depth + "1" + " }" * depth + " }"
        result = extract_with_timeout(content, ".kt", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_kotlin_token_chain_100k(self):
        """Kotlin with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"fun main() {{ val x = {chain} }}"
        result = extract_with_timeout(content, ".kt", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # Swift Tests (.swift)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_swift_deeply_nested_closures(self):
        """Swift with deeply nested closures."""
        depth = 2000
        # { { { ... } } }
        content = "let x = " + "{ " * depth + "1" + " }" * depth
        result = extract_with_timeout(content, ".swift", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_swift_token_chain_100k(self):
        """Swift with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"let x = {chain}"
        result = extract_with_timeout(content, ".swift", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # C# Tests (.cs)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_csharp_deeply_nested_braces(self):
        """C# with deeply nested braces."""
        depth = 3000
        prefix = "class Program { static void Main() "
        content = prefix + "{" * depth + "return;" + "}" * depth + " }"
        result = extract_with_timeout(content, ".cs", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_csharp_token_chain_100k(self):
        """C# with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"class Program {{ static void Main() {{ var x = {chain}; }} }}"
        result = extract_with_timeout(content, ".cs", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # Scala Tests (.scala)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_scala_deeply_nested_blocks(self):
        """Scala with deeply nested blocks."""
        depth = 2000
        prefix = "object Main { def main(args: Array[String]): Unit = "
        content = prefix + "{ " * depth + "println(1)" + " }" * depth + " }"
        result = extract_with_timeout(content, ".scala", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_scala_token_chain_100k(self):
        """Scala with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"object Main {{ val x = {chain} }}"
        result = extract_with_timeout(content, ".scala", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # Lua Tests (.lua)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_lua_deeply_nested_tables(self):
        """Lua with deeply nested tables."""
        depth = 5000
        # {{{...1...}}}
        content = "local x = " + "{" * depth + "1" + "}" * depth
        result = extract_with_timeout(content, ".lua", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_lua_token_chain_100k(self):
        """Lua with 100,000 tokens in expression chain."""
        count = 100000
        chain = "+".join(["1"] * count)
        content = f"local x = {chain}"
        result = extract_with_timeout(content, ".lua", timeout_seconds=5)
        assert result is not None

    # -------------------------------------------------------------------------
    # Elixir Tests (.ex)
    # -------------------------------------------------------------------------

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_elixir_deeply_nested_tuples(self):
        """Elixir with deeply nested tuples."""
        depth = 3000
        # {{{...1...}}}
        content = "x = " + "{" * depth + "1" + "}" * depth
        result = extract_with_timeout(content, ".ex", timeout_seconds=5)
        assert result is not None

    @pytest.mark.xfail(reason="No timeout protection", strict=False)
    def test_elixir_token_chain_100k(self):
        """Elixir with 100,000 tokens in expression chain."""
        count = 100000
        chain = " + ".join(["1"] * count)
        content = f"x = {chain}"
        result = extract_with_timeout(content, ".ex", timeout_seconds=5)
        assert result is not None
