"""Tests for PHP DFG extraction.

TDD tests for PHP language support in TLDR.
PHP uses tree-sitter-php with node types:
- function_definition
- variable_name (for $var)
- assignment_expression
"""
import pytest

# Check if tree-sitter-php is available
try:
    from tldr.dfg_extractor import extract_php_dfg, TREE_SITTER_PHP_AVAILABLE
    PHP_AVAILABLE = TREE_SITTER_PHP_AVAILABLE
except ImportError:
    PHP_AVAILABLE = False


pytestmark = pytest.mark.skipif(not PHP_AVAILABLE, reason="tree-sitter-php not available")


@pytest.fixture
def simple_assignment_code():
    return '''<?php
function calculate(int $a, int $b): int {
    $x = $a;
    $y = $b;
    $result = $x + $y;
    return $result;
}
'''


@pytest.fixture
def reassignment_code():
    return '''<?php
function process(int $n): int {
    $x = $n;
    $x = $x + 1;
    $x = $x * 2;
    return $x;
}
'''


@pytest.fixture
def loop_variable_code():
    return '''<?php
function sum(array $numbers): int {
    $total = 0;
    foreach ($numbers as $number) {
        $total = $total + $number;
    }
    return $total;
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''<?php
function choose(int $x): int {
    $result = 0;
    if ($x > 0) {
        $result = 1;
    } else {
        $result = -1;
    }
    return $result;
}
'''


@pytest.fixture
def reference_code():
    return '''<?php
function swap(&$a, &$b): void {
    $temp = $a;
    $a = $b;
    $b = $temp;
}
'''


@pytest.fixture
def array_code():
    return '''<?php
function arraySum(array $arr): int {
    $total = 0;
    for ($i = 0; $i < count($arr); $i++) {
        $total += $arr[$i];
    }
    return $total;
}
'''


@pytest.fixture
def chained_code():
    return '''<?php
function chainedCompute(int $x): int {
    $a = $x + 1;
    $b = $a * 2;
    $c = $b + 3;
    return $c;
}
'''


@pytest.fixture
def multi_path_code():
    return '''<?php
function multiPath(int $x, int $y): int {
    $sum = $x + $y;
    $product = $x * $y;
    $result = $sum + $product;
    return $result;
}
'''


class TestBasicDFG:
    """Test basic DFG extraction for PHP."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_php_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_php_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of '$x'
        x_refs = [r for r in dfg.var_refs if r.name == "x" or r.name == "$x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_php_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track '$total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total" or r.name == "$total"]
        assert len(total_refs) > 0

    def test_chained_data_flow(self, chained_code):
        dfg = extract_php_dfg(chained_code, "chainedCompute")
        assert dfg is not None
        # Should have data flow edges for the chain x -> a -> b -> c
        assert len(dfg.dataflow_edges) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_php_dfg(simple_assignment_code, "calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_php_dfg(reassignment_code, "process")
        # $x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_php_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # '$result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result" or r.name == "$result"]
        assert len(result_refs) > 0

    def test_multi_path_data_flow(self, multi_path_code):
        dfg = extract_php_dfg(multi_path_code, "multiPath")
        assert dfg is not None
        # Should track $x and $y being used in multiple paths
        assert len(dfg.var_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_php_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_php_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0


class TestReferenceAndArrayDFG:
    """Test reference and array variable tracking."""

    def test_reference_parameter(self, reference_code):
        dfg = extract_php_dfg(reference_code, "swap")
        assert dfg is not None
        # Should track $temp variable
        temp_refs = [r for r in dfg.var_refs if r.name == "temp" or r.name == "$temp"]
        assert len(temp_refs) > 0

    def test_array_access(self, array_code):
        dfg = extract_php_dfg(array_code, "arraySum")
        assert dfg is not None
        # Should track $total variable
        total_refs = [r for r in dfg.var_refs if r.name == "total" or r.name == "$total"]
        assert len(total_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_php_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
