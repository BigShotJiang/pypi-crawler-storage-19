"""Tests for Java DFG extraction."""
import pytest

# Check if tree-sitter-java is available
try:
    from tldr.dfg_extractor import extract_java_dfg, TREE_SITTER_JAVA_AVAILABLE
    JAVA_AVAILABLE = TREE_SITTER_JAVA_AVAILABLE
except ImportError:
    JAVA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")


@pytest.fixture
def simple_assignment_code():
    return '''
public class Example {
    public int calculate(int a, int b) {
        int x = a;
        int y = b;
        int result = x + y;
        return result;
    }
}
'''


@pytest.fixture
def reassignment_code():
    return '''
public class Example {
    public int process(int n) {
        int x = n;
        x = x + 1;
        x = x * 2;
        return x;
    }
}
'''


@pytest.fixture
def loop_variable_code():
    return '''
public class Example {
    public int sum(int n) {
        int total = 0;
        for (int i = 0; i < n; i++) {
            total = total + i;
        }
        return total;
    }
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
public class Example {
    public int choose(int x) {
        int result;
        if (x > 0) {
            result = 1;
        } else {
            result = -1;
        }
        return result;
    }
}
'''


class TestBasicDFG:
    """Test basic DFG extraction for Java."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_java_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_java_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_java_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_java_dfg(simple_assignment_code, "calculate")
        # Should have variable references (edges may be empty due to Java node structure)
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_java_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_java_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_java_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_java_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_java_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
