"""Tests for tldr.durability module - Durability Partitioning (P5).

This module tests the durability classification system that separates
indexes into DURABLE (never changes) and VOLATILE (changes frequently)
partitions for efficient caching.

Benefit: Never re-index durable portions (node_modules, .venv, etc.).
Load durable on startup, volatile on demand.
"""

import json
import tempfile
import pytest
from pathlib import Path

# Import the module under test - will fail until implemented
from tldr.durability import (
    is_durable,
    PartitionedIndex,
    DurablePartition,
    VolatilePartition,
)
from tldr.cross_file_calls import ProjectCallGraph


class TestIsDurable:
    """Tests for is_durable() classification function."""

    def test_is_durable_node_modules(self):
        """node_modules/ paths should be classified as durable."""
        assert is_durable("project/node_modules/lodash/index.js") is True
        assert is_durable("node_modules/react/index.js") is True
        assert is_durable("/abs/path/node_modules/pkg/file.ts") is True

    def test_is_durable_venv(self):
        """.venv/ paths should be classified as durable."""
        assert is_durable("project/.venv/lib/python3.12/site-packages/requests/api.py") is True
        assert is_durable(".venv/bin/python") is True

    def test_is_durable_site_packages(self):
        """site-packages/ paths should be classified as durable."""
        assert is_durable("lib/python3.12/site-packages/numpy/core.py") is True
        assert is_durable("/usr/lib/python3/site-packages/pkg/mod.py") is True

    def test_is_durable_vendor(self):
        """vendor/ paths should be classified as durable."""
        assert is_durable("project/vendor/github.com/pkg/errors/errors.go") is True
        assert is_durable("vendor/some_dep/lib.rs") is True

    def test_is_durable_pycache(self):
        """__pycache__/ paths should be classified as durable."""
        assert is_durable("src/__pycache__/module.cpython-312.pyc") is True
        assert is_durable("__pycache__/test.pyc") is True

    def test_is_volatile_src(self):
        """src/ files (user code) should be classified as volatile."""
        assert is_durable("src/main.py") is False
        assert is_durable("src/utils/helpers.ts") is False
        assert is_durable("app/controllers/user.go") is False

    def test_is_volatile_lib_not_site_packages(self):
        """lib/ without site-packages should be volatile."""
        assert is_durable("lib/my_module.py") is False
        assert is_durable("project/lib/utils.py") is False

    def test_is_volatile_tests(self):
        """tests/ should be classified as volatile."""
        assert is_durable("tests/test_main.py") is False
        assert is_durable("test/unit/test_utils.py") is False

    def test_is_durable_with_mixed_case(self):
        """Durability check should be case-sensitive (Unix-style)."""
        # node_modules is lowercase by convention
        assert is_durable("Node_Modules/pkg/file.js") is False
        # .venv is lowercase by convention
        assert is_durable(".VENV/lib/pkg.py") is False


class TestDurablePartition:
    """Tests for DurablePartition class."""

    def test_durable_partition_creation(self):
        """DurablePartition should be creatable with optional package key."""
        partition = DurablePartition(package_key="lodash@4.17.21")
        assert partition.package_key == "lodash@4.17.21"

    def test_durable_partition_add_edge(self):
        """DurablePartition should store edges."""
        partition = DurablePartition(package_key="numpy@1.24.0")
        partition.add_edge("numpy/core.py", "array", "numpy/lib.py", "helper")

        edges = list(partition.edges)
        assert len(edges) == 1
        assert ("numpy/core.py", "array", "numpy/lib.py", "helper") in edges

    def test_durable_partition_get_edges_for_file(self):
        """DurablePartition should return edges for a specific file."""
        partition = DurablePartition(package_key="lodash@4.17.21")
        partition.add_edge("lodash/array.js", "chunk", "lodash/utils.js", "_baseSlice")
        partition.add_edge("lodash/object.js", "keys", "lodash/internal.js", "_keys")

        array_edges = partition.get_edges_for_file("lodash/array.js")
        assert len(array_edges) == 1
        assert array_edges[0] == ("lodash/array.js", "chunk", "lodash/utils.js", "_baseSlice")

    def test_durable_partition_empty(self):
        """DurablePartition with no edges should return empty list."""
        partition = DurablePartition(package_key="empty@0.0.0")
        assert list(partition.edges) == []
        assert partition.get_edges_for_file("any/file.py") == []


class TestVolatilePartition:
    """Tests for VolatilePartition class."""

    def test_volatile_partition_wraps_project_call_graph(self):
        """VolatilePartition should wrap a ProjectCallGraph."""
        graph = ProjectCallGraph()
        graph.add_edge("main.py", "main", "utils.py", "helper")

        partition = VolatilePartition(graph=graph)

        edges = list(partition.edges)
        assert ("main.py", "main", "utils.py", "helper") in edges

    def test_volatile_partition_add_edge(self):
        """VolatilePartition should add edges to underlying graph."""
        graph = ProjectCallGraph()
        partition = VolatilePartition(graph=graph)

        partition.add_edge("a.py", "foo", "b.py", "bar")

        assert ("a.py", "foo", "b.py", "bar") in graph.edges

    def test_volatile_partition_remove_edges_for_file(self):
        """VolatilePartition should support removing edges from a file."""
        graph = ProjectCallGraph()
        graph.add_edge("edited.py", "func1", "other.py", "helper")
        graph.add_edge("edited.py", "func2", "other.py", "helper")
        graph.add_edge("other.py", "caller", "edited.py", "func1")

        partition = VolatilePartition(graph=graph)
        partition.remove_edges_from_file("edited.py")

        edges = list(partition.edges)
        # Edges FROM edited.py should be gone
        assert not any(e[0] == "edited.py" for e in edges)
        # Edges TO edited.py from other files should remain
        assert ("other.py", "caller", "edited.py", "func1") in edges


class TestPartitionedIndex:
    """Tests for PartitionedIndex class."""

    def test_partitioned_index_creation(self):
        """PartitionedIndex should be creatable with durable and volatile partitions."""
        index = PartitionedIndex()
        assert index.durable == {}
        assert index.volatile is not None

    def test_partitioned_index_add_durable(self):
        """Adding to a durable path should go to durable partition."""
        index = PartitionedIndex()

        index.add_edge(
            "node_modules/lodash/chunk.js", "chunk",
            "node_modules/lodash/utils.js", "_baseSlice"
        )

        # Should be in durable partition, not volatile
        volatile_edges = list(index.volatile.edges)
        assert not any("lodash" in str(e) for e in volatile_edges)

        # Should be in some durable partition
        all_durable_edges = index.get_all_durable_edges()
        assert len(all_durable_edges) >= 1

    def test_partitioned_index_add_volatile(self):
        """Adding to a volatile path should go to volatile partition."""
        index = PartitionedIndex()

        index.add_edge("src/main.py", "main", "src/utils.py", "helper")

        # Should be in volatile partition
        volatile_edges = list(index.volatile.edges)
        assert ("src/main.py", "main", "src/utils.py", "helper") in volatile_edges

    def test_partitioned_index_query_merged(self):
        """Querying should merge results from both partitions."""
        index = PartitionedIndex()

        # Add durable edge
        index.add_edge(
            "node_modules/lodash/chunk.js", "chunk",
            "node_modules/lodash/utils.js", "_baseSlice"
        )

        # Add volatile edge
        index.add_edge("src/main.py", "main", "src/utils.py", "helper")

        # Get all edges (merged)
        all_edges = index.get_all_edges()

        assert len(all_edges) >= 2
        # Should contain both durable and volatile
        assert any("lodash" in str(e) for e in all_edges)
        assert any("main.py" in str(e) for e in all_edges)

    def test_partitioned_index_get_edges_for_file_durable(self):
        """get_edges_for_file should return durable edges for durable files."""
        index = PartitionedIndex()

        index.add_edge(
            "node_modules/pkg/a.js", "funcA",
            "node_modules/pkg/b.js", "funcB"
        )

        edges = index.get_edges_for_file("node_modules/pkg/a.js")
        assert len(edges) == 1

    def test_partitioned_index_get_edges_for_file_volatile(self):
        """get_edges_for_file should return volatile edges for volatile files."""
        index = PartitionedIndex()

        index.add_edge("src/main.py", "main", "src/utils.py", "helper")

        edges = index.get_edges_for_file("src/main.py")
        assert len(edges) == 1
        assert edges[0] == ("src/main.py", "main", "src/utils.py", "helper")


class TestDurableNeverReindexed:
    """Tests ensuring durable files are never re-indexed."""

    def test_durable_skipped_on_reindex(self):
        """Durable files should be skipped when reindexing."""
        index = PartitionedIndex()

        # Add initial durable content
        index.add_edge(
            "node_modules/pkg/a.js", "funcA",
            "node_modules/pkg/b.js", "funcB"
        )

        # Mark node_modules file as "dirty" - it should be ignored
        dirty_files = ["node_modules/pkg/a.js", "src/main.py"]
        files_to_reindex = index.filter_reindexable(dirty_files)

        # Only volatile files should be reindexed
        assert "node_modules/pkg/a.js" not in files_to_reindex
        assert "src/main.py" in files_to_reindex

    def test_volatile_reindexed_on_change(self):
        """Volatile files should be reindexed when changed."""
        index = PartitionedIndex()

        # Add initial volatile content
        index.add_edge("src/main.py", "main", "src/utils.py", "helper")

        # Mark as dirty
        dirty_files = ["src/main.py"]
        files_to_reindex = index.filter_reindexable(dirty_files)

        assert "src/main.py" in files_to_reindex


class TestDurablePersistence:
    """Tests for durable partition persistence."""

    def test_persistence_durable_separate(self, tmp_path):
        """Durable partitions should be stored separately from volatile."""
        index = PartitionedIndex()

        # Add durable edge
        index.add_edge(
            "node_modules/lodash/chunk.js", "chunk",
            "node_modules/lodash/utils.js", "_baseSlice"
        )

        # Add volatile edge
        index.add_edge("src/main.py", "main", "src/utils.py", "helper")

        # Save partitions
        durable_path = tmp_path / "durable"
        volatile_path = tmp_path / "volatile.json"

        index.save_durable(str(durable_path))
        index.save_volatile(str(volatile_path))

        # Verify separate storage
        assert durable_path.exists()
        assert volatile_path.exists()

        # Load back and verify
        loaded_index = PartitionedIndex()
        loaded_index.load_durable(str(durable_path))
        loaded_index.load_volatile(str(volatile_path))

        all_edges = loaded_index.get_all_edges()
        assert len(all_edges) >= 2

    def test_save_load_durable_roundtrip(self, tmp_path):
        """Durable partition should survive save/load cycle."""
        index = PartitionedIndex()

        index.add_edge(
            "node_modules/react/index.js", "createElement",
            "node_modules/react/element.js", "ReactElement"
        )

        durable_path = tmp_path / "durable"
        index.save_durable(str(durable_path))

        new_index = PartitionedIndex()
        new_index.load_durable(str(durable_path))

        edges = new_index.get_all_durable_edges()
        assert any("createElement" in str(e) for e in edges)


class TestStartupLoading:
    """Tests for fast startup with durable-only loading."""

    def test_startup_loads_durable_only(self, tmp_path):
        """On startup, only durable should be loaded (volatile is on-demand)."""
        # Create and save an index with both partitions
        original = PartitionedIndex()
        original.add_edge(
            "node_modules/pkg/a.js", "funcA",
            "node_modules/pkg/b.js", "funcB"
        )
        original.add_edge("src/main.py", "main", "src/utils.py", "helper")

        durable_path = tmp_path / "durable"
        volatile_path = tmp_path / "volatile.json"
        original.save_durable(str(durable_path))
        original.save_volatile(str(volatile_path))

        # Simulate startup - load only durable
        startup_index = PartitionedIndex()
        startup_index.load_durable(str(durable_path))
        # Note: volatile NOT loaded

        # Durable edges should be available
        durable_edges = startup_index.get_all_durable_edges()
        assert len(durable_edges) >= 1

        # Volatile should be empty (not loaded)
        volatile_edges = list(startup_index.volatile.edges)
        assert len(volatile_edges) == 0

    def test_load_volatile_on_demand(self, tmp_path):
        """Volatile partition can be loaded on demand after startup."""
        original = PartitionedIndex()
        original.add_edge("src/main.py", "main", "src/utils.py", "helper")

        volatile_path = tmp_path / "volatile.json"
        original.save_volatile(str(volatile_path))

        # Startup with empty volatile
        index = PartitionedIndex()
        assert len(list(index.volatile.edges)) == 0

        # Load on demand
        index.load_volatile(str(volatile_path))

        volatile_edges = list(index.volatile.edges)
        assert len(volatile_edges) == 1


class TestPackageExtraction:
    """Tests for extracting package keys from durable paths."""

    def test_extract_package_node_modules(self):
        """Should extract package name from node_modules paths."""
        index = PartitionedIndex()

        key = index._extract_package("node_modules/lodash/chunk.js")
        assert key == "lodash"

        # Scoped packages
        key = index._extract_package("node_modules/@types/react/index.d.ts")
        assert key == "@types/react"

    def test_extract_package_site_packages(self):
        """Should extract package name from site-packages paths."""
        index = PartitionedIndex()

        key = index._extract_package("lib/python3.12/site-packages/numpy/core.py")
        assert key == "numpy"

    def test_extract_package_venv(self):
        """Should extract package name from .venv paths."""
        index = PartitionedIndex()

        key = index._extract_package(".venv/lib/python3.12/site-packages/requests/api.py")
        assert key == "requests"

    def test_extract_package_vendor_go(self):
        """Should extract package path from Go vendor paths."""
        index = PartitionedIndex()

        key = index._extract_package("vendor/github.com/pkg/errors/errors.go")
        assert key == "github.com/pkg/errors"
