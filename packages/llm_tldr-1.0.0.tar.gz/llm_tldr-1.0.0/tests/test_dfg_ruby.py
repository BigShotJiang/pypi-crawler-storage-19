"""Tests for Ruby DFG extraction.

TDD tests for Ruby language support in TLDR DFG extraction.
These tests should FAIL initially until Ruby support is implemented.

Ruby variable reference patterns (tree-sitter-ruby):
- assignment: identifier = expression
- identifier: variable usage
- method parameters: defined in method signature
- block parameters: |param| in blocks
"""
import pytest

# Check if tree-sitter-ruby is available
try:
    from tldr.dfg_extractor import extract_ruby_dfg, TREE_SITTER_RUBY_AVAILABLE
    RUBY_AVAILABLE = TREE_SITTER_RUBY_AVAILABLE
except ImportError:
    RUBY_AVAILABLE = False


pytestmark = pytest.mark.skipif(not RUBY_AVAILABLE, reason="tree-sitter-ruby not available")


@pytest.fixture
def simple_assignment_code():
    return '''
class Example
  def calculate(a, b)
    x = a
    y = b
    result = x + y
    result
  end
end
'''


@pytest.fixture
def reassignment_code():
    return '''
class Example
  def process(n)
    x = n
    x = x + 1
    x = x * 2
    x
  end
end
'''


@pytest.fixture
def loop_variable_code():
    return '''
class Example
  def sum(numbers)
    total = 0
    numbers.each do |n|
      total = total + n
    end
    total
  end
end
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
class Example
  def choose(x)
    if x > 0
      result = 1
    else
      result = -1
    end
    result
  end
end
'''


@pytest.fixture
def chained_deps_code():
    return '''
class Example
  def compute(x)
    a = x + 1
    b = a * 2
    c = b + 3
    c
  end
end
'''


@pytest.fixture
def multi_path_code():
    return '''
class Example
  def multi_path(x, y)
    sum = x + y
    product = x * y
    result = sum + product
    result
  end
end
'''


@pytest.fixture
def block_variable_code():
    return '''
class Example
  def transform(items)
    results = []
    items.each do |item|
      transformed = item * 2
      results << transformed
    end
    results
  end
end
'''


class TestBasicDFG:
    """Test basic DFG extraction for Ruby."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_ruby_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_ruby_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_ruby_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_chained_dependencies(self, chained_deps_code):
        dfg = extract_ruby_dfg(chained_deps_code, "compute")
        assert dfg is not None
        # Should track the chain x -> a -> b -> c
        a_refs = [r for r in dfg.var_refs if r.name == "a"]
        b_refs = [r for r in dfg.var_refs if r.name == "b"]
        c_refs = [r for r in dfg.var_refs if r.name == "c"]
        assert len(a_refs) > 0
        assert len(b_refs) > 0
        assert len(c_refs) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_ruby_dfg(simple_assignment_code, "calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_ruby_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_ruby_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0

    def test_multi_path_def_use(self, multi_path_code):
        dfg = extract_ruby_dfg(multi_path_code, "multi_path")
        assert dfg is not None
        # x and y are used in two different paths
        assert len(dfg.var_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_ruby_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_ruby_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0

    def test_block_parameter_detected(self, block_variable_code):
        dfg = extract_ruby_dfg(block_variable_code, "transform")
        assert dfg is not None
        # Block parameter 'item' should be tracked
        item_refs = [r for r in dfg.var_refs if r.name == "item"]
        assert len(item_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_ruby_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
