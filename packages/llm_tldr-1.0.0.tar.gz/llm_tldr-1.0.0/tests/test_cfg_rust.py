"""Tests for Rust CFG extraction."""
import pytest

# Check if tree-sitter-rust is available
try:
    from tldr.cfg_extractor import extract_rust_cfg, TREE_SITTER_RUST_AVAILABLE, TREE_SITTER_AVAILABLE
    RUST_AVAILABLE = TREE_SITTER_RUST_AVAILABLE and TREE_SITTER_AVAILABLE
except ImportError:
    RUST_AVAILABLE = False


pytestmark = pytest.mark.skipif(not RUST_AVAILABLE, reason="tree-sitter-rust not available")


@pytest.fixture
def simple_if_code():
    return '''
fn check(x: i32) -> &'static str {
    if x > 0 {
        return "positive";
    }
    "non-positive"
}
'''


@pytest.fixture
def while_loop_code():
    return '''
fn count(n: i32) -> i32 {
    let mut i = 0;
    while i < n {
        i += 1;
    }
    i
}
'''


@pytest.fixture
def for_loop_code():
    return '''
fn sum(items: &[i32]) -> i32 {
    let mut total = 0;
    for item in items {
        total += item;
    }
    total
}
'''


@pytest.fixture
def nested_code():
    return '''
fn process(items: &[Item]) {
    for item in items {
        if item.valid {
            handle(item);
        } else {
            skip(item);
        }
    }
}
'''


@pytest.fixture
def break_continue_code():
    return '''
fn find_first(items: &[i32], target: i32) -> Option<usize> {
    for (i, item) in items.iter().enumerate() {
        if *item == target {
            return Some(i);
        }
        if *item < 0 {
            continue;
        }
        process(item);
    }
    None
}
'''


@pytest.fixture
def loop_code():
    return '''
fn infinite_until(target: i32) -> i32 {
    let mut i = 0;
    loop {
        i += 1;
        if i >= target {
            break;
        }
    }
    i
}
'''


class TestRustCFG:
    """Test Rust CFG extraction."""

    def test_simple_function_has_entry_and_exit(self, simple_if_code):
        cfg = extract_rust_cfg(simple_if_code, "check")
        assert cfg.entry_block_id is not None
        assert len(cfg.exit_block_ids) >= 1

    def test_if_creates_branch(self, simple_if_code):
        cfg = extract_rust_cfg(simple_if_code, "check")
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 2

    def test_while_creates_back_edge(self, while_loop_code):
        cfg = extract_rust_cfg(while_loop_code, "count")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_while_has_loop_header(self, while_loop_code):
        cfg = extract_rust_cfg(while_loop_code, "count")
        headers = [b for b in cfg.blocks if b.block_type == "loop_header"]
        assert len(headers) >= 1

    def test_for_loop_creates_back_edge(self, for_loop_code):
        cfg = extract_rust_cfg(for_loop_code, "sum")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_cyclomatic_complexity_simple_if(self, simple_if_code):
        cfg = extract_rust_cfg(simple_if_code, "check")
        assert cfg.cyclomatic_complexity == 2

    def test_cyclomatic_complexity_while(self, while_loop_code):
        cfg = extract_rust_cfg(while_loop_code, "count")
        assert cfg.cyclomatic_complexity == 2

    def test_nested_complexity(self, nested_code):
        cfg = extract_rust_cfg(nested_code, "process")
        # for + if + 1 = 3
        assert cfg.cyclomatic_complexity == 3

    def test_cfg_to_dict(self, simple_if_code):
        cfg = extract_rust_cfg(simple_if_code, "check")
        d = cfg.to_dict()
        assert "blocks" in d
        assert "edges" in d
        assert "cyclomatic_complexity" in d
        assert d["function"] == "check"

    def test_continue_creates_edge(self, break_continue_code):
        cfg = extract_rust_cfg(break_continue_code, "find_first")
        continue_edges = [e for e in cfg.edges if e.edge_type == "continue"]
        assert len(continue_edges) >= 1

    def test_function_not_found_raises(self):
        code = "fn foo() {}"
        with pytest.raises(ValueError, match="not found"):
            extract_rust_cfg(code, "bar")


class TestRustCFGEdgeCases:
    """Edge cases for Rust CFG."""

    def test_if_else_if(self):
        code = '''
fn grade(score: i32) -> &'static str {
    if score >= 90 {
        "A"
    } else if score >= 80 {
        "B"
    } else {
        "F"
    }
}
'''
        cfg = extract_rust_cfg(code, "grade")
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 4

    def test_nested_loops(self):
        code = '''
fn matrix(rows: i32, cols: i32) {
    for i in 0..rows {
        for j in 0..cols {
            process(i, j);
        }
    }
}
'''
        cfg = extract_rust_cfg(code, "matrix")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 2

    def test_match_not_handled_yet(self):
        # Match expressions are complex - just verify we don't crash
        code = '''
fn classify(x: i32) -> &'static str {
    match x {
        n if n < 0 => "negative",
        0 => "zero",
        _ => "positive",
    }
}
'''
        cfg = extract_rust_cfg(code, "classify")
        assert cfg.entry_block_id is not None

    def test_loop_expression(self, loop_code):
        # Rust's `loop` is an infinite loop - should still create CFG
        cfg = extract_rust_cfg(loop_code, "infinite_until")
        assert cfg.entry_block_id is not None
        # Should have at least a break edge somewhere
        break_edges = [e for e in cfg.edges if e.edge_type == "break"]
        assert len(break_edges) >= 1
