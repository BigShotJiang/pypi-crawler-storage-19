"""Tests for Scala PDG extraction and program slicing (L5).

TDD Tests for Scala PDG support.

Tests mirror the structure of test_pdg_java.py but for Scala language support.
Scala CFG (L3) and DFG (L4) will be implemented first - these tests expect them.
"""
import os
import pytest

# Check if tree-sitter-scala is available
try:
    from tldr.cfg_extractor import TREE_SITTER_SCALA_AVAILABLE
    SCALA_AVAILABLE = TREE_SITTER_SCALA_AVAILABLE
except ImportError:
    SCALA_AVAILABLE = False

# Check if extract_scala_pdg is implemented
try:
    from tldr.pdg_extractor import extract_scala_pdg
    SCALA_PDG_AVAILABLE = True
except ImportError:
    SCALA_PDG_AVAILABLE = False
    extract_scala_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not SCALA_AVAILABLE,
    reason="tree-sitter-scala not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_scala_path():
    """Path to sample.scala fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.scala")


@pytest.fixture
def sample_scala_code(sample_scala_path):
    """Load sample.scala fixture code."""
    with open(sample_scala_path) as f:
        return f.read()


@pytest.fixture
def simple_scala_code():
    """Simple Scala code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
// =============================================================================
// Simple Scala test fixture for PDG extraction
// This code is used to test basic PDG node and edge extraction.
// The add function has simple data flow: a -> c, b -> c, c -> return
// =============================================================================
object Example {
  def add(a: Int, b: Int): Int = {
    val c = a + b
    c
  }
}
'''


@pytest.fixture
def chained_scala_code():
    """Scala code with chained dependencies for slice testing."""
    return '''
// =============================================================================
// Chained computation test fixture for Scala PDG extraction
// This code tests forward and backward slicing with clear data flow.
// x -> a -> b -> c -> return
// =============================================================================
object ChainedCompute {
  def compute(x: Int): Int = {
    val a = x + 1     // line ~10: a depends on x
    val b = a * 2     // line ~11: b depends on a
    val c = b + 3     // line ~12: c depends on b
    c                  // line ~13: return depends on c
  }
}
'''


# =============================================================================
# Tests for extract_scala_pdg()
# =============================================================================

class TestExtractScalaPDG:
    """Test extract_scala_pdg() function."""

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_extract_scala_pdg_basic(self, sample_scala_code):
        """Test basic PDG extraction from sample.scala calculate function."""
        pdg = extract_scala_pdg(sample_scala_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_extract_scala_pdg_has_nodes(self, sample_scala_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_scala_pdg(sample_scala_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_extract_scala_pdg_has_edges(self, sample_scala_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_scala_pdg(sample_scala_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        # Note: PDGEdge uses dep_type attribute (control/data)
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_extract_scala_pdg_sum_function(self, sample_scala_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_scala_pdg(sample_scala_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_extract_scala_pdg_nonexistent_function(self, sample_scala_code):
        """Test that nonexistent function returns None."""
        pdg = extract_scala_pdg(sample_scala_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for Scala Program Slicing
# =============================================================================

class TestScalaProgramSlicing:
    """Test program slicing for Scala code."""

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_scala_backward_slice(self, sample_scala_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_scala_pdg(sample_scala_code, "sum")

        assert pdg is not None
        # Line 37 is "total" return in sample.scala sum function
        slice_lines = pdg.backward_slice(line=37)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_scala_forward_slice(self, chained_scala_code):
        """Test forward slice from first assignment."""
        pdg = extract_scala_pdg(chained_scala_code, "compute")

        assert pdg is not None
        # Forward slice from "val a = x + 1;"
        slice_lines = pdg.forward_slice(line=10)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_scala_slice_returns_set(self, simple_scala_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_scala_pdg(simple_scala_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=11)  # c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for Scala PDG via API
# =============================================================================

class TestScalaPDGAPI:
    """Test Scala PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_scala_get_pdg_context(self, sample_scala_path):
        """Test get_pdg_context() for Scala code via file path."""
        result = get_pdg_context(sample_scala_path, "calculate", language="scala")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_scala_get_slice_backward(self, sample_scala_path):
        """Test get_slice() backward for Scala code via file path."""
        # Backward slice from return statement in sum function (line 37 is "total")
        lines = get_slice(
            sample_scala_path, "sum", line=37,
            direction="backward", language="scala"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_scala_get_slice_forward(self, sample_scala_path):
        """Test get_slice() forward for Scala code via file path."""
        # Forward slice from "val a = x + 1" in compute function (line 57)
        lines = get_slice(
            sample_scala_path, "compute", line=57,
            direction="forward", language="scala"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestScalaPDGIntegration:
    """Integration tests for Scala PDG."""

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_pdg_from_file(self, sample_scala_path, sample_scala_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_scala_pdg(sample_scala_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not SCALA_PDG_AVAILABLE, reason="extract_scala_pdg not implemented")
    def test_pdg_to_dict(self, simple_scala_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_scala_pdg(simple_scala_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
