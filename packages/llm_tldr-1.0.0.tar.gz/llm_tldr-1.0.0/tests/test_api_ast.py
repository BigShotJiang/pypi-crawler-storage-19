#!/usr/bin/env python3
"""
Tests for Layer 1 (AST) functions in the TLDR API.

TDD Phase 1: These tests define expected behavior for:
- get_imports() - Extract import statements from a file
- get_intra_file_calls() - Extract call graph within a file
- extract_file() - Generic file extractor exposed at API level
"""

import pytest
import tempfile
from pathlib import Path


class TestGetImports:
    """Tests for get_imports() API function."""

    def test_get_imports_simple_import(self, tmp_path):
        """Test extraction of simple import statements."""
        from tldr.api import get_imports

        # Create test file
        test_file = tmp_path / "test_simple.py"
        test_file.write_text("""
import os
import sys
import json
""")
        imports = get_imports(str(test_file))

        assert isinstance(imports, list)
        assert len(imports) == 3

        # Check structure
        modules = [i["module"] for i in imports]
        assert "os" in modules
        assert "sys" in modules
        assert "json" in modules

    def test_get_imports_from_import(self, tmp_path):
        """Test extraction of from ... import statements."""
        from tldr.api import get_imports

        test_file = tmp_path / "test_from.py"
        test_file.write_text("""
from pathlib import Path
from typing import Optional, List
from collections import defaultdict
""")
        imports = get_imports(str(test_file))

        assert len(imports) == 3

        # Check from import structure
        pathlib_import = next(i for i in imports if i["module"] == "pathlib")
        assert pathlib_import["is_from"] is True
        assert "Path" in pathlib_import["names"]

        typing_import = next(i for i in imports if i["module"] == "typing")
        assert "Optional" in typing_import["names"]
        assert "List" in typing_import["names"]

    def test_get_imports_returns_dict_with_expected_keys(self, tmp_path):
        """Test that import dicts have all expected keys."""
        from tldr.api import get_imports

        test_file = tmp_path / "test_keys.py"
        test_file.write_text("import os")

        imports = get_imports(str(test_file))
        assert len(imports) == 1

        imp = imports[0]
        assert "module" in imp
        assert "names" in imp
        assert "is_from" in imp
        # Note: line_number may or may not be present depending on backend

    def test_get_imports_empty_file(self, tmp_path):
        """Test extraction from file with no imports."""
        from tldr.api import get_imports

        test_file = tmp_path / "test_empty.py"
        test_file.write_text("x = 1")

        imports = get_imports(str(test_file))
        assert imports == []

    def test_get_imports_nonexistent_file(self):
        """Test behavior for nonexistent file - returns empty list."""
        from tldr.api import get_imports

        # The cross_file_calls parse_imports returns [] for nonexistent files
        # rather than raising, which is consistent with its "best effort" design
        result = get_imports("/nonexistent/file.py")
        assert result == []


class TestGetIntraFileCalls:
    """Tests for get_intra_file_calls() API function."""

    def test_get_intra_file_calls_simple(self, tmp_path):
        """Test extraction of simple call relationships."""
        from tldr.api import get_intra_file_calls

        test_file = tmp_path / "test_calls.py"
        test_file.write_text("""
def helper():
    return 42

def main():
    result = helper()
    return result
""")
        call_graph = get_intra_file_calls(str(test_file))

        assert isinstance(call_graph, dict)
        assert "calls" in call_graph
        assert "called_by" in call_graph

        # main calls helper
        assert "main" in call_graph["calls"]
        assert "helper" in call_graph["calls"]["main"]

        # helper is called by main
        assert "helper" in call_graph["called_by"]
        assert "main" in call_graph["called_by"]["helper"]

    def test_get_intra_file_calls_chain(self, tmp_path):
        """Test extraction of call chain: a -> b -> c."""
        from tldr.api import get_intra_file_calls

        test_file = tmp_path / "test_chain.py"
        test_file.write_text("""
def step_c():
    return "done"

def step_b():
    return step_c()

def step_a():
    return step_b()
""")
        call_graph = get_intra_file_calls(str(test_file))

        assert "step_a" in call_graph["calls"]
        assert "step_b" in call_graph["calls"]["step_a"]

        assert "step_b" in call_graph["calls"]
        assert "step_c" in call_graph["calls"]["step_b"]

    def test_get_intra_file_calls_no_calls(self, tmp_path):
        """Test file with functions that don't call each other."""
        from tldr.api import get_intra_file_calls

        test_file = tmp_path / "test_nocalls.py"
        test_file.write_text("""
def func_a():
    return 1

def func_b():
    return 2
""")
        call_graph = get_intra_file_calls(str(test_file))

        # Should return empty or minimal call graph
        assert call_graph["calls"] == {} or all(
            len(v) == 0 for v in call_graph["calls"].values()
        )

    def test_get_intra_file_calls_nonexistent_file(self):
        """Test error handling for nonexistent file."""
        from tldr.api import get_intra_file_calls

        with pytest.raises((FileNotFoundError, ValueError)):
            get_intra_file_calls("/nonexistent/file.py")


class TestExtractFile:
    """Tests for extract_file() API function."""

    def test_extract_file_returns_module_info(self, tmp_path):
        """Test that extract_file returns proper module info."""
        from tldr.api import extract_file

        test_file = tmp_path / "test_module.py"
        test_file.write_text('''
"""Module docstring."""

import os

def my_function(x: int) -> str:
    """Function docstring."""
    return str(x)

class MyClass:
    """Class docstring."""

    def method(self):
        pass
''')
        result = extract_file(str(test_file))

        # Should return dict with expected keys
        assert isinstance(result, dict)
        assert "file_path" in result
        assert "language" in result
        assert "imports" in result
        assert "functions" in result
        assert "classes" in result
        assert "call_graph" in result

    def test_extract_file_captures_docstring(self, tmp_path):
        """Test that module docstring is captured."""
        from tldr.api import extract_file

        test_file = tmp_path / "test_doc.py"
        test_file.write_text('"""This is the module docstring."""\n\nx = 1')

        result = extract_file(str(test_file))
        assert result["docstring"] == "This is the module docstring."

    def test_extract_file_captures_functions(self, tmp_path):
        """Test that functions are captured with signatures."""
        from tldr.api import extract_file

        test_file = tmp_path / "test_funcs.py"
        test_file.write_text("""
def add(a: int, b: int) -> int:
    return a + b

async def fetch(url: str) -> str:
    return ""
""")
        result = extract_file(str(test_file))

        assert len(result["functions"]) == 2

        # Find add function
        add_func = next(f for f in result["functions"] if f["name"] == "add")
        assert add_func["return_type"] == "int"
        assert "a: int" in add_func["params"] or "a" in add_func["params"]

        # Find async function
        fetch_func = next(f for f in result["functions"] if f["name"] == "fetch")
        assert fetch_func["is_async"] is True

    def test_extract_file_captures_classes(self, tmp_path):
        """Test that classes and methods are captured."""
        from tldr.api import extract_file

        test_file = tmp_path / "test_classes.py"
        test_file.write_text("""
class MyClass:
    def method_a(self):
        pass

    def method_b(self, x: int) -> int:
        return x
""")
        result = extract_file(str(test_file))

        assert len(result["classes"]) == 1
        cls = result["classes"][0]
        assert cls["name"] == "MyClass"
        assert len(cls["methods"]) == 2

    def test_extract_file_unknown_extension_uses_fallback(self, tmp_path):
        """Test that unknown file types use Pygments fallback."""
        from tldr.api import extract_file

        test_file = tmp_path / "test.xyz"
        test_file.write_text("def foo(): pass\ndef bar(): pass")

        # Should not raise - uses Pygments fallback
        result = extract_file(str(test_file))
        assert "file_path" in result
        assert "functions" in result

    def test_extract_file_nonexistent(self):
        """Test error handling for nonexistent file."""
        from tldr.api import extract_file

        with pytest.raises((FileNotFoundError, ValueError)):
            extract_file("/nonexistent/file.py")


class TestImportInfoExport:
    """Tests that ImportInfo is importable from api module."""

    def test_import_info_available(self):
        """Test ImportInfo class is exported from api."""
        from tldr.api import ImportInfo

        # Should be a dataclass
        info = ImportInfo(module="os", names=[], is_from=False, line_number=1)
        assert info.module == "os"
        assert info.statement() == "import os"

    def test_import_info_from_statement(self):
        """Test ImportInfo with from import."""
        from tldr.api import ImportInfo

        info = ImportInfo(
            module="typing",
            names=["Optional", "List"],
            is_from=True,
            line_number=1
        )
        assert "from typing import" in info.statement()
        assert "Optional" in info.statement()


class TestCallGraphInfoExport:
    """Tests that CallGraphInfo is importable from api module."""

    def test_call_graph_info_available(self):
        """Test CallGraphInfo class is exported from api."""
        from tldr.api import CallGraphInfo

        cg = CallGraphInfo()
        cg.add_call("main", "helper")

        assert "main" in cg.calls
        assert "helper" in cg.calls["main"]
        assert "helper" in cg.called_by
        assert "main" in cg.called_by["helper"]
