"""Tests for Python CFG extraction."""
import pytest
from tldr.cfg_extractor import CFGBlock, CFGEdge, CFGInfo, extract_python_cfg


@pytest.fixture
def simple_if_code():
    return '''
def check(x):
    if x > 0:
        return "positive"
    return "non-positive"
'''


@pytest.fixture
def while_loop_code():
    return '''
def count(n):
    i = 0
    while i < n:
        i += 1
    return i
'''


@pytest.fixture
def nested_code():
    return '''
def process(items):
    for item in items:
        if item.valid:
            handle(item)
        else:
            skip(item)
    return done()
'''


@pytest.fixture
def break_continue_code():
    return '''
def find_first(items, target):
    for item in items:
        if item == target:
            break
        if item is None:
            continue
        process(item)
    return None
'''


@pytest.fixture
def multiple_returns_code():
    return '''
def validate(x):
    if x < 0:
        return "negative"
    if x == 0:
        return "zero"
    if x > 100:
        return "too large"
    return "valid"
'''


class TestCFGDataclasses:
    """Test the dataclass definitions."""

    def test_cfg_block_creation(self):
        block = CFGBlock(id=0, start_line=1, end_line=5, block_type="entry")
        assert block.id == 0
        assert block.start_line == 1
        assert block.end_line == 5
        assert block.block_type == "entry"

    def test_cfg_edge_creation(self):
        edge = CFGEdge(source_id=0, target_id=1, edge_type="true", condition="x > 0")
        assert edge.source_id == 0
        assert edge.target_id == 1
        assert edge.edge_type == "true"
        assert edge.condition == "x > 0"

    def test_cfg_block_to_dict(self):
        block = CFGBlock(id=0, start_line=1, end_line=5, block_type="entry")
        d = block.to_dict()
        assert d["id"] == 0
        assert d["type"] == "entry"
        assert d["lines"] == [1, 5]

    def test_cfg_edge_to_dict(self):
        edge = CFGEdge(source_id=0, target_id=1, edge_type="true", condition="x > 0")
        d = edge.to_dict()
        assert d["from"] == 0
        assert d["to"] == 1
        assert d["type"] == "true"
        assert d["condition"] == "x > 0"

    def test_cfg_edge_to_dict_no_condition(self):
        edge = CFGEdge(source_id=0, target_id=1, edge_type="unconditional")
        d = edge.to_dict()
        assert "condition" not in d


class TestPythonCFG:
    """Test Python CFG extraction."""

    def test_simple_function_has_entry_and_exit(self, simple_if_code):
        cfg = extract_python_cfg(simple_if_code, "check")
        assert cfg.entry_block_id is not None
        assert len(cfg.exit_block_ids) >= 1

    def test_if_creates_branch(self, simple_if_code):
        cfg = extract_python_cfg(simple_if_code, "check")
        # Should have branch block with true/false edges
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 2

    def test_while_creates_back_edge(self, while_loop_code):
        cfg = extract_python_cfg(while_loop_code, "count")
        # Should have back edge for loop
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_while_has_loop_header(self, while_loop_code):
        cfg = extract_python_cfg(while_loop_code, "count")
        # Should have loop_header block
        headers = [b for b in cfg.blocks if b.block_type == "loop_header"]
        assert len(headers) >= 1

    def test_cyclomatic_complexity_simple_if(self, simple_if_code):
        cfg = extract_python_cfg(simple_if_code, "check")
        # if + 1 = complexity 2
        assert cfg.cyclomatic_complexity == 2

    def test_cyclomatic_complexity_while(self, while_loop_code):
        cfg = extract_python_cfg(while_loop_code, "count")
        # while + 1 = complexity 2
        assert cfg.cyclomatic_complexity == 2

    def test_nested_complexity(self, nested_code):
        cfg = extract_python_cfg(nested_code, "process")
        # for + if + 1 = complexity 3
        assert cfg.cyclomatic_complexity == 3

    def test_cfg_to_dict(self, simple_if_code):
        cfg = extract_python_cfg(simple_if_code, "check")
        d = cfg.to_dict()
        assert "blocks" in d
        assert "edges" in d
        assert "cyclomatic_complexity" in d
        assert "function" in d
        assert d["function"] == "check"

    def test_for_loop_creates_back_edge(self, nested_code):
        cfg = extract_python_cfg(nested_code, "process")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_for_loop_has_iterate_edge(self, nested_code):
        cfg = extract_python_cfg(nested_code, "process")
        iterate_edges = [e for e in cfg.edges if e.edge_type == "iterate"]
        assert len(iterate_edges) >= 1

    def test_break_creates_edge_to_after_loop(self, break_continue_code):
        cfg = extract_python_cfg(break_continue_code, "find_first")
        break_edges = [e for e in cfg.edges if e.edge_type == "break"]
        assert len(break_edges) >= 1

    def test_continue_creates_edge_to_guard(self, break_continue_code):
        cfg = extract_python_cfg(break_continue_code, "find_first")
        continue_edges = [e for e in cfg.edges if e.edge_type == "continue"]
        assert len(continue_edges) >= 1

    def test_multiple_returns_multiple_exits(self, multiple_returns_code):
        cfg = extract_python_cfg(multiple_returns_code, "validate")
        # 4 return statements = 4 exit blocks
        assert len(cfg.exit_block_ids) >= 4

    def test_multiple_if_complexity(self, multiple_returns_code):
        cfg = extract_python_cfg(multiple_returns_code, "validate")
        # 3 if statements + 1 = complexity 4
        assert cfg.cyclomatic_complexity == 4

    def test_function_not_found_raises(self):
        with pytest.raises(ValueError, match="not found"):
            extract_python_cfg("def foo(): pass", "bar")

    def test_condition_in_edge(self, simple_if_code):
        cfg = extract_python_cfg(simple_if_code, "check")
        true_edges = [e for e in cfg.edges if e.edge_type == "true"]
        assert len(true_edges) >= 1
        # Should have condition text
        assert true_edges[0].condition is not None
        assert "x" in true_edges[0].condition


class TestPythonCFGEdgeCases:
    """Edge cases for Python CFG."""

    def test_empty_function(self):
        code = "def empty(): pass"
        cfg = extract_python_cfg(code, "empty")
        assert cfg.entry_block_id is not None
        assert len(cfg.exit_block_ids) >= 1
        assert cfg.cyclomatic_complexity == 1

    def test_nested_loops(self):
        code = '''
def matrix(rows, cols):
    for i in range(rows):
        for j in range(cols):
            process(i, j)
'''
        cfg = extract_python_cfg(code, "matrix")
        # 2 for loops = 2 back edges
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 2
        # complexity = 2 loops + 1 = 3
        assert cfg.cyclomatic_complexity == 3

    def test_if_elif_else(self):
        code = '''
def grade(score):
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    else:
        return "F"
'''
        cfg = extract_python_cfg(code, "grade")
        # Multiple branch points
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 6  # 3 conditions = 6 edges

    def test_while_else(self):
        code = '''
def search(items, target):
    i = 0
    while i < len(items):
        if items[i] == target:
            return i
        i += 1
    return -1
'''
        cfg = extract_python_cfg(code, "search")
        # while + if = complexity 3
        assert cfg.cyclomatic_complexity == 3
