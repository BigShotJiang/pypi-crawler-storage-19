"""Tests for Lua DFG extraction.

TDD tests for Lua language support in TLDR DFG extraction.
These tests should FAIL initially until Lua support is implemented.

Lua variable reference patterns (tree-sitter-lua):
- variable_declaration: local x = value
- assignment_statement: x = value (existing variable)
- identifier: variable usage
- function parameters: defined in function signature
- for loop variables: loop iteration variables
"""
import pytest

# Check if tree-sitter-lua is available
try:
    from tldr.dfg_extractor import extract_lua_dfg, TREE_SITTER_LUA_AVAILABLE
    LUA_AVAILABLE = TREE_SITTER_LUA_AVAILABLE
except ImportError:
    LUA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not LUA_AVAILABLE, reason="tree-sitter-lua not available")


@pytest.fixture
def simple_assignment_code():
    return '''
function calculate(a, b)
    local x = a
    local y = b
    local result = x + y
    return result
end
'''


@pytest.fixture
def reassignment_code():
    return '''
function process(n)
    local x = n
    x = x + 1
    x = x * 2
    return x
end
'''


@pytest.fixture
def loop_variable_code():
    return '''
function sum(numbers)
    local total = 0
    for i, n in ipairs(numbers) do
        total = total + n
    end
    return total
end
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
function choose(x)
    local result
    if x > 0 then
        result = 1
    else
        result = -1
    end
    return result
end
'''


@pytest.fixture
def chained_deps_code():
    return '''
function compute(x)
    local a = x + 1
    local b = a * 2
    local c = b + 3
    return c
end
'''


@pytest.fixture
def multi_path_code():
    return '''
function multi_path(x, y)
    local sum = x + y
    local product = x * y
    local result = sum + product
    return result
end
'''


@pytest.fixture
def numeric_for_variable_code():
    return '''
function count_evens(start_val, end_val)
    local count = 0
    for i = start_val, end_val do
        if i % 2 == 0 then
            count = count + 1
        end
    end
    return count
end
'''


@pytest.fixture
def table_field_code():
    return '''
function update_table(tbl)
    local value = tbl.field
    tbl.result = value * 2
    return tbl.result
end
'''


@pytest.fixture
def multiple_return_code():
    return '''
function swap(a, b)
    local temp = a
    a = b
    b = temp
    return a, b
end
'''


class TestBasicDFG:
    """Test basic DFG extraction for Lua."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_lua_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_lua_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_lua_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_chained_dependencies(self, chained_deps_code):
        dfg = extract_lua_dfg(chained_deps_code, "compute")
        assert dfg is not None
        # Should track the chain x -> a -> b -> c
        a_refs = [r for r in dfg.var_refs if r.name == "a"]
        b_refs = [r for r in dfg.var_refs if r.name == "b"]
        c_refs = [r for r in dfg.var_refs if r.name == "c"]
        assert len(a_refs) > 0
        assert len(b_refs) > 0
        assert len(c_refs) > 0

    def test_numeric_for_loop_variable(self, numeric_for_variable_code):
        dfg = extract_lua_dfg(numeric_for_variable_code, "count_evens")
        assert dfg is not None
        # Should track loop variable 'i' and 'count'
        i_refs = [r for r in dfg.var_refs if r.name == "i"]
        count_refs = [r for r in dfg.var_refs if r.name == "count"]
        assert len(i_refs) > 0
        assert len(count_refs) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_lua_dfg(simple_assignment_code, "calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_lua_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_lua_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0

    def test_multi_path_def_use(self, multi_path_code):
        dfg = extract_lua_dfg(multi_path_code, "multi_path")
        assert dfg is not None
        # x and y are used in two different paths
        assert len(dfg.var_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_lua_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_lua_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0

    def test_for_loop_variable_detected(self, loop_variable_code):
        dfg = extract_lua_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Loop variable 'n' should be tracked
        n_refs = [r for r in dfg.var_refs if r.name == "n"]
        assert len(n_refs) > 0

    def test_parameter_detected(self, simple_assignment_code):
        dfg = extract_lua_dfg(simple_assignment_code, "calculate")
        # Parameters 'a' and 'b' should be tracked
        a_refs = [r for r in dfg.var_refs if r.name == "a"]
        b_refs = [r for r in dfg.var_refs if r.name == "b"]
        assert len(a_refs) > 0
        assert len(b_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_lua_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0

    def test_empty_code(self):
        dfg = extract_lua_dfg("", "any_function")
        assert dfg is not None
        assert len(dfg.var_refs) == 0
