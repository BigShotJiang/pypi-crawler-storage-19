"""Tests for tldr.incremental_parse module - Tree-sitter Incremental Parsing (P5).

This module tests the tree-sitter incremental parsing system that provides
10-100x speedup by only re-parsing changed portions of files.
"""

import json
import tempfile
import pickle
import pytest
from pathlib import Path
from dataclasses import dataclass

# Import the module under test - will fail until implemented
from tldr.incremental_parse import (
    EditRange,
    TreeCache,
    IncrementalParser,
    calculate_edit_range,
    parse_incremental,
)


class TestEditRange:
    """Tests for EditRange dataclass."""

    def test_edit_range_creation(self):
        """EditRange should store byte offsets for edits."""
        edit = EditRange(
            start_byte=100,
            old_end_byte=150,
            new_end_byte=160,
            start_point=(5, 0),
            old_end_point=(7, 10),
            new_end_point=(8, 5),
        )

        assert edit.start_byte == 100
        assert edit.old_end_byte == 150
        assert edit.new_end_byte == 160
        assert edit.start_point == (5, 0)
        assert edit.old_end_point == (7, 10)
        assert edit.new_end_point == (8, 5)

    def test_edit_range_from_insert(self):
        """EditRange for pure insertion should have old_end_byte == start_byte."""
        # Inserting "hello" at position 10
        edit = EditRange(
            start_byte=10,
            old_end_byte=10,  # No bytes removed
            new_end_byte=15,  # 5 bytes added
            start_point=(0, 10),
            old_end_point=(0, 10),
            new_end_point=(0, 15),
        )

        assert edit.old_end_byte == edit.start_byte
        assert edit.new_end_byte > edit.start_byte

    def test_edit_range_from_delete(self):
        """EditRange for pure deletion should have new_end_byte == start_byte."""
        # Deleting 5 bytes at position 10
        edit = EditRange(
            start_byte=10,
            old_end_byte=15,  # 5 bytes removed
            new_end_byte=10,  # Nothing added
            start_point=(0, 10),
            old_end_point=(0, 15),
            new_end_point=(0, 10),
        )

        assert edit.new_end_byte == edit.start_byte
        assert edit.old_end_byte > edit.start_byte


class TestCalculateEditRange:
    """Tests for calculate_edit_range() function."""

    def test_calculate_edit_range_single_char_insert(self):
        """calculate_edit_range() should detect single character insertion."""
        old_content = b"function foo() { return 1; }"
        new_content = b"function foo() { return 42; }"

        edit = calculate_edit_range(old_content, new_content)

        # The '4' was inserted before the '2' (previously '1')
        assert edit is not None
        assert edit.new_end_byte > edit.old_end_byte  # Insertion

    def test_calculate_edit_range_single_char_delete(self):
        """calculate_edit_range() should detect single character deletion."""
        old_content = b"function foo() { return 42; }"
        new_content = b"function foo() { return 4; }"

        edit = calculate_edit_range(old_content, new_content)

        assert edit is not None
        assert edit.old_end_byte > edit.new_end_byte  # Deletion

    def test_calculate_edit_range_line_insert(self):
        """calculate_edit_range() should detect line insertion."""
        old_content = b"function foo() {\n  return 1;\n}"
        new_content = b"function foo() {\n  console.log('debug');\n  return 1;\n}"

        edit = calculate_edit_range(old_content, new_content)

        assert edit is not None
        # New line was added
        assert edit.new_end_byte > edit.old_end_byte

    def test_calculate_edit_range_line_delete(self):
        """calculate_edit_range() should detect line deletion."""
        old_content = b"function foo() {\n  console.log('debug');\n  return 1;\n}"
        new_content = b"function foo() {\n  return 1;\n}"

        edit = calculate_edit_range(old_content, new_content)

        assert edit is not None
        assert edit.old_end_byte > edit.new_end_byte

    def test_calculate_edit_range_replacement(self):
        """calculate_edit_range() should detect replacement."""
        old_content = b"const x = 'hello';"
        new_content = b"const x = 'world';"

        edit = calculate_edit_range(old_content, new_content)

        assert edit is not None
        # Replacement of same length
        assert edit.start_byte < edit.old_end_byte
        assert edit.start_byte < edit.new_end_byte

    def test_calculate_edit_range_no_change(self):
        """calculate_edit_range() should return None for identical content."""
        content = b"function foo() { return 1; }"

        edit = calculate_edit_range(content, content)

        assert edit is None

    def test_calculate_edit_range_multiline_points(self):
        """calculate_edit_range() should calculate correct row/column points."""
        old_content = b"line1\nline2\nline3"
        new_content = b"line1\nmodified_line2\nline3"

        edit = calculate_edit_range(old_content, new_content)

        assert edit is not None
        # Edit starts on line 1 (0-indexed)
        assert edit.start_point[0] == 1  # Row 1


class TestTreeCache:
    """Tests for TreeCache class."""

    def test_tree_cache_store_and_retrieve(self, tmp_path):
        """TreeCache should store and retrieve trees by file path."""
        cache = TreeCache(cache_dir=tmp_path)

        # Create a mock tree (we'll use the actual parser)
        from tree_sitter import Parser, Language
        import tree_sitter_typescript

        parser = Parser()
        parser.language = Language(tree_sitter_typescript.language_typescript())
        source = b"function foo() { return 1; }"
        tree = parser.parse(source)

        # Store
        cache.store("/path/to/file.ts", tree, source)

        # Retrieve
        cached_tree, cached_source = cache.get("/path/to/file.ts")

        assert cached_tree is not None
        assert cached_source == source

    def test_tree_cache_miss(self, tmp_path):
        """TreeCache should return None for cache miss."""
        cache = TreeCache(cache_dir=tmp_path)

        result = cache.get("/nonexistent/file.ts")

        assert result is None

    def test_tree_cache_invalidate(self, tmp_path):
        """TreeCache should support invalidation."""
        cache = TreeCache(cache_dir=tmp_path)

        from tree_sitter import Parser, Language
        import tree_sitter_typescript

        parser = Parser()
        parser.language = Language(tree_sitter_typescript.language_typescript())
        source = b"function foo() { return 1; }"
        tree = parser.parse(source)

        cache.store("/path/to/file.ts", tree, source)
        cache.invalidate("/path/to/file.ts")

        result = cache.get("/path/to/file.ts")
        assert result is None

    def test_tree_cache_persistence(self, tmp_path):
        """TreeCache should persist to disk and reload."""
        cache_dir = tmp_path / "cache"

        # Create and populate cache
        cache1 = TreeCache(cache_dir=cache_dir)

        from tree_sitter import Parser, Language
        import tree_sitter_typescript

        parser = Parser()
        parser.language = Language(tree_sitter_typescript.language_typescript())
        source = b"function foo() { return 1; }"
        tree = parser.parse(source)

        cache1.store("/path/to/file.ts", tree, source)

        # Create new cache instance (simulating restart)
        cache2 = TreeCache(cache_dir=cache_dir)

        # Should be able to retrieve (at least source + metadata)
        result = cache2.get("/path/to/file.ts")
        # Note: Tree objects aren't directly serializable, so we store source
        # and re-parse on load, but the cache hit should be detected
        assert result is not None

    def test_tree_cache_clear_all(self, tmp_path):
        """TreeCache.clear() should remove all cached trees."""
        cache = TreeCache(cache_dir=tmp_path)

        from tree_sitter import Parser, Language
        import tree_sitter_typescript

        parser = Parser()
        parser.language = Language(tree_sitter_typescript.language_typescript())

        # Store multiple
        for i in range(3):
            source = f"function foo{i}() {{ return {i}; }}".encode()
            tree = parser.parse(source)
            cache.store(f"/path/to/file{i}.ts", tree, source)

        cache.clear()

        for i in range(3):
            assert cache.get(f"/path/to/file{i}.ts") is None


class TestIncrementalParser:
    """Tests for IncrementalParser class."""

    def test_incremental_parser_first_parse(self, tmp_path):
        """IncrementalParser should parse file on first access."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("function foo() { return 1; }")

        tree = parser.parse(str(test_file), language="typescript")

        assert tree is not None
        assert tree.root_node is not None

    def test_incremental_parser_cache_hit(self, tmp_path):
        """IncrementalParser should return cached tree for unchanged file."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("function foo() { return 1; }")

        # Parse twice
        tree1 = parser.parse(str(test_file), language="typescript")
        tree2 = parser.parse(str(test_file), language="typescript")

        # Should be same tree (from cache)
        assert tree1.root_node.start_byte == tree2.root_node.start_byte
        assert tree1.root_node.end_byte == tree2.root_node.end_byte

    def test_incremental_parser_single_edit(self, tmp_path):
        """IncrementalParser should use incremental parsing for small edits."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("function foo() { return 1; }")

        # First parse
        tree1 = parser.parse(str(test_file), language="typescript")
        assert tree1.root_node.child_count > 0

        # Edit file (small change)
        test_file.write_text("function foo() { return 42; }")

        # Second parse (should use incremental)
        tree2 = parser.parse(str(test_file), language="typescript")

        assert tree2 is not None
        # Tree should be valid and reflect new content
        source = test_file.read_bytes()
        # The return statement should now have "42"
        assert b"42" in source

    def test_incremental_parser_multiple_edits(self, tmp_path):
        """IncrementalParser should handle multiple sequential edits."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("function foo() { return 1; }")

        # Parse initial
        parser.parse(str(test_file), language="typescript")

        # Multiple edits
        for i in range(2, 5):
            test_file.write_text(f"function foo() {{ return {i}; }}")
            tree = parser.parse(str(test_file), language="typescript")
            assert tree is not None

    def test_incremental_parser_insert_function(self, tmp_path):
        """IncrementalParser should handle inserting a new function."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("function foo() { return 1; }")

        parser.parse(str(test_file), language="typescript")

        # Add a new function
        test_file.write_text("""function foo() { return 1; }

function bar() { return 2; }
""")

        tree = parser.parse(str(test_file), language="typescript")

        assert tree is not None
        # Should have two function declarations
        func_count = sum(
            1 for child in tree.root_node.children
            if child.type == "function_declaration"
        )
        assert func_count == 2

    def test_incremental_parser_delete_function(self, tmp_path):
        """IncrementalParser should handle deleting a function."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("""function foo() { return 1; }

function bar() { return 2; }
""")

        parser.parse(str(test_file), language="typescript")

        # Remove one function
        test_file.write_text("function foo() { return 1; }")

        tree = parser.parse(str(test_file), language="typescript")

        assert tree is not None
        func_count = sum(
            1 for child in tree.root_node.children
            if child.type == "function_declaration"
        )
        assert func_count == 1

    def test_incremental_parser_python(self, tmp_path):
        """IncrementalParser should work with Python files."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.py"
        test_file.write_text("def foo():\n    return 1\n")

        tree = parser.parse(str(test_file), language="python")

        assert tree is not None
        assert tree.root_node is not None

    def test_incremental_parser_go(self, tmp_path):
        """IncrementalParser should work with Go files."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.go"
        test_file.write_text("package main\n\nfunc foo() int { return 1 }\n")

        tree = parser.parse(str(test_file), language="go")

        assert tree is not None
        assert tree.root_node is not None

    def test_incremental_parser_rust(self, tmp_path):
        """IncrementalParser should work with Rust files."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.rs"
        test_file.write_text("fn foo() -> i32 { 1 }\n")

        tree = parser.parse(str(test_file), language="rust")

        assert tree is not None
        assert tree.root_node is not None


class TestParseIncremental:
    """Tests for parse_incremental() convenience function."""

    def test_parse_incremental_basic(self, tmp_path):
        """parse_incremental() should parse a file."""
        test_file = tmp_path / "test.ts"
        test_file.write_text("const x = 1;")

        tree = parse_incremental(str(test_file), language="typescript")

        assert tree is not None

    def test_parse_incremental_with_old_tree(self, tmp_path):
        """parse_incremental() should accept old_tree for incremental parsing."""
        from tree_sitter import Parser, Language
        import tree_sitter_typescript

        test_file = tmp_path / "test.ts"
        old_content = b"const x = 1;"
        new_content = b"const x = 42;"

        test_file.write_bytes(old_content)

        # Get initial tree
        parser = Parser()
        parser.language = Language(tree_sitter_typescript.language_typescript())
        old_tree = parser.parse(old_content)

        # Update file
        test_file.write_bytes(new_content)

        # Calculate edit
        edit = calculate_edit_range(old_content, new_content)

        # Parse incrementally
        new_tree = parse_incremental(
            str(test_file),
            language="typescript",
            old_tree=old_tree,
            edit_range=edit,
        )

        assert new_tree is not None


class TestIncrementalParserStats:
    """Tests for incremental parser statistics/metrics."""

    def test_parser_tracks_cache_hits(self, tmp_path):
        """IncrementalParser should track cache hit/miss statistics."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("const x = 1;")

        # First parse - cache miss
        parser.parse(str(test_file), language="typescript")

        # Second parse - cache hit (unchanged)
        parser.parse(str(test_file), language="typescript")

        stats = parser.get_stats()
        assert stats["cache_hits"] >= 1
        assert stats["cache_misses"] >= 1

    def test_parser_tracks_incremental_parses(self, tmp_path):
        """IncrementalParser should track incremental vs full parses."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.ts"
        test_file.write_text("const x = 1;")

        # First parse - full
        parser.parse(str(test_file), language="typescript")

        # Edit and reparse - incremental
        test_file.write_text("const x = 2;")
        parser.parse(str(test_file), language="typescript")

        stats = parser.get_stats()
        assert stats["full_parses"] >= 1
        assert stats["incremental_parses"] >= 1


class TestEdgeCases:
    """Tests for edge cases and error handling."""

    def test_parse_empty_file(self, tmp_path):
        """IncrementalParser should handle empty files."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "empty.ts"
        test_file.write_text("")

        tree = parser.parse(str(test_file), language="typescript")

        assert tree is not None

    def test_parse_syntax_error(self, tmp_path):
        """IncrementalParser should handle files with syntax errors."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "broken.ts"
        test_file.write_text("function { this is not valid")

        # Should not raise, tree-sitter produces partial trees
        tree = parser.parse(str(test_file), language="typescript")

        assert tree is not None

    def test_parse_large_file(self, tmp_path):
        """IncrementalParser should handle large files."""
        parser = IncrementalParser(cache_dir=tmp_path)

        # Generate a large file
        lines = [f"function func{i}() {{ return {i}; }}" for i in range(1000)]
        test_file = tmp_path / "large.ts"
        test_file.write_text("\n".join(lines))

        tree = parser.parse(str(test_file), language="typescript")

        assert tree is not None

    def test_parse_unicode_content(self, tmp_path):
        """IncrementalParser should handle unicode content."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "unicode.ts"
        test_file.write_text('const greeting = "Hello, World!";\n')

        tree = parser.parse(str(test_file), language="typescript")

        assert tree is not None

    def test_missing_file(self, tmp_path):
        """IncrementalParser should handle missing files gracefully."""
        parser = IncrementalParser(cache_dir=tmp_path)

        with pytest.raises(FileNotFoundError):
            parser.parse(str(tmp_path / "nonexistent.ts"), language="typescript")

    def test_unsupported_language(self, tmp_path):
        """IncrementalParser should raise for unsupported languages."""
        parser = IncrementalParser(cache_dir=tmp_path)

        test_file = tmp_path / "test.xyz"
        test_file.write_text("some content")

        with pytest.raises(ValueError, match="Unsupported language"):
            parser.parse(str(test_file), language="xyz")
