"""
Tests for PDG (Program Dependence Graph) extraction.

Tests:
1. Basic PDG construction from CFG + DFG
2. Control edge labeling
3. Data edge labeling
4. Program slicing (backward and forward)
5. Multi-language support
6. Edge cases
"""

import pytest

from tldr.pdg_extractor import (
    extract_python_pdg,
    extract_pdg,
    PDGInfo,
    PDGNode,
    PDGEdge,
)


# =============================================================================
# Basic PDG Construction Tests
# =============================================================================

class TestBasicPDG:
    """Test basic PDG construction."""

    def test_simple_function_pdg(self):
        """Test PDG for a simple function with no branches."""
        code = '''
def add(a, b):
    c = a + b
    return c
'''
        pdg = extract_python_pdg(code, "add")
        assert pdg is not None
        assert pdg.function_name == "add"

        # Should have nodes
        assert len(pdg.nodes) > 0

        # Should have both CFG and DFG accessible
        assert pdg.cfg is not None
        assert pdg.dfg is not None

    def test_pdg_has_control_edges(self):
        """Test that PDG has control dependency edges."""
        code = '''
def check(x):
    if x > 0:
        return True
    return False
'''
        pdg = extract_python_pdg(code, "check")
        assert pdg is not None

        control_edges = [e for e in pdg.edges if e.dep_type == "control"]
        assert len(control_edges) > 0

    def test_pdg_has_data_edges(self):
        """Test that PDG has data dependency edges."""
        code = '''
def compute(x):
    y = x * 2
    z = y + 1
    return z
'''
        pdg = extract_python_pdg(code, "compute")
        assert pdg is not None

        data_edges = [e for e in pdg.edges if e.dep_type == "data"]
        # x -> y (x used in y's definition)
        # y -> z (y used in z's definition)
        assert len(data_edges) >= 1

    def test_pdg_to_dict(self):
        """Test PDG serialization to dict."""
        code = '''
def simple(x):
    return x + 1
'''
        pdg = extract_python_pdg(code, "simple")
        assert pdg is not None

        d = pdg.to_dict()
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert "nodes" in d["pdg"]
        assert "edges" in d["pdg"]

    def test_pdg_to_compact_dict(self):
        """Test PDG compact summary."""
        code = '''
def example(x, y):
    if x > 0:
        z = x + y
    else:
        z = y
    return z
'''
        pdg = extract_python_pdg(code, "example")
        assert pdg is not None

        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert "nodes" in compact
        assert "control_edges" in compact
        assert "data_edges" in compact
        assert "complexity" in compact
        assert "variables" in compact


# =============================================================================
# Control Dependency Tests
# =============================================================================

class TestControlDependencies:
    """Test control dependency edges."""

    def test_branch_control_edges(self):
        """Test control edges for if statements."""
        code = '''
def branch(x):
    if x > 0:
        y = 1
    else:
        y = 2
    return y
'''
        pdg = extract_python_pdg(code, "branch")
        assert pdg is not None

        control_edges = [e for e in pdg.edges if e.dep_type == "control"]

        # Should have true and false edges
        edge_labels = {e.label for e in control_edges}
        assert "true" in edge_labels or "unconditional" in edge_labels

    def test_loop_control_edges(self):
        """Test control edges for loops."""
        code = '''
def loop(items):
    total = 0
    for item in items:
        total += item
    return total
'''
        pdg = extract_python_pdg(code, "loop")
        assert pdg is not None

        control_edges = [e for e in pdg.edges if e.dep_type == "control"]
        edge_labels = {e.label for e in control_edges}

        # Should have iterate or back_edge for loop
        assert len(edge_labels) > 0


# =============================================================================
# Data Dependency Tests
# =============================================================================

class TestDataDependencies:
    """Test data dependency edges."""

    def test_simple_data_flow(self):
        """Test data edges for simple def-use chain."""
        code = '''
def chain(x):
    y = x + 1
    z = y * 2
    return z
'''
        pdg = extract_python_pdg(code, "chain")
        assert pdg is not None

        data_edges = [e for e in pdg.edges if e.dep_type == "data"]

        # Should have edges for x->y and y->z data flow
        var_names = {e.label for e in data_edges}
        # At least one variable should flow
        assert len(var_names) >= 0  # May have no cross-block data edges

    def test_node_definitions_and_uses(self):
        """Test that nodes track their definitions and uses."""
        code = '''
def vars(a, b):
    c = a + b
    d = c * 2
    return d
'''
        pdg = extract_python_pdg(code, "vars")
        assert pdg is not None

        # Find a node that has definitions
        defs_found = False
        uses_found = False
        for node in pdg.nodes:
            if node.definitions:
                defs_found = True
            if node.uses:
                uses_found = True

        # At least some nodes should have defs/uses
        assert defs_found or uses_found


# =============================================================================
# Program Slicing Tests
# =============================================================================

class TestProgramSlicing:
    """Test backward and forward slicing."""

    def test_backward_slice_simple(self):
        """Test backward slice finds dependencies."""
        code = '''
def compute(x):
    a = x + 1
    b = a * 2
    c = b + 3
    return c
'''
        pdg = extract_python_pdg(code, "compute")
        assert pdg is not None

        # Backward slice from return (line 6) should include earlier lines
        slice_lines = pdg.backward_slice(line=6)

        # Should include some lines (the exact lines depend on CFG structure)
        assert len(slice_lines) > 0

    def test_forward_slice_simple(self):
        """Test forward slice finds dependents."""
        code = '''
def propagate(x):
    a = x * 2
    b = a + 1
    c = b - 1
    return c
'''
        pdg = extract_python_pdg(code, "propagate")
        assert pdg is not None

        # Forward slice from first assignment should reach later lines
        slice_lines = pdg.forward_slice(line=3)

        # Should include some lines
        assert len(slice_lines) > 0

    def test_slice_with_variable_filter(self):
        """Test slicing filtered to specific variable."""
        code = '''
def multi(x, y):
    a = x + 1
    b = y + 2
    c = a + b
    return c
'''
        pdg = extract_python_pdg(code, "multi")
        assert pdg is not None

        # Full backward slice from return
        full_slice = pdg.backward_slice(line=6)

        # Variable-specific slice (if implemented)
        # Should be subset or equal to full slice
        var_slice = pdg.backward_slice(line=6, variable="a")
        assert len(var_slice) <= len(full_slice) or len(var_slice) > 0


# =============================================================================
# Get Dependencies Tests
# =============================================================================

class TestGetDependencies:
    """Test getting dependencies for a specific line."""

    def test_get_dependencies(self):
        """Test getting all dependencies for a line."""
        code = '''
def deps(x):
    y = x + 1
    z = y * 2
    return z
'''
        pdg = extract_python_pdg(code, "deps")
        assert pdg is not None

        deps = pdg.get_dependencies(line=4)  # z = y * 2

        assert "control_in" in deps
        assert "control_out" in deps
        assert "data_in" in deps
        assert "data_out" in deps


# =============================================================================
# Multi-language Tests
# =============================================================================

class TestMultiLanguage:
    """Test PDG extraction for multiple languages."""

    def test_python_pdg(self):
        """Test Python PDG extraction."""
        code = '''
def add(a, b):
    return a + b
'''
        pdg = extract_pdg(code, "add", "python")
        assert pdg is not None

    def test_extract_pdg_invalid_language(self):
        """Test error handling for invalid language."""
        with pytest.raises(ValueError):
            extract_pdg("", "func", "invalid_lang")


# =============================================================================
# Edge Cases
# =============================================================================

class TestEdgeCases:
    """Test edge cases and error handling."""

    def test_nonexistent_function(self):
        """Test handling of nonexistent function."""
        code = '''
def exists():
    pass
'''
        pdg = extract_python_pdg(code, "nonexistent")
        assert pdg is None

    def test_empty_function(self):
        """Test handling of empty function."""
        code = '''
def empty():
    pass
'''
        pdg = extract_python_pdg(code, "empty")
        # May return PDG or None depending on implementation
        # Just shouldn't crash
        if pdg is not None:
            assert pdg.function_name == "empty"

    def test_backward_slice_invalid_line(self):
        """Test backward slice with invalid line."""
        code = '''
def simple(x):
    return x
'''
        pdg = extract_python_pdg(code, "simple")
        assert pdg is not None

        # Slice from line that doesn't exist
        slice_lines = pdg.backward_slice(line=100)
        assert len(slice_lines) == 0

    def test_forward_slice_invalid_line(self):
        """Test forward slice with invalid line."""
        code = '''
def simple(x):
    return x
'''
        pdg = extract_python_pdg(code, "simple")
        assert pdg is not None

        # Slice from line that doesn't exist
        slice_lines = pdg.forward_slice(line=100)
        assert len(slice_lines) == 0


# =============================================================================
# PDG Node Tests
# =============================================================================

class TestPDGNode:
    """Test PDGNode data structure."""

    def test_node_to_dict(self):
        """Test PDGNode serialization."""
        node = PDGNode(
            id=1,
            node_type="statement",
            start_line=5,
            end_line=5,
            definitions=["x"],
            uses=["y", "z"],
        )

        d = node.to_dict()
        assert d["id"] == 1
        assert d["type"] == "statement"
        assert d["lines"] == [5, 5]
        assert d["defs"] == ["x"]
        assert d["uses"] == ["y", "z"]

    def test_node_to_dict_minimal(self):
        """Test PDGNode serialization with minimal data."""
        node = PDGNode(
            id=0,
            node_type="entry",
            start_line=1,
            end_line=1,
        )

        d = node.to_dict()
        assert "defs" not in d  # Empty list not included
        assert "uses" not in d


# =============================================================================
# PDG Edge Tests
# =============================================================================

class TestPDGEdge:
    """Test PDGEdge data structure."""

    def test_edge_to_dict(self):
        """Test PDGEdge serialization."""
        edge = PDGEdge(
            source_id=0,
            target_id=1,
            dep_type="control",
            label="true",
        )

        d = edge.to_dict()
        assert d["from"] == 0
        assert d["to"] == 1
        assert d["type"] == "control"
        assert d["label"] == "true"

    def test_edge_full_type(self):
        """Test PDGEdge full_type property."""
        control_edge = PDGEdge(0, 1, "control", "true")
        assert control_edge.full_type == "control:true"

        data_edge = PDGEdge(1, 2, "data", "x")
        assert data_edge.full_type == "data:x"


# =============================================================================
# Integration Tests
# =============================================================================

class TestIntegration:
    """Integration tests with realistic code."""

    def test_realistic_function(self):
        """Test PDG for a realistic function."""
        code = '''
def process_items(items, threshold):
    """Process items above threshold."""
    results = []
    total = 0

    for item in items:
        if item > threshold:
            results.append(item)
            total += item

    if total > 0:
        average = total / len(results)
    else:
        average = 0

    return {"results": results, "average": average}
'''
        pdg = extract_python_pdg(code, "process_items")
        assert pdg is not None

        # Should have decent complexity
        assert pdg.cfg.cyclomatic_complexity >= 2

        # Should have multiple variables
        assert len(pdg.dfg.variables) > 0

        # Should have both edge types
        control_count = sum(1 for e in pdg.edges if e.dep_type == "control")
        data_count = sum(1 for e in pdg.edges if e.dep_type == "data")

        assert control_count > 0
        # Data edges may or may not exist depending on cross-block flow

    def test_nested_function_in_pdg(self):
        """Test that nested functions are handled (via CFG nested_cfgs)."""
        code = '''
def outer(x):
    def inner(y):
        return y * 2
    return inner(x) + 1
'''
        pdg = extract_python_pdg(code, "outer")
        assert pdg is not None

        # CFG should have nested_cfgs
        assert pdg.cfg is not None
        # Note: nested function CFGs are in cfg.nested_cfgs


# =============================================================================
# Separate Layer Access Tests
# =============================================================================

class TestSeparateLayers:
    """Test that CFG and DFG are accessible separately (ARISTODE pattern)."""

    def test_access_cfg_layer(self):
        """Test direct access to CFG layer."""
        code = '''
def example(x):
    if x > 0:
        return x
    return 0
'''
        pdg = extract_python_pdg(code, "example")
        assert pdg is not None

        # Access CFG directly
        cfg = pdg.cfg
        assert cfg.function_name == "example"
        assert len(cfg.blocks) > 0
        assert len(cfg.edges) > 0
        assert cfg.cyclomatic_complexity >= 1

    def test_access_dfg_layer(self):
        """Test direct access to DFG layer."""
        code = '''
def example(x):
    y = x + 1
    return y
'''
        pdg = extract_python_pdg(code, "example")
        assert pdg is not None

        # Access DFG directly
        dfg = pdg.dfg
        assert dfg.function_name == "example"
        assert len(dfg.var_refs) > 0
