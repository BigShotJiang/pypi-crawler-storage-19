"""Tests for DFG integration in tldr.api module."""
import pytest
from tldr.api import get_dfg_context


class TestGetDfgContext:
    """Tests for the get_dfg_context API function."""

    def test_python_dfg_basic(self):
        """Extract DFG for a simple Python function."""
        code = '''
def calculate(x, y):
    z = x + y
    result = z * 2
    return result
'''
        dfg = get_dfg_context(code, "calculate", language="python")

        assert dfg["function"] == "calculate"
        assert "refs" in dfg
        assert "edges" in dfg
        assert "variables" in dfg

        # Should have variable references for x, y, z, result
        var_names = dfg["variables"]
        assert "x" in var_names
        assert "y" in var_names
        assert "z" in var_names
        assert "result" in var_names

    def test_python_dfg_with_conditionals(self):
        """DFG should capture dataflow through conditionals."""
        code = '''
def process(flag, value):
    if flag:
        x = value * 2
    else:
        x = value + 1
    return x
'''
        dfg = get_dfg_context(code, "process", language="python")

        assert dfg["function"] == "process"
        # Should have def-use edges for x
        edges = dfg["edges"]
        x_edges = [e for e in edges if e["var"] == "x"]
        assert len(x_edges) >= 1  # At least one def-use for x

    def test_python_dfg_function_not_found(self):
        """Non-existent function should return empty DFG."""
        code = '''
def existing():
    return 42
'''
        dfg = get_dfg_context(code, "nonexistent", language="python")

        assert dfg["function"] == "nonexistent"
        assert dfg["refs"] == []
        assert dfg["edges"] == []

    def test_typescript_dfg_basic(self):
        """Extract DFG for a TypeScript function."""
        code = '''
function calculate(x: number, y: number): number {
    const z = x + y;
    const result = z * 2;
    return result;
}
'''
        dfg = get_dfg_context(code, "calculate", language="typescript")

        assert dfg["function"] == "calculate"
        assert "variables" in dfg
        assert "refs" in dfg
        assert "edges" in dfg

        # Note: TypeScript extraction requires tree-sitter-typescript
        # If not available, returns empty but valid structure
        # When available, should have variable references for z and result

    def test_go_dfg_basic(self):
        """Extract DFG for a Go function."""
        code = '''
package main

func calculate(x int, y int) int {
    z := x + y
    result := z * 2
    return result
}
'''
        dfg = get_dfg_context(code, "calculate", language="go")

        assert dfg["function"] == "calculate"
        assert "variables" in dfg

    def test_rust_dfg_basic(self):
        """Extract DFG for a Rust function."""
        code = '''
fn calculate(x: i32, y: i32) -> i32 {
    let z = x + y;
    let result = z * 2;
    result
}
'''
        dfg = get_dfg_context(code, "calculate", language="rust")

        assert dfg["function"] == "calculate"
        assert "variables" in dfg

    def test_invalid_language_defaults_to_python(self):
        """Invalid language should default to Python extraction."""
        code = '''
def simple():
    x = 1
    return x
'''
        dfg = get_dfg_context(code, "simple", language="invalid_lang")

        # Should still work using Python parser
        assert dfg["function"] == "simple"
        assert "x" in dfg["variables"]

    def test_default_language_is_python(self):
        """Language parameter should default to Python."""
        code = '''
def default_test():
    a = 1
    b = a + 1
    return b
'''
        dfg = get_dfg_context(code, "default_test")

        assert dfg["function"] == "default_test"
        assert "a" in dfg["variables"]
        assert "b" in dfg["variables"]


class TestDfgEdgeStructure:
    """Test the structure of DFG edges."""

    def test_edge_contains_def_and_use_info(self):
        """Each edge should have def and use information."""
        code = '''
def example():
    x = 10
    y = x + 5
    return y
'''
        dfg = get_dfg_context(code, "example", language="python")

        edges = dfg["edges"]
        assert len(edges) > 0

        # Each edge should have var, def_line, use_line
        for edge in edges:
            assert "var" in edge
            assert "def_line" in edge
            assert "use_line" in edge
            assert "def" in edge
            assert "use" in edge

    def test_edge_def_use_detail(self):
        """Edge def/use should contain name, type, line, column."""
        code = '''
def track():
    value = 100
    doubled = value * 2
    return doubled
'''
        dfg = get_dfg_context(code, "track", language="python")

        edges = dfg["edges"]
        if len(edges) > 0:
            edge = edges[0]
            # Check def structure
            assert "name" in edge["def"]
            assert "type" in edge["def"]
            assert "line" in edge["def"]
            assert "column" in edge["def"]
            # Check use structure
            assert "name" in edge["use"]
            assert "type" in edge["use"]
            assert "line" in edge["use"]
            assert "column" in edge["use"]


class TestDfgRefStructure:
    """Test the structure of variable references."""

    def test_ref_contains_required_fields(self):
        """Each ref should have name, type, line, column."""
        code = '''
def refs_test():
    a = 1
    b = a
    return b
'''
        dfg = get_dfg_context(code, "refs_test", language="python")

        refs = dfg["refs"]
        assert len(refs) > 0

        for ref in refs:
            assert "name" in ref
            assert "type" in ref
            assert "line" in ref
            assert "column" in ref

    def test_ref_types_are_valid(self):
        """Ref types should be 'definition', 'update', or 'use'."""
        code = '''
def types_test():
    x = 1
    x = x + 1
    return x
'''
        dfg = get_dfg_context(code, "types_test", language="python")

        valid_types = {"definition", "update", "use"}
        for ref in dfg["refs"]:
            assert ref["type"] in valid_types, f"Invalid ref type: {ref['type']}"
