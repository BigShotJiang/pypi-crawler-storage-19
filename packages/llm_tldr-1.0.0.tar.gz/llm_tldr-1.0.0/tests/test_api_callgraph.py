"""
Tests for TLDR API Layer 2: Call Graph Functions.

These tests verify that the cross-file call graph functions are properly
exposed through the unified api.py interface.
"""

import tempfile
from pathlib import Path

import pytest


class TestScanProjectFiles:
    """Tests for scan_project_files API function."""

    def test_scan_project_files_exists_in_api(self):
        """API should export scan_project_files function."""
        from tldr.api import scan_project_files
        assert callable(scan_project_files)

    def test_scan_python_files(self, tmp_path: Path):
        """Should find all Python files in project."""
        from tldr.api import scan_project_files

        # Create test structure
        (tmp_path / "main.py").write_text("def main(): pass")
        (tmp_path / "utils").mkdir()
        (tmp_path / "utils" / "helper.py").write_text("def help(): pass")
        (tmp_path / "README.md").write_text("# Project")

        files = scan_project_files(str(tmp_path), language="python")

        assert len(files) == 2
        assert any("main.py" in f for f in files)
        assert any("helper.py" in f for f in files)

    def test_scan_typescript_files(self, tmp_path: Path):
        """Should find TypeScript files when language=typescript."""
        from tldr.api import scan_project_files

        (tmp_path / "index.ts").write_text("export function main() {}")
        (tmp_path / "utils.tsx").write_text("export const App = () => {}")
        (tmp_path / "main.py").write_text("# should be ignored")

        files = scan_project_files(str(tmp_path), language="typescript")

        assert len(files) == 2
        assert any(".ts" in f or ".tsx" in f for f in files)
        assert not any(".py" in f for f in files)

    def test_scan_skips_node_modules(self, tmp_path: Path):
        """Should skip node_modules directory."""
        from tldr.api import scan_project_files
        import tempfile

        # Use a temp dir without 'node_modules' in the path name
        # (scan_project does substring matching, not path component matching)
        with tempfile.TemporaryDirectory(prefix="proj_") as tmp:
            proj = Path(tmp)
            (proj / "src").mkdir()
            (proj / "src" / "main.ts").write_text("export function main() {}")
            (proj / "node_modules").mkdir()
            (proj / "node_modules" / "lib.ts").write_text("// ignored")

            files = scan_project_files(str(proj), language="typescript")

            assert len(files) == 1
            assert not any("node_modules" in f for f in files)

    def test_scan_go_files(self, tmp_path: Path):
        """Should find Go files when language=go."""
        from tldr.api import scan_project_files

        (tmp_path / "main.go").write_text("package main\nfunc main() {}")
        (tmp_path / "utils.go").write_text("package utils")

        files = scan_project_files(str(tmp_path), language="go")

        assert len(files) == 2

    def test_scan_rust_files(self, tmp_path: Path):
        """Should find Rust files when language=rust."""
        from tldr.api import scan_project_files

        (tmp_path / "main.rs").write_text("fn main() {}")
        (tmp_path / "lib.rs").write_text("mod utils;")

        files = scan_project_files(str(tmp_path), language="rust")

        assert len(files) == 2


class TestGetImports:
    """Tests for get_imports API function."""

    def test_get_imports_exists_in_api(self):
        """API should export get_imports function."""
        from tldr.api import get_imports
        assert callable(get_imports)

    def test_get_python_imports(self, tmp_path: Path):
        """Should extract Python import statements."""
        from tldr.api import get_imports

        py_file = tmp_path / "test.py"
        py_file.write_text("""
import os
from pathlib import Path
from typing import Optional, List
import json as j
""")

        imports = get_imports(str(py_file), language="python")

        assert len(imports) >= 3
        # Check for 'os' import
        os_import = next((i for i in imports if i.get("module") == "os"), None)
        assert os_import is not None

        # Check for 'from pathlib import Path'
        pathlib_import = next((i for i in imports if i.get("module") == "pathlib"), None)
        assert pathlib_import is not None
        assert "Path" in pathlib_import.get("names", [])

    def test_get_typescript_imports(self, tmp_path: Path):
        """Should extract TypeScript import statements."""
        from tldr.api import get_imports

        ts_file = tmp_path / "test.ts"
        ts_file.write_text("""
import React from 'react';
import { useState, useEffect } from 'react';
import * as utils from './utils';
""")

        imports = get_imports(str(ts_file), language="typescript")

        # Should find at least one import (may vary based on tree-sitter availability)
        assert isinstance(imports, list)

    def test_get_go_imports(self, tmp_path: Path):
        """Should extract Go import statements."""
        from tldr.api import get_imports

        go_file = tmp_path / "test.go"
        go_file.write_text("""
package main

import (
    "fmt"
    "os"
    json "encoding/json"
)
""")

        imports = get_imports(str(go_file), language="go")

        assert isinstance(imports, list)
        # If tree-sitter-go is available, should find imports
        if imports:
            modules = [i.get("module") for i in imports]
            assert "fmt" in modules or any("fmt" in str(m) for m in modules)

    def test_get_rust_imports(self, tmp_path: Path):
        """Should extract Rust use statements."""
        from tldr.api import get_imports

        rs_file = tmp_path / "test.rs"
        rs_file.write_text("""
use std::io;
use std::collections::{HashMap, HashSet};
use crate::utils::helper;
""")

        imports = get_imports(str(rs_file), language="rust")

        assert isinstance(imports, list)

    def test_get_imports_nonexistent_file(self, tmp_path: Path):
        """Should return empty list for nonexistent file."""
        from tldr.api import get_imports

        imports = get_imports(str(tmp_path / "nonexistent.py"), language="python")

        assert imports == []

    def test_get_imports_syntax_error(self, tmp_path: Path):
        """Should return empty list for file with syntax errors."""
        from tldr.api import get_imports

        bad_file = tmp_path / "bad.py"
        bad_file.write_text("def broken(:\n  pass")

        imports = get_imports(str(bad_file), language="python")

        assert imports == []


class TestBuildFunctionIndex:
    """Tests for build_function_index API function."""

    def test_build_function_index_exists_in_api(self):
        """API should export build_function_index function."""
        from tldr.api import build_function_index
        assert callable(build_function_index)

    def test_build_python_function_index(self, tmp_path: Path):
        """Should index Python functions to their files."""
        from tldr.api import build_function_index

        # Create test module structure
        (tmp_path / "utils.py").write_text("""
def helper():
    pass

def process_data(x):
    return x * 2

class DataProcessor:
    def run(self):
        pass
""")

        (tmp_path / "main.py").write_text("""
def main():
    pass
""")

        index = build_function_index(str(tmp_path), language="python")

        assert isinstance(index, dict)
        assert len(index) > 0

        # Should find helper function
        helper_entries = [k for k in index if "helper" in str(k)]
        assert len(helper_entries) > 0

    def test_index_contains_module_qualified_names(self, tmp_path: Path):
        """Index should contain both simple and qualified function names."""
        from tldr.api import build_function_index

        (tmp_path / "pkg").mkdir()
        (tmp_path / "pkg" / "core.py").write_text("""
def process():
    pass
""")

        index = build_function_index(str(tmp_path), language="python")

        # Should have entries for both qualified and simple names
        keys_str = [str(k) for k in index.keys()]
        assert any("process" in k for k in keys_str)

    def test_build_empty_project_index(self, tmp_path: Path):
        """Should return empty index for project with no source files."""
        from tldr.api import build_function_index

        # Just a README, no source files
        (tmp_path / "README.md").write_text("# Empty project")

        index = build_function_index(str(tmp_path), language="python")

        assert index == {}


class TestExtractDirectory:
    """Tests for extract_directory API function."""

    def test_extract_directory_exists_in_api(self):
        """API should export extract_directory function."""
        from tldr.api import extract_directory
        assert callable(extract_directory)

    def test_extract_directory_basic(self, tmp_path: Path):
        """Should extract code structure from directory."""
        from tldr.api import extract_directory

        (tmp_path / "main.py").write_text("""
def main():
    '''Main entry point.'''
    print("Hello")

class App:
    def run(self):
        pass
""")

        result = extract_directory(str(tmp_path))

        assert "directory" in result
        assert "files" in result
        assert len(result["files"]) >= 1

    def test_extract_directory_with_extensions_filter(self, tmp_path: Path):
        """Should filter by extensions when provided."""
        from tldr.api import extract_directory

        (tmp_path / "main.py").write_text("def main(): pass")
        (tmp_path / "utils.ts").write_text("export function util() {}")

        result = extract_directory(str(tmp_path), extensions={".py"})

        # Should only include Python files
        file_names = [f.get("file", "") for f in result["files"]]
        assert any(".py" in f for f in file_names) or len(result["files"]) == 1

    def test_extract_directory_recursive(self, tmp_path: Path):
        """Should recursively scan subdirectories by default."""
        from tldr.api import extract_directory

        (tmp_path / "main.py").write_text("def main(): pass")
        (tmp_path / "sub").mkdir()
        (tmp_path / "sub" / "helper.py").write_text("def help(): pass")

        result = extract_directory(str(tmp_path), recursive=True)

        # Should find files in subdirectories
        assert len(result["files"]) >= 2

    def test_extract_directory_non_recursive(self, tmp_path: Path):
        """Should not scan subdirs when recursive=False."""
        from tldr.api import extract_directory

        (tmp_path / "main.py").write_text("def main(): pass")
        (tmp_path / "sub").mkdir()
        (tmp_path / "sub" / "helper.py").write_text("def help(): pass")

        result = extract_directory(str(tmp_path), recursive=False)

        # Should only find top-level file
        assert len(result["files"]) == 1


class TestAPIIntegration:
    """Integration tests for call graph API functions."""

    def test_workflow_scan_then_index(self, tmp_path: Path):
        """Complete workflow: scan project, then build index."""
        from tldr.api import scan_project_files, build_function_index

        # Setup project
        (tmp_path / "app.py").write_text("""
def start():
    run()

def run():
    pass
""")

        # Step 1: Scan files
        files = scan_project_files(str(tmp_path), language="python")
        assert len(files) == 1

        # Step 2: Build index
        index = build_function_index(str(tmp_path), language="python")
        assert len(index) > 0

    def test_imports_match_index(self, tmp_path: Path):
        """Imports from one file should match functions in index."""
        from tldr.api import get_imports, build_function_index

        (tmp_path / "utils.py").write_text("""
def helper():
    return 42
""")

        (tmp_path / "main.py").write_text("""
from utils import helper

def main():
    return helper()
""")

        imports = get_imports(str(tmp_path / "main.py"), language="python")
        index = build_function_index(str(tmp_path), language="python")

        # Find 'helper' in imports
        utils_import = next((i for i in imports if i.get("module") == "utils"), None)
        assert utils_import is not None
        assert "helper" in utils_import.get("names", [])

        # 'helper' should be in the index
        helper_in_index = any("helper" in str(k) for k in index.keys())
        assert helper_in_index
