"""Tests for C PDG extraction and program slicing (L5).

TDD Tests for C PDG support.

Tests mirror the structure of test_pdg_java.py but for C language support.
C CFG (L3) and DFG (L4) must be implemented first.
"""
import os
import pytest

# Check if tree-sitter-c is available
try:
    from tldr.cfg_extractor import TREE_SITTER_C_AVAILABLE
    C_AVAILABLE = TREE_SITTER_C_AVAILABLE
except ImportError:
    C_AVAILABLE = False

# Check if extract_c_pdg is implemented
try:
    from tldr.pdg_extractor import extract_c_pdg
    C_PDG_AVAILABLE = True
except ImportError:
    C_PDG_AVAILABLE = False
    extract_c_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not C_AVAILABLE,
    reason="tree-sitter-c not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_c_path():
    """Path to sample.c fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.c")


@pytest.fixture
def sample_c_code(sample_c_path):
    """Load sample.c fixture code."""
    with open(sample_c_path) as f:
        return f.read()


@pytest.fixture
def simple_c_code():
    """Simple C code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
/* =============================================================================
 * Simple C test fixture for PDG extraction
 * This code is used to test basic PDG node and edge extraction.
 * The add function has simple data flow: a -> c, b -> c, c -> return
 * ============================================================================= */
int add(int a, int b) {
    int c = a + b;
    return c;
}
'''


@pytest.fixture
def chained_c_code():
    """C code with chained dependencies for slicing tests."""
    return '''
/* =============================================================================
 * Chained computation for forward/backward slice testing.
 * x -> a -> b -> c -> return creates a clear data flow chain.
 * This fixture tests that slicing correctly traces dependencies.
 * ============================================================================= */
int chained_compute(int x) {
    int a = x + 1;     /* line 8: a depends on x */
    int b = a * 2;     /* line 9: b depends on a */
    int c = b + 3;     /* line 10: c depends on b */
    return c;          /* line 11: return depends on c */
}
'''


# =============================================================================
# Tests for extract_c_pdg()
# =============================================================================

class TestExtractCPDG:
    """Test extract_c_pdg() function."""

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_extract_c_pdg_basic(self, sample_c_code):
        """Test basic PDG extraction from sample.c calculate function."""
        pdg = extract_c_pdg(sample_c_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_extract_c_pdg_has_nodes(self, sample_c_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_c_pdg(sample_c_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_extract_c_pdg_has_edges(self, sample_c_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_c_pdg(sample_c_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        # Note: PDGEdge uses dep_type attribute (control/data)
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_extract_c_pdg_sum_function(self, sample_c_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_c_pdg(sample_c_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_extract_c_pdg_nonexistent_function(self, sample_c_code):
        """Test that nonexistent function returns None."""
        pdg = extract_c_pdg(sample_c_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for C Program Slicing
# =============================================================================

class TestCProgramSlicing:
    """Test program slicing for C code."""

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_c_backward_slice(self, sample_c_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_c_pdg(sample_c_code, "sum")

        assert pdg is not None
        # Line 25 is "return total;" in sample.c
        slice_lines = pdg.backward_slice(line=25)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_c_forward_slice(self, chained_c_code):
        """Test forward slice from first assignment."""
        pdg = extract_c_pdg(chained_c_code, "chained_compute")

        assert pdg is not None
        # Forward slice from "int a = x + 1;" (line 8 in chained_c_code)
        slice_lines = pdg.forward_slice(line=8)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_c_slice_returns_set(self, simple_c_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_c_pdg(simple_c_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=9)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for C PDG via API
# =============================================================================

class TestCPDGAPI:
    """Test C PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_c_get_pdg_context(self, sample_c_path):
        """Test get_pdg_context() for C code via file path."""
        result = get_pdg_context(sample_c_path, "calculate", language="c")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_c_get_slice_backward(self, sample_c_path):
        """Test get_slice() backward for C code via file path."""
        # Backward slice from return statement in sum function
        lines = get_slice(
            sample_c_path, "sum", line=25,
            direction="backward", language="c"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_c_get_slice_forward(self, sample_c_path):
        """Test get_slice() forward for C code via file path."""
        lines = get_slice(
            sample_c_path, "chained_compute", line=80,
            direction="forward", language="c"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestCPDGIntegration:
    """Integration tests for C PDG."""

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_pdg_from_file(self, sample_c_path, sample_c_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_c_pdg(sample_c_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not C_PDG_AVAILABLE, reason="extract_c_pdg not implemented")
    def test_pdg_to_dict(self, simple_c_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_c_pdg(simple_c_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
