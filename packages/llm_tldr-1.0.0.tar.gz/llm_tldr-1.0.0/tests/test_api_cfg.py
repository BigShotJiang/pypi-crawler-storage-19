"""Tests for CFG integration in tldr.api module."""
import pytest
from tldr.api import (
    get_cfg_blocks,
    get_cfg_edges,
    get_cfg_context,
    CFGBlock,
    CFGEdge,
)


class TestGetCfgBlocks:
    """Tests for the get_cfg_blocks API function."""

    def test_python_cfg_blocks_basic(self):
        """Extract CFG blocks for a simple Python function."""
        code = '''
def greet(name):
    message = f"Hello, {name}!"
    return message
'''
        blocks = get_cfg_blocks(code, "greet", language="python")

        assert isinstance(blocks, list)
        assert len(blocks) >= 1

        # Each block should have required keys
        for block in blocks:
            assert "id" in block
            assert "type" in block
            assert "lines" in block

    def test_python_cfg_blocks_with_conditional(self):
        """CFG blocks should capture branches."""
        code = '''
def check_value(x):
    if x > 0:
        return "positive"
    else:
        return "non-positive"
'''
        blocks = get_cfg_blocks(code, "check_value", language="python")

        assert isinstance(blocks, list)
        # Should have multiple blocks for conditional
        assert len(blocks) >= 2

        # Should have entry and at least one branch block
        block_types = [b["type"] for b in blocks]
        assert "entry" in block_types or "branch" in block_types or "return" in block_types

    def test_python_cfg_blocks_with_loop(self):
        """CFG blocks should capture loop structure."""
        code = '''
def count_up(n):
    total = 0
    for i in range(n):
        total += i
    return total
'''
        blocks = get_cfg_blocks(code, "count_up", language="python")

        assert isinstance(blocks, list)
        # Should have multiple blocks including loop header
        assert len(blocks) >= 2

    def test_python_cfg_blocks_function_not_found(self):
        """Non-existent function should return empty list."""
        code = '''
def existing():
    return 42
'''
        blocks = get_cfg_blocks(code, "nonexistent", language="python")

        assert blocks == []

    def test_typescript_cfg_blocks_basic(self):
        """Extract CFG blocks for a TypeScript function."""
        code = '''
function greet(name: string): string {
    const message = `Hello, ${name}!`;
    return message;
}
'''
        blocks = get_cfg_blocks(code, "greet", language="typescript")

        assert isinstance(blocks, list)
        # TypeScript CFG extraction may return empty if tree-sitter unavailable
        # or function matching differs - this is expected behavior


class TestGetCfgEdges:
    """Tests for the get_cfg_edges API function."""

    def test_python_cfg_edges_basic(self):
        """Extract CFG edges for a simple Python function."""
        code = '''
def greet(name):
    message = f"Hello, {name}!"
    return message
'''
        edges = get_cfg_edges(code, "greet", language="python")

        assert isinstance(edges, list)
        # Simple function should have at least one edge (entry -> exit)

    def test_python_cfg_edges_with_conditional(self):
        """CFG edges should capture branch conditions."""
        code = '''
def check_value(x):
    if x > 0:
        return "positive"
    else:
        return "non-positive"
'''
        edges = get_cfg_edges(code, "check_value", language="python")

        assert isinstance(edges, list)
        # Should have edges for true/false branches
        assert len(edges) >= 2

        # Each edge should have required keys
        for edge in edges:
            assert "from" in edge
            assert "to" in edge
            assert "type" in edge

        # Should have true/false edge types for conditional
        edge_types = [e["type"] for e in edges]
        # May have true, false, or unconditional edges
        assert any(t in edge_types for t in ["true", "false", "unconditional"])

    def test_python_cfg_edges_function_not_found(self):
        """Non-existent function should return empty list."""
        code = '''
def existing():
    return 42
'''
        edges = get_cfg_edges(code, "nonexistent", language="python")

        assert edges == []

    def test_typescript_cfg_edges_basic(self):
        """Extract CFG edges for a TypeScript function."""
        code = '''
function greet(name: string): string {
    const message = `Hello, ${name}!`;
    return message;
}
'''
        edges = get_cfg_edges(code, "greet", language="typescript")

        assert isinstance(edges, list)


class TestGetCfgContext:
    """Tests for the get_cfg_context unified API function."""

    def test_python_cfg_context_basic(self):
        """Get full CFG context for a Python function."""
        code = '''
def calculate(x, y):
    result = x + y
    return result
'''
        cfg = get_cfg_context(code, "calculate", language="python")

        assert cfg["function"] == "calculate"
        assert "blocks" in cfg
        assert "edges" in cfg
        assert "cyclomatic_complexity" in cfg
        assert isinstance(cfg["blocks"], list)
        assert isinstance(cfg["edges"], list)

    def test_python_cfg_context_with_nested_function(self):
        """CFG should capture nested functions."""
        code = '''
def outer(x):
    def inner(y):
        return y * 2
    return inner(x) + 1
'''
        cfg = get_cfg_context(code, "outer", language="python")

        assert cfg["function"] == "outer"
        # Nested functions may be in nested_functions dict
        # This depends on implementation

    def test_python_cfg_context_function_not_found(self):
        """Non-existent function should return empty CFG."""
        code = '''
def existing():
    return 42
'''
        cfg = get_cfg_context(code, "nonexistent", language="python")

        assert cfg["function"] == "nonexistent"
        assert cfg["blocks"] == []
        assert cfg["edges"] == []


class TestCFGTypeExports:
    """Tests that CFGBlock and CFGEdge are properly exported."""

    def test_cfgblock_is_dataclass(self):
        """CFGBlock should be a usable dataclass."""
        block = CFGBlock(
            id=0,
            start_line=1,
            end_line=3,
            block_type="entry",
        )
        assert block.id == 0
        assert block.start_line == 1
        assert block.end_line == 3
        assert block.block_type == "entry"

    def test_cfgblock_to_dict(self):
        """CFGBlock should have to_dict method."""
        block = CFGBlock(
            id=1,
            start_line=5,
            end_line=10,
            block_type="branch",
            func_calls=["foo", "bar"],
        )
        d = block.to_dict()
        assert d["id"] == 1
        assert d["type"] == "branch"
        assert d["lines"] == [5, 10]
        assert d["calls"] == ["foo", "bar"]

    def test_cfgedge_is_dataclass(self):
        """CFGEdge should be a usable dataclass."""
        edge = CFGEdge(
            source_id=0,
            target_id=1,
            edge_type="true",
            condition="x > 0",
        )
        assert edge.source_id == 0
        assert edge.target_id == 1
        assert edge.edge_type == "true"
        assert edge.condition == "x > 0"

    def test_cfgedge_to_dict(self):
        """CFGEdge should have to_dict method."""
        edge = CFGEdge(
            source_id=2,
            target_id=3,
            edge_type="false",
            condition="x <= 0",
        )
        d = edge.to_dict()
        assert d["from"] == 2
        assert d["to"] == 3
        assert d["type"] == "false"
        assert d["condition"] == "x <= 0"
