"""Tests for crash protection features in hybrid_extractor.

Tests:
1. File size limits (5MB default, env var override)
2. Parser crash protection (_safe_parse, _try_tree_sitter)
3. Graceful fallback to Pygments on failure
4. Error logging
"""

import os
import tempfile
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from tldr.hybrid_extractor import (
    HybridExtractor,
    FileTooLargeError,
    ParseError,
    MAX_FILE_SIZE,
    DEFAULT_MAX_FILE_SIZE,
)


class TestFileSizeLimits:
    """Tests for file size protection."""

    def test_default_file_size_limit(self):
        """Default limit should be 5MB."""
        assert DEFAULT_MAX_FILE_SIZE == 5_000_000

    def test_file_too_large_error_raised(self):
        """FileTooLargeError raised for files exceeding limit."""
        extractor = HybridExtractor()

        # Create a file that exceeds the limit (we'll mock the size)
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("x = 1\n")
            path = Path(f.name)

        try:
            # Mock os.stat to report a huge file size
            mock_result = MagicMock()
            mock_result.st_size = 10_000_000  # 10MB

            with patch("os.stat", return_value=mock_result):
                with pytest.raises(FileTooLargeError) as exc_info:
                    extractor.extract(path)

                assert exc_info.value.size == 10_000_000
                assert exc_info.value.limit == MAX_FILE_SIZE
                assert "TLDR_MAX_FILE_SIZE" in str(exc_info.value)
        finally:
            path.unlink()

    def test_file_size_limit_env_var_override(self):
        """TLDR_MAX_FILE_SIZE env var should override default.

        Note: This test verifies the env var is read at import time.
        We test this by running a subprocess to avoid polluting the test process.
        """
        import subprocess
        import sys

        # Run Python subprocess that imports with custom env var
        result = subprocess.run(
            [sys.executable, "-c", """
import os
os.environ["TLDR_MAX_FILE_SIZE"] = "12345"
from tldr.hybrid_extractor import MAX_FILE_SIZE
print(MAX_FILE_SIZE)
"""],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0, f"Subprocess failed: {result.stderr}"
        assert result.stdout.strip() == "12345", f"Got {result.stdout.strip()}"

    def test_file_under_limit_succeeds(self):
        """Files under the limit should parse normally."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("def hello():\n    return 'world'\n")
            path = Path(f.name)

        try:
            result = extractor.extract(path)
            assert result is not None
            funcs = [fn.name for fn in result.functions]
            assert "hello" in funcs
        finally:
            path.unlink()

    def test_file_too_large_error_message_format(self):
        """FileTooLargeError message should be informative."""
        error = FileTooLargeError(Path("/test/file.py"), 10_000_000, 5_000_000)
        message = str(error)

        assert "/test/file.py" in message
        assert "10,000,000" in message
        assert "5,000,000" in message
        assert "TLDR_MAX_FILE_SIZE" in message


class TestParseErrorHandling:
    """Tests for parser crash protection."""

    def test_parse_error_creation(self):
        """ParseError should capture file, language, and original error."""
        original = ValueError("test error")
        error = ParseError(Path("/test/file.ts"), "typescript", original)

        assert error.file_path == Path("/test/file.ts")
        assert error.language == "typescript"
        assert error.original_error is original
        assert "typescript" in str(error)
        assert "test error" in str(error)

    def test_safe_parse_catches_exceptions(self):
        """_safe_parse should catch parser exceptions and raise ParseError."""
        extractor = HybridExtractor()

        # Create a mock parser that raises an exception
        mock_parser = MagicMock()
        mock_parser.parse.side_effect = RuntimeError("Parser crashed!")

        with pytest.raises(ParseError) as exc_info:
            extractor._safe_parse(mock_parser, b"code", Path("/test.ts"), "typescript")

        assert exc_info.value.language == "typescript"
        assert "Parser crashed" in str(exc_info.value.original_error)

    def test_safe_parse_success(self):
        """_safe_parse should return parse result on success."""
        extractor = HybridExtractor()

        mock_parser = MagicMock()
        mock_tree = MagicMock()
        mock_parser.parse.return_value = mock_tree

        result = extractor._safe_parse(mock_parser, b"code", Path("/test.ts"), "typescript")

        assert result is mock_tree
        mock_parser.parse.assert_called_once_with(b"code")


class TestTreeSitterFallback:
    """Tests for graceful fallback to Pygments."""

    def test_try_tree_sitter_returns_none_on_parse_error(self):
        """_try_tree_sitter should return None on ParseError."""
        extractor = HybridExtractor()

        def failing_extractor(fp):
            raise ParseError(fp, "test", ValueError("test"))

        result = extractor._try_tree_sitter(failing_extractor, Path("/test.ts"), "typescript")
        assert result is None

    def test_try_tree_sitter_returns_none_on_os_error(self):
        """_try_tree_sitter should return None on OSError."""
        extractor = HybridExtractor()

        def failing_extractor(fp):
            raise OSError("File not found")

        result = extractor._try_tree_sitter(failing_extractor, Path("/test.ts"), "typescript")
        assert result is None

    def test_try_tree_sitter_returns_none_on_value_error(self):
        """_try_tree_sitter should return None on ValueError."""
        extractor = HybridExtractor()

        def failing_extractor(fp):
            raise ValueError("Invalid input")

        result = extractor._try_tree_sitter(failing_extractor, Path("/test.ts"), "typescript")
        assert result is None

    def test_try_tree_sitter_returns_none_on_runtime_error(self):
        """_try_tree_sitter should return None on RuntimeError."""
        extractor = HybridExtractor()

        def failing_extractor(fp):
            raise RuntimeError("Grammar crashed")

        result = extractor._try_tree_sitter(failing_extractor, Path("/test.ts"), "typescript")
        assert result is None

    def test_try_tree_sitter_catches_unexpected_exceptions(self):
        """_try_tree_sitter should catch unexpected exceptions too."""
        extractor = HybridExtractor()

        def failing_extractor(fp):
            raise Exception("Totally unexpected!")

        result = extractor._try_tree_sitter(failing_extractor, Path("/test.ts"), "typescript")
        assert result is None

    def test_try_tree_sitter_success(self):
        """_try_tree_sitter should return result on success."""
        from tldr.ast_extractor import ModuleInfo

        extractor = HybridExtractor()
        expected = ModuleInfo(file_path=Path("/test.ts"), language="typescript", docstring=None)

        def success_extractor(fp):
            return expected

        result = extractor._try_tree_sitter(success_extractor, Path("/test.ts"), "typescript")
        assert result is expected


class TestPygmentsFallback:
    """Tests for fallback to Pygments when tree-sitter fails."""

    def test_typescript_falls_back_to_pygments(self):
        """TypeScript should fall back to Pygments on tree-sitter failure."""
        extractor = HybridExtractor()

        # Create a valid TypeScript file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".ts", delete=False) as f:
            f.write("function hello(): string { return 'world'; }\n")
            path = Path(f.name)

        try:
            # Mock tree-sitter to fail
            with patch.object(extractor, "_extract_tree_sitter", side_effect=RuntimeError("Crash!")):
                result = extractor.extract(path)
                # Should still get a result from Pygments
                assert result is not None
        finally:
            path.unlink()

    def test_go_falls_back_to_pygments(self):
        """Go should fall back to Pygments on tree-sitter failure."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".go", delete=False) as f:
            f.write("package main\n\nfunc hello() string { return \"world\" }\n")
            path = Path(f.name)

        try:
            with patch.object(extractor, "_extract_go", side_effect=RuntimeError("Crash!")):
                result = extractor.extract(path)
                assert result is not None
        finally:
            path.unlink()

    def test_rust_falls_back_to_pygments(self):
        """Rust should fall back to Pygments on tree-sitter failure."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".rs", delete=False) as f:
            f.write("fn hello() -> String { String::from(\"world\") }\n")
            path = Path(f.name)

        try:
            with patch.object(extractor, "_extract_rust", side_effect=RuntimeError("Crash!")):
                result = extractor.extract(path)
                assert result is not None
        finally:
            path.unlink()


class TestErrorLogging:
    """Tests for proper error logging."""

    def test_safe_parse_logs_error(self, caplog):
        """_safe_parse should log errors before raising."""
        import logging

        extractor = HybridExtractor()
        mock_parser = MagicMock()
        mock_parser.parse.side_effect = RuntimeError("Parser crashed!")

        with caplog.at_level(logging.ERROR):
            with pytest.raises(ParseError):
                extractor._safe_parse(mock_parser, b"code", Path("/test.ts"), "typescript")

        assert "Tree-sitter parse failed" in caplog.text
        assert "Parser crashed" in caplog.text

    def test_try_tree_sitter_logs_warning_on_failure(self, caplog):
        """_try_tree_sitter should log warnings on fallback."""
        import logging

        extractor = HybridExtractor()

        def failing_extractor(fp):
            raise RuntimeError("Grammar crashed")

        with caplog.at_level(logging.WARNING):
            extractor._try_tree_sitter(failing_extractor, Path("/test.ts"), "typescript")

        assert "falling back to Pygments" in caplog.text or "Unexpected error" in caplog.text


class TestOSErrorHandling:
    """Tests for OS-level error handling."""

    def test_stat_os_error_continues(self):
        """OSError during stat should not crash extraction."""
        extractor = HybridExtractor()

        # Create a valid file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("x = 1\n")
            path = Path(f.name)

        try:
            # First stat fails, but second (during read) succeeds
            original_stat = Path.stat
            call_count = [0]

            def flaky_stat(self):
                call_count[0] += 1
                if call_count[0] == 1:
                    raise OSError("stat failed")
                return original_stat(self)

            with patch.object(Path, "stat", flaky_stat):
                # Should not crash - continues to read attempt
                result = extractor.extract(path)
                assert result is not None
        finally:
            path.unlink()


class TestEdgeCases:
    """Edge case tests for crash protection."""

    def test_empty_file(self):
        """Empty files should not crash."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("")
            path = Path(f.name)

        try:
            result = extractor.extract(path)
            assert result is not None
        finally:
            path.unlink()

    def test_binary_garbage(self):
        """Binary content should not crash (may fail gracefully)."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="wb", suffix=".py", delete=False) as f:
            f.write(b"\x00\x01\x02\x03\xff\xfe\xfd")
            path = Path(f.name)

        try:
            # May raise or return partial result - just should not crash
            try:
                result = extractor.extract(path)
            except (UnicodeDecodeError, SyntaxError, ValueError):
                pass  # Expected - graceful failure
        finally:
            path.unlink()

    def test_file_exactly_at_limit(self):
        """File exactly at size limit should succeed."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("x = 1\n")
            path = Path(f.name)

        try:
            # Mock stat to report size exactly at limit
            mock_result = MagicMock()
            mock_result.st_size = MAX_FILE_SIZE

            with patch("os.stat", return_value=mock_result):
                # Should NOT raise - exactly at limit is allowed
                result = extractor.extract(path)
                assert result is not None
        finally:
            path.unlink()

    def test_file_one_byte_over_limit(self):
        """File one byte over limit should fail."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write("x = 1\n")
            path = Path(f.name)

        try:
            mock_result = MagicMock()
            mock_result.st_size = MAX_FILE_SIZE + 1

            with patch("os.stat", return_value=mock_result):
                with pytest.raises(FileTooLargeError):
                    extractor.extract(path)
        finally:
            path.unlink()


class TestRealWorldCrashScenarios:
    """Tests simulating real-world crash scenarios."""

    def test_corrupted_utf8(self):
        """Corrupted UTF-8 should not crash."""
        extractor = HybridExtractor()

        with tempfile.NamedTemporaryFile(mode="wb", suffix=".ts", delete=False) as f:
            # Valid TS with invalid UTF-8 in the middle
            f.write(b"function hello() {\n")
            f.write(b"  // \xff\xfe invalid utf8\n")
            f.write(b"  return 'world';\n")
            f.write(b"}\n")
            path = Path(f.name)

        try:
            # Should not crash - either parses with error recovery or falls back
            try:
                result = extractor.extract(path)
                assert result is not None
            except UnicodeDecodeError:
                pass  # Acceptable failure mode
        finally:
            path.unlink()

    def test_deeply_nested_code(self):
        """Deeply nested code (100 levels) should not stack overflow."""
        extractor = HybridExtractor()

        # Generate 100 levels of nesting
        code = "def f():\n"
        for i in range(100):
            indent = "    " * (i + 1)
            code += f"{indent}if True:\n"
        code += "    " * 101 + "return 1\n"

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(code)
            path = Path(f.name)

        try:
            result = extractor.extract(path)
            assert result is not None
        finally:
            path.unlink()

    def test_extremely_long_line(self):
        """Extremely long line (100KB) should not crash."""
        extractor = HybridExtractor()

        # 100KB single line
        long_string = "x = '" + "a" * 100_000 + "'\n"

        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(long_string)
            path = Path(f.name)

        try:
            result = extractor.extract(path)
            assert result is not None
        finally:
            path.unlink()
