"""Tests for C++ #include parsing.

TDD tests for C++ support in TLDR import parsing.
These tests mirror test_imports_c.py patterns but for C++ constructs.

Expected to fail initially with ImportError (parse_cpp_imports not implemented).
"""
import pytest
from pathlib import Path

# Check if tree-sitter-cpp is available
try:
    from tldr.cross_file_calls import parse_cpp_imports, TREE_SITTER_CPP_AVAILABLE
    CPP_AVAILABLE = TREE_SITTER_CPP_AVAILABLE
except ImportError:
    CPP_AVAILABLE = False


pytestmark = pytest.mark.skipif(not CPP_AVAILABLE, reason="tree-sitter-cpp not available")


@pytest.fixture
def system_includes_file(tmp_path):
    """Create a C++ file with system includes."""
    code = '''
#include <iostream>
#include <string>
#include <vector>
#include <map>

int main() {
    std::cout << "Hello" << std::endl;
    return 0;
}
'''
    file_path = tmp_path / "main.cpp"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def local_includes_file(tmp_path):
    """Create a C++ file with local includes."""
    code = '''
#include "utils.hpp"
#include "config.hpp"
#include "../common/types.hpp"

void process() {
    init();
}
'''
    file_path = tmp_path / "main.cpp"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_includes_file(tmp_path):
    """Create a C++ file with mixed includes."""
    code = '''
#include <iostream>
#include <vector>
#include "utils.hpp"
#include "config.hpp"

int main() {
    init();
    return 0;
}
'''
    file_path = tmp_path / "main.cpp"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def conditional_includes_file(tmp_path):
    """Create a C++ file with conditional includes."""
    code = '''
#ifndef HEADER_HPP
#define HEADER_HPP

#include <iostream>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

#ifdef USE_BOOST
#include <boost/shared_ptr.hpp>
#endif

#endif
'''
    file_path = tmp_path / "header.hpp"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def cpp_specific_includes_file(tmp_path):
    """Create a C++ file with C++ specific headers."""
    code = '''
#include <memory>
#include <algorithm>
#include <functional>
#include <thread>
#include <mutex>

class Manager {
    std::unique_ptr<int> data;
    std::mutex mtx;
};
'''
    file_path = tmp_path / "manager.cpp"
    file_path.write_text(code)
    return file_path


class TestSystemIncludes:
    """Test system header include parsing."""

    def test_parses_system_includes(self, system_includes_file):
        imports = parse_cpp_imports(system_includes_file)
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        assert 'iostream' in modules or any('iostream' in m for m in modules)
        assert 'vector' in modules or any('vector' in m for m in modules)

    def test_system_include_angle_brackets(self, system_includes_file):
        imports = parse_cpp_imports(system_includes_file)
        # System includes use angle brackets
        for imp in imports:
            assert 'module' in imp


class TestLocalIncludes:
    """Test local header include parsing."""

    def test_parses_local_includes(self, local_includes_file):
        imports = parse_cpp_imports(local_includes_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        assert 'utils.hpp' in modules or any('utils' in m for m in modules)

    def test_relative_path_includes(self, local_includes_file):
        imports = parse_cpp_imports(local_includes_file)
        modules = [imp['module'] for imp in imports]
        # Should capture relative path include
        assert any('common' in m or 'types' in m for m in modules)


class TestMixedIncludes:
    """Test mixed include scenarios."""

    def test_mixed_includes(self, mixed_includes_file):
        imports = parse_cpp_imports(mixed_includes_file)
        # Should have all includes
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various include types are captured
        assert any('iostream' in m for m in modules)
        assert any('utils' in m for m in modules)


class TestConditionalIncludes:
    """Test conditional preprocessing includes."""

    def test_conditional_includes_parsed(self, conditional_includes_file):
        imports = parse_cpp_imports(conditional_includes_file)
        # Should capture includes even in conditional blocks
        assert len(imports) >= 1
        modules = [imp['module'] for imp in imports]
        assert any('iostream' in m for m in modules)


class TestCppSpecificIncludes:
    """Test C++ specific header parsing."""

    def test_cpp_memory_headers(self, cpp_specific_includes_file):
        imports = parse_cpp_imports(cpp_specific_includes_file)
        assert len(imports) >= 5
        modules = [imp['module'] for imp in imports]
        assert any('memory' in m for m in modules)
        assert any('algorithm' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "empty.cpp"
        file_path.write_text("int main() { return 0; }")
        imports = parse_cpp_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "nonexistent.cpp"
        imports = parse_cpp_imports(file_path)
        assert imports == []

    def test_commented_include(self, tmp_path):
        code = '''
// #include <commented.h>
/* #include <block_commented.h> */
#include <actual.h>

int main() { return 0; }
'''
        file_path = tmp_path / "main.cpp"
        file_path.write_text(code)
        imports = parse_cpp_imports(file_path)
        modules = [imp['module'] for imp in imports]
        # Should only have actual.h, not commented ones
        assert len([m for m in modules if 'actual' in m]) >= 1
