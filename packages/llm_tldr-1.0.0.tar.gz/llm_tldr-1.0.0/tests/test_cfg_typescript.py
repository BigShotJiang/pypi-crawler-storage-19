"""Tests for TypeScript/JavaScript CFG extraction."""
import pytest

# Check if tree-sitter is available
try:
    from tldr.cfg_extractor import extract_typescript_cfg, TREE_SITTER_AVAILABLE
    TS_AVAILABLE = TREE_SITTER_AVAILABLE
except ImportError:
    TS_AVAILABLE = False


pytestmark = pytest.mark.skipif(not TS_AVAILABLE, reason="tree-sitter not available")


@pytest.fixture
def simple_if_code():
    return '''
function check(x) {
    if (x > 0) {
        return "positive";
    }
    return "non-positive";
}
'''


@pytest.fixture
def while_loop_code():
    return '''
function count(n) {
    let i = 0;
    while (i < n) {
        i++;
    }
    return i;
}
'''


@pytest.fixture
def for_loop_code():
    return '''
function sum(items) {
    let total = 0;
    for (const item of items) {
        total += item;
    }
    return total;
}
'''


@pytest.fixture
def nested_code():
    return '''
function process(items) {
    for (const item of items) {
        if (item.valid) {
            handle(item);
        } else {
            skip(item);
        }
    }
    return done();
}
'''


@pytest.fixture
def break_continue_code():
    return '''
function findFirst(items, target) {
    for (const item of items) {
        if (item === target) {
            break;
        }
        if (item === null) {
            continue;
        }
        process(item);
    }
    return null;
}
'''


@pytest.fixture
def arrow_function_code():
    return '''
const check = (x) => {
    if (x > 0) {
        return "positive";
    }
    return "negative";
};
'''


class TestTypeScriptCFG:
    """Test TypeScript CFG extraction."""

    def test_simple_function_has_entry_and_exit(self, simple_if_code):
        cfg = extract_typescript_cfg(simple_if_code, "check")
        assert cfg.entry_block_id is not None
        assert len(cfg.exit_block_ids) >= 1

    def test_if_creates_branch(self, simple_if_code):
        cfg = extract_typescript_cfg(simple_if_code, "check")
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 2

    def test_while_creates_back_edge(self, while_loop_code):
        cfg = extract_typescript_cfg(while_loop_code, "count")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_while_has_loop_header(self, while_loop_code):
        cfg = extract_typescript_cfg(while_loop_code, "count")
        headers = [b for b in cfg.blocks if b.block_type == "loop_header"]
        assert len(headers) >= 1

    def test_for_loop_creates_back_edge(self, for_loop_code):
        cfg = extract_typescript_cfg(for_loop_code, "sum")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_cyclomatic_complexity_simple_if(self, simple_if_code):
        cfg = extract_typescript_cfg(simple_if_code, "check")
        assert cfg.cyclomatic_complexity == 2

    def test_cyclomatic_complexity_while(self, while_loop_code):
        cfg = extract_typescript_cfg(while_loop_code, "count")
        assert cfg.cyclomatic_complexity == 2

    def test_nested_complexity(self, nested_code):
        cfg = extract_typescript_cfg(nested_code, "process")
        # for + if + 1 = 3
        assert cfg.cyclomatic_complexity == 3

    def test_cfg_to_dict(self, simple_if_code):
        cfg = extract_typescript_cfg(simple_if_code, "check")
        d = cfg.to_dict()
        assert "blocks" in d
        assert "edges" in d
        assert "cyclomatic_complexity" in d
        assert d["function"] == "check"

    def test_break_creates_edge(self, break_continue_code):
        cfg = extract_typescript_cfg(break_continue_code, "findFirst")
        break_edges = [e for e in cfg.edges if e.edge_type == "break"]
        assert len(break_edges) >= 1

    def test_continue_creates_edge(self, break_continue_code):
        cfg = extract_typescript_cfg(break_continue_code, "findFirst")
        continue_edges = [e for e in cfg.edges if e.edge_type == "continue"]
        assert len(continue_edges) >= 1

    def test_function_not_found_raises(self):
        with pytest.raises(ValueError, match="not found"):
            extract_typescript_cfg("function foo() {}", "bar")


class TestTypeScriptCFGEdgeCases:
    """Edge cases for TypeScript CFG."""

    def test_traditional_for_loop(self):
        code = '''
function count(n) {
    let sum = 0;
    for (let i = 0; i < n; i++) {
        sum += i;
    }
    return sum;
}
'''
        cfg = extract_typescript_cfg(code, "count")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_if_else_if(self):
        code = '''
function grade(score) {
    if (score >= 90) {
        return "A";
    } else if (score >= 80) {
        return "B";
    } else {
        return "F";
    }
}
'''
        cfg = extract_typescript_cfg(code, "grade")
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 4

    def test_nested_loops(self):
        code = '''
function matrix(rows, cols) {
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
            process(i, j);
        }
    }
}
'''
        cfg = extract_typescript_cfg(code, "matrix")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 2
