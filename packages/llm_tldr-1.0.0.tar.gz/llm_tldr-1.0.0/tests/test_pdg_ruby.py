"""Tests for Ruby PDG extraction and program slicing (L5).

TDD Tests for Ruby PDG support.
These tests should FAIL initially until Ruby support is implemented.

Tests mirror the structure of test_pdg_java.py but for Ruby language support.
"""
import os
import pytest

# Check if tree-sitter-ruby is available
try:
    from tldr.cfg_extractor import TREE_SITTER_RUBY_AVAILABLE
    RUBY_AVAILABLE = TREE_SITTER_RUBY_AVAILABLE
except ImportError:
    RUBY_AVAILABLE = False

# Check if extract_ruby_pdg is implemented
try:
    from tldr.pdg_extractor import extract_ruby_pdg
    RUBY_PDG_AVAILABLE = True
except ImportError:
    RUBY_PDG_AVAILABLE = False
    extract_ruby_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not RUBY_AVAILABLE,
    reason="tree-sitter-ruby not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_ruby_path():
    """Path to sample.rb fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.rb")


@pytest.fixture
def sample_ruby_code(sample_ruby_path):
    """Load sample.rb fixture code."""
    with open(sample_ruby_path) as f:
        return f.read()


@pytest.fixture
def simple_ruby_code():
    """Simple Ruby code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
# =============================================================================
# Simple Ruby test fixture for PDG extraction
# This code is used to test basic PDG node and edge extraction.
# The add function has simple data flow: a -> c, b -> c, c -> return
# The comments here ensure the code is longer than 500 characters so it is
# not mistakenly treated as a file path by _resolve_source heuristic.
# =============================================================================
class Example
  def add(a, b)
    c = a + b
    c
  end
end
'''


@pytest.fixture
def chained_ruby_code():
    """Ruby code with chained dependencies for slice testing."""
    return '''
# =============================================================================
# Chained Ruby test fixture for PDG extraction and slicing
# This tests forward and backward slices through a dependency chain.
# Dependencies: x -> a -> b -> c -> return
# =============================================================================
class ChainedCompute
  def compute(x)
    a = x + 1     # line 9: a depends on x
    b = a * 2     # line 10: b depends on a
    c = b + 3     # line 11: c depends on b
    c             # line 12: return depends on c
  end
end
'''


# =============================================================================
# Tests for extract_ruby_pdg()
# =============================================================================

class TestExtractRubyPDG:
    """Test extract_ruby_pdg() function."""

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_extract_ruby_pdg_basic(self, sample_ruby_code):
        """Test basic PDG extraction from sample.rb calculate method."""
        pdg = extract_ruby_pdg(sample_ruby_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_extract_ruby_pdg_has_nodes(self, sample_ruby_code):
        """Verify PDG has nodes extracted from the method."""
        pdg = extract_ruby_pdg(sample_ruby_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_extract_ruby_pdg_has_edges(self, sample_ruby_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_ruby_pdg(sample_ruby_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_extract_ruby_pdg_sum_method(self, sample_ruby_code):
        """Test PDG extraction for the sum method with loop."""
        pdg = extract_ruby_pdg(sample_ruby_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum method should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_extract_ruby_pdg_nonexistent_method(self, sample_ruby_code):
        """Test that nonexistent method returns None."""
        pdg = extract_ruby_pdg(sample_ruby_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for Ruby Program Slicing
# =============================================================================

class TestRubyProgramSlicing:
    """Test program slicing for Ruby code."""

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_ruby_backward_slice(self, sample_ruby_code):
        """Test backward slice from return statement in sum method."""
        pdg = extract_ruby_pdg(sample_ruby_code, "sum")

        assert pdg is not None
        # Line 25 is "total" return in sample.rb
        slice_lines = pdg.backward_slice(line=25)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_ruby_forward_slice(self, chained_ruby_code):
        """Test forward slice from first assignment."""
        pdg = extract_ruby_pdg(chained_ruby_code, "compute")

        assert pdg is not None
        # Forward slice from "a = x + 1" (line 9)
        slice_lines = pdg.forward_slice(line=9)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_ruby_slice_returns_set(self, simple_ruby_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_ruby_pdg(simple_ruby_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=12)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for Ruby PDG via API
# =============================================================================

class TestRubyPDGAPI:
    """Test Ruby PDG integration via tldr.api functions."""

    def test_ruby_get_pdg_context(self, sample_ruby_path):
        """Test get_pdg_context() for Ruby code via file path."""
        result = get_pdg_context(sample_ruby_path, "calculate", language="ruby")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_ruby_get_slice_backward(self, sample_ruby_path):
        """Test get_slice() backward for Ruby code via file path."""
        # Backward slice from return statement in sum method
        lines = get_slice(
            sample_ruby_path, "sum", line=25,
            direction="backward", language="ruby"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_ruby_get_slice_forward(self, sample_ruby_path):
        """Test get_slice() forward for Ruby code via file path."""
        lines = get_slice(
            sample_ruby_path, "compute", line=47,
            direction="forward", language="ruby"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestRubyPDGIntegration:
    """Integration tests for Ruby PDG."""

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_pdg_from_file(self, sample_ruby_path, sample_ruby_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate method
        pdg = extract_ruby_pdg(sample_ruby_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not RUBY_PDG_AVAILABLE, reason="extract_ruby_pdg not implemented")
    def test_pdg_to_dict(self, simple_ruby_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_ruby_pdg(simple_ruby_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
