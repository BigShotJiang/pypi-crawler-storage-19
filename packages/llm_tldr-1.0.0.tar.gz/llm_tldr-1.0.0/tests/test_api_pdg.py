"""
Tests for PDG integration in tldr.api module.

TDD Tests for:
1. get_pdg_context() - PDG extraction via API
2. get_slice() - Program slicing via API
3. PDG data in get_relevant_context() output
"""

import pytest

from tldr.api import (
    get_pdg_context,
    get_slice,
    get_relevant_context,
)


# =============================================================================
# Tests for get_pdg_context()
# =============================================================================

class TestGetPDGContext:
    """Test get_pdg_context() API function."""

    def test_basic_python_pdg(self):
        """Test PDG extraction for simple Python function."""
        code = '''
def add(a, b):
    c = a + b
    return c
'''
        result = get_pdg_context(code, "add", language="python")

        assert result is not None
        assert "function" in result
        assert result["function"] == "add"
        assert "nodes" in result
        # compact_dict has edge counts, not full edges list
        assert "control_edges" in result
        assert "data_edges" in result

    def test_pdg_context_includes_complexity(self):
        """Test that PDG context includes complexity metrics."""
        code = '''
def complex(x):
    if x > 0:
        if x > 10:
            return "big"
        return "small"
    return "negative"
'''
        result = get_pdg_context(code, "complex", language="python")

        assert result is not None
        assert "complexity" in result
        assert result["complexity"] >= 2  # Has branches

    def test_pdg_context_includes_variables(self):
        """Test that PDG context includes tracked variables."""
        code = '''
def vars(x, y):
    total = x + y
    average = total / 2
    return average
'''
        result = get_pdg_context(code, "vars", language="python")

        assert result is not None
        assert "variables" in result
        assert "total" in result["variables"] or len(result["variables"]) > 0

    @pytest.mark.skipif(
        True,  # Skip until tree-sitter-typescript is installed
        reason="tree-sitter-typescript not available"
    )
    def test_pdg_context_typescript(self):
        """Test PDG extraction for TypeScript function."""
        code = '''
function multiply(a: number, b: number): number {
    const result = a * b;
    return result;
}
'''
        result = get_pdg_context(code, "multiply", language="typescript")

        assert result is not None
        assert result["function"] == "multiply"

    @pytest.mark.skipif(
        True,  # Skip until tree-sitter-go is installed
        reason="tree-sitter-go not available"
    )
    def test_pdg_context_go(self):
        """Test PDG extraction for Go function."""
        code = '''
func divide(a int, b int) int {
    result := a / b
    return result
}
'''
        result = get_pdg_context(code, "divide", language="go")

        assert result is not None
        assert result["function"] == "divide"

    @pytest.mark.skipif(
        True,  # Skip until tree-sitter-rust is installed
        reason="tree-sitter-rust not available"
    )
    def test_pdg_context_rust(self):
        """Test PDG extraction for Rust function."""
        code = '''
fn subtract(a: i32, b: i32) -> i32 {
    let result = a - b;
    result
}
'''
        result = get_pdg_context(code, "subtract", language="rust")

        assert result is not None
        assert result["function"] == "subtract"

    def test_pdg_context_nonexistent_function(self):
        """Test that nonexistent function returns None."""
        code = '''
def exists():
    pass
'''
        result = get_pdg_context(code, "nonexistent", language="python")
        assert result is None

    def test_pdg_context_invalid_language(self):
        """Test that invalid language raises ValueError."""
        code = "def foo(): pass"

        with pytest.raises(ValueError):
            get_pdg_context(code, "foo", language="invalid_lang")

    def test_pdg_context_default_language(self):
        """Test that default language is Python."""
        code = '''
def default_test():
    x = 1
    return x
'''
        # Should work without specifying language
        result = get_pdg_context(code, "default_test")

        assert result is not None
        assert result["function"] == "default_test"


# =============================================================================
# Tests for get_slice()
# =============================================================================

class TestGetSlice:
    """Test get_slice() API function."""

    def test_backward_slice_simple(self):
        """Test backward slice for simple data flow."""
        code = '''
def compute(x):
    a = x + 1
    b = a * 2
    c = b + 3
    return c
'''
        # Backward slice from return line should include earlier lines
        lines = get_slice(code, "compute", line=6, direction="backward")

        assert isinstance(lines, set)
        assert len(lines) > 0
        # Should include line 6 itself
        assert 6 in lines or len(lines) > 0

    def test_forward_slice_simple(self):
        """Test forward slice for simple data flow."""
        code = '''
def propagate(x):
    a = x * 2
    b = a + 1
    c = b - 1
    return c
'''
        # Forward slice from first assignment should reach later lines
        lines = get_slice(code, "propagate", line=3, direction="forward")

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_slice_with_variable(self):
        """Test slicing filtered to specific variable."""
        code = '''
def multi(x, y):
    a = x + 1
    b = y + 2
    c = a + b
    return c
'''
        # Slice for variable 'a' specifically
        lines = get_slice(
            code, "multi", line=6, direction="backward",
            variable="a"
        )

        assert isinstance(lines, set)
        # Should be smaller or equal to full slice
        full_slice = get_slice(code, "multi", line=6, direction="backward")
        assert len(lines) <= len(full_slice) or len(lines) > 0

    def test_slice_invalid_line(self):
        """Test slice with invalid line returns empty set."""
        code = '''
def simple(x):
    return x
'''
        lines = get_slice(code, "simple", line=100, direction="backward")
        assert lines == set()

    def test_slice_invalid_direction(self):
        """Test slice with invalid direction raises error."""
        code = '''
def foo():
    pass
'''
        with pytest.raises(ValueError):
            get_slice(code, "foo", line=2, direction="sideways")

    def test_slice_nonexistent_function(self):
        """Test slice for nonexistent function returns empty set."""
        code = '''
def exists():
    pass
'''
        lines = get_slice(code, "nonexistent", line=2, direction="backward")
        assert lines == set()

    @pytest.mark.skipif(
        True,  # Skip until tree-sitter-typescript is installed
        reason="tree-sitter-typescript not available"
    )
    def test_slice_typescript(self):
        """Test slicing works for TypeScript."""
        code = '''
function chain(x: number): number {
    const a = x + 1;
    const b = a * 2;
    return b;
}
'''
        lines = get_slice(
            code, "chain", line=5, direction="backward",
            language="typescript"
        )

        assert isinstance(lines, set)

    def test_slice_default_direction(self):
        """Test that default direction is backward."""
        code = '''
def test_default():
    x = 1
    y = x + 1
    return y
'''
        # Should default to backward
        lines = get_slice(code, "test_default", line=5)
        assert isinstance(lines, set)


# =============================================================================
# Tests for PDG in get_relevant_context()
# =============================================================================

class TestPDGInRelevantContext:
    """Test PDG data integration in get_relevant_context()."""

    def test_relevant_context_with_pdg_analysis(self, tmp_path):
        """Test that PDG can be extracted for functions found by get_relevant_context."""
        # Create a file with function
        file1 = tmp_path / "module.py"
        file1.write_text('''
def process(x):
    a = x + 1
    b = a * 2
    return b
''')

        # Get context for the function
        ctx = get_relevant_context(tmp_path, "module.process", depth=0)
        assert len(ctx.functions) == 1
        func = ctx.functions[0]

        # Read source and extract PDG separately
        source_code = file1.read_text()
        pdg_ctx = get_pdg_context(source_code, "process")

        assert pdg_ctx is not None
        assert pdg_ctx["function"] == "process"

    def test_relevant_context_pdg_default_off(self, tmp_path):
        """Test that PDG is not included by default (performance)."""
        file1 = tmp_path / "simple.py"
        file1.write_text('''
def simple():
    return 1
''')

        ctx = get_relevant_context(tmp_path, "simple.simple", depth=0)

        # By default, no PDG processing overhead
        # Just verify it doesn't error
        assert len(ctx.functions) >= 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestPDGAPIIntegration:
    """Integration tests for PDG API."""

    def test_end_to_end_slice_analysis(self):
        """Test complete slice analysis workflow."""
        code = '''
def analyze_data(items, threshold):
    filtered = []
    total = 0

    for item in items:
        if item > threshold:
            filtered.append(item)
            total += item

    if total > 0:
        average = total / len(filtered)
    else:
        average = 0

    return {"filtered": filtered, "average": average}
'''
        # Get PDG context
        pdg_ctx = get_pdg_context(code, "analyze_data")
        assert pdg_ctx is not None
        assert pdg_ctx["complexity"] >= 2

        # Get backward slice from return
        return_line = 16  # return statement
        slice_lines = get_slice(
            code, "analyze_data", line=return_line,
            direction="backward"
        )

        assert len(slice_lines) > 0

    def test_multiple_functions_pdg(self):
        """Test PDG for multiple functions in same source."""
        code = '''
def helper(x):
    return x * 2

def main(a, b):
    x = helper(a)
    y = helper(b)
    return x + y
'''
        # Should be able to get PDG for each function
        helper_pdg = get_pdg_context(code, "helper")
        main_pdg = get_pdg_context(code, "main")

        assert helper_pdg is not None
        assert main_pdg is not None
        assert helper_pdg["function"] == "helper"
        assert main_pdg["function"] == "main"
