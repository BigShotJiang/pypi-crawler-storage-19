"""Tests for tldr.dirty_flag module - lazy staleness handling (P3)."""
import json
import tempfile
import pytest
from pathlib import Path
from datetime import datetime
from unittest.mock import patch

from tldr.dirty_flag import (
    mark_dirty,
    is_dirty,
    get_dirty_files,
    clear_dirty,
    get_dirty_count,
    DIRTY_FILE,
)


class TestMarkDirty:
    """Tests for mark_dirty() function."""

    def test_mark_dirty_creates_dirty_flag_file(self, tmp_path):
        """mark_dirty() should create the dirty flag file with the edited file."""
        edited_file = "src/auth.py"

        mark_dirty(tmp_path, edited_file)

        dirty_path = tmp_path / DIRTY_FILE
        assert dirty_path.exists(), "Dirty flag file should be created"

        data = json.loads(dirty_path.read_text())
        assert edited_file in data["dirty_files"]
        assert "first_dirty_at" in data
        assert "last_dirty_at" in data

    def test_mark_dirty_appends_to_existing_list(self, tmp_path):
        """mark_dirty() should append to existing dirty files list."""
        # Mark first file dirty
        mark_dirty(tmp_path, "src/auth.py")

        # Mark second file dirty
        mark_dirty(tmp_path, "src/api.py")

        dirty_path = tmp_path / DIRTY_FILE
        data = json.loads(dirty_path.read_text())

        assert len(data["dirty_files"]) == 2
        assert "src/auth.py" in data["dirty_files"]
        assert "src/api.py" in data["dirty_files"]

    def test_mark_dirty_no_duplicates(self, tmp_path):
        """mark_dirty() should not add duplicate files."""
        mark_dirty(tmp_path, "src/auth.py")
        mark_dirty(tmp_path, "src/auth.py")

        dirty_path = tmp_path / DIRTY_FILE
        data = json.loads(dirty_path.read_text())

        assert data["dirty_files"].count("src/auth.py") == 1

    def test_mark_dirty_updates_last_dirty_at(self, tmp_path):
        """mark_dirty() should update last_dirty_at timestamp."""
        mark_dirty(tmp_path, "src/auth.py")

        dirty_path = tmp_path / DIRTY_FILE
        data1 = json.loads(dirty_path.read_text())
        first_dirty = data1["first_dirty_at"]

        # Small delay to ensure different timestamp
        mark_dirty(tmp_path, "src/api.py")

        data2 = json.loads(dirty_path.read_text())
        assert data2["first_dirty_at"] == first_dirty, "first_dirty_at should not change"
        # last_dirty_at should be >= first (may be equal if fast)
        assert data2["last_dirty_at"] >= first_dirty

    def test_mark_dirty_creates_parent_directories(self, tmp_path):
        """mark_dirty() should create .tldr/cache/ directories if needed."""
        # Ensure directories don't exist
        cache_dir = tmp_path / ".tldr" / "cache"
        assert not cache_dir.exists()

        mark_dirty(tmp_path, "src/auth.py")

        assert cache_dir.exists()


class TestIsDirty:
    """Tests for is_dirty() function."""

    def test_is_dirty_returns_true_when_flag_exists(self, tmp_path):
        """is_dirty() should return True when dirty flag file exists."""
        mark_dirty(tmp_path, "src/auth.py")

        assert is_dirty(tmp_path) is True

    def test_is_dirty_returns_false_when_no_flag(self, tmp_path):
        """is_dirty() should return False when no dirty flag file."""
        assert is_dirty(tmp_path) is False

    def test_is_dirty_returns_false_after_clear(self, tmp_path):
        """is_dirty() should return False after clear_dirty()."""
        mark_dirty(tmp_path, "src/auth.py")
        clear_dirty(tmp_path)

        assert is_dirty(tmp_path) is False


class TestGetDirtyFiles:
    """Tests for get_dirty_files() function."""

    def test_get_dirty_files_returns_list(self, tmp_path):
        """get_dirty_files() should return list of dirty files."""
        mark_dirty(tmp_path, "src/auth.py")
        mark_dirty(tmp_path, "src/api.py")

        dirty_files = get_dirty_files(tmp_path)

        assert isinstance(dirty_files, list)
        assert len(dirty_files) == 2
        assert "src/auth.py" in dirty_files
        assert "src/api.py" in dirty_files

    def test_get_dirty_files_returns_empty_when_no_flag(self, tmp_path):
        """get_dirty_files() should return empty list when no dirty flag."""
        dirty_files = get_dirty_files(tmp_path)

        assert dirty_files == []

    def test_get_dirty_files_preserves_order(self, tmp_path):
        """get_dirty_files() should preserve order of files."""
        files = ["src/c.py", "src/a.py", "src/b.py"]
        for f in files:
            mark_dirty(tmp_path, f)

        dirty_files = get_dirty_files(tmp_path)
        assert dirty_files == files


class TestClearDirty:
    """Tests for clear_dirty() function."""

    def test_clear_dirty_removes_flag_file(self, tmp_path):
        """clear_dirty() should remove the dirty flag file."""
        mark_dirty(tmp_path, "src/auth.py")
        dirty_path = tmp_path / DIRTY_FILE
        assert dirty_path.exists()

        clear_dirty(tmp_path)

        assert not dirty_path.exists()

    def test_clear_dirty_handles_missing_file_gracefully(self, tmp_path):
        """clear_dirty() should not raise when file doesn't exist."""
        # Should not raise
        clear_dirty(tmp_path)

        # Should still work after clearing
        assert is_dirty(tmp_path) is False

    def test_clear_dirty_handles_missing_directory(self, tmp_path):
        """clear_dirty() should handle case where .tldr/cache doesn't exist."""
        # Ensure directory doesn't exist
        cache_dir = tmp_path / ".tldr" / "cache"
        assert not cache_dir.exists()

        # Should not raise
        clear_dirty(tmp_path)


class TestGetDirtyCount:
    """Tests for get_dirty_count() function."""

    def test_get_dirty_count_returns_zero_when_clean(self, tmp_path):
        """get_dirty_count() should return 0 when no dirty files."""
        assert get_dirty_count(tmp_path) == 0

    def test_get_dirty_count_returns_correct_count(self, tmp_path):
        """get_dirty_count() should return correct count of dirty files."""
        mark_dirty(tmp_path, "src/a.py")
        assert get_dirty_count(tmp_path) == 1

        mark_dirty(tmp_path, "src/b.py")
        assert get_dirty_count(tmp_path) == 2

        mark_dirty(tmp_path, "src/c.py")
        assert get_dirty_count(tmp_path) == 3


class TestDirtyFlagPersistence:
    """Tests for dirty flag persistence across operations."""

    def test_dirty_flag_persists_across_read_operations(self, tmp_path):
        """Dirty flag should persist when reading multiple times."""
        mark_dirty(tmp_path, "src/auth.py")

        # Multiple reads should not affect the flag
        for _ in range(5):
            assert is_dirty(tmp_path) is True
            files = get_dirty_files(tmp_path)
            assert "src/auth.py" in files

    def test_dirty_flag_json_format(self, tmp_path):
        """Dirty flag file should have correct JSON format."""
        mark_dirty(tmp_path, "src/auth.py")
        mark_dirty(tmp_path, "src/api.py")

        dirty_path = tmp_path / DIRTY_FILE
        data = json.loads(dirty_path.read_text())

        # Check structure
        assert "dirty_files" in data
        assert "first_dirty_at" in data
        assert "last_dirty_at" in data

        # Check types
        assert isinstance(data["dirty_files"], list)
        assert isinstance(data["first_dirty_at"], str)
        assert isinstance(data["last_dirty_at"], str)

        # Check timestamps are valid ISO format
        datetime.fromisoformat(data["first_dirty_at"].replace("Z", "+00:00"))
        datetime.fromisoformat(data["last_dirty_at"].replace("Z", "+00:00"))


class TestPathHandling:
    """Tests for path handling edge cases."""

    def test_accepts_string_path(self, tmp_path):
        """Functions should accept string paths."""
        path_str = str(tmp_path)

        mark_dirty(path_str, "src/auth.py")
        assert is_dirty(path_str) is True
        assert get_dirty_files(path_str) == ["src/auth.py"]
        assert get_dirty_count(path_str) == 1
        clear_dirty(path_str)
        assert is_dirty(path_str) is False

    def test_accepts_path_object(self, tmp_path):
        """Functions should accept Path objects."""
        mark_dirty(tmp_path, "src/auth.py")
        assert is_dirty(tmp_path) is True
        assert get_dirty_files(tmp_path) == ["src/auth.py"]
        assert get_dirty_count(tmp_path) == 1
        clear_dirty(tmp_path)
        assert is_dirty(tmp_path) is False

    def test_normalizes_edited_file_path(self, tmp_path):
        """mark_dirty() should normalize file paths."""
        # Mix of forward and backslashes should be normalized
        mark_dirty(tmp_path, "src\\auth.py")
        mark_dirty(tmp_path, "src/auth.py")

        # Should only have one entry (normalized)
        assert get_dirty_count(tmp_path) == 1
