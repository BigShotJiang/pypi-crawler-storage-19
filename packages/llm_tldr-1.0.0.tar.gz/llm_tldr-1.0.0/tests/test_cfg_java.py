"""Tests for Java CFG extraction."""
import pytest

# Check if tree-sitter-java is available
try:
    from tldr.cfg_extractor import extract_java_cfg, TREE_SITTER_JAVA_AVAILABLE
    JAVA_AVAILABLE = TREE_SITTER_JAVA_AVAILABLE
except ImportError:
    JAVA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")


@pytest.fixture
def simple_if_code():
    return '''
public class Example {
    public String check(int x) {
        if (x > 0) {
            return "positive";
        }
        return "non-positive";
    }
}
'''


@pytest.fixture
def for_loop_code():
    return '''
public class Example {
    public int count(int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += i;
        }
        return sum;
    }
}
'''


@pytest.fixture
def while_loop_code():
    return '''
public class Example {
    public int countdown(int n) {
        int count = 0;
        while (n > 0) {
            count++;
            n--;
        }
        return count;
    }
}
'''


@pytest.fixture
def nested_code():
    return '''
public class Example {
    public void process(List<Item> items) {
        for (Item item : items) {
            if (item.isValid()) {
                handle(item);
            } else {
                skip(item);
            }
        }
    }
}
'''


@pytest.fixture
def try_catch_code():
    return '''
public class Example {
    public int divide(int a, int b) {
        try {
            return a / b;
        } catch (ArithmeticException e) {
            return 0;
        }
    }
}
'''


@pytest.fixture
def switch_code():
    return '''
public class Example {
    public String getDay(int day) {
        switch (day) {
            case 1:
                return "Monday";
            case 2:
                return "Tuesday";
            default:
                return "Unknown";
        }
    }
}
'''


class TestBasicCFG:
    """Test basic CFG extraction for Java."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_java_cfg(simple_if_code, "check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_for_loop(self, for_loop_code):
        cfg = extract_java_cfg(for_loop_code, "count")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_java_cfg(while_loop_code, "countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_java_cfg(nested_code, "process")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_try_catch(self, try_catch_code):
        cfg = extract_java_cfg(try_catch_code, "divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_switch(self, switch_code):
        cfg = extract_java_cfg(switch_code, "getDay")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_java_cfg(simple_if_code, "check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, for_loop_code):
        cfg = extract_java_cfg(for_loop_code, "count")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_java_cfg(simple_if_code, "nonexistent")
