"""
Tests for Data Flow Graph (DFG) extraction.

DFG tracks variable definitions and uses, building def-use chains.
Following pflux/python-program-analysis architecture:
- DEFINITION: variable assignments (x = ...)
- UPDATE: in-place modifications (x += ..., x.append())
- USE: variable reads
"""
import pytest


# =============================================================================
# Data Structure Tests
# =============================================================================

class TestDFGDataStructures:
    """Test DFG data structures."""

    def test_var_ref_creation(self):
        """VarRef captures a variable reference."""
        from tldr.dfg_extractor import VarRef

        ref = VarRef(
            name="x",
            ref_type="definition",
            line=1,
            column=0,
        )
        assert ref.name == "x"
        assert ref.ref_type == "definition"
        assert ref.line == 1
        assert ref.column == 0

    def test_var_ref_to_dict(self):
        """VarRef serializes to dict."""
        from tldr.dfg_extractor import VarRef

        ref = VarRef(name="x", ref_type="use", line=5, column=4)
        d = ref.to_dict()

        assert d["name"] == "x"
        assert d["type"] == "use"
        assert d["line"] == 5

    def test_dataflow_edge_creation(self):
        """DataflowEdge connects definition to use."""
        from tldr.dfg_extractor import VarRef, DataflowEdge

        def_ref = VarRef(name="x", ref_type="definition", line=1, column=0)
        use_ref = VarRef(name="x", ref_type="use", line=3, column=4)

        edge = DataflowEdge(def_ref=def_ref, use_ref=use_ref)

        assert edge.def_ref.name == "x"
        assert edge.use_ref.line == 3
        assert edge.var_name == "x"

    def test_dataflow_edge_to_dict(self):
        """DataflowEdge serializes to dict."""
        from tldr.dfg_extractor import VarRef, DataflowEdge

        def_ref = VarRef(name="y", ref_type="definition", line=1, column=0)
        use_ref = VarRef(name="y", ref_type="use", line=5, column=8)
        edge = DataflowEdge(def_ref=def_ref, use_ref=use_ref)

        d = edge.to_dict()
        assert d["var"] == "y"
        assert d["def_line"] == 1
        assert d["use_line"] == 5

    def test_dfg_info_creation(self):
        """DFGInfo holds the full data flow graph."""
        from tldr.dfg_extractor import VarRef, DataflowEdge, DFGInfo

        refs = [
            VarRef(name="x", ref_type="definition", line=1, column=0),
            VarRef(name="x", ref_type="use", line=2, column=4),
        ]
        edges = [DataflowEdge(def_ref=refs[0], use_ref=refs[1])]

        dfg = DFGInfo(
            function_name="foo",
            var_refs=refs,
            dataflow_edges=edges,
        )

        assert dfg.function_name == "foo"
        assert len(dfg.var_refs) == 2
        assert len(dfg.dataflow_edges) == 1

    def test_dfg_info_variables_by_name(self):
        """DFGInfo groups references by variable name."""
        from tldr.dfg_extractor import VarRef, DFGInfo

        refs = [
            VarRef(name="x", ref_type="definition", line=1, column=0),
            VarRef(name="y", ref_type="definition", line=2, column=0),
            VarRef(name="x", ref_type="use", line=3, column=4),
        ]

        dfg = DFGInfo(function_name="foo", var_refs=refs, dataflow_edges=[])

        assert len(dfg.variables["x"]) == 2
        assert len(dfg.variables["y"]) == 1


# =============================================================================
# Python DFG Extraction Tests
# =============================================================================

class TestPythonDFGBasic:
    """Test basic Python DFG extraction."""

    def test_simple_assignment(self):
        """Extract definition from simple assignment."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo():
    x = 1
"""
        dfg = extract_python_dfg(code, "foo")

        assert dfg.function_name == "foo"
        defs = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert any(r.name == "x" for r in defs)

    def test_simple_use(self):
        """Extract use from return statement."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo():
    x = 1
    return x
"""
        dfg = extract_python_dfg(code, "foo")

        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert any(r.name == "x" for r in uses)

    def test_def_use_chain(self):
        """Build def-use chain for simple case."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo():
    x = 1
    y = x + 2
    return y
"""
        dfg = extract_python_dfg(code, "foo")

        # x is defined then used
        x_edges = [e for e in dfg.dataflow_edges if e.var_name == "x"]
        assert len(x_edges) >= 1

        # y is defined then used
        y_edges = [e for e in dfg.dataflow_edges if e.var_name == "y"]
        assert len(y_edges) >= 1

    def test_multiple_assignments(self):
        """Track multiple definitions of same variable."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo():
    x = 1
    x = 2
    return x
"""
        dfg = extract_python_dfg(code, "foo")

        # Two definitions of x
        x_defs = [r for r in dfg.var_refs if r.name == "x" and r.ref_type == "definition"]
        assert len(x_defs) == 2

        # Use should link to second definition (reaching def)
        x_edges = [e for e in dfg.dataflow_edges if e.var_name == "x"]
        assert any(e.def_ref.line > 2 for e in x_edges)  # Second def is line 4

    def test_augmented_assignment(self):
        """Track update from augmented assignment."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo():
    x = 1
    x += 2
    return x
"""
        dfg = extract_python_dfg(code, "foo")

        # x += 2 is both use and update
        updates = [r for r in dfg.var_refs if r.ref_type == "update"]
        assert any(r.name == "x" for r in updates)


class TestPythonDFGParameters:
    """Test DFG extraction with function parameters."""

    def test_parameter_is_definition(self):
        """Function parameters are definitions."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo(x, y):
    return x + y
"""
        dfg = extract_python_dfg(code, "foo")

        defs = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert any(r.name == "x" for r in defs)
        assert any(r.name == "y" for r in defs)

    def test_parameter_use(self):
        """Parameters used in body have def-use edges."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo(x):
    return x * 2
"""
        dfg = extract_python_dfg(code, "foo")

        x_edges = [e for e in dfg.dataflow_edges if e.var_name == "x"]
        assert len(x_edges) >= 1


class TestPythonDFGControlFlow:
    """Test DFG with control flow."""

    def test_cfg_aware_reaching_defs(self):
        """DFG should track reaching defs through CFG branches.

        The default extract_python_dfg should be CFG-aware, meaning
        definitions from BOTH if/else branches reach uses after merge.
        """
        from tldr.dfg_extractor import extract_python_dfg

        code = '''
def branch_test(cond):
    if cond:
        x = 1
    else:
        x = 2
    return x
'''
        dfg = extract_python_dfg(code, "branch_test")
        # The 'return x' should have edges from BOTH x definitions
        return_uses = [e for e in dfg.dataflow_edges if e.use_ref.line == 7]
        assert len(return_uses) >= 2, "Should see both branch defs reaching return"

    def test_if_branch_def(self):
        """Track definitions in if branches - both should reach use."""
        from tldr.dfg_extractor import extract_python_dfg_with_cfg

        code = """
def foo(cond):
    if cond:
        x = 1
    else:
        x = 2
    return x
"""
        dfg = extract_python_dfg_with_cfg(code, "foo")

        # Two definitions of x from branches
        x_defs = [r for r in dfg.var_refs if r.name == "x" and r.ref_type == "definition"]
        assert len(x_defs) == 2

        # CFG-based: BOTH definitions should reach the use (from both paths)
        x_edges = [e for e in dfg.dataflow_edges if e.var_name == "x"]
        assert len(x_edges) == 2  # Both branches reach the use

    def test_loop_def_use(self):
        """Track def-use in loops."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo():
    total = 0
    for i in range(10):
        total += i
    return total
"""
        dfg = extract_python_dfg(code, "foo")

        # i is defined by for loop
        i_defs = [r for r in dfg.var_refs if r.name == "i" and r.ref_type == "definition"]
        assert len(i_defs) >= 1

        # total has initial def and update
        total_refs = dfg.variables.get("total", [])
        assert len(total_refs) >= 2


class TestPythonDFGComplex:
    """Test complex DFG scenarios."""

    def test_nested_expressions(self):
        """Track uses in nested expressions."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo(a, b, c):
    return (a + b) * c
"""
        dfg = extract_python_dfg(code, "foo")

        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        use_names = {r.name for r in uses}
        assert use_names == {"a", "b", "c"}

    def test_function_call_args(self):
        """Track uses in function call arguments."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo(x):
    y = len(x)
    return y
"""
        dfg = extract_python_dfg(code, "foo")

        # x is used as argument to len()
        x_uses = [r for r in dfg.var_refs if r.name == "x" and r.ref_type == "use"]
        assert len(x_uses) >= 1

    def test_attribute_access(self):
        """Track uses in attribute access."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo(obj):
    return obj.value
"""
        dfg = extract_python_dfg(code, "foo")

        # obj is used
        obj_uses = [r for r in dfg.var_refs if r.name == "obj" and r.ref_type == "use"]
        assert len(obj_uses) >= 1

    def test_subscript_access(self):
        """Track uses in subscript access."""
        from tldr.dfg_extractor import extract_python_dfg

        code = """
def foo(arr, idx):
    return arr[idx]
"""
        dfg = extract_python_dfg(code, "foo")

        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        use_names = {r.name for r in uses}
        assert "arr" in use_names
        assert "idx" in use_names


# =============================================================================
# TypeScript DFG Tests
# =============================================================================

class TestTypeScriptDFGBasic:
    """Test TypeScript DFG extraction."""

    def test_simple_assignment(self):
        """Extract definition from let/const."""
        from tldr.dfg_extractor import extract_typescript_dfg, TREE_SITTER_AVAILABLE
        if not TREE_SITTER_AVAILABLE:
            pytest.skip("tree-sitter-typescript not available")

        code = """
function foo() {
    let x = 1;
    return x;
}
"""
        dfg = extract_typescript_dfg(code, "foo")

        defs = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert any(r.name == "x" for r in defs)

    def test_def_use_chain(self):
        """Build def-use chain for TypeScript."""
        from tldr.dfg_extractor import extract_typescript_dfg, TREE_SITTER_AVAILABLE
        if not TREE_SITTER_AVAILABLE:
            pytest.skip("tree-sitter-typescript not available")

        code = """
function foo() {
    let x = 1;
    let y = x + 2;
    return y;
}
"""
        dfg = extract_typescript_dfg(code, "foo")

        x_edges = [e for e in dfg.dataflow_edges if e.var_name == "x"]
        assert len(x_edges) >= 1


# =============================================================================
# Go DFG Tests
# =============================================================================

class TestGoDFGBasic:
    """Test Go DFG extraction."""

    def test_simple_assignment(self):
        """Extract definition from Go assignment."""
        from tldr.dfg_extractor import extract_go_dfg, TREE_SITTER_GO_AVAILABLE
        if not TREE_SITTER_GO_AVAILABLE:
            pytest.skip("tree-sitter-go not available")

        code = """
func foo() int {
    x := 1
    return x
}
"""
        dfg = extract_go_dfg(code, "foo")

        defs = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert any(r.name == "x" for r in defs)


# =============================================================================
# Rust DFG Tests
# =============================================================================

class TestRustDFGBasic:
    """Test Rust DFG extraction."""

    def test_simple_assignment(self):
        """Extract definition from Rust let."""
        from tldr.dfg_extractor import extract_rust_dfg, TREE_SITTER_RUST_AVAILABLE
        if not TREE_SITTER_RUST_AVAILABLE:
            pytest.skip("tree-sitter-rust not available")

        code = """
fn foo() -> i32 {
    let x = 1;
    x
}
"""
        dfg = extract_rust_dfg(code, "foo")

        defs = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert any(r.name == "x" for r in defs)
