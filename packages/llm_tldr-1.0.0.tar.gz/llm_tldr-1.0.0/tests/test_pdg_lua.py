"""Tests for Lua PDG extraction and program slicing (L5).

TDD Tests for Lua PDG support.
These tests should FAIL initially until Lua support is implemented.

Tests mirror the structure of test_pdg_ruby.py but for Lua language support.
"""
import os
import pytest

# Check if tree-sitter-lua is available
try:
    from tldr.cfg_extractor import TREE_SITTER_LUA_AVAILABLE
    LUA_AVAILABLE = TREE_SITTER_LUA_AVAILABLE
except ImportError:
    LUA_AVAILABLE = False

# Check if extract_lua_pdg is implemented
try:
    from tldr.pdg_extractor import extract_lua_pdg
    LUA_PDG_AVAILABLE = True
except ImportError:
    LUA_PDG_AVAILABLE = False
    extract_lua_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not LUA_AVAILABLE,
    reason="tree-sitter-lua not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_lua_path():
    """Path to sample.lua fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.lua")


@pytest.fixture
def sample_lua_code(sample_lua_path):
    """Load sample.lua fixture code."""
    with open(sample_lua_path) as f:
        return f.read()


@pytest.fixture
def simple_lua_code():
    """Simple Lua code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
-- =============================================================================
-- Simple Lua test fixture for PDG extraction
-- This code is used to test basic PDG node and edge extraction.
-- The add function has simple data flow: a -> c, b -> c, c -> return
-- The comments here ensure the code is longer than 500 characters so it is
-- not mistakenly treated as a file path by _resolve_source heuristic.
-- =============================================================================
function add(a, b)
    local c = a + b
    return c
end
'''


@pytest.fixture
def chained_lua_code():
    """Lua code with chained dependencies for slice testing."""
    return '''
-- =============================================================================
-- Chained Lua test fixture for PDG extraction and slicing
-- This tests forward and backward slices through a dependency chain.
-- Dependencies: x -> a -> b -> c -> return
-- =============================================================================
function compute(x)
    local a = x + 1     -- line 8: a depends on x
    local b = a * 2     -- line 9: b depends on a
    local c = b + 3     -- line 10: c depends on b
    return c            -- line 11: return depends on c
end
'''


# =============================================================================
# Tests for extract_lua_pdg()
# =============================================================================

class TestExtractLuaPDG:
    """Test extract_lua_pdg() function."""

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_extract_lua_pdg_basic(self, sample_lua_code):
        """Test basic PDG extraction from sample.lua calculate function."""
        pdg = extract_lua_pdg(sample_lua_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_extract_lua_pdg_has_nodes(self, sample_lua_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_lua_pdg(sample_lua_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_extract_lua_pdg_has_edges(self, sample_lua_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_lua_pdg(sample_lua_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_extract_lua_pdg_sum_function(self, sample_lua_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_lua_pdg(sample_lua_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_extract_lua_pdg_nonexistent_function(self, sample_lua_code):
        """Test that nonexistent function returns None."""
        pdg = extract_lua_pdg(sample_lua_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for Lua Program Slicing
# =============================================================================

class TestLuaProgramSlicing:
    """Test program slicing for Lua code."""

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_lua_backward_slice(self, sample_lua_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_lua_pdg(sample_lua_code, "sum")

        assert pdg is not None
        # Line 28 is "return total" in sample.lua
        slice_lines = pdg.backward_slice(line=28)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_lua_forward_slice(self, chained_lua_code):
        """Test forward slice from first assignment."""
        pdg = extract_lua_pdg(chained_lua_code, "compute")

        assert pdg is not None
        # Forward slice from "local a = x + 1" (line 8)
        slice_lines = pdg.forward_slice(line=8)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_lua_slice_returns_set(self, simple_lua_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_lua_pdg(simple_lua_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=11)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for Lua PDG via API
# =============================================================================

class TestLuaPDGAPI:
    """Test Lua PDG integration via tldr.api functions."""

    def test_lua_get_pdg_context(self, sample_lua_path):
        """Test get_pdg_context() for Lua code via file path."""
        result = get_pdg_context(sample_lua_path, "calculate", language="lua")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_lua_get_slice_backward(self, sample_lua_path):
        """Test get_slice() backward for Lua code via file path."""
        # Backward slice from return statement in sum function
        lines = get_slice(
            sample_lua_path, "sum", line=28,
            direction="backward", language="lua"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_lua_get_slice_forward(self, sample_lua_path):
        """Test get_slice() forward for Lua code via file path."""
        lines = get_slice(
            sample_lua_path, "compute", line=46,
            direction="forward", language="lua"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestLuaPDGIntegration:
    """Integration tests for Lua PDG."""

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_pdg_from_file(self, sample_lua_path, sample_lua_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_lua_pdg(sample_lua_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not LUA_PDG_AVAILABLE, reason="extract_lua_pdg not implemented")
    def test_pdg_to_dict(self, simple_lua_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_lua_pdg(simple_lua_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
