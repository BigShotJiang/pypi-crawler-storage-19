"""Tests for Go CFG extraction."""
import pytest

# Check if tree-sitter-go is available
try:
    from tldr.cfg_extractor import extract_go_cfg, TREE_SITTER_GO_AVAILABLE, TREE_SITTER_AVAILABLE
    GO_AVAILABLE = TREE_SITTER_GO_AVAILABLE and TREE_SITTER_AVAILABLE
except ImportError:
    GO_AVAILABLE = False


pytestmark = pytest.mark.skipif(not GO_AVAILABLE, reason="tree-sitter-go not available")


@pytest.fixture
def simple_if_code():
    return '''
package main

func check(x int) string {
    if x > 0 {
        return "positive"
    }
    return "non-positive"
}
'''


@pytest.fixture
def for_loop_code():
    return '''
package main

func count(n int) int {
    i := 0
    for i < n {
        i++
    }
    return i
}
'''


@pytest.fixture
def range_loop_code():
    return '''
package main

func sum(items []int) int {
    total := 0
    for _, item := range items {
        total += item
    }
    return total
}
'''


@pytest.fixture
def nested_code():
    return '''
package main

func process(items []Item) {
    for _, item := range items {
        if item.Valid {
            handle(item)
        } else {
            skip(item)
        }
    }
}
'''


@pytest.fixture
def break_continue_code():
    return '''
package main

func findFirst(items []int, target int) int {
    for i, item := range items {
        if item == target {
            return i
        }
        if item < 0 {
            continue
        }
        process(item)
    }
    return -1
}
'''


class TestGoCFG:
    """Test Go CFG extraction."""

    def test_simple_function_has_entry_and_exit(self, simple_if_code):
        cfg = extract_go_cfg(simple_if_code, "check")
        assert cfg.entry_block_id is not None
        assert len(cfg.exit_block_ids) >= 1

    def test_if_creates_branch(self, simple_if_code):
        cfg = extract_go_cfg(simple_if_code, "check")
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 2

    def test_for_creates_back_edge(self, for_loop_code):
        cfg = extract_go_cfg(for_loop_code, "count")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_for_has_loop_header(self, for_loop_code):
        cfg = extract_go_cfg(for_loop_code, "count")
        headers = [b for b in cfg.blocks if b.block_type == "loop_header"]
        assert len(headers) >= 1

    def test_range_loop_creates_back_edge(self, range_loop_code):
        cfg = extract_go_cfg(range_loop_code, "sum")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_cyclomatic_complexity_simple_if(self, simple_if_code):
        cfg = extract_go_cfg(simple_if_code, "check")
        assert cfg.cyclomatic_complexity == 2

    def test_cyclomatic_complexity_for(self, for_loop_code):
        cfg = extract_go_cfg(for_loop_code, "count")
        assert cfg.cyclomatic_complexity == 2

    def test_nested_complexity(self, nested_code):
        cfg = extract_go_cfg(nested_code, "process")
        # for + if + 1 = 3
        assert cfg.cyclomatic_complexity == 3

    def test_cfg_to_dict(self, simple_if_code):
        cfg = extract_go_cfg(simple_if_code, "check")
        d = cfg.to_dict()
        assert "blocks" in d
        assert "edges" in d
        assert "cyclomatic_complexity" in d
        assert d["function"] == "check"

    def test_continue_creates_edge(self, break_continue_code):
        cfg = extract_go_cfg(break_continue_code, "findFirst")
        continue_edges = [e for e in cfg.edges if e.edge_type == "continue"]
        assert len(continue_edges) >= 1

    def test_function_not_found_raises(self):
        code = '''
package main

func foo() {}
'''
        with pytest.raises(ValueError, match="not found"):
            extract_go_cfg(code, "bar")


class TestGoCFGEdgeCases:
    """Edge cases for Go CFG."""

    def test_traditional_for_loop(self):
        code = '''
package main

func countTo(n int) int {
    sum := 0
    for i := 0; i < n; i++ {
        sum += i
    }
    return sum
}
'''
        cfg = extract_go_cfg(code, "countTo")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 1

    def test_if_else_if(self):
        code = '''
package main

func grade(score int) string {
    if score >= 90 {
        return "A"
    } else if score >= 80 {
        return "B"
    } else {
        return "F"
    }
}
'''
        cfg = extract_go_cfg(code, "grade")
        branch_edges = [e for e in cfg.edges if e.edge_type in ("true", "false")]
        assert len(branch_edges) >= 4

    def test_nested_loops(self):
        code = '''
package main

func matrix(rows, cols int) {
    for i := 0; i < rows; i++ {
        for j := 0; j < cols; j++ {
            process(i, j)
        }
    }
}
'''
        cfg = extract_go_cfg(code, "matrix")
        back_edges = [e for e in cfg.edges if e.edge_type == "back_edge"]
        assert len(back_edges) >= 2

    def test_switch_not_handled_yet(self):
        # Switch statements are complex - just verify we don't crash
        code = '''
package main

func classify(x int) string {
    switch {
    case x < 0:
        return "negative"
    case x == 0:
        return "zero"
    default:
        return "positive"
    }
}
'''
        cfg = extract_go_cfg(code, "classify")
        assert cfg.entry_block_id is not None
