"""
TDD tests for P2: Monorepo Scoping - Workspace Configuration.

Tests written BEFORE implementation per TDD discipline.
These tests cover the workspace module that provides:
- Workspace config file parsing (.claude/workspace.json)
- Path filtering by activePackages
- Path exclusion by glob patterns
- Combined filtering for monorepo scoping
"""

import json
import tempfile
from pathlib import Path

import pytest


class TestLoadWorkspaceConfig:
    """Test suite for loading workspace configuration."""

    def test_load_valid_workspace_config(self, tmp_path: Path):
        """Should parse valid workspace.json correctly."""
        from tldr.workspace import load_workspace_config

        # Create .claude/workspace.json
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        workspace_file = claude_dir / "workspace.json"
        workspace_file.write_text(json.dumps({
            "activePackages": ["packages/auth", "services/api"],
            "excludePatterns": ["**/generated/**", "**/vendor/**"]
        }))

        config = load_workspace_config(tmp_path)

        assert config.active_packages == ["packages/auth", "services/api"]
        assert config.exclude_patterns == ["**/generated/**", "**/vendor/**"]

    def test_load_missing_workspace_returns_defaults(self, tmp_path: Path):
        """Missing workspace.json should return default config (index everything)."""
        from tldr.workspace import load_workspace_config

        config = load_workspace_config(tmp_path)

        # Default: no active packages filter (index everything)
        assert config.active_packages == []
        # Default: common excludes
        assert "**/node_modules/**" in config.exclude_patterns

    def test_load_empty_active_packages_indexes_everything(self, tmp_path: Path):
        """Empty activePackages should mean index everything."""
        from tldr.workspace import load_workspace_config

        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        workspace_file = claude_dir / "workspace.json"
        workspace_file.write_text(json.dumps({
            "activePackages": [],
            "excludePatterns": []
        }))

        config = load_workspace_config(tmp_path)

        assert config.active_packages == []
        # Empty exclude patterns from config
        assert config.exclude_patterns == []

    def test_load_invalid_json_returns_defaults(self, tmp_path: Path):
        """Invalid JSON should return default config."""
        from tldr.workspace import load_workspace_config

        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        workspace_file = claude_dir / "workspace.json"
        workspace_file.write_text("not valid json {{{")

        config = load_workspace_config(tmp_path)

        # Should fallback to defaults, not crash
        assert config.active_packages == []
        assert "**/node_modules/**" in config.exclude_patterns

    def test_load_partial_config_uses_defaults_for_missing(self, tmp_path: Path):
        """Partial config should use defaults for missing fields."""
        from tldr.workspace import load_workspace_config

        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        workspace_file = claude_dir / "workspace.json"
        # Only activePackages, no excludePatterns
        workspace_file.write_text(json.dumps({
            "activePackages": ["packages/core"]
        }))

        config = load_workspace_config(tmp_path)

        assert config.active_packages == ["packages/core"]
        # Should have default exclude patterns
        assert "**/node_modules/**" in config.exclude_patterns

    def test_load_config_handles_string_path(self, tmp_path: Path):
        """Should accept string path as well as Path object."""
        from tldr.workspace import load_workspace_config

        # No workspace.json, just verify it doesn't crash with str path
        config = load_workspace_config(str(tmp_path))

        assert config.active_packages == []


class TestShouldIncludePath:
    """Test suite for path filtering logic."""

    def test_include_path_in_active_package(self, tmp_path: Path):
        """Path within active package should be included."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/auth", "services/api"],
            exclude_patterns=[]
        )

        assert should_include_path("packages/auth/src/login.py", config) is True
        assert should_include_path("services/api/handler.ts", config) is True

    def test_exclude_path_not_in_active_package(self, tmp_path: Path):
        """Path outside active packages should be excluded."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/auth"],
            exclude_patterns=[]
        )

        # Different package
        assert should_include_path("packages/billing/invoice.py", config) is False
        # Root level file
        assert should_include_path("main.py", config) is False

    def test_include_all_when_no_active_packages(self, tmp_path: Path):
        """Empty activePackages should include all paths."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=[],  # Empty = include all
            exclude_patterns=[]
        )

        assert should_include_path("any/path/file.py", config) is True
        assert should_include_path("root.py", config) is True

    def test_exclude_path_matching_exclude_pattern(self, tmp_path: Path):
        """Path matching exclude pattern should be excluded."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=[],
            exclude_patterns=["**/generated/**", "**/vendor/**"]
        )

        assert should_include_path("src/generated/models.py", config) is False
        assert should_include_path("packages/auth/vendor/lib.py", config) is False

    def test_include_path_not_matching_exclude_pattern(self, tmp_path: Path):
        """Path not matching exclude patterns should be included."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=[],
            exclude_patterns=["**/generated/**"]
        )

        assert should_include_path("src/models.py", config) is True
        assert should_include_path("packages/auth/login.py", config) is True

    def test_combined_active_and_exclude_patterns(self, tmp_path: Path):
        """Should combine activePackages AND excludePatterns."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/auth"],
            exclude_patterns=["**/generated/**", "**/node_modules/**"]
        )

        # In active package, not excluded
        assert should_include_path("packages/auth/login.py", config) is True

        # In active package, but excluded
        assert should_include_path("packages/auth/generated/models.py", config) is False

        # Not in active package
        assert should_include_path("packages/billing/invoice.py", config) is False

    def test_exclude_node_modules_by_default(self, tmp_path: Path):
        """node_modules should be excluded with default patterns."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=[],
            exclude_patterns=["**/node_modules/**"]
        )

        assert should_include_path("node_modules/lodash/index.js", config) is False
        assert should_include_path("packages/ui/node_modules/react/index.js", config) is False


class TestFilterPaths:
    """Test suite for batch path filtering."""

    def test_filter_paths_by_active_packages(self, tmp_path: Path):
        """Should filter list of paths by activePackages."""
        from tldr.workspace import WorkspaceConfig, filter_paths

        config = WorkspaceConfig(
            active_packages=["packages/auth"],
            exclude_patterns=[]
        )

        paths = [
            "packages/auth/login.py",
            "packages/auth/logout.py",
            "packages/billing/invoice.py",
            "services/api/handler.py"
        ]

        filtered = filter_paths(paths, config)

        assert filtered == ["packages/auth/login.py", "packages/auth/logout.py"]

    def test_filter_paths_excludes_patterns(self, tmp_path: Path):
        """Should exclude paths matching excludePatterns."""
        from tldr.workspace import WorkspaceConfig, filter_paths

        config = WorkspaceConfig(
            active_packages=[],
            exclude_patterns=["**/generated/**", "**/*.test.py"]
        )

        paths = [
            "src/main.py",
            "src/generated/models.py",
            "src/utils.test.py",
            "src/utils.py"
        ]

        filtered = filter_paths(paths, config)

        assert "src/main.py" in filtered
        assert "src/utils.py" in filtered
        assert "src/generated/models.py" not in filtered
        assert "src/utils.test.py" not in filtered

    def test_filter_paths_combined(self, tmp_path: Path):
        """Should combine active package and exclude pattern filtering."""
        from tldr.workspace import WorkspaceConfig, filter_paths

        config = WorkspaceConfig(
            active_packages=["packages/auth", "packages/billing"],
            exclude_patterns=["**/generated/**"]
        )

        paths = [
            "packages/auth/login.py",
            "packages/auth/generated/types.py",
            "packages/billing/invoice.py",
            "packages/ui/button.py",
            "services/api/handler.py"
        ]

        filtered = filter_paths(paths, config)

        assert filtered == ["packages/auth/login.py", "packages/billing/invoice.py"]

    def test_filter_paths_empty_list(self, tmp_path: Path):
        """Empty path list should return empty list."""
        from tldr.workspace import WorkspaceConfig, filter_paths

        config = WorkspaceConfig(
            active_packages=["packages/auth"],
            exclude_patterns=[]
        )

        filtered = filter_paths([], config)

        assert filtered == []

    def test_filter_paths_all_excluded(self, tmp_path: Path):
        """Should handle case where all paths are excluded."""
        from tldr.workspace import WorkspaceConfig, filter_paths

        config = WorkspaceConfig(
            active_packages=["packages/nonexistent"],
            exclude_patterns=[]
        )

        paths = [
            "packages/auth/login.py",
            "packages/billing/invoice.py"
        ]

        filtered = filter_paths(paths, config)

        assert filtered == []


class TestWorkspaceConfigDataclass:
    """Test suite for WorkspaceConfig dataclass."""

    def test_workspace_config_creation(self):
        """Should create WorkspaceConfig with correct fields."""
        from tldr.workspace import WorkspaceConfig

        config = WorkspaceConfig(
            active_packages=["pkg1", "pkg2"],
            exclude_patterns=["*.test.py"]
        )

        assert config.active_packages == ["pkg1", "pkg2"]
        assert config.exclude_patterns == ["*.test.py"]

    def test_workspace_config_default_factory(self):
        """Should have default empty lists if not provided."""
        from tldr.workspace import WorkspaceConfig

        # Test with explicit empty lists
        config = WorkspaceConfig(active_packages=[], exclude_patterns=[])

        assert config.active_packages == []
        assert config.exclude_patterns == []


class TestEdgeCases:
    """Test suite for edge cases and special scenarios."""

    def test_trailing_slashes_in_active_packages(self, tmp_path: Path):
        """Should handle trailing slashes in activePackages."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/auth/"],
            exclude_patterns=[]
        )

        assert should_include_path("packages/auth/login.py", config) is True

    def test_relative_path_normalization(self, tmp_path: Path):
        """Should handle paths with ./ prefix."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/auth"],
            exclude_patterns=[]
        )

        assert should_include_path("./packages/auth/login.py", config) is True

    def test_windows_style_paths(self, tmp_path: Path):
        """Should handle Windows-style backslash paths."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/auth"],
            exclude_patterns=[]
        )

        # The implementation should normalize these
        assert should_include_path("packages\\auth\\login.py", config) is True

    def test_case_sensitivity(self, tmp_path: Path):
        """Path matching should be case-sensitive on Unix."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/Auth"],
            exclude_patterns=[]
        )

        # Different case should not match (Unix is case-sensitive)
        assert should_include_path("packages/auth/login.py", config) is False
        assert should_include_path("packages/Auth/login.py", config) is True

    def test_nested_active_package_paths(self, tmp_path: Path):
        """Should handle deeply nested paths in active packages."""
        from tldr.workspace import WorkspaceConfig, should_include_path

        config = WorkspaceConfig(
            active_packages=["packages/auth/src/core"],
            exclude_patterns=[]
        )

        assert should_include_path("packages/auth/src/core/login.py", config) is True
        assert should_include_path("packages/auth/src/utils.py", config) is False

    def test_absolute_paths_converted_to_relative(self, tmp_path: Path):
        """Should handle absolute paths by treating them relative to config."""
        from tldr.workspace import WorkspaceConfig, filter_paths

        config = WorkspaceConfig(
            active_packages=["packages/auth"],
            exclude_patterns=[]
        )

        # Absolute paths - implementation should handle these
        paths = [
            "/home/user/project/packages/auth/login.py",
            "/home/user/project/packages/billing/invoice.py"
        ]

        # The filter_paths function might need a root parameter
        # or should work with relative paths extracted from absolute ones
        # For now, test that it doesn't crash
        filtered = filter_paths(paths, config)
        # Behavior TBD based on implementation decisions


class TestIntegrationWithScanProject:
    """Test integration with cross_file_calls.scan_project."""

    def test_workspace_config_filters_scan_results(self, tmp_path: Path):
        """Workspace config should filter scan_project results."""
        from tldr.workspace import load_workspace_config, filter_paths

        # Create monorepo structure
        (tmp_path / "packages" / "auth" / "src").mkdir(parents=True)
        (tmp_path / "packages" / "billing" / "src").mkdir(parents=True)
        (tmp_path / "services" / "api").mkdir(parents=True)

        (tmp_path / "packages" / "auth" / "src" / "login.py").write_text("def login(): pass")
        (tmp_path / "packages" / "billing" / "src" / "invoice.py").write_text("def invoice(): pass")
        (tmp_path / "services" / "api" / "handler.py").write_text("def handle(): pass")

        # Create workspace config
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "workspace.json").write_text(json.dumps({
            "activePackages": ["packages/auth"],
            "excludePatterns": []
        }))

        # Load config and filter
        config = load_workspace_config(tmp_path)

        # Simulate scan results (relative paths)
        all_files = [
            "packages/auth/src/login.py",
            "packages/billing/src/invoice.py",
            "services/api/handler.py"
        ]

        filtered = filter_paths(all_files, config)

        assert filtered == ["packages/auth/src/login.py"]

    def test_workspace_config_with_generated_exclusion(self, tmp_path: Path):
        """Should exclude generated directories in monorepo."""
        from tldr.workspace import load_workspace_config, filter_paths

        # Create monorepo with generated code
        (tmp_path / "packages" / "auth" / "src").mkdir(parents=True)
        (tmp_path / "packages" / "auth" / "generated").mkdir(parents=True)

        (tmp_path / "packages" / "auth" / "src" / "login.py").write_text("")
        (tmp_path / "packages" / "auth" / "generated" / "types.py").write_text("")

        # Create workspace config
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "workspace.json").write_text(json.dumps({
            "activePackages": ["packages/auth"],
            "excludePatterns": ["**/generated/**"]
        }))

        config = load_workspace_config(tmp_path)

        all_files = [
            "packages/auth/src/login.py",
            "packages/auth/generated/types.py"
        ]

        filtered = filter_paths(all_files, config)

        assert filtered == ["packages/auth/src/login.py"]


class TestIntegrationWithCallGraph:
    """Test integration with cross_file_calls.build_project_call_graph."""

    def test_call_graph_respects_workspace_config(self, tmp_path: Path):
        """build_project_call_graph should only index activePackages."""
        from tldr.cross_file_calls import build_project_call_graph

        # Create monorepo structure
        (tmp_path / "packages" / "auth").mkdir(parents=True)
        (tmp_path / "packages" / "billing").mkdir(parents=True)

        # Auth package (in activePackages)
        (tmp_path / "packages" / "auth" / "login.py").write_text('''
def login():
    return validate()

def validate():
    return True
''')

        # Billing package (NOT in activePackages)
        (tmp_path / "packages" / "billing" / "invoice.py").write_text('''
def create_invoice():
    return process()

def process():
    return "done"
''')

        # Create workspace config that only includes auth
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "workspace.json").write_text(json.dumps({
            "activePackages": ["packages/auth"],
            "excludePatterns": []
        }))

        # Build call graph
        graph = build_project_call_graph(tmp_path, language="python")

        # Should have edges from auth package
        edges = list(graph.edges)
        auth_edges = [e for e in edges if "auth" in e[0]]
        billing_edges = [e for e in edges if "billing" in e[0]]

        assert len(auth_edges) > 0, "Should have edges from auth package"
        assert len(billing_edges) == 0, "Should NOT have edges from billing package"

    def test_call_graph_excludes_patterns(self, tmp_path: Path):
        """build_project_call_graph should exclude files matching excludePatterns."""
        from tldr.cross_file_calls import build_project_call_graph

        # Create structure with generated code
        (tmp_path / "src").mkdir()
        (tmp_path / "generated").mkdir()

        # Source code
        (tmp_path / "src" / "main.py").write_text('''
def main():
    return helper()

def helper():
    return 42
''')

        # Generated code (should be excluded)
        (tmp_path / "generated" / "models.py").write_text('''
def auto_func():
    return gen_helper()

def gen_helper():
    return "generated"
''')

        # Create workspace config that excludes generated
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "workspace.json").write_text(json.dumps({
            "activePackages": [],
            "excludePatterns": ["**/generated/**"]
        }))

        # Build call graph
        graph = build_project_call_graph(tmp_path, language="python")

        # Should have edges from src but not generated
        edges = list(graph.edges)
        src_edges = [e for e in edges if "src" in e[0]]
        gen_edges = [e for e in edges if "generated" in e[0]]

        assert len(src_edges) > 0, "Should have edges from src"
        assert len(gen_edges) == 0, "Should NOT have edges from generated"

    def test_call_graph_with_no_workspace_config(self, tmp_path: Path):
        """Without workspace.json, should index everything (with default excludes)."""
        from tldr.cross_file_calls import build_project_call_graph

        # Create simple structure without workspace.json
        (tmp_path / "main.py").write_text('''
def main():
    return helper()

def helper():
    return 42
''')

        # NO workspace.json - should still work
        graph = build_project_call_graph(tmp_path, language="python")

        # Should have the edge
        assert ("main.py", "main", "main.py", "helper") in graph.edges

    def test_call_graph_disable_workspace_config(self, tmp_path: Path):
        """use_workspace_config=False should ignore workspace.json."""
        from tldr.cross_file_calls import build_project_call_graph

        # Create structure
        (tmp_path / "packages" / "auth").mkdir(parents=True)
        (tmp_path / "packages" / "billing").mkdir(parents=True)

        (tmp_path / "packages" / "auth" / "login.py").write_text('''
def login():
    return True
''')

        (tmp_path / "packages" / "billing" / "invoice.py").write_text('''
def invoice():
    return True
''')

        # Create restrictive workspace config
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        (claude_dir / "workspace.json").write_text(json.dumps({
            "activePackages": ["packages/auth"],
            "excludePatterns": []
        }))

        # Build call graph WITH workspace config disabled
        graph = build_project_call_graph(tmp_path, language="python", use_workspace_config=False)

        # Should have edges from BOTH packages (workspace config ignored)
        edges = list(graph.edges)
        # With use_workspace_config=False, billing should be included
        # (though in this case there are no cross-file calls, just checking files are scanned)
