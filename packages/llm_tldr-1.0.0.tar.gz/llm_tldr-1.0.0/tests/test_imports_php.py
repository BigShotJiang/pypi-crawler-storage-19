"""Tests for PHP import/include parsing.

TDD tests for PHP language support in TLDR.
PHP import types:
- use_declaration (use statements)
- include_expression (include, include_once)
- require_expression (require, require_once)
"""
import pytest
from pathlib import Path

# Check if tree-sitter-php is available
try:
    from tldr.cross_file_calls import parse_php_imports, TREE_SITTER_PHP_AVAILABLE
    PHP_AVAILABLE = TREE_SITTER_PHP_AVAILABLE
except ImportError:
    PHP_AVAILABLE = False


pytestmark = pytest.mark.skipif(not PHP_AVAILABLE, reason="tree-sitter-php not available")


@pytest.fixture
def use_statements_file(tmp_path):
    """Create a PHP file with use statements."""
    code = '''<?php
namespace App\\Services;

use App\\Models\\User;
use App\\Models\\Post;
use Illuminate\\Support\\Collection;

class UserService {
    public function getUsers(): Collection {
        return User::all();
    }
}
'''
    file_path = tmp_path / "UserService.php"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def grouped_use_file(tmp_path):
    """Create a PHP file with grouped use statements."""
    code = '''<?php
namespace App\\Services;

use App\\Models\\{User, Post, Comment};
use App\\Helpers\\{StringHelper, ArrayHelper};

class ContentService {
    public function process(): void {}
}
'''
    file_path = tmp_path / "ContentService.php"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def aliased_use_file(tmp_path):
    """Create a PHP file with aliased use statements."""
    code = '''<?php
namespace App\\Services;

use App\\Models\\User as UserModel;
use Illuminate\\Support\\Facades\\Cache as CacheFacade;
use Carbon\\Carbon as DateTime;

class CacheService {
    public function getCachedUser(): UserModel {
        return CacheFacade::get('user');
    }
}
'''
    file_path = tmp_path / "CacheService.php"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def require_include_file(tmp_path):
    """Create a PHP file with require/include statements."""
    code = '''<?php
require_once 'vendor/autoload.php';
require 'config/database.php';
include 'helpers/functions.php';
include_once 'helpers/constants.php';

function bootstrap(): void {
    // Initialize application
}
'''
    file_path = tmp_path / "bootstrap.php"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create a PHP file with mixed import types."""
    code = '''<?php
namespace App\\Console;

require_once __DIR__ . '/../vendor/autoload.php';

use App\\Models\\User;
use App\\Services\\{UserService, AuthService};
use Illuminate\\Console\\Command;

include 'helpers.php';

class SyncCommand extends Command {
    public function handle(): void {}
}
'''
    file_path = tmp_path / "SyncCommand.php"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def function_use_file(tmp_path):
    """Create a PHP file with function/const use statements."""
    code = '''<?php
namespace App\\Utils;

use function array_map;
use function array_filter;
use const PHP_EOL;
use const PHP_VERSION;

function processArray(array $items): array {
    return array_map(fn($x) => $x * 2, $items);
}
'''
    file_path = tmp_path / "Utils.php"
    file_path.write_text(code)
    return file_path


class TestUseStatements:
    """Test use statement parsing."""

    def test_parses_simple_use(self, use_statements_file):
        imports = parse_php_imports(use_statements_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        assert any('User' in m or 'App\\Models\\User' in m for m in modules)
        assert any('Collection' in m for m in modules)

    def test_grouped_use(self, grouped_use_file):
        imports = parse_php_imports(grouped_use_file)
        # Grouped use should expand to individual imports
        assert len(imports) >= 5
        modules = [imp['module'] for imp in imports]
        assert any('User' in m for m in modules)
        assert any('Post' in m for m in modules)
        assert any('Comment' in m for m in modules)

    def test_aliased_use(self, aliased_use_file):
        imports = parse_php_imports(aliased_use_file)
        assert len(imports) >= 3
        # Should capture the original module names
        modules = [imp['module'] for imp in imports]
        assert any('User' in m for m in modules)
        assert any('Cache' in m for m in modules)


class TestRequireInclude:
    """Test require/include parsing."""

    def test_parses_require_include(self, require_include_file):
        imports = parse_php_imports(require_include_file)
        # Should capture all require/include variants
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        assert any('autoload' in m for m in modules)
        assert any('functions' in m or 'helpers' in m for m in modules)

    def test_require_once_detected(self, require_include_file):
        imports = parse_php_imports(require_include_file)
        modules = [imp['module'] for imp in imports]
        assert any('autoload' in m for m in modules)


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_php_imports(mixed_imports_file)
        # Should have both use statements and require/include
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('User' in m for m in modules)
        assert any('autoload' in m or 'vendor' in m for m in modules)

    def test_function_const_use(self, function_use_file):
        imports = parse_php_imports(function_use_file)
        # Function and const imports should be captured
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        assert any('array_map' in m or 'PHP_EOL' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "Empty.php"
        file_path.write_text("<?php\nclass Empty {}")
        imports = parse_php_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "NonExistent.php"
        imports = parse_php_imports(file_path)
        assert imports == []

    def test_only_namespace(self, tmp_path):
        code = '''<?php
namespace App\\Services;

class NoImports {
    public function test(): void {}
}
'''
        file_path = tmp_path / "NoImports.php"
        file_path.write_text(code)
        imports = parse_php_imports(file_path)
        assert imports == []

    def test_commented_imports(self, tmp_path):
        code = '''<?php
// use App\\Models\\Commented;
/* require 'commented.php'; */
use App\\Models\\Actual;

class Test {}
'''
        file_path = tmp_path / "Test.php"
        file_path.write_text(code)
        imports = parse_php_imports(file_path)
        modules = [imp['module'] for imp in imports]
        # Should only have Actual, not commented ones
        assert len([m for m in modules if 'Actual' in m]) >= 1
        assert not any('Commented' in m for m in modules)
