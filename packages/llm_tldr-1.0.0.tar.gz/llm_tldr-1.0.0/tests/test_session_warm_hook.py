"""
TDD tests for P1: Auto Background Warming.

Tests written BEFORE implementation per TDD discipline.
These tests cover the session_warm module that provides:
- Cache staleness detection
- Source file counting
- Freshness message generation
- Background warming trigger logic
"""

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestCacheStaleness:
    """Test suite for cache staleness detection."""

    def test_is_cache_stale_missing_cache_returns_true(self, tmp_path: Path):
        """Missing cache file should be considered stale."""
        from tldr.session_warm import is_cache_stale

        # No .tldr/cache/call_graph.json exists
        result = is_cache_stale(tmp_path)
        assert result is True, "Missing cache should be stale"

    def test_is_cache_stale_old_cache_returns_true(self, tmp_path: Path):
        """Cache older than max_age_hours should be stale."""
        from tldr.session_warm import is_cache_stale

        # Create old cache (25 hours old)
        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        old_timestamp = time.time() - (25 * 3600)  # 25 hours ago
        cache_data = {"edges": [], "timestamp": old_timestamp}
        cache_file.write_text(json.dumps(cache_data))

        result = is_cache_stale(tmp_path, max_age_hours=24)
        assert result is True, "Cache >24h old should be stale"

    def test_is_cache_stale_fresh_cache_returns_false(self, tmp_path: Path):
        """Cache younger than max_age_hours should not be stale."""
        from tldr.session_warm import is_cache_stale

        # Create fresh cache (4 hours old)
        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        fresh_timestamp = time.time() - (4 * 3600)  # 4 hours ago
        cache_data = {"edges": [], "timestamp": fresh_timestamp}
        cache_file.write_text(json.dumps(cache_data))

        result = is_cache_stale(tmp_path, max_age_hours=24)
        assert result is False, "Cache <24h old should not be stale"

    def test_is_cache_stale_custom_max_age(self, tmp_path: Path):
        """Custom max_age_hours should be respected."""
        from tldr.session_warm import is_cache_stale

        # Create cache 2 hours old
        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        two_hours_ago = time.time() - (2 * 3600)
        cache_data = {"edges": [], "timestamp": two_hours_ago}
        cache_file.write_text(json.dumps(cache_data))

        # With max_age=1, it should be stale
        assert is_cache_stale(tmp_path, max_age_hours=1) is True
        # With max_age=4, it should be fresh
        assert is_cache_stale(tmp_path, max_age_hours=4) is False

    def test_is_cache_stale_invalid_json_returns_true(self, tmp_path: Path):
        """Invalid JSON in cache file should be considered stale."""
        from tldr.session_warm import is_cache_stale

        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"
        cache_file.write_text("not valid json")

        result = is_cache_stale(tmp_path)
        assert result is True, "Invalid JSON cache should be stale"

    def test_is_cache_stale_missing_timestamp_returns_true(self, tmp_path: Path):
        """Cache without timestamp field should be considered stale."""
        from tldr.session_warm import is_cache_stale

        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"
        cache_file.write_text(json.dumps({"edges": []}))  # No timestamp

        result = is_cache_stale(tmp_path)
        assert result is True, "Cache without timestamp should be stale"


class TestSourceFileCounting:
    """Test suite for source file counting."""

    def test_count_source_files_empty_dir(self, tmp_path: Path):
        """Empty directory should return 0."""
        from tldr.session_warm import count_source_files

        result = count_source_files(tmp_path)
        assert result == 0

    def test_count_source_files_counts_python(self, tmp_path: Path):
        """Should count .py files."""
        from tldr.session_warm import count_source_files

        (tmp_path / "a.py").write_text("")
        (tmp_path / "b.py").write_text("")
        (tmp_path / "c.py").write_text("")

        result = count_source_files(tmp_path)
        assert result == 3

    def test_count_source_files_nested_dirs(self, tmp_path: Path):
        """Should count files in nested directories."""
        from tldr.session_warm import count_source_files

        (tmp_path / "a.py").write_text("")
        (tmp_path / "subdir").mkdir()
        (tmp_path / "subdir" / "b.py").write_text("")
        (tmp_path / "subdir" / "nested").mkdir()
        (tmp_path / "subdir" / "nested" / "c.py").write_text("")

        result = count_source_files(tmp_path)
        assert result == 3

    def test_count_source_files_ignores_non_python(self, tmp_path: Path):
        """Should not count non-Python files."""
        from tldr.session_warm import count_source_files

        (tmp_path / "a.py").write_text("")
        (tmp_path / "b.txt").write_text("")
        (tmp_path / "c.js").write_text("")
        (tmp_path / "d.json").write_text("")

        result = count_source_files(tmp_path)
        assert result == 1

    def test_count_source_files_early_exit_at_max(self, tmp_path: Path):
        """Should stop counting early when max_count is reached."""
        from tldr.session_warm import count_source_files

        # Create 10 Python files
        for i in range(10):
            (tmp_path / f"file{i}.py").write_text("")

        # With max_count=5, should return 5 (early exit)
        result = count_source_files(tmp_path, max_count=5)
        assert result == 5, "Should stop at max_count"

    def test_count_source_files_ignores_venv(self, tmp_path: Path):
        """Should ignore common virtual environment directories."""
        from tldr.session_warm import count_source_files

        (tmp_path / "main.py").write_text("")
        (tmp_path / "venv").mkdir()
        (tmp_path / "venv" / "lib.py").write_text("")
        (tmp_path / ".venv").mkdir()
        (tmp_path / ".venv" / "pip.py").write_text("")
        (tmp_path / "node_modules").mkdir()
        (tmp_path / "node_modules" / "fake.py").write_text("")

        result = count_source_files(tmp_path)
        assert result == 1, "Should only count main.py, ignoring venv dirs"

    def test_count_source_files_ignores_pycache(self, tmp_path: Path):
        """Should ignore __pycache__ directories."""
        from tldr.session_warm import count_source_files

        (tmp_path / "main.py").write_text("")
        (tmp_path / "__pycache__").mkdir()
        (tmp_path / "__pycache__" / "main.cpython-39.pyc").write_text("")

        result = count_source_files(tmp_path)
        assert result == 1


class TestCacheFreshnessMessage:
    """Test suite for cache freshness message generation."""

    def test_freshness_message_missing_cache(self, tmp_path: Path):
        """Missing cache should show 'no cache' message."""
        from tldr.session_warm import get_cache_freshness_message

        msg = get_cache_freshness_message(tmp_path)
        assert "no cache" in msg.lower() or "not found" in msg.lower()

    def test_freshness_message_fresh_cache(self, tmp_path: Path):
        """Fresh cache should show 'fresh' with age."""
        from tldr.session_warm import get_cache_freshness_message

        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        four_hours_ago = time.time() - (4 * 3600)
        cache_data = {"edges": [], "timestamp": four_hours_ago}
        cache_file.write_text(json.dumps(cache_data))

        msg = get_cache_freshness_message(tmp_path)
        assert "fresh" in msg.lower()
        assert "4" in msg or "4h" in msg.lower()

    def test_freshness_message_stale_cache(self, tmp_path: Path):
        """Stale cache should show age in days."""
        from tldr.session_warm import get_cache_freshness_message

        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        two_days_ago = time.time() - (48 * 3600)
        cache_data = {"edges": [], "timestamp": two_days_ago}
        cache_file.write_text(json.dumps(cache_data))

        msg = get_cache_freshness_message(tmp_path)
        assert "2 day" in msg.lower() or "48" in msg

    def test_freshness_message_warming_indicator(self, tmp_path: Path):
        """When warming is happening, should indicate that."""
        from tldr.session_warm import get_cache_freshness_message

        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        two_days_ago = time.time() - (48 * 3600)
        cache_data = {"edges": [], "timestamp": two_days_ago}
        cache_file.write_text(json.dumps(cache_data))

        msg = get_cache_freshness_message(tmp_path, warming=True)
        assert "warming" in msg.lower()


class TestMaybeWarmBackground:
    """Test suite for background warming trigger logic."""

    def test_maybe_warm_skips_fresh_cache(self, tmp_path: Path):
        """Should not warm if cache is fresh."""
        from tldr.session_warm import maybe_warm_background

        # Create fresh cache
        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        fresh_timestamp = time.time() - (1 * 3600)  # 1 hour ago
        cache_data = {"edges": [], "timestamp": fresh_timestamp}
        cache_file.write_text(json.dumps(cache_data))

        (tmp_path / "main.py").write_text("def main(): pass")

        with patch("tldr.session_warm.subprocess.Popen") as mock_popen:
            result = maybe_warm_background(tmp_path)

        assert result is False, "Should not warm fresh cache"
        mock_popen.assert_not_called()

    def test_maybe_warm_skips_large_project(self, tmp_path: Path):
        """Should not warm if project has too many files."""
        from tldr.session_warm import maybe_warm_background

        # Create many Python files (> 500)
        for i in range(501):
            (tmp_path / f"file{i}.py").write_text("")

        with patch("tldr.session_warm.subprocess.Popen") as mock_popen:
            result = maybe_warm_background(tmp_path, max_files=500)

        assert result is False, "Should not warm large project"
        mock_popen.assert_not_called()

    def test_maybe_warm_spawns_for_stale_small_project(self, tmp_path: Path):
        """Should spawn background process for stale cache in small project."""
        from tldr.session_warm import maybe_warm_background

        # Create small project with no cache (stale)
        (tmp_path / "main.py").write_text("def main(): pass")

        with patch("tldr.session_warm.subprocess.Popen") as mock_popen:
            result = maybe_warm_background(tmp_path)

        assert result is True, "Should spawn for stale cache in small project"
        mock_popen.assert_called_once()

        # Verify the command includes --background
        call_args = mock_popen.call_args
        cmd = call_args[0][0]  # First positional arg is the command list
        assert "--background" in cmd

    def test_maybe_warm_returns_false_for_nonexistent_path(self):
        """Should return False for non-existent path."""
        from tldr.session_warm import maybe_warm_background

        result = maybe_warm_background(Path("/nonexistent/path/xyz"))
        assert result is False

    def test_maybe_warm_respects_custom_max_age(self, tmp_path: Path):
        """Should respect custom max_age_hours parameter."""
        from tldr.session_warm import maybe_warm_background

        # Create cache 2 hours old
        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        two_hours_ago = time.time() - (2 * 3600)
        cache_data = {"edges": [], "timestamp": two_hours_ago}
        cache_file.write_text(json.dumps(cache_data))

        (tmp_path / "main.py").write_text("def main(): pass")

        # With max_age=1, should be stale and warm
        with patch("tldr.session_warm.subprocess.Popen") as mock_popen:
            result = maybe_warm_background(tmp_path, max_age_hours=1)
        assert result is True
        mock_popen.assert_called_once()

        # With max_age=4, should be fresh and skip
        with patch("tldr.session_warm.subprocess.Popen") as mock_popen:
            result = maybe_warm_background(tmp_path, max_age_hours=4)
        assert result is False
        mock_popen.assert_not_called()


class TestGetCacheAge:
    """Test suite for get_cache_age helper."""

    def test_get_cache_age_missing_returns_none(self, tmp_path: Path):
        """Missing cache should return None."""
        from tldr.session_warm import get_cache_age

        result = get_cache_age(tmp_path)
        assert result is None

    def test_get_cache_age_returns_hours(self, tmp_path: Path):
        """Should return age in hours."""
        from tldr.session_warm import get_cache_age

        cache_dir = tmp_path / ".tldr" / "cache"
        cache_dir.mkdir(parents=True)
        cache_file = cache_dir / "call_graph.json"

        four_hours_ago = time.time() - (4 * 3600)
        cache_data = {"edges": [], "timestamp": four_hours_ago}
        cache_file.write_text(json.dumps(cache_data))

        result = get_cache_age(tmp_path)
        # Allow small tolerance for test execution time
        assert result is not None
        assert 3.9 < result < 4.1, f"Expected ~4 hours, got {result}"
