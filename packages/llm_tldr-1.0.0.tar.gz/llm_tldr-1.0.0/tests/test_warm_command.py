"""
TDD tests for P0: `tldr warm` CLI command.

Tests written BEFORE implementation per TDD discipline.
"""

import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import pytest


class TestWarmCommand:
    """Test suite for `tldr warm` subcommand."""

    def test_warm_command_exists(self, tmp_path: Path):
        """Warm command should exist and return 0 for valid path."""
        # Create a minimal Python project
        (tmp_path / "main.py").write_text("def hello(): pass")

        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "warm", str(tmp_path)],
            capture_output=True,
            text=True,
        )

        assert result.returncode == 0, f"Expected 0, got {result.returncode}. stderr: {result.stderr}"

    def test_warm_creates_cache_file(self, tmp_path: Path):
        """Warm should create a cache file with call graph data."""
        # Create a minimal Python project with a call
        (tmp_path / "main.py").write_text(
            "from helper import greet\ndef main(): greet()"
        )
        (tmp_path / "helper.py").write_text("def greet(): print('hi')")

        # Run warm
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "warm", str(tmp_path)],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0

        # Check cache file exists
        cache_dir = tmp_path / ".tldr" / "cache"
        cache_file = cache_dir / "call_graph.json"

        assert cache_dir.exists(), f"Cache dir should exist at {cache_dir}"
        assert cache_file.exists(), f"Cache file should exist at {cache_file}"

        # Verify cache contains valid JSON with edges
        data = json.loads(cache_file.read_text())
        assert "edges" in data, "Cache should have 'edges' key"
        assert "timestamp" in data, "Cache should have 'timestamp' key"
        assert isinstance(data["edges"], list), "Edges should be a list"

    def test_warm_background_returns_immediately(self, tmp_path: Path):
        """--background flag should return immediately while building in background."""
        # Create a project
        (tmp_path / "main.py").write_text("def hello(): pass")

        start = time.time()
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "warm", str(tmp_path), "--background"],
            capture_output=True,
            text=True,
        )
        elapsed = time.time() - start

        # Should return quickly (< 1 second) even if build takes longer
        assert result.returncode == 0
        assert elapsed < 1.0, f"Background should return immediately, took {elapsed}s"

        # Output should indicate background process started
        assert "background" in result.stdout.lower() or "spawned" in result.stdout.lower()

    def test_warm_missing_path_returns_error(self):
        """Warm should return error code for non-existent path."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "warm", "/nonexistent/path/xyz"],
            capture_output=True,
            text=True,
        )

        assert result.returncode != 0, "Should return non-zero for missing path"
        assert "error" in result.stderr.lower() or "not found" in result.stderr.lower()

    def test_warm_empty_project_succeeds(self, tmp_path: Path):
        """Warm should succeed on empty directory (no Python files)."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "warm", str(tmp_path)],
            capture_output=True,
            text=True,
        )

        # Should succeed with empty edges
        assert result.returncode == 0

        cache_file = tmp_path / ".tldr" / "cache" / "call_graph.json"
        assert cache_file.exists()

        data = json.loads(cache_file.read_text())
        assert data["edges"] == [], "Empty project should have empty edges"

    def test_warm_output_shows_stats(self, tmp_path: Path):
        """Warm should output statistics about what was indexed."""
        # Create project with multiple files
        (tmp_path / "a.py").write_text("def a(): pass")
        (tmp_path / "b.py").write_text("def b(): a()")
        (tmp_path / "c.py").write_text("def c(): b()")

        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "warm", str(tmp_path)],
            capture_output=True,
            text=True,
        )

        assert result.returncode == 0
        # Should show files indexed or edges found
        output = result.stdout + result.stderr
        assert "files" in output.lower() or "edges" in output.lower()
