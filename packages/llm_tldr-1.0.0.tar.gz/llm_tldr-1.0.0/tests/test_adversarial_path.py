"""Adversarial path containment tests for TLDR code analysis.

Security test suite targeting path traversal vulnerabilities identified by Aegis scan.
The scan flagged missing `is_relative_to()` validation in path handling.

Attack Vectors Tested:
1. Directory traversal (../..) - Classic path escape via parent references
2. Absolute path injection - Bypassing relative path expectations
3. Symlink escape - Using symlinks to access files outside project
4. Null byte injection - Truncating paths to bypass extension checks
5. Path normalization attacks - Using redundant ./ and .. combinations
6. Unicode path confusion - Homoglyph attacks on path components

Test Philosophy:
- All tests are marked xfail(strict=False) - they SHOULD fail until security fixes land
- Tests document the expected secure behavior
- Tests provide reproduction steps for the vulnerability
- Tests verify the ABSENCE of security checks by showing dangerous operations succeed

Usage:
    pytest tests/test_adversarial_path.py -v
    pytest tests/test_adversarial_path.py -v --runxfail  # Run even expected failures

References:
- OWASP Path Traversal: https://owasp.org/www-community/attacks/Path_Traversal
- CWE-22: Improper Limitation of a Pathname to a Restricted Directory
"""

import os
import pytest
import tempfile
from pathlib import Path
from typing import Optional

# Import the actual PathTraversalError from tldr.api
from tldr.api import PathTraversalError


# =============================================================================
# TEST INFRASTRUCTURE
# =============================================================================


class SymlinkEscapeError(Exception):
    """Expected exception when symlink resolves outside project.

    TLDR should raise this when a symlink points outside the project root.
    Currently does not exist - tests will fail until implemented.
    """
    pass


def xfail_no_containment_check(description: str):
    """Mark test as expected failure due to missing path containment."""
    return pytest.mark.xfail(
        reason=f"No path containment check: {description}",
        strict=False
    )


def xfail_no_symlink_validation(description: str):
    """Mark test as expected failure due to missing symlink validation."""
    return pytest.mark.xfail(
        reason=f"No symlink validation: {description}",
        strict=False
    )


def xfail_no_null_byte_check(description: str):
    """Mark test as expected failure due to missing null byte sanitization."""
    return pytest.mark.xfail(
        reason=f"No null byte sanitization: {description}",
        strict=False
    )


def assert_security_rejection(exc_info, message=""):
    """Assert that exception is a SECURITY rejection, not just FileNotFoundError.

    The key insight: FileNotFoundError means the path was processed and the file
    wasn't found. A proper security check should reject the path BEFORE attempting
    filesystem access, raising a specific security error.

    Current behavior: Paths with .. resolve and get FileNotFoundError
    Expected behavior: Paths with .. get PathTraversalError before resolution
    """
    exc_type = exc_info.type
    exc_value = exc_info.value

    # These are SECURITY rejections - what we want
    security_exceptions = (PathTraversalError, SymlinkEscapeError)

    # These are NOT security rejections - they mean the path was processed
    # ValueError might be security (e.g., "Path contains null byte") or not
    # FileNotFoundError definitely means path was processed

    if exc_type == FileNotFoundError:
        pytest.fail(
            f"Got FileNotFoundError instead of security rejection. {message}\n"
            f"This means the path was processed (traversal allowed) but file doesn't exist.\n"
            f"A proper security check should reject BEFORE filesystem access.\n"
            f"Exception: {exc_value}"
        )

    if exc_type == OSError and "File name too long" in str(exc_value):
        # OS rejected the path, but not for security reasons
        pytest.fail(
            f"Got OS rejection for path length, not security. {message}\n"
            f"Exception: {exc_value}"
        )

    # Check if it's a proper security rejection
    if exc_type not in security_exceptions:
        # It's some other exception - might be ok, might not be
        # For now, allow ValueError and PermissionError as potential security
        allowed = (ValueError, PermissionError)
        if exc_type not in allowed:
            pytest.fail(
                f"Unexpected exception type {exc_type}. {message}\n"
                f"Expected one of: {security_exceptions} or {allowed}\n"
                f"Exception: {exc_value}"
            )


# =============================================================================
# DIRECTORY TRAVERSAL TESTS
# =============================================================================


class TestDirectoryTraversal:
    """Test directory traversal attack prevention.

    Directory traversal uses .. sequences to escape intended directories.
    TLDR processes file paths from user input (CLI, API) and should validate
    that resolved paths remain within expected boundaries.

    CRITICAL: These tests demonstrate that path traversal WORKS (vulnerability).
    Tests pass when the vulnerability is FIXED (path rejected with security error).
    Tests fail when vulnerability exists (file outside project is accessed).
    """

    @xfail_no_containment_check("extract_file allows path escape via ..")
    def test_extract_file_traversal_to_real_file(self, tmp_path):
        """extract_file should reject paths that escape project root.

        This test creates a REAL file outside the project and verifies
        that traversal can access it (vulnerability) or is blocked (fix).
        """
        from tldr.api import extract_file

        # Setup: Create nested structure
        # /tmp/xxx/outside/secret.py  <- file OUTSIDE project
        # /tmp/xxx/project/           <- project root
        outside = tmp_path / "outside"
        outside.mkdir()
        secret_file = outside / "secret.py"
        secret_file.write_text("SECRET = 'leaked_data'\ndef leak(): return SECRET")

        project = tmp_path / "project"
        project.mkdir()
        (project / "main.py").write_text("def hello(): pass")

        # Attack: project/../outside/secret.py escapes project
        malicious_path = str(project / ".." / "outside" / "secret.py")

        # Expected: Security rejection BEFORE filesystem access
        # Current: Likely succeeds and returns the secret file's content
        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious_path)
            # If we get here, the attack succeeded - file was read
            # Check that we actually got the secret file's content
            if "SECRET" in str(result) or "leaked_data" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Escaped project via ..\n"
                    f"Accessed secret file outside project!\n"
                    f"Result contained: {result}"
                )
            # Even if content doesn't match, accessing outside files is wrong
            pytest.fail(
                f"Path traversal allowed: accessed file outside project.\n"
                f"Path: {malicious_path}\n"
                f"Result: {result}"
            )

        # If we get an exception, verify it's a security rejection
        assert_security_rejection(exc_info, "extract_file traversal")

    @xfail_no_containment_check("extract_file allows path escape via ..")
    def test_extract_file_traversal_attack(self, tmp_path):
        """extract_file should reject paths that escape project root."""
        from tldr.api import extract_file

        # Setup: Create a project directory
        project = tmp_path / "project"
        project.mkdir()

        # Create a legitimate file inside project
        (project / "main.py").write_text("def hello(): pass")

        # Attack: Try to escape to parent directory
        # The path project/../../../etc/passwd should be rejected
        malicious_path = project / ".." / ".." / ".." / "etc" / "passwd"

        # Expected behavior: Should raise PathTraversalError or similar
        # Current behavior: May read /etc/passwd if it exists
        with pytest.raises((PathTraversalError, ValueError, PermissionError)):
            extract_file(str(malicious_path))

    @xfail_no_containment_check("get_cfg_context allows path escape via ..")
    def test_cfg_traversal_attack(self, tmp_path):
        """get_cfg_context should reject paths that escape project root."""
        from tldr.api import get_cfg_context

        project = tmp_path / "project"
        project.mkdir()

        # Attack: Use .. to reach system files
        malicious_path = str(project / ".." / ".." / "etc" / "passwd")

        # Expected: Rejection before attempting to parse
        with pytest.raises((PathTraversalError, ValueError, FileNotFoundError)):
            get_cfg_context(malicious_path, "main", language="python")

    @xfail_no_containment_check("get_dfg_context allows path escape via ..")
    def test_dfg_traversal_attack(self, tmp_path):
        """get_dfg_context should reject paths that escape project root."""
        from tldr.api import get_dfg_context

        project = tmp_path / "project"
        project.mkdir()

        malicious_path = str(project / ".." / ".." / "etc" / "passwd")

        with pytest.raises((PathTraversalError, ValueError, FileNotFoundError)):
            get_dfg_context(malicious_path, "main", language="python")

    @xfail_no_containment_check("get_slice allows path escape via ..")
    def test_slice_traversal_attack(self, tmp_path):
        """get_slice should reject paths that escape project root."""
        from tldr.api import get_slice

        project = tmp_path / "project"
        project.mkdir()

        malicious_path = str(project / ".." / ".." / "etc" / "passwd")

        with pytest.raises((PathTraversalError, ValueError, FileNotFoundError)):
            get_slice(malicious_path, "main", line=1, language="python")

    @xfail_no_containment_check("HybridExtractor.extract allows path escape")
    def test_hybrid_extractor_traversal_attack(self, tmp_path):
        """HybridExtractor should reject paths outside intended scope."""
        from tldr.hybrid_extractor import HybridExtractor

        # Create file outside project that we try to access
        outside = tmp_path / "outside"
        outside.mkdir()
        secret_file = outside / "secret.py"
        secret_file.write_text("HYBRID_SECRET = 'hybrid_leak'\ndef exploit(): pass")

        project = tmp_path / "project"
        project.mkdir()

        extractor = HybridExtractor()

        # Attack: Path with traversal to real file
        malicious_path = str(project / ".." / "outside" / "secret.py")

        # Expected: Rejection before file access
        # Current: May read the secret file
        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious_path)
            # If we get here, check if attack succeeded
            if hasattr(result, 'functions'):
                func_names = [f.name for f in result.functions]
                if 'exploit' in func_names:
                    pytest.fail(
                        f"PATH TRAVERSAL VULNERABILITY in HybridExtractor!\n"
                        f"Accessed file outside project via ..\n"
                        f"Functions found: {func_names}"
                    )
            pytest.fail(
                f"HybridExtractor allowed path traversal.\n"
                f"Path: {malicious_path}\n"
                f"Result: {result}"
            )

        assert_security_rejection(exc_info, "HybridExtractor traversal")

    @xfail_no_containment_check("search allows traversal in search path")
    def test_search_traversal_in_root(self, tmp_path):
        """search() should reject root paths containing traversal."""
        from tldr.api import search

        project = tmp_path / "project"
        project.mkdir()

        # Attack: Root path that escapes via traversal
        malicious_root = str(project / ".." / "..")

        # This could scan /etc, /var, etc.
        with pytest.raises((PathTraversalError, ValueError)):
            search("password", malicious_root)

    @xfail_no_containment_check("get_file_tree allows traversal in root")
    def test_file_tree_traversal(self, tmp_path):
        """get_file_tree should reject root paths with traversal."""
        from tldr.api import get_file_tree

        project = tmp_path / "project"
        project.mkdir()

        # Attack: Scan parent directories
        malicious_root = str(project / ".." / "..")

        with pytest.raises((PathTraversalError, ValueError)):
            get_file_tree(malicious_root)


# =============================================================================
# ABSOLUTE PATH INJECTION TESTS
# =============================================================================


class TestAbsolutePathInjection:
    """Test absolute path injection prevention.

    When APIs expect relative paths (e.g., within a project), absolute paths
    could bypass containment checks entirely.
    """

    @xfail_no_containment_check("extract_file accepts absolute paths without validation")
    def test_absolute_path_injection_etc_passwd(self, tmp_path):
        """Absolute paths should be rejected when relative is expected."""
        from tldr.api import extract_file

        # Project context - user specifies project root
        project = tmp_path / "project"
        project.mkdir()

        # Attack: Ignore project root, access system file directly
        # Even though we "should" be in project context
        absolute_attack = "/etc/passwd"

        # If /etc/passwd exists, this should NOT return its contents
        # Instead should raise an error about path not being relative to project
        if Path(absolute_attack).exists():
            with pytest.raises((PathTraversalError, ValueError)):
                extract_file(absolute_attack)

    @xfail_no_containment_check("get_imports accepts absolute paths to system files")
    def test_imports_absolute_path_attack(self, tmp_path):
        """get_imports should validate path is within expected scope."""
        from tldr.api import get_imports

        # Attack: Read imports from a system Python file
        # This could leak information about installed packages
        system_python = "/usr/lib/python3/os.py"  # Common location

        if Path(system_python).exists():
            with pytest.raises((PathTraversalError, ValueError)):
                get_imports(system_python, language="python")


# =============================================================================
# SYMLINK ESCAPE TESTS
# =============================================================================


class TestSymlinkEscape:
    """Test symlink-based path escape prevention.

    Symlinks can appear to be inside a project but point to external files.
    TLDR should resolve symlinks and verify the target is within bounds.
    """

    @xfail_no_symlink_validation("extract_file follows symlinks without validation")
    def test_symlink_escape_to_outside_file(self, tmp_path):
        """Symlinks pointing outside project should be rejected.

        This test creates a REAL file outside the project and symlinks to it
        from inside the project, then verifies the symlink is followed
        (vulnerability) or rejected (fix).
        """
        from tldr.api import extract_file

        # Setup: Create secret file OUTSIDE project
        outside = tmp_path / "outside"
        outside.mkdir()
        secret_file = outside / "secret.py"
        secret_file.write_text("SYMLINK_SECRET = 'escaped_via_symlink'\ndef symlink_exploit(): pass")

        # Setup: Create project with symlink to secret
        project = tmp_path / "project"
        project.mkdir()

        symlink_path = project / "innocent.py"
        try:
            symlink_path.symlink_to(secret_file)
        except OSError:
            pytest.skip("Cannot create symlinks (permissions or filesystem)")

        # The symlink LOOKS like it's in project, but points outside
        # Expected: Reject after resolving symlink
        # Current: Likely follows symlink and returns secret content
        with pytest.raises((SymlinkEscapeError, PathTraversalError, ValueError)) as exc_info:
            result = extract_file(str(symlink_path))
            # If we got here, check if attack succeeded
            if "SYMLINK_SECRET" in str(result) or "symlink_exploit" in str(result):
                pytest.fail(
                    f"SYMLINK ESCAPE VULNERABILITY!\n"
                    f"Followed symlink to file outside project.\n"
                    f"Symlink: {symlink_path} -> {secret_file}\n"
                    f"Result contained secret data: {result}"
                )
            pytest.fail(
                f"Symlink escape allowed access to outside file.\n"
                f"Symlink: {symlink_path} -> {secret_file}"
            )

        # Verify it's a security rejection, not just FileNotFoundError
        assert_security_rejection(exc_info, "symlink escape")

    @xfail_no_symlink_validation("extract_file follows symlinks without validation")
    def test_symlink_to_etc_passwd(self, tmp_path):
        """Symlinks pointing outside project should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # Create symlink inside project pointing to /etc/passwd
        symlink_path = project / "config.txt"
        target = Path("/etc/passwd")

        if not target.exists():
            pytest.skip("/etc/passwd not available")

        try:
            symlink_path.symlink_to(target)
        except OSError:
            pytest.skip("Cannot create symlinks (permissions or filesystem)")

        # The symlink LOOKS like it's in project, but points outside
        # Should be rejected after resolving
        with pytest.raises((SymlinkEscapeError, PathTraversalError, ValueError)):
            extract_file(str(symlink_path))

    @xfail_no_symlink_validation("directory symlinks can escape project")
    def test_symlink_directory_escape(self, tmp_path):
        """Directory symlinks should also be validated."""
        from tldr.api import get_file_tree

        project = tmp_path / "project"
        project.mkdir()

        # Create directory symlink to /etc
        escape_dir = project / "external"
        target = Path("/etc")

        if not target.exists():
            pytest.skip("/etc not available")

        try:
            escape_dir.symlink_to(target)
        except OSError:
            pytest.skip("Cannot create symlinks")

        # get_file_tree should not traverse into /etc via symlink
        with pytest.raises((SymlinkEscapeError, PathTraversalError, ValueError)):
            result = get_file_tree(str(project))
            # If no exception, verify /etc contents are NOT included
            # (This is a weaker assertion - better to reject outright)
            assert "passwd" not in str(result), "Symlink escape allowed access to /etc"

    @xfail_no_symlink_validation("scan_project_files follows symlinks")
    def test_scan_project_symlink_escape(self, tmp_path):
        """scan_project_files should not follow symlinks outside project."""
        from tldr.api import scan_project_files

        project = tmp_path / "project"
        project.mkdir()

        # Create symlink to system Python
        sys_python = Path("/usr/lib/python3")
        if not sys_python.exists():
            sys_python = Path("/usr/lib/python3.11")  # Try specific version
        if not sys_python.exists():
            pytest.skip("System Python not found")

        escape_link = project / "stdlib"
        try:
            escape_link.symlink_to(sys_python)
        except OSError:
            pytest.skip("Cannot create symlinks")

        # Should not return files from /usr/lib/python3
        with pytest.raises((SymlinkEscapeError, ValueError)):
            files = scan_project_files(str(project), language="python")
            # Weaker check: verify stdlib files not included
            for f in files:
                assert "/usr/lib/" not in f, f"Symlink escape: {f}"

    @xfail_no_symlink_validation("build_project_call_graph follows symlinks")
    def test_call_graph_symlink_escape(self, tmp_path):
        """build_project_call_graph should not follow external symlinks."""
        from tldr.api import build_project_call_graph

        project = tmp_path / "project"
        project.mkdir()

        # Create legitimate file
        (project / "main.py").write_text("import os\ndef main(): pass")

        # Create symlink to system
        sys_lib = Path("/usr/lib/python3")
        if not sys_lib.exists():
            pytest.skip("System Python lib not found")

        try:
            (project / "external").symlink_to(sys_lib)
        except OSError:
            pytest.skip("Cannot create symlinks")

        with pytest.raises((SymlinkEscapeError, ValueError)):
            graph = build_project_call_graph(str(project), language="python")
            # Weaker: check edges don't reference /usr/lib
            for edge in graph.edges:
                for part in edge:
                    if isinstance(part, str):
                        assert "/usr/lib/" not in part, f"Symlink escape in graph: {edge}"


# =============================================================================
# NULL BYTE INJECTION TESTS
# =============================================================================


class TestNullByteInjection:
    """Test null byte injection prevention.

    Null bytes (\x00) can truncate strings in C-based systems, potentially
    bypassing extension checks: "file.py\x00.txt" might be treated as "file.py"
    """

    @xfail_no_null_byte_check("extract_file does not sanitize null bytes")
    def test_null_byte_extension_bypass(self, tmp_path):
        """Null bytes in filenames should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # Create a Python file
        (project / "script.py").write_text("def hello(): pass")

        # Attack: Inject null byte to potentially bypass checks
        # "script.py\x00.txt" - the null byte might truncate to "script.py"
        malicious_path = str(project / "script.py") + "\x00.txt"

        # Should reject paths containing null bytes entirely
        with pytest.raises((ValueError, OSError)):
            extract_file(malicious_path)

    @xfail_no_null_byte_check("CLI does not sanitize null byte in arguments")
    def test_cli_null_byte_injection(self, tmp_path):
        """CLI should reject paths with null bytes."""
        import subprocess

        project = tmp_path / "project"
        project.mkdir()
        (project / "test.py").write_text("x = 1")

        # Attack: Null byte in CLI argument
        # Note: This may not be passable via subprocess on all systems
        malicious = str(project / "test.py") + "\x00/etc/passwd"

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "extract", malicious],
            capture_output=True,
            text=True
        )

        # Should fail with error, not succeed
        assert result.returncode != 0, "CLI should reject null byte paths"
        assert "null" in result.stderr.lower() or "invalid" in result.stderr.lower()


# =============================================================================
# PATH NORMALIZATION ATTACK TESTS
# =============================================================================


class TestPathNormalization:
    """Test path normalization attack prevention.

    Redundant path components (./foo/../bar) can confuse simple string checks.
    Paths should be normalized before containment validation.
    """

    @xfail_no_containment_check("extract_file checks path before normalization")
    def test_redundant_dot_traversal(self, tmp_path):
        """./././../.. sequences should be normalized and rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # Attack: Use redundant ./ to obfuscate traversal
        # ./foo/./../../../etc/passwd
        malicious = str(project) + "/./foo/./../../../etc/passwd"

        with pytest.raises((PathTraversalError, ValueError, FileNotFoundError)):
            extract_file(malicious)

    @xfail_no_containment_check("double-encoded traversal not handled")
    def test_encoded_traversal(self, tmp_path):
        """URL-encoded or double-encoded traversal should be caught."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # Attack: URL-encoded ..
        # %2e%2e = .. in URL encoding
        # Even though this is a filesystem path, we should be defensive
        malicious = str(project) + "/%2e%2e/%2e%2e/etc/passwd"

        # Should not succeed even if filesystem interprets literally
        # (it won't, but defense in depth)
        try:
            result = extract_file(malicious)
            # If we got here, make sure it's NOT /etc/passwd content
            assert "root:" not in str(result)
        except (FileNotFoundError, ValueError, OSError):
            pass  # Expected - file with literal %2e%2e doesn't exist

    @xfail_no_containment_check("backslash handling on Unix")
    def test_backslash_traversal_unix(self, tmp_path):
        """Backslash traversal variants should be handled."""
        from tldr.api import extract_file

        if os.name == 'nt':
            pytest.skip("Test for Unix systems")

        project = tmp_path / "project"
        project.mkdir()

        # On Unix, backslash is a valid filename character
        # But mixed-path handling code might interpret it as separator
        malicious = str(project) + "/..\\..\\..\\etc\\passwd"

        # Should handle gracefully - either reject or treat as literal filename
        try:
            result = extract_file(malicious)
            # If succeeds, must NOT be /etc/passwd
            assert "root:" not in str(result)
        except (FileNotFoundError, ValueError, OSError):
            pass  # Expected


# =============================================================================
# UNICODE PATH CONFUSION TESTS
# =============================================================================


class TestUnicodePathConfusion:
    """Test Unicode-based path confusion attacks.

    Unicode lookalike characters (homoglyphs) can create paths that look
    legitimate but resolve differently.
    """

    @xfail_no_containment_check("Unicode normalization not applied to paths")
    def test_unicode_dot_homoglyph(self, tmp_path):
        """Unicode dots that look like . but aren't should be handled."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # U+FF0E FULLWIDTH FULL STOP looks like .
        # Path: project/../../../etc might bypass string checks
        unicode_dot = "\uff0e"
        malicious = str(project) + f"/{unicode_dot}{unicode_dot}/etc/passwd"

        # Should either normalize or reject suspicious Unicode
        try:
            result = extract_file(malicious)
            # If succeeds, verify not reading system file
            assert "root:" not in str(result)
        except (FileNotFoundError, ValueError, OSError):
            pass

    @xfail_no_containment_check("Unicode slash variants not normalized")
    def test_unicode_slash_variants(self, tmp_path):
        """Unicode slash-like characters should not bypass checks."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # Various Unicode characters that might be interpreted as /
        # U+2215 DIVISION SLASH, U+FF0F FULLWIDTH SOLIDUS
        unicode_slash = "\u2215"
        malicious = str(project) + f"{unicode_slash}..{unicode_slash}..{unicode_slash}etc{unicode_slash}passwd"

        try:
            result = extract_file(malicious)
            assert "root:" not in str(result)
        except (FileNotFoundError, ValueError, OSError):
            pass

    @xfail_no_containment_check("RTL override characters not stripped")
    def test_rtl_override_confusion(self, tmp_path):
        """Right-to-left override characters could confuse path display."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # U+202E RIGHT-TO-LEFT OVERRIDE
        # While this doesn't change path resolution, it could confuse logging
        # and make malicious paths appear legitimate in output
        rlo = "\u202e"
        suspicious_path = str(project / f"file{rlo}py.exe")

        # Should strip or reject control characters
        try:
            result = extract_file(suspicious_path)
        except (ValueError, FileNotFoundError, OSError):
            pass  # Expected


# =============================================================================
# WINDOWS-SPECIFIC TESTS
# =============================================================================


@pytest.mark.skipif(os.name != 'nt', reason="Windows-specific tests")
class TestWindowsPathAttacks:
    r"""Windows-specific path traversal tests.

    Windows has additional path attack vectors:
    - Drive-relative paths (C:file.txt vs C:\file.txt)
    - UNC paths (\\server\share)
    - Device paths (\\.\COM1, \\.\PhysicalDrive0)
    - Short names (PROGRA~1)
    """

    @xfail_no_containment_check("Windows drive-relative paths not validated")
    def test_drive_relative_path(self, tmp_path):
        """Drive-relative paths should be handled safely."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # C:file.txt is relative to current directory of C: drive
        # Different from C:\file.txt which is absolute
        malicious = "C:../../../Windows/System32/config/SAM"

        with pytest.raises((PathTraversalError, ValueError, FileNotFoundError)):
            extract_file(malicious)

    @xfail_no_containment_check("UNC paths not rejected")
    def test_unc_path_injection(self, tmp_path):
        """UNC paths should be rejected in local file context."""
        from tldr.api import extract_file

        # Attack: Access network share
        malicious = "\\\\evil.com\\share\\malware.py"

        with pytest.raises((PathTraversalError, ValueError)):
            extract_file(malicious)

    @xfail_no_containment_check("Windows device paths not rejected")
    def test_device_path_injection(self, tmp_path):
        """Device paths should be rejected."""
        from tldr.api import extract_file

        # Attack: Access raw device
        malicious = "\\\\.\\PhysicalDrive0"

        with pytest.raises((PathTraversalError, ValueError)):
            extract_file(malicious)

    @xfail_no_containment_check("8.3 short names not normalized")
    def test_short_name_obfuscation(self, tmp_path):
        """8.3 short names should be resolved before validation."""
        from tldr.api import extract_file

        # Attack: Use short name to obfuscate path
        # PROGRA~1 = Program Files
        malicious = "C:\\PROGRA~1\\..\\Windows\\System32\\config\\SAM"

        with pytest.raises((PathTraversalError, ValueError, FileNotFoundError)):
            extract_file(malicious)


# =============================================================================
# RACE CONDITION TESTS (TOCTOU)
# =============================================================================


class TestTOCTOU:
    """Test Time-Of-Check-Time-Of-Use race conditions.

    If path validation and file access are not atomic, an attacker could
    swap a file/symlink between check and use.
    """

    @xfail_no_containment_check("TOCTOU: gap between validation and file read")
    def test_symlink_swap_race(self, tmp_path):
        """Path could be swapped between validation and use."""
        from tldr.api import extract_file
        import threading
        import time

        project = tmp_path / "project"
        project.mkdir()

        # Create legitimate file
        legitimate = project / "safe.py"
        legitimate.write_text("x = 1")

        # This test demonstrates the concept but can't reliably
        # trigger the race. The vulnerability exists if:
        # 1. TLDR validates path at time T
        # 2. Attacker swaps symlink target between T and T+1
        # 3. TLDR reads file at T+1, getting different content

        # For now, just verify we can detect obvious races
        results = []

        def swap_symlink():
            """Background thread to swap symlink target."""
            for _ in range(100):
                try:
                    # Remove and recreate pointing to /etc/passwd
                    if legitimate.exists() and not legitimate.is_symlink():
                        legitimate.unlink()
                        legitimate.symlink_to("/etc/passwd")
                    time.sleep(0.001)
                    # Swap back
                    if legitimate.is_symlink():
                        legitimate.unlink()
                        legitimate.write_text("x = 1")
                except (OSError, PermissionError):
                    pass

        # Note: This test is inherently flaky and documents
        # the vulnerability rather than reliably detecting it
        # In production, use O_NOFOLLOW or similar
        pytest.skip("TOCTOU race test - demonstrates concept only")


# =============================================================================
# INTEGRATION TESTS - CLI ENTRY POINTS
# =============================================================================


class TestCLIPathContainment:
    """Test path containment via CLI entry points."""

    @xfail_no_containment_check("CLI extract allows traversal")
    def test_cli_extract_traversal(self, tmp_path):
        """tldr extract should reject traversal paths."""
        import subprocess

        project = tmp_path / "project"
        project.mkdir()

        malicious = str(project / "../../../etc/passwd")

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "extract", malicious],
            capture_output=True,
            text=True
        )

        # Should fail with security error, not succeed
        assert result.returncode != 0
        # Output should NOT contain /etc/passwd contents
        assert "root:" not in result.stdout
        assert "root:" not in result.stderr

    @xfail_no_containment_check("CLI search allows traversal in path")
    def test_cli_search_traversal(self, tmp_path):
        """tldr search should reject traversal in search root."""
        import subprocess

        project = tmp_path / "project"
        project.mkdir()

        malicious_root = str(project / "../../..")

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "search", "password", malicious_root],
            capture_output=True,
            text=True
        )

        assert result.returncode != 0

    @xfail_no_containment_check("CLI cfg allows traversal")
    def test_cli_cfg_traversal(self, tmp_path):
        """tldr cfg should reject traversal paths."""
        import subprocess

        project = tmp_path / "project"
        project.mkdir()

        malicious = str(project / "../../../etc/passwd")

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "cfg", malicious, "main"],
            capture_output=True,
            text=True
        )

        assert result.returncode != 0

    @xfail_no_containment_check("CLI imports allows traversal")
    def test_cli_imports_traversal(self, tmp_path):
        """tldr imports should reject traversal paths."""
        import subprocess

        project = tmp_path / "project"
        project.mkdir()

        # Try to read imports from system file
        malicious = str(project / "../../../etc/passwd")

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "imports", malicious],
            capture_output=True,
            text=True
        )

        assert result.returncode != 0


# =============================================================================
# ADDITIONAL EDGE CASES
# =============================================================================


class TestEdgeCases:
    """Additional edge cases for path handling."""

    @xfail_no_containment_check("Empty path not rejected")
    def test_empty_path(self):
        """Empty paths should be rejected."""
        from tldr.api import extract_file

        with pytest.raises((ValueError, FileNotFoundError)):
            extract_file("")

    @xfail_no_containment_check("Whitespace-only path not rejected")
    def test_whitespace_path(self):
        """Whitespace-only paths should be rejected."""
        from tldr.api import extract_file

        with pytest.raises((ValueError, FileNotFoundError)):
            extract_file("   ")

    @xfail_no_containment_check("Path with only dots not handled")
    def test_dots_only_path(self, tmp_path):
        """Paths like .... should be handled safely."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()

        # ... is not a special path, but could confuse parsers
        malicious = str(project) + "/..."

        try:
            extract_file(malicious)
        except FileNotFoundError:
            pass  # Expected - no file named ...

    @xfail_no_containment_check("Very long paths not validated")
    def test_very_long_path(self, tmp_path):
        """Extremely long paths should be rejected early."""
        from tldr.api import extract_file

        # Attack: Very long path could cause DoS or buffer issues
        long_component = "a" * 1000
        malicious = str(tmp_path / long_component / long_component / long_component)

        # Should reject early, not attempt filesystem operations
        with pytest.raises((ValueError, OSError)):
            extract_file(malicious)


# =============================================================================
# MISSING LANGUAGES PATH TRAVERSAL TESTS
# =============================================================================


class TestMissingLanguagesPathTraversal:
    """Path traversal tests for additional languages.

    These tests verify that path containment checks work regardless of
    file extension. Each language test creates a file outside the project
    and attempts to access it via path traversal.

    Languages covered: C, C++, Ruby, Kotlin, Swift, C#, Scala, Lua, Elixir
    """

    # -------------------------------------------------------------------------
    # C (.c)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows C file path escape via ..")
    def test_c_file_traversal(self, tmp_path):
        """C file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.c"
        secret.write_text("int secret_function() { return 42; }")

        malicious = str(project / ".." / "outside" / "secret.c")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "secret_function" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed C file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for C file: {malicious}")

        assert_security_rejection(exc_info, "C file traversal")

    @xfail_no_containment_check("HybridExtractor allows C file path escape")
    def test_c_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject C files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.c"
        secret.write_text("#include <stdio.h>\nvoid leak() { printf(\"leaked\"); }")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.c")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            if hasattr(result, 'functions'):
                func_names = [f.name for f in result.functions]
                if 'leak' in func_names:
                    pytest.fail(f"PATH TRAVERSAL: Accessed C file functions: {func_names}")
            pytest.fail(f"HybridExtractor allowed C file traversal: {malicious}")

        assert_security_rejection(exc_info, "C file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # C++ (.cpp)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows C++ file path escape via ..")
    def test_cpp_file_traversal(self, tmp_path):
        """C++ file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.cpp"
        secret.write_text("class SecretClass { public: void leak(); };")

        malicious = str(project / ".." / "outside" / "secret.cpp")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretClass" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed C++ file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for C++ file: {malicious}")

        assert_security_rejection(exc_info, "C++ file traversal")

    @xfail_no_containment_check("HybridExtractor allows C++ file path escape")
    def test_cpp_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject C++ files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.cpp"
        secret.write_text("namespace leaked { class Exploit { void run(); }; }")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.cpp")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            if hasattr(result, 'classes'):
                class_names = [c.name for c in result.classes]
                if 'Exploit' in class_names:
                    pytest.fail(f"PATH TRAVERSAL: Accessed C++ classes: {class_names}")
            pytest.fail(f"HybridExtractor allowed C++ file traversal: {malicious}")

        assert_security_rejection(exc_info, "C++ file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # Ruby (.rb)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows Ruby file path escape via ..")
    def test_ruby_file_traversal(self, tmp_path):
        """Ruby file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.rb"
        secret.write_text("class SecretRuby\n  def leak\n    'secret'\n  end\nend")

        malicious = str(project / ".." / "outside" / "secret.rb")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretRuby" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed Ruby file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for Ruby file: {malicious}")

        assert_security_rejection(exc_info, "Ruby file traversal")

    @xfail_no_containment_check("HybridExtractor allows Ruby file path escape")
    def test_ruby_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject Ruby files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.rb"
        secret.write_text("module Leaked\n  def exploit\n    system('whoami')\n  end\nend")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.rb")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            pytest.fail(f"HybridExtractor allowed Ruby file traversal: {malicious}")

        assert_security_rejection(exc_info, "Ruby file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # Kotlin (.kt)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows Kotlin file path escape via ..")
    def test_kotlin_file_traversal(self, tmp_path):
        """Kotlin file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.kt"
        secret.write_text("class SecretKotlin {\n    fun leak(): String = \"secret\"\n}")

        malicious = str(project / ".." / "outside" / "secret.kt")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretKotlin" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed Kotlin file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for Kotlin file: {malicious}")

        assert_security_rejection(exc_info, "Kotlin file traversal")

    @xfail_no_containment_check("HybridExtractor allows Kotlin file path escape")
    def test_kotlin_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject Kotlin files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.kt"
        secret.write_text("package leaked\nfun exploit() = Runtime.getRuntime().exec(\"whoami\")")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.kt")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            pytest.fail(f"HybridExtractor allowed Kotlin file traversal: {malicious}")

        assert_security_rejection(exc_info, "Kotlin file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # Swift (.swift)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows Swift file path escape via ..")
    def test_swift_file_traversal(self, tmp_path):
        """Swift file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.swift"
        secret.write_text("class SecretSwift {\n    func leak() -> String { return \"secret\" }\n}")

        malicious = str(project / ".." / "outside" / "secret.swift")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretSwift" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed Swift file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for Swift file: {malicious}")

        assert_security_rejection(exc_info, "Swift file traversal")

    @xfail_no_containment_check("HybridExtractor allows Swift file path escape")
    def test_swift_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject Swift files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.swift"
        secret.write_text("import Foundation\nfunc exploit() { Process.launchedProcess(launchPath: \"/bin/sh\", arguments: []) }")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.swift")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            pytest.fail(f"HybridExtractor allowed Swift file traversal: {malicious}")

        assert_security_rejection(exc_info, "Swift file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # C# (.cs)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows C# file path escape via ..")
    def test_csharp_file_traversal(self, tmp_path):
        """C# file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.cs"
        secret.write_text("public class SecretCSharp {\n    public string Leak() => \"secret\";\n}")

        malicious = str(project / ".." / "outside" / "secret.cs")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretCSharp" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed C# file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for C# file: {malicious}")

        assert_security_rejection(exc_info, "C# file traversal")

    @xfail_no_containment_check("HybridExtractor allows C# file path escape")
    def test_csharp_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject C# files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.cs"
        secret.write_text("using System.Diagnostics;\nclass Leaked { void Exploit() { Process.Start(\"cmd\"); } }")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.cs")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            pytest.fail(f"HybridExtractor allowed C# file traversal: {malicious}")

        assert_security_rejection(exc_info, "C# file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # Scala (.scala)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows Scala file path escape via ..")
    def test_scala_file_traversal(self, tmp_path):
        """Scala file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.scala"
        secret.write_text("class SecretScala {\n  def leak: String = \"secret\"\n}")

        malicious = str(project / ".." / "outside" / "secret.scala")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretScala" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed Scala file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for Scala file: {malicious}")

        assert_security_rejection(exc_info, "Scala file traversal")

    @xfail_no_containment_check("HybridExtractor allows Scala file path escape")
    def test_scala_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject Scala files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.scala"
        secret.write_text("import sys.process._\nobject Leaked { def exploit = \"whoami\".! }")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.scala")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            pytest.fail(f"HybridExtractor allowed Scala file traversal: {malicious}")

        assert_security_rejection(exc_info, "Scala file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # Lua (.lua)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows Lua file path escape via ..")
    def test_lua_file_traversal(self, tmp_path):
        """Lua file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.lua"
        secret.write_text("local SecretLua = {}\nfunction SecretLua.leak() return 'secret' end\nreturn SecretLua")

        malicious = str(project / ".." / "outside" / "secret.lua")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretLua" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed Lua file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for Lua file: {malicious}")

        assert_security_rejection(exc_info, "Lua file traversal")

    @xfail_no_containment_check("HybridExtractor allows Lua file path escape")
    def test_lua_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject Lua files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.lua"
        secret.write_text("function exploit() os.execute('whoami') end")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.lua")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            pytest.fail(f"HybridExtractor allowed Lua file traversal: {malicious}")

        assert_security_rejection(exc_info, "Lua file HybridExtractor traversal")

    # -------------------------------------------------------------------------
    # Elixir (.ex)
    # -------------------------------------------------------------------------

    @xfail_no_containment_check("extract_file allows Elixir file path escape via ..")
    def test_elixir_file_traversal(self, tmp_path):
        """Elixir file with path traversal should be rejected."""
        from tldr.api import extract_file

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "secret.ex"
        secret.write_text("defmodule SecretElixir do\n  def leak, do: \"secret\"\nend")

        malicious = str(project / ".." / "outside" / "secret.ex")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extract_file(malicious)
            if "SecretElixir" in str(result):
                pytest.fail(
                    f"PATH TRAVERSAL VULNERABILITY: Accessed Elixir file outside project!\n"
                    f"Result: {result}"
                )
            pytest.fail(f"Path traversal allowed for Elixir file: {malicious}")

        assert_security_rejection(exc_info, "Elixir file traversal")

    @xfail_no_containment_check("HybridExtractor allows Elixir file path escape")
    def test_elixir_hybrid_extractor_traversal(self, tmp_path):
        """HybridExtractor should reject Elixir files outside project."""
        from tldr.hybrid_extractor import HybridExtractor

        project = tmp_path / "project"
        project.mkdir()
        outside = tmp_path / "outside"
        outside.mkdir()
        secret = outside / "leaked.ex"
        secret.write_text("defmodule Leaked do\n  def exploit, do: System.cmd(\"whoami\", [])\nend")

        extractor = HybridExtractor()
        malicious = str(project / ".." / "outside" / "leaked.ex")

        with pytest.raises((PathTraversalError, ValueError, PermissionError)) as exc_info:
            result = extractor.extract(malicious)
            pytest.fail(f"HybridExtractor allowed Elixir file traversal: {malicious}")

        assert_security_rejection(exc_info, "Elixir file HybridExtractor traversal")
