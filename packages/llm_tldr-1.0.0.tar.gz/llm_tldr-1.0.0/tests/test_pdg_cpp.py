"""Tests for C++ PDG extraction and program slicing (L5).

TDD Tests for C++ PDG support.

Tests mirror the structure of test_pdg_c.py but for C++ language support.
C++ CFG (L3) and DFG (L4) must be implemented first.

Expected to fail initially with ImportError (extract_cpp_pdg not implemented).
"""
import os
import pytest

# Check if tree-sitter-cpp is available
try:
    from tldr.cfg_extractor import TREE_SITTER_CPP_AVAILABLE
    CPP_AVAILABLE = TREE_SITTER_CPP_AVAILABLE
except ImportError:
    CPP_AVAILABLE = False

# Check if extract_cpp_pdg is implemented
try:
    from tldr.pdg_extractor import extract_cpp_pdg
    CPP_PDG_AVAILABLE = True
except ImportError:
    CPP_PDG_AVAILABLE = False
    extract_cpp_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not CPP_AVAILABLE,
    reason="tree-sitter-cpp not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_cpp_path():
    """Path to sample.cpp fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.cpp")


@pytest.fixture
def sample_cpp_code(sample_cpp_path):
    """Load sample.cpp fixture code."""
    with open(sample_cpp_path) as f:
        return f.read()


@pytest.fixture
def simple_cpp_code():
    """Simple C++ code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
/* =============================================================================
 * Simple C++ test fixture for PDG extraction
 * This code is used to test basic PDG node and edge extraction.
 * The add function has simple data flow: a -> c, b -> c, c -> return
 * ============================================================================= */
int add(int a, int b) {
    int c = a + b;
    return c;
}
'''


@pytest.fixture
def chained_cpp_code():
    """C++ code with chained dependencies for slicing tests."""
    return '''
/* =============================================================================
 * Chained computation for forward/backward slice testing.
 * x -> a -> b -> c -> return creates a clear data flow chain.
 * This fixture tests that slicing correctly traces dependencies.
 * ============================================================================= */
int chained_compute(int x) {
    int a = x + 1;     /* line 8: a depends on x */
    int b = a * 2;     /* line 9: b depends on a */
    int c = b + 3;     /* line 10: c depends on b */
    return c;          /* line 11: return depends on c */
}
'''


@pytest.fixture
def class_method_code():
    """C++ code with class methods for OOP PDG testing."""
    return '''
/* =============================================================================
 * Class with methods for testing C++ OOP PDG extraction.
 * Tests member variable access and method control flow.
 * ============================================================================= */
class Counter {
private:
    int value_;

public:
    bool add(int amount) {
        if (amount < 0) {
            return false;
        }
        value_ += amount;
        return true;
    }
};
'''


# =============================================================================
# Tests for extract_cpp_pdg()
# =============================================================================

class TestExtractCppPDG:
    """Test extract_cpp_pdg() function."""

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_extract_cpp_pdg_basic(self, sample_cpp_code):
        """Test basic PDG extraction from sample.cpp calculate function."""
        pdg = extract_cpp_pdg(sample_cpp_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_extract_cpp_pdg_has_nodes(self, sample_cpp_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_cpp_pdg(sample_cpp_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_extract_cpp_pdg_has_edges(self, sample_cpp_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_cpp_pdg(sample_cpp_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_extract_cpp_pdg_sum_function(self, sample_cpp_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_cpp_pdg(sample_cpp_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_extract_cpp_pdg_nonexistent_function(self, sample_cpp_code):
        """Test that nonexistent function returns None."""
        pdg = extract_cpp_pdg(sample_cpp_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for C++ Program Slicing
# =============================================================================

class TestCppProgramSlicing:
    """Test program slicing for C++ code."""

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_cpp_backward_slice(self, sample_cpp_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_cpp_pdg(sample_cpp_code, "sum")

        assert pdg is not None
        # Line 37 is "return total;" in sample.cpp sum function
        slice_lines = pdg.backward_slice(line=37)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_cpp_forward_slice(self, chained_cpp_code):
        """Test forward slice from first assignment."""
        pdg = extract_cpp_pdg(chained_cpp_code, "chained_compute")

        assert pdg is not None
        # Forward slice from "int a = x + 1;" (line 8 in chained_cpp_code)
        slice_lines = pdg.forward_slice(line=8)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_cpp_slice_returns_set(self, simple_cpp_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_cpp_pdg(simple_cpp_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=9)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for C++ PDG via API
# =============================================================================

class TestCppPDGAPI:
    """Test C++ PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_cpp_get_pdg_context(self, sample_cpp_path):
        """Test get_pdg_context() for C++ code via file path."""
        result = get_pdg_context(sample_cpp_path, "calculate", language="cpp")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_cpp_get_slice_backward(self, sample_cpp_path):
        """Test get_slice() backward for C++ code via file path."""
        # Backward slice from return statement in sum function
        lines = get_slice(
            sample_cpp_path, "sum", line=37,
            direction="backward", language="cpp"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_cpp_get_slice_forward(self, sample_cpp_path):
        """Test get_slice() forward for C++ code via file path."""
        # Line 78 is "int a = x + 1;" in chained_compute function
        lines = get_slice(
            sample_cpp_path, "chained_compute", line=78,
            direction="forward", language="cpp"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Tests for C++ Class Methods
# =============================================================================

class TestCppClassMethodPDG:
    """Test PDG extraction for C++ class methods."""

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_method_pdg_extraction(self, class_method_code):
        """Test PDG extraction from a class method."""
        pdg = extract_cpp_pdg(class_method_code, "add")

        assert pdg is not None
        assert pdg.function_name == "add"
        assert len(pdg.nodes) >= 2  # Should have nodes for the if/return

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_method_has_control_edges(self, class_method_code):
        """Test that method with if statement has control edges."""
        pdg = extract_cpp_pdg(class_method_code, "add")

        assert pdg is not None
        # Method has if statement, should have control dependencies
        control_edges = [e for e in pdg.edges if e.dep_type == "control"]
        # May have control edges from the if statement
        assert len(control_edges) >= 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestCppPDGIntegration:
    """Integration tests for C++ PDG."""

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_pdg_from_file(self, sample_cpp_path, sample_cpp_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_cpp_pdg(sample_cpp_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not CPP_PDG_AVAILABLE, reason="extract_cpp_pdg not implemented")
    def test_pdg_to_dict(self, simple_cpp_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_cpp_pdg(simple_cpp_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
