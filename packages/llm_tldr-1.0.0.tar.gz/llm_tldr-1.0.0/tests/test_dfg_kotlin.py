"""Tests for Kotlin DFG extraction.

TDD Tests for Kotlin DFG support.
Tests mirror the structure of test_dfg_java.py but for Kotlin language support.

Kotlin uses:
- val for immutable variables (like Java final)
- var for mutable variables
- Property declarations inside classes
"""
import pytest

# Check if tree-sitter-kotlin is available
try:
    from tldr.dfg_extractor import extract_kotlin_dfg, TREE_SITTER_KOTLIN_AVAILABLE
    KOTLIN_AVAILABLE = TREE_SITTER_KOTLIN_AVAILABLE
except ImportError:
    KOTLIN_AVAILABLE = False


pytestmark = pytest.mark.skipif(not KOTLIN_AVAILABLE, reason="tree-sitter-kotlin not available")


@pytest.fixture
def simple_assignment_code():
    return '''
class Example {
    fun calculate(a: Int, b: Int): Int {
        val x = a
        val y = b
        val result = x + y
        return result
    }
}
'''


@pytest.fixture
def reassignment_code():
    return '''
class Example {
    fun process(n: Int): Int {
        var x = n
        x = x + 1
        x = x * 2
        return x
    }
}
'''


@pytest.fixture
def loop_variable_code():
    return '''
class Example {
    fun sum(n: Int): Int {
        var total = 0
        for (i in 0 until n) {
            total = total + i
        }
        return total
    }
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
class Example {
    fun choose(x: Int): Int {
        val result: Int
        if (x > 0) {
            result = 1
        } else {
            result = -1
        }
        return result
    }
}
'''


@pytest.fixture
def val_var_mixed_code():
    return '''
class Example {
    fun mixed(input: Int): Int {
        val immutable = input * 2
        var mutable = immutable
        mutable += 1
        return mutable + immutable
    }
}
'''


@pytest.fixture
def when_expression_code():
    return '''
class Example {
    fun classify(x: Int): String {
        val category = when {
            x < 0 -> "negative"
            x == 0 -> "zero"
            else -> "positive"
        }
        return category
    }
}
'''


@pytest.fixture
def lambda_code():
    return '''
class Example {
    fun transform(items: List<Int>): List<Int> {
        val doubled = items.map { it * 2 }
        return doubled
    }
}
'''


@pytest.fixture
def chained_code():
    return '''
class Example {
    fun compute(x: Int): Int {
        val a = x + 1
        val b = a * 2
        val c = b + 3
        return c
    }
}
'''


class TestBasicDFG:
    """Test basic DFG extraction for Kotlin."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_kotlin_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_kotlin_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_kotlin_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_function_name(self, simple_assignment_code):
        dfg = extract_kotlin_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_kotlin_dfg(simple_assignment_code, "calculate")
        # Should have variable references (edges may be empty due to node structure)
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_kotlin_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_kotlin_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0

    def test_chained_dependencies(self, chained_code):
        dfg = extract_kotlin_dfg(chained_code, "compute")
        assert dfg is not None
        # Should have dataflow edges: x -> a -> b -> c
        assert len(dfg.dataflow_edges) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_kotlin_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_kotlin_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0

    def test_val_creates_definition(self, simple_assignment_code):
        dfg = extract_kotlin_dfg(simple_assignment_code, "calculate")
        # val x = a should create a definition of x
        x_defs = [r for r in dfg.var_refs if r.name == "x" and r.ref_type == "definition"]
        assert len(x_defs) >= 1

    def test_var_tracks_reassignment(self, reassignment_code):
        dfg = extract_kotlin_dfg(reassignment_code, "process")
        # var x is reassigned multiple times
        x_defs = [r for r in dfg.var_refs if r.name == "x" and r.ref_type == "definition"]
        # Should have multiple definitions (initial + 2 reassignments)
        assert len(x_defs) >= 2


class TestKotlinSpecific:
    """Test Kotlin-specific constructs."""

    def test_val_var_mixed(self, val_var_mixed_code):
        dfg = extract_kotlin_dfg(val_var_mixed_code, "mixed")
        assert dfg is not None
        # Should track both val and var
        immutable_refs = [r for r in dfg.var_refs if r.name == "immutable"]
        mutable_refs = [r for r in dfg.var_refs if r.name == "mutable"]
        assert len(immutable_refs) > 0
        assert len(mutable_refs) > 0

    def test_when_expression(self, when_expression_code):
        dfg = extract_kotlin_dfg(when_expression_code, "classify")
        assert dfg is not None
        # Should track 'category' variable
        category_refs = [r for r in dfg.var_refs if r.name == "category"]
        assert len(category_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_kotlin_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
