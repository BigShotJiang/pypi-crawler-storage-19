"""Tests for C #include parsing."""
import pytest
from pathlib import Path

# Check if tree-sitter-c is available
try:
    from tldr.cross_file_calls import parse_c_imports, TREE_SITTER_C_AVAILABLE
    C_AVAILABLE = TREE_SITTER_C_AVAILABLE
except ImportError:
    C_AVAILABLE = False


pytestmark = pytest.mark.skipif(not C_AVAILABLE, reason="tree-sitter-c not available")


@pytest.fixture
def system_includes_file(tmp_path):
    """Create a C file with system includes."""
    code = '''
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    printf("Hello\\n");
    return 0;
}
'''
    file_path = tmp_path / "main.c"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def local_includes_file(tmp_path):
    """Create a C file with local includes."""
    code = '''
#include "utils.h"
#include "config.h"
#include "../common/types.h"

void process() {
    init();
}
'''
    file_path = tmp_path / "main.c"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_includes_file(tmp_path):
    """Create a C file with mixed includes."""
    code = '''
#include <stdio.h>
#include <stdlib.h>
#include "utils.h"
#include "config.h"

int main() {
    init();
    return 0;
}
'''
    file_path = tmp_path / "main.c"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def conditional_includes_file(tmp_path):
    """Create a C file with conditional includes."""
    code = '''
#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>

#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

#endif
'''
    file_path = tmp_path / "header.h"
    file_path.write_text(code)
    return file_path


class TestSystemIncludes:
    """Test system header include parsing."""

    def test_parses_system_includes(self, system_includes_file):
        imports = parse_c_imports(system_includes_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        assert 'stdio.h' in modules or any('stdio' in m for m in modules)
        assert 'stdlib.h' in modules or any('stdlib' in m for m in modules)

    def test_system_include_angle_brackets(self, system_includes_file):
        imports = parse_c_imports(system_includes_file)
        # System includes use angle brackets
        for imp in imports:
            # Should have some indicator of system include
            assert 'module' in imp


class TestLocalIncludes:
    """Test local header include parsing."""

    def test_parses_local_includes(self, local_includes_file):
        imports = parse_c_imports(local_includes_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        assert 'utils.h' in modules or any('utils' in m for m in modules)

    def test_relative_path_includes(self, local_includes_file):
        imports = parse_c_imports(local_includes_file)
        modules = [imp['module'] for imp in imports]
        # Should capture relative path include
        assert any('common' in m or 'types' in m for m in modules)


class TestMixedIncludes:
    """Test mixed include scenarios."""

    def test_mixed_includes(self, mixed_includes_file):
        imports = parse_c_imports(mixed_includes_file)
        # Should have all includes
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various include types are captured
        assert any('stdio' in m for m in modules)
        assert any('utils' in m for m in modules)


class TestConditionalIncludes:
    """Test conditional preprocessing includes."""

    def test_conditional_includes_parsed(self, conditional_includes_file):
        imports = parse_c_imports(conditional_includes_file)
        # Should capture includes even in conditional blocks
        assert len(imports) >= 1
        modules = [imp['module'] for imp in imports]
        assert any('stdio' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "empty.c"
        file_path.write_text("int main() { return 0; }")
        imports = parse_c_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "nonexistent.c"
        imports = parse_c_imports(file_path)
        assert imports == []

    def test_commented_include(self, tmp_path):
        code = '''
// #include <commented.h>
/* #include <block_commented.h> */
#include <actual.h>

int main() { return 0; }
'''
        file_path = tmp_path / "main.c"
        file_path.write_text(code)
        imports = parse_c_imports(file_path)
        modules = [imp['module'] for imp in imports]
        # Should only have actual.h, not commented ones
        assert len([m for m in modules if 'actual' in m]) >= 1
