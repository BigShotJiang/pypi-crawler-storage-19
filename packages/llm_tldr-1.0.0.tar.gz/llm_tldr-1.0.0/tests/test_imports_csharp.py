"""Tests for C# import (using directive) parsing.

TDD Tests - Expected to fail until C# support is implemented.
C# uses tree-sitter-c-sharp (hyphen in package name, underscore in Python import).
"""
import pytest
import tempfile
from pathlib import Path

# Check if tree-sitter-c-sharp is available
try:
    from tldr.cross_file_calls import parse_csharp_imports, TREE_SITTER_CSHARP_AVAILABLE
    CSHARP_AVAILABLE = TREE_SITTER_CSHARP_AVAILABLE
except ImportError:
    CSHARP_AVAILABLE = False


pytestmark = pytest.mark.skipif(not CSHARP_AVAILABLE, reason="tree-sitter-c-sharp not available")


@pytest.fixture
def simple_using_file(tmp_path):
    """Create a C# file with simple using directives."""
    code = '''
using System;
using System.Collections.Generic;

namespace Example {
    public class Sample {
        public void Process(List<string> items) {
            Console.WriteLine("Processing");
        }
    }
}
'''
    file_path = tmp_path / "Sample.cs"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def static_using_file(tmp_path):
    """Create a C# file with static using directives."""
    code = '''
using System;
using static System.Math;
using static System.Console;

namespace Example {
    public class Calc {
        public double Calculate() {
            WriteLine("Calculating PI");
            return PI * 2;
        }
    }
}
'''
    file_path = tmp_path / "Calc.cs"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def alias_using_file(tmp_path):
    """Create a C# file with alias using directives."""
    code = '''
using System;
using Col = System.Collections.Generic;
using Dict = System.Collections.Generic.Dictionary<string, int>;

namespace Example {
    public class Sample {
        public void Process() {
            Col.List<int> items = new Col.List<int>();
        }
    }
}
'''
    file_path = tmp_path / "AliasExample.cs"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def global_using_file(tmp_path):
    """Create a C# file with global using directives (C# 10+)."""
    code = '''
global using System;
global using System.Collections.Generic;
using System.Linq;

namespace Example {
    public class Sample {
        public void Process() { }
    }
}
'''
    file_path = tmp_path / "GlobalUsing.cs"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_using_file(tmp_path):
    """Create a C# file with mixed using directives."""
    code = '''
using System;
using System.Collections.Generic;
using System.Linq;
using static System.Math;
using Col = System.Collections;
using MyApp.Utils;

namespace MyApp.Core {
    public class Processor {
        public void Process() { }
    }
}
'''
    file_path = tmp_path / "Processor.cs"
    file_path.write_text(code)
    return file_path


class TestSimpleUsing:
    """Test basic using directive parsing."""

    def test_parses_simple_using(self, simple_using_file):
        imports = parse_csharp_imports(simple_using_file)
        assert len(imports) == 2
        modules = [imp['module'] for imp in imports]
        assert 'System' in modules
        assert 'System.Collections.Generic' in modules

    def test_static_using(self, static_using_file):
        imports = parse_csharp_imports(static_using_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        # Static usings should be captured
        assert any('System.Math' in m or 'Math' in m for m in modules)
        assert any('System.Console' in m or 'Console' in m for m in modules)

    def test_alias_using(self, alias_using_file):
        imports = parse_csharp_imports(alias_using_file)
        assert len(imports) >= 2
        # Should capture the aliased imports
        modules = [imp['module'] for imp in imports]
        assert any('Collections' in m for m in modules)


class TestGlobalUsing:
    """Test C# 10+ global using directives."""

    def test_global_using(self, global_using_file):
        imports = parse_csharp_imports(global_using_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        assert any('System' in m for m in modules)


class TestMixedUsing:
    """Test mixed using scenarios."""

    def test_mixed_using(self, mixed_using_file):
        imports = parse_csharp_imports(mixed_using_file)
        # Should have all using directives
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various using types are captured
        assert any('System' in m for m in modules)
        assert any('Linq' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "Empty.cs"
        file_path.write_text("namespace Empty { public class EmptyClass { } }")
        imports = parse_csharp_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "NonExistent.cs"
        imports = parse_csharp_imports(file_path)
        assert imports == []

    def test_only_namespace_declaration(self, tmp_path):
        code = '''
namespace MyApp {
    public class NoUsings {
        public void Test() { }
    }
}
'''
        file_path = tmp_path / "NoUsings.cs"
        file_path.write_text(code)
        imports = parse_csharp_imports(file_path)
        assert imports == []

    def test_file_scoped_namespace(self, tmp_path):
        """Test C# 10+ file-scoped namespace syntax."""
        code = '''
using System;
using System.Collections.Generic;

namespace MyApp;

public class Sample {
    public void Process() { }
}
'''
        file_path = tmp_path / "FileScopedNs.cs"
        file_path.write_text(code)
        imports = parse_csharp_imports(file_path)
        assert len(imports) == 2
        modules = [imp['module'] for imp in imports]
        assert 'System' in modules
