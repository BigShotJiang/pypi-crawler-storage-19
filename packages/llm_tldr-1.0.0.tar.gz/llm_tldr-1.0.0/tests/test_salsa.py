"""Tests for tldr.salsa module - Salsa-style query memoization (P5).

Salsa is rust-analyzer's incremental computation framework. Key concepts:
1. Queries as functions - everything is a query with automatic memoization
2. Automatic dependency tracking - queries record which other queries they call
3. Minimal re-computation - only affected queries re-run on change
"""
import pytest
from typing import List, Dict, Any


class TestSalsaQueryDecorator:
    """Tests for @salsa_query decorator."""

    def test_salsa_query_decorator_basic(self):
        """@salsa_query should make function callable through SalsaDB."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def get_value(key: str) -> str:
            return f"value_{key}"

        db = SalsaDB()
        result = db.query(get_value, "test")
        assert result == "value_test"

    def test_salsa_query_with_multiple_args(self):
        """@salsa_query should work with multiple arguments."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def add_values(a: int, b: int) -> int:
            return a + b

        db = SalsaDB()
        result = db.query(add_values, 3, 5)
        assert result == 8

    def test_salsa_query_preserves_function_name(self):
        """@salsa_query should preserve function metadata."""
        from tldr.salsa import salsa_query

        @salsa_query
        def my_custom_query(x: int) -> int:
            """My docstring."""
            return x * 2

        assert my_custom_query.__name__ == "my_custom_query"
        assert "docstring" in my_custom_query.__doc__


class TestSalsaMemoization:
    """Tests for query memoization."""

    def test_salsa_memoization_returns_cached(self):
        """Same query should return cached result without re-computing."""
        from tldr.salsa import SalsaDB, salsa_query

        call_count = 0

        @salsa_query
        def expensive_query(key: str) -> str:
            nonlocal call_count
            call_count += 1
            return f"computed_{key}"

        db = SalsaDB()

        # First call - should compute
        result1 = db.query(expensive_query, "test")
        assert result1 == "computed_test"
        assert call_count == 1

        # Second call - should use cache
        result2 = db.query(expensive_query, "test")
        assert result2 == "computed_test"
        assert call_count == 1  # Not incremented!

    def test_salsa_memoization_different_args(self):
        """Different args should compute separately."""
        from tldr.salsa import SalsaDB, salsa_query

        call_count = 0

        @salsa_query
        def query_with_arg(key: str) -> str:
            nonlocal call_count
            call_count += 1
            return f"result_{key}"

        db = SalsaDB()

        db.query(query_with_arg, "a")
        assert call_count == 1

        db.query(query_with_arg, "b")
        assert call_count == 2

        # Both should now be cached
        db.query(query_with_arg, "a")
        db.query(query_with_arg, "b")
        assert call_count == 2


class TestSalsaDependencyTracking:
    """Tests for automatic dependency tracking."""

    def test_salsa_tracks_query_dependencies(self):
        """Queries should track which other queries they call."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def get_file_content(path: str) -> str:
            return f"content_of_{path}"

        @salsa_query
        def parse_file(db: SalsaDB, path: str) -> dict:
            content = db.query(get_file_content, path)
            return {"parsed": content}

        db = SalsaDB()
        db.query(parse_file, db, "test.py")

        # Check dependencies were tracked
        deps = db.get_dependencies(parse_file, db, "test.py")
        assert len(deps) == 1
        assert (get_file_content, ("test.py",)) in deps

    def test_salsa_tracks_nested_dependencies(self):
        """Nested query calls should all be tracked."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def level_3(x: int) -> int:
            return x * 2

        @salsa_query
        def level_2(db: SalsaDB, x: int) -> int:
            return db.query(level_3, x) + 1

        @salsa_query
        def level_1(db: SalsaDB, x: int) -> int:
            return db.query(level_2, db, x) + 10

        db = SalsaDB()
        result = db.query(level_1, db, 5)
        assert result == 21  # (5*2) + 1 + 10

        # level_1 depends on level_2 - check function is in deps
        deps_1 = db.get_dependencies(level_1, db, 5)
        dep_funcs_1 = [dep[0] for dep in deps_1]
        assert level_2 in dep_funcs_1

        # level_2 depends on level_3
        deps_2 = db.get_dependencies(level_2, db, 5)
        assert (level_3, (5,)) in deps_2


class TestSalsaInvalidation:
    """Tests for cache invalidation."""

    def test_salsa_invalidation_propagates(self):
        """Invalidating a query should invalidate its dependents."""
        from tldr.salsa import SalsaDB, salsa_query

        call_counts = {"read": 0, "parse": 0}

        @salsa_query
        def read_file(path: str) -> str:
            call_counts["read"] += 1
            return f"content_{call_counts['read']}"

        @salsa_query
        def parse_file(db: SalsaDB, path: str) -> dict:
            call_counts["parse"] += 1
            content = db.query(read_file, path)
            return {"parsed": content}

        db = SalsaDB()

        # Initial computation
        result1 = db.query(parse_file, db, "test.py")
        assert result1 == {"parsed": "content_1"}
        assert call_counts["read"] == 1
        assert call_counts["parse"] == 1

        # Invalidate read_file - should cascade to parse_file
        db.invalidate(read_file, "test.py")

        # Re-query should recompute both
        result2 = db.query(parse_file, db, "test.py")
        assert result2 == {"parsed": "content_2"}
        assert call_counts["read"] == 2
        assert call_counts["parse"] == 2

    def test_salsa_partial_invalidation(self):
        """Only affected queries should re-run."""
        from tldr.salsa import SalsaDB, salsa_query

        call_counts = {"a": 0, "b": 0, "combined": 0}

        @salsa_query
        def query_a() -> str:
            call_counts["a"] += 1
            return f"a_{call_counts['a']}"

        @salsa_query
        def query_b() -> str:
            call_counts["b"] += 1
            return f"b_{call_counts['b']}"

        @salsa_query
        def combined_query(db: SalsaDB) -> str:
            call_counts["combined"] += 1
            a = db.query(query_a)
            b = db.query(query_b)
            return f"{a}+{b}"

        db = SalsaDB()

        # Initial computation
        result1 = db.query(combined_query, db)
        assert result1 == "a_1+b_1"

        # Invalidate only query_a
        db.invalidate(query_a)

        # combined_query should recompute, but query_b should be cached
        result2 = db.query(combined_query, db)
        assert result2 == "a_2+b_1"  # b stays at 1!
        assert call_counts["a"] == 2
        assert call_counts["b"] == 1  # Not recomputed!
        assert call_counts["combined"] == 2


class TestSalsaRevisionTracking:
    """Tests for file revision tracking."""

    def test_salsa_revision_tracking(self):
        """File revisions should be tracked correctly."""
        from tldr.salsa import SalsaDB

        db = SalsaDB()

        # Set initial content
        db.set_file("test.py", "print('hello')")
        assert db.get_revision("test.py") == 1

        # Update content
        db.set_file("test.py", "print('world')")
        assert db.get_revision("test.py") == 2

        # Another file doesn't affect revision
        db.set_file("other.py", "x = 1")
        assert db.get_revision("test.py") == 2
        assert db.get_revision("other.py") == 1

    def test_salsa_no_recompute_unchanged(self):
        """Unchanged files shouldn't trigger recomputation."""
        from tldr.salsa import SalsaDB, salsa_query

        compute_count = 0

        @salsa_query
        def process_file(db: SalsaDB, path: str) -> str:
            nonlocal compute_count
            compute_count += 1
            content = db.get_file(path)
            return f"processed: {content}"

        db = SalsaDB()
        db.set_file("test.py", "original")

        # First computation
        result1 = db.query(process_file, db, "test.py")
        assert compute_count == 1

        # Same content again - shouldn't recompute
        db.query(process_file, db, "test.py")
        assert compute_count == 1

        # Different file - separate computation
        db.set_file("other.py", "other")
        db.query(process_file, db, "other.py")
        assert compute_count == 2


class TestSalsaDiamondDependency:
    """Tests for diamond-shaped dependency handling."""

    def test_salsa_diamond_dependency(self):
        r"""Diamond dependencies should be handled correctly.

            A
           / \
          B   C
           \ /
            D

        If D changes, both B and C should be invalidated,
        and A should recompute once (not twice).
        """
        from tldr.salsa import SalsaDB, salsa_query

        call_counts = {"a": 0, "b": 0, "c": 0, "d": 0}

        @salsa_query
        def query_d() -> int:
            call_counts["d"] += 1
            return call_counts["d"]

        @salsa_query
        def query_b(db: SalsaDB) -> int:
            call_counts["b"] += 1
            return db.query(query_d) * 2

        @salsa_query
        def query_c(db: SalsaDB) -> int:
            call_counts["c"] += 1
            return db.query(query_d) * 3

        @salsa_query
        def query_a(db: SalsaDB) -> int:
            call_counts["a"] += 1
            b = db.query(query_b, db)
            c = db.query(query_c, db)
            return b + c

        db = SalsaDB()

        # Initial computation: d=1, b=2, c=3, a=5
        result1 = db.query(query_a, db)
        assert result1 == 5  # (1*2) + (1*3)
        assert call_counts == {"a": 1, "b": 1, "c": 1, "d": 1}

        # Invalidate D
        db.invalidate(query_d)

        # Recompute A - D should only run once despite being dep of both B and C
        result2 = db.query(query_a, db)
        assert result2 == 10  # (2*2) + (2*3)
        assert call_counts["d"] == 2  # Only 2, not 3!
        assert call_counts["a"] == 2
        assert call_counts["b"] == 2
        assert call_counts["c"] == 2


class TestSalsaDBStats:
    """Tests for database statistics."""

    def test_salsa_db_stats_basic(self):
        """SalsaDB should track cache hits and misses."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def simple_query(x: int) -> int:
            return x * 2

        db = SalsaDB()

        # First call - miss
        db.query(simple_query, 5)
        stats = db.get_stats()
        assert stats["cache_hits"] == 0
        assert stats["cache_misses"] == 1

        # Second call - hit
        db.query(simple_query, 5)
        stats = db.get_stats()
        assert stats["cache_hits"] == 1
        assert stats["cache_misses"] == 1

        # Different arg - miss
        db.query(simple_query, 10)
        stats = db.get_stats()
        assert stats["cache_hits"] == 1
        assert stats["cache_misses"] == 2

    def test_salsa_db_stats_invalidations(self):
        """Stats should track invalidation count."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def tracked_query(x: int) -> int:
            return x

        db = SalsaDB()
        db.query(tracked_query, 1)
        db.query(tracked_query, 2)

        db.invalidate(tracked_query, 1)
        stats = db.get_stats()
        assert stats["invalidations"] == 1

        db.invalidate(tracked_query, 2)
        stats = db.get_stats()
        assert stats["invalidations"] == 2

    def test_salsa_db_stats_recomputations(self):
        """Stats should track recomputation count."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def recomputed_query() -> int:
            return 42

        db = SalsaDB()

        db.query(recomputed_query)
        stats = db.get_stats()
        assert stats["recomputations"] == 1

        db.invalidate(recomputed_query)
        db.query(recomputed_query)
        stats = db.get_stats()
        assert stats["recomputations"] == 2


class TestSalsaIntegrationWithTLDR:
    """Integration tests with TLDR operations."""

    def test_integration_extract_and_calls(self):
        """Integration test with file extraction and call graph queries."""
        from tldr.salsa import SalsaDB, salsa_query
        import tempfile
        import os

        # Define TLDR-like queries
        @salsa_query
        def read_source(db: SalsaDB, path: str) -> str:
            return db.get_file(path)

        @salsa_query
        def extract_functions(db: SalsaDB, path: str) -> List[str]:
            content = db.query(read_source, db, path)
            # Simple extraction: find 'def ' lines
            functions = []
            for line in content.split('\n'):
                if line.strip().startswith('def '):
                    name = line.split('def ')[1].split('(')[0]
                    functions.append(name)
            return functions

        @salsa_query
        def get_function_calls(db: SalsaDB, path: str) -> Dict[str, List[str]]:
            content = db.query(read_source, db, path)
            functions = db.query(extract_functions, db, path)
            # Simplified call extraction
            calls = {f: [] for f in functions}
            return calls

        db = SalsaDB()

        # Set up file content
        db.set_file("auth.py", """
def login(user):
    validate(user)

def validate(user):
    pass
""")

        # Query functions
        funcs = db.query(extract_functions, db, "auth.py")
        assert "login" in funcs
        assert "validate" in funcs

        # Update file - should invalidate dependent queries
        db.set_file("auth.py", """
def login(user):
    validate(user)

def validate(user):
    pass

def logout(user):
    pass
""")

        # Re-query - should see new function
        funcs2 = db.query(extract_functions, db, "auth.py")
        assert "logout" in funcs2

    def test_integration_cross_file_dependencies(self):
        """Test cross-file dependency tracking."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def get_imports(db: SalsaDB, path: str) -> List[str]:
            content = db.get_file(path)
            imports = []
            for line in content.split('\n'):
                if line.startswith('from ') or line.startswith('import '):
                    imports.append(line)
            return imports

        @salsa_query
        def get_all_imports(db: SalsaDB, paths: tuple) -> Dict[str, List[str]]:
            result = {}
            for path in paths:
                result[path] = db.query(get_imports, db, path)
            return result

        db = SalsaDB()
        db.set_file("a.py", "from b import x")
        db.set_file("b.py", "import os")

        imports = db.query(get_all_imports, db, ("a.py", "b.py"))
        assert "from b import x" in imports["a.py"]
        assert "import os" in imports["b.py"]


class TestSalsaEdgeCases:
    """Tests for edge cases and error handling."""

    def test_query_with_no_args(self):
        """Query with no arguments should work."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def constant_query() -> int:
            return 42

        db = SalsaDB()
        assert db.query(constant_query) == 42

    def test_query_returns_none(self):
        """Query returning None should be cached properly."""
        from tldr.salsa import SalsaDB, salsa_query

        call_count = 0

        @salsa_query
        def none_query() -> None:
            nonlocal call_count
            call_count += 1
            return None

        db = SalsaDB()
        result1 = db.query(none_query)
        assert result1 is None
        assert call_count == 1

        result2 = db.query(none_query)
        assert result2 is None
        assert call_count == 1  # Still cached

    def test_get_file_nonexistent(self):
        """Getting nonexistent file should return None or raise."""
        from tldr.salsa import SalsaDB

        db = SalsaDB()
        result = db.get_file("nonexistent.py")
        assert result is None

    def test_invalidate_uncached_query(self):
        """Invalidating uncached query should be safe."""
        from tldr.salsa import SalsaDB, salsa_query

        @salsa_query
        def uncached_query() -> int:
            return 1

        db = SalsaDB()
        # Should not raise
        db.invalidate(uncached_query)

    def test_clear_all_cache(self):
        """clear() should remove all cached queries."""
        from tldr.salsa import SalsaDB, salsa_query

        call_count = 0

        @salsa_query
        def counted_query(x: int) -> int:
            nonlocal call_count
            call_count += 1
            return x

        db = SalsaDB()
        db.query(counted_query, 1)
        db.query(counted_query, 2)
        assert call_count == 2

        # Clear all
        db.clear()

        # Should recompute
        db.query(counted_query, 1)
        db.query(counted_query, 2)
        assert call_count == 4
