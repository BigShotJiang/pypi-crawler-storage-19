"""Tests for cross-file call graph resolution."""

import tempfile
import os
from pathlib import Path


def test_cross_file_call_resolution():
    """Call graph should resolve calls across files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create module structure
        Path(tmpdir, "main.py").write_text('''
from utils import helper
def main():
    return helper()
''')
        Path(tmpdir, "utils.py").write_text('''
def helper():
    return 42
''')

        # Build cross-file call graph
        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        # main.py:main should have edge to utils.py:helper
        assert ("main.py", "main", "utils.py", "helper") in graph.edges


def test_cross_file_aliased_import():
    """Call graph should handle aliased imports."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.py").write_text('''
from utils import helper as h
def main():
    return h()
''')
        Path(tmpdir, "utils.py").write_text('''
def helper():
    return 42
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        # Should resolve alias to original function
        assert ("main.py", "main", "utils.py", "helper") in graph.edges


def test_cross_file_module_import():
    """Call graph should handle module-level imports."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.py").write_text('''
import utils
def main():
    return utils.helper()
''')
        Path(tmpdir, "utils.py").write_text('''
def helper():
    return 42
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        assert ("main.py", "main", "utils.py", "helper") in graph.edges


def test_cross_file_nested_package():
    """Call graph should handle nested package imports."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create nested package
        pkg_dir = Path(tmpdir, "pkg")
        pkg_dir.mkdir()
        Path(pkg_dir, "__init__.py").write_text('')
        Path(pkg_dir, "core.py").write_text('''
def process():
    return "processed"
''')
        Path(tmpdir, "main.py").write_text('''
from pkg.core import process
def main():
    return process()
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        assert ("main.py", "main", "pkg/core.py", "process") in graph.edges


def test_cross_file_no_external_deps():
    """Call graph should only include project-internal calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.py").write_text('''
import os
from utils import helper
def main():
    os.getcwd()  # External - should NOT be in graph
    return helper()  # Internal - should be in graph
''')
        Path(tmpdir, "utils.py").write_text('''
def helper():
    return 42
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        # Internal call should be present
        assert ("main.py", "main", "utils.py", "helper") in graph.edges
        # External call should NOT be present
        external_edges = [e for e in graph.edges if "os" in str(e)]
        assert len(external_edges) == 0


def test_cross_file_class_method_calls():
    """Call graph should handle calls to class methods."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.py").write_text('''
from service import MyService
def main():
    svc = MyService()
    return svc.run()
''')
        Path(tmpdir, "service.py").write_text('''
class MyService:
    def run(self):
        return "running"
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        # Should track instantiation
        assert ("main.py", "main", "service.py", "MyService") in graph.edges


def test_project_call_graph_edges_property():
    """ProjectCallGraph should provide edges as tuples."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "a.py").write_text('''
from b import func_b
def func_a():
    return func_b()
''')
        Path(tmpdir, "b.py").write_text('''
def func_b():
    return 1
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        # edges should be iterable of (src_file, src_func, dst_file, dst_func)
        edges = list(graph.edges)
        assert len(edges) >= 1
        assert all(len(e) == 4 for e in edges)


def test_intra_file_calls_preserved():
    """Cross-file graph should also include intra-file calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "utils.py").write_text('''
def helper():
    return inner()

def inner():
    return 42
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir)

        # Intra-file call: helper -> inner (same file)
        assert ("utils.py", "helper", "utils.py", "inner") in graph.edges


def test_scan_project_finds_python_files():
    """scan_project should find all .py files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "a.py").write_text('')
        Path(tmpdir, "b.py").write_text('')
        subdir = Path(tmpdir, "sub")
        subdir.mkdir()
        Path(subdir, "c.py").write_text('')
        Path(tmpdir, "readme.md").write_text('')  # Not Python

        from tldr.cross_file_calls import scan_project
        files = scan_project(tmpdir)

        assert len(files) == 3
        assert all(f.endswith('.py') for f in files)


def test_parse_imports():
    """parse_imports should extract import statements."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "test.py").write_text('''
import os
from pathlib import Path
from utils import helper, formatter
import json as j
from pkg.core import process as proc
''')

        from tldr.cross_file_calls import parse_imports
        imports = parse_imports(Path(tmpdir, "test.py"))

        # Should have 5 import entries
        assert len(imports) == 5

        # Check structure
        assert any(i['module'] == 'os' and not i['is_from'] for i in imports)
        assert any(i['module'] == 'pathlib' and 'Path' in i['names'] for i in imports)
        assert any(i['module'] == 'utils' and 'helper' in i['names'] for i in imports)


def test_build_function_index():
    """build_function_index should map module.func to file paths."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "utils.py").write_text('''
def helper():
    pass

def formatter():
    pass
''')
        Path(tmpdir, "core.py").write_text('''
def process():
    pass
''')

        from tldr.cross_file_calls import build_function_index
        index = build_function_index(tmpdir)

        # Should map function names to their file locations
        assert 'utils.helper' in index or ('utils', 'helper') in index
        assert 'utils.formatter' in index or ('utils', 'formatter') in index
        assert 'core.process' in index or ('core', 'process') in index


# ============ TypeScript Tests ============

def test_ts_cross_file_call_resolution():
    """TypeScript call graph should resolve calls across files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.ts").write_text('''
import { helper } from "./utils";

export function main() {
    return helper();
}
''')
        Path(tmpdir, "utils.ts").write_text('''
export function helper() {
    return 42;
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="typescript")

        # main.ts:main should have edge to utils.ts:helper
        assert ("main.ts", "main", "utils.ts", "helper") in graph.edges


def test_ts_cross_file_aliased_import():
    """TypeScript call graph should handle aliased imports."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.ts").write_text('''
import { helper as h } from "./utils";

function main() {
    return h();
}
''')
        Path(tmpdir, "utils.ts").write_text('''
export function helper() {
    return 42;
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="typescript")

        # Should resolve alias to original function
        assert ("main.ts", "main", "utils.ts", "helper") in graph.edges


def test_ts_intra_file_calls():
    """TypeScript cross-file graph should include intra-file calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "utils.ts").write_text('''
function inner() {
    return 42;
}

export function helper() {
    return inner();
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="typescript")

        # Intra-file call: helper -> inner (same file)
        assert ("utils.ts", "helper", "utils.ts", "inner") in graph.edges


def test_ts_arrow_function_calls():
    """TypeScript should handle arrow functions."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.ts").write_text('''
import { helper } from "./utils";

const main = () => {
    return helper();
};
''')
        Path(tmpdir, "utils.ts").write_text('''
export const helper = () => {
    return 42;
};
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="typescript")

        assert ("main.ts", "main", "utils.ts", "helper") in graph.edges


def test_ts_class_method_calls():
    """TypeScript should handle class method calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "service.ts").write_text('''
export class MyService {
    process() {
        return this.helper();
    }

    helper() {
        return 42;
    }
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="typescript")

        # Method calling another method in same class
        assert ("service.ts", "MyService.process", "service.ts", "helper") in graph.edges


def test_ts_scan_project_finds_ts_files():
    """scan_project should find .ts and .tsx files for typescript."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "a.ts").write_text('')
        Path(tmpdir, "b.tsx").write_text('')
        subdir = Path(tmpdir, "sub")
        subdir.mkdir()
        Path(subdir, "c.ts").write_text('')
        Path(tmpdir, "d.py").write_text('')  # Not TypeScript
        Path(tmpdir, "readme.md").write_text('')

        from tldr.cross_file_calls import scan_project
        files = scan_project(tmpdir, language="typescript")

        assert len(files) == 3
        assert all(f.endswith('.ts') or f.endswith('.tsx') for f in files)


def test_ts_scan_project_skips_node_modules():
    """scan_project should skip node_modules directory."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.ts").write_text('')
        node_modules = Path(tmpdir, "node_modules")
        node_modules.mkdir()
        Path(node_modules, "lib.ts").write_text('')

        from tldr.cross_file_calls import scan_project
        files = scan_project(tmpdir, language="typescript")

        assert len(files) == 1
        assert files[0].endswith("main.ts")


def test_ts_parse_imports():
    """parse_ts_imports should extract import statements."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "test.ts").write_text('''
import { foo, bar } from "./utils";
import DefaultClass from "./default";
import * as utils from "./all";
import { baz as b } from "./aliased";
''')

        from tldr.cross_file_calls import parse_ts_imports
        imports = parse_ts_imports(Path(tmpdir, "test.ts"))

        # Should have 4 import entries
        assert len(imports) == 4

        # Check named imports
        utils_imp = next((i for i in imports if i['module'] == './utils'), None)
        assert utils_imp is not None
        assert 'foo' in utils_imp['names']
        assert 'bar' in utils_imp['names']

        # Check default import
        default_imp = next((i for i in imports if i['module'] == './default'), None)
        assert default_imp is not None
        assert default_imp['default'] == 'DefaultClass'

        # Check namespace import
        all_imp = next((i for i in imports if i['module'] == './all'), None)
        assert all_imp is not None
        assert 'utils' in all_imp['aliases']
        assert all_imp['aliases']['utils'] == '*'

        # Check aliased import
        aliased_imp = next((i for i in imports if i['module'] == './aliased'), None)
        assert aliased_imp is not None
        assert 'baz' in aliased_imp['names']
        assert 'b' in aliased_imp['aliases']


def test_ts_build_function_index():
    """build_function_index should map TypeScript functions to file paths."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "utils.ts").write_text('''
export function helper() {
    return 1;
}

export const formatter = () => {
    return 2;
};
''')
        Path(tmpdir, "core.ts").write_text('''
function process() {
    return 3;
}

export class Service {
    run() {
        return 4;
    }
}
''')

        from tldr.cross_file_calls import build_function_index
        index = build_function_index(tmpdir, language="typescript")

        # Should map function names to their file locations
        assert ('utils', 'helper') in index
        assert ('utils', 'formatter') in index
        assert ('core', 'process') in index
        assert ('core', 'Service') in index


def test_ts_nested_directory_imports():
    """TypeScript call graph should handle nested directory imports."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create nested structure
        services_dir = Path(tmpdir, "services")
        services_dir.mkdir()
        Path(services_dir, "user.ts").write_text('''
export function getUser() {
    return { id: 1 };
}
''')
        Path(tmpdir, "main.ts").write_text('''
import { getUser } from "./services/user";

export function main() {
    return getUser();
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="typescript")

        # main.ts:main should have edge to services/user.ts:getUser
        assert ("main.ts", "main", "services/user.ts", "getUser") in graph.edges


# ============ Go Tests ============

def test_go_cross_file_call_resolution():
    """Go call graph should resolve calls across files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.go").write_text('''
package main

import "./utils"

func main() {
    utils.Helper()
}
''')
        Path(tmpdir, "utils.go").write_text('''
package utils

func Helper() int {
    return 42
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="go")

        # main.go:main should have edge to utils.go:Helper
        assert ("main.go", "main", "utils.go", "Helper") in graph.edges


def test_go_intra_file_calls():
    """Go cross-file graph should include intra-file calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "utils.go").write_text('''
package utils

func inner() int {
    return 42
}

func Helper() int {
    return inner()
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="go")

        # Intra-file call: Helper -> inner (same file)
        assert ("utils.go", "Helper", "utils.go", "inner") in graph.edges


def test_go_package_imports():
    """Go call graph should handle package imports."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create package structure
        pkg_dir = Path(tmpdir, "pkg")
        pkg_dir.mkdir()
        Path(pkg_dir, "service.go").write_text('''
package pkg

func Process() string {
    return "processed"
}
''')
        Path(tmpdir, "main.go").write_text('''
package main

import "./pkg"

func main() {
    pkg.Process()
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="go")

        # main.go:main should have edge to pkg/service.go:Process
        assert ("main.go", "main", "pkg/service.go", "Process") in graph.edges


def test_go_scan_project_finds_go_files():
    """scan_project should find .go files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.go").write_text('')
        Path(tmpdir, "utils.go").write_text('')
        subdir = Path(tmpdir, "internal")
        subdir.mkdir()
        Path(subdir, "helper.go").write_text('')
        Path(tmpdir, "readme.md").write_text('')  # Not Go
        Path(tmpdir, "test.py").write_text('')  # Not Go

        from tldr.cross_file_calls import scan_project
        files = scan_project(tmpdir, language="go")

        assert len(files) == 3
        assert all(f.endswith('.go') for f in files)


def test_go_build_function_index():
    """build_function_index should map Go functions to file paths."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "utils.go").write_text('''
package utils

func Helper() int {
    return 1
}

func Formatter() string {
    return "formatted"
}
''')
        Path(tmpdir, "core.go").write_text('''
package core

func Process() bool {
    return true
}

type Service struct {}

func (s *Service) Run() {}
''')

        from tldr.cross_file_calls import build_function_index
        index = build_function_index(tmpdir, language="go")

        # Should map function names to their file locations
        assert ('utils', 'Helper') in index
        assert ('utils', 'Formatter') in index
        assert ('core', 'Process') in index
        assert ('core', 'Service') in index


def test_go_parse_imports():
    """parse_go_imports should extract import statements."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "test.go").write_text('''
package main

import "fmt"

import (
    "os"
    "strings"
    utils "./internal/utils"
)

func main() {}
''')

        from tldr.cross_file_calls import parse_go_imports
        imports = parse_go_imports(Path(tmpdir, "test.go"))

        # Should have 4 import entries
        assert len(imports) == 4

        # Check basic import
        fmt_imp = next((i for i in imports if i['module'] == 'fmt'), None)
        assert fmt_imp is not None

        # Check grouped imports
        assert any(i['module'] == 'os' for i in imports)
        assert any(i['module'] == 'strings' for i in imports)

        # Check aliased import
        utils_imp = next((i for i in imports if i.get('alias') == 'utils'), None)
        assert utils_imp is not None


def test_go_method_calls():
    """Go should handle method calls within the same package."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "service.go").write_text('''
package service

type MyService struct{}

func (s *MyService) Process() int {
    return s.helper()
}

func (s *MyService) helper() int {
    return 42
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="go")

        # Method calling another method - should be tracked as intra-file
        edges = list(graph.edges)
        assert len(edges) >= 1  # Should have at least one edge


# ============ Rust Tests ============

def test_rust_cross_file_call_resolution():
    """Rust call graph should resolve calls across files via use statements."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.rs").write_text('''
mod utils;
use crate::utils::helper;

fn main() {
    helper();
}
''')
        Path(tmpdir, "utils.rs").write_text('''
pub fn helper() -> i32 {
    42
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="rust")

        # main.rs:main should have edge to utils.rs:helper
        assert ("main.rs", "main", "utils.rs", "helper") in graph.edges


def test_rust_intra_file_calls():
    """Rust cross-file graph should include intra-file calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "lib.rs").write_text('''
fn inner() -> i32 {
    42
}

pub fn outer() -> i32 {
    inner()
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="rust")

        # Intra-file call: outer -> inner (same file)
        assert ("lib.rs", "outer", "lib.rs", "inner") in graph.edges


def test_rust_mod_imports():
    """Rust call graph should handle mod and use imports."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create module structure
        services_dir = Path(tmpdir, "services")
        services_dir.mkdir()
        Path(services_dir, "mod.rs").write_text('''
pub mod user;
''')
        Path(services_dir, "user.rs").write_text('''
pub fn get_user() -> String {
    String::from("user")
}
''')
        Path(tmpdir, "main.rs").write_text('''
mod services;
use services::user::get_user;

fn main() {
    get_user();
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="rust")

        # main.rs:main should have edge to services/user.rs:get_user
        assert ("main.rs", "main", "services/user.rs", "get_user") in graph.edges


def test_rust_scan_project_finds_rs_files():
    """scan_project should find .rs files for Rust."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.rs").write_text('')
        Path(tmpdir, "lib.rs").write_text('')
        subdir = Path(tmpdir, "sub")
        subdir.mkdir()
        Path(subdir, "mod.rs").write_text('')
        Path(tmpdir, "readme.md").write_text('')  # Not Rust
        Path(tmpdir, "script.py").write_text('')  # Not Rust

        from tldr.cross_file_calls import scan_project
        files = scan_project(tmpdir, language="rust")

        assert len(files) == 3
        assert all(f.endswith('.rs') for f in files)


def test_rust_build_function_index():
    """build_function_index should map Rust functions to file paths."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "utils.rs").write_text('''
pub fn helper() -> i32 {
    42
}

fn private_func() {
}
''')
        Path(tmpdir, "core.rs").write_text('''
pub fn process() -> String {
    String::new()
}

pub struct Service {}

impl Service {
    pub fn run(&self) {}
}
''')

        from tldr.cross_file_calls import build_function_index
        index = build_function_index(tmpdir, language="rust")

        # Should map function names to their file locations
        assert ('utils', 'helper') in index
        assert ('utils', 'private_func') in index
        assert ('core', 'process') in index
        assert ('core', 'Service') in index


def test_rust_parse_imports():
    """parse_rust_imports should extract use statements."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "test.rs").write_text('''
use std::io;
use crate::utils::helper;
use self::inner::process;
use super::parent::func;
mod utils;
pub use crate::utils::*;
''')

        from tldr.cross_file_calls import parse_rust_imports
        imports = parse_rust_imports(Path(tmpdir, "test.rs"))

        # Should extract use statements
        assert len(imports) >= 4

        # Check that crate::utils::helper is captured
        assert any('utils' in str(i.get('module', '')) and 'helper' in str(i.get('names', [])) for i in imports)


def test_rust_impl_method_cross_file():
    """Rust call graph should resolve impl method calls across files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "service.rs").write_text('''
pub struct Service {}

impl Service {
    pub fn new() -> Self {
        Service {}
    }

    pub fn run(&self) {
        process_data();
    }
}

fn process_data() {
}
''')
        Path(tmpdir, "main.rs").write_text('''
mod service;
use service::Service;

fn main() {
    let svc = Service::new();
    svc.run();
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="rust")

        # main calls Service::new (cross-file)
        # Note: Exact edge format depends on implementation
        edges = list(graph.edges)
        # At minimum, intra-file call in service.rs should exist
        assert any(e[0] == "service.rs" and "run" in e[1] and e[2] == "service.rs" and e[3] == "process_data" for e in edges)


def test_rust_skip_target_directory():
    """scan_project should skip target/ directory (Rust build output)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "main.rs").write_text('')
        target_dir = Path(tmpdir, "target")
        target_dir.mkdir()
        debug_dir = target_dir / "debug"
        debug_dir.mkdir()
        Path(debug_dir, "build.rs").write_text('')

        from tldr.cross_file_calls import scan_project
        files = scan_project(tmpdir, language="rust")

        assert len(files) == 1
        assert files[0].endswith("main.rs")
        assert not any("target" in f for f in files)


# ============ Java Tests ============

def test_java_parse_imports():
    """parse_java_imports should extract Java import statements."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "Main.java").write_text('''
package com.example;

import java.util.List;
import java.util.Map;
import static java.lang.Math.PI;
import com.example.utils.*;

public class Main {
    public static void main(String[] args) {}
}
''')

        from tldr.cross_file_calls import parse_java_imports
        imports = parse_java_imports(Path(tmpdir, "Main.java"))

        # Should have 4 imports
        assert len(imports) == 4

        # Check regular imports
        list_imp = next((i for i in imports if i['module'] == 'java.util.List'), None)
        assert list_imp is not None

        map_imp = next((i for i in imports if i['module'] == 'java.util.Map'), None)
        assert map_imp is not None

        # Check static import
        static_imp = next((i for i in imports if i.get('is_static') is True), None)
        assert static_imp is not None
        assert 'PI' in static_imp.get('module', '') or 'Math.PI' in static_imp.get('module', '')

        # Check wildcard import
        wildcard_imp = next((i for i in imports if 'utils' in i.get('module', '')), None)
        assert wildcard_imp is not None
        assert wildcard_imp.get('is_wildcard') is True


def test_java_build_function_index():
    """build_function_index should map Java methods to file paths."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "Calculator.java").write_text('''
package com.example;

public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }

    public int multiply(int a, int b) {
        return a * b;
    }
}
''')
        Path(tmpdir, "Logger.java").write_text('''
package com.example;

public class Logger {
    public void log(String message) {
        System.out.println(message);
    }
}
''')

        from tldr.cross_file_calls import build_function_index
        index = build_function_index(tmpdir, language="java")

        # Should map method names to their file locations
        assert ('Calculator', 'add') in index
        assert ('Calculator', 'multiply') in index
        assert ('Logger', 'log') in index
        # Also indexed by class.method
        assert ('Calculator', 'Calculator.add') in index or 'Calculator.add' in [k for k in index.keys() if isinstance(k, str)]


def test_java_intra_file_calls():
    """Java cross-file graph should include intra-file calls."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "Calculator.java").write_text('''
package com.example;

public class Calculator {
    private int helper(int x) {
        return x * 2;
    }

    public int calculate(int a) {
        return helper(a);
    }
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="java")

        # Intra-file call: calculate -> helper (same file)
        edges = list(graph.edges)
        assert any(
            e[0] == "Calculator.java" and "calculate" in e[1] and
            e[2] == "Calculator.java" and e[3] == "helper"
            for e in edges
        )


def test_java_cross_file_calls():
    """Java call graph should resolve calls across files."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "Main.java").write_text('''
package com.example;

public class Main {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        calc.add(1, 2);
    }
}
''')
        Path(tmpdir, "Calculator.java").write_text('''
package com.example;

public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="java")

        edges = list(graph.edges)
        # Main.main should call Calculator.add
        # The exact edge format may vary based on implementation
        assert len(edges) >= 0  # At minimum, graph should build without error


def test_java_method_invocation_types():
    """Java call graph should handle different method invocation types."""
    with tempfile.TemporaryDirectory() as tmpdir:
        Path(tmpdir, "Service.java").write_text('''
package com.example;

public class Service {
    private Logger logger;

    public void process() {
        logger.log("Starting");  // Instance method call
        Helper.staticMethod();   // Static method call
        internalMethod();        // Direct method call
    }

    private void internalMethod() {}
}
''')
        Path(tmpdir, "Logger.java").write_text('''
package com.example;

public class Logger {
    public void log(String msg) {}
}
''')
        Path(tmpdir, "Helper.java").write_text('''
package com.example;

public class Helper {
    public static void staticMethod() {}
}
''')

        from tldr.cross_file_calls import build_project_call_graph
        graph = build_project_call_graph(tmpdir, language="java")

        edges = list(graph.edges)
        # Should have internal method call at minimum
        assert any(
            "Service.java" in e[0] and "internalMethod" in str(e)
            for e in edges
        )


def test_java_extract_file_calls():
    """_extract_java_file_calls should extract method calls grouped by caller."""
    with tempfile.TemporaryDirectory() as tmpdir:
        java_file = Path(tmpdir, "Calculator.java")
        java_file.write_text('''
package com.example;

public class Calculator {
    private Logger logger;

    public int add(int a, int b) {
        logger.log("Adding");
        return a + b;
    }

    public int multiply(int a, int b) {
        int result = add(a, b);
        logger.log("Multiplying");
        return result;
    }
}
''')

        from tldr.cross_file_calls import _extract_java_file_calls
        calls_by_func = _extract_java_file_calls(java_file, Path(tmpdir))

        # multiply should call add (intra-file) and logger.log (attr)
        assert "multiply" in calls_by_func or "Calculator.multiply" in calls_by_func
        multiply_key = "multiply" if "multiply" in calls_by_func else "Calculator.multiply"
        multiply_calls = calls_by_func.get(multiply_key, [])
        # Should have the add call as intra-file
        assert any(call_type == 'intra' and 'add' in call_target for call_type, call_target in multiply_calls)
