"""Tests for tldr extract --class and --function filtering.

TDD: Tests written before implementation.
"""

import json
import subprocess
import sys
from pathlib import Path

import pytest

# Test file with multiple classes and functions
SAMPLE_CODE = '''
def standalone_func(x: int) -> int:
    """A standalone function."""
    return x * 2

def another_func():
    """Another standalone."""
    pass

class Foo:
    """First class."""

    def __init__(self, val: str):
        self.val = val

    def method_a(self) -> str:
        return self.val

class Bar(Foo):
    """Second class inheriting from Foo."""

    def __init__(self, val: str, extra: int):
        super().__init__(val)
        self.extra = extra

    def method_b(self) -> int:
        return self.extra * 2

class Baz:
    """Third class."""
    pass
'''


@pytest.fixture
def sample_file(tmp_path):
    """Create a sample Python file for testing."""
    f = tmp_path / "sample.py"
    f.write_text(SAMPLE_CODE)
    return f


class TestExtractClassFilter:
    """Test --class filtering for tldr extract."""

    def test_extract_single_class(self, sample_file):
        """Extract only the Bar class."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file), "--class", "Bar"],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)

        # Should only have Bar class
        assert len(data["classes"]) == 1
        assert data["classes"][0]["name"] == "Bar"
        assert "Foo" in data["classes"][0]["bases"]  # Inheritance preserved

        # Should have no functions (filtered out)
        assert len(data.get("functions", [])) == 0

    def test_extract_class_with_methods(self, sample_file):
        """Extracted class should include its methods."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file), "--class", "Bar"],
            capture_output=True, text=True
        )
        data = json.loads(result.stdout)

        bar_class = data["classes"][0]
        method_names = [m["name"] for m in bar_class.get("methods", [])]
        assert "__init__" in method_names
        assert "method_b" in method_names

    def test_extract_nonexistent_class(self, sample_file):
        """Filtering for nonexistent class returns empty."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file), "--class", "NotExist"],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert len(data["classes"]) == 0


class TestExtractFunctionFilter:
    """Test --function filtering for tldr extract."""

    def test_extract_single_function(self, sample_file):
        """Extract only standalone_func."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file), "--function", "standalone_func"],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)

        # Should only have the one function
        assert len(data["functions"]) == 1
        assert data["functions"][0]["name"] == "standalone_func"
        assert "x: int" in data["functions"][0]["signature"]

        # Should have no classes (filtered out)
        assert len(data.get("classes", [])) == 0

    def test_extract_function_preserves_docstring(self, sample_file):
        """Filtered function should preserve docstring."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file), "--function", "standalone_func"],
            capture_output=True, text=True
        )
        data = json.loads(result.stdout)

        func = data["functions"][0]
        assert "standalone function" in func.get("docstring", "").lower()

    def test_extract_nonexistent_function(self, sample_file):
        """Filtering for nonexistent function returns empty."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file), "--function", "not_exists"],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)
        assert len(data["functions"]) == 0


class TestExtractCombinedFilters:
    """Test combining --class and --function filters."""

    def test_extract_class_and_function(self, sample_file):
        """Can filter for both a class and a function."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file),
             "--class", "Foo", "--function", "standalone_func"],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)

        assert len(data["classes"]) == 1
        assert data["classes"][0]["name"] == "Foo"
        assert len(data["functions"]) == 1
        assert data["functions"][0]["name"] == "standalone_func"

    def test_extract_without_filters_returns_all(self, sample_file):
        """Without filters, returns everything (existing behavior)."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file)],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)

        # Should have all 3 classes and 2 functions
        assert len(data["classes"]) == 3
        assert len(data["functions"]) == 2


class TestExtractMethodFilter:
    """Test --method filtering (Class.method syntax)."""

    def test_extract_specific_method(self, sample_file):
        """Extract only Bar.method_b."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "extract", str(sample_file), "--method", "Bar.method_b"],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        data = json.loads(result.stdout)

        # Should return the class with only that method
        assert len(data["classes"]) == 1
        assert data["classes"][0]["name"] == "Bar"
        methods = data["classes"][0].get("methods", [])
        assert len(methods) == 1
        assert methods[0]["name"] == "method_b"
