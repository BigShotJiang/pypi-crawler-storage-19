"""Tests for Go call graph extraction."""
import pytest
from pathlib import Path
from tldr.hybrid_extractor import HybridExtractor

# Skip if tree-sitter-go not available
pytest.importorskip("tree_sitter_go")


@pytest.fixture
def extractor():
    return HybridExtractor()


@pytest.fixture
def go_file_with_calls(tmp_path):
    """Go file with function calls."""
    code = '''
package main

func processData(data []byte) []byte {
    return transform(data)
}

func transform(input []byte) []byte {
    return validate(input)
}

func validate(input []byte) []byte {
    return input
}

func main() {
    data := []byte("test")
    result := processData(data)
    _ = result
}
'''
    path = tmp_path / "calls.go"
    path.write_text(code)
    return path


@pytest.fixture
def go_file_with_method_calls(tmp_path):
    """Go file with method calls."""
    code = '''
package main

type Service struct {
    name string
}

func (s *Service) Start() {
    s.prepare()
    s.run()
}

func (s *Service) prepare() {
}

func (s *Service) run() {
    s.log("running")
}

func (s *Service) log(msg string) {
}
'''
    path = tmp_path / "methods.go"
    path.write_text(code)
    return path


class TestGoCallGraph:
    def test_extracts_function_calls(self, extractor, go_file_with_calls):
        """Should extract function call relationships."""
        info = extractor.extract(go_file_with_calls)

        # Check call graph exists
        assert info.call_graph.calls, "Call graph should have entries"

        # processData calls transform
        assert "transform" in info.call_graph.calls.get("processData", [])

        # transform calls validate
        assert "validate" in info.call_graph.calls.get("transform", [])

        # main calls processData
        assert "processData" in info.call_graph.calls.get("main", [])

    def test_extracts_called_by(self, extractor, go_file_with_calls):
        """Should build reverse call graph (called_by)."""
        info = extractor.extract(go_file_with_calls)

        # transform is called by processData
        assert "processData" in info.call_graph.called_by.get("transform", [])

        # validate is called by transform
        assert "transform" in info.call_graph.called_by.get("validate", [])

    def test_extracts_method_calls(self, extractor, go_file_with_method_calls):
        """Should extract method call relationships."""
        info = extractor.extract(go_file_with_method_calls)

        # Find the Start method (receiver name varies)
        start_caller = None
        for caller in info.call_graph.calls:
            if "Start" in caller and "Service" in caller:
                start_caller = caller
                break

        assert start_caller is not None, f"Could not find Start method, got: {list(info.call_graph.calls.keys())}"
        start_calls = info.call_graph.calls[start_caller]
        assert "prepare" in start_calls, f"Expected 'prepare' in {start_calls}"
        assert "run" in start_calls, f"Expected 'run' in {start_calls}"

    def test_only_tracks_defined_functions(self, extractor, tmp_path):
        """Should not track calls to stdlib/external functions."""
        code = '''
package main

import "fmt"

func greet(name string) {
    fmt.Println("Hello", name)
}
'''
        path = tmp_path / "external.go"
        path.write_text(code)

        info = extractor.extract(path)

        # fmt.Println should NOT be in call graph (external)
        greet_calls = info.call_graph.calls.get("greet", [])
        assert "Println" not in greet_calls

    def test_call_graph_in_compact_output(self, extractor, go_file_with_calls):
        """Call graph should appear in compact output."""
        info = extractor.extract(go_file_with_calls)
        compact = info.to_compact()

        assert "calls" in compact
        assert "processData" in compact["calls"]
