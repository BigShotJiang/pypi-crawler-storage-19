"""Tests for Scala DFG extraction.

TDD Tests for Scala DFG support.
Scala is JVM-based like Java/Kotlin, using similar patterns.

Variable types:
- val: immutable variable (like final in Java)
- var: mutable variable
"""
import pytest

# Check if tree-sitter-scala is available
try:
    from tldr.dfg_extractor import extract_scala_dfg, TREE_SITTER_SCALA_AVAILABLE
    SCALA_AVAILABLE = TREE_SITTER_SCALA_AVAILABLE
except ImportError:
    SCALA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not SCALA_AVAILABLE, reason="tree-sitter-scala not available")


@pytest.fixture
def simple_assignment_code():
    return '''
object Example {
  def calculate(a: Int, b: Int): Int = {
    val x = a
    val y = b
    val result = x + y
    result
  }
}
'''


@pytest.fixture
def reassignment_code():
    return '''
object Example {
  def process(n: Int): Int = {
    var x = n
    x = x + 1
    x = x * 2
    x
  }
}
'''


@pytest.fixture
def loop_variable_code():
    return '''
object Example {
  def sum(n: Int): Int = {
    var total = 0
    for (i <- 0 until n) {
      total = total + i
    }
    total
  }
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
object Example {
  def choose(x: Int): Int = {
    val result = if (x > 0) {
      1
    } else {
      -1
    }
    result
  }
}
'''


@pytest.fixture
def chained_deps_code():
    return '''
object Example {
  def compute(x: Int): Int = {
    val a = x + 1     // a depends on x
    val b = a * 2     // b depends on a
    val c = b + 3     // c depends on b
    c                  // return depends on c
  }
}
'''


class TestBasicDFG:
    """Test basic DFG extraction for Scala."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_scala_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_scala_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_scala_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_scala_dfg(simple_assignment_code, "calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_scala_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_scala_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0

    def test_chained_dependencies(self, chained_deps_code):
        dfg = extract_scala_dfg(chained_deps_code, "compute")
        assert dfg is not None
        # Should have multiple variables in the chain
        var_names = {r.name for r in dfg.var_refs}
        # Should track a, b, c at minimum
        assert len(var_names) >= 3


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_scala_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_scala_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0

    def test_val_vs_var_detection(self, reassignment_code):
        """Test that var (mutable) assignments are tracked correctly."""
        dfg = extract_scala_dfg(reassignment_code, "process")
        # 'x' is a var, should have multiple definitions
        x_defs = [r for r in dfg.var_refs if r.name == "x" and r.ref_type == "definition"]
        assert len(x_defs) >= 2  # Initial + reassignments


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_scala_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0

    def test_empty_code(self):
        dfg = extract_scala_dfg("", "anyFunc")
        assert dfg.function_name == "anyFunc"
        assert len(dfg.var_refs) == 0
