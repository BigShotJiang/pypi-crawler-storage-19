"""Tests for Kotlin import parsing.

TDD Tests for Kotlin import support.
Tests mirror the structure of test_imports_java.py but for Kotlin language support.

Kotlin import syntax:
- import kotlin.collections.List
- import kotlin.math.*  (wildcard)
- import com.example.MyClass as Alias  (aliased import)
"""
import pytest
import tempfile
from pathlib import Path

# Check if tree-sitter-kotlin is available
try:
    from tldr.cross_file_calls import parse_kotlin_imports, TREE_SITTER_KOTLIN_AVAILABLE
    KOTLIN_AVAILABLE = TREE_SITTER_KOTLIN_AVAILABLE
except ImportError:
    KOTLIN_AVAILABLE = False


pytestmark = pytest.mark.skipif(not KOTLIN_AVAILABLE, reason="tree-sitter-kotlin not available")


@pytest.fixture
def simple_imports_file(tmp_path):
    """Create a Kotlin file with simple imports."""
    code = '''
import kotlin.collections.List
import kotlin.collections.Map

class Example {
    fun process(items: List<String>) {
        val counts: Map<String, Int> = mutableMapOf()
    }
}
'''
    file_path = tmp_path / "Example.kt"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def wildcard_imports_file(tmp_path):
    """Create a Kotlin file with wildcard imports."""
    code = '''
import kotlin.collections.*
import kotlin.io.*

class Example {
    fun process() {}
}
'''
    file_path = tmp_path / "Example.kt"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def aliased_imports_file(tmp_path):
    """Create a Kotlin file with aliased imports."""
    code = '''
import kotlin.collections.ArrayList as KList
import com.example.util.Helper as HelperUtil

class Example {
    fun process(): KList<String> {
        return KList()
    }
}
'''
    file_path = tmp_path / "Example.kt"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create a Kotlin file with mixed imports."""
    code = '''
package com.example.app

import kotlin.collections.List
import kotlin.collections.Map
import kotlin.io.*
import kotlin.math.abs
import com.example.util.Helper as H

class Example {
    fun process() {}
}
'''
    file_path = tmp_path / "Example.kt"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def java_interop_imports_file(tmp_path):
    """Create a Kotlin file with Java interop imports."""
    code = '''
import java.util.ArrayList
import java.io.File
import java.nio.file.Path

class Example {
    fun readFile(path: Path): String {
        return File(path.toString()).readText()
    }
}
'''
    file_path = tmp_path / "Example.kt"
    file_path.write_text(code)
    return file_path


class TestSimpleImports:
    """Test basic import parsing."""

    def test_parses_simple_imports(self, simple_imports_file):
        imports = parse_kotlin_imports(simple_imports_file)
        assert len(imports) == 2
        modules = [imp['module'] for imp in imports]
        assert 'kotlin.collections.List' in modules
        assert 'kotlin.collections.Map' in modules

    def test_wildcard_imports(self, wildcard_imports_file):
        imports = parse_kotlin_imports(wildcard_imports_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        assert any('kotlin.collections' in m for m in modules)
        assert any('kotlin.io' in m for m in modules)

    def test_aliased_imports(self, aliased_imports_file):
        imports = parse_kotlin_imports(aliased_imports_file)
        assert len(imports) >= 2
        # Should capture alias information
        # Check that the original module is present
        modules = [imp['module'] for imp in imports]
        assert any('ArrayList' in m or 'collections' in m for m in modules)


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_kotlin_imports(mixed_imports_file)
        # Should have all imports
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('kotlin.collections' in m for m in modules)
        assert any('Helper' in m or 'com.example' in m for m in modules)

    def test_java_interop_imports(self, java_interop_imports_file):
        imports = parse_kotlin_imports(java_interop_imports_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        # Should capture Java stdlib imports
        assert any('java.util' in m for m in modules)
        assert any('java.io' in m or 'File' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "Empty.kt"
        file_path.write_text("class Empty")
        imports = parse_kotlin_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "NonExistent.kt"
        imports = parse_kotlin_imports(file_path)
        assert imports == []

    def test_only_package_declaration(self, tmp_path):
        code = '''
package com.example

class NoImports {
    fun test() {}
}
'''
        file_path = tmp_path / "NoImports.kt"
        file_path.write_text(code)
        imports = parse_kotlin_imports(file_path)
        assert imports == []

    def test_import_with_backticks(self, tmp_path):
        """Kotlin allows backtick-escaped identifiers."""
        code = '''
import kotlin.`is`.reserved
import kotlin.collections.List

class Example {
    fun process() {}
}
'''
        file_path = tmp_path / "Example.kt"
        file_path.write_text(code)
        imports = parse_kotlin_imports(file_path)
        # Should still parse valid imports
        modules = [imp['module'] for imp in imports]
        assert any('List' in m or 'collections' in m for m in modules)
