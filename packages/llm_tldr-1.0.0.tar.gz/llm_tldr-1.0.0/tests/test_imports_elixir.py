"""Tests for Elixir import parsing.

TDD tests for Elixir language support in TLDR import parsing.
These tests should FAIL initially until Elixir support is implemented.

Elixir import patterns (tree-sitter-elixir):
- alias MyApp.Module : creates alias
- alias MyApp.Module, as: M : creates named alias
- import Module : imports all functions
- import Module, only: [func: arity] : selective import
- use Module : invokes __using__ macro
- require Module : ensures module is compiled for macros
- All of these appear as `call` nodes with identifier "alias", "import", "use", or "require"
"""
import pytest
from pathlib import Path

# Check if tree-sitter-elixir is available
try:
    from tldr.cross_file_calls import parse_elixir_imports, TREE_SITTER_ELIXIR_AVAILABLE
    ELIXIR_AVAILABLE = TREE_SITTER_ELIXIR_AVAILABLE
except ImportError:
    ELIXIR_AVAILABLE = False


pytestmark = pytest.mark.skipif(not ELIXIR_AVAILABLE, reason="tree-sitter-elixir not available")


@pytest.fixture
def simple_alias_file(tmp_path):
    """Create an Elixir file with simple alias statements."""
    code = '''
alias MyApp.Accounts.User
alias MyApp.Accounts.Account

defmodule Example do
  def get_user(id) do
    User.get(id)
  end
end
'''
    file_path = tmp_path / "example.ex"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def alias_with_as_file(tmp_path):
    """Create an Elixir file with aliased imports using as:."""
    code = '''
alias MyApp.VeryLongModuleName.User, as: U
alias MyApp.VeryLongModuleName.Account, as: Acc
alias MyApp.Helpers.{Utils, Formatter}

defmodule Example do
  def create_user(params) do
    U.create(params)
  end
end
'''
    file_path = tmp_path / "example.ex"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def import_file(tmp_path):
    """Create an Elixir file with import statements."""
    code = '''
import Enum
import String, only: [trim: 1, upcase: 1]
import List, except: [first: 1]

defmodule Example do
  def process(items) do
    items
    |> map(&process_item/1)
    |> filter(&valid?/1)
  end
end
'''
    file_path = tmp_path / "example.ex"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def use_require_file(tmp_path):
    """Create an Elixir file with use and require statements."""
    code = '''
use GenServer
use Phoenix.Controller
require Logger
require EEx

defmodule MyServer do
  def init(state) do
    Logger.info("Starting server")
    {:ok, state}
  end
end
'''
    file_path = tmp_path / "my_server.ex"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create an Elixir file with mixed import statements."""
    code = '''
alias MyApp.Accounts.User
alias MyApp.Helpers.Utils, as: U
import Enum, only: [map: 2, filter: 2]
import String
use GenServer
require Logger

defmodule Application do
  def start(type, args) do
    Logger.info("Starting application")
    {:ok, self()}
  end
end
'''
    file_path = tmp_path / "application.ex"
    file_path.write_text(code)
    return file_path


class TestSimpleImports:
    """Test basic import parsing."""

    def test_parses_alias_statements(self, simple_alias_file):
        imports = parse_elixir_imports(simple_alias_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        assert any('User' in m for m in modules)
        assert any('Account' in m for m in modules)

    def test_alias_with_as(self, alias_with_as_file):
        imports = parse_elixir_imports(alias_with_as_file)
        assert len(imports) >= 2
        # Should track the alias name
        for imp in imports:
            if 'User' in imp['module']:
                assert imp.get('alias') == 'U' or imp.get('as') == 'U'

    def test_import_statements(self, import_file):
        imports = parse_elixir_imports(import_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        assert any('Enum' in m for m in modules)
        assert any('String' in m for m in modules)


class TestUseAndRequire:
    """Test use and require statement parsing."""

    def test_use_statements(self, use_require_file):
        imports = parse_elixir_imports(use_require_file)
        modules = [imp['module'] for imp in imports]
        assert any('GenServer' in m for m in modules)

    def test_require_statements(self, use_require_file):
        imports = parse_elixir_imports(use_require_file)
        modules = [imp['module'] for imp in imports]
        assert any('Logger' in m for m in modules)

    def test_import_types_distinguished(self, mixed_imports_file):
        imports = parse_elixir_imports(mixed_imports_file)
        # Imports should indicate their type (alias vs import vs use vs require)
        import_types = set()
        for imp in imports:
            if 'type' in imp:
                import_types.add(imp['type'])
            elif 'import_type' in imp:
                import_types.add(imp['import_type'])
        # Should have multiple types
        assert len(import_types) >= 2


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_elixir_imports(mixed_imports_file)
        # Should have all import types
        assert len(imports) >= 5
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('User' in m for m in modules)
        assert any('GenServer' in m for m in modules)
        assert any('Logger' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "empty.ex"
        file_path.write_text("defmodule Empty do\nend")
        imports = parse_elixir_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "nonexistent.ex"
        imports = parse_elixir_imports(file_path)
        assert imports == []

    def test_conditional_import(self, tmp_path):
        """Import inside conditional should still be detected."""
        code = '''
if Mix.env() == :test do
  import ExUnit.Callbacks
else
  import MyApp.Helpers
end
'''
        file_path = tmp_path / "conditional.ex"
        file_path.write_text(code)
        imports = parse_elixir_imports(file_path)
        # Should detect both imports
        assert len(imports) >= 2

    def test_only_module_definition(self, tmp_path):
        code = '''
defmodule NoImports do
  def test do
    IO.puts("hello")
  end
end
'''
        file_path = tmp_path / "no_imports.ex"
        file_path.write_text(code)
        imports = parse_elixir_imports(file_path)
        assert imports == []
