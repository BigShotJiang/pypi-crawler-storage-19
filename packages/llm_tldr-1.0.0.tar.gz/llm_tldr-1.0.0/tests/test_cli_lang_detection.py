"""Tests for CLI language auto-detection from file extension."""
import subprocess
import sys
from pathlib import Path

import pytest


class TestDetectLanguageFromExtension:
    """Test the detect_language_from_extension helper function."""

    def test_java_extension(self):
        """Java files should be detected as java."""
        from tldr.cli import detect_language_from_extension
        assert detect_language_from_extension("Sample.java") == "java"
        assert detect_language_from_extension("/path/to/File.java") == "java"

    def test_python_extension(self):
        """Python files should be detected as python."""
        from tldr.cli import detect_language_from_extension
        assert detect_language_from_extension("script.py") == "python"
        assert detect_language_from_extension("/path/to/module.py") == "python"

    def test_typescript_extensions(self):
        """TypeScript files should be detected as typescript."""
        from tldr.cli import detect_language_from_extension
        assert detect_language_from_extension("component.ts") == "typescript"
        assert detect_language_from_extension("Component.tsx") == "typescript"

    def test_javascript_extensions(self):
        """JavaScript files should be detected as javascript."""
        from tldr.cli import detect_language_from_extension
        assert detect_language_from_extension("script.js") == "javascript"
        assert detect_language_from_extension("Component.jsx") == "javascript"

    def test_go_extension(self):
        """Go files should be detected as go."""
        from tldr.cli import detect_language_from_extension
        assert detect_language_from_extension("main.go") == "go"

    def test_rust_extension(self):
        """Rust files should be detected as rust."""
        from tldr.cli import detect_language_from_extension
        assert detect_language_from_extension("lib.rs") == "rust"

    def test_unknown_extension_defaults_to_python(self):
        """Unknown extensions should default to python."""
        from tldr.cli import detect_language_from_extension
        assert detect_language_from_extension("file.unknown") == "python"
        assert detect_language_from_extension("file.txt") == "python"
        assert detect_language_from_extension("file") == "python"


class TestCLIAutoDetection:
    """Test CLI commands auto-detect language from file extension."""

    @pytest.fixture
    def java_fixture(self):
        """Path to Java test fixture."""
        return Path(__file__).parent / "fixtures" / "Sample.java"

    def test_cfg_auto_detects_java(self, java_fixture):
        """tldr cfg should auto-detect java from .java extension."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "cfg", str(java_fixture), "calculate"],
            capture_output=True,
            text=True,
        )
        # Should succeed without --lang java AND find the function
        assert result.returncode == 0, f"Failed: {result.stderr}"
        import json
        data = json.loads(result.stdout)
        # Must have non-empty blocks (proves Java parser was used)
        assert len(data["blocks"]) > 0, "No blocks found - language not auto-detected"

    def test_dfg_auto_detects_java(self, java_fixture):
        """tldr dfg should auto-detect java from .java extension."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "dfg", str(java_fixture), "sum"],
            capture_output=True,
            text=True,
        )
        # Should succeed without --lang java AND find variable refs
        assert result.returncode == 0, f"Failed: {result.stderr}"
        import json
        data = json.loads(result.stdout)
        # Must have variable references (proves Java parser was used)
        assert len(data.get("refs", [])) > 0, "No refs found - language not auto-detected"

    def test_imports_auto_detects_java(self, java_fixture):
        """tldr imports should auto-detect java from .java extension."""
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "imports", str(java_fixture)],
            capture_output=True,
            text=True,
        )
        # Should succeed without --lang java
        assert result.returncode == 0, f"Failed: {result.stderr}"
        import json
        data = json.loads(result.stdout)
        # Sample.java has imports - verify they're found (returns list directly)
        assert isinstance(data, list) and len(data) > 0, "No imports found - language not auto-detected"

    def test_explicit_lang_overrides_detection(self, java_fixture):
        """Explicit --lang flag should override auto-detection."""
        # Force python parser on a java file - should find nothing
        result = subprocess.run(
            [sys.executable, "-m", "tldr.cli", "cfg", str(java_fixture), "calculate", "--lang", "python"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        import json
        data = json.loads(result.stdout)
        # With python parser, should find NO blocks (wrong language)
        assert len(data["blocks"]) == 0, "Explicit --lang should override auto-detection"
