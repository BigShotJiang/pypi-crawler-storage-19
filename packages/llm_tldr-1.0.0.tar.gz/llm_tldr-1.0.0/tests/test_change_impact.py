"""
Tests for tldr/change_impact.py
"""

import json
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tldr.change_impact import (
    is_test_file,
    get_changed_functions,
    find_affected_tests,
    get_git_changed_files,
    analyze_change_impact,
)


class TestIsTestFile:
    """Test test file detection."""

    def test_python_test_prefix(self):
        assert is_test_file("test_foo.py") is True
        assert is_test_file("test_bar.py") is True
        assert is_test_file("tests/test_utils.py") is True

    def test_python_test_suffix(self):
        assert is_test_file("foo_test.py") is True
        assert is_test_file("bar_test.py") is True

    def test_javascript_test_files(self):
        assert is_test_file("foo.test.js") is True
        assert is_test_file("bar.test.ts") is True
        assert is_test_file("component.test.tsx") is True

    def test_javascript_spec_files(self):
        assert is_test_file("foo.spec.js") is True
        assert is_test_file("bar.spec.ts") is True

    def test_tests_directory(self):
        assert is_test_file("tests/utils.py") is True
        assert is_test_file("test/helpers.py") is True
        assert is_test_file("src/__tests__/foo.js") is True

    def test_non_test_files(self):
        assert is_test_file("foo.py") is False
        assert is_test_file("utils.py") is False
        assert is_test_file("src/main.py") is False
        assert is_test_file("lib/helpers.js") is False


class TestGetChangedFunctions:
    """Test function extraction from files."""

    def test_extract_functions(self, tmp_path):
        test_file = tmp_path / "module.py"
        test_file.write_text("""def foo():
    pass

def bar(x: int) -> str:
    return str(x)
""")
        functions = get_changed_functions(str(test_file))
        names = [f["name"] for f in functions]
        assert "foo" in names
        assert "bar" in names
        # Verify structure
        assert all("file" in f for f in functions)

    def test_nonexistent_file(self):
        functions = get_changed_functions("/nonexistent/file.py")
        assert functions == []


class TestFindAffectedTests:
    """Test affected test discovery."""

    def test_changed_test_file_included(self, tmp_path):
        # Create a test file
        test_file = tmp_path / "test_foo.py"
        test_file.write_text("def test_foo(): pass")

        result = find_affected_tests(
            str(tmp_path),
            ["test_foo.py"],
            language="python",
        )

        assert "test_foo.py" in result["affected_tests"]

    def test_empty_changed_files(self, tmp_path):
        result = find_affected_tests(
            str(tmp_path),
            [],
            language="python",
        )

        assert result["affected_tests"] == []
        assert result["changed_functions"] == []


class TestGetGitChangedFiles:
    """Test git diff integration."""

    def test_with_mocked_git(self, tmp_path):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="src/foo.py\nsrc/bar.py\n",
            )
            files = get_git_changed_files(str(tmp_path))

        assert files == ["src/foo.py", "src/bar.py"]

    def test_git_failure(self, tmp_path):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=1, stdout="")
            files = get_git_changed_files(str(tmp_path))

        assert files == []

    def test_git_not_available(self, tmp_path):
        with patch("subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError("git not found")
            files = get_git_changed_files(str(tmp_path))

        assert files == []


class TestAnalyzeChangeImpact:
    """Test the main analysis function."""

    def test_explicit_files(self, tmp_path):
        # Create source file
        src = tmp_path / "src"
        src.mkdir()
        (src / "module.py").write_text("def foo(): pass")

        # Create test file
        tests = tmp_path / "tests"
        tests.mkdir()
        (tests / "test_module.py").write_text("def test_foo(): pass")

        result = analyze_change_impact(
            str(tmp_path),
            files=["src/module.py"],
            language="python",
        )

        assert result["source"] == "explicit"
        assert "module.py" in str(result["changed_files"])

    def test_no_changes_detected(self, tmp_path):
        result = analyze_change_impact(
            str(tmp_path),
            files=[],
            language="python",
        )

        assert result["message"] == "No changed files detected"
        assert result["affected_tests"] == []

    def test_session_source(self, tmp_path):
        # Create dirty flag
        dirty_dir = tmp_path / ".tldr"
        dirty_dir.mkdir()
        dirty_file = dirty_dir / "dirty.json"
        dirty_file.write_text(json.dumps({
            "files": {"src/foo.py": {"modified": "2024-01-01T00:00:00"}}
        }))

        # Create source file
        src = tmp_path / "src"
        src.mkdir()
        (src / "foo.py").write_text("def foo(): pass")

        result = analyze_change_impact(
            str(tmp_path),
            use_session=True,
            language="python",
        )

        assert result["source"] == "session"

    def test_filters_non_source_files(self, tmp_path):
        # Create non-source files
        (tmp_path / "README.md").write_text("# Readme")
        (tmp_path / "config.json").write_text("{}")

        result = analyze_change_impact(
            str(tmp_path),
            files=["README.md", "config.json"],
            language="python",
        )

        # Non-source files should be filtered out
        assert result["changed_functions"] == []


class TestCLIIntegration:
    """Test CLI command integration."""

    def test_cli_help(self):
        result = subprocess.run(
            ["python", "-m", "tldr.cli", "change-impact", "--help"],
            capture_output=True,
            text=True,
            cwd=str(Path(__file__).parent.parent),
        )
        assert result.returncode == 0
        assert "change-impact" in result.stdout
        assert "--session" in result.stdout
        assert "--git" in result.stdout

    def test_cli_no_changes(self, tmp_path):
        result = subprocess.run(
            ["python", "-m", "tldr.cli", "change-impact"],
            capture_output=True,
            text=True,
            cwd=str(tmp_path),
        )
        # Should succeed even with no changes
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert "affected_tests" in output

    def test_cli_explicit_file(self, tmp_path):
        # Create a source file
        test_file = tmp_path / "foo.py"
        test_file.write_text("def bar(): pass")

        result = subprocess.run(
            ["python", "-m", "tldr.cli", "change-impact", str(test_file)],
            capture_output=True,
            text=True,
            cwd=str(tmp_path),
        )
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert "foo.py" in str(output["changed_files"])


class TestIntegration:
    """Integration tests with real file analysis."""

    def test_full_workflow(self, tmp_path):
        """Test complete workflow: source -> test -> impact."""
        # Create project structure
        src = tmp_path / "src"
        src.mkdir()
        tests = tmp_path / "tests"
        tests.mkdir()

        # Source module with function
        (src / "calculator.py").write_text("""def add(a: int, b: int) -> int:
    return a + b

def multiply(a: int, b: int) -> int:
    return a * b
""")

        # Test that calls the function
        (tests / "test_calculator.py").write_text("""from src.calculator import add, multiply

def test_add():
    assert add(2, 3) == 5

def test_multiply():
    assert multiply(2, 3) == 6
""")

        # Analyze impact of changing calculator.py
        result = analyze_change_impact(
            str(tmp_path),
            files=["src/calculator.py"],
            language="python",
        )

        # Should extract functions from changed file
        assert "add" in result["changed_functions"] or "multiply" in result["changed_functions"]
        # Note: affected_tests discovery depends on call graph which needs proper imports

    def test_test_command_generation(self, tmp_path):
        """Test that correct test command is generated."""
        tests = tmp_path / "tests"
        tests.mkdir()
        (tests / "test_foo.py").write_text("def test_foo(): pass")

        result = analyze_change_impact(
            str(tmp_path),
            files=["tests/test_foo.py"],
            language="python",
        )

        assert "affected_tests" in result
        if result["affected_tests"]:
            assert result["test_command"] is not None
            assert "pytest" in result["test_command"]
