"""Tests for C# DFG extraction.

TDD Tests - Expected to fail until C# support is implemented.
C# uses tree-sitter-c-sharp (hyphen in package name, underscore in Python import).
"""
import pytest

# Check if tree-sitter-c-sharp is available
try:
    from tldr.dfg_extractor import extract_csharp_dfg, TREE_SITTER_CSHARP_AVAILABLE
    CSHARP_AVAILABLE = TREE_SITTER_CSHARP_AVAILABLE
except ImportError:
    CSHARP_AVAILABLE = False


pytestmark = pytest.mark.skipif(not CSHARP_AVAILABLE, reason="tree-sitter-c-sharp not available")


@pytest.fixture
def simple_assignment_code():
    return '''
public class Example {
    public int Calculate(int a, int b) {
        int x = a;
        int y = b;
        int result = x + y;
        return result;
    }
}
'''


@pytest.fixture
def reassignment_code():
    return '''
public class Example {
    public int Process(int n) {
        int x = n;
        x = x + 1;
        x = x * 2;
        return x;
    }
}
'''


@pytest.fixture
def loop_variable_code():
    return '''
public class Example {
    public int Sum(int n) {
        int total = 0;
        for (int i = 0; i < n; i++) {
            total = total + i;
        }
        return total;
    }
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
public class Example {
    public int Choose(int x) {
        int result;
        if (x > 0) {
            result = 1;
        } else {
            result = -1;
        }
        return result;
    }
}
'''


@pytest.fixture
def property_assignment_code():
    """Test C# property assignments."""
    return '''
public class Example {
    public int Value { get; set; }

    public void SetValue(int n) {
        Value = n;
        int local = Value;
        Value = local * 2;
    }
}
'''


@pytest.fixture
def chained_assignment_code():
    return '''
public class Example {
    public int ChainedCompute(int x) {
        int a = x + 1;
        int b = a * 2;
        int c = b + 3;
        return c;
    }
}
'''


@pytest.fixture
def multi_path_code():
    return '''
public class Example {
    public int MultiPath(int x, int y) {
        int sum = x + y;
        int product = x * y;
        int result = sum + product;
        return result;
    }
}
'''


class TestBasicDFG:
    """Test basic DFG extraction for C#."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_csharp_dfg(simple_assignment_code, "Calculate")
        assert dfg is not None
        assert dfg.function_name == "Calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_csharp_dfg(reassignment_code, "Process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_csharp_dfg(loop_variable_code, "Sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_chained_assignment(self, chained_assignment_code):
        dfg = extract_csharp_dfg(chained_assignment_code, "ChainedCompute")
        assert dfg is not None
        # Should track chain: x -> a -> b -> c
        assert len(dfg.dataflow_edges) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_csharp_dfg(simple_assignment_code, "Calculate")
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_csharp_dfg(reassignment_code, "Process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_csharp_dfg(conditional_assignment_code, "Choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0

    def test_multi_path_data_flow(self, multi_path_code):
        dfg = extract_csharp_dfg(multi_path_code, "MultiPath")
        assert dfg is not None
        # x and y are used in multiple paths
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        y_refs = [r for r in dfg.var_refs if r.name == "y"]
        assert len(x_refs) > 0
        assert len(y_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_csharp_dfg(simple_assignment_code, "Calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_csharp_dfg(simple_assignment_code, "Calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0

    def test_parameter_as_definition(self, simple_assignment_code):
        dfg = extract_csharp_dfg(simple_assignment_code, "Calculate")
        # Parameters a and b should be tracked
        a_refs = [r for r in dfg.var_refs if r.name == "a"]
        b_refs = [r for r in dfg.var_refs if r.name == "b"]
        assert len(a_refs) > 0
        assert len(b_refs) > 0


class TestPropertyDataFlow:
    """Test C#-specific property data flow."""

    def test_property_assignment(self, property_assignment_code):
        dfg = extract_csharp_dfg(property_assignment_code, "SetValue")
        assert dfg is not None
        # Should track property Value and local variable
        assert len(dfg.var_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_csharp_dfg(simple_assignment_code, "NonExistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "NonExistent"
        assert len(dfg.var_refs) == 0

    def test_empty_class(self):
        code = "public class Empty { }"
        dfg = extract_csharp_dfg(code, "SomeMethod")
        assert dfg.function_name == "SomeMethod"
        assert len(dfg.var_refs) == 0
