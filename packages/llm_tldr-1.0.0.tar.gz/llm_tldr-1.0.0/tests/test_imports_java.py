"""Tests for Java import parsing."""
import pytest
import tempfile
from pathlib import Path

# Check if tree-sitter-java is available
try:
    from tldr.cross_file_calls import parse_java_imports, TREE_SITTER_JAVA_AVAILABLE
    JAVA_AVAILABLE = TREE_SITTER_JAVA_AVAILABLE
except ImportError:
    JAVA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")


@pytest.fixture
def simple_imports_file(tmp_path):
    """Create a Java file with simple imports."""
    code = '''
import java.util.List;
import java.util.Map;

public class Example {
    public void process(List<String> items) {
        Map<String, Integer> counts = new HashMap<>();
    }
}
'''
    file_path = tmp_path / "Example.java"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def wildcard_imports_file(tmp_path):
    """Create a Java file with wildcard imports."""
    code = '''
import java.util.*;
import java.io.*;

public class Example {
    public void process() {}
}
'''
    file_path = tmp_path / "Example.java"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def static_imports_file(tmp_path):
    """Create a Java file with static imports."""
    code = '''
import static java.lang.Math.PI;
import static java.util.Collections.emptyList;

public class Example {
    public double calculate() {
        return PI * 2;
    }
}
'''
    file_path = tmp_path / "Example.java"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create a Java file with mixed imports."""
    code = '''
package com.example.app;

import java.util.List;
import java.util.Map;
import java.io.*;
import static java.lang.Math.sqrt;
import com.example.util.Helper;

public class Example {
    public void process() {}
}
'''
    file_path = tmp_path / "Example.java"
    file_path.write_text(code)
    return file_path


class TestSimpleImports:
    """Test basic import parsing."""

    def test_parses_simple_imports(self, simple_imports_file):
        imports = parse_java_imports(simple_imports_file)
        assert len(imports) == 2
        modules = [imp['module'] for imp in imports]
        assert 'java.util.List' in modules
        assert 'java.util.Map' in modules

    def test_wildcard_imports(self, wildcard_imports_file):
        imports = parse_java_imports(wildcard_imports_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        assert any('java.util' in m for m in modules)
        assert any('java.io' in m for m in modules)

    def test_static_imports(self, static_imports_file):
        imports = parse_java_imports(static_imports_file)
        assert len(imports) >= 2
        # Static imports should be marked or have a flag
        modules = [imp['module'] for imp in imports]
        assert any('Math' in m or 'PI' in m for m in modules)


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_java_imports(mixed_imports_file)
        # Should have all imports
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('java.util' in m for m in modules)
        assert any('Helper' in m or 'com.example' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "Empty.java"
        file_path.write_text("public class Empty {}")
        imports = parse_java_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "NonExistent.java"
        imports = parse_java_imports(file_path)
        assert imports == []

    def test_only_package_declaration(self, tmp_path):
        code = '''
package com.example;

public class NoImports {
    public void test() {}
}
'''
        file_path = tmp_path / "NoImports.java"
        file_path.write_text(code)
        imports = parse_java_imports(file_path)
        assert imports == []
