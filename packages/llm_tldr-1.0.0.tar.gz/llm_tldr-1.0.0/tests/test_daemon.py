"""
Tests for TLDR daemon - socket-based server holding indexes in memory.

TDD: Write tests first, then implement.
"""

import hashlib
import json
import os
import socket
import tempfile
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestSocketPathGeneration:
    """Test deterministic socket path generation from project path."""

    def test_socket_path_uses_md5_hash(self):
        """Socket path should be /tmp/tldr-{md5[:8]}.sock"""
        from tldr.daemon import TLDRDaemon

        project = Path("/Users/test/myproject")
        daemon = TLDRDaemon(project)

        expected_hash = hashlib.md5(str(project).encode()).hexdigest()[:8]
        expected_path = Path(f"/tmp/tldr-{expected_hash}.sock")

        assert daemon.socket_path == expected_path

    def test_socket_path_deterministic(self):
        """Same project path should always produce same socket path."""
        from tldr.daemon import TLDRDaemon

        project = Path("/Users/test/myproject")
        daemon1 = TLDRDaemon(project)
        daemon2 = TLDRDaemon(project)

        assert daemon1.socket_path == daemon2.socket_path

    def test_different_projects_different_sockets(self):
        """Different project paths should produce different socket paths."""
        from tldr.daemon import TLDRDaemon

        daemon1 = TLDRDaemon(Path("/project/a"))
        daemon2 = TLDRDaemon(Path("/project/b"))

        assert daemon1.socket_path != daemon2.socket_path


class TestDaemonInitialization:
    """Test daemon initialization and state."""

    def test_daemon_init_sets_project_path(self):
        """Daemon should store project path."""
        from tldr.daemon import TLDRDaemon

        project = Path("/test/project")
        daemon = TLDRDaemon(project)

        assert daemon.project == project

    def test_daemon_init_sets_tldr_dir(self):
        """Daemon should set .tldr directory path."""
        from tldr.daemon import TLDRDaemon

        project = Path("/test/project")
        daemon = TLDRDaemon(project)

        assert daemon.tldr_dir == project / ".tldr"

    def test_daemon_init_empty_indexes(self):
        """Daemon should start with empty indexes."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))

        assert daemon.indexes == {}

    def test_daemon_init_sets_last_query_time(self):
        """Daemon should track last query time for idle timeout."""
        from tldr.daemon import TLDRDaemon

        before = time.time()
        daemon = TLDRDaemon(Path("/test/project"))
        after = time.time()

        assert before <= daemon.last_query <= after


class TestIdleTimeout:
    """Test idle timeout behavior."""

    def test_idle_timeout_constant(self):
        """IDLE_TIMEOUT should be 30 minutes."""
        from tldr.daemon import IDLE_TIMEOUT

        assert IDLE_TIMEOUT == 30 * 60  # 30 minutes in seconds

    def test_is_idle_returns_false_when_recent_activity(self):
        """is_idle() should return False when last_query is recent."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        daemon.last_query = time.time()

        assert daemon.is_idle() is False

    def test_is_idle_returns_true_when_no_recent_activity(self):
        """is_idle() should return True when last_query is old."""
        from tldr.daemon import IDLE_TIMEOUT, TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        daemon.last_query = time.time() - IDLE_TIMEOUT - 1

        assert daemon.is_idle() is True


class TestCommandRouting:
    """Test command parsing and routing."""

    def test_handle_ping_command(self):
        """Ping command should return ok status."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        result = daemon.handle_command({"cmd": "ping"})

        assert result == {"status": "ok"}

    def test_handle_status_command(self):
        """Status command should return daemon status."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        daemon._status = "ready"
        daemon._start_time = time.time() - 100

        result = daemon.handle_command({"cmd": "status"})

        assert result["status"] == "ready"
        assert "uptime" in result
        assert result["uptime"] >= 100

    def test_handle_shutdown_command(self):
        """Shutdown command should signal daemon to stop."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        result = daemon.handle_command({"cmd": "shutdown"})

        assert result == {"status": "shutting_down"}
        assert daemon._shutdown_requested is True

    def test_handle_unknown_command(self):
        """Unknown command should return error."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        result = daemon.handle_command({"cmd": "unknown_cmd"})

        assert result["status"] == "error"
        assert "unknown" in result["message"].lower()

    def test_handle_command_updates_last_query(self):
        """Handling any command should update last_query time."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        old_time = daemon.last_query - 10
        daemon.last_query = old_time

        daemon.handle_command({"cmd": "ping"})

        assert daemon.last_query > old_time


class TestSearchCommand:
    """Test search command handling."""

    def test_search_command_requires_pattern(self):
        """Search command should require pattern parameter."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        result = daemon.handle_command({"cmd": "search"})

        assert result["status"] == "error"
        assert "pattern" in result["message"].lower()

    def test_search_command_delegates_to_api(self):
        """Search command should delegate to tldr.api.search."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            # Create a test file
            test_file = project / "test.py"
            test_file.write_text("def hello():\n    print('world')\n")

            daemon = TLDRDaemon(project)
            result = daemon.handle_command({"cmd": "search", "pattern": "hello"})

            assert result["status"] == "ok"
            assert "results" in result


class TestExtractCommand:
    """Test extract command handling."""

    def test_extract_command_requires_file(self):
        """Extract command should require file parameter."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        result = daemon.handle_command({"cmd": "extract"})

        assert result["status"] == "error"
        assert "file" in result["message"].lower()

    def test_extract_command_delegates_to_api(self):
        """Extract command should delegate to tldr.api.extract_file."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            test_file = project / "test.py"
            test_file.write_text("def hello():\n    pass\n")

            daemon = TLDRDaemon(project)
            result = daemon.handle_command(
                {"cmd": "extract", "file": str(test_file)}
            )

            assert result["status"] == "ok"
            assert "result" in result


class TestImpactCommand:
    """Test impact command handling."""

    def test_impact_command_requires_func(self):
        """Impact command should require func parameter."""
        from tldr.daemon import TLDRDaemon

        daemon = TLDRDaemon(Path("/test/project"))
        result = daemon.handle_command({"cmd": "impact"})

        assert result["status"] == "error"
        assert "func" in result["message"].lower()


class TestPidFile:
    """Test PID file management."""

    def test_write_pid_file(self):
        """Daemon should write PID file on start."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            tldr_dir = project / ".tldr"
            tldr_dir.mkdir()

            daemon = TLDRDaemon(project)
            daemon.write_pid_file()

            pid_file = tldr_dir / "daemon.pid"
            assert pid_file.exists()
            assert int(pid_file.read_text().strip()) == os.getpid()

    def test_remove_pid_file(self):
        """Daemon should remove PID file on stop."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            tldr_dir = project / ".tldr"
            tldr_dir.mkdir()

            daemon = TLDRDaemon(project)
            daemon.write_pid_file()
            daemon.remove_pid_file()

            pid_file = tldr_dir / "daemon.pid"
            assert not pid_file.exists()


class TestStatusFile:
    """Test status file management."""

    def test_write_status_file(self):
        """Daemon should write status to .tldr/status."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            tldr_dir = project / ".tldr"
            tldr_dir.mkdir()

            daemon = TLDRDaemon(project)
            daemon.write_status("indexing")

            status_file = tldr_dir / "status"
            assert status_file.exists()
            assert status_file.read_text().strip() == "indexing"

    def test_read_status_file(self):
        """read_status should return current status."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            tldr_dir = project / ".tldr"
            tldr_dir.mkdir()

            daemon = TLDRDaemon(project)
            daemon.write_status("ready")

            assert daemon.read_status() == "ready"


class TestSocketCommunication:
    """Test socket-based communication."""

    def test_send_receive_json(self):
        """Should be able to send and receive JSON over socket."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            daemon = TLDRDaemon(project)

            # Start daemon in background thread
            server_ready = threading.Event()

            def run_server():
                daemon._create_socket()
                server_ready.set()
                daemon._handle_one_connection()
                daemon._cleanup_socket()

            thread = threading.Thread(target=run_server)
            thread.start()

            server_ready.wait(timeout=2)
            time.sleep(0.1)  # Give socket time to bind

            # Connect and send command
            client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                client.connect(str(daemon.socket_path))
                request = json.dumps({"cmd": "ping"}) + "\n"
                client.sendall(request.encode())

                response = client.recv(4096).decode()
                result = json.loads(response)

                assert result["status"] == "ok"
            finally:
                client.close()
                thread.join(timeout=2)


class TestIndexLoading:
    """Test lazy index loading."""

    def test_load_call_graph_on_demand(self):
        """Call graph should be loaded on first query needing it."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            tldr_dir = project / ".tldr"
            tldr_dir.mkdir()

            # Create a minimal call_graph.json
            call_graph = {
                "edges": [],
                "nodes": {},
                "metadata": {"language": "python"},
            }
            (tldr_dir / "call_graph.json").write_text(json.dumps(call_graph))

            daemon = TLDRDaemon(project)
            assert "call_graph" not in daemon.indexes

            # Access call graph
            daemon._ensure_call_graph_loaded()

            assert "call_graph" in daemon.indexes


class TestPlatformCompatibility:
    """Test cross-platform socket/TCP compatibility (Unix vs Windows)."""

    def test_get_connection_info_unix(self):
        """On Unix, should return Unix socket path."""
        from tldr.daemon import TLDRDaemon

        with patch("sys.platform", "darwin"):
            project = Path("/Users/test/myproject")
            daemon = TLDRDaemon(project)
            info = daemon._get_connection_info()

            # Should return (socket_path, None) for Unix
            assert info[1] is None  # port is None for Unix socket
            assert "/tmp/tldr-" in info[0]
            assert info[0].endswith(".sock")

    def test_get_connection_info_linux(self):
        """On Linux, should return Unix socket path."""
        from tldr.daemon import TLDRDaemon

        with patch("sys.platform", "linux"):
            project = Path("/home/test/myproject")
            daemon = TLDRDaemon(project)
            info = daemon._get_connection_info()

            # Should return (socket_path, None) for Unix
            assert info[1] is None
            assert "/tmp/tldr-" in info[0]

    def test_get_connection_info_windows(self):
        """On Windows, should return TCP localhost with port."""
        from tldr.daemon import TLDRDaemon

        with patch("sys.platform", "win32"):
            project = Path("C:\\Users\\test\\myproject")
            daemon = TLDRDaemon(project)
            info = daemon._get_connection_info()

            # Should return ('127.0.0.1', port) for Windows
            assert info[0] == "127.0.0.1"
            assert info[1] is not None
            assert isinstance(info[1], int)
            # Port should be in ephemeral range
            assert 49152 <= info[1] < 59152

    def test_windows_port_deterministic(self):
        """Same project path should always produce same port on Windows."""
        from tldr.daemon import TLDRDaemon

        with patch("sys.platform", "win32"):
            project = Path("C:\\Users\\test\\myproject")
            daemon1 = TLDRDaemon(project)
            daemon2 = TLDRDaemon(project)

            info1 = daemon1._get_connection_info()
            info2 = daemon2._get_connection_info()

            assert info1[1] == info2[1]

    def test_different_projects_different_ports_windows(self):
        """Different projects should produce different ports on Windows."""
        from tldr.daemon import TLDRDaemon

        with patch("sys.platform", "win32"):
            daemon1 = TLDRDaemon(Path("C:\\project\\a"))
            daemon2 = TLDRDaemon(Path("C:\\project\\b"))

            info1 = daemon1._get_connection_info()
            info2 = daemon2._get_connection_info()

            assert info1[1] != info2[1]

    def test_create_server_socket_unix(self):
        """On Unix, should create AF_UNIX socket."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            daemon = TLDRDaemon(project)

            with patch("sys.platform", "darwin"):
                sock = daemon._create_server_socket()

                try:
                    assert sock.family == socket.AF_UNIX
                finally:
                    sock.close()
                    # Clean up socket file
                    if daemon.socket_path.exists():
                        daemon.socket_path.unlink()

    def test_create_server_socket_windows(self):
        """On Windows, should create AF_INET socket bound to localhost."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            daemon = TLDRDaemon(project)

            with patch("sys.platform", "win32"):
                sock = daemon._create_server_socket()

                try:
                    assert sock.family == socket.AF_INET
                    # Should be bound to localhost
                    addr = sock.getsockname()
                    assert addr[0] == "127.0.0.1"
                    assert 49152 <= addr[1] < 59152
                finally:
                    sock.close()

    def test_hash_consistency_across_platforms(self):
        """Hash computation should be consistent for same normalized path."""
        import hashlib

        # Simulate path normalization
        unix_path = "/Users/test/myproject"
        windows_path = "C:\\Users\\test\\myproject"

        # Hash should be based on string representation
        unix_hash = hashlib.md5(unix_path.encode()).hexdigest()[:8]
        windows_hash = hashlib.md5(windows_path.encode()).hexdigest()[:8]

        # Different paths should have different hashes (expected)
        assert unix_hash != windows_hash

        # Same path string should have same hash
        hash1 = hashlib.md5(unix_path.encode()).hexdigest()[:8]
        hash2 = hashlib.md5(unix_path.encode()).hexdigest()[:8]
        assert hash1 == hash2
