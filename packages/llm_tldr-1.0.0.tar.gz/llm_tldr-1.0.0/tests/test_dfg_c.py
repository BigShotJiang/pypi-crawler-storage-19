"""Tests for C DFG extraction."""
import pytest

# Check if tree-sitter-c is available
try:
    from tldr.dfg_extractor import extract_c_dfg, TREE_SITTER_C_AVAILABLE
    C_AVAILABLE = TREE_SITTER_C_AVAILABLE
except ImportError:
    C_AVAILABLE = False


pytestmark = pytest.mark.skipif(not C_AVAILABLE, reason="tree-sitter-c not available")


@pytest.fixture
def simple_assignment_code():
    return '''
int calculate(int a, int b) {
    int x = a;
    int y = b;
    int result = x + y;
    return result;
}
'''


@pytest.fixture
def reassignment_code():
    return '''
int process(int n) {
    int x = n;
    x = x + 1;
    x = x * 2;
    return x;
}
'''


@pytest.fixture
def loop_variable_code():
    return '''
int sum(int* numbers, int count) {
    int total = 0;
    for (int i = 0; i < count; i++) {
        total = total + numbers[i];
    }
    return total;
}
'''


@pytest.fixture
def conditional_assignment_code():
    return '''
int choose(int x) {
    int result;
    if (x > 0) {
        result = 1;
    } else {
        result = -1;
    }
    return result;
}
'''


@pytest.fixture
def pointer_code():
    return '''
void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}
'''


@pytest.fixture
def array_code():
    return '''
int array_sum(int arr[], int n) {
    int total = 0;
    for (int i = 0; i < n; i++) {
        total += arr[i];
    }
    return total;
}
'''


@pytest.fixture
def chained_code():
    return '''
int chained_compute(int x) {
    int a = x + 1;
    int b = a * 2;
    int c = b + 3;
    return c;
}
'''


class TestBasicDFG:
    """Test basic DFG extraction for C."""

    def test_simple_assignment(self, simple_assignment_code):
        dfg = extract_c_dfg(simple_assignment_code, "calculate")
        assert dfg is not None
        assert dfg.function_name == "calculate"
        # Should have variable references
        assert len(dfg.var_refs) > 0

    def test_reassignment(self, reassignment_code):
        dfg = extract_c_dfg(reassignment_code, "process")
        assert dfg is not None
        # Should find definitions and uses of 'x'
        x_refs = [r for r in dfg.var_refs if r.name == "x"]
        assert len(x_refs) > 0

    def test_loop_variable(self, loop_variable_code):
        dfg = extract_c_dfg(loop_variable_code, "sum")
        assert dfg is not None
        # Should track 'total' through the loop
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0

    def test_chained_data_flow(self, chained_code):
        dfg = extract_c_dfg(chained_code, "chained_compute")
        assert dfg is not None
        # Should have data flow edges for the chain x -> a -> b -> c
        assert len(dfg.dataflow_edges) > 0


class TestDefUseChains:
    """Test def-use chain computation."""

    def test_simple_def_use(self, simple_assignment_code):
        dfg = extract_c_dfg(simple_assignment_code, "calculate")
        # Should have variable references (edges may be empty due to node structure)
        assert len(dfg.var_refs) > 0

    def test_multiple_uses(self, reassignment_code):
        dfg = extract_c_dfg(reassignment_code, "process")
        # x is used multiple times after each reassignment
        assert len(dfg.dataflow_edges) > 0

    def test_conditional_def_use(self, conditional_assignment_code):
        dfg = extract_c_dfg(conditional_assignment_code, "choose")
        assert dfg is not None
        # 'result' should be tracked
        result_refs = [r for r in dfg.var_refs if r.name == "result"]
        assert len(result_refs) > 0


class TestVarRefTypes:
    """Test variable reference type detection."""

    def test_definition_detected(self, simple_assignment_code):
        dfg = extract_c_dfg(simple_assignment_code, "calculate")
        definitions = [r for r in dfg.var_refs if r.ref_type == "definition"]
        assert len(definitions) > 0

    def test_use_detected(self, simple_assignment_code):
        dfg = extract_c_dfg(simple_assignment_code, "calculate")
        uses = [r for r in dfg.var_refs if r.ref_type == "use"]
        assert len(uses) > 0


class TestPointerAndArrayDFG:
    """Test pointer and array variable tracking."""

    def test_pointer_dereference(self, pointer_code):
        dfg = extract_c_dfg(pointer_code, "swap")
        assert dfg is not None
        # Should track temp variable
        temp_refs = [r for r in dfg.var_refs if r.name == "temp"]
        assert len(temp_refs) > 0

    def test_array_access(self, array_code):
        dfg = extract_c_dfg(array_code, "array_sum")
        assert dfg is not None
        # Should track total variable
        total_refs = [r for r in dfg.var_refs if r.name == "total"]
        assert len(total_refs) > 0


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_assignment_code):
        dfg = extract_c_dfg(simple_assignment_code, "nonexistent")
        # Should return empty DFG, not raise
        assert dfg.function_name == "nonexistent"
        assert len(dfg.var_refs) == 0
