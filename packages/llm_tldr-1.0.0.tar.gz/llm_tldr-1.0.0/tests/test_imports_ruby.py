"""Tests for Ruby import parsing.

TDD tests for Ruby language support in TLDR import parsing.
These tests should FAIL initially until Ruby support is implemented.

Ruby import patterns (tree-sitter-ruby):
- require 'module_name' : standard library or gems
- require_relative 'path' : relative path imports
- load 'file.rb' : load and execute file
- These appear as `call` nodes with method name "require", "require_relative", or "load"
"""
import pytest
from pathlib import Path

# Check if tree-sitter-ruby is available
try:
    from tldr.cross_file_calls import parse_ruby_imports, TREE_SITTER_RUBY_AVAILABLE
    RUBY_AVAILABLE = TREE_SITTER_RUBY_AVAILABLE
except ImportError:
    RUBY_AVAILABLE = False


pytestmark = pytest.mark.skipif(not RUBY_AVAILABLE, reason="tree-sitter-ruby not available")


@pytest.fixture
def simple_imports_file(tmp_path):
    """Create a Ruby file with simple require statements."""
    code = '''
require 'json'
require 'yaml'

class Example
  def process(data)
    JSON.parse(data)
  end
end
'''
    file_path = tmp_path / "example.rb"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def relative_imports_file(tmp_path):
    """Create a Ruby file with require_relative statements."""
    code = '''
require_relative 'helper'
require_relative '../lib/utils'
require_relative './models/user'

class Example
  def run
    Helper.new.execute
  end
end
'''
    file_path = tmp_path / "example.rb"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create a Ruby file with mixed import statements."""
    code = '''
require 'json'
require 'net/http'
require_relative 'config'
require_relative '../lib/helpers/formatter'
load 'legacy_code.rb'

class Application
  def initialize
    @config = Config.load
  end
end
'''
    file_path = tmp_path / "application.rb"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def gem_imports_file(tmp_path):
    """Create a Ruby file with gem requires."""
    code = '''
require 'bundler/setup'
require 'rails'
require 'activerecord'
require 'nokogiri'

class Parser
  def parse(html)
    Nokogiri::HTML(html)
  end
end
'''
    file_path = tmp_path / "parser.rb"
    file_path.write_text(code)
    return file_path


class TestSimpleImports:
    """Test basic import parsing."""

    def test_parses_require_statements(self, simple_imports_file):
        imports = parse_ruby_imports(simple_imports_file)
        assert len(imports) == 2
        modules = [imp['module'] for imp in imports]
        assert 'json' in modules
        assert 'yaml' in modules

    def test_relative_imports(self, relative_imports_file):
        imports = parse_ruby_imports(relative_imports_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        assert any('helper' in m for m in modules)
        assert any('utils' in m for m in modules)

    def test_gem_imports(self, gem_imports_file):
        imports = parse_ruby_imports(gem_imports_file)
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        assert any('rails' in m for m in modules)
        assert any('nokogiri' in m for m in modules)


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_ruby_imports(mixed_imports_file)
        # Should have all imports: require, require_relative, and load
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('json' in m for m in modules)
        assert any('config' in m for m in modules)

    def test_import_types_distinguished(self, mixed_imports_file):
        imports = parse_ruby_imports(mixed_imports_file)
        # Imports should indicate their type (require vs require_relative)
        import_types = set()
        for imp in imports:
            if 'type' in imp:
                import_types.add(imp['type'])
            elif 'is_relative' in imp:
                import_types.add('relative' if imp['is_relative'] else 'absolute')
        # Should have both types
        assert len(import_types) >= 1  # At minimum should track type


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "empty.rb"
        file_path.write_text("class Empty; end")
        imports = parse_ruby_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "nonexistent.rb"
        imports = parse_ruby_imports(file_path)
        assert imports == []

    def test_conditional_require(self, tmp_path):
        """Require inside if statement should still be detected."""
        code = '''
if RUBY_VERSION >= '3.0'
  require 'new_feature'
else
  require 'compatibility_shim'
end
'''
        file_path = tmp_path / "conditional.rb"
        file_path.write_text(code)
        imports = parse_ruby_imports(file_path)
        # Should detect both requires
        assert len(imports) >= 2

    def test_only_class_definition(self, tmp_path):
        code = '''
class NoImports
  def test
    puts "hello"
  end
end
'''
        file_path = tmp_path / "no_imports.rb"
        file_path.write_text(code)
        imports = parse_ruby_imports(file_path)
        assert imports == []
