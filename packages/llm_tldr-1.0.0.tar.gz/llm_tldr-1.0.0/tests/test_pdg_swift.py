"""Tests for Swift PDG extraction and program slicing (L5).

TDD Tests for Swift PDG support.
These tests are expected to FAIL initially until Swift support is implemented.

Tests mirror the structure of test_pdg_java.py but for Swift language support.
Swift CFG (L3) and DFG (L4) must be implemented first.
"""
import os
import pytest

# Check if tree-sitter-swift is available
try:
    from tldr.cfg_extractor import TREE_SITTER_SWIFT_AVAILABLE
    SWIFT_AVAILABLE = TREE_SITTER_SWIFT_AVAILABLE
except ImportError:
    SWIFT_AVAILABLE = False

# Check if extract_swift_pdg is implemented
try:
    from tldr.pdg_extractor import extract_swift_pdg
    SWIFT_PDG_AVAILABLE = True
except ImportError:
    SWIFT_PDG_AVAILABLE = False
    extract_swift_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not SWIFT_AVAILABLE,
    reason="tree-sitter-swift not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_swift_path():
    """Path to sample.swift fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.swift")


@pytest.fixture
def sample_swift_code(sample_swift_path):
    """Load sample.swift fixture code."""
    with open(sample_swift_path) as f:
        return f.read()


@pytest.fixture
def simple_swift_code():
    """Simple Swift code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
// =============================================================================
// Simple Swift test fixture for PDG extraction
// This code is used to test basic PDG node and edge extraction.
// The add function has simple data flow: a -> c, b -> c, c -> return
// =============================================================================
class Example {
    func add(a: Int, b: Int) -> Int {
        let c = a + b
        return c
    }
}
'''


@pytest.fixture
def chained_swift_code():
    """Swift code with chained dependencies for slice testing."""
    return '''
// =============================================================================
// Chained Swift test fixture for PDG extraction
// This code is used to test program slicing with data flow chains.
// Chain: x -> a -> b -> c -> return
// =============================================================================
class ChainedCompute {
    func compute(x: Int) -> Int {
        let a = x + 1     // line 9: a depends on x
        let b = a * 2     // line 10: b depends on a
        let c = b + 3     // line 11: c depends on b
        return c          // line 12: return depends on c
    }
}
'''


# =============================================================================
# Tests for extract_swift_pdg()
# =============================================================================

class TestExtractSwiftPDG:
    """Test extract_swift_pdg() function."""

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_extract_swift_pdg_basic(self, sample_swift_code):
        """Test basic PDG extraction from sample.swift calculate function."""
        pdg = extract_swift_pdg(sample_swift_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_extract_swift_pdg_has_nodes(self, sample_swift_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_swift_pdg(sample_swift_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_extract_swift_pdg_has_edges(self, sample_swift_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_swift_pdg(sample_swift_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        # Note: PDGEdge uses dep_type attribute (control/data)
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_extract_swift_pdg_sum_function(self, sample_swift_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_swift_pdg(sample_swift_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_extract_swift_pdg_nonexistent_function(self, sample_swift_code):
        """Test that nonexistent function returns None."""
        pdg = extract_swift_pdg(sample_swift_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for Swift Program Slicing
# =============================================================================

class TestSwiftProgramSlicing:
    """Test program slicing for Swift code."""

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_swift_backward_slice(self, sample_swift_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_swift_pdg(sample_swift_code, "sum")

        assert pdg is not None
        # Line 26 is "return total" in sample.swift
        slice_lines = pdg.backward_slice(line=26)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_swift_forward_slice(self, chained_swift_code):
        """Test forward slice from first assignment."""
        pdg = extract_swift_pdg(chained_swift_code, "compute")

        assert pdg is not None
        # Forward slice from "let a = x + 1" (line 9)
        slice_lines = pdg.forward_slice(line=9)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_swift_slice_returns_set(self, simple_swift_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_swift_pdg(simple_swift_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=11)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)


# =============================================================================
# Tests for Swift PDG via API
# =============================================================================

class TestSwiftPDGAPI:
    """Test Swift PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_swift_get_pdg_context(self, sample_swift_path):
        """Test get_pdg_context() for Swift code via file path."""
        result = get_pdg_context(sample_swift_path, "calculate", language="swift")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_swift_get_slice_backward(self, sample_swift_path):
        """Test get_slice() backward for Swift code via file path."""
        # Backward slice from return statement in sum function
        lines = get_slice(
            sample_swift_path, "sum", line=26,
            direction="backward", language="swift"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_swift_get_slice_forward(self, sample_swift_path):
        """Test get_slice() forward for Swift code via file path."""
        # Forward slice from first assignment in compute function
        lines = get_slice(
            sample_swift_path, "compute", line=46,
            direction="forward", language="swift"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0


# =============================================================================
# Integration Tests
# =============================================================================

class TestSwiftPDGIntegration:
    """Integration tests for Swift PDG."""

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_pdg_from_file(self, sample_swift_path, sample_swift_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_swift_pdg(sample_swift_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not SWIFT_PDG_AVAILABLE, reason="extract_swift_pdg not implemented")
    def test_pdg_to_dict(self, simple_swift_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_swift_pdg(simple_swift_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
