"""Tests for tldr.patch module - True Incremental Updates (P4).

This module tests the file-level graph patching system for O(1) updates
instead of O(all files) full rebuilds.
"""

import hashlib
import tempfile
import pytest
from pathlib import Path

# Import the module under test - will fail until implemented
from tldr.patch import (
    compute_file_hash,
    extract_edges_from_file,
    patch_call_graph,
    has_file_changed,
    Edge,
)
from tldr.cross_file_calls import ProjectCallGraph, build_project_call_graph


class TestComputeFileHash:
    """Tests for compute_file_hash() function."""

    def test_compute_file_hash_returns_sha1(self, tmp_path):
        """compute_file_hash() should return a SHA-1 hash string."""
        test_file = tmp_path / "test.py"
        test_file.write_text("def foo(): pass")

        result = compute_file_hash(str(test_file))

        # SHA-1 is 40 hex characters
        assert len(result) == 40
        assert all(c in "0123456789abcdef" for c in result)

    def test_compute_file_hash_consistent(self, tmp_path):
        """compute_file_hash() should return same hash for same content."""
        test_file = tmp_path / "test.py"
        content = "def foo(): pass"
        test_file.write_text(content)

        hash1 = compute_file_hash(str(test_file))
        hash2 = compute_file_hash(str(test_file))

        assert hash1 == hash2

    def test_compute_file_hash_different_for_different_content(self, tmp_path):
        """compute_file_hash() should return different hash for different content."""
        file1 = tmp_path / "file1.py"
        file2 = tmp_path / "file2.py"
        file1.write_text("def foo(): pass")
        file2.write_text("def bar(): pass")

        hash1 = compute_file_hash(str(file1))
        hash2 = compute_file_hash(str(file2))

        assert hash1 != hash2

    def test_compute_file_hash_handles_utf8(self, tmp_path):
        """compute_file_hash() should handle UTF-8 content."""
        test_file = tmp_path / "test.py"
        test_file.write_text('# Comment with unicode: \u00e9\u00e8\u00ea\ndef foo(): pass')

        result = compute_file_hash(str(test_file))

        assert len(result) == 40

    def test_compute_file_hash_empty_file(self, tmp_path):
        """compute_file_hash() should handle empty files."""
        test_file = tmp_path / "empty.py"
        test_file.write_text("")

        result = compute_file_hash(str(test_file))

        # Should be hash of empty string
        expected = hashlib.sha1(b"").hexdigest()
        assert result == expected


class TestHasFileChanged:
    """Tests for has_file_changed() function."""

    def test_has_file_changed_returns_false_for_same_hash(self, tmp_path):
        """has_file_changed() should return False when hash matches."""
        test_file = tmp_path / "test.py"
        test_file.write_text("def foo(): pass")

        current_hash = compute_file_hash(str(test_file))

        assert has_file_changed(str(test_file), current_hash) is False

    def test_has_file_changed_returns_true_for_different_hash(self, tmp_path):
        """has_file_changed() should return True when hash differs."""
        test_file = tmp_path / "test.py"
        test_file.write_text("def foo(): pass")

        # Use a bogus old hash
        old_hash = "a" * 40

        assert has_file_changed(str(test_file), old_hash) is True

    def test_has_file_changed_detects_content_change(self, tmp_path):
        """has_file_changed() should detect when file content changes."""
        test_file = tmp_path / "test.py"
        test_file.write_text("def foo(): pass")

        old_hash = compute_file_hash(str(test_file))

        # Modify the file
        test_file.write_text("def foo(): return 42")

        assert has_file_changed(str(test_file), old_hash) is True

    def test_has_file_changed_handles_missing_file(self, tmp_path):
        """has_file_changed() should return True for missing files."""
        missing_file = tmp_path / "does_not_exist.py"
        old_hash = "a" * 40

        # Missing file should be considered "changed" (or needs handling)
        assert has_file_changed(str(missing_file), old_hash) is True


class TestEdge:
    """Tests for Edge dataclass."""

    def test_edge_creation(self):
        """Edge should be creatable with from/to file and function."""
        edge = Edge(
            from_file="main.py",
            from_func="main",
            to_file="utils.py",
            to_func="helper"
        )

        assert edge.from_file == "main.py"
        assert edge.from_func == "main"
        assert edge.to_file == "utils.py"
        assert edge.to_func == "helper"

    def test_edge_equality(self):
        """Edges with same values should be equal."""
        edge1 = Edge("a.py", "f1", "b.py", "f2")
        edge2 = Edge("a.py", "f1", "b.py", "f2")

        assert edge1 == edge2

    def test_edge_hashable(self):
        """Edges should be hashable for use in sets."""
        edge = Edge("a.py", "f1", "b.py", "f2")

        # Should not raise
        edge_set = {edge}
        assert edge in edge_set


class TestExtractEdgesFromFile:
    """Tests for extract_edges_from_file() function."""

    def test_extract_edges_from_file_python(self, tmp_path):
        """extract_edges_from_file() should extract edges from Python file."""
        test_file = tmp_path / "test.py"
        test_file.write_text('''
def caller():
    return helper()

def helper():
    return 42
''')

        edges = extract_edges_from_file(str(test_file), lang="python")

        # Should have intra-file edge: caller -> helper
        assert any(
            e.from_func == "caller" and e.to_func == "helper"
            for e in edges
        )

    def test_extract_edges_from_file_no_calls(self, tmp_path):
        """extract_edges_from_file() should return empty list for file with no calls."""
        test_file = tmp_path / "test.py"
        test_file.write_text('''
def standalone():
    return 42
''')

        edges = extract_edges_from_file(str(test_file), lang="python")

        assert edges == []

    def test_extract_edges_from_file_multiple_calls(self, tmp_path):
        """extract_edges_from_file() should extract multiple edges."""
        test_file = tmp_path / "test.py"
        test_file.write_text('''
def main():
    helper1()
    helper2()

def helper1():
    pass

def helper2():
    pass
''')

        edges = extract_edges_from_file(str(test_file), lang="python")

        # Should have two edges from main
        main_edges = [e for e in edges if e.from_func == "main"]
        assert len(main_edges) == 2

    def test_extract_edges_includes_file_path(self, tmp_path):
        """extract_edges_from_file() should include file path in edges."""
        test_file = tmp_path / "module.py"
        test_file.write_text('''
def caller():
    return callee()

def callee():
    pass
''')

        edges = extract_edges_from_file(str(test_file), lang="python")

        assert len(edges) >= 1
        edge = edges[0]
        # from_file should be the relative path or filename
        assert "module.py" in edge.from_file

    def test_extract_edges_handles_syntax_error(self, tmp_path):
        """extract_edges_from_file() should handle syntax errors gracefully."""
        test_file = tmp_path / "broken.py"
        test_file.write_text("def broken( this is not valid python")

        edges = extract_edges_from_file(str(test_file), lang="python")

        # Should return empty list, not raise
        assert edges == []


class TestPatchCallGraph:
    """Tests for patch_call_graph() function."""

    def test_patch_call_graph_removes_old_edges(self, tmp_path):
        """patch_call_graph() should remove old edges from edited file."""
        # Setup: Create initial graph with edges
        graph = ProjectCallGraph()
        graph.add_edge("edited.py", "old_func", "other.py", "helper")
        graph.add_edge("other.py", "caller", "edited.py", "old_func")

        # Create the edited file (now empty)
        edited_file = tmp_path / "edited.py"
        edited_file.write_text("# No functions here anymore")

        # Patch the graph
        patched = patch_call_graph(graph, str(edited_file), str(tmp_path), lang="python")

        # Edge FROM edited.py should be gone
        assert ("edited.py", "old_func", "other.py", "helper") not in patched.edges

        # Edge TO edited.py should still exist (caller unchanged)
        # Note: This edge is from other.py, so it shouldn't be affected
        # unless we also patch other.py

    def test_patch_call_graph_adds_new_edges(self, tmp_path):
        """patch_call_graph() should add new edges from edited file."""
        # Setup: Create empty graph
        graph = ProjectCallGraph()

        # Create the edited file with a new function
        (tmp_path / "helper.py").write_text("def helper_func(): pass")
        edited_file = tmp_path / "main.py"
        edited_file.write_text('''
def main():
    return helper_func()

def helper_func():
    return 42
''')

        # Patch the graph
        patched = patch_call_graph(graph, str(edited_file), str(tmp_path), lang="python")

        # New intra-file edge should exist
        edges = list(patched.edges)
        main_to_helper = [e for e in edges if "main" in e[1] and "helper_func" in e[3]]
        assert len(main_to_helper) >= 1

    def test_patch_call_graph_preserves_other_edges(self, tmp_path):
        """patch_call_graph() should preserve edges from other files."""
        # Setup: Create graph with edges from multiple files
        graph = ProjectCallGraph()
        graph.add_edge("unrelated.py", "func_a", "utils.py", "helper")
        graph.add_edge("another.py", "func_b", "utils.py", "helper")

        # Create the edited file
        edited_file = tmp_path / "edited.py"
        edited_file.write_text("def new_func(): pass")

        # Patch the graph
        patched = patch_call_graph(graph, str(edited_file), str(tmp_path), lang="python")

        # Edges from other files should still exist
        assert ("unrelated.py", "func_a", "utils.py", "helper") in patched.edges
        assert ("another.py", "func_b", "utils.py", "helper") in patched.edges

    def test_patch_call_graph_empty_graph(self, tmp_path):
        """patch_call_graph() should work with empty initial graph."""
        graph = ProjectCallGraph()

        edited_file = tmp_path / "test.py"
        edited_file.write_text('''
def caller():
    return callee()

def callee():
    pass
''')

        patched = patch_call_graph(graph, str(edited_file), str(tmp_path), lang="python")

        # Should have the new edge
        edges = list(patched.edges)
        assert len(edges) >= 1

    def test_patch_call_graph_file_with_no_calls(self, tmp_path):
        """patch_call_graph() should work with file that has no calls."""
        graph = ProjectCallGraph()
        graph.add_edge("old.py", "func", "target.py", "helper")

        edited_file = tmp_path / "standalone.py"
        edited_file.write_text('''
def standalone():
    return 42
''')

        patched = patch_call_graph(graph, str(edited_file), str(tmp_path), lang="python")

        # Original edge should still exist
        assert ("old.py", "func", "target.py", "helper") in patched.edges


class TestEndToEndPatching:
    """End-to-end tests for incremental patching workflow."""

    def test_edit_adds_new_call(self, tmp_path):
        """Editing a file to add a new call should update the graph."""
        # Create initial project
        (tmp_path / "utils.py").write_text('''
def helper():
    return 42
''')
        main_file = tmp_path / "main.py"
        main_file.write_text('''
def main():
    pass
''')

        # Build initial graph
        graph = build_project_call_graph(str(tmp_path), language="python")
        initial_edge_count = len(list(graph.edges))

        # Edit main.py to add a call
        main_file.write_text('''
from utils import helper

def main():
    return helper()
''')

        # Patch the graph
        patched = patch_call_graph(graph, str(main_file), str(tmp_path), lang="python")

        # Should have new edge
        edges = list(patched.edges)
        assert len(edges) >= initial_edge_count

    def test_edit_removes_call(self, tmp_path):
        """Editing a file to remove a call should update the graph."""
        # Create initial project with a call
        (tmp_path / "utils.py").write_text('''
def helper():
    return 42
''')
        main_file = tmp_path / "main.py"
        main_file.write_text('''
def main():
    return inner()

def inner():
    return 1
''')

        # Build initial graph
        graph = build_project_call_graph(str(tmp_path), language="python")

        # Edit main.py to remove the call
        main_file.write_text('''
def main():
    return 42

def inner():
    return 1
''')

        # Patch the graph
        patched = patch_call_graph(graph, str(main_file), str(tmp_path), lang="python")

        # Edge from main -> inner should be gone
        edges = list(patched.edges)
        main_to_inner = [e for e in edges if e[1] == "main" and e[3] == "inner"]
        assert len(main_to_inner) == 0

    def test_patch_only_affects_edited_file(self, tmp_path):
        """Patching should only re-extract edges from the edited file."""
        # Create a multi-file project
        (tmp_path / "a.py").write_text('''
def func_a():
    return func_a_helper()

def func_a_helper():
    pass
''')
        (tmp_path / "b.py").write_text('''
def func_b():
    return func_b_helper()

def func_b_helper():
    pass
''')

        # Build initial graph
        graph = build_project_call_graph(str(tmp_path), language="python")

        # Count edges from each file
        edges = list(graph.edges)
        a_edges_before = [e for e in edges if e[0] == "a.py"]
        b_edges_before = [e for e in edges if e[0] == "b.py"]

        # Edit only a.py
        (tmp_path / "a.py").write_text('''
def func_a():
    pass  # Removed call

def func_a_helper():
    pass
''')

        # Patch the graph for a.py only
        patched = patch_call_graph(graph, str(tmp_path / "a.py"), str(tmp_path), lang="python")

        # b.py edges should be unchanged
        patched_edges = list(patched.edges)
        b_edges_after = [e for e in patched_edges if e[0] == "b.py"]
        assert b_edges_after == b_edges_before


class TestTypescriptPatching:
    """Tests for TypeScript incremental patching."""

    def test_extract_edges_from_typescript_file(self, tmp_path):
        """extract_edges_from_file() should work with TypeScript."""
        test_file = tmp_path / "test.ts"
        test_file.write_text('''
function caller() {
    return helper();
}

function helper() {
    return 42;
}
''')

        edges = extract_edges_from_file(str(test_file), lang="typescript")

        # Should have intra-file edge
        assert any(
            e.from_func == "caller" and e.to_func == "helper"
            for e in edges
        )


class TestHashCaching:
    """Tests for content-hash deduplication."""

    def test_skip_unchanged_file(self, tmp_path):
        """Files with unchanged hash should be skipped."""
        test_file = tmp_path / "test.py"
        test_file.write_text("def foo(): pass")

        hash1 = compute_file_hash(str(test_file))

        # File unchanged - hash should match
        assert has_file_changed(str(test_file), hash1) is False

        # Modify and check again
        test_file.write_text("def bar(): pass")
        assert has_file_changed(str(test_file), hash1) is True


class TestDirtyFileIntegration:
    """Tests for integration with dirty flag system."""

    def test_patch_dirty_files_patches_all_dirty(self, tmp_path):
        """patch_dirty_files() should patch graph for all dirty files."""
        from tldr.patch import patch_dirty_files

        # Create initial project
        (tmp_path / "a.py").write_text('''
def func_a():
    return helper_a()

def helper_a():
    pass
''')
        (tmp_path / "b.py").write_text('''
def func_b():
    return helper_b()

def helper_b():
    pass
''')

        # Build initial graph
        graph = build_project_call_graph(str(tmp_path), language="python")
        initial_edges = set(graph.edges)

        # Modify a.py - remove the call
        (tmp_path / "a.py").write_text('''
def func_a():
    pass

def helper_a():
    pass
''')

        # Patch with dirty file list
        patched = patch_dirty_files(graph, str(tmp_path), ["a.py"], lang="python")

        # Edge from func_a -> helper_a should be gone
        patched_edges = set(patched.edges)
        assert patched_edges != initial_edges

        # b.py edges should be unchanged
        b_edges = [e for e in patched_edges if e[0] == "b.py"]
        assert len(b_edges) >= 1

    def test_patch_dirty_files_handles_missing_file(self, tmp_path):
        """patch_dirty_files() should skip missing files gracefully."""
        from tldr.patch import patch_dirty_files

        graph = ProjectCallGraph()
        graph.add_edge("existing.py", "func", "other.py", "helper")

        # Patch with a non-existent file
        patched = patch_dirty_files(
            graph,
            str(tmp_path),
            ["does_not_exist.py"],
            lang="python"
        )

        # Original edge should still exist
        assert ("existing.py", "func", "other.py", "helper") in patched.edges
