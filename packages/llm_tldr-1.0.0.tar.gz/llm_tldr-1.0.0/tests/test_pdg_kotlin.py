"""Tests for Kotlin PDG extraction and program slicing (L5).

TDD Tests for Kotlin PDG support.

Tests mirror the structure of test_pdg_java.py but for Kotlin language support.
Kotlin CFG (L3) and DFG (L4) are tested in test_cfg_kotlin.py and test_dfg_kotlin.py.
"""
import os
import pytest

# Check if tree-sitter-kotlin is available
try:
    from tldr.cfg_extractor import TREE_SITTER_KOTLIN_AVAILABLE
    KOTLIN_AVAILABLE = TREE_SITTER_KOTLIN_AVAILABLE
except ImportError:
    KOTLIN_AVAILABLE = False

# Check if extract_kotlin_pdg is implemented
try:
    from tldr.pdg_extractor import extract_kotlin_pdg
    KOTLIN_PDG_AVAILABLE = True
except ImportError:
    KOTLIN_PDG_AVAILABLE = False
    extract_kotlin_pdg = None

from tldr.api import get_slice, get_pdg_context


pytestmark = pytest.mark.skipif(
    not KOTLIN_AVAILABLE,
    reason="tree-sitter-kotlin not available"
)


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_kotlin_path():
    """Path to sample.kt fixture."""
    return os.path.join(os.path.dirname(__file__), "fixtures", "sample.kt")


@pytest.fixture
def sample_kotlin_code(sample_kotlin_path):
    """Load sample.kt fixture code."""
    with open(sample_kotlin_path) as f:
        return f.read()


@pytest.fixture
def simple_kotlin_code():
    """Simple Kotlin code for basic tests (inline, > 500 chars to avoid path heuristic)."""
    # Padded with comments to exceed 500 chars and avoid _resolve_source treating as path
    return '''
// =============================================================================
// Simple Kotlin test fixture for PDG extraction
// This code is used to test basic PDG node and edge extraction.
// The add function has simple data flow: a -> c, b -> c, c -> return
// =============================================================================
class Example {
    fun add(a: Int, b: Int): Int {
        val c = a + b
        return c
    }
}
'''


@pytest.fixture
def chained_kotlin_code():
    """Kotlin code with chained dependencies for slice testing."""
    return '''
// =============================================================================
// Chained Kotlin test fixture for PDG slice testing
// This code tests forward and backward slicing with clear data dependencies.
// x -> a -> b -> c -> return
// =============================================================================
class ChainedCompute {
    fun compute(x: Int): Int {
        val a = x + 1     // line 10: a depends on x
        val b = a * 2     // line 11: b depends on a
        val c = b + 3     // line 12: c depends on b
        return c          // line 13: return depends on c
    }
}
'''


# =============================================================================
# Tests for extract_kotlin_pdg()
# =============================================================================

class TestExtractKotlinPDG:
    """Test extract_kotlin_pdg() function."""

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_extract_kotlin_pdg_basic(self, sample_kotlin_code):
        """Test basic PDG extraction from sample.kt calculate function."""
        pdg = extract_kotlin_pdg(sample_kotlin_code, "calculate")

        assert pdg is not None
        assert pdg.function_name == "calculate"

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_extract_kotlin_pdg_has_nodes(self, sample_kotlin_code):
        """Verify PDG has nodes extracted from the function."""
        pdg = extract_kotlin_pdg(sample_kotlin_code, "calculate")

        assert pdg is not None
        assert len(pdg.nodes) > 0
        # Should have at least entry and exit nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_extract_kotlin_pdg_has_edges(self, sample_kotlin_code):
        """Verify PDG has edges (control and/or data)."""
        pdg = extract_kotlin_pdg(sample_kotlin_code, "calculate")

        assert pdg is not None
        # PDG should have edges connecting nodes
        # Note: PDGEdge uses dep_type attribute (control/data)
        assert len(pdg.edges) >= 0  # May have 0 edges for simple functions

        # If there are edges, verify they have proper types
        for edge in pdg.edges:
            assert edge.dep_type in ("control", "data"), f"Invalid dep_type: {edge.dep_type}"

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_extract_kotlin_pdg_sum_function(self, sample_kotlin_code):
        """Test PDG extraction for the sum function with loop."""
        pdg = extract_kotlin_pdg(sample_kotlin_code, "sum")

        assert pdg is not None
        assert pdg.function_name == "sum"
        # sum function should have nodes
        assert len(pdg.nodes) >= 2

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_extract_kotlin_pdg_nonexistent_function(self, sample_kotlin_code):
        """Test that nonexistent function returns None."""
        pdg = extract_kotlin_pdg(sample_kotlin_code, "nonexistent")

        assert pdg is None


# =============================================================================
# Tests for Kotlin Program Slicing
# =============================================================================

class TestKotlinProgramSlicing:
    """Test program slicing for Kotlin code."""

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_kotlin_backward_slice(self, sample_kotlin_code):
        """Test backward slice from return statement in sum function."""
        pdg = extract_kotlin_pdg(sample_kotlin_code, "sum")

        assert pdg is not None
        # Line 38 is "return total" in sample.kt
        slice_lines = pdg.backward_slice(line=38)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should include the return line or lines that affect it

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_kotlin_forward_slice(self, chained_kotlin_code):
        """Test forward slice from first assignment."""
        pdg = extract_kotlin_pdg(chained_kotlin_code, "compute")

        assert pdg is not None
        # Forward slice from "val a = x + 1" (line 10 in fixture)
        slice_lines = pdg.forward_slice(line=10)

        assert isinstance(slice_lines, set)
        assert len(slice_lines) > 0
        # Should propagate through the chain to later lines

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_kotlin_slice_returns_set(self, simple_kotlin_code):
        """Verify slice returns a set of line numbers."""
        pdg = extract_kotlin_pdg(simple_kotlin_code, "add")

        assert pdg is not None
        slice_lines = pdg.backward_slice(line=10)  # return c

        assert isinstance(slice_lines, set)
        # All elements should be integers (line numbers)
        for line in slice_lines:
            assert isinstance(line, int)

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_kotlin_slice_nonexistent_function(self, sample_kotlin_code):
        """Test that slicing nonexistent function returns empty set."""
        pdg = extract_kotlin_pdg(sample_kotlin_code, "nonexistent")

        # Either returns None (no PDG) or empty slice
        if pdg is None:
            # This is acceptable behavior
            pass
        else:
            slice_lines = pdg.backward_slice(line=10)
            assert slice_lines == set()


# =============================================================================
# Tests for Kotlin PDG via API
# =============================================================================

class TestKotlinPDGAPI:
    """Test Kotlin PDG integration via tldr.api functions.

    These tests use file paths to avoid the _resolve_source heuristic issue
    where short source code strings are mistaken for file paths.
    """

    def test_kotlin_get_pdg_context(self, sample_kotlin_path):
        """Test get_pdg_context() for Kotlin code via file path."""
        result = get_pdg_context(sample_kotlin_path, "calculate", language="kotlin")

        assert result is not None
        assert "function" in result
        assert result["function"] == "calculate"
        assert "nodes" in result
        assert "control_edges" in result
        assert "data_edges" in result

    def test_kotlin_get_slice_backward(self, sample_kotlin_path):
        """Test get_slice() backward for Kotlin code via file path."""
        # Backward slice from return statement in sum function
        lines = get_slice(
            sample_kotlin_path, "sum", line=38,
            direction="backward", language="kotlin"
        )

        assert isinstance(lines, set)
        assert len(lines) > 0

    def test_kotlin_get_slice_forward(self, sample_kotlin_path):
        """Test get_slice() forward for Kotlin code via file path."""
        # Forward slice from compute function - line 59 is where compute starts
        lines = get_slice(
            sample_kotlin_path, "compute", line=59,
            direction="forward", language="kotlin"
        )

        assert isinstance(lines, set)
        # Forward slice may be empty if no data flows out from the starting point
        # This is expected behavior for the first line of a function


# =============================================================================
# Integration Tests
# =============================================================================

class TestKotlinPDGIntegration:
    """Integration tests for Kotlin PDG."""

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_pdg_from_file(self, sample_kotlin_path, sample_kotlin_code):
        """Test PDG extraction works with file content."""
        # Extract PDG for calculate function
        pdg = extract_kotlin_pdg(sample_kotlin_code, "calculate")

        assert pdg is not None

        # Get compact dict representation
        compact = pdg.to_compact_dict()
        assert "function" in compact
        assert compact["function"] == "calculate"
        assert "complexity" in compact

    @pytest.mark.skipif(not KOTLIN_PDG_AVAILABLE, reason="extract_kotlin_pdg not implemented")
    def test_pdg_to_dict(self, simple_kotlin_code):
        """Test PDG serialization to dictionary."""
        pdg = extract_kotlin_pdg(simple_kotlin_code, "add")

        assert pdg is not None
        d = pdg.to_dict()

        assert isinstance(d, dict)
        # to_dict() returns nested structure with 'function' key
        assert "function" in d
        assert "pdg" in d
        assert "cfg" in d
        assert "dfg" in d
        assert d["function"] == "add"
