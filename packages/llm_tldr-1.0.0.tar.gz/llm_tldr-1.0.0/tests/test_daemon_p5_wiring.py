"""Tests for P5 feature wiring into daemon.

P5 Features:
- ContentHashedIndex (dedup.py): Skip unchanged files via content hashing
- SalsaDB (salsa.py): Memoize query results with automatic invalidation
- Incremental parsing: Faster AST rebuilds on file changes

These tests verify that P5 features are properly integrated into daemon.py.
"""

import json
import tempfile
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestDaemonContentHashedIndex:
    """Tests for ContentHashedIndex integration into daemon."""

    def test_daemon_has_dedup_index(self):
        """Daemon should have ContentHashedIndex attribute (lazy-loaded)."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            daemon = TLDRDaemon(project)

            # Daemon should have dedup_index attribute (None before lazy load)
            assert hasattr(daemon, "dedup_index")

            # After ensure, it should be initialized
            daemon._ensure_dedup_index_loaded()
            assert daemon.dedup_index is not None

    def test_daemon_uses_dedup_for_edges(self):
        """Daemon should use ContentHashedIndex when extracting edges."""
        from tldr.daemon import TLDRDaemon
        from tldr.dedup import ContentHashedIndex

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)

            # Create test files with same content
            content = "def foo(): bar()\ndef bar(): pass"
            (project / "a.py").write_text(content)
            (project / "b.py").write_text(content)

            daemon = TLDRDaemon(project)

            # Ensure index is loaded with dedup
            daemon._ensure_dedup_index_loaded()

            # Both files should share same content hash
            stats = daemon.dedup_index.stats()
            assert stats["total_files"] >= 2
            assert stats["unique_hashes"] == 1
            assert stats["dedup_savings"] >= 1

    def test_daemon_persists_dedup_index(self):
        """Daemon should save dedup index on shutdown."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            (project / "test.py").write_text("def foo(): pass")

            daemon = TLDRDaemon(project)
            daemon._ensure_dedup_index_loaded()

            # Get edges to populate the index
            daemon.dedup_index.get_or_create_edges(
                str(project / "test.py"), lang="python"
            )
            daemon._save_dedup_index()

            # Check index was saved
            cache_file = project / ".tldr" / "cache" / "content_index.json"
            assert cache_file.exists()

    def test_daemon_loads_dedup_index_on_start(self):
        """Daemon should load persisted dedup index on startup."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            (project / "test.py").write_text("def foo(): pass")

            # First daemon - populate and save
            daemon1 = TLDRDaemon(project)
            daemon1._ensure_dedup_index_loaded()
            daemon1.dedup_index.get_or_create_edges(
                str(project / "test.py"), lang="python"
            )
            daemon1._save_dedup_index()

            # Second daemon - should load saved index
            daemon2 = TLDRDaemon(project)
            daemon2._ensure_dedup_index_loaded()

            # Should have loaded the saved state
            stats = daemon2.dedup_index.stats()
            assert stats["total_files"] >= 1


class TestDaemonSalsaDB:
    """Tests for SalsaDB integration into daemon."""

    def test_daemon_has_salsa_db(self):
        """Daemon should initialize SalsaDB for query memoization."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            daemon = TLDRDaemon(project)

            assert hasattr(daemon, "salsa_db")
            assert daemon.salsa_db is not None

    def test_daemon_caches_search_results(self):
        """Search results should be cached by SalsaDB."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            test_file = project / "test.py"
            test_file.write_text("def hello():\n    print('world')\n")

            daemon = TLDRDaemon(project)

            # First search - should compute
            result1 = daemon.handle_command({"cmd": "search", "pattern": "hello"})
            stats1 = daemon.salsa_db.get_stats()
            initial_misses = stats1["cache_misses"]

            # Second identical search - should hit cache
            result2 = daemon.handle_command({"cmd": "search", "pattern": "hello"})
            stats2 = daemon.salsa_db.get_stats()

            # Results should be identical
            assert result1 == result2

            # Should have cache hit (or at least no new miss)
            assert stats2["cache_hits"] > stats1.get("cache_hits", 0) or \
                   stats2["cache_misses"] == initial_misses

    def test_daemon_invalidates_on_file_change(self):
        """SalsaDB cache should invalidate when files change."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            test_file = project / "test.py"
            test_file.write_text("def hello(): pass")

            daemon = TLDRDaemon(project)

            # First search
            result1 = daemon.handle_command({"cmd": "search", "pattern": "hello"})

            # Simulate file change notification
            daemon.notify_file_changed(str(test_file))

            # Search again - should recompute due to invalidation
            test_file.write_text("def hello(): pass\ndef world(): pass")
            result2 = daemon.handle_command({"cmd": "search", "pattern": "hello"})

            # Results may differ due to file change
            # Key point: invalidation happened, new result was computed


class TestDaemonCachingPerformance:
    """Tests verifying caching improves performance."""

    def test_second_query_faster_than_first(self):
        """Second identical query should be faster due to caching."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)

            # Create some test files
            for i in range(5):
                (project / f"module_{i}.py").write_text(
                    f"def func_{i}():\n    return {i}\n"
                )

            daemon = TLDRDaemon(project)

            # First query - cold cache
            start1 = time.perf_counter()
            daemon.handle_command({"cmd": "search", "pattern": "func"})
            time1 = time.perf_counter() - start1

            # Second query - warm cache
            start2 = time.perf_counter()
            daemon.handle_command({"cmd": "search", "pattern": "func"})
            time2 = time.perf_counter() - start2

            # Second should be faster (or at least not significantly slower)
            # Allow some tolerance for timing variations
            assert time2 <= time1 * 1.5 or time2 < 0.01  # Either faster or trivially fast


class TestDaemonFileChangeHandling:
    """Tests for file change detection and cache invalidation."""

    def test_notify_file_changed_exists(self):
        """Daemon should have notify_file_changed method."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            daemon = TLDRDaemon(project)

            assert hasattr(daemon, "notify_file_changed")
            assert callable(daemon.notify_file_changed)

    def test_notify_file_changed_invalidates_cache(self):
        """notify_file_changed should invalidate relevant cache entries."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            test_file = project / "test.py"
            test_file.write_text("def foo(): pass")

            daemon = TLDRDaemon(project)

            # Warm up cache
            daemon.handle_command({"cmd": "extract", "file": str(test_file)})

            # Get initial stats
            stats1 = daemon.salsa_db.get_stats()
            initial_invalidations = stats1.get("invalidations", 0)

            # Notify file change
            daemon.notify_file_changed(str(test_file))

            # Check invalidation happened
            stats2 = daemon.salsa_db.get_stats()
            assert stats2.get("invalidations", 0) >= initial_invalidations

    def test_file_hash_change_triggers_reindex(self):
        """File with changed hash should trigger re-extraction."""
        from tldr.daemon import TLDRDaemon
        from tldr.patch import compute_file_hash

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            test_file = project / "test.py"
            test_file.write_text("def foo(): pass")

            daemon = TLDRDaemon(project)
            daemon._ensure_dedup_index_loaded()

            # Get initial hash
            hash1 = compute_file_hash(str(test_file))
            daemon.dedup_index.get_or_create_edges(str(test_file), lang="python")

            # Modify file
            test_file.write_text("def foo(): bar()\ndef bar(): pass")
            hash2 = compute_file_hash(str(test_file))

            # Hashes should differ
            assert hash1 != hash2

            # Re-extract should detect change
            edges = daemon.dedup_index.get_or_create_edges(str(test_file), lang="python")

            # Should have more edges now
            assert len(edges) > 0


class TestDaemonStatusWithP5:
    """Tests for status command including P5 info."""

    def test_status_includes_cache_stats(self):
        """Status command should include cache statistics."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)
            daemon = TLDRDaemon(project)

            result = daemon.handle_command({"cmd": "status"})

            # Should include cache stats
            assert "cache_stats" in result or "salsa_stats" in result or "dedup_stats" in result

    def test_status_shows_dedup_savings(self):
        """Status should show deduplication savings."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)

            # Create duplicate files
            content = "def shared(): pass"
            (project / "a.py").write_text(content)
            (project / "b.py").write_text(content)

            daemon = TLDRDaemon(project)
            daemon._ensure_dedup_index_loaded()
            daemon.dedup_index.get_or_create_edges(str(project / "a.py"), lang="python")
            daemon.dedup_index.get_or_create_edges(str(project / "b.py"), lang="python")

            result = daemon.handle_command({"cmd": "status"})

            # Should show dedup info
            assert "dedup_savings" in str(result) or "dedup_stats" in result


class TestDaemonP5Integration:
    """Integration tests for all P5 features working together."""

    def test_full_p5_workflow(self):
        """Test complete P5 workflow: dedup + caching + invalidation."""
        from tldr.daemon import TLDRDaemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)

            # Create files - some duplicates
            (project / "utils.py").write_text("def helper(): return 42")
            (project / "utils_copy.py").write_text("def helper(): return 42")
            (project / "main.py").write_text("from utils import helper\ndef main(): helper()")

            daemon = TLDRDaemon(project)

            # Search - populates cache
            r1 = daemon.handle_command({"cmd": "search", "pattern": "helper"})
            assert r1["status"] == "ok"

            # Same search - should use cache
            r2 = daemon.handle_command({"cmd": "search", "pattern": "helper"})
            assert r2 == r1

            # Check dedup worked
            if hasattr(daemon, "dedup_index") and daemon.dedup_index:
                stats = daemon.dedup_index.stats()
                # utils.py and utils_copy.py should share hash
                if stats["total_files"] >= 2:
                    assert stats["unique_hashes"] < stats["total_files"]

            # Modify a file
            (project / "main.py").write_text("def main(): pass")
            daemon.notify_file_changed(str(project / "main.py"))

            # Search again - might have different results
            r3 = daemon.handle_command({"cmd": "search", "pattern": "helper"})
            assert r3["status"] == "ok"
