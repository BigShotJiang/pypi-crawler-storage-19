"""Tests for Rust call graph extraction."""
import pytest
from pathlib import Path
from tldr.hybrid_extractor import HybridExtractor

# Skip if tree-sitter-rust not available
pytest.importorskip("tree_sitter_rust")


@pytest.fixture
def extractor():
    return HybridExtractor()


@pytest.fixture
def rust_file_with_calls(tmp_path):
    """Rust file with function calls."""
    code = '''
fn process_data(data: &[u8]) -> Vec<u8> {
    transform(data)
}

fn transform(input: &[u8]) -> Vec<u8> {
    validate(input)
}

fn validate(input: &[u8]) -> Vec<u8> {
    input.to_vec()
}

fn main() {
    let data = b"test";
    let result = process_data(data);
}
'''
    path = tmp_path / "calls.rs"
    path.write_text(code)
    return path


@pytest.fixture
def rust_file_with_impl_calls(tmp_path):
    """Rust file with impl method calls."""
    code = '''
struct Service {
    name: String,
}

impl Service {
    fn start(&self) {
        self.prepare();
        self.run();
    }

    fn prepare(&self) {
    }

    fn run(&self) {
        self.log("running");
    }

    fn log(&self, msg: &str) {
    }
}
'''
    path = tmp_path / "impl_methods.rs"
    path.write_text(code)
    return path


@pytest.fixture
def rust_file_with_async(tmp_path):
    """Rust file with async function calls."""
    code = '''
async fn fetch_data() -> Vec<u8> {
    process().await
}

async fn process() -> Vec<u8> {
    validate().await
}

async fn validate() -> Vec<u8> {
    vec![]
}
'''
    path = tmp_path / "async_calls.rs"
    path.write_text(code)
    return path


class TestRustCallGraph:
    def test_extracts_function_calls(self, extractor, rust_file_with_calls):
        """Should extract function call relationships."""
        info = extractor.extract(rust_file_with_calls)

        # Check call graph exists
        assert info.call_graph.calls, "Call graph should have entries"

        # process_data calls transform
        assert "transform" in info.call_graph.calls.get("process_data", [])

        # transform calls validate
        assert "validate" in info.call_graph.calls.get("transform", [])

        # main calls process_data
        assert "process_data" in info.call_graph.calls.get("main", [])

    def test_extracts_called_by(self, extractor, rust_file_with_calls):
        """Should build reverse call graph (called_by)."""
        info = extractor.extract(rust_file_with_calls)

        # transform is called by process_data
        assert "process_data" in info.call_graph.called_by.get("transform", [])

        # validate is called by transform
        assert "transform" in info.call_graph.called_by.get("validate", [])

    def test_extracts_impl_method_calls(self, extractor, rust_file_with_impl_calls):
        """Should extract impl method call relationships."""
        info = extractor.extract(rust_file_with_impl_calls)

        # start() calls prepare() and run()
        # Caller might be "(Service) start" based on how Rust impl methods are named
        start_keys = [k for k in info.call_graph.calls.keys() if "start" in k.lower()]
        assert len(start_keys) > 0, "Should have start method in call graph"

        start_calls = info.call_graph.calls.get(start_keys[0], [])
        # Check that prepare and run are called (might have type prefix)
        assert any("prepare" in c for c in start_calls), f"start should call prepare, got {start_calls}"
        assert any("run" in c for c in start_calls), f"start should call run, got {start_calls}"

    def test_extracts_async_calls(self, extractor, rust_file_with_async):
        """Should extract async function call relationships."""
        info = extractor.extract(rust_file_with_async)

        # fetch_data calls process
        assert "process" in info.call_graph.calls.get("fetch_data", [])

        # process calls validate
        assert "validate" in info.call_graph.calls.get("process", [])

    def test_only_tracks_defined_functions(self, extractor, tmp_path):
        """Should not track calls to stdlib/external functions."""
        code = '''
fn greet(name: &str) {
    println!("Hello {}", name);
}
'''
        path = tmp_path / "external.rs"
        path.write_text(code)

        info = extractor.extract(path)

        # println should NOT be in call graph (it's a macro, and external)
        greet_calls = info.call_graph.calls.get("greet", [])
        assert "println" not in greet_calls

    def test_call_graph_in_compact_output(self, extractor, rust_file_with_calls):
        """Call graph should appear in compact output."""
        info = extractor.extract(rust_file_with_calls)
        compact = info.to_compact()

        assert "calls" in compact
        assert "process_data" in compact["calls"]
