"""Integration tests for all 16 supported languages across all 5 layers.

Tests:
- L1: Structure (AST extraction)
- L2: Call Graph (cross-file calls)
- L3: CFG (control flow graph)
- L4: DFG (data flow graph)
- L5: PDG (program dependence graph / slicing)
"""
import pytest
import tempfile
from pathlib import Path

# Language samples - each has a function with control flow and data flow
LANGUAGE_SAMPLES = {
    "python": {
        "ext": ".py",
        "code": '''
def calculate(x, y):
    result = x + y
    if result > 10:
        result = result * 2
    return result

def helper(n):
    return n + 1
''',
        "function": "calculate",
        "import_line": "import os",
    },
    "typescript": {
        "ext": ".ts",
        "code": '''
function calculate(x: number, y: number): number {
    let result = x + y;
    if (result > 10) {
        result = result * 2;
    }
    return result;
}

function helper(n: number): number {
    return n + 1;
}
''',
        "function": "calculate",
        "import_line": "import { something } from 'module';",
    },
    "javascript": {
        "ext": ".js",
        "code": '''
function calculate(x, y) {
    let result = x + y;
    if (result > 10) {
        result = result * 2;
    }
    return result;
}

function helper(n) {
    return n + 1;
}
''',
        "function": "calculate",
        "import_line": "import { readFile } from 'fs';",
    },
    "go": {
        "ext": ".go",
        "code": '''
package main

import "fmt"

func calculate(x int, y int) int {
    result := x + y
    if result > 10 {
        result = result * 2
    }
    return result
}

func helper(n int) int {
    return n + 1
}
''',
        "function": "calculate",
        "import_line": 'import "fmt"',
    },
    "rust": {
        "ext": ".rs",
        "code": '''
fn calculate(x: i32, y: i32) -> i32 {
    let mut result = x + y;
    if result > 10 {
        result = result * 2;
    }
    result
}

fn helper(n: i32) -> i32 {
    n + 1
}
''',
        "function": "calculate",
        "import_line": "use std::io;",
    },
    "java": {
        "ext": ".java",
        "code": '''
import java.util.List;

public class Calculator {
    public int calculate(int x, int y) {
        int result = x + y;
        if (result > 10) {
            result = result * 2;
        }
        return result;
    }

    public int helper(int n) {
        return n + 1;
    }
}
''',
        "function": "calculate",
        "import_line": "import java.util.List;",
    },
    "c": {
        "ext": ".c",
        "code": '''
#include <stdio.h>

int calculate(int x, int y) {
    int result = x + y;
    if (result > 10) {
        result = result * 2;
    }
    return result;
}

int helper(int n) {
    return n + 1;
}
''',
        "function": "calculate",
        "import_line": "#include <stdio.h>",
    },
    "cpp": {
        "ext": ".cpp",
        "code": '''
#include <iostream>

int calculate(int x, int y) {
    int result = x + y;
    if (result > 10) {
        result = result * 2;
    }
    return result;
}

int helper(int n) {
    return n + 1;
}
''',
        "function": "calculate",
        "import_line": "#include <iostream>",
    },
    "ruby": {
        "ext": ".rb",
        "code": '''
require 'json'

def calculate(x, y)
  result = x + y
  if result > 10
    result = result * 2
  end
  result
end

def helper(n)
  n + 1
end
''',
        "function": "calculate",
        "import_line": "require 'json'",
    },
    "php": {
        "ext": ".php",
        "code": '''<?php
use App\\Utils;

function calculate($x, $y) {
    $result = $x + $y;
    if ($result > 10) {
        $result = $result * 2;
    }
    return $result;
}

function helper($n) {
    return $n + 1;
}
''',
        "function": "calculate",
        "import_line": "use App\\Utils;",
    },
    "kotlin": {
        "ext": ".kt",
        "code": '''
import kotlin.math.abs

fun calculate(x: Int, y: Int): Int {
    var result = x + y
    if (result > 10) {
        result = result * 2
    }
    return result
}

fun helper(n: Int): Int {
    return n + 1
}
''',
        "function": "calculate",
        "import_line": "import kotlin.math.abs",
    },
    "swift": {
        "ext": ".swift",
        "code": '''
import Foundation

func calculate(x: Int, y: Int) -> Int {
    var result = x + y
    if result > 10 {
        result = result * 2
    }
    return result
}

func helper(n: Int) -> Int {
    return n + 1
}
''',
        "function": "calculate",
        "import_line": "import Foundation",
    },
    "csharp": {
        "ext": ".cs",
        "code": '''
using System;

public class Calculator {
    public int Calculate(int x, int y) {
        int result = x + y;
        if (result > 10) {
            result = result * 2;
        }
        return result;
    }

    public int Helper(int n) {
        return n + 1;
    }
}
''',
        "function": "Calculate",
        "import_line": "using System;",
    },
    "scala": {
        "ext": ".scala",
        "code": '''
import scala.math.abs

object Calculator {
  def calculate(x: Int, y: Int): Int = {
    var result = x + y
    if (result > 10) {
      result = result * 2
    }
    result
  }

  def helper(n: Int): Int = {
    n + 1
  }
}
''',
        "function": "calculate",
        "import_line": "import scala.math.abs",
    },
    "lua": {
        "ext": ".lua",
        "code": '''
local json = require("json")

local function calculate(x, y)
    local result = x + y
    if result > 10 then
        result = result * 2
    end
    return result
end

local function helper(n)
    return n + 1
end

return { calculate = calculate, helper = helper }
''',
        "function": "calculate",
        "import_line": 'require("json")',
    },
    "elixir": {
        "ext": ".ex",
        "code": '''
defmodule Calculator do
  alias Some.Module

  def calculate(x, y) do
    result = x + y
    if result > 10 do
      result * 2
    else
      result
    end
  end

  def helper(n) do
    n + 1
  end
end
''',
        "function": "calculate",
        "import_line": "alias Some.Module",
    },
}


class TestL1Structure:
    """L1: AST/Structure extraction tests."""

    @pytest.mark.parametrize("lang", LANGUAGE_SAMPLES.keys())
    def test_extract_functions(self, lang):
        """Test that we can extract function names from each language."""
        from tldr.api import extract_file

        sample = LANGUAGE_SAMPLES[lang]
        code = sample["code"]

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=sample["ext"], delete=False
        ) as f:
            f.write(code)
            f.flush()
            path = Path(f.name)

        try:
            result = extract_file(str(path))
            assert result is not None, f"{lang}: No result from extract_file"
            # Check we got functions
            functions = result.get("functions", [])
            assert len(functions) > 0, f"{lang}: No functions extracted"
        finally:
            path.unlink()


class TestL2Imports:
    """L2: Import/Call graph tests."""

    @pytest.mark.parametrize("lang", LANGUAGE_SAMPLES.keys())
    def test_parse_imports(self, lang):
        """Test that we can parse imports from each language."""
        from tldr.api import get_imports

        sample = LANGUAGE_SAMPLES[lang]
        # Add import line to code
        code = sample["import_line"] + "\n" + sample["code"]

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=sample["ext"], delete=False
        ) as f:
            f.write(code)
            f.flush()
            path = Path(f.name)

        try:
            imports = get_imports(str(path), language=lang)
            assert imports is not None, f"{lang}: get_imports returned None"
            assert len(imports) > 0, f"{lang}: No imports parsed"
        finally:
            path.unlink()


class TestL3CFG:
    """L3: Control Flow Graph tests."""

    @pytest.mark.parametrize("lang", LANGUAGE_SAMPLES.keys())
    def test_extract_cfg(self, lang):
        """Test that we can extract CFG from each language."""
        from tldr.api import get_cfg_context

        sample = LANGUAGE_SAMPLES[lang]
        code = sample["code"]
        func = sample["function"]

        cfg_context = get_cfg_context(code, func, language=lang)

        assert cfg_context is not None, f"{lang}: CFG context is None"
        # API returns dict with blocks and edges
        if isinstance(cfg_context, dict):
            assert "blocks" in cfg_context or "edges" in cfg_context, f"{lang}: CFG missing blocks/edges"
        else:
            assert len(cfg_context) > 0, f"{lang}: CFG context is empty"


class TestL4DFG:
    """L4: Data Flow Graph tests."""

    @pytest.mark.parametrize("lang", LANGUAGE_SAMPLES.keys())
    def test_extract_dfg(self, lang):
        """Test that we can extract DFG from each language."""
        from tldr.api import get_dfg_context

        sample = LANGUAGE_SAMPLES[lang]
        code = sample["code"]
        func = sample["function"]

        dfg_context = get_dfg_context(code, func, language=lang)

        assert dfg_context is not None, f"{lang}: DFG context is None"
        # API returns dict with refs and edges
        if isinstance(dfg_context, dict):
            assert "refs" in dfg_context or "edges" in dfg_context, f"{lang}: DFG missing refs/edges"
        else:
            assert len(dfg_context) > 0, f"{lang}: DFG context is empty"


class TestL5PDG:
    """L5: Program Dependence Graph / Slicing tests."""

    @pytest.mark.parametrize("lang", LANGUAGE_SAMPLES.keys())
    def test_extract_pdg(self, lang):
        """Test that we can extract PDG from each language."""
        from tldr.api import get_pdg_context

        sample = LANGUAGE_SAMPLES[lang]
        code = sample["code"]
        func = sample["function"]

        pdg_context = get_pdg_context(code, func, language=lang)

        assert pdg_context is not None, f"{lang}: PDG context is None"
        # API returns dict with nodes and edges
        if isinstance(pdg_context, dict):
            assert "nodes" in pdg_context or "edges" in pdg_context or len(pdg_context) > 0, f"{lang}: PDG is empty"
        else:
            assert len(pdg_context) > 0, f"{lang}: PDG context is empty"

    @pytest.mark.parametrize("lang", LANGUAGE_SAMPLES.keys())
    def test_program_slice(self, lang):
        """Test that we can compute program slices for each language."""
        from tldr.api import get_slice

        sample = LANGUAGE_SAMPLES[lang]
        code = sample["code"]
        func = sample["function"]

        # Slice at line 4 (should be inside the function for most languages)
        slice_lines = get_slice(code, func, line=4, language=lang)

        # Slice can return set or dict
        assert slice_lines is not None, f"{lang}: Slice is None"
        if isinstance(slice_lines, set):
            pass  # Expected
        elif isinstance(slice_lines, dict):
            pass  # Also ok
        else:
            assert False, f"{lang}: Slice should be set or dict, got {type(slice_lines)}"


class TestAllLayersSummary:
    """Summary test that verifies all layers work for all languages."""

    def test_all_languages_all_layers(self):
        """Comprehensive test: all 16 languages x 5 layers = 80 checks."""
        from tldr.api import (
            extract_file,
            get_imports,
            get_cfg_context,
            get_dfg_context,
            get_pdg_context,
        )

        results = {}

        for lang, sample in LANGUAGE_SAMPLES.items():
            results[lang] = {"L1": False, "L2": False, "L3": False, "L4": False, "L5": False}
            code = sample["import_line"] + "\n" + sample["code"]
            func = sample["function"]

            # Create temp file
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=sample["ext"], delete=False
            ) as f:
                f.write(code)
                f.flush()
                path = Path(f.name)

            try:
                # L1: Structure
                try:
                    result = extract_file(str(path))
                    if result and len(result.get("functions", [])) > 0:
                        results[lang]["L1"] = True
                except Exception as e:
                    print(f"{lang} L1 failed: {e}")

                # L2: Imports
                try:
                    imports = get_imports(str(path), language=lang)
                    if imports is not None and len(imports) > 0:
                        results[lang]["L2"] = True
                except Exception as e:
                    print(f"{lang} L2 failed: {e}")

                # L3: CFG
                try:
                    cfg = get_cfg_context(code, func, language=lang)
                    if cfg is not None:
                        if isinstance(cfg, dict) and ("blocks" in cfg or "edges" in cfg):
                            results[lang]["L3"] = True
                        elif cfg:
                            results[lang]["L3"] = True
                except Exception as e:
                    print(f"{lang} L3 failed: {e}")

                # L4: DFG
                try:
                    dfg = get_dfg_context(code, func, language=lang)
                    if dfg is not None:
                        if isinstance(dfg, dict) and ("refs" in dfg or "edges" in dfg):
                            results[lang]["L4"] = True
                        elif dfg:
                            results[lang]["L4"] = True
                except Exception as e:
                    print(f"{lang} L4 failed: {e}")

                # L5: PDG
                try:
                    pdg = get_pdg_context(code, func, language=lang)
                    if pdg is not None:
                        if isinstance(pdg, dict):
                            results[lang]["L5"] = True
                        elif pdg:
                            results[lang]["L5"] = True
                except Exception as e:
                    print(f"{lang} L5 failed: {e}")

            finally:
                path.unlink()

        # Print results matrix
        print("\n" + "=" * 60)
        print("LANGUAGE SUPPORT MATRIX")
        print("=" * 60)
        print(f"{'Language':<12} {'L1':>4} {'L2':>4} {'L3':>4} {'L4':>4} {'L5':>4}")
        print("-" * 60)

        all_pass = True
        for lang, layers in results.items():
            l1 = "✓" if layers["L1"] else "✗"
            l2 = "✓" if layers["L2"] else "✗"
            l3 = "✓" if layers["L3"] else "✗"
            l4 = "✓" if layers["L4"] else "✗"
            l5 = "✓" if layers["L5"] else "✗"
            print(f"{lang:<12} {l1:>4} {l2:>4} {l3:>4} {l4:>4} {l5:>4}")
            if not all(layers.values()):
                all_pass = False

        print("=" * 60)
        total = sum(sum(l.values()) for l in results.values())
        print(f"Total: {total}/80 checks passed")
        print("=" * 60)

        assert all_pass, "Not all language/layer combinations passed"
