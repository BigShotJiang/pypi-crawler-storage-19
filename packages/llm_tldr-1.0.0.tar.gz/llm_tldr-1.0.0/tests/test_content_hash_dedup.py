"""Tests for Content-Hash Deduplication (P5 #21).

Files with identical content should share the same index entry.
Storage changes from {file_path: index} to {content_hash: index}
with a lookup table {file_path: content_hash}.

This enables:
- Duplicate files indexed once (copy-pasted utils)
- Generated files (protobuf, graphql) share index
- 10-20% storage savings typical
"""

import tempfile
import pytest
from pathlib import Path

from tldr.patch import compute_file_hash


class TestContentHashIndex:
    """Tests for content-hash based index storage."""

    def test_identical_files_same_hash(self, tmp_path):
        """Two files with same content should produce same hash."""
        content = "def helper(): return 42"

        file1 = tmp_path / "utils.py"
        file2 = tmp_path / "helpers.py"
        file1.write_text(content)
        file2.write_text(content)

        hash1 = compute_file_hash(str(file1))
        hash2 = compute_file_hash(str(file2))

        assert hash1 == hash2, "Identical content should produce identical hashes"

    def test_different_files_different_hash(self, tmp_path):
        """Two files with different content should have different hashes."""
        file1 = tmp_path / "a.py"
        file2 = tmp_path / "b.py"
        file1.write_text("def a(): pass")
        file2.write_text("def b(): pass")

        hash1 = compute_file_hash(str(file1))
        hash2 = compute_file_hash(str(file2))

        assert hash1 != hash2


class TestContentHashedCallGraphIndex:
    """Tests for content-hash based call graph index."""

    def test_get_or_create_index_new_content(self, tmp_path):
        """get_or_create_index should create new entry for new content."""
        from tldr.dedup import ContentHashedIndex

        file1 = tmp_path / "a.py"
        file1.write_text("def foo(): bar()\ndef bar(): pass")

        index = ContentHashedIndex(str(tmp_path))
        edges = index.get_or_create_edges(str(file1), lang="python")

        assert len(edges) > 0
        assert index.stats()["unique_hashes"] == 1
        assert index.stats()["total_files"] == 1

    def test_get_or_create_index_duplicate_content(self, tmp_path):
        """get_or_create_index should reuse entry for duplicate content."""
        from tldr.dedup import ContentHashedIndex

        content = "def foo(): bar()\ndef bar(): pass"
        file1 = tmp_path / "utils.py"
        file2 = tmp_path / "helpers.py"
        file1.write_text(content)
        file2.write_text(content)

        index = ContentHashedIndex(str(tmp_path))
        edges1 = index.get_or_create_edges(str(file1), lang="python")
        edges2 = index.get_or_create_edges(str(file2), lang="python")

        # Both should return same edges
        assert edges1 == edges2
        # But stats should show deduplication
        assert index.stats()["unique_hashes"] == 1
        assert index.stats()["total_files"] == 2
        assert index.stats()["dedup_savings"] == 1  # 1 extraction skipped

    def test_get_or_create_index_different_content(self, tmp_path):
        """get_or_create_index should create separate entries for different content."""
        from tldr.dedup import ContentHashedIndex

        file1 = tmp_path / "a.py"
        file2 = tmp_path / "b.py"
        file1.write_text("def foo(): pass")
        file2.write_text("def bar(): pass")

        index = ContentHashedIndex(str(tmp_path))
        edges1 = index.get_or_create_edges(str(file1), lang="python")
        edges2 = index.get_or_create_edges(str(file2), lang="python")

        assert index.stats()["unique_hashes"] == 2
        assert index.stats()["total_files"] == 2
        assert index.stats()["dedup_savings"] == 0

    def test_content_hash_lookup_table(self, tmp_path):
        """Should maintain lookup table from file_path -> content_hash."""
        from tldr.dedup import ContentHashedIndex

        content = "def foo(): pass"
        file1 = tmp_path / "utils.py"
        file1.write_text(content)
        expected_hash = compute_file_hash(str(file1))

        index = ContentHashedIndex(str(tmp_path))
        index.get_or_create_edges(str(file1), lang="python")

        # Lookup table should map path -> hash
        assert index.get_file_hash(str(file1)) == expected_hash

    def test_invalidation_on_content_change(self, tmp_path):
        """When file content changes, hash changes and new extraction happens."""
        from tldr.dedup import ContentHashedIndex

        file1 = tmp_path / "utils.py"
        file1.write_text("def foo(): pass")

        index = ContentHashedIndex(str(tmp_path))

        # Initial extraction
        hash1 = index.get_file_hash(str(file1))
        edges1 = index.get_or_create_edges(str(file1), lang="python")

        # Modify file
        file1.write_text("def foo(): bar()\ndef bar(): pass")

        # Re-extract - should detect change
        edges2 = index.get_or_create_edges(str(file1), lang="python")
        hash2 = index.get_file_hash(str(file1))

        assert hash1 != hash2
        assert len(edges2) > len(edges1)  # More edges after adding bar()


class TestContentHashPersistence:
    """Tests for persisting content-hash index to disk."""

    def test_save_and_load_index(self, tmp_path):
        """Index should persist and reload correctly."""
        from tldr.dedup import ContentHashedIndex

        content = "def foo(): bar()\ndef bar(): pass"
        file1 = tmp_path / "utils.py"
        file1.write_text(content)

        # Create and populate
        index1 = ContentHashedIndex(str(tmp_path))
        index1.get_or_create_edges(str(file1), lang="python")
        index1.save()

        # Reload
        index2 = ContentHashedIndex(str(tmp_path))
        index2.load()

        # Should have same state
        assert index2.stats()["unique_hashes"] == 1
        assert index2.get_file_hash(str(file1)) == compute_file_hash(str(file1))

    def test_storage_format(self, tmp_path):
        """Storage should use {content_hash: edges} format."""
        from tldr.dedup import ContentHashedIndex
        import json

        file1 = tmp_path / "utils.py"
        file1.write_text("def foo(): pass")
        content_hash = compute_file_hash(str(file1))

        index = ContentHashedIndex(str(tmp_path))
        index.get_or_create_edges(str(file1), lang="python")
        index.save()

        # Check storage format
        cache_dir = tmp_path / ".tldr" / "cache"

        # Should have hash-based index
        hash_index_file = cache_dir / "content_index.json"
        assert hash_index_file.exists()

        data = json.loads(hash_index_file.read_text())
        assert content_hash in data["by_hash"]

        # Should have path->hash lookup
        assert str(file1) in data["path_to_hash"] or "utils.py" in str(data["path_to_hash"])


class TestDedupWithCallGraph:
    """Tests for dedup integration with call graph building."""

    def test_build_call_graph_with_dedup(self, tmp_path):
        """Building call graph should use dedup for identical files."""
        from tldr.dedup import ContentHashedIndex
        from tldr.cross_file_calls import build_project_call_graph

        # Create project with duplicate files
        content = """
def shared_util():
    return 42
"""
        (tmp_path / "pkg1").mkdir()
        (tmp_path / "pkg2").mkdir()
        (tmp_path / "pkg1" / "utils.py").write_text(content)
        (tmp_path / "pkg2" / "utils.py").write_text(content)  # Duplicate!

        index = ContentHashedIndex(str(tmp_path))

        # Build graph using dedup index
        for py_file in tmp_path.rglob("*.py"):
            index.get_or_create_edges(str(py_file), lang="python")

        # Should only extract once
        stats = index.stats()
        assert stats["unique_hashes"] == 1
        assert stats["total_files"] == 2
        assert stats["dedup_savings"] == 1


class TestDedupEdgeCases:
    """Edge cases for content-hash deduplication."""

    def test_empty_file(self, tmp_path):
        """Empty files should be handled correctly."""
        from tldr.dedup import ContentHashedIndex

        file1 = tmp_path / "empty.py"
        file1.write_text("")

        index = ContentHashedIndex(str(tmp_path))
        edges = index.get_or_create_edges(str(file1), lang="python")

        assert edges == []
        assert index.stats()["unique_hashes"] == 1

    def test_syntax_error_file(self, tmp_path):
        """Files with syntax errors should be handled gracefully."""
        from tldr.dedup import ContentHashedIndex

        file1 = tmp_path / "broken.py"
        file1.write_text("def foo( broken syntax")

        index = ContentHashedIndex(str(tmp_path))
        edges = index.get_or_create_edges(str(file1), lang="python")

        # Should return empty edges but still track the file
        assert edges == []
        assert index.stats()["total_files"] == 1

    def test_binary_like_content(self, tmp_path):
        """Files with binary-like content should be handled."""
        from tldr.dedup import ContentHashedIndex

        file1 = tmp_path / "weird.py"
        file1.write_bytes(b"\x00\x01\x02def foo(): pass")

        index = ContentHashedIndex(str(tmp_path))

        # Should compute hash without crashing
        content_hash = compute_file_hash(str(file1))
        assert len(content_hash) == 40
