"""Tests for Swift import parsing.

TDD Tests for Swift language support in TLDR.
These tests are expected to FAIL initially until Swift support is implemented.

Swift import syntax:
- import Foundation
- import UIKit
- import struct Foundation.Date
- import class UIKit.UIView
- import func Darwin.sqrt
- @testable import MyModule
"""
import pytest
import tempfile
from pathlib import Path

# Check if tree-sitter-swift is available
try:
    from tldr.cross_file_calls import parse_swift_imports, TREE_SITTER_SWIFT_AVAILABLE
    SWIFT_AVAILABLE = TREE_SITTER_SWIFT_AVAILABLE
except ImportError:
    SWIFT_AVAILABLE = False


pytestmark = pytest.mark.skipif(not SWIFT_AVAILABLE, reason="tree-sitter-swift not available")


@pytest.fixture
def simple_imports_file(tmp_path):
    """Create a Swift file with simple imports."""
    code = '''
import Foundation
import UIKit

class Example {
    func process() {
        let date = Date()
        print(date)
    }
}
'''
    file_path = tmp_path / "Example.swift"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def selective_imports_file(tmp_path):
    """Create a Swift file with selective imports."""
    code = '''
import struct Foundation.Date
import class UIKit.UIView
import func Darwin.sqrt

class Example {
    func calculate() -> Double {
        return sqrt(4.0)
    }
}
'''
    file_path = tmp_path / "Example.swift"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def testable_import_file(tmp_path):
    """Create a Swift file with @testable import."""
    code = '''
import XCTest
@testable import MyApp

class ExampleTests: XCTestCase {
    func testSomething() {
        XCTAssertTrue(true)
    }
}
'''
    file_path = tmp_path / "ExampleTests.swift"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create a Swift file with mixed imports."""
    code = '''
import Foundation
import UIKit
import struct CoreGraphics.CGRect
@testable import MyModule
import Darwin

class Example {
    func process() {}
}
'''
    file_path = tmp_path / "Example.swift"
    file_path.write_text(code)
    return file_path


class TestSimpleImports:
    """Test basic import parsing."""

    def test_parses_simple_imports(self, simple_imports_file):
        imports = parse_swift_imports(simple_imports_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        assert 'Foundation' in modules
        assert 'UIKit' in modules

    def test_selective_imports(self, selective_imports_file):
        imports = parse_swift_imports(selective_imports_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        # Should capture the full import path or at least the module
        assert any('Foundation' in m or 'Date' in m for m in modules)
        assert any('UIKit' in m or 'UIView' in m for m in modules)
        assert any('Darwin' in m or 'sqrt' in m for m in modules)

    def test_testable_import(self, testable_import_file):
        imports = parse_swift_imports(testable_import_file)
        assert len(imports) >= 2
        modules = [imp['module'] for imp in imports]
        # Should include both XCTest and MyApp
        assert any('XCTest' in m for m in modules)
        assert any('MyApp' in m for m in modules)


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_swift_imports(mixed_imports_file)
        # Should have all imports
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('Foundation' in m for m in modules)
        assert any('UIKit' in m for m in modules)


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "Empty.swift"
        file_path.write_text("class Empty {}")
        imports = parse_swift_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "NonExistent.swift"
        imports = parse_swift_imports(file_path)
        assert imports == []

    def test_only_class_no_imports(self, tmp_path):
        code = '''
class NoImports {
    func test() {}
}
'''
        file_path = tmp_path / "NoImports.swift"
        file_path.write_text(code)
        imports = parse_swift_imports(file_path)
        assert imports == []
