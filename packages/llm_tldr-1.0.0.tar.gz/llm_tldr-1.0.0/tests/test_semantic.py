"""Tests for semantic search with 5-layer embeddings (P6).

Tests the semantic search module which embeds functions/methods using
all 5 TLDR layers:
- L1: Signature + docstring
- L2: Top callers + callees (from call graph)
- L3: Control flow summary
- L4: Data flow summary
- L5: Dependencies

Uses sentence-transformers with BAAI/bge-large-en-v1.5 for embeddings
and FAISS for vector search.
"""

import json
import tempfile
from pathlib import Path

import pytest


# ============================================================================
# Test Fixtures
# ============================================================================

@pytest.fixture
def simple_project():
    """Create a simple Python project for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Create main.py
        Path(tmpdir, "main.py").write_text('''
"""Main module for processing data."""

from utils import helper, validate

def process_data(data: list[str]) -> dict:
    """Process input data and return results.

    Args:
        data: List of strings to process.

    Returns:
        Dictionary with processed results.
    """
    if not validate(data):
        raise ValueError("Invalid data")
    result = {}
    for item in data:
        key = helper(item)
        result[key] = item.upper()
    return result

def main():
    """Entry point."""
    data = ["hello", "world"]
    return process_data(data)
''')

        # Create utils.py
        Path(tmpdir, "utils.py").write_text('''
"""Utility functions."""

def helper(value: str) -> str:
    """Transform a value into a key.

    Args:
        value: Input string.

    Returns:
        Processed key string.
    """
    return value.lower().strip()

def validate(data: list) -> bool:
    """Validate input data.

    Args:
        data: Data to validate.

    Returns:
        True if valid, False otherwise.
    """
    return data is not None and len(data) > 0
''')

        yield tmpdir


@pytest.fixture
def multi_lang_project():
    """Create a project with multiple languages."""
    with tempfile.TemporaryDirectory() as tmpdir:
        # Python file
        Path(tmpdir, "processor.py").write_text('''
def process(data):
    """Process data."""
    return data
''')

        # TypeScript file
        Path(tmpdir, "handler.ts").write_text('''
export function handleRequest(req: Request): Response {
    // Handle incoming request
    return new Response();
}
''')

        # Go file
        Path(tmpdir, "service.go").write_text('''
package main

func ServeHTTP(w http.ResponseWriter, r *http.Request) {
    // Handle HTTP request
}
''')

        # Rust file
        Path(tmpdir, "lib.rs").write_text('''
pub fn calculate(x: i32, y: i32) -> i32 {
    x + y
}
''')

        yield tmpdir


# ============================================================================
# L1: Signature + Docstring Tests
# ============================================================================

def test_build_embedding_text_includes_signature(simple_project):
    """Embedding text should include the function signature (L1)."""
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="process_data",
        qualified_name="main.process_data",
        file="main.py",
        line=6,
        language="python",
        unit_type="function",
        signature="def process_data(data: list[str]) -> dict",
        docstring="Process input data and return results.",
        calls=["validate", "helper"],
        called_by=["main"],
        cfg_summary="2 branches, 1 loop",
        dfg_summary="data -> validate -> result",
        dependencies="depends on: utils.helper, utils.validate",
    )

    text = build_embedding_text(unit)

    assert "def process_data" in text
    assert "list[str]" in text
    assert "dict" in text


def test_build_embedding_text_includes_docstring(simple_project):
    """Embedding text should include the docstring (L1)."""
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="process_data",
        qualified_name="main.process_data",
        file="main.py",
        line=6,
        language="python",
        unit_type="function",
        signature="def process_data(data: list[str]) -> dict",
        docstring="Process input data and return results.",
        calls=[],
        called_by=[],
        cfg_summary="",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)

    assert "Process input data" in text


# ============================================================================
# L2: Call Graph Tests
# ============================================================================

def test_build_embedding_text_includes_calls(simple_project):
    """Embedding text should include callees (L2 forward)."""
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="process_data",
        qualified_name="main.process_data",
        file="main.py",
        line=6,
        language="python",
        unit_type="function",
        signature="def process_data(data: list[str]) -> dict",
        docstring="",
        calls=["validate", "helper"],
        called_by=[],
        cfg_summary="",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)

    assert "validate" in text
    assert "helper" in text


def test_build_embedding_text_includes_called_by(simple_project):
    """Embedding text should include callers (L2 backward)."""
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="process_data",
        qualified_name="main.process_data",
        file="main.py",
        line=6,
        language="python",
        unit_type="function",
        signature="def process_data(data: list[str]) -> dict",
        docstring="",
        calls=[],
        called_by=["main", "test_process"],
        cfg_summary="",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)

    assert "main" in text
    assert "test_process" in text


# ============================================================================
# L3: Control Flow Summary Tests
# ============================================================================

def test_build_embedding_text_includes_cfg_summary(simple_project):
    """Embedding text should include CFG summary (L3)."""
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="process_data",
        qualified_name="main.process_data",
        file="main.py",
        line=6,
        language="python",
        unit_type="function",
        signature="def process_data(data: list[str]) -> dict",
        docstring="",
        calls=[],
        called_by=[],
        cfg_summary="3 branches, 1 loop, handles: ValueError",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)

    assert "branch" in text.lower() or "3 branches" in text
    assert "loop" in text.lower()


# ============================================================================
# L4: Data Flow Summary Tests
# ============================================================================

def test_build_embedding_text_includes_dfg_summary(simple_project):
    """Embedding text should include DFG summary (L4)."""
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="process_data",
        qualified_name="main.process_data",
        file="main.py",
        line=6,
        language="python",
        unit_type="function",
        signature="def process_data(data: list[str]) -> dict",
        docstring="",
        calls=[],
        called_by=[],
        cfg_summary="",
        dfg_summary="token -> decode -> payload -> verify",
        dependencies="",
    )

    text = build_embedding_text(unit)

    assert "token" in text or "decode" in text or "payload" in text


# ============================================================================
# Embedding Computation Tests
# ============================================================================

def test_compute_embedding_returns_vector():
    """compute_embedding should return a numpy array."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("numpy")
    import numpy as np
    from tldr.semantic import compute_embedding

    text = "def process_data(data: list) -> dict: Process input data."
    embedding = compute_embedding(text)

    assert isinstance(embedding, np.ndarray)
    assert embedding.ndim == 1  # Should be 1D vector


def test_compute_embedding_correct_dimension():
    """BGE-large embedding should return 1024-dimensional vector."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("numpy")
    from tldr.semantic import compute_embedding

    text = "def process_data(data: list) -> dict"
    embedding = compute_embedding(text)

    # BGE-large returns 1024 dimensions
    assert embedding.shape[0] == 1024


def test_compute_embedding_normalized():
    """Embedding should be normalized for cosine similarity."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("numpy")
    import numpy as np
    from tldr.semantic import compute_embedding

    text = "def helper(value: str) -> str"
    embedding = compute_embedding(text)

    # Check L2 norm is approximately 1
    norm = np.linalg.norm(embedding)
    assert abs(norm - 1.0) < 0.01


# ============================================================================
# Semantic Index Building Tests
# ============================================================================

def test_build_semantic_index_creates_faiss_file(simple_project):
    """build_semantic_index should create a FAISS index file."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index

    count = build_semantic_index(simple_project, lang="python")

    index_file = Path(simple_project) / ".tldr" / "cache" / "semantic" / "index.faiss"
    assert index_file.exists()
    assert count > 0


def test_build_semantic_index_creates_metadata_file(simple_project):
    """build_semantic_index should create a metadata JSON file."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index

    build_semantic_index(simple_project, lang="python")

    metadata_file = Path(simple_project) / ".tldr" / "cache" / "semantic" / "metadata.json"
    assert metadata_file.exists()

    # Metadata should be valid JSON with expected structure
    metadata = json.loads(metadata_file.read_text())
    assert "units" in metadata
    assert isinstance(metadata["units"], list)


def test_build_semantic_index_metadata_contains_units(simple_project):
    """Metadata should contain information about each indexed unit."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index

    build_semantic_index(simple_project, lang="python")

    metadata_file = Path(simple_project) / ".tldr" / "cache" / "semantic" / "metadata.json"
    metadata = json.loads(metadata_file.read_text())

    # Should have indexed functions from both files
    names = [u["name"] for u in metadata["units"]]
    assert "process_data" in names or "main.process_data" in names
    assert "helper" in names or "utils.helper" in names


# ============================================================================
# Semantic Search Tests
# ============================================================================

def test_semantic_search_returns_results(simple_project):
    """semantic_search should return a list of results."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index, semantic_search

    # Build index first
    build_semantic_index(simple_project, lang="python")

    # Search for something
    results = semantic_search(simple_project, "process data and return results", k=3)

    assert isinstance(results, list)
    assert len(results) > 0


def test_semantic_search_result_structure(simple_project):
    """Search results should have expected structure."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index, semantic_search

    build_semantic_index(simple_project, lang="python")
    results = semantic_search(simple_project, "process data", k=1)

    assert len(results) >= 1
    result = results[0]

    # Each result should have these fields
    assert "name" in result
    assert "file" in result
    assert "line" in result
    assert "score" in result


def test_semantic_search_includes_graph_expansion(simple_project):
    """With expand_graph=True, results should include callers/callees."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index, semantic_search

    build_semantic_index(simple_project, lang="python")
    results = semantic_search(
        simple_project,
        "process data",
        k=1,
        expand_graph=True
    )

    assert len(results) >= 1
    result = results[0]

    # Expanded results should have related functions
    assert "related" in result or "calls" in result or "called_by" in result


def test_semantic_search_ranks_relevant_higher(simple_project):
    """Search should rank semantically relevant functions higher."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index, semantic_search

    build_semantic_index(simple_project, lang="python")

    # Search for data processing
    results = semantic_search(simple_project, "process data", k=5)

    # process_data should be ranked high (in top 2)
    top_names = [r["name"] for r in results[:2]]
    assert any("process" in name.lower() for name in top_names)


def test_semantic_search_empty_query_handled(simple_project):
    """Empty query should return empty results or raise ValueError."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import build_semantic_index, semantic_search

    build_semantic_index(simple_project, lang="python")

    # Empty query should be handled gracefully
    results = semantic_search(simple_project, "", k=5)
    assert isinstance(results, list)
    # Empty query typically returns empty results
    assert len(results) == 0


def test_semantic_search_no_index_error(simple_project):
    """Search without building index first should raise appropriate error."""
    pytest.importorskip("sentence_transformers")
    pytest.importorskip("faiss")
    from tldr.semantic import semantic_search

    # Remove any existing index
    index_dir = Path(simple_project) / ".tldr" / "cache" / "semantic"
    if index_dir.exists():
        import shutil
        shutil.rmtree(index_dir)

    with pytest.raises((FileNotFoundError, ValueError)):
        semantic_search(simple_project, "test query")


# ============================================================================
# Cross-Language Normalization Tests
# ============================================================================

def test_cross_language_normalization_python():
    """Python function embeddings should work."""
    pytest.importorskip("sentence_transformers")
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="process",
        qualified_name="processor.process",
        file="processor.py",
        line=1,
        language="python",
        unit_type="function",
        signature="def process(data) -> None",
        docstring="Process data.",
        calls=[],
        called_by=[],
        cfg_summary="",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)
    assert "process" in text
    assert len(text) > 10


def test_cross_language_normalization_typescript():
    """TypeScript function embeddings should work."""
    pytest.importorskip("sentence_transformers")
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="handleRequest",
        qualified_name="handler.handleRequest",
        file="handler.ts",
        line=1,
        language="typescript",
        unit_type="function",
        signature="function handleRequest(req: Request): Response",
        docstring="Handle incoming request.",
        calls=[],
        called_by=[],
        cfg_summary="",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)
    assert "handleRequest" in text
    assert len(text) > 10


def test_cross_language_normalization_go():
    """Go function embeddings should work."""
    pytest.importorskip("sentence_transformers")
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="ServeHTTP",
        qualified_name="main.ServeHTTP",
        file="service.go",
        line=1,
        language="go",
        unit_type="function",
        signature="func ServeHTTP(w http.ResponseWriter, r *http.Request)",
        docstring="Handle HTTP request.",
        calls=[],
        called_by=[],
        cfg_summary="",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)
    assert "ServeHTTP" in text
    assert len(text) > 10


def test_cross_language_normalization_rust():
    """Rust function embeddings should work."""
    pytest.importorskip("sentence_transformers")
    from tldr.semantic import EmbeddingUnit, build_embedding_text

    unit = EmbeddingUnit(
        name="calculate",
        qualified_name="lib.calculate",
        file="lib.rs",
        line=1,
        language="rust",
        unit_type="function",
        signature="pub fn calculate(x: i32, y: i32) -> i32",
        docstring="Calculate sum.",
        calls=[],
        called_by=[],
        cfg_summary="",
        dfg_summary="",
        dependencies="",
    )

    text = build_embedding_text(unit)
    assert "calculate" in text
    assert len(text) > 10


# ============================================================================
# Unit Extraction Tests
# ============================================================================

def test_extract_units_from_project(simple_project):
    """extract_units_from_project should find all functions/methods."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(simple_project, lang="python")

    # Should find at least the functions we defined
    assert len(units) >= 4  # process_data, main, helper, validate

    names = [u.name for u in units]
    assert "process_data" in names
    assert "main" in names
    assert "helper" in names
    assert "validate" in names


def test_extract_units_has_signatures(simple_project):
    """Extracted units should have signatures."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(simple_project, lang="python")

    for unit in units:
        assert unit.signature, f"Unit {unit.name} missing signature"


def test_extract_units_has_calls(simple_project):
    """Extracted units should have call graph info when available."""
    from tldr.semantic import extract_units_from_project

    units = extract_units_from_project(simple_project, lang="python")

    # Find process_data
    process_unit = next((u for u in units if u.name == "process_data"), None)
    assert process_unit is not None

    # process_data calls validate and helper
    assert "validate" in process_unit.calls or "helper" in process_unit.calls


# ============================================================================
# Model Loading Tests
# ============================================================================

def test_get_model_returns_sentence_transformer():
    """get_model should return a SentenceTransformer instance."""
    pytest.importorskip("sentence_transformers")
    from sentence_transformers import SentenceTransformer
    from tldr.semantic import get_model

    model = get_model()
    assert isinstance(model, SentenceTransformer)


def test_get_model_caches_instance():
    """get_model should return the same instance on multiple calls."""
    pytest.importorskip("sentence_transformers")
    from tldr.semantic import get_model

    model1 = get_model()
    model2 = get_model()

    # Should be the same object (cached)
    assert model1 is model2
