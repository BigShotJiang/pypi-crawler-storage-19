"""Adversarial recursion depth tests for TLDR extractors.

These tests target stack overflow vulnerabilities in AST traversal code.
TLDR uses recursive tree traversal in:
- hybrid_extractor.py: _extract_ts_nodes, _extract_go_nodes, etc.
- cfg_extractor.py: PythonCFGBuilder.visit_*, TreeSitterCFGBuilder._visit_node
- dfg_extractor.py: PythonDefUseVisitor.visit_*, generic_visit

Attack vectors tested:
1. Deep AST nesting (if/for/while statements nested 500+ levels)
2. Deep class inheritance chains
3. Nested function definitions
4. Deep expression trees (binary ops nested 500+ deep)
5. CFG with deep nesting
6. DFG traversal overflow

Default Python recursion limit is 1000. Tests use depths of 50, 500, and 1000
to verify protection at various levels.

Note: Python has a 100-level indentation limit, so we test tree-sitter languages
at higher depths. Python tests use expression/class nesting that doesn't hit
the indentation limit.

Usage:
    pytest tests/test_adversarial_recursion.py -v
    pytest tests/test_adversarial_recursion.py -v --runxfail  # Run expected failures
"""

import sys
import pytest
import tempfile
from pathlib import Path
from typing import Callable

# =============================================================================
# TEST INFRASTRUCTURE
# =============================================================================

# Depth thresholds for testing
# Note: Python has 100-level indentation limit, so Python-indented code maxes at ~90
SAFE_DEPTH = 50         # Should always work for Python indentation
RISKY_DEPTH = 500       # Approaches half of default recursion limit (for non-Python)
OVERFLOW_DEPTH = 1000   # At default recursion limit
EXTREME_DEPTH = 2000    # Well beyond default limit

# Python-specific depths (must respect 100-level indentation limit)
PYTHON_SAFE_DEPTH = 50
PYTHON_MAX_INDENT_DEPTH = 90  # Just under Python's 100-level limit

# Get current recursion limit for reference
DEFAULT_RECURSION_LIMIT = sys.getrecursionlimit()


def xfail_recursion(depth: int, reason: str = None):
    """Mark test as expected failure due to potential stack overflow."""
    if reason is None:
        reason = f"No recursion limit protection - depth {depth} may overflow (limit={DEFAULT_RECURSION_LIMIT})"
    # Also accept SyntaxError for Python's "too many nested parentheses" limit
    # and ValueError for when function lookup fails due to parsing issues
    return pytest.mark.xfail(reason=reason, strict=False, raises=(RecursionError, SystemError, SyntaxError, ValueError))


def xfail_syntax_limit(reason: str = "Python syntax limit"):
    """Mark test as expected failure due to Python syntax limits."""
    return pytest.mark.xfail(reason=reason, strict=False, raises=(SyntaxError,))


def xfail_file_size(reason: str = "File exceeds size limit"):
    """Mark test as expected failure due to file size limits."""
    return pytest.mark.xfail(reason=reason, strict=False)


def write_temp_file(content: str, suffix: str) -> Path:
    """Write content to a temporary file and return the path."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False) as f:
        f.write(content)
        return Path(f.name)


# =============================================================================
# CODE GENERATORS - Create deeply nested code structures
# =============================================================================

def generate_nested_if_python(depth: int) -> str:
    """Generate Python code with deeply nested if statements.

    Note: Python has a 100-level indentation limit, so depth should be < 90.
    """
    lines = ["def deeply_nested_if(x):"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}if x{i}:")
    # Add final pass at deepest level
    lines.append("    " * (depth + 1) + "pass")
    return "\n".join(lines)


def generate_nested_for_python(depth: int) -> str:
    """Generate Python code with deeply nested for loops."""
    lines = ["def deeply_nested_for():"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}for x{i} in range(10):")
    # Add final pass at deepest level
    lines.append("    " * (depth + 1) + "pass")
    return "\n".join(lines)


def generate_nested_while_python(depth: int) -> str:
    """Generate Python code with deeply nested while loops."""
    lines = ["def deeply_nested_while():"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}while x{i}:")
    # Add final pass at deepest level
    lines.append("    " * (depth + 1) + "pass")
    return "\n".join(lines)


def generate_nested_functions_python(depth: int) -> str:
    """Generate Python code with deeply nested function definitions."""
    lines = ["def outer():"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}def inner{i}():")
    # Add final pass at deepest level
    lines.append("    " * (depth + 1) + "pass")
    return "\n".join(lines)


def generate_nested_classes_python(depth: int) -> str:
    """Generate Python code with deeply nested class definitions."""
    lines = []
    for i in range(depth):
        indent = "    " * i
        lines.append(f"{indent}class Class{i}:")
    # Add final method at deepest level
    indent = "    " * depth
    lines.append(f"{indent}def method(self):")
    lines.append(f"{indent}    pass")
    return "\n".join(lines)


def generate_deep_expression_python(depth: int) -> str:
    """Generate Python code with deeply nested binary expressions.

    This doesn't hit indentation limits since it's a single expression.
    """
    # Build expression like: ((((1 + 2) + 3) + 4) + ...)
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"def deep_expr():\n    return {expr}"


def generate_nested_comprehensions_python(depth: int) -> str:
    """Generate Python code with deeply nested list comprehensions.

    This doesn't hit indentation limits since it's a single expression.
    """
    # Build: [x0 for x0 in [x1 for x1 in [x2 for x2 in [...]]]]
    expr = "range(10)"
    for i in range(depth):
        expr = f"[x{i} for x{i} in {expr}]"
    return f"def nested_comprehensions():\n    return {expr}"


def generate_nested_try_except_python(depth: int) -> str:
    """Generate Python code with deeply nested try/except blocks."""
    lines = ["def nested_try():"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}try:")
    # Add final statement at deepest level
    lines.append("    " * (depth + 1) + "pass")
    # Add all the except clauses
    for i in range(depth - 1, -1, -1):
        indent = "    " * (i + 1)
        lines.append(f"{indent}except Exception as e{i}:")
        lines.append(f"{indent}    pass")
    return "\n".join(lines)


def generate_nested_with_python(depth: int) -> str:
    """Generate Python code with deeply nested with statements."""
    lines = ["def nested_with():"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}with ctx{i}():")
    # Add final pass at deepest level
    lines.append("    " * (depth + 1) + "pass")
    return "\n".join(lines)


def generate_nested_lambda_python(depth: int) -> str:
    """Generate Python code with deeply nested lambda expressions.

    This doesn't hit indentation limits since it's a single expression.
    """
    # Build: lambda x0: lambda x1: lambda x2: ... : xN
    inner = f"x{depth - 1}"
    for i in range(depth - 2, -1, -1):
        inner = f"lambda x{i}: {inner}"
    return f"deep_lambda = {inner}"


def generate_nested_dict_python(depth: int) -> str:
    """Generate Python code with deeply nested dict literals.

    This doesn't hit indentation limits since it's a single expression.
    """
    # Build: {"a": {"a": {"a": {...}}}}
    inner = '{"leaf": 1}'
    for i in range(depth):
        inner = f'{{"level{i}": {inner}}}'
    return f"deep_dict = {inner}"


def generate_nested_if_typescript(depth: int) -> str:
    """Generate TypeScript code with deeply nested if statements."""
    lines = ["function deeplyNestedIf(x: number): void {"]
    for i in range(depth):
        indent = "  " * (i + 1)
        lines.append(f"{indent}if (x{i}) {{")
    # Add final statement at deepest level
    lines.append("  " * (depth + 1) + "console.log('deep');")
    # Close all braces
    for i in range(depth - 1, -1, -1):
        indent = "  " * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_nested_for_typescript(depth: int) -> str:
    """Generate TypeScript code with deeply nested for loops."""
    lines = ["function deeplyNestedFor(): void {"]
    for i in range(depth):
        indent = "  " * (i + 1)
        lines.append(f"{indent}for (let x{i} = 0; x{i} < 10; x{i}++) {{")
    # Add final statement at deepest level
    lines.append("  " * (depth + 1) + "console.log('deep');")
    # Close all braces
    for i in range(depth - 1, -1, -1):
        indent = "  " * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_nested_classes_typescript(depth: int) -> str:
    """Generate TypeScript code with deeply nested class definitions."""
    lines = []
    for i in range(depth):
        indent = "  " * i
        lines.append(f"{indent}class Class{i} {{")
    # Add final method at deepest level
    indent = "  " * depth
    lines.append(f"{indent}method(): void {{ }}")
    # Close all classes
    for i in range(depth - 1, -1, -1):
        indent = "  " * i
        lines.append(f"{indent}}}")
    return "\n".join(lines)


def generate_nested_arrow_functions_typescript(depth: int) -> str:
    """Generate TypeScript code with deeply nested arrow functions."""
    # Build: const f = () => () => () => ...
    inner = "42"
    for i in range(depth):
        inner = f"() => {inner}"
    return f"const deeply_nested_arrow = {inner};"


def generate_nested_if_go(depth: int) -> str:
    """Generate Go code with deeply nested if statements."""
    lines = ["package main", "", "func deeplyNestedIf() {"]
    for i in range(depth):
        indent = "\t" * (i + 1)
        lines.append(f"{indent}if x{i} > 0 {{")
    # Add final statement at deepest level
    lines.append("\t" * (depth + 1) + "println(\"deep\")")
    # Close all braces
    for i in range(depth - 1, -1, -1):
        indent = "\t" * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_nested_for_go(depth: int) -> str:
    """Generate Go code with deeply nested for loops."""
    lines = ["package main", "", "func deeplyNestedFor() {"]
    for i in range(depth):
        indent = "\t" * (i + 1)
        lines.append(f"{indent}for i{i} := 0; i{i} < 10; i{i}++ {{")
    # Add final statement at deepest level
    lines.append("\t" * (depth + 1) + "println(\"deep\")")
    # Close all braces
    for i in range(depth - 1, -1, -1):
        indent = "\t" * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_nested_if_rust(depth: int) -> str:
    """Generate Rust code with deeply nested if statements."""
    lines = ["fn deeply_nested_if() {"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}if x{i} > 0 {{")
    # Add final statement at deepest level
    lines.append("    " * (depth + 1) + "println!(\"deep\");")
    # Close all braces
    for i in range(depth - 1, -1, -1):
        indent = "    " * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_nested_match_rust(depth: int) -> str:
    """Generate Rust code with deeply nested match expressions."""
    lines = ["fn deeply_nested_match(x: i32) {"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}match x {{")
        lines.append(f"{indent}    _ => {{")
    # Add final statement at deepest level
    lines.append("    " * (depth + 1) + "println!(\"deep\");")
    # Close all match arms and braces
    for i in range(depth - 1, -1, -1):
        indent = "    " * (i + 1)
        lines.append(f"{indent}    }}")
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


# =============================================================================
# HYBRID EXTRACTOR RECURSION TESTS
# =============================================================================

class TestHybridExtractorRecursionDepth:
    """Test recursion depth handling in hybrid_extractor.py."""

    # --- Python AST traversal tests (respecting 100-level indent limit) ---

    def test_python_nested_if_safe_depth(self, tmp_path):
        """Python nested if statements at safe depth should work."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_if_python(PYTHON_SAFE_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None
        assert len(result.functions) == 1
        assert result.functions[0].name == "deeply_nested_if"

    def test_python_nested_if_max_indent(self, tmp_path):
        """Python nested if at max indent depth (90 levels)."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_if_python(PYTHON_MAX_INDENT_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        # Should parse (under 100-level limit)
        assert result is not None
        assert len(result.functions) == 1

    @xfail_recursion(RISKY_DEPTH, "Deep expression tree may overflow ast.walk()")
    def test_python_deep_expression_risky(self, tmp_path):
        """Python deep binary expression tree at risky depth.

        Expressions don't hit indentation limits but may overflow ast.walk().
        """
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_deep_expression_python(RISKY_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(OVERFLOW_DEPTH, "Deep expression tree may overflow ast.walk()")
    def test_python_deep_expression_overflow(self, tmp_path):
        """Python deep binary expression tree at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_deep_expression_python(OVERFLOW_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Deep nested comprehensions may overflow")
    def test_python_nested_comprehensions_risky(self, tmp_path):
        """Python nested list comprehensions at risky depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_comprehensions_python(RISKY_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Deep lambda chain may overflow")
    def test_python_nested_lambda_risky(self, tmp_path):
        """Python nested lambda expressions at risky depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_lambda_python(RISKY_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(OVERFLOW_DEPTH, "Deep lambda chain may overflow")
    def test_python_nested_lambda_overflow(self, tmp_path):
        """Python nested lambda expressions at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_lambda_python(OVERFLOW_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Deep dict literal may overflow")
    def test_python_nested_dict_risky(self, tmp_path):
        """Python nested dict literals at risky depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_dict_python(RISKY_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- TypeScript tree-sitter traversal tests ---

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_typescript_nested_if_overflow(self, tmp_path):
        """TypeScript nested if statements at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_if_typescript(OVERFLOW_DEPTH)
        file = tmp_path / "test.ts"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_typescript_nested_for_overflow(self, tmp_path):
        """TypeScript nested for loops at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_for_typescript(OVERFLOW_DEPTH)
        file = tmp_path / "test.ts"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_typescript_nested_classes_overflow(self, tmp_path):
        """TypeScript nested class definitions at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_classes_typescript(OVERFLOW_DEPTH)
        file = tmp_path / "test.ts"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(RISKY_DEPTH)
    def test_typescript_nested_arrow_functions_risky(self, tmp_path):
        """TypeScript nested arrow functions at risky depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_arrow_functions_typescript(RISKY_DEPTH)
        file = tmp_path / "test.ts"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Go tree-sitter traversal tests ---

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_go_nested_if_overflow(self, tmp_path):
        """Go nested if statements at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_if_go(OVERFLOW_DEPTH)
        file = tmp_path / "test.go"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_go_nested_for_overflow(self, tmp_path):
        """Go nested for loops at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_for_go(OVERFLOW_DEPTH)
        file = tmp_path / "test.go"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Rust tree-sitter traversal tests ---

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_rust_nested_if_overflow(self, tmp_path):
        """Rust nested if statements at overflow depth."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_if_rust(OVERFLOW_DEPTH)
        file = tmp_path / "test.rs"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Nested match generates large files")
    def test_rust_nested_match_risky(self, tmp_path):
        """Rust nested match expressions at risky depth."""
        from tldr.hybrid_extractor import HybridExtractor

        # Use smaller depth to avoid file size limits
        code = generate_nested_match_rust(RISKY_DEPTH // 2)
        file = tmp_path / "test.rs"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None


# =============================================================================
# CFG EXTRACTOR RECURSION TESTS
# =============================================================================

class TestCFGExtractorRecursionDepth:
    """Test recursion depth handling in cfg_extractor.py."""

    # --- Python CFG tests (respecting indent limit) ---

    def test_python_cfg_nested_if_safe(self):
        """Python CFG with nested if at safe depth should work."""
        from tldr.cfg_extractor import extract_python_cfg

        code = generate_nested_if_python(PYTHON_SAFE_DEPTH)
        cfg = extract_python_cfg(code, "deeply_nested_if")
        assert cfg is not None
        assert cfg.function_name == "deeply_nested_if"

    def test_python_cfg_nested_if_max_indent(self):
        """Python CFG with nested if at max indent depth."""
        from tldr.cfg_extractor import extract_python_cfg

        code = generate_nested_if_python(PYTHON_MAX_INDENT_DEPTH)
        cfg = extract_python_cfg(code, "deeply_nested_if")
        assert cfg is not None

    @xfail_recursion(RISKY_DEPTH, "Deep expression CFG traversal may overflow")
    def test_python_cfg_deep_expression_risky(self):
        """Python CFG with deep expression at risky depth."""
        from tldr.cfg_extractor import extract_python_cfg

        code = generate_deep_expression_python(RISKY_DEPTH)
        cfg = extract_python_cfg(code, "deep_expr")
        assert cfg is not None

    @xfail_recursion(RISKY_DEPTH, "Nested functions create recursive CFG builds")
    def test_python_cfg_nested_functions_risky(self):
        """Python CFG with nested function definitions at safe-ish depth."""
        from tldr.cfg_extractor import extract_python_cfg

        # Use depth under Python's 100-level indent limit
        code = generate_nested_functions_python(PYTHON_MAX_INDENT_DEPTH)
        cfg = extract_python_cfg(code, "outer")
        assert cfg is not None
        # Nested CFGs should be capped too
        assert cfg.nested_cfgs is not None

    # --- TypeScript CFG tests ---

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_typescript_cfg_nested_if_overflow(self, tmp_path):
        """TypeScript CFG with nested if at overflow depth."""
        from tldr.cfg_extractor import extract_typescript_cfg

        code = generate_nested_if_typescript(OVERFLOW_DEPTH)
        # Note: extract_typescript_cfg expects source code, not file path
        cfg = extract_typescript_cfg(code, "deeplyNestedIf")
        assert cfg is not None

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_typescript_cfg_nested_for_overflow(self, tmp_path):
        """TypeScript CFG with nested for at overflow depth."""
        from tldr.cfg_extractor import extract_typescript_cfg

        code = generate_nested_for_typescript(OVERFLOW_DEPTH)
        # Note: extract_typescript_cfg expects source code, not file path
        cfg = extract_typescript_cfg(code, "deeplyNestedFor")
        assert cfg is not None

    # --- Go CFG tests ---

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_go_cfg_nested_if_overflow(self, tmp_path):
        """Go CFG with nested if at overflow depth."""
        from tldr.cfg_extractor import extract_go_cfg

        code = generate_nested_if_go(OVERFLOW_DEPTH)
        # Note: extract_go_cfg expects source code, not file path
        cfg = extract_go_cfg(code, "deeplyNestedIf")
        assert cfg is not None

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_go_cfg_nested_for_overflow(self, tmp_path):
        """Go CFG with nested for at overflow depth."""
        from tldr.cfg_extractor import extract_go_cfg

        code = generate_nested_for_go(OVERFLOW_DEPTH)
        # Note: extract_go_cfg expects source code, not file path
        cfg = extract_go_cfg(code, "deeplyNestedFor")
        assert cfg is not None

    # --- Rust CFG tests ---

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_rust_cfg_nested_if_overflow(self, tmp_path):
        """Rust CFG with nested if at overflow depth."""
        from tldr.cfg_extractor import extract_rust_cfg

        code = generate_nested_if_rust(OVERFLOW_DEPTH)
        # Note: extract_rust_cfg expects source code, not file path
        cfg = extract_rust_cfg(code, "deeply_nested_if")
        assert cfg is not None

    @xfail_recursion(RISKY_DEPTH)
    def test_rust_cfg_nested_match_risky(self, tmp_path):
        """Rust CFG with nested match at risky depth."""
        from tldr.cfg_extractor import extract_rust_cfg

        # Use smaller depth to avoid file size limits
        code = generate_nested_match_rust(RISKY_DEPTH // 2)
        # Note: extract_rust_cfg expects source code, not file path
        cfg = extract_rust_cfg(code, "deeply_nested_match")
        assert cfg is not None


# =============================================================================
# DFG EXTRACTOR RECURSION TESTS
# =============================================================================

class TestDFGExtractorRecursionDepth:
    """Test recursion depth handling in dfg_extractor.py."""

    def test_python_dfg_nested_if_safe(self):
        """Python DFG with nested if at safe depth should work."""
        from tldr.dfg_extractor import extract_python_dfg

        code = generate_nested_if_python(PYTHON_SAFE_DEPTH)
        dfg = extract_python_dfg(code, "deeply_nested_if")
        assert dfg is not None
        assert dfg.function_name == "deeply_nested_if"

    def test_python_dfg_nested_if_max_indent(self):
        """Python DFG with nested if at max indent depth."""
        from tldr.dfg_extractor import extract_python_dfg

        code = generate_nested_if_python(PYTHON_MAX_INDENT_DEPTH)
        dfg = extract_python_dfg(code, "deeply_nested_if")
        assert dfg is not None

    @xfail_recursion(RISKY_DEPTH, "Deep expression DFG traversal may overflow")
    def test_python_dfg_deep_expression_risky(self):
        """Python DFG with deep expression at risky depth - targets generic_visit."""
        from tldr.dfg_extractor import extract_python_dfg

        code = generate_deep_expression_python(RISKY_DEPTH)
        dfg = extract_python_dfg(code, "deep_expr")
        assert dfg is not None

    @xfail_recursion(OVERFLOW_DEPTH, "Deep expression DFG traversal may overflow")
    def test_python_dfg_deep_expression_overflow(self):
        """Python DFG with deep expression at overflow depth."""
        from tldr.dfg_extractor import extract_python_dfg

        code = generate_deep_expression_python(OVERFLOW_DEPTH)
        dfg = extract_python_dfg(code, "deep_expr")
        assert dfg is not None

    @xfail_recursion(RISKY_DEPTH, "Nested comprehensions create deep DFG traversal")
    def test_python_dfg_nested_comprehensions_risky(self):
        """Python DFG with nested comprehensions at risky depth."""
        from tldr.dfg_extractor import extract_python_dfg

        code = generate_nested_comprehensions_python(RISKY_DEPTH)
        dfg = extract_python_dfg(code, "nested_comprehensions")
        assert dfg is not None

    @xfail_recursion(RISKY_DEPTH, "Nested lambda creates deep DFG traversal")
    def test_python_dfg_nested_lambda_risky(self):
        """Python DFG with nested lambda at risky depth."""
        from tldr.dfg_extractor import extract_python_dfg

        code = generate_nested_lambda_python(RISKY_DEPTH)
        # Lambda doesn't define a named function, test the extraction doesn't crash
        try:
            from tldr.dfg_extractor import extract_python_dfg
            # The lambda is assigned to deep_lambda, not a function
            # This test verifies extraction doesn't crash on the file
            import ast
            tree = ast.parse(code)
            # If we get here, parsing succeeded
            assert True
        except RecursionError:
            pytest.fail("RecursionError during lambda DFG extraction")

    # --- TypeScript DFG tests ---

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_typescript_dfg_nested_if_overflow(self, tmp_path):
        """TypeScript DFG with nested if at overflow depth."""
        from tldr.dfg_extractor import extract_typescript_dfg

        code = generate_nested_if_typescript(OVERFLOW_DEPTH)
        file = tmp_path / "test.ts"
        file.write_text(code)

        dfg = extract_typescript_dfg(str(file), "deeplyNestedIf")
        assert dfg is not None

    @xfail_recursion(OVERFLOW_DEPTH)
    def test_typescript_dfg_nested_for_overflow(self, tmp_path):
        """TypeScript DFG with nested for at overflow depth."""
        from tldr.dfg_extractor import extract_typescript_dfg

        code = generate_nested_for_typescript(OVERFLOW_DEPTH)
        file = tmp_path / "test.ts"
        file.write_text(code)

        dfg = extract_typescript_dfg(str(file), "deeplyNestedFor")
        assert dfg is not None


# =============================================================================
# CROSS-FILE CALL GRAPH RECURSION TESTS
# =============================================================================

class TestCallGraphRecursionDepth:
    """Test recursion depth handling in cross_file_calls.py."""

    @xfail_recursion(RISKY_DEPTH, "Deeply nested calls may overflow call extraction")
    def test_python_callgraph_nested_calls_risky(self, tmp_path):
        """Python call graph with deeply nested call expressions."""
        from tldr.cross_file_calls import build_project_call_graph

        # Generate code with deeply nested function calls: f0(f1(f2(...)))
        # Use smaller depth to avoid extremely large files
        depth = RISKY_DEPTH // 10
        inner = "x"
        for i in range(depth):
            inner = f"f{i}({inner})"
        code = f"def main():\n    return {inner}"

        file = tmp_path / "test.py"
        file.write_text(code)

        graph = build_project_call_graph(str(tmp_path))
        # If we get here without RecursionError, graph has some protection
        assert graph is not None

    @xfail_recursion(RISKY_DEPTH, "Deeply nested calls may overflow call extraction")
    def test_typescript_callgraph_nested_calls_risky(self, tmp_path):
        """TypeScript call graph with deeply nested call expressions."""
        from tldr.cross_file_calls import build_project_call_graph

        # Generate code with deeply nested function calls
        depth = RISKY_DEPTH // 10
        inner = "x"
        for i in range(depth):
            inner = f"f{i}({inner})"
        code = f"function main(): void {{ return {inner}; }}"

        file = tmp_path / "test.ts"
        file.write_text(code)

        graph = build_project_call_graph(str(tmp_path))
        assert graph is not None


# =============================================================================
# API ENTRY POINT RECURSION TESTS
# =============================================================================

class TestAPIRecursionDepth:
    """Test recursion depth handling through public API."""

    def test_extract_file_safe_nesting(self, tmp_path):
        """API extract_file with safely nested code."""
        from tldr.api import extract_file

        code = generate_nested_if_python(PYTHON_SAFE_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        result = extract_file(str(file))
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Deep expression may overflow API extraction")
    def test_extract_file_deep_expression(self, tmp_path):
        """API extract_file with deeply nested expression."""
        from tldr.api import extract_file

        code = generate_deep_expression_python(RISKY_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        result = extract_file(str(file))
        assert result is not None

    def test_get_cfg_context_safe_nesting(self):
        """API get_cfg_context with safely nested code."""
        from tldr.api import get_cfg_context

        code = generate_nested_if_python(PYTHON_SAFE_DEPTH)
        result = get_cfg_context(code, "deeply_nested_if", language="python")
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Deep expression may overflow CFG context")
    def test_get_cfg_context_deep_expression(self):
        """API get_cfg_context with deeply nested expression."""
        from tldr.api import get_cfg_context

        code = generate_deep_expression_python(RISKY_DEPTH)
        result = get_cfg_context(code, "deep_expr", language="python")
        assert result is not None

    def test_get_dfg_context_safe_nesting(self):
        """API get_dfg_context with safely nested code."""
        from tldr.api import get_dfg_context

        code = generate_nested_if_python(PYTHON_SAFE_DEPTH)
        result = get_dfg_context(code, "deeply_nested_if", language="python")
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Deep expression may overflow DFG context")
    def test_get_dfg_context_deep_expression(self):
        """API get_dfg_context with deeply nested expression."""
        from tldr.api import get_dfg_context

        code = generate_deep_expression_python(RISKY_DEPTH)
        result = get_dfg_context(code, "deep_expr", language="python")
        assert result is not None


# =============================================================================
# RECURSION LIMIT ENVIRONMENT TESTS
# =============================================================================

class TestRecursionLimitBehavior:
    """Test that recursion limit is properly respected."""

    def test_default_recursion_limit(self):
        """Verify default Python recursion limit."""
        limit = sys.getrecursionlimit()
        assert limit >= 1000, f"Unexpectedly low recursion limit: {limit}"

    def test_recursion_limit_constant(self):
        """Verify our test constants are appropriate."""
        limit = sys.getrecursionlimit()
        assert SAFE_DEPTH < limit / 2, "SAFE_DEPTH should be well under half the limit"
        assert RISKY_DEPTH < limit, "RISKY_DEPTH should be under the limit"
        assert OVERFLOW_DEPTH >= limit, "OVERFLOW_DEPTH should be at or above limit"

    def test_python_indent_limit_constant(self):
        """Verify Python indent depth constants respect 100-level limit."""
        assert PYTHON_SAFE_DEPTH < 100, "PYTHON_SAFE_DEPTH must be under 100"
        assert PYTHON_MAX_INDENT_DEPTH < 100, "PYTHON_MAX_INDENT_DEPTH must be under 100"

    @xfail_recursion(RISKY_DEPTH, "Deep non-indented structures may overflow")
    def test_non_indent_depth_protection(self, tmp_path):
        """Code with deep non-indented structures should be handled gracefully."""
        from tldr.hybrid_extractor import HybridExtractor

        # Use deeply nested expressions (no indent limit)
        code = generate_deep_expression_python(RISKY_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        try:
            result = extractor.extract(file)
            assert result is not None
        except (ValueError, RuntimeError) as e:
            # Graceful error handling is acceptable
            assert "depth" in str(e).lower() or "recursion" in str(e).lower()


# =============================================================================
# EDGE CASES AND COMBINATIONS
# =============================================================================

class TestRecursionEdgeCases:
    """Test edge cases in recursion handling."""

    def test_mixed_nesting_python_safe(self, tmp_path):
        """Python code with mixed nesting types at safe depth."""
        from tldr.hybrid_extractor import HybridExtractor

        lines = ["def mixed_nesting():"]
        # Distribute depth across 4 types, staying well under 100 total
        depth = 20  # 20 * 4 = 80 indent levels

        for i in range(depth):
            indent = "    " * (i * 4 + 1)
            lines.append(f"{indent}if cond{i}:")
            lines.append(f"{indent}    for x{i} in range(10):")
            lines.append(f"{indent}        while flag{i}:")
            lines.append(f"{indent}            with ctx{i}():")
        lines.append("    " * (depth * 4 + 1) + "pass")
        code = "\n".join(lines)

        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Nested classes may overflow")
    def test_deeply_nested_classes_risky(self, tmp_path):
        """Python deeply nested classes (single expression per line)."""
        from tldr.hybrid_extractor import HybridExtractor

        # Use depth under Python's 100-level indent limit
        code = generate_nested_classes_python(PYTHON_MAX_INDENT_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    def test_decorator_chain_safe(self, tmp_path):
        """Python function with moderately stacked decorators."""
        from tldr.hybrid_extractor import HybridExtractor

        # Use smaller depth for decorators
        lines = []
        for i in range(100):  # 100 decorators (no indentation issue)
            lines.append(f"@decorator{i}")
        lines.append("def heavily_decorated():")
        lines.append("    pass")
        code = "\n".join(lines)

        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None
        assert len(result.functions) == 1

    @xfail_recursion(RISKY_DEPTH, "Many decorators may overflow AST traversal")
    def test_decorator_chain_risky(self, tmp_path):
        """Python function with many stacked decorators."""
        from tldr.hybrid_extractor import HybridExtractor

        lines = []
        for i in range(RISKY_DEPTH):
            lines.append(f"@decorator{i}")
        lines.append("def heavily_decorated():")
        lines.append("    pass")
        code = "\n".join(lines)

        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @xfail_recursion(RISKY_DEPTH, "Nested dict literals may overflow")
    def test_nested_dict_risky(self, tmp_path):
        """Python deeply nested dict literals."""
        from tldr.hybrid_extractor import HybridExtractor

        code = generate_nested_dict_python(RISKY_DEPTH)
        file = tmp_path / "test.py"
        file.write_text(code)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None


# =============================================================================
# CODE GENERATORS - Additional Languages
# =============================================================================

def generate_nested_if_c(depth: int) -> str:
    """Generate C code with deeply nested if statements."""
    lines = ["int main() {"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}if (x{i}) {{")
    lines.append("    " * (depth + 1) + "return 0;")
    for i in range(depth - 1, -1, -1):
        indent = "    " * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_deep_expression_c(depth: int) -> str:
    """Generate C code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"int deep_expr() {{\n    return {expr};\n}}"


def generate_nested_if_cpp(depth: int) -> str:
    """Generate C++ code with deeply nested if statements."""
    lines = ["int main() {"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}if (x{i}) {{")
    lines.append("    " * (depth + 1) + "return 0;")
    for i in range(depth - 1, -1, -1):
        indent = "    " * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_deep_expression_cpp(depth: int) -> str:
    """Generate C++ code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"int deep_expr() {{\n    return {expr};\n}}"


def generate_nested_if_ruby(depth: int) -> str:
    """Generate Ruby code with deeply nested if statements."""
    lines = ["def deeply_nested_if"]
    for i in range(depth):
        indent = "  " * (i + 1)
        lines.append(f"{indent}if x{i}")
    lines.append("  " * (depth + 1) + "nil")
    for i in range(depth - 1, -1, -1):
        indent = "  " * (i + 1)
        lines.append(f"{indent}end")
    lines.append("end")
    return "\n".join(lines)


def generate_deep_expression_ruby(depth: int) -> str:
    """Generate Ruby code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"def deep_expr\n  {expr}\nend"


def generate_nested_if_kotlin(depth: int) -> str:
    """Generate Kotlin code with deeply nested if statements."""
    lines = ["fun deeplyNestedIf() {"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}if (x{i}) {{")
    lines.append("    " * (depth + 1) + "println(\"deep\")")
    for i in range(depth - 1, -1, -1):
        indent = "    " * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_deep_expression_kotlin(depth: int) -> str:
    """Generate Kotlin code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"fun deepExpr(): Int {{\n    return {expr}\n}}"


def generate_nested_if_swift(depth: int) -> str:
    """Generate Swift code with deeply nested if statements."""
    lines = ["func deeplyNestedIf() {"]
    for i in range(depth):
        indent = "    " * (i + 1)
        lines.append(f"{indent}if x{i} {{")
    lines.append("    " * (depth + 1) + "print(\"deep\")")
    for i in range(depth - 1, -1, -1):
        indent = "    " * (i + 1)
        lines.append(f"{indent}}}")
    lines.append("}")
    return "\n".join(lines)


def generate_deep_expression_swift(depth: int) -> str:
    """Generate Swift code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"func deepExpr() -> Int {{\n    return {expr}\n}}"


def generate_nested_if_csharp(depth: int) -> str:
    """Generate C# code with deeply nested if statements."""
    lines = ["class Program {", "    static void Main() {"]
    for i in range(depth):
        indent = "        " + "    " * i
        lines.append(f"{indent}if (x{i}) {{")
    lines.append("        " + "    " * depth + "Console.WriteLine(\"deep\");")
    for i in range(depth - 1, -1, -1):
        indent = "        " + "    " * i
        lines.append(f"{indent}}}")
    lines.append("    }")
    lines.append("}")
    return "\n".join(lines)


def generate_deep_expression_csharp(depth: int) -> str:
    """Generate C# code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"class Program {{\n    static int DeepExpr() {{\n        return {expr};\n    }}\n}}"


def generate_nested_if_scala(depth: int) -> str:
    """Generate Scala code with deeply nested if statements."""
    lines = ["object Main {", "  def deeplyNestedIf(): Unit = {"]
    for i in range(depth):
        indent = "    " + "  " * i
        lines.append(f"{indent}if (x{i}) {{")
    lines.append("    " + "  " * depth + "println(\"deep\")")
    for i in range(depth - 1, -1, -1):
        indent = "    " + "  " * i
        lines.append(f"{indent}}}")
    lines.append("  }")
    lines.append("}")
    return "\n".join(lines)


def generate_deep_expression_scala(depth: int) -> str:
    """Generate Scala code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"object Main {{\n  def deepExpr(): Int = {{\n    {expr}\n  }}\n}}"


def generate_nested_if_lua(depth: int) -> str:
    """Generate Lua code with deeply nested if statements."""
    lines = ["function deeply_nested_if()"]
    for i in range(depth):
        indent = "  " * (i + 1)
        lines.append(f"{indent}if x{i} then")
    lines.append("  " * (depth + 1) + "print(\"deep\")")
    for i in range(depth - 1, -1, -1):
        indent = "  " * (i + 1)
        lines.append(f"{indent}end")
    lines.append("end")
    return "\n".join(lines)


def generate_deep_expression_lua(depth: int) -> str:
    """Generate Lua code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"function deep_expr()\n  return {expr}\nend"


def generate_nested_if_elixir(depth: int) -> str:
    """Generate Elixir code with deeply nested if statements."""
    lines = ["defmodule DeepNesting do", "  def deeply_nested_if do"]
    for i in range(depth):
        indent = "    " + "  " * i
        lines.append(f"{indent}if x{i} do")
    lines.append("    " + "  " * depth + "IO.puts(\"deep\")")
    for i in range(depth - 1, -1, -1):
        indent = "    " + "  " * i
        lines.append(f"{indent}end")
    lines.append("  end")
    lines.append("end")
    return "\n".join(lines)


def generate_deep_expression_elixir(depth: int) -> str:
    """Generate Elixir code with deeply nested binary expressions."""
    expr = "1"
    for i in range(2, depth + 2):
        expr = f"({expr} + {i})"
    return f"defmodule DeepExpr do\n  def deep_expr do\n    {expr}\n  end\nend"


# =============================================================================
# MISSING LANGUAGES RECURSION TESTS
# =============================================================================

class TestMissingLanguagesRecursion:
    """Recursion depth tests for additional languages: C, C++, Ruby, Kotlin, Swift, C#, Scala, Lua, Elixir."""

    # --- C tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_c_deeply_nested_if(self, tmp_path):
        """C with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_c(depth)
        file = tmp_path / "test.c"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_c_deep_expression(self, tmp_path):
        """C with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_c(depth)
        file = tmp_path / "test.c"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- C++ tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_cpp_deeply_nested_if(self, tmp_path):
        """C++ with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_cpp(depth)
        file = tmp_path / "test.cpp"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_cpp_deep_expression(self, tmp_path):
        """C++ with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_cpp(depth)
        file = tmp_path / "test.cpp"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Ruby tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_ruby_deeply_nested_if(self, tmp_path):
        """Ruby with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_ruby(depth)
        file = tmp_path / "test.rb"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_ruby_deep_expression(self, tmp_path):
        """Ruby with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_ruby(depth)
        file = tmp_path / "test.rb"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Kotlin tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_kotlin_deeply_nested_if(self, tmp_path):
        """Kotlin with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_kotlin(depth)
        file = tmp_path / "test.kt"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_kotlin_deep_expression(self, tmp_path):
        """Kotlin with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_kotlin(depth)
        file = tmp_path / "test.kt"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Swift tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_swift_deeply_nested_if(self, tmp_path):
        """Swift with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_swift(depth)
        file = tmp_path / "test.swift"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_swift_deep_expression(self, tmp_path):
        """Swift with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_swift(depth)
        file = tmp_path / "test.swift"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- C# tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_csharp_deeply_nested_if(self, tmp_path):
        """C# with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_csharp(depth)
        file = tmp_path / "test.cs"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_csharp_deep_expression(self, tmp_path):
        """C# with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_csharp(depth)
        file = tmp_path / "test.cs"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Scala tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_scala_deeply_nested_if(self, tmp_path):
        """Scala with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_scala(depth)
        file = tmp_path / "test.scala"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_scala_deep_expression(self, tmp_path):
        """Scala with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_scala(depth)
        file = tmp_path / "test.scala"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Lua tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_lua_deeply_nested_if(self, tmp_path):
        """Lua with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_lua(depth)
        file = tmp_path / "test.lua"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_lua_deep_expression(self, tmp_path):
        """Lua with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_lua(depth)
        file = tmp_path / "test.lua"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    # --- Elixir tests ---

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_elixir_deeply_nested_if(self, tmp_path):
        """Elixir with deeply nested if statements."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_nested_if_elixir(depth)
        file = tmp_path / "test.ex"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None

    @pytest.mark.xfail(reason="No recursion limit", strict=False)
    def test_elixir_deep_expression(self, tmp_path):
        """Elixir with deeply nested binary expressions."""
        from tldr.hybrid_extractor import HybridExtractor

        depth = 500
        content = generate_deep_expression_elixir(depth)
        file = tmp_path / "test.ex"
        file.write_text(content)

        extractor = HybridExtractor()
        result = extractor.extract(file)
        assert result is not None
