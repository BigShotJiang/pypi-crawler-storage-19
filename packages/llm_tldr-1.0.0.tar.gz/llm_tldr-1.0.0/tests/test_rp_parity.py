"""
Tests for rp-cli parity features: file tree, search, selection.

Tests cover all 4 supported languages: Python, TypeScript, Go, Rust.
"""
import tempfile
import os
from pathlib import Path
import pytest


class TestGetFileTree:
    """Tests for get_file_tree() - matches rp-cli 'tree' command."""

    def test_simple_python_project(self, tmp_path):
        """Test file tree for a simple Python project."""
        from tldr.api import get_file_tree

        # Create structure
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("def main(): pass")
        (tmp_path / "src" / "utils.py").write_text("def helper(): pass")
        (tmp_path / "tests").mkdir()
        (tmp_path / "tests" / "test_main.py").write_text("def test_main(): pass")

        tree = get_file_tree(tmp_path)

        assert tree["name"] == tmp_path.name
        assert tree["type"] == "dir"
        assert len(tree["children"]) == 2  # src, tests

        # Find src directory
        src = next(c for c in tree["children"] if c["name"] == "src")
        assert src["type"] == "dir"
        assert len(src["children"]) == 2  # main.py, utils.py

    def test_filter_by_extension(self, tmp_path):
        """Test filtering file tree by extension."""
        from tldr.api import get_file_tree

        (tmp_path / "app.py").write_text("pass")
        (tmp_path / "app.ts").write_text("export {}")
        (tmp_path / "readme.md").write_text("# Readme")

        # Python only
        tree = get_file_tree(tmp_path, extensions={".py"})
        files = [c["name"] for c in tree["children"] if c["type"] == "file"]
        assert "app.py" in files
        assert "app.ts" not in files
        assert "readme.md" not in files

    def test_multi_language_project(self, tmp_path):
        """Test file tree with Python, TypeScript, Go, Rust."""
        from tldr.api import get_file_tree

        (tmp_path / "main.py").write_text("def main(): pass")
        (tmp_path / "app.ts").write_text("export function app() {}")
        (tmp_path / "server.go").write_text("package main")
        (tmp_path / "lib.rs").write_text("fn main() {}")

        tree = get_file_tree(tmp_path)
        files = [c["name"] for c in tree["children"] if c["type"] == "file"]

        assert "main.py" in files
        assert "app.ts" in files
        assert "server.go" in files
        assert "lib.rs" in files

    def test_excludes_hidden_files(self, tmp_path):
        """Test that hidden files/dirs are excluded by default."""
        from tldr.api import get_file_tree

        (tmp_path / ".git").mkdir()
        (tmp_path / ".git" / "config").write_text("config")
        (tmp_path / ".env").write_text("SECRET=123")
        (tmp_path / "main.py").write_text("pass")

        tree = get_file_tree(tmp_path)
        names = [c["name"] for c in tree["children"]]

        assert ".git" not in names
        assert ".env" not in names
        assert "main.py" in names

    def test_nested_structure(self, tmp_path):
        """Test deeply nested directory structure."""
        from tldr.api import get_file_tree

        (tmp_path / "a" / "b" / "c").mkdir(parents=True)
        (tmp_path / "a" / "b" / "c" / "deep.py").write_text("pass")

        tree = get_file_tree(tmp_path)

        # Navigate to deep.py
        a = next(c for c in tree["children"] if c["name"] == "a")
        b = next(c for c in a["children"] if c["name"] == "b")
        c = next(c for c in b["children"] if c["name"] == "c")
        deep = next(c for c in c["children"] if c["name"] == "deep.py")

        assert deep["type"] == "file"
        assert deep["path"] == "a/b/c/deep.py"


class TestSearch:
    """Tests for search() - matches rp-cli 'search' command."""

    def test_simple_pattern_search(self, tmp_path):
        """Test searching for a simple pattern."""
        from tldr.api import search

        (tmp_path / "main.py").write_text("def hello():\n    print('hello')\n")
        (tmp_path / "utils.py").write_text("def world():\n    return 'world'\n")

        results = search("hello", tmp_path)

        assert len(results) == 2  # def hello, print('hello')
        assert any("main.py" in r["file"] for r in results)

    def test_regex_pattern(self, tmp_path):
        """Test regex pattern search."""
        from tldr.api import search

        (tmp_path / "code.py").write_text("def func_one(): pass\ndef func_two(): pass\n")

        results = search(r"def func_\w+", tmp_path)

        assert len(results) == 2

    def test_filter_by_extension(self, tmp_path):
        """Test search filtering by file extension."""
        from tldr.api import search

        (tmp_path / "app.py").write_text("# TODO: fix this")
        (tmp_path / "app.ts").write_text("// TODO: fix this")

        # Python only
        results = search("TODO", tmp_path, extensions={".py"})

        assert len(results) == 1
        assert "app.py" in results[0]["file"]

    def test_multi_language_search(self, tmp_path):
        """Test search across Python, TypeScript, Go, Rust."""
        from tldr.api import search

        (tmp_path / "main.py").write_text("# FIXME: python bug")
        (tmp_path / "app.ts").write_text("// FIXME: typescript bug")
        (tmp_path / "server.go").write_text("// FIXME: go bug")
        (tmp_path / "lib.rs").write_text("// FIXME: rust bug")

        results = search("FIXME", tmp_path)

        assert len(results) == 4
        files = [r["file"] for r in results]
        assert any("main.py" in f for f in files)
        assert any("app.ts" in f for f in files)
        assert any("server.go" in f for f in files)
        assert any("lib.rs" in f for f in files)

    def test_returns_line_numbers(self, tmp_path):
        """Test that search returns correct line numbers."""
        from tldr.api import search

        (tmp_path / "code.py").write_text("line one\nTARGET here\nline three\n")

        results = search("TARGET", tmp_path)

        assert len(results) == 1
        assert results[0]["line"] == 2
        assert "TARGET" in results[0]["content"]

    def test_no_results(self, tmp_path):
        """Test search with no matches."""
        from tldr.api import search

        (tmp_path / "code.py").write_text("nothing here")

        results = search("NOTFOUND", tmp_path)

        assert results == []


class TestSelection:
    """Tests for Selection class - matches rp-cli 'select' command."""

    def test_add_files(self):
        """Test adding files to selection."""
        from tldr.api import Selection

        sel = Selection()
        sel.add("src/main.py", "src/utils.py")

        assert "src/main.py" in sel.files
        assert "src/utils.py" in sel.files

    def test_remove_files(self):
        """Test removing files from selection."""
        from tldr.api import Selection

        sel = Selection()
        sel.add("a.py", "b.py", "c.py")
        sel.remove("b.py")

        assert "a.py" in sel.files
        assert "b.py" not in sel.files
        assert "c.py" in sel.files

    def test_clear_selection(self):
        """Test clearing all selection."""
        from tldr.api import Selection

        sel = Selection()
        sel.add("a.py", "b.py")
        sel.clear()

        assert sel.files == []

    def test_set_selection(self):
        """Test replacing entire selection."""
        from tldr.api import Selection

        sel = Selection()
        sel.add("old.py")
        sel.set("new.py", "another.py")

        assert "old.py" not in sel.files
        assert "new.py" in sel.files
        assert "another.py" in sel.files

    def test_files_returns_sorted(self):
        """Test that files property returns sorted list."""
        from tldr.api import Selection

        sel = Selection()
        sel.add("z.py", "a.py", "m.py")

        assert sel.files == ["a.py", "m.py", "z.py"]

    def test_get_context_for_selection(self, tmp_path):
        """Test getting context for selected files."""
        from tldr.api import Selection, extract_file

        (tmp_path / "main.py").write_text("def main(): pass")
        (tmp_path / "utils.py").write_text("def helper(): pass")

        sel = Selection()
        sel.add(str(tmp_path / "main.py"))

        # Should be able to extract context for selected files
        for f in sel.files:
            info = extract_file(f)
            assert "functions" in info


class TestGetCodeStructure:
    """Tests for get_code_structure() - matches rp-cli 'structure' command."""

    def test_python_structure(self, tmp_path):
        """Test code structure extraction for Python."""
        from tldr.api import get_code_structure

        (tmp_path / "main.py").write_text('''
class MyClass:
    def method(self): pass

def my_function(x: int) -> str:
    return str(x)
''')

        structure = get_code_structure(tmp_path)

        assert len(structure["files"]) == 1
        f = structure["files"][0]
        assert "MyClass" in f["classes"]
        assert "my_function" in f["functions"]

    def test_typescript_structure(self, tmp_path):
        """Test code structure extraction for TypeScript."""
        from tldr.api import get_code_structure

        (tmp_path / "app.ts").write_text('''
export class AppService {
    getData(): string { return "data"; }
}

export function processData(x: number): void {}
''')

        structure = get_code_structure(tmp_path, language="typescript")

        assert len(structure["files"]) == 1
        f = structure["files"][0]
        assert "AppService" in f["classes"]
        assert "processData" in f["functions"]

    def test_go_structure(self, tmp_path):
        """Test code structure extraction for Go."""
        from tldr.api import get_code_structure

        (tmp_path / "main.go").write_text('''
package main

type Server struct {
    port int
}

func (s *Server) Start() {}

func main() {}
''')

        structure = get_code_structure(tmp_path, language="go")

        assert len(structure["files"]) == 1
        f = structure["files"][0]
        assert "Server" in f["classes"]  # structs as classes
        assert "main" in f["functions"]

    def test_rust_structure(self, tmp_path):
        """Test code structure extraction for Rust."""
        from tldr.api import get_code_structure

        (tmp_path / "lib.rs").write_text('''
pub struct Config {
    pub name: String,
}

impl Config {
    pub fn new() -> Self { Config { name: String::new() } }
}

pub fn process() {}
''')

        structure = get_code_structure(tmp_path, language="rust")

        assert len(structure["files"]) == 1
        f = structure["files"][0]
        assert "Config" in f["classes"]  # structs as classes
        assert "process" in f["functions"]

    def test_includes_imports(self, tmp_path):
        """Test that structure includes imports."""
        from tldr.api import get_code_structure

        (tmp_path / "main.py").write_text('''
import os
from pathlib import Path

def main(): pass
''')

        structure = get_code_structure(tmp_path)
        f = structure["files"][0]

        assert "os" in str(f["imports"])
        assert "Path" in str(f["imports"]) or "pathlib" in str(f["imports"])


class TestRpCliComparison:
    """Compare tldr-code output with rp-cli output format."""

    def test_structure_format_matches_rp(self, tmp_path):
        """Verify our structure output is comparable to rp-cli."""
        from tldr.api import get_code_structure

        (tmp_path / "example.py").write_text('''
import json
from typing import Optional

class DataProcessor:
    """Process data efficiently."""

    def __init__(self, config: dict):
        self.config = config

    def process(self, data: list) -> dict:
        return {"processed": len(data)}

def main():
    processor = DataProcessor({})
    processor.process([1, 2, 3])
''')

        structure = get_code_structure(tmp_path)

        # rp-cli format has: path, functions, classes, imports
        f = structure["files"][0]
        assert "path" in f
        assert "functions" in f
        assert "classes" in f
        assert "imports" in f

        # Check data types match rp-cli expectations
        assert isinstance(f["functions"], list)
        assert isinstance(f["classes"], list)
        assert isinstance(f["imports"], list)
