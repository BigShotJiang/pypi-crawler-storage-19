"""Tests for Lua import parsing.

TDD tests for Lua language support in TLDR import parsing.
These tests should FAIL initially until Lua support is implemented.

Lua import patterns (tree-sitter-lua):
- require("module_name") : load and return module
- require "module_name" : parentheses optional for string literal
- dofile("path.lua") : load and execute file
- loadfile("path.lua") : load file as function (lazy)
- These appear as `function_call` nodes where the function is "require", "dofile", or "loadfile"
"""
import pytest
from pathlib import Path

# Check if tree-sitter-lua is available
try:
    from tldr.cross_file_calls import parse_lua_imports, TREE_SITTER_LUA_AVAILABLE
    LUA_AVAILABLE = TREE_SITTER_LUA_AVAILABLE
except ImportError:
    LUA_AVAILABLE = False


pytestmark = pytest.mark.skipif(not LUA_AVAILABLE, reason="tree-sitter-lua not available")


@pytest.fixture
def simple_imports_file(tmp_path):
    """Create a Lua file with simple require statements."""
    code = '''
local json = require("json")
local yaml = require("yaml")

local function process(data)
    return json.decode(data)
end

return { process = process }
'''
    file_path = tmp_path / "example.lua"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def dotted_imports_file(tmp_path):
    """Create a Lua file with dotted module paths."""
    code = '''
local utils = require("myapp.utils")
local models = require("myapp.models.user")
local handlers = require("myapp.handlers.api.v1")

local M = {}

function M.run()
    local user = models.User.new()
    return handlers.process(user)
end

return M
'''
    file_path = tmp_path / "main.lua"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def mixed_imports_file(tmp_path):
    """Create a Lua file with mixed import statements."""
    code = '''
-- Standard require
local json = require("json")
local http = require("socket.http")

-- Dotted path require
local config = require("myapp.config")

-- String literal without parentheses
local legacy = require "legacy_module"

-- dofile for direct execution
dofile("init.lua")

-- loadfile for lazy loading
local lazy_loader = loadfile("optional.lua")

local M = {}
return M
'''
    file_path = tmp_path / "application.lua"
    file_path.write_text(code)
    return file_path


@pytest.fixture
def conditional_imports_file(tmp_path):
    """Create a Lua file with conditional require statements."""
    code = '''
local socket

if os.getenv("USE_LUASOCKET") then
    socket = require("socket")
else
    socket = require("cosocket")
end

local feature
if _VERSION >= "Lua 5.3" then
    feature = require("lua53_feature")
else
    feature = require("lua52_compat")
end

return { socket = socket, feature = feature }
'''
    file_path = tmp_path / "conditional.lua"
    file_path.write_text(code)
    return file_path


class TestSimpleImports:
    """Test basic import parsing."""

    def test_parses_require_statements(self, simple_imports_file):
        imports = parse_lua_imports(simple_imports_file)
        assert len(imports) == 2
        modules = [imp['module'] for imp in imports]
        assert 'json' in modules
        assert 'yaml' in modules

    def test_dotted_module_paths(self, dotted_imports_file):
        imports = parse_lua_imports(dotted_imports_file)
        assert len(imports) >= 3
        modules = [imp['module'] for imp in imports]
        assert any('myapp.utils' in m for m in modules)
        assert any('myapp.models.user' in m for m in modules)
        assert any('myapp.handlers.api.v1' in m for m in modules)

    def test_string_without_parentheses(self, tmp_path):
        """Test require with string literal without parentheses."""
        code = '''
local mod = require "simple_module"
return mod
'''
        file_path = tmp_path / "no_parens.lua"
        file_path.write_text(code)
        imports = parse_lua_imports(file_path)
        assert len(imports) == 1
        assert imports[0]['module'] == 'simple_module'


class TestMixedImports:
    """Test mixed import scenarios."""

    def test_mixed_imports(self, mixed_imports_file):
        imports = parse_lua_imports(mixed_imports_file)
        # Should have all imports: require, dofile, loadfile
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        # Check various import types are captured
        assert any('json' in m for m in modules)
        assert any('config' in m for m in modules)

    def test_import_types_distinguished(self, mixed_imports_file):
        imports = parse_lua_imports(mixed_imports_file)
        # Imports should indicate their type (require vs dofile vs loadfile)
        import_types = set()
        for imp in imports:
            if 'type' in imp:
                import_types.add(imp['type'])
        # Should have multiple types
        assert len(import_types) >= 1  # At minimum should track type

    def test_dofile_detected(self, mixed_imports_file):
        imports = parse_lua_imports(mixed_imports_file)
        # dofile should be detected
        dofile_imports = [imp for imp in imports if imp.get('type') == 'dofile' or 'init.lua' in imp.get('module', '')]
        assert len(dofile_imports) >= 1

    def test_loadfile_detected(self, mixed_imports_file):
        imports = parse_lua_imports(mixed_imports_file)
        # loadfile should be detected
        loadfile_imports = [imp for imp in imports if imp.get('type') == 'loadfile' or 'optional.lua' in imp.get('module', '')]
        assert len(loadfile_imports) >= 1


class TestEdgeCases:
    """Test edge cases."""

    def test_empty_file(self, tmp_path):
        file_path = tmp_path / "empty.lua"
        file_path.write_text("local M = {} return M")
        imports = parse_lua_imports(file_path)
        assert imports == []

    def test_nonexistent_file(self, tmp_path):
        file_path = tmp_path / "nonexistent.lua"
        imports = parse_lua_imports(file_path)
        assert imports == []

    def test_conditional_require(self, conditional_imports_file):
        """Require inside if statement should still be detected."""
        imports = parse_lua_imports(conditional_imports_file)
        # Should detect all requires even inside conditionals
        assert len(imports) >= 4
        modules = [imp['module'] for imp in imports]
        assert any('socket' in m for m in modules)
        assert any('cosocket' in m for m in modules)

    def test_only_function_definition(self, tmp_path):
        code = '''
local function add(a, b)
    return a + b
end

return { add = add }
'''
        file_path = tmp_path / "no_imports.lua"
        file_path.write_text(code)
        imports = parse_lua_imports(file_path)
        assert imports == []

    def test_dynamic_require(self, tmp_path):
        """Dynamic require with variable should be handled gracefully."""
        code = '''
local module_name = "dynamic"
local mod = require(module_name)
return mod
'''
        file_path = tmp_path / "dynamic.lua"
        file_path.write_text(code)
        imports = parse_lua_imports(file_path)
        # May or may not detect dynamic requires, but should not crash
        assert isinstance(imports, list)
