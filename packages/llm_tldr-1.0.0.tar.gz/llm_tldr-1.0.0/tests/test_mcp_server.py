"""
Tests for TLDR MCP Server - Model Context Protocol interface for TLDR.

TDD: Write tests first, then implement.
"""

import hashlib
import json
import socket
import tempfile
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestMCPServerHelpers:
    """Test MCP server helper functions."""

    def test_get_socket_path_uses_md5_hash(self):
        """Socket path should match daemon.py logic."""
        from tldr.mcp_server import _get_socket_path

        project = "/Users/test/myproject"
        expected_hash = hashlib.md5(str(Path(project).resolve()).encode()).hexdigest()[:8]
        expected_path = Path(f"/tmp/tldr-{expected_hash}.sock")

        result = _get_socket_path(project)
        assert result == expected_path

    def test_get_socket_path_deterministic(self):
        """Same project path should always produce same socket path."""
        from tldr.mcp_server import _get_socket_path

        project = "/Users/test/myproject"
        result1 = _get_socket_path(project)
        result2 = _get_socket_path(project)

        assert result1 == result2


class TestMCPToolDefinitions:
    """Test that MCP tools are properly defined."""

    def test_mcp_instance_exists(self):
        """mcp instance should be created."""
        from tldr.mcp_server import mcp

        assert mcp is not None
        assert mcp.name == "tldr-code"

    def test_tree_tool_exists(self):
        """tree tool should be defined."""
        from tldr.mcp_server import tree

        assert callable(tree)

    def test_structure_tool_exists(self):
        """structure tool should be defined."""
        from tldr.mcp_server import structure

        assert callable(structure)

    def test_search_tool_exists(self):
        """search tool should be defined."""
        from tldr.mcp_server import search

        assert callable(search)

    def test_extract_tool_exists(self):
        """extract tool should be defined."""
        from tldr.mcp_server import extract

        assert callable(extract)

    def test_context_tool_exists(self):
        """context tool should be defined."""
        from tldr.mcp_server import context

        assert callable(context)

    def test_cfg_tool_exists(self):
        """cfg tool should be defined."""
        from tldr.mcp_server import cfg

        assert callable(cfg)

    def test_dfg_tool_exists(self):
        """dfg tool should be defined."""
        from tldr.mcp_server import dfg

        assert callable(dfg)

    def test_slice_tool_exists(self):
        """slice tool should be defined."""
        from tldr.mcp_server import slice

        assert callable(slice)

    def test_impact_tool_exists(self):
        """impact tool should be defined."""
        from tldr.mcp_server import impact

        assert callable(impact)

    def test_dead_tool_exists(self):
        """dead tool should be defined."""
        from tldr.mcp_server import dead

        assert callable(dead)

    def test_arch_tool_exists(self):
        """arch tool should be defined."""
        from tldr.mcp_server import arch

        assert callable(arch)

    def test_calls_tool_exists(self):
        """calls tool should be defined."""
        from tldr.mcp_server import calls

        assert callable(calls)

    def test_imports_tool_exists(self):
        """imports tool should be defined."""
        from tldr.mcp_server import imports

        assert callable(imports)

    def test_importers_tool_exists(self):
        """importers tool should be defined."""
        from tldr.mcp_server import importers

        assert callable(importers)

    def test_semantic_tool_exists(self):
        """semantic tool should be defined."""
        from tldr.mcp_server import semantic

        assert callable(semantic)

    def test_diagnostics_tool_exists(self):
        """diagnostics tool should be defined."""
        from tldr.mcp_server import diagnostics

        assert callable(diagnostics)

    def test_change_impact_tool_exists(self):
        """change_impact tool should be defined."""
        from tldr.mcp_server import change_impact

        assert callable(change_impact)

    def test_status_tool_exists(self):
        """status tool should be defined."""
        from tldr.mcp_server import status

        assert callable(status)


class TestMCPDaemonInteraction:
    """Test MCP server communication with daemon."""

    def test_send_raw_connects_to_socket(self):
        """_send_raw should connect to Unix socket and send command."""
        from tldr.mcp_server import _send_raw, _get_socket_path

        with tempfile.TemporaryDirectory() as tmpdir:
            project = tmpdir
            socket_path = _get_socket_path(project)

            # Create a mock daemon server
            server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            server.bind(str(socket_path))
            server.listen(1)

            received = []

            def handle_connection():
                conn, _ = server.accept()
                data = conn.recv(4096)
                received.append(json.loads(data.decode().strip()))
                conn.sendall(json.dumps({"status": "ok"}).encode())
                conn.close()

            thread = threading.Thread(target=handle_connection)
            thread.start()

            try:
                result = _send_raw(project, {"cmd": "ping"})
                thread.join(timeout=2)

                assert result == {"status": "ok"}
                assert received[0] == {"cmd": "ping"}
            finally:
                server.close()
                if socket_path.exists():
                    socket_path.unlink()


class TestMCPToolIntegration:
    """Integration tests for MCP tools with actual daemon."""

    @pytest.fixture
    def temp_project(self):
        """Create a temporary project with test files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project = Path(tmpdir)

            # Create a Python file
            (project / "main.py").write_text("""
def hello():
    '''Say hello'''
    print("Hello, world!")

def goodbye():
    '''Say goodbye'''
    hello()
    print("Goodbye!")

class Greeter:
    def greet(self):
        hello()
""")

            (project / "test_main.py").write_text("""
from main import hello, goodbye

def test_hello():
    hello()

def test_goodbye():
    goodbye()
""")

            yield project

    @pytest.mark.integration
    def test_tree_with_running_daemon(self, temp_project):
        """tree tool should return file tree when daemon is running."""
        from tldr.mcp_server import tree, _ensure_daemon
        from tldr.daemon import stop_daemon

        try:
            _ensure_daemon(str(temp_project))
            result = tree(project=str(temp_project))

            assert result["status"] == "ok"
            assert "result" in result
        finally:
            stop_daemon(temp_project)

    @pytest.mark.integration
    def test_structure_with_running_daemon(self, temp_project):
        """structure tool should return code structure when daemon is running."""
        from tldr.mcp_server import structure, _ensure_daemon
        from tldr.daemon import stop_daemon

        try:
            _ensure_daemon(str(temp_project))
            result = structure(project=str(temp_project), language="python")

            assert result["status"] == "ok"
        finally:
            stop_daemon(temp_project)

    @pytest.mark.integration
    def test_search_with_running_daemon(self, temp_project):
        """search tool should find patterns when daemon is running."""
        from tldr.mcp_server import search, _ensure_daemon
        from tldr.daemon import stop_daemon

        try:
            _ensure_daemon(str(temp_project))
            result = search(project=str(temp_project), pattern="hello")

            assert result["status"] == "ok"
            assert "results" in result
        finally:
            stop_daemon(temp_project)

    @pytest.mark.integration
    def test_extract_with_running_daemon(self, temp_project):
        """extract tool should return file info when daemon is running."""
        from tldr.mcp_server import extract, _ensure_daemon
        from tldr.daemon import stop_daemon

        file_path = str(temp_project / "main.py")

        try:
            _ensure_daemon(str(temp_project))
            result = extract(file=file_path)

            assert result["status"] == "ok"
            assert "result" in result
        finally:
            stop_daemon(temp_project)

    @pytest.mark.integration
    def test_status_with_running_daemon(self, temp_project):
        """status tool should return daemon status when running."""
        from tldr.mcp_server import status, _ensure_daemon
        from tldr.daemon import stop_daemon

        try:
            _ensure_daemon(str(temp_project))
            result = status(project=str(temp_project))

            assert result["status"] in ["ok", "ready", "indexing"]
            assert "uptime" in result
        finally:
            stop_daemon(temp_project)


class TestDaemonAutoStart:
    """Test that daemon auto-starts when needed."""

    def test_ensure_daemon_starts_daemon(self):
        """_ensure_daemon should start daemon if not running."""
        from tldr.mcp_server import _ensure_daemon, _get_socket_path
        from tldr.daemon import stop_daemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = tmpdir
            socket_path = _get_socket_path(project)

            # Ensure no daemon is running
            stop_daemon(project)
            if socket_path.exists():
                socket_path.unlink()

            try:
                # This should start the daemon
                _ensure_daemon(project, timeout=15.0)

                # Socket should now exist
                assert socket_path.exists()
            finally:
                stop_daemon(project)

    def test_ensure_daemon_reuses_existing(self):
        """_ensure_daemon should reuse existing daemon."""
        from tldr.mcp_server import _ensure_daemon, _send_raw
        from tldr.daemon import stop_daemon, start_daemon

        with tempfile.TemporaryDirectory() as tmpdir:
            project = tmpdir

            try:
                # Start daemon first
                _ensure_daemon(project, timeout=15.0)

                # Get status before
                status1 = _send_raw(project, {"cmd": "status"})
                uptime1 = status1.get("uptime", 0)

                # Call ensure_daemon again
                time.sleep(0.2)
                _ensure_daemon(project, timeout=15.0)

                # Get status after
                status2 = _send_raw(project, {"cmd": "status"})
                uptime2 = status2.get("uptime", 0)

                # Uptime should have increased (same daemon)
                assert uptime2 >= uptime1
            finally:
                stop_daemon(project)


class TestMCPMainEntryPoint:
    """Test MCP server main entry point."""

    def test_main_function_exists(self):
        """main function should exist."""
        from tldr.mcp_server import main

        assert callable(main)

    def test_main_sets_project_env(self):
        """main should set TLDR_PROJECT environment variable."""
        import os
        from unittest.mock import patch, MagicMock

        mock_mcp = MagicMock()

        with patch("tldr.mcp_server.mcp", mock_mcp):
            with patch("sys.argv", ["tldr-mcp", "--project", "/test/project"]):
                # Import and call main
                from tldr.mcp_server import main
                try:
                    main()
                except SystemExit:
                    pass  # argparse may exit

                # mcp.run should have been called
                assert mock_mcp.run.called
