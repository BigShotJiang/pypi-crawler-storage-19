"""Tests for Swift CFG extraction.

TDD Tests for Swift language support in TLDR.
These tests are expected to FAIL initially until Swift support is implemented.

Swift tree-sitter node types:
- Function: function_declaration
- Call: call_expression
- Import: import_declaration
"""
import pytest

# Check if tree-sitter-swift is available
try:
    from tldr.cfg_extractor import extract_swift_cfg, TREE_SITTER_SWIFT_AVAILABLE
    SWIFT_AVAILABLE = TREE_SITTER_SWIFT_AVAILABLE
except ImportError:
    SWIFT_AVAILABLE = False


pytestmark = pytest.mark.skipif(not SWIFT_AVAILABLE, reason="tree-sitter-swift not available")


@pytest.fixture
def simple_if_code():
    return '''
class Example {
    func check(x: Int) -> String {
        if x > 0 {
            return "positive"
        }
        return "non-positive"
    }
}
'''


@pytest.fixture
def for_loop_code():
    return '''
class Example {
    func count(n: Int) -> Int {
        var sum = 0
        for i in 0..<n {
            sum += i
        }
        return sum
    }
}
'''


@pytest.fixture
def while_loop_code():
    return '''
class Example {
    func countdown(n: Int) -> Int {
        var count = 0
        var current = n
        while current > 0 {
            count += 1
            current -= 1
        }
        return count
    }
}
'''


@pytest.fixture
def nested_code():
    return '''
class Example {
    func process(items: [Item]) {
        for item in items {
            if item.isValid {
                handle(item)
            } else {
                skip(item)
            }
        }
    }
}
'''


@pytest.fixture
def do_catch_code():
    return '''
class Example {
    func divide(a: Int, b: Int) -> Int {
        do {
            guard b != 0 else {
                throw DivisionError.divideByZero
            }
            return a / b
        } catch {
            return 0
        }
    }
}
'''


@pytest.fixture
def switch_code():
    return '''
class Example {
    func getDay(day: Int) -> String {
        switch day {
        case 1:
            return "Monday"
        case 2:
            return "Tuesday"
        default:
            return "Unknown"
        }
    }
}
'''


@pytest.fixture
def guard_code():
    return '''
class Example {
    func processOptional(input: Int?) -> Int {
        guard let value = input else {
            return -1
        }
        return value * 2
    }
}
'''


class TestBasicCFG:
    """Test basic CFG extraction for Swift."""

    def test_simple_if(self, simple_if_code):
        cfg = extract_swift_cfg(simple_if_code, "check")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have entry, if-true, if-false (implicit), and exit blocks
        assert len(cfg.blocks) >= 3

    def test_for_loop(self, for_loop_code):
        cfg = extract_swift_cfg(for_loop_code, "count")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Should have loop structure
        assert len(cfg.edges) >= 2

    def test_while_loop(self, while_loop_code):
        cfg = extract_swift_cfg(while_loop_code, "countdown")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_guard_statement(self, guard_code):
        cfg = extract_swift_cfg(guard_code, "processOptional")
        assert cfg is not None
        assert len(cfg.blocks) > 0
        # Guard creates branching - should have multiple blocks
        assert len(cfg.blocks) >= 2


class TestAdvancedCFG:
    """Test advanced CFG patterns."""

    def test_nested_control_flow(self, nested_code):
        cfg = extract_swift_cfg(nested_code, "process")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_do_catch(self, do_catch_code):
        cfg = extract_swift_cfg(do_catch_code, "divide")
        assert cfg is not None
        assert len(cfg.blocks) > 0

    def test_switch(self, switch_code):
        cfg = extract_swift_cfg(switch_code, "getDay")
        assert cfg is not None
        assert len(cfg.blocks) > 0


class TestCFGStructure:
    """Test CFG structural properties."""

    def test_has_entry_block(self, simple_if_code):
        cfg = extract_swift_cfg(simple_if_code, "check")
        # Find entry block (id 0 or labeled "entry")
        entry_blocks = [b for b in cfg.blocks if b.id == 0 or "entry" in str(b.statements).lower()]
        assert len(entry_blocks) >= 1 or cfg.blocks[0].id == 0

    def test_edges_reference_valid_blocks(self, for_loop_code):
        cfg = extract_swift_cfg(for_loop_code, "count")
        block_ids = {b.id for b in cfg.blocks}
        for edge in cfg.edges:
            assert edge.source_id in block_ids, f"Edge source {edge.source_id} not in blocks"
            assert edge.target_id in block_ids, f"Edge destination {edge.target_id} not in blocks"

    def test_cyclomatic_complexity(self, switch_code):
        cfg = extract_swift_cfg(switch_code, "getDay")
        # Switch with 3 cases should have complexity >= 3
        assert cfg.cyclomatic_complexity >= 2


class TestErrorHandling:
    """Test error cases."""

    def test_function_not_found(self, simple_if_code):
        with pytest.raises(ValueError, match="not found"):
            extract_swift_cfg(simple_if_code, "nonexistent")
