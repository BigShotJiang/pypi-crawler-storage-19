from setuptools import setup, find_packages
from setuptools.command.build_py import build_py
import os

class CustomBuildPy(build_py):
    def run(self):
        super().run()
        internal_build_dir = os.path.join(
            self.build_lib, "conversational_graph", "_internal"
        )

        if os.path.exists(internal_build_dir):
            for filename in os.listdir(internal_build_dir):
                if filename.endswith(".py"):
                    os.remove(os.path.join(internal_build_dir, filename))

setup(
    name="videosdk-conversational-graph",
    version="0.0.3",
    packages=find_packages(),
    cmdclass={"build_py": CustomBuildPy},
    include_package_data=True,
    exclude_package_data={
        "conversational_graph": ["_internal/*.py"]
    },
)
