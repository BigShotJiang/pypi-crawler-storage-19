"""Platon CLI - Unified tool for Vault and Kubernetes operations"""

try:
    from importlib.metadata import version
    __version__ = version("platon-cli")
except Exception:
    __version__ = "unknown"

from .cli import cli, main
from .config import Config
from .vault import VaultManager
from .kubectl import KubectlManager
from .git import GitRepo

__all__ = [
    "cli",
    "main",
    "Config",
    "VaultManager",
    "KubectlManager",
    "GitRepo",
]
