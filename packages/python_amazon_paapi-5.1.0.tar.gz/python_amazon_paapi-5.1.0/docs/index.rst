.. python-amazon-paapi documentation master file, created by
   sphinx-quickstart on Mon Nov 22 18:33:43 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python Amazon PAAPI's documentation!
===============================================

A simple Python wrapper for the last version of the Amazon Product Advertising API. This module allows
interacting with Amazon using the official API in an easier way.

Reference
---------

.. toctree::

   amazon_paapi
   amazon_paapi.errors
   amazon_paapi.tools

Usage guide
---------------

.. toctree::
    :maxdepth: 1

    ./pages/usage-guide.md

Migration guide
---------------

If you are still using version 4.x or lower, it is highly recommended upgrading to the latest version.

.. toctree::
    :maxdepth: 1

    ./pages/migration-guide-4.md
    ./pages/migration-guide-5.md

Changelog
---------

See the `changelog <https://github.com/sergioteula/python-amazon-paapi/blob/master/CHANGELOG.md>`_ for a detailed history of changes.
