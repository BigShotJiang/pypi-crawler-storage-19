"""
FluxTokens SDK

Official SDK for the FluxTokens API - Access GPT-4.1, Gemini 2.5 and more
at 30% lower cost than competitors.

Example:
    >>> from fluxtokens import FluxTokens
    >>> 
    >>> client = FluxTokens(api_key="sk-flux-...")
    >>> 
    >>> response = client.chat.completions.create(
    ...     model="gpt-4.1-mini",
    ...     messages=[{"role": "user", "content": "Hello!"}]
    ... )
    >>> 
    >>> print(response.choices[0].message.content)
"""

from fluxtokens.client import FluxTokens, AsyncFluxTokens
from fluxtokens.types import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatMessage,
    Choice,
    Usage,
    Model,
    ModelInfo,
    MODELS,
)
from fluxtokens.errors import (
    FluxTokensError,
    AuthenticationError,
    RateLimitError,
    InsufficientBalanceError,
    BadRequestError,
    InternalServerError,
    TimeoutError,
    ConnectionError,
)

__version__ = "1.0.0"
__all__ = [
    # Client
    "FluxTokens",
    "AsyncFluxTokens",
    # Types
    "ChatCompletionRequest",
    "ChatCompletionResponse",
    "ChatMessage",
    "Choice",
    "Usage",
    "Model",
    "ModelInfo",
    "MODELS",
    # Errors
    "FluxTokensError",
    "AuthenticationError",
    "RateLimitError",
    "InsufficientBalanceError",
    "BadRequestError",
    "InternalServerError",
    "TimeoutError",
    "ConnectionError",
]
