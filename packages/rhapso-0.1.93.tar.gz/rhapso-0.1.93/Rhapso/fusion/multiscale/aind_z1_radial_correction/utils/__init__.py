"""
Utility functions
"""
