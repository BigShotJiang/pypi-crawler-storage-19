"""
CZI compression
"""
