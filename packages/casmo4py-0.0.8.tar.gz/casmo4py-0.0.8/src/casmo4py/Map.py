#! /usr/bin/env python3

""" """
import pygmt as pg
import pandas as pd
import numpy as np

# from casmo4py.Setup import Setup
from casmo4py.DataSelection import DataSelection


class Map(DataSelection):
    def __init__(
        self,
        fname="",
        lon=(0, 0),
        lat=(0, 0),
        quality=[],
        regime=[],
        typ=[],
        upper=0,
        lower=75,
        path_data="",
        path_output="",
        path_mean_data="",
        own_data="",
        cmap = '',
    ):
        """
        Args:
            bla (test.type): does blub
        """
        super().__init__(
            fname,
            lon,
            lat,
            quality,
            regime,
            typ,
            upper,
            lower,
            path_data,
            path_output,
            path_mean_data,
            own_data,
        )
        self.order = [
            "FMS",
            "FMF",
            "OC",
            "GFI",
            "GVA",
            "BO",
            "DIF",
            "HF",
            "PP",
            "MAG",
            "DIR",
        ]
        self.order_q = ["D", "C", "B", "A", "DIR"]
        self.fig = pg.Figure()
        self.cmap=cmap

    def hillshade(self, grid, normalize=10, azimuth=45):
        grd = pg.grdgradient(
            grid=grid,  # /home/tim/casmo_ap/gmt_files_casmo/ETOPO1_Bed_g_gmt4.grd
            region=self.region,
            normalize=normalize,
            azimuth=azimuth,
        )
        self.fig.grdimage(
            grid=grid,
            shading=grd,
            cmap=self.cmap,
            transparency=50,
        )

    def is_landscape(self, x, y):
        x_dif = abs(x[0] - x[1])
        y_dif = abs(y[0] - y[1])
        return x_dif / 180 > y_dif / 90

    def plot_stress_data(self, data):
        grp = data.groupby(["TYPE", "QUALITY", "REGIME"])
        for t in self.order:
            if t not in self.type:
                continue
            if t == "PP" or t == "MAG":
                try:
                    g = grp.get_group((t, t, t))
                    self.fig.plot(
                        x=g.LON,
                        y=g.LAT,
                        style="{}10p".format("c" if t == "PP" else "t"),
                        pen=f"{self.pen[t]}",
                        fill=f"{self.colors[t]}",
                    )
                except:
                    continue

            for q in self.order_q:
                if q not in self.quality:
                    continue
                for r in self.regime:
                    try:
                        g = grp.get_group((t, q, r))
                        if t == "FMS":
                            g = g.sort_values(by="DEPTH", ascending=False)
                        g = g[["LON", "LAT", "AZI", "LEN"]]
                        self.fig.plot(
                            x=g.LON,
                            y=g.LAT,
                            style="V0c+jc",
                            pen=f"{self.pen['stress_dir']},{self.colors[r]}",
                            direction=[g.AZI, g.LEN],
                        )
                        if not t == "DIR":
                            if t in ["FMA", "FMS", "FMF"]:
                                st = "c8p"
                            else:
                                st = f"k{t}/9p"
                            self.fig.plot(
                                g,
                                style=st,
                                pen=f"{self.pen['stress_dir']},{self.colors[r]}",
                            )
                    except:
                        continue

    def create_base(self, frame="af", projection="M20.5c"):
        self.fig.basemap(
            region=self.region,
            frame=frame,
            projection=projection,
        )

    def plot_coastline(self, grid):
        self.fig.grdcontour(
            grid=grid,
            levels=[0],
            pen=f"{self.pen['coastline']}",
        )

    def plot_water(self, thresh="400", rivers=True, polt_bound=False):
        self.fig.coast(
            resolution="intermediate",
            area_thresh=f"{thresh}/2",
            water=self.colors["water"],
            transparency=50,
            rivers=f"r/0.4p,{self.colors['water']}" if rivers else None,
            borders=f"a/0.4p,{self.colors['border']}" if polt_bound else None,
        )

    def plot_plate_boundaries(self):
        self.fig.plot(data=self.path_plate_boundary, pen=f"{self.pen['plate_bound']}")

    def convert(self, name, fmt, dpi=128):
        for f in fmt:
            self.fig.psconvert(prefix=self.path_output + name, fmt=f, dpi=dpi)


if __name__ == "__main__":
    reg = ["NF", "TF", "SS", "TS", "NS", "U", "DIR", "PP", "MAG"]
    typ = ["FMS", "FMF", "OC", "GFI", "GVA", "BO", "DIF", "HF", "PP", "MAG", "DIR"]
    qual = ["A", "B", "C", "D", "DIR", "PP", "MAG"]
    x = (5, 25)
    y = (55, 63)
    c = "/home/tim/casmo_ap/gmt_files_casmo/blue_gray.cpt",

    m = Map(x, y, qual, reg, typ, cmap=c)
    p = "/home/tim/casmo_ap/gmt_files_casmo/stress_data/wsm2025.csv"
    m.set_data_path(p)
    m.read_data()
    own_data = """60, 10, 0, PP, 0, PP, PP
59, 10, 0, PP, 0, PP, PP
60, 10, 0, MAG, 0, MAG, MAG
59, 10, 0, MAG, 0, MAG, MAG
59, 11, 0, DIR, 0, DIR, DIR
59, 12, 0, DIR, 0, DIR, DIR"""
    m.set_own_data(own_data)
    m.prepare_own_data()
    df_o = m.get_df_own()

    df = m.get_df_data()
    grid = "/home/tim/casmo_ap/gmt_files_casmo/ETOPO1_Bed_g_gmt4.grd"

    m.create_base()
    m.hillshade(grid)
    m.plot_coastline(grid)
    m.plot_water(rivers=False, polt_bound=True)
    # m.plot_plate_boundaries()
    m.plot_stress_data(df)
    m.plot_stress_data(df_o)
    m.convert("test", ["g", "f"])
