#! /usr/bin/env python3

""" """
from casmo4py.Map import Map
import pandas as pd


class Protocol(Map):
    def __init__(
        self,
        fname="",
        lon=(0, 0),
        lat=(0, 0),
        quality=[],
        regime=[],
        typ=[],
        upper=0,
        lower=75,
        path_data="",
        path_output="",
        path_mean_data="",
    ):
        """
        Args:
            bla (test.type): does blub
        """
        super().__init__(
            fname,
            lon,
            lat,
            quality,
            regime,
            typ,
            upper,
            lower,
            path_data,
            path_output,
            path_mean_data,
        )
        self.file = open(self.path_output + fname, "w")

        self.projections = {
            "M": "Mercator",
            "B": "Albers",
            "L": "Lambert (conical)",
            "A": "Lambert (azimuthal)",
        }

    def summary_data(self, data):
        dfs = pd.DataFrame(
            0, index=self.order + ["SUM"], columns=["SUM"] + self.quality
        )
        for d in data:
            grp = d.groupby(by=["TYPE", "QUALITY"])
            for t in d.TYPE.unique():
                if t in ["DIR", "PP", "MAG"]:
                    dfs.loc[t, "SUM"] += sum(d.TYPE == t)
                for q in d.QUALITY.unique():
                    try:
                        g = grp.get_group((t, q))
                        dfs.loc[t, q] += len(g)
                    except:
                        continue

        dfs.loc[:, "SUM"] = dfs.sum(axis=1)
        dfs.loc["SUM", :] = dfs.sum(axis=0)
        return dfs

    def write_summary_data(self, data):
        sum = self.summary_data(data)
        self.file.write(sum.to_string())

    def write_line(self, s):
        return

    def write_specs(self):
        return

    def save_protocol(self):
        self.file.close()


if __name__ == "__main__":
    path = "/home/tim/casmo/test/"
    df = pd.read_csv(path + "test_ptcl.csv")
    dfo = pd.read_csv(path + "test_ptcl2.csv")
    p = Protocol(fname="test.txt")
    p.set_types(["FMS", "FMA", "GFI", "MAG", "PP", "DIR"])
    p.set_qualities(["A", "B", "C", "D"])

    print(p.get_types())
    info = p.summary_data([df, dfo, df])
    print(info)
