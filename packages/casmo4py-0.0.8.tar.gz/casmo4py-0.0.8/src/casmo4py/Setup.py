#! /usr/bin/env python3

""" """


class Setup:
    def __init__(
        self,
        fname="",
        lon=(0, 0),
        lat=(0, 0),
        qual=[],
        reg=[],
        typ=[],
        upper=0,
        lower=75,
        path_data="",
        path_output="",
        path_mean_data="",
    ):
        """
        Args:
            bla (test.type): does blub
        """

        self.path_input = "/home/tim/casmo_ap/gmt_files_casmo/"
        self.path_output = path_output
        self.path_plate_boundary = self.path_input + "BIRD_plate_boundaries.dat"
        self.path_data = path_data
        self.path_mean_data = path_mean_data
        self.symbols = {}
        self.pen = {
            "PP": ".2p,black",
            "MAG": ".2p,black",
            "stress_dir": ".2p",
            "coastline": ".1p,black",
            "plate_bound": "0.8p,100/100/100",
        }

        self.vec_len_qual = {
            "A": 1.1,
            "B": 0.95,
            "C": 0.8,
            "D": 0.7,
            "DIR": 0.75,
        }
        self.colors = {
            "TF": "51/102/153",
            "TS": "51/102/153",
            "SS": "0/153/51",
            "NF": "204/0/0",
            "NS": "204/0/0",
            "DIR": "153/153/153",
            "PP": "102/204/255",
            "MAG": "255/255/51",
            "U": "0/0/0",
            "water": "22/135/183",
            "border": "160/32/240",
        }

        self.lat = lat
        self.lon = lon
        self.region = [*self.lon, *self.lat]
        self.quality = qual
        self.regime = reg
        self.type = typ
        self.upper = upper
        self.lower = lower

    def set_qualities(self, qual):
        self.quality = qual

    def get_qualities(self):
        return self.quality

    def set_regimes(self, reg):
        self.regime = reg

    def get_regimes(self):
        return self.regime

    def set_types(self, typ):
        self.type = typ

    def get_types(self):
        return self.type

    def set_lat(self, lat):
        self.lat = lat
        self.region[2:4] = [*lat]

    def get_lat(self):
        return self.lat

    def set_lon(self, lon):
        self.lon = lon
        self.region[0:2] = [*lon]

    def get_lon(self):
        return self.lon

    def set_input_path(self, path):
        self.path_input = path

    def get_input_path(self):
        return self.path_input

    def set_data_path(self, path):
        self.path_data = path

    def get_data_path(self):
        return self.path_data

    def set_mean_data_path(self, path):
        self.path_mean_data = path

    def get_mean_data_path(self):
        return self.path_mean_data

    def set_output_path(self, path):
        self.path_output = path

    def get_output_path(self):
        return self.path_output

    def set_plate_bound_path(self, path):
        self.path_plate_boundary = path

    def get_plate_bound_path(self):
        return self.path_plate_boundary

    def set_colors(self, key, col):
        if key in self.colors.keys():
            self.colors[key] = col
        else:
            print("No such item")

    def get_colors(self):
        return self.colors

    def set_vec_len(self, key, len):
        if key in self.vec_len_qual.keys():
            self.vec_len_qual[key] = len
        else:
            print("No such item")

    def get_vec_len(self):
        return self.vec_len_qual


if __name__ == "__main__":
    reg = ["NF", "TF", "SS", "TS", "NS", "U", "DIR", "PP", "MAG"]
    typ = ["FMS", "FMF", "OC", "GFI", "GVA", "BO", "DIF", "HF", "PP", "MAG", "DIR"]
    qual = ["A", "B", "C", "D", "DIR", "PP", "MAG"]
    x = (3, 15)
    y = (57, 63)

    s = Setup(x, y, qual, reg, typ)

    print(s.get_regimes())
    p = ("/home/tim/casmo_ap/gmt_files_casmo/stress_data/wsm2025.csv",)
    s.set_data_path(p)
    print(s.get_data_path())
