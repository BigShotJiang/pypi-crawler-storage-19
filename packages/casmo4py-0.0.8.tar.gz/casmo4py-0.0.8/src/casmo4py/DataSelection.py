#! /usr/bin/env python3

""" """
import pandas as pd
from casmo4.py.Setup import Setup

# from casmo4py.Utils import vec_len


class DataSelection(Setup):
    def __init__(
        self,
        fname="",
        lon=(0, 0),
        lat=(0, 0),
        quality=[],
        regime=[],
        typ=[],
        upper=0,
        lower=75,
        path_data="",
        path_output="",
        path_mean_data="",
        own_data="",
    ):
        """
        Args:
            bla (test.type): does blub
        """
        super().__init__(
            fname,
            lon,
            lat,
            quality,
            regime,
            typ,
            upper,
            lower,
            path_data,
            path_output,
            path_mean_data,
        )
        self.cols = ["LAT", "LON", "AZI", "TYPE", "DEPTH", "QUALITY", "REGIME"]

        self.own_data = own_data

        self.df_data = pd.DataFrame(columns=self.cols)
        self.df_mean = pd.DataFrame(columns=self.cols)
        self.df_own = pd.DataFrame(columns=self.cols)

    def set_columns(self, columns):
        self.cols = columns

    def get_columns(self):
        return self.cols

    def get_df_data(self, raw=False):
        df = self.crop_data(self.df_data, raw)
        return df

    def get_df_mean(self, raw=False):
        df = self.crop_data(self.df_mean, raw)
        return df

    def set_own_data(self, own_data):
        self.own_data = own_data
        self.prepare_own_data()

    def get_own_data(self):
        return self.own_data

    def get_df_own(self, raw=False):
        df = self.crop_data(self.df_own, raw)
        return df

    def read_data(self):
        self.df_data = pd.read_csv(self.path_data, low_memory=True)
        if self.path_mean_data != "":
            self.df_mean = pd.read_csv(self.path_mean_data)
            self.regime.append("DIR")
            self.type.append("DIR")
            self.quality.append("DIR")

    def prepare_own_data(self):
        if len(self.own_data) > 0:
            data = []
            if "\n" in self.own_data:
                od = self.own_data.replace(" ", "")
                od = od.split("\n")
                for d in od:
                    tmp = d.split(",")
                    data.append(tmp)
            else:
                tmp = od.split("\n")
                data.append(tmp)
            self.df_own = pd.DataFrame.from_records(data, columns=self.cols)

    def crop_data(self, df, raw=False):
        def vec_len(row):
            x = row.QUALITY
            try:
                return self.vec_len_qual[x]
            except:
                return 0

        df = df.astype({"LAT": "float64", "LON": "float64", "DEPTH": "float64"})
        df = df[
            (df.LON >= self.region[0])
            & (df.LON <= self.region[1])
            & (df.LAT >= self.region[2])
            & (df.LAT <= self.region[3])
            & (df.DEPTH >= self.upper)
            & (df.DEPTH <= self.lower)
        ]
        df = df[
            (df.REGIME.isin(self.regime))
            & (df.TYPE.isin(self.type))
            & (df.QUALITY.isin(self.quality))
        ]
        if raw:
            return df
        else:
            df = df[self.cols]
            df["LEN"] = df.apply(vec_len, axis=1)
            return df


if __name__ == "__main__":
    reg = ["NF", "TF", "SS", "TS", "NS", "U", "DIR", "PP", "MAG"]
    typ = ["FMS", "FMF", "OC", "GFI", "GVA", "BO", "DIF", "HF", "PP", "MAG", "DIR"]
    qual = ["A", "B", "C", "D", "DIR", "PP", "MAG"]
    x = (3, 20)
    y = (57, 63)

    ds = DataSelection(x, y, qual, reg, typ)

    print(ds.get_regimes())
    p = "/home/tim/casmo_ap/gmt_files_casmo/stress_data/wsm2025.csv"
    ds.set_data_path(p)
    print(ds.path_data[0])
    # print(ds.get_coordinates())-> Setup
    # ds.set_path_wsm("~/casmo/data/wsm2025.csv")->setup
    ds.read_data()
    df = ds.get_df_data()
    print(df.head())
    own_data = """61.376, 18.171, 138, PP, 0.32, PP, PP
59.376, 18.171, 138, PP, 0.32, PP, PP
59.376, 18.171, 138, DIR, 0.32, DIR, DIR
60.376, 17.171, 138, DIR, 0.32, DIR, DIR
60.376, 17.171, 138, MAG, 0.32, MAG, MAG
61.376, 19.171, 138, MAG, 0.32, MAG, MAG"""
    ds.set_own_data(own_data)

    dfo = ds.get_df_own()
    print(dfo)
    # ds.set_path_mean("~/casmo/data/mean_SHmax_r250_02.csv")

    df = ds.get_df_data()
    print(df.head())
    df.to_csv("../../test/test_ptcl.csv", index=False)
    dfo.to_csv("../../test/test_ptcl2.csv", index=False)
