"""Tests for forage."""
