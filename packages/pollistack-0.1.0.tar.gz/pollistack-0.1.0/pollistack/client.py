import httpx
import json
from typing import Optional, Dict, Any, List

class PolliClient:
    def __init__(self, api_key: str, base_url: str = "http://129.153.168.156:8000"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json"
        }

    async def chat(self, prompt: str, user_id: str, app_id: Optional[str] = None, model: str = "qwen-coder") -> str:
        """Send a prompt to the agent and get a response."""
        url = f"{self.base_url}/chat"
        headers = self.headers.copy()
        headers["x-user-id"] = user_id
        if app_id:
            headers["X-App-ID"] = app_id
        
        payload = {
            "prompt": prompt,
            "user_id": user_id,
            "model": model
        }
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            return response.json().get("response", "")

    async def sync(self, query: str, user_id: str, content: Optional[str] = None, app_id: Optional[str] = None) -> Dict[str, Any]:
        """Synchronize memory and retrieve context in one call."""
        url = f"{self.base_url}/sync"
        headers = self.headers.copy()
        headers["x-user-id"] = user_id
        if app_id:
            headers["X-App-ID"] = app_id
        
        payload = {
            "query": query,
            "content": content,
            "user_id": user_id
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            return response.json()

    async def retrieve(self, query: str, user_id: str, app_id: Optional[str] = None) -> str:
        """Retrieve relevant context for a query."""
        url = f"{self.base_url}/retrieve"
        headers = self.headers.copy()
        headers["x-user-id"] = user_id
        if app_id:
            headers["X-App-ID"] = app_id
        
        payload = {
            "query": query,
            "user_id": user_id
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url, headers=headers, json=payload)
            response.raise_for_status()
            return response.json().get("context", "")

    async def remember(self, prompt: str, response: str, user_id: str, app_id: Optional[str] = None) -> Dict[str, str]:
        """Manually trigger memory extraction from an interaction."""
        url = f"{self.base_url}/remember"
        headers = self.headers.copy()
        headers["x-user-id"] = user_id
        if app_id:
            headers["X-App-ID"] = app_id
        
        payload = {
            "prompt": prompt,
            "response": response,
            "user_id": user_id
        }
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(url, headers=headers, json=payload)
            resp.raise_for_status()
            return resp.json()

    async def get_graph(self, user_id: str, limit: int = 50, app_id: Optional[str] = None) -> Dict[str, Any]:
        """Fetch the current memory graph."""
        url = f"{self.base_url}/graph"
        params = {"limit": limit}
        headers = self.headers.copy()
        headers["x-user-id"] = user_id
        if app_id:
            headers["X-App-ID"] = app_id
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response.json()
