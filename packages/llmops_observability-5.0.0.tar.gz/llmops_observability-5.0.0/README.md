# LLMOps Observability SDK

A lightweight Python SDK for LLM observability with **direct Langfuse integration**. No SQS queues, no batching, no worker threads - just instant tracing to Langfuse.

## Key Features

- ⚡ **Instant Tracing**: Sends traces directly to Langfuse in real-time
- 🎯 **Simple API**: Same decorators as veriskGO (`@track_function`, `@track_llm_call`)
- 🚫 **No Complexity**: No SQS queues, no batching, no background workers
- 🔄 **Sync & Async**: Supports both synchronous and asynchronous functions
- 🎨 **Provider Agnostic**: Works with any LLM provider (Bedrock, OpenAI, Anthropic, etc.)

## Comparison with veriskGO

| Feature | veriskGO | llmops-observability |
|---------|----------|---------------------|
| Trace Destination | SQS → Lambda → Langfuse | Direct to Langfuse |
| Batching | Yes | No |
| Worker Threads | Yes | No |
| Latency | Queued/Batched | Instant |
| Complexity | High | Low |
| Use Case | Production at scale | Development/Testing |

## Installation

```bash
cd llmops-observability
pip install -e .
```

## Quick Start

### 1. Configure Environment Variables

Create a `.env` file:

```bash
LANGFUSE_PUBLIC_KEY=pk-lf-...
LANGFUSE_SECRET_KEY=sk-lf-...
LANGFUSE_BASE_URL=https://your-langfuse-instance.com
LANGFUSE_VERIFY_SSL=false  # Optional, default is true
```

### 2. Use in Your Code

```python
from llmops_observability import TraceManager, track_function, track_llm_call

# Start a trace
TraceManager.start_trace(
    name="my_workflow",
    user_id="user_123",
    session_id="session_456",
    metadata={"environment": "development"}
)

# Track regular functions
@track_function()
def process_data(input_data):
    # Your code here
    return {"processed": input_data}

# Track LLM calls
@track_llm_call()
def call_bedrock(prompt):
    # Call your LLM
    response = bedrock_client.converse(
        modelId="anthropic.claude-3-sonnet",
        messages=[{"role": "user", "content": prompt}]
    )
    return response

# Use the functions
result = process_data("some data")
llm_response = call_bedrock("Hello, world!")

# End the trace (flushes to Langfuse)
TraceManager.end_trace()
```

### 3. Async Support

```python
@track_function()
async def async_process(data):
    return await some_async_operation(data)

@track_llm_call(name="summarize")
async def async_llm_call(text):
    return await chain.ainvoke({"text": text})
```

## Configuration

### Environment Variables

- `LANGFUSE_PUBLIC_KEY`: Your Langfuse public key (required)
- `LANGFUSE_SECRET_KEY`: Your Langfuse secret key (required)
- `LANGFUSE_BASE_URL`: Your Langfuse instance URL (required)
- `LANGFUSE_VERIFY_SSL`: Whether to verify SSL certificates (optional, default: `true`)

### Programmatic Configuration

```python
from llmops_observability import configure

configure(
    public_key="pk-lf-...",
    secret_key="sk-lf-...",
    base_url="https://your-langfuse.com",
    verify_ssl=False
)
```

## API Reference

### TraceManager

#### `start_trace(name, user_id=None, session_id=None, metadata=None, tags=None)`
Start a new trace.

```python
TraceManager.start_trace(
    name="my_workflow",
    user_id="user_123",
    session_id="session_456",
    metadata={"env": "dev"},
    tags=["experiment"]
)
```

#### `end_trace()`
End the current trace and flush to Langfuse.

```python
TraceManager.end_trace()
```

### Decorators

#### `@track_function(name=None, tags=None)`
Track regular function execution.

```python
@track_function()
def my_function(x, y):
    return x + y

@track_function(name="custom_name", tags={"version": "1.0"})
def another_function():
    pass
```

#### `@track_llm_call(name=None, tags=None, extract_output=True)`
Track LLM generation calls.

```python
@track_llm_call()
def call_llm(prompt):
    return llm.invoke(prompt)

@track_llm_call(name="summarize", tags={"model": "claude-3"})
def summarize(text):
    return llm.summarize(text)
```

## Response Format Support

The `@track_llm_call` decorator automatically extracts text from various LLM response formats:

- AWS Bedrock Converse API
- Anthropic Messages API
- Amazon Titan
- Cohere
- AI21
- OpenAI
- Generic text responses

## Project Structure

```
llmops-observability/
├── src/
│   └── llmops_observability/
│       ├── __init__.py          # Public API
│       ├── config.py             # Langfuse client configuration
│       ├── trace_manager.py     # TraceManager & @track_function
│       ├── llm.py                # @track_llm_call decorator
│       └── models.py             # SpanContext model
├── pyproject.toml
└── README.md
```

## Example: Complete Workflow

```python
from llmops_observability import TraceManager, track_function, track_llm_call
import boto3

# Initialize Bedrock client
bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")

@track_function()
def retrieve_context(query):
    # Simulate RAG retrieval
    return {"documents": ["Context doc 1", "Context doc 2"]}

@track_llm_call()
def generate_answer(prompt, context):
    response = bedrock.converse(
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        messages=[{
            "role": "user",
            "content": f"Context: {context}\n\nQuestion: {prompt}"
        }]
    )
    return response

# Start trace
TraceManager.start_trace(
    name="rag_pipeline",
    user_id="user_123",
    metadata={"pipeline": "v1"}
)

# Execute workflow
context = retrieve_context("What is Python?")
answer = generate_answer("What is Python?", context)

# End trace
TraceManager.end_trace()
```

## When to Use This SDK

✅ **Use llmops-observability when:**
- Developing and testing LLM applications
- You want instant trace visibility in Langfuse
- Simple, straightforward tracing without infrastructure

✅ **Use veriskGO when:**
- Running in production at scale
- Need decoupled, async tracing via SQS
- Want batching and optimized throughput
- Need complex observability pipelines

## License

TODO: Add license

## Contributing

TODO: Add contribution guidelines
