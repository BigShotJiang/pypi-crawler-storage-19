"""
LLM tracking decorator for LLMOps Observability
Direct Langfuse integration for tracking LLM calls
Enhanced with veriskGO-style input/output handling
"""
from __future__ import annotations
import functools
import inspect
import time
import traceback
from typing import Optional, Dict, Any
from .trace_manager import TraceManager


def extract_text(resp: Any) -> str:
    """
    Extract text from various LLM response formats.
    Supports: Bedrock Converse, Bedrock InvokeModel, OpenAI, LangChain, etc.
    """
    if isinstance(resp, str):
        return resp

    if not isinstance(resp, dict):
        return str(resp)

    # Bedrock Converse API
    try:
        return resp["output"]["message"]["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Anthropic Messages API
    try:
        return resp["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Amazon Titan
    try:
        return resp["results"][0]["outputText"]
    except (KeyError, IndexError, TypeError):
        pass

    # Cohere
    try:
        return resp["generation"]
    except (KeyError, TypeError):
        pass

    # AI21
    try:
        return resp["outputs"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Generic text field
    try:
        return resp["text"]
    except (KeyError, TypeError):
        pass

    # OpenAI format
    try:
        return resp["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        pass

    return str(resp)


def track_llm_call(
    name: Optional[str] = None,
    *,
    tags: Optional[Dict[str, Any]] = None,
    extract_output: bool = True,
):
    """
    Decorator to track LLM calls with Langfuse as generations.
    
    Enhanced version inspired by veriskGO with proper input/output handling.
    
    Usage:
        @track_llm_call()
        def call_bedrock(prompt):
            response = bedrock.converse(...)
            return response
            
        @track_llm_call(name="summarize", tags={"model": "claude-3"})
        async def summarize(text):
            return await chain.ainvoke(...)
    
    Args:
        name: Optional custom name for the generation
        tags: Optional metadata tags
        extract_output: Whether to extract text from LLM response
    """
    def decorator(func):
        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)
        
        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    return await func(*args, **kwargs)

                # Build input - extract prompt if first arg is string
                if args and isinstance(args[0], str):
                    input_data = {
                        "prompt": args[0],
                        "args": args[1:],
                        "kwargs": kwargs,
                    }
                else:
                    input_data = {
                        "args": args,
                        "kwargs": kwargs,
                    }

                # Start observation context (this will be parent for nested calls)
                obs_ctx = TraceManager.start_observation_context(span_name, "generation", input_data)
                
                if not obs_ctx:
                    return await func(*args, **kwargs)

                error = None
                result = None
                start_time = time.time()
                
                # Use the observation context properly with 'with' statement
                with obs_ctx as obs:
                    # Push observation onto stack so nested calls become children
                    TraceManager.push_observation(obs)
                    
                    try:
                        result = await func(*args, **kwargs)
                    except Exception as e:
                        error = e
                        raise
                    finally:
                        # Pop observation from stack
                        TraceManager.pop_observation()
                        duration_ms = int((time.time() - start_time) * 1000)
                        
                        # Build output
                        if error:
                            output_data = {
                                "status": "error",
                                "error": str(error),
                                "stacktrace": traceback.format_exc(),
                            }
                        else:
                            # Extract text from response if enabled
                            if extract_output:
                                try:
                                    text_output = extract_text(result)
                                    output_data = {
                                        "status": "success",
                                        "text": text_output,
                                        "raw": result,
                                    }
                                except Exception:
                                    output_data = {
                                        "status": "success",
                                        "raw": result,
                                    }
                            else:
                                output_data = {
                                    "status": "success",
                                    "raw": result,
                                }
                        
                        # Update observation with output
                        from .trace_manager import serialize_value
                        obs.update(
                            output=serialize_value(output_data),
                            metadata=tags or {},
                            level="ERROR" if error else "DEFAULT",
                            status_message=str(error) if error else None,
                        )
                
                # Flush after exiting context
                from .config import get_langfuse_client
                langfuse = get_langfuse_client()
                langfuse.flush()
                
                status_str = " (error)" if error else ""
                print(f"[LLMOps-Observability] Generation sent{status_str}: {span_name} ({duration_ms}ms)")
                
                return result
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    return func(*args, **kwargs)

                # Build input - extract prompt if first arg is string
                if args and isinstance(args[0], str):
                    input_data = {
                        "prompt": args[0],
                        "args": args[1:],
                        "kwargs": kwargs,
                    }
                else:
                    input_data = {
                        "args": args,
                        "kwargs": kwargs,
                    }

                # Start observation context (this will be parent for nested calls)
                obs_ctx = TraceManager.start_observation_context(span_name, "generation", input_data)
                
                if not obs_ctx:
                    return func(*args, **kwargs)

                error = None
                result = None
                start_time = time.time()
                
                # Use the observation context properly with 'with' statement
                with obs_ctx as obs:
                    # Push observation onto stack so nested calls become children
                    TraceManager.push_observation(obs)
                    
                    try:
                        result = func(*args, **kwargs)
                    except Exception as e:
                        error = e
                        raise
                    finally:
                        # Pop observation from stack
                        TraceManager.pop_observation()
                        
                        duration_ms = int((time.time() - start_time) * 1000)
                        
                        # Build output
                        if error:
                            output_data = {
                                "status": "error",
                                "error": str(error),
                                "stacktrace": traceback.format_exc(),
                            }
                        else:
                            # Extract text from response if enabled
                            if extract_output:
                                try:
                                    text_output = extract_text(result)
                                    output_data = {
                                        "status": "success",
                                        "text": text_output,
                                        "raw": result,
                                    }
                                except Exception:
                                    output_data = {
                                        "status": "success",
                                        "raw": result,
                                    }
                            else:
                                output_data = {
                                    "status": "success",
                                    "raw": result,
                                }
                        
                        # Update observation with output
                        from .trace_manager import serialize_value
                        obs.update(
                            output=serialize_value(output_data),
                            metadata=tags or {},
                            level="ERROR" if error else "DEFAULT",
                            status_message=str(error) if error else None,
                        )
                
                # Flush after exiting context
                from .config import get_langfuse_client
                langfuse = get_langfuse_client()
                langfuse.flush()
                
                status_str = " (error)" if error else ""
                print(f"[LLMOps-Observability] Generation sent{status_str}: {span_name} ({duration_ms}ms)")
                
                return result
            
            return sync_wrapper
    
    return decorator


