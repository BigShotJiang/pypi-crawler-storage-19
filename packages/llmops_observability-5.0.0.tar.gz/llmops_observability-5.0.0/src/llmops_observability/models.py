"""
Data models for LLMOps Observability
"""
from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import time


@dataclass
class SpanContext:
    """
    Context holder for span execution.
    Provides all necessary data for span creation and finalization.
    """
    trace_id: str
    span_id: str
    parent_span_id: Optional[str]
    start_time: float
    span_name: str
    span_type: str = "span"  # "span" or "generation"
    tags: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Captured inputs/outputs
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Optional[Any] = None
    error: Optional[Exception] = None
    
    @property
    def duration_ms(self) -> int:
        """Calculate duration in milliseconds"""
        return int((time.time() - self.start_time) * 1000)
