


class InMemoryDocumentContentError(Exception):
    pass