# drevix/__init__.py
import requests
import time
import threading
import json
import os

# =====================================================
# 1. كلاس التخزين المحلي (الخزنة الخاصة بك)
# =====================================================
class LocalDB:
    def __init__(self, filename):
        self.filename = filename
        self.data = self._load()

    def _load(self):
        """تحميل البيانات من الملف المحلي"""
        if os.path.exists(self.filename):
            try:
                with open(self.filename, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def _save(self):
        """حفظ البيانات في الملف المحلي"""
        with open(self.filename, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=4)

    def set(self, key, value):
        """حفظ قيمة معينة (مثل النقاط)"""
        self.data[str(key)] = value
        self._save()

    def get(self, key, default=None):
        """جلب قيمة معينة"""
        return self.data.get(str(key), default)

# =====================================================
# 2. كلاس البوت الرئيسي
# =====================================================
class Bot:
    def __init__(self, token):
        self.token = token
        # رابط قاعدتك (تأكد من صحته)
        self.db_url = "https://test-e7f1b-default-rtdb.firebaseio.com"
        self.handlers = []
        self.running = False
        
        # 🔥 إنشاء قاعدة بيانات محلية خاصة بهذا البوت تلقائياً
        # سيتم إنشاء ملف باسم مثل: local_data_token123.json
        safe_token = token[-5:] if len(token) > 5 else token
        self.local = LocalDB(f"local_data_{safe_token}.json")

    def send_message(self, chat_id, text):
        """إرسال رسالة إلى Firebase"""
        url = f"{self.db_url}/chat_rooms/{self.token}/{chat_id}.json"
        # نستخدم push (POST) لإضافة رسالة جديدة دون حذف القديم
        data = {
            "msg": text,
            "sender": "bot",
            "type": "text",
            "timestamp": {".sv": "timestamp"}
        }
        try:
            requests.post(url, json=data)
        except:
            pass

    def message_handler(self, func):
        """Decorator لاستقبال الرسائل"""
        self.handlers.append(func)
        return func

    def polling(self):
        """تشغيل البوت والاستماع للرسائل"""
        print(f"🚀 Drevix Library v2.0 (Local Storage Edition) - Started...")
        print(f"📂 Local DB File: local_data_{self.token[-5:]}.json")
        
        self.running = True
        while self.running:
            try:
                # جلب آخر الرسائل
                url = f"{self.db_url}/chat_rooms/{self.token}.json?orderBy=\"$key\"&limitToLast=10"
                response = requests.get(url, timeout=10)
                
                if response.status_code == 200 and response.json():
                    data = response.json()
                    self._process_messages(data)
            except Exception as e:
                # تجاهل أخطاء الاتصال المؤقتة
                pass 
            time.sleep(1.0) # سرعة التحديث

    def _process_messages(self, data):
        """معالجة الرسائل الواردة"""
        if not isinstance(data, dict): return

        for user_id, chats in data.items():
            if isinstance(chats, dict):
                for msg_id, content in chats.items():
                    # التحقق: هل هي رسالة جديدة من المستخدم؟
                    if content.get('status') == 'pending' and content.get('sender') == 'user':
                        
                        # 1. تغيير الحالة إلى "مقرؤة" فوراً في Firebase (لكي لا نرد عليها مرتين)
                        update_url = f"{self.db_url}/chat_rooms/{self.token}/{user_id}/{msg_id}.json"
                        requests.patch(update_url, json={"status": "read"})

                        # 2. تمرير الرسالة للكود الخاص بك
                        msg_obj = Message(user_id, content.get('msg'), self, msg_id)
                        for handler in self.handlers:
                            # تشغيل الرد في خط منفصل لعدم تعليق البوت
                            threading.Thread(target=handler, args=(msg_obj,)).start()

# =====================================================
# 3. كلاس الرسالة (التعامل مع الردود)
# =====================================================
class Message:
    def __init__(self, chat_id, text, bot, msg_id):
        self.chat_id = chat_id
        self.text = text
        self.bot = bot
        self.id = msg_id # معرف الرسالة في فايربيس

    def reply(self, text):
        """الرد على الرسالة"""
        self.bot.send_message(self.chat_id, text)
        
    def delete(self):
        """(اختياري) حذف الرسالة تماماً من فايربيس لتطبيق نظام الشبح"""
        url = f"{self.bot.db_url}/chat_rooms/{self.bot.token}/{self.chat_id}/{self.id}.json"
        try:
            requests.delete(url)
        except:
            pass
