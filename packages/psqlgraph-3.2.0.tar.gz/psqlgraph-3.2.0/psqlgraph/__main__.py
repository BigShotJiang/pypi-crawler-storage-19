import argparse
import getpass
from psqlgraph import psql


try:
    import ipython

    has_ipython = True
except Exception as e:
    print(
        (
            (
                "{}, using standard interactive console. "
                "If you install IPython, then it will automatically "
                "be used for this repl."
            ).format(e)
        )
    )
    import code

    has_ipython = False


message = """
Entering psqlgraph console:
    database : {}
    host     : {}
    user     : {}

NOTE:
    PsqlGraphDriver stored in local variable `g`.
    A `g.session_scope` session is at `s`.
    `rb()` will rollback the session.
"""


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-d",
        "--database",
        default="test",
        type=str,
        help="name of the database to connect to",
    )
    parser.add_argument(
        "-i",
        "--host",
        default="localhost",
        type=str,
        help="host of the postgres server",
    )
    parser.add_argument(
        "-u", "--user", default="test", type=str, help="user to connect to postgres as"
    )
    parser.add_argument(
        "-p",
        "--password",
        default=None,
        type=str,
        help="password for given user. If no " "password given, one will be prompted.",
    )

    args = parser.parse_args()

    print(message.format(args.database, args.host, args.user))
    if args.password is None:
        args.password = getpass.getpass()

    g = psql.PsqlGraphDriver(args.host, args.user, args.password, args.database)

    with g.session_scope() as s:
        rb = s.rollback
        if has_ipython:
            ipython.embed()
        else:
            code.InteractiveConsole(locals=globals()).interact()
