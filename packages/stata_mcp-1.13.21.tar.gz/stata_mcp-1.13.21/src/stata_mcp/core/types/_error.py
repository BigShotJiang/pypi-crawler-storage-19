class StataMCPError(Exception):
    pass
