from __future__ import annotations

from typing import TYPE_CHECKING

from pytest import Config, ExitCode, Parser, hookimpl

from .no_problem_text import NO_PROBLEM_TEXT

if TYPE_CHECKING:
    from _pytest.terminal import (
        TerminalReporter,  # pyright: ignore[reportPrivateImportUsage]
    )


@hookimpl
def pytest_addoption(parser: Parser) -> None:
    """Register argparse-style options and config-style config values."""
    parser.addini(
        name="no_problem_width",
        help="Width of no-problem output. Should be a minimum of 40.",
        default="80",
    )
    parser.addoption(
        "--no-problem-width",
        help="Width of no-problem output. Should be a minimum of 40.",
    )


@hookimpl
def pytest_terminal_summary(
    terminalreporter: TerminalReporter,
    exitstatus: int,
    config: Config,
) -> None:
    """Add a section to terminal summary reporting."""
    if exitstatus != ExitCode.OK:
        return

    max_width = int(
        config.getoption("--no-problem-width", default=None)
        or config.getini("no_problem_width"),
    )
    output_text = next(
        (output for width, output in NO_PROBLEM_TEXT.items() if width <= max_width),
        "",
    )

    terminalreporter.section(title="no problem")
    terminalreporter.write(output_text)
