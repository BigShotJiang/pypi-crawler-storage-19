"""Nova Agent - Browser automation agent for Nova QA platform."""

__version__ = "0.3.5"
__all__ = ["__version__"]
