====================================
Ansible Changelog Tool Release Notes
====================================

.. contents:: Topics

v0.35.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Antsibull-changelog now also depends on antsibull-docs-parser (https://github.com/ansible-community/antsibull-changelog/pull/213).
- Declare support for Python 3.14 (https://github.com/ansible-community/antsibull-changelog/pull/207).
- Process Ansible markup in plugin/module/role ``short_description`` (https://github.com/ansible-community/antsibull-changelog/issues/207, https://github.com/ansible-community/antsibull-changelog/pull/213).

v0.34.0
=======

Release Summary
---------------

Feature release for antsibull-build.

Minor Changes
-------------

- The ``RSTDocumentRenderer`` API now allows to configure section underlines. This is needed to fix the Ansible 12 porting guide (https://github.com/ansible-community/antsibull-changelog/pull/203).

v0.33.0
=======

Release Summary
---------------

Maintenance release for fixing / deprecating certain boolean options.

Breaking Changes / Porting Guide
--------------------------------

- The ``--strict`` option of the ``lint-changelog-yaml`` subcommand no longer expects a parameter. It now matches what was documented (https://github.com/ansible-community/antsibull-changelog/issues/195, https://github.com/ansible-community/antsibull-changelog/pull/196).

Deprecated Features
-------------------

- The boolean valued options ``--is-collection`` and ``--collection-flatmap`` will likely change to proper flags (``--flag`` and `--no-flag`` instead of ``--flag true``/``--flag false``) in the near future. If you are using these options and want them to not change, or have other suggestions, please `create an issue in the antsibull-changelog repository <https://github.com/ansible-community/antsibull-changelog/issues/new>`__ (https://github.com/ansible-community/antsibull-changelog/pull/199).

v0.32.0
=======

Release Summary
---------------

Feature release.

Major Changes
-------------

- The new configuration setting ``output`` allows to configure more precisely which changelog files are generated and how they are formatted (https://github.com/ansible-community/antsibull-changelog/issues/190, https://github.com/ansible-community/antsibull-changelog/pull/194).

Minor Changes
-------------

- Antsibull-changelog now depends on Pydantic 2 (https://github.com/ansible-community/antsibull-changelog/pull/193).
- Antsibull-changelog now uses Pydantic to parse and validate the config. This means that validation is more strict than before and might reject configs that were incorrect, but still got accepted somehow (https://github.com/ansible-community/antsibull-changelog/pull/193).

Breaking Changes / Porting Guide
--------------------------------

- When using antsibull-changelog as a library, ``ChangelogConfig``'s constructor should no longer be called directly. Instead, use the class method ``ChangelogConfig.parse()``, which has the same signature than the previous constructor, except that ``ignore_is_other_project`` now must be a keyword parameter (https://github.com/ansible-community/antsibull-changelog/pull/193).
- When using antsibull-changelog as a library, ``rendering.changelog.generate_changelog()`` now needs a ``ChangelogOutput`` object instead of the ``document_format: TextFormat`` parameter, and the ``config`` and ``changelog_path`` parameters have been removed (https://github.com/ansible-community/antsibull-changelog/pull/194).
- When using the ``--output`` argument for ``antsibull-changelog generate``, the generated changelog's title will not contain any parts of the version number. If you need this, `please create an issue <https://github.com/ansible-community/antsibull-changelog/issues/new>`__ (https://github.com/ansible-community/antsibull-changelog/pull/194).

Deprecated Features
-------------------

- The configuration settings ``changelog_filename_template``, ``changelog_filename_version_depth``, and ``output_formats`` are deprecated and will eventually be removed. Use the new setting ``output`` instead. Note that there are no runtime warnings right now. If the time to remove them comes nearer, there will be runtime warnings for a longer time first before they are actually removed (https://github.com/ansible-community/antsibull-changelog/pull/194).

Removed Features (previously deprecated)
----------------------------------------

- Python API: remove ``antsibull_changelog.rst`` module (https://github.com/ansible-community/antsibull-changelog/pull/183).
- Python API: remove constructor arguments ``plugins`` and ``fragments`` from class ``ChangelogGenerator`` in ``antsibull_changelog.rendering.changelog`` (https://github.com/ansible-community/antsibull-changelog/pull/183).
- Python API: remove method ``ChangelogEntry.add_section_content``, class ``ChangelogGenerator``, and function ``generate_changelog`` from ``antsibull_changelog.changelog_generator`` (https://github.com/ansible-community/antsibull-changelog/pull/183).
- When using antsibull-changelog as a library, the fields ``changelog_filename_template``, ``changelog_filename_version_depth``, and ``output_formats`` are no longer available in ``ChangelogConfig``. Use ``output`` instead (https://github.com/ansible-community/antsibull-changelog/pull/194).

v0.31.2
=======

Release Summary
---------------

Bugfix release.

Bugfixes
--------

- When linting found RST problems with rstcheck, the error messages were reduced to a single letter (https://github.com/ansible-community/antsibull-changelog/pull/188).

v0.31.1
=======

Release Summary
---------------

Bugfix release for ansible-core.

Bugfixes
--------

- Fix ``namespace`` extraction for ansible-core modules (https://github.com/ansible-community/antsibull-changelog/issues/184, https://github.com/ansible-community/antsibull-changelog/pull/185).

v0.31.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Add ``--strict`` parameter to the ``lint-changelog-yaml`` subcommand to also check for extra fields that should not be there (https://github.com/ansible-community/antsibull-changelog/pull/182).
- Declare support for Python 3.13 (https://github.com/ansible-community/antsibull-changelog/pull/180).
- Python API: allow to extract extra data when loading changelog files, and allow to insert extra data when saving (https://github.com/ansible-community/antsibull-changelog/pull/181).
- Python API: allow to preprocess changelog.yaml before linting (https://github.com/ansible-community/antsibull-changelog/pull/181).

Breaking Changes / Porting Guide
--------------------------------

- More internal code related to the old changelog format has been removed. This only potentially affects other projects which consume antsibull-changelog as a library. The sister antsibull projects antsibull-build and antsibull-docs might only be affected in older versions. **Users of the antsibull-changelog CLI tool are not affected by this change** (https://github.com/ansible-community/antsibull-changelog/pull/179).

v0.30.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Allow to configure the used VCS in ``changelogs/config.yml``. Valid choices are ``none`` (default), ``git``, or ``auto``. If set to ``git``, or ``auto`` detects that the project is part of a Git repository, only non-ignored files will be copied to a temporary directory when trying to load information on Ansible modules, plugins and roles (https://github.com/ansible-community/antsibull-changelog/issues/172, https://github.com/ansible-community/antsibull-changelog/pull/175).
- Antsibull-changelog now depends on the new package antsibull-docutils. This should not have any visible impact, expect potentially improved MarkDown output (https://github.com/ansible-community/antsibull-changelog/pull/174).
- Antsibull-changelog now depends on the new project antsibull-fileutils (https://github.com/ansible-community/antsibull-changelog/pull/176).
- If you are using `argcomplete <https://pypi.org/project/argcomplete/>`__ global completion, you can now tab-complete ``antsibull-changelog`` command lines. See `Activating global completion <https://pypi.org/project/argcomplete/#activating-global-completion>`__ in the argcomplete README for how to enable tab completion globally. This will also tab-complete Ansible commands such as ``ansible-playbook`` and ``ansible-test`` (https://github.com/ansible-community/antsibull-changelog/pull/173).

v0.29.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Add a ``reformat`` command that reformats ``changelogs/changelog.yaml`` to the current settings of ``changelogs/config.yaml`` (https://github.com/ansible-community/antsibull-changelog/pull/169).
- Adds a new configuration option ``changelog_sort``. This option allows sorting of changelog entries in ``changelogs/changelog.yaml`` (https://github.com/ansible-community/antsibull-changelog/pull/165).
- Replaces numbers with constants for return codes (https://github.com/ansible-community/antsibull-changelog/issues/77).

Removed Features (previously deprecated)
----------------------------------------

- Removes support for the deprecated classic changelog format. ``changes_format`` must now be present and set to ``combined`` for ansible-core usage, and the value ``classic`` is no longer allowed (https://github.com/ansible-community/antsibull-changelog/issues/137).

Bugfixes
--------

- Remove Python version check that was checking for Python >= 3.6 (instead of >= 3.9). This check is not really necessary since ``pyproject.toml`` declares ``requires-python``, and old enough Python versions where pip does not know about ``requires-python`` will not load antsibull-changelog due to syntax errors anyway (https://github.com/ansible-community/antsibull-changelog/pull/167).

v0.28.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- There is now an option ``changelog_nice_yaml`` to prepend the YAML document start
  marker ``---`` to the header of the ``changelogs/changelog.yaml`` file, and to increases
  indentation level on list items. This makes the file pass ansible-lint
  (https://github.com/ansible-community/antsibull-changelog/issues/91,
  https://github.com/ansible-community/antsibull-changelog/issues/152,
  https://github.com/ansible-community/antsibull-changelog/pull/160).

v0.27.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Adds period where needed at end of new plugin short descriptions. Controlled by the ``add_plugin_period`` option in the config file (https://github.com/ansible-community/antsibull-changelog/issues/87, https://github.com/ansible-community/antsibull-changelog/pull/162).

v0.26.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- The Markdown output format is now compatible with `python-markdown <https://python-markdown.github.io/>`_ and `mkdocs <https://www.mkdocs.org/>`_, as long as the `pymdownx.escapeall <https://facelessuser.github.io/pymdown-extensions/extensions/escapeall/>`_ extension is enabled (https://github.com/ansible-community/antsibull-changelog/pull/153).

v0.25.0
=======

Release Summary
---------------

Bugfix and feature release.

Minor Changes
-------------

- Add ``--version`` flag to print package version and exit (https://github.com/ansible-community/antsibull-changelog/pull/147).

Bugfixes
--------

- When multiple output formats are defined and ``antsibull-changelog generate`` is used with both ``--output`` and ``--output-format``, an error was displayed that ``--output-format`` must be specified (https://github.com/ansible-community/antsibull-changelog/issues/149, https://github.com/ansible-community/antsibull-changelog/pull/151).

v0.24.0
=======

Release Summary
---------------

Feature release which now allows to output MarkDown.

Minor Changes
-------------

- Allow automatically retrieving package version for hatch projects with the ``hatch version`` command (https://github.com/ansible-community/antsibull-changelog/pull/141).
- Allow to render changelogs as MarkDown. The output formats written can be controlled with the ``output_formats`` option in the config file (https://github.com/ansible-community/antsibull-changelog/pull/139).
- Officially support Python 3.12 (https://github.com/ansible-community/antsibull-changelog/pull/134).

Deprecated Features
-------------------

- Some code in ``antsibull_changelog.changelog_entry`` has been deprecated, and the ``antsibull_changelog.rst`` module has been deprecated completely. If you use them in your own code, please take a look at the `PR deprecating them <https://github.com/ansible-community/antsibull-changelog/pull/139>`__ for information on how to stop using them (https://github.com/ansible-community/antsibull-changelog/pull/139).

v0.23.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Allow to generate changelog for a specific version (https://github.com/ansible-community/antsibull-changelog/pull/130).
- Allow to generate only the last entry without preamble with the ``generate`` command (https://github.com/ansible-community/antsibull-changelog/pull/131).
- Allow to write ``generate`` output to a user-provided file (https://github.com/ansible-community/antsibull-changelog/pull/131).

v0.22.0
=======

Release Summary
---------------

New feature release

Minor Changes
-------------

- Add ``antsibull-changelog-lint`` and ``antsibull-changelog-lint-changelog-yaml`` pre-commit.com hooks (https://github.com/ansible-community/antsibull-changelog/pull/125).
- Add ``toml`` extra to pull in a toml parser to use to guess the version based on ``pyproject.toml`` (https://github.com/ansible-community/antsibull-changelog/pull/126).

v0.21.0
=======

Release Summary
---------------

Maintenance release with a deprecation.

Deprecated Features
-------------------

- Support for ``classic`` changelogs is deprecated and will be removed soon. If you need to build changelogs for Ansible 2.9 or before, please use an older version (https://github.com/ansible-community/antsibull-changelog/pull/123).

v0.20.0
=======

Release Summary
---------------

Bugfix and maintenance release using a new build system.

Major Changes
-------------

- Change pyproject build backend from ``poetry-core`` to ``hatchling``. ``pip install antsibull`` works exactly the same as before, but some users may be affected depending on how they build/install the project (https://github.com/ansible-community/antsibull-changelog/pull/109).

Bugfixes
--------

- When releasing ansible-core and only one of ``--version`` and ``--codename`` is supplied, error out instead of ignoring the supplied value (https://github.com/ansible-community/antsibull-changelog/issues/104, https://github.com/ansible-community/antsibull-changelog/pull/105).

v0.19.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Allow to extract other project versions for JavaScript / TypeScript projects from ``package.json`` (https://github.com/ansible-community/antsibull-changelog/pull/100).
- Allow to extract other project versions for Python projects from PEP 621 conformant ``pyproject.toml`` (https://github.com/ansible-community/antsibull-changelog/pull/100).
- Support Python 3.11's ``tomllib`` to load ``pyproject.toml`` (https://github.com/ansible-community/antsibull-changelog/issues/101, https://github.com/ansible-community/antsibull-changelog/pull/102).
- Use more specific exceptions than ``Exception`` for some cases in internal code (https://github.com/ansible-community/antsibull-changelog/pull/103).

v0.18.0
=======

Release Summary
---------------

Maintenance release that drops support for older Python versions.

Breaking Changes / Porting Guide
--------------------------------

- Drop support for Python 3.6, 3.7, and 3.8 (https://github.com/ansible-community/antsibull-changelog/pull/93).

v0.17.0
=======

Release Summary
---------------

Feature release for ansible-core.

Minor Changes
-------------

- Only allow a ``trival`` section in the ansible-core/ansible-base changelog when explicitly configured (https://github.com/ansible-community/antsibull-changelog/pull/90).

v0.16.0
=======

Release Summary
---------------

Feature and bugfix release.

Minor Changes
-------------

- Allow to extract other project versions for Python poetry projects from ``pyproject.toml`` (https://github.com/ansible-community/antsibull-changelog/pull/80).
- The files in the source repository now follow the `REUSE Specification <https://reuse.software/spec/>`_. The only exceptions are changelog fragments in ``changelogs/fragments/`` (https://github.com/ansible-community/antsibull-changelog/pull/82).

Bugfixes
--------

- Mark rstcheck 4.x and 5.x as compatible. Support rstcheck 6.x as well (https://github.com/ansible-community/antsibull-changelog/pull/81).

v0.15.0
=======

Release Summary
---------------

Feature release.

Minor Changes
-------------

- Add ``changelogs/changelog.yaml`` file format linting subcommand that was previously part of antsibull-lint (https://github.com/ansible-community/antsibull-changelog/pull/76, https://github.com/ansible-community/antsibull/issues/410).

v0.14.0
=======

Release Summary
---------------

Feature release that will speed up the release process with ansible-core 2.13.

Minor Changes
-------------

- The internal ``changelog.yaml`` linting API allows to use ``packaging.version.Version`` for version numbers instead of semantic versioning (https://github.com/ansible-community/antsibull-changelog/pull/73).
- Use the new ``--metadata-dump`` option for ansible-core 2.13+ to quickly dump and extract all module/plugin ``version_added`` values for the collection (https://github.com/ansible-community/antsibull-changelog/pull/72).

v0.13.0
=======

Release Summary
---------------

This release makes changelog building more reliable.

Minor Changes
-------------

- Always lint fragments before releasing (https://github.com/ansible-community/antsibull-changelog/issues/65, https://github.com/ansible-community/antsibull-changelog/pull/67).

Bugfixes
--------

- Fix issues with module namespaces when symlinks appear in the path to the temp directory (https://github.com/ansible-community/antsibull-changelog/issues/68, https://github.com/ansible-community/antsibull-changelog/pull/69).
- Stop mentioning ``galaxy.yaml`` instead of ``galaxy.yml`` in some error messages (https://github.com/ansible-community/antsibull-changelog/pull/66).

v0.12.0
=======

Release Summary
---------------

New feature release which supports other projects than ansible-core and Ansible collections.

Minor Changes
-------------

- Support changelogs for other projects than ansible-core/-base and Ansible collections (https://github.com/ansible-community/antsibull-changelog/pull/60).

Bugfixes
--------

- Fix prerelease collapsing when ``use_semantic_versioning`` is set to ``true`` for ansible-core.

v0.11.0
=======

Minor Changes
-------------

- When using ansible-core 2.11 or newer, will now detect new roles with argument spec. We only consider the ``main`` entrypoint of roles.

Bugfixes
--------

- When subdirectories of ``modules`` are used in ansible-base/ansible-core, the wrong module name was passed to ``ansible-doc`` when ``--use-ansible-doc`` was not used.

v0.10.0
=======

Minor Changes
-------------

- The new ``--cummulative-release`` option for ``antsibull-changelog release`` allows to add all plugins and objects to a release since whose ``version_added`` is later than the previous release version (or ancestor if there was no previous release), and at latest the current release version. This is needed for major releases of ``community.general`` and similarly organized collections.
- Will now print a warning when a release is made where the no ``prelude_section_name`` section (default: ``release_summary``) appears.

Bugfixes
--------

- Make sure that the plugin caching inside ansible-base/-core works without ``--use-ansible-doc``.

v0.9.0
======

Major Changes
-------------

- Add support for reporting new playbooks and roles in collections.
- Add support for special changelog fragment sections which add new plugins and/or objects to the changelog for this version. This is mainly useful for ``test`` and ``filter`` plugins, and for ``playbook`` and ``role`` objects, which are not yet automatically detected and mentioned in ``changelogs/changelog.yaml`` or the generated RST changelog.

  The format of these sections and their content is as follows::

      ---
      add plugin.filter:
        - name: to_time_unit
          description: Converts a time expression to a given unit
        - name: to_seconds
          description: Converts a time expression to seconds
      add object.role:
        - name: nginx
          description: The most awesome nginx installation role ever
      add object.playbook:
        - name: wipe_server
          description: Totally wipes a server

  For every entry, a list of plugins (section ``add plugin.xxx``) or objects (section ``add object.xxx``) of the given type (``filter``, ``test`` for plugins, ``playbook``, ``role`` for objects) will be added. Every plugin or object has a short name as well as a short description. These fields correspond to the module/plugin name and the ``short_description`` field of the ``DOCUMENTATION`` block of modules and documentable plugins.

Minor Changes
-------------

- Add ``--update-existing`` option for ``antsibull-changelog release``, which allows to update the current release's release date and (if relevant) codename instead of simply reporting that the release already exists.

Breaking Changes / Porting Guide
--------------------------------

- The new option ``prevent_known_fragments`` with default value being the value of ``keep_fragments`` allows to control whether fragments with names that already appeared in the past are ignored or not. The new behavior happens if ``keep_fragments=false``, and is less surprising to users (see https://github.com/ansible-community/antsibull-changelog/issues/46). Changelogs with ``keep_fragments=true``, like the ansible-base/ansible-core changelog, are not affected.

v0.8.1
======

Bugfixes
--------

- Fixed error on generating changelogs when using the trivial section.

v0.8.0
======

Minor Changes
-------------

- Allow to not save a changelog on release when using API.
- Allow to sanitize changelog data on load/save. This means that unknown information will be removed, and bad information will be stripped. This will be enabled in newly created changelog configs, but is disabled for backwards compatibility.

v0.7.0
======

Minor Changes
-------------

- A new config option, ``ignore_other_fragment_extensions`` allows for configuring whether only ``.yaml`` and ``.yml`` files are used (as mandated by the ``ansible-test sanity --test changelog`` test). The default value for existing configurations is ``false``, and for new configurations ``true``.
- Allow to use semantic versioning also for Ansible-base with the ``use_semantic_versioning`` configuration setting.
- Refactoring changelog generation code to provide all preludes (release summaries) in changelog entries, and provide generic functionality to extract a grouped list of versions. These changes are mainly for the antsibull project.

v0.6.0
======

Minor Changes
-------------

- New changelog configurations place the ``CHANGELOG.rst`` file by default in the top-level directory, and not in ``changelogs/``.
- The config option ``archive_path_template`` allows to move fragments into an archive directory when ``keep_fragments`` is set to ``false``.
- The option ``use_fqcn`` (set to ``true`` in new configurations) allows to use FQCN for new plugins and modules.

v0.5.0
======

Minor Changes
-------------

- The internal changelog generator code got more flexible to help antsibull generate Ansible porting guides.

v0.4.0
======

Minor Changes
-------------

- Allow to enable or disable flatmapping via ``config.yaml``.

Bugfixes
--------

- Fix bad module namespace detection when collection was symlinked into Ansible's collection search path. This also allows to add releases to collections which are not installed in a way that Ansible finds them.

v0.3.1
======

Bugfixes
--------

- Do not fail when ``changelogs/fragments`` does not exist. Simply assume there are no fragments in that case.
- Improve behavior when ``changelogs/config.yaml`` is not a dictionary, or does not contain ``sections``.
- Improve error message when ``--is-collection`` is specified and ``changelogs/config.yaml`` cannot be found, or when the ``lint`` subcommand is used.

v0.3.0
======

Minor Changes
-------------

- Allow to pass path to ansible-doc binary via ``--ansible-doc-bin``.
- Changelog generator can be ran via ``python -m antsibull_changelog``.
- Use ``ansible-doc`` instead of ``/path/to/checkout/bin/ansible-doc`` when being run in ansible-base checkouts.

v0.2.1
======

Bugfixes
--------

- Allow to enumerate plugins/modules with ansible-doc by specifying ``--use-ansible-doc``.

v0.2.0
======

Minor Changes
-------------

- Added more testing.
- Fix internal API for ACD changelog generation (pruning and concatenation of changelogs).
- Improve error handling.
- Improve reStructuredText creation when new modules with and without namespace exist at the same time.
- Title generation improved (remove superfluous space).
- Use PyYAML C loader/dumper if available.
- ``lint`` subcommand no longer requires specification whether it is run inside a collection or not (if usual indicators are absent).

v0.1.0
======

Release Summary
---------------

Initial release as antsibull-changelog. The Ansible Changelog Tool has originally been developed by @mattclay in `the ansible/ansible <https://github.com/ansible/ansible/blob/stable-2.9/packaging/release/changelogs/changelog.py>`_ repository for Ansible itself. It has been extended in `felixfontein/ansible-changelog <https://github.com/felixfontein/ansible-changelog/>`_ and `ansible-community/antsibull <https://github.com/ansible-community/antsibull/>`_ to work with collections, until it was moved to its current location `ansible-community/antsibull-changelog <https://github.com/ansible-community/antsibull-changelog/>`_.
