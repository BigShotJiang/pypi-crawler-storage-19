"""Tests for finlab-sentinel."""
