from django.apps import AppConfig


class StaticEngineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'static_engine'
