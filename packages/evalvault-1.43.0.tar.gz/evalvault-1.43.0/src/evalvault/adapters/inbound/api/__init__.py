"""EvalVault REST API Adapter."""
