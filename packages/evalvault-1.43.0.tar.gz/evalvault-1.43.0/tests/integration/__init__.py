"""Integration tests for EvalVault."""
