"""LLM configuration resolution and CLI building for Obra.

Handles model validation, thinking level mapping, config resolution, and CLI argument
construction for all supported LLM providers (Anthropic, OpenAI, Google).

Example:
    from obra.config.llm import resolve_llm_config, build_llm_args

    config = resolve_llm_config("orchestrator", override_model="sonnet")
    args = build_llm_args(config, mode="text")
"""

import logging
import shutil
import uuid
from typing import Any

from .loaders import load_config, save_config
from .providers import (
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
)

# Module logger
logger = logging.getLogger(__name__)

# Default thinking level
DEFAULT_THINKING_LEVEL = "medium"

# Abstract thinking levels (user-facing, provider-agnostic)
# Maps to provider-specific parameters in build_llm_args()
THINKING_LEVELS = ["off", "low", "medium", "high", "maximum"]

# Provider-specific thinking level mappings
# See docs/reference/llm-providers/ for official documentation
THINKING_LEVEL_MAP = {
    "anthropic": {
        # Claude Code V2 - only "ultrathink" keyword allocates thinking tokens
        # Intermediate levels (think, think hard) were deprecated in V2
        # See: docs/reference/llm-providers/claude-code-thinking.md
        "off": None,  # No thinking, don't use ultrathink
        "low": None,  # No intermediate levels exist
        "medium": None,  # No intermediate levels exist
        "high": None,  # No intermediate levels exist
        "maximum": "ultrathink",  # Only keyword that allocates thinking tokens (31,999)
    },
    "openai": {
        # Codex CLI model_reasoning_effort values
        # See: docs/reference/llm-providers/openai-codex-reasoning.md
        "off": "minimal",  # Minimize reasoning overhead
        "low": "low",
        "medium": "medium",  # Default
        "high": "high",
        "maximum": "xhigh",  # Only gpt-5.1-codex-max and gpt-5.2
    },
    "google": {
        # Gemini CLI - no reasoning effort control available
        "off": None,
        "low": None,
        "medium": None,
        "high": None,
        "maximum": None,
    },
}

# Known model shortcuts for quick switching
# Full model names (e.g., "claude-sonnet-4-5") are passed through
MODEL_SHORTCUTS = {"default", "sonnet", "opus", "haiku"}

# Models that support xhigh/maximum reasoning effort
# Used by get_effective_thinking_value() for fallback logic
XHIGH_SUPPORTED_MODELS: dict[str, set[str]] = {
    "openai": {"gpt-5.2", "gpt-5.1-codex-max"},  # xhigh only on flagship models
    "anthropic": set(),  # All Claude models support ultrathink (prompt keyword)
    "google": set(),  # Gemini has no reasoning effort control
}

# Model name patterns for provider inference (regex)
# Used by infer_provider_from_model() to auto-detect provider
MODEL_PROVIDER_PATTERNS: dict[str, str] = {
    # Anthropic/Claude patterns
    r"^opus$": "anthropic",
    r"^sonnet$": "anthropic",
    r"^haiku$": "anthropic",
    r"^claude": "anthropic",  # claude-*, claude-3-*, etc.
    # OpenAI/Codex patterns
    r"^gpt": "openai",  # gpt-4, gpt-5.2, etc.
    r"^o[134]": "openai",  # o1, o3, o4 models
    r"^codex": "openai",  # codex-*, codex-mini, etc.
    # Google/Gemini patterns
    r"^gemini": "google",  # gemini-2.5-*, gemini-3-*, etc.
}

# Model name prefixes for fast provider inference (non-regex fallback)
MODEL_PROVIDER_PREFIXES: dict[str, str] = {
    "opus": "anthropic",
    "sonnet": "anthropic",
    "haiku": "anthropic",
    "claude": "anthropic",
    "gpt": "openai",
    "o1": "openai",
    "o3": "openai",
    "o4": "openai",
    "codex": "openai",
    "gemini": "google",
}


def infer_provider_from_model(model: str) -> str | None:
    """Infer the LLM provider from a model name.

    Uses regex patterns first (MODEL_PROVIDER_PATTERNS), then falls back
    to prefix matching (MODEL_PROVIDER_PREFIXES).

    Args:
        model: Model name to analyze (e.g., "opus", "gpt-5.2", "gemini-2.5-flash")

    Returns:
        Provider name ("anthropic", "openai", "google") or None if unknown

    Examples:
        >>> infer_provider_from_model("opus")
        'anthropic'
        >>> infer_provider_from_model("gpt-5.2")
        'openai'
        >>> infer_provider_from_model("gemini-2.5-flash")
        'google'
        >>> infer_provider_from_model("custom-model")
        None
    """
    import re  # noqa: PLC0415

    if not model or model == "default":
        return None

    model_lower = model.lower()

    # Try regex patterns first (most precise)
    for pattern, provider in MODEL_PROVIDER_PATTERNS.items():
        if re.match(pattern, model_lower):
            return provider

    # Fall back to prefix matching
    for prefix, provider in MODEL_PROVIDER_PREFIXES.items():
        if model_lower.startswith(prefix):
            return provider

    return None


def get_thinking_level_notes(
    provider: str,
    thinking_level: str,
    model: str | None = None,
) -> list[str]:
    """Get user-facing notes about thinking level behavior for a provider.

    Provides feedback about how the selected thinking level maps to
    provider-specific behavior, including limitations and recommendations.

    Args:
        provider: LLM provider name
        thinking_level: Abstract thinking level (off, low, medium, high, maximum)
        model: Optional model name for model-specific notes

    Returns:
        List of note strings to display to the user

    Examples:
        >>> get_thinking_level_notes("anthropic", "maximum")
        ['Using "ultrathink" prompt keyword for extended thinking (31,999 tokens)']

        >>> get_thinking_level_notes("google", "high")
        ['Gemini CLI does not support reasoning effort control']

        >>> get_thinking_level_notes("openai", "maximum", "gpt-5.1")
        ['xhigh reasoning not supported on gpt-5.1, using "high" instead']
    """
    notes = []

    # Provider-specific notes
    if provider == "anthropic":
        if thinking_level == "maximum":
            notes.append('Using "ultrathink" prompt keyword for extended thinking (31,999 tokens)')
        elif thinking_level in ("low", "high"):
            notes.append(
                f'Claude Code V2 only supports "off" (no thinking) or "maximum" (ultrathink). '
                f'Level "{thinking_level}" has no effect.'
            )

    elif provider == "openai":
        # Check xhigh support
        if thinking_level == "maximum":
            supported = XHIGH_SUPPORTED_MODELS.get("openai", set())
            if model and model not in supported:
                notes.append(f'xhigh reasoning not supported on {model}, using "high" instead')
                notes.append(f'For xhigh, use: {", ".join(sorted(supported))}')
            else:
                notes.append("Using xhigh reasoning effort for maximum analysis")

    elif provider == "google" and thinking_level != "off":
        notes.append("Gemini CLI does not support reasoning effort control")

    return notes


def get_effective_thinking_value(
    provider: str,
    thinking_level: str,
    model: str | None = None,
) -> str | None:
    """Get the effective provider-specific thinking value with fallback.

    Maps abstract thinking level to provider-specific value, applying
    fallback logic for unsupported configurations (e.g., xhigh -> high
    for OpenAI models that don't support xhigh).

    Args:
        provider: LLM provider name
        thinking_level: Abstract thinking level (off, low, medium, high, maximum)
        model: Optional model name for model-specific fallback

    Returns:
        Provider-specific thinking value (e.g., "xhigh", "high", "ultrathink")
        or None if the provider doesn't support the level

    Examples:
        >>> get_effective_thinking_value("openai", "maximum", "gpt-5.2")
        'xhigh'
        >>> get_effective_thinking_value("openai", "maximum", "gpt-5.1")
        'high'  # Fallback - xhigh not supported
        >>> get_effective_thinking_value("anthropic", "maximum")
        'ultrathink'
        >>> get_effective_thinking_value("google", "high")
        None  # No reasoning control
    """
    provider_map = THINKING_LEVEL_MAP.get(provider, {})
    base_value = provider_map.get(thinking_level)

    # Apply fallback logic for OpenAI xhigh
    if provider == "openai" and thinking_level == "maximum":
        supported = XHIGH_SUPPORTED_MODELS.get("openai", set())
        if model and model not in supported:
            # Fall back to high
            return provider_map.get("high", "high")

    return base_value


def validate_model(model: str, provider: str = DEFAULT_PROVIDER) -> str:
    """Validate and normalize a model name.

    Supports two types of model names:
    1. Shortcuts: default, sonnet, opus, haiku (validated against provider)
    2. Full model names: claude-sonnet-4-5, gpt-4o, etc. (passthrough)

    Args:
        model: Model name to validate (shortcut or full name)
        provider: Provider to validate against for shortcuts

    Returns:
        Validated model name (unchanged)

    Raises:
        ValueError: If shortcut is not valid for the given provider
    """
    if not model:
        return DEFAULT_MODEL

    # Shortcuts are validated against provider's model list
    if model in MODEL_SHORTCUTS:
        provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
        valid_models = provider_info.get("models", [])
        if model not in valid_models:
            raise ValueError(
                f"Model '{model}' not valid for provider '{provider}'. "
                f"Valid: {', '.join(valid_models)}"
            )
        return model

    # Full model names are passed through without validation
    # This allows users to use specific model versions like "claude-sonnet-4-5"
    return model


def resolve_llm_config(
    role: str,
    override_provider: str | None = None,
    override_model: str | None = None,
    override_auth_method: str | None = None,
    override_thinking_level: str | None = None,
) -> dict[str, Any]:
    """Resolve LLM configuration for a role with optional overrides.

    Resolution order (highest to lowest priority):
    1. Session overrides (passed as arguments)
    2. Global config file (~/.obra/client-config.yaml)
    3. Defaults (anthropic, oauth, default, medium)

    Args:
        role: "orchestrator" or "implementation"
        override_provider: Optional provider override (session-only)
        override_model: Optional model override (session-only)
        override_auth_method: Optional auth method override (session-only)
        override_thinking_level: Optional thinking level override (session-only)

    Returns:
        Resolved config dict with provider, auth_method, model, thinking_level keys
        and optional parse retry controls.
    """
    if role not in ("orchestrator", "implementation"):
        raise ValueError(f"Invalid role: {role}")

    # Get base config from global config file
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    # Start with defaults
    resolved = {
        "provider": role_config.get("provider", DEFAULT_PROVIDER),
        "auth_method": role_config.get("auth_method", DEFAULT_AUTH_METHOD),
        "model": role_config.get("model", DEFAULT_MODEL),
        "thinking_level": role_config.get("thinking_level", DEFAULT_THINKING_LEVEL),
        "parse_retry_enabled": role_config.get("parse_retry_enabled", True),
        "parse_retry_providers": role_config.get("parse_retry_providers"),
        "parse_retry_models": role_config.get("parse_retry_models"),
    }

    # Apply overrides (session-only, don't persist)
    if override_provider:
        if override_provider not in LLM_PROVIDERS:
            raise ValueError(f"Invalid provider: {override_provider}")
        resolved["provider"] = override_provider

    if override_auth_method:
        if override_auth_method not in LLM_AUTH_METHODS:
            raise ValueError(f"Invalid auth method: {override_auth_method}")
        resolved["auth_method"] = override_auth_method

    if override_model:
        # Validate model against resolved provider
        resolved["model"] = validate_model(override_model, resolved["provider"])

    if override_thinking_level:
        if override_thinking_level not in THINKING_LEVELS:
            raise ValueError(
                f"Invalid thinking level: {override_thinking_level}. "
                f"Valid: {', '.join(THINKING_LEVELS)}"
            )
        resolved["thinking_level"] = override_thinking_level

    return resolved


def get_llm_config() -> dict[str, Any]:
    """Get LLM configuration from config file.

    Returns:
        Dictionary with LLM config for both orchestrator and implementation:
        {
            "orchestrator": {
                "provider": "anthropic",
                "auth_method": "oauth",
                "model": "default",
                "thinking_level": "medium"
            },
            "implementation": {
                "provider": "anthropic",
                "auth_method": "oauth",
                "model": "default",
                "thinking_level": "medium"
            }
        }
    """
    config = load_config()
    default_config = {
        "orchestrator": {
            "provider": DEFAULT_PROVIDER,
            "auth_method": DEFAULT_AUTH_METHOD,
            "model": DEFAULT_MODEL,
            "thinking_level": DEFAULT_THINKING_LEVEL,
        },
        "implementation": {
            "provider": DEFAULT_PROVIDER,
            "auth_method": DEFAULT_AUTH_METHOD,
            "model": DEFAULT_MODEL,
            "thinking_level": DEFAULT_THINKING_LEVEL,
        },
    }
    return config.get("llm", default_config)


def set_llm_config(
    role: str,  # "orchestrator" or "implementation"
    provider: str,
    auth_method: str,
    model: str = "default",
    thinking_level: str = "medium",
) -> None:
    """Set LLM configuration for a specific role.

    Args:
        role: "orchestrator" or "implementation"
        provider: LLM provider (anthropic, openai, google)
        auth_method: Auth method (oauth, api_key)
        model: Model to use (default recommended for oauth)
        thinking_level: Abstract thinking level (off, low, medium, high, maximum)
            Maps to provider-specific values via THINKING_LEVEL_MAP

    Raises:
        ValueError: If any parameter is invalid
    """
    if role not in ("orchestrator", "implementation"):
        raise ValueError(f"Invalid role: {role}. Must be 'orchestrator' or 'implementation'")

    if provider not in LLM_PROVIDERS:
        raise ValueError(f"Invalid provider: {provider}. Valid: {list(LLM_PROVIDERS.keys())}")

    if auth_method not in LLM_AUTH_METHODS:
        raise ValueError(
            f"Invalid auth method: {auth_method}. Valid: {list(LLM_AUTH_METHODS.keys())}"
        )

    provider_info = LLM_PROVIDERS[provider]
    if model not in provider_info["models"]:
        raise ValueError(
            f"Invalid model '{model}' for {provider}. Valid: {provider_info['models']}"
        )

    if thinking_level not in THINKING_LEVELS:
        raise ValueError(
            f"Invalid thinking level: {thinking_level}. " f"Valid: {', '.join(THINKING_LEVELS)}"
        )

    config = load_config()
    if "llm" not in config:
        config["llm"] = get_llm_config()

    config["llm"][role] = {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
        "thinking_level": thinking_level,
    }

    save_config(config)


def get_llm_display(role: str) -> str:
    """Get a human-readable display string for LLM config.

    Args:
        role: "orchestrator" or "implementation"

    Returns:
        Display string like "Anthropic (OAuth, default)"
    """
    llm_config = get_llm_config()
    role_config = llm_config.get(role, {})

    provider = role_config.get("provider", DEFAULT_PROVIDER)
    auth_method = role_config.get("auth_method", DEFAULT_AUTH_METHOD)
    model = role_config.get("model", DEFAULT_MODEL)

    provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
    auth_name = "OAuth" if auth_method == "oauth" else "API Key"

    return f"{provider_name} ({auth_name}, {model})"


def get_thinking_keyword(resolved_config: dict[str, str]) -> str | None:
    """Get the thinking keyword to prepend to prompts (Claude Code only).

    Claude Code V2 uses prompt keywords (not CLI args) to trigger extended thinking.
    Only "ultrathink" allocates thinking tokens; other levels were deprecated.

    Args:
        resolved_config: Resolved config dict from resolve_llm_config()

    Returns:
        "ultrathink" if provider is anthropic and thinking_level is maximum,
        None otherwise.

    Example:
        >>> get_thinking_keyword({"provider": "anthropic", "thinking_level": "maximum"})
        "ultrathink"
        >>> get_thinking_keyword({"provider": "anthropic", "thinking_level": "high"})
        None
        >>> get_thinking_keyword({"provider": "openai", "thinking_level": "maximum"})
        None  # OpenAI uses CLI args, not keywords
    """
    provider = resolved_config.get("provider", DEFAULT_PROVIDER)
    thinking_level = resolved_config.get("thinking_level", DEFAULT_THINKING_LEVEL)

    if provider == "anthropic" and thinking_level == "maximum":
        return "ultrathink"
    return None


def build_llm_args(resolved_config: dict[str, str], mode: str = "text") -> list[str]:
    """Build CLI arguments from resolved LLM configuration.

    Generates provider-specific CLI arguments including the --model flag
    when model != "default" and thinking_level mapped to provider-specific
    parameters via THINKING_LEVEL_MAP.

    Note: For Claude Code, thinking is triggered via prompt keyword (see
    get_thinking_keyword()), not CLI args. For OpenAI Codex, thinking is
    controlled via --config model_reasoning_effort=<level>.

    Args:
        resolved_config: Resolved config dict from resolve_llm_config()
            Must have: provider, model keys
            Optional: thinking_level (maps to provider-specific values)
        mode: Operation mode - "text" for derive/examine phases that need
            --print and JSON output, "execute" for execute/fix phases that
            need to write files (no --print). Default is "text" for backward
            compatibility. (ISSUE-SAAS-035)

    Returns:
        List of CLI arguments (e.g., ["--dangerously-skip-permissions", "--model", "sonnet"])

    Example:
        # OpenAI with maximum thinking -> xhigh reasoning effort
        >>> build_llm_args({"provider": "openai", "model": "gpt-5.2", "thinking_level": "maximum"})
        ["exec", "--full-auto", "--model", "gpt-5.2", "--config", "model_reasoning_effort=xhigh"]

        # Anthropic text mode (derive/examine) - with --print for JSON output
        >>> build_llm_args({"provider": "anthropic", "model": "sonnet"}, mode="text")
        ["--print", "--output-format", "json", "--dangerously-skip-permissions", "--model", "sonnet", ...]

        # Anthropic execute mode (execute/fix) - no --print, allows file writing
        >>> build_llm_args({"provider": "anthropic", "model": "sonnet"}, mode="execute")
        ["--dangerously-skip-permissions", "--model", "sonnet", ...]
    """
    provider = resolved_config.get("provider", DEFAULT_PROVIDER)
    model = resolved_config.get("model", DEFAULT_MODEL)
    thinking_level = resolved_config.get("thinking_level", DEFAULT_THINKING_LEVEL)

    # Map abstract thinking_level to provider-specific value
    provider_thinking_map = THINKING_LEVEL_MAP.get(provider, {})
    provider_thinking_value = provider_thinking_map.get(thinking_level)

    # Build args based on provider CLI
    if provider == "anthropic":
        # Claude Code CLI
        # ISSUE-SAAS-035 FIX: Mode-aware argument building
        # - "text" mode: For derive/examine phases that need --print and JSON output
        # - "execute" mode: For execute/fix phases that need to write files (no --print)
        args = []
        if mode == "text":
            # ISSUE-LLM-002 FIX: Use --print mode for text generation (not code implementation)
            # and --output-format json to enforce JSON responses for derivation/examine phases
            args.append("--print")  # Text generation mode (prevents code writing)
            args.extend(["--output-format", "json"])  # Force JSON output
        # Execute mode: No --print flag - allows Claude Code to write files
        args.append("--dangerously-skip-permissions")
        if model and model != "default":
            args.extend(["--model", model])
        # Note: Claude thinking mode (ultrathink, etc.) would be passed via prompt
        # or environment, not CLI args - handled separately by orchestrator

        # FEAT-CLI-ISOLATION-001: Context isolation flags to prevent cross-session pollution
        # Fresh session ID ensures no cached context from prior invocations
        session_id = str(uuid.uuid4())
        args.extend(["--no-session-persistence"])  # Don't persist session state
        args.extend(["--session-id", session_id])  # Fresh session each invocation
        args.extend(["--setting-sources", ""])  # Block user-level settings pollution
        logger.info(f"Claude CLI isolation: session_id={session_id[:8]}...")
        return args

    if provider == "google":
        # Gemini CLI - no reasoning effort control
        # See: docs/reference/llm-providers/gemini-cli-models.md
        # ISSUE-SAAS-046 FIX: Mode-aware argument building for Gemini
        # - "text" mode: For derive/examine phases (JSON output, no file writes)
        # - "execute" mode: For execute/fix phases (auto-approve file writes)
        #
        # ISSUE-SAAS-048 FIX: Use --sandbox=none for text mode to disable tools.
        # With --sandbox=permissive, Gemini has access to internal tools
        # (write_todos, etc.) that can hijack the response instead of returning
        # structured JSON. This causes intermittent failures where plan items
        # have "Untitled" fields because Gemini uses tools instead of returning JSON.
        if mode == "text":
            # Text generation mode - disable tools, structured output for parsing
            args = ["--sandbox=none"]
            args.extend(["--output-format", "json"])
        else:
            # Execute mode - MUST have --sandbox=permissive for file operations
            # and --yolo for auto-approval (Gemini waits for approval in headless mode)
            args = ["--sandbox=permissive"]
            args.append("--yolo")
        # "default" and "auto" both mean let Gemini choose (no --model flag)
        if model and model not in ("default", "auto"):
            args.extend(["--model", model])
        return args

    if provider == "openai":
        # OpenAI Codex CLI - uses exec --full-auto mode
        args = ["exec", "--full-auto"]
        if model and model != "default":
            args.extend(["--model", model])
        # Add reasoning effort (codex uses --config flag)
        if provider_thinking_value:
            args.extend(["--config", f"model_reasoning_effort={provider_thinking_value}"])
        return args

    # Fallback to Claude Code CLI args
    return ["--dangerously-skip-permissions"]


def get_llm_cli(provider: str = DEFAULT_PROVIDER) -> str:
    """Get the CLI executable path for a provider.

    Returns the full executable path for cross-platform subprocess compatibility.
    On Windows, this ensures extensions (.cmd/.exe) are included.
    On macOS/Linux, returns the resolved path for reliability.

    Args:
        provider: LLM provider name

    Returns:
        Full path to CLI executable, or bare command name as fallback
    """
    provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
    cli_name = provider_info.get("cli", "claude")
    # Full path for Windows compatibility (.cmd/.exe) and reliability everywhere
    return shutil.which(cli_name) or cli_name


def get_llm_command() -> tuple[str, list[str]]:
    """Get the implementation LLM command and arguments.

    Returns:
        Tuple of (command, args) for subprocess execution.
        Uses provider-specific CLI:
        - Anthropic: claude (Claude Code CLI)
        - Google: gemini (Gemini CLI)
        - OpenAI: codex (OpenAI Codex CLI)

    Note:
        Consider using resolve_llm_config() + build_llm_args() for more control.
    """
    llm_config = get_llm_config()
    impl_config = llm_config.get("implementation", {})

    provider = impl_config.get("provider", DEFAULT_PROVIDER)
    model = impl_config.get("model", DEFAULT_MODEL)

    cli = get_llm_cli(provider)
    args = build_llm_args({"provider": provider, "model": model})

    return cli, args


# API key environment variable names for each provider
# Used by build_subprocess_env() to strip keys when OAuth is configured
PROVIDER_API_KEY_ENV_VARS = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "google": "GOOGLE_API_KEY",
}


def build_subprocess_env(
    auth_method: str,
    base_env: dict[str, str] | None = None,
    extra_env: dict[str, str] | None = None,
) -> dict[str, str]:
    """Build subprocess environment with auth-aware API key handling.

    When auth_method is "oauth", API key environment variables are stripped
    to ensure the CLI uses OAuth authentication instead of API key billing.
    This prevents unexpected billing when a user has both OAuth configured
    in Obra and API keys set in their shell environment.

    Provider CLI auth priority (applies to all providers):
    1. API key environment variable (highest - API billing)
    2. OAuth token
    3. Subscription (lowest)

    By stripping API keys when OAuth is configured, we ensure Obra respects
    the user's auth_method configuration.

    Args:
        auth_method: Authentication method ("oauth" or "api_key")
        base_env: Base environment dict (defaults to os.environ.copy())
        extra_env: Additional environment variables to add

    Returns:
        Environment dict suitable for subprocess.run(env=...)

    Example:
        >>> # OAuth mode - API keys stripped
        >>> env = build_subprocess_env("oauth")
        >>> "ANTHROPIC_API_KEY" in env
        False

        >>> # API key mode - API keys preserved
        >>> env = build_subprocess_env("api_key")
        >>> "ANTHROPIC_API_KEY" in env  # if set in os.environ
        True

    Note:
        This is NON-DESTRUCTIVE. The original os.environ is never modified.
        Only the returned copy has API keys removed when auth_method is "oauth".
        Other processes (parallel Obra runs, direct API calls) are unaffected.
    """
    import os

    # Start with base environment (copy to avoid modifying original)
    if base_env is None:
        env = os.environ.copy()
    else:
        env = base_env.copy()

    # When OAuth is configured, strip API keys to prevent CLI from using them
    if auth_method == "oauth":
        stripped_keys = []
        for provider, key_var in PROVIDER_API_KEY_ENV_VARS.items():
            if key_var in env:
                env.pop(key_var)
                stripped_keys.append(key_var)

        if stripped_keys:
            logger.info(
                f"OAuth mode: Stripped API key env vars from subprocess environment: "
                f"{', '.join(stripped_keys)}. CLI will use OAuth authentication."
            )
    else:
        # API key mode - log if API keys are present
        present_keys = [
            key_var
            for key_var in PROVIDER_API_KEY_ENV_VARS.values()
            if key_var in env
        ]
        if present_keys:
            logger.debug(
                f"API key mode: Using API key authentication. "
                f"Present: {', '.join(present_keys)}"
            )

    # Add extra environment variables
    if extra_env:
        env.update(extra_env)

    return env


# Public exports
__all__ = [
    # Thinking constants
    "DEFAULT_THINKING_LEVEL",
    "THINKING_LEVELS",
    "THINKING_LEVEL_MAP",
    # Model constants
    "MODEL_SHORTCUTS",
    "XHIGH_SUPPORTED_MODELS",
    "MODEL_PROVIDER_PATTERNS",
    "MODEL_PROVIDER_PREFIXES",
    # Model inference
    "infer_provider_from_model",
    # Thinking level functions
    "get_thinking_level_notes",
    "get_effective_thinking_value",
    # Model validation
    "validate_model",
    # Config resolution
    "resolve_llm_config",
    "get_llm_config",
    "set_llm_config",
    "get_llm_display",
    # CLI building
    "get_thinking_keyword",
    "build_llm_args",
    "get_llm_cli",
    "get_llm_command",
    # Subprocess environment
    "PROVIDER_API_KEY_ENV_VARS",
    "build_subprocess_env",
]
