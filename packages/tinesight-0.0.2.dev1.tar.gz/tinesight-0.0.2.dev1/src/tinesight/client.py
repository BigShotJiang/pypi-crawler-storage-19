from collections.abc import Callable
from functools import partial
from pathlib import Path

import requests

from tinesight.api import TinesightApiMixin


class TinesightClient(TinesightApiMixin):
    """
    Client for invoking the Tinesight API from a device.

    To use this class, a device must be registered with a signed certificate using the
    `TinesightRegistrar`.

    Examples:
        >>> result = TinesightClient(my_key_path, my_cert_path).classify(my_image_bytes)
        >>> print(result.json)
        >>> {'class': 'deer', 'probability': 0.98}

    """

    @property
    def _mtls_post(self) -> Callable:
        """Private wrapper for making invoking requests with a certa"""
        return partial(requests.post, cert=(self.cert_path, self.key_path))

    def __init__(self, x509_key_path: Path | str, x509_cert_path: Path | str):
        self.key_path: str = str(x509_key_path)
        self.cert_path: str = str(x509_cert_path)

    def classify(self, image_bytes: bytes) -> requests.Response:
        """Invokes the classification model for the specified image"""
        classification_url = self.tenant_base_api_uri + "/classify/v1"
        return self._mtls_post(classification_url, files={"file": image_bytes})
