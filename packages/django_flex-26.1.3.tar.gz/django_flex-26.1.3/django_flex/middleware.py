"""
Django-Flex Middleware

Optional middleware for handling flexible queries through a
centralized endpoint.

Features:
- Single endpoint for all flex queries
- Automatic model routing
- Request/response logging (optional)
"""

import json
import logging

from django.http import JsonResponse

from django_flex.query import FlexQuery, get_model_by_name
from django_flex.response import FlexResponse
from django_flex.conf import flex_settings


logger = logging.getLogger("django_flex")


class FlexQueryMiddleware:
    """
    Middleware for handling flexible queries through a single endpoint.

    This middleware intercepts requests to a configured URL path and
    handles them as flex queries.

    Setup:
        # settings.py
        MIDDLEWARE = [
            ...
            'django_flex.middleware.FlexQueryMiddleware',
        ]

        DJANGO_FLEX = {
            'MIDDLEWARE_PATH': '/api/flex/',
            'PERMISSIONS': {...},
        }

    Usage:
        # Client sends POST to /api/flex/
        {
            "_model": "booking",
            "_action": "query",
            "fields": "id, customer.name",
            "filters": {"status": "confirmed"},
            "limit": 20
        }
    """

    def __init__(self, get_response):
        self.get_response = get_response
        self.path = getattr(flex_settings, "MIDDLEWARE_PATH", "/api/flex/")

    def __call__(self, request):
        # Check if this is a flex query request
        if request.path == self.path and request.method == "POST":
            return self.handle_flex_query(request)

        return self.get_response(request)

    def handle_flex_query(self, request):
        """Handle a flex query request."""
        # Check authentication if required
        if flex_settings.REQUIRE_AUTHENTICATION:
            if not hasattr(request, "user") or not request.user.is_authenticated:
                return JsonResponse(
                    FlexResponse.error("PERMISSION_DENIED", "Authentication required").to_dict(),
                    status=401,
                )

        # Parse request body
        try:
            body = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse(
                FlexResponse.error("INVALID_FILTER", "Invalid JSON body").to_dict(),
                status=400,
            )

        # Extract model and action
        model_name = body.get("_model")
        action = body.get("_action", "query")

        if not model_name:
            return JsonResponse(
                FlexResponse.error("MODEL_NOT_FOUND", "Missing '_model' in request").to_dict(),
                status=400,
            )

        # Normalize action (legacy support)
        if action == "get+" or action == "list":
            action = "query"

        # Get model
        model = get_model_by_name(model_name)
        if model is None:
            return JsonResponse(
                FlexResponse.error("MODEL_NOT_FOUND", f"Model '{model_name}' not found").to_dict(),
                status=404,
            )

        # Build query spec (remove internal keys)
        query_spec = {k: v for k, v in body.items() if not k.startswith("_")}

        # Add id if present in body
        if "id" in body:
            query_spec["id"] = body["id"]

        # Log query if auditing enabled
        if flex_settings.AUDIT_QUERIES:
            user = getattr(request, "user", None)
            logger.info(
                "flex_query",
                extra={
                    "user": str(user) if user else "anonymous",
                    "model": model_name,
                    "action": action,
                    "query": query_spec,
                },
            )

        # Execute query
        user = request.user if hasattr(request, "user") else None
        query = FlexQuery(model)
        result = query.execute(query_spec, user=user, action=action)

        # Determine HTTP status
        if result.success:
            status = 200
        elif result.code == "NOT_FOUND":
            status = 404
        elif result.code == "PERMISSION_DENIED":
            status = 403
        else:
            status = 400

        return JsonResponse(result.to_dict(), status=status)
