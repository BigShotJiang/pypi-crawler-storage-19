class ExperimentalWarning(Warning):
    pass
