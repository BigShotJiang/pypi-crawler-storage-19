import { z as defineStore, k as axios, a4 as shallowRef, r as ref, d as defineComponent, an as useCssVars, F as onMounted, o as openBlock, c as createElementBlock, a as createBaseVNode, T as renderSlot, y as createBlock, t as toDisplayString, e as createCommentVNode, a0 as normalizeStyle, n as normalizeClass, ag as Teleport, Z as nextTick, g as _export_sfc } from "./index-387a6f18.js";
const FLOW_ID_STORAGE_KEY = "last_flow_id";
const useFlowStore = defineStore("flow", {
  state: () => {
    const savedFlowId = sessionStorage.getItem(FLOW_ID_STORAGE_KEY);
    const initialFlowId = savedFlowId ? parseInt(savedFlowId) : -1;
    return {
      flowId: initialFlowId,
      vueFlowInstance: null
    };
  },
  getters: {
    currentFlowId: (state) => state.flowId
  },
  actions: {
    setFlowId(flowId) {
      this.flowId = flowId;
      try {
        sessionStorage.setItem(FLOW_ID_STORAGE_KEY, flowId.toString());
      } catch (error) {
        console.warn("Failed to store flow ID in session storage:", error);
      }
    },
    setVueFlowInstance(vueFlowInstance) {
      this.vueFlowInstance = vueFlowInstance;
    },
    getVueFlowInstance() {
      return this.vueFlowInstance;
    }
  }
});
class NodeApi {
  /**
   * Get node data for a specific node
   */
  static async getNodeData(flowId, nodeId) {
    const response = await axios.get("/node", {
      params: { flow_id: flowId, node_id: nodeId },
      headers: { accept: "application/json" }
    });
    return response.data;
  }
  /**
   * Get table example/preview data for a node
   */
  static async getTableExample(flowId, nodeId) {
    const response = await axios.get("/node/data", {
      params: { flow_id: flowId, node_id: nodeId },
      headers: { accept: "application/json" }
    });
    return response.data;
  }
  /**
   * Get downstream node IDs for a given node
   */
  static async getDownstreamNodeIds(flowId, nodeId) {
    const response = await axios.get("/node/downstream_node_ids", {
      params: { flow_id: flowId, node_id: nodeId },
      headers: { accept: "application/json" }
    });
    return response.data;
  }
  /**
   * Get node description
   */
  static async getNodeDescription(flowId, nodeId) {
    const response = await axios.get("/node/description", {
      params: { node_id: nodeId, flow_id: flowId }
    });
    return response.data;
  }
  /**
   * Set/update node description
   */
  static async setNodeDescription(flowId, nodeId, description) {
    const response = await axios.post("/node/description/", JSON.stringify(description), {
      params: { flow_id: flowId, node_id: nodeId },
      headers: { "Content-Type": "application/json" }
    });
    return response.data;
  }
  /**
   * Update node settings directly
   */
  static async updateSettingsDirectly(nodeType, inputData) {
    const response = await axios.post("/update_settings/", inputData, {
      params: { node_type: nodeType }
    });
    return response.data;
  }
  /**
   * Update user-defined node settings
   */
  static async updateUserDefinedSettings(nodeType, inputData) {
    const response = await axios.post(
      "/user_defined_components/update_user_defined_node/",
      inputData,
      {
        params: { node_type: nodeType }
      }
    );
    return response.data;
  }
}
class ExpressionsApi {
  /**
   * Fetch all available expressions overview/documentation
   */
  static async getExpressionsOverview() {
    const response = await axios.get("/editor/expression_doc");
    return response.data;
  }
}
const useResultsStore = defineStore("results", {
  state: () => ({
    runResults: {},
    runNodeResults: {},
    runNodeValidations: {},
    currentRunResult: null,
    resultVersion: 0
  }),
  getters: {
    getCurrentRunResult: (state) => state.currentRunResult
  },
  actions: {
    // ========== Result Cache Management ==========
    initializeResultCache(flowId) {
      if (!this.runNodeResults[flowId]) {
        this.runNodeResults[flowId] = {};
      }
    },
    setNodeResult(flowId, nodeId, result) {
      this.initializeResultCache(flowId);
      this.runNodeResults[flowId][nodeId] = result;
    },
    getNodeResult(flowId, nodeId) {
      var _a;
      return (_a = this.runNodeResults[flowId]) == null ? void 0 : _a[nodeId];
    },
    resetNodeResult() {
      console.log("Clearing node results");
      this.runNodeResults = {};
    },
    clearFlowResults(flowId) {
      if (this.runNodeResults[flowId]) {
        delete this.runNodeResults[flowId];
      }
    },
    // ========== Validation Cache Management ==========
    initializeValidationCache(flowId) {
      if (!this.runNodeValidations[flowId]) {
        this.runNodeValidations[flowId] = {};
      }
    },
    setNodeValidation(flowId, nodeId, nodeValidationInput) {
      if (typeof nodeId === "string") {
        nodeId = parseInt(nodeId);
      }
      this.initializeValidationCache(flowId);
      const nodeValidation = {
        ...nodeValidationInput,
        validationTime: Date.now() / 1e3
      };
      this.runNodeValidations[flowId][nodeId] = nodeValidation;
    },
    resetNodeValidation() {
      this.runNodeValidations = {};
    },
    getNodeValidation(flowId, nodeId) {
      var _a;
      return ((_a = this.runNodeValidations[flowId]) == null ? void 0 : _a[nodeId]) || {
        isValid: true,
        error: "",
        validationTime: 0
      };
    },
    // ========== Run Results Management ==========
    insertRunResult(runResult) {
      this.currentRunResult = runResult;
      this.runResults[runResult.flow_id] = runResult;
      this.initializeResultCache(runResult.flow_id);
      runResult.node_step_result.forEach((nodeResult) => {
        this.runNodeResults[runResult.flow_id][nodeResult.node_id] = nodeResult;
      });
      this.resultVersion++;
    },
    resetRunResults() {
      this.runNodeResults = {};
      this.runResults = {};
      this.currentRunResult = null;
    },
    getRunResult(flowId) {
      return this.runResults[flowId] || null;
    }
  }
});
const useEditorStore = defineStore("editor", {
  state: () => ({
    // Drawer state
    isDrawerOpen: false,
    isAnalysisOpen: false,
    activeDrawerComponent: shallowRef(null),
    drawerProps: ref({}),
    drawCloseFunction: null,
    // Editor state
    initialEditorData: "",
    inputCode: "",
    // Log viewer state
    hideLogViewerForThisRun: false,
    isShowingLogViewer: false,
    isStreamingLogs: false,
    displayLogViewer: true,
    // Code generator state
    showCodeGenerator: false,
    // Run state
    isRunning: false,
    showFlowResult: false,
    tableVisible: false
  }),
  getters: {
    drawerOpen() {
      return !!this.activeDrawerComponent;
    }
  },
  actions: {
    // ========== Drawer Management ==========
    async executeDrawCloseFunction() {
      console.log("Executing draw close function");
      if (this.drawCloseFunction) {
        this.drawCloseFunction();
      }
    },
    setCloseFunction(f) {
      this.drawCloseFunction = f;
    },
    openDrawer(component, nodeTitleInfo, props = {}) {
      this.activeDrawerComponent = component;
      this.drawerProps = { ...nodeTitleInfo, ...props };
      this.isDrawerOpen = true;
    },
    closeDrawer() {
      this.activeDrawerComponent = null;
      if (this.drawCloseFunction)
        ;
    },
    toggleDrawer() {
      if (this.isDrawerOpen && this.drawCloseFunction) {
        this.pushNodeData();
      }
      this.isDrawerOpen = !this.isDrawerOpen;
    },
    pushNodeData() {
      if (this.drawCloseFunction && !this.isRunning) {
        this.drawCloseFunction();
        this.drawCloseFunction = null;
      }
    },
    openAnalysisDrawer(closeFunction) {
      console.log("openAnalysisDrawer in editor-store.ts");
      if (this.isAnalysisOpen) {
        this.pushNodeData();
      }
      if (closeFunction) {
        this.drawCloseFunction = closeFunction;
      }
      this.isAnalysisOpen = true;
    },
    closeAnalysisDrawer() {
      this.isAnalysisOpen = false;
      if (this.drawCloseFunction) {
        console.log("closeDrawer in editor-store.ts");
        this.pushNodeData();
      }
    },
    // ========== Code Generator ==========
    toggleCodeGenerator() {
      this.showCodeGenerator = !this.showCodeGenerator;
    },
    setCodeGeneratorVisibility(visible) {
      this.showCodeGenerator = visible;
    },
    // ========== Log Viewer ==========
    showLogViewer() {
      console.log("triggered show log viewer");
      this.isShowingLogViewer = this.displayLogViewer;
    },
    hideLogViewer() {
      this.isShowingLogViewer = false;
    },
    toggleLogViewer() {
      console.log("triggered toggle log viewer");
      this.isShowingLogViewer = !this.isShowingLogViewer;
    },
    updateLogViewerVisibility(showResult) {
      this.isShowingLogViewer = this.displayLogViewer && showResult && !this.hideLogViewerForThisRun;
    },
    // ========== Editor Data ==========
    setInitialEditorData(editorDataString) {
      this.initialEditorData = editorDataString;
    },
    getInitialEditorData() {
      return this.initialEditorData;
    },
    setInputCode(newCode) {
      this.inputCode = newCode;
    },
    // ========== Flow Result Display ==========
    setShowFlowResult(show) {
      this.showFlowResult = show;
    },
    setTableVisible(visible) {
      this.tableVisible = visible;
    },
    setIsRunning(running) {
      this.isRunning = running;
    }
  }
});
const useNodeStore = defineStore("node", {
  state: () => ({
    nodeId: -1,
    previousNodeId: -1,
    nodeValidateFuncs: /* @__PURE__ */ new Map(),
    nodeData: null,
    nodeExists: false,
    isLoaded: false,
    sizeDataPreview: 300,
    dataTypes: ["String", "Datetime", "Int64", "Int32", "Int16", "Float64", "Float32", "Boolean"],
    nodeDescriptions: {},
    allExpressions: null
  }),
  getters: {
    currentNodeId: (state) => state.nodeId,
    currentNodeData: (state) => state.nodeData,
    // Backward compatibility: read-only getters (use snake_case for legacy)
    /** @deprecated Use `nodeId` (camelCase) instead. This getter is read-only. */
    node_id: (state) => state.nodeId,
    /** @deprecated Use `isLoaded` (camelCase) instead. This getter is read-only. */
    is_loaded: (state) => state.isLoaded,
    // Proxy getters to other stores
    /** @deprecated Use `useFlowStore().flowId` directly. This getter is read-only. */
    flow_id() {
      return useFlowStore().flowId;
    },
    /** @deprecated Use `useFlowStore().vueFlowInstance` directly. This getter is read-only. */
    vueFlowInstance() {
      return useFlowStore().vueFlowInstance;
    },
    /** @deprecated Use `useEditorStore().isRunning` directly. This getter is read-only. */
    isRunning() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.isRunning) || false;
    },
    /** @deprecated Use `useEditorStore().isDrawerOpen` directly. This getter is read-only. */
    isDrawerOpen() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.isDrawerOpen) || false;
    },
    /** @deprecated Use `useEditorStore().activeDrawerComponent` directly. This getter is read-only. */
    activeDrawerComponent() {
      var _a;
      return (_a = useEditorStore()) == null ? void 0 : _a.activeDrawerComponent;
    },
    /** @deprecated Use `useEditorStore().drawerProps` directly. This getter is read-only. */
    drawerProps() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.drawerProps) || {};
    },
    /** @deprecated Use `useEditorStore().showCodeGenerator` directly. This getter is read-only. */
    showCodeGenerator() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.showCodeGenerator) || false;
    },
    /** @deprecated Use `useEditorStore().showFlowResult` directly. This getter is read-only. */
    showFlowResult() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.showFlowResult) || false;
    },
    /** @deprecated Use `useEditorStore().isShowingLogViewer` directly. This getter is read-only. */
    isShowingLogViewer() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.isShowingLogViewer) || false;
    },
    /** @deprecated Use `useEditorStore().hideLogViewerForThisRun` directly. This getter is read-only. */
    hideLogViewerForThisRun() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.hideLogViewerForThisRun) || false;
    },
    /** @deprecated Use `useEditorStore().displayLogViewer` directly. This getter is read-only. */
    displayLogViewer() {
      const editorStore = useEditorStore();
      return (editorStore == null ? void 0 : editorStore.displayLogViewer) !== void 0 ? editorStore.displayLogViewer : true;
    },
    /** @deprecated Use `useEditorStore().inputCode` directly. This getter is read-only. */
    inputCode() {
      var _a;
      return ((_a = useEditorStore()) == null ? void 0 : _a.inputCode) || "";
    },
    /** @deprecated Use `useResultsStore().currentRunResult` directly. This getter is read-only. */
    currentRunResult() {
      var _a;
      return (_a = useResultsStore()) == null ? void 0 : _a.currentRunResult;
    },
    /** @deprecated Use `useResultsStore().runResults` directly. This getter is read-only. */
    runResults() {
      var _a;
      return ((_a = useResultsStore()) == null ? void 0 : _a.runResults) || {};
    }
  },
  actions: {
    // ========== Node Data Management ==========
    async getNodeData(nodeId, useCache = true) {
      const flowStore = useFlowStore();
      if (this.nodeId === nodeId && useCache) {
        if (this.nodeData) {
          this.isLoaded = true;
          return this.nodeData;
        }
      }
      try {
        console.log("Getting node data");
        const data = await NodeApi.getNodeData(flowStore.flowId, nodeId);
        this.nodeData = data;
        this.isLoaded = true;
        this.nodeExists = true;
        return this.nodeData;
      } catch (error) {
        console.error("Error fetching node data:", error);
        this.nodeData = null;
        this.isLoaded = false;
        this.nodeExists = false;
        return null;
      }
    },
    async reloadCurrentNodeData() {
      return this.getNodeData(this.nodeId, false);
    },
    getCurrentNodeData() {
      return this.nodeData;
    },
    async getTableExample(flowId, nodeId) {
      try {
        return await NodeApi.getTableExample(flowId, nodeId);
      } catch (error) {
        console.error("Error fetching table example:", error);
        return null;
      }
    },
    // ========== Node ID Management ==========
    setFlowIdAndNodeId(flowId, nodeId) {
      const flowStore = useFlowStore();
      if (this.nodeId === nodeId && flowStore.flowId === flowId) {
        return;
      }
      console.log("Automatically pushing the node data");
      if (flowStore.flowId !== flowId) {
        flowStore.setFlowId(flowId);
      }
      this.nodeId = nodeId;
    },
    doReset() {
      this.isLoaded = false;
    },
    // ========== Node Validation ==========
    setNodeValidateFunc(nodeId, func) {
      if (typeof nodeId === "string") {
        nodeId = parseInt(nodeId);
      }
      this.nodeValidateFuncs.set(nodeId, func);
    },
    async validateNode(nodeId) {
      if (typeof nodeId === "string") {
        nodeId = parseInt(nodeId);
      }
      const func = this.nodeValidateFuncs.get(nodeId);
      if (func) {
        func();
      }
    },
    // ========== Node Descriptions ==========
    initializeDescriptionCache(flowId) {
      if (!this.nodeDescriptions[flowId]) {
        this.nodeDescriptions[flowId] = {};
      }
    },
    cacheNodeDescriptionDict(flowId, nodeId, description) {
      this.initializeDescriptionCache(flowId);
      this.nodeDescriptions[flowId][nodeId] = description;
      if (this.nodeData && this.nodeData.node_id === nodeId && this.nodeData.setting_input) {
        this.nodeData.setting_input.description = description;
      }
    },
    clearNodeDescriptionCache(flowId, nodeId) {
      if (this.nodeDescriptions[flowId] && this.nodeDescriptions[flowId][nodeId]) {
        delete this.nodeDescriptions[flowId][nodeId];
      }
    },
    clearFlowDescriptionCache(flowId) {
      if (this.nodeDescriptions[flowId]) {
        delete this.nodeDescriptions[flowId];
      }
    },
    clearAllDescriptionCaches() {
      this.nodeDescriptions = {};
    },
    async getNodeDescription(nodeId, forceRefresh = false) {
      var _a, _b;
      const flowStore = useFlowStore();
      this.initializeDescriptionCache(flowStore.flowId);
      if (!forceRefresh && ((_a = this.nodeDescriptions[flowStore.flowId]) == null ? void 0 : _a[nodeId])) {
        return this.nodeDescriptions[flowStore.flowId][nodeId];
      }
      try {
        const description = await NodeApi.getNodeDescription(flowStore.flowId, nodeId);
        this.cacheNodeDescriptionDict(flowStore.flowId, nodeId, description);
        return description;
      } catch (error) {
        console.info("Error fetching node description:", error);
        if ((_b = this.nodeDescriptions[flowStore.flowId]) == null ? void 0 : _b[nodeId]) {
          console.warn("Using cached description due to API error");
          return this.nodeDescriptions[flowStore.flowId][nodeId];
        }
        return "";
      }
    },
    async setNodeDescription(nodeId, description) {
      const flowStore = useFlowStore();
      try {
        this.cacheNodeDescriptionDict(flowStore.flowId, nodeId, description);
        const result = await NodeApi.setNodeDescription(flowStore.flowId, nodeId, description);
        if (result === true) {
          console.log("Description updated successfully");
        } else {
          console.warn("Unexpected response:", result);
        }
      } catch (error) {
        if (error.response) {
          console.error("API error:", error.response.data.message);
        } else if (error.request) {
          console.error("The request was made but no response was received");
        } else {
          console.error("Error", error.message);
        }
        throw error;
      }
    },
    updateNodeDescription(nodeId, description) {
      const flowStore = useFlowStore();
      this.cacheNodeDescriptionDict(flowStore.flowId, nodeId, description);
    },
    // ========== Node Settings Updates ==========
    async updateSettingsDirectly(inputData) {
      var _a, _b;
      const flowStore = useFlowStore();
      try {
        const node = (_a = flowStore.vueFlowInstance) == null ? void 0 : _a.findNode(String(inputData.node_id));
        inputData.pos_x = node.position.x;
        inputData.pos_y = node.position.y;
        const response = await NodeApi.updateSettingsDirectly(
          node.data.nodeTemplate.item,
          inputData
        );
        const downstreamNodeIds = await NodeApi.getDownstreamNodeIds(
          flowStore.flowId,
          inputData.node_id
        );
        downstreamNodeIds.map((nodeId) => {
          this.validateNode(nodeId);
        });
        return response;
      } catch (error) {
        console.error("Error updating settings directly:", (_b = error.response) == null ? void 0 : _b.data);
        throw error;
      }
    },
    async updateUserDefinedSettings(inputData) {
      var _a, _b;
      const flowStore = useFlowStore();
      try {
        const node = (_a = flowStore.vueFlowInstance) == null ? void 0 : _a.findNode(String(inputData.value.node_id));
        const nodeType = node.data.nodeTemplate.item;
        inputData.value.pos_x = node.position.x;
        inputData.value.pos_y = node.position.y;
        const response = await NodeApi.updateUserDefinedSettings(nodeType, inputData.value);
        const downstreamNodeIds = await NodeApi.getDownstreamNodeIds(
          flowStore.flowId,
          inputData.value.node_id
        );
        downstreamNodeIds.map((nodeId) => {
          this.validateNode(nodeId);
        });
        return response;
      } catch (error) {
        console.error("Error updating settings:", (_b = error.response) == null ? void 0 : _b.data);
        throw error;
      }
    },
    async updateSettings(inputData, inputNodeType) {
      var _a, _b;
      const flowStore = useFlowStore();
      try {
        const node = (_a = flowStore.vueFlowInstance) == null ? void 0 : _a.findNode(String(inputData.value.node_id));
        const nodeType = inputNodeType ?? node.data.nodeTemplate.item;
        inputData.value.pos_x = node.position.x;
        inputData.value.pos_y = node.position.y;
        const response = await NodeApi.updateSettingsDirectly(nodeType, inputData.value);
        const downstreamNodeIds = await NodeApi.getDownstreamNodeIds(
          flowStore.flowId,
          inputData.value.node_id
        );
        downstreamNodeIds.map((nodeId) => {
          this.validateNode(nodeId);
        });
        return response;
      } catch (error) {
        console.error("Error updating settings:", (_b = error.response) == null ? void 0 : _b.data);
        throw error;
      }
    },
    // ========== Expressions ==========
    async fetchExpressionsOverview() {
      try {
        const expressions = await ExpressionsApi.getExpressionsOverview();
        this.allExpressions = expressions;
        return this.allExpressions;
      } catch (error) {
        console.error("Error fetching expressions overview:", error);
        return [];
      }
    },
    async getExpressionsOverview() {
      if (this.allExpressions) {
        return this.allExpressions;
      } else {
        return await this.fetchExpressionsOverview();
      }
    },
    // ========== Utilities ==========
    getDataTypes() {
      return this.dataTypes;
    },
    getSizeDataPreview() {
      return this.sizeDataPreview;
    },
    setSizeDataPreview(newHeight) {
      this.sizeDataPreview = newHeight;
    },
    getEditorNodeData() {
      var _a;
      const flowStore = useFlowStore();
      if (this.nodeId) {
        return (_a = flowStore.vueFlowInstance) == null ? void 0 : _a.findNode(String(this.nodeId));
      }
      return null;
    },
    // ========== Backward Compatibility Actions (Proxy to other stores) ==========
    /** @deprecated Use `useFlowStore().setFlowId()` directly instead. */
    setFlowId(flowId) {
      const flowStore = useFlowStore();
      flowStore.setFlowId(flowId);
    },
    /** @deprecated Use `useFlowStore().setVueFlowInstance()` directly instead. */
    setVueFlowInstance(vueFlowInstance) {
      const flowStore = useFlowStore();
      flowStore.setVueFlowInstance(vueFlowInstance);
    },
    /** @deprecated Use `useFlowStore().getVueFlowInstance()` directly instead. */
    getVueFlowInstance() {
      const flowStore = useFlowStore();
      return flowStore.getVueFlowInstance();
    },
    /** @deprecated Use `useResultsStore().setNodeResult()` directly instead. */
    setNodeResult(nodeId, result) {
      const flowStore = useFlowStore();
      const resultsStore = useResultsStore();
      resultsStore.setNodeResult(flowStore.flowId, nodeId, result);
    },
    /** @deprecated Use `useResultsStore().getNodeResult()` directly instead. */
    getNodeResult(nodeId) {
      const flowStore = useFlowStore();
      const resultsStore = useResultsStore();
      return resultsStore.getNodeResult(flowStore.flowId, nodeId);
    },
    /** @deprecated Use `useResultsStore().resetNodeResult()` directly instead. */
    resetNodeResult() {
      const resultsStore = useResultsStore();
      resultsStore.resetNodeResult();
    },
    /** @deprecated Use `useResultsStore().clearFlowResults()` directly instead. */
    clearFlowResults(flowId) {
      const resultsStore = useResultsStore();
      resultsStore.clearFlowResults(flowId);
    },
    /** @deprecated Use `useResultsStore().setNodeValidation()` directly instead. */
    setNodeValidation(nodeId, nodeValidationInput) {
      const flowStore = useFlowStore();
      const resultsStore = useResultsStore();
      resultsStore.setNodeValidation(flowStore.flowId, nodeId, nodeValidationInput);
    },
    /** @deprecated Use `useResultsStore().resetNodeValidation()` directly instead. */
    resetNodeValidation() {
      const resultsStore = useResultsStore();
      resultsStore.resetNodeValidation();
    },
    /** @deprecated Use `useResultsStore().getNodeValidation()` directly instead. */
    getNodeValidation(nodeId) {
      const flowStore = useFlowStore();
      const resultsStore = useResultsStore();
      return resultsStore.getNodeValidation(flowStore.flowId, nodeId);
    },
    /** @deprecated Use `useResultsStore().insertRunResult()` directly instead. */
    insertRunResult(runResult) {
      const resultsStore = useResultsStore();
      resultsStore.insertRunResult(runResult);
    },
    /** @deprecated Use `useResultsStore().resetRunResults()` directly instead. */
    resetRunResults() {
      const resultsStore = useResultsStore();
      resultsStore.resetRunResults();
    },
    /** @deprecated Use `useResultsStore().getRunResult()` directly instead. */
    getRunResult(flowId) {
      const resultsStore = useResultsStore();
      return resultsStore.getRunResult(flowId);
    },
    /** @deprecated Use `useEditorStore().openDrawer()` directly instead. */
    openDrawer(component, nodeTitleInfo, props = {}) {
      const editorStore = useEditorStore();
      editorStore.openDrawer(component, nodeTitleInfo, props);
    },
    /** @deprecated Use `useEditorStore().closeDrawer()` directly instead. */
    closeDrawer() {
      const editorStore = useEditorStore();
      editorStore.closeDrawer();
      this.nodeId = -1;
    },
    /** @deprecated Use `useEditorStore().toggleDrawer()` directly instead. */
    toggleDrawer() {
      const editorStore = useEditorStore();
      editorStore.toggleDrawer();
    },
    /** @deprecated Use `useEditorStore().pushNodeData()` directly instead. */
    pushNodeData() {
      const editorStore = useEditorStore();
      editorStore.pushNodeData();
    },
    /** @deprecated Use `useEditorStore().setCloseFunction()` directly instead. */
    setCloseFunction(f) {
      const editorStore = useEditorStore();
      editorStore.setCloseFunction(f);
    },
    /** @deprecated Use `useEditorStore().executeDrawCloseFunction()` directly instead. */
    executeDrawCloseFunction() {
      const editorStore = useEditorStore();
      return editorStore.executeDrawCloseFunction();
    },
    /** @deprecated Use `useEditorStore().toggleCodeGenerator()` directly instead. */
    toggleCodeGenerator() {
      const editorStore = useEditorStore();
      editorStore.toggleCodeGenerator();
    },
    /** @deprecated Use `useEditorStore().setCodeGeneratorVisibility()` directly instead. */
    setCodeGeneratorVisibility(visible) {
      const editorStore = useEditorStore();
      editorStore.setCodeGeneratorVisibility(visible);
    },
    /** @deprecated Use `useEditorStore().showLogViewer()` directly instead. */
    showLogViewer() {
      const editorStore = useEditorStore();
      editorStore.showLogViewer();
    },
    /** @deprecated Use `useEditorStore().hideLogViewer()` directly instead. */
    hideLogViewer() {
      const editorStore = useEditorStore();
      editorStore.hideLogViewer();
    },
    /** @deprecated Use `useEditorStore().toggleLogViewer()` directly instead. */
    toggleLogViewer() {
      const editorStore = useEditorStore();
      editorStore.toggleLogViewer();
    },
    /** @deprecated Use `useEditorStore().setInputCode()` directly instead. */
    setInputCode(newCode) {
      const editorStore = useEditorStore();
      editorStore.setInputCode(newCode);
    },
    /** @deprecated Use `useEditorStore().setInitialEditorData()` directly instead. */
    setInitialEditorData(editorDataString) {
      const editorStore = useEditorStore();
      editorStore.setInitialEditorData(editorDataString);
    },
    /** @deprecated Use `useEditorStore().getInitialEditorData()` directly instead. */
    getInitialEditorData() {
      const editorStore = useEditorStore();
      return editorStore.getInitialEditorData();
    }
  }
});
const _hoisted_1 = { class: "popover-container" };
const _hoisted_2 = { key: 0 };
const _hoisted_3 = ["innerHTML"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PopOver",
  props: {
    content: {
      type: String,
      required: true
    },
    title: {
      type: String,
      default: ""
    },
    placement: {
      type: String,
      default: "top"
    },
    minWidth: {
      type: Number,
      default: 100
    },
    zIndex: {
      type: Number,
      default: 9999
    }
  },
  setup(__props) {
    useCssVars((_ctx) => ({
      "355ab648": props.minWidth + "px"
    }));
    const visible = ref(false);
    const referenceEl = ref(null);
    const popoverEl = ref(null);
    const props = __props;
    const popoverStyle = ref({
      top: "0px",
      left: "0px",
      zIndex: props.zIndex.toString()
    });
    const showPopover = () => {
      visible.value = true;
      nextTick(() => {
        updatePosition();
      });
    };
    const hidePopover = () => {
      visible.value = false;
    };
    const updatePosition = () => {
      if (!referenceEl.value || !popoverEl.value)
        return;
      const referenceRect = referenceEl.value.getBoundingClientRect();
      const popoverRect = popoverEl.value.getBoundingClientRect();
      const offset = 20;
      let top = 0;
      let left = 0;
      switch (props.placement) {
        case "top":
          top = referenceRect.top - popoverRect.height - offset;
          left = referenceRect.left + referenceRect.width / 2 - popoverRect.width / 2;
          break;
        case "bottom":
          top = referenceRect.bottom + offset;
          left = referenceRect.left + referenceRect.width / 2 - popoverRect.width / 2;
          break;
        case "left":
          top = referenceRect.top + referenceRect.height / 2 - popoverRect.height / 2;
          left = referenceRect.left - popoverRect.width - offset;
          break;
        case "right":
          top = referenceRect.top + referenceRect.height / 2 - popoverRect.height / 2;
          left = referenceRect.right + offset;
          break;
      }
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      if (left < 10)
        left = 10;
      if (left + popoverRect.width > viewportWidth - 10) {
        left = viewportWidth - popoverRect.width - 10;
      }
      if (top < 10)
        top = 10;
      if (top + popoverRect.height > viewportHeight - 10) {
        top = viewportHeight - popoverRect.height - 10;
      }
      popoverStyle.value = {
        top: `${top}px`,
        left: `${left}px`,
        zIndex: props.zIndex.toString()
      };
    };
    onMounted(() => {
      window.addEventListener("resize", () => {
        if (visible.value) {
          updatePosition();
        }
      });
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", {
          ref_key: "referenceEl",
          ref: referenceEl,
          class: "popover-reference",
          onMouseenter: showPopover,
          onMouseleave: hidePopover
        }, [
          renderSlot(_ctx.$slots, "default", {}, void 0, true)
        ], 544),
        visible.value ? (openBlock(), createBlock(Teleport, {
          key: 0,
          to: "body"
        }, [
          createBaseVNode("div", {
            ref_key: "popoverEl",
            ref: popoverEl,
            style: normalizeStyle(popoverStyle.value),
            class: normalizeClass(["popover", { "popover--left": props.placement === "left" }])
          }, [
            props.title !== "" ? (openBlock(), createElementBlock("h3", _hoisted_2, toDisplayString(props.title), 1)) : createCommentVNode("", true),
            createBaseVNode("p", {
              class: "content",
              innerHTML: props.content
            }, null, 8, _hoisted_3)
          ], 6)
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const PopOver_vue_vue_type_style_index_0_scoped_8b5d0b86_lang = "";
const PopOver = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-8b5d0b86"]]);
export {
  PopOver as P,
  useEditorStore as a,
  useResultsStore as b,
  useFlowStore as c,
  useNodeStore as u
};
