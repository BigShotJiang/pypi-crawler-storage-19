import { _ as _sfc_main } from "./TextInput.vue_vue_type_script_setup_true_lang-e86510d0.js";
import "./index-387a6f18.js";
export {
  _sfc_main as default
};
