import { d as defineComponent, r as ref, F as onMounted, l as onUnmounted, o as openBlock, c as createElementBlock, a as createBaseVNode, G as Fragment, H as renderList, n as normalizeClass, t as toDisplayString, a0 as normalizeStyle } from "./index-387a6f18.js";
const _hoisted_1 = ["onClick"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ContextMenu",
  props: {
    position: {},
    options: {}
  },
  emits: ["select", "close"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const menuRef = ref(null);
    const selectOption = (option) => {
      if (option.disabled)
        return;
      emit("select", option.action);
      emit("close");
    };
    const handleClickOutside = (event) => {
      if (menuRef.value && !menuRef.value.contains(event.target)) {
        emit("close");
      }
    };
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        emit("close");
      }
    };
    onMounted(() => {
      document.addEventListener("mousedown", handleClickOutside);
      document.addEventListener("keydown", handleKeyDown);
    });
    onUnmounted(() => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleKeyDown);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "menuRef",
        ref: menuRef,
        class: "context-menu",
        style: normalizeStyle({ top: _ctx.position.y + "px", left: _ctx.position.x + "px" })
      }, [
        createBaseVNode("ul", null, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.options, (option) => {
            return openBlock(), createElementBlock("li", {
              key: option.action,
              class: normalizeClass({ disabled: option.disabled, danger: option.danger }),
              onClick: ($event) => selectOption(option)
            }, toDisplayString(option.label), 11, _hoisted_1);
          }), 128))
        ])
      ], 4);
    };
  }
});
export {
  _sfc_main as _
};
