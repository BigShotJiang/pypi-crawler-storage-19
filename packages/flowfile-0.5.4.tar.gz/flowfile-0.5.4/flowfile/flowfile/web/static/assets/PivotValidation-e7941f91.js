import { d as defineComponent, B as computed, o as openBlock, y as createBlock, q as withCtx, p as createVNode, a as createBaseVNode, x as unref, at as ElIcon, c as createElementBlock, e as createCommentVNode, ax as ElPopover, g as _export_sfc } from "./index-387a6f18.js";
const _hoisted_1 = { class: "validation-wrapper" };
const _hoisted_2 = {
  key: 0,
  class: "error-message"
};
const _hoisted_3 = {
  key: 1,
  class: "error-message"
};
const _hoisted_4 = {
  key: 2,
  class: "error-message"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "PivotValidation",
  props: {
    pivotInput: {}
  },
  setup(__props) {
    const props = __props;
    const showValidationMessages = computed(() => {
      return !props.pivotInput.pivot_column || !props.pivotInput.value_col || props.pivotInput.aggregations.length === 0;
    });
    return (_ctx, _cache) => {
      return showValidationMessages.value ? (openBlock(), createBlock(unref(ElPopover), {
        key: 0,
        placement: "top",
        width: "200",
        trigger: "hover",
        content: "Some required fields are missing"
      }, {
        reference: withCtx(() => [
          createVNode(unref(ElIcon), {
            color: "#FF6B6B",
            class: "warning-icon"
          }, {
            default: withCtx(() => _cache[0] || (_cache[0] = [
              createBaseVNode("i", { class: "el-icon-warning" }, null, -1)
            ])),
            _: 1,
            __: [0]
          })
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            !_ctx.pivotInput.pivot_column ? (openBlock(), createElementBlock("p", _hoisted_2, "Pivot Column cannot be empty.")) : createCommentVNode("", true),
            !_ctx.pivotInput.value_col ? (openBlock(), createElementBlock("p", _hoisted_3, "Value Column cannot be empty.")) : createCommentVNode("", true),
            _ctx.pivotInput.aggregations.length === 0 ? (openBlock(), createElementBlock("p", _hoisted_4, " At least one aggregation must be selected. ")) : createCommentVNode("", true)
          ])
        ]),
        _: 1
      })) : createCommentVNode("", true);
    };
  }
});
const PivotValidation_vue_vue_type_style_index_0_scoped_2b1abc75_lang = "";
const PivotValidation = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-2b1abc75"]]);
export {
  PivotValidation as default
};
