import { _ as _sfc_main } from "./SingleSelect.vue_vue_type_script_setup_true_lang-c8ebdd33.js";
import "./index-387a6f18.js";
export {
  _sfc_main as default
};
