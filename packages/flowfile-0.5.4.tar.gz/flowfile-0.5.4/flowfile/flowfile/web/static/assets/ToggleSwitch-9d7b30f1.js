import { _ as _sfc_main } from "./ToggleSwitch.vue_vue_type_script_setup_true_lang-00f2580e.js";
import "./index-387a6f18.js";
export {
  _sfc_main as default
};
