# Reminix Python SDK

Python SDK for Reminix API.

## Installation

```bash
pip install reminix
```

## Quick Start

```python
import asyncio
from reminix import Client

async def main():
    async with Client(api_key="your-api-key") as client:
        project = await client.project.get()
        print(f"Project: {project.name} ({project.id})")

asyncio.run(main())
```

## Usage

### Basic Client Usage

The SDK uses async/await and should be used with an async context manager:

```python
import asyncio
from reminix import Client

async def main():
    async with Client(api_key="your-api-key") as client:
        # Use the client here
        pass

asyncio.run(main())
```

### Project Operations

```python
import asyncio
from reminix import Client

async def main():
    async with Client(api_key="your-api-key") as client:
        # Get current project
        project = await client.project.get()
        
        print(f"Project ID: {project.id}")
        print(f"Project Name: {project.name}")
        print(f"Organization ID: {project.organizationId}")
        print(f"Slug: {project.slug}")
        print(f"Created: {project.createdAt}")
        print(f"Updated: {project.updatedAt}")

asyncio.run(main())
```

### Pagination

For endpoints that return paginated data, use the pagination utilities:

```python
import asyncio
from reminix import Client, PaginatedResponse, paginate_all, collect_all

async def fetch_events(client, cursor=None):
    """Helper function to fetch a page of events"""
    response = await client.request(
        "GET", 
        "/events", 
        params={"cursor": cursor} if cursor else None
    )
    return PaginatedResponse(
        data=response["data"],
        next_cursor=response.get("nextCursor"),
        has_more=response.get("hasMore", False),
    )

async def main():
    async with Client(api_key="your-api-key") as client:
        # Option 1: Iterate through all pages (async generator)
        async for event in paginate_all(lambda c: fetch_events(client, c)):
            print(f"Event: {event.id}")
        
        # Option 2: Collect all items into a list
        all_events = await collect_all(lambda c: fetch_events(client, c))
        print(f"Total events: {len(all_events)}")

asyncio.run(main())
```

### Error Handling

```python
import asyncio
from reminix import Client, AuthenticationError, APIError, NetworkError

async def main():
    try:
        async with Client(api_key="invalid-key") as client:
            project = await client.project.get()
    except AuthenticationError as e:
        print(f"Authentication failed: {e}")
        print(f"Status code: {e.status}")
    except APIError as e:
        print(f"API error: {e}")
        print(f"Status: {e.status} {e.reason}")
    except NetworkError as e:
        print(f"Network error: {e}")

asyncio.run(main())
```

### Configuration

```python
from reminix import Client

# Custom base URL
client = Client(
    api_key="your-api-key",
    base_url="https://custom-api.example.com/v1"
)

# Custom timeout
client = Client(
    api_key="your-api-key",
    timeout=60  # 60 seconds
)

# Custom headers
client = Client(
    api_key="your-api-key",
    headers={"X-Custom-Header": "value"}
)
```

## 🤖 Agent Runtime

Build AI agents that integrate with the Reminix API:

```bash
pip install reminix[runtime]
```

```python
from reminix.runtime import Agent, serve

# Create an agent with optional metadata for dashboard display
agent = Agent(
    "my-agent",
    metadata={
        "framework": "custom",
        "model": "gpt-4",
        "description": "My first agent",
    },
)

@agent.invoke
async def handle_invoke(input_data: dict) -> dict:
    return {"output": f"Processed: {input_data.get('message', '')}"}

@agent.chat
async def handle_chat(messages: list) -> dict:
    last_message = messages[-1]["content"] if messages else ""
    return {"message": {"role": "assistant", "content": f"Reply: {last_message}"}}

if __name__ == "__main__":
    serve(agent, port=8080)
```

See [examples](./examples/README.md) for more details.

## 🔌 Framework Adapters

Wrap your existing AI agents from popular frameworks. All adapter extras include the runtime, so you're ready to deploy:

```bash
# Individual adapters (each includes runtime)
pip install reminix[openai]      # OpenAI + runtime
pip install reminix[anthropic]   # Anthropic + runtime
pip install reminix[langchain]   # LangChain + runtime
pip install reminix[langgraph]   # LangGraph + runtime
pip install reminix[llamaindex]  # LlamaIndex + runtime

# All adapters + runtime
pip install reminix[adapters]
pip install reminix[all]
```

### OpenAI SDK

```python
from openai import AsyncOpenAI
from reminix.adapters.openai import from_openai
from reminix.runtime import serve

client = AsyncOpenAI()
agent = from_openai(client, name="gpt4-agent", model="gpt-4o")

serve(agent)
```

### Anthropic SDK

```python
from anthropic import AsyncAnthropic
from reminix.adapters.anthropic import from_anthropic
from reminix.runtime import serve

client = AsyncAnthropic()
agent = from_anthropic(client, name="claude-agent", model="claude-sonnet-4-20250514")

serve(agent)
```

### LangChain

```python
# Modern API (recommended)
from langchain.agents import create_agent
from reminix.adapters.langchain import from_langchain_agent
from reminix.runtime import serve

lc_agent = create_agent(model="openai:gpt-4o", tools=[...])
agent = from_langchain_agent(lc_agent, name="smart-agent")
serve(agent)

# Legacy AgentExecutor (for older code)
from langchain.agents import AgentExecutor
from reminix.adapters.langchain import from_agent_executor

executor = AgentExecutor(agent=agent, tools=tools)
agent = from_agent_executor(executor, name="my-agent")
serve(agent)
```

### LangGraph

```python
from langgraph.graph import StateGraph, START, END
from reminix.adapters.langgraph import from_compiled_graph
from reminix.runtime import serve

graph = StateGraph(State).add_node("process", fn).compile()
agent = from_compiled_graph(graph, name="workflow", output_key="output")
serve(agent)
```

### LlamaIndex

```python
from llama_index.core import VectorStoreIndex
from reminix.adapters.llamaindex import from_chat_engine
from reminix.runtime import serve

index = VectorStoreIndex.from_documents(documents)
chat_engine = index.as_chat_engine()
agent = from_chat_engine(chat_engine, name="docs-chat")
serve(agent)
```

## 🚀 Deploying to Reminix

Ready to deploy your agent? See the [Project Structure Guide](https://docs.reminix.com/docs/python/project-structure) for deployment requirements.

## 🛠️ Development

### Setup

```bash
# Run setup (installs dependencies and pre-commit hooks)
poetry run setup

# Or manually:
# poetry install
# poetry run pre-commit install
```

**Note:** Pre-commit hooks will automatically run formatting, linting, and type checking before each commit.

For more details, see [CONTRIBUTING.md](./CONTRIBUTING.md).

## 🧪 Integration Tests

### Client SDK Tests

Integration tests verify that the SDK works correctly with the actual Reminix API:

```bash
REMINIX_API_KEY=your-api-key poetry run test-integration
```

See [tests/integration/README.md](./tests/integration/README.md) for more details.

### Adapter Tests

Integration tests verify that adapters work correctly with real LLM APIs:

```bash
# Run all adapter integration tests
OPENAI_API_KEY=sk-... ANTHROPIC_API_KEY=sk-ant-... poetry run test-integration-adapters

# Run specific adapter tests
poetry run test-integration-adapters -k openai
poetry run test-integration-adapters -k anthropic
```

See [tests/integration/adapters/README.md](./tests/integration/adapters/README.md) for more details.

### E2E Tests

E2E tests verify the full HTTP request/response cycle through the FastAPI server:

```bash
# Run all E2E tests
OPENAI_API_KEY=sk-... ANTHROPIC_API_KEY=sk-ant-... poetry run test-e2e-adapters

# Run specific adapter
poetry run test-e2e-adapters -k openai
poetry run test-e2e-adapters -k anthropic
```

See [tests/e2e/adapters/README.md](./tests/e2e/adapters/README.md) for more details.

## License

MIT
