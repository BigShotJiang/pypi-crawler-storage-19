from __future__ import annotations
import collections.abc
import typing
__all__: list[str] = ['AccelerometerRange', 'AllianceStationID', 'CANDeviceType', 'CANManufacturer', 'ControlWord', 'JoystickAxes', 'JoystickButtons', 'JoystickDescriptor', 'JoystickPOVs', 'MatchInfo', 'MatchType', 'RuntimeType', 'SPIMode', 'SPIPort', 'SimBoolean', 'SimDevice', 'SimDouble', 'SimEnum', 'SimInt', 'SimLong', 'SimValue', 'SimValueDirection', 'Type', 'Value', 'cancelNotifierAlarm', 'cleanNotifier', 'exitMain', 'expandFPGATime', 'getAccelerometerX', 'getAccelerometerY', 'getAccelerometerZ', 'getAllJoystickData', 'getAllianceStation', 'getBrownedOut', 'getComments', 'getCommsDisableCount', 'getControlWord', 'getCurrentThreadPriority', 'getErrorMessage', 'getFPGAButton', 'getFPGARevision', 'getFPGATime', 'getFPGAVersion', 'getJoystickAxes', 'getJoystickAxisType', 'getJoystickButtons', 'getJoystickDescriptor', 'getJoystickIsXbox', 'getJoystickName', 'getJoystickPOVs', 'getJoystickType', 'getLastError', 'getMatchInfo', 'getMatchTime', 'getOutputsEnabled', 'getPort', 'getPortWithModule', 'getRSLState', 'getRuntimeType', 'getSerialNumber', 'getSystemActive', 'getSystemTimeValid', 'getTeamNumber', 'hasMain', 'initialize', 'initializeNotifier', 'loadExtensions', 'loadOneExtension', 'observeUserProgramAutonomous', 'observeUserProgramDisabled', 'observeUserProgramStarting', 'observeUserProgramTeleop', 'observeUserProgramTest', 'provideNewDataEventHandle', 'refreshDSData', 'removeNewDataEventHandle', 'report', 'runMain', 'sendConsoleLine', 'sendError', 'setAccelerometerActive', 'setAccelerometerRange', 'setCurrentThreadPriority', 'setJoystickOutputs', 'setNotifierName', 'setNotifierThreadPriority', 'setShowExtensionsNotFoundMessages', 'shutdown', 'simPeriodicAfter', 'simPeriodicBefore', 'stopNotifier', 'tInstances', 'tResourceType', 'updateNotifierAlarm', 'waitForNotifierAlarm']
class AccelerometerRange:
    """
    The acceptable accelerometer ranges.
    
    Members:
    
      k2G
    
      k4G
    
      k8G
    """
    __members__: typing.ClassVar[dict[str, AccelerometerRange]]  # value = {'k2G': <AccelerometerRange.k2G: 0>, 'k4G': <AccelerometerRange.k4G: 1>, 'k8G': <AccelerometerRange.k8G: 2>}
    k2G: typing.ClassVar[AccelerometerRange]  # value = <AccelerometerRange.k2G: 0>
    k4G: typing.ClassVar[AccelerometerRange]  # value = <AccelerometerRange.k4G: 1>
    k8G: typing.ClassVar[AccelerometerRange]  # value = <AccelerometerRange.k8G: 2>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class AllianceStationID:
    """
    Members:
    
      kUnknown : Unknown Alliance Station
    
      kRed1 : Red Alliance Station 1
    
      kRed2 : Red Alliance Station 2
    
      kRed3 : Red Alliance Station 3
    
      kBlue1 : Blue Alliance Station 1
    
      kBlue2 : Blue Alliance Station 2
    
      kBlue3 : Blue Alliance Station 3
    """
    __members__: typing.ClassVar[dict[str, AllianceStationID]]  # value = {'kUnknown': <AllianceStationID.kUnknown: 0>, 'kRed1': <AllianceStationID.kRed1: 1>, 'kRed2': <AllianceStationID.kRed2: 2>, 'kRed3': <AllianceStationID.kRed3: 3>, 'kBlue1': <AllianceStationID.kBlue1: 4>, 'kBlue2': <AllianceStationID.kBlue2: 5>, 'kBlue3': <AllianceStationID.kBlue3: 6>}
    kBlue1: typing.ClassVar[AllianceStationID]  # value = <AllianceStationID.kBlue1: 4>
    kBlue2: typing.ClassVar[AllianceStationID]  # value = <AllianceStationID.kBlue2: 5>
    kBlue3: typing.ClassVar[AllianceStationID]  # value = <AllianceStationID.kBlue3: 6>
    kRed1: typing.ClassVar[AllianceStationID]  # value = <AllianceStationID.kRed1: 1>
    kRed2: typing.ClassVar[AllianceStationID]  # value = <AllianceStationID.kRed2: 2>
    kRed3: typing.ClassVar[AllianceStationID]  # value = <AllianceStationID.kRed3: 3>
    kUnknown: typing.ClassVar[AllianceStationID]  # value = <AllianceStationID.kUnknown: 0>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class CANDeviceType:
    """
    The CAN device type.
    
    Teams should use HAL_CAN_Dev_kMiscellaneous
    
    Members:
    
      kBroadcast : Broadcast.
    
      kRobotController : Robot controller.
    
      kMotorController : Motor controller.
    
      kRelayController : Relay controller.
    
      kGyroSensor : Gyro sensor.
    
      kAccelerometer : Accelerometer.
    
      kDistanceSensor : Distance sensor.
    
      kEncoder : Encoder.
    
      kPowerDistribution : Power distribution.
    
      kPneumatics : Pneumatics.
    
      kMiscellaneous : Miscellaneous.
    
      kIOBreakout : IO breakout.
    
      kServoController : Servo controller.
    
      ColorSensor : Color Sensor.
    
      kFirmwareUpdate : Firmware update.
    """
    ColorSensor: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.ColorSensor: 13>
    __members__: typing.ClassVar[dict[str, CANDeviceType]]  # value = {'kBroadcast': <CANDeviceType.kBroadcast: 0>, 'kRobotController': <CANDeviceType.kRobotController: 1>, 'kMotorController': <CANDeviceType.kMotorController: 2>, 'kRelayController': <CANDeviceType.kRelayController: 3>, 'kGyroSensor': <CANDeviceType.kGyroSensor: 4>, 'kAccelerometer': <CANDeviceType.kAccelerometer: 5>, 'kDistanceSensor': <CANDeviceType.kDistanceSensor: 6>, 'kEncoder': <CANDeviceType.kEncoder: 7>, 'kPowerDistribution': <CANDeviceType.kPowerDistribution: 8>, 'kPneumatics': <CANDeviceType.kPneumatics: 9>, 'kMiscellaneous': <CANDeviceType.kMiscellaneous: 10>, 'kIOBreakout': <CANDeviceType.kIOBreakout: 11>, 'kServoController': <CANDeviceType.kServoController: 12>, 'ColorSensor': <CANDeviceType.ColorSensor: 13>, 'kFirmwareUpdate': <CANDeviceType.kFirmwareUpdate: 31>}
    kAccelerometer: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kAccelerometer: 5>
    kBroadcast: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kBroadcast: 0>
    kDistanceSensor: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kDistanceSensor: 6>
    kEncoder: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kEncoder: 7>
    kFirmwareUpdate: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kFirmwareUpdate: 31>
    kGyroSensor: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kGyroSensor: 4>
    kIOBreakout: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kIOBreakout: 11>
    kMiscellaneous: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kMiscellaneous: 10>
    kMotorController: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kMotorController: 2>
    kPneumatics: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kPneumatics: 9>
    kPowerDistribution: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kPowerDistribution: 8>
    kRelayController: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kRelayController: 3>
    kRobotController: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kRobotController: 1>
    kServoController: typing.ClassVar[CANDeviceType]  # value = <CANDeviceType.kServoController: 12>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class CANManufacturer:
    """
    The CAN manufacturer ID.
    
    Teams should use HAL_CAN_Man_kTeamUse.
    
    Members:
    
      kBroadcast : Broadcast.
    
      kNI : National Instruments.
    
      kLM : Luminary Micro.
    
      kDEKA : DEKA Research and Development Corp.
    
      kCTRE : Cross the Road Electronics.
    
      kREV : REV robotics.
    
      kGrapple : Grapple.
    
      kMS : MindSensors.
    
      kTeamUse : Team use.
    
      kKauaiLabs : Kauai Labs.
    
      kCopperforge : Copperforge.
    
      kPWF : Playing With Fusion.
    
      kStudica : Studica.
    
      kTheThriftyBot : TheThriftyBot.
    
      kReduxRobotics : Redux Robotics.
    
      kAndyMark : AndyMark.
    
      kVividHosting : Vivid-Hosting.
    
      kVertosRobotics : Vertos Robotics.
    
      kSWYFTRobotics : SWYFT Robotics.
    
      kLumynLabs : Lumyn Labs.
    
      kBrushlandLabs : Brushland Labs
    """
    __members__: typing.ClassVar[dict[str, CANManufacturer]]  # value = {'kBroadcast': <CANManufacturer.kBroadcast: 0>, 'kNI': <CANManufacturer.kNI: 1>, 'kLM': <CANManufacturer.kLM: 2>, 'kDEKA': <CANManufacturer.kDEKA: 3>, 'kCTRE': <CANManufacturer.kCTRE: 4>, 'kREV': <CANManufacturer.kREV: 5>, 'kGrapple': <CANManufacturer.kGrapple: 6>, 'kMS': <CANManufacturer.kMS: 7>, 'kTeamUse': <CANManufacturer.kTeamUse: 8>, 'kKauaiLabs': <CANManufacturer.kKauaiLabs: 9>, 'kCopperforge': <CANManufacturer.kCopperforge: 10>, 'kPWF': <CANManufacturer.kPWF: 11>, 'kStudica': <CANManufacturer.kStudica: 12>, 'kTheThriftyBot': <CANManufacturer.kTheThriftyBot: 13>, 'kReduxRobotics': <CANManufacturer.kReduxRobotics: 14>, 'kAndyMark': <CANManufacturer.kAndyMark: 15>, 'kVividHosting': <CANManufacturer.kVividHosting: 16>, 'kVertosRobotics': <CANManufacturer.kVertosRobotics: 17>, 'kSWYFTRobotics': <CANManufacturer.kSWYFTRobotics: 18>, 'kLumynLabs': <CANManufacturer.kLumynLabs: 19>, 'kBrushlandLabs': <CANManufacturer.kBrushlandLabs: 20>}
    kAndyMark: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kAndyMark: 15>
    kBroadcast: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kBroadcast: 0>
    kBrushlandLabs: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kBrushlandLabs: 20>
    kCTRE: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kCTRE: 4>
    kCopperforge: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kCopperforge: 10>
    kDEKA: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kDEKA: 3>
    kGrapple: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kGrapple: 6>
    kKauaiLabs: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kKauaiLabs: 9>
    kLM: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kLM: 2>
    kLumynLabs: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kLumynLabs: 19>
    kMS: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kMS: 7>
    kNI: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kNI: 1>
    kPWF: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kPWF: 11>
    kREV: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kREV: 5>
    kReduxRobotics: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kReduxRobotics: 14>
    kSWYFTRobotics: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kSWYFTRobotics: 18>
    kStudica: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kStudica: 12>
    kTeamUse: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kTeamUse: 8>
    kTheThriftyBot: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kTheThriftyBot: 13>
    kVertosRobotics: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kVertosRobotics: 17>
    kVividHosting: typing.ClassVar[CANManufacturer]  # value = <CANManufacturer.kVividHosting: 16>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ControlWord:
    def __init__(self) -> None:
        ...
    @property
    def autonomous(self) -> int:
        ...
    @autonomous.setter
    def autonomous(self, arg1: typing.SupportsInt) -> None:
        ...
    @property
    def control_reserved(self) -> int:
        ...
    @control_reserved.setter
    def control_reserved(self, arg1: typing.SupportsInt) -> None:
        ...
    @property
    def dsAttached(self) -> int:
        ...
    @dsAttached.setter
    def dsAttached(self, arg1: typing.SupportsInt) -> None:
        ...
    @property
    def eStop(self) -> int:
        ...
    @eStop.setter
    def eStop(self, arg1: typing.SupportsInt) -> None:
        ...
    @property
    def enabled(self) -> int:
        ...
    @enabled.setter
    def enabled(self, arg1: typing.SupportsInt) -> None:
        ...
    @property
    def fmsAttached(self) -> int:
        ...
    @fmsAttached.setter
    def fmsAttached(self, arg1: typing.SupportsInt) -> None:
        ...
    @property
    def test(self) -> int:
        ...
    @test.setter
    def test(self, arg1: typing.SupportsInt) -> None:
        ...
class JoystickAxes:
    def __init__(self) -> None:
        ...
    @property
    def axes(self) -> memoryview:
        ...
    @property
    def count(self) -> int:
        ...
    @count.setter
    def count(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def raw(self) -> memoryview:
        ...
class JoystickButtons:
    def __init__(self) -> None:
        ...
    @property
    def buttons(self) -> int:
        ...
    @buttons.setter
    def buttons(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def count(self) -> int:
        ...
    @count.setter
    def count(self, arg0: typing.SupportsInt) -> None:
        ...
class JoystickDescriptor:
    def __init__(self) -> None:
        ...
    @property
    def axisCount(self) -> int:
        ...
    @axisCount.setter
    def axisCount(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def axisTypes(self) -> memoryview:
        ...
    @property
    def buttonCount(self) -> int:
        ...
    @buttonCount.setter
    def buttonCount(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def isXbox(self) -> int:
        ...
    @isXbox.setter
    def isXbox(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def name(self) -> memoryview:
        ...
    @property
    def povCount(self) -> int:
        ...
    @povCount.setter
    def povCount(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def type(self) -> int:
        ...
    @type.setter
    def type(self, arg0: typing.SupportsInt) -> None:
        ...
class JoystickPOVs:
    def __init__(self) -> None:
        ...
    @property
    def count(self) -> int:
        ...
    @count.setter
    def count(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def povs(self) -> memoryview:
        ...
class MatchInfo:
    matchType: MatchType
    def __init__(self) -> None:
        ...
    @property
    def eventName(self) -> memoryview:
        ...
    @property
    def gameSpecificMessage(self) -> memoryview:
        ...
    @property
    def gameSpecificMessageSize(self) -> int:
        ...
    @gameSpecificMessageSize.setter
    def gameSpecificMessageSize(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def matchNumber(self) -> int:
        ...
    @matchNumber.setter
    def matchNumber(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def replayNumber(self) -> int:
        ...
    @replayNumber.setter
    def replayNumber(self, arg0: typing.SupportsInt) -> None:
        ...
class MatchType:
    """
    Members:
    
      none
    
      practice
    
      qualification
    
      elimination
    """
    __members__: typing.ClassVar[dict[str, MatchType]]  # value = {'none': <MatchType.none: 0>, 'practice': <MatchType.practice: 1>, 'qualification': <MatchType.qualification: 2>, 'elimination': <MatchType.elimination: 3>}
    elimination: typing.ClassVar[MatchType]  # value = <MatchType.elimination: 3>
    none: typing.ClassVar[MatchType]  # value = <MatchType.none: 0>
    practice: typing.ClassVar[MatchType]  # value = <MatchType.practice: 1>
    qualification: typing.ClassVar[MatchType]  # value = <MatchType.qualification: 2>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class RuntimeType:
    """
    Runtime type.
    
    Members:
    
      HAL_Runtime_RoboRIO : roboRIO 1.0
    
      HAL_Runtime_RoboRIO2 : roboRIO 2.0
    
      HAL_Runtime_Simulation : Simulation runtime
    """
    HAL_Runtime_RoboRIO: typing.ClassVar[RuntimeType]  # value = <RuntimeType.HAL_Runtime_RoboRIO: 0>
    HAL_Runtime_RoboRIO2: typing.ClassVar[RuntimeType]  # value = <RuntimeType.HAL_Runtime_RoboRIO2: 1>
    HAL_Runtime_Simulation: typing.ClassVar[RuntimeType]  # value = <RuntimeType.HAL_Runtime_Simulation: 2>
    __members__: typing.ClassVar[dict[str, RuntimeType]]  # value = {'HAL_Runtime_RoboRIO': <RuntimeType.HAL_Runtime_RoboRIO: 0>, 'HAL_Runtime_RoboRIO2': <RuntimeType.HAL_Runtime_RoboRIO2: 1>, 'HAL_Runtime_Simulation': <RuntimeType.HAL_Runtime_Simulation: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SPIMode:
    """
    SPI mode.
    
    Members:
    
      kMode0 : Clock idle low, data sampled on rising edge.
    
      kMode1 : Clock idle low, data sampled on falling edge.
    
      kMode2 : Clock idle high, data sampled on falling edge.
    
      kMode3 : Clock idle high, data sampled on rising edge.
    """
    __members__: typing.ClassVar[dict[str, SPIMode]]  # value = {'kMode0': <SPIMode.kMode0: 0>, 'kMode1': <SPIMode.kMode1: 1>, 'kMode2': <SPIMode.kMode2: 2>, 'kMode3': <SPIMode.kMode3: 3>}
    kMode0: typing.ClassVar[SPIMode]  # value = <SPIMode.kMode0: 0>
    kMode1: typing.ClassVar[SPIMode]  # value = <SPIMode.kMode1: 1>
    kMode2: typing.ClassVar[SPIMode]  # value = <SPIMode.kMode2: 2>
    kMode3: typing.ClassVar[SPIMode]  # value = <SPIMode.kMode3: 3>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SPIPort:
    """
    SPI port.
    
    Members:
    
      kInvalid : Invalid port number.
    
      kOnboardCS0 : Onboard SPI bus port CS0.
    
      kOnboardCS1 : Onboard SPI bus port CS1.
    
      kOnboardCS2 : Onboard SPI bus port CS2.
    
      kOnboardCS3 : Onboard SPI bus port CS3.
    
      kMXP : MXP (roboRIO MXP) SPI bus port.
    """
    __members__: typing.ClassVar[dict[str, SPIPort]]  # value = {'kInvalid': <SPIPort.kInvalid: -1>, 'kOnboardCS0': <SPIPort.kOnboardCS0: 0>, 'kOnboardCS1': <SPIPort.kOnboardCS1: 1>, 'kOnboardCS2': <SPIPort.kOnboardCS2: 2>, 'kOnboardCS3': <SPIPort.kOnboardCS3: 3>, 'kMXP': <SPIPort.kMXP: 4>}
    kInvalid: typing.ClassVar[SPIPort]  # value = <SPIPort.kInvalid: -1>
    kMXP: typing.ClassVar[SPIPort]  # value = <SPIPort.kMXP: 4>
    kOnboardCS0: typing.ClassVar[SPIPort]  # value = <SPIPort.kOnboardCS0: 0>
    kOnboardCS1: typing.ClassVar[SPIPort]  # value = <SPIPort.kOnboardCS1: 1>
    kOnboardCS2: typing.ClassVar[SPIPort]  # value = <SPIPort.kOnboardCS2: 2>
    kOnboardCS3: typing.ClassVar[SPIPort]  # value = <SPIPort.kOnboardCS3: 3>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class SimBoolean(SimValue):
    """
    Wrapper around a HAL simulator boolean value.
    
    It is not useful to construct these directly -- they are returned from
    :meth:`.SimDeviceSim.getBoolean` or :meth:`.SimDevice.createBoolean`.
    """
    value: bool
    def __init__(self, handle: typing.SupportsInt) -> None:
        """
        Wraps a simulated value handle as returned by HAL_CreateSimValueBoolean().
        
        :param handle: simulated value handle
        """
    def __repr__(self) -> str:
        ...
    def get(self) -> bool:
        """
        Gets the simulated value.
        
        :returns: The current value
        """
    def set(self, value: bool) -> None:
        """
        Sets the simulated value.
        
        :param value: the value to set
        """
class SimDevice:
    """
    Wrapper around a HAL simulation 'device'
    
    This creates a simulated 'device' object that can be interacted with
    from user SimDeviceSim objects or via the Simulation GUI.
    
    .. note:: To interact with an existing device use
              :class:`hal.simulation.SimDeviceSim` instead.
    """
    class Direction:
        """
        Direction of a simulated value (from the perspective of user code).
        
        Members:
        
          kInput
        
          kOutput
        
          kBidir
        """
        __members__: typing.ClassVar[dict[str, SimDevice.Direction]]  # value = {'kInput': <Direction.kInput: 0>, 'kOutput': <Direction.kOutput: 1>, 'kBidir': <Direction.kBidir: 2>}
        kBidir: typing.ClassVar[SimDevice.Direction]  # value = <Direction.kBidir: 2>
        kInput: typing.ClassVar[SimDevice.Direction]  # value = <Direction.kInput: 0>
        kOutput: typing.ClassVar[SimDevice.Direction]  # value = <Direction.kOutput: 1>
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: typing.SupportsInt) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: typing.SupportsInt) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __bool__(self) -> bool:
        ...
    @typing.overload
    def __init__(self, name: str) -> None:
        """
        Creates a simulated device.
        
        The device name must be unique.  Returns null if the device name
        already exists.  If multiple instances of the same device are desired,
        recommend appending the instance/unique identifier in brackets to the base
        name, e.g. "device[1]".
        
        Using a device name of the form "Type:Name" will create a WebSockets node
        with a type value of "Type" and a device value of "Name"
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name: device name
        """
    @typing.overload
    def __init__(self, name: str, index: typing.SupportsInt) -> None:
        """
        Creates a simulated device.
        
        The device name must be unique.  Returns null if the device name
        already exists.  This is a convenience method that appends index in
        brackets to the device name, e.g. passing index=1 results in "device[1]"
        for the device name.
        
        Using a device name of the form "Type:Name" will create a WebSockets node
        with a type value of "Type" and a device value of "Name"
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:  device name
        :param index: device index number to append to name
        """
    @typing.overload
    def __init__(self, name: str, index: typing.SupportsInt, channel: typing.SupportsInt) -> None:
        """
        Creates a simulated device.
        
        The device name must be unique.  Returns null if the device name
        already exists.  This is a convenience method that appends index and
        channel in brackets to the device name, e.g. passing index=1 and channel=2
        results in "device[1,2]" for the device name.
        
        Using a device name of the form "Type:Name" will create a WebSockets node
        with a type value of "Type" and a device value of "Name"
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:    device name
        :param index:   device index number to append to name
        :param channel: device channel number to append to name
        """
    def __repr__(self) -> str:
        ...
    def createBoolean(self, name: str, direction: typing.SupportsInt, initialValue: bool) -> SimBoolean:
        """
        Creates a boolean value on the simulated device.
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:         value name
        :param direction:    input/output/bidir (from perspective of user code)
        :param initialValue: initial value
        
        :returns: simulated boolean value object
        """
    def createDouble(self, name: str, direction: typing.SupportsInt, initialValue: typing.SupportsFloat) -> SimDouble:
        """
        Creates a double value on the simulated device.
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:         value name
        :param direction:    input/output/bidir (from perspective of user code)
        :param initialValue: initial value
        
        :returns: simulated double value object
        """
    def createEnum(self, name: str, direction: typing.SupportsInt, options: collections.abc.Sequence[str], initialValue: typing.SupportsInt) -> SimEnum:
        """
        Creates an enumerated value on the simulated device.
        
        Enumerated values are always in the range 0 to numOptions-1.
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:         value name
        :param direction:    input/output/bidir (from perspective of user code)
        :param options:      array of option descriptions
        :param initialValue: initial value (selection)
        
        :returns: simulated enum value object
        """
    def createEnumDouble(self, name: str, direction: typing.SupportsInt, options: collections.abc.Sequence[str], optionValues: collections.abc.Sequence[typing.SupportsFloat], initialValue: typing.SupportsInt) -> SimEnum:
        """
        Creates an enumerated value on the simulated device with double values.
        
        Enumerated values are always in the range 0 to numOptions-1.
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:         value name
        :param direction:    input/output/bidir (from perspective of user code)
        :param options:      array of option descriptions
        :param optionValues: array of option values (must be the same size as
                             options)
        :param initialValue: initial value (selection)
        
        :returns: simulated enum value object
        """
    def createInt(self, name: str, direction: typing.SupportsInt, initialValue: typing.SupportsInt) -> SimInt:
        """
        Creates an int value on the simulated device.
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:         value name
        :param direction:    input/output/bidir (from perspective of user code)
        :param initialValue: initial value
        
        :returns: simulated double value object
        """
    def createLong(self, name: str, direction: typing.SupportsInt, initialValue: typing.SupportsInt) -> SimLong:
        """
        Creates a long value on the simulated device.
        
        If not in simulation, results in an "empty" object that evaluates to false
        in a boolean context.
        
        :param name:         value name
        :param direction:    input/output/bidir (from perspective of user code)
        :param initialValue: initial value
        
        :returns: simulated double value object
        """
    def getName(self) -> str:
        """
        Get the name of the simulated device.
        
        :returns: name
        """
    @property
    def name(self) -> str:
        ...
class SimDouble(SimValue):
    """
    Wrapper around a HAL simulator double value.
    
    It is not useful to construct these directly -- they are returned from
    :meth:`.SimDeviceSim.getDouble` or :meth:`.SimDevice.createDouble`.
    """
    def __init__(self, handle: typing.SupportsInt) -> None:
        """
        Wraps a simulated value handle as returned by HAL_CreateSimValueDouble().
        
        :param handle: simulated value handle
        """
    def __repr__(self) -> str:
        ...
    def get(self) -> float:
        """
        Gets the simulated value.
        
        :returns: The current value
        """
    def reset(self) -> None:
        """
        Resets the simulated value to 0. Use this instead of Set(0) for resetting
        incremental sensor values like encoder counts or gyro accumulated angle
        to ensure correct behavior in a distributed system (e.g. WebSockets).
        """
    def set(self, value: typing.SupportsFloat) -> None:
        """
        Sets the simulated value.
        
        :param value: the value to set
        """
    @property
    def value(self) -> float:
        ...
    @value.setter
    def value(self, arg1: typing.SupportsFloat) -> None:
        ...
class SimEnum(SimValue):
    """
    Wrapper around a HAL simulator enum value.
    
    It is not useful to construct these directly -- they are returned from
    :meth:`.SimDeviceSim.getEnum` or :meth:`.SimDevice.createEnum`.
    """
    def __init__(self, handle: typing.SupportsInt) -> None:
        """
        Wraps a simulated value handle as returned by HAL_CreateSimValueEnum().
        
        :param handle: simulated value handle
        """
    def __repr__(self) -> str:
        ...
    def get(self) -> int:
        """
        Gets the simulated value.
        
        :returns: The current value
        """
    def set(self, value: typing.SupportsInt) -> None:
        """
        Sets the simulated value.
        
        :param value: the value to set
        """
    @property
    def value(self) -> int:
        ...
    @value.setter
    def value(self, arg1: typing.SupportsInt) -> None:
        ...
class SimInt(SimValue):
    """
    Wrapper around a HAL simulator int value handle.
    
    It is not useful to construct these directly, they are returned
    from various functions.
    """
    def __init__(self, handle: typing.SupportsInt) -> None:
        """
        Wraps a simulated value handle as returned by HAL_CreateSimValueInt().
        
        :param handle: simulated value handle
        """
    def __repr__(self) -> str:
        ...
    def get(self) -> int:
        """
        Gets the simulated value.
        
        :returns: The current value
        """
    def reset(self) -> None:
        """
        Resets the simulated value to 0. Use this instead of Set(0) for resetting
        incremental sensor values like encoder counts or gyro accumulated angle
        to ensure correct behavior in a distributed system (e.g. WebSockets).
        """
    def set(self, value: typing.SupportsInt) -> None:
        """
        Sets the simulated value.
        
        :param value: the value to set
        """
    @property
    def value(self) -> int:
        ...
    @value.setter
    def value(self, arg1: typing.SupportsInt) -> None:
        ...
class SimLong(SimValue):
    """
    Wrapper around a HAL simulator long value handle.
    
    It is not useful to construct these directly, they are returned
    from various functions.
    """
    def __init__(self, handle: typing.SupportsInt) -> None:
        """
        Wraps a simulated value handle as returned by HAL_CreateSimValueLong().
        
        :param handle: simulated value handle
        """
    def __repr__(self) -> str:
        ...
    def get(self) -> int:
        """
        Gets the simulated value.
        
        :returns: The current value
        """
    def reset(self) -> None:
        """
        Resets the simulated value to 0. Use this instead of Set(0) for resetting
        incremental sensor values like encoder counts or gyro accumulated angle
        to ensure correct behavior in a distributed system (e.g. WebSockets).
        """
    def set(self, value: typing.SupportsInt) -> None:
        """
        Sets the simulated value.
        
        :param value: the value to set
        """
    @property
    def value(self) -> int:
        ...
    @value.setter
    def value(self, arg1: typing.SupportsInt) -> None:
        ...
class SimValue:
    """
    Readonly wrapper around a HAL simulator value.
    
    It is not useful to construct these directly -- they are returned from
    :meth:`.SimDeviceSim.getValue` or :meth:`.SimDevice.createValue`.
    """
    def __bool__(self) -> bool:
        ...
    def __init__(self, handle: typing.SupportsInt) -> None:
        """
        Wraps a simulated value handle as returned by HAL_CreateSimValue().
        
        :param handle: simulated value handle
        """
    def __repr__(self) -> str:
        ...
    @property
    def type(self) -> Type:
        ...
    @property
    def value(self) -> typing.Any:
        ...
class SimValueDirection:
    """
    Direction of a simulated value (from the perspective of user code).
    
    Members:
    
      HAL_SimValueInput : input to user code from the simulator
    
      HAL_SimValueOutput : output from user code to the simulator
    
      HAL_SimValueBidir : bidirectional between user code and simulator
    """
    HAL_SimValueBidir: typing.ClassVar[SimValueDirection]  # value = <SimValueDirection.HAL_SimValueBidir: 2>
    HAL_SimValueInput: typing.ClassVar[SimValueDirection]  # value = <SimValueDirection.HAL_SimValueInput: 0>
    HAL_SimValueOutput: typing.ClassVar[SimValueDirection]  # value = <SimValueDirection.HAL_SimValueOutput: 1>
    __members__: typing.ClassVar[dict[str, SimValueDirection]]  # value = {'HAL_SimValueInput': <SimValueDirection.HAL_SimValueInput: 0>, 'HAL_SimValueOutput': <SimValueDirection.HAL_SimValueOutput: 1>, 'HAL_SimValueBidir': <SimValueDirection.HAL_SimValueBidir: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Type:
    """
    Members:
    
      UNASSIGNED
    
      BOOLEAN
    
      DOUBLE
    
      ENUM
    
      INT
    
      LONG
    """
    BOOLEAN: typing.ClassVar[Type]  # value = <Type.BOOLEAN: 1>
    DOUBLE: typing.ClassVar[Type]  # value = <Type.DOUBLE: 2>
    ENUM: typing.ClassVar[Type]  # value = <Type.ENUM: 4>
    INT: typing.ClassVar[Type]  # value = <Type.INT: 8>
    LONG: typing.ClassVar[Type]  # value = <Type.LONG: 16>
    UNASSIGNED: typing.ClassVar[Type]  # value = <Type.UNASSIGNED: 0>
    __members__: typing.ClassVar[dict[str, Type]]  # value = {'UNASSIGNED': <Type.UNASSIGNED: 0>, 'BOOLEAN': <Type.BOOLEAN: 1>, 'DOUBLE': <Type.DOUBLE: 2>, 'ENUM': <Type.ENUM: 4>, 'INT': <Type.INT: 8>, 'LONG': <Type.LONG: 16>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class Value:
    def __repr__(self) -> str:
        ...
    @property
    def type(self) -> Type:
        ...
    @property
    def value(self) -> typing.Any:
        ...
class tInstances:
    """
    Members:
    
      kLanguage_LabVIEW
    
      kLanguage_CPlusPlus
    
      kLanguage_Java
    
      kLanguage_Python
    
      kLanguage_DotNet
    
      kLanguage_Kotlin
    
      kLanguage_Rust
    
      kCANPlugin_BlackJagBridge
    
      kCANPlugin_2CAN
    
      kFramework_Iterative
    
      kFramework_Simple
    
      kFramework_CommandControl
    
      kFramework_Timed
    
      kFramework_ROS
    
      kFramework_RobotBuilder
    
      kFramework_AdvantageKit
    
      kFramework_MagicBot
    
      kFramework_KitBotTraditional
    
      kFramework_KitBotInline
    
      kFramework_Everybot
    
      kRobotDrive_ArcadeStandard
    
      kRobotDrive_ArcadeButtonSpin
    
      kRobotDrive_ArcadeRatioCurve
    
      kRobotDrive_Tank
    
      kRobotDrive_MecanumPolar
    
      kRobotDrive_MecanumCartesian
    
      kRobotDrive2_DifferentialArcade
    
      kRobotDrive2_DifferentialTank
    
      kRobotDrive2_DifferentialCurvature
    
      kRobotDrive2_MecanumCartesian
    
      kRobotDrive2_MecanumPolar
    
      kRobotDrive2_KilloughCartesian
    
      kRobotDrive2_KilloughPolar
    
      kRobotDriveSwerve_Other
    
      kRobotDriveSwerve_YAGSL
    
      kRobotDriveSwerve_CTRE
    
      kRobotDriveSwerve_MaxSwerve
    
      kRobotDriveSwerve_AdvantageKit
    
      kDriverStationCIO_Analog
    
      kDriverStationCIO_DigitalIn
    
      kDriverStationCIO_DigitalOut
    
      kDriverStationEIO_Acceleration
    
      kDriverStationEIO_AnalogIn
    
      kDriverStationEIO_AnalogOut
    
      kDriverStationEIO_Button
    
      kDriverStationEIO_LED
    
      kDriverStationEIO_DigitalIn
    
      kDriverStationEIO_DigitalOut
    
      kDriverStationEIO_FixedDigitalOut
    
      kDriverStationEIO_PWM
    
      kDriverStationEIO_Encoder
    
      kDriverStationEIO_TouchSlider
    
      kADXL345_SPI
    
      kADXL345_I2C
    
      kCommand_Scheduler
    
      kCommand2_Scheduler
    
      kSmartDashboard_Instance
    
      kSmartDashboard_LiveWindow
    
      kKinematics_DifferentialDrive
    
      kKinematics_MecanumDrive
    
      kKinematics_SwerveDrive
    
      kOdometry_DifferentialDrive
    
      kOdometry_MecanumDrive
    
      kOdometry_SwerveDrive
    
      kDashboard_Unknown
    
      kDashboard_Glass
    
      kDashboard_SmartDashboard
    
      kDashboard_Shuffleboard
    
      kDashboard_Elastic
    
      kDashboard_LabVIEW
    
      kDashboard_AdvantageScope
    
      kDashboard_QFRCDashboard
    
      kDashboard_FRCWebComponents
    
      kDataLogLocation_Onboard
    
      kDataLogLocation_USB
    
      kLoggingFramework_Other
    
      kLoggingFramework_Epilogue
    
      kLoggingFramework_Monologue
    
      kLoggingFramework_AdvantageKit
    
      kLoggingFramework_DogLog
    
      kPDP_CTRE
    
      kPDP_REV
    
      kPDP_Unknown
    """
    __members__: typing.ClassVar[dict[str, tInstances]]  # value = {'kLanguage_LabVIEW': <tInstances.kLanguage_LabVIEW: 1>, 'kLanguage_CPlusPlus': <tInstances.kLanguage_CPlusPlus: 2>, 'kLanguage_Java': <tInstances.kLanguage_Java: 3>, 'kLanguage_Python': <tInstances.kLanguage_Python: 4>, 'kLanguage_DotNet': <tInstances.kLanguage_DotNet: 5>, 'kLanguage_Kotlin': <tInstances.kLanguage_Kotlin: 6>, 'kLanguage_Rust': <tInstances.kLanguage_Rust: 7>, 'kCANPlugin_BlackJagBridge': <tInstances.kLanguage_LabVIEW: 1>, 'kCANPlugin_2CAN': <tInstances.kLanguage_CPlusPlus: 2>, 'kFramework_Iterative': <tInstances.kLanguage_LabVIEW: 1>, 'kFramework_Simple': <tInstances.kLanguage_CPlusPlus: 2>, 'kFramework_CommandControl': <tInstances.kLanguage_Java: 3>, 'kFramework_Timed': <tInstances.kLanguage_Python: 4>, 'kFramework_ROS': <tInstances.kLanguage_DotNet: 5>, 'kFramework_RobotBuilder': <tInstances.kLanguage_Kotlin: 6>, 'kFramework_AdvantageKit': <tInstances.kLanguage_Rust: 7>, 'kFramework_MagicBot': <tInstances.kFramework_MagicBot: 8>, 'kFramework_KitBotTraditional': <tInstances.kFramework_KitBotTraditional: 9>, 'kFramework_KitBotInline': <tInstances.kFramework_KitBotInline: 10>, 'kFramework_Everybot': <tInstances.kFramework_Everybot: 11>, 'kRobotDrive_ArcadeStandard': <tInstances.kLanguage_LabVIEW: 1>, 'kRobotDrive_ArcadeButtonSpin': <tInstances.kLanguage_CPlusPlus: 2>, 'kRobotDrive_ArcadeRatioCurve': <tInstances.kLanguage_Java: 3>, 'kRobotDrive_Tank': <tInstances.kLanguage_Python: 4>, 'kRobotDrive_MecanumPolar': <tInstances.kLanguage_DotNet: 5>, 'kRobotDrive_MecanumCartesian': <tInstances.kLanguage_Kotlin: 6>, 'kRobotDrive2_DifferentialArcade': <tInstances.kLanguage_Rust: 7>, 'kRobotDrive2_DifferentialTank': <tInstances.kFramework_MagicBot: 8>, 'kRobotDrive2_DifferentialCurvature': <tInstances.kFramework_KitBotTraditional: 9>, 'kRobotDrive2_MecanumCartesian': <tInstances.kFramework_KitBotInline: 10>, 'kRobotDrive2_MecanumPolar': <tInstances.kFramework_Everybot: 11>, 'kRobotDrive2_KilloughCartesian': <tInstances.kRobotDrive2_KilloughCartesian: 12>, 'kRobotDrive2_KilloughPolar': <tInstances.kRobotDrive2_KilloughPolar: 13>, 'kRobotDriveSwerve_Other': <tInstances.kRobotDriveSwerve_Other: 14>, 'kRobotDriveSwerve_YAGSL': <tInstances.kRobotDriveSwerve_YAGSL: 15>, 'kRobotDriveSwerve_CTRE': <tInstances.kRobotDriveSwerve_CTRE: 16>, 'kRobotDriveSwerve_MaxSwerve': <tInstances.kRobotDriveSwerve_MaxSwerve: 17>, 'kRobotDriveSwerve_AdvantageKit': <tInstances.kRobotDriveSwerve_AdvantageKit: 18>, 'kDriverStationCIO_Analog': <tInstances.kLanguage_LabVIEW: 1>, 'kDriverStationCIO_DigitalIn': <tInstances.kLanguage_CPlusPlus: 2>, 'kDriverStationCIO_DigitalOut': <tInstances.kLanguage_Java: 3>, 'kDriverStationEIO_Acceleration': <tInstances.kLanguage_LabVIEW: 1>, 'kDriverStationEIO_AnalogIn': <tInstances.kLanguage_CPlusPlus: 2>, 'kDriverStationEIO_AnalogOut': <tInstances.kLanguage_Java: 3>, 'kDriverStationEIO_Button': <tInstances.kLanguage_Python: 4>, 'kDriverStationEIO_LED': <tInstances.kLanguage_DotNet: 5>, 'kDriverStationEIO_DigitalIn': <tInstances.kLanguage_Kotlin: 6>, 'kDriverStationEIO_DigitalOut': <tInstances.kLanguage_Rust: 7>, 'kDriverStationEIO_FixedDigitalOut': <tInstances.kFramework_MagicBot: 8>, 'kDriverStationEIO_PWM': <tInstances.kFramework_KitBotTraditional: 9>, 'kDriverStationEIO_Encoder': <tInstances.kFramework_KitBotInline: 10>, 'kDriverStationEIO_TouchSlider': <tInstances.kFramework_Everybot: 11>, 'kADXL345_SPI': <tInstances.kLanguage_LabVIEW: 1>, 'kADXL345_I2C': <tInstances.kLanguage_CPlusPlus: 2>, 'kCommand_Scheduler': <tInstances.kLanguage_LabVIEW: 1>, 'kCommand2_Scheduler': <tInstances.kLanguage_CPlusPlus: 2>, 'kSmartDashboard_Instance': <tInstances.kLanguage_LabVIEW: 1>, 'kSmartDashboard_LiveWindow': <tInstances.kLanguage_CPlusPlus: 2>, 'kKinematics_DifferentialDrive': <tInstances.kLanguage_LabVIEW: 1>, 'kKinematics_MecanumDrive': <tInstances.kLanguage_CPlusPlus: 2>, 'kKinematics_SwerveDrive': <tInstances.kLanguage_Java: 3>, 'kOdometry_DifferentialDrive': <tInstances.kLanguage_LabVIEW: 1>, 'kOdometry_MecanumDrive': <tInstances.kLanguage_CPlusPlus: 2>, 'kOdometry_SwerveDrive': <tInstances.kLanguage_Java: 3>, 'kDashboard_Unknown': <tInstances.kLanguage_LabVIEW: 1>, 'kDashboard_Glass': <tInstances.kLanguage_CPlusPlus: 2>, 'kDashboard_SmartDashboard': <tInstances.kLanguage_Java: 3>, 'kDashboard_Shuffleboard': <tInstances.kLanguage_Python: 4>, 'kDashboard_Elastic': <tInstances.kLanguage_DotNet: 5>, 'kDashboard_LabVIEW': <tInstances.kLanguage_Kotlin: 6>, 'kDashboard_AdvantageScope': <tInstances.kLanguage_Rust: 7>, 'kDashboard_QFRCDashboard': <tInstances.kFramework_MagicBot: 8>, 'kDashboard_FRCWebComponents': <tInstances.kFramework_KitBotTraditional: 9>, 'kDataLogLocation_Onboard': <tInstances.kLanguage_LabVIEW: 1>, 'kDataLogLocation_USB': <tInstances.kLanguage_CPlusPlus: 2>, 'kLoggingFramework_Other': <tInstances.kLanguage_LabVIEW: 1>, 'kLoggingFramework_Epilogue': <tInstances.kLanguage_CPlusPlus: 2>, 'kLoggingFramework_Monologue': <tInstances.kLanguage_Java: 3>, 'kLoggingFramework_AdvantageKit': <tInstances.kLanguage_Python: 4>, 'kLoggingFramework_DogLog': <tInstances.kLanguage_DotNet: 5>, 'kPDP_CTRE': <tInstances.kLanguage_LabVIEW: 1>, 'kPDP_REV': <tInstances.kLanguage_CPlusPlus: 2>, 'kPDP_Unknown': <tInstances.kLanguage_Java: 3>}
    kADXL345_I2C: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kADXL345_SPI: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kCANPlugin_2CAN: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kCANPlugin_BlackJagBridge: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kCommand2_Scheduler: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kCommand_Scheduler: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kDashboard_AdvantageScope: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Rust: 7>
    kDashboard_Elastic: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_DotNet: 5>
    kDashboard_FRCWebComponents: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_KitBotTraditional: 9>
    kDashboard_Glass: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kDashboard_LabVIEW: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Kotlin: 6>
    kDashboard_QFRCDashboard: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_MagicBot: 8>
    kDashboard_Shuffleboard: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Python: 4>
    kDashboard_SmartDashboard: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kDashboard_Unknown: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kDataLogLocation_Onboard: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kDataLogLocation_USB: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kDriverStationCIO_Analog: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kDriverStationCIO_DigitalIn: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kDriverStationCIO_DigitalOut: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kDriverStationEIO_Acceleration: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kDriverStationEIO_AnalogIn: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kDriverStationEIO_AnalogOut: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kDriverStationEIO_Button: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Python: 4>
    kDriverStationEIO_DigitalIn: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Kotlin: 6>
    kDriverStationEIO_DigitalOut: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Rust: 7>
    kDriverStationEIO_Encoder: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_KitBotInline: 10>
    kDriverStationEIO_FixedDigitalOut: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_MagicBot: 8>
    kDriverStationEIO_LED: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_DotNet: 5>
    kDriverStationEIO_PWM: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_KitBotTraditional: 9>
    kDriverStationEIO_TouchSlider: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_Everybot: 11>
    kFramework_AdvantageKit: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Rust: 7>
    kFramework_CommandControl: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kFramework_Everybot: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_Everybot: 11>
    kFramework_Iterative: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kFramework_KitBotInline: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_KitBotInline: 10>
    kFramework_KitBotTraditional: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_KitBotTraditional: 9>
    kFramework_MagicBot: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_MagicBot: 8>
    kFramework_ROS: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_DotNet: 5>
    kFramework_RobotBuilder: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Kotlin: 6>
    kFramework_Simple: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kFramework_Timed: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Python: 4>
    kKinematics_DifferentialDrive: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kKinematics_MecanumDrive: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kKinematics_SwerveDrive: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kLanguage_CPlusPlus: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kLanguage_DotNet: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_DotNet: 5>
    kLanguage_Java: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kLanguage_Kotlin: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Kotlin: 6>
    kLanguage_LabVIEW: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kLanguage_Python: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Python: 4>
    kLanguage_Rust: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Rust: 7>
    kLoggingFramework_AdvantageKit: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Python: 4>
    kLoggingFramework_DogLog: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_DotNet: 5>
    kLoggingFramework_Epilogue: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kLoggingFramework_Monologue: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kLoggingFramework_Other: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kOdometry_DifferentialDrive: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kOdometry_MecanumDrive: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kOdometry_SwerveDrive: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kPDP_CTRE: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kPDP_REV: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kPDP_Unknown: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kRobotDrive2_DifferentialArcade: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Rust: 7>
    kRobotDrive2_DifferentialCurvature: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_KitBotTraditional: 9>
    kRobotDrive2_DifferentialTank: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_MagicBot: 8>
    kRobotDrive2_KilloughCartesian: typing.ClassVar[tInstances]  # value = <tInstances.kRobotDrive2_KilloughCartesian: 12>
    kRobotDrive2_KilloughPolar: typing.ClassVar[tInstances]  # value = <tInstances.kRobotDrive2_KilloughPolar: 13>
    kRobotDrive2_MecanumCartesian: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_KitBotInline: 10>
    kRobotDrive2_MecanumPolar: typing.ClassVar[tInstances]  # value = <tInstances.kFramework_Everybot: 11>
    kRobotDriveSwerve_AdvantageKit: typing.ClassVar[tInstances]  # value = <tInstances.kRobotDriveSwerve_AdvantageKit: 18>
    kRobotDriveSwerve_CTRE: typing.ClassVar[tInstances]  # value = <tInstances.kRobotDriveSwerve_CTRE: 16>
    kRobotDriveSwerve_MaxSwerve: typing.ClassVar[tInstances]  # value = <tInstances.kRobotDriveSwerve_MaxSwerve: 17>
    kRobotDriveSwerve_Other: typing.ClassVar[tInstances]  # value = <tInstances.kRobotDriveSwerve_Other: 14>
    kRobotDriveSwerve_YAGSL: typing.ClassVar[tInstances]  # value = <tInstances.kRobotDriveSwerve_YAGSL: 15>
    kRobotDrive_ArcadeButtonSpin: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    kRobotDrive_ArcadeRatioCurve: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Java: 3>
    kRobotDrive_ArcadeStandard: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kRobotDrive_MecanumCartesian: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Kotlin: 6>
    kRobotDrive_MecanumPolar: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_DotNet: 5>
    kRobotDrive_Tank: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_Python: 4>
    kSmartDashboard_Instance: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_LabVIEW: 1>
    kSmartDashboard_LiveWindow: typing.ClassVar[tInstances]  # value = <tInstances.kLanguage_CPlusPlus: 2>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class tResourceType:
    """
    Members:
    
      kResourceType_Controller
    
      kResourceType_Module
    
      kResourceType_Language
    
      kResourceType_CANPlugin
    
      kResourceType_Accelerometer
    
      kResourceType_ADXL345
    
      kResourceType_AnalogChannel
    
      kResourceType_AnalogTrigger
    
      kResourceType_AnalogTriggerOutput
    
      kResourceType_CANJaguar
    
      kResourceType_Compressor
    
      kResourceType_Counter
    
      kResourceType_Dashboard
    
      kResourceType_DigitalInput
    
      kResourceType_DigitalOutput
    
      kResourceType_DriverStationCIO
    
      kResourceType_DriverStationEIO
    
      kResourceType_DriverStationLCD
    
      kResourceType_Encoder
    
      kResourceType_GearTooth
    
      kResourceType_Gyro
    
      kResourceType_I2C
    
      kResourceType_Framework
    
      kResourceType_Jaguar
    
      kResourceType_Joystick
    
      kResourceType_Kinect
    
      kResourceType_KinectStick
    
      kResourceType_PIDController
    
      kResourceType_Preferences
    
      kResourceType_PWM
    
      kResourceType_Relay
    
      kResourceType_RobotDrive
    
      kResourceType_SerialPort
    
      kResourceType_Servo
    
      kResourceType_Solenoid
    
      kResourceType_SPI
    
      kResourceType_Task
    
      kResourceType_Ultrasonic
    
      kResourceType_Victor
    
      kResourceType_Button
    
      kResourceType_Command
    
      kResourceType_AxisCamera
    
      kResourceType_PCVideoServer
    
      kResourceType_SmartDashboard
    
      kResourceType_Talon
    
      kResourceType_HiTechnicColorSensor
    
      kResourceType_HiTechnicAccel
    
      kResourceType_HiTechnicCompass
    
      kResourceType_SRF08
    
      kResourceType_AnalogOutput
    
      kResourceType_VictorSP
    
      kResourceType_PWMTalonSRX
    
      kResourceType_CANTalonSRX
    
      kResourceType_ADXL362
    
      kResourceType_ADXRS450
    
      kResourceType_RevSPARK
    
      kResourceType_MindsensorsSD540
    
      kResourceType_DigitalGlitchFilter
    
      kResourceType_ADIS16448
    
      kResourceType_PDP
    
      kResourceType_PCM
    
      kResourceType_PigeonIMU
    
      kResourceType_NidecBrushless
    
      kResourceType_CANifier
    
      kResourceType_TalonFX
    
      kResourceType_CTRE_future1
    
      kResourceType_CTRE_future2
    
      kResourceType_CTRE_future3
    
      kResourceType_CTRE_future4
    
      kResourceType_CTRE_future5
    
      kResourceType_CTRE_future6
    
      kResourceType_LinearFilter
    
      kResourceType_XboxController
    
      kResourceType_UsbCamera
    
      kResourceType_NavX
    
      kResourceType_Pixy
    
      kResourceType_Pixy2
    
      kResourceType_ScanseSweep
    
      kResourceType_Shuffleboard
    
      kResourceType_CAN
    
      kResourceType_DigilentDMC60
    
      kResourceType_PWMVictorSPX
    
      kResourceType_RevSparkMaxPWM
    
      kResourceType_RevSparkMaxCAN
    
      kResourceType_ADIS16470
    
      kResourceType_PIDController2
    
      kResourceType_ProfiledPIDController
    
      kResourceType_Kinematics
    
      kResourceType_Odometry
    
      kResourceType_Units
    
      kResourceType_TrapezoidProfile
    
      kResourceType_DutyCycle
    
      kResourceType_AddressableLEDs
    
      kResourceType_FusionVenom
    
      kResourceType_CTRE_future7
    
      kResourceType_CTRE_future8
    
      kResourceType_CTRE_future9
    
      kResourceType_CTRE_future10
    
      kResourceType_CTRE_future11
    
      kResourceType_CTRE_future12
    
      kResourceType_CTRE_future13
    
      kResourceType_CTRE_future14
    
      kResourceType_ExponentialProfile
    
      kResourceType_PS4Controller
    
      kResourceType_PhotonCamera
    
      kResourceType_PhotonPoseEstimator
    
      kResourceType_PathPlannerPath
    
      kResourceType_PathPlannerAuto
    
      kResourceType_PathFindingCommand
    
      kResourceType_Redux_future1
    
      kResourceType_Redux_future2
    
      kResourceType_Redux_future3
    
      kResourceType_Redux_future4
    
      kResourceType_Redux_future5
    
      kResourceType_RevSparkFlexCAN
    
      kResourceType_RevSparkFlexPWM
    
      kResourceType_BangBangController
    
      kResourceType_DataLogManager
    
      kResourceType_LoggingFramework
    
      kResourceType_ChoreoTrajectory
    
      kResourceType_ChoreoTrigger
    
      kResourceType_PathWeaverTrajectory
    
      kResourceType_Koors40
    
      kResourceType_ThriftyNova
    
      kResourceType_RevServoHub
    
      kResourceType_PWFSEN36005
    
      kResourceType_LaserShark
    
      kResourceType_YAMS
    
      kResourceType_LEDPattern
    
      kResourceType_LinearQuadraticRegulator
    
      kResourceType_KalmanFilter
    
      kResourceType_PoseEstimator
    
      kResourceType_PoseEstimator3d
    
      kResourceType_LinearSystemLoop
    
      kResourceType_LumynLabs_ConnectorX
    
      kResourceType_LumynLabs_ConnectorXAnimate
    """
    __members__: typing.ClassVar[dict[str, tResourceType]]  # value = {'kResourceType_Controller': <tResourceType.kResourceType_Controller: 0>, 'kResourceType_Module': <tResourceType.kResourceType_Module: 1>, 'kResourceType_Language': <tResourceType.kResourceType_Language: 2>, 'kResourceType_CANPlugin': <tResourceType.kResourceType_CANPlugin: 3>, 'kResourceType_Accelerometer': <tResourceType.kResourceType_Accelerometer: 4>, 'kResourceType_ADXL345': <tResourceType.kResourceType_ADXL345: 5>, 'kResourceType_AnalogChannel': <tResourceType.kResourceType_AnalogChannel: 6>, 'kResourceType_AnalogTrigger': <tResourceType.kResourceType_AnalogTrigger: 7>, 'kResourceType_AnalogTriggerOutput': <tResourceType.kResourceType_AnalogTriggerOutput: 8>, 'kResourceType_CANJaguar': <tResourceType.kResourceType_CANJaguar: 9>, 'kResourceType_Compressor': <tResourceType.kResourceType_Compressor: 10>, 'kResourceType_Counter': <tResourceType.kResourceType_Counter: 11>, 'kResourceType_Dashboard': <tResourceType.kResourceType_Dashboard: 12>, 'kResourceType_DigitalInput': <tResourceType.kResourceType_DigitalInput: 13>, 'kResourceType_DigitalOutput': <tResourceType.kResourceType_DigitalOutput: 14>, 'kResourceType_DriverStationCIO': <tResourceType.kResourceType_DriverStationCIO: 15>, 'kResourceType_DriverStationEIO': <tResourceType.kResourceType_DriverStationEIO: 16>, 'kResourceType_DriverStationLCD': <tResourceType.kResourceType_DriverStationLCD: 17>, 'kResourceType_Encoder': <tResourceType.kResourceType_Encoder: 18>, 'kResourceType_GearTooth': <tResourceType.kResourceType_GearTooth: 19>, 'kResourceType_Gyro': <tResourceType.kResourceType_Gyro: 20>, 'kResourceType_I2C': <tResourceType.kResourceType_I2C: 21>, 'kResourceType_Framework': <tResourceType.kResourceType_Framework: 22>, 'kResourceType_Jaguar': <tResourceType.kResourceType_Jaguar: 23>, 'kResourceType_Joystick': <tResourceType.kResourceType_Joystick: 24>, 'kResourceType_Kinect': <tResourceType.kResourceType_Kinect: 25>, 'kResourceType_KinectStick': <tResourceType.kResourceType_KinectStick: 26>, 'kResourceType_PIDController': <tResourceType.kResourceType_PIDController: 27>, 'kResourceType_Preferences': <tResourceType.kResourceType_Preferences: 28>, 'kResourceType_PWM': <tResourceType.kResourceType_PWM: 29>, 'kResourceType_Relay': <tResourceType.kResourceType_Relay: 30>, 'kResourceType_RobotDrive': <tResourceType.kResourceType_RobotDrive: 31>, 'kResourceType_SerialPort': <tResourceType.kResourceType_SerialPort: 32>, 'kResourceType_Servo': <tResourceType.kResourceType_Servo: 33>, 'kResourceType_Solenoid': <tResourceType.kResourceType_Solenoid: 34>, 'kResourceType_SPI': <tResourceType.kResourceType_SPI: 35>, 'kResourceType_Task': <tResourceType.kResourceType_Task: 36>, 'kResourceType_Ultrasonic': <tResourceType.kResourceType_Ultrasonic: 37>, 'kResourceType_Victor': <tResourceType.kResourceType_Victor: 38>, 'kResourceType_Button': <tResourceType.kResourceType_Button: 39>, 'kResourceType_Command': <tResourceType.kResourceType_Command: 40>, 'kResourceType_AxisCamera': <tResourceType.kResourceType_AxisCamera: 41>, 'kResourceType_PCVideoServer': <tResourceType.kResourceType_PCVideoServer: 42>, 'kResourceType_SmartDashboard': <tResourceType.kResourceType_SmartDashboard: 43>, 'kResourceType_Talon': <tResourceType.kResourceType_Talon: 44>, 'kResourceType_HiTechnicColorSensor': <tResourceType.kResourceType_HiTechnicColorSensor: 45>, 'kResourceType_HiTechnicAccel': <tResourceType.kResourceType_HiTechnicAccel: 46>, 'kResourceType_HiTechnicCompass': <tResourceType.kResourceType_HiTechnicCompass: 47>, 'kResourceType_SRF08': <tResourceType.kResourceType_SRF08: 48>, 'kResourceType_AnalogOutput': <tResourceType.kResourceType_AnalogOutput: 49>, 'kResourceType_VictorSP': <tResourceType.kResourceType_VictorSP: 50>, 'kResourceType_PWMTalonSRX': <tResourceType.kResourceType_PWMTalonSRX: 51>, 'kResourceType_CANTalonSRX': <tResourceType.kResourceType_CANTalonSRX: 52>, 'kResourceType_ADXL362': <tResourceType.kResourceType_ADXL362: 53>, 'kResourceType_ADXRS450': <tResourceType.kResourceType_ADXRS450: 54>, 'kResourceType_RevSPARK': <tResourceType.kResourceType_RevSPARK: 55>, 'kResourceType_MindsensorsSD540': <tResourceType.kResourceType_MindsensorsSD540: 56>, 'kResourceType_DigitalGlitchFilter': <tResourceType.kResourceType_DigitalGlitchFilter: 57>, 'kResourceType_ADIS16448': <tResourceType.kResourceType_ADIS16448: 58>, 'kResourceType_PDP': <tResourceType.kResourceType_PDP: 59>, 'kResourceType_PCM': <tResourceType.kResourceType_PCM: 60>, 'kResourceType_PigeonIMU': <tResourceType.kResourceType_PigeonIMU: 61>, 'kResourceType_NidecBrushless': <tResourceType.kResourceType_NidecBrushless: 62>, 'kResourceType_CANifier': <tResourceType.kResourceType_CANifier: 63>, 'kResourceType_TalonFX': <tResourceType.kResourceType_TalonFX: 64>, 'kResourceType_CTRE_future1': <tResourceType.kResourceType_CTRE_future1: 65>, 'kResourceType_CTRE_future2': <tResourceType.kResourceType_CTRE_future2: 66>, 'kResourceType_CTRE_future3': <tResourceType.kResourceType_CTRE_future3: 67>, 'kResourceType_CTRE_future4': <tResourceType.kResourceType_CTRE_future4: 68>, 'kResourceType_CTRE_future5': <tResourceType.kResourceType_CTRE_future5: 69>, 'kResourceType_CTRE_future6': <tResourceType.kResourceType_CTRE_future6: 70>, 'kResourceType_LinearFilter': <tResourceType.kResourceType_LinearFilter: 71>, 'kResourceType_XboxController': <tResourceType.kResourceType_XboxController: 72>, 'kResourceType_UsbCamera': <tResourceType.kResourceType_UsbCamera: 73>, 'kResourceType_NavX': <tResourceType.kResourceType_NavX: 74>, 'kResourceType_Pixy': <tResourceType.kResourceType_Pixy: 75>, 'kResourceType_Pixy2': <tResourceType.kResourceType_Pixy2: 76>, 'kResourceType_ScanseSweep': <tResourceType.kResourceType_ScanseSweep: 77>, 'kResourceType_Shuffleboard': <tResourceType.kResourceType_Shuffleboard: 78>, 'kResourceType_CAN': <tResourceType.kResourceType_CAN: 79>, 'kResourceType_DigilentDMC60': <tResourceType.kResourceType_DigilentDMC60: 80>, 'kResourceType_PWMVictorSPX': <tResourceType.kResourceType_PWMVictorSPX: 81>, 'kResourceType_RevSparkMaxPWM': <tResourceType.kResourceType_RevSparkMaxPWM: 82>, 'kResourceType_RevSparkMaxCAN': <tResourceType.kResourceType_RevSparkMaxCAN: 83>, 'kResourceType_ADIS16470': <tResourceType.kResourceType_ADIS16470: 84>, 'kResourceType_PIDController2': <tResourceType.kResourceType_PIDController2: 85>, 'kResourceType_ProfiledPIDController': <tResourceType.kResourceType_ProfiledPIDController: 86>, 'kResourceType_Kinematics': <tResourceType.kResourceType_Kinematics: 87>, 'kResourceType_Odometry': <tResourceType.kResourceType_Odometry: 88>, 'kResourceType_Units': <tResourceType.kResourceType_Units: 89>, 'kResourceType_TrapezoidProfile': <tResourceType.kResourceType_TrapezoidProfile: 90>, 'kResourceType_DutyCycle': <tResourceType.kResourceType_DutyCycle: 91>, 'kResourceType_AddressableLEDs': <tResourceType.kResourceType_AddressableLEDs: 92>, 'kResourceType_FusionVenom': <tResourceType.kResourceType_FusionVenom: 93>, 'kResourceType_CTRE_future7': <tResourceType.kResourceType_CTRE_future7: 94>, 'kResourceType_CTRE_future8': <tResourceType.kResourceType_CTRE_future8: 95>, 'kResourceType_CTRE_future9': <tResourceType.kResourceType_CTRE_future9: 96>, 'kResourceType_CTRE_future10': <tResourceType.kResourceType_CTRE_future10: 97>, 'kResourceType_CTRE_future11': <tResourceType.kResourceType_CTRE_future11: 98>, 'kResourceType_CTRE_future12': <tResourceType.kResourceType_CTRE_future12: 99>, 'kResourceType_CTRE_future13': <tResourceType.kResourceType_CTRE_future13: 100>, 'kResourceType_CTRE_future14': <tResourceType.kResourceType_CTRE_future14: 101>, 'kResourceType_ExponentialProfile': <tResourceType.kResourceType_ExponentialProfile: 102>, 'kResourceType_PS4Controller': <tResourceType.kResourceType_PS4Controller: 103>, 'kResourceType_PhotonCamera': <tResourceType.kResourceType_PhotonCamera: 104>, 'kResourceType_PhotonPoseEstimator': <tResourceType.kResourceType_PhotonPoseEstimator: 105>, 'kResourceType_PathPlannerPath': <tResourceType.kResourceType_PathPlannerPath: 106>, 'kResourceType_PathPlannerAuto': <tResourceType.kResourceType_PathPlannerAuto: 107>, 'kResourceType_PathFindingCommand': <tResourceType.kResourceType_PathFindingCommand: 108>, 'kResourceType_Redux_future1': <tResourceType.kResourceType_Redux_future1: 109>, 'kResourceType_Redux_future2': <tResourceType.kResourceType_Redux_future2: 110>, 'kResourceType_Redux_future3': <tResourceType.kResourceType_Redux_future3: 111>, 'kResourceType_Redux_future4': <tResourceType.kResourceType_Redux_future4: 112>, 'kResourceType_Redux_future5': <tResourceType.kResourceType_Redux_future5: 113>, 'kResourceType_RevSparkFlexCAN': <tResourceType.kResourceType_RevSparkFlexCAN: 114>, 'kResourceType_RevSparkFlexPWM': <tResourceType.kResourceType_RevSparkFlexPWM: 115>, 'kResourceType_BangBangController': <tResourceType.kResourceType_BangBangController: 116>, 'kResourceType_DataLogManager': <tResourceType.kResourceType_DataLogManager: 117>, 'kResourceType_LoggingFramework': <tResourceType.kResourceType_LoggingFramework: 118>, 'kResourceType_ChoreoTrajectory': <tResourceType.kResourceType_ChoreoTrajectory: 119>, 'kResourceType_ChoreoTrigger': <tResourceType.kResourceType_ChoreoTrigger: 120>, 'kResourceType_PathWeaverTrajectory': <tResourceType.kResourceType_PathWeaverTrajectory: 121>, 'kResourceType_Koors40': <tResourceType.kResourceType_Koors40: 122>, 'kResourceType_ThriftyNova': <tResourceType.kResourceType_ThriftyNova: 123>, 'kResourceType_RevServoHub': <tResourceType.kResourceType_RevServoHub: 124>, 'kResourceType_PWFSEN36005': <tResourceType.kResourceType_PWFSEN36005: 125>, 'kResourceType_LaserShark': <tResourceType.kResourceType_LaserShark: 126>, 'kResourceType_YAMS': <tResourceType.kResourceType_YAMS: 127>, 'kResourceType_LEDPattern': <tResourceType.kResourceType_LEDPattern: 128>, 'kResourceType_LinearQuadraticRegulator': <tResourceType.kResourceType_LinearQuadraticRegulator: 129>, 'kResourceType_KalmanFilter': <tResourceType.kResourceType_KalmanFilter: 130>, 'kResourceType_PoseEstimator': <tResourceType.kResourceType_PoseEstimator: 131>, 'kResourceType_PoseEstimator3d': <tResourceType.kResourceType_PoseEstimator3d: 132>, 'kResourceType_LinearSystemLoop': <tResourceType.kResourceType_LinearSystemLoop: 133>, 'kResourceType_LumynLabs_ConnectorX': <tResourceType.kResourceType_LumynLabs_ConnectorX: 134>, 'kResourceType_LumynLabs_ConnectorXAnimate': <tResourceType.kResourceType_LumynLabs_ConnectorXAnimate: 135>}
    kResourceType_ADIS16448: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ADIS16448: 58>
    kResourceType_ADIS16470: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ADIS16470: 84>
    kResourceType_ADXL345: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ADXL345: 5>
    kResourceType_ADXL362: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ADXL362: 53>
    kResourceType_ADXRS450: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ADXRS450: 54>
    kResourceType_Accelerometer: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Accelerometer: 4>
    kResourceType_AddressableLEDs: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_AddressableLEDs: 92>
    kResourceType_AnalogChannel: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_AnalogChannel: 6>
    kResourceType_AnalogOutput: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_AnalogOutput: 49>
    kResourceType_AnalogTrigger: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_AnalogTrigger: 7>
    kResourceType_AnalogTriggerOutput: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_AnalogTriggerOutput: 8>
    kResourceType_AxisCamera: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_AxisCamera: 41>
    kResourceType_BangBangController: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_BangBangController: 116>
    kResourceType_Button: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Button: 39>
    kResourceType_CAN: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CAN: 79>
    kResourceType_CANJaguar: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CANJaguar: 9>
    kResourceType_CANPlugin: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CANPlugin: 3>
    kResourceType_CANTalonSRX: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CANTalonSRX: 52>
    kResourceType_CANifier: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CANifier: 63>
    kResourceType_CTRE_future1: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future1: 65>
    kResourceType_CTRE_future10: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future10: 97>
    kResourceType_CTRE_future11: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future11: 98>
    kResourceType_CTRE_future12: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future12: 99>
    kResourceType_CTRE_future13: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future13: 100>
    kResourceType_CTRE_future14: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future14: 101>
    kResourceType_CTRE_future2: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future2: 66>
    kResourceType_CTRE_future3: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future3: 67>
    kResourceType_CTRE_future4: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future4: 68>
    kResourceType_CTRE_future5: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future5: 69>
    kResourceType_CTRE_future6: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future6: 70>
    kResourceType_CTRE_future7: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future7: 94>
    kResourceType_CTRE_future8: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future8: 95>
    kResourceType_CTRE_future9: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_CTRE_future9: 96>
    kResourceType_ChoreoTrajectory: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ChoreoTrajectory: 119>
    kResourceType_ChoreoTrigger: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ChoreoTrigger: 120>
    kResourceType_Command: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Command: 40>
    kResourceType_Compressor: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Compressor: 10>
    kResourceType_Controller: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Controller: 0>
    kResourceType_Counter: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Counter: 11>
    kResourceType_Dashboard: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Dashboard: 12>
    kResourceType_DataLogManager: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DataLogManager: 117>
    kResourceType_DigilentDMC60: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DigilentDMC60: 80>
    kResourceType_DigitalGlitchFilter: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DigitalGlitchFilter: 57>
    kResourceType_DigitalInput: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DigitalInput: 13>
    kResourceType_DigitalOutput: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DigitalOutput: 14>
    kResourceType_DriverStationCIO: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DriverStationCIO: 15>
    kResourceType_DriverStationEIO: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DriverStationEIO: 16>
    kResourceType_DriverStationLCD: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DriverStationLCD: 17>
    kResourceType_DutyCycle: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_DutyCycle: 91>
    kResourceType_Encoder: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Encoder: 18>
    kResourceType_ExponentialProfile: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ExponentialProfile: 102>
    kResourceType_Framework: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Framework: 22>
    kResourceType_FusionVenom: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_FusionVenom: 93>
    kResourceType_GearTooth: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_GearTooth: 19>
    kResourceType_Gyro: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Gyro: 20>
    kResourceType_HiTechnicAccel: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_HiTechnicAccel: 46>
    kResourceType_HiTechnicColorSensor: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_HiTechnicColorSensor: 45>
    kResourceType_HiTechnicCompass: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_HiTechnicCompass: 47>
    kResourceType_I2C: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_I2C: 21>
    kResourceType_Jaguar: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Jaguar: 23>
    kResourceType_Joystick: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Joystick: 24>
    kResourceType_KalmanFilter: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_KalmanFilter: 130>
    kResourceType_Kinect: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Kinect: 25>
    kResourceType_KinectStick: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_KinectStick: 26>
    kResourceType_Kinematics: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Kinematics: 87>
    kResourceType_Koors40: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Koors40: 122>
    kResourceType_LEDPattern: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LEDPattern: 128>
    kResourceType_Language: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Language: 2>
    kResourceType_LaserShark: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LaserShark: 126>
    kResourceType_LinearFilter: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LinearFilter: 71>
    kResourceType_LinearQuadraticRegulator: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LinearQuadraticRegulator: 129>
    kResourceType_LinearSystemLoop: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LinearSystemLoop: 133>
    kResourceType_LoggingFramework: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LoggingFramework: 118>
    kResourceType_LumynLabs_ConnectorX: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LumynLabs_ConnectorX: 134>
    kResourceType_LumynLabs_ConnectorXAnimate: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_LumynLabs_ConnectorXAnimate: 135>
    kResourceType_MindsensorsSD540: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_MindsensorsSD540: 56>
    kResourceType_Module: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Module: 1>
    kResourceType_NavX: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_NavX: 74>
    kResourceType_NidecBrushless: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_NidecBrushless: 62>
    kResourceType_Odometry: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Odometry: 88>
    kResourceType_PCM: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PCM: 60>
    kResourceType_PCVideoServer: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PCVideoServer: 42>
    kResourceType_PDP: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PDP: 59>
    kResourceType_PIDController: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PIDController: 27>
    kResourceType_PIDController2: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PIDController2: 85>
    kResourceType_PS4Controller: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PS4Controller: 103>
    kResourceType_PWFSEN36005: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PWFSEN36005: 125>
    kResourceType_PWM: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PWM: 29>
    kResourceType_PWMTalonSRX: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PWMTalonSRX: 51>
    kResourceType_PWMVictorSPX: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PWMVictorSPX: 81>
    kResourceType_PathFindingCommand: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PathFindingCommand: 108>
    kResourceType_PathPlannerAuto: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PathPlannerAuto: 107>
    kResourceType_PathPlannerPath: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PathPlannerPath: 106>
    kResourceType_PathWeaverTrajectory: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PathWeaverTrajectory: 121>
    kResourceType_PhotonCamera: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PhotonCamera: 104>
    kResourceType_PhotonPoseEstimator: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PhotonPoseEstimator: 105>
    kResourceType_PigeonIMU: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PigeonIMU: 61>
    kResourceType_Pixy: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Pixy: 75>
    kResourceType_Pixy2: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Pixy2: 76>
    kResourceType_PoseEstimator: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PoseEstimator: 131>
    kResourceType_PoseEstimator3d: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_PoseEstimator3d: 132>
    kResourceType_Preferences: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Preferences: 28>
    kResourceType_ProfiledPIDController: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ProfiledPIDController: 86>
    kResourceType_Redux_future1: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Redux_future1: 109>
    kResourceType_Redux_future2: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Redux_future2: 110>
    kResourceType_Redux_future3: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Redux_future3: 111>
    kResourceType_Redux_future4: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Redux_future4: 112>
    kResourceType_Redux_future5: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Redux_future5: 113>
    kResourceType_Relay: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Relay: 30>
    kResourceType_RevSPARK: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_RevSPARK: 55>
    kResourceType_RevServoHub: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_RevServoHub: 124>
    kResourceType_RevSparkFlexCAN: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_RevSparkFlexCAN: 114>
    kResourceType_RevSparkFlexPWM: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_RevSparkFlexPWM: 115>
    kResourceType_RevSparkMaxCAN: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_RevSparkMaxCAN: 83>
    kResourceType_RevSparkMaxPWM: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_RevSparkMaxPWM: 82>
    kResourceType_RobotDrive: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_RobotDrive: 31>
    kResourceType_SPI: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_SPI: 35>
    kResourceType_SRF08: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_SRF08: 48>
    kResourceType_ScanseSweep: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ScanseSweep: 77>
    kResourceType_SerialPort: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_SerialPort: 32>
    kResourceType_Servo: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Servo: 33>
    kResourceType_Shuffleboard: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Shuffleboard: 78>
    kResourceType_SmartDashboard: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_SmartDashboard: 43>
    kResourceType_Solenoid: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Solenoid: 34>
    kResourceType_Talon: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Talon: 44>
    kResourceType_TalonFX: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_TalonFX: 64>
    kResourceType_Task: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Task: 36>
    kResourceType_ThriftyNova: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_ThriftyNova: 123>
    kResourceType_TrapezoidProfile: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_TrapezoidProfile: 90>
    kResourceType_Ultrasonic: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Ultrasonic: 37>
    kResourceType_Units: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Units: 89>
    kResourceType_UsbCamera: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_UsbCamera: 73>
    kResourceType_Victor: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_Victor: 38>
    kResourceType_VictorSP: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_VictorSP: 50>
    kResourceType_XboxController: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_XboxController: 72>
    kResourceType_YAMS: typing.ClassVar[tResourceType]  # value = <tResourceType.kResourceType_YAMS: 127>
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
def __test_senderr() -> None:
    ...
def cancelNotifierAlarm(notifierHandle: typing.SupportsInt) -> int:
    """
    Cancels the next notifier alarm.
    
    This does not cause HAL_WaitForNotifierAlarm to return.
    
    :param in:  notifierHandle the notifier handle
    :param out: status Error status variable. 0 on success.
    """
def cleanNotifier(notifierHandle: typing.SupportsInt) -> None:
    """
    Cleans a notifier.
    
    Note this also stops a notifier if it is already running.
    
    :param in: notifierHandle the notifier handle
    """
def exitMain() -> None:
    """
    Causes HAL_RunMain() to exit.
    
    If HAL_SetMain() has been called, this calls the exit function provided
    to that function.
    """
def expandFPGATime(unexpandedLower: typing.SupportsInt) -> tuple[int, int]:
    """
    Given an 32 bit FPGA time, expand it to the nearest likely 64 bit FPGA time.
    
    Note: This is making the assumption that the timestamp being converted is
    always in the past.  If you call this with a future timestamp, it probably
    will make it in the past.  If you wait over 70 minutes between capturing the
    bottom 32 bits of the timestamp and expanding it, you will be off by
    multiples of 1<<32 microseconds.
    
    :param in:  unexpandedLower 32 bit FPGA time
    :param out: status the error code, or 0 for success
    
    :returns: The current time in microseconds according to the FPGA (since FPGA
              reset) as a 64 bit number.
    """
def getAccelerometerX() -> float:
    """
    Gets the x-axis acceleration.
    
    This is a floating point value in units of 1 g-force.
    
    :returns: the X acceleration
    """
def getAccelerometerY() -> float:
    """
    Gets the y-axis acceleration.
    
    This is a floating point value in units of 1 g-force.
    
    :returns: the Y acceleration
    """
def getAccelerometerZ() -> float:
    """
    Gets the z-axis acceleration.
    
    This is a floating point value in units of 1 g-force.
    
    :returns: the Z acceleration
    """
def getAllJoystickData(axes: JoystickAxes, povs: JoystickPOVs, buttons: JoystickButtons) -> None:
    ...
def getAllianceStation() -> tuple[AllianceStationID, int]:
    """
    Gets the current alliance station ID.
    
    :param out: status the error code, or 0 for success
    
    :returns: the alliance station ID
    """
def getBrownedOut() -> tuple[int, int]:
    """
    Gets if the system is in a browned out state.
    
    :param out: status the error code, or 0 for success
    
    :returns: true if the system is in a low voltage brown out, false otherwise
    """
def getComments() -> str:
    """
    Returns the comments from the roboRIO web interface.
    
    :param out: comments The comments string. Free with WPI_FreeString
    """
def getCommsDisableCount() -> tuple[int, int]:
    """
    Gets the number of times the system has been disabled due to communication
    errors with the Driver Station.
    
    :returns: number of disables due to communication errors.
    """
def getControlWord(controlWord: ControlWord) -> int:
    """
    Gets the current control word of the driver station.
    
    The control word contains the robot state.
    
    :param controlWord: the control word (out)
    
    :returns: the error code, or 0 for success
    """
def getCurrentThreadPriority(isRealTime: typing.SupportsInt) -> tuple[int, int]:
    """
    Gets the thread priority for the current thread.
    
    :param out: isRealTime Set to true if thread is real-time, otherwise false.
    :param out: status     Error status variable. 0 on success.
    
    :returns: The current thread priority. For real-time, this is 1-99 with 99
              being highest. For non-real-time, this is 0. See "man 7 sched" for
              details.
    """
def getErrorMessage(code: typing.SupportsInt) -> str:
    """
    Gets the error message for a specific status code.
    
    :param code: the status code
    
    :returns: the error message for the code. This does not need to be freed.
    """
def getFPGAButton() -> tuple[int, int]:
    """
    Gets the state of the "USER" button on the roboRIO.
    
    @warning the User Button is used to stop user programs from automatically
    loading if it is held for more then 5 seconds. Because of this, it's not
    recommended to be used by teams for any other purpose.
    
    :param out: status the error code, or 0 for success
    
    :returns: true if the button is currently pressed down
    """
def getFPGARevision() -> tuple[int, int]:
    """
    Returns the FPGA Revision number.
    
    The format of the revision is 3 numbers.
    The 12 most significant bits are the Major Revision.
    the next 8 bits are the Minor Revision.
    The 12 least significant bits are the Build Number.
    
    :param out: status the error code, or 0 for success
    
    :returns: FPGA Revision number.
    """
def getFPGATime() -> tuple[int, int]:
    """
    Reads the microsecond-resolution timer on the FPGA.
    
    :param out: status the error code, or 0 for success
    
    :returns: The current time in microseconds according to the FPGA (since FPGA
              reset).
    """
def getFPGAVersion() -> tuple[int, int]:
    """
    Returns the FPGA Version number.
    
    For now, expect this to be competition year.
    
    :param out: status the error code, or 0 for success
    
    :returns: FPGA Version number.
    """
def getJoystickAxes(joystickNum: typing.SupportsInt, axes: JoystickAxes) -> int:
    """
    Gets the axes of a specific joystick.
    
    :param joystickNum: the joystick number
    :param axes:        the axes values (output)
    
    :returns: the error code, or 0 for success
    """
def getJoystickAxisType(joystickNum: typing.SupportsInt, axis: typing.SupportsInt) -> int:
    """
    Gets the type of a specific joystick axis.
    
    This is device specific, and different depending on what system input type
    the joystick uses.
    
    :param joystickNum: the joystick number
    :param axis:        the axis number
    
    :returns: the enumerated axis type
    """
def getJoystickButtons(joystickNum: typing.SupportsInt, buttons: JoystickButtons) -> int:
    """
    Gets the buttons of a specific joystick.
    
    :param joystickNum: the joystick number
    :param buttons:     the button values (output)
    
    :returns: the error code, or 0 for success
    """
def getJoystickDescriptor(joystickNum: typing.SupportsInt, desc: JoystickDescriptor) -> int:
    """
    Retrieves the Joystick Descriptor for particular slot.
    
    :param joystickNum: the joystick number
    :param out:         desc   descriptor (data transfer object) to fill in. desc is
                        filled in regardless of success. In other words, if
                        descriptor is not available, desc is filled in with
                        default values matching the init-values in Java and C++
                        Driver Station for when caller requests a too-large
                        joystick index.
    
    :returns: error code reported from Network Comm back-end.  Zero is good,
              nonzero is bad.
    """
def getJoystickIsXbox(joystickNum: typing.SupportsInt) -> int:
    """
    Gets whether a specific joystick is considered to be an XBox controller.
    
    :param joystickNum: the joystick number
    
    :returns: true if xbox, false otherwise
    """
def getJoystickName(joystickNum: typing.SupportsInt) -> str:
    """
    Gets the name of a joystick.
    
    The returned string must be freed with WPI_FreeString
    
    :param name:        the joystick name string
    :param joystickNum: the joystick number
    """
def getJoystickPOVs(joystickNum: typing.SupportsInt, povs: JoystickPOVs) -> int:
    """
    Gets the POVs of a specific joystick.
    
    :param joystickNum: the joystick number
    :param povs:        the POV values (output)
    
    :returns: the error code, or 0 for success
    """
def getJoystickType(joystickNum: typing.SupportsInt) -> int:
    """
    Gets the type of joystick connected.
    
    This is device specific, and different depending on what system input type
    the joystick uses.
    
    :param joystickNum: the joystick number
    
    :returns: the enumerated joystick type
    """
def getLastError() -> tuple[str, int]:
    """
    Gets the last error set on this thread, or the message for the status code.
    
    If passed HAL_USE_LAST_ERROR, the last error set on the thread will be
    returned.
    
    :param out: status the status code, set to the error status code if input is
                HAL_USE_LAST_ERROR
    
    :returns: the error message for the code. This does not need to be freed,
              but can be overwritten by another hal call on the same thread.
    """
def getMatchInfo(info: MatchInfo) -> int:
    """
    Gets info about a specific match.
    
    :param in: info the match info (output)
    
    :returns: the error code, or 0 for success
    """
def getMatchTime() -> tuple[float, int]:
    """
    Return the approximate match time. The FMS does not send an official match
    time to the robots, but does send an approximate match time. The value will
    count down the time remaining in the current period (auto or teleop).
    Warning: This is not an official time (so it cannot be used to dispute ref
    calls or guarantee that a function will trigger before the match ends).
    
    When connected to the real field, this number only changes in full integer
    increments, and always counts down.
    
    When the DS is in practice mode, this number is a floating point number,
    and counts down.
    
    When the DS is in teleop or autonomous mode, this number is a floating
    point number, and counts up.
    
    Simulation matches DS behavior without an FMS connected.
    
    :param out: status the error code, or 0 for success
    
    :returns: Time remaining in current match period (auto or teleop) in seconds
    """
def getOutputsEnabled() -> int:
    """
    Gets if outputs are enabled by the control system.
    
    :returns: true if outputs are enabled
    """
def getPort(channel: typing.SupportsInt) -> int:
    """
    Gets a port handle for a specific channel.
    
    The created handle does not need to be freed.
    
    :param channel: the channel number
    
    :returns: the created port
    """
def getPortWithModule(module: typing.SupportsInt, channel: typing.SupportsInt) -> int:
    """
    Gets a port handle for a specific channel and module.
    
    This is expected to be used for PCMs, as the roboRIO does not work with
    modules anymore.
    
    The created handle does not need to be freed.
    
    :param module:  the module number
    :param channel: the channel number
    
    :returns: the created port
    """
def getRSLState() -> tuple[int, int]:
    """
    Gets the current state of the Robot Signal Light (RSL).
    
    :param out: status the error code, or 0 for success
    
    :returns: The current state of the RSL- true if on, false if off
    """
def getRuntimeType() -> RuntimeType:
    """
    Returns the runtime type of the HAL.
    
    :returns: HAL Runtime Type
    """
def getSerialNumber() -> str:
    """
    Returns the roboRIO serial number.
    
    :param out: serialNumber The roboRIO serial number. Free with WPI_FreeString
    """
def getSystemActive() -> tuple[int, int]:
    """
    Gets if the system outputs are currently active.
    
    :param out: status the error code, or 0 for success
    
    :returns: true if the system outputs are active, false if disabled
    """
def getSystemTimeValid() -> tuple[int, int]:
    """
    Gets if the system time is valid.
    
    :param out: status the error code, or 0 for success
    
    :returns: True if the system time is valid, false otherwise
    """
def getTeamNumber() -> int:
    """
    Returns the team number configured for the robot controller.
    
    :returns: team number, or 0 if not found.
    """
def hasMain() -> int:
    """
    Returns true if HAL_SetMain() has been called.
    
    :returns: True if HAL_SetMain() has been called, false otherwise.
    """
def initialize(timeout: typing.SupportsInt, mode: typing.SupportsInt) -> int:
    """
    Call this to start up HAL. This is required for robot programs.
    
    This must be called before any other HAL functions. Failure to do so will
    result in undefined behavior, and likely segmentation faults. This means that
    any statically initialized variables in a program MUST call this function in
    their constructors if they want to use other HAL calls.
    
    The common parameters are 500 for timeout and 0 for mode.
    
    This function is safe to call from any thread, and as many times as you wish.
    It internally guards from any reentrancy.
    
    The applicable modes are:
    0: Try to kill an existing HAL from another program, if not successful,
    error.
    1: Force kill a HAL from another program.
    2: Just warn if another hal exists and cannot be killed. Will likely result
    in undefined behavior.
    
    :param timeout: the initialization timeout (ms)
    :param mode:    the initialization mode (see remarks)
    
    :returns: true if initialization was successful, otherwise false.
    """
def initializeNotifier() -> tuple[int, int]:
    """
    Initializes a notifier.
    
    A notifier is an FPGA controller timer that triggers at requested intervals
    based on the FPGA time. This can be used to make precise control loops.
    
    :param out: status Error status variable. 0 on success.
    
    :returns: the created notifier
    """
def loadExtensions() -> int:
    """
    Loads any extra halsim libraries provided in the HALSIM_EXTENSIONS
    environment variable.
    
    :returns: the success state of the initialization
    """
def loadOneExtension(library: str) -> int:
    """
    Loads a single extension from a direct path.
    
    Expected to be called internally, not by users.
    
    :param library: the library path
    
    :returns: the success state of the initialization
    """
def observeUserProgramAutonomous() -> None:
    """
    Sets the autonomous enabled flag in the DS.
    
    This is used for the DS to ensure the robot is properly responding to its
    state request. Ensure this gets called about every 50ms, or the robot will be
    disabled by the DS.
    """
def observeUserProgramDisabled() -> None:
    """
    Sets the disabled flag in the DS.
    
    This is used for the DS to ensure the robot is properly responding to its
    state request. Ensure this gets called about every 50ms, or the robot will be
    disabled by the DS.
    """
def observeUserProgramStarting() -> None:
    """
    Sets the program starting flag in the DS.
    
    This is what changes the DS to showing robot code ready.
    """
def observeUserProgramTeleop() -> None:
    """
    Sets the teleoperated enabled flag in the DS.
    
    This is used for the DS to ensure the robot is properly responding to its
    state request. Ensure this gets called about every 50ms, or the robot will be
    disabled by the DS.
    """
def observeUserProgramTest() -> None:
    """
    Sets the test mode flag in the DS.
    
    This is used for the DS to ensure the robot is properly responding to its
    state request. Ensure this gets called about every 50ms, or the robot will be
    disabled by the DS.
    """
def provideNewDataEventHandle(handle: typing.SupportsInt) -> None:
    """
    Adds an event handle to be signalled when new data arrives.
    
    :param handle: the event handle to be signalled
    """
def refreshDSData() -> int:
    """
    Refresh the DS control word.
    
    :returns: true if updated
    """
def removeNewDataEventHandle(handle: typing.SupportsInt) -> None:
    """
    Removes the event handle from being signalled when new data arrives.
    
    :param handle: the event handle to remove
    """
def report(resource: typing.SupportsInt, instanceNumber: typing.SupportsInt, context: typing.SupportsInt = 0, feature: str = None) -> int:
    """
    Reports a hardware usage to the HAL.
    
    :param resource:       the used resource
    :param instanceNumber: the instance of the resource
    :param context:        a user specified context index
    :param feature:        a user specified feature string
    
    :returns: the index of the added value in NetComm
    """
def runMain() -> None:
    """
    Runs the main function provided to HAL_SetMain().
    
    If HAL_SetMain() has not been called, simply sleeps until HAL_ExitMain()
    is called.
    """
def sendConsoleLine(line: str) -> int:
    """
    Sends a line to the driver station console.
    
    :param line: the line to send (null terminated)
    
    :returns: the error code, or 0 for success
    """
def sendError(isError: typing.SupportsInt, errorCode: typing.SupportsInt, isLVCode: typing.SupportsInt, details: str, location: str, callStack: str, printMsg: typing.SupportsInt) -> int:
    """
    Sends an error to the driver station.
    
    :param isError:   true for error, false for warning
    :param errorCode: the error code
    :param isLVCode:  true for a LV error code, false for a standard error code
    :param details:   the details of the error
    :param location:  the file location of the error
    :param callStack: the callstack of the error
    :param printMsg:  true to print the error message to stdout as well as to the
                      DS
    
    :returns: the error code, or 0 for success
    """
def setAccelerometerActive(active: typing.SupportsInt) -> None:
    """
    Sets the accelerometer to active or standby mode.
    
    It must be in standby mode to change any configuration.
    
    :param active: true to set to active, false for standby
    """
def setAccelerometerRange(range: AccelerometerRange) -> None:
    """
    Sets the range of values that can be measured (either 2, 4, or 8 g-forces).
    
    The accelerometer should be in standby mode when this is called.
    
    :param range: the accelerometer range
    """
def setCurrentThreadPriority(realTime: typing.SupportsInt, priority: typing.SupportsInt) -> tuple[int, int]:
    """
    Sets the thread priority for the current thread.
    
    :param in:  realTime Set to true to set a real-time priority, false for
                standard priority.
    :param in:  priority Priority to set the thread to. For real-time, this is
                1-99 with 99 being highest. For non-real-time, this is
                forced to 0. See "man 7 sched" for more details.
    :param out: status  Error status variable. 0 on success.
    
    :returns: True on success.
    """
def setJoystickOutputs(joystickNum: typing.SupportsInt, outputs: typing.SupportsInt, leftRumble: typing.SupportsInt, rightRumble: typing.SupportsInt) -> int:
    """
    Set joystick outputs.
    
    :param joystickNum: the joystick number
    :param outputs:     bitmask of outputs, 1 for on 0 for off
    :param leftRumble:  the left rumble value (0-FFFF)
    :param rightRumble: the right rumble value (0-FFFF)
    
    :returns: the error code, or 0 for success
    """
def setNotifierName(notifierHandle: typing.SupportsInt, name: str) -> int:
    """
    Sets the name of a notifier.
    
    :param in:  notifierHandle the notifier handle
    :param in:  name name
    :param out: status Error status variable. 0 on success.
    """
def setNotifierThreadPriority(realTime: typing.SupportsInt, priority: typing.SupportsInt) -> tuple[int, int]:
    """
    Sets the HAL notifier thread priority.
    
    The HAL notifier thread is responsible for managing the FPGA's notifier
    interrupt and waking up user's Notifiers when it's their time to run.
    Giving the HAL notifier thread real-time priority helps ensure the user's
    real-time Notifiers, if any, are notified to run in a timely manner.
    
    :param in:  realTime Set to true to set a real-time priority, false for
                standard priority.
    :param in:  priority Priority to set the thread to. For real-time, this is
                1-99 with 99 being highest. For non-real-time, this is
                forced to 0. See "man 7 sched" for more details.
    :param out: status  Error status variable. 0 on success.
    
    :returns: True on success.
    """
def setShowExtensionsNotFoundMessages(showMessage: typing.SupportsInt) -> None:
    """
    Enables or disables the message saying no HAL extensions were found.
    
    Some apps don't care, and the message create clutter. For general team code,
    we want it.
    
    This must be called before HAL_Initialize is called.
    
    This defaults to true.
    
    :param showMessage: true to show message, false to not.
    """
def shutdown() -> None:
    """
    Call this to shut down HAL.
    
    This must be called at termination of the robot program to avoid potential
    segmentation faults with simulation extensions at exit.
    """
def simPeriodicAfter() -> None:
    """
    Calls registered SimPeriodic "after" callbacks (only in simulation mode).
    This should be called after user code periodic simulation functions.
    """
def simPeriodicBefore() -> None:
    """
    Calls registered SimPeriodic "before" callbacks (only in simulation mode).
    This should be called prior to user code periodic simulation functions.
    """
def stopNotifier(notifierHandle: typing.SupportsInt) -> int:
    """
    Stops a notifier from running.
    
    This will cause any call into HAL_WaitForNotifierAlarm to return with time =
    0.
    
    :param in:  notifierHandle the notifier handle
    :param out: status Error status variable. 0 on success.
    """
def updateNotifierAlarm(notifierHandle: typing.SupportsInt, triggerTime: typing.SupportsInt) -> int:
    """
    Updates the trigger time for a notifier.
    
    Note that this time is an absolute time relative to HAL_GetFPGATime()
    
    :param in:  notifierHandle the notifier handle
    :param in:  triggerTime    the updated trigger time
    :param out: status        Error status variable. 0 on success.
    """
def waitForNotifierAlarm(notifierHandle: typing.SupportsInt) -> tuple[int, int]:
    """
    Waits for the next alarm for the specific notifier.
    
    This is a blocking call until either the time elapses or HAL_StopNotifier
    gets called. If the latter occurs, this function will return zero and any
    loops using this function should exit. Failing to do so can lead to
    use-after-frees.
    
    :param in:  notifierHandle the notifier handle
    :param out: status        Error status variable. 0 on success.
    
    :returns: the FPGA time the notifier returned
    """
__hal_simulation__: bool = True
__halplatform__: str = 'sim'
_cleanup: typing.Any  # value = <capsule object>
