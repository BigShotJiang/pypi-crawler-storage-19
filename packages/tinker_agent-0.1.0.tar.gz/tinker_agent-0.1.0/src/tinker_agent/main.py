import asyncio
import http.server
import json
import os
import shutil
import subprocess
import sys
import threading
import webbrowser
from datetime import datetime
from functools import partial
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt
from rich.text import Text

sys.path.insert(0, str(Path(__file__).parent.parent))

from tinker_agent.agent import run_agent, Config

console = Console()

# Trace file location
TRACES_FILE = "traces.json"


def update_runs_index(project_root: Path) -> None:
    """Update runs/index.json with all runs that have traces."""
    runs_dir = project_root / "runs"
    index_path = runs_dir / "index.json"

    if not runs_dir.exists():
        return

    index = {}
    for run_dir in runs_dir.iterdir():
        if run_dir.is_dir() and (run_dir / "traces.json").exists():
            # Count traces from JSON array
            trace_count = 0
            try:
                with open(run_dir / "traces.json") as f:
                    traces = json.load(f)
                    if isinstance(traces, list):
                        trace_count = len(traces)
            except:
                pass

            index[run_dir.name] = {
                "path": f"runs/{run_dir.name}",
                "traceCount": trace_count,
            }

    with open(index_path, "w") as f:
        json.dump(index, f, indent=2)


def start_trace_server(project_root: Path, port: int = 8765) -> int:
    """Start a simple HTTP server at project root to serve the viewer."""
    handler = partial(http.server.SimpleHTTPRequestHandler, directory=str(project_root))

    def serve():
        with http.server.HTTPServer(("", port), handler) as httpd:
            httpd.serve_forever()

    thread = threading.Thread(target=serve, daemon=True)
    thread.start()
    return port


PYPROJECT_DEPENDENCIES = """dependencies = [
    "tinker",
    "tinker-cookbook",
    "wandb",
    "python-dotenv",
]
"""

PYPROJECT_UV_SOURCES = """
[tool.uv.sources]
tinker-cookbook = { git = "https://github.com/thinking-machines-lab/tinker-cookbook.git" }
"""


def setup_project(runs_dir: Path) -> None:
    """Initialize uv project and install dependencies."""
    console.print("[dim]Setting up project...[/dim]")

    # Force uv to use a local .venv and ignore parent workspace
    env = os.environ.copy()
    env["UV_PROJECT_ENVIRONMENT"] = str(runs_dir / ".venv")
    env["UV_NO_WORKSPACE"] = "1"  # Prevent discovering parent workspace

    # Run uv init (--no-workspace prevents modifying parent pyproject.toml)
    subprocess.run(
        ["uv", "init", "--no-workspace"],
        cwd=runs_dir,
        env=env,
        check=True,
        capture_output=True,
    )

    # Update pyproject.toml with dependencies
    pyproject_path = runs_dir / "pyproject.toml"
    content = pyproject_path.read_text()

    # Replace the default dependencies line
    content = content.replace("dependencies = []", PYPROJECT_DEPENDENCIES.strip())

    # Add uv sources section at the end
    content = content.rstrip() + "\n" + PYPROJECT_UV_SOURCES

    pyproject_path.write_text(content)

    # Run uv sync with isolated environment
    subprocess.run(
        ["uv", "sync"], cwd=runs_dir, env=env, check=True, capture_output=True
    )

    console.print("[green]✓[/green] Project setup complete")


def main() -> None:
    """CLI entrypoint with interactive prompt."""
    # Create timestamped runs directory (resolve before chdir)
    project_root = Path.cwd().resolve()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    runs_dir = (project_root / "runs" / timestamp).resolve()
    runs_dir.mkdir(parents=True, exist_ok=True)

    # Copy .env to runs directory if it exists
    env_file = project_root / ".env"
    if env_file.exists():
        shutil.copy(env_file, runs_dir / ".env")

    # Setup uv project with dependencies
    setup_project(runs_dir)

    # Change to the runs directory
    os.chdir(runs_dir)

    # Trace file path
    trace_path = runs_dir / TRACES_FILE

    # Update runs index and start server from project root
    update_runs_index(project_root)
    port = start_trace_server(project_root)
    viewer_url = f"http://localhost:{port}/viewer.html"

    # Header
    console.print()
    console.print(
        Panel(
            Text("tinker-agent", style="bold cyan", justify="center"),
            subtitle=f"[dim]{runs_dir}[/dim]",
            border_style="cyan",
        )
    )
    # console.print(f"[dim]Trace viewer: [link={viewer_url}]{viewer_url}[/link][/dim]")

    # Interactive CLI loop
    while True:
        try:
            console.print()
            prompt = Prompt.ask("[bold cyan]>[/bold cyan]")
            if not prompt.strip():
                continue
            if prompt.strip().lower() in ("exit", "quit", "q"):
                break
            if prompt.strip().lower() == "view":
                webbrowser.open(viewer_url)
                continue

            config = Config(
                prompt=prompt, cwd=str(runs_dir), trace_path=str(trace_path)
            )
            try:
                asyncio.run(run_agent(config))
            except Exception as e:
                # Agent crashed - offer to continue with error context
                console.print(
                    f"\n[dim]Agent crashed. You can continue with a follow-up prompt.[/dim]"
                )

            # Update index after each run
            update_runs_index(project_root)

        except KeyboardInterrupt:
            console.print("\n[dim]Exiting...[/dim]")
            break
        except EOFError:
            break


if __name__ == "__main__":
    main()
