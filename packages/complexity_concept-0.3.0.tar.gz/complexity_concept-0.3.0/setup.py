"""
Complexity Concept - Llama + INL Dynamics
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="complexity-concept",
    version="0.3.0",
    description="Llama-based architecture with INL Dynamics Lite stabilization",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Pacific Prime",
    author_email="contact@pacific-prime.ai",
    url="https://github.com/Pacific-Prime/complexity-concept",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "torch>=2.0.0",
        "transformers>=4.30.0",
        "datasets>=2.0.0",
        "tokenizers>=0.13.0",
        "tqdm",
        "tensorboard",
    ],
    extras_require={
        "cuda": ["triton>=2.0.0"],
        "dev": ["pytest", "black", "isort"],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="llm transformer dynamics llama pytorch deep-learning",
)
