"""
Complexity Concept - Llama + INL Dynamics
=========================================

Llama-based architecture with INL Dynamics Lite stabilization.

Features:
- Token-Routed MLP (from Complexity)
- Flash Attention via SDPA
- QK Normalization
- INL Dynamics Lite - stabilizes activations towards learned equilibrium

Usage:
    from complexity_concept import ComplexityConfig, ComplexityForCausalLM

    config = ComplexityConfig.complexity_base()
    model = ComplexityForCausalLM(config)
"""

from complexity_concept.core import (
    RMSNorm,
    RotaryEmbedding,
    ComplexityAttention,
    ComplexityMLP,
    ComplexityDecoderLayer,
    INLDynamicsLite,
)

from complexity_concept.models import (
    ComplexityConfig,
    ComplexityModel,
    ComplexityForCausalLM,
    create_complexity_model,
)

__version__ = "0.3.0"
__all__ = [
    # Core
    "RMSNorm",
    "RotaryEmbedding",
    "ComplexityAttention",
    "ComplexityMLP",
    "ComplexityDecoderLayer",
    "INLDynamicsLite",
    # Models
    "ComplexityConfig",
    "ComplexityModel",
    "ComplexityForCausalLM",
    "create_complexity_model",
]
