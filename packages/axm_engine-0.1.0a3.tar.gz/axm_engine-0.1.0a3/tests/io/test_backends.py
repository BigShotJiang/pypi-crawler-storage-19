"""Tests for storage backends."""

from pathlib import Path

import pytest

from axm_engine.io.backends import LocalBackend, StorageBackend


class TestLocalBackend:
    """Tests for LocalBackend implementation."""

    def test_implements_protocol(self) -> None:
        """LocalBackend should satisfy StorageBackend protocol."""
        backend = LocalBackend()
        assert isinstance(backend, StorageBackend)

    def test_write_and_read(self, tmp_path: Path) -> None:
        """Can write and read bytes."""
        backend = LocalBackend()
        file_path = str(tmp_path / "test.txt")

        backend.write(file_path, b"hello world")
        result = backend.read(file_path)

        assert result == b"hello world"

    def test_write_creates_parent_dirs(self, tmp_path: Path) -> None:
        """Write creates parent directories if needed."""
        backend = LocalBackend()
        file_path = str(tmp_path / "nested" / "deep" / "file.txt")

        backend.write(file_path, b"data")

        assert Path(file_path).exists()
        assert backend.read(file_path) == b"data"

    def test_read_file_not_found(self, tmp_path: Path) -> None:
        """Read raises FileNotFoundError for missing file."""
        backend = LocalBackend()

        with pytest.raises(FileNotFoundError):
            backend.read(str(tmp_path / "nonexistent.txt"))

    def test_exists_true(self, tmp_path: Path) -> None:
        """Exists returns True for existing file."""
        backend = LocalBackend()
        file_path = str(tmp_path / "exists.txt")
        backend.write(file_path, b"data")

        assert backend.exists(file_path) is True

    def test_exists_false(self, tmp_path: Path) -> None:
        """Exists returns False for missing file."""
        backend = LocalBackend()

        assert backend.exists(str(tmp_path / "missing.txt")) is False


class TestStorageBackendProtocol:
    """Tests for StorageBackend protocol compliance."""

    def test_protocol_is_runtime_checkable(self) -> None:
        """StorageBackend should be runtime checkable."""

        class CustomBackend:
            def read(self, path: str) -> bytes:
                return b""

            def write(self, path: str, data: bytes) -> None:
                pass

            def exists(self, path: str) -> bool:
                return False

        assert isinstance(CustomBackend(), StorageBackend)
