"""Tests for async pipeline orchestration."""

import asyncio
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from axm.catalog.entries.base import Identity, Owner
from axm.catalog.entries.pipeline import DAG, PipelineEntry, PipelineStep
from axm_engine.context import RuntimeContext
from axm_engine.orchestration import PipelineRunner


@pytest.fixture
def mock_context() -> RuntimeContext:
    """Create a mock runtime context."""
    context = MagicMock(spec=RuntimeContext)
    context.catalog = {}
    return context


@pytest.fixture
def simple_pipeline() -> PipelineEntry:
    """Create a simple single-step pipeline."""
    return PipelineEntry(
        name="simple_pipeline",
        version="1.0.0",
        identity=Identity(
            display_name="Simple Pipeline",
            description="Test",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        dag=DAG(
            steps=[
                PipelineStep(id="step1", operation="op1", dependencies=[]),
            ]
        ),
        inputs=[],
        outputs=[],
    )


@pytest.fixture
def parallel_pipeline() -> PipelineEntry:
    """Create a pipeline with parallel steps."""
    return PipelineEntry(
        name="parallel_pipeline",
        version="1.0.0",
        identity=Identity(
            display_name="Parallel Pipeline",
            description="Test",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        dag=DAG(
            steps=[
                PipelineStep(id="step1", operation="op1", dependencies=[]),
                PipelineStep(id="step2", operation="op2", dependencies=[]),
                PipelineStep(
                    id="step3", operation="op3", dependencies=["step1", "step2"]
                ),
            ]
        ),
        inputs=[],
        outputs=[],
    )


class TestRunAsync:
    """Tests for PipelineRunner.run_async method."""

    @pytest.mark.asyncio
    async def test_run_async_exists(self, mock_context: RuntimeContext) -> None:
        """run_async method exists on PipelineRunner."""
        runner = PipelineRunner(mock_context)
        assert hasattr(runner, "run_async")
        assert asyncio.iscoroutinefunction(runner.run_async)

    @pytest.mark.asyncio
    async def test_run_async_simple_pipeline(
        self, mock_context: RuntimeContext, simple_pipeline: PipelineEntry
    ) -> None:
        """run_async executes simple pipeline."""
        runner = PipelineRunner(mock_context)

        # Patch _run_step_async to avoid OperationEntry validation
        async def mock_run_step(*args: Any, **kwargs: Any) -> dict[str, Any]:
            return {"result": "data"}

        with patch.object(runner, "_run_step_async", side_effect=mock_run_step):
            result = await runner.run_async(simple_pipeline)

            assert "result" in result

    @pytest.mark.asyncio
    async def test_run_async_returns_dict(
        self, mock_context: RuntimeContext, simple_pipeline: PipelineEntry
    ) -> None:
        """run_async returns a dictionary."""
        runner = PipelineRunner(mock_context)

        async def mock_run_step(*args: Any, **kwargs: Any) -> dict[str, Any]:
            return {"output": 42}

        with patch.object(runner, "_run_step_async", side_effect=mock_run_step):
            result = await runner.run_async(simple_pipeline)

            assert isinstance(result, dict)


class TestGroupByLevel:
    """Tests for dependency level grouping."""

    def test_group_by_level_exists(self, mock_context: RuntimeContext) -> None:
        """_group_by_level method exists."""
        runner = PipelineRunner(mock_context)
        assert hasattr(runner, "_group_by_level")

    def test_group_by_level_single_step(self, mock_context: RuntimeContext) -> None:
        """Single step returns one level."""
        runner = PipelineRunner(mock_context)

        steps = ["step1"]
        deps = {"step1": []}

        levels = runner._group_by_level(steps, deps)

        assert len(levels) == 1
        assert levels[0] == ["step1"]

    def test_group_by_level_parallel_steps(self, mock_context: RuntimeContext) -> None:
        """Independent steps are in same level."""
        runner = PipelineRunner(mock_context)

        steps = ["step1", "step2", "step3"]
        deps = {"step1": [], "step2": [], "step3": ["step1", "step2"]}

        levels = runner._group_by_level(steps, deps)

        # step1 and step2 should be in level 0
        # step3 should be in level 1
        assert len(levels) == 2
        assert set(levels[0]) == {"step1", "step2"}
        assert levels[1] == ["step3"]
