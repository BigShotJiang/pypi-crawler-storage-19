"""IO Manager core logic."""

from typing import Any

from axm.catalog.entries import DataEntry
from axm_engine.io.backends import LocalBackend, StorageBackend


class IOManager:
    """Handles data loading and writing with strict validation.

    Args:
        backend: Optional storage backend for I/O operations.
                 Defaults to LocalBackend for filesystem access.
    """

    def __init__(self, backend: StorageBackend | None = None) -> None:
        """Initialize IOManager with optional storage backend."""
        self.backend = backend or LocalBackend()

    def load(self, entry: DataEntry) -> Any:
        """Load data from entry location and validate it.

        Args:
            entry: The DataEntry definition.

        Returns:
            The loaded data object (e.g. DataFrame) if valid.

        Raises:
            ValidationError: If the data does not match the schema.
            IOError: If data cannot be read.
        """
        # 1. Read Raw Data
        data = self._read_data(entry)

        # 2. Validate
        # Local import to avoid circular dependency
        from axm.catalog.validation import SchemaValidator

        validator = SchemaValidator(entry)
        result = validator.validate(data)

        if not result.is_valid:
            # Raise exception on validation failure (Zero-Trust)
            msg = f"Data validation failed for {entry.name}: {result.errors}"
            raise ValueError(msg)

        return data

    def save(self, entry: DataEntry, data: Any) -> None:
        """Validate data and save it using standard operations."""
        # 1. Validate BEFORE Save (Zero-Trust)
        from axm.catalog.validation import SchemaValidator

        validator = SchemaValidator(entry)
        result = validator.validate(data)
        if not result.is_valid:
            msg = f"Output validation failed for {entry.name}: {result.errors}"
            raise ValueError(msg)

        # 2. Run Save Operation
        fmt = entry.data_schema.format
        fmt_str = fmt.value if hasattr(fmt, "value") else fmt
        from axm.operations import OperationRegistry

        op = OperationRegistry.get(f"{fmt_str}.save")

        # Build context
        context = {"path": entry.location.path_template}  # Simplification

        op_result = op.execute(data, context, {})
        if not op_result.success:
            raise OSError(f"Failed to save {entry.name}: {op_result.error}")

    def _read_data(self, entry: DataEntry) -> Any:
        """Internal method to read raw data based on storage backend."""
        fmt = entry.data_schema.format
        fmt_str = fmt.value if hasattr(fmt, "value") else fmt
        from axm.operations import OperationRegistry

        op = OperationRegistry.get(f"{fmt_str}.load")

        # Build context - In AXM, location holds the path
        context = {"path": entry.location.path_template}  # Simplification for now

        result = op.execute(None, context, {})
        if not result.success:
            raise OSError(f"Failed to load {entry.name}: {result.error}")

        return result.data
