"""Storage backend abstractions for IOManager.

This module defines the StorageBackend protocol and implementations
for different storage systems (local filesystem, S3, GCS, etc.).
"""

from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class StorageBackend(Protocol):
    """Protocol for storage backends.

    Implementations can support local filesystem, S3, GCS, Azure Blob, etc.
    This abstraction enables:
    - Phase B: Cloud connectors (S3/GCS)
    - Phase D: Zero-Copy with lazy loading
    """

    def read(self, path: str) -> bytes:
        """Read raw bytes from the given path.

        Args:
            path: The path or key to read from.

        Returns:
            The raw bytes content.

        Raises:
            FileNotFoundError: If the path does not exist.
            IOError: If reading fails.
        """
        ...

    def write(self, path: str, data: bytes) -> None:
        """Write raw bytes to the given path.

        Args:
            path: The path or key to write to.
            data: The raw bytes to write.

        Raises:
            IOError: If writing fails.
        """
        ...

    def exists(self, path: str) -> bool:
        """Check if a path exists.

        Args:
            path: The path or key to check.

        Returns:
            True if the path exists, False otherwise.
        """
        ...


class LocalBackend:
    """Local filesystem storage backend.

    This is the default backend for IOManager, providing
    standard file I/O operations.
    """

    def read(self, path: str) -> bytes:
        """Read bytes from local file."""
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        return file_path.read_bytes()

    def write(self, path: str, data: bytes) -> None:
        """Write bytes to local file, creating parent directories."""
        file_path = Path(path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_bytes(data)

    def exists(self, path: str) -> bool:
        """Check if local file exists."""
        return Path(path).exists()
