"""Pipeline orchestration and execution."""

import time
from typing import Any

from axm.catalog.entries.pipeline import PipelineEntry, PipelineStep
from axm.observability.hooks import get_audit_hook
from axm_engine.context import OperationRequest, RuntimeContext
from axm_engine.dag import topological_sort
from axm_engine.execution import OperationRunner
from axm_engine.io import IOManager


class PipelineRunner:
    """Orchestrates the execution of a PipelineEntry DAG.

    Manages step dependencies and intermediate data flow.
    """

    def __init__(
        self, context: RuntimeContext, io_manager: IOManager | None = None
    ) -> None:
        self.context = context
        self.io = io_manager or IOManager()
        self._op_runner = OperationRunner(context, io_manager=self.io)

    def run(
        self, pipeline: PipelineEntry, inputs: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute the pipeline DAG.

        Workflow:
        1. Sort steps topologically.
        2. Execute each step, capturing outputs.
        3. Pass outputs of one step as inputs to dependent steps.
        """
        # Start timing and notify hook
        start_ns = time.perf_counter_ns()
        hook = get_audit_hook()
        hook.on_pipeline_start(pipeline.name)

        try:
            # 1. Prepare graph
            steps = {step.id: step for step in pipeline.dag.steps}
            deps = {step.id: step.dependencies for step in pipeline.dag.steps}

            # 2. Sort
            ordered_step_ids = topological_sort(list(steps.keys()), deps)

            # 3. Execution state (capturing intermediate results)
            # key: step_id, value: dict[binding_name, data]
            results: dict[str, dict[str, Any]] = {}

            # Load pipeline inputs from catalog via IOManager
            pipeline_inputs: dict[str, Any] = inputs or {}
            for binding in pipeline.inputs:
                if binding.name not in pipeline_inputs:
                    # Load from catalog using data: namespace
                    data_key = f"data:{binding.data_ref}"
                    try:
                        data_entry = self.context.catalog[data_key]
                        pipeline_inputs[binding.name] = self.io.load(data_entry)
                    except KeyError:
                        # Fallback: try loading without namespace
                        data_entry = self.context.catalog[binding.data_ref]
                        pipeline_inputs[binding.name] = self.io.load(data_entry)

            # 4. Run loop
            for step_id in ordered_step_ids:
                step = steps[step_id]

                # Resolve operation entry (use namespaced lookup)
                op_key = f"operation:{step.operation}"
                op_entry = self.context.catalog[op_key]

                # Prepare inputs for this step
                # Start with pipeline inputs for root steps, then add dependency outputs
                step_inputs = dict(pipeline_inputs) if not step.dependencies else {}
                for dep_id in step.dependencies:
                    # Merge all outputs from dependency result as potential inputs
                    step_inputs.update(results[dep_id])

                # Request execution
                request = OperationRequest(
                    operation=op_entry, inputs=step_inputs, parameters=step.arguments
                )

                # Execute step
                step_outputs = self._op_runner.run(request)

                # Store results
                results[step_id] = step_outputs

            # 5. Collect final results
            final_outputs = {}
            for _step_id, res in results.items():
                final_outputs.update(res)

            # 6. Save outputs to catalog (mirrors input loading)
            if pipeline.outputs:
                for binding in pipeline.outputs:
                    if binding.name in final_outputs:
                        # Resolve output data entry
                        data_key = f"data:{binding.data_ref}"
                        try:
                            data_entry = self.context.catalog[data_key]
                        except KeyError:
                            data_entry = self.context.catalog[binding.data_ref]

                        # Save output via IOManager
                        self.io.save(data_entry, final_outputs[binding.name])

            return final_outputs

        finally:
            # End timing and notify hook
            duration_ns = time.perf_counter_ns() - start_ns
            hook.on_pipeline_end(pipeline.name, duration_ns)

    async def run_async(
        self, pipeline: PipelineEntry, inputs: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute the pipeline DAG asynchronously.

        Steps without dependencies can run in parallel for improved performance.

        Args:
            pipeline: The pipeline entry to execute.
            inputs: Optional pre-loaded inputs (bypasses catalog loading).

        Returns:
            Dictionary of final output values.
        """
        import asyncio

        # 1. Prepare graph
        steps = {step.id: step for step in pipeline.dag.steps}
        deps = {step.id: step.dependencies for step in pipeline.dag.steps}

        # 2. Sort and group by level
        ordered_step_ids = topological_sort(list(steps.keys()), deps)
        levels = self._group_by_level(ordered_step_ids, deps)

        # 3. Execution state
        results: dict[str, dict[str, Any]] = {}

        # Load pipeline inputs
        pipeline_inputs: dict[str, Any] = inputs or {}
        for binding in pipeline.inputs:
            if binding.name not in pipeline_inputs:
                data_key = f"data:{binding.data_ref}"
                try:
                    data_entry = self.context.catalog[data_key]
                    pipeline_inputs[binding.name] = self.io.load(data_entry)
                except KeyError:
                    data_entry = self.context.catalog[binding.data_ref]
                    pipeline_inputs[binding.name] = self.io.load(data_entry)

        # 4. Run each level (parallel within level)
        for level_step_ids in levels:
            if len(level_step_ids) == 1:
                # Single step, run directly
                step_result = await self._run_step_async(
                    steps[level_step_ids[0]], pipeline_inputs, results
                )
                results[level_step_ids[0]] = step_result
            else:
                # Multiple independent steps, run in parallel
                tasks = [
                    self._run_step_async(steps[sid], pipeline_inputs, results)
                    for sid in level_step_ids
                ]
                step_results = await asyncio.gather(*tasks)
                for sid, res in zip(level_step_ids, step_results, strict=True):
                    results[sid] = res

        # 5. Return final results
        final_outputs = {}
        for _step_id, res in results.items():
            final_outputs.update(res)

        return final_outputs

    async def _run_step_async(
        self,
        step: "PipelineStep",
        pipeline_inputs: dict[str, Any],
        results: dict[str, dict[str, Any]],
    ) -> dict[str, Any]:
        """Run a single step asynchronously."""
        import asyncio

        from axm_engine.context import OperationRequest

        # Resolve operation entry
        op_key = f"operation:{step.operation}"
        op_entry = self.context.catalog[op_key]

        # Prepare inputs
        step_inputs = dict(pipeline_inputs) if not step.dependencies else {}
        for dep_id in step.dependencies:
            step_inputs.update(results[dep_id])

        # Request execution
        request = OperationRequest(
            operation=op_entry, inputs=step_inputs, parameters=step.arguments
        )

        # Run in thread pool
        return await asyncio.to_thread(self._op_runner.run, request)

    def _group_by_level(
        self, ordered_step_ids: list[str], deps: dict[str, list[str]]
    ) -> list[list[str]]:
        """Group steps by dependency level.

        Steps with no dependencies or whose dependencies are all in previous
        levels are grouped together for parallel execution.

        Args:
            ordered_step_ids: Topologically sorted step IDs.
            deps: Mapping of step ID to list of dependency step IDs.

        Returns:
            List of levels, where each level contains step IDs that can run
            in parallel.
        """
        levels: list[list[str]] = []
        assigned: set[str] = set()

        for step_id in ordered_step_ids:
            step_deps = set(deps.get(step_id, []))

            # Find the level where all dependencies are satisfied
            level_idx = 0
            for dep in step_deps:
                # Find which level this dependency is in
                for i, level in enumerate(levels):
                    if dep in level:
                        level_idx = max(level_idx, i + 1)
                        break

            # Add to appropriate level
            while len(levels) <= level_idx:
                levels.append([])
            levels[level_idx].append(step_id)
            assigned.add(step_id)

        return levels
