# 🧙‍♂️ Agewizard

**Agewizard** is a world-class, magic-like Python library designed to handle all your age and date of birth (DOB) calculations with zero effort. Whether you need an exact age, zodiac signs, or next birthday countdowns, Agewizard does it all in a single line.

[![PyPI Version](https://img.shields.io/pypi/v/agewizard.svg)](https://pypi.org/project/agewizard/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features

- **🚀 Instant Age**: Calculate age in years, months, weeks, or days.
- **�️ Strict Validation**: Automatically catches invalid months (e.g., month 22) or invalid days (e.g., Feb 30).
- **📅 Customizable Formats**: Supports ANY date format (e.g., `DD-MM-YYYY`, `MM.DD.YYYY`, `YYYY/MM/DD`).
- **🔞 Age Verification**: One-line checks for account eligibility (e.g., `is_adult()`).
- **♈ Zodiac Magic**: Get star signs instantly from a DOB.
- **🎂 Birthday Insights**: Countdown to the next birthday and find out what day of the week it falls on.
- **👶 Age Classification**: Infant, Child, Teen, Adult, Senior.
- **🌗 Multi-Cultural**: Basic Hijri lunar age approximation.

---

## 🛠 Installation

```bash
pip install agewizard
```

---

## 📖 Detailed Usage

### 1. Strict Validation & Error Handling
Agewizard ensures you never process "fake" dates.

```python
from agewizard import Age

try:
    # This will raise a helpful ValueError
    user = Age("2021-02-30") 
except ValueError as e:
    print(f"Invalid date: {e}")
```

### 2. Custom Date Formats (Global Support)
Different countries use different formats. Agewizard handles them all.

```python
from agewizard import Age

# UK/Europe Format
uk_user = Age("31-12-1990", date_format="DD-MM-YYYY")

# US Format
us_user = Age("12.31.1990", date_format="MM.DD.YYYY")

# Default (Auto-detects YYYY-MM-DD or DD-MM-YYYY)
auto_user = Age("2000-01-01")
```

### 3. One-Line Age Verification
Perfect for apps that require a minimum age (like 18+).

```python
from agewizard import Age

user_dob = input("Enter your DOB: ")
person = Age(user_dob)

if person.is_adult():
    print("✅ Access Granted: 18+")
else:
    print(f"❌ Access Denied: You are only {person.years}")

# Custom age checks
if person.is_over(21):
    print("🥃 You can enter the bar.")
```

### 4. Interactive User Input Example
```python
from agewizard import Age

dob_input = input("Birth Date (DD-MM-YYYY): ")
try:
    p = Age(dob_input, date_format="DD-MM-YYYY")
    print(f"Wizard Result: {p.readable}")
    print(f"Zodiac: {p.zodiac}")
except ValueError as e:
    print(f"Please check your input: {e}")
```

---

## 👨‍💻 Author
**Kamran Hussain**  
- **Email**: [contact.kamrankami@gmail.com](mailto:contact.kamrankami@gmail.com)  
- **GitHub**: [KamranProjects](https://github.com/KamranProjects)

---

## 📜 License
Agewizard is open-source software licensed under the **MIT License**.
