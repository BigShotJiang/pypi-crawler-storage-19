class VPNConnectionError(Exception):
    pass

