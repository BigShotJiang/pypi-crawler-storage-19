# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowComplianceStatusForOrganizationalUnitResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'compliance_status': 'str'
    }

    attribute_map = {
        'compliance_status': 'compliance_status'
    }

    def __init__(self, compliance_status=None):
        r"""ShowComplianceStatusForOrganizationalUnitResponse

        The model defined in huaweicloud sdk

        :param compliance_status: 合规状态。
        :type compliance_status: str
        """
        
        super().__init__()

        self._compliance_status = None
        self.discriminator = None

        if compliance_status is not None:
            self.compliance_status = compliance_status

    @property
    def compliance_status(self):
        r"""Gets the compliance_status of this ShowComplianceStatusForOrganizationalUnitResponse.

        合规状态。

        :return: The compliance_status of this ShowComplianceStatusForOrganizationalUnitResponse.
        :rtype: str
        """
        return self._compliance_status

    @compliance_status.setter
    def compliance_status(self, compliance_status):
        r"""Sets the compliance_status of this ShowComplianceStatusForOrganizationalUnitResponse.

        合规状态。

        :param compliance_status: The compliance_status of this ShowComplianceStatusForOrganizationalUnitResponse.
        :type compliance_status: str
        """
        self._compliance_status = compliance_status

    def to_dict(self):
        import warnings
        warnings.warn("ShowComplianceStatusForOrganizationalUnitResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowComplianceStatusForOrganizationalUnitResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
