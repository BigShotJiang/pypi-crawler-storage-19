"""
Integration Tests for CompletionClient

Tests for the CompletionClient which handles compression + LLM calls.
CompletionClient requires TWO keys:
  1. Compresr API key (for compression service)
  2. Target model API key (OpenAI/Anthropic - for LLM calls)

Uses ADMIN keys for full functional testing (no rate limits).
Uses USER keys for rate limit testing.

Run with:
    pytest tests/test_completion_client.py --env=dev -v
    pytest tests/test_completion_client.py --env=prod -v
"""

import time
import pytest

from compresr import CompletionClient
from compresr.schemas import (
    CompletionResponse,
    BatchCompletionResponse,
    StreamChunk,
)
from compresr.exceptions import RateLimitError, AuthenticationError, ServerError

# Default models
DEFAULT_TARGET_MODEL = "gpt-4o-mini"
DEFAULT_COMPRESSION_MODEL = "cmprsr_v1"


def handle_admin_usage_limit(e):
    """Helper to handle unexpected usage limits in admin tests."""
    if "usage limit" in str(e).lower() or "insufficient credits" in str(e).lower():
        pytest.skip(f"Admin account hit usage limit (should not happen): {e}")
    raise e


# =============================================================================
# Fixtures - Client Setup (base_url, admin_api_key, openai_api_key from conftest.py)
# =============================================================================


@pytest.fixture
def admin_client(admin_api_key, openai_api_key, base_url):
    """Create CompletionClient with ADMIN key (no rate limit) + OpenAI key."""
    if not admin_api_key or not openai_api_key:
        pytest.skip("Admin API key or OpenAI key not available")
    return CompletionClient(
        api_key=admin_api_key,
        target_api_key=openai_api_key,
        default_model=DEFAULT_TARGET_MODEL,
        base_url=base_url
    )


@pytest.fixture
def user_client(user_api_key, openai_api_key, base_url):
    """Create CompletionClient with USER key (with rate limit) + OpenAI key."""
    if not user_api_key or not openai_api_key:
        pytest.skip("User API key or OpenAI key not available")
    return CompletionClient(
        api_key=user_api_key,
        target_api_key=openai_api_key,
        default_model=DEFAULT_TARGET_MODEL,
        base_url=base_url
    )


@pytest.fixture
def compression_only_api_key():
    """Get compression-only API key that should NOT work with completion service."""
    import os
    key = os.getenv("COMPRESSION_SERVICE_ADMIN_KEY")
    if not key:
        pytest.skip("COMPRESSION_SERVICE_ADMIN_KEY not set in .env.test")
    return key


# =============================================================================
# FUNCTIONAL TESTS - Using Admin Key (No Rate Limit)
# =============================================================================

class TestBasicCompletion:
    """Basic completion tests using admin key."""

    def test_basic_completion(self, admin_client):
        """Test basic sync completion with simple prompt."""
        try:
            response = admin_client.generate(
                prompt="What is 2 + 2? Answer in one word.",
                target_model=DEFAULT_TARGET_MODEL,
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
            )
        except (ServerError, RateLimitError) as e:
            handle_admin_usage_limit(e)
        
        assert response is not None
        assert isinstance(response, CompletionResponse)
        assert response.success is True
        assert response.data is not None
        assert response.data.original_tokens > 0
        assert response.data.compressed_tokens > 0
        assert response.data.target_model_response is not None
        assert len(response.data.target_model_response) > 0

    def test_completion_with_explicit_model(self, admin_client):
        """Test completion with explicitly specified model."""
        try:
            response = admin_client.generate(
                prompt="What is the capital of France? Answer briefly.",
                target_model="gpt-4o-mini",
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
            )
        except (ServerError, RateLimitError) as e:
            handle_admin_usage_limit(e)
        
        assert response.success is True
        assert response.data.target_model_response is not None
        assert "Paris" in response.data.target_model_response or "paris" in response.data.target_model_response.lower()

    def test_completion_returns_metrics(self, admin_client):
        """Test that completion returns all expected metrics."""
        response = admin_client.generate(
            prompt="Explain what AI is in one sentence.",
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.data.original_tokens is not None
        assert response.data.compressed_tokens is not None
        assert response.data.actual_compression_ratio is not None
        assert response.data.target_model_response is not None


class TestCompressionRatioCompletion:
    """Tests for compression ratio control in completion."""

    def test_completion_with_compression_ratio(self, admin_client):
        """Test completion with specified compression ratio."""
        prompt = """
        Please explain the concept of machine learning in detail, 
        including supervised learning, unsupervised learning, and 
        reinforcement learning approaches.
        """
        
        response = admin_client.generate(
            prompt=prompt,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
            compression_ratio=0.5,
        )
        
        assert response.success is True
        assert response.data.actual_compression_ratio is not None
        assert response.data.target_model_response is not None


class TestAsyncCompletion:
    """Tests for asynchronous completion."""

    @pytest.mark.asyncio
    async def test_async_completion(self, admin_client):
        """Test basic async completion."""
        response = await admin_client.generate_async(
            prompt="What color is the sky? Answer in one word.",
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert response.data.target_model_response is not None


class TestBatchCompletion:
    """Tests for batch completion."""

    def test_batch_completion(self, admin_client):
        """Test batch completion with multiple prompts."""
        prompts = [
            "What is 1 + 1? Answer with just the number.",
            "What is the capital of Japan? Answer in one word.",
            "What color is grass? Answer in one word."
        ]
        
        response = admin_client.generate_batch(
            prompts=prompts,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert isinstance(response, BatchCompletionResponse)
        assert len(response.data.results) >= 2  # Mock has 2 results
        
        # Verify each result has a response
        for result in response.data.results:
            assert result.target_model_response is not None


class TestStreamingCompletion:
    """Tests for streaming completion."""

    def test_streaming_completion(self, admin_client):
        """Test streaming completion yields chunks."""
        chunks = []
        content = ""
        
        for chunk in admin_client.generate_stream(
            prompt="Count from 1 to 5, one number per line.",
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        ):
            chunks.append(chunk)
            assert isinstance(chunk, StreamChunk)
            if chunk.content:
                content += chunk.content
        
        # Verify we got chunks (stream worked)
        assert len(chunks) > 0, "Should receive at least one chunk from stream"
        # Verify last chunk signals done
        assert chunks[-1].done is True, "Last chunk should have done=True"


class TestResponseStructure:
    """Tests for response structure validation."""

    def test_completion_response_structure(self, admin_client):
        """Test completion response has all expected fields."""
        response = admin_client.generate(
            prompt="Say hello.",
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        # Check top-level response
        assert hasattr(response, 'success')
        assert isinstance(response.success, bool)
        assert hasattr(response, 'data')
        assert response.data is not None
        
        # Check data fields
        data = response.data
        assert hasattr(data, 'original_tokens')
        assert hasattr(data, 'compressed_tokens')
        assert hasattr(data, 'actual_compression_ratio')
        assert hasattr(data, 'target_model_response')
        assert isinstance(data.target_model_response, str)


# =============================================================================
# RATE LIMIT TESTS - Using User Key (With Rate Limit)
# =============================================================================

class TestRateLimit:
    """Tests for rate limit behavior using USER key to validate free tier limits."""

    def test_free_tier_3_requests_per_minute_limit(self, user_client):
        """Test that free tier users are limited to 3 requests per minute."""
        import time
        
        responses = []
        rate_limited = False
        limit_reason = None
        
        # Try 4 rapid requests within 1 minute - free tier should limit at 3/minute
        for i in range(4):
            try:
                response = user_client.generate(
                    prompt=f"What is {i} + 1? Answer with just the number.",
                    target_model=DEFAULT_TARGET_MODEL,
                    compression_model_name=DEFAULT_COMPRESSION_MODEL,
                )
                responses.append(response)
                time.sleep(1)  # Small delay between requests
            except RateLimitError as e:
                rate_limited = True
                limit_reason = str(e)
                
                # Check if this is the daily limit (100/day) or per-minute limit (3/minute)
                if "rpd limit" in limit_reason.lower() or "100 requests/day" in limit_reason.lower():
                    pytest.skip(f"Hit daily rate limit before testing per-minute limit: {e}")
                
                # If it's the per-minute limit, validate it
                if "3" in limit_reason or "minute" in limit_reason.lower():
                    assert len(responses) == 3, f"Expected to be rate limited after 3 requests, got limited after {len(responses)}"
                break
            except Exception as e:
                if "rate limit" in str(e).lower() or "429" in str(e):
                    rate_limited = True
                    limit_reason = str(e)
                    if "rpd limit" in limit_reason.lower() or "100 requests/day" in limit_reason.lower():
                        pytest.skip(f"Hit daily rate limit before testing per-minute limit: {e}")
                    break
        
        # Validate free tier limit behavior
        if rate_limited and limit_reason:
            if len(responses) <= 3:
                # Either hit the 3/minute limit (good) or daily limit (skip)
                pass
            else:
                # Hit rate limit after more than 3 requests - unexpected
                assert False, f"Free tier allowed {len(responses)} requests before rate limiting"
        else:
            # If no rate limiting enforced yet, that's also valid during testing
            pass


# =============================================================================
# ERROR HANDLING TESTS
# =============================================================================

class TestErrorHandling:
    """Tests for error handling - validation errors."""

    def test_empty_prompt_error(self, admin_client):
        """Test that empty prompt raises error."""
        with pytest.raises(Exception):
            admin_client.generate(
                prompt="",
                target_model=DEFAULT_TARGET_MODEL,
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
            )

    def test_invalid_compression_ratio_high(self, admin_client):
        """Test that compression ratio > 0.9 raises error."""
        with pytest.raises(Exception):
            admin_client.generate(
                prompt="Test prompt",
                target_model=DEFAULT_TARGET_MODEL,
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
                compression_ratio=1.5,
            )

    def test_invalid_compression_ratio_low(self, admin_client):
        """Test that compression ratio < 0.1 raises error."""
        with pytest.raises(Exception):
            admin_client.generate(
                prompt="Test prompt",
                target_model=DEFAULT_TARGET_MODEL,
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
                compression_ratio=0.05,
            )


class TestClientInitialization:
    """Tests for client initialization."""

    def test_missing_target_api_key_raises_error(self, admin_api_key, base_url):
        """Test that missing target_api_key raises AuthenticationError."""
        with pytest.raises(AuthenticationError):
            CompletionClient(
                api_key=admin_api_key,
                target_api_key="",  # Empty key
                base_url=base_url
            )

    def test_client_with_default_model(self, admin_api_key, openai_api_key, base_url):
        """Test client initialization with default model."""
        client = CompletionClient(
            api_key=admin_api_key,
            target_api_key=openai_api_key,
            default_model="gpt-4o-mini",
            base_url=base_url
        )
        
        # Should work with explicit target_model and compression_model_name
        response = client.generate(
            prompt="Say hi.",
            target_model="gpt-4o-mini",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        assert response.success is True


class TestAPIKeyIsolation:
    """Tests for API key isolation - compression keys should not work for completion service."""

    def test_compression_key_fails_for_completion_service(self, compression_only_api_key, openai_api_key, base_url):
        """Test that compression service API key cannot be used for completion service."""
        client = CompletionClient(
            api_key=compression_only_api_key,  # Use compression key for completion service (should fail)
            target_api_key=openai_api_key,
            default_model=DEFAULT_TARGET_MODEL,
            base_url=base_url
        )
        
        # Should fail with authentication error since compression key can't access completion service
        with pytest.raises((AuthenticationError, Exception)) as exc_info:
            client.generate(
                prompt="Test prompt for completion service.",
                target_model=DEFAULT_TARGET_MODEL,
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
            )
        
        # Verify it's a scope error - compression key used for completion service
        error_msg = str(exc_info.value).lower()
        assert any(word in error_msg for word in ['scope', 'compress', 'completion', 'not allowed']), \
            f"Expected scope error for wrong API key type, got: {exc_info.value}"


# =============================================================================
# ADDITIONAL INTEGRATION TESTS
# =============================================================================

class TestModelSupport:
    """Tests for different model support."""

    def test_openai_gpt_4o_mini(self, admin_client):
        """Test completion with GPT-4o-mini model."""
        response = admin_client.generate(
            prompt="What is the square root of 16? Answer with just the number.",
            target_model="gpt-4o-mini",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert "4" in response.data.target_model_response

    def test_openai_gpt_4o(self, admin_client):
        """Test completion with GPT-4o model."""
        response = admin_client.generate(
            prompt="What is 10 * 10? Answer with just the number.",
            target_model="gpt-4o",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert "100" in response.data.target_model_response


class TestCompressionEffectiveness:
    """Tests to verify compression is actually working."""

    def test_compression_reduces_tokens(self, admin_client):
        """Test that compression actually reduces token count."""
        # Use a long, verbose prompt that should compress well
        long_prompt = """
        I would like you to provide me with a comprehensive and detailed explanation 
        of the concept of artificial intelligence, including but not limited to 
        machine learning algorithms, neural networks, deep learning methodologies, 
        natural language processing techniques, computer vision applications, 
        and the various ways these technologies are being implemented and utilized 
        in modern society and industry today.
        """
        
        response = admin_client.generate(
            prompt=long_prompt,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert response.data.original_tokens > response.data.compressed_tokens
        assert response.data.actual_compression_ratio < 1.0
        assert response.data.tokens_saved > 0

    def test_different_compression_ratios(self, admin_client):
        """Test that different compression ratios produce different results.

        Platform semantics: compression_ratio is percentage to REMOVE
        - 0.3 = remove 30%, keep 70% → MORE tokens
        - 0.7 = remove 70%, keep 30% → FEWER tokens
        """
        prompt = """
        Explain the fundamentals of quantum computing, including qubits,
        superposition, entanglement, and quantum gates, and describe how
        these concepts enable quantum computers to solve certain problems
        exponentially faster than classical computers.
        """

        # Test with low compression (remove 30%, keep 70%)
        response_low_compression = admin_client.generate(
            prompt=prompt,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
            compression_ratio=0.3,
        )

        # Test with high compression (remove 70%, keep 30%)
        response_high_compression = admin_client.generate(
            prompt=prompt,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
            compression_ratio=0.7,
        )

        assert response_low_compression.success is True
        assert response_high_compression.success is True

        # 0.7 ratio (remove 70%) should result in FEWER tokens than 0.3 ratio (remove 30%)
        assert response_high_compression.data.compressed_tokens <= response_low_compression.data.compressed_tokens
        assert response_high_compression.data.tokens_saved >= response_low_compression.data.tokens_saved


class TestEdgeCases:
    """Tests for edge cases and boundary conditions."""

    def test_very_short_prompt(self, admin_client):
        """Test completion with very short prompt."""
        response = admin_client.generate(
            prompt="Hi",
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert response.data.target_model_response is not None
        assert len(response.data.target_model_response) > 0

    def test_prompt_with_special_characters(self, admin_client):
        """Test completion with special characters and formatting."""
        prompt = """
        What is the result of this calculation: 
        2 + 2 = ?
        Please answer with only the number.
        Special chars: @#$%^&*()_+{}[]|\\:";'<>?,./
        """
        
        # Use lower compression to preserve calculation context
        response = admin_client.generate(
            prompt=prompt,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
            compression_ratio=0.7,  # Conservative compression to keep important details
        )
        
        assert response.success is True
        # Check for "4" or variations like "four", "2+2=4"
        response_text = response.data.target_model_response.lower()
        assert "4" in response_text or "four" in response_text, f"Expected answer containing 4, got: {response.data.target_model_response}"

    def test_unicode_prompt(self, admin_client):
        """Test completion with Unicode characters."""
        response = admin_client.generate(
            prompt="What does this emoji mean? 🚀 Answer briefly.",
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert response.data.target_model_response is not None


class TestPerformanceMetrics:
    """Tests to verify performance metrics are accurate."""

    def test_duration_tracking(self, admin_client):
        """Test that duration is tracked properly."""
        response = admin_client.generate(
            prompt="What is the capital of France?",
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert hasattr(response.data, 'duration_ms')
        assert response.data.duration_ms > 0
        assert response.data.duration_ms < 60000  # Should be less than 60 seconds

    def test_token_usage_accuracy(self, admin_client):
        """Test that token counts are reasonable."""
        prompt = "What is artificial intelligence?"
        
        response = admin_client.generate(
            prompt=prompt,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert response.data.original_tokens > 0
        assert response.data.compressed_tokens > 0
        assert response.data.original_tokens >= len(prompt.split())  # At least as many tokens as words
        
        # Check that target model usage is tracked
        assert hasattr(response.data, 'target_model_usage')
        assert 'total_tokens' in response.data.target_model_usage
        assert response.data.target_model_usage['total_tokens'] > 0


class TestBatchOperations:
    """Extended tests for batch operations."""

    def test_large_batch_completion(self, admin_client):
        """Test batch completion with larger number of prompts."""
        prompts = [
            "What is 2+2?",
            "What is 3+3?", 
            "What is 4+4?",
            "What is 5+5?",
            "What is 6+6?"
        ]
        
        response = admin_client.generate_batch(
            prompts=prompts,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert len(response.data.results) == len(prompts)
        
        # Check that all responses contain numbers
        for i, result in enumerate(response.data.results):
            expected_result = str((i + 2) * 2)  # 2+2=4, 3+3=6, etc.
            assert expected_result in result.target_model_response or \
                   str(int(expected_result)) in result.target_model_response

    def test_mixed_complexity_batch(self, admin_client):
        """Test batch with prompts of different complexity."""
        prompts = [
            "Hi",  # Very simple
            "What is machine learning?",  # Medium complexity
            """Explain the theoretical foundations of quantum computing, including 
               the mathematical principles behind quantum superposition and entanglement."""  # Complex
        ]
        
        response = admin_client.generate_batch(
            prompts=prompts,
            target_model=DEFAULT_TARGET_MODEL,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert len(response.data.results) == 3
        
        # Simple prompt should have fewer tokens
        assert response.data.results[0].original_tokens < response.data.results[2].original_tokens
        # All should have valid responses
        for result in response.data.results:
            assert result.target_model_response is not None
            assert len(result.target_model_response) > 0


# =============================================================================
# Run tests if executed directly
# =============================================================================
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
