# Compresr Python SDK

Intelligent prompt compression to optimize LLM costs and performance.

## Installation

```bash
pip install compresr
```

## Quick Start

### API Key Setup

Get your API key from [compresr.ai](https://compresr.ai) and set it up:

```python
import os
os.environ["COMPRESR_API_KEY"] = "cmp_your_api_key_here"

# Or pass directly to client
from compresr import CompletionClient
client = CompletionClient(
    api_key="cmp_your_api_key_here",
    target_api_key="sk_your_openai_key_here"  # Required for LLM calls
)
```

### Completion Client (Compression + LLM)

Compress your prompts and get LLM responses in one call:

```python
from compresr import CompletionClient

client = CompletionClient(
    api_key="cmp_your_api_key",
    target_api_key="sk_your_openai_key"  # Required for LLM calls
)

# Generate completion with compression
result = client.generate(
    prompt="Your very long prompt that needs compression...",
    target_model="gpt-4o-mini",
    compression_model_name="cmprsr_v1"
)

print(result.data.target_model_response)
print(f"Compression ratio: {result.data.actual_compression_ratio:.2%}")
print(f"Tokens saved: {result.data.tokens_saved}")
```

### Compression Client (Compression Only)

Get compressed context for use with your own LLM:

```python
from compresr import CompressionClient

client = CompressionClient(api_key="cmp_your_api_key")

# Get compressed context
result = client.generate(
    context="Your very long context that needs compression...",
    compression_model_name="cmprsr_v1"
)

compressed_context = result.data.compressed_context
# Now use with your own LLM: openai.chat(messages=[{"role": "user", "content": compressed_context}])
```

## Streaming Support

Both clients support real-time streaming:

```python
# Completion streaming
for chunk in client.generate_stream(
    prompt="Write a long story about...",
    target_model="gpt-4o-mini",
    compression_model_name="cmprsr_v1"
):
    print(chunk.content, end="", flush=True)

# Compression streaming  
compression_client = CompressionClient(api_key="...")
for chunk in compression_client.generate_stream(
    context="Your long context...",
    compression_model_name="cmprsr_v1"
):
    print(chunk.content, end="", flush=True)
```

## Async Support

All methods have async variants:

```python
import asyncio
from compresr import CompletionClient

async def main():
    client = CompletionClient(
        api_key="...",
        target_api_key="sk_..."
    )
    
    result = await client.generate_async(
        prompt="Your prompt...",
        target_model="gpt-4o-mini",
        compression_model_name="cmprsr_v1"
    )
    
    print(result.data.target_model_response)
    await client.close()

asyncio.run(main())
```

## Batch Processing

Process multiple requests efficiently:

```python
client = CompletionClient(
    api_key="...",
    target_api_key="sk_..."
)
results = client.generate_batch(
    prompts=[
        "First prompt to compress and send to LLM...",
        "Second prompt to compress and send to LLM..."
    ],
    target_model="gpt-4o-mini",
    compression_model_name="cmprsr_v1"
)

for result in results:
    print(f"Response: {result.data.target_model_response}")
```

### Compression Client Batch Processing

For compression-only operations:

```python
client = CompressionClient(api_key="...")
results = client.generate_batch(
    contexts=[
        "First context to compress...",
        "Second context to compress..."
    ],
    compression_model_name="cmprsr_v1"
)

for result in results.data.results:
    print(f"Compressed: {result.compressed_context}")
```

## Key Features

- **🗜️ Intelligent Compression**: Reduce prompt lengths while preserving meaning
- **💰 Cost Optimization**: Save 30-70% on LLM API costs through intelligent compression
- **⚡ Dual Modes**: Compression-only or Compression + LLM completion
- **🔄 Streaming Support**: Real-time response streaming
- **📊 Usage Tracking**: Monitor credits, costs, and compression ratios
- **🔗 Async Ready**: Full async/await support
- **📦 Batch Processing**: Handle multiple requests efficiently

## Available Models

**Compression Models:**
- `cmprsr_v1` - Compresr V1 (default compression model)

**Target LLM Models:**
- OpenAI: `gpt-4o`, `gpt-4o-mini`, `gpt-3.5-turbo`
- Anthropic: `claude-3-sonnet`, `claude-3-haiku`
- And many more...

## Error Handling

```python
from compresr import CompletionClient
from compresr.exceptions import CompresrError, AuthenticationError, RateLimitError

client = CompletionClient(
    api_key="your_key",
    target_api_key="sk_your_target_key"
)

try:
    result = client.generate(
        prompt="Your prompt...",
        target_model="gpt-4o-mini",
        compression_model_name="cmprsr_v1"
    )
except AuthenticationError:
    print("Invalid API key")
except RateLimitError:
    print("Rate limit exceeded")
except CompresrError as e:
    print(f"API error: {e}")
```

## Authentication

The Compresr SDK uses API key authentication. You can get your API key from [compresr.ai](https://compresr.ai):

1. Create an account at [compresr.ai](https://compresr.ai)
2. Navigate to your API Keys section  
3. Generate a new API key
4. Use it with the SDK

## Requirements

- Python 3.9+
- `httpx >= 0.27.0`
- `pydantic >= 2.10.0`

## License

MIT License

## Support

- 📖 Documentation: [docs.compresr.ai](https://docs.compresr.ai)
- 💬 Support: [support@compresr.ai](mailto:support@compresr.ai)
- 🐛 Issues: [GitHub Issues](https://github.com/compresr/sdk/issues)
- 🌐 Website: [compresr.ai](https://compresr.ai)