"""
SDK Configuration

Constants and configuration for the Compresr Python SDK.
"""

import os
from dataclasses import dataclass


# =============================================================================
# Environment URLs
# =============================================================================
# Production: https://api.compresr.ai
# Development: http://localhost:8000

_DEFAULT_BASE_URL = "https://api.compresr.ai"


# =============================================================================
# API Configuration
# =============================================================================

@dataclass(frozen=True)
class APIConfig:
    """API configuration constants."""
    
    # Base URL uses environment-specific variables
    DEFAULT_BASE_URL: str = os.getenv(
        "DEV_COMPRESR_BASE_URL" if os.getenv("DEPLOY_ENV", "production") == "development" else "PROD_COMPRESR_BASE_URL",
        _DEFAULT_BASE_URL
    )
    API_KEY_PREFIX: str = "cmp_"
    
    # Timeouts (seconds)
    DEFAULT_TIMEOUT: int = 60
    BATCH_TIMEOUT: int = 120
    STREAM_TIMEOUT: int = 300


# =============================================================================
# Model Configuration
# =============================================================================

@dataclass(frozen=True)
class ModelConfig:
    """Model configuration constants."""
    
    DEFAULT_COMPRESSION_RATIO: float = 0.5
    
    # Compression ratio bounds
    MIN_COMPRESSION_RATIO: float = 0.3
    MAX_COMPRESSION_RATIO: float = 0.7


# =============================================================================
# API Endpoints
# =============================================================================

@dataclass(frozen=True)
class Endpoints:
    """Backend API endpoints."""
    
    # Completion endpoints (compression + LLM call)
    COMPLETION: str = "/api/completion/generate"
    COMPLETION_BATCH: str = "/api/completion/batch"
    COMPLETION_STREAM: str = "/api/completion/stream"
    
    # Compression endpoints (compression only, no LLM call)
    COMPRESS: str = "/api/compression/generate"
    COMPRESS_BATCH: str = "/api/compression/batch"
    COMPRESS_STREAM: str = "/api/compression/stream"
    
    # Token endpoints
    TOKEN_COUNT: str = "/api/tokens/count"
    
    # Model endpoints
    MODELS: str = "/api/models"
    MODELS_PROVIDERS: str = "/api/models/providers"
    
    # Usage endpoints
    USAGE: str = "/api/usage"


# =============================================================================
# HTTP Headers
# =============================================================================

@dataclass(frozen=True)
class Headers:
    """HTTP header constants."""
    
    API_KEY: str = "X-API-Key"
    CONTENT_TYPE: str = "Content-Type"
    ACCEPT: str = "Accept"
    
    # Content types
    JSON: str = "application/json"
    SSE: str = "text/event-stream"


# =============================================================================
# Error Codes (must match backend/app/schemas/exceptions.py)
# =============================================================================

@dataclass(frozen=True)
class ErrorCodes:
    """Standard error codes - must match backend."""
    
    AUTHENTICATION_ERROR: str = "authentication_error"
    SCOPE_ERROR: str = "scope_error"
    RATE_LIMIT_ERROR: str = "rate_limit_error"
    VALIDATION_ERROR: str = "validation_error"
    SERVER_ERROR: str = "server_error"
    NOT_FOUND: str = "not_found"
    CONNECTION_ERROR: str = "connection_error"


# =============================================================================
# HTTP Status Codes
# =============================================================================

@dataclass(frozen=True)
class StatusCodes:
    """HTTP status codes."""
    
    OK: int = 200
    CREATED: int = 201
    BAD_REQUEST: int = 400
    UNAUTHORIZED: int = 401
    FORBIDDEN: int = 403
    NOT_FOUND: int = 404
    VALIDATION_ERROR: int = 422
    RATE_LIMITED: int = 429
    SERVER_ERROR: int = 500


# =============================================================================
# Singleton Instances
# =============================================================================

API_CONFIG = APIConfig()
MODEL_CONFIG = ModelConfig()
ENDPOINTS = Endpoints()
HEADERS = Headers()
ERROR_CODES = ErrorCodes()
STATUS_CODES = StatusCodes()
