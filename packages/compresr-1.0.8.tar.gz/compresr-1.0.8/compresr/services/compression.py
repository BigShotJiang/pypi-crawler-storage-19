"""
CompressionClient - Compression Only

Compresses context without calling an LLM.
Use when you want to integrate with your own LLM pipeline.
"""

from typing import Optional, List, Generator
from .proxy import HTTPClient
from ..config import ENDPOINTS
from ..schemas import (
    StreamChunk,
    CompressRequest,
    CompressResponse,
    BatchCompressRequest,
    BatchCompressResponse,
)


class CompressionClient(HTTPClient):
    """
    Compression client - compression only, no LLM call.
    
    Args:
        api_key: Your Compresr API key (required) - "cmp_..."
        base_url: API base URL (optional)
        timeout: Request timeout in seconds (optional)
    
    Example:
        client = CompressionClient(api_key="cmp_...")
        
        response = client.generate(
            context="Your long context...",
            compression_model_name="cmprsr_v1"
        )
        print(response.data.compressed_context)
    """
    
    # ==================== Sync ====================
    
    def generate(
        self,
        context: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> CompressResponse:
        """
        Compress context (sync).
        
        Args:
            context: Context text to compress (documents, background info, etc.)
            compression_model_name: Compression model to use (e.g., "cmprsr_v1") - REQUIRED
            target_compression_ratio: Compression ratio 0.1-0.9 (percentage to REMOVE - e.g., 0.3 removes 30%)
        
        Returns:
            CompressResponse with compressed context and metrics
        """
        req = CompressRequest(
            context=context,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPRESS, req.model_dump(exclude_none=True))
        return CompressResponse.model_validate(data)
    
    def generate_batch(
        self,
        contexts: List[str],
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> BatchCompressResponse:
        """
        Batch compression (sync).
        
        Args:
            contexts: List of context texts (max 100)
            compression_model_name: Compression model to use - REQUIRED
            target_compression_ratio: Target ratio (optional)
        """
        req = BatchCompressRequest(
            contexts=contexts,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPRESS_BATCH, req.model_dump(exclude_none=True))
        return BatchCompressResponse.model_validate(data)
    
    def generate_stream(
        self,
        context: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> Generator[StreamChunk, None, None]:
        """
        Stream compression (sync).
        
        Yields:
            StreamChunk objects with compressed content
        """
        req = CompressRequest(
            context=context,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        for content in self.stream(ENDPOINTS.COMPRESS_STREAM, req.model_dump(exclude_none=True)):
            yield StreamChunk(content=content, done=False)
        yield StreamChunk(content="", done=True)
    
    # ==================== Async ====================
    
    async def generate_async(
        self,
        context: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> CompressResponse:
        """Compress context (async)."""
        req = CompressRequest(
            context=context,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPRESS, req.model_dump(exclude_none=True))
        return CompressResponse.model_validate(data)
    
    async def generate_batch_async(
        self,
        contexts: List[str],
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> BatchCompressResponse:
        """Batch compression (async)."""
        req = BatchCompressRequest(
            contexts=contexts,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPRESS_BATCH, req.model_dump(exclude_none=True))
        return BatchCompressResponse.model_validate(data)
