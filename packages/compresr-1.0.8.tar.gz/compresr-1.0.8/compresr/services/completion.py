"""
CompletionClient - Compress Context + Combine with Prompt + LLM Call

Compresses context, combines with user's prompt, and sends to target LLMs using YOUR API key.
"""

from typing import Optional, List, Generator
from .proxy import HTTPClient
from ..config import ENDPOINTS
from ..exceptions import AuthenticationError, ValidationError
from ..schemas import (
    StreamChunk,
    CompletionRequest,
    CompletionResponse,
    BatchCompletionRequest,
    BatchCompletionResponse,
)


class CompletionClient(HTTPClient):
    """
    Completion client - compress context + combine with prompt + LLM call.
    
    Args:
        api_key: Your Compresr API key (required) - "cmp_..."
        target_api_key: Your LLM API key (required) - OpenAI "sk-...", Anthropic "sk-ant-..."
        default_model: Default target model (optional) - e.g., "gpt-4o-mini"
        base_url: API base URL (optional)
        timeout: Request timeout in seconds (optional)
    
    Example:
        client = CompletionClient(
            api_key="cmp_...",
            target_api_key="sk-...",  # Your OpenAI key
            default_model="gpt-4o-mini"
        )
        
        response = client.generate(
            prompt="Summarize this document.",
            context="Your long document text...",
            target_model="gpt-4o-mini",
            compression_model_name="cmprsr_v1"
        )
        print(response.data.target_model_response)
    """
    
    def __init__(
        self,
        api_key: str,
        target_api_key: str,
        default_model: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
    ):
        super().__init__(api_key, base_url, timeout)
        
        if not target_api_key:
            raise AuthenticationError("target_api_key is required (your OpenAI/Anthropic API key)")
        
        self._target_api_key = target_api_key
        self._default_model = default_model
    
    def _model(self, target_model: Optional[str]) -> str:
        """Get model, using default if not provided."""
        model = target_model or self._default_model
        if not model:
            raise ValidationError("target_model required (or set default_model in __init__)")
        return model
    
    # ==================== Sync ====================
    
    def generate(
        self,
        prompt: str,
        context: str,
        target_model: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> CompletionResponse:
        """
        Generate completion (sync).
        
        Args:
            prompt: User's question or instruction (not compressed)
            context: Context text to compress (documents, background info)
            target_model: LLM model - REQUIRED (e.g., "gpt-4o-mini", "claude-3-sonnet")
            compression_model_name: Compression model to use - REQUIRED (e.g., "cmprsr_v1")
            target_compression_ratio: Target ratio 0.1-0.9 (optional)
        
        Returns:
            CompletionResponse with metrics and LLM response
        """
        req = CompletionRequest(
            prompt=prompt,
            context=context,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPLETION, req.model_dump(exclude_none=True))
        return CompletionResponse.model_validate(data)
    
    def generate_batch(
        self,
        prompts: List[str],
        contexts: List[str],
        target_model: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> BatchCompletionResponse:
        """
        Batch completion (sync).
        
        Args:
            prompts: List of user questions/instructions (max 100)
            contexts: List of context texts to compress (must match prompts length)
            target_model: LLM model - REQUIRED
            compression_model_name: Compression model to use - REQUIRED
            target_compression_ratio: Target ratio (optional)
        """
        req = BatchCompletionRequest(
            prompts=prompts,
            contexts=contexts,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPLETION_BATCH, req.model_dump(exclude_none=True))
        return BatchCompletionResponse.model_validate(data)
    
    def generate_stream(
        self,
        prompt: str,
        context: str,
        target_model: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> Generator[StreamChunk, None, None]:
        """
        Stream completion (sync).
        
        Yields:
            StreamChunk objects with content
        """
        req = CompletionRequest(
            prompt=prompt,
            context=context,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        for content in self.stream(ENDPOINTS.COMPLETION_STREAM, req.model_dump(exclude_none=True)):
            yield StreamChunk(content=content, done=False)
        yield StreamChunk(content="", done=True)
    
    # ==================== Async ====================
    
    async def generate_async(
        self,
        prompt: str,
        context: str,
        target_model: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> CompletionResponse:
        """Generate completion (async)."""
        req = CompletionRequest(
            prompt=prompt,
            context=context,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPLETION, req.model_dump(exclude_none=True))
        return CompletionResponse.model_validate(data)
    
    async def generate_batch_async(
        self,
        prompts: List[str],
        contexts: List[str],
        target_model: str,
        compression_model_name: str,
        target_compression_ratio: Optional[float] = None,
    ) -> BatchCompletionResponse:
        """Batch completion (async)."""
        req = BatchCompletionRequest(
            prompts=prompts,
            contexts=contexts,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=target_compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPLETION_BATCH, req.model_dump(exclude_none=True))
        return BatchCompletionResponse.model_validate(data)
