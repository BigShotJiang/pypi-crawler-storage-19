"""
Compresr Services

Usage:
    from compresr import CompletionClient, CompressionClient
    
    # CompletionClient - compress + LLM call (requires target_api_key)
    client = CompletionClient(
        api_key="cmp_...",
        target_api_key="sk-...",  # YOUR OpenAI/Anthropic key (REQUIRED)
        default_model="gpt-4o-mini"
    )
    
    # CompressionClient - compression only
    client = CompressionClient(api_key="cmp_...")
"""

from .completion import CompletionClient
from .compression import CompressionClient

__all__ = ["CompletionClient", "CompressionClient"]
