"""
Exception Handlers - All exceptions, responses, and handlers in one place.

This is the SINGLE SOURCE OF TRUTH for all exception handling:
- Exception classes (ValidationError, RateLimitError, etc.)
- Response models (ValidationErrorResponse, RateLimitErrorResponse, etc.)  
- Handler functions (validation_error_handler, rate_limit_error_handler, etc.)
- Registration function (register_exception_handlers)

Usage in routers:
    from app.middleware.exception_handlers import ValidationError, ServerError
    
    if not valid:
        raise ValidationError(message="Invalid input", field="prompt")

Usage in main.py:
    from app.middleware.exception_handlers import register_exception_handlers
    register_exception_handlers(app)
"""
from pydantic import BaseModel
from typing import Optional
from enum import Enum
import logging

logger = logging.getLogger(__name__)


# =============================================================================
# ERROR CODES (Centralized)
# =============================================================================

class ErrorCode(str, Enum):
    """All error codes used across the platform."""
    # Authentication
    AUTHENTICATION_ERROR = "authentication_error"
    INVALID_API_KEY = "invalid_api_key"
    EXPIRED_API_KEY = "expired_api_key"
    REVOKED_API_KEY = "revoked_api_key"
    
    # Rate Limiting
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
    DAILY_LIMIT_EXCEEDED = "daily_limit_exceeded"
    
    # Budget & Credits
    INSUFFICIENT_CREDITS = "insufficient_credits"
    BUDGET_LIMIT_REACHED = "budget_limit_reached"
    API_KEY_BUDGET_EXCEEDED = "api_key_budget_exceeded"
    INCREASE_BUDGET_REQUIRED = "increase_budget_required"
    
    # Validation
    VALIDATION_ERROR = "validation_error"
    INVALID_INPUT = "invalid_input"
    
    # Permission
    SCOPE_ERROR = "scope_error"
    INSUFFICIENT_PERMISSIONS = "insufficient_permissions"
    
    # Server
    SERVER_ERROR = "server_error"
    CONNECTION_ERROR = "connection_error"
    TIMEOUT = "timeout"
    
    # Resource
    NOT_FOUND = "not_found"
    RESOURCE_NOT_FOUND = "resource_not_found"


# =============================================================================
# RESPONSE MODELS (for OpenAPI documentation)
# =============================================================================

class ErrorResponse(BaseModel):
    """Generic error response."""
    success: bool = False
    error: str
    detail: Optional[str] = None
    code: Optional[str] = None


class ValidationErrorResponse(BaseModel):
    """Validation error response - invalid input."""
    success: bool = False
    error: str
    detail: Optional[str] = None
    code: str = ErrorCode.VALIDATION_ERROR.value
    field: Optional[str] = None


class AuthenticationErrorResponse(BaseModel):
    """Authentication error response - invalid/missing API key."""
    success: bool = False
    error: str = "Authentication failed"
    detail: Optional[str] = None
    code: str = ErrorCode.AUTHENTICATION_ERROR.value


class RateLimitErrorResponse(BaseModel):
    """Rate limit error response - too many requests."""
    success: bool = False
    error: str = "Rate limit exceeded"
    detail: Optional[str] = None
    code: str = ErrorCode.RATE_LIMIT_EXCEEDED.value
    retry_after: Optional[int] = None


class BudgetErrorResponse(BaseModel):
    """Budget/credit error response - insufficient funds or budget reached."""
    success: bool = False
    error: str = "Budget limit reached"
    detail: Optional[str] = None
    code: str = ErrorCode.BUDGET_LIMIT_REACHED.value
    current_budget: Optional[float] = None
    budget_used: Optional[float] = None
    remaining: Optional[float] = None


class InsufficientCreditsErrorResponse(BaseModel):
    """Insufficient credits error response."""
    success: bool = False
    error: str = "Insufficient credits"
    detail: Optional[str] = None
    code: str = ErrorCode.INSUFFICIENT_CREDITS.value
    credits_required: Optional[float] = None
    credits_remaining: Optional[float] = None


class ScopeErrorResponse(BaseModel):
    """Scope/permission error response - API key lacks permission."""
    success: bool = False
    error: str = "Insufficient permissions"
    detail: Optional[str] = None
    code: str = ErrorCode.SCOPE_ERROR.value
    required_scope: Optional[str] = None


class ServerErrorResponse(BaseModel):
    """Server error response - internal error."""
    success: bool = False
    error: str = "Internal server error"
    detail: Optional[str] = None
    code: str = ErrorCode.SERVER_ERROR.value


class NotFoundErrorResponse(BaseModel):
    """Not found error response - resource doesn't exist."""
    success: bool = False
    error: str = "Resource not found"
    detail: Optional[str] = None
    code: str = ErrorCode.NOT_FOUND.value
    resource: Optional[str] = None


class ConnectionErrorResponse(BaseModel):
    """Connection error response - failed to connect to service."""
    success: bool = False
    error: str = "Connection failed"
    detail: Optional[str] = None
    code: str = ErrorCode.CONNECTION_ERROR.value
    service: Optional[str] = None


# =============================================================================
# EXCEPTION CLASSES (raised in routers/services)
# =============================================================================

class CompresrError(Exception):
    """Base exception for all Compresr errors."""
    def __init__(self, message: str, response_data: dict = None, code: str = None):
        super().__init__(message)
        self.message = message
        self.response_data = response_data or {}
        self.code = code


class AuthenticationError(CompresrError):
    """Raised when authentication fails (invalid/missing API key)."""
    def __init__(self, message: str = "Authentication failed", response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.AUTHENTICATION_ERROR.value)


class RateLimitError(CompresrError):
    """Raised when rate limit is exceeded."""
    def __init__(self, message: str, retry_after: int = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.RATE_LIMIT_EXCEEDED.value)
        self.retry_after = retry_after


class ValidationError(CompresrError):
    """Raised when request validation fails."""
    def __init__(self, message: str, field: str = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.VALIDATION_ERROR.value)
        self.field = field


class ScopeError(CompresrError):
    """Raised when API key lacks required permissions."""
    def __init__(self, message: str, required_scope: str = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.SCOPE_ERROR.value)
        self.required_scope = required_scope


class ServerError(CompresrError):
    """Raised when server encounters an internal error."""
    def __init__(self, message: str = "Internal server error", response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.SERVER_ERROR.value)


class NotFoundError(CompresrError):
    """Raised when requested resource is not found."""
    def __init__(self, message: str, resource: str = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.NOT_FOUND.value)
        self.resource = resource


class ConnectionError(CompresrError):
    """Raised when connection to service fails."""
    def __init__(self, message: str, service: str = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.CONNECTION_ERROR.value)
        self.service = service


class InsufficientCreditsError(CompresrError):
    """Raised when user doesn't have enough credits."""
    def __init__(self, message: str = "Insufficient credits", credits_required: float = None, 
                 credits_remaining: float = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.INSUFFICIENT_CREDITS.value)
        self.credits_required = credits_required
        self.credits_remaining = credits_remaining


class BudgetLimitError(CompresrError):
    """Raised when budget limit is reached."""
    def __init__(self, message: str = "Budget limit reached", current_budget: float = None,
                 budget_used: float = None, remaining: float = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.BUDGET_LIMIT_REACHED.value)
        self.current_budget = current_budget
        self.budget_used = budget_used
        self.remaining = remaining


class ApiKeyBudgetError(CompresrError):
    """Raised when API key's budget limit is exceeded."""
    def __init__(self, message: str = "API key budget exceeded", api_key_budget: float = None,
                 api_key_used: float = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.API_KEY_BUDGET_EXCEEDED.value)
        self.api_key_budget = api_key_budget
        self.api_key_used = api_key_used


class DailyLimitError(CompresrError):
    """Raised when daily request limit is exceeded (demo keys)."""
    def __init__(self, message: str = "Daily limit exceeded", daily_limit: int = None,
                 requests_used: int = None, response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.DAILY_LIMIT_EXCEEDED.value)
        self.daily_limit = daily_limit
        self.requests_used = requests_used


class BadRequestException(CompresrError):
    """Raised when request is invalid or malformed."""
    def __init__(self, message: str = "Bad request", response_data: dict = None):
        super().__init__(message, response_data, ErrorCode.VALIDATION_ERROR.value)


class NotFoundException(NotFoundError):
    """Alias for NotFoundError for backward compatibility."""
    pass