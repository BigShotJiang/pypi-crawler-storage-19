"""
Compresr Client Classes

Direct imports of client classes for easy access.
"""

from .services.completion import CompletionClient
from .services.compression import CompressionClient

__all__ = [
    "CompletionClient",
    "CompressionClient",
]