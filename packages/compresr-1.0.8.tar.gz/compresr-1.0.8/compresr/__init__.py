"""
Compresr Python SDK

Compress prompts to reduce LLM costs.

Quick Start:
    # CompletionClient - compress + call LLM with YOUR API key
    from compresr import CompletionClient
    
    client = CompletionClient(
        api_key="cmp_...",           # Your Compresr key
        target_api_key="sk-...",     # Your OpenAI/Anthropic key (REQUIRED)
        default_model="gpt-4o-mini"
    )
    response = client.generate(prompt="Your prompt...")
    print(response.data.target_model_response)
    
    # CompressionClient - compression only
    from compresr import CompressionClient
    
    client = CompressionClient(api_key="cmp_...")
    response = client.generate(prompt="...", target_model="gpt-4o-mini")
    print(response.data.compressed_prompt)
"""

from .clients import CompletionClient, CompressionClient

__version__ = "1.0.3"
__all__ = ["CompletionClient", "CompressionClient"]
