"""
Base Schemas - Common response patterns.

All API responses should extend these base classes.
"""

from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, TypeVar
from datetime import datetime

T = TypeVar("T")

class ClientSchema(BaseModel):
    """Generic client wrapper."""
    name: str
    instance: object
    refresh_interval: int  # in seconds
    
class BaseResponse(BaseModel):
    """Base response with success flag."""
    model_config = ConfigDict(from_attributes=True)
    
    success: bool = True
    message: Optional[str] = None


class MessageResponse(BaseModel):
    """Simple message response."""
    model_config = ConfigDict(from_attributes=True)
    
    success: bool = True
    message: str


class TimestampMixin(BaseModel):
    """Mixin for created/updated timestamps."""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class HealthResponse(BaseModel):
    """Health check response."""
    status: str = Field(..., description="Service status")
    server: str = Field(..., description="Server name")
    