"""
Usage Schemas

Request/Response schemas for usage tracking and analytics.

Used by:
- GET /usage/stats - Comprehensive usage statistics with time series
- GET /usage/balance - Current balance (money-wise)
- GET /usage/summary - Aggregated stats by API key and model
"""

from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List
from .base import BaseResponse


# =============================================================================
# Request Schemas
# =============================================================================

class UsageStatsRequest(BaseModel):
    """Request for usage statistics with filters."""
    model_config = ConfigDict(from_attributes=True)
    
    period: str = Field(default="last_day", description="Time period: last_day, last_week, last_month, last_90_days, last_year, custom")
    start_date: Optional[str] = Field(None, description="Start date for custom period (YYYY-MM-DD)")
    end_date: Optional[str] = Field(None, description="End date for custom period (YYYY-MM-DD)")
    group_by: str = Field(default="day", description="Group by: hour or day")
    api_key_id: Optional[str] = Field(None, description="Filter by specific API key ID")
    model: Optional[str] = Field(None, description="Filter by specific model")


class AggregatedSummaryRequest(BaseModel):
    """Request for aggregated summary."""
    model_config = ConfigDict(from_attributes=True)
    
    period: str = Field(default="last_day", description="Time period: last_day, last_week, last_month, last_90_days, last_year, custom")
    start_date: Optional[str] = Field(None, description="Start date for custom period (YYYY-MM-DD)")
    end_date: Optional[str] = Field(None, description="End date for custom period (YYYY-MM-DD)")


# =============================================================================
# Helper/Item Schemas
# =============================================================================

class TimeSeriesDataPoint(BaseModel):
    """Single data point in time series."""
    model_config = ConfigDict(from_attributes=True)
    
    timestamp: str = Field(..., description="ISO timestamp")
    requests: int = Field(0, description="Number of requests")
    input_tokens: int = Field(0, description="Original input tokens")
    compressed_input_tokens: int = Field(0, description="Compressed input tokens")
    output_tokens: int = Field(0, description="Output tokens")
    cost_usd: float = Field(0.0, description="Cost in USD")
    savings_usd: float = Field(0.0, description="Savings in USD")


class ApiKeyStatsItem(BaseModel):
    """Aggregated stats for a single API key."""
    model_config = ConfigDict(from_attributes=True)
    
    api_key_id: str = Field(..., description="API key ID")
    api_key_name: str = Field(..., description="API key name")
    requests: int = Field(0, description="Number of requests")
    input_tokens: int = Field(0, description="Original input tokens")
    compressed_input_tokens: int = Field(0, description="Compressed input tokens")
    output_tokens: int = Field(0, description="Output tokens")
    cost_usd: float = Field(0.0, description="Cost in USD")


class ModelStatsItem(BaseModel):
    """Aggregated stats for a single model."""
    model_config = ConfigDict(from_attributes=True)
    
    model: str = Field(..., description="Model name")
    requests: int = Field(0, description="Number of requests")
    input_tokens: int = Field(0, description="Original input tokens")
    compressed_input_tokens: int = Field(0, description="Compressed input tokens")
    output_tokens: int = Field(0, description="Output tokens")
    cost_usd: float = Field(0.0, description="Cost in USD")


class ApiKeyUsageSummary(BaseModel):
    """Summary of usage for a single API key (dashboard view)."""
    model_config = ConfigDict(from_attributes=True)
    
    api_key_id: str = Field(..., description="API key UUID")
    api_key_name: str = Field(..., description="API key name")
    requests_this_month: int = Field(0, description="Requests made this month")
    money_used_this_month: float = Field(0.0, description="Money used via this key this month (USD)")
    budget_limit: Optional[float] = Field(None, description="Budget limit for this key (USD)")
    budget_remaining: Optional[float] = Field(None, description="Budget remaining for this key (USD)")


# =============================================================================
# Spending Schemas
# =============================================================================

class SpendingCategory(BaseModel):
    """Spending breakdown by category/request type."""
    model_config = ConfigDict(from_attributes=True)
    
    name: str = Field(..., description="Category name")
    amount: float = Field(..., description="Amount spent in USD")
    percentage: float = Field(..., description="Percentage of total spending")
    requests: int = Field(0, description="Number of requests in this category")


class DailySpending(BaseModel):
    """Daily spending data point."""
    model_config = ConfigDict(from_attributes=True)
    
    date: str = Field(..., description="Date (YYYY-MM-DD)")
    amount: float = Field(..., description="Amount spent in USD")
    requests: int = Field(0, description="Number of requests")


class SpendingResult(BaseModel):
    """Comprehensive spending data for current month."""
    model_config = ConfigDict(from_attributes=True)
    
    # Money balance
    total_uploaded_money: float = Field(0.0, description="Total money uploaded (USD)")
    total_used_money: float = Field(0.0, description="Total money used all time (USD)")
    current_remaining_credits: float = Field(0.0, description="Remaining balance (USD)")
    
    # Monthly budget tracking
    monthly_budget: float = Field(200.0, description="Monthly budget limit (USD)")
    spent_this_month: float = Field(0.0, description="Spent this month (USD)")
    budget_remaining: float = Field(200.0, description="Budget remaining this month (USD)")
    budget_percentage: float = Field(0.0, description="Percentage of monthly budget used")
    
    # Projections
    projected_monthly_spend: float = Field(0.0, description="Projected spend for full month (USD)")
    avg_daily_spend: float = Field(0.0, description="Average daily spend (USD)")
    days_elapsed_this_month: int = Field(0, description="Days elapsed in current month")
    days_remaining_this_month: int = Field(0, description="Days remaining in current month")
    
    # Breakdowns
    categories: List[SpendingCategory] = Field(default_factory=list, description="Spending by category")
    daily_spending: List[DailySpending] = Field(default_factory=list, description="Daily spending history")
    
    # Month info
    current_month: str = Field(..., description="Current month (YYYY-MM)")
    account_created_at: Optional[str] = Field(None, description="Account creation date")


# =============================================================================
# Result Schemas
# =============================================================================

class UsageStatsResult(BaseModel):
    """Comprehensive usage statistics result with time series."""
    model_config = ConfigDict(from_attributes=True)
    
    # Time period context
    period: str = Field(..., description="Time period (last_day, last_week, etc.)")
    period_start: str = Field(..., description="Start of period (ISO)")
    period_end: str = Field(..., description="End of period (ISO)")
    group_by: str = Field(..., description="Grouping: hour or day")
    
    # Time series data
    time_series: List[TimeSeriesDataPoint] = Field(default_factory=list, description="Time series data points")
    
    # Aggregated totals
    total_requests: int = Field(0, description="Total number of requests")
    total_input_tokens: int = Field(0, description="Total original input tokens")
    total_compressed_input_tokens: int = Field(0, description="Total compressed input tokens")
    total_output_tokens: int = Field(0, description="Total output tokens")
    total_cost_usd: float = Field(0.0, description="Total cost in USD")
    total_savings_usd: float = Field(0.0, description="Total savings in USD")
    total_spent_usd: float = Field(0.0, description="Total amount spent in USD")
    
    # Filters applied
    api_key_id: Optional[str] = Field(None, description="Filtered by API key ID")
    model: Optional[str] = Field(None, description="Filtered by model")


class MoneyBalanceResult(BaseModel):
    """Current balance in monetary terms - money-based system."""
    model_config = ConfigDict(from_attributes=True)
    
    # Money Tracking (replaces credits)
    total_uploaded_money: float = Field(0.0, description="Total money uploaded to account (USD)")
    total_used_money: float = Field(0.0, description="Total money consumed via API usage (USD)")
    current_remaining_credits: float = Field(0.0, description="Remaining balance (USD)")
    percentage_used: float = Field(0.0, description="Percentage of uploaded money used")
    
    # Budget Management
    monthly_budget: float = Field(200.0, description="User's monthly budget limit (USD)")
    budget_used_this_month: float = Field(0.0, description="Money used this month (USD)")
    budget_remaining_this_month: float = Field(200.0, description="Budget remaining this month (USD)")
    
    # Account info
    tier: str = Field(default="free", description="Current subscription tier")
    is_admin: bool = Field(False, description="Whether user is admin (infinite usage)")
    account_created_at: Optional[str] = Field(None, description="Account creation date (ISO)")


class AggregatedSummaryResult(BaseModel):
    """Aggregated usage summary (not time series)."""
    model_config = ConfigDict(from_attributes=True)
    
    # Overall totals
    total_requests: int = Field(0, description="Total number of requests")
    total_input_tokens: int = Field(0, description="Total original input tokens")
    total_compressed_input_tokens: int = Field(0, description="Total compressed input tokens")
    total_output_tokens: int = Field(0, description="Total output tokens")
    total_cost_usd: float = Field(0.0, description="Total cost in USD")
    total_savings_usd: float = Field(0.0, description="Total savings in USD")
    
    # Breakdown by API key
    by_api_key: List[ApiKeyStatsItem] = Field(default_factory=list, description="Stats per API key")
    
    # Breakdown by model
    by_model: List[ModelStatsItem] = Field(default_factory=list, description="Stats per model")


class DashboardStats(BaseModel):
    """Comprehensive dashboard statistics - money-based system."""
    model_config = ConfigDict(from_attributes=True)
    
    # Money Tracking (replaces credits)
    total_uploaded_money: float = Field(0.0, description="Total money uploaded to account (USD)")
    total_used_money: float = Field(0.0, description="Total money consumed via API usage (USD)")
    credits_remaining: float = Field(0.0, description="Remaining balance (USD)")
    usage_percentage: float = Field(0.0, description="Percentage of uploaded money used")
    
    # Budget Management
    monthly_budget: Optional[float] = Field(None, description="User's monthly budget limit (USD, None for admin/unlimited)")
    budget_used_this_month: float = Field(0.0, description="Money used this month (USD)")
    budget_remaining_this_month: Optional[float] = Field(None, description="Budget remaining this month (USD, None for unlimited)")
    budget_percentage: float = Field(0.0, description="Percentage of monthly budget used")
    spend_this_month: float = Field(0.0, description="Total money spent this month (USD)")
    
    # API Usage Stats
    total_api_calls: int = Field(0, description="Total API calls (all time)")
    api_calls_this_month: int = Field(0, description="API calls in current month")
    active_api_keys: int = Field(0, description="Number of active API keys")
    
    # Time Tracking
    days_until_month_reset: int = Field(0, description="Days until current month ends")
    current_month: str = Field("", description="Current month (YYYY-MM format)")
    
    # Compression Performance
    avg_compression_ratio: float = Field(0.0, description="Average compression ratio (last 30 days)")
    total_tokens_saved: int = Field(0, description="Total tokens saved (all time)")
    tokens_saved_this_month: int = Field(0, description="Tokens saved this month")
    
    # Account Information
    tier: str = Field("free", description="Current subscription tier")
    is_admin: bool = Field(False, description="Whether user is admin (infinite usage)")
    account_created_at: Optional[str] = Field(None, description="Account creation date")
    
    # Per API Key Usage (for detailed breakdown)
    api_key_usage: List[ApiKeyUsageSummary] = Field(
        default_factory=list, 
        description="Usage breakdown per API key"
    )


# =============================================================================
# Response Schemas
# =============================================================================

class UsageStatsResponse(BaseResponse):
    """Response for usage statistics."""
    result: Optional[UsageStatsResult] = None


class MoneyBalanceResponse(BaseResponse):
    """Response for money balance."""
    result: Optional[MoneyBalanceResult] = None


class AggregatedSummaryResponse(BaseResponse):
    """Response for aggregated summary."""
    result: Optional[AggregatedSummaryResult] = None


class SpendingResponse(BaseResponse):
    """Response for spending data."""
    data: Optional[SpendingResult] = None


class DashboardStatsResponse(BaseResponse):
    """Response for dashboard statistics."""
    data: Optional[DashboardStats] = None
