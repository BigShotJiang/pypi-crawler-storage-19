"""
Inference Schemas

Generic, reusable schemas for all inference endpoints (compression + completion).

Architecture:
- Base classes define common fields
- Specific classes inherit and extend as needed
- DRY principle: No duplication

Schema Types:
1. Request - Input data
2. Result - Output data
3. Response - API response wrapper

Terminology:
- Context: The text that gets compressed (documents, background info, etc.)
- Prompt: The user's actual question/instruction (used in completion endpoints)
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
# CompressionConfig constants (copied from backend)
class CompressionConfig:
    MIN_RATIO = 0.1  # Remove minimum 10%, keep maximum 90%
    MAX_RATIO = 0.9  # Remove maximum 90%, keep minimum 10%
    DEFAULT_RATIO = 0.5  # Remove 50%, keep 50% - Default balanced compression
from .base import BaseResponse


# =============================================================================
# Streaming Schemas
# =============================================================================

class StreamChunk(BaseModel):
    """A chunk of streamed response."""
    content: str
    done: bool = False
    error: Optional[str] = None


# =============================================================================
# Compression Request Schemas (compress context only, no LLM)
# =============================================================================

class CompressRequest(BaseModel):
    """Request to compress context only (no LLM call)."""
    context: str = Field(..., min_length=1, description="Context text to compress.")
    compression_model_name: str = Field(
        ...,
        description="Compression model to use (e.g., 'cmprsr_v1') - REQUIRED"
    )
    target_compression_ratio: Optional[float] = Field(
        None, 
        ge=CompressionConfig.MIN_RATIO, 
        le=CompressionConfig.MAX_RATIO, 
        description=f"Target compression ratio {CompressionConfig.MIN_RATIO}-{CompressionConfig.MAX_RATIO} (optional)"
    )


class BatchCompressRequest(BaseModel):
    """Request to compress multiple contexts (no LLM call)."""
    contexts: List[str] = Field(..., min_length=1, max_length=100, description="List of context texts to compress")
    compression_model_name: str = Field(
        ...,
        description="Compression model to use (e.g., 'cmprsr_v1') - REQUIRED"
    )
    target_compression_ratio: Optional[float] = Field(
        None, 
        ge=CompressionConfig.MIN_RATIO, 
        le=CompressionConfig.MAX_RATIO, 
        description=f"Target compression ratio {CompressionConfig.MIN_RATIO}-{CompressionConfig.MAX_RATIO} (optional)"
    )


# =============================================================================
# Completion Request Schemas (compress context + combine with prompt + LLM call)
# =============================================================================

class CompletionRequest(BaseModel):
    """Request to compress context, combine with prompt, and call target model."""
    prompt: str = Field(..., min_length=1, description="User's question or instruction")
    context: str = Field(..., min_length=1, description="Context text to compress.")
    compression_model_name: str = Field(
        ...,
        description="Compression model to use (e.g., 'cmprsr_v1') - REQUIRED"
    )
    target_compression_ratio: Optional[float] = Field(
        None, 
        ge=CompressionConfig.MIN_RATIO, 
        le=CompressionConfig.MAX_RATIO, 
        description=f"Target compression ratio {CompressionConfig.MIN_RATIO}-{CompressionConfig.MAX_RATIO} (optional)"
    )
    target_api_key: str = Field(..., min_length=1, description="User's API key for the target model provider (required)")
    target_model: str = Field(..., description="Target LLM model (required) - e.g., gpt-4o, gpt-4o-mini, claude-3-sonnet")


class BatchCompletionRequest(BaseModel):
    """Request to compress multiple contexts, combine with prompts, and call target model."""
    prompts: List[str] = Field(..., min_length=1, max_length=100, description="List of user questions/instructions")
    contexts: List[str] = Field(..., min_length=1, max_length=100, description="List of context texts to compress (must match prompts length)")
    compression_model_name: str = Field(
        ...,
        description="Compression model to use (e.g., 'cmprsr_v1') - REQUIRED"
    )
    target_compression_ratio: Optional[float] = Field(
        None, 
        ge=CompressionConfig.MIN_RATIO, 
        le=CompressionConfig.MAX_RATIO, 
        description=f"Target compression ratio {CompressionConfig.MIN_RATIO}-{CompressionConfig.MAX_RATIO} (optional)"
    )
    target_api_key: str = Field(..., min_length=1, description="User's API key for the target model provider (required)")
    target_model: str = Field(..., description="Target LLM model (required)")


# =============================================================================
# Base Result Schemas (Common Output Fields)
# =============================================================================

class BaseCompressionResult(BaseModel):
    """Base result with common compression output fields."""
    original_context: str = Field(..., description="Original input context")
    original_tokens: int = Field(..., description="Token count of original context")
    compressed_tokens: int = Field(..., description="Token count after compression")
    target_compression_ratio: Optional[float] = Field(None, description="User-requested compression ratio (if provided)")
    actual_compression_ratio: float = Field(..., description="Actual achieved compression ratio (0-1)")
    tokens_saved: int = Field(..., description="Number of tokens saved")
    duration_ms: int = Field(..., description="Processing time in milliseconds")

    model_config = {
        'from_attributes': True,
        'protected_namespaces': (),
    }


class BaseBatchResult(BaseModel):
    """Base batch result with aggregated metrics."""
    total_original_tokens: int = 0
    total_compressed_tokens: int = 0
    total_tokens_saved: int = 0
    average_compression_ratio: float = 0.0
    count: int = 0


# =============================================================================
# Compression Result Schemas (compression only, no LLM)
# =============================================================================

class CompressResult(BaseCompressionResult):
    """Compression result - metrics and compressed context."""
    compressed_context: str = Field(..., description="Compressed context")


class BatchCompressResult(BaseBatchResult):
    """Results for batch compression."""
    results: List[CompressResult] = []


# =============================================================================
# Completion Result Schemas (compression + LLM)
# =============================================================================

class CompletionResult(BaseCompressionResult):
    """
    Completion result - compression metrics and target model response.
    
    Public response (compressed_context is NOT included for non-admin users).
    """
    prompt: str = Field(..., description="User's original question/instruction")
    target_model: str = Field(..., description="Target model used")
    target_model_response: str = Field(..., description="Response content from target model")
    target_model_usage: Dict[str, Any] = Field(..., description="Token usage from target model (prompt_tokens, completion_tokens, total_tokens)")
    cost_usd: Optional[float] = Field(None, description="Cost in USD")


class AdminCompletionResult(CompletionResult):
    """
    Admin completion result - includes compressed context.
    
    Only returned to admin users. Contains the actual compressed context
    which is proprietary and should not be exposed to regular users.
    """
    compressed_context: str = Field(..., description="Compressed context (admin only)")


class BatchCompletionResult(BaseBatchResult):
    """Results for batch completion."""
    results: List[CompletionResult] = []
    total_cost_usd: Optional[float] = None


class AdminBatchCompletionResult(BaseBatchResult):
    """Admin results for batch completion (includes compressed texts)."""
    results: List[AdminCompletionResult] = []
    total_cost_usd: Optional[float] = None


# =============================================================================
# Response Schemas - Compression Only
# =============================================================================

class CompressResponse(BaseResponse):
    """Response for single compression."""
    data: Optional[CompressResult] = None


class BatchCompressResponse(BaseResponse):
    """Response for batch compression."""
    data: Optional[BatchCompressResult] = None


# =============================================================================
# Response Schemas - Completion
# =============================================================================

class CompletionResponse(BaseResponse):
    """Response for single completion."""
    data: Optional[CompletionResult] = None


class AdminCompletionResponse(BaseResponse):
    """Admin response for single completion (includes compressed text)."""
    data: Optional[AdminCompletionResult] = None


class BatchCompletionResponse(BaseResponse):
    """Response for batch completion."""
    data: Optional[BatchCompletionResult] = None


class AdminBatchCompletionResponse(BaseResponse):
    """Admin response for batch completion."""
    data: Optional[AdminBatchCompletionResult] = None


# =============================================================================
# Demo Data Schemas
# =============================================================================

class SampleText(BaseModel):
    """Sample text for demo interface."""
    name: str
    text: str


class ModelInfo(BaseModel):
    """Model info for demo interface."""
    value: str
    label: str
    provider: str


class DemoData(BaseModel):
    """Demo data container with samples and models."""
    sample_texts: List[SampleText]
    available_models: List[ModelInfo]


class DemoDataResponse(BaseResponse):
    """Response for demo data endpoint."""
    data: DemoData
