from multimodal_communication.s3_helper.s3_functions import S3CloudHelper
import polars as pl

df = pl.DataFrame({'a':[1,2,3], 'b':[3,4,5]})

helper = S3CloudHelper(obj=df)

helper.update_and_archive_table(bucket_name='test', table_name='test_table', file_name='test_file',
                                upsert=True, dedup_columns=['test_col_1'], file_type='parquet')