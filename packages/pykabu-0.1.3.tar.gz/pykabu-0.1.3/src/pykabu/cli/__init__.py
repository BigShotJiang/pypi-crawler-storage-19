"""CLI module for pykabu"""
