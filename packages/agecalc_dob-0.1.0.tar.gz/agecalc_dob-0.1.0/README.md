# agecalc_dob

A powerful yet simple Python library to calculate age, zodiac signs, next birthday info, and more from a DOB string.

## Installation

```bash
pip install agecalc_dob
```

## Quick Start

```python
from agecalc import Age, ac

# 1. Simple alias
print(ac("2000-01-01")) # Returns age in years

# 2. Advanced fluent API
me = Age("2000-01-01")
print(me.years)           # 26
print(me.days)            # 9504
print(me.zodiac)          # Capricorn
print(me.readable)        # "26 years, 0 months..."
print(me.category)        # "Adult"
print(me.next_birthday_days) # Days left
```

## Features

- **Flexible Parsing**: Handles `YYYY-MM-DD`, `YYYY.MM.DD`, `YYYY/MM/DD`.
- **Zodiac Identification**: Get star signs automatically.
- **Birthday Info**: Countdown and weekday for your next birthday.
- **Units**: Age in days, weeks, and months.
- **Comparison**: Compare two people's ages easily.
- **Classification**: Child, Teen, Adult, etc.
- **Multi-Cultural**: Basic Hijri age approximation.

## License
MIT
