from setuptools import setup, find_packages

setup(
    name="agecalc_dob",          # Package name on PyPI
    version="0.1.0",         # Start small
    packages=find_packages(),
    install_requires=[],     # Dependencies (none if pure Python)
    python_requires=">=3.6",
    author="Adnan Hussain",
    author_email="adnan@example.com",
    description="A powerful age calculator library",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/agecalc",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
