"""Claude Code Tools - Collection of utilities for Claude Code."""

__version__ = "1.4.8"