"""Chrome cookie decryption utilities for Mac."""

import browser_cookie3
from typing import Dict


def grab_chrome_cookies(domain: str) -> Dict[str, str]:
    """Grab cookies from Chrome for a specific domain.
    
    Args:
        domain: The domain to get cookies for
        
    Returns:
        Dictionary of cookie name-value pairs
        
    Raises:
        RuntimeError: If unable to access Chrome cookies
    """
    try:
        # Normalize domain (remove protocol)
        domain_normalized = domain.strip().lower()
        domain_normalized = domain_normalized.replace('https://', '').replace('http://', '').split('/')[0]
        
        # Use browser-cookie3 to get cookies from Chrome
        cj = browser_cookie3.chrome(domain_name=domain_normalized)
        
        # Convert CookieJar to dictionary format
        cookies = {}
        for cookie in cj:
            cookies[cookie.name] = cookie.value
        
        return cookies
    except Exception as e:
        raise RuntimeError(f"Failed to get cookies from Chrome: {e}")
