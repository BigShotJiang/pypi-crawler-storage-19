"""Base64 encoding/decoding utilities for file operations."""

import base64
import mimetypes
import re
import tempfile
from pathlib import Path
from typing import Any, Callable, Optional, Union

from synapse_sdk.utils.string import hash_text


def decode_base64(data: str) -> tuple[bytes, str]:
    """Decode base64-encoded data and extract MIME type.

    This function performs pure base64 decoding without file I/O operations.
    It handles both data URI format and raw base64 strings.

    Args:
        data (str): Base64-encoded data to decode.
            - Data URI (e.g., "data:image/png;base64,iVBORw0KG..."): Extracts MIME type
            - Raw base64 string (e.g., "SGVsbG8gV29ybGQh"): No MIME type

    Returns:
        tuple[bytes, str]: A tuple of (decoded_bytes, file_extension)
            - decoded_bytes: The decoded binary data
            - file_extension: File extension inferred from MIME type (e.g., '.png', '.bin')

    Raises:
        base64.binascii.Error: If base64 data is invalid.

    Examples:
        Decode data URI with MIME type:
        >>> content, ext = decode_base64('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUA...')
        >>> print(ext)  # '.png'
        >>> print(type(content))  # <class 'bytes'>

        Decode raw base64 string:
        >>> content, ext = decode_base64('SGVsbG8gV29ybGQh')  # "Hello World!" in base64
        >>> print(ext)  # '.bin'
        >>> print(content.decode())  # 'Hello World!'

    Note:
        - MIME type is extracted from data URI format (data:type;base64,...)
        - Raw base64 strings default to .bin extension
        - This function does not perform file I/O operations
    """
    mime_type = None
    base64_data = None

    # Check for data URI scheme (e.g., "data:image/png;base64,...")
    data_uri_match = re.match(r'^data:([^;]+);base64,(.+)$', data)
    if data_uri_match:
        mime_type = data_uri_match.group(1)
        base64_data = data_uri_match.group(2)
    else:
        # Treat as raw base64 string
        base64_data = data

    # Decode base64 data
    decoded_bytes = base64.b64decode(base64_data)

    # Determine file extension from mime type or default to .bin
    if mime_type:
        ext = mimetypes.guess_extension(mime_type) or '.bin'
    else:
        ext = '.bin'

    return decoded_bytes, ext


def base64_to_bytes(data: str) -> bytes:
    """Convert base64-encoded data to bytes without saving to file.

    This is a convenience function that extracts only the decoded bytes
    from decode_base64(). Use this when you only need the binary content
    and don't care about the file extension.

    Args:
        data (str): Base64-encoded data (data URI or raw base64 string).

    Returns:
        bytes: Decoded binary data.

    Raises:
        base64.binascii.Error: If base64 data is invalid.

    Examples:
        Decode data URI to bytes:
        >>> data_uri = 'data:text/plain;base64,SGVsbG8gV29ybGQh'
        >>> content = base64_to_bytes(data_uri)
        >>> print(content.decode())  # 'Hello World!'

        Decode raw base64 to bytes:
        >>> base64_str = 'SGVsbG8gV29ybGQh'
        >>> content = base64_to_bytes(base64_str)
        >>> print(content.decode())  # 'Hello World!'

        Use in memory without file I/O:
        >>> image_data = base64_to_bytes('data:image/jpeg;base64,/9j/4AA...')
        >>> # Process image_data in memory
    """
    decoded_bytes, _ = decode_base64(data)
    return decoded_bytes


def base64_to_file(
    data: str,
    download_path: Optional[Union[str, Path]] = None,
    name: Optional[str] = None,
    coerce: Optional[Callable[[Path], Any]] = None,
    use_cached: bool = True,
) -> Union[Path, Any]:
    """Convert base64-encoded data to a file.

    This function decodes base64 data (either as a data URI or raw base64 string)
    and saves it as a file. Supports caching, custom naming, and optional path transformation.

    Args:
        data (str): Base64-encoded data to convert to a file.
            - Data URI (e.g., "data:image/png;base64,iVBORw0KG..."): Extracts MIME type and decodes
            - Raw base64 string (e.g., "SGVsbG8gV29ybGQh"): Decodes with default .bin extension
        download_path (str | Path, optional): Directory path where the file will be saved.
            If None, uses system temporary directory.
        name (str, optional): Custom filename (without extension).
            If provided, caching is disabled. If None, a hash of the data is used as the name.
        coerce (callable, optional): A function to transform the file path.
            Called with the Path object after file creation.
            Example: lambda p: str(p) to convert Path to string
        use_cached (bool): If True (default), skip conversion if file already exists.
            Automatically set to False when a custom name is provided.

    Returns:
        Path | Any: Path object pointing to the created file, or the result of
            coerce(path) if a coerce function was provided.

    Raises:
        base64.binascii.Error: If base64 data is invalid.
        IOError: If file write fails due to permissions or disk space.

    Examples:
        Convert data URI with MIME type:
        >>> data_uri = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUA...'
        >>> path = base64_to_file(data_uri, '/tmp/uploads')
        >>> print(path)  # /tmp/uploads/abc123def456.png (extension from MIME type)

        Convert to temp directory (download_path omitted):
        >>> path = base64_to_file('data:image/jpeg;base64,/9j/4AA...')
        >>> print(path.parent)  # PosixPath('/tmp') or similar

        Convert raw base64 string:
        >>> base64_str = 'SGVsbG8gV29ybGQh'  # "Hello World!" in base64
        >>> path = base64_to_file(base64_str, '/tmp/uploads')
        >>> print(path)  # /tmp/uploads/abc123def456.bin (default extension)

        Custom filename without caching:
        >>> path = base64_to_file(
        ...     'iVBORw0KGgoAAAANS...',
        ...     '/tmp/uploads',
        ...     name='user_upload'
        ... )
        >>> print(path)  # /tmp/uploads/user_upload.bin

        With path coercion to string:
        >>> path_str = base64_to_file(
        ...     'data:text/plain;base64,SGVsbG8=',
        ...     '/tmp',
        ...     coerce=str
        ... )
        >>> print(type(path_str))  # <class 'str'>

    Note:
        - MIME type is extracted from data URI format
        - Raw base64 strings default to .bin extension
        - File content is cached using hash-based filenames when use_cached=True
        - Existing files are reused when use_cached=True
        - If download_path is None, files are saved to system temp directory
    """
    # Use temp directory if download_path is not specified
    if download_path is None:
        download_path = tempfile.gettempdir()

    # Use the new decode_base64 function
    decoded_bytes, ext = decode_base64(data)

    if name:
        use_cached = False
    else:
        # Hash the base64 data part (without data URI prefix if present)
        data_uri_match = re.match(r'^data:[^;]+;base64,(.+)$', data)
        base64_data = data_uri_match.group(1) if data_uri_match else data
        name = hash_text(base64_data)

    name += ext
    path = Path(download_path) / name

    if not use_cached or not path.is_file():
        path.write_bytes(decoded_bytes)

    if coerce:
        path = coerce(path)

    return path


async def abase64_to_file(
    data: str,
    download_path: Optional[Union[str, Path]] = None,
    name: Optional[str] = None,
    coerce: Optional[Callable[[Path], Any]] = None,
    use_cached: bool = True,
) -> Union[Path, Any]:
    """Asynchronously convert base64-encoded data to a file.

    Async version of base64_to_file(). Since base64 decoding is a fast CPU operation,
    this function performs the same synchronous decoding but is async-compatible
    for use in async contexts alongside adownload_file().

    Args:
        data (str): Base64-encoded data to convert to a file.
            - Data URI (e.g., "data:image/png;base64,..."): Extracts MIME type and decodes
            - Raw base64 string: Decodes with default .bin extension
        download_path (str | Path, optional): Directory path where the file will be saved.
            If None, uses system temporary directory.
        name (str, optional): Custom filename (without extension).
        coerce (callable, optional): Function to transform the file path.
        use_cached (bool): If True (default), skip conversion if file exists.

    Returns:
        Path | Any: Path to created file, or coerce(path) if provided.

    Examples:
        Convert data URI:
        >>> path = await abase64_to_file('data:image/jpeg;base64,/9j/...', '/tmp')

        Convert to temp directory:
        >>> path = await abase64_to_file('data:image/jpeg;base64,/9j/...')

        Multiple concurrent conversions:
        >>> data_list = ['SGVsbG8=', 'V29ybGQh', 'Rm9vIQ==']
        >>> paths = await asyncio.gather(*[
        ...     abase64_to_file(d, '/tmp') for d in data_list
        ... ])

    Note:
        - Base64 decoding is synchronous (fast CPU operation)
        - Async wrapper for compatibility with adownload_file()
    """
    # Delegate to synchronous version since base64 decoding is fast
    return base64_to_file(data, download_path, name=name, coerce=coerce, use_cached=use_cached)


def is_base64_data(data: str) -> bool:
    """Check if a string is base64-encoded data (data URI or raw base64).

    Args:
        data (str): String to check.

    Returns:
        bool: True if data is base64-encoded, False if it's a URL.

    Examples:
        >>> is_base64_data('data:image/png;base64,iVBORw0...')
        True
        >>> is_base64_data('https://example.com/image.jpg')
        False
        >>> is_base64_data('SGVsbG8gV29ybGQh')  # "Hello World!" in base64
        True
    """
    # Check for data URI scheme - this is the most reliable indicator
    if data.startswith('data:'):
        return True

    # If it starts with common URL schemes, it's definitely a URL
    if data.startswith(('http://', 'https://', 'ftp://', 'file://')):
        return False

    # Check if string contains only valid base64 characters
    # Base64 uses: A-Z, a-z, 0-9, +, /, and = for padding
    base64_pattern = re.compile(r'^[A-Za-z0-9+/]*={0,2}$')
    if not base64_pattern.match(data):
        return False

    # Try to validate as base64
    try:
        decoded = base64.b64decode(data, validate=True)
        # Additional check: decoded data should have reasonable size
        # (at least a few bytes for actual file content)
        return len(decoded) > 0
    except Exception:
        return False
