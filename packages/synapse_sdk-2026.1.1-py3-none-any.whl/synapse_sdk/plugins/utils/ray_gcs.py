"""Utilities for converting HTTP URLs to Ray GCS URLs."""

import tempfile
from pathlib import Path

from synapse_sdk.utils.file.base64 import base64_to_file, is_base64_data
from synapse_sdk.utils.file.download import download_file


def convert_http_to_ray_gcs(file_source: str) -> str:
    """Convert HTTP URL or base64 data to Ray GCS URL by downloading/converting and uploading to Ray's GCS.

    Ray's working_dir only accepts certain protocols (gcs://, s3://, gs://, https://).
    When SYNAPSE_PLUGIN_STORAGE is an HTTP URL (Django media server) or base64-encoded data,
    this function converts it to a Ray-compatible gcs:// URL by:
    1. Downloading the file from HTTP or converting base64 data to a file
    2. Uploading it to Ray's Global Control Store (GCS)
    3. Returning the content-addressable gcs:// URI

    Args:
        file_source: HTTP/HTTPS URL to plugin zip file or base64-encoded data
            (data URI format like "data:application/zip;base64,..." or raw base64 string)

    Returns:
        gcs:// URL that Ray can use for working_dir
        Example: "gcs://_ray_pkg_abc123def456.zip"

    Raises:
        RuntimeError: If Ray is not initialized or not installed
        requests.exceptions.RequestException: If HTTP download fails
        base64.binascii.Error: If base64 data is invalid

    Note:
        - Ray must be initialized (ray.init()) before calling this function
        - The gcs:// URI is content-addressable (same file = same URI)
        - Ray automatically deduplicates uploads via package_exists()
        - Supports both HTTP URLs and base64-encoded file data
    """
    try:
        import ray
    except ImportError:
        raise RuntimeError(
            'Ray is not installed but is required for HTTP → GCS conversion. Install ray with: pip install ray'
        )

    if not ray.is_initialized():
        raise RuntimeError(
            'Ray must be initialized before converting HTTP URLs to GCS. '
            'Call ray.init() before submitting jobs with HTTP storage.'
        )

    from ray._private.runtime_env.packaging import (
        get_uri_for_package,
        package_exists,
        upload_package_to_gcs,
    )

    # Download HTTP file or convert base64 to temporary location
    with tempfile.TemporaryDirectory() as temp_dir:
        if is_base64_data(file_source):
            # If data is base64-encoded, convert it to file
            local_path = base64_to_file(file_source, temp_dir)
        else:
            # If data is URL, download it
            local_path = Path(download_file(file_source, temp_dir))

        # Generate content-addressable gcs:// URI based on file content
        gcs_uri = get_uri_for_package(local_path)

        # Check if already exists in Ray GCS (deduplication)
        if not package_exists(gcs_uri):
            # Upload to Ray's Global Control Store
            upload_package_to_gcs(gcs_uri, local_path.read_bytes())

        return gcs_uri
