"""Custom resources for CMDOP LLM service."""

from .ocr import AsyncOCR, OCR
from .vision import AsyncVision, Vision

__all__ = [
    "Vision",
    "AsyncVision",
    "OCR",
    "AsyncOCR",
]
