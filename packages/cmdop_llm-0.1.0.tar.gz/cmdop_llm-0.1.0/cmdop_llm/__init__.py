"""CMDOP LLM Python SDK.

A drop-in replacement for OpenAI Python SDK that connects to llm.cmdop.com.
Provides access to 200+ AI models via OpenRouter, plus custom vision/OCR endpoints.

Example:
    ```python
    from cmdop_llm import CmdopLLM

    client = CmdopLLM(api_key="your-api-key")

    # Chat completion (same as OpenAI)
    response = client.chat.completions.create(
        model="anthropic/claude-3.5-sonnet",
        messages=[{"role": "user", "content": "Hello!"}]
    )

    # Vision analysis (CMDOP-specific)
    result = client.vision.analyze(image_url="https://...")

    # OCR (CMDOP-specific)
    result = client.ocr.extract(image_url="https://...")
    ```
"""

from openai import (
    APIConnectionError,
    APIError,
    APIStatusError,
    APITimeoutError,
    AsyncStream,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    NotFoundError,
    OpenAIError,
    PermissionDeniedError,
    RateLimitError,
    Stream,
    UnprocessableEntityError,
)
from openai._types import NOT_GIVEN, NotGiven

from ._client import AsyncClient, AsyncCmdopLLM, Client, CmdopLLM
from ._version import __author__, __email__, __title__, __version__
from .resources import AsyncOCR, AsyncVision, OCR, Vision
from .types import OCRRequest, OCRResponse, VisionAnalyzeRequest, VisionAnalyzeResponse

__all__ = [
    # Version info
    "__version__",
    "__title__",
    "__author__",
    "__email__",
    # Main clients
    "CmdopLLM",
    "AsyncCmdopLLM",
    "Client",
    "AsyncClient",
    # Custom resources
    "Vision",
    "AsyncVision",
    "OCR",
    "AsyncOCR",
    # Custom types
    "VisionAnalyzeRequest",
    "VisionAnalyzeResponse",
    "OCRRequest",
    "OCRResponse",
    # Re-exported from OpenAI
    "OpenAIError",
    "APIError",
    "APIStatusError",
    "APIConnectionError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "UnprocessableEntityError",
    "InternalServerError",
    "Stream",
    "AsyncStream",
    "NOT_GIVEN",
    "NotGiven",
]
