"""Type definitions for cmdop-llm custom endpoints."""

from .ocr import OCRRequest, OCRResponse
from .vision import VisionAnalyzeRequest, VisionAnalyzeResponse

__all__ = [
    "VisionAnalyzeRequest",
    "VisionAnalyzeResponse",
    "OCRRequest",
    "OCRResponse",
]
