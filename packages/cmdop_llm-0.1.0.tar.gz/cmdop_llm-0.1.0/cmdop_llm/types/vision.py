"""Type definitions for vision analysis endpoint."""

from typing import Literal, Optional

from pydantic import BaseModel, model_validator


class VisionAnalyzeRequest(BaseModel):
    """Request for vision analysis."""

    image: Optional[str] = None
    """Base64-encoded image data."""

    image_url: Optional[str] = None
    """URL of the image to analyze."""

    prompt: Optional[str] = None
    """Custom prompt for the analysis."""

    model: Optional[str] = None
    """Model to use for analysis. Defaults to server default."""

    ocr_mode: Literal["tiny", "small", "base", "gundam"] = "base"
    """OCR mode for text extraction quality."""

    fetch_image: bool = True
    """Whether to fetch image from URL on server side."""

    @model_validator(mode="after")
    def validate_image_source(self) -> "VisionAnalyzeRequest":
        """Ensure at least one image source is provided."""
        if not self.image and not self.image_url:
            raise ValueError("Either 'image' or 'image_url' must be provided")
        return self


class VisionAnalyzeResponse(BaseModel):
    """Response from vision analysis."""

    extracted_text: str
    """Text extracted from the image."""

    description: str
    """Description of the image content."""

    language: Optional[str] = None
    """Detected language of the text."""

    model: str
    """Model used for analysis."""

    cost_usd: float
    """Cost of the request in USD."""

    tokens_input: int
    """Number of input tokens used."""

    tokens_output: int
    """Number of output tokens generated."""
