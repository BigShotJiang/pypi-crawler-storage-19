"""Version information for cmdop-llm package."""

__version__ = "0.1.0"
__title__ = "cmdop-llm"
__author__ = "CMDOP Team"
__email__ = "support@cmdop.com"
