from typing import Union, List, Tuple, Optional
import leangeo, json

class LeanGeoEngine:
    """
    A Python wrapper for the Rust-based LeanGeo geospatial database.
    
    This wrapper ensures compatibility with raw JSON strings (as used in the provided
    test suite) while offering convenience methods for Python dictionaries and 
    scalar coordinate arguments.
    """

    def __init__(self, storage_path: str):
        """
        Initialize the LeanGeo database engine.
        
        Args:
            storage_path (str): Path to the directory where data will be stored.
        """
        self._inner = leangeo.LeanGeo(storage_path)
        self.base_path = storage_path

    def _ensure_json_string(self, data: Union[str, dict, None]) -> Optional[str]:
        """Helper to convert dict to JSON string if necessary."""
        if data is None:
            return None
        if isinstance(data, dict):
            return json.dumps(data)
        return data

    def add(self, id: str, lat: float, lon: float, metadata: Union[str, dict]) -> None:
        """
        Add a point to the index.
        
        Args:
            id (str): Unique identifier.
            lat (float): Latitude.
            lon (float): Longitude.
            metadata (str | dict): JSON string or Python dictionary.
        """
        meta_str = self._ensure_json_string(metadata)
        # Rust signature: add(id, lat, lon, metadata_string)
        self._inner.add(id, float(lat), float(lon), meta_str)

    def persist(self) -> None:
        """Persist the Write-Ahead Log (WAL) to the main snapshot files."""
        self._inner.persist()

    def count(self) -> int:
        """Return the number of valid items in the index."""
        return self._inner.count()

    def delete(self, id: str) -> None:
        """Mark an ID as deleted."""
        self._inner.delete(id)

    def delete_by_filter(self, filter_json: Union[str, dict]) -> int:
        """
        Delete items matching a specific JSON filter criteria.
        
        Returns:
            int: Number of items deleted.
        """
        f_str = self._ensure_json_string(filter_json)
        return self._inner.delete_by_filter(f_str)

    def vacuum(self) -> None:
        """
        Reclaim space from deleted items and compact the storage files.
        """
        self._inner.vacuum()

    def search_knn(
        self, 
        lat: float, 
        lon: float, 
        k: int, 
        filter_json: Union[str, dict, None] = None
    ) -> List[Tuple[str, float, str]]:
        """
        Search for the K nearest neighbors.

        Args:
            lat (float): Latitude.
            lon (float): Longitude.
            k (int): Number of results.
            filter_json (str | dict | None): Optional JSON filter.

        Returns:
            List of tuples: (id, distance_in_meters, metadata_json_string)
        """
        f_str = self._ensure_json_string(filter_json)
        return self._inner.search_knn(float(lat), float(lon), int(k), f_str)

    def search_radius(
        self, 
        lat: float, 
        lon: float, 
        radius_m: float, 
        filter_json: Union[str, dict, None] = None
    ) -> List[Tuple[str, float, str]]:
        """
        Search for points within a specific radius.

        Args:
            lat (float): Latitude.
            lon (float): Longitude.
            radius_m (float): Radius in meters.
            filter_json (str | dict | None): Optional JSON filter.

        Returns:
            List of tuples: (id, distance_in_meters, metadata_json_string)
        """
        f_str = self._ensure_json_string(filter_json)
        return self._inner.search_radius(float(lat), float(lon), float(radius_m), f_str)

    def search_box(
        self, 
        top_left: Tuple[float, float], 
        bottom_right: Tuple[float, float], 
        filter_json: Union[str, dict, None] = None
    ) -> List[Tuple[str, str]]:
        """
        Search for points within a bounding box (Raw Rust API style).
        
        Args:
            top_left (tuple): (lat, lon) of the North-West corner.
            bottom_right (tuple): (lat, lon) of the South-East corner.
            filter_json (str | dict | None): Optional JSON filter.
        
        Returns:
            List of tuples: (id, metadata_json_string)
        """
        f_str = self._ensure_json_string(filter_json)
        return self._inner.search_box(top_left, bottom_right, f_str)

    def search_bbox(
        self, 
        min_lat: float, 
        max_lat: float, 
        min_lon: float, 
        max_lon: float, 
        filter_json: Union[str, dict, None] = None
    ) -> List[str]:
        """
        Convenience method for Bounding Box search using scalars (sample.py style).
        
        Args:
            min_lat, max_lat, min_lon, max_lon: Coordinates.

        Returns:
            List of IDs found in the box.
        """
        # Convert scalar bounds to TopLeft/BottomRight tuples required by Rust
        top_left = (max_lat, min_lon)
        bottom_right = (min_lat, max_lon)
        
        results = self.search_box(top_left, bottom_right, filter_json)
        return [r[0] for r in results]

    def search_polygon(
        self, 
        points: List[Tuple[float, float]], 
        filter_json: Union[str, dict, None] = None
    ) -> List[Tuple[str, str]]:
        """
        Search for points inside a polygon.

        Args:
            points (List[Tuple[float, float]]): List of (lat, lon) vertices.
            filter_json (str | dict | None): Optional JSON filter.

        Returns:
            List of tuples: (id, metadata_json_string)
        """
        f_str = self._ensure_json_string(filter_json)
        return self._inner.search_polygon(points, f_str)
