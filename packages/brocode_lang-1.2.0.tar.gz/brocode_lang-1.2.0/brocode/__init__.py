"""
Bro Code - The Ultimate Vibe Check Programming Language

A high-level, dynamically typed esoteric programming language.
"""

__version__ = "1.2.0"
__author__ = "Prashith"
