import os
import json
import requests
from typing import Optional, List, Dict, Any
from mcp.server.fastmcp import FastMCP
from volcengine.auth.SignerV4 import SignerV4
from volcengine.Credentials import Credentials
from volcengine.base.Request import Request
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 初始化 FastMCP
mcp = FastMCP("Vinehoo Products Search MCP")

class VikingDBClient:
    def __init__(self, ak: str, sk: str, host: str, region: str = "cn-beijing"):
        self.ak = ak
        self.sk = sk
        self.host = host
        self.region = region

    def prepare_request(self, method: str, path: str, params: Optional[Dict] = None, data: Optional[Dict] = None):
        r = Request()
        r.set_shema("https")
        r.set_method(method)
        r.set_connection_timeout(10)
        r.set_socket_timeout(10)
        mheaders = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Host': self.host,
        }
        r.set_headers(mheaders)
        if params:
            r.set_query(params)
        r.set_host(self.host)
        r.set_path(path)
        if data is not None:
            r.set_body(json.dumps(data))
        
        credentials = Credentials(self.ak, self.sk, 'vikingdb', self.region)
        SignerV4.sign(r, credentials)
        return r

    def do_req(self, req_method: str, req_path: str, req_params: Optional[Dict] = None, req_body: Optional[Dict] = None):
        req = self.prepare_request(method=req_method, path=req_path, params=req_params, data=req_body)
        url = f"https://{self.host}{req.path}"
        response = requests.request(
            method=req.method,
            url=url,
            headers=req.headers,
            data=req.body,
            timeout=10
        )
        return response

def get_client():
    ak = os.getenv("VOLC_AK")
    sk = os.getenv("VOLC_SK")
    host = os.getenv("VIKINGDB_HOST", "api-vikingdb.vikingdb.cn-beijing.volces.com")
    region = os.getenv("VIKINGDB_REGION", "cn-beijing")
    
    if not ak or not sk:
        raise ValueError("请在环境变量中设置 VOLC_AK 和 VOLC_SK")
    
    return VikingDBClient(ak, sk, host, region)

@mcp.tool()
def search_multi_modal(
    text: str,
    min_price: float,
    max_price: float,
    count: int,
) -> str:
    """
    在 VikingDB 向量数据库中进行多模态检索。
    
    Args:
        text: 待进行检索的 JSON 字符串
        min_price: 最低价格 (必填)
        max_price: 最高价格 (必填)
        count: 返回结果数量 (必填)
    """
    client = get_client()
    
    req_body = {
        "collection_name": "vinehoo_products",
        "index_name": "vinehoo_products_index",
        "need_instruction": True,
        "limit": count
    }
    
    if text:
        req_body["text"] = text
        
    req_body["output_fields"] = ["pid","products","periods_type","price"]

    # 构造价格范围过滤条件
    req_body["filter"] = {
        "op": "range",
        "field": "price",
        "gte": min_price,
        "lte": max_price
    }

    if not any([text]):
        return "错误：text 至少需要提供一个。"

    try:
        response = client.do_req(
            req_method="POST",
            req_path="/api/vikingdb/data/search/multi_modal",
            req_body=req_body
        )
        
        if response.status_code == 200:
            result = response.json()
            # 删除顶层字段
            for field in ["message", "code", "request_id"]:
                result.pop(field, None)
            
            # 删除 result 中的字段
            if "result" in result:
                res_data = result["result"]
                for field in ["real_text_query", "total_return_count", "token_usage", "filter_matched_count"]:
                    res_data.pop(field, None)
                
                # 删除 data 列表中每个项的字段
                if "data" in res_data and isinstance(res_data["data"], list):
                    for item in res_data["data"]:
                        # 处理 price 字段保留一位小数
                        if "fields" in item and "price" in item["fields"]:
                            try:
                                item["fields"]["price"] = round(float(item["fields"]["price"]), 1)
                            except (ValueError, TypeError):
                                pass

                        for field in ["score", "ann_score"]:
                            item.pop(field, None)
                            
            return json.dumps(result, separators=(',', ':'), ensure_ascii=False)
        else:
            return f"请求失败，状态码: {response.status_code}, 响应: {response.text}"
    except Exception as e:
        return f"发生异常: {str(e)}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
