"""Protocol handlers for DataFrame server commands."""
from __future__ import annotations

import json
import struct
from typing import TYPE_CHECKING, Any

import pyarrow as pa
from pyspark.sql import functions as F

if TYPE_CHECKING:
    from pyspark.sql import DataFrame

STATUS_OK = 0
STATUS_ERROR = 1

# Cache for computed stats (cleared when DataFrame is re-registered)
_stats_cache: dict[str, dict] = {}


def clear_stats_cache(name: str | None = None) -> None:
    """Clear cached stats for a DataFrame or all DataFrames."""
    if name is None:
        _stats_cache.clear()
    elif name in _stats_cache:
        del _stats_cache[name]


def encode_response(status: int, payload: bytes) -> bytes:
    """Encode response with status and length prefix."""
    return struct.pack(">II", status, len(payload)) + payload


def encode_json_response(data: Any) -> bytes:
    """Encode JSON data as successful response."""
    return encode_response(STATUS_OK, json.dumps(data).encode("utf-8"))


def encode_error(message: str) -> bytes:
    """Encode error message response."""
    return encode_response(STATUS_ERROR, message.encode("utf-8"))


def handle_list(registry: dict[str, DataFrame]) -> bytes:
    """Return list of registered DataFrame names."""
    return encode_json_response(list(registry.keys()))


def handle_schema(registry: dict[str, DataFrame], name: str) -> bytes:
    """Return schema of a DataFrame as JSON."""
    if name not in registry:
        return encode_error(f"DataFrame '{name}' not found")

    df = registry[name]
    columns = [
        {"name": field.name, "type": str(field.dataType), "nullable": field.nullable}
        for field in df.schema.fields
    ]
    return encode_json_response({"name": name, "columns": columns})


def handle_get(registry: dict[str, DataFrame], name: str, limit: int) -> bytes:
    """Return DataFrame data as Arrow IPC stream."""
    if name not in registry:
        return encode_error(f"DataFrame '{name}' not found")

    df = registry[name]
    limited_df = df.limit(limit) if limit > 0 else df

    table = limited_df.toArrow()

    sink = pa.BufferOutputStream()
    with pa.ipc.RecordBatchStreamWriter(sink, table.schema) as writer:
        for batch in table.to_batches():
            writer.write_batch(batch)

    return encode_response(STATUS_OK, sink.getvalue().to_pybytes())


def _is_numeric_type(dtype_str: str) -> bool:
    """Check if a Spark type string represents a numeric type."""
    dtype_lower = dtype_str.lower()
    return any(t in dtype_lower for t in ["int", "long", "double", "float", "decimal"])


def handle_stats(registry: dict[str, DataFrame], name: str) -> bytes:
    """Return basic statistics for a DataFrame using single aggregation."""
    if name not in registry:
        return encode_error(f"DataFrame '{name}' not found")

    # Return cached stats if available
    if name in _stats_cache:
        return encode_json_response(_stats_cache[name])

    df = registry[name]
    fields = df.schema.fields

    # Build all aggregation expressions in one pass
    agg_exprs = [F.count(F.lit(1)).alias("__total")]
    for field in fields:
        col_name = field.name
        agg_exprs.append(
            F.sum(F.when(F.col(col_name).isNull(), 1).otherwise(0)).alias(f"{col_name}__nulls")
        )
        if _is_numeric_type(str(field.dataType)):
            agg_exprs.append(F.min(col_name).alias(f"{col_name}__min"))
            agg_exprs.append(F.max(col_name).alias(f"{col_name}__max"))

    # Single Spark action
    result = df.agg(*agg_exprs).collect()[0]
    row_count = result["__total"]

    # Extract stats from result
    column_stats = []
    for field in fields:
        col_name = field.name
        dtype_str = str(field.dataType)
        stats = {"name": col_name, "type": dtype_str, "nullable": field.nullable}
        stats["null_count"] = result[f"{col_name}__nulls"] or 0

        if _is_numeric_type(dtype_str):
            min_val = result[f"{col_name}__min"]
            max_val = result[f"{col_name}__max"]
            stats["min"] = str(min_val) if min_val is not None else None
            stats["max"] = str(max_val) if max_val is not None else None

        column_stats.append(stats)

    stats_data = {"name": name, "row_count": row_count, "columns": column_stats}
    _stats_cache[name] = stats_data  # Cache for future requests

    return encode_json_response(stats_data)


def dispatch_command(
    registry: dict[str, DataFrame], command: str
) -> bytes:
    """Parse and dispatch a command to the appropriate handler."""
    command = command.strip()

    if command == "LIST":
        return handle_list(registry)

    if command.startswith("SCHEMA:"):
        name = command[7:]
        return handle_schema(registry, name)

    if command.startswith("GET:"):
        parts = command[4:].split(":")
        if len(parts) != 2:
            return encode_error("Invalid GET format. Use GET:name:limit")
        name, limit_str = parts
        try:
            limit = int(limit_str)
        except ValueError:
            return encode_error(f"Invalid limit: {limit_str}")
        return handle_get(registry, name, limit)

    if command.startswith("STATS:"):
        name = command[6:]
        return handle_stats(registry, name)

    return encode_error(f"Unknown command: {command}")
