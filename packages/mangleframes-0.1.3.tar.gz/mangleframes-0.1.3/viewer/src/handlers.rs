//! HTTP route handlers for the web API.

use std::sync::Arc;

use axum::body::Body;
use axum::extract::{Path, Query, State};
use axum::http::{header, Response, StatusCode};
use axum::response::IntoResponse;
use axum::Json;
use serde::Deserialize;
use serde_json::json;

use crate::arrow_reader::{batches_to_json, parse_arrow_stream, total_row_count};
use crate::export;
use crate::query_engine::QueryEngine;
use crate::web_server::{AppState, CachedFrame};

const INDEX_HTML: &str = include_str!("../static/index.html");
const APP_JS: &str = include_str!("../static/app.js");
const STYLE_CSS: &str = include_str!("../static/style.css");

pub async fn serve_index() -> impl IntoResponse {
    Response::builder()
        .header(header::CONTENT_TYPE, "text/html")
        .body(Body::from(INDEX_HTML))
        .unwrap()
}

pub async fn serve_js() -> impl IntoResponse {
    Response::builder()
        .header(header::CONTENT_TYPE, "application/javascript")
        .body(Body::from(APP_JS))
        .unwrap()
}

pub async fn serve_css() -> impl IntoResponse {
    Response::builder()
        .header(header::CONTENT_TYPE, "text/css")
        .body(Body::from(STYLE_CSS))
        .unwrap()
}

pub async fn list_frames(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    match state.client.list_frames() {
        Ok(names) => Json(json!({"frames": names})).into_response(),
        Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"error": e.to_string()}))).into_response(),
    }
}

pub async fn get_schema(
    State(state): State<Arc<AppState>>,
    Path(name): Path<String>,
) -> impl IntoResponse {
    match state.client.get_schema(&name) {
        Ok(schema) => Json(schema).into_response(),
        Err(e) => (StatusCode::NOT_FOUND, Json(json!({"error": e.to_string()}))).into_response(),
    }
}

#[derive(Deserialize)]
pub struct DataQuery {
    offset: Option<usize>,
    limit: Option<usize>,
}

pub async fn get_data(
    State(state): State<Arc<AppState>>,
    Path(name): Path<String>,
    Query(query): Query<DataQuery>,
) -> impl IntoResponse {
    let offset = query.offset.unwrap_or(0);
    let limit = query.limit.unwrap_or(100).min(10000);

    let cache = state.cache.read().await;
    if let Some(cached) = cache.get(&name) {
        let rows = batches_to_json(&cached.batches, offset, limit);
        let total = total_row_count(&cached.batches);
        return Json(json!({"rows": rows, "total": total, "offset": offset})).into_response();
    }
    drop(cache);

    let fetch_limit = (offset + limit).max(10000);
    match state.client.get_frame(&name, fetch_limit) {
        Ok(data) => match parse_arrow_stream(&data) {
            Ok(batches) => {
                let rows = batches_to_json(&batches, offset, limit);
                let total = total_row_count(&batches);

                let mut cache = state.cache.write().await;
                cache.insert(name, CachedFrame { batches, stats: None });

                Json(json!({"rows": rows, "total": total, "offset": offset})).into_response()
            }
            Err(e) => (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"error": e.to_string()}))).into_response(),
        },
        Err(e) => (StatusCode::NOT_FOUND, Json(json!({"error": e.to_string()}))).into_response(),
    }
}

pub async fn get_stats(
    State(state): State<Arc<AppState>>,
    Path(name): Path<String>,
) -> impl IntoResponse {
    match state.client.get_stats(&name) {
        Ok(stats) => Json(stats).into_response(),
        Err(e) => (StatusCode::NOT_FOUND, Json(json!({"error": e.to_string()}))).into_response(),
    }
}

#[derive(Deserialize)]
pub struct ExportRequest {
    format: String,
}

pub async fn export_frame(
    State(state): State<Arc<AppState>>,
    Path(name): Path<String>,
    Json(req): Json<ExportRequest>,
) -> impl IntoResponse {
    let cache = state.cache.read().await;
    let batches = match cache.get(&name) {
        Some(cached) => cached.batches.clone(),
        None => {
            drop(cache);
            match state.client.get_frame(&name, 100000) {
                Ok(data) => match parse_arrow_stream(&data) {
                    Ok(b) => b,
                    Err(e) => return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
                },
                Err(e) => return (StatusCode::NOT_FOUND, e.to_string()).into_response(),
            }
        }
    };

    let (content_type, data) = match req.format.as_str() {
        "csv" => match export::to_csv(&batches) {
            Ok(d) => ("text/csv", d),
            Err(e) => return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
        },
        "json" => match export::to_json(&batches) {
            Ok(d) => ("application/json", d),
            Err(e) => return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
        },
        "parquet" => match export::to_parquet(&batches) {
            Ok(d) => ("application/octet-stream", d),
            Err(e) => return (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()).into_response(),
        },
        _ => return (StatusCode::BAD_REQUEST, "Invalid format").into_response(),
    };

    let filename = format!("{}.{}", name, req.format);
    Response::builder()
        .header(header::CONTENT_TYPE, content_type)
        .header(header::CONTENT_DISPOSITION, format!("attachment; filename=\"{}\"", filename))
        .body(Body::from(data))
        .unwrap()
        .into_response()
}

#[derive(Deserialize)]
pub struct QueryRequest {
    sql: String,
}

pub async fn execute_query(
    State(state): State<Arc<AppState>>,
    Json(req): Json<QueryRequest>,
) -> impl IntoResponse {
    let cache = state.cache.read().await;
    let frames: Vec<_> = cache.iter()
        .map(|(name, cached)| (name.clone(), cached.batches.clone()))
        .collect();
    drop(cache);

    let engine = QueryEngine::new();
    for (name, batches) in &frames {
        if let Err(e) = engine.register_frame(name, batches.clone()).await {
            return (StatusCode::INTERNAL_SERVER_ERROR, Json(json!({"error": e.to_string()}))).into_response();
        }
    }

    match engine.execute(&req.sql).await {
        Ok(batches) => {
            let rows = batches_to_json(&batches, 0, 1000);
            let total = total_row_count(&batches);
            Json(json!({"rows": rows, "total": total})).into_response()
        }
        Err(e) => (StatusCode::BAD_REQUEST, Json(json!({"error": e.to_string()}))).into_response(),
    }
}
