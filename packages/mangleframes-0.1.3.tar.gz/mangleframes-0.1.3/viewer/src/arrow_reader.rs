//! Arrow IPC stream parsing and JSON conversion.

use std::io::Cursor;

use arrow::array::{Array, AsArray};
use arrow::datatypes::DataType;
use arrow::record_batch::RecordBatch;
use arrow_ipc::reader::StreamReader;
use serde_json::{json, Value};
use thiserror::Error;

#[derive(Error, Debug)]
pub enum ArrowError {
    #[error("Failed to parse Arrow IPC: {0}")]
    ParseError(#[from] arrow::error::ArrowError),
}

pub fn parse_arrow_stream(data: &[u8]) -> Result<Vec<RecordBatch>, ArrowError> {
    let cursor = Cursor::new(data);
    let reader = StreamReader::try_new(cursor, None)?;
    let batches: Result<Vec<_>, _> = reader.collect();
    Ok(batches?)
}

pub fn batches_to_json(batches: &[RecordBatch], offset: usize, limit: usize) -> Value {
    let mut rows: Vec<Value> = Vec::new();
    let mut current_offset = 0;

    for batch in batches {
        let batch_rows = batch.num_rows();
        if current_offset + batch_rows <= offset {
            current_offset += batch_rows;
            continue;
        }

        let start = if current_offset < offset { offset - current_offset } else { 0 };
        let end = (start + limit - rows.len()).min(batch_rows);

        for row_idx in start..end {
            let mut row = serde_json::Map::new();
            for (col_idx, field) in batch.schema().fields().iter().enumerate() {
                let col = batch.column(col_idx);
                let value = array_value_to_json(col.as_ref(), row_idx);
                row.insert(field.name().clone(), value);
            }
            rows.push(Value::Object(row));
            if rows.len() >= limit {
                break;
            }
        }
        current_offset += batch_rows;
        if rows.len() >= limit {
            break;
        }
    }

    json!(rows)
}

fn array_value_to_json(array: &dyn Array, index: usize) -> Value {
    if array.is_null(index) {
        return Value::Null;
    }

    match array.data_type() {
        DataType::Boolean => {
            json!(array.as_boolean().value(index))
        }
        DataType::Int8 => {
            json!(array.as_primitive::<arrow::datatypes::Int8Type>().value(index))
        }
        DataType::Int16 => {
            json!(array.as_primitive::<arrow::datatypes::Int16Type>().value(index))
        }
        DataType::Int32 => {
            json!(array.as_primitive::<arrow::datatypes::Int32Type>().value(index))
        }
        DataType::Int64 => {
            json!(array.as_primitive::<arrow::datatypes::Int64Type>().value(index))
        }
        DataType::UInt8 => {
            json!(array.as_primitive::<arrow::datatypes::UInt8Type>().value(index))
        }
        DataType::UInt16 => {
            json!(array.as_primitive::<arrow::datatypes::UInt16Type>().value(index))
        }
        DataType::UInt32 => {
            json!(array.as_primitive::<arrow::datatypes::UInt32Type>().value(index))
        }
        DataType::UInt64 => {
            json!(array.as_primitive::<arrow::datatypes::UInt64Type>().value(index))
        }
        DataType::Float32 => {
            json!(array.as_primitive::<arrow::datatypes::Float32Type>().value(index))
        }
        DataType::Float64 => {
            json!(array.as_primitive::<arrow::datatypes::Float64Type>().value(index))
        }
        DataType::Utf8 => {
            json!(array.as_string::<i32>().value(index))
        }
        DataType::LargeUtf8 => {
            json!(array.as_string::<i64>().value(index))
        }
        _ => json!(format!("{:?}", array.data_type())),
    }
}

pub fn schema_to_json(batches: &[RecordBatch]) -> Value {
    if batches.is_empty() {
        return json!({"columns": []});
    }

    let schema = batches[0].schema();
    let columns: Vec<Value> = schema
        .fields()
        .iter()
        .map(|f| {
            json!({
                "name": f.name(),
                "type": format!("{:?}", f.data_type()),
                "nullable": f.is_nullable()
            })
        })
        .collect();

    json!({"columns": columns})
}

pub fn total_row_count(batches: &[RecordBatch]) -> usize {
    batches.iter().map(|b| b.num_rows()).sum()
}
