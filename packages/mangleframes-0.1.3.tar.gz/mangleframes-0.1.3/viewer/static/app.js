const state = {
    currentFrame: null,
    columns: [],
    rows: [],
    total: 0,
    offset: 0,
    limit: 100,
    sortCol: null,
    sortDir: 'asc',
    searchTerm: '',
    loading: false
};

const $ = id => document.getElementById(id);

async function fetchJSON(url, options = {}) {
    const res = await fetch(url, options);
    if (!res.ok) {
        const err = await res.json().catch(() => ({ error: res.statusText }));
        throw new Error(err.error || 'Request failed');
    }
    return res.json();
}

async function loadFrames() {
    try {
        const data = await fetchJSON('/api/frames');
        const select = $('frame-select');
        select.innerHTML = '<option value="">Select DataFrame...</option>';
        data.frames.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            select.appendChild(opt);
        });
    } catch (e) {
        showError('Failed to load frames: ' + e.message);
    }
}

async function loadSchema(name) {
    const data = await fetchJSON(`/api/frames/${name}/schema`);
    state.columns = data.columns || [];
    renderHeader();
}

async function loadData(name, offset = 0) {
    if (state.loading) return;
    state.loading = true;
    $('load-status').textContent = 'Loading...';

    try {
        const url = `/api/frames/${name}/data?offset=${offset}&limit=${state.limit}`;
        const data = await fetchJSON(url);

        if (offset === 0) {
            state.rows = data.rows;
        } else {
            state.rows = state.rows.concat(data.rows);
        }
        state.total = data.total;
        state.offset = offset + data.rows.length;

        renderRows();
        updateStatus();
    } catch (e) {
        showError('Failed to load data: ' + e.message);
    } finally {
        state.loading = false;
        $('load-status').textContent = '';
    }
}

async function loadStats(name) {
    try {
        const data = await fetchJSON(`/api/frames/${name}/stats`);
        renderStats(data);
    } catch (e) {
        $('stats-content').innerHTML = `<p class="error">${e.message}</p>`;
    }
}

function renderHeader() {
    const thead = $('table-head');
    thead.innerHTML = '';
    const tr = document.createElement('tr');

    state.columns.forEach(col => {
        const th = document.createElement('th');
        th.textContent = col.name;
        th.dataset.col = col.name;
        th.title = `${col.type}${col.nullable ? ' (nullable)' : ''}`;

        if (state.sortCol === col.name) {
            th.className = state.sortDir === 'asc' ? 'sorted-asc' : 'sorted-desc';
        }

        th.onclick = () => toggleSort(col.name);
        tr.appendChild(th);
    });

    thead.appendChild(tr);
}

function renderRows() {
    const tbody = $('table-body');
    tbody.innerHTML = '';

    let rows = state.rows;

    if (state.searchTerm) {
        const term = state.searchTerm.toLowerCase();
        rows = rows.filter(row =>
            Object.values(row).some(v =>
                String(v).toLowerCase().includes(term)
            )
        );
    }

    if (state.sortCol) {
        rows = [...rows].sort((a, b) => {
            const av = a[state.sortCol];
            const bv = b[state.sortCol];
            if (av === null) return 1;
            if (bv === null) return -1;
            const cmp = av < bv ? -1 : av > bv ? 1 : 0;
            return state.sortDir === 'asc' ? cmp : -cmp;
        });
    }

    rows.forEach(row => {
        const tr = document.createElement('tr');
        state.columns.forEach(col => {
            const td = document.createElement('td');
            const val = row[col.name];
            if (val === null) {
                td.textContent = 'null';
                td.className = 'null';
            } else {
                td.textContent = String(val);
                td.title = String(val);
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
}

function renderStats(data) {
    const container = $('stats-content');
    container.innerHTML = '';

    const rowCard = document.createElement('div');
    rowCard.className = 'stat-card';
    rowCard.innerHTML = `<h4>Total Rows</h4><p>${data.row_count?.toLocaleString() || 'N/A'}</p>`;
    container.appendChild(rowCard);

    if (data.columns) {
        data.columns.forEach(col => {
            const card = document.createElement('div');
            card.className = 'stat-card';
            let html = `<h4>${col.name}</h4>`;
            html += `<p>Type: ${col.type}</p>`;
            html += `<p>Nulls: ${col.null_count?.toLocaleString() || 0}</p>`;
            if (col.min !== undefined) html += `<p>Min: ${col.min}</p>`;
            if (col.max !== undefined) html += `<p>Max: ${col.max}</p>`;
            card.innerHTML = html;
            container.appendChild(card);
        });
    }
}

function toggleSort(colName) {
    if (state.sortCol === colName) {
        state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
        state.sortCol = colName;
        state.sortDir = 'asc';
    }
    renderHeader();
    renderRows();
}

function updateStatus() {
    const showing = state.searchTerm ? 'filtered' : state.rows.length;
    $('row-count').textContent = `Showing ${showing} of ${state.total.toLocaleString()} rows`;
}

function showError(msg) {
    const tbody = $('table-body');
    tbody.innerHTML = `<tr><td colspan="${state.columns.length || 1}" class="error">${msg}</td></tr>`;
}

async function exportData(format) {
    if (!state.currentFrame) return;

    try {
        const res = await fetch(`/api/frames/${state.currentFrame}/export`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ format })
        });

        if (!res.ok) throw new Error('Export failed');

        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${state.currentFrame}.${format}`;
        a.click();
        URL.revokeObjectURL(url);
    } catch (e) {
        alert('Export failed: ' + e.message);
    }
}

async function runSQL() {
    const sql = $('sql-input').value.trim();
    if (!sql) return;

    const resultDiv = $('sql-result');
    resultDiv.innerHTML = '<p class="loading">Running query...</p>';

    try {
        const data = await fetchJSON('/api/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sql })
        });

        if (data.rows.length === 0) {
            resultDiv.innerHTML = '<p>No results</p>';
            return;
        }

        const cols = Object.keys(data.rows[0]);
        let html = '<table><thead><tr>';
        cols.forEach(c => html += `<th>${c}</th>`);
        html += '</tr></thead><tbody>';

        data.rows.forEach(row => {
            html += '<tr>';
            cols.forEach(c => {
                const v = row[c];
                html += v === null
                    ? '<td class="null">null</td>'
                    : `<td>${v}</td>`;
            });
            html += '</tr>';
        });

        html += '</tbody></table>';
        html += `<p style="margin-top:8px;font-size:12px;color:var(--text-muted)">${data.total} rows</p>`;
        resultDiv.innerHTML = html;
    } catch (e) {
        resultDiv.innerHTML = `<p class="error">${e.message}</p>`;
    }
}

function setupInfiniteScroll() {
    const container = $('table-container');
    container.addEventListener('scroll', () => {
        if (state.loading || state.offset >= state.total) return;

        const { scrollTop, scrollHeight, clientHeight } = container;
        if (scrollTop + clientHeight >= scrollHeight - 100) {
            loadData(state.currentFrame, state.offset);
        }
    });
}

function setupWebSocket() {
    const ws = new WebSocket(`ws://${location.host}/ws`);

    ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.type === 'refresh') {
            loadFrames();
        }
    };

    ws.onclose = () => setTimeout(setupWebSocket, 3000);
}

function init() {
    loadFrames();
    setupInfiniteScroll();
    setupWebSocket();

    $('frame-select').onchange = async (e) => {
        const name = e.target.value;
        if (!name) return;

        state.currentFrame = name;
        state.rows = [];
        state.offset = 0;
        state.sortCol = null;

        // Fetch schema and data in parallel for faster display
        await Promise.all([loadSchema(name), loadData(name)]);
        loadStats(name);  // Fire-and-forget, updates UI when ready
    };

    $('refresh-btn').onclick = () => {
        loadFrames();
        if (state.currentFrame) {
            state.rows = [];
            state.offset = 0;
            loadData(state.currentFrame);
        }
    };

    $('search-input').oninput = (e) => {
        state.searchTerm = e.target.value;
        renderRows();
        updateStatus();
    };

    document.querySelectorAll('.export-buttons button').forEach(btn => {
        btn.onclick = () => exportData(btn.dataset.format);
    });

    $('run-sql').onclick = runSQL;
    $('sql-input').onkeydown = (e) => {
        if (e.ctrlKey && e.key === 'Enter') runSQL();
    };
}

document.addEventListener('DOMContentLoaded', init);
