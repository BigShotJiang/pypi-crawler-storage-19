"""Version information for myfy-tasks package."""

__version__ = "0.1.2a94"
