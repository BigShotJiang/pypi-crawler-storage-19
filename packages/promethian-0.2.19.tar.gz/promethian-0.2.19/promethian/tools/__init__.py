"""Built-in tools for Promethian agents.

These tools are always available regardless of what's in the knowledge base.
"""

from __future__ import annotations

from promethian.tools.browser import (
    BrowserTool,
    BrowserResult,
    get_browser,
    close_browser,
)

from promethian.tools.bash import (
    BashTool,
    BashResult,
    get_bash,
    reset_bash,
)

from promethian.tools.web_search import (
    APISearchTool,
    DDGSearchTool,
    WebSearchResult,
    SearchResult,
    get_web_search,
    reset_web_search,
)

from promethian.tools.web_fetch import (
    WebFetchTool,
    FetchResult,
    get_web_fetch,
    reset_web_fetch,
)

from promethian.tools.file_tools import (
    # Result types
    ReadResult,
    WriteResult,
    EditResult,
    GlobResult,
    GrepResult,
    GrepMatch,
    # Tool classes
    ReadTool,
    WriteTool,
    EditTool,
    GlobTool,
    GrepTool,
    FileTools,
    # Accessors
    get_file_tools,
    reset_file_tools,
    get_read,
    get_write,
    get_edit,
    get_glob,
    get_grep,
)

from promethian.tools.todo import (
    TodoStatus,
    TodoItem,
    TodoResult,
    TodoWriteTool,
    get_todo_tool,
    reset_todo_tool,
)

from promethian.tools.ask_user import (
    AskUserResult,
    AskUserTool,
    get_ask_user_tool,
    reset_ask_user_tool,
)

__all__ = [
    # Browser tools
    "BrowserTool",
    "BrowserResult",
    "get_browser",
    "close_browser",
    # Bash tools
    "BashTool",
    "BashResult",
    "get_bash",
    "reset_bash",
    # Web search tools
    "APISearchTool",
    "DDGSearchTool",
    "WebSearchResult",
    "SearchResult",
    "get_web_search",
    "reset_web_search",
    # Web fetch tools
    "WebFetchTool",
    "FetchResult",
    "get_web_fetch",
    "reset_web_fetch",
    # File tools
    "ReadResult",
    "WriteResult",
    "EditResult",
    "GlobResult",
    "GrepResult",
    "GrepMatch",
    "ReadTool",
    "WriteTool",
    "EditTool",
    "GlobTool",
    "GrepTool",
    "FileTools",
    "get_file_tools",
    "reset_file_tools",
    "get_read",
    "get_write",
    "get_edit",
    "get_glob",
    "get_grep",
    # Todo tools
    "TodoStatus",
    "TodoItem",
    "TodoResult",
    "TodoWriteTool",
    "get_todo_tool",
    "reset_todo_tool",
    # Ask user tools
    "AskUserResult",
    "AskUserTool",
    "get_ask_user_tool",
    "reset_ask_user_tool",
]
