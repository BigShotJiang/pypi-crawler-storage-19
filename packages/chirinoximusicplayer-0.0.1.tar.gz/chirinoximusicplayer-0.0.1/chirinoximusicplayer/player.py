"""
This is player package documentation
"""


class Player:
    """
      This class creates a music player
    """

    def __init__(self):
        pass

    def play(self, songname):
        """
          Play a song by parameter

          Parameters:
            songname: song name

          Returns:
            int: returns 1 if was successfull, otherwise return 0
        """
        print(f'playing song: {songname}')

    def stop(self):
        """
          Stops a reproducing song
        """
        print("stopping....")
