# Procurement Spend Leakage — Executive Brief

**Generated (UTC):** 2026-01-12 02:37:01
**Program:** Procurement Spend Leakage
**Reporting Period:** 2026-01

## Key Takeaways
- Estimated savings identified: **$6,310.00/month**
- Governance decision: **human_review** (confidence **0.646**)
- Recommendations produced: **3**

## Top Opportunities
- **duplicate_invoice** on `r2` — **$5,200.00/mo** (risk: `med`)
- **unapproved_vendor** on `r4` — **$960.00/mo** (risk: `med`)
- **price_variance** on `r3` — **$150.00/mo** (risk: `high`)

## Controls Applied
- Execution guardrails (steps/tool calls/cost ceilings)
- Confidence-based routing (auto vs human review)
- Append-only audit logging (traceable run metadata)

## Assumptions
- Savings estimates represent recoverable leakage and are conservative
- No payments are stopped automatically; all actions are recommendations
- High-risk findings require AP + business owner approval
- All decisions are logged for audit and review
