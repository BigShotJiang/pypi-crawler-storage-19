# Procurement Spend Leakage ROI Report

> **Executive Summary:** This run generated actionable cloud cost-optimization recommendations with
> projected savings of **$6,310.00 / month**.

## Overview
- Generated (UTC): **2026-01-12 02:37:01**
- Correlation ID: `f854cbfa-d4ae-428f-bbb1-1cd20400b374`
- Run ID: `8a17c35f-08e6-4a6d-a303-a3dbc690d757`

## Governance Decision
- Outcome: **human_review**
- Confidence score: **0.646**

## ROI Summary
- Estimated monthly savings: **$6,310.00**
- Estimated run cost: **$0.0200**
- ROI multiple (monthly savings / run cost): **315,500×**
- Payback period: **~1 minutes**

## Scope and Risk Breakdown

| Metric | Value |
|---|---:|
| Resources scanned | 0 |
| Recommendations generated | 3 |
| Low risk | 0 |
| Medium risk | 2 |
| High risk | 1 |

## Recommended Next Actions
- **Owner approval required:** 1 high-risk recommendation(s) (e.g., database rightsizing).
- **Validate before scheduling changes:** 2 medium-risk recommendation(s).

## Top Recommendations (by estimated monthly savings)

| Rank | Resource | Type | Action | Risk | Est. savings / month | Rationale |
|---:|---|---|---|---|---:|---|
| 1 | `` |  | duplicate_invoice | med | $5,200.00 | Duplicate invoice signature detected. Recommend payment hold + review. |
| 2 | `` |  | unapproved_vendor | med | $960.00 | Vendor not in approved list. Recommend onboarding check + contract validation. |
| 3 | `` |  | price_variance | high | $150.00 | Unit price 29.4% above baseline. Recommend contract check + vendor dispute. |

## Notes
- Savings are estimates based on deterministic heuristics in the demo (replace with real utilization + pricing data).
- High-risk actions (e.g., database rightsizing) should require explicit owner approval and a rollback plan.
- Audit events were recorded in an append-only log to support traceability and governance review.
