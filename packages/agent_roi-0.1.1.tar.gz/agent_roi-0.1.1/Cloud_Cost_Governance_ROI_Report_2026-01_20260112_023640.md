# Cloud Cost Governance ROI Report

> **Executive Summary:** This run generated actionable cloud cost-optimization recommendations with
> projected savings of **$663.50 / month**.

## Overview
- Generated (UTC): **2026-01-12 02:36:40**
- Correlation ID: `44ec1711-d387-4164-b17b-78c6aaec8f91`
- Run ID: `b4991e19-0c87-4e97-be6b-c1b0f49e99e8`

## Governance Decision
- Outcome: **human_review**
- Confidence score: **0.635**

## ROI Summary
- Estimated monthly savings: **$663.50**
- Estimated run cost: **$0.0200**
- ROI multiple (monthly savings / run cost): **33,175×**
- Payback period: **~1 minutes**

## Scope and Risk Breakdown

| Metric | Value |
|---|---:|
| Resources scanned | 5 |
| Recommendations generated | 5 |
| Low risk | 3 |
| Medium risk | 1 |
| High risk | 1 |

## Recommended Next Actions
- **Owner approval required:** 1 high-risk recommendation(s) (e.g., database rightsizing).
- **Validate before scheduling changes:** 1 medium-risk recommendation(s).
- **Candidate for fast-track remediation:** 3 low-risk recommendation(s) (after standard checks).

## Top Recommendations (by estimated monthly savings)

| Rank | Resource | Type | Action | Risk | Est. savings / month | Rationale |
|---:|---|---|---|---|---:|---|
| 1 | `rds-prod-orders` | rds_instance | rightsizing_recommendation | high | $301.00 | Very low utilization (2.0%). Owner validation required. |
| 2 | `ec2-prod-payments-01` | ec2_instance | rightsizing_recommendation | med | $182.00 | Low utilization (6.2%). Recommend downsizing. |
| 3 | `ec2-dev-batch-02` | ec2_instance | scheduled_stop | low | $78.00 | Idle for 19 days. Recommend schedule/stop. |
| 4 | `s3-central-logs` | s3_bucket | lifecycle_policy_to_infrequent_access | low | $62.00 | Large bucket. Add lifecycle policy to cheaper storage class. |
| 5 | `ebs-orphan-vol-17` | ebs_volume | snapshot_then_delete | low | $40.50 | Unattached volume. Snapshot then delete. |

## Notes
- Savings are estimates based on deterministic heuristics in the demo (replace with real utilization + pricing data).
- High-risk actions (e.g., database rightsizing) should require explicit owner approval and a rollback plan.
- Audit events were recorded in an append-only log to support traceability and governance review.
