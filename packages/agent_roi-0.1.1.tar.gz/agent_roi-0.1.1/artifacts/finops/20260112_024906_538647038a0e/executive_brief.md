# Cloud Cost Governance — Executive Brief

**Generated (UTC):** 2026-01-12 02:49:06
**Program:** Cloud Cost Governance
**Reporting Period:** 2026-01

## Key Takeaways
- Estimated savings identified: **$545.00/month**
- Governance decision: **human_review** (confidence **0.635**)
- Recommendations produced: **3**

## Top Opportunities
- **rightsizing_recommendation** on `rds-prod-orders` — **$301.00/mo** (risk: `high`)
- **rightsizing_recommendation** on `ec2-prod-payments-01` — **$182.00/mo** (risk: `med`)
- **lifecycle_policy_to_infrequent_access** on `s3-central-logs` — **$62.00/mo** (risk: `low`)

## Controls Applied
- Execution guardrails (steps/tool calls/cost ceilings)
- Confidence-based routing (auto vs human review)
- Append-only audit logging (traceable run metadata)

## Assumptions
- Savings estimates are conservative
- No production changes executed automatically
- High-risk actions require owner approval
- All decisions are audited
