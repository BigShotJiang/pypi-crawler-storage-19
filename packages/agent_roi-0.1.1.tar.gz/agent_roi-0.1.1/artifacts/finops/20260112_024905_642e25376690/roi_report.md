# Cloud Cost Governance ROI Report

> **Executive Summary:** This run generated actionable cloud cost-optimization recommendations with
> projected savings of **$545.00 / month**.

## Overview
- Generated (UTC): **2026-01-12 02:49:05**
- Correlation ID: `3705d53c-a6d5-4d5f-bd67-a90a22563f6f`
- Run ID: `18c4d340-363a-402b-b29e-f7bb727205bc`

## Governance Decision
- Outcome: **human_review**
- Confidence score: **0.635**

## ROI Summary
- Estimated monthly savings: **$545.00**
- Estimated run cost: **$0.0200**
- ROI multiple (monthly savings / run cost): **27,250×**
- Payback period: **~2 minutes**

## Scope and Risk Breakdown

| Metric | Value |
|---|---:|
| Resources scanned | 3 |
| Recommendations generated | 3 |
| Low risk | 1 |
| Medium risk | 1 |
| High risk | 1 |

## Recommended Next Actions
- **Owner approval required:** 1 high-risk recommendation(s) (e.g., database rightsizing).
- **Validate before scheduling changes:** 1 medium-risk recommendation(s).
- **Candidate for fast-track remediation:** 1 low-risk recommendation(s) (after standard checks).

## Top Recommendations (by estimated monthly savings)

| Rank | Resource | Type | Action | Risk | Est. savings / month | Rationale |
|---:|---|---|---|---|---:|---|
| 1 | `rds-prod-orders` | rds_instance | rightsizing_recommendation | high | $301.00 | Very low utilization (2.0%). Owner validation required. |
| 2 | `ec2-prod-payments-01` | ec2_instance | rightsizing_recommendation | med | $182.00 | Low utilization (6.2%). Recommend downsizing. |
| 3 | `s3-central-logs` | s3_bucket | lifecycle_policy_to_infrequent_access | low | $62.00 | Large bucket. Add lifecycle policy to cheaper storage class. |

## Notes
- Savings are estimates based on deterministic heuristics in the demo (replace with real utilization + pricing data).
- High-risk actions (e.g., database rightsizing) should require explicit owner approval and a rollback plan.
- Audit events were recorded in an append-only log to support traceability and governance review.
