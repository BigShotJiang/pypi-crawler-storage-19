# Cloud Cost Governance — Executive Brief

**Generated (UTC):** 2026-01-12 02:36:40
**Program:** Cloud Cost Governance
**Reporting Period:** 2026-01

## Key Takeaways
- Estimated savings identified: **$663.50/month**
- Governance decision: **human_review** (confidence **0.635**)
- Recommendations produced: **5**

## Top Opportunities
- **rightsizing_recommendation** on `rds-prod-orders` — **$301.00/mo** (risk: `high`)
- **rightsizing_recommendation** on `ec2-prod-payments-01` — **$182.00/mo** (risk: `med`)
- **scheduled_stop** on `ec2-dev-batch-02` — **$78.00/mo** (risk: `low`)
- **lifecycle_policy_to_infrequent_access** on `s3-central-logs` — **$62.00/mo** (risk: `low`)
- **snapshot_then_delete** on `ebs-orphan-vol-17` — **$40.50/mo** (risk: `low`)

## Controls Applied
- Execution guardrails (steps/tool calls/cost ceilings)
- Confidence-based routing (auto vs human review)
- Append-only audit logging (traceable run metadata)

## Assumptions
- Savings estimates are conservative and based on current utilization
- No production changes are executed automatically
- High-risk actions require explicit owner approval
- All decisions are logged for audit and review
