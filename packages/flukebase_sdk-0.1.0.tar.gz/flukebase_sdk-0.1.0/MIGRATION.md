# Migration Guide for Contributors

This guide helps existing FlukeBase contributors transition to the new plugin-based development model.

## Overview of Changes

FlukeBase has transitioned to a closed-source model for the core platform, with an open-source SDK for plugin development. This change allows us to:

- Maintain a stable, well-tested core platform
- Enable community innovation through plugins
- Protect proprietary implementations while sharing interfaces
- Provide a clear, documented API for third-party developers

## What Changed

### Now Closed Source

The following components are now part of the closed-source FlukeBase Connect:

- Core MCP server implementation
- Built-in plugins (50+ tools)
- API client implementation
- Memory store implementation
- WeDo task manager implementation
- Environment manager
- Platform-specific integrations

### Remains Open Source

The following remain open source:

| Component | Repository | Purpose |
|-----------|------------|---------|
| `flukebase-sdk` | This repository | SDK for building plugins |
| `flukebase-plugin-template` | flukebase/flukebase-plugin-template | Cookiecutter template for new plugins |
| Community plugins | Various | Third-party plugin implementations |

## For Existing Contributors

### If You Were Contributing to Core

If you were contributing to the core FlukeBase Connect codebase, here's how to continue participating:

#### Option 1: Build Plugins

Transform your contributions into plugins:

```python
# Before: Contributing to core
class CoreFeature:
    def do_something(self):
        # Implementation in core

# After: Build as a plugin
from flukebase_sdk import BasePlugin, PluginMetadata, ToolDefinition

class MyFeaturePlugin(BasePlugin):
    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="my-feature",
            version="1.0.0",
            ...
        )

    def get_tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="my_feature_do_something",
                description="Does something useful",
                handler_method="handle_do_something",
                ...
            )
        ]

    async def handle_do_something(self, args: dict) -> str:
        # Your implementation here
        return "Result"
```

#### Option 2: Contribute to the SDK

The SDK itself is open source. You can contribute:

- New base classes and utilities
- Testing improvements
- Documentation
- Bug fixes
- Type definitions

#### Option 3: Build Community Tools

Create tools that enhance the ecosystem:

- CLI utilities
- Testing frameworks
- Development tools
- Integration helpers

## Migration Patterns

### Converting Internal Logic to Plugins

**Before (Internal Implementation):**
```python
# Inside flukebase_connect/features/calculator.py
class Calculator:
    def add(self, a: float, b: float) -> float:
        return a + b

    def multiply(self, a: float, b: float) -> float:
        return a * b
```

**After (Plugin):**
```python
# In your plugin package
from flukebase_sdk import BasePlugin, PluginMetadata, ToolDefinition, PluginType

class CalculatorPlugin(BasePlugin):
    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="calculator",
            display_name="Calculator",
            version="1.0.0",
            description="Basic arithmetic operations",
            plugin_type=PluginType.TOOL,
            author="Your Name",
        )

    def get_tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="calculator_add",
                description="Add two numbers",
                input_schema={
                    "type": "object",
                    "properties": {
                        "a": {"type": "number", "description": "First number"},
                        "b": {"type": "number", "description": "Second number"},
                    },
                    "required": ["a", "b"],
                },
                handler_method="handle_add",
            ),
            ToolDefinition(
                name="calculator_multiply",
                description="Multiply two numbers",
                input_schema={
                    "type": "object",
                    "properties": {
                        "a": {"type": "number", "description": "First number"},
                        "b": {"type": "number", "description": "Second number"},
                    },
                    "required": ["a", "b"],
                },
                handler_method="handle_multiply",
            ),
        ]

    async def handle_add(self, args: dict) -> str:
        a = args["a"]
        b = args["b"]
        result = a + b
        return f"{a} + {b} = {result}"

    async def handle_multiply(self, args: dict) -> str:
        a = args["a"]
        b = args["b"]
        result = a * b
        return f"{a} * {b} = {result}"
```

### Using FlukeBase Services

Plugins can access FlukeBase services through Protocol interfaces:

```python
from flukebase_sdk import (
    BasePlugin,
    MemoryStoreProtocol,
    WedoManagerProtocol,
    FlukeBaseClientProtocol,
)

class MyPlugin(BasePlugin):
    def __init__(self):
        super().__init__()
        self.memory: MemoryStoreProtocol | None = None
        self.wedo: WedoManagerProtocol | None = None
        self.client: FlukeBaseClientProtocol | None = None

    async def initialize(self, config: dict, services: dict) -> None:
        await super().initialize(config, services)
        # Get typed service references
        self.memory = self.get_service("memory")
        self.wedo = self.get_service("wedo")
        self.client = self.get_service("flukebase_client")

    async def handle_my_tool(self, args: dict) -> str:
        # Use memory service
        await self.memory.remember(
            content="Something important",
            type="fact",
            scope="global",
        )

        # Use WeDo service
        await self.wedo.create_task(
            task_id="TASK-001",
            description="Do something",
        )

        return "Done!"
```

### Testing Without Core Access

Use the SDK's mock services for testing:

```python
import pytest
from flukebase_sdk.testing import create_mock_services, MockMemory

@pytest.mark.asyncio
async def test_my_plugin():
    plugin = MyPlugin()
    services = create_mock_services()

    # Pre-populate mock data if needed
    services["memory"].add_memory(MockMemory(
        id="test-1",
        content="Test data",
        type="fact",
    ))

    await plugin.initialize({}, services)

    result = await plugin.handle_my_tool({"param": "value"})

    # Verify service calls
    assert services["memory"].was_called("remember")
    assert services["wedo"].was_called("create_task")
```

## New Development Workflow

### 1. Create a New Plugin

```bash
# Using the template
pip install cookiecutter
cookiecutter gh:flukebase/flukebase-plugin-template

# Or using SDK CLI
pip install flukebase-sdk[cli]
flukebase-sdk new my-plugin --author "Your Name"
```

### 2. Develop Locally

```bash
cd my-plugin
pip install -e ".[dev]"

# Run tests
pytest tests/ -v

# Validate structure
flukebase-sdk validate
```

### 3. Test with FlukeBase Connect

```bash
# Install your plugin
pip install -e .

# FlukeBase Connect auto-discovers plugins via entry points
```

### 4. Publish to PyPI

```bash
# Build
python -m build

# Upload
python -m twine upload dist/*
```

### 5. Submit to Marketplace

1. Fork the `flukebase_connect` repository
2. Add your plugin to `marketplace/registry.json`
3. Create a Pull Request
4. Wait for review and approval

## Common Questions

### Q: Can I still contribute bug fixes?

**A:** Yes! If you find bugs in the SDK or documentation, please submit issues and PRs to the SDK repository.

### Q: How do I report issues with core FlukeBase?

**A:** Use the FlukeBase Connect issue tracker for core issues. For SDK issues, use this repository's issue tracker.

### Q: Can my plugin access internal FlukeBase APIs?

**A:** No. Plugins can only access the documented Protocol interfaces. This ensures stability and forward compatibility.

### Q: Will my existing PRs be lost?

**A:** Open PRs against the core repository were reviewed before the transition. If your PR wasn't merged, consider converting it to a plugin.

### Q: How do I get help with plugin development?

**A:**
- Read the [SDK documentation](docs/index.md)
- Check the [examples](docs/examples/)
- Open an issue with the `question` label
- Join the FlukeBase community Discord

### Q: Can I monetize my plugins?

**A:** Yes! Plugins you create are yours. You can:
- Release them as open source
- Sell them commercially
- Offer freemium models
- Provide paid support

## Version Compatibility

When developing plugins, specify `min_sdk_version` in your metadata:

```python
PluginMetadata(
    name="my-plugin",
    version="1.0.0",
    min_sdk_version="0.1.0",  # Minimum SDK version required
    ...
)
```

FlukeBase Connect validates compatibility at plugin load time. See [VERSIONING.md](VERSIONING.md) for details.

## Getting Started

1. **Read the documentation**: Start with [Getting Started](docs/getting-started.md)
2. **Try the examples**: Work through [Hello World](docs/examples/hello-world.md)
3. **Build something**: Create your first plugin
4. **Share it**: Submit to the marketplace

Welcome to the new plugin ecosystem! Your contributions as a plugin developer are valued and help make FlukeBase better for everyone.

---

Questions? Open an issue with the `migration` label.
