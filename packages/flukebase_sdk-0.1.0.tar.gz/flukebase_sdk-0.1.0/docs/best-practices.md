# Best Practices

This guide covers conventions, patterns, and recommendations for building high-quality FlukeBase plugins.

## Plugin Naming Conventions

### Package Names

Use kebab-case for package names:

```
flukebase-my-plugin          # Good
flukebase_my_plugin          # Avoid
FlukebaseMyPlugin            # Avoid
```

### Plugin Names (Metadata)

The `name` field in `PluginMetadata` should:

- Use kebab-case
- Be unique across all plugins
- Be descriptive but concise

```python
# Good
name="slack-integration"
name="github-sync"
name="analytics-dashboard"

# Avoid
name="my_plugin"
name="Plugin1"
name="the-slack-integration-plugin-v2"
```

### Display Names

Human-readable names for UI display:

```python
# Good
display_name="Slack Integration"
display_name="GitHub Sync"
display_name="Analytics Dashboard"

# Avoid
display_name="slack-integration"  # Not human-friendly
display_name="SLACK INTEGRATION"  # Too aggressive
```

## Tool Naming Conventions

### Prefix with Plugin Name

Always prefix tool names with your plugin name to avoid conflicts:

```python
# Good - clear ownership
"slack_send_message"
"slack_list_channels"
"github_create_pr"
"github_list_issues"

# Bad - may conflict with other plugins
"send_message"
"list_channels"
"create_pr"
```

### Use Action Verbs

Start tool names with descriptive action verbs:

```python
# Good - clear actions
"my_plugin_create_item"    # Creates something
"my_plugin_get_status"     # Retrieves information
"my_plugin_update_config"  # Modifies something
"my_plugin_delete_record"  # Removes something
"my_plugin_list_users"     # Lists multiple items
"my_plugin_search_logs"    # Searches/queries
"my_plugin_validate_input" # Validates data

# Avoid - unclear actions
"my_plugin_item"           # What does it do?
"my_plugin_process"        # Too vague
"my_plugin_handler"        # Implementation detail
```

### Consistent Verb Usage

| Action | Verb | Example |
|--------|------|---------|
| Create new | `create_` | `create_user`, `create_task` |
| Retrieve one | `get_` | `get_user`, `get_config` |
| Retrieve many | `list_` | `list_users`, `list_tasks` |
| Update/modify | `update_` | `update_user`, `update_config` |
| Delete/remove | `delete_` | `delete_user`, `delete_task` |
| Search/query | `search_` | `search_users`, `search_logs` |
| Send/transmit | `send_` | `send_message`, `send_notification` |
| Fetch from external | `fetch_` | `fetch_data`, `fetch_status` |
| Validate | `validate_` | `validate_input`, `validate_config` |
| Show/display | `show_` | `show_status`, `show_summary` |

## Error Handling Patterns

### Return User-Friendly Errors

```python
async def handle_create_item(self, args: dict) -> str:
    name = args.get("name")

    # Validate input
    if not name:
        return "Error: 'name' is required"

    if len(name) > 100:
        return "Error: 'name' must be 100 characters or less"

    try:
        result = await self._create_item(name)
        return f"Created item: {result['id']}"

    except ValueError as e:
        return f"Invalid input: {e}"

    except ConnectionError:
        return "Error: Unable to connect to service. Please try again."

    except Exception as e:
        # Log unexpected errors, return generic message
        self._log_error(e)
        return "Error: An unexpected error occurred"
```

### Validate Early, Fail Fast

```python
async def handle_complex_operation(self, args: dict) -> str:
    # Validate all inputs first
    errors = []

    if not args.get("source"):
        errors.append("'source' is required")

    if not args.get("destination"):
        errors.append("'destination' is required")

    count = args.get("count", 0)
    if count < 1 or count > 1000:
        errors.append("'count' must be between 1 and 1000")

    if errors:
        return "Validation errors:\n- " + "\n- ".join(errors)

    # All inputs valid, proceed with operation
    return await self._perform_operation(args)
```

### Handle Service Unavailability

```python
async def handle_api_call(self, args: dict) -> str:
    if not self.client:
        return "Error: API client not initialized"

    if not self.client.is_configured:
        return "Error: API not configured. Please set up credentials."

    try:
        result = await self.client.get_data(args["id"])
        return f"Result: {result}"

    except ConnectionError:
        return "Error: Cannot reach API. Check your network connection."

    except TimeoutError:
        return "Error: Request timed out. The service may be slow."
```

## Async Best Practices

### Always Use Async/Await

Tool handlers must be async:

```python
# Good
async def handle_my_tool(self, args: dict) -> str:
    result = await self._async_operation()
    return result

# Bad - blocks the event loop
def handle_my_tool(self, args: dict) -> str:
    result = self._sync_operation()  # Blocks!
    return result
```

### Avoid Blocking Calls

```python
import asyncio

# Bad - blocking I/O
def read_file_bad(self, path: str) -> str:
    with open(path) as f:
        return f.read()

# Good - run in thread pool
async def read_file_good(self, path: str) -> str:
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, self._read_file_sync, path)

def _read_file_sync(self, path: str) -> str:
    with open(path) as f:
        return f.read()
```

### Use Async Context Managers

```python
# Good - proper resource management
async def handle_with_connection(self, args: dict) -> str:
    async with self._get_connection() as conn:
        result = await conn.execute(args["query"])
        return str(result)
```

### Handle Concurrent Operations

```python
import asyncio

async def handle_batch_operation(self, args: dict) -> str:
    items = args.get("items", [])

    # Process items concurrently
    tasks = [self._process_item(item) for item in items]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Handle results
    successes = [r for r in results if not isinstance(r, Exception)]
    failures = [r for r in results if isinstance(r, Exception)]

    return f"Processed {len(successes)} items, {len(failures)} failed"
```

## Type Hints Usage

### Always Type Hint Public Methods

```python
from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    ToolDefinition,
    MemoryStoreProtocol,
)


class MyPlugin(BasePlugin):
    def __init__(self) -> None:
        super().__init__()
        self.memory: MemoryStoreProtocol | None = None

    def get_metadata(self) -> PluginMetadata:
        ...

    def get_tools(self) -> list[ToolDefinition]:
        ...

    async def initialize(self, config: dict, services: dict) -> None:
        ...

    async def handle_my_tool(self, args: dict) -> str:
        ...
```

### Type Hint Service References

```python
from flukebase_sdk import (
    FlukeBaseClientProtocol,
    MemoryStoreProtocol,
    WedoManagerProtocol,
)


class MyPlugin(BasePlugin):
    def __init__(self) -> None:
        super().__init__()
        # Type hint service attributes
        self.client: FlukeBaseClientProtocol | None = None
        self.memory: MemoryStoreProtocol | None = None
        self.wedo: WedoManagerProtocol | None = None

    async def initialize(self, config: dict, services: dict) -> None:
        await super().initialize(config, services)
        self.client = self.get_service("flukebase_client")
        self.memory = self.get_service("memory")
        self.wedo = self.get_service("wedo")
```

### Use Union Types for Optional Values

```python
def get_config_value(self, key: str, default: str | None = None) -> str | None:
    return self._config.get(key, default)


async def get_item(self, item_id: str) -> dict | None:
    """Returns item dict or None if not found."""
    ...
```

## Documentation Standards

### Docstrings for Public Methods

```python
class MyPlugin(BasePlugin):
    """A plugin that does useful things.

    This plugin provides tools for:
    - Creating items
    - Managing configurations
    - Generating reports

    Example:
        plugin = MyPlugin()
        await plugin.initialize({}, services)
    """

    async def handle_create_item(self, args: dict) -> str:
        """Create a new item with the given parameters.

        Args:
            args: Dictionary containing:
                - name (str): Item name (required)
                - description (str): Item description (optional)
                - tags (list[str]): Tags for the item (optional)

        Returns:
            Success message with item ID, or error message.

        Example:
            result = await plugin.handle_create_item({
                "name": "My Item",
                "tags": ["important"],
            })
        """
        ...
```

### Tool Descriptions for AI

Write clear descriptions that help AI understand when and how to use tools:

```python
ToolDefinition(
    name="my_plugin_search",
    # Good - clear purpose, parameters explained
    description=(
        "Search for items matching the query. "
        "Returns up to 'limit' results sorted by relevance. "
        "Use 'filters' to narrow results by category or date."
    ),
    ...
)

ToolDefinition(
    name="my_plugin_delete",
    # Good - explains consequences
    description=(
        "Permanently delete an item by ID. "
        "This action cannot be undone. "
        "Use with caution."
    ),
    ...
)
```

## Security Considerations

### Never Log Secrets

```python
# Bad - logs sensitive data
async def handle_connect(self, args: dict) -> str:
    api_key = args.get("api_key")
    print(f"Connecting with key: {api_key}")  # Don't do this!
    ...

# Good - mask sensitive data
async def handle_connect(self, args: dict) -> str:
    api_key = args.get("api_key")
    masked = api_key[:4] + "****" if api_key else "None"
    print(f"Connecting with key: {masked}")
    ...
```

### Validate Input Boundaries

```python
async def handle_query(self, args: dict) -> str:
    # Prevent SQL injection by using parameterized queries
    query = args.get("query", "")

    # Limit result size
    limit = min(args.get("limit", 100), 1000)

    # Validate allowed characters
    if not query.replace(" ", "").isalnum():
        return "Error: Query contains invalid characters"

    ...
```

### Sanitize File Paths

```python
from pathlib import Path

async def handle_read_file(self, args: dict) -> str:
    requested_path = args.get("path", "")

    # Resolve to absolute path
    base_dir = Path("/safe/directory")
    full_path = (base_dir / requested_path).resolve()

    # Verify path is within allowed directory
    if not str(full_path).startswith(str(base_dir)):
        return "Error: Access denied - path outside allowed directory"

    if not full_path.exists():
        return f"Error: File not found: {requested_path}"

    ...
```

### Use Scoped Tokens

```python
async def handle_container_operation(self, args: dict) -> str:
    # Generate scoped token for container
    scoped_token = await self.client.generate_scoped_token(
        scope=f"container:{args['container_id']}",
        ttl_minutes=15,  # Short-lived
        permissions=["read"],  # Minimal permissions
    )

    # Use scoped token for container operation
    ...
```

## Performance Considerations

### Cache Expensive Operations

```python
class MyPlugin(BasePlugin):
    def __init__(self) -> None:
        super().__init__()
        self._cache: dict = {}
        self._cache_ttl: int = 300  # 5 minutes

    async def handle_get_data(self, args: dict) -> str:
        key = args.get("key")

        # Check cache first
        cached = self._get_cached(key)
        if cached:
            return cached

        # Fetch and cache
        result = await self._fetch_expensive_data(key)
        self._set_cached(key, result)

        return result
```

### Batch Operations When Possible

```python
# Bad - N+1 queries
async def handle_get_all_bad(self, args: dict) -> str:
    ids = args.get("ids", [])
    results = []
    for id in ids:
        result = await self.client.get_item(id)  # One call per item
        results.append(result)
    return str(results)

# Good - single batch call
async def handle_get_all_good(self, args: dict) -> str:
    ids = args.get("ids", [])
    results = await self.client.batch_get_items(ids)  # Single call
    return str(results)
```

### Implement Pagination

```python
async def handle_list_items(self, args: dict) -> str:
    page = args.get("page", 1)
    per_page = min(args.get("per_page", 20), 100)  # Cap at 100

    offset = (page - 1) * per_page

    items = await self._get_items(limit=per_page, offset=offset)
    total = await self._get_item_count()

    return f"Page {page}/{(total + per_page - 1) // per_page}: {len(items)} items"
```

## Code Organization

### Separate Concerns

```python
# my_plugin/plugin.py - Main plugin class
class MyPlugin(BasePlugin):
    def get_metadata(self) -> PluginMetadata:
        ...

    def get_tools(self) -> list[ToolDefinition]:
        ...

    async def handle_action(self, args: dict) -> str:
        # Delegate to service
        return await self._action_service.execute(args)


# my_plugin/services/action_service.py - Business logic
class ActionService:
    def __init__(self, memory: MemoryStoreProtocol):
        self.memory = memory

    async def execute(self, args: dict) -> str:
        ...


# my_plugin/models.py - Data models
@dataclass
class ActionResult:
    success: bool
    message: str
    data: dict | None = None
```

### Keep Handlers Thin

```python
# Good - handler delegates to services
async def handle_create_item(self, args: dict) -> str:
    try:
        result = await self._item_service.create(args)
        return f"Created: {result.id}"
    except ValidationError as e:
        return f"Validation error: {e}"
    except ServiceError as e:
        return f"Service error: {e}"


# Avoid - handler contains all logic
async def handle_create_item_bad(self, args: dict) -> str:
    # 100 lines of validation, business logic, persistence...
    ...
```

## Testing Checklist

Before publishing your plugin, ensure:

- [ ] All tools have unit tests
- [ ] Error cases are tested
- [ ] Service interactions are tested with mocks
- [ ] Plugin initializes and shuts down cleanly
- [ ] All public methods have type hints
- [ ] Docstrings describe behavior
- [ ] Tool descriptions are clear for AI
- [ ] No secrets in code or tests
- [ ] Input validation is comprehensive

---

Previous: [Testing Guide](testing.md) | Next: [Examples](examples/hello-world.md)
