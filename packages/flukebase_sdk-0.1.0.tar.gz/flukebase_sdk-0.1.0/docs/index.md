# FlukeBase SDK Documentation

Welcome to the FlukeBase SDK documentation. This SDK provides everything you need to build plugins for the FlukeBase platform.

## What is FlukeBase SDK?

FlukeBase SDK is a Python development kit for creating plugins that extend FlukeBase Connect. Plugins can:

- Add new tools that AI agents can use
- Integrate with external services and APIs
- Provide analytics and automation capabilities
- Extend the platform with custom functionality

## Documentation Sections

### Getting Started

- **[Getting Started Guide](getting-started.md)** - Installation, prerequisites, and your first plugin
- **[Plugin Development Tutorial](plugin-development.md)** - Complete guide to building plugins

### API Reference

- **[Tools API Reference](tools-api.md)** - ToolDefinition, ToolAnnotations, and ResourceDefinition
- **[Service Protocols Guide](services.md)** - Using FlukeBase services in your plugins

### Testing & Best Practices

- **[Testing Guide](testing.md)** - Unit testing plugins with mock services
- **[Best Practices](best-practices.md)** - Conventions, patterns, and recommendations

### Examples

- **[Hello World Plugin](examples/hello-world.md)** - Minimal plugin example
- **[Integration Plugin](examples/integration-plugin.md)** - Complete integration example

---

## Quick Installation

```bash
pip install flukebase-sdk
```

## Quick Start Example

Here is a minimal plugin that adds a greeting tool:

```python
from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
)


class HelloWorldPlugin(BasePlugin):
    """A simple hello world plugin."""

    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="hello-world",
            display_name="Hello World",
            version="1.0.0",
            description="A simple greeting plugin",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
            author="Your Name",
        )

    def get_tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="hello_greet",
                description="Greet someone by name",
                input_schema={
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Name of the person to greet",
                        }
                    },
                    "required": ["name"],
                },
                handler_method="handle_greet",
            )
        ]

    async def handle_greet(self, args: dict) -> str:
        name = args.get("name", "World")
        return f"Hello, {name}! Welcome to FlukeBase."
```

## SDK Version

Current version: **0.1.0**

## Key Concepts

### Plugins

Plugins are Python classes that extend `BasePlugin`. Each plugin:

- Defines metadata describing itself
- Provides one or more tools
- Implements handler methods for each tool
- Can access shared services for storage and API calls

### Tools

Tools are functions that AI agents can call. Each tool has:

- A unique name (prefixed with the plugin name)
- A description for the AI to understand its purpose
- An input schema (JSON Schema format)
- A handler method that executes the tool logic

### Services

Services are shared capabilities provided by FlukeBase Connect:

| Service | Description |
|---------|-------------|
| `FlukeBaseClientProtocol` | API client for FlukeBase platform |
| `MemoryStoreProtocol` | Local knowledge/memory storage |
| `WedoManagerProtocol` | Task management (WeDo system) |
| `EnvManagerProtocol` | Environment variable management |
| `ConfigProtocol` | Configuration access |

## Requirements

- Python 3.11 or higher
- FlukeBase Connect (for running plugins)

## Support

- [GitHub Issues](https://github.com/flukebase/flukebase-sdk/issues)
- [FlukeBase Documentation](https://docs.flukebase.com)

---

Next: [Getting Started Guide](getting-started.md)
