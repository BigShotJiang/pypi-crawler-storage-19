# Security Guide for Plugin Developers

This guide covers security best practices when developing FlukeBase plugins.

## Scope System

Plugins must declare the permissions they need via scopes. FlukeBase Connect enforces these at runtime.

### Declaring Scopes

```python
from flukebase_sdk import BasePlugin, PluginMetadata, PluginScope

class MyPlugin(BasePlugin):
    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="my-plugin",
            required_scopes=[
                PluginScope.MEMORY_READ,
                PluginScope.MEMORY_WRITE,
            ],
            ...
        )
```

### Available Scopes

```python
from flukebase_sdk import PluginScope

# Memory service
PluginScope.MEMORY_READ      # Read memories
PluginScope.MEMORY_WRITE     # Store/delete memories

# WeDo tasks
PluginScope.WEDO_READ        # View tasks
PluginScope.WEDO_WRITE       # Create/update tasks
PluginScope.WEDO_DELETE      # Delete tasks

# Environment
PluginScope.ENV_READ         # Read env vars (masked)
PluginScope.ENV_READ_SECRETS # Read unmasked secrets (elevated)

# API
PluginScope.API_READ         # Read from FlukeBase API
PluginScope.API_WRITE        # Write to FlukeBase API

# Configuration
PluginScope.CONFIG_READ      # Read config values

# Filesystem
PluginScope.FS_READ_PROJECT  # Read project files
PluginScope.FS_WRITE_PROJECT # Write project files (elevated)

# Network
PluginScope.NETWORK_OUTBOUND # Outbound HTTP/WebSocket

# Subprocess
PluginScope.SUBPROCESS_SAFE         # Safe commands
PluginScope.SUBPROCESS_UNRESTRICTED # Any command (elevated)
```

### Elevated Scopes

These scopes require explicit user approval:

- `env:read_secrets` - Access to unmasked secret values
- `fs:write_project` - Write access to project files
- `subprocess:unrestricted` - Run arbitrary commands

**Only request elevated scopes if absolutely necessary.**

## Principle of Least Privilege

Request only the scopes your plugin actually needs:

```python
# Good - minimal scopes
required_scopes=[PluginScope.MEMORY_READ]

# Bad - over-requesting
required_scopes=[
    PluginScope.MEMORY_READ,
    PluginScope.MEMORY_WRITE,      # Not needed for read-only plugin
    PluginScope.ENV_READ_SECRETS,  # Very dangerous
]
```

## Input Validation

### Validate All Tool Arguments

Never trust input from tool calls:

```python
async def handle_process(self, args: dict) -> str:
    # Validate required fields
    data = args.get("data")
    if not data:
        return "Error: 'data' is required"

    # Validate types
    if not isinstance(data, str):
        return "Error: 'data' must be a string"

    # Validate length
    if len(data) > 10000:
        return "Error: 'data' exceeds maximum length"

    # Validate content
    if not data.isprintable():
        return "Error: 'data' contains invalid characters"

    # Safe to process
    return self._process_data(data)
```

### Sanitize File Paths

Prevent path traversal attacks:

```python
from pathlib import Path

async def handle_read_file(self, args: dict) -> str:
    requested_path = args.get("path", "")

    # Resolve to absolute path
    base_dir = Path(self.project_dir)
    full_path = (base_dir / requested_path).resolve()

    # Verify path is within project
    try:
        full_path.relative_to(base_dir)
    except ValueError:
        return "Error: Path outside project directory"

    # Check for path traversal attempts
    if ".." in requested_path:
        return "Error: Path traversal not allowed"

    if not full_path.exists():
        return f"Error: File not found"

    # Safe to read
    return full_path.read_text()
```

### Validate URLs

```python
from urllib.parse import urlparse

def _is_safe_url(self, url: str) -> bool:
    try:
        parsed = urlparse(url)
        # Only allow http/https
        if parsed.scheme not in ("http", "https"):
            return False
        # Require a host
        if not parsed.netloc:
            return False
        # Block localhost/internal IPs (SSRF prevention)
        host = parsed.hostname.lower()
        if host in ("localhost", "127.0.0.1", "0.0.0.0"):
            return False
        if host.startswith("192.168.") or host.startswith("10."):
            return False
        return True
    except Exception:
        return False
```

## Secret Handling

### Never Log Secrets

```python
# Bad - exposes secrets in logs
print(f"API key: {api_key}")
logger.info(f"Connecting with token: {token}")

# Good - mask sensitive values
masked_key = api_key[:4] + "****" if api_key else "None"
print(f"API key: {masked_key}")
```

### Don't Store Secrets in Memory

```python
# Avoid keeping secrets in instance variables
class BadPlugin(BasePlugin):
    def __init__(self):
        self.api_key = None  # Don't do this

# Better - fetch secrets when needed
class GoodPlugin(BasePlugin):
    async def _get_api_key(self) -> str:
        """Fetch API key from secure storage."""
        return await self.env.get("API_KEY")
```

### Use Short-Lived Credentials

```python
# Request minimal, time-limited tokens
token = await self.client.create_scoped_token(
    scope="read:project:123",
    ttl_minutes=5,  # Short expiration
)

# Use the token
async with self._make_request(token) as response:
    return await response.json()
# Token expires automatically
```

## Error Handling

### Don't Expose Internal Details

```python
# Bad - leaks internal information
except DatabaseError as e:
    return f"Database error: {e}"  # Exposes schema/query details

# Good - generic error message
except DatabaseError:
    logger.exception("Database error")  # Log details internally
    return "Error: Unable to process request"
```

### Handle Permission Errors

```python
async def handle_save(self, args: dict) -> str:
    try:
        await self.memory.remember(
            content=args["content"],
            type="fact",
        )
        return "Saved successfully"
    except PermissionError:
        return "Error: Plugin lacks permission to write memories"
    except Exception:
        return "Error: Failed to save"
```

## Network Security

### Validate External Requests

If your plugin makes external API calls:

```python
import aiohttp

async def _fetch_external(self, url: str) -> dict:
    # Validate URL first
    if not self._is_safe_url(url):
        raise ValueError("Invalid URL")

    async with aiohttp.ClientSession() as session:
        async with session.get(
            url,
            timeout=aiohttp.ClientTimeout(total=10),  # Timeout
            allow_redirects=False,  # Prevent redirect attacks
        ) as response:
            # Validate response size
            if int(response.headers.get("content-length", 0)) > 1_000_000:
                raise ValueError("Response too large")
            return await response.json()
```

### Use HTTPS

Always prefer HTTPS for external connections:

```python
if not url.startswith("https://"):
    return "Error: HTTPS required for external requests"
```

## Testing Security

### Test Permission Boundaries

```python
@pytest.mark.asyncio
async def test_respects_scope_limitations(plugin, services):
    """Test plugin fails gracefully without write scope."""
    # Initialize with read-only scope
    await plugin.initialize({
        "scopes": ["memory:read"],
    }, services)

    # Attempt write should fail gracefully
    result = await plugin.handle_save({"content": "test"})
    assert "permission" in result.lower() or "error" in result.lower()
```

### Test Input Validation

```python
@pytest.mark.asyncio
async def test_rejects_path_traversal(plugin, services):
    """Test plugin blocks path traversal."""
    await plugin.initialize({}, services)

    result = await plugin.handle_read_file({
        "path": "../../../etc/passwd"
    })

    assert "error" in result.lower()
    assert "passwd" not in result  # File content not leaked
```

## Security Checklist

Before publishing your plugin:

- [ ] Request only necessary scopes
- [ ] Validate all input parameters
- [ ] Sanitize file paths
- [ ] Validate URLs before fetching
- [ ] Never log secrets
- [ ] Use HTTPS for external calls
- [ ] Set reasonable timeouts
- [ ] Handle errors without exposing internals
- [ ] Test permission boundary behavior
- [ ] Test with malicious input

## Reporting Vulnerabilities

Found a security issue in the SDK or a plugin?

- SDK issues: security@flukebase.com
- Plugin issues: Contact the plugin author
- For urgent issues, include "SECURITY" in the subject

---

Previous: [Best Practices](best-practices.md) | Back to: [Documentation Index](index.md)
