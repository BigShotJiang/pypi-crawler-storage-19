# Plugin Development Tutorial

This tutorial covers everything you need to know about building FlukeBase plugins, from basic concepts to advanced patterns.

## The BasePlugin Class

All plugins must inherit from `BasePlugin`, which provides the core plugin interface:

```python
from abc import ABC, abstractmethod
from flukebase_sdk import BasePlugin, PluginMetadata, ToolDefinition


class BasePlugin(ABC):
    """Abstract base class for all FlukeBase plugins."""

    @abstractmethod
    def get_metadata(self) -> PluginMetadata:
        """Return metadata describing this plugin."""
        pass

    @abstractmethod
    def get_tools(self) -> list[ToolDefinition]:
        """Return list of tools provided by this plugin."""
        pass

    async def initialize(self, config: dict, services: dict) -> None:
        """Initialize the plugin with configuration and services."""
        pass

    async def shutdown(self) -> None:
        """Clean up resources when the plugin is unloaded."""
        pass
```

### Key Properties and Methods

| Method/Property | Description |
|-----------------|-------------|
| `get_metadata()` | Returns plugin metadata (abstract) |
| `get_tools()` | Returns tool definitions (abstract) |
| `initialize()` | Called once when plugin loads |
| `shutdown()` | Called when plugin unloads |
| `is_initialized` | Property: True if initialized |
| `get_service(name)` | Get a shared service by name |
| `get_config_value(key, default)` | Get a config value |
| `validate_scope(required, token_scopes)` | Check token scope |

## PluginMetadata Configuration

The `PluginMetadata` dataclass describes your plugin:

```python
from flukebase_sdk import PluginMetadata, PluginType, PluginMaturity


metadata = PluginMetadata(
    # Required fields
    name="my-plugin",              # Unique identifier (kebab-case)
    display_name="My Plugin",      # Human-readable name
    version="1.0.0",               # Semantic version
    description="What this plugin does",
    plugin_type=PluginType.TOOL,   # Plugin type
    maturity=PluginMaturity.MVP,   # Maturity level

    # Optional fields
    author="Your Name",
    homepage="https://github.com/you/my-plugin",
    required_scopes=["read", "write"],  # OAuth scopes needed
    configuration_schema={},            # JSON Schema for config
    features={"feature_x": True},       # Feature flags
    dependencies=["other-plugin"],      # Plugin dependencies
)
```

### PluginType Enum

Choose the type that best describes your plugin:

| Type | Value | Description |
|------|-------|-------------|
| `INTEGRATION` | `"integration"` | Connects to external services (Slack, GitHub, etc.) |
| `TOOL` | `"tool"` | Provides utility tools |
| `AI_PROVIDER` | `"ai_provider"` | Integrates AI/LLM providers |

```python
from flukebase_sdk import PluginType

# Examples
PluginType.INTEGRATION  # For service integrations
PluginType.TOOL         # For utility tools
PluginType.AI_PROVIDER  # For AI service integrations
```

### PluginMaturity Enum

Indicate the stability level of your plugin:

| Level | Value | Description |
|-------|-------|-------------|
| `CONCEPTUAL` | `"conceptual"` | Idea phase, not fully functional |
| `MVP` | `"mvp"` | Basic functionality, limited testing |
| `BETA` | `"beta"` | Feature complete, testing in progress |
| `PRODUCTION` | `"production"` | Full featured, tested, stable |

```python
from flukebase_sdk import PluginMaturity

# Progress through maturity levels
PluginMaturity.CONCEPTUAL   # Early development
PluginMaturity.MVP          # Minimum viable
PluginMaturity.BETA         # Feature complete
PluginMaturity.PRODUCTION   # Production ready
```

## Implementing get_tools()

The `get_tools()` method returns a list of `ToolDefinition` objects that describe the tools your plugin provides:

```python
from flukebase_sdk import ToolDefinition, ToolAnnotations


def get_tools(self) -> list[ToolDefinition]:
    return [
        ToolDefinition(
            name="my_plugin_action",  # Tool name (prefix with plugin name)
            description="Performs an action",
            input_schema={
                "type": "object",
                "properties": {
                    "param1": {
                        "type": "string",
                        "description": "First parameter",
                    },
                    "param2": {
                        "type": "integer",
                        "description": "Second parameter",
                        "default": 10,
                    },
                },
                "required": ["param1"],
            },
            handler_method="handle_action",  # Method to call
            annotations=ToolAnnotations(     # Optional behavior hints
                read_only=False,
                destructive=False,
                idempotent=True,
                open_world=False,
            ),
        ),
    ]
```

### Input Schema (JSON Schema)

The `input_schema` uses JSON Schema format to define parameters:

```python
input_schema = {
    "type": "object",
    "properties": {
        # String parameter
        "name": {
            "type": "string",
            "description": "User's name",
            "minLength": 1,
            "maxLength": 100,
        },

        # Integer parameter with constraints
        "count": {
            "type": "integer",
            "description": "Number of items",
            "minimum": 1,
            "maximum": 100,
            "default": 10,
        },

        # Boolean parameter
        "enabled": {
            "type": "boolean",
            "description": "Whether feature is enabled",
            "default": True,
        },

        # Enum parameter
        "status": {
            "type": "string",
            "description": "Current status",
            "enum": ["pending", "active", "completed"],
        },

        # Array parameter
        "tags": {
            "type": "array",
            "description": "List of tags",
            "items": {"type": "string"},
        },

        # Nested object
        "options": {
            "type": "object",
            "description": "Additional options",
            "properties": {
                "verbose": {"type": "boolean"},
                "timeout": {"type": "integer"},
            },
        },
    },
    "required": ["name"],  # Required parameters
}
```

## Handling Tool Calls

For each tool, implement a handler method:

```python
class MyPlugin(BasePlugin):
    def get_tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="my_plugin_process",
                description="Process some data",
                input_schema={
                    "type": "object",
                    "properties": {
                        "data": {"type": "string"},
                        "options": {
                            "type": "object",
                            "properties": {
                                "format": {"type": "string", "default": "json"},
                            },
                        },
                    },
                    "required": ["data"],
                },
                handler_method="handle_process",
            ),
        ]

    async def handle_process(self, args: dict) -> str:
        """Handle the process tool call.

        Args:
            args: Dictionary of validated arguments from the tool call.

        Returns:
            Result string (or dict/list that will be JSON serialized).
        """
        data = args["data"]
        options = args.get("options", {})
        output_format = options.get("format", "json")

        # Process the data
        result = self._do_processing(data)

        # Return formatted result
        if output_format == "json":
            return json.dumps(result)
        return str(result)
```

### Handler Return Values

Handlers can return various types:

```python
# String - returned as-is
async def handle_string(self, args: dict) -> str:
    return "Plain text result"

# Dictionary - JSON serialized
async def handle_dict(self, args: dict) -> dict:
    return {"status": "success", "data": [1, 2, 3]}

# List - JSON serialized
async def handle_list(self, args: dict) -> list:
    return ["item1", "item2", "item3"]

# None - empty response
async def handle_void(self, args: dict) -> None:
    # Perform action with no return value
    pass
```

### Error Handling in Handlers

```python
async def handle_risky_operation(self, args: dict) -> str:
    try:
        result = await self._perform_operation(args["input"])
        return f"Success: {result}"

    except ValueError as e:
        # Return user-friendly error message
        return f"Invalid input: {e}"

    except ConnectionError as e:
        # Log and return error
        return f"Connection failed: {e}"

    except Exception as e:
        # Catch-all for unexpected errors
        return f"Unexpected error: {e}"
```

## Plugin Lifecycle

### Initialize Method

The `initialize()` method is called once when your plugin is loaded:

```python
from flukebase_sdk import (
    BasePlugin,
    MemoryStoreProtocol,
    WedoManagerProtocol,
    FlukeBaseClientProtocol,
)


class MyPlugin(BasePlugin):
    def __init__(self):
        super().__init__()
        # Instance variables (set before initialize)
        self.api_client = None
        self.cache = {}

    async def initialize(self, config: dict, services: dict) -> None:
        """Initialize the plugin.

        Args:
            config: Plugin-specific configuration from config file
            services: Shared FlukeBase services dictionary
        """
        # IMPORTANT: Call parent initialize first
        await super().initialize(config, services)

        # Access configuration values
        self.api_url = self.get_config_value("api_url", "https://default.api.com")
        self.api_key = self.get_config_value("api_key")
        self.timeout = self.get_config_value("timeout", 30)

        # Store references to services (with type hints)
        self.memory: MemoryStoreProtocol = self.get_service("memory")
        self.wedo: WedoManagerProtocol = self.get_service("wedo")
        self.client: FlukeBaseClientProtocol = self.get_service("flukebase_client")

        # Initialize your own resources
        self.api_client = await self._create_api_client()

        # Load any cached data
        await self._load_cache()
```

### Shutdown Method

The `shutdown()` method is called when the plugin is unloaded:

```python
async def shutdown(self) -> None:
    """Clean up when plugin is unloaded."""
    # Save any state
    await self._save_cache()

    # Close connections
    if self.api_client:
        await self.api_client.close()

    # Clear resources
    self.cache.clear()

    # IMPORTANT: Call parent shutdown last
    await super().shutdown()
```

## Complete Example Plugin

Here is a complete plugin that demonstrates all concepts:

```python
"""Example plugin demonstrating all SDK features."""

from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
    ToolAnnotations,
    MemoryStoreProtocol,
)


class TaskManagerPlugin(BasePlugin):
    """A plugin for managing tasks with memory integration."""

    def __init__(self):
        super().__init__()
        self.memory: MemoryStoreProtocol | None = None

    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="task-manager",
            display_name="Task Manager",
            version="1.0.0",
            description="Manage tasks with persistent memory",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
            author="FlukeBase Team",
            homepage="https://github.com/flukebase/task-manager-plugin",
            required_scopes=["memory:read", "memory:write"],
            features={
                "persistent_storage": True,
                "task_search": True,
            },
        )

    def get_tools(self) -> list[ToolDefinition]:
        return [
            # Create task tool
            ToolDefinition(
                name="task_manager_create",
                description="Create a new task and store it in memory",
                input_schema={
                    "type": "object",
                    "properties": {
                        "title": {
                            "type": "string",
                            "description": "Task title",
                            "minLength": 1,
                        },
                        "description": {
                            "type": "string",
                            "description": "Task description",
                        },
                        "priority": {
                            "type": "string",
                            "description": "Task priority",
                            "enum": ["low", "medium", "high"],
                            "default": "medium",
                        },
                    },
                    "required": ["title"],
                },
                handler_method="handle_create_task",
                annotations=ToolAnnotations(
                    read_only=False,
                    destructive=False,
                    idempotent=False,
                    open_world=False,
                ),
            ),

            # List tasks tool
            ToolDefinition(
                name="task_manager_list",
                description="List all stored tasks",
                input_schema={
                    "type": "object",
                    "properties": {
                        "priority": {
                            "type": "string",
                            "description": "Filter by priority",
                            "enum": ["low", "medium", "high"],
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum tasks to return",
                            "default": 10,
                            "minimum": 1,
                            "maximum": 100,
                        },
                    },
                },
                handler_method="handle_list_tasks",
                annotations=ToolAnnotations(
                    read_only=True,
                    destructive=False,
                    idempotent=True,
                    open_world=False,
                ),
            ),

            # Search tasks tool
            ToolDefinition(
                name="task_manager_search",
                description="Search tasks by keyword",
                input_schema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query",
                            "minLength": 1,
                        },
                    },
                    "required": ["query"],
                },
                handler_method="handle_search_tasks",
                annotations=ToolAnnotations(
                    read_only=True,
                    destructive=False,
                    idempotent=True,
                    open_world=False,
                ),
            ),
        ]

    async def initialize(self, config: dict, services: dict) -> None:
        """Initialize with memory service."""
        await super().initialize(config, services)
        self.memory = self.get_service("memory")

    async def handle_create_task(self, args: dict) -> str:
        """Create a new task."""
        if not self.memory:
            return "Error: Memory service not available"

        title = args["title"]
        description = args.get("description", "")
        priority = args.get("priority", "medium")

        # Store task in memory
        task_content = f"Task: {title}\nDescription: {description}\nPriority: {priority}"

        await self.memory.remember(
            content=task_content,
            type="fact",
            scope="global",
            tags=["task", f"priority:{priority}"],
        )

        return f"Created task: {title} (priority: {priority})"

    async def handle_list_tasks(self, args: dict) -> str:
        """List stored tasks."""
        if not self.memory:
            return "Error: Memory service not available"

        priority_filter = args.get("priority")
        limit = args.get("limit", 10)

        # Recall tasks from memory
        results = await self.memory.recall(
            query="Task:",
            type="fact",
            limit=limit,
        )

        # Filter by priority if specified
        if priority_filter:
            results = [
                r for r in results
                if f"priority:{priority_filter}" in getattr(r, 'tags', [])
            ]

        if not results:
            return "No tasks found"

        # Format output
        output = [f"Found {len(results)} task(s):"]
        for i, task in enumerate(results, 1):
            output.append(f"{i}. {task.content[:100]}...")

        return "\n".join(output)

    async def handle_search_tasks(self, args: dict) -> str:
        """Search tasks by query."""
        if not self.memory:
            return "Error: Memory service not available"

        query = args["query"]

        results = await self.memory.recall(
            query=query,
            type="fact",
            limit=20,
        )

        # Filter to only task entries
        tasks = [r for r in results if r.content.startswith("Task:")]

        if not tasks:
            return f"No tasks matching '{query}'"

        output = [f"Found {len(tasks)} task(s) matching '{query}':"]
        for task in tasks:
            output.append(f"- {task.content[:80]}...")

        return "\n".join(output)

    async def shutdown(self) -> None:
        """Clean up resources."""
        self.memory = None
        await super().shutdown()
```

## Advanced Topics

### Plugin Dependencies

Declare dependencies on other plugins:

```python
metadata = PluginMetadata(
    name="my-plugin",
    # ... other fields ...
    dependencies=["core-plugin", "auth-plugin"],
)
```

FlukeBase Connect will ensure dependencies are loaded and initialized before your plugin.

### Configuration Schema

Define a JSON Schema for your plugin's configuration:

```python
metadata = PluginMetadata(
    name="my-plugin",
    # ... other fields ...
    configuration_schema={
        "type": "object",
        "properties": {
            "api_url": {
                "type": "string",
                "description": "API endpoint URL",
                "default": "https://api.example.com",
            },
            "timeout": {
                "type": "integer",
                "description": "Request timeout in seconds",
                "minimum": 1,
                "maximum": 300,
                "default": 30,
            },
            "features": {
                "type": "object",
                "properties": {
                    "caching": {"type": "boolean", "default": True},
                    "logging": {"type": "boolean", "default": False},
                },
            },
        },
        "required": ["api_url"],
    },
)
```

### Scope Validation

Validate that the token has required permissions:

```python
async def handle_admin_action(self, args: dict) -> str:
    # Get token scopes from config or context
    token_scopes = self._config.get("token_scopes", [])

    if not self.validate_scope("admin:write", token_scopes):
        return "Error: Insufficient permissions. Requires 'admin:write' scope."

    # Proceed with admin action
    return await self._do_admin_action(args)
```

---

Previous: [Getting Started](getting-started.md) | Next: [Tools API Reference](tools-api.md)
