# Hello World Plugin Example

This example demonstrates a minimal FlukeBase plugin with a single greeting tool.

## Complete Plugin Code

```python
"""Hello World Plugin - A minimal FlukeBase plugin example.

This plugin demonstrates the basic structure of a FlukeBase plugin:
- Defining plugin metadata
- Creating a simple tool
- Implementing a tool handler
"""

from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
    ToolAnnotations,
)


class HelloWorldPlugin(BasePlugin):
    """A simple greeting plugin.

    This plugin provides a single tool that greets users by name.
    It demonstrates the minimal structure required for a FlukeBase plugin.
    """

    def get_metadata(self) -> PluginMetadata:
        """Return plugin metadata.

        The metadata describes the plugin to FlukeBase Connect and
        provides information displayed in the plugin registry.
        """
        return PluginMetadata(
            name="hello-world",
            display_name="Hello World",
            version="1.0.0",
            description="A simple greeting plugin that demonstrates FlukeBase SDK basics",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
            author="FlukeBase Team",
            homepage="https://github.com/flukebase/hello-world-plugin",
        )

    def get_tools(self) -> list[ToolDefinition]:
        """Return the tools this plugin provides.

        Each tool has:
        - A unique name (prefixed with plugin name)
        - A description for the AI to understand
        - An input schema (JSON Schema format)
        - A handler method name
        """
        return [
            ToolDefinition(
                name="hello_world_greet",
                description="Greet someone by name with a friendly message",
                input_schema={
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "The name of the person to greet",
                        },
                        "enthusiasm": {
                            "type": "string",
                            "description": "Level of enthusiasm for the greeting",
                            "enum": ["low", "medium", "high"],
                            "default": "medium",
                        },
                    },
                    "required": ["name"],
                },
                handler_method="handle_greet",
                annotations=ToolAnnotations(
                    read_only=True,       # This tool only returns data
                    destructive=False,    # No data is modified
                    idempotent=True,      # Same input = same output
                    open_world=False,     # No external API calls
                ),
            ),
        ]

    async def handle_greet(self, args: dict) -> str:
        """Handle the greet tool call.

        Args:
            args: Dictionary containing validated parameters:
                - name (str): Required, the name to greet
                - enthusiasm (str): Optional, greeting enthusiasm level

        Returns:
            A greeting message string.
        """
        name = args.get("name", "World")
        enthusiasm = args.get("enthusiasm", "medium")

        # Generate greeting based on enthusiasm level
        if enthusiasm == "low":
            greeting = f"Hello, {name}."
        elif enthusiasm == "high":
            greeting = f"Hello, {name}! Great to meet you! Welcome to FlukeBase!"
        else:  # medium
            greeting = f"Hello, {name}! Welcome to FlukeBase."

        return greeting
```

## Project Structure

```
hello-world-plugin/
    src/
        hello_world/
            __init__.py
            plugin.py
    tests/
        __init__.py
        test_plugin.py
    pyproject.toml
    README.md
```

## Package Files

### src/hello_world/__init__.py

```python
"""Hello World plugin package."""

from hello_world.plugin import HelloWorldPlugin

__all__ = ["HelloWorldPlugin"]
```

### pyproject.toml

```toml
[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[project]
name = "flukebase-hello-world"
version = "1.0.0"
description = "A simple greeting plugin for FlukeBase"
readme = "README.md"
requires-python = ">=3.11"
license = {text = "MIT"}
authors = [
    {name = "Your Name", email = "you@example.com"},
]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]
dependencies = [
    "flukebase-sdk>=0.1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
]

[project.urls]
Homepage = "https://github.com/yourusername/hello-world-plugin"
Repository = "https://github.com/yourusername/hello-world-plugin"

[tool.setuptools.packages.find]
where = ["src"]
```

## Test File

### tests/test_plugin.py

```python
"""Tests for HelloWorldPlugin."""

import pytest
from hello_world import HelloWorldPlugin
from flukebase_sdk.testing import create_mock_services


class TestHelloWorldPlugin:
    """Test suite for the Hello World plugin."""

    @pytest.fixture
    def plugin(self):
        """Create plugin instance."""
        return HelloWorldPlugin()

    @pytest.fixture
    def services(self):
        """Create mock services."""
        return create_mock_services()

    def test_metadata(self, plugin):
        """Test plugin metadata is correct."""
        metadata = plugin.get_metadata()

        assert metadata.name == "hello-world"
        assert metadata.display_name == "Hello World"
        assert metadata.version == "1.0.0"

    def test_tools_defined(self, plugin):
        """Test plugin defines the greet tool."""
        tools = plugin.get_tools()

        assert len(tools) == 1
        assert tools[0].name == "hello_world_greet"

    def test_tool_schema(self, plugin):
        """Test tool has correct input schema."""
        tools = plugin.get_tools()
        schema = tools[0].input_schema

        assert schema["type"] == "object"
        assert "name" in schema["properties"]
        assert "name" in schema["required"]

    @pytest.mark.asyncio
    async def test_greet_basic(self, plugin, services):
        """Test basic greeting."""
        await plugin.initialize({}, services)

        result = await plugin.handle_greet({"name": "Alice"})

        assert "Alice" in result
        assert "Hello" in result

    @pytest.mark.asyncio
    async def test_greet_low_enthusiasm(self, plugin, services):
        """Test low enthusiasm greeting."""
        await plugin.initialize({}, services)

        result = await plugin.handle_greet({
            "name": "Bob",
            "enthusiasm": "low",
        })

        assert result == "Hello, Bob."

    @pytest.mark.asyncio
    async def test_greet_high_enthusiasm(self, plugin, services):
        """Test high enthusiasm greeting."""
        await plugin.initialize({}, services)

        result = await plugin.handle_greet({
            "name": "Charlie",
            "enthusiasm": "high",
        })

        assert "Charlie" in result
        assert "Great to meet you" in result

    @pytest.mark.asyncio
    async def test_greet_default_enthusiasm(self, plugin, services):
        """Test default medium enthusiasm."""
        await plugin.initialize({}, services)

        result = await plugin.handle_greet({"name": "Dana"})

        assert "Dana" in result
        assert "Welcome to FlukeBase" in result
        assert "Great to meet you" not in result  # Not high

    @pytest.mark.asyncio
    async def test_plugin_lifecycle(self, plugin, services):
        """Test plugin initializes and shuts down."""
        assert not plugin.is_initialized

        await plugin.initialize({}, services)
        assert plugin.is_initialized

        await plugin.shutdown()
        assert not plugin.is_initialized
```

## Running the Example

### Install Dependencies

```bash
cd hello-world-plugin
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest tests/ -v
```

Expected output:

```
tests/test_plugin.py::TestHelloWorldPlugin::test_metadata PASSED
tests/test_plugin.py::TestHelloWorldPlugin::test_tools_defined PASSED
tests/test_plugin.py::TestHelloWorldPlugin::test_tool_schema PASSED
tests/test_plugin.py::TestHelloWorldPlugin::test_greet_basic PASSED
tests/test_plugin.py::TestHelloWorldPlugin::test_greet_low_enthusiasm PASSED
tests/test_plugin.py::TestHelloWorldPlugin::test_greet_high_enthusiasm PASSED
tests/test_plugin.py::TestHelloWorldPlugin::test_greet_default_enthusiasm PASSED
tests/test_plugin.py::TestHelloWorldPlugin::test_plugin_lifecycle PASSED
```

## Key Concepts Demonstrated

1. **Plugin Metadata**: Defining name, version, type, and maturity
2. **Tool Definition**: Creating a tool with schema and handler
3. **Input Schema**: Using JSON Schema for parameters
4. **Tool Annotations**: Describing tool behavior for AI clients
5. **Handler Method**: Async handler that processes arguments
6. **Testing**: Using mock services and pytest fixtures

## Next Steps

- Add more tools to the plugin
- Use memory service to persist data
- Create an integration plugin (see [Integration Plugin Example](integration-plugin.md))

---

Previous: [Best Practices](../best-practices.md) | Next: [Integration Plugin Example](integration-plugin.md)
