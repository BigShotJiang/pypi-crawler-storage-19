# Integration Plugin Example

This example demonstrates a complete integration plugin that connects to an external API, uses FlukeBase services for persistence, and follows best practices.

## Overview

We will build a "Bookmark Manager" plugin that:

- Connects to a bookmark storage API
- Stores bookmark metadata in FlukeBase memory
- Creates tasks for bookmarks to review
- Uses proper error handling and testing

## Complete Plugin Code

### src/bookmark_manager/plugin.py

```python
"""Bookmark Manager Plugin - An integration plugin example.

This plugin demonstrates:
- External API integration
- Using multiple FlukeBase services
- Configuration management
- Comprehensive error handling
- Multiple related tools
"""

from typing import Any
from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
    ToolAnnotations,
    MemoryStoreProtocol,
    WedoManagerProtocol,
)


class BookmarkManagerPlugin(BasePlugin):
    """A plugin for managing bookmarks with FlukeBase integration.

    This plugin provides tools to:
    - Save bookmarks with tags and notes
    - Search bookmarks by keyword or tag
    - Create review tasks for bookmarks
    - List recent bookmarks

    Configuration:
        max_bookmarks: Maximum bookmarks to store (default: 1000)
        auto_create_tasks: Automatically create review tasks (default: False)
    """

    def __init__(self) -> None:
        super().__init__()
        self.memory: MemoryStoreProtocol | None = None
        self.wedo: WedoManagerProtocol | None = None
        self.max_bookmarks: int = 1000
        self.auto_create_tasks: bool = False

    def get_metadata(self) -> PluginMetadata:
        """Return plugin metadata."""
        return PluginMetadata(
            name="bookmark-manager",
            display_name="Bookmark Manager",
            version="1.0.0",
            description="Manage bookmarks with notes, tags, and review tasks",
            plugin_type=PluginType.INTEGRATION,
            maturity=PluginMaturity.BETA,
            author="FlukeBase Team",
            homepage="https://github.com/flukebase/bookmark-manager-plugin",
            required_scopes=["memory:read", "memory:write", "wedo:write"],
            configuration_schema={
                "type": "object",
                "properties": {
                    "max_bookmarks": {
                        "type": "integer",
                        "description": "Maximum bookmarks to store",
                        "default": 1000,
                        "minimum": 100,
                        "maximum": 10000,
                    },
                    "auto_create_tasks": {
                        "type": "boolean",
                        "description": "Automatically create review tasks for new bookmarks",
                        "default": False,
                    },
                },
            },
            features={
                "bookmark_storage": True,
                "tag_search": True,
                "task_integration": True,
            },
        )

    def get_tools(self) -> list[ToolDefinition]:
        """Return the tools this plugin provides."""
        return [
            # Save bookmark tool
            ToolDefinition(
                name="bookmark_save",
                description=(
                    "Save a bookmark with URL, title, and optional notes/tags. "
                    "The bookmark is stored in FlukeBase memory for later retrieval."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The URL to bookmark",
                            "format": "uri",
                        },
                        "title": {
                            "type": "string",
                            "description": "Title or name for the bookmark",
                        },
                        "notes": {
                            "type": "string",
                            "description": "Optional notes about the bookmark",
                        },
                        "tags": {
                            "type": "array",
                            "description": "Tags for categorization",
                            "items": {"type": "string"},
                            "default": [],
                        },
                        "create_review_task": {
                            "type": "boolean",
                            "description": "Create a WeDo task to review this bookmark",
                            "default": False,
                        },
                    },
                    "required": ["url", "title"],
                },
                handler_method="handle_save_bookmark",
                annotations=ToolAnnotations(
                    read_only=False,
                    destructive=False,
                    idempotent=False,
                    open_world=False,
                ),
            ),

            # Search bookmarks tool
            ToolDefinition(
                name="bookmark_search",
                description=(
                    "Search bookmarks by keyword, tag, or both. "
                    "Returns matching bookmarks with their details."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search keyword to match in title, URL, or notes",
                        },
                        "tag": {
                            "type": "string",
                            "description": "Filter by specific tag",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum results to return",
                            "default": 10,
                            "minimum": 1,
                            "maximum": 50,
                        },
                    },
                },
                handler_method="handle_search_bookmarks",
                annotations=ToolAnnotations(
                    read_only=True,
                    destructive=False,
                    idempotent=True,
                    open_world=False,
                ),
            ),

            # List recent bookmarks tool
            ToolDefinition(
                name="bookmark_list_recent",
                description="List the most recently saved bookmarks",
                input_schema={
                    "type": "object",
                    "properties": {
                        "limit": {
                            "type": "integer",
                            "description": "Number of bookmarks to return",
                            "default": 5,
                            "minimum": 1,
                            "maximum": 20,
                        },
                    },
                },
                handler_method="handle_list_recent",
                annotations=ToolAnnotations(
                    read_only=True,
                    destructive=False,
                    idempotent=True,
                    open_world=False,
                ),
            ),

            # Delete bookmark tool
            ToolDefinition(
                name="bookmark_delete",
                description=(
                    "Delete a bookmark by its ID. "
                    "This action cannot be undone."
                ),
                input_schema={
                    "type": "object",
                    "properties": {
                        "bookmark_id": {
                            "type": "string",
                            "description": "The ID of the bookmark to delete",
                        },
                    },
                    "required": ["bookmark_id"],
                },
                handler_method="handle_delete_bookmark",
                annotations=ToolAnnotations(
                    read_only=False,
                    destructive=True,
                    idempotent=True,
                    open_world=False,
                ),
            ),

            # Create review task tool
            ToolDefinition(
                name="bookmark_create_review_task",
                description="Create a WeDo task to review a specific bookmark",
                input_schema={
                    "type": "object",
                    "properties": {
                        "bookmark_id": {
                            "type": "string",
                            "description": "The ID of the bookmark to review",
                        },
                        "priority": {
                            "type": "string",
                            "description": "Task priority",
                            "enum": ["low", "normal", "high"],
                            "default": "normal",
                        },
                        "notes": {
                            "type": "string",
                            "description": "Additional notes for the review task",
                        },
                    },
                    "required": ["bookmark_id"],
                },
                handler_method="handle_create_review_task",
                annotations=ToolAnnotations(
                    read_only=False,
                    destructive=False,
                    idempotent=False,
                    open_world=False,
                ),
            ),
        ]

    async def initialize(self, config: dict, services: dict) -> None:
        """Initialize the plugin with configuration and services."""
        await super().initialize(config, services)

        # Load configuration
        self.max_bookmarks = self.get_config_value("max_bookmarks", 1000)
        self.auto_create_tasks = self.get_config_value("auto_create_tasks", False)

        # Get service references
        self.memory = self.get_service("memory")
        self.wedo = self.get_service("wedo")

    async def shutdown(self) -> None:
        """Clean up resources."""
        self.memory = None
        self.wedo = None
        await super().shutdown()

    # =========================================================================
    # Tool Handlers
    # =========================================================================

    async def handle_save_bookmark(self, args: dict) -> str:
        """Save a new bookmark."""
        if not self.memory:
            return "Error: Memory service not available"

        # Extract and validate arguments
        url = args.get("url", "").strip()
        title = args.get("title", "").strip()
        notes = args.get("notes", "").strip()
        tags = args.get("tags", [])
        create_task = args.get("create_review_task", self.auto_create_tasks)

        if not url:
            return "Error: URL is required"

        if not title:
            return "Error: Title is required"

        if not self._is_valid_url(url):
            return f"Error: Invalid URL format: {url}"

        # Build bookmark content
        bookmark_content = self._format_bookmark(url, title, notes)

        # Prepare tags (add 'bookmark' tag)
        all_tags = ["bookmark"] + [t.lower().strip() for t in tags if t.strip()]

        # Store in memory
        try:
            memory = await self.memory.remember(
                content=bookmark_content,
                type="fact",
                scope="global",
                tags=all_tags,
                references={"url": url, "title": title},
            )

            bookmark_id = memory.id
            result_parts = [f"Saved bookmark: {title}", f"ID: {bookmark_id}"]

            # Create review task if requested
            if create_task and self.wedo:
                task_result = await self._create_review_task(
                    bookmark_id=bookmark_id,
                    title=title,
                    url=url,
                    priority="normal",
                )
                if task_result:
                    result_parts.append(f"Created review task: {task_result}")

            return "\n".join(result_parts)

        except Exception as e:
            return f"Error saving bookmark: {e}"

    async def handle_search_bookmarks(self, args: dict) -> str:
        """Search for bookmarks."""
        if not self.memory:
            return "Error: Memory service not available"

        query = args.get("query", "")
        tag = args.get("tag", "")
        limit = min(args.get("limit", 10), 50)

        # Build search query
        search_query = query if query else "bookmark"

        try:
            results = await self.memory.recall(
                query=search_query,
                type="fact",
                scope="global",
                limit=limit * 2,  # Fetch extra for filtering
            )

            # Filter to bookmarks and by tag if specified
            bookmarks = []
            for result in results:
                if "bookmark" not in getattr(result, "tags", []):
                    continue
                if tag and tag.lower() not in [t.lower() for t in result.tags]:
                    continue
                bookmarks.append(result)

                if len(bookmarks) >= limit:
                    break

            if not bookmarks:
                filter_desc = []
                if query:
                    filter_desc.append(f"query '{query}'")
                if tag:
                    filter_desc.append(f"tag '{tag}'")
                filter_str = " and ".join(filter_desc) if filter_desc else "any criteria"
                return f"No bookmarks found matching {filter_str}"

            # Format results
            output = [f"Found {len(bookmarks)} bookmark(s):"]
            for i, bm in enumerate(bookmarks, 1):
                tags_str = ", ".join(t for t in bm.tags if t != "bookmark")
                output.append(f"\n{i}. {bm.content[:100]}...")
                output.append(f"   ID: {bm.id}")
                if tags_str:
                    output.append(f"   Tags: {tags_str}")

            return "\n".join(output)

        except Exception as e:
            return f"Error searching bookmarks: {e}"

    async def handle_list_recent(self, args: dict) -> str:
        """List recent bookmarks."""
        if not self.memory:
            return "Error: Memory service not available"

        limit = min(args.get("limit", 5), 20)

        try:
            # Search for recent bookmarks
            results = await self.memory.recall(
                query="bookmark",
                type="fact",
                scope="global",
                limit=limit * 2,
            )

            # Filter to bookmarks only
            bookmarks = [
                r for r in results
                if "bookmark" in getattr(r, "tags", [])
            ][:limit]

            if not bookmarks:
                return "No bookmarks saved yet"

            output = [f"Recent bookmarks ({len(bookmarks)}):"]
            for i, bm in enumerate(bookmarks, 1):
                # Parse bookmark content
                lines = bm.content.split("\n")
                title = lines[0].replace("Bookmark: ", "") if lines else "Untitled"
                output.append(f"{i}. {title} (ID: {bm.id})")

            return "\n".join(output)

        except Exception as e:
            return f"Error listing bookmarks: {e}"

    async def handle_delete_bookmark(self, args: dict) -> str:
        """Delete a bookmark."""
        if not self.memory:
            return "Error: Memory service not available"

        bookmark_id = args.get("bookmark_id", "").strip()

        if not bookmark_id:
            return "Error: bookmark_id is required"

        try:
            result = await self.memory.forget(id=bookmark_id, scope="global")

            if result.get("success"):
                return f"Deleted bookmark: {bookmark_id}"
            else:
                return f"Bookmark not found: {bookmark_id}"

        except Exception as e:
            return f"Error deleting bookmark: {e}"

    async def handle_create_review_task(self, args: dict) -> str:
        """Create a review task for a bookmark."""
        if not self.memory:
            return "Error: Memory service not available"

        if not self.wedo:
            return "Error: WeDo service not available"

        bookmark_id = args.get("bookmark_id", "").strip()
        priority = args.get("priority", "normal")
        notes = args.get("notes", "")

        if not bookmark_id:
            return "Error: bookmark_id is required"

        # Verify bookmark exists
        results = await self.memory.recall(
            query=bookmark_id,
            type="fact",
            limit=1,
        )

        bookmark = None
        for r in results:
            if r.id == bookmark_id:
                bookmark = r
                break

        if not bookmark:
            return f"Bookmark not found: {bookmark_id}"

        # Extract title from bookmark
        lines = bookmark.content.split("\n")
        title = lines[0].replace("Bookmark: ", "") if lines else "Unknown"

        try:
            task_id = await self._create_review_task(
                bookmark_id=bookmark_id,
                title=title,
                url="",
                priority=priority,
                notes=notes,
            )

            if task_id:
                return f"Created review task: {task_id}\nBookmark: {title}"
            else:
                return "Error: Failed to create review task"

        except Exception as e:
            return f"Error creating review task: {e}"

    # =========================================================================
    # Helper Methods
    # =========================================================================

    def _is_valid_url(self, url: str) -> bool:
        """Validate URL format."""
        return url.startswith(("http://", "https://", "ftp://"))

    def _format_bookmark(self, url: str, title: str, notes: str) -> str:
        """Format bookmark for storage."""
        parts = [f"Bookmark: {title}", f"URL: {url}"]
        if notes:
            parts.append(f"Notes: {notes}")
        return "\n".join(parts)

    async def _create_review_task(
        self,
        bookmark_id: str,
        title: str,
        url: str,
        priority: str = "normal",
        notes: str = "",
    ) -> str | None:
        """Create a WeDo task to review a bookmark."""
        if not self.wedo:
            return None

        # Generate task ID
        import uuid
        task_id = f"REVIEW-{uuid.uuid4().hex[:8].upper()}"

        description = f"Review bookmark: {title}"
        if notes:
            description += f"\n{notes}"

        try:
            task = await self.wedo.create_task(
                task_id=task_id,
                description=description,
                priority=priority,
                tags=["bookmark-review", f"bookmark:{bookmark_id}"],
                artifact_path=None,
                remote_url=url if url else None,
            )

            return task.task_id if task else None

        except Exception:
            return None
```

## Test File

### tests/test_bookmark_plugin.py

```python
"""Tests for BookmarkManagerPlugin."""

import pytest
from bookmark_manager import BookmarkManagerPlugin
from flukebase_sdk.testing import (
    create_mock_services,
    MockMemory,
)


class TestBookmarkManagerPlugin:
    """Test suite for Bookmark Manager plugin."""

    @pytest.fixture
    def plugin(self):
        """Create plugin instance."""
        return BookmarkManagerPlugin()

    @pytest.fixture
    def services(self):
        """Create mock services."""
        return create_mock_services()

    @pytest.fixture
    async def initialized_plugin(self, plugin, services):
        """Create and initialize plugin."""
        await plugin.initialize({}, services)
        yield plugin
        await plugin.shutdown()

    # =========================================================================
    # Metadata Tests
    # =========================================================================

    def test_metadata(self, plugin):
        """Test plugin metadata."""
        metadata = plugin.get_metadata()

        assert metadata.name == "bookmark-manager"
        assert metadata.plugin_type.value == "integration"
        assert "memory:read" in metadata.required_scopes

    def test_tools_defined(self, plugin):
        """Test all expected tools are defined."""
        tools = plugin.get_tools()
        tool_names = [t.name for t in tools]

        assert "bookmark_save" in tool_names
        assert "bookmark_search" in tool_names
        assert "bookmark_list_recent" in tool_names
        assert "bookmark_delete" in tool_names

    # =========================================================================
    # Save Bookmark Tests
    # =========================================================================

    @pytest.mark.asyncio
    async def test_save_bookmark_success(self, initialized_plugin, services):
        """Test saving a bookmark."""
        result = await initialized_plugin.handle_save_bookmark({
            "url": "https://example.com",
            "title": "Example Site",
            "notes": "A test bookmark",
            "tags": ["test", "example"],
        })

        assert "Saved bookmark" in result
        assert "Example Site" in result
        assert services["memory"].was_called("remember")

    @pytest.mark.asyncio
    async def test_save_bookmark_missing_url(self, initialized_plugin):
        """Test error when URL is missing."""
        result = await initialized_plugin.handle_save_bookmark({
            "title": "No URL",
        })

        assert "Error" in result
        assert "URL" in result

    @pytest.mark.asyncio
    async def test_save_bookmark_invalid_url(self, initialized_plugin):
        """Test error with invalid URL."""
        result = await initialized_plugin.handle_save_bookmark({
            "url": "not-a-url",
            "title": "Invalid",
        })

        assert "Error" in result
        assert "Invalid URL" in result

    @pytest.mark.asyncio
    async def test_save_bookmark_with_review_task(self, initialized_plugin, services):
        """Test saving bookmark with review task."""
        result = await initialized_plugin.handle_save_bookmark({
            "url": "https://example.com",
            "title": "Review This",
            "create_review_task": True,
        })

        assert "Saved bookmark" in result
        assert services["wedo"].was_called("create_task")

    # =========================================================================
    # Search Tests
    # =========================================================================

    @pytest.mark.asyncio
    async def test_search_bookmarks_empty(self, initialized_plugin, services):
        """Test search with no bookmarks."""
        result = await initialized_plugin.handle_search_bookmarks({
            "query": "test",
        })

        assert "No bookmarks found" in result

    @pytest.mark.asyncio
    async def test_search_bookmarks_with_results(self, initialized_plugin, services):
        """Test search with existing bookmarks."""
        # Add a bookmark to memory
        services["memory"].add_memory(MockMemory(
            id="bm-001",
            content="Bookmark: Test Site\nURL: https://test.com",
            type="fact",
            scope="global",
            tags=["bookmark", "test"],
        ))

        result = await initialized_plugin.handle_search_bookmarks({
            "query": "Test",
        })

        assert "Found" in result
        assert "bm-001" in result

    @pytest.mark.asyncio
    async def test_search_bookmarks_by_tag(self, initialized_plugin, services):
        """Test search filtering by tag."""
        services["memory"].add_memory(MockMemory(
            id="bm-tagged",
            content="Bookmark: Tagged\nURL: https://tagged.com",
            type="fact",
            scope="global",
            tags=["bookmark", "important"],
        ))

        result = await initialized_plugin.handle_search_bookmarks({
            "tag": "important",
        })

        assert "bm-tagged" in result

    # =========================================================================
    # Delete Tests
    # =========================================================================

    @pytest.mark.asyncio
    async def test_delete_bookmark_success(self, initialized_plugin, services):
        """Test deleting a bookmark."""
        services["memory"].add_memory(MockMemory(
            id="delete-me",
            content="Bookmark: Delete Me",
            type="fact",
            tags=["bookmark"],
        ))

        result = await initialized_plugin.handle_delete_bookmark({
            "bookmark_id": "delete-me",
        })

        assert "Deleted" in result
        assert services["memory"].was_called("forget")

    @pytest.mark.asyncio
    async def test_delete_bookmark_not_found(self, initialized_plugin):
        """Test deleting non-existent bookmark."""
        result = await initialized_plugin.handle_delete_bookmark({
            "bookmark_id": "does-not-exist",
        })

        assert "not found" in result

    # =========================================================================
    # Configuration Tests
    # =========================================================================

    @pytest.mark.asyncio
    async def test_config_max_bookmarks(self, plugin, services):
        """Test configuration loading."""
        await plugin.initialize({
            "max_bookmarks": 500,
            "auto_create_tasks": True,
        }, services)

        assert plugin.max_bookmarks == 500
        assert plugin.auto_create_tasks is True

    # =========================================================================
    # Service Unavailability Tests
    # =========================================================================

    @pytest.mark.asyncio
    async def test_handles_missing_memory(self, plugin):
        """Test handling when memory service is unavailable."""
        await plugin.initialize({}, {})  # No services

        result = await plugin.handle_save_bookmark({
            "url": "https://example.com",
            "title": "Test",
        })

        assert "Error" in result
        assert "Memory service" in result
```

## Project Structure

```
bookmark-manager-plugin/
    src/
        bookmark_manager/
            __init__.py
            plugin.py
    tests/
        __init__.py
        test_bookmark_plugin.py
        conftest.py
    pyproject.toml
    README.md
```

## Key Patterns Demonstrated

### 1. Multiple Related Tools

The plugin provides five tools that work together:
- `bookmark_save` - Create bookmarks
- `bookmark_search` - Find bookmarks
- `bookmark_list_recent` - List recent items
- `bookmark_delete` - Remove bookmarks
- `bookmark_create_review_task` - Create tasks

### 2. Service Integration

Using multiple FlukeBase services together:

```python
# Memory for storage
await self.memory.remember(content=..., type="fact", tags=...)

# WeDo for task creation
await self.wedo.create_task(task_id=..., description=...)
```

### 3. Configuration Schema

Defining configurable options:

```python
configuration_schema={
    "type": "object",
    "properties": {
        "max_bookmarks": {"type": "integer", "default": 1000},
        "auto_create_tasks": {"type": "boolean", "default": False},
    },
}
```

### 4. Proper Error Handling

- Validating inputs before processing
- Checking service availability
- Returning user-friendly error messages
- Catching and handling exceptions

### 5. Tool Annotations

Correctly annotating tool behavior:

```python
# Read-only search tool
annotations=ToolAnnotations(read_only=True, idempotent=True)

# Destructive delete tool
annotations=ToolAnnotations(destructive=True)
```

### 6. Comprehensive Testing

- Testing success cases
- Testing error cases
- Testing configuration
- Testing service unavailability
- Using mock services effectively

---

Previous: [Hello World Example](hello-world.md) | Back to: [Documentation Index](../index.md)
