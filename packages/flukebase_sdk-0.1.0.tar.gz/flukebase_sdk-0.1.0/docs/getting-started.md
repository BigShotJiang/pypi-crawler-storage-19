# Getting Started with FlukeBase SDK

This guide walks you through installing the SDK, creating your first plugin, and testing it locally.

## Prerequisites

Before you begin, ensure you have:

- **Python 3.11 or higher** - The SDK uses modern Python features
- **pip** - Python package installer
- **A code editor** - VS Code, PyCharm, or your preferred IDE

Verify your Python version:

```bash
python --version
# Should output: Python 3.11.x or higher
```

## Installation

Install the FlukeBase SDK from PyPI:

```bash
pip install flukebase-sdk
```

For development, install with testing dependencies:

```bash
pip install flukebase-sdk[dev]
```

### Verify Installation

```python
import flukebase_sdk
print(flukebase_sdk.__version__)
# Output: 0.1.0
```

## Creating Your First Plugin

Let us create a simple plugin step by step.

### Step 1: Create Project Structure

```bash
mkdir my-flukebase-plugin
cd my-flukebase-plugin

# Create package structure
mkdir -p src/my_plugin
touch src/my_plugin/__init__.py
touch src/my_plugin/plugin.py
```

Your directory structure should look like:

```
my-flukebase-plugin/
    src/
        my_plugin/
            __init__.py
            plugin.py
    pyproject.toml
```

### Step 2: Define Plugin Metadata

Open `src/my_plugin/plugin.py` and add:

```python
"""My first FlukeBase plugin."""

from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
)


class MyPlugin(BasePlugin):
    """A simple example plugin."""

    def get_metadata(self) -> PluginMetadata:
        """Return plugin metadata."""
        return PluginMetadata(
            name="my-plugin",
            display_name="My Plugin",
            version="1.0.0",
            description="My first FlukeBase plugin",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
            author="Your Name",
            homepage="https://github.com/yourusername/my-plugin",
        )

    def get_tools(self) -> list[ToolDefinition]:
        """Return the tools this plugin provides."""
        return [
            ToolDefinition(
                name="my_plugin_echo",
                description="Echo back the provided message",
                input_schema={
                    "type": "object",
                    "properties": {
                        "message": {
                            "type": "string",
                            "description": "The message to echo back",
                        }
                    },
                    "required": ["message"],
                },
                handler_method="handle_echo",
            )
        ]

    async def handle_echo(self, args: dict) -> str:
        """Handle the echo tool call."""
        message = args.get("message", "")
        return f"Echo: {message}"
```

### Step 3: Export the Plugin

Update `src/my_plugin/__init__.py`:

```python
"""My FlukeBase plugin package."""

from my_plugin.plugin import MyPlugin

__all__ = ["MyPlugin"]
```

### Step 4: Create pyproject.toml

```toml
[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[project]
name = "my-flukebase-plugin"
version = "1.0.0"
description = "My first FlukeBase plugin"
readme = "README.md"
requires-python = ">=3.11"
dependencies = [
    "flukebase-sdk>=0.1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0",
    "pytest-asyncio>=0.21",
]

[tool.setuptools.packages.find]
where = ["src"]
```

## Running and Testing Locally

### Create a Test File

Create `tests/test_plugin.py`:

```python
"""Tests for MyPlugin."""

import pytest
from my_plugin import MyPlugin
from flukebase_sdk.testing import create_mock_services


@pytest.mark.asyncio
async def test_plugin_metadata():
    """Test that plugin metadata is correct."""
    plugin = MyPlugin()
    metadata = plugin.get_metadata()

    assert metadata.name == "my-plugin"
    assert metadata.version == "1.0.0"


@pytest.mark.asyncio
async def test_plugin_has_tools():
    """Test that plugin provides tools."""
    plugin = MyPlugin()
    tools = plugin.get_tools()

    assert len(tools) == 1
    assert tools[0].name == "my_plugin_echo"


@pytest.mark.asyncio
async def test_echo_tool():
    """Test the echo tool handler."""
    plugin = MyPlugin()
    services = create_mock_services()

    await plugin.initialize({}, services)

    result = await plugin.handle_echo({"message": "Hello!"})
    assert result == "Echo: Hello!"
```

### Run Tests

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest tests/ -v
```

## Using the Cookiecutter Template

For a faster start, use the FlukeBase plugin cookiecutter template:

```bash
# Install cookiecutter
pip install cookiecutter

# Create a new plugin from template
cookiecutter gh:flukebase/flukebase-plugin-template
```

The template will prompt you for:

- Plugin name
- Author name
- Description
- Plugin type

And generate a complete project structure with:

- Pre-configured pyproject.toml
- Example plugin code
- Test scaffolding
- CI/CD configuration
- Documentation templates

## Plugin Lifecycle

Understanding how plugins are loaded helps you write better plugins:

```
1. Discovery    - FlukeBase Connect finds your plugin
2. Instantiation - Plugin class is instantiated
3. Initialization - initialize(config, services) is called
4. Operation    - Tools are called as needed
5. Shutdown     - shutdown() is called when unloading
```

### Lifecycle Methods

```python
class MyPlugin(BasePlugin):
    async def initialize(self, config: dict, services: dict) -> None:
        """Called once when plugin is loaded.

        Use this to:
        - Store configuration values
        - Initialize connections
        - Set up resources

        Args:
            config: Plugin-specific configuration
            services: Shared FlukeBase services
        """
        await super().initialize(config, services)

        # Access configuration
        self.api_url = self.get_config_value("api_url", "https://api.example.com")

        # Access services
        self.memory = self.get_service("memory")

    async def shutdown(self) -> None:
        """Called when plugin is unloaded.

        Use this to:
        - Close connections
        - Save state
        - Clean up resources
        """
        await super().shutdown()
        # Your cleanup code here
```

## Next Steps

Now that you have a working plugin, explore:

1. **[Plugin Development Tutorial](plugin-development.md)** - Deep dive into plugin architecture
2. **[Tools API Reference](tools-api.md)** - Learn about tool definitions and schemas
3. **[Services Guide](services.md)** - Use FlukeBase services in your plugin
4. **[Testing Guide](testing.md)** - Write comprehensive tests

---

Previous: [Index](index.md) | Next: [Plugin Development Tutorial](plugin-development.md)
