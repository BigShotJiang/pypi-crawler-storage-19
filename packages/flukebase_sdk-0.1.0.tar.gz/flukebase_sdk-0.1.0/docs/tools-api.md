# Tools API Reference

This reference documents the classes and patterns for defining tools in FlukeBase plugins.

## ToolDefinition Class

The `ToolDefinition` class describes a single tool provided by a plugin:

```python
from dataclasses import dataclass
from flukebase_sdk import ToolDefinition, ToolAnnotations


@dataclass
class ToolDefinition:
    """Definition of a single tool provided by a plugin."""

    name: str                              # Unique tool name
    description: str                       # Description for AI understanding
    input_schema: dict                     # JSON Schema for parameters
    handler_method: str                    # Method name on plugin class
    annotations: ToolAnnotations | None    # Behavioral hints (auto-inferred if None)
```

### Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | `str` | Yes | Unique identifier for the tool |
| `description` | `str` | Yes | Human/AI-readable description |
| `input_schema` | `dict` | Yes | JSON Schema defining parameters |
| `handler_method` | `str` | Yes | Name of the handler method |
| `annotations` | `ToolAnnotations` | No | Behavioral hints (auto-inferred) |

### Example

```python
from flukebase_sdk import ToolDefinition, ToolAnnotations


tool = ToolDefinition(
    name="my_plugin_fetch_data",
    description="Fetch data from the configured API endpoint",
    input_schema={
        "type": "object",
        "properties": {
            "endpoint": {
                "type": "string",
                "description": "API endpoint path",
            },
            "params": {
                "type": "object",
                "description": "Query parameters",
                "additionalProperties": {"type": "string"},
            },
        },
        "required": ["endpoint"],
    },
    handler_method="handle_fetch_data",
    annotations=ToolAnnotations(
        read_only=True,
        destructive=False,
        idempotent=True,
        open_world=True,
    ),
)
```

### MCP Format Conversion

Tools are converted to MCP (Model Context Protocol) format for AI clients:

```python
tool = ToolDefinition(
    name="example_tool",
    description="An example tool",
    input_schema={"type": "object", "properties": {}},
    handler_method="handle_example",
)

# Convert to MCP format
mcp_format = tool.to_mcp_format()
# Returns:
# {
#     "name": "example_tool",
#     "description": "An example tool",
#     "inputSchema": {"type": "object", "properties": {}},
#     "annotations": {
#         "readOnlyHint": False,
#         "destructiveHint": False,
#         "idempotentHint": False,
#         "openWorldHint": True,
#     }
# }
```

## Input Schema (JSON Schema Format)

The `input_schema` field uses [JSON Schema](https://json-schema.org/) to define tool parameters.

### Basic Structure

```python
input_schema = {
    "type": "object",
    "properties": {
        # Define each parameter here
    },
    "required": ["param1", "param2"],  # List required params
}
```

### Data Types

#### String Parameters

```python
"name": {
    "type": "string",
    "description": "User's full name",
}

# With constraints
"email": {
    "type": "string",
    "description": "Email address",
    "format": "email",
    "minLength": 5,
    "maxLength": 255,
}

# With pattern
"phone": {
    "type": "string",
    "description": "Phone number",
    "pattern": "^\\+?[0-9]{10,15}$",
}

# Enum (fixed values)
"status": {
    "type": "string",
    "description": "Current status",
    "enum": ["pending", "active", "completed", "cancelled"],
}
```

#### Integer Parameters

```python
"count": {
    "type": "integer",
    "description": "Number of items",
}

# With constraints
"age": {
    "type": "integer",
    "description": "User age",
    "minimum": 0,
    "maximum": 150,
}

# With default
"limit": {
    "type": "integer",
    "description": "Maximum results",
    "default": 10,
    "minimum": 1,
    "maximum": 100,
}
```

#### Number Parameters (Float)

```python
"price": {
    "type": "number",
    "description": "Item price",
    "minimum": 0,
}

"percentage": {
    "type": "number",
    "description": "Percentage value",
    "minimum": 0,
    "maximum": 100,
}
```

#### Boolean Parameters

```python
"enabled": {
    "type": "boolean",
    "description": "Whether feature is enabled",
    "default": True,
}

"verbose": {
    "type": "boolean",
    "description": "Enable verbose output",
    "default": False,
}
```

#### Array Parameters

```python
# Simple array
"tags": {
    "type": "array",
    "description": "List of tags",
    "items": {"type": "string"},
}

# Array with constraints
"ids": {
    "type": "array",
    "description": "List of IDs to process",
    "items": {"type": "integer"},
    "minItems": 1,
    "maxItems": 100,
    "uniqueItems": True,
}

# Array of objects
"users": {
    "type": "array",
    "description": "List of users",
    "items": {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "email": {"type": "string"},
        },
        "required": ["name"],
    },
}
```

#### Object Parameters

```python
# Nested object
"config": {
    "type": "object",
    "description": "Configuration options",
    "properties": {
        "timeout": {"type": "integer", "default": 30},
        "retries": {"type": "integer", "default": 3},
        "verbose": {"type": "boolean", "default": False},
    },
}

# Object with additional properties
"metadata": {
    "type": "object",
    "description": "Custom metadata key-value pairs",
    "additionalProperties": {"type": "string"},
}
```

### Complete Schema Example

```python
input_schema = {
    "type": "object",
    "properties": {
        "query": {
            "type": "string",
            "description": "Search query",
            "minLength": 1,
            "maxLength": 500,
        },
        "filters": {
            "type": "object",
            "description": "Search filters",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["active", "inactive", "all"],
                    "default": "all",
                },
                "date_range": {
                    "type": "object",
                    "properties": {
                        "start": {"type": "string", "format": "date"},
                        "end": {"type": "string", "format": "date"},
                    },
                },
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                },
            },
        },
        "pagination": {
            "type": "object",
            "properties": {
                "page": {"type": "integer", "minimum": 1, "default": 1},
                "per_page": {"type": "integer", "minimum": 1, "maximum": 100, "default": 20},
            },
        },
        "include_metadata": {
            "type": "boolean",
            "default": False,
        },
    },
    "required": ["query"],
}
```

## ToolAnnotations Class

The `ToolAnnotations` class provides behavioral hints that help AI clients make safer decisions:

```python
from dataclasses import dataclass


@dataclass
class ToolAnnotations:
    """MCP tool behavior hints."""

    read_only: bool = False      # Tool only reads data
    destructive: bool = False    # Tool may delete/permanently modify data
    idempotent: bool = False     # Safe to retry without side effects
    open_world: bool = True      # May interact with external systems
```

### Fields

| Field | Default | Description |
|-------|---------|-------------|
| `read_only` | `False` | Tool only reads data, no side effects |
| `destructive` | `False` | Tool may delete or permanently modify data |
| `idempotent` | `False` | Safe to retry without different results |
| `open_world` | `True` | May interact with external systems/APIs |

### Usage Examples

```python
from flukebase_sdk import ToolAnnotations

# Read-only tool (safe to call anytime)
annotations_read = ToolAnnotations(
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
)

# Destructive tool (AI should confirm before calling)
annotations_delete = ToolAnnotations(
    read_only=False,
    destructive=True,
    idempotent=False,
    open_world=False,
)

# External API tool (may have network effects)
annotations_api = ToolAnnotations(
    read_only=False,
    destructive=False,
    idempotent=True,
    open_world=True,
)
```

### Auto-Inference from Tool Names

If `annotations` is not provided, they are automatically inferred from the tool name:

```python
# Read-only patterns (auto-detected)
# list_, get_, show_, search_, find_
tool = ToolDefinition(
    name="my_plugin_list_items",  # Auto: read_only=True
    ...
)

# Destructive patterns (auto-detected)
# delete_, remove_, drop_, destroy_
tool = ToolDefinition(
    name="my_plugin_delete_item",  # Auto: destructive=True
    ...
)

# Idempotent patterns (auto-detected)
# Includes all read-only patterns plus update_, set_
tool = ToolDefinition(
    name="my_plugin_update_config",  # Auto: idempotent=True
    ...
)

# Open world patterns (auto-detected)
# Names containing: fb_, env_pull, webhook_, sandbox_, gateway_
tool = ToolDefinition(
    name="my_plugin_webhook_send",  # Auto: open_world=True
    ...
)
```

### Inference Patterns Reference

| Pattern Prefix | Inferred Annotation |
|----------------|---------------------|
| `list_`, `get_`, `show_`, `search_`, `find_` | `read_only=True` |
| `delete_`, `remove_`, `drop_`, `destroy_` | `destructive=True` |
| `mem_remember`, `wedo_update`, `env_pull`, `fb_sync` | `idempotent=True` |
| `fb_`, `webhook_`, `sandbox_`, `gateway_` | `open_world=True` |

### MCP Format Conversion

Annotations are converted to MCP format with camelCase keys:

```python
annotations = ToolAnnotations(
    read_only=True,
    destructive=False,
    idempotent=True,
    open_world=False,
)

mcp_format = annotations.to_mcp_format()
# Returns:
# {
#     "readOnlyHint": True,
#     "destructiveHint": False,
#     "idempotentHint": True,
#     "openWorldHint": False,
# }
```

## ResourceDefinition Class

The `ResourceDefinition` class defines static resources that AI clients can browse:

```python
from dataclasses import dataclass


@dataclass
class ResourceDefinition:
    """Definition of a resource provided by a plugin."""

    uri: str           # Resource URI (e.g., "wedo://tasks/global")
    name: str          # Human-readable name
    description: str   # Resource description
    mime_type: str     # Content type (default: "application/json")
```

### Fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `uri` | `str` | Yes | - | Unique resource identifier |
| `name` | `str` | Yes | - | Human-readable name |
| `description` | `str` | Yes | - | Description of the resource |
| `mime_type` | `str` | No | `"application/json"` | Content MIME type |

### URI Conventions

Resources use URI schemes to identify their source:

| Scheme | Description | Example |
|--------|-------------|---------|
| `wedo://` | WeDo task data | `wedo://tasks/global` |
| `memory://` | Memory/knowledge data | `memory://global/facts` |
| `config://` | Configuration data | `config://plugins/my-plugin` |
| `env://` | Environment data | `env://development` |

### Example Usage

```python
from flukebase_sdk import ResourceDefinition


# Define resources in your plugin
def get_resources(self) -> list[ResourceDefinition]:
    return [
        ResourceDefinition(
            uri="my_plugin://data/summary",
            name="Data Summary",
            description="Summary of all processed data",
            mime_type="application/json",
        ),
        ResourceDefinition(
            uri="my_plugin://config/current",
            name="Current Configuration",
            description="The plugin's current configuration",
            mime_type="application/json",
        ),
        ResourceDefinition(
            uri="my_plugin://logs/recent",
            name="Recent Logs",
            description="Recent activity logs",
            mime_type="text/plain",
        ),
    ]
```

### MCP Format Conversion

```python
resource = ResourceDefinition(
    uri="my_plugin://data/items",
    name="Items List",
    description="List of all items",
)

mcp_format = resource.to_mcp_format()
# Returns:
# {
#     "uri": "my_plugin://data/items",
#     "name": "Items List",
#     "description": "List of all items",
#     "mimeType": "application/json",
# }
```

## Naming Conventions (NAMING-008)

Follow these conventions for tool and resource names:

### Tool Naming

1. **Prefix with plugin name**: `{plugin_name}_{action}`
   ```python
   # Good
   "my_plugin_create_item"
   "my_plugin_list_items"
   "my_plugin_delete_item"

   # Bad (no prefix)
   "create_item"
   "list_items"
   ```

2. **Use snake_case**: All lowercase with underscores
   ```python
   # Good
   "my_plugin_get_user_data"

   # Bad
   "myPlugin_getUserData"
   "my-plugin-get-user-data"
   ```

3. **Use action verbs**: Start with a verb describing the action
   ```python
   # Good (verb first)
   "my_plugin_create_task"
   "my_plugin_update_config"
   "my_plugin_delete_record"
   "my_plugin_list_users"
   "my_plugin_search_items"
   "my_plugin_fetch_data"

   # Bad (no verb)
   "my_plugin_task"
   "my_plugin_config"
   ```

4. **Common verb patterns**:
   | Verb | Usage |
   |------|-------|
   | `create_` | Create new resources |
   | `get_` | Retrieve single item |
   | `list_` | Retrieve multiple items |
   | `update_` | Modify existing resource |
   | `delete_` | Remove resource |
   | `search_` | Search/query resources |
   | `fetch_` | Retrieve from external source |
   | `send_` | Send data externally |
   | `validate_` | Validate input/data |

### Resource URI Naming

1. **Use scheme for source identification**:
   ```python
   "my_plugin://category/resource"
   ```

2. **Use lowercase with slashes**:
   ```python
   # Good
   "my_plugin://data/users/active"

   # Bad
   "my_plugin://Data/Users/Active"
   ```

---

Previous: [Plugin Development Tutorial](plugin-development.md) | Next: [Service Protocols Guide](services.md)
