# Service Protocols Guide

FlukeBase plugins can access shared services provided by the FlukeBase Connect runtime. This guide documents all available service protocols and how to use them.

## Overview

Services are accessed through the `services` dictionary passed to `initialize()`:

```python
async def initialize(self, config: dict, services: dict) -> None:
    await super().initialize(config, services)

    # Access services
    self.client = self.get_service("flukebase_client")
    self.memory = self.get_service("memory")
    self.wedo = self.get_service("wedo")
    self.env_manager = self.get_service("env_manager")
    self.config = self.get_service("config")
```

### Available Services

| Service Key | Protocol | Description |
|-------------|----------|-------------|
| `flukebase_client` | `FlukeBaseClientProtocol` | API client for FlukeBase platform |
| `memory` | `MemoryStoreProtocol` | Local knowledge/memory storage |
| `wedo` | `WedoManagerProtocol` | Task management system |
| `env_manager` | `EnvManagerProtocol` | Environment variable management |
| `config` | `ConfigProtocol` | Configuration access |

### Type-Safe Service Access

Use the `get_typed_service()` helper for better type checking:

```python
from flukebase_sdk import (
    get_typed_service,
    FlukeBaseClientProtocol,
    MemoryStoreProtocol,
)


async def initialize(self, config: dict, services: dict) -> None:
    await super().initialize(config, services)

    self.client = get_typed_service(
        services, "flukebase_client", FlukeBaseClientProtocol
    )
    self.memory = get_typed_service(
        services, "memory", MemoryStoreProtocol
    )
```

---

## FlukeBaseClientProtocol

The FlukeBase API client provides methods for communicating with the FlukeBase platform.

### Import

```python
from flukebase_sdk import FlukeBaseClientProtocol
```

### Connection Management

```python
# Check if client is configured
if self.client.is_configured:
    status = await self.client.get_status()
    print(f"Connected: {status['connected']}")
    print(f"User: {status['user_email']}")
    print(f"Projects: {status['project_count']}")

# Close the client (call in shutdown)
await self.client.close()
```

### Authentication

```python
# Validate current token
result = await self.client.validate_token()
print(f"Token valid: {result['valid']}")

# Get current user info
user = await self.client.get_current_user()
print(f"User ID: {user['id']}")
print(f"Email: {user['email']}")

# Generate scoped token for containers
scoped_token = await self.client.generate_scoped_token(
    scope="container:pool-123",
    ttl_minutes=60,
    permissions=["read", "write"],
)
```

### Projects

```python
# List all projects
projects = await self.client.list_projects()
for project in projects:
    print(f"Project: {project.name} (ID: {project.id})")

# Get specific project
project = await self.client.get_project(project_id=1)

# Create new project
new_project = await self.client.create_project(
    name="my-project",
    repository_url="https://github.com/user/repo",
    description="Project description",
    stage="prototype",
)

# Find project by repository URL
project = await self.client.get_project_by_repo(
    repo_url="https://github.com/user/repo"
)

# Get full project context (for AI)
context = await self.client.get_project_context(project_id=1)
```

### Environment Variables

```python
# Get environment variables
env_vars = await self.client.get_environment(
    project_id=1,
    environment="development",  # or "staging", "production"
)

for var in env_vars:
    print(f"{var.key}={var.value}")

# Record sync event
await self.client.record_sync(project_id=1, environment="development")
```

### Memories (Remote)

```python
from datetime import datetime, timedelta

# List memories
memories = await self.client.list_memories(
    project_id=1,
    memory_type="fact",  # or "convention", "gotcha", "decision"
    since=datetime.now() - timedelta(days=7),
    synced=True,
)

# Get specific memory
memory = await self.client.get_memory(project_id=1, memory_id=123)

# Create memory
new_memory = await self.client.create_memory(
    project_id=1,
    memory_type="fact",
    content="Python uses snake_case for variables",
    tags=["python", "style"],
    references={"source": "PEP 8"},
)

# Update memory
updated = await self.client.update_memory(
    project_id=1,
    memory_id=123,
    content="Updated content",
    tags=["updated", "tag"],
)

# Delete memory
deleted = await self.client.delete_memory(project_id=1, memory_id=123)

# Bulk push memories
result = await self.client.bulk_push_memories(
    project_id=1,
    memories=[
        {"type": "fact", "content": "Fact 1", "external_id": "local-1"},
        {"type": "fact", "content": "Fact 2", "external_id": "local-2"},
    ],
)
print(f"Created: {result['created']}, Updated: {result['updated']}")

# Search across all projects
results = await self.client.search_memories_cross_project(
    query="python",
    memory_type="convention",
    tag="style",
    page=1,
    per_page=50,
)
```

### WeDo Tasks (Remote)

```python
# List tasks
tasks = await self.client.list_tasks(
    project_id=1,
    status="pending",
    scope="global",
    since_version=0,
    root_only=True,
    page=1,
    per_page=50,
)

# Get specific task
task = await self.client.get_task(project_id=1, task_id="TASK-001")

# Create task
new_task = await self.client.create_task(
    project_id=1,
    task_id="TASK-002",
    description="Implement feature X",
    status="pending",
    dependency="AGENT_CAPABLE",
    scope="global",
    priority="high",
    tags=["feature", "sprint-1"],
)

# Update task
updated = await self.client.update_task(
    project_id=1,
    task_id="TASK-002",
    status="in_progress",
    synthesis_note="Started work on this task",
)

# Delete task
deleted = await self.client.delete_task(project_id=1, task_id="TASK-002")

# Bulk push tasks
result = await self.client.bulk_push_tasks(
    project_id=1,
    tasks=[
        {"task_id": "T-001", "description": "Task 1"},
        {"task_id": "T-002", "description": "Task 2"},
    ],
)
```

### Agents

```python
# Register agent
agent = await self.client.register_agent(
    project_id=1,
    agent_id="session-123",
    persona_name="ZION",
    agent_type="claude_code",
    capabilities=["code", "analysis"],
)

# Send heartbeat
await self.client.agent_heartbeat(
    project_id=1,
    agent_id="session-123",
    tokens_used=1000,
    tools_executed=5,
)

# List agents
agents = await self.client.list_agents(
    project_id=1,
    status="active",
    connected_only=True,
)
```

### Webhooks

```python
# List webhooks
webhooks = await self.client.list_webhooks(project_id=1)

# Create webhook
webhook = await self.client.create_webhook(
    project_id=1,
    callback_url="https://example.com/webhook",
    events=["task.created", "memory.created"],
)

# Delete webhook
deleted = await self.client.delete_webhook(project_id=1, webhook_id=123)
```

### Batch Operations

```python
# Get context for multiple projects
contexts = await self.client.batch_get_project_contexts(
    project_ids=[1, 2, 3],
    # OR
    all_projects=True,
)

# Get environments for multiple projects
environments = await self.client.batch_get_environments(
    project_ids=[1, 2],
    environment="development",
)

# Pull memories from multiple projects
memories = await self.client.batch_pull_memories(
    all_projects=True,
    memory_type="convention",
)
```

---

## MemoryStoreProtocol

The memory store provides local SQLite-based storage for facts, conventions, gotchas, and decisions.

### Import

```python
from flukebase_sdk import MemoryStoreProtocol, MemoryType
```

### Type Aliases

```python
MemoryType = Literal["fact", "convention", "gotcha", "decision"]
ScopeType = Union[str, list[str], Literal["all"]]
```

### Scopes

```python
# List all available scopes
scopes = self.memory.list_scopes()
# Returns: ["global", "project-a", "project-b", ...]
```

### Remember (Store)

```python
# Store a fact
fact = await self.memory.remember(
    content="The API uses JWT tokens for authentication",
    type="fact",
    scope="global",
    tags=["api", "auth", "jwt"],
    references={"file": "auth.py", "line": 42},
)

# Store a convention
convention = await self.memory.remember(
    content="All API endpoints use kebab-case",
    type="convention",
    scope="my-project",
    tags=["api", "naming"],
)

# Store a gotcha (common pitfall)
gotcha = await self.memory.remember(
    content="The cache expires after 5 minutes, not 5 seconds",
    type="gotcha",
    scope="global",
    tags=["cache", "timing"],
)

# Store a decision
decision = await self.memory.remember(
    content="We chose PostgreSQL over MySQL for JSON support",
    type="decision",
    scope="my-project",
    tags=["database", "architecture"],
)
```

### Recall (Search)

```python
# Search across all scopes
results = await self.memory.recall(
    query="authentication",
    limit=10,
)

# Search specific type
conventions = await self.memory.recall(
    query="naming",
    type="convention",
    limit=5,
)

# Search specific scope
project_facts = await self.memory.recall(
    query="database",
    type="fact",
    scope="my-project",
)

# Search multiple scopes
results = await self.memory.recall(
    query="api",
    scope=["global", "my-project"],
)

# Search all scopes explicitly
all_results = await self.memory.recall(
    query="config",
    scope="all",
)
```

### Forget (Delete)

```python
# Delete a memory by ID
result = await self.memory.forget(
    id="memory-uuid-123",
    scope="global",
)

if result["success"]:
    print(f"Deleted from scope: {result['scope']}")
else:
    print("Memory not found")

# Search all scopes for the memory
result = await self.memory.forget(
    id="memory-uuid-123",
    scope="all",
)
```

### Conventions (Key-Value)

```python
# Set a convention
convention = await self.memory.set_convention(
    key="naming_style",
    value="snake_case for variables, PascalCase for classes",
    rationale="Following PEP 8 style guide",
    scope="global",
)

# Get a convention
conv = await self.memory.get_convention(
    key="naming_style",
    scope="global",
)

if conv:
    print(f"Value: {conv['value']}")
    print(f"Rationale: {conv['rationale']}")

# List all conventions
conventions = await self.memory.list_conventions(scope="global")
for conv in conventions:
    print(f"{conv['key']}: {conv['value']}")
```

---

## WedoManagerProtocol

The WeDo manager handles task tracking, agent sessions, and templates.

### Import

```python
from flukebase_sdk import WedoManagerProtocol, WedoStatusType, WedoDependencyType
```

### Type Aliases

```python
WedoStatusType = Literal["pending", "in_progress", "completed", "blocked"]
WedoDependencyType = Literal["USER_REQUIRED", "AGENT_CAPABLE"]
TaskPriorityType = Literal["critical", "high", "normal", "low", "none"]
```

### Agent Management

```python
# Register an agent
agent = await self.wedo.register_agent(
    agent_id="session-abc123",
    name="ZION",
    is_named_persona=True,
    metadata={"purpose": "code review"},
    client_type="claude_code",
    client_version="1.0.0",
)

# Get agent
agent = await self.wedo.get_agent("session-abc123")

# List agents
agents = await self.wedo.list_agents(named_only=True)

# Get/set current agent
current_id = self.wedo.get_current_agent_id()
self.wedo.set_current_agent("session-abc123")

# Send heartbeat
success = await self.wedo.heartbeat(agent_id="session-abc123")

# Session management
session = await self.wedo.start_session(
    agent_id="session-abc123",
    scope="global",
)

await self.wedo.end_session(session_id=session["id"])
```

### Task Management

```python
# Create a task
task = await self.wedo.create_task(
    task_id="FEAT-001",
    description="Implement user authentication",
    dependency="AGENT_CAPABLE",  # or "USER_REQUIRED"
    scope="global",
    parent_task_id=None,  # For subtasks
    tags=["feature", "auth"],
    artifact_path="/src/auth/",
    remote_url="https://github.com/user/repo/issues/1",
    priority="high",
    due_date="2024-12-31",
    estimated_minutes=120,
)

# Get a task
task = await self.wedo.get_task("FEAT-001")

# Update task status
updated = await self.wedo.update_task_status(
    task_id="FEAT-001",
    status="in_progress",
    synthesis_note="Started implementation",
    check_dependencies=True,  # Verify blockers are complete
)

# Delete a task
deleted = await self.wedo.delete_task("FEAT-001")

# List tasks with filters
tasks = await self.wedo.list_tasks(
    status="pending",
    scope="global",
    agent_id="session-abc123",
    limit=50,
)

# Get manager status
status = await self.wedo.get_status(scope="global")
print(f"Total tasks: {status['total_tasks']}")
print(f"Status breakdown: {status['status_counts']}")
```

### Milestone Progress

```python
# Get progress for a milestone (parent task)
progress = await self.wedo.get_milestone_progress(
    milestone_id="EPIC-001",
    scope="global",
)
print(f"Completed: {progress['completed']}/{progress['total']}")
print(f"Progress: {progress['percentage']:.1f}%")

# Get progress for all milestones
all_progress = await self.wedo.get_all_milestones_progress(scope="global")
for milestone in all_progress:
    print(f"{milestone['milestone_id']}: {milestone['percentage']:.1f}%")
```

### Task Relationships

```python
# Add a blocking relationship
relationship = await self.wedo.add_relationship(
    source_task_id="FEAT-002",
    target_task_id="FEAT-001",
    relationship_type="blocks",
    metadata={"reason": "Depends on auth"},
)

# Remove relationship
removed = await self.wedo.remove_relationship(
    source_task_id="FEAT-002",
    target_task_id="FEAT-001",
    relationship_type="blocks",
)

# Get blocking tasks
blockers = await self.wedo.get_blocking_tasks("FEAT-002")
print(f"Blocked by: {blockers}")

# Check if dependencies are met
deps = await self.wedo.check_dependencies_met("FEAT-002")
if deps["met"]:
    print("Ready to start!")
else:
    print(f"Blocked by: {deps['blocking']}")
```

### Templates

```python
# Create a template
template = await self.wedo.create_template(
    name="feature-implementation",
    description="Standard feature implementation checklist",
    default_tasks=[
        {"description": "Write design doc", "tags": ["docs"]},
        {"description": "Implement core logic", "tags": ["code"]},
        {"description": "Write tests", "tags": ["testing"]},
        {"description": "Update documentation", "tags": ["docs"]},
    ],
    scope="global",
)

# List templates
templates = await self.wedo.list_templates(scope="global")

# Instantiate template (create tasks from it)
tasks = await self.wedo.instantiate_template(
    template_id=template["id"],
    id_prefix="FEAT-001",
    scope="global",
)
# Creates: FEAT-001-01, FEAT-001-02, FEAT-001-03, FEAT-001-04
```

### Export

```python
# Export to markdown
export_path = await self.wedo.export_to_markdown(
    scope="global",
    include_tasks=True,
    include_memories=True,
    temporal_folders=True,  # Year/Quarter/Month/Day structure
)
print(f"Exported to: {export_path}")
```

---

## EnvManagerProtocol

The environment manager handles `.env` file operations and environment variable management.

### Import

```python
from flukebase_sdk import EnvManagerProtocol
from pathlib import Path
```

### Environment Sync

```python
# Sync environment from FlukeBase
env_path = await self.env_manager.sync_environment(
    project_id=1,
    project_path=Path("/path/to/project"),
    environment="development",
)
print(f"Generated .env at: {env_path}")
```

### Reading Environment

```python
project_path = Path("/path/to/project")

# Read raw .env file (unmasked)
env_vars = self.env_manager.read_env_file(project_path / ".env")
for key, value in env_vars.items():
    print(f"{key}={value}")

# Show environment (secrets masked by default)
masked_env = self.env_manager.show_environment(
    project_path=project_path,
    mask_secrets=True,
)
# API_KEY=****
# DEBUG=true
```

### Environment Diff

```python
# Compare local vs remote
diff = await self.env_manager.diff_environment(
    project_id=1,
    project_path=project_path,
    environment="development",
)

if diff["in_sync"]:
    print("Environment is in sync!")
else:
    print(f"Added: {diff['added']}")
    print(f"Removed: {diff['removed']}")
    print(f"Changed: {diff['changed']}")
```

### Caching

```python
# Load from cache (offline mode)
cached = self.env_manager.load_from_cache(
    project_path=project_path,
    environment="development",
)

if cached:
    print("Using cached environment")
else:
    print("No cache available")
```

### Building Inherited Environment

```python
# Build env vars for sandbox/container
inherited_env = self.env_manager.build_inherited_env(
    project_path=project_path,
    include_defaults=True,      # Default AI provider keys
    include_project_env=True,   # Project .env values
    include_host_env=True,      # Host environment overrides
    extra_keys=["CUSTOM_VAR"],  # Additional explicit keys
    extra_patterns=["AWS_*"],   # Wildcard patterns
)

# Use for subprocess or container
subprocess.run(cmd, env=inherited_env)
```

---

## ConfigProtocol

The config service provides access to FlukeBase Connect configuration.

### Import

```python
from flukebase_sdk import ConfigProtocol
from pathlib import Path
```

### Properties and Methods

```python
# Get FlukeBase home directory
home: Path = self.config.home
print(f"FlukeBase home: {home}")

# Get configuration as dictionary
config_dict = self.config.to_dict()

# Save configuration
self.config.save()

# Project context
self.config.ensure_project_context()  # Detect if not detected
self.config.refresh_project_context(path=Path("/new/path"))  # Re-detect
```

### Typical Usage

```python
class MyPlugin(BasePlugin):
    async def initialize(self, config: dict, services: dict) -> None:
        await super().initialize(config, services)

        self.fb_config = self.get_service("config")

        # Get home directory for storing plugin data
        plugin_data_dir = self.fb_config.home / "plugins" / "my-plugin"
        plugin_data_dir.mkdir(parents=True, exist_ok=True)

        # Ensure project is detected
        self.fb_config.ensure_project_context()
```

---

## Complete Service Usage Example

Here is a plugin that uses all services:

```python
"""Plugin demonstrating all service protocols."""

from pathlib import Path
from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
    FlukeBaseClientProtocol,
    MemoryStoreProtocol,
    WedoManagerProtocol,
    EnvManagerProtocol,
    ConfigProtocol,
)


class FullServicePlugin(BasePlugin):
    """A plugin using all available services."""

    def __init__(self):
        super().__init__()
        self.client: FlukeBaseClientProtocol | None = None
        self.memory: MemoryStoreProtocol | None = None
        self.wedo: WedoManagerProtocol | None = None
        self.env_manager: EnvManagerProtocol | None = None
        self.fb_config: ConfigProtocol | None = None

    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="full-service-plugin",
            display_name="Full Service Plugin",
            version="1.0.0",
            description="Demonstrates all service protocols",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
        )

    def get_tools(self) -> list[ToolDefinition]:
        return [
            ToolDefinition(
                name="full_service_status",
                description="Get status from all services",
                input_schema={"type": "object", "properties": {}},
                handler_method="handle_status",
            ),
        ]

    async def initialize(self, config: dict, services: dict) -> None:
        await super().initialize(config, services)

        # Store all service references
        self.client = self.get_service("flukebase_client")
        self.memory = self.get_service("memory")
        self.wedo = self.get_service("wedo")
        self.env_manager = self.get_service("env_manager")
        self.fb_config = self.get_service("config")

    async def handle_status(self, args: dict) -> str:
        """Get status from all services."""
        output = []

        # FlukeBase Client status
        if self.client and self.client.is_configured:
            status = await self.client.get_status()
            output.append(f"FlukeBase: Connected={status['connected']}")
        else:
            output.append("FlukeBase: Not configured")

        # Memory scopes
        if self.memory:
            scopes = self.memory.list_scopes()
            output.append(f"Memory: {len(scopes)} scopes")

        # WeDo status
        if self.wedo:
            wedo_status = await self.wedo.get_status()
            output.append(f"WeDo: {wedo_status['total_tasks']} tasks")

        # Config home
        if self.fb_config:
            output.append(f"Config home: {self.fb_config.home}")

        return "\n".join(output)

    async def shutdown(self) -> None:
        # Clear service references
        self.client = None
        self.memory = None
        self.wedo = None
        self.env_manager = None
        self.fb_config = None
        await super().shutdown()
```

---

Previous: [Tools API Reference](tools-api.md) | Next: [Testing Guide](testing.md)
