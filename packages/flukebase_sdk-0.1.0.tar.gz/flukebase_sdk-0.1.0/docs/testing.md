# Testing Guide

This guide covers testing FlukeBase plugins using the SDK's mock services and pytest fixtures.

## Overview

The FlukeBase SDK provides comprehensive testing utilities:

- **Mock Classes**: In-memory implementations of all service protocols
- **CallTracker Mixin**: Track and verify method calls on mocks
- **Pytest Fixtures**: Ready-to-use fixtures for common testing scenarios
- **Factory Functions**: Create pre-configured mock services

## Installation

Install the SDK with testing dependencies:

```bash
pip install flukebase-sdk[dev]
```

This includes:
- pytest
- pytest-asyncio

## Mock Services

### Available Mocks

| Mock Class | Protocol | Description |
|------------|----------|-------------|
| `MockFlukeBaseClient` | `FlukeBaseClientProtocol` | API client mock |
| `MockMemoryStore` | `MemoryStoreProtocol` | Memory storage mock |
| `MockWedoManager` | `WedoManagerProtocol` | Task manager mock |
| `MockEnvManager` | `EnvManagerProtocol` | Environment manager mock |
| `MockConfig` | `ConfigProtocol` | Configuration mock |
| `MockPlugin` | `BasePlugin` | Plugin mock for testing |

### Importing Mocks

```python
from flukebase_sdk.testing import (
    # Mock classes
    MockFlukeBaseClient,
    MockMemoryStore,
    MockWedoManager,
    MockEnvManager,
    MockConfig,
    MockPlugin,
    # Data classes
    MockProject,
    MockMemory,
    MockTask,
    MockAgent,
    MockEnvVar,
    # Factory functions
    create_mock_services,
    create_mock_services_with_data,
)
```

## MockFlukeBaseClient

Mock implementation of the FlukeBase API client.

### Basic Usage

```python
import pytest
from flukebase_sdk.testing import MockFlukeBaseClient, MockProject


@pytest.mark.asyncio
async def test_client_operations():
    client = MockFlukeBaseClient(
        is_configured=True,
        connected=True,
        user_email="test@example.com",
    )

    # Add test data
    client.add_project(MockProject(id=1, name="test-project"))

    # Use the client
    status = await client.get_status()
    assert status["connected"] is True

    projects = await client.list_projects()
    assert len(projects) == 1
```

### Setup Methods

```python
# Add a project
client.add_project(MockProject(
    id=1,
    name="my-project",
    repository_url="https://github.com/user/repo",
))

# Add a memory to a project
client.add_memory(project_id=1, memory=MockMemory(
    id="mem-1",
    content="Test memory",
    type="fact",
))

# Add an environment variable
client.add_env_var(
    project_id=1,
    env="development",
    key="API_KEY",
    value="test-key",
    is_secret=True,
)
```

## MockMemoryStore

Mock implementation of local memory storage.

### Basic Usage

```python
import pytest
from flukebase_sdk.testing import MockMemoryStore, MockMemory


@pytest.mark.asyncio
async def test_memory_operations():
    store = MockMemoryStore()

    # Store a memory
    memory = await store.remember(
        content="Test fact",
        type="fact",
        scope="global",
        tags=["test"],
    )

    # Search memories
    results = await store.recall(query="Test", limit=10)
    assert len(results) == 1
    assert results[0].content == "Test fact"
```

### Setup Methods

```python
# Add a scope
store.add_scope("my-project")

# Add a memory directly
store.add_memory(MockMemory(
    id="test-id",
    content="Pre-existing memory",
    type="convention",
    scope="global",
    tags=["setup"],
))
```

## MockWedoManager

Mock implementation of the WeDo task manager.

### Basic Usage

```python
import pytest
from flukebase_sdk.testing import MockWedoManager, MockTask


@pytest.mark.asyncio
async def test_task_operations():
    manager = MockWedoManager()

    # Register an agent
    agent = await manager.register_agent(
        agent_id="test-agent",
        name="Test Agent",
        is_named_persona=True,
    )

    # Create a task
    task = await manager.create_task(
        task_id="TEST-001",
        description="Test task",
        priority="high",
    )

    # Get the task
    retrieved = await manager.get_task("TEST-001")
    assert retrieved is not None
    assert retrieved.description == "Test task"
```

### Setup Methods

```python
# Add a task directly
manager.add_task(MockTask(
    task_id="EXISTING-001",
    description="Pre-existing task",
    status="pending",
))

# Add an agent directly
manager.add_agent(MockAgent(
    agent_id="existing-agent",
    name="Existing Agent",
))
```

## MockEnvManager

Mock implementation of environment variable management.

### Basic Usage

```python
import pytest
from pathlib import Path
from flukebase_sdk.testing import MockEnvManager


def test_env_operations():
    env_manager = MockEnvManager()

    # Set environment variables
    env_manager.set_env_vars({
        "API_KEY": "test-api-key",
        "DEBUG": "true",
        "DATABASE_URL": "sqlite:///test.db",
    })

    # Show environment (secrets masked)
    env = env_manager.show_environment(Path("/project"), mask_secrets=True)
    assert env["API_KEY"] == "****"  # Masked
    assert env["DEBUG"] == "true"    # Not masked
```

### Setup Methods

```python
# Set environment variables
env_manager.set_env_vars({
    "VAR1": "value1",
    "VAR2": "value2",
})

# Set cached environment
env_manager.set_cache(
    project_path="/project",
    environment="development",
    vars=[
        {"key": "CACHED_VAR", "value": "cached"},
    ],
)
```

## MockConfig

Mock implementation of configuration access.

### Basic Usage

```python
from pathlib import Path
from flukebase_sdk.testing import MockConfig


def test_config_operations():
    config = MockConfig(home=Path("/tmp/flukebase"))

    # Set configuration values
    config.set_values({
        "api_url": "https://api.test.com",
        "timeout": 30,
    })

    # Access configuration
    data = config.to_dict()
    assert data["api_url"] == "https://api.test.com"

    # Access home directory
    assert config.home == Path("/tmp/flukebase")
```

## CallTracker Mixin

All mock classes include the `CallTracker` mixin for verifying method calls.

### Tracking Method Calls

```python
@pytest.mark.asyncio
async def test_call_tracking():
    store = MockMemoryStore()

    # Perform operations
    await store.remember("Test", type="fact")
    await store.recall("Test")
    await store.recall("Test")

    # Verify calls
    assert store.was_called("remember")
    assert store.call_count("recall") == 2
    assert store.call_count() == 3  # All calls
```

### Inspecting Call Details

```python
@pytest.mark.asyncio
async def test_call_inspection():
    store = MockMemoryStore()

    await store.remember(
        content="Test content",
        type="fact",
        scope="global",
        tags=["test"],
    )

    # Get all calls to a method
    calls = store.get_calls("remember")
    assert len(calls) == 1

    # Inspect call details
    call = calls[0]
    assert call.kwargs["content"] == "Test content"
    assert call.kwargs["type"] == "fact"
    assert call.kwargs["tags"] == ["test"]

    # Get last call
    last = store.last_call("remember")
    assert last.kwargs["scope"] == "global"
```

### Verifying Call Arguments

```python
@pytest.mark.asyncio
async def test_call_arguments():
    client = MockFlukeBaseClient()

    await client.get_project(project_id=1)

    # Check if called with specific arguments
    assert client.was_called_with("get_project", project_id=1)
    assert not client.was_called_with("get_project", project_id=2)
```

### Configuring Return Values

```python
@pytest.mark.asyncio
async def test_custom_return_values():
    client = MockFlukeBaseClient()

    # Set custom return value
    client.set_return_value("get_status", {
        "connected": False,
        "user_email": None,
        "project_count": 0,
    })

    status = await client.get_status()
    assert status["connected"] is False
```

### Configuring Side Effects (Exceptions)

```python
@pytest.mark.asyncio
async def test_side_effects():
    client = MockFlukeBaseClient()

    # Configure to raise exception
    client.set_side_effect("validate_token", ConnectionError("Network error"))

    with pytest.raises(ConnectionError):
        await client.validate_token()
```

### Resetting Mocks

```python
@pytest.mark.asyncio
async def test_reset():
    store = MockMemoryStore()

    await store.remember("Test", type="fact")
    assert store.call_count() == 1

    # Reset just calls
    store.reset_calls()
    assert store.call_count() == 0

    # Reset everything
    store.reset()  # Clears calls, return values, and side effects
```

## Pytest Fixtures

The SDK provides pre-configured pytest fixtures for common testing patterns.

### Setting Up Fixtures

In your `conftest.py`:

```python
# Import all fixtures
from flukebase_sdk.testing.fixtures import *  # noqa: F401,F403

# Or import specific fixtures
from flukebase_sdk.testing.fixtures import (
    mock_services,
    mock_flukebase_client,
    mock_memory_store,
    mock_wedo_manager,
)
```

### Available Fixtures

#### Function-Scoped (Fresh per test)

```python
@pytest.mark.asyncio
async def test_with_services(mock_services):
    """mock_services provides all mock services."""
    plugin = MyPlugin()
    await plugin.initialize({}, mock_services)

    # Access individual services
    client = mock_services["flukebase_client"]
    memory = mock_services["memory"]
    wedo = mock_services["wedo"]


@pytest.mark.asyncio
async def test_with_client(mock_flukebase_client):
    """Individual service fixtures."""
    mock_flukebase_client.add_project(MockProject(id=1, name="test"))
    projects = await mock_flukebase_client.list_projects()
    assert len(projects) == 1


@pytest.mark.asyncio
async def test_with_memory(mock_memory_store):
    """Memory store fixture."""
    await mock_memory_store.remember("Test", type="fact")


@pytest.mark.asyncio
async def test_with_wedo(mock_wedo_manager):
    """WeDo manager fixture."""
    await mock_wedo_manager.create_task("T-001", "Test task")
```

#### Pre-Configured Data Fixtures

```python
@pytest.mark.asyncio
async def test_with_project(mock_services_with_project):
    """Services with a pre-configured project."""
    client = mock_services_with_project["flukebase_client"]
    projects = await client.list_projects()
    assert len(projects) == 1


@pytest.mark.asyncio
async def test_with_full_data(mock_services_with_data):
    """Services with project, memory, task, and env vars."""
    client = mock_services_with_data["flukebase_client"]
    memory = mock_services_with_data["memory"]
    wedo = mock_services_with_data["wedo"]
    # All have pre-populated data
```

#### Data Fixtures

```python
def test_with_mock_data(mock_project, mock_memory, mock_task):
    """Individual data fixtures."""
    assert mock_project.id == 1
    assert mock_project.name == "test-project"

    assert mock_memory.type == "fact"
    assert mock_task.status == "pending"
```

#### Utility Fixtures

```python
def test_with_temp_path(temp_project_path):
    """Temporary project directory."""
    assert temp_project_path.exists()


def test_with_reset(mock_services, reset_mocks):
    """Reset helper fixture."""
    # Use services...
    reset_mocks(mock_services.values())
    # All mocks are now reset


def test_with_assertions(mock_memory_store, assert_mock_called):
    """Assertion helper fixture."""
    await mock_memory_store.remember("Test", type="fact")

    assert_mock_called.called(mock_memory_store, "remember")
    assert_mock_called.once(mock_memory_store, "remember")
```

#### Parametrized Fixtures

```python
@pytest.mark.asyncio
async def test_all_memory_types(mock_memory_store, memory_type):
    """Runs once for each memory type (fact, convention, gotcha, decision)."""
    await mock_memory_store.remember("Test", type=memory_type)


@pytest.mark.asyncio
async def test_all_task_statuses(mock_wedo_manager, task_status):
    """Runs once for each status (pending, in_progress, completed, blocked)."""
    task = MockTask(task_id="T-001", description="Test", status=task_status)
    mock_wedo_manager.add_task(task)


def test_multiple_scopes(mock_memory_store, scope):
    """Runs for global, project-a, project-b."""
    mock_memory_store.add_scope(scope)
```

## Factory Functions

### create_mock_services()

Creates a complete set of mock services:

```python
from flukebase_sdk.testing import create_mock_services


services = create_mock_services()
# Contains: flukebase_client, memory, wedo, env_manager, config

# Use with plugin
await plugin.initialize({}, services)

# Access for verification
assert services["memory"].was_called("remember")
```

### create_mock_services_with_data()

Creates mock services pre-populated with test data:

```python
from flukebase_sdk.testing import (
    create_mock_services_with_data,
    MockProject,
    MockMemory,
    MockTask,
)


services = create_mock_services_with_data(
    project=MockProject(id=1, name="test"),
    memories=[
        MockMemory(id="m1", content="Fact 1", type="fact"),
        MockMemory(id="m2", content="Fact 2", type="fact"),
    ],
    tasks=[
        MockTask(task_id="T-001", description="Task 1"),
    ],
    env_vars={
        "API_KEY": "test-key",
        "DEBUG": "true",
    },
)
```

## Example Test Cases

### Testing Plugin Initialization

```python
import pytest
from my_plugin import MyPlugin
from flukebase_sdk.testing import create_mock_services


@pytest.mark.asyncio
async def test_plugin_initializes():
    plugin = MyPlugin()
    services = create_mock_services()

    await plugin.initialize({}, services)

    assert plugin.is_initialized


@pytest.mark.asyncio
async def test_plugin_shutdown():
    plugin = MyPlugin()
    services = create_mock_services()

    await plugin.initialize({}, services)
    await plugin.shutdown()

    assert not plugin.is_initialized
```

### Testing Tool Handlers

```python
import pytest
from my_plugin import MyPlugin
from flukebase_sdk.testing import create_mock_services


@pytest.mark.asyncio
async def test_tool_returns_expected_result():
    plugin = MyPlugin()
    services = create_mock_services()
    await plugin.initialize({}, services)

    result = await plugin.handle_my_tool({"param": "value"})

    assert "expected" in result


@pytest.mark.asyncio
async def test_tool_handles_missing_params():
    plugin = MyPlugin()
    services = create_mock_services()
    await plugin.initialize({}, services)

    result = await plugin.handle_my_tool({})  # Missing required param

    assert "error" in result.lower()
```

### Testing Service Integration

```python
import pytest
from my_plugin import MyPlugin
from flukebase_sdk.testing import create_mock_services


@pytest.mark.asyncio
async def test_plugin_stores_memory():
    plugin = MyPlugin()
    services = create_mock_services()
    await plugin.initialize({}, services)

    # Call tool that should store memory
    await plugin.handle_create_item({"name": "Test Item"})

    # Verify memory was stored
    memory = services["memory"]
    assert memory.was_called("remember")
    assert memory.was_called_with("remember", type="fact")


@pytest.mark.asyncio
async def test_plugin_creates_task():
    plugin = MyPlugin()
    services = create_mock_services()
    await plugin.initialize({}, services)

    # Call tool that should create task
    await plugin.handle_start_workflow({"workflow": "deploy"})

    # Verify task was created
    wedo = services["wedo"]
    assert wedo.was_called("create_task")
```

### Testing Error Handling

```python
import pytest
from my_plugin import MyPlugin
from flukebase_sdk.testing import create_mock_services


@pytest.mark.asyncio
async def test_handles_api_error():
    plugin = MyPlugin()
    services = create_mock_services()
    await plugin.initialize({}, services)

    # Configure mock to raise error
    services["flukebase_client"].set_side_effect(
        "get_project",
        ConnectionError("API unavailable"),
    )

    result = await plugin.handle_fetch_project({"id": 1})

    assert "error" in result.lower()
    assert "unavailable" in result.lower()
```

### Complete Test File Example

```python
"""Tests for MyPlugin."""

import pytest
from my_plugin import MyPlugin
from flukebase_sdk.testing import (
    create_mock_services,
    MockProject,
    MockMemory,
)


class TestMyPlugin:
    """Test suite for MyPlugin."""

    @pytest.fixture
    def plugin(self):
        """Create plugin instance."""
        return MyPlugin()

    @pytest.fixture
    def services(self):
        """Create mock services."""
        return create_mock_services()

    @pytest.fixture
    async def initialized_plugin(self, plugin, services):
        """Create and initialize plugin."""
        await plugin.initialize({}, services)
        yield plugin
        await plugin.shutdown()

    @pytest.mark.asyncio
    async def test_metadata(self, plugin):
        """Test plugin metadata."""
        metadata = plugin.get_metadata()

        assert metadata.name == "my-plugin"
        assert metadata.version == "1.0.0"

    @pytest.mark.asyncio
    async def test_tools_defined(self, plugin):
        """Test plugin defines expected tools."""
        tools = plugin.get_tools()

        tool_names = [t.name for t in tools]
        assert "my_plugin_action" in tool_names

    @pytest.mark.asyncio
    async def test_action_tool(self, initialized_plugin, services):
        """Test the action tool."""
        result = await initialized_plugin.handle_action({
            "input": "test data",
        })

        assert "success" in result.lower()
        assert services["memory"].was_called("remember")

    @pytest.mark.asyncio
    async def test_action_tool_missing_input(self, initialized_plugin):
        """Test action tool with missing input."""
        result = await initialized_plugin.handle_action({})

        assert "error" in result.lower()

    @pytest.mark.asyncio
    async def test_uses_memory_service(self, initialized_plugin, services):
        """Test plugin correctly uses memory service."""
        await initialized_plugin.handle_store({
            "content": "Important fact",
        })

        memory = services["memory"]
        assert memory.call_count("remember") == 1

        call = memory.last_call("remember")
        assert call.kwargs["content"] == "Important fact"
        assert call.kwargs["type"] == "fact"
```

---

Previous: [Service Protocols Guide](services.md) | Next: [Best Practices](best-practices.md)
