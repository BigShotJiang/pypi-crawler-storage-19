# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2025-01-06

### Added

- Initial release of the FlukeBase SDK
- `BasePlugin` abstract base class for creating plugins
- `PluginMetadata` dataclass for plugin configuration
- `PluginType` enum with categories: INTEGRATION, ANALYTICS, AUTOMATION, DEVELOPER_TOOLS, AI_PROVIDER, FRAMEWORK, UTILITY
- `PluginMaturity` enum with levels: EXPERIMENTAL, BETA, STABLE, DEPRECATED
- `ToolDefinition` dataclass for defining plugin tools
- `ToolAnnotations` dataclass for tool behavioral hints
- `ResourceDefinition` dataclass for read-only resources
- `Protocol` classes for type-safe interfaces
- `MockPlugin` testing utility for plugin development
- Full type annotations with py.typed marker
- Comprehensive documentation and examples

### Developer Experience

- Support for Python 3.11, 3.12, and 3.13
- Strict mypy type checking enabled
- Ruff linting with Google-style docstrings
- pytest with asyncio support for testing
- 100% test coverage target

[Unreleased]: https://github.com/flukebase/flukebase-sdk/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/flukebase/flukebase-sdk/releases/tag/v0.1.0
