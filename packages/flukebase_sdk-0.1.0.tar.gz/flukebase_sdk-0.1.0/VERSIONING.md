# FlukeBase SDK Versioning and Compatibility Strategy

This document defines the versioning policy, compatibility guarantees, and deprecation workflow for the FlukeBase SDK.

## Semantic Versioning

The FlukeBase SDK follows [Semantic Versioning 2.0.0](https://semver.org/):

```
MAJOR.MINOR.PATCH
```

### Version Components

| Component | When to Increment | Example |
|-----------|-------------------|---------|
| **MAJOR** | Breaking changes to public API | Removing a method from `BasePlugin` |
| **MINOR** | New features, backward-compatible | Adding new `PluginType` enum value |
| **PATCH** | Bug fixes, backward-compatible | Fixing type hint errors |

### Public API Definition

The **public API** consists of everything exported from `flukebase_sdk`:

```python
from flukebase_sdk import (
    # Core classes
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
    ToolAnnotations,
    ResourceDefinition,

    # Service protocols
    FlukeBaseClientProtocol,
    MemoryStoreProtocol,
    WedoManagerProtocol,
    EnvManagerProtocol,
    ConfigProtocol,

    # Type aliases
    MemoryType,
    ScopeType,
    WedoStatusType,
    WedoDependencyType,
    TaskPriorityType,
    ServiceDict,

    # Helper functions
    get_typed_service,
)
```

### What Constitutes a Breaking Change

**Breaking changes (require MAJOR bump):**
- Removing or renaming public classes, methods, or functions
- Changing method signatures (required parameters, return types)
- Removing enum values
- Changing Protocol method signatures
- Removing exports from `__all__`

**Non-breaking changes (MINOR or PATCH):**
- Adding new classes, methods, or functions
- Adding new enum values
- Adding optional parameters with defaults
- Adding new Protocol methods (plugins don't implement protocols)
- Internal implementation changes
- Documentation updates
- Type hint improvements

## Compatibility Matrix

### SDK to FlukeBase Connect Compatibility

| SDK Version | Minimum FBC Version | Maximum FBC Version | Notes |
|-------------|---------------------|---------------------|-------|
| 0.1.x       | 0.1.0               | latest              | Initial release |
| 0.2.x       | 0.1.0               | latest              | Protocol additions |
| 1.0.x       | 1.0.0               | latest              | Stable API |

### Python Version Support

| SDK Version | Python Versions | End of Support |
|-------------|-----------------|----------------|
| 0.1.x       | 3.11, 3.12, 3.13 | TBD           |
| 1.0.x       | 3.11+           | Python EOL + 1 year |

**Policy:** We support the three most recent Python minor versions. When a new Python version is released, support for the oldest version may be dropped in the next MINOR release.

## Plugin Compatibility

### min_sdk_version Field

Plugins declare their minimum required SDK version in `PluginMetadata`:

```python
class MyPlugin(BasePlugin):
    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="my-plugin",
            version="1.0.0",
            min_sdk_version="0.1.0",  # Minimum SDK version required
            # ...
        )
```

### Marketplace Requirements

| Requirement | Description |
|-------------|-------------|
| `min_sdk_version` | Required for marketplace submission |
| Version format | Must be valid semver (X.Y.Z) |
| Testing | Plugin must pass tests with declared min version |

### Compatibility Checking

FlukeBase Connect validates plugin compatibility at load time:

```python
# Pseudo-code for compatibility check
if plugin.metadata.min_sdk_version > current_sdk_version:
    raise IncompatiblePluginError(
        f"Plugin requires SDK >= {plugin.metadata.min_sdk_version}, "
        f"but current SDK is {current_sdk_version}"
    )
```

## Deprecation Workflow

### Deprecation Timeline

1. **Announce** - Mark as deprecated in MINOR release (with warnings)
2. **Maintain** - Keep working for at least 2 MINOR releases
3. **Remove** - Remove in next MAJOR release

### Deprecation Markers

Use `warnings.warn()` with `DeprecationWarning`:

```python
import warnings

def old_method():
    warnings.warn(
        "old_method() is deprecated, use new_method() instead. "
        "Will be removed in SDK 2.0.0",
        DeprecationWarning,
        stacklevel=2,
    )
    return new_method()
```

### Documentation Requirements

When deprecating:
1. Add `@deprecated` note in docstring
2. Update CHANGELOG.md with deprecation notice
3. Add migration guide in docs/migration/
4. Update README if feature is prominently documented

### Example Deprecation

```python
from flukebase_sdk import BasePlugin

class BasePlugin:
    def get_tools(self) -> list[ToolDefinition]:
        """Return tool definitions.

        .. deprecated:: 0.3.0
           Use :meth:`tools` property instead. Will be removed in 1.0.0.
        """
        warnings.warn(
            "get_tools() is deprecated, use the tools property instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.tools

    @property
    def tools(self) -> list[ToolDefinition]:
        """Tool definitions for this plugin."""
        raise NotImplementedError
```

## Release Process

### Version Bump Checklist

- [ ] Update version in `pyproject.toml`
- [ ] Update version in `src/flukebase_sdk/__init__.py`
- [ ] Update CHANGELOG.md with all changes
- [ ] Update compatibility matrix if needed
- [ ] Tag release with `v{version}` (e.g., `v0.2.0`)
- [ ] CI automatically publishes to PyPI

### Pre-release Versions

For testing before official release:

```
0.2.0a1   # Alpha 1
0.2.0b1   # Beta 1
0.2.0rc1  # Release candidate 1
```

### Long-Term Support (LTS)

- No LTS versions during 0.x development
- LTS policy will be defined for 1.x+ releases
- LTS versions receive security fixes for extended period

## Version Discovery

### Checking SDK Version

```python
import flukebase_sdk
print(flukebase_sdk.__version__)  # "0.1.0"
```

### Programmatic Version Comparison

```python
from packaging.version import Version

sdk_version = Version(flukebase_sdk.__version__)
required_version = Version("0.2.0")

if sdk_version < required_version:
    raise RuntimeError(f"SDK {sdk_version} too old, need {required_version}+")
```

## Stability Guarantees

### During 0.x (Current)

- API may change between MINOR versions
- Breaking changes documented in CHANGELOG
- Best effort to minimize disruption
- Deprecation warnings when feasible

### Starting 1.0.0 (Future)

- Full semantic versioning guarantees
- No breaking changes without MAJOR bump
- Minimum 6-month deprecation periods
- LTS versions available

## Questions?

For versioning questions or compatibility concerns:
- Open an issue on [GitHub](https://github.com/flukebase/flukebase-sdk/issues)
- Tag with `versioning` or `compatibility`
