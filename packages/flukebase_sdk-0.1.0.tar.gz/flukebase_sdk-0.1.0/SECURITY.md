# Plugin Security Model

This document describes the security architecture for FlukeBase plugins, including sandboxing, scope enforcement, and isolation mechanisms.

## Overview

FlukeBase Connect implements a **defense-in-depth** security model for third-party plugins:

1. **Scope Declaration**: Plugins declare required permissions in metadata
2. **User Approval**: Elevated permissions require explicit user consent
3. **Runtime Enforcement**: FlukeBase Connect restricts service access
4. **Sandbox Isolation**: Plugins run in isolated environments

## Scope System

### Declaring Scopes

Plugins declare required scopes in their `PluginMetadata`:

```python
from flukebase_sdk import BasePlugin, PluginMetadata, PluginScope

class MyPlugin(BasePlugin):
    def get_metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name="my-plugin",
            version="1.0.0",
            required_scopes=[
                PluginScope.MEMORY_READ,
                PluginScope.MEMORY_WRITE,
                PluginScope.WEDO_READ,
            ],
            ...
        )
```

### Available Scopes

| Scope | Description | Elevated |
|-------|-------------|----------|
| `memory:read` | Read memories from local store | No |
| `memory:write` | Store and delete memories | No |
| `wedo:read` | View WeDo tasks and progress | No |
| `wedo:write` | Create and update WeDo tasks | No |
| `wedo:delete` | Delete WeDo tasks | No |
| `env:read` | Read environment variables (secrets masked) | No |
| `env:read_secrets` | Read unmasked secret values | **Yes** |
| `api:read` | Read from FlukeBase API | No |
| `api:write` | Write to FlukeBase API | No |
| `config:read` | Read configuration values | No |
| `fs:read_project` | Read files in project directory | No |
| `fs:write_project` | Write files in project directory | **Yes** |
| `network:outbound` | Make outbound network requests | No |
| `subprocess:safe` | Run safe subprocess commands | No |
| `subprocess:unrestricted` | Run any subprocess command | **Yes** |

### Elevated Scopes

Scopes marked as "Elevated" require explicit user approval before the plugin can be loaded. Users are prompted during plugin installation:

```
Plugin 'dangerous-plugin' requests elevated permissions:
  - env:read_secrets: Read unmasked secret values
  - subprocess:unrestricted: Run any subprocess command

Do you want to grant these permissions? [y/N]
```

### Scope Validation

Use SDK utilities to validate scopes:

```python
from flukebase_sdk import validate_scopes, requires_approval, get_scope_description

# Check if scopes are valid
is_valid, invalid = validate_scopes(["memory:read", "invalid:scope"])
# is_valid = False, invalid = ["invalid:scope"]

# Check which scopes need approval
elevated = requires_approval(["memory:read", "env:read_secrets"])
# elevated = [PluginScope.ENV_READ_SECRETS]

# Get human-readable description
desc = get_scope_description("memory:write")
# desc = "Store and delete memories"
```

## Runtime Enforcement

### Service Access Control

FlukeBase Connect restricts service access based on declared scopes:

```python
# Plugin declared: required_scopes=["memory:read"]

# This works - read access granted
memories = await self.memory.recall(query="test")

# This fails - write access not declared
await self.memory.remember(content="test", type="fact")
# Raises: PermissionError("Plugin 'my-plugin' lacks scope 'memory:write'")
```

### Enforcement Points

| Service | Read Scope | Write Scope | Delete Scope |
|---------|------------|-------------|--------------|
| MemoryStore | `memory:read` | `memory:write` | `memory:write` |
| WedoManager | `wedo:read` | `wedo:write` | `wedo:delete` |
| EnvManager | `env:read` | N/A | N/A |
| FlukeBase API | `api:read` | `api:write` | N/A |
| Config | `config:read` | N/A | N/A |

### Masked Service Proxies

Instead of direct service access, plugins receive proxy objects that enforce scopes:

```python
# Internal implementation (simplified)
class ScopedMemoryProxy:
    def __init__(self, memory: MemoryStore, allowed_scopes: set[str]):
        self._memory = memory
        self._scopes = allowed_scopes

    async def recall(self, query: str, **kwargs):
        if "memory:read" not in self._scopes:
            raise PermissionError("Requires scope: memory:read")
        return await self._memory.recall(query, **kwargs)

    async def remember(self, content: str, **kwargs):
        if "memory:write" not in self._scopes:
            raise PermissionError("Requires scope: memory:write")
        return await self._memory.remember(content, **kwargs)
```

## Sandbox Isolation

### Process Isolation

Plugins can be run in isolated subprocess sandboxes:

- **Separate process**: Plugin runs in a child process
- **Limited resources**: CPU, memory, and time limits enforced
- **Network filtering**: Outbound connections require `network:outbound` scope
- **Filesystem jailing**: Access limited to project directory with appropriate scopes

### Sandbox Configuration

FlukeBase Connect configuration controls sandbox behavior:

```yaml
# ~/.config/flukebase/config.yaml
plugins:
  sandbox:
    enabled: true
    timeout_seconds: 30
    max_memory_mb: 512
    allow_network: false  # Override with network:outbound scope
```

### Marketplace Plugin Isolation

Plugins installed from the marketplace run with additional restrictions:

1. **Code signature verification**: Package hash verified against registry
2. **Automatic sandboxing**: All marketplace plugins run in sandbox by default
3. **Scope audit**: Scopes reviewed during marketplace approval
4. **Update validation**: New versions must maintain scope compatibility

## Security Best Practices for Plugin Developers

### Request Minimum Scopes

Only request scopes your plugin actually needs:

```python
# Good - minimal scopes
required_scopes=[PluginScope.MEMORY_READ]

# Bad - requesting unnecessary scopes
required_scopes=[
    PluginScope.MEMORY_READ,
    PluginScope.MEMORY_WRITE,
    PluginScope.ENV_READ_SECRETS,  # Do you really need this?
    PluginScope.SUBPROCESS_UNRESTRICTED,  # Very dangerous
]
```

### Handle Permission Errors Gracefully

```python
async def handle_my_tool(self, args: dict) -> str:
    try:
        await self.memory.remember(content="test", type="fact")
        return "Saved!"
    except PermissionError as e:
        return f"Cannot save: plugin lacks required permissions"
```

### Validate Input Thoroughly

Never trust tool input:

```python
async def handle_read_file(self, args: dict) -> str:
    path = args.get("path", "")

    # Validate path is within project
    resolved = Path(path).resolve()
    if not str(resolved).startswith(str(self.project_dir)):
        return "Error: Path outside project directory"

    # Additional validation
    if ".." in path:
        return "Error: Path traversal not allowed"

    # Safe to proceed
    ...
```

### Never Log Secrets

```python
# Bad
print(f"Connecting with API key: {api_key}")

# Good
masked = api_key[:4] + "****" if api_key else "None"
print(f"Connecting with API key: {masked}")
```

### Use Scoped Credentials

If your plugin needs credentials, use short-lived scoped tokens:

```python
# Request minimal permissions for the specific operation
token = await self.client.create_scoped_token(
    scope="read:project:123",
    ttl_minutes=5,
)
```

## Incident Response

### Reporting Security Issues

If you discover a security vulnerability in FlukeBase or the SDK:

1. **Do not** disclose publicly
2. Email security@flukebase.com with details
3. Include reproduction steps if possible
4. Allow 90 days for patching before disclosure

### Plugin Removal

Malicious plugins can be emergency-removed from:

- User's local installation (via CLI)
- FlukeBase Marketplace (by maintainers)
- All connected systems (via remote disable)

## Compliance

### Data Handling

Plugins that handle sensitive data should:

- Minimize data collection
- Encrypt data at rest
- Respect user data deletion requests
- Document data practices in README

### Audit Logging

FlukeBase Connect logs plugin activity for security audits:

```
[2024-01-06T12:00:00Z] Plugin 'my-plugin' called memory.remember (scope: memory:write)
[2024-01-06T12:00:01Z] Plugin 'my-plugin' called wedo.create_task (scope: wedo:write)
```

Access logs via:
```bash
flukebase-connect logs --plugin my-plugin --since 24h
```

## Questions?

For security-related questions, contact security@flukebase.com or open an issue with the `security` label.
