"""Plugin metadata definitions."""

from dataclasses import dataclass, field
from enum import Enum


class PluginType(Enum):
    """Types of plugins supported by FlukeBase Connect."""

    AI_PROVIDER = "ai_provider"
    INTEGRATION = "integration"
    TOOL = "tool"


class PluginMaturity(Enum):
    """Maturity levels for plugins."""

    CONCEPTUAL = "conceptual"  # Idea phase, not fully functional
    MVP = "mvp"  # Basic functionality, limited testing
    BETA = "beta"  # Feature complete, testing in progress
    PRODUCTION = "production"  # Full featured, tested, stable


@dataclass
class PluginMetadata:
    """Metadata describing a plugin."""

    name: str  # Unique identifier (e.g., "flukebase-core")
    display_name: str  # Human-readable name (e.g., "FlukeBase Core")
    version: str
    description: str
    plugin_type: PluginType
    maturity: PluginMaturity
    author: str = ""
    homepage: str = ""
    required_scopes: list[str] = field(default_factory=list)
    configuration_schema: dict = field(default_factory=dict)
    features: dict[str, bool] = field(default_factory=dict)
    # ORCH-001: Plugin dependencies for initialization ordering
    dependencies: list[str] = field(default_factory=list)
    # AI-ARCH-001: AI agent comprehension fields
    tool_registration: str = "self"  # "self" | "manifest" | "dynamic"
    manifest_reference: str = ""  # e.g., "manifest.py:1497-2200"
    # Example: {"mem_": "Memory ops"}
    tool_prefixes: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert metadata to dictionary for API responses."""
        return {
            "name": self.name,
            "display_name": self.display_name,
            "version": self.version,
            "description": self.description,
            "plugin_type": self.plugin_type.value,
            "maturity": self.maturity.value,
            "author": self.author,
            "homepage": self.homepage,
            "required_scopes": self.required_scopes,
            "configuration_schema": self.configuration_schema,
            "features": self.features,
            "dependencies": self.dependencies,
            "tool_registration": self.tool_registration,
            "manifest_reference": self.manifest_reference,
            "tool_prefixes": self.tool_prefixes,
        }
