"""Service protocol interfaces for FlukeBase plugins.

This module defines Protocol classes (typing.Protocol) that establish the
CONTRACT between plugins and the FlukeBase Connect runtime. These protocols
define the method signatures that plugins can rely on without exposing
implementation details.

IMPORTANT: Protocols are STRUCTURAL types - any class that implements these
methods is considered to satisfy the protocol, regardless of inheritance.
Use @runtime_checkable if you need isinstance() checks.

Usage in plugins:
    from flukebase_sdk.protocols import FlukeBaseClientProtocol, MemoryStoreProtocol

    class MyPlugin(BasePlugin):
        async def initialize(self, config: dict, services: dict) -> None:
            await super().initialize(config, services)
            # Type-safe service access
            self.client: FlukeBaseClientProtocol = self.get_service("flukebase_client")
            self.memory: MemoryStoreProtocol = self.get_service("memory")
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Literal, Protocol, runtime_checkable

# Type aliases for clarity
MemoryType = Literal["fact", "convention", "gotcha", "decision"]
ScopeType = str | list[str] | Literal["all"]
WedoStatusType = Literal["pending", "in_progress", "completed", "blocked"]
WedoDependencyType = Literal["USER_REQUIRED", "AGENT_CAPABLE"]
TaskPriorityType = Literal["critical", "high", "normal", "low", "none"]


# =============================================================================
# FlukeBase API Client Protocol
# =============================================================================


@runtime_checkable
class FlukeBaseClientProtocol(Protocol):
    """Protocol for FlukeBase API client.

    Provides async methods for communicating with the FlukeBase platform API
    including project management, environment sync, memories, time tracking,
    webhooks, agents, and multi-project batch operations.

    The actual implementation handles HTTP communication, authentication,
    error handling, and response parsing.
    """

    # --- Properties ---

    @property
    def is_configured(self) -> bool:
        """Check if the client is properly configured with an API token."""
        ...

    # --- Connection Management ---

    async def close(self) -> None:
        """Close the HTTP client and release resources."""
        ...

    async def get_status(self) -> dict:
        """Get FlukeBase connection status.

        Returns:
            Dict with 'connected' (bool), 'user_email', 'project_id', 'project_count'.
        """
        ...

    # --- Authentication ---

    async def validate_token(self) -> dict:
        """Validate the current API token.

        Returns:
            Dict with validation result from the server.

        Raises:
            AuthError: If token is invalid or expired.
        """
        ...

    async def generate_scoped_token(
        self,
        scope: str,
        ttl_minutes: int = 60,
        permissions: list[str] | None = None,
    ) -> dict:
        """Generate a scoped, short-lived API token for container execution.

        Args:
            scope: Scope identifier (e.g., "container:pool-abc123").
            ttl_minutes: Token time-to-live in minutes (default: 60, max: 480).
            permissions: Optional list of permission scopes.

        Returns:
            Dict with 'token', 'expires_at', 'scope', 'permissions'.
        """
        ...

    async def get_current_user(self) -> Any:
        """Get authenticated user info.

        Returns:
            User object with id, email, name, project_count.
        """
        ...

    # --- Projects ---

    async def list_projects(self) -> list[Any]:
        """List all accessible projects.

        Returns:
            List of Project objects.
        """
        ...

    async def get_project(self, project_id: int) -> Any:
        """Get project by ID.

        Args:
            project_id: FlukeBase project ID.

        Returns:
            Project object.
        """
        ...

    async def create_project(
        self,
        name: str,
        repository_url: str | None = None,
        description: str | None = None,
        stage: str = "prototype",
    ) -> Any:
        """Create a new project.

        Args:
            name: Project name.
            repository_url: Optional GitHub repository URL.
            description: Optional project description.
            stage: Project stage (default: "prototype").

        Returns:
            Created Project object.
        """
        ...

    async def get_project_by_repo(self, repo_url: str) -> Any | None:
        """Get project by repository URL.

        Args:
            repo_url: GitHub repository URL.

        Returns:
            Project object if found, None otherwise.
        """
        ...

    async def get_project_context(self, project_id: int) -> dict:
        """Get full project context for AI.

        Args:
            project_id: FlukeBase project ID.

        Returns:
            Dict with project context data.
        """
        ...

    # --- Environment Variables ---

    async def get_environment(
        self, project_id: int, environment: str = "development"
    ) -> list[Any]:
        """Get environment variables for project.

        Args:
            project_id: FlukeBase project ID.
            environment: Environment name (development, staging, production).

        Returns:
            List of EnvironmentVariable objects.
        """
        ...

    async def record_sync(
        self, project_id: int, environment: str = "development"
    ) -> dict:
        """Record that an environment sync happened.

        Args:
            project_id: FlukeBase project ID.
            environment: Environment name.

        Returns:
            Dict with sync result.
        """
        ...

    # --- Memories ---

    async def list_memories(
        self,
        project_id: int,
        memory_type: str | None = None,
        since: datetime | None = None,
        synced: bool | None = None,
    ) -> list[Any]:
        """List memories for a project.

        Args:
            project_id: FlukeBase project ID.
            memory_type: Optional filter by type (fact, convention, gotcha, decision).
            since: Optional filter for memories updated after this datetime.
            synced: Optional filter for sync status.

        Returns:
            List of Memory objects.
        """
        ...

    async def get_memory(self, project_id: int, memory_id: int) -> Any:
        """Get a specific memory.

        Args:
            project_id: FlukeBase project ID.
            memory_id: Memory ID.

        Returns:
            Memory object.
        """
        ...

    async def create_memory(
        self,
        project_id: int,
        memory_type: str,
        content: str,
        key: str | None = None,
        rationale: str | None = None,
        tags: list[str] | None = None,
        references: dict | None = None,
        external_id: str | None = None,
    ) -> Any:
        """Create a new memory.

        Args:
            project_id: FlukeBase project ID.
            memory_type: Type of memory (fact, convention, gotcha, decision).
            content: Memory content.
            key: Optional key for conventions.
            rationale: Optional rationale/explanation.
            tags: Optional list of tags.
            references: Optional dict of references.
            external_id: Optional external ID for sync.

        Returns:
            Created Memory object.
        """
        ...

    async def update_memory(
        self,
        project_id: int,
        memory_id: int,
        content: str | None = None,
        rationale: str | None = None,
        tags: list[str] | None = None,
    ) -> Any:
        """Update an existing memory.

        Args:
            project_id: FlukeBase project ID.
            memory_id: Memory ID to update.
            content: Optional new content.
            rationale: Optional new rationale.
            tags: Optional new tags list.

        Returns:
            Updated Memory object.
        """
        ...

    async def delete_memory(self, project_id: int, memory_id: int) -> bool:
        """Delete a memory.

        Args:
            project_id: FlukeBase project ID.
            memory_id: Memory ID to delete.

        Returns:
            True if deleted successfully.
        """
        ...

    async def bulk_push_memories(self, project_id: int, memories: list[dict]) -> dict:
        """Push memories to FlukeBase remote (upsert by external_id).

        Args:
            project_id: FlukeBase project ID.
            memories: List of memory dicts.

        Returns:
            Dict with push result summary.
        """
        ...

    async def search_memories_cross_project(
        self,
        query: str | None = None,
        memory_type: str | None = None,
        tag: str | None = None,
        page: int = 1,
        per_page: int = 50,
    ) -> dict:
        """Search memories across ALL accessible projects.

        Args:
            query: Search string to match against memory content.
            memory_type: Filter by type (fact, convention, gotcha, decision).
            tag: Filter by tag.
            page: Page number for pagination.
            per_page: Results per page (max 100).

        Returns:
            Dict with memories list and meta.
        """
        ...

    # --- WeDo Tasks ---

    async def list_tasks(
        self,
        project_id: int,
        status: str | None = None,
        scope: str = "global",
        since_version: int = 0,
        assignee_id: int | None = None,
        root_only: bool = False,
        page: int = 1,
        per_page: int = 50,
    ) -> dict:
        """List WeDo tasks for a project.

        Args:
            project_id: FlukeBase project ID.
            status: Filter by status.
            scope: Filter by scope.
            since_version: Only return tasks with version > N.
            assignee_id: Filter by assignee user ID.
            root_only: Only return tasks without parent.
            page: Page number.
            per_page: Items per page.

        Returns:
            Dict with tasks list and meta.
        """
        ...

    async def get_task(self, project_id: int, task_id: str) -> dict:
        """Get a single WeDo task by task_id.

        Args:
            project_id: FlukeBase project ID.
            task_id: Task identifier (e.g., "WISH-YTA").

        Returns:
            Dict with task data.
        """
        ...

    async def create_task(
        self,
        project_id: int,
        task_id: str,
        description: str,
        status: str = "pending",
        dependency: str = "AGENT_CAPABLE",
        scope: str = "global",
        priority: str = "normal",
        tags: list[str] | None = None,
        blocked_by: list[str] | None = None,
        artifact_path: str | None = None,
        remote_url: str | None = None,
        parent_task_id: str | None = None,
        external_id: str | None = None,
        agent_id: str | None = None,
    ) -> dict:
        """Create a new WeDo task.

        Args:
            project_id: FlukeBase project ID.
            task_id: Task identifier.
            description: Task description.
            status: Initial status.
            dependency: USER_REQUIRED or AGENT_CAPABLE.
            scope: Task scope.
            priority: low, normal, high, urgent.
            tags: List of tag strings.
            blocked_by: List of task_ids that block this task.
            artifact_path: Local file reference.
            remote_url: GitHub PR/issue URL.
            parent_task_id: Parent task for subtasks.
            external_id: UUID for CLI sync tracking.
            agent_id: Agent ID to record.

        Returns:
            Dict with created task data.
        """
        ...

    async def update_task(
        self,
        project_id: int,
        task_id: str,
        version: int = 0,
        status: str | None = None,
        description: str | None = None,
        priority: str | None = None,
        synthesis_note: str | None = None,
        agent_id: str | None = None,
        artifact_path: str | None = None,
        remote_url: str | None = None,
        blocked_by: list[str] | None = None,
        tags: list[str] | None = None,
        assignee_id: int | None = None,
        due_date: str | None = None,
    ) -> dict:
        """Update a WeDo task with optimistic locking.

        Args:
            project_id: FlukeBase project ID.
            task_id: Task identifier.
            version: Client's version for conflict detection.
            status: New status.
            description: New description.
            priority: New priority.
            synthesis_note: Note to append to audit trail.
            agent_id: Agent ID for synthesis note.
            artifact_path: Local file reference.
            remote_url: GitHub PR/issue URL.
            blocked_by: List of blocking task IDs.
            tags: List of tags.
            assignee_id: User ID to assign.
            due_date: Due date (ISO format).

        Returns:
            Dict with updated task data.
        """
        ...

    async def delete_task(self, project_id: int, task_id: str) -> bool:
        """Delete a WeDo task.

        Args:
            project_id: FlukeBase project ID.
            task_id: Task identifier.

        Returns:
            True if deleted successfully.
        """
        ...

    async def bulk_push_tasks(self, project_id: int, tasks: list[dict]) -> dict:
        """Push WeDo tasks to FlukeBase remote.

        Args:
            project_id: FlukeBase project ID.
            tasks: List of task dicts.

        Returns:
            Dict with push result summary.
        """
        ...

    # --- Agents ---

    async def register_agent(
        self,
        project_id: int,
        agent_id: str,
        persona_name: str | None = None,
        agent_type: str = "claude_code",
        capabilities: list[str] | None = None,
        client_version: str | None = None,
        metadata: dict | None = None,
    ) -> dict:
        """Register or update an agent session.

        Args:
            project_id: FlukeBase project ID.
            agent_id: Unique agent identifier.
            persona_name: Named persona (e.g., ZION, KORE).
            agent_type: Type of agent.
            capabilities: List of capabilities.
            client_version: Version of flukebase_connect.
            metadata: Additional metadata dict.

        Returns:
            Registered agent session dict.
        """
        ...

    async def agent_heartbeat(
        self,
        project_id: int,
        agent_id: str,
        tokens_used: int = 0,
        tools_executed: int = 0,
        metadata: dict | None = None,
    ) -> dict:
        """Send agent heartbeat to keep session alive.

        Args:
            project_id: FlukeBase project ID.
            agent_id: Agent identifier.
            tokens_used: Tokens used since last heartbeat.
            tools_executed: Tools executed since last heartbeat.
            metadata: Additional metadata to update.

        Returns:
            Updated agent session dict.
        """
        ...

    async def list_agents(
        self,
        project_id: int,
        status: str | None = None,
        agent_type: str | None = None,
        connected_only: bool = False,
        refresh_status: bool = False,
        page: int = 1,
        per_page: int = 50,
    ) -> dict:
        """List agent sessions for a project.

        Args:
            project_id: FlukeBase project ID.
            status: Filter by status.
            agent_type: Filter by agent type.
            connected_only: Only return connected agents.
            refresh_status: Mark stale agents as idle.
            page: Page number.
            per_page: Items per page.

        Returns:
            Dict with agents list and meta.
        """
        ...

    # --- Webhooks ---

    async def list_webhooks(self, project_id: int) -> list[dict]:
        """List webhook subscriptions for a project.

        Args:
            project_id: FlukeBase project ID.

        Returns:
            List of webhook dicts.
        """
        ...

    async def create_webhook(
        self,
        project_id: int,
        callback_url: str,
        events: list[str] | None = None,
    ) -> dict:
        """Create a webhook subscription.

        Args:
            project_id: FlukeBase project ID.
            callback_url: URL to receive webhook events.
            events: List of event types to subscribe to.

        Returns:
            Created webhook dict.
        """
        ...

    async def delete_webhook(self, project_id: int, webhook_id: int) -> bool:
        """Delete a webhook subscription.

        Args:
            project_id: FlukeBase project ID.
            webhook_id: Webhook ID to delete.

        Returns:
            True if deleted successfully.
        """
        ...

    # --- Batch Operations ---

    async def batch_get_project_contexts(
        self,
        project_ids: list[int] | None = None,
        all_projects: bool = False,
    ) -> dict:
        """Get context for multiple projects at once.

        Args:
            project_ids: List of project IDs to fetch.
            all_projects: If True, fetch for ALL accessible projects.

        Returns:
            Dict with contexts list and meta.
        """
        ...

    async def batch_get_environments(
        self,
        project_ids: list[int] | None = None,
        environment: str = "development",
        all_projects: bool = False,
    ) -> dict:
        """Get environment variables for multiple projects at once.

        Args:
            project_ids: List of project IDs.
            environment: Environment name.
            all_projects: If True, fetch for ALL accessible projects.

        Returns:
            Dict with environments list and meta.
        """
        ...

    async def batch_pull_memories(
        self,
        project_ids: list[int] | None = None,
        memory_type: str | None = None,
        tag: str | None = None,
        since: datetime | None = None,
        all_projects: bool = False,
    ) -> dict:
        """Pull memories from multiple projects at once.

        Args:
            project_ids: List of project IDs.
            memory_type: Filter by type.
            tag: Filter by tag.
            since: Only return memories updated since this datetime.
            all_projects: If True, pull from ALL accessible projects.

        Returns:
            Dict with projects/memories and meta.
        """
        ...


# =============================================================================
# Memory Store Protocol (Local SQLite Storage)
# =============================================================================


@runtime_checkable
class MemoryStoreProtocol(Protocol):
    """Protocol for local memory/knowledge storage.

    Provides methods for storing and retrieving project knowledge locally
    in a SQLite database. Supports facts, conventions, gotchas, and decisions
    with scope-based organization and search capabilities.
    """

    def list_scopes(self) -> list[str]:
        """List all available scopes (global + all projects).

        Returns:
            List of scope names, always includes 'global' first.
        """
        ...

    async def remember(
        self,
        content: str,
        type: MemoryType = "fact",
        scope: str = "global",
        tags: list[str] | None = None,
        references: dict | None = None,
    ) -> Any:
        """Store a new memory.

        Args:
            content: Memory content text.
            type: Memory type (fact, convention, gotcha, decision).
            scope: Scope for the memory (default: "global").
            tags: Optional list of tags for categorization.
            references: Optional dict of references/metadata.

        Returns:
            Fact object representing the stored memory.
        """
        ...

    async def recall(
        self,
        query: str,
        type: MemoryType | None = None,
        scope: ScopeType | None = None,
        limit: int = 10,
        include_scope_info: bool = True,
    ) -> list[Any]:
        """Search memory across scopes.

        Args:
            query: Search string to match against content and tags.
            type: Optional filter by memory type.
            scope: Scopes to search (None/"all" = all scopes).
            limit: Maximum number of results to return.
            include_scope_info: If True, includes scope in results.

        Returns:
            List of Fact objects matching the query.
        """
        ...

    async def forget(self, id: str, scope: ScopeType | None = None) -> dict:
        """Remove a memory by ID.

        Args:
            id: The memory ID to remove.
            scope: Where to search for the memory.

        Returns:
            Dict with 'success' (bool) and 'scope' (where found).
        """
        ...

    async def set_convention(
        self,
        key: str,
        value: str,
        rationale: str | None = None,
        scope: str = "global",
    ) -> Any:
        """Set or update a convention.

        Args:
            key: Convention key identifier.
            value: Convention value/rule.
            rationale: Optional explanation of why this convention exists.
            scope: Scope for the convention.

        Returns:
            Convention object.
        """
        ...

    async def get_convention(self, key: str, scope: str = "global") -> Any | None:
        """Get a convention by key.

        Args:
            key: Convention key identifier.
            scope: Scope to search in.

        Returns:
            Convention object if found, None otherwise.
        """
        ...

    async def list_conventions(self, scope: str = "global") -> list[Any]:
        """List all conventions for a scope.

        Args:
            scope: Scope to list conventions from.

        Returns:
            List of Convention objects.
        """
        ...


# =============================================================================
# WeDo Manager Protocol (Task Management)
# =============================================================================


@runtime_checkable
class WedoManagerProtocol(Protocol):
    """Protocol for WeDo task management.

    Provides functionality for:
    - Agent registration and session management
    - WeDo task CRUD operations
    - Template creation and instantiation
    - Memory access tracking
    - Task dependency and relationship management
    """

    # --- Agent Management ---

    async def register_agent(
        self,
        agent_id: str | None = None,
        name: str | None = None,
        is_named_persona: bool = False,
        metadata: dict | None = None,
        client_type: str | None = None,
        client_version: str | None = None,
    ) -> Any:
        """Register an agent (named persona or auto-generated session ID).

        Args:
            agent_id: Optional agent ID (auto-generated if not provided).
            name: Human-readable name (e.g., ZION, KORE).
            is_named_persona: True for persistent personas.
            metadata: Optional additional agent metadata.
            client_type: MCP client type.
            client_version: MCP client version.

        Returns:
            Registered Agent object.
        """
        ...

    async def get_agent(self, agent_id: str) -> Any | None:
        """Get an agent by ID.

        Args:
            agent_id: The agent ID to look up.

        Returns:
            Agent object if found, None otherwise.
        """
        ...

    async def list_agents(self, named_only: bool = False) -> list[Any]:
        """List all registered agents.

        Args:
            named_only: If True, only return named personas.

        Returns:
            List of Agent objects.
        """
        ...

    def get_current_agent_id(self) -> str | None:
        """Get the current agent ID.

        Returns:
            Current agent ID or None if not set.
        """
        ...

    def set_current_agent(self, agent_id: str) -> None:
        """Set the current agent ID for tracking.

        Args:
            agent_id: Agent ID to set as current.
        """
        ...

    async def heartbeat(self, agent_id: str | None = None) -> bool:
        """Update agent's last_active timestamp.

        Args:
            agent_id: Agent ID to update (uses current if not specified).

        Returns:
            True if heartbeat was successful.
        """
        ...

    async def start_session(self, agent_id: str, scope: str = "global") -> Any:
        """Start a new agent session.

        Args:
            agent_id: The agent starting the session.
            scope: Scope for the session.

        Returns:
            Created AgentSession object.
        """
        ...

    async def end_session(self, session_id: str) -> None:
        """End an agent session.

        Args:
            session_id: The session ID to end.
        """
        ...

    # --- Task Management ---

    async def create_task(
        self,
        task_id: str,
        description: str,
        dependency: Any = None,
        scope: str = "global",
        parent_task_id: str | None = None,
        template_id: str | None = None,
        tags: list[str] | None = None,
        artifact_path: str | None = None,
        remote_url: str | None = None,
        project_ids: list[int] | None = None,
        priority: Any = None,
        urgency: Any = None,
        due_date: str | None = None,
        estimated_minutes: int | None = None,
        assignee_type: Any = None,
        assignee_id: str | None = None,
        task_type: Any = None,
        metadata: dict | None = None,
    ) -> Any:
        """Create a new WeDo task.

        Args:
            task_id: Unique task identifier (e.g., WISH-YTA, META-01).
            description: Task description.
            dependency: USER_REQUIRED or AGENT_CAPABLE.
            scope: Scope for the task.
            parent_task_id: Optional parent task ID for subtasks.
            template_id: Optional template this task was created from.
            tags: Optional list of tags.
            artifact_path: Local file path reference.
            remote_url: Remote URL reference (e.g., GitHub).
            project_ids: List of FlukeBase project IDs.
            priority: Task priority level.
            urgency: Time urgency for the task.
            due_date: Optional due date (ISO 8601 format).
            estimated_minutes: Estimated time to complete.
            assignee_type: Type of assignee.
            assignee_id: ID of the assignee.
            task_type: Classification type.
            metadata: Custom key-value pairs.

        Returns:
            Created WedoTask object.
        """
        ...

    async def get_task(self, task_id: str) -> Any | None:
        """Get a task by ID.

        Args:
            task_id: The task ID to look up.

        Returns:
            WedoTask object if found, None otherwise.
        """
        ...

    async def update_task_status(
        self,
        task_id: str,
        status: Any,
        synthesis_note: str | None = None,
        check_dependencies: bool = True,
    ) -> Any | None:
        """Update task status and append to synthesis report.

        Args:
            task_id: The task ID to update.
            status: New status.
            synthesis_note: Note to append to audit trail.
            check_dependencies: If True and status is IN_PROGRESS, verify dependencies.

        Returns:
            Updated WedoTask or None if not found.

        Raises:
            ValueError: If trying to start a task with unmet dependencies.
        """
        ...

    async def delete_task(self, task_id: str) -> bool:
        """Delete a task by ID.

        Args:
            task_id: The task ID to delete.

        Returns:
            True if deleted, False if not found.
        """
        ...

    async def list_tasks(
        self,
        status: Any | None = None,
        scope: str = "global",
        agent_id: str | None = None,
        project_ids: list[int] | None = None,
        limit: int = 50,
    ) -> list[Any]:
        """List tasks with optional filters.

        Args:
            status: Filter by status.
            scope: Filter by scope ("all" for all scopes).
            agent_id: Filter by creator agent.
            project_ids: Filter by project IDs.
            limit: Maximum results to return.

        Returns:
            List of WedoTask objects.
        """
        ...

    async def get_status(self, scope: str = "global") -> dict:
        """Get WeDo manager status summary.

        Args:
            scope: Scope to get status for.

        Returns:
            Dict with task counts and agent info.
        """
        ...

    # --- Milestone/Progress ---

    async def get_milestone_progress(
        self,
        milestone_id: str,
        scope: str = "global",
    ) -> dict:
        """Get progress statistics for a milestone (parent task).

        Args:
            milestone_id: The milestone task ID.
            scope: Filter by scope.

        Returns:
            Dict with progress statistics.
        """
        ...

    async def get_all_milestones_progress(self, scope: str = "global") -> list[dict]:
        """Get progress for all milestones in a scope.

        Args:
            scope: Filter by scope.

        Returns:
            List of progress dictionaries for each milestone.
        """
        ...

    # --- Relationships ---

    async def add_relationship(
        self,
        source_task_id: str,
        target_task_id: str,
        relationship_type: Any,
        metadata: dict | None = None,
    ) -> Any:
        """Add a relationship between two tasks.

        Args:
            source_task_id: The source task ID.
            target_task_id: The target task ID.
            relationship_type: Type of relationship.
            metadata: Optional metadata for the relationship.

        Returns:
            Created TaskRelationship object.
        """
        ...

    async def remove_relationship(
        self,
        source_task_id: str,
        target_task_id: str,
        relationship_type: Any,
    ) -> bool:
        """Remove a relationship between two tasks.

        Args:
            source_task_id: The source task ID.
            target_task_id: The target task ID.
            relationship_type: Type of relationship to remove.

        Returns:
            True if removed, False if not found.
        """
        ...

    async def get_blocking_tasks(self, task_id: str) -> list[str]:
        """Get all task IDs that are blocking this task.

        Args:
            task_id: The task ID to check.

        Returns:
            List of blocking task IDs.
        """
        ...

    async def check_dependencies_met(self, task_id: str) -> dict:
        """Check if all dependencies for a task are completed.

        Args:
            task_id: The task ID to check.

        Returns:
            Dict with 'met' (bool), 'blocking' (list), 'total' (int).
        """
        ...

    # --- Templates ---

    async def create_template(
        self,
        name: str,
        description: str,
        default_tasks: list[dict],
        scope: str = "global",
    ) -> Any:
        """Create a reusable WeDo template.

        Args:
            name: Template name.
            description: Template description.
            default_tasks: List of task definitions.
            scope: Scope for the template.

        Returns:
            Created WedoTemplate object.
        """
        ...

    async def list_templates(self, scope: str = "global") -> list[Any]:
        """List all templates for a scope.

        Args:
            scope: Scope to filter by.

        Returns:
            List of WedoTemplate objects.
        """
        ...

    async def instantiate_template(
        self,
        template_id: str,
        id_prefix: str,
        scope: str = "global",
    ) -> list[Any]:
        """Create tasks from a template.

        Args:
            template_id: The template to instantiate.
            id_prefix: Prefix for generated task IDs.
            scope: Scope for the created tasks.

        Returns:
            List of created WedoTask objects.
        """
        ...

    # --- Export ---

    async def export_to_markdown(
        self,
        scope: str = "global",
        include_tasks: bool = True,
        include_memories: bool = True,
        temporal_folders: bool = True,
    ) -> Path:
        """Export memories and tasks to markdown files.

        Args:
            scope: Scope to export.
            include_tasks: Include WeDo tasks in export.
            include_memories: Include memories in export.
            temporal_folders: Use YEAR/Q/M/D folder structure.

        Returns:
            Path to the export directory.
        """
        ...


# =============================================================================
# Environment Manager Protocol
# =============================================================================


@runtime_checkable
class EnvManagerProtocol(Protocol):
    """Protocol for environment variable management.

    Handles .env file generation, syncing with FlukeBase, caching,
    and environment variable inheritance for sandboxes.
    """

    async def sync_environment(
        self,
        project_id: int,
        project_path: Path,
        environment: str = "development",
    ) -> Path:
        """Sync environment from FlukeBase and generate .env.

        Args:
            project_id: FlukeBase project ID.
            project_path: Path to project directory.
            environment: Environment name.

        Returns:
            Path to generated .env file.
        """
        ...

    def read_env_file(self, env_path: Path) -> dict[str, str]:
        """Read .env file and return as dict (no masking).

        Args:
            env_path: Path to .env file.

        Returns:
            Dict of environment variable key-value pairs.
        """
        ...

    def show_environment(
        self, project_path: Path, mask_secrets: bool = True
    ) -> dict[str, str]:
        """Display current environment (optionally masked).

        Args:
            project_path: Path to project directory.
            mask_secrets: If True, mask secret values.

        Returns:
            Dict of environment variables (potentially masked).
        """
        ...

    async def diff_environment(
        self,
        project_id: int,
        project_path: Path,
        environment: str = "development",
    ) -> dict:
        """Compare local .env with FlukeBase.

        Args:
            project_id: FlukeBase project ID.
            project_path: Path to project directory.
            environment: Environment name.

        Returns:
            Dict with 'added', 'removed', 'changed', 'in_sync' keys.
        """
        ...

    def load_from_cache(
        self, project_path: Path, environment: str = "development"
    ) -> list[dict] | None:
        """Load environment from cache (for offline use).

        Args:
            project_path: Path to project directory.
            environment: Environment name.

        Returns:
            List of variable dicts if cached, None otherwise.
        """
        ...

    def build_inherited_env(
        self,
        project_path: Path | None = None,
        include_defaults: bool = True,
        include_project_env: bool = True,
        include_host_env: bool = True,
        extra_keys: list[str] | None = None,
        extra_patterns: list[str] | None = None,
    ) -> dict[str, str]:
        """Build env vars to forward into sandboxes/Burner sessions.

        Args:
            project_path: Path to project directory.
            include_defaults: Include default AI provider keys.
            include_project_env: Include project .env values.
            include_host_env: Include host environment overrides.
            extra_keys: Additional explicit keys to include.
            extra_patterns: Wildcard patterns to match.

        Returns:
            Dict of environment variables to forward.
        """
        ...


# =============================================================================
# Config Protocol
# =============================================================================


@runtime_checkable
class ConfigProtocol(Protocol):
    """Protocol for configuration access.

    Provides access to FlukeBase Connect configuration including
    API settings, resilience options, gateway settings, and plugin config.
    """

    @property
    def home(self) -> Path:
        """Get the home directory for FlukeBase Connect data."""
        ...

    def to_dict(self) -> dict:
        """Convert configuration to dictionary.

        Returns:
            Dictionary representation of the config.
        """
        ...

    def save(self) -> None:
        """Save configuration to config file."""
        ...

    def ensure_project_context(self) -> None:
        """Ensure project context has been detected."""
        ...

    def refresh_project_context(self, path: Path | None = None) -> None:
        """Refresh project context detection.

        Args:
            path: Optional path to detect from (defaults to cwd).
        """
        ...


# =============================================================================
# Convenience type aliases for service access
# =============================================================================

# These can be used in type hints when accessing services from plugins
ServiceDict = dict[str, Any]


def get_typed_service(services: ServiceDict, name: str, protocol: type) -> Any | None:
    """Helper to get a typed service from the services dict.

    Example:
        client = get_typed_service(
            services, "flukebase_client", FlukeBaseClientProtocol
        )

    Args:
        services: Services dictionary from plugin initialization.
        name: Service name key.
        protocol: Expected protocol type (for documentation).

    Returns:
        Service instance or None if not available.
    """
    return services.get(name)
