"""FlukeBase SDK CLI - Development tools for plugin authors.

Commands:
    new        Create a new plugin from template
    validate   Validate plugin structure and configuration
    test       Run plugin tests with mock services
    info       Show SDK version and environment info
"""

import importlib.util
import subprocess
import sys
from pathlib import Path

try:
    import typer
    from rich.console import Console
    from rich.table import Table
except ImportError:
    print("CLI requires typer and rich. Install with: pip install flukebase-sdk[cli]")
    sys.exit(1)

from flukebase_sdk import __version__

app = typer.Typer(
    name="flukebase-sdk",
    help="FlukeBase SDK - Development tools for plugin authors",
    no_args_is_help=True,
)
console = Console()


@app.command()
def info():
    """Show SDK version and environment information."""
    table = Table(title="FlukeBase SDK Environment")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")

    table.add_row("SDK Version", __version__)
    table.add_row("Python Version", sys.version.split()[0])
    table.add_row("Python Path", sys.executable)
    table.add_row("Working Directory", str(Path.cwd()))

    # Check for optional dependencies
    deps = {
        "pytest": "Testing",
        "pytest-asyncio": "Async Testing",
        "typer": "CLI",
        "rich": "Rich Output",
    }
    for pkg, purpose in deps.items():
        spec = importlib.util.find_spec(pkg.replace("-", "_"))
        status = "[green]installed[/green]" if spec else "[red]not installed[/red]"
        table.add_row(f"{pkg} ({purpose})", status)

    console.print(table)


@app.command()
def new(
    plugin_name: str = typer.Argument(..., help="Name for the new plugin"),
    output_dir: Path | None = typer.Option(
        None, "--output", "-o", help="Output directory (default: current directory)"
    ),
    author: str | None = typer.Option(
        None, "--author", "-a", help="Plugin author name"
    ),
    description: str | None = typer.Option(
        None, "--description", "-d", help="Plugin description"
    ),
):
    """Create a new plugin from template.

    Examples:
        flukebase-sdk new my-awesome-plugin
        flukebase-sdk new my-plugin --author "Jane Dev" --description "Does cool stuff"
    """
    output_dir = output_dir or Path.cwd()

    # Validate plugin name
    if not plugin_name.replace("-", "").replace("_", "").isalnum():
        console.print(
            "[red]Error:[/red] Plugin name must contain only letters, "
            "numbers, hyphens, and underscores"
        )
        raise typer.Exit(1)

    # Convert to module name (underscores)
    module_name = plugin_name.replace("-", "_")

    # Create plugin directory structure
    plugin_dir = output_dir / plugin_name
    if plugin_dir.exists():
        console.print(f"[red]Error:[/red] Directory {plugin_dir} already exists")
        raise typer.Exit(1)

    console.print(f"[cyan]Creating plugin:[/cyan] {plugin_name}")

    # Create directories
    (plugin_dir / "src" / module_name).mkdir(parents=True)
    (plugin_dir / "tests").mkdir(parents=True)

    # Create __init__.py
    init_content = f'''"""FlukeBase plugin: {plugin_name}."""

from {module_name}.plugin import {_to_class_name(module_name)}

__all__ = ["{_to_class_name(module_name)}"]
'''
    (plugin_dir / "src" / module_name / "__init__.py").write_text(init_content)

    # Create plugin.py
    author_str = author or "Your Name"
    desc_str = description or "A FlukeBase plugin"
    plugin_content = f'''"""FlukeBase plugin implementation."""

from flukebase_sdk import (
    BasePlugin,
    PluginMetadata,
    PluginType,
    PluginMaturity,
    ToolDefinition,
)


class {_to_class_name(module_name)}(BasePlugin):
    """{desc_str}."""

    def get_metadata(self) -> PluginMetadata:
        """Return plugin metadata."""
        return PluginMetadata(
            name="{plugin_name}",
            display_name="{_to_display_name(plugin_name)}",
            version="0.1.0",
            description="{desc_str}",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
            author="{author_str}",
            min_sdk_version="0.1.0",
        )

    def get_tools(self) -> list[ToolDefinition]:
        """Return the tools this plugin provides."""
        return [
            ToolDefinition(
                name="{module_name}_hello",
                description="Say hello",
                input_schema={{
                    "type": "object",
                    "properties": {{
                        "name": {{
                            "type": "string",
                            "description": "Name to greet",
                        }}
                    }},
                    "required": ["name"],
                }},
                handler_method="handle_hello",
            )
        ]

    async def handle_hello(self, args: dict) -> str:
        """Handle the hello tool call."""
        name = args.get("name", "World")
        return f"Hello, {{name}}!"
'''
    (plugin_dir / "src" / module_name / "plugin.py").write_text(plugin_content)

    # Create pyproject.toml
    pyproject_content = f'''[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[project]
name = "{plugin_name}"
version = "0.1.0"
description = "{desc_str}"
readme = "README.md"
requires-python = ">=3.11"
authors = [
    {{ name = "{author_str}" }}
]
dependencies = [
    "flukebase-sdk>=0.1.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
]

[project.entry-points."flukebase.plugins"]
{module_name} = "{module_name}:{_to_class_name(module_name)}"

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
'''
    (plugin_dir / "pyproject.toml").write_text(pyproject_content)

    # Create test file
    test_content = f'''"""Tests for {plugin_name}."""

import pytest
from {module_name} import {_to_class_name(module_name)}
from flukebase_sdk.testing import create_mock_services


@pytest.mark.asyncio
async def test_plugin_metadata():
    """Test that plugin metadata is correct."""
    plugin = {_to_class_name(module_name)}()
    metadata = plugin.get_metadata()

    assert metadata.name == "{plugin_name}"
    assert metadata.version == "0.1.0"


@pytest.mark.asyncio
async def test_plugin_has_tools():
    """Test that plugin provides tools."""
    plugin = {_to_class_name(module_name)}()
    tools = plugin.get_tools()

    assert len(tools) >= 1


@pytest.mark.asyncio
async def test_hello_tool():
    """Test the hello tool handler."""
    plugin = {_to_class_name(module_name)}()
    services = create_mock_services()

    await plugin.initialize({{}}, services)

    result = await plugin.handle_hello({{"name": "Test"}})
    assert "Hello" in result
    assert "Test" in result
'''
    (plugin_dir / "tests" / "test_plugin.py").write_text(test_content)

    # Create README
    readme_content = f"""# {_to_display_name(plugin_name)}

{desc_str}

## Installation

```bash
pip install {plugin_name}
```

## Usage

This plugin provides the following tools:

- `{module_name}_hello` - Say hello

## Development

```bash
# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest tests/ -v
```

## License

MIT
"""
    (plugin_dir / "README.md").write_text(readme_content)

    # Create .gitignore
    gitignore_content = """__pycache__/
*.py[cod]
*$py.class
*.egg-info/
dist/
build/
.eggs/
.pytest_cache/
.coverage
htmlcov/
.venv/
venv/
"""
    (plugin_dir / ".gitignore").write_text(gitignore_content)

    console.print(f"[green]Created plugin at:[/green] {plugin_dir}")
    console.print("\n[cyan]Next steps:[/cyan]")
    console.print(f"  cd {plugin_name}")
    console.print("  pip install -e '.[dev]'")
    console.print("  pytest tests/ -v")


@app.command()
def validate(
    path: Path | None = typer.Argument(
        None, help="Path to plugin directory (default: current directory)"
    ),
):
    """Validate plugin structure and configuration.

    Checks:
    - Required files exist (pyproject.toml, plugin module)
    - Plugin class can be imported
    - Metadata is valid
    - Tools have required fields
    - Entry point is configured
    """
    path = path or Path.cwd()
    errors = []
    warnings = []

    console.print(f"[cyan]Validating plugin at:[/cyan] {path}")

    # Check pyproject.toml exists
    pyproject_path = path / "pyproject.toml"
    if not pyproject_path.exists():
        errors.append("pyproject.toml not found")
    else:
        try:
            import tomli

            with open(pyproject_path, "rb") as f:
                pyproject = tomli.load(f)

            # Check for entry point
            entry_points = pyproject.get("project", {}).get("entry-points", {})
            if "flukebase.plugins" not in entry_points:
                warnings.append(
                    "No flukebase.plugins entry point defined in pyproject.toml"
                )
            else:
                console.print("[green]  Entry point configured[/green]")

            # Check dependencies
            deps = pyproject.get("project", {}).get("dependencies", [])
            has_sdk = any("flukebase-sdk" in d for d in deps)
            if not has_sdk:
                warnings.append("flukebase-sdk not in dependencies")
            else:
                console.print("[green]  flukebase-sdk dependency found[/green]")

        except ImportError:
            warnings.append("tomli not installed, skipping pyproject.toml validation")
        except Exception as e:
            errors.append(f"Error parsing pyproject.toml: {e}")

    # Check src directory
    src_dir = path / "src"
    if not src_dir.exists():
        errors.append("src/ directory not found")
    else:
        # Find plugin module
        modules = [
            d for d in src_dir.iterdir() if d.is_dir() and not d.name.startswith("_")
        ]
        if not modules:
            errors.append("No plugin module found in src/")
        else:
            for module_dir in modules:
                init_file = module_dir / "__init__.py"
                plugin_file = module_dir / "plugin.py"

                if not init_file.exists():
                    errors.append(f"{module_dir.name}/__init__.py not found")
                if not plugin_file.exists():
                    warnings.append(f"{module_dir.name}/plugin.py not found (optional)")

                console.print(f"[green]  Found module: {module_dir.name}[/green]")

    # Check tests directory
    tests_dir = path / "tests"
    if not tests_dir.exists():
        warnings.append("tests/ directory not found")
    else:
        test_files = list(tests_dir.glob("test_*.py"))
        if not test_files:
            warnings.append("No test files found in tests/")
        else:
            console.print(f"[green]  Found {len(test_files)} test file(s)[/green]")

    # Check README
    readme_files = list(path.glob("README*"))
    if not readme_files:
        warnings.append("README file not found")
    else:
        console.print("[green]  README found[/green]")

    # Report results
    console.print()
    if errors:
        console.print("[red]Errors:[/red]")
        for err in errors:
            console.print(f"  [red]  {err}[/red]")
    if warnings:
        console.print("[yellow]Warnings:[/yellow]")
        for warn in warnings:
            console.print(f"  [yellow]  {warn}[/yellow]")

    if errors:
        console.print("\n[red]Validation failed[/red]")
        raise typer.Exit(1)
    elif warnings:
        console.print("\n[yellow]Validation passed with warnings[/yellow]")
    else:
        console.print("\n[green]Validation passed[/green]")


@app.command()
def test(
    path: Path | None = typer.Argument(
        None, help="Path to plugin directory (default: current directory)"
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output"),
    coverage: bool = typer.Option(False, "--coverage", "-c", help="Run with coverage"),
):
    """Run plugin tests with mock services.

    This command runs pytest with the flukebase_sdk.testing fixtures available.
    """
    path = path or Path.cwd()
    tests_dir = path / "tests"

    if not tests_dir.exists():
        console.print("[red]Error:[/red] tests/ directory not found")
        raise typer.Exit(1)

    console.print(f"[cyan]Running tests in:[/cyan] {tests_dir}")

    cmd = [sys.executable, "-m", "pytest", str(tests_dir)]

    if verbose:
        cmd.append("-v")
    if coverage:
        cmd.extend(["--cov", "--cov-report=term-missing"])

    try:
        result = subprocess.run(cmd, cwd=path)
        raise typer.Exit(result.returncode)
    except FileNotFoundError as err:
        console.print(
            "[red]Error:[/red] pytest not found. Install with: pip install pytest"
        )
        raise typer.Exit(1) from err


def _to_class_name(module_name: str) -> str:
    """Convert module_name to ClassName."""
    return "".join(word.capitalize() for word in module_name.split("_")) + "Plugin"


def _to_display_name(plugin_name: str) -> str:
    """Convert plugin-name to Display Name."""
    normalized = plugin_name.replace("-", " ").replace("_", " ")
    return " ".join(word.capitalize() for word in normalized.split())


def main():
    """Entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()
