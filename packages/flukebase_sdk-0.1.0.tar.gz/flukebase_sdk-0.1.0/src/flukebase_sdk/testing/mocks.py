"""Mock implementations for testing FlukeBase plugins.

This module provides comprehensive mock implementations of all service protocols
defined in the SDK. These mocks:
1. Implement all methods from each protocol
2. Store data in-memory for testing assertions
3. Provide configurable return values
4. Track method calls for verification
5. Include helper methods for test setup

Example:
    from flukebase_sdk.testing import (
        MockFlukeBaseClient,
        MockMemoryStore,
        MockWedoManager,
        MockEnvManager,
        MockConfig,
        create_mock_services,
    )

    # Create mock services for plugin testing
    services = create_mock_services()
    await plugin.initialize({}, services)

    # Access mocks for verification
    client = services["flukebase_client"]
    assert client.call_count("get_project") == 1
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from flukebase_sdk.base import BasePlugin
from flukebase_sdk.metadata import PluginMaturity, PluginMetadata, PluginType
from flukebase_sdk.protocols import (
    MemoryType,
    ScopeType,
    WedoDependencyType,
    WedoStatusType,
)
from flukebase_sdk.tools import ToolDefinition

# =============================================================================
# Call Tracking Mixin
# =============================================================================


@dataclass
class MethodCall:
    """Record of a single method call for verification."""

    method: str
    args: tuple
    kwargs: dict
    timestamp: datetime = field(default_factory=datetime.now)
    result: Any = None
    exception: Exception | None = None


class CallTracker:
    """Mixin for tracking method calls on mocks."""

    def __init__(self) -> None:
        self._calls: list[MethodCall] = []
        self._return_values: dict[str, Any] = {}
        self._side_effects: dict[str, Exception] = {}

    def _record_call(
        self,
        method: str,
        args: tuple = (),
        kwargs: dict | None = None,
        result: Any = None,
    ) -> None:
        """Record a method call."""
        self._calls.append(
            MethodCall(
                method=method,
                args=args,
                kwargs=kwargs or {},
                result=result,
            )
        )

    def call_count(self, method: str | None = None) -> int:
        """Get the number of calls to a method (or all methods)."""
        if method is None:
            return len(self._calls)
        return sum(1 for c in self._calls if c.method == method)

    def get_calls(self, method: str | None = None) -> list[MethodCall]:
        """Get all recorded calls to a method (or all methods)."""
        if method is None:
            return self._calls.copy()
        return [c for c in self._calls if c.method == method]

    def last_call(self, method: str | None = None) -> MethodCall | None:
        """Get the last call to a method (or any method)."""
        calls = self.get_calls(method)
        return calls[-1] if calls else None

    def was_called(self, method: str) -> bool:
        """Check if a method was called."""
        return self.call_count(method) > 0

    def was_called_with(self, method: str, *args: Any, **kwargs: Any) -> bool:
        """Check if a method was called with specific arguments."""
        for call in self.get_calls(method):
            if call.args == args and call.kwargs == kwargs:
                return True
        return False

    def reset_calls(self) -> None:
        """Clear all recorded calls."""
        self._calls.clear()

    def set_return_value(self, method: str, value: Any) -> None:
        """Set a custom return value for a method."""
        self._return_values[method] = value

    def set_side_effect(self, method: str, exception: Exception) -> None:
        """Set a side effect (exception) for a method."""
        self._side_effects[method] = exception

    def _get_return_value(self, method: str, default: Any = None) -> Any:
        """Get the configured return value or default."""
        if method in self._side_effects:
            raise self._side_effects[method]
        return self._return_values.get(method, default)

    def clear_return_values(self) -> None:
        """Clear all configured return values."""
        self._return_values.clear()

    def clear_side_effects(self) -> None:
        """Clear all configured side effects."""
        self._side_effects.clear()

    def reset(self) -> None:
        """Reset all tracking data."""
        self.reset_calls()
        self.clear_return_values()
        self.clear_side_effects()


# =============================================================================
# Mock Data Classes
# =============================================================================


@dataclass
class MockProject:
    """Mock project data."""

    id: int
    name: str
    repository_url: str | None = None
    description: str | None = None
    stage: str = "prototype"
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class MockMemory:
    """Mock memory data."""

    id: str
    content: str
    type: MemoryType
    scope: str = "global"
    tags: list[str] = field(default_factory=list)
    references: dict = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    remote_id: int | None = None
    synced: bool = False


@dataclass
class MockTask:
    """Mock WeDo task data."""

    task_id: str
    description: str
    status: WedoStatusType = "pending"
    dependency: WedoDependencyType = "AGENT_CAPABLE"
    scope: str = "global"
    priority: str = "normal"
    tags: list[str] = field(default_factory=list)
    blocked_by: list[str] = field(default_factory=list)
    artifact_path: str | None = None
    remote_url: str | None = None
    parent_task_id: str | None = None
    agent_id: str | None = None
    synthesis_report: list[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    version: int = 1


@dataclass
class MockAgent:
    """Mock agent data."""

    agent_id: str
    name: str | None = None
    is_named_persona: bool = False
    metadata: dict = field(default_factory=dict)
    client_type: str | None = None
    client_version: str | None = None
    created_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)


@dataclass
class MockEnvVar:
    """Mock environment variable."""

    key: str
    value: str
    is_secret: bool = False


# =============================================================================
# Mock FlukeBase Client
# =============================================================================


class MockFlukeBaseClient(CallTracker):
    """Mock implementation of FlukeBaseClientProtocol.

    Provides an in-memory implementation of the FlukeBase API client
    for testing plugins that interact with the FlukeBase platform.

    Example:
        client = MockFlukeBaseClient()
        client.add_project(MockProject(id=1, name="test-project"))

        status = await client.get_status()
        assert status["connected"] is True

        # Verify API calls
        assert client.was_called("get_status")
    """

    def __init__(
        self,
        is_configured: bool = True,
        connected: bool = True,
        user_email: str = "test@example.com",
    ) -> None:
        super().__init__()
        self._is_configured = is_configured
        self._connected = connected
        self._user_email = user_email
        self._projects: dict[int, MockProject] = {}
        self._memories: dict[int, dict[int, MockMemory]] = {}  # project_id -> memories
        self._tasks: dict[int, dict[str, MockTask]] = {}  # project_id -> tasks
        self._agents: dict[int, dict[str, MockAgent]] = {}  # project_id -> agents
        self._webhooks: dict[int, list[dict]] = {}  # project_id -> webhooks
        # project_id -> environment -> vars
        self._environments: dict[int, dict[str, list[MockEnvVar]]] = {}
        self._closed = False

    # --- Properties ---

    @property
    def is_configured(self) -> bool:
        return self._is_configured

    # --- Setup Helpers ---

    def add_project(self, project: MockProject) -> None:
        """Add a project to the mock data."""
        self._projects[project.id] = project
        self._memories.setdefault(project.id, {})
        self._tasks.setdefault(project.id, {})
        self._agents.setdefault(project.id, {})
        self._webhooks.setdefault(project.id, [])
        self._environments.setdefault(project.id, {})

    def add_memory(self, project_id: int, memory: MockMemory) -> None:
        """Add a memory to a project."""
        self._memories.setdefault(project_id, {})
        memory_id = len(self._memories[project_id]) + 1
        memory.remote_id = memory_id
        self._memories[project_id][memory_id] = memory

    def add_env_var(
        self, project_id: int, env: str, key: str, value: str, is_secret: bool = False
    ) -> None:
        """Add an environment variable."""
        self._environments.setdefault(project_id, {})
        self._environments[project_id].setdefault(env, [])
        self._environments[project_id][env].append(
            MockEnvVar(key=key, value=value, is_secret=is_secret)
        )

    # --- Connection Management ---

    async def close(self) -> None:
        self._record_call("close")
        self._closed = True

    async def get_status(self) -> dict:
        result = self._get_return_value(
            "get_status",
            {
                "connected": self._connected,
                "user_email": self._user_email,
                "project_id": next(iter(self._projects.keys()), None),
                "project_count": len(self._projects),
            },
        )
        self._record_call("get_status", result=result)
        return result

    # --- Authentication ---

    async def validate_token(self) -> dict:
        result = self._get_return_value("validate_token", {"valid": True})
        self._record_call("validate_token", result=result)
        return result

    async def generate_scoped_token(
        self,
        scope: str,
        ttl_minutes: int = 60,
        permissions: list[str] | None = None,
    ) -> dict:
        result = self._get_return_value(
            "generate_scoped_token",
            {
                "token": f"mock_scoped_token_{scope}",
                "expires_at": datetime.now().isoformat(),
                "scope": scope,
                "permissions": permissions or ["*"],
            },
        )
        self._record_call(
            "generate_scoped_token",
            kwargs={
                "scope": scope,
                "ttl_minutes": ttl_minutes,
                "permissions": permissions,
            },
            result=result,
        )
        return result

    async def get_current_user(self) -> Any:
        result = self._get_return_value(
            "get_current_user",
            {
                "id": 1,
                "email": self._user_email,
                "name": "Test User",
                "project_count": len(self._projects),
            },
        )
        self._record_call("get_current_user", result=result)
        return result

    # --- Projects ---

    async def list_projects(self) -> list[Any]:
        result = self._get_return_value("list_projects", list(self._projects.values()))
        self._record_call("list_projects", result=result)
        return result

    async def get_project(self, project_id: int) -> Any:
        result = self._get_return_value("get_project", self._projects.get(project_id))
        self._record_call(
            "get_project", kwargs={"project_id": project_id}, result=result
        )
        return result

    async def create_project(
        self,
        name: str,
        repository_url: str | None = None,
        description: str | None = None,
        stage: str = "prototype",
    ) -> Any:
        project_id = max(self._projects.keys(), default=0) + 1
        project = MockProject(
            id=project_id,
            name=name,
            repository_url=repository_url,
            description=description,
            stage=stage,
        )
        self.add_project(project)
        result = self._get_return_value("create_project", project)
        self._record_call(
            "create_project",
            kwargs={
                "name": name,
                "repository_url": repository_url,
                "description": description,
                "stage": stage,
            },
            result=result,
        )
        return result

    async def get_project_by_repo(self, repo_url: str) -> Any | None:
        for project in self._projects.values():
            if project.repository_url == repo_url:
                result = project
                break
        else:
            result = None
        result = self._get_return_value("get_project_by_repo", result)
        self._record_call(
            "get_project_by_repo",
            kwargs={"repo_url": repo_url},
            result=result,
        )
        return result

    async def get_project_context(self, project_id: int) -> dict:
        project = self._projects.get(project_id)
        result = self._get_return_value(
            "get_project_context",
            {
                "project": project,
                "memories": list(self._memories.get(project_id, {}).values()),
                "tasks": list(self._tasks.get(project_id, {}).values()),
            },
        )
        self._record_call(
            "get_project_context",
            kwargs={"project_id": project_id},
            result=result,
        )
        return result

    # --- Environment Variables ---

    async def get_environment(
        self, project_id: int, environment: str = "development"
    ) -> list[Any]:
        envs = self._environments.get(project_id, {}).get(environment, [])
        result = self._get_return_value("get_environment", envs)
        self._record_call(
            "get_environment",
            kwargs={"project_id": project_id, "environment": environment},
            result=result,
        )
        return result

    async def record_sync(
        self, project_id: int, environment: str = "development"
    ) -> dict:
        result = self._get_return_value("record_sync", {"synced": True})
        self._record_call(
            "record_sync",
            kwargs={"project_id": project_id, "environment": environment},
            result=result,
        )
        return result

    # --- Memories ---

    async def list_memories(
        self,
        project_id: int,
        memory_type: str | None = None,
        since: datetime | None = None,
        synced: bool | None = None,
    ) -> list[Any]:
        memories = list(self._memories.get(project_id, {}).values())
        if memory_type:
            memories = [m for m in memories if m.type == memory_type]
        if since:
            memories = [m for m in memories if m.updated_at > since]
        if synced is not None:
            memories = [m for m in memories if m.synced == synced]
        result = self._get_return_value("list_memories", memories)
        self._record_call(
            "list_memories",
            kwargs={
                "project_id": project_id,
                "memory_type": memory_type,
                "since": since,
                "synced": synced,
            },
            result=result,
        )
        return result

    async def get_memory(self, project_id: int, memory_id: int) -> Any:
        memory = self._memories.get(project_id, {}).get(memory_id)
        result = self._get_return_value("get_memory", memory)
        self._record_call(
            "get_memory",
            kwargs={"project_id": project_id, "memory_id": memory_id},
            result=result,
        )
        return result

    async def create_memory(
        self,
        project_id: int,
        memory_type: str,
        content: str,
        key: str | None = None,
        rationale: str | None = None,
        tags: list[str] | None = None,
        references: dict | None = None,
        external_id: str | None = None,
    ) -> Any:
        memory_id = max(self._memories.get(project_id, {}).keys(), default=0) + 1
        memory = MockMemory(
            id=external_id or str(uuid.uuid4()),
            content=content,
            type=memory_type,  # type: ignore
            tags=tags or [],
            references=references or {},
            remote_id=memory_id,
            synced=True,
        )
        self._memories.setdefault(project_id, {})[memory_id] = memory
        result = self._get_return_value("create_memory", memory)
        self._record_call(
            "create_memory",
            kwargs={
                "project_id": project_id,
                "memory_type": memory_type,
                "content": content,
                "key": key,
                "rationale": rationale,
                "tags": tags,
                "references": references,
                "external_id": external_id,
            },
            result=result,
        )
        return result

    async def update_memory(
        self,
        project_id: int,
        memory_id: int,
        content: str | None = None,
        rationale: str | None = None,
        tags: list[str] | None = None,
    ) -> Any:
        memory = self._memories.get(project_id, {}).get(memory_id)
        if memory:
            if content is not None:
                memory.content = content
            if tags is not None:
                memory.tags = tags
            memory.updated_at = datetime.now()
        result = self._get_return_value("update_memory", memory)
        self._record_call(
            "update_memory",
            kwargs={
                "project_id": project_id,
                "memory_id": memory_id,
                "content": content,
                "rationale": rationale,
                "tags": tags,
            },
            result=result,
        )
        return result

    async def delete_memory(self, project_id: int, memory_id: int) -> bool:
        deleted = memory_id in self._memories.get(project_id, {})
        if deleted:
            del self._memories[project_id][memory_id]
        result = self._get_return_value("delete_memory", deleted)
        self._record_call(
            "delete_memory",
            kwargs={"project_id": project_id, "memory_id": memory_id},
            result=result,
        )
        return result

    async def bulk_push_memories(self, project_id: int, memories: list[dict]) -> dict:
        created = 0
        updated = 0
        for mem_data in memories:
            external_id = mem_data.get("external_id")
            # Check if exists
            existing = None
            for m in self._memories.get(project_id, {}).values():
                if m.id == external_id:
                    existing = m
                    break
            if existing:
                existing.content = mem_data.get("content", existing.content)
                updated += 1
            else:
                await self.create_memory(
                    project_id=project_id,
                    memory_type=mem_data.get("type", "fact"),
                    content=mem_data.get("content", ""),
                    external_id=external_id,
                    tags=mem_data.get("tags", []),
                )
                created += 1
        result = self._get_return_value(
            "bulk_push_memories",
            {"created": created, "updated": updated, "total": len(memories)},
        )
        self._record_call(
            "bulk_push_memories",
            kwargs={"project_id": project_id, "memories": memories},
            result=result,
        )
        return result

    async def search_memories_cross_project(
        self,
        query: str | None = None,
        memory_type: str | None = None,
        tag: str | None = None,
        page: int = 1,
        per_page: int = 50,
    ) -> dict:
        all_memories = []
        for project_memories in self._memories.values():
            all_memories.extend(project_memories.values())

        if query:
            query_lower = query.lower()
            all_memories = [m for m in all_memories if query_lower in m.content.lower()]
        if memory_type:
            all_memories = [m for m in all_memories if m.type == memory_type]
        if tag:
            all_memories = [m for m in all_memories if tag in m.tags]

        start = (page - 1) * per_page
        end = start + per_page
        result = self._get_return_value(
            "search_memories_cross_project",
            {"memories": all_memories[start:end], "meta": {"total": len(all_memories)}},
        )
        self._record_call(
            "search_memories_cross_project",
            kwargs={
                "query": query,
                "memory_type": memory_type,
                "tag": tag,
                "page": page,
                "per_page": per_page,
            },
            result=result,
        )
        return result

    # --- WeDo Tasks ---

    async def list_tasks(
        self,
        project_id: int,
        status: str | None = None,
        scope: str = "global",
        since_version: int = 0,
        assignee_id: int | None = None,
        root_only: bool = False,
        page: int = 1,
        per_page: int = 50,
    ) -> dict:
        tasks = list(self._tasks.get(project_id, {}).values())
        if status:
            tasks = [t for t in tasks if t.status == status]
        if scope != "all":
            tasks = [t for t in tasks if t.scope == scope]
        if since_version:
            tasks = [t for t in tasks if t.version > since_version]
        if root_only:
            tasks = [t for t in tasks if t.parent_task_id is None]

        start = (page - 1) * per_page
        end = start + per_page
        result = self._get_return_value(
            "list_tasks",
            {"tasks": tasks[start:end], "meta": {"total": len(tasks)}},
        )
        self._record_call(
            "list_tasks",
            kwargs={
                "project_id": project_id,
                "status": status,
                "scope": scope,
                "since_version": since_version,
                "assignee_id": assignee_id,
                "root_only": root_only,
                "page": page,
                "per_page": per_page,
            },
            result=result,
        )
        return result

    async def get_task(self, project_id: int, task_id: str) -> dict:
        task = self._tasks.get(project_id, {}).get(task_id)
        result = self._get_return_value("get_task", {"task": task} if task else {})
        self._record_call(
            "get_task",
            kwargs={"project_id": project_id, "task_id": task_id},
            result=result,
        )
        return result

    async def create_task(
        self,
        project_id: int,
        task_id: str,
        description: str,
        status: str = "pending",
        dependency: str = "AGENT_CAPABLE",
        scope: str = "global",
        priority: str = "normal",
        tags: list[str] | None = None,
        blocked_by: list[str] | None = None,
        artifact_path: str | None = None,
        remote_url: str | None = None,
        parent_task_id: str | None = None,
        external_id: str | None = None,
        agent_id: str | None = None,
    ) -> dict:
        task = MockTask(
            task_id=task_id,
            description=description,
            status=status,  # type: ignore
            dependency=dependency,  # type: ignore
            scope=scope,
            priority=priority,
            tags=tags or [],
            blocked_by=blocked_by or [],
            artifact_path=artifact_path,
            remote_url=remote_url,
            parent_task_id=parent_task_id,
            agent_id=agent_id,
        )
        self._tasks.setdefault(project_id, {})[task_id] = task
        result = self._get_return_value("create_task", {"task": task})
        self._record_call(
            "create_task",
            kwargs={
                "project_id": project_id,
                "task_id": task_id,
                "description": description,
                "status": status,
                "dependency": dependency,
                "scope": scope,
                "priority": priority,
                "tags": tags,
                "blocked_by": blocked_by,
                "artifact_path": artifact_path,
                "remote_url": remote_url,
                "parent_task_id": parent_task_id,
                "external_id": external_id,
                "agent_id": agent_id,
            },
            result=result,
        )
        return result

    async def update_task(
        self,
        project_id: int,
        task_id: str,
        version: int = 0,
        status: str | None = None,
        description: str | None = None,
        priority: str | None = None,
        synthesis_note: str | None = None,
        agent_id: str | None = None,
        artifact_path: str | None = None,
        remote_url: str | None = None,
        blocked_by: list[str] | None = None,
        tags: list[str] | None = None,
        assignee_id: int | None = None,
        due_date: str | None = None,
    ) -> dict:
        task = self._tasks.get(project_id, {}).get(task_id)
        if task:
            if status is not None:
                task.status = status  # type: ignore
            if description is not None:
                task.description = description
            if priority is not None:
                task.priority = priority
            if synthesis_note:
                task.synthesis_report.append(synthesis_note)
            if artifact_path is not None:
                task.artifact_path = artifact_path
            if remote_url is not None:
                task.remote_url = remote_url
            if blocked_by is not None:
                task.blocked_by = blocked_by
            if tags is not None:
                task.tags = tags
            task.version += 1
            task.updated_at = datetime.now()
        result = self._get_return_value("update_task", {"task": task} if task else {})
        self._record_call(
            "update_task",
            kwargs={
                "project_id": project_id,
                "task_id": task_id,
                "version": version,
                "status": status,
                "description": description,
                "priority": priority,
                "synthesis_note": synthesis_note,
                "agent_id": agent_id,
                "artifact_path": artifact_path,
                "remote_url": remote_url,
                "blocked_by": blocked_by,
                "tags": tags,
                "assignee_id": assignee_id,
                "due_date": due_date,
            },
            result=result,
        )
        return result

    async def delete_task(self, project_id: int, task_id: str) -> bool:
        deleted = task_id in self._tasks.get(project_id, {})
        if deleted:
            del self._tasks[project_id][task_id]
        result = self._get_return_value("delete_task", deleted)
        self._record_call(
            "delete_task",
            kwargs={"project_id": project_id, "task_id": task_id},
            result=result,
        )
        return result

    async def bulk_push_tasks(self, project_id: int, tasks: list[dict]) -> dict:
        created = 0
        updated = 0
        for task_data in tasks:
            task_id = task_data.get("task_id")
            if task_id in self._tasks.get(project_id, {}):
                await self.update_task(project_id, task_id, **task_data)
                updated += 1
            else:
                await self.create_task(project_id, **task_data)
                created += 1
        result = self._get_return_value(
            "bulk_push_tasks",
            {"created": created, "updated": updated, "total": len(tasks)},
        )
        self._record_call(
            "bulk_push_tasks",
            kwargs={"project_id": project_id, "tasks": tasks},
            result=result,
        )
        return result

    # --- Agents ---

    async def register_agent(
        self,
        project_id: int,
        agent_id: str,
        persona_name: str | None = None,
        agent_type: str = "claude_code",
        capabilities: list[str] | None = None,
        client_version: str | None = None,
        metadata: dict | None = None,
    ) -> dict:
        agent = MockAgent(
            agent_id=agent_id,
            name=persona_name,
            is_named_persona=bool(persona_name),
            metadata=metadata or {},
            client_type=agent_type,
            client_version=client_version,
        )
        self._agents.setdefault(project_id, {})[agent_id] = agent
        result = self._get_return_value("register_agent", {"agent": agent})
        self._record_call(
            "register_agent",
            kwargs={
                "project_id": project_id,
                "agent_id": agent_id,
                "persona_name": persona_name,
                "agent_type": agent_type,
                "capabilities": capabilities,
                "client_version": client_version,
                "metadata": metadata,
            },
            result=result,
        )
        return result

    async def agent_heartbeat(
        self,
        project_id: int,
        agent_id: str,
        tokens_used: int = 0,
        tools_executed: int = 0,
        metadata: dict | None = None,
    ) -> dict:
        agent = self._agents.get(project_id, {}).get(agent_id)
        if agent:
            agent.last_active = datetime.now()
            if metadata:
                agent.metadata.update(metadata)
        result = self._get_return_value("agent_heartbeat", {"agent": agent})
        self._record_call(
            "agent_heartbeat",
            kwargs={
                "project_id": project_id,
                "agent_id": agent_id,
                "tokens_used": tokens_used,
                "tools_executed": tools_executed,
                "metadata": metadata,
            },
            result=result,
        )
        return result

    async def list_agents(
        self,
        project_id: int,
        status: str | None = None,
        agent_type: str | None = None,
        connected_only: bool = False,
        refresh_status: bool = False,
        page: int = 1,
        per_page: int = 50,
    ) -> dict:
        agents = list(self._agents.get(project_id, {}).values())
        if agent_type:
            agents = [a for a in agents if a.client_type == agent_type]
        start = (page - 1) * per_page
        end = start + per_page
        result = self._get_return_value(
            "list_agents",
            {"agents": agents[start:end], "meta": {"total": len(agents)}},
        )
        self._record_call(
            "list_agents",
            kwargs={
                "project_id": project_id,
                "status": status,
                "agent_type": agent_type,
                "connected_only": connected_only,
                "refresh_status": refresh_status,
                "page": page,
                "per_page": per_page,
            },
            result=result,
        )
        return result

    # --- Webhooks ---

    async def list_webhooks(self, project_id: int) -> list[dict]:
        webhooks = self._webhooks.get(project_id, [])
        result = self._get_return_value("list_webhooks", webhooks)
        self._record_call(
            "list_webhooks",
            kwargs={"project_id": project_id},
            result=result,
        )
        return result

    async def create_webhook(
        self,
        project_id: int,
        callback_url: str,
        events: list[str] | None = None,
    ) -> dict:
        webhook = {
            "id": len(self._webhooks.get(project_id, [])) + 1,
            "callback_url": callback_url,
            "events": events or ["*"],
            "created_at": datetime.now().isoformat(),
        }
        self._webhooks.setdefault(project_id, []).append(webhook)
        result = self._get_return_value("create_webhook", webhook)
        self._record_call(
            "create_webhook",
            kwargs={
                "project_id": project_id,
                "callback_url": callback_url,
                "events": events,
            },
            result=result,
        )
        return result

    async def delete_webhook(self, project_id: int, webhook_id: int) -> bool:
        webhooks = self._webhooks.get(project_id, [])
        for i, wh in enumerate(webhooks):
            if wh["id"] == webhook_id:
                del webhooks[i]
                result = True
                break
        else:
            result = False
        result = self._get_return_value("delete_webhook", result)
        self._record_call(
            "delete_webhook",
            kwargs={"project_id": project_id, "webhook_id": webhook_id},
            result=result,
        )
        return result

    # --- Batch Operations ---

    async def batch_get_project_contexts(
        self,
        project_ids: list[int] | None = None,
        all_projects: bool = False,
    ) -> dict:
        ids = list(self._projects.keys()) if all_projects else (project_ids or [])
        contexts = []
        for pid in ids:
            if pid in self._projects:
                contexts.append(await self.get_project_context(pid))
        result = self._get_return_value(
            "batch_get_project_contexts",
            {"contexts": contexts, "meta": {"total": len(contexts)}},
        )
        self._record_call(
            "batch_get_project_contexts",
            kwargs={"project_ids": project_ids, "all_projects": all_projects},
            result=result,
        )
        return result

    async def batch_get_environments(
        self,
        project_ids: list[int] | None = None,
        environment: str = "development",
        all_projects: bool = False,
    ) -> dict:
        ids = list(self._projects.keys()) if all_projects else (project_ids or [])
        environments = []
        for pid in ids:
            envs = await self.get_environment(pid, environment)
            environments.append({"project_id": pid, "variables": envs})
        result = self._get_return_value(
            "batch_get_environments",
            {"environments": environments, "meta": {"total": len(environments)}},
        )
        self._record_call(
            "batch_get_environments",
            kwargs={
                "project_ids": project_ids,
                "environment": environment,
                "all_projects": all_projects,
            },
            result=result,
        )
        return result

    async def batch_pull_memories(
        self,
        project_ids: list[int] | None = None,
        memory_type: str | None = None,
        tag: str | None = None,
        since: datetime | None = None,
        all_projects: bool = False,
    ) -> dict:
        ids = list(self._projects.keys()) if all_projects else (project_ids or [])
        projects_memories = []
        for pid in ids:
            memories = await self.list_memories(pid, memory_type, since)
            projects_memories.append({"project_id": pid, "memories": memories})
        result = self._get_return_value(
            "batch_pull_memories",
            {"projects": projects_memories, "meta": {"total": len(projects_memories)}},
        )
        self._record_call(
            "batch_pull_memories",
            kwargs={
                "project_ids": project_ids,
                "memory_type": memory_type,
                "tag": tag,
                "since": since,
                "all_projects": all_projects,
            },
            result=result,
        )
        return result


# =============================================================================
# Mock Memory Store
# =============================================================================


class MockMemoryStore(CallTracker):
    """Mock implementation of MemoryStoreProtocol.

    Provides an in-memory implementation of the local memory store
    for testing plugins that interact with stored knowledge.

    Example:
        store = MockMemoryStore()
        await store.remember(
            "Python uses snake_case", type="convention", scope="global"
        )

        results = await store.recall("snake_case")
        assert len(results) > 0
    """

    def __init__(self) -> None:
        super().__init__()
        self._memories: dict[str, dict[str, MockMemory]] = {"global": {}}
        self._conventions: dict[str, dict[str, dict]] = {"global": {}}

    # --- Setup Helpers ---

    def add_scope(self, scope: str) -> None:
        """Add a new scope."""
        self._memories.setdefault(scope, {})
        self._conventions.setdefault(scope, {})

    def add_memory(self, memory: MockMemory) -> None:
        """Add a memory directly."""
        scope = memory.scope
        self._memories.setdefault(scope, {})
        self._memories[scope][memory.id] = memory

    # --- Protocol Methods ---

    def list_scopes(self) -> list[str]:
        scopes = ["global"] + [s for s in self._memories.keys() if s != "global"]
        result = self._get_return_value("list_scopes", scopes)
        self._record_call("list_scopes", result=result)
        return result

    async def remember(
        self,
        content: str,
        type: MemoryType = "fact",
        scope: str = "global",
        tags: list[str] | None = None,
        references: dict | None = None,
    ) -> Any:
        memory_id = str(uuid.uuid4())
        memory = MockMemory(
            id=memory_id,
            content=content,
            type=type,
            scope=scope,
            tags=tags or [],
            references=references or {},
        )
        self._memories.setdefault(scope, {})[memory_id] = memory
        result = self._get_return_value("remember", memory)
        self._record_call(
            "remember",
            kwargs={
                "content": content,
                "type": type,
                "scope": scope,
                "tags": tags,
                "references": references,
            },
            result=result,
        )
        return result

    async def recall(
        self,
        query: str,
        type: MemoryType | None = None,
        scope: ScopeType | None = None,
        limit: int = 10,
        include_scope_info: bool = True,
    ) -> list[Any]:
        # Determine scopes to search
        if scope is None or scope == "all":
            scopes_to_search = list(self._memories.keys())
        elif isinstance(scope, list):
            scopes_to_search = scope
        else:
            scopes_to_search = [scope]

        results = []
        query_lower = query.lower()
        for s in scopes_to_search:
            for memory in self._memories.get(s, {}).values():
                if query_lower in memory.content.lower() or any(
                    query_lower in tag.lower() for tag in memory.tags
                ):
                    if type is None or memory.type == type:
                        results.append(memory)

        results = results[:limit]
        result = self._get_return_value("recall", results)
        self._record_call(
            "recall",
            kwargs={
                "query": query,
                "type": type,
                "scope": scope,
                "limit": limit,
                "include_scope_info": include_scope_info,
            },
            result=result,
        )
        return result

    async def forget(self, id: str, scope: ScopeType | None = None) -> dict:
        found_scope = None
        scopes_to_search = (
            list(self._memories.keys())
            if scope is None or scope == "all"
            else ([scope] if isinstance(scope, str) else scope)
        )

        for s in scopes_to_search:
            if id in self._memories.get(s, {}):
                del self._memories[s][id]
                found_scope = s
                break

        result = self._get_return_value(
            "forget",
            {"success": found_scope is not None, "scope": found_scope},
        )
        self._record_call(
            "forget",
            kwargs={"id": id, "scope": scope},
            result=result,
        )
        return result

    async def set_convention(
        self,
        key: str,
        value: str,
        rationale: str | None = None,
        scope: str = "global",
    ) -> Any:
        convention = {
            "key": key,
            "value": value,
            "rationale": rationale,
            "scope": scope,
            "created_at": datetime.now().isoformat(),
        }
        self._conventions.setdefault(scope, {})[key] = convention
        result = self._get_return_value("set_convention", convention)
        self._record_call(
            "set_convention",
            kwargs={
                "key": key,
                "value": value,
                "rationale": rationale,
                "scope": scope,
            },
            result=result,
        )
        return result

    async def get_convention(self, key: str, scope: str = "global") -> Any | None:
        convention = self._conventions.get(scope, {}).get(key)
        result = self._get_return_value("get_convention", convention)
        self._record_call(
            "get_convention",
            kwargs={"key": key, "scope": scope},
            result=result,
        )
        return result

    async def list_conventions(self, scope: str = "global") -> list[Any]:
        conventions = list(self._conventions.get(scope, {}).values())
        result = self._get_return_value("list_conventions", conventions)
        self._record_call(
            "list_conventions",
            kwargs={"scope": scope},
            result=result,
        )
        return result


# =============================================================================
# Mock WeDo Manager
# =============================================================================


class MockWedoManager(CallTracker):
    """Mock implementation of WedoManagerProtocol.

    Provides an in-memory implementation of the WeDo task manager
    for testing plugins that interact with task management.

    Example:
        manager = MockWedoManager()
        await manager.register_agent("ZION", name="ZION", is_named_persona=True)
        await manager.create_task("TEST-001", "Test task")

        task = await manager.get_task("TEST-001")
        assert task is not None
    """

    def __init__(self) -> None:
        super().__init__()
        self._agents: dict[str, MockAgent] = {}
        self._tasks: dict[str, MockTask] = {}
        self._templates: dict[str, dict] = {}
        self._relationships: list[dict] = []
        self._sessions: dict[str, dict] = {}
        self._current_agent_id: str | None = None

    # --- Setup Helpers ---

    def add_task(self, task: MockTask) -> None:
        """Add a task directly."""
        self._tasks[task.task_id] = task

    def add_agent(self, agent: MockAgent) -> None:
        """Add an agent directly."""
        self._agents[agent.agent_id] = agent

    # --- Agent Management ---

    async def register_agent(
        self,
        agent_id: str | None = None,
        name: str | None = None,
        is_named_persona: bool = False,
        metadata: dict | None = None,
        client_type: str | None = None,
        client_version: str | None = None,
    ) -> Any:
        aid = agent_id or str(uuid.uuid4())[:8]
        agent = MockAgent(
            agent_id=aid,
            name=name,
            is_named_persona=is_named_persona,
            metadata=metadata or {},
            client_type=client_type,
            client_version=client_version,
        )
        self._agents[aid] = agent
        self._current_agent_id = aid
        result = self._get_return_value("register_agent", agent)
        self._record_call(
            "register_agent",
            kwargs={
                "agent_id": agent_id,
                "name": name,
                "is_named_persona": is_named_persona,
                "metadata": metadata,
                "client_type": client_type,
                "client_version": client_version,
            },
            result=result,
        )
        return result

    async def get_agent(self, agent_id: str) -> Any | None:
        agent = self._agents.get(agent_id)
        result = self._get_return_value("get_agent", agent)
        self._record_call(
            "get_agent",
            kwargs={"agent_id": agent_id},
            result=result,
        )
        return result

    async def list_agents(self, named_only: bool = False) -> list[Any]:
        agents = list(self._agents.values())
        if named_only:
            agents = [a for a in agents if a.is_named_persona]
        result = self._get_return_value("list_agents", agents)
        self._record_call(
            "list_agents",
            kwargs={"named_only": named_only},
            result=result,
        )
        return result

    def get_current_agent_id(self) -> str | None:
        result = self._get_return_value("get_current_agent_id", self._current_agent_id)
        self._record_call("get_current_agent_id", result=result)
        return result

    def set_current_agent(self, agent_id: str) -> None:
        self._current_agent_id = agent_id
        self._record_call(
            "set_current_agent",
            kwargs={"agent_id": agent_id},
        )

    async def heartbeat(self, agent_id: str | None = None) -> bool:
        aid = agent_id or self._current_agent_id
        if aid and aid in self._agents:
            self._agents[aid].last_active = datetime.now()
            result = True
        else:
            result = False
        result = self._get_return_value("heartbeat", result)
        self._record_call(
            "heartbeat",
            kwargs={"agent_id": agent_id},
            result=result,
        )
        return result

    async def start_session(self, agent_id: str, scope: str = "global") -> Any:
        session_id = str(uuid.uuid4())
        session = {
            "id": session_id,
            "agent_id": agent_id,
            "scope": scope,
            "started_at": datetime.now().isoformat(),
            "ended_at": None,
        }
        self._sessions[session_id] = session
        result = self._get_return_value("start_session", session)
        self._record_call(
            "start_session",
            kwargs={"agent_id": agent_id, "scope": scope},
            result=result,
        )
        return result

    async def end_session(self, session_id: str) -> None:
        if session_id in self._sessions:
            self._sessions[session_id]["ended_at"] = datetime.now().isoformat()
        self._record_call(
            "end_session",
            kwargs={"session_id": session_id},
        )

    # --- Task Management ---

    async def create_task(
        self,
        task_id: str,
        description: str,
        dependency: Any = None,
        scope: str = "global",
        parent_task_id: str | None = None,
        template_id: str | None = None,
        tags: list[str] | None = None,
        artifact_path: str | None = None,
        remote_url: str | None = None,
        project_ids: list[int] | None = None,
        priority: Any = None,
        urgency: Any = None,
        due_date: str | None = None,
        estimated_minutes: int | None = None,
        assignee_type: Any = None,
        assignee_id: str | None = None,
        task_type: Any = None,
        metadata: dict | None = None,
    ) -> Any:
        task = MockTask(
            task_id=task_id,
            description=description,
            status="pending",
            dependency=dependency or "AGENT_CAPABLE",
            scope=scope,
            priority=priority or "normal",
            tags=tags or [],
            artifact_path=artifact_path,
            remote_url=remote_url,
            parent_task_id=parent_task_id,
            agent_id=self._current_agent_id,
        )
        self._tasks[task_id] = task
        result = self._get_return_value("create_task", task)
        self._record_call(
            "create_task",
            kwargs={
                "task_id": task_id,
                "description": description,
                "dependency": dependency,
                "scope": scope,
                "parent_task_id": parent_task_id,
                "template_id": template_id,
                "tags": tags,
                "artifact_path": artifact_path,
                "remote_url": remote_url,
                "project_ids": project_ids,
                "priority": priority,
                "urgency": urgency,
                "due_date": due_date,
                "estimated_minutes": estimated_minutes,
                "assignee_type": assignee_type,
                "assignee_id": assignee_id,
                "task_type": task_type,
                "metadata": metadata,
            },
            result=result,
        )
        return result

    async def get_task(self, task_id: str) -> Any | None:
        task = self._tasks.get(task_id)
        result = self._get_return_value("get_task", task)
        self._record_call(
            "get_task",
            kwargs={"task_id": task_id},
            result=result,
        )
        return result

    async def update_task_status(
        self,
        task_id: str,
        status: Any,
        synthesis_note: str | None = None,
        check_dependencies: bool = True,
    ) -> Any | None:
        task = self._tasks.get(task_id)
        if task:
            # Check dependencies if starting task
            if check_dependencies and status == "in_progress":
                deps = await self.check_dependencies_met(task_id)
                if not deps["met"]:
                    blocking = deps["blocking"]
                    raise ValueError(
                        f"Task {task_id} has unmet dependencies: {blocking}"
                    )

            task.status = status
            if synthesis_note:
                task.synthesis_report.append(synthesis_note)
            task.updated_at = datetime.now()
            task.version += 1
        result = self._get_return_value("update_task_status", task)
        self._record_call(
            "update_task_status",
            kwargs={
                "task_id": task_id,
                "status": status,
                "synthesis_note": synthesis_note,
                "check_dependencies": check_dependencies,
            },
            result=result,
        )
        return result

    async def delete_task(self, task_id: str) -> bool:
        deleted = task_id in self._tasks
        if deleted:
            del self._tasks[task_id]
        result = self._get_return_value("delete_task", deleted)
        self._record_call(
            "delete_task",
            kwargs={"task_id": task_id},
            result=result,
        )
        return result

    async def list_tasks(
        self,
        status: Any | None = None,
        scope: str = "global",
        agent_id: str | None = None,
        project_ids: list[int] | None = None,
        limit: int = 50,
    ) -> list[Any]:
        tasks = list(self._tasks.values())
        if status:
            tasks = [t for t in tasks if t.status == status]
        if scope != "all":
            tasks = [t for t in tasks if t.scope == scope]
        if agent_id:
            tasks = [t for t in tasks if t.agent_id == agent_id]
        tasks = tasks[:limit]
        result = self._get_return_value("list_tasks", tasks)
        self._record_call(
            "list_tasks",
            kwargs={
                "status": status,
                "scope": scope,
                "agent_id": agent_id,
                "project_ids": project_ids,
                "limit": limit,
            },
            result=result,
        )
        return result

    async def get_status(self, scope: str = "global") -> dict:
        tasks = await self.list_tasks(scope=scope)
        status_counts = {}
        for task in tasks:
            status_counts[task.status] = status_counts.get(task.status, 0) + 1
        result = self._get_return_value(
            "get_status",
            {
                "total_tasks": len(tasks),
                "status_counts": status_counts,
                "current_agent": self._current_agent_id,
                "agents": len(self._agents),
            },
        )
        self._record_call(
            "get_status",
            kwargs={"scope": scope},
            result=result,
        )
        return result

    # --- Milestone/Progress ---

    async def get_milestone_progress(
        self,
        milestone_id: str,
        scope: str = "global",
    ) -> dict:
        # Find all subtasks
        subtasks = [t for t in self._tasks.values() if t.parent_task_id == milestone_id]
        completed = sum(1 for t in subtasks if t.status == "completed")
        total = len(subtasks)
        result = self._get_return_value(
            "get_milestone_progress",
            {
                "milestone_id": milestone_id,
                "total": total,
                "completed": completed,
                "percentage": (completed / total * 100) if total > 0 else 0,
            },
        )
        self._record_call(
            "get_milestone_progress",
            kwargs={"milestone_id": milestone_id, "scope": scope},
            result=result,
        )
        return result

    async def get_all_milestones_progress(self, scope: str = "global") -> list[dict]:
        # Find all parent tasks (milestones)
        milestone_ids = {
            t.parent_task_id for t in self._tasks.values() if t.parent_task_id
        }
        progress_list = []
        for mid in milestone_ids:
            progress = await self.get_milestone_progress(mid, scope)
            progress_list.append(progress)
        result = self._get_return_value("get_all_milestones_progress", progress_list)
        self._record_call(
            "get_all_milestones_progress",
            kwargs={"scope": scope},
            result=result,
        )
        return result

    # --- Relationships ---

    async def add_relationship(
        self,
        source_task_id: str,
        target_task_id: str,
        relationship_type: Any,
        metadata: dict | None = None,
    ) -> Any:
        rel = {
            "source": source_task_id,
            "target": target_task_id,
            "type": relationship_type,
            "metadata": metadata or {},
            "created_at": datetime.now().isoformat(),
        }
        self._relationships.append(rel)
        result = self._get_return_value("add_relationship", rel)
        self._record_call(
            "add_relationship",
            kwargs={
                "source_task_id": source_task_id,
                "target_task_id": target_task_id,
                "relationship_type": relationship_type,
                "metadata": metadata,
            },
            result=result,
        )
        return result

    async def remove_relationship(
        self,
        source_task_id: str,
        target_task_id: str,
        relationship_type: Any,
    ) -> bool:
        for i, rel in enumerate(self._relationships):
            if (
                rel["source"] == source_task_id
                and rel["target"] == target_task_id
                and rel["type"] == relationship_type
            ):
                del self._relationships[i]
                result = True
                break
        else:
            result = False
        result = self._get_return_value("remove_relationship", result)
        self._record_call(
            "remove_relationship",
            kwargs={
                "source_task_id": source_task_id,
                "target_task_id": target_task_id,
                "relationship_type": relationship_type,
            },
            result=result,
        )
        return result

    async def get_blocking_tasks(self, task_id: str) -> list[str]:
        task = self._tasks.get(task_id)
        blocking = task.blocked_by if task else []
        result = self._get_return_value("get_blocking_tasks", blocking)
        self._record_call(
            "get_blocking_tasks",
            kwargs={"task_id": task_id},
            result=result,
        )
        return result

    async def check_dependencies_met(self, task_id: str) -> dict:
        task = self._tasks.get(task_id)
        if not task:
            result = {"met": True, "blocking": [], "total": 0}
        else:
            blocking = []
            for blocked_id in task.blocked_by:
                blocked_task = self._tasks.get(blocked_id)
                if blocked_task and blocked_task.status != "completed":
                    blocking.append(blocked_id)
            result = {
                "met": len(blocking) == 0,
                "blocking": blocking,
                "total": len(task.blocked_by),
            }
        result = self._get_return_value("check_dependencies_met", result)
        self._record_call(
            "check_dependencies_met",
            kwargs={"task_id": task_id},
            result=result,
        )
        return result

    # --- Templates ---

    async def create_template(
        self,
        name: str,
        description: str,
        default_tasks: list[dict],
        scope: str = "global",
    ) -> Any:
        template_id = str(uuid.uuid4())
        template = {
            "id": template_id,
            "name": name,
            "description": description,
            "default_tasks": default_tasks,
            "scope": scope,
            "created_at": datetime.now().isoformat(),
        }
        self._templates[template_id] = template
        result = self._get_return_value("create_template", template)
        self._record_call(
            "create_template",
            kwargs={
                "name": name,
                "description": description,
                "default_tasks": default_tasks,
                "scope": scope,
            },
            result=result,
        )
        return result

    async def list_templates(self, scope: str = "global") -> list[Any]:
        templates = [t for t in self._templates.values() if t["scope"] == scope]
        result = self._get_return_value("list_templates", templates)
        self._record_call(
            "list_templates",
            kwargs={"scope": scope},
            result=result,
        )
        return result

    async def instantiate_template(
        self,
        template_id: str,
        id_prefix: str,
        scope: str = "global",
    ) -> list[Any]:
        template = self._templates.get(template_id)
        if not template:
            result = []
        else:
            created = []
            for i, task_def in enumerate(template["default_tasks"]):
                task_id = f"{id_prefix}-{i + 1:02d}"
                task = await self.create_task(
                    task_id=task_id,
                    description=task_def.get("description", ""),
                    scope=scope,
                    tags=task_def.get("tags", []),
                    template_id=template_id,
                )
                created.append(task)
            result = created
        result = self._get_return_value("instantiate_template", result)
        self._record_call(
            "instantiate_template",
            kwargs={
                "template_id": template_id,
                "id_prefix": id_prefix,
                "scope": scope,
            },
            result=result,
        )
        return result

    # --- Export ---

    async def export_to_markdown(
        self,
        scope: str = "global",
        include_tasks: bool = True,
        include_memories: bool = True,
        temporal_folders: bool = True,
    ) -> Path:
        export_path = Path("/tmp/wedo_export")
        result = self._get_return_value("export_to_markdown", export_path)
        self._record_call(
            "export_to_markdown",
            kwargs={
                "scope": scope,
                "include_tasks": include_tasks,
                "include_memories": include_memories,
                "temporal_folders": temporal_folders,
            },
            result=result,
        )
        return result


# =============================================================================
# Mock Env Manager
# =============================================================================


class MockEnvManager(CallTracker):
    """Mock implementation of EnvManagerProtocol.

    Provides an in-memory implementation of environment variable management
    for testing plugins that interact with environment configuration.

    Example:
        env_manager = MockEnvManager()
        env_manager.set_env_vars({"API_KEY": "test123", "DEBUG": "true"})

        result = env_manager.show_environment(Path("/project"))
        assert "API_KEY" in result
    """

    def __init__(self) -> None:
        super().__init__()
        self._env_vars: dict[str, str] = {}
        self._cached_envs: dict[str, list[dict]] = {}

    # --- Setup Helpers ---

    def set_env_vars(self, env_vars: dict[str, str]) -> None:
        """Set environment variables."""
        self._env_vars = env_vars.copy()

    def set_cache(self, project_path: str, environment: str, vars: list[dict]) -> None:
        """Set cached environment."""
        key = f"{project_path}:{environment}"
        self._cached_envs[key] = vars

    # --- Protocol Methods ---

    async def sync_environment(
        self,
        project_id: int,
        project_path: Path,
        environment: str = "development",
    ) -> Path:
        env_path = project_path / ".env"
        result = self._get_return_value("sync_environment", env_path)
        self._record_call(
            "sync_environment",
            kwargs={
                "project_id": project_id,
                "project_path": project_path,
                "environment": environment,
            },
            result=result,
        )
        return result

    def read_env_file(self, env_path: Path) -> dict[str, str]:
        result = self._get_return_value("read_env_file", self._env_vars.copy())
        self._record_call(
            "read_env_file",
            kwargs={"env_path": env_path},
            result=result,
        )
        return result

    def show_environment(
        self, project_path: Path, mask_secrets: bool = True
    ) -> dict[str, str]:
        env = self._env_vars.copy()
        if mask_secrets:
            secret_patterns = ["SECRET", "KEY", "TOKEN", "PASSWORD"]
            for key in env:
                if any(s in key.upper() for s in secret_patterns):
                    env[key] = "****"
        result = self._get_return_value("show_environment", env)
        self._record_call(
            "show_environment",
            kwargs={"project_path": project_path, "mask_secrets": mask_secrets},
            result=result,
        )
        return result

    async def diff_environment(
        self,
        project_id: int,
        project_path: Path,
        environment: str = "development",
    ) -> dict:
        result = self._get_return_value(
            "diff_environment",
            {"added": [], "removed": [], "changed": [], "in_sync": True},
        )
        self._record_call(
            "diff_environment",
            kwargs={
                "project_id": project_id,
                "project_path": project_path,
                "environment": environment,
            },
            result=result,
        )
        return result

    def load_from_cache(
        self, project_path: Path, environment: str = "development"
    ) -> list[dict] | None:
        key = f"{project_path}:{environment}"
        cached = self._cached_envs.get(key)
        result = self._get_return_value("load_from_cache", cached)
        self._record_call(
            "load_from_cache",
            kwargs={"project_path": project_path, "environment": environment},
            result=result,
        )
        return result

    def build_inherited_env(
        self,
        project_path: Path | None = None,
        include_defaults: bool = True,
        include_project_env: bool = True,
        include_host_env: bool = True,
        extra_keys: list[str] | None = None,
        extra_patterns: list[str] | None = None,
    ) -> dict[str, str]:
        env = {}
        if include_defaults:
            env.update({"ANTHROPIC_API_KEY": "mock_key", "OPENAI_API_KEY": "mock_key"})
        if include_project_env:
            env.update(self._env_vars)
        result = self._get_return_value("build_inherited_env", env)
        self._record_call(
            "build_inherited_env",
            kwargs={
                "project_path": project_path,
                "include_defaults": include_defaults,
                "include_project_env": include_project_env,
                "include_host_env": include_host_env,
                "extra_keys": extra_keys,
                "extra_patterns": extra_patterns,
            },
            result=result,
        )
        return result


# =============================================================================
# Mock Config
# =============================================================================


class MockConfig(CallTracker):
    """Mock implementation of ConfigProtocol.

    Provides an in-memory implementation of configuration access
    for testing plugins that need configuration values.

    Example:
        config = MockConfig()
        config.set_values({"api_url": "https://api.test.com"})

        data = config.to_dict()
        assert "api_url" in data
    """

    def __init__(self, home: Path | None = None) -> None:
        super().__init__()
        self._home = home or Path("/tmp/flukebase")
        self._values: dict[str, Any] = {}
        self._project_context_detected = False

    # --- Setup Helpers ---

    def set_values(self, values: dict[str, Any]) -> None:
        """Set configuration values."""
        self._values.update(values)

    def set_home(self, home: Path) -> None:
        """Set home directory."""
        self._home = home

    # --- Protocol Methods ---

    @property
    def home(self) -> Path:
        return self._home

    def to_dict(self) -> dict:
        result = self._get_return_value("to_dict", self._values.copy())
        self._record_call("to_dict", result=result)
        return result

    def save(self) -> None:
        self._record_call("save")

    def ensure_project_context(self) -> None:
        self._project_context_detected = True
        self._record_call("ensure_project_context")

    def refresh_project_context(self, path: Path | None = None) -> None:
        self._project_context_detected = True
        self._record_call(
            "refresh_project_context",
            kwargs={"path": path},
        )


# =============================================================================
# MockPlugin (enhanced version)
# =============================================================================


class MockPlugin(BasePlugin, CallTracker):
    """A mock plugin implementation for testing purposes.

    This class provides a minimal implementation of BasePlugin that can
    be used in tests without requiring actual functionality. Now enhanced
    with call tracking capabilities.

    Example:
        plugin = MockPlugin()
        await plugin.initialize({}, {})
        assert plugin.get_metadata().name == "mock-plugin"
        assert plugin.was_called("initialize")  # NEW: call tracking
    """

    def __init__(
        self,
        name: str = "mock-plugin",
        display_name: str = "Mock Plugin",
        version: str = "1.0.0",
        tools: list[ToolDefinition] | None = None,
    ) -> None:
        """Initialize the mock plugin.

        Args:
            name: Plugin name for metadata.
            display_name: Human-readable plugin name.
            version: Plugin version for metadata.
            tools: Optional list of tool definitions.
        """
        BasePlugin.__init__(self)
        CallTracker.__init__(self)
        self._name = name
        self._display_name = display_name
        self._version = version
        self._tools = tools or []
        self._shutdown = False

    def get_metadata(self) -> PluginMetadata:
        """Return mock plugin metadata."""
        return PluginMetadata(
            name=self._name,
            display_name=self._display_name,
            version=self._version,
            description="Mock plugin for testing",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
            author="FlukeBase",
        )

    def get_tools(self) -> list[ToolDefinition]:
        """Return configured mock tools."""
        return self._tools

    async def initialize(self, config: dict, services: dict) -> None:
        """Initialize and track the call."""
        await super().initialize(config, services)
        self._record_call(
            "initialize",
            kwargs={"config": config, "services": services},
        )

    async def shutdown(self) -> None:
        """Mark plugin as shutdown and track the call."""
        await super().shutdown()
        self._shutdown = True
        self._record_call("shutdown")

    @property
    def is_shutdown(self) -> bool:
        """Check if plugin has been shutdown."""
        return self._shutdown

    async def handle_tool_call(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        """Return a mock response for tool calls.

        Args:
            tool_name: Name of the tool being called.
            arguments: Dictionary of arguments.

        Returns:
            Dictionary with tool_name and arguments for verification.
        """
        result = {"tool": tool_name, "arguments": arguments, "result": "mock"}
        self._record_call(
            "handle_tool_call",
            kwargs={"tool_name": tool_name, "arguments": arguments},
            result=result,
        )
        return result


# =============================================================================
# Factory Functions
# =============================================================================


def create_mock_services(
    include_client: bool = True,
    include_memory: bool = True,
    include_wedo: bool = True,
    include_env: bool = True,
    include_config: bool = True,
) -> dict[str, Any]:
    """Create a complete mock services dict for plugin testing.

    This creates pre-configured mock services that can be passed directly
    to plugin.initialize(). Each mock can be accessed individually for
    setup and verification.

    Args:
        include_client: Include MockFlukeBaseClient.
        include_memory: Include MockMemoryStore.
        include_wedo: Include MockWedoManager.
        include_env: Include MockEnvManager.
        include_config: Include MockConfig.

    Returns:
        Dictionary of mock services ready for plugin initialization.

    Example:
        services = create_mock_services()
        await plugin.initialize({}, services)

        # Access mocks for setup
        services["flukebase_client"].add_project(MockProject(id=1, name="test"))

        # Access mocks for verification
        assert services["memory"].was_called("remember")
    """
    services: dict[str, Any] = {}

    if include_client:
        services["flukebase_client"] = MockFlukeBaseClient()
    if include_memory:
        services["memory"] = MockMemoryStore()
    if include_wedo:
        services["wedo"] = MockWedoManager()
    if include_env:
        services["env_manager"] = MockEnvManager()
    if include_config:
        services["config"] = MockConfig()

    return services


def create_mock_services_with_data(
    project: MockProject | None = None,
    memories: list[MockMemory] | None = None,
    tasks: list[MockTask] | None = None,
    env_vars: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Create mock services pre-populated with test data.

    Convenience function that creates mock services and populates them
    with provided test data.

    Args:
        project: Project to add to client mock.
        memories: Memories to add to memory store.
        tasks: Tasks to add to WeDo manager.
        env_vars: Environment variables to set.

    Returns:
        Dictionary of mock services with test data.

    Example:
        services = create_mock_services_with_data(
            project=MockProject(id=1, name="test"),
            memories=[MockMemory(id="m1", content="test", type="fact")],
            env_vars={"API_KEY": "test123"},
        )
    """
    services = create_mock_services()

    if project:
        services["flukebase_client"].add_project(project)

    if memories:
        for memory in memories:
            services["memory"].add_memory(memory)

    if tasks:
        for task in tasks:
            services["wedo"].add_task(task)

    if env_vars:
        services["env_manager"].set_env_vars(env_vars)

    return services
