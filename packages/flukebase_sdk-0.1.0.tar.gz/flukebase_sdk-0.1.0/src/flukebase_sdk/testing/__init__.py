"""Testing utilities for FlukeBase plugins.

This module provides comprehensive testing utilities including:
- Mock implementations of all service protocols
- Pytest fixtures for easy test setup
- Call tracking and verification helpers
- Pre-configured test data factories

Quick Start:
    from flukebase_sdk.testing import MockPlugin, create_mock_services

    # Create mock services for plugin testing
    services = create_mock_services()
    plugin = MyPlugin()
    await plugin.initialize({}, services)

    # Verify service interactions
    assert services["memory"].was_called("remember")

Using Fixtures (in conftest.py):
    from flukebase_sdk.testing.fixtures import *  # noqa: F401,F403

    # Now all fixtures are available in your tests
    @pytest.mark.asyncio
    async def test_my_plugin(mock_services):
        plugin = MyPlugin()
        await plugin.initialize({}, mock_services)

Mock Classes:
    - MockFlukeBaseClient: Mock for FlukeBaseClientProtocol
    - MockMemoryStore: Mock for MemoryStoreProtocol
    - MockWedoManager: Mock for WedoManagerProtocol
    - MockEnvManager: Mock for EnvManagerProtocol
    - MockConfig: Mock for ConfigProtocol
    - MockPlugin: Mock plugin for testing plugin infrastructure

Data Classes:
    - MockProject: Test project data
    - MockMemory: Test memory data
    - MockTask: Test task data
    - MockAgent: Test agent data
    - MockEnvVar: Test environment variable

Call Tracking:
    - MethodCall: Record of a single method call
    - CallTracker: Mixin class for tracking method calls

Factory Functions:
    - create_mock_services(): Create all mock services
    - create_mock_services_with_data(): Create services with test data
"""

from flukebase_sdk.testing.mocks import (
    # Call tracking
    CallTracker,
    MethodCall,
    # Mock data classes
    MockAgent,
    MockConfig,
    MockEnvManager,
    MockEnvVar,
    MockFlukeBaseClient,
    MockMemory,
    MockMemoryStore,
    # Mock plugin
    MockPlugin,
    MockProject,
    MockTask,
    MockWedoManager,
    # Factory functions
    create_mock_services,
    create_mock_services_with_data,
)

# Note: Fixtures are not imported here to avoid pytest collection issues
# Import them in your conftest.py with:
#   from flukebase_sdk.testing.fixtures import *  # noqa: F401,F403

__all__ = [
    # Call tracking
    "CallTracker",
    "MethodCall",
    # Mock data classes
    "MockProject",
    "MockMemory",
    "MockTask",
    "MockAgent",
    "MockEnvVar",
    # Mock service implementations
    "MockFlukeBaseClient",
    "MockMemoryStore",
    "MockWedoManager",
    "MockEnvManager",
    "MockConfig",
    # Mock plugin
    "MockPlugin",
    # Factory functions
    "create_mock_services",
    "create_mock_services_with_data",
]
