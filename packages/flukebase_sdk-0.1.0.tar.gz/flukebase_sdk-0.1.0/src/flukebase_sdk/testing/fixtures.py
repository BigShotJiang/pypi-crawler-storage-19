"""Pytest fixtures for FlukeBase plugin testing.

This module provides pytest fixtures that make it easy to test plugins
with mock services. The fixtures include both session-scoped and
function-scoped variants for different testing needs.

Usage:
    # In your conftest.py
    from flukebase_sdk.testing.fixtures import *  # noqa: F401,F403

    # Or import specific fixtures
    from flukebase_sdk.testing.fixtures import (
        mock_services,
        mock_flukebase_client,
        mock_memory_store,
    )

    # In your tests
    @pytest.mark.asyncio
    async def test_my_plugin(mock_services):
        plugin = MyPlugin()
        await plugin.initialize({}, mock_services)
        # ... test assertions

Example test file:
    import pytest
    from flukebase_sdk.testing.fixtures import *  # noqa: F401,F403

    @pytest.mark.asyncio
    async def test_plugin_uses_memory(mock_services):
        plugin = MyPlugin()
        await plugin.initialize({}, mock_services)

        # Plugin should have called memory.remember
        memory = mock_services["memory"]
        assert memory.was_called("remember")
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

from flukebase_sdk.testing.mocks import (
    MockConfig,
    MockEnvManager,
    MockFlukeBaseClient,
    MockMemory,
    MockMemoryStore,
    MockPlugin,
    MockProject,
    MockTask,
    MockWedoManager,
    create_mock_services,
    create_mock_services_with_data,
)

if TYPE_CHECKING:
    from flukebase_sdk.testing.mocks import CallTracker


# =============================================================================
# Function-Scoped Fixtures (Fresh per test)
# =============================================================================


@pytest.fixture
def mock_flukebase_client() -> MockFlukeBaseClient:
    """Create a fresh MockFlukeBaseClient for each test.

    Returns:
        A new MockFlukeBaseClient instance.

    Example:
        @pytest.mark.asyncio
        async def test_client_operations(mock_flukebase_client):
            mock_flukebase_client.add_project(MockProject(id=1, name="test"))
            projects = await mock_flukebase_client.list_projects()
            assert len(projects) == 1
    """
    return MockFlukeBaseClient()


@pytest.fixture
def mock_memory_store() -> MockMemoryStore:
    """Create a fresh MockMemoryStore for each test.

    Returns:
        A new MockMemoryStore instance.

    Example:
        @pytest.mark.asyncio
        async def test_memory_operations(mock_memory_store):
            await mock_memory_store.remember("Test fact", type="fact")
            results = await mock_memory_store.recall("Test")
            assert len(results) == 1
    """
    return MockMemoryStore()


@pytest.fixture
def mock_wedo_manager() -> MockWedoManager:
    """Create a fresh MockWedoManager for each test.

    Returns:
        A new MockWedoManager instance.

    Example:
        @pytest.mark.asyncio
        async def test_task_operations(mock_wedo_manager):
            await mock_wedo_manager.create_task("TEST-001", "Test task")
            task = await mock_wedo_manager.get_task("TEST-001")
            assert task is not None
    """
    return MockWedoManager()


@pytest.fixture
def mock_env_manager() -> MockEnvManager:
    """Create a fresh MockEnvManager for each test.

    Returns:
        A new MockEnvManager instance.

    Example:
        def test_env_operations(mock_env_manager):
            mock_env_manager.set_env_vars({"API_KEY": "test"})
            env = mock_env_manager.show_environment(Path("/project"))
            assert "API_KEY" in env
    """
    return MockEnvManager()


@pytest.fixture
def mock_config() -> MockConfig:
    """Create a fresh MockConfig for each test.

    Returns:
        A new MockConfig instance.

    Example:
        def test_config_operations(mock_config):
            mock_config.set_values({"setting": "value"})
            data = mock_config.to_dict()
            assert data["setting"] == "value"
    """
    return MockConfig()


@pytest.fixture
def mock_plugin() -> MockPlugin:
    """Create a fresh MockPlugin for each test.

    Returns:
        A new MockPlugin instance.

    Example:
        @pytest.mark.asyncio
        async def test_plugin_lifecycle(mock_plugin):
            await mock_plugin.initialize({}, {})
            assert mock_plugin.is_initialized
    """
    return MockPlugin()


@pytest.fixture
def mock_services() -> dict[str, Any]:
    """Create a complete set of mock services for each test.

    This is the primary fixture for plugin testing. It creates all
    mock services pre-configured and ready for plugin.initialize().

    Returns:
        Dictionary with all mock services.

    Example:
        @pytest.mark.asyncio
        async def test_my_plugin(mock_services):
            plugin = MyPlugin()
            await plugin.initialize({}, mock_services)

            # Verify plugin used the memory service
            assert mock_services["memory"].was_called("remember")
    """
    return create_mock_services()


# =============================================================================
# Session-Scoped Fixtures (Shared across tests in session)
# =============================================================================


@pytest.fixture(scope="session")
def mock_flukebase_client_session() -> MockFlukeBaseClient:
    """Create a session-scoped MockFlukeBaseClient.

    Use this when you want to share client state across multiple tests.
    Remember to call reset() if you need to clear state between tests.

    Returns:
        A session-scoped MockFlukeBaseClient instance.

    Example:
        def test_with_session_client(mock_flukebase_client_session):
            # This client is shared across all tests in the session
            mock_flukebase_client_session.reset()  # Clear any previous state
            mock_flukebase_client_session.add_project(MockProject(id=1, name="test"))
    """
    return MockFlukeBaseClient()


@pytest.fixture(scope="session")
def mock_memory_store_session() -> MockMemoryStore:
    """Create a session-scoped MockMemoryStore.

    Use this when you want to share memory state across multiple tests.

    Returns:
        A session-scoped MockMemoryStore instance.
    """
    return MockMemoryStore()


@pytest.fixture(scope="session")
def mock_wedo_manager_session() -> MockWedoManager:
    """Create a session-scoped MockWedoManager.

    Use this when you want to share task state across multiple tests.

    Returns:
        A session-scoped MockWedoManager instance.
    """
    return MockWedoManager()


@pytest.fixture(scope="session")
def mock_services_session() -> dict[str, Any]:
    """Create session-scoped mock services.

    Use this when you want to share service state across multiple tests.
    Be careful about test isolation when using session-scoped fixtures.

    Returns:
        Dictionary with session-scoped mock services.

    Example:
        def test_with_session_services(mock_services_session):
            # Reset all mocks before test
            for service in mock_services_session.values():
                if hasattr(service, "reset"):
                    service.reset()
    """
    return create_mock_services()


# =============================================================================
# Pre-Configured Fixtures (With test data)
# =============================================================================


@pytest.fixture
def mock_project() -> MockProject:
    """Create a sample MockProject for testing.

    Returns:
        A pre-configured MockProject instance.

    Example:
        def test_with_project(mock_project, mock_flukebase_client):
            mock_flukebase_client.add_project(mock_project)
            # Now client has a project
    """
    return MockProject(
        id=1,
        name="test-project",
        repository_url="https://github.com/test/repo",
        description="A test project for unit testing",
        stage="development",
    )


@pytest.fixture
def mock_memory() -> MockMemory:
    """Create a sample MockMemory for testing.

    Returns:
        A pre-configured MockMemory instance.

    Example:
        def test_with_memory(mock_memory, mock_memory_store):
            mock_memory_store.add_memory(mock_memory)
            results = await mock_memory_store.recall("test")
            assert len(results) == 1
    """
    return MockMemory(
        id="test-memory-001",
        content="This is a test memory for unit testing",
        type="fact",
        scope="global",
        tags=["test", "sample"],
    )


@pytest.fixture
def mock_task() -> MockTask:
    """Create a sample MockTask for testing.

    Returns:
        A pre-configured MockTask instance.

    Example:
        def test_with_task(mock_task, mock_wedo_manager):
            mock_wedo_manager.add_task(mock_task)
            task = await mock_wedo_manager.get_task(mock_task.task_id)
            assert task is not None
    """
    return MockTask(
        task_id="TEST-001",
        description="Test task for unit testing",
        status="pending",
        dependency="AGENT_CAPABLE",
        scope="global",
        priority="normal",
        tags=["test"],
    )


@pytest.fixture
def mock_services_with_project(mock_project: MockProject) -> dict[str, Any]:
    """Create mock services with a pre-configured project.

    Returns:
        Dictionary with mock services including a test project.

    Example:
        @pytest.mark.asyncio
        async def test_plugin_with_project(mock_services_with_project):
            plugin = MyPlugin()
            await plugin.initialize({}, mock_services_with_project)

            # Client already has a project
            client = mock_services_with_project["flukebase_client"]
            projects = await client.list_projects()
            assert len(projects) == 1
    """
    return create_mock_services_with_data(project=mock_project)


@pytest.fixture
def mock_services_with_data(
    mock_project: MockProject,
    mock_memory: MockMemory,
    mock_task: MockTask,
) -> dict[str, Any]:
    """Create mock services with full test data.

    This fixture provides services pre-populated with:
    - A test project
    - A test memory
    - A test task
    - Default environment variables

    Returns:
        Dictionary with fully populated mock services.

    Example:
        @pytest.mark.asyncio
        async def test_plugin_with_full_data(mock_services_with_data):
            plugin = MyPlugin()
            await plugin.initialize({}, mock_services_with_data)

            # All services have test data ready
            client = mock_services_with_data["flukebase_client"]
            memory = mock_services_with_data["memory"]
            wedo = mock_services_with_data["wedo"]
    """
    return create_mock_services_with_data(
        project=mock_project,
        memories=[mock_memory],
        tasks=[mock_task],
        env_vars={
            "API_KEY": "test-api-key",
            "DEBUG": "true",
            "DATABASE_URL": "sqlite:///test.db",
        },
    )


# =============================================================================
# Utility Fixtures
# =============================================================================


@pytest.fixture
def temp_project_path(tmp_path: Path) -> Path:
    """Create a temporary project path for testing.

    Returns:
        A temporary directory path for project testing.

    Example:
        def test_env_sync(mock_env_manager, temp_project_path):
            await mock_env_manager.sync_environment(1, temp_project_path)
    """
    project_path = tmp_path / "test-project"
    project_path.mkdir(parents=True, exist_ok=True)
    return project_path


@pytest.fixture
def reset_mocks():
    """Fixture that provides a helper to reset multiple mocks.

    Returns:
        A function that resets all provided mocks.

    Example:
        def test_with_reset(mock_services, reset_mocks):
            # ... do something with services ...

            # Reset all services
            reset_mocks(mock_services.values())

            # Services are now in fresh state
    """

    def _reset_mocks(mocks: Any) -> None:
        """Reset all provided mock objects."""
        for mock in mocks:
            if hasattr(mock, "reset"):
                mock.reset()

    return _reset_mocks


@pytest.fixture
def assert_mock_called():
    """Fixture that provides assertion helpers for mock verification.

    Returns:
        A helper object with assertion methods.

    Example:
        def test_calls(mock_memory_store, assert_mock_called):
            await mock_memory_store.remember("test", type="fact")

            assert_mock_called.once(mock_memory_store, "remember")
            assert_mock_called.with_kwargs(
                mock_memory_store, "remember", content="test", type="fact"
            )
    """

    class MockAssertions:
        @staticmethod
        def called(mock: CallTracker, method: str) -> None:
            """Assert that a method was called."""
            assert mock.was_called(method), f"Expected {method} to be called"

        @staticmethod
        def not_called(mock: CallTracker, method: str) -> None:
            """Assert that a method was NOT called."""
            assert not mock.was_called(method), f"Expected {method} to not be called"

        @staticmethod
        def once(mock: CallTracker, method: str) -> None:
            """Assert that a method was called exactly once."""
            count = mock.call_count(method)
            assert count == 1, (
                f"Expected {method} to be called once, was called {count} times"
            )

        @staticmethod
        def times(mock: CallTracker, method: str, expected: int) -> None:
            """Assert that a method was called a specific number of times."""
            count = mock.call_count(method)
            assert count == expected, (
                f"Expected {method} to be called {expected} times, "
                f"was called {count} times"
            )

        @staticmethod
        def with_kwargs(mock: CallTracker, method: str, **kwargs: Any) -> None:
            """Assert that a method was called with specific kwargs."""
            calls = mock.get_calls(method)
            for call in calls:
                if all(call.kwargs.get(k) == v for k, v in kwargs.items()):
                    return
            raise AssertionError(f"Expected {method} to be called with {kwargs}")

    return MockAssertions()


# =============================================================================
# Async Cleanup Fixtures
# =============================================================================


@pytest.fixture
async def mock_services_async() -> dict[str, Any]:
    """Async fixture that creates mock services.

    This is useful when you need async setup/teardown for your tests.

    Returns:
        Dictionary with all mock services.

    Example:
        @pytest.mark.asyncio
        async def test_async_plugin(mock_services_async):
            plugin = MyPlugin()
            await plugin.initialize({}, mock_services_async)
    """
    services = create_mock_services()
    yield services
    # Cleanup: close client if it has an open connection
    client = services.get("flukebase_client")
    if client and hasattr(client, "_closed") and not client._closed:
        await client.close()


@pytest.fixture
async def initialized_plugin(mock_services: dict[str, Any]) -> MockPlugin:
    """Create a MockPlugin that's already initialized.

    Returns:
        An initialized MockPlugin instance.

    Example:
        @pytest.mark.asyncio
        async def test_initialized_plugin(initialized_plugin):
            assert initialized_plugin.is_initialized
            result = await initialized_plugin.handle_tool_call("test", {})
    """
    plugin = MockPlugin()
    await plugin.initialize({}, mock_services)
    yield plugin
    await plugin.shutdown()


# =============================================================================
# Parametrized Fixtures
# =============================================================================


@pytest.fixture(params=["fact", "convention", "gotcha", "decision"])
def memory_type(request: pytest.FixtureRequest) -> str:
    """Parametrized fixture for testing all memory types.

    Yields:
        Each memory type in sequence.

    Example:
        @pytest.mark.asyncio
        async def test_all_memory_types(mock_memory_store, memory_type):
            await mock_memory_store.remember("test", type=memory_type)
            # Test runs once for each memory type
    """
    return request.param


@pytest.fixture(params=["pending", "in_progress", "completed", "blocked"])
def task_status(request: pytest.FixtureRequest) -> str:
    """Parametrized fixture for testing all task statuses.

    Yields:
        Each task status in sequence.

    Example:
        @pytest.mark.asyncio
        async def test_all_task_statuses(mock_wedo_manager, task_status):
            task = MockTask(task_id="T-001", description="test", status=task_status)
            mock_wedo_manager.add_task(task)
            # Test runs once for each status
    """
    return request.param


@pytest.fixture(params=["global", "project-a", "project-b"])
def scope(request: pytest.FixtureRequest) -> str:
    """Parametrized fixture for testing different scopes.

    Yields:
        Each scope in sequence.

    Example:
        @pytest.mark.asyncio
        async def test_different_scopes(mock_memory_store, scope):
            mock_memory_store.add_scope(scope)
            await mock_memory_store.remember("test", scope=scope)
            # Test runs once for each scope
    """
    return request.param


# =============================================================================
# Export all fixtures
# =============================================================================

__all__ = [
    # Function-scoped mocks
    "mock_flukebase_client",
    "mock_memory_store",
    "mock_wedo_manager",
    "mock_env_manager",
    "mock_config",
    "mock_plugin",
    "mock_services",
    # Session-scoped mocks
    "mock_flukebase_client_session",
    "mock_memory_store_session",
    "mock_wedo_manager_session",
    "mock_services_session",
    # Pre-configured data
    "mock_project",
    "mock_memory",
    "mock_task",
    "mock_services_with_project",
    "mock_services_with_data",
    # Utilities
    "temp_project_path",
    "reset_mocks",
    "assert_mock_called",
    # Async fixtures
    "mock_services_async",
    "initialized_plugin",
    # Parametrized fixtures
    "memory_type",
    "task_status",
    "scope",
]
