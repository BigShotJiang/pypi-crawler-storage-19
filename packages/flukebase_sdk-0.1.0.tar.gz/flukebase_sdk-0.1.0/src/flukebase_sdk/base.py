"""Base plugin abstract class for FlukeBase plugins."""

from abc import ABC, abstractmethod
from typing import Any

from flukebase_sdk.metadata import PluginMetadata
from flukebase_sdk.tools import ToolDefinition


class BasePlugin(ABC):
    """Abstract base class for all FlukeBase Connect plugins.

    To create a plugin:
    1. Subclass BasePlugin
    2. Implement get_metadata() to return plugin info
    3. Implement get_tools() to return tool definitions
    4. Implement handler methods for each tool
    5. Optionally implement initialize() and shutdown() for lifecycle management

    Example:
        class MyPlugin(BasePlugin):
            def get_metadata(self) -> PluginMetadata:
                return PluginMetadata(
                    name="my-plugin",
                    display_name="My Plugin",
                    version="1.0.0",
                    description="Does something useful",
                    plugin_type=PluginType.TOOL,
                    maturity=PluginMaturity.MVP,
                    features={"basic_functionality": True}
                )

            def get_tools(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="my_tool",
                        description="Does a thing",
                        input_schema={"type": "object", "properties": {}},
                        handler_method="handle_my_tool"
                    )
                ]

            async def handle_my_tool(self, args: dict) -> str:
                return "Tool executed!"
    """

    def __init__(self):
        """Initialize the plugin. Override for custom initialization."""
        self._config: dict = {}
        self._services: dict = {}
        self._initialized: bool = False

    @abstractmethod
    def get_metadata(self) -> PluginMetadata:
        """Return metadata describing this plugin.

        Returns:
            PluginMetadata with name, version, type, maturity, and features.
        """
        pass

    @abstractmethod
    def get_tools(self) -> list[ToolDefinition]:
        """Return list of tools provided by this plugin.

        Returns:
            List of ToolDefinition objects describing each tool.
        """
        pass

    async def initialize(self, config: dict, services: dict) -> None:
        """Initialize the plugin with configuration and shared services.

        Called once when the plugin is loaded. Override to perform
        setup like establishing connections or loading resources.

        Args:
            config: Plugin-specific configuration from config file
            services: Shared services dict (e.g., flukebase_client, env_manager)
        """
        self._config = config
        self._services = services
        self._initialized = True

    async def shutdown(self) -> None:
        """Clean up resources when the plugin is unloaded.

        Override to close connections, save state, etc.
        """
        self._initialized = False

    @property
    def is_initialized(self) -> bool:
        """Check if the plugin has been initialized."""
        return self._initialized

    def validate_scope(self, required_scope: str, token_scopes: list[str]) -> bool:
        """Check if the token has the required scope.

        Args:
            required_scope: The scope required for an operation
            token_scopes: List of scopes the token has

        Returns:
            True if the token has the required scope or wildcard
        """
        return required_scope in token_scopes or "*" in token_scopes

    def get_service(self, name: str) -> Any:
        """Get a shared service by name.

        Args:
            name: Service name (e.g., "flukebase_client", "env_manager", "memory")

        Returns:
            The service instance or None if not available
        """
        return self._services.get(name)

    def get_config_value(self, key: str, default: Any = None) -> Any:
        """Get a configuration value for this plugin.

        Args:
            key: Configuration key
            default: Default value if key not found

        Returns:
            The configuration value or default
        """
        return self._config.get(key, default)

    # AI-ARCH-001: Optional methods for AI agent comprehension
    def get_capability_summary(self) -> dict | None:
        """Return AI-readable capability summary.

        Override this method to provide AI agents with a quick understanding
        of what this plugin does, especially when get_tools() is delegated
        to a manifest for lazy loading.

        Returns:
            dict with keys like: tool_count, domains, prefixes, notes
            or None if get_tools() is self-describing
        """
        return None

    def get_ai_architecture_notes(self) -> str:
        """Return architecture notes for AI agents.

        Explain any non-obvious patterns like:
        - Lazy loading delegation to manifest
        - Tool prefix conventions
        - Hidden capabilities not exposed via get_tools()

        Returns:
            Human-readable architecture notes string
        """
        return ""
