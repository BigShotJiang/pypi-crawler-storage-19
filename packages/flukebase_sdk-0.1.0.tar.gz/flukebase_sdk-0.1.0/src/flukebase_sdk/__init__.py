"""FlukeBase SDK - Plugin development kit for the FlukeBase platform."""

from flukebase_sdk.base import BasePlugin
from flukebase_sdk.metadata import PluginMaturity, PluginMetadata, PluginType
from flukebase_sdk.protocols import (
    ConfigProtocol,
    EnvManagerProtocol,
    FlukeBaseClientProtocol,
    MemoryStoreProtocol,
    MemoryType,
    ScopeType,
    ServiceDict,
    TaskPriorityType,
    WedoDependencyType,
    WedoManagerProtocol,
    WedoStatusType,
    get_typed_service,
)
from flukebase_sdk.scopes import (
    DEFAULT_SCOPES,
    ELEVATED_SCOPES,
    SCOPE_CATEGORIES,
    PluginScope,
    get_scope_description,
    requires_approval,
    validate_scopes,
)
from flukebase_sdk.tools import ResourceDefinition, ToolAnnotations, ToolDefinition

__version__ = "0.1.0"

__all__ = [
    # Base plugin class
    "BasePlugin",
    # Plugin metadata
    "PluginMaturity",
    "PluginMetadata",
    "PluginType",
    # Plugin scopes and permissions (CLOSED-011)
    "PluginScope",
    "SCOPE_CATEGORIES",
    "ELEVATED_SCOPES",
    "DEFAULT_SCOPES",
    "validate_scopes",
    "get_scope_description",
    "requires_approval",
    # Tool definitions
    "ResourceDefinition",
    "ToolAnnotations",
    "ToolDefinition",
    # Service protocols (CLOSED-009 + CLOSED-020)
    "FlukeBaseClientProtocol",
    "MemoryStoreProtocol",
    "WedoManagerProtocol",
    "EnvManagerProtocol",
    "ConfigProtocol",
    # Type aliases for protocols
    "MemoryType",
    "ScopeType",
    "WedoStatusType",
    "WedoDependencyType",
    "TaskPriorityType",
    "ServiceDict",
    # Helper functions
    "get_typed_service",
    # Version
    "__version__",
]
