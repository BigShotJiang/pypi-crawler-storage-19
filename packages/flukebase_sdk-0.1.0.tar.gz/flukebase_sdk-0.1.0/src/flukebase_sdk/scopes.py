"""Plugin scope and permission definitions.

This module defines the available scopes that plugins can request access to.
FlukeBase Connect enforces these scopes at runtime, ensuring plugins only
access the services and data they've declared.
"""

from enum import Enum


class PluginScope(str, Enum):
    """Available scopes for plugin permissions.

    Plugins must declare required scopes in their PluginMetadata.
    FlukeBase Connect validates these scopes and restricts service access accordingly.

    Example:
        PluginMetadata(
            name="my-plugin",
            required_scopes=[
                PluginScope.MEMORY_READ,
                PluginScope.MEMORY_WRITE,
            ],
            ...
        )
    """

    # Memory service scopes
    MEMORY_READ = "memory:read"
    """Read access to memory store (recall, search)."""

    MEMORY_WRITE = "memory:write"
    """Write access to memory store (remember, forget)."""

    # WeDo task service scopes
    WEDO_READ = "wedo:read"
    """Read access to WeDo tasks (list, get)."""

    WEDO_WRITE = "wedo:write"
    """Write access to WeDo tasks (create, update)."""

    WEDO_DELETE = "wedo:delete"
    """Delete access to WeDo tasks."""

    # Environment service scopes
    ENV_READ = "env:read"
    """Read access to environment variables (masked by default)."""

    ENV_READ_SECRETS = "env:read_secrets"
    """Read access to unmasked secret values. Use with caution."""

    # FlukeBase API client scopes
    API_READ = "api:read"
    """Read access to FlukeBase API (status, project info)."""

    API_WRITE = "api:write"
    """Write access to FlukeBase API (push memories, sync)."""

    # Configuration scopes
    CONFIG_READ = "config:read"
    """Read access to configuration values."""

    # File system scopes (sandboxed)
    FS_READ_PROJECT = "fs:read_project"
    """Read files within the project directory only."""

    FS_WRITE_PROJECT = "fs:write_project"
    """Write files within the project directory only."""

    # Network scopes
    NETWORK_OUTBOUND = "network:outbound"
    """Make outbound network requests (HTTP, WebSocket)."""

    # Subprocess scopes (restricted)
    SUBPROCESS_SAFE = "subprocess:safe"
    """Run safe, predefined subprocess commands."""

    SUBPROCESS_UNRESTRICTED = "subprocess:unrestricted"
    """Run unrestricted subprocess commands. Requires explicit user approval."""


# Scope categories for documentation and validation
SCOPE_CATEGORIES = {
    "memory": [PluginScope.MEMORY_READ, PluginScope.MEMORY_WRITE],
    "wedo": [PluginScope.WEDO_READ, PluginScope.WEDO_WRITE, PluginScope.WEDO_DELETE],
    "env": [PluginScope.ENV_READ, PluginScope.ENV_READ_SECRETS],
    "api": [PluginScope.API_READ, PluginScope.API_WRITE],
    "config": [PluginScope.CONFIG_READ],
    "fs": [PluginScope.FS_READ_PROJECT, PluginScope.FS_WRITE_PROJECT],
    "network": [PluginScope.NETWORK_OUTBOUND],
    "subprocess": [PluginScope.SUBPROCESS_SAFE, PluginScope.SUBPROCESS_UNRESTRICTED],
}


# Scopes that require explicit user approval
ELEVATED_SCOPES = {
    PluginScope.ENV_READ_SECRETS,
    PluginScope.FS_WRITE_PROJECT,
    PluginScope.SUBPROCESS_UNRESTRICTED,
}


# Default scopes granted to all plugins (minimal read access)
DEFAULT_SCOPES = {
    PluginScope.CONFIG_READ,
}


def validate_scopes(requested_scopes: list[str]) -> tuple[bool, list[str]]:
    """Validate a list of requested scopes.

    Args:
        requested_scopes: List of scope strings to validate.

    Returns:
        Tuple of (is_valid, invalid_scopes).
        is_valid is True if all scopes are valid.
        invalid_scopes contains any unrecognized scope strings.
    """
    valid_scope_values = {s.value for s in PluginScope}
    invalid = [s for s in requested_scopes if s not in valid_scope_values]
    return len(invalid) == 0, invalid


def get_scope_description(scope: str | PluginScope) -> str:
    """Get a human-readable description for a scope.

    Args:
        scope: The scope to describe (string or PluginScope enum).

    Returns:
        Description string, or 'Unknown scope' if not found.
    """
    if isinstance(scope, str):
        try:
            scope = PluginScope(scope)
        except ValueError:
            return "Unknown scope"

    descriptions = {
        PluginScope.MEMORY_READ: "Read memories from the local store",
        PluginScope.MEMORY_WRITE: "Store and delete memories",
        PluginScope.WEDO_READ: "View WeDo tasks and progress",
        PluginScope.WEDO_WRITE: "Create and update WeDo tasks",
        PluginScope.WEDO_DELETE: "Delete WeDo tasks",
        PluginScope.ENV_READ: "Read environment variables (secrets masked)",
        PluginScope.ENV_READ_SECRETS: "Read unmasked secret values",
        PluginScope.API_READ: "Read from FlukeBase API",
        PluginScope.API_WRITE: "Write to FlukeBase API",
        PluginScope.CONFIG_READ: "Read configuration values",
        PluginScope.FS_READ_PROJECT: "Read files in project directory",
        PluginScope.FS_WRITE_PROJECT: "Write files in project directory",
        PluginScope.NETWORK_OUTBOUND: "Make outbound network requests",
        PluginScope.SUBPROCESS_SAFE: "Run safe subprocess commands",
        PluginScope.SUBPROCESS_UNRESTRICTED: "Run any subprocess command",
    }
    return descriptions.get(scope, "Unknown scope")


def requires_approval(scopes: list[str | PluginScope]) -> list[PluginScope]:
    """Get list of scopes that require explicit user approval.

    Args:
        scopes: List of scopes to check.

    Returns:
        List of elevated scopes that require approval.
    """
    result = []
    for scope in scopes:
        if isinstance(scope, str):
            try:
                scope = PluginScope(scope)
            except ValueError:
                continue
        if scope in ELEVATED_SCOPES:
            result.append(scope)
    return result
