"""Tool and resource definitions for FlukeBase plugins."""

from dataclasses import dataclass


@dataclass
class ToolAnnotations:
    """MCP tool behavior hints (MCP-EXPAND-001-05).

    These annotations help AI clients make safer decisions about tool usage:
    - read_only: Tool only reads data, no side effects
    - destructive: Tool may delete or permanently modify data
    - idempotent: Safe to retry without different results
    - open_world: May interact with external systems
    """

    read_only: bool = False
    destructive: bool = False
    idempotent: bool = False
    open_world: bool = True

    def to_mcp_format(self) -> dict:
        """Convert to MCP annotations format."""
        return {
            "readOnlyHint": self.read_only,
            "destructiveHint": self.destructive,
            "idempotentHint": self.idempotent,
            "openWorldHint": self.open_world,
        }

    @classmethod
    def infer_from_tool_name(cls, name: str) -> "ToolAnnotations":
        """Auto-infer annotations from tool naming conventions."""
        # Read-only patterns
        read_only = any(
            name.startswith(prefix)
            for prefix in (
                "list_",
                "get_",
                "show_",
                "search_",
                "find_",
                "mem_recall",
                "mem_search",
                "mem_list",
                "mem_why",
                "wedo_list",
                "wedo_get",
                "wedo_progress",
                "log_",
                "metrics_",
                "dashboard_",
                "cache_status",
                "env_show",
                "env_validate",
                "fb_status",
                "fb_projects",
                "gateway_list",
                "gateway_server_status",
                "agent_list",
                "agent_whoami",
            )
        )

        # Destructive patterns
        destructive = any(
            name.startswith(prefix)
            for prefix in (
                "delete_",
                "remove_",
                "drop_",
                "destroy_",
                "mem_forget",
                "cache_clear",
                "sandbox_destroy",
                "gateway_remove",
            )
        )

        # Idempotent patterns (safe to retry)
        idempotent = read_only or any(
            name.startswith(prefix)
            for prefix in (
                "mem_remember",  # Upsert behavior
                "wedo_update",  # Status updates are idempotent
                "env_pull",  # Overwrites with same data
                "fb_sync",
                "agent_register",  # Re-registering is safe
            )
        )

        # Open world (external system interaction)
        open_world = any(
            pattern in name
            for pattern in (
                "fb_",
                "env_pull",
                "env_push",
                "webhook_",
                "sandbox_",
                "gateway_",  # Upstream MCP servers
            )
        )

        return cls(
            read_only=read_only,
            destructive=destructive,
            idempotent=idempotent,
            open_world=open_world,
        )


@dataclass
class ResourceDefinition:
    """Definition of a resource provided by a plugin (MCP-EXPAND-001-01).

    Resources are static data that AI clients can browse without tool calls.
    """

    uri: str  # e.g., "wedo://tasks/global" or "memory://global/facts"
    name: str  # Human-readable name
    description: str
    mime_type: str = "application/json"

    def to_mcp_format(self) -> dict:
        """Convert to MCP resource format."""
        return {
            "uri": self.uri,
            "name": self.name,
            "description": self.description,
            "mimeType": self.mime_type,
        }


@dataclass
class ToolDefinition:
    """Definition of a single tool provided by a plugin."""

    name: str
    description: str
    input_schema: dict
    handler_method: str  # Method name on the plugin class to call
    annotations: ToolAnnotations | None = None  # MCP-EXPAND-001-05

    def __post_init__(self):
        """Auto-infer annotations if not provided."""
        if self.annotations is None:
            self.annotations = ToolAnnotations.infer_from_tool_name(self.name)

    def to_mcp_format(self) -> dict:
        """Convert to MCP tool definition format."""
        result = {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }
        # MCP-EXPAND-001-05: Include annotations if available
        if self.annotations:
            result["annotations"] = self.annotations.to_mcp_format()
        return result
