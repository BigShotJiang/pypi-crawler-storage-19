"""Tests for the SDK mock implementations.

This test file verifies that all mock implementations work correctly
and can be used effectively for plugin testing.
"""

from pathlib import Path

import pytest

from flukebase_sdk.testing import (
    CallTracker,
    MockConfig,
    MockEnvManager,
    MockFlukeBaseClient,
    MockMemory,
    MockMemoryStore,
    MockPlugin,
    MockProject,
    MockTask,
    MockWedoManager,
    create_mock_services,
    create_mock_services_with_data,
)

# =============================================================================
# CallTracker Tests
# =============================================================================


class TestCallTracker:
    """Tests for the CallTracker mixin."""

    def test_record_call(self) -> None:
        """Test that calls are recorded."""
        tracker = CallTracker()
        tracker._record_call("test_method", args=(1, 2), kwargs={"key": "value"})

        assert tracker.call_count("test_method") == 1
        assert tracker.was_called("test_method")

    def test_call_count(self) -> None:
        """Test counting calls to specific methods."""
        tracker = CallTracker()
        tracker._record_call("method_a")
        tracker._record_call("method_a")
        tracker._record_call("method_b")

        assert tracker.call_count("method_a") == 2
        assert tracker.call_count("method_b") == 1
        assert tracker.call_count() == 3  # All calls

    def test_get_calls(self) -> None:
        """Test retrieving recorded calls."""
        tracker = CallTracker()
        tracker._record_call("method_a", args=(1,))
        tracker._record_call("method_b", args=(2,))

        calls_a = tracker.get_calls("method_a")
        assert len(calls_a) == 1
        assert calls_a[0].args == (1,)

        all_calls = tracker.get_calls()
        assert len(all_calls) == 2

    def test_last_call(self) -> None:
        """Test getting the last call."""
        tracker = CallTracker()
        tracker._record_call("method", args=(1,))
        tracker._record_call("method", args=(2,))

        last = tracker.last_call("method")
        assert last is not None
        assert last.args == (2,)

    def test_was_called_with(self) -> None:
        """Test checking if method was called with specific args."""
        tracker = CallTracker()
        tracker._record_call("method", kwargs={"key": "value", "num": 42})

        assert tracker.was_called_with("method", key="value", num=42)
        assert not tracker.was_called_with("method", key="other")

    def test_reset_calls(self) -> None:
        """Test resetting call history."""
        tracker = CallTracker()
        tracker._record_call("method")
        tracker.reset_calls()

        assert tracker.call_count() == 0

    def test_set_return_value(self) -> None:
        """Test setting custom return values."""
        tracker = CallTracker()
        tracker.set_return_value("method", {"custom": "result"})

        result = tracker._get_return_value("method", default="default")
        assert result == {"custom": "result"}

    def test_set_side_effect(self) -> None:
        """Test setting side effects (exceptions)."""
        tracker = CallTracker()
        tracker.set_side_effect("method", ValueError("Test error"))

        with pytest.raises(ValueError, match="Test error"):
            tracker._get_return_value("method")

    def test_reset(self) -> None:
        """Test full reset."""
        tracker = CallTracker()
        tracker._record_call("method")
        tracker.set_return_value("method", "value")
        tracker.set_side_effect("other", ValueError())

        tracker.reset()

        assert tracker.call_count() == 0
        assert tracker._get_return_value("method") is None


# =============================================================================
# MockFlukeBaseClient Tests
# =============================================================================


class TestMockFlukeBaseClient:
    """Tests for MockFlukeBaseClient."""

    def test_init_defaults(self) -> None:
        """Test default initialization."""
        client = MockFlukeBaseClient()
        assert client.is_configured is True
        assert client._connected is True

    def test_init_custom(self) -> None:
        """Test custom initialization."""
        client = MockFlukeBaseClient(
            is_configured=False, connected=False, user_email="custom@test.com"
        )
        assert client.is_configured is False
        assert client._connected is False
        assert client._user_email == "custom@test.com"

    @pytest.mark.asyncio
    async def test_get_status(self) -> None:
        """Test get_status method."""
        client = MockFlukeBaseClient()
        status = await client.get_status()

        assert status["connected"] is True
        assert client.was_called("get_status")

    @pytest.mark.asyncio
    async def test_add_and_list_projects(self) -> None:
        """Test adding and listing projects."""
        client = MockFlukeBaseClient()
        project = MockProject(id=1, name="test-project")
        client.add_project(project)

        projects = await client.list_projects()
        assert len(projects) == 1
        assert projects[0].name == "test-project"

    @pytest.mark.asyncio
    async def test_create_project(self) -> None:
        """Test creating a project."""
        client = MockFlukeBaseClient()
        project = await client.create_project(
            name="new-project", description="A new project"
        )

        assert project.id == 1
        assert project.name == "new-project"
        assert client.was_called("create_project")

    @pytest.mark.asyncio
    async def test_memory_operations(self) -> None:
        """Test memory CRUD operations."""
        client = MockFlukeBaseClient()
        client.add_project(MockProject(id=1, name="test"))

        # Create memory
        memory = await client.create_memory(
            project_id=1, memory_type="fact", content="Test content"
        )
        assert memory.content == "Test content"

        # List memories
        memories = await client.list_memories(project_id=1)
        assert len(memories) == 1

        # Delete memory
        deleted = await client.delete_memory(project_id=1, memory_id=memory.remote_id)
        assert deleted is True

    @pytest.mark.asyncio
    async def test_task_operations(self) -> None:
        """Test task CRUD operations."""
        client = MockFlukeBaseClient()
        client.add_project(MockProject(id=1, name="test"))

        # Create task
        result = await client.create_task(
            project_id=1, task_id="TEST-001", description="Test task"
        )
        assert result["task"].task_id == "TEST-001"

        # Get task
        result = await client.get_task(project_id=1, task_id="TEST-001")
        assert result["task"] is not None

        # Update task
        result = await client.update_task(
            project_id=1, task_id="TEST-001", status="in_progress"
        )
        assert result["task"].status == "in_progress"

    @pytest.mark.asyncio
    async def test_close(self) -> None:
        """Test closing the client."""
        client = MockFlukeBaseClient()
        await client.close()

        assert client._closed is True
        assert client.was_called("close")

    @pytest.mark.asyncio
    async def test_custom_return_value(self) -> None:
        """Test setting custom return values."""
        client = MockFlukeBaseClient()
        client.set_return_value("get_status", {"connected": False, "custom": True})

        status = await client.get_status()
        assert status["connected"] is False
        assert status["custom"] is True


# =============================================================================
# MockMemoryStore Tests
# =============================================================================


class TestMockMemoryStore:
    """Tests for MockMemoryStore."""

    @pytest.mark.asyncio
    async def test_remember_and_recall(self) -> None:
        """Test storing and recalling memories."""
        store = MockMemoryStore()

        # Remember something
        memory = await store.remember("Python uses snake_case", type="convention")
        assert memory.content == "Python uses snake_case"

        # Recall it
        results = await store.recall("snake_case")
        assert len(results) == 1
        assert "snake_case" in results[0].content

    @pytest.mark.asyncio
    async def test_recall_by_type(self) -> None:
        """Test filtering recall by type."""
        store = MockMemoryStore()

        await store.remember("Fact 1", type="fact")
        await store.remember("Convention 1", type="convention")

        facts = await store.recall("1", type="fact")
        assert len(facts) == 1
        assert facts[0].type == "fact"

    @pytest.mark.asyncio
    async def test_forget(self) -> None:
        """Test forgetting a memory."""
        store = MockMemoryStore()

        memory = await store.remember("Test memory", type="fact")
        result = await store.forget(memory.id)

        assert result["success"] is True
        assert result["scope"] == "global"

        # Should not find it anymore
        results = await store.recall("Test memory")
        assert len(results) == 0

    @pytest.mark.asyncio
    async def test_conventions(self) -> None:
        """Test convention operations."""
        store = MockMemoryStore()

        # Set convention
        conv = await store.set_convention(
            key="naming", value="snake_case", rationale="Python standard"
        )
        assert conv["key"] == "naming"

        # Get convention
        result = await store.get_convention("naming")
        assert result["value"] == "snake_case"

        # List conventions
        conventions = await store.list_conventions()
        assert len(conventions) == 1

    def test_list_scopes(self) -> None:
        """Test listing scopes."""
        store = MockMemoryStore()
        store.add_scope("project-a")
        store.add_scope("project-b")

        scopes = store.list_scopes()
        assert "global" in scopes
        assert "project-a" in scopes
        assert "project-b" in scopes


# =============================================================================
# MockWedoManager Tests
# =============================================================================


class TestMockWedoManager:
    """Tests for MockWedoManager."""

    @pytest.mark.asyncio
    async def test_register_agent(self) -> None:
        """Test agent registration."""
        manager = MockWedoManager()

        agent = await manager.register_agent(
            agent_id="ZION", name="ZION", is_named_persona=True
        )

        assert agent.agent_id == "ZION"
        assert agent.is_named_persona is True
        assert manager.get_current_agent_id() == "ZION"

    @pytest.mark.asyncio
    async def test_create_and_get_task(self) -> None:
        """Test task creation and retrieval."""
        manager = MockWedoManager()

        task = await manager.create_task("TEST-001", "Test task")
        assert task.task_id == "TEST-001"
        assert task.status == "pending"

        retrieved = await manager.get_task("TEST-001")
        assert retrieved is not None
        assert retrieved.task_id == "TEST-001"

    @pytest.mark.asyncio
    async def test_update_task_status(self) -> None:
        """Test updating task status."""
        manager = MockWedoManager()
        await manager.create_task("TEST-001", "Test task")

        updated = await manager.update_task_status(
            "TEST-001", "in_progress", synthesis_note="Started work"
        )

        assert updated.status == "in_progress"
        assert "Started work" in updated.synthesis_report

    @pytest.mark.asyncio
    async def test_task_dependencies(self) -> None:
        """Test task dependency checking."""
        manager = MockWedoManager()

        # Create blocking task
        blocking_task = MockTask(
            task_id="BLOCK-001", description="Blocking task", status="pending"
        )
        manager.add_task(blocking_task)

        # Create dependent task
        dependent = MockTask(
            task_id="DEP-001",
            description="Dependent task",
            blocked_by=["BLOCK-001"],
        )
        manager.add_task(dependent)

        # Check dependencies
        deps = await manager.check_dependencies_met("DEP-001")
        assert deps["met"] is False
        assert "BLOCK-001" in deps["blocking"]

        # Complete blocking task
        await manager.update_task_status("BLOCK-001", "completed")

        # Now dependencies should be met
        deps = await manager.check_dependencies_met("DEP-001")
        assert deps["met"] is True

    @pytest.mark.asyncio
    async def test_cannot_start_blocked_task(self) -> None:
        """Test that starting a blocked task raises an error."""
        manager = MockWedoManager()

        blocking = MockTask(
            task_id="BLOCK-001", description="Blocker", status="pending"
        )
        dependent = MockTask(
            task_id="DEP-001", description="Dependent", blocked_by=["BLOCK-001"]
        )
        manager.add_task(blocking)
        manager.add_task(dependent)

        with pytest.raises(ValueError, match="unmet dependencies"):
            await manager.update_task_status("DEP-001", "in_progress")

    @pytest.mark.asyncio
    async def test_templates(self) -> None:
        """Test template creation and instantiation."""
        manager = MockWedoManager()

        # Create template
        template = await manager.create_template(
            name="Daily Tasks",
            description="Daily task template",
            default_tasks=[
                {"description": "Check emails"},
                {"description": "Review PRs"},
            ],
        )

        # Instantiate template
        tasks = await manager.instantiate_template(template["id"], "DAY-01")

        assert len(tasks) == 2
        assert tasks[0].task_id == "DAY-01-01"

    @pytest.mark.asyncio
    async def test_milestone_progress(self) -> None:
        """Test milestone progress calculation."""
        manager = MockWedoManager()

        # Create milestone and subtasks
        milestone = MockTask(task_id="MS-001", description="Milestone")
        manager.add_task(milestone)

        sub1 = MockTask(
            task_id="SUB-001",
            description="Sub 1",
            parent_task_id="MS-001",
            status="completed",
        )
        sub2 = MockTask(
            task_id="SUB-002",
            description="Sub 2",
            parent_task_id="MS-001",
            status="pending",
        )
        manager.add_task(sub1)
        manager.add_task(sub2)

        progress = await manager.get_milestone_progress("MS-001")
        assert progress["total"] == 2
        assert progress["completed"] == 1
        assert progress["percentage"] == 50.0


# =============================================================================
# MockEnvManager Tests
# =============================================================================


class TestMockEnvManager:
    """Tests for MockEnvManager."""

    def test_set_and_get_env_vars(self) -> None:
        """Test setting and getting environment variables."""
        env_manager = MockEnvManager()
        env_manager.set_env_vars({"API_KEY": "secret123", "DEBUG": "true"})

        env = env_manager.read_env_file(Path("/project/.env"))
        assert env["API_KEY"] == "secret123"
        assert env["DEBUG"] == "true"

    def test_show_environment_masked(self) -> None:
        """Test that secrets are masked by default."""
        env_manager = MockEnvManager()
        env_manager.set_env_vars({"API_KEY": "secret123", "DEBUG": "true"})

        env = env_manager.show_environment(Path("/project"))
        assert env["API_KEY"] == "****"  # Masked
        assert env["DEBUG"] == "true"  # Not masked

    def test_show_environment_revealed(self) -> None:
        """Test showing secrets when mask_secrets=False."""
        env_manager = MockEnvManager()
        env_manager.set_env_vars({"API_KEY": "secret123"})

        env = env_manager.show_environment(Path("/project"), mask_secrets=False)
        assert env["API_KEY"] == "secret123"

    def test_build_inherited_env(self) -> None:
        """Test building inherited environment."""
        env_manager = MockEnvManager()
        env_manager.set_env_vars({"PROJECT_VAR": "value"})

        env = env_manager.build_inherited_env()
        assert "ANTHROPIC_API_KEY" in env  # Default
        assert "PROJECT_VAR" in env  # Project env


# =============================================================================
# MockConfig Tests
# =============================================================================


class TestMockConfig:
    """Tests for MockConfig."""

    def test_home_property(self) -> None:
        """Test home directory property."""
        config = MockConfig(home=Path("/custom/home"))
        assert config.home == Path("/custom/home")

    def test_set_and_get_values(self) -> None:
        """Test setting and getting config values."""
        config = MockConfig()
        config.set_values({"api_url": "https://api.test.com", "timeout": 30})

        data = config.to_dict()
        assert data["api_url"] == "https://api.test.com"
        assert data["timeout"] == 30

    def test_save_tracking(self) -> None:
        """Test that save is tracked."""
        config = MockConfig()
        config.save()

        assert config.was_called("save")

    def test_project_context(self) -> None:
        """Test project context methods."""
        config = MockConfig()

        config.ensure_project_context()
        assert config._project_context_detected is True
        assert config.was_called("ensure_project_context")


# =============================================================================
# MockPlugin Tests
# =============================================================================


class TestMockPlugin:
    """Tests for MockPlugin."""

    @pytest.mark.asyncio
    async def test_lifecycle(self) -> None:
        """Test plugin lifecycle."""
        plugin = MockPlugin()

        assert not plugin.is_initialized
        assert not plugin.is_shutdown

        await plugin.initialize({}, {})
        assert plugin.is_initialized
        assert plugin.was_called("initialize")

        await plugin.shutdown()
        assert plugin.is_shutdown
        assert plugin.was_called("shutdown")

    def test_metadata(self) -> None:
        """Test plugin metadata."""
        plugin = MockPlugin(
            name="custom-plugin", display_name="Custom Plugin", version="2.0.0"
        )
        metadata = plugin.get_metadata()

        assert metadata.name == "custom-plugin"
        assert metadata.display_name == "Custom Plugin"
        assert metadata.version == "2.0.0"

    @pytest.mark.asyncio
    async def test_tool_call(self) -> None:
        """Test handling tool calls."""
        plugin = MockPlugin()
        result = await plugin.handle_tool_call("test_tool", {"arg": "value"})

        assert result["tool"] == "test_tool"
        assert result["arguments"] == {"arg": "value"}
        assert plugin.was_called("handle_tool_call")


# =============================================================================
# Factory Function Tests
# =============================================================================


class TestFactoryFunctions:
    """Tests for factory functions."""

    def test_create_mock_services(self) -> None:
        """Test creating all mock services."""
        services = create_mock_services()

        assert "flukebase_client" in services
        assert "memory" in services
        assert "wedo" in services
        assert "env_manager" in services
        assert "config" in services

        assert isinstance(services["flukebase_client"], MockFlukeBaseClient)
        assert isinstance(services["memory"], MockMemoryStore)
        assert isinstance(services["wedo"], MockWedoManager)

    def test_create_mock_services_selective(self) -> None:
        """Test creating selective mock services."""
        services = create_mock_services(
            include_client=True,
            include_memory=True,
            include_wedo=False,
            include_env=False,
            include_config=False,
        )

        assert "flukebase_client" in services
        assert "memory" in services
        assert "wedo" not in services
        assert "env_manager" not in services
        assert "config" not in services

    def test_create_mock_services_with_data(self) -> None:
        """Test creating mock services with pre-populated data."""
        project = MockProject(id=1, name="test")
        memory = MockMemory(id="m1", content="test content", type="fact")
        task = MockTask(task_id="T-001", description="Test task")

        services = create_mock_services_with_data(
            project=project,
            memories=[memory],
            tasks=[task],
            env_vars={"KEY": "value"},
        )

        # Verify project was added
        assert len(services["flukebase_client"]._projects) == 1

        # Verify memory was added
        assert len(services["memory"]._memories["global"]) == 1

        # Verify task was added
        assert len(services["wedo"]._tasks) == 1

        # Verify env vars were set
        assert services["env_manager"]._env_vars["KEY"] == "value"


# =============================================================================
# Integration Tests
# =============================================================================


class TestIntegration:
    """Integration tests for mock services with plugins."""

    @pytest.mark.asyncio
    async def test_plugin_with_mock_services(self) -> None:
        """Test using mock services with a plugin."""
        services = create_mock_services()
        plugin = MockPlugin()

        # Initialize plugin
        await plugin.initialize({"setting": "value"}, services)

        # Plugin should be able to access services
        client = plugin.get_service("flukebase_client")
        assert client is not None
        assert isinstance(client, MockFlukeBaseClient)

        # Plugin should be able to use services
        memory = plugin.get_service("memory")
        await memory.remember("Test from plugin", type="fact")
        assert memory.was_called("remember")

    @pytest.mark.asyncio
    async def test_mock_service_verification(self) -> None:
        """Test verifying mock service interactions."""
        services = create_mock_services()
        client = services["flukebase_client"]

        # Setup mock data
        client.add_project(MockProject(id=1, name="test"))

        # Perform operations
        await client.get_project(1)
        await client.list_projects()
        await client.get_status()

        # Verify calls
        assert client.call_count("get_project") == 1
        assert client.call_count("list_projects") == 1
        assert client.call_count("get_status") == 1

        # Verify specific call arguments
        get_project_call = client.last_call("get_project")
        assert get_project_call.kwargs["project_id"] == 1

    @pytest.mark.asyncio
    async def test_mock_error_simulation(self) -> None:
        """Test simulating errors with mocks."""
        client = MockFlukeBaseClient()
        client.set_side_effect("get_project", ValueError("Project not found"))

        with pytest.raises(ValueError, match="Project not found"):
            await client.get_project(999)
