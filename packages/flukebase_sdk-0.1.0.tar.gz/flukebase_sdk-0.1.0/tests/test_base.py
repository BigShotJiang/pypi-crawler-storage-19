"""Basic tests for the FlukeBase SDK."""

import pytest

from flukebase_sdk import (
    PluginMaturity,
    PluginMetadata,
    PluginType,
    ResourceDefinition,
    ToolAnnotations,
    ToolDefinition,
)
from flukebase_sdk.testing import MockPlugin


class TestPluginMetadata:
    """Tests for PluginMetadata."""

    def test_metadata_creation(self) -> None:
        """Test basic metadata creation."""
        metadata = PluginMetadata(
            name="test-plugin",
            display_name="Test Plugin",
            version="1.0.0",
            description="A test plugin",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
        )
        assert metadata.name == "test-plugin"
        assert metadata.display_name == "Test Plugin"
        assert metadata.version == "1.0.0"
        assert metadata.description == "A test plugin"

    def test_metadata_defaults(self) -> None:
        """Test metadata default values."""
        metadata = PluginMetadata(
            name="test-plugin",
            display_name="Test Plugin",
            version="1.0.0",
            description="A test plugin",
            plugin_type=PluginType.TOOL,
            maturity=PluginMaturity.MVP,
        )
        assert metadata.author == ""
        assert metadata.homepage == ""
        assert metadata.dependencies == []
        assert metadata.required_scopes == []
        assert metadata.features == {}

    def test_metadata_to_dict(self) -> None:
        """Test metadata dictionary conversion."""
        metadata = PluginMetadata(
            name="test-plugin",
            display_name="Test Plugin",
            version="1.0.0",
            description="A test plugin",
            plugin_type=PluginType.INTEGRATION,
            maturity=PluginMaturity.BETA,
        )
        data = metadata.to_dict()
        assert data["name"] == "test-plugin"
        assert data["display_name"] == "Test Plugin"
        assert data["plugin_type"] == "integration"
        assert data["maturity"] == "beta"


class TestToolAnnotations:
    """Tests for ToolAnnotations."""

    def test_annotations_defaults(self) -> None:
        """Test default annotation values."""
        annotations = ToolAnnotations()
        assert annotations.read_only is False
        assert annotations.destructive is False
        assert annotations.idempotent is False
        assert annotations.open_world is True

    def test_annotations_to_mcp_format(self) -> None:
        """Test MCP format conversion."""
        annotations = ToolAnnotations(
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=False,
        )
        mcp = annotations.to_mcp_format()
        assert mcp["readOnlyHint"] is True
        assert mcp["destructiveHint"] is False
        assert mcp["idempotentHint"] is True
        assert mcp["openWorldHint"] is False

    def test_infer_from_read_only_tool(self) -> None:
        """Test inference for read-only tools."""
        annotations = ToolAnnotations.infer_from_tool_name("list_users")
        assert annotations.read_only is True
        assert annotations.destructive is False
        assert annotations.idempotent is True  # read-only implies idempotent

    def test_infer_from_destructive_tool(self) -> None:
        """Test inference for destructive tools."""
        annotations = ToolAnnotations.infer_from_tool_name("delete_user")
        assert annotations.read_only is False
        assert annotations.destructive is True

    def test_infer_from_open_world_tool(self) -> None:
        """Test inference for open-world tools."""
        annotations = ToolAnnotations.infer_from_tool_name("fb_sync")
        assert annotations.open_world is True
        assert annotations.idempotent is True


class TestToolDefinition:
    """Tests for ToolDefinition."""

    def test_tool_creation(self) -> None:
        """Test basic tool creation."""
        tool = ToolDefinition(
            name="my_tool",
            description="Does something useful",
            input_schema={"type": "object", "properties": {}},
            handler_method="handle_my_tool",
        )
        assert tool.name == "my_tool"
        assert tool.description == "Does something useful"
        assert tool.handler_method == "handle_my_tool"

    def test_tool_auto_annotations(self) -> None:
        """Test automatic annotation inference."""
        tool = ToolDefinition(
            name="get_data",
            description="Gets data",
            input_schema={"type": "object", "properties": {}},
            handler_method="handle_get_data",
        )
        assert tool.annotations is not None
        assert tool.annotations.read_only is True

    def test_tool_with_explicit_annotations(self) -> None:
        """Test tool with explicit annotations."""
        tool = ToolDefinition(
            name="custom_tool",
            description="Custom tool",
            input_schema={"type": "object", "properties": {}},
            handler_method="handle_custom",
            annotations=ToolAnnotations(
                read_only=True,
                destructive=False,
                idempotent=True,
                open_world=False,
            ),
        )
        assert tool.annotations.read_only is True
        assert tool.annotations.open_world is False

    def test_tool_to_mcp_format(self) -> None:
        """Test MCP format conversion."""
        tool = ToolDefinition(
            name="my_tool",
            description="Does something",
            input_schema={"type": "object", "properties": {"arg": {"type": "string"}}},
            handler_method="handle_my_tool",
        )
        mcp = tool.to_mcp_format()
        assert mcp["name"] == "my_tool"
        assert mcp["description"] == "Does something"
        assert "inputSchema" in mcp
        assert "annotations" in mcp


class TestResourceDefinition:
    """Tests for ResourceDefinition."""

    def test_resource_creation(self) -> None:
        """Test basic resource creation."""
        resource = ResourceDefinition(
            uri="file:///data/config.json",
            name="Configuration",
            description="Application configuration",
            mime_type="application/json",
        )
        assert resource.uri == "file:///data/config.json"
        assert resource.mime_type == "application/json"

    def test_resource_default_mime_type(self) -> None:
        """Test default MIME type."""
        resource = ResourceDefinition(
            uri="wedo://tasks/global",
            name="Tasks",
            description="Global tasks",
        )
        assert resource.mime_type == "application/json"

    def test_resource_to_mcp_format(self) -> None:
        """Test MCP format conversion."""
        resource = ResourceDefinition(
            uri="memory://global/facts",
            name="Memory Facts",
            description="Global memory facts",
        )
        mcp = resource.to_mcp_format()
        assert mcp["uri"] == "memory://global/facts"
        assert mcp["name"] == "Memory Facts"
        assert mcp["mimeType"] == "application/json"


class TestMockPlugin:
    """Tests for MockPlugin."""

    @pytest.mark.asyncio
    async def test_mock_plugin_lifecycle(self) -> None:
        """Test mock plugin initialization and shutdown."""
        plugin = MockPlugin()
        assert not plugin.is_initialized
        assert not plugin.is_shutdown

        await plugin.initialize({}, {})
        assert plugin.is_initialized

        await plugin.shutdown()
        assert plugin.is_shutdown

    def test_mock_plugin_metadata(self) -> None:
        """Test mock plugin metadata."""
        plugin = MockPlugin(
            name="custom-mock", display_name="Custom Mock", version="2.0.0"
        )
        metadata = plugin.get_metadata()
        assert metadata.name == "custom-mock"
        assert metadata.display_name == "Custom Mock"
        assert metadata.version == "2.0.0"

    @pytest.mark.asyncio
    async def test_mock_plugin_tool_call(self) -> None:
        """Test mock plugin tool call handling."""
        plugin = MockPlugin()
        result = await plugin.handle_tool_call("test_tool", {"arg": "value"})
        assert result["tool"] == "test_tool"
        assert result["arguments"] == {"arg": "value"}


class TestBasePlugin:
    """Tests for BasePlugin functionality."""

    def test_validate_scope_exact_match(self) -> None:
        """Test scope validation with exact match."""
        plugin = MockPlugin()
        assert plugin.validate_scope("read", ["read", "write"]) is True
        assert plugin.validate_scope("admin", ["read", "write"]) is False

    def test_validate_scope_wildcard(self) -> None:
        """Test scope validation with wildcard."""
        plugin = MockPlugin()
        assert plugin.validate_scope("anything", ["*"]) is True

    @pytest.mark.asyncio
    async def test_get_service(self) -> None:
        """Test service retrieval."""
        plugin = MockPlugin()
        services = {"memory": "memory_service", "env": "env_service"}
        await plugin.initialize({}, services)

        assert plugin.get_service("memory") == "memory_service"
        assert plugin.get_service("nonexistent") is None

    @pytest.mark.asyncio
    async def test_get_config_value(self) -> None:
        """Test configuration value retrieval."""
        plugin = MockPlugin()
        config = {"api_key": "secret123", "timeout": 30}
        await plugin.initialize(config, {})

        assert plugin.get_config_value("api_key") == "secret123"
        assert plugin.get_config_value("timeout") == 30
        assert plugin.get_config_value("missing", "default") == "default"
