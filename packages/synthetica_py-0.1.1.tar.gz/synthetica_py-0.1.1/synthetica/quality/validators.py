"""Validators - Sample validation logic."""

from abc import ABC, abstractmethod
from typing import Optional, List, Set
import hashlib

from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec
from synthetica.core.schema import SchemaEngine


class BaseValidator(ABC):
    """Abstract base for validators."""
    
    name: str = "base"
    
    @abstractmethod
    def validate(self, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """
        Validate a sample.
        
        Args:
            sample: Sample to validate
            spec: Task specification
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        pass


class SchemaValidator(BaseValidator):
    """Validates samples against their schema."""
    
    name = "schema"
    
    def __init__(self):
        self.engine = SchemaEngine()
    
    def validate(self, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Check sample conforms to schema."""
        return self.engine.validate(sample.content, spec.task_type)


class ContentValidator(BaseValidator):
    """Validates sample content quality."""
    
    name = "content"
    
    # Patterns that indicate low-quality content
    BAD_PATTERNS = [
        "[insert",
        "[your",
        "TODO",
        "PLACEHOLDER",
        "example.com",
        "lorem ipsum",
        "asdf",
        "xxx",
        "test123",
    ]
    
    def validate(self, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Check content quality."""
        content_str = str(sample.content).lower()
        
        # Check for placeholder patterns
        for pattern in self.BAD_PATTERNS:
            if pattern.lower() in content_str:
                return False, f"Contains placeholder/test pattern: {pattern}"
        
        # Check minimum content length
        if len(content_str) < 20:
            return False, "Content too short"
        
        # Check for excessive repetition
        words = content_str.split()
        if len(words) > 10:
            unique_ratio = len(set(words)) / len(words)
            if unique_ratio < 0.3:
                return False, "Excessive word repetition detected"
        
        return True, None


class DuplicateValidator(BaseValidator):
    """Validates samples are not duplicates."""
    
    name = "duplicate"
    
    def __init__(self):
        self._seen_hashes: Set[str] = set()
    
    def validate(self, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Check for exact duplicates via hash."""
        content_hash = sample.metadata.content_hash
        
        if content_hash in self._seen_hashes:
            return False, "Duplicate sample detected"
        
        self._seen_hashes.add(content_hash)
        return True, None
    
    def reset(self):
        """Clear seen hashes."""
        self._seen_hashes.clear()


class ValidationPipeline:
    """
    Chain multiple validators together.
    
    Runs validators in sequence, stopping on first failure.
    """
    
    def __init__(self, validators: List[BaseValidator] = None):
        self.validators = validators or [
            SchemaValidator(),
            ContentValidator(),
            DuplicateValidator(),
        ]
    
    def validate(self, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Run all validators on sample."""
        for validator in self.validators:
            valid, error = validator.validate(sample, spec)
            if not valid:
                return False, f"[{validator.name}] {error}"
        
        return True, None
    
    def add_validator(self, validator: BaseValidator):
        """Add a validator to the pipeline."""
        self.validators.append(validator)
    
    def reset(self):
        """Reset stateful validators."""
        for validator in self.validators:
            if hasattr(validator, 'reset'):
                validator.reset()
