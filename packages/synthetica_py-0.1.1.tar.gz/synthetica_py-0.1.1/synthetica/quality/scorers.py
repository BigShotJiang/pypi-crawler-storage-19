"""Scorers - Sample quality scoring."""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class BaseScorer(ABC):
    """Abstract base for scorers."""
    
    name: str = "base"
    weight: float = 1.0
    
    @abstractmethod
    def score(self, sample: Sample, spec: TaskSpec) -> float:
        """
        Score a sample.
        
        Args:
            sample: Sample to score
            spec: Task specification
            
        Returns:
            Score between 0.0 and 1.0
        """
        pass


class QualityScorer(BaseScorer):
    """
    Overall quality scorer.
    
    Aggregates multiple quality signals.
    """
    
    name = "quality"
    weight = 1.0
    
    def score(self, sample: Sample, spec: TaskSpec) -> float:
        """Calculate overall quality score."""
        scores = []
        
        # Use critique scores if available
        for critique in sample.metadata.critique_results:
            scores.append(critique.overall_score)
        
        if scores:
            return sum(scores) / len(scores)
        
        # Fallback: basic heuristic scoring
        return self._heuristic_score(sample, spec)
    
    def _heuristic_score(self, sample: Sample, spec: TaskSpec) -> float:
        """Basic heuristic scoring when no critique available."""
        score = 0.7  # Base score
        
        content = sample.content
        content_str = str(content)
        
        # Length bonus/penalty
        length = len(content_str)
        if length > 100:
            score += 0.05
        if length > 500:
            score += 0.05
        if length < 50:
            score -= 0.1
        
        # Completeness check
        if isinstance(content, dict):
            # More complete content is better
            non_empty_fields = sum(1 for v in content.values() if v)
            if non_empty_fields >= 3:
                score += 0.05
        
        return min(1.0, max(0.0, score))


class DifficultyScorer(BaseScorer):
    """
    Score how well difficulty matches target.
    """
    
    name = "difficulty"
    weight = 0.5
    
    def score(self, sample: Sample, spec: TaskSpec) -> float:
        """Score difficulty alignment."""
        target_difficulty = sample.metadata.difficulty
        content_str = str(sample.content).lower()
        
        # Heuristic difficulty estimation
        estimated_difficulty = self._estimate_difficulty(content_str)
        
        # Compare to target
        difficulty_order = ["easy", "medium", "hard", "adversarial"]
        target_idx = difficulty_order.index(target_difficulty) if target_difficulty in difficulty_order else 1
        estimated_idx = difficulty_order.index(estimated_difficulty)
        
        # Score based on distance
        distance = abs(target_idx - estimated_idx)
        if distance == 0:
            return 1.0
        elif distance == 1:
            return 0.7
        else:
            return 0.4
    
    def _estimate_difficulty(self, content: str) -> str:
        """Estimate difficulty from content."""
        # Simple heuristics
        word_count = len(content.split())
        
        # Technical terms increase difficulty
        technical_terms = ["algorithm", "complexity", "optimization", "edge case", 
                         "exception", "recursive", "async", "concurrent"]
        tech_count = sum(1 for term in technical_terms if term in content)
        
        if tech_count >= 3 or word_count > 300:
            return "hard"
        elif tech_count >= 1 or word_count > 150:
            return "medium"
        else:
            return "easy"


class CoherenceScorer(BaseScorer):
    """
    Score internal coherence of content.
    """
    
    name = "coherence"
    weight = 0.7
    
    def score(self, sample: Sample, spec: TaskSpec) -> float:
        """Score content coherence."""
        content = sample.content
        
        if not isinstance(content, dict):
            return 0.5
        
        score = 0.8  # Base score
        
        # Check for consistent content
        instruction = content.get("instruction", "") or content.get("question", "") or content.get("prompt", "")
        output = content.get("output", "") or content.get("answer", "") or content.get("response", "")
        
        if instruction and output:
            # Basic coherence: output should relate to instruction
            instruction_words = set(instruction.lower().split())
            output_words = set(output.lower().split())
            
            # Some word overlap is expected
            overlap = len(instruction_words & output_words)
            if overlap > 0:
                score += 0.1
            
            # But not too much (copy-paste detection)
            if len(instruction_words) > 5:
                overlap_ratio = overlap / len(instruction_words)
                if overlap_ratio > 0.8:
                    score -= 0.2  # Too similar
        
        return min(1.0, max(0.0, score))


class ScorerPipeline:
    """
    Combine multiple scorers with weights.
    """
    
    def __init__(self, scorers: List[BaseScorer] = None):
        self.scorers = scorers or [
            QualityScorer(),
            DifficultyScorer(),
            CoherenceScorer(),
        ]
    
    def score(self, sample: Sample, spec: TaskSpec) -> float:
        """Calculate weighted average score."""
        total_weight = sum(s.weight for s in self.scorers)
        weighted_sum = sum(
            s.score(sample, spec) * s.weight 
            for s in self.scorers
        )
        
        return weighted_sum / total_weight if total_weight > 0 else 0.0
    
    def score_detailed(self, sample: Sample, spec: TaskSpec) -> Dict[str, float]:
        """Get individual scores from each scorer."""
        return {
            scorer.name: scorer.score(sample, spec)
            for scorer in self.scorers
        }
    
    def add_scorer(self, scorer: BaseScorer):
        """Add a scorer to the pipeline."""
        self.scorers.append(scorer)
