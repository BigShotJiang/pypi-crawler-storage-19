"""Filters - Sample filtering and selection."""

from abc import ABC, abstractmethod
from typing import List, Set
import hashlib

from synthetica.core.sample import Sample, SampleBatch
from synthetica.core.task_spec import TaskSpec


class BaseFilter(ABC):
    """Abstract base for filters."""
    
    name: str = "base"
    
    @abstractmethod
    def filter(self, batch: SampleBatch, spec: TaskSpec) -> SampleBatch:
        """
        Filter a batch of samples.
        
        Args:
            batch: Input batch
            spec: Task specification
            
        Returns:
            Filtered batch
        """
        pass


class QualityFilter(BaseFilter):
    """Filter samples by quality score."""
    
    name = "quality"
    
    def __init__(self, min_score: float = 0.7):
        self.min_score = min_score
    
    def filter(self, batch: SampleBatch, spec: TaskSpec) -> SampleBatch:
        """Keep only high-quality samples."""
        filtered = [
            sample for sample in batch.samples
            if sample.quality_score >= self.min_score
        ]
        return SampleBatch(samples=filtered)


class DuplicateFilter(BaseFilter):
    """
    Filter duplicate samples.
    
    Uses both exact hash matching and optional semantic similarity.
    """
    
    name = "duplicate"
    
    def __init__(self, use_semantic: bool = False, threshold: float = 0.85):
        self.use_semantic = use_semantic
        self.threshold = threshold
        self._seen_hashes: Set[str] = set()
    
    def filter(self, batch: SampleBatch, spec: TaskSpec) -> SampleBatch:
        """Remove duplicate samples."""
        unique = []
        
        for sample in batch.samples:
            content_hash = sample.metadata.content_hash
            
            # Exact duplicate check
            if content_hash in self._seen_hashes:
                sample.reject("Exact duplicate")
                continue
            
            # Semantic similarity check (if enabled)
            if self.use_semantic and sample.metadata.embedding_vector:
                is_similar = self._check_semantic_duplicate(sample, unique)
                if is_similar:
                    sample.reject("Semantic duplicate")
                    continue
            
            self._seen_hashes.add(content_hash)
            unique.append(sample)
        
        return SampleBatch(samples=unique)
    
    def _check_semantic_duplicate(self, sample: Sample, existing: List[Sample]) -> bool:
        """Check if sample is semantically similar to existing samples."""
        if not sample.metadata.embedding_vector:
            return False
        
        for existing_sample in existing:
            if existing_sample.metadata.embedding_vector:
                similarity = self._cosine_similarity(
                    sample.metadata.embedding_vector,
                    existing_sample.metadata.embedding_vector
                )
                if similarity > self.threshold:
                    return True
        
        return False
    
    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Calculate cosine similarity."""
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x ** 2 for x in a) ** 0.5
        norm_b = sum(x ** 2 for x in b) ** 0.5
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot / (norm_a * norm_b)
    
    def reset(self):
        """Clear state."""
        self._seen_hashes.clear()


class DifficultyFilter(BaseFilter):
    """
    Filter to maintain difficulty distribution.
    """
    
    name = "difficulty"
    
    def __init__(self, target_distribution: dict = None):
        self.target = target_distribution or {
            "easy": 0.3,
            "medium": 0.4,
            "hard": 0.2,
            "adversarial": 0.1,
        }
    
    def filter(self, batch: SampleBatch, spec: TaskSpec) -> SampleBatch:
        """
        Filter to match target difficulty distribution.
        
        Keeps samples that help achieve the target distribution.
        """
        # Count current distribution
        counts = {"easy": 0, "medium": 0, "hard": 0, "adversarial": 0}
        for sample in batch.samples:
            diff = sample.metadata.difficulty
            if diff in counts:
                counts[diff] += 1
        
        total = sum(counts.values())
        if total == 0:
            return batch
        
        # Calculate target counts
        target_counts = {
            diff: int(total * ratio)
            for diff, ratio in self.target.items()
        }
        
        # Keep samples that help achieve target
        filtered = []
        current_counts = {"easy": 0, "medium": 0, "hard": 0, "adversarial": 0}
        
        for sample in batch.samples:
            diff = sample.metadata.difficulty
            if diff in current_counts:
                if current_counts[diff] < target_counts.get(diff, 0):
                    filtered.append(sample)
                    current_counts[diff] += 1
                else:
                    sample.reject("Difficulty quota exceeded")
        
        return SampleBatch(samples=filtered)


class FilterPipeline:
    """
    Chain multiple filters together.
    """
    
    def __init__(self, filters: List[BaseFilter] = None):
        self.filters = filters or [
            QualityFilter(),
            DuplicateFilter(),
        ]
    
    def filter(self, batch: SampleBatch, spec: TaskSpec) -> SampleBatch:
        """Run all filters on batch."""
        result = batch
        for f in self.filters:
            result = f.filter(result, spec)
        return result
    
    def add_filter(self, filter_obj: BaseFilter):
        """Add a filter to the pipeline."""
        self.filters.append(filter_obj)
    
    def reset(self):
        """Reset stateful filters."""
        for f in self.filters:
            if hasattr(f, 'reset'):
                f.reset()
