"""Base Exporter - Abstract interface for export handlers."""

from abc import ABC, abstractmethod
from typing import Union
from pathlib import Path

from synthetica.core.sample import SampleBatch


class BaseExporter(ABC):
    """
    Abstract base class for export handlers.
    
    Subclasses implement export to specific formats.
    """
    
    format_name: str = "base"
    file_extension: str = ""
    
    @abstractmethod
    def export(
        self,
        batch: SampleBatch,
        path: Union[str, Path],
        **kwargs
    ) -> None:
        """
        Export samples to file.
        
        Args:
            batch: Samples to export
            path: Output file path
            **kwargs: Format-specific options
        """
        pass
    
    def validate_path(self, path: Union[str, Path]) -> Path:
        """Validate and prepare output path."""
        path = Path(path)
        
        # Create parent directory if needed
        path.parent.mkdir(parents=True, exist_ok=True)
        
        return path
