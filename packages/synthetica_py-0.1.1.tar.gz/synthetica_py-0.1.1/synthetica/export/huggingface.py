"""HuggingFace Exporter - Export to HuggingFace Datasets format."""

from typing import Union, Optional
from pathlib import Path

from synthetica.export.base import BaseExporter
from synthetica.core.sample import SampleBatch


class HuggingFaceExporter(BaseExporter):
    """
    Export samples to HuggingFace Datasets format.
    
    Supports:
        - Local Arrow format save
        - Push to HuggingFace Hub
    """
    
    format_name = "huggingface"
    file_extension = ""
    
    def export(
        self,
        batch: SampleBatch,
        path: Union[str, Path],
        **kwargs
    ) -> None:
        """
        Export samples to HuggingFace Dataset format.
        
        Args:
            batch: Samples to export
            path: Directory to save dataset
        """
        try:
            from datasets import Dataset
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required: pip install datasets"
            )
        
        path = self.validate_path(path)
        
        # Convert samples to list of dicts
        data = [sample.to_training_format() for sample in batch.accepted]
        
        # Create dataset
        dataset = Dataset.from_list(data)
        
        # Save to disk
        dataset.save_to_disk(str(path))
    
    def push_to_hub(
        self,
        batch: SampleBatch,
        repo_id: str,
        private: bool = False,
        token: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        Push dataset to HuggingFace Hub.
        
        Args:
            batch: Samples to push
            repo_id: Repository ID (e.g., "username/dataset-name")
            private: Whether to make the dataset private
            token: HuggingFace API token (optional, uses cached token if None)
            
        Returns:
            URL of the pushed dataset
        """
        try:
            from datasets import Dataset
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required: pip install datasets"
            )
        
        # Convert samples to list of dicts
        data = [sample.to_training_format() for sample in batch.accepted]
        
        # Create dataset
        dataset = Dataset.from_list(data)
        
        # Push to hub
        dataset.push_to_hub(
            repo_id,
            private=private,
            token=token,
        )
        
        return f"https://huggingface.co/datasets/{repo_id}"
    
    def export_with_config(
        self,
        batch: SampleBatch,
        path: Union[str, Path],
        config_name: str = "default",
        description: str = "",
        **kwargs
    ) -> None:
        """
        Export with dataset configuration.
        
        Args:
            batch: Samples to export
            path: Directory to save dataset
            config_name: Configuration name
            description: Dataset description
        """
        try:
            from datasets import Dataset, DatasetInfo
        except ImportError:
            raise ImportError(
                "HuggingFace datasets required: pip install datasets"
            )
        
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        
        # Convert samples
        data = [sample.to_training_format() for sample in batch.accepted]
        
        # Create dataset with info
        dataset = Dataset.from_list(data)
        
        # Add metadata if possible
        if description:
            dataset.info.description = description
        
        # Save
        dataset.save_to_disk(str(path))
