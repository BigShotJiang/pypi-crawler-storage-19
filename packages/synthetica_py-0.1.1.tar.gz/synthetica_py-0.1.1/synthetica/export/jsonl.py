"""JSONL Exporter - Export to JSON Lines format."""

from typing import Union
from pathlib import Path
import json

from synthetica.export.base import BaseExporter
from synthetica.core.sample import SampleBatch


class JSONLExporter(BaseExporter):
    """
    Export samples to JSONL format.
    
    Each line is a valid JSON object.
    Standard format for LLM training datasets.
    """
    
    format_name = "jsonl"
    file_extension = ".jsonl"
    
    def export(
        self,
        batch: SampleBatch,
        path: Union[str, Path],
        include_metadata: bool = False,
        pretty: bool = False,
        **kwargs
    ) -> None:
        """
        Export samples to JSONL file.
        
        Args:
            batch: Samples to export
            path: Output file path
            include_metadata: Include quality metadata
            pretty: Pretty print JSON (one object per line, but formatted)
        """
        path = self.validate_path(path)
        
        with open(path, 'w', encoding='utf-8') as f:
            for sample in batch.accepted:
                if include_metadata:
                    data = sample.to_dict()
                else:
                    data = sample.to_training_format()
                
                if pretty:
                    # Still one line, but with sorted keys
                    line = json.dumps(data, ensure_ascii=False, sort_keys=True)
                else:
                    line = json.dumps(data, ensure_ascii=False)
                
                f.write(line + '\n')
    
    def export_with_splits(
        self,
        batch: SampleBatch,
        base_path: Union[str, Path],
        train_ratio: float = 0.8,
        val_ratio: float = 0.1,
        test_ratio: float = 0.1,
        **kwargs
    ) -> dict:
        """
        Export with train/val/test splits.
        
        Args:
            batch: Samples to export
            base_path: Base path for split files
            train_ratio: Training set ratio
            val_ratio: Validation set ratio
            test_ratio: Test set ratio
            
        Returns:
            Dict with file paths and counts
        """
        import random
        
        base_path = Path(base_path)
        samples = list(batch.accepted)
        random.shuffle(samples)
        
        total = len(samples)
        train_end = int(total * train_ratio)
        val_end = train_end + int(total * val_ratio)
        
        splits = {
            "train": samples[:train_end],
            "val": samples[train_end:val_end],
            "test": samples[val_end:],
        }
        
        result = {}
        for split_name, split_samples in splits.items():
            split_path = base_path.parent / f"{base_path.stem}_{split_name}.jsonl"
            split_batch = SampleBatch(samples=split_samples)
            self.export(split_batch, split_path, **kwargs)
            result[split_name] = {
                "path": str(split_path),
                "count": len(split_samples),
            }
        
        return result
