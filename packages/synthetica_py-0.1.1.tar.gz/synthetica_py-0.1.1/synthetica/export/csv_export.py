"""CSV Exporter - Export to CSV format."""

from typing import Union, List
from pathlib import Path
import csv
import json

from synthetica.export.base import BaseExporter
from synthetica.core.sample import SampleBatch


class CSVExporter(BaseExporter):
    """
    Export samples to CSV format.
    
    Flattens nested structures and handles complex fields.
    """
    
    format_name = "csv"
    file_extension = ".csv"
    
    def export(
        self,
        batch: SampleBatch,
        path: Union[str, Path],
        columns: List[str] = None,
        include_metadata: bool = False,
        **kwargs
    ) -> None:
        """
        Export samples to CSV file.
        
        Args:
            batch: Samples to export
            path: Output file path
            columns: Specific columns to include (None = all)
            include_metadata: Include quality metadata columns
        """
        path = self.validate_path(path)
        
        # Get all samples as dicts
        if include_metadata:
            rows = [sample.to_dict() for sample in batch.accepted]
        else:
            rows = [sample.to_training_format() for sample in batch.accepted]
        
        if not rows:
            # Empty file
            with open(path, 'w', encoding='utf-8') as f:
                f.write("")
            return
        
        # Flatten nested structures
        flattened_rows = [self._flatten_dict(row) for row in rows]
        
        # Determine columns
        if columns is None:
            # Collect all keys
            all_keys = set()
            for row in flattened_rows:
                all_keys.update(row.keys())
            columns = sorted(all_keys)
        
        # Write CSV
        with open(path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(flattened_rows)
    
    def _flatten_dict(self, d: dict, parent_key: str = '', sep: str = '_') -> dict:
        """Flatten nested dictionary."""
        items = []
        for k, v in d.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            
            if isinstance(v, dict):
                items.extend(self._flatten_dict(v, new_key, sep).items())
            elif isinstance(v, list):
                # Convert list to JSON string
                items.append((new_key, json.dumps(v, ensure_ascii=False)))
            else:
                items.append((new_key, v))
        
        return dict(items)
