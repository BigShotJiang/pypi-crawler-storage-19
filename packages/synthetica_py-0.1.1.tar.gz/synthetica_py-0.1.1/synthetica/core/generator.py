"""
Synthetic Data Generator - Main entry point for the library.

The SyntheticDataGenerator class provides a high-level API for:
    - Configuring generation tasks
    - Running generation pipelines
    - Exporting results
"""

from typing import Optional, Dict, Any, List, Union, Type
from pathlib import Path
import asyncio
import logging

from synthetica.core.task_spec import TaskSpec, TaskType
from synthetica.core.pipeline import GenerationPipeline, PipelineConfig
from synthetica.core.sample import SampleBatch


logger = logging.getLogger(__name__)


class SyntheticDataGenerator:
    """
    High-level interface for synthetic data generation.
    
    Provides a simple API for:
    - Defining generation tasks
    - Configuring model providers
    - Running generation with quality control
    - Exporting results in multiple formats
    
    Example:
        ```python
        from synthetica import SyntheticDataGenerator, TaskSpec, TaskType
        from synthetica import OllamaProvider
        
        generator = SyntheticDataGenerator(
            generator_provider=OllamaProvider(model="gemma:7b"),
            critic_provider=OllamaProvider(model="llama3:8b"),  # Cross-model critique
        )
        
        spec = TaskSpec(
            task_type=TaskType.INSTRUCTION,
            domain="python_coding",
            num_samples=1000,
        )
        
        dataset = generator.generate(spec)
        dataset.export_jsonl("training_data.jsonl")
        ```
    """
    
    def __init__(
        self,
        generator_provider,
        critic_provider=None,
        embedding_provider=None,
        config: Optional[PipelineConfig] = None,
    ):
        """
        Initialize the generator.
        
        Args:
            generator_provider: Model provider for generation (required)
            critic_provider: Model provider for critique (optional, defaults to generator)
            embedding_provider: Provider for embeddings/semantic dedup (optional)
            config: Pipeline configuration (optional)
        """
        self.generator_provider = generator_provider
        self.critic_provider = critic_provider or generator_provider
        self.embedding_provider = embedding_provider
        self.config = config or PipelineConfig()
        
        self._pipeline: Optional[GenerationPipeline] = None
    
    def generate(
        self,
        spec: TaskSpec,
        progress_callback=None,
    ) -> "GeneratedDataset":
        """
        Generate synthetic dataset (synchronous).
        
        Args:
            spec: Task specification
            progress_callback: Optional callback(progress_pct, message)
            
        Returns:
            GeneratedDataset with results
        """
        return asyncio.run(self.generate_async(spec, progress_callback))
    
    async def generate_async(
        self,
        spec: TaskSpec,
        progress_callback=None,
    ) -> "GeneratedDataset":
        """
        Generate synthetic dataset (asynchronous).
        
        Args:
            spec: Task specification
            progress_callback: Optional callback(progress_pct, message)
            
        Returns:
            GeneratedDataset with results
        """
        if progress_callback:
            self.config.on_progress = progress_callback
        
        self._pipeline = GenerationPipeline(
            generator_provider=self.generator_provider,
            critic_provider=self.critic_provider,
            config=self.config,
        )
        
        logger.info(f"Starting generation: {spec.task_type} - {spec.domain}")
        logger.info(f"Target samples: {spec.num_samples}")
        
        batch = await self._pipeline.run(spec)
        
        logger.info(f"Generation complete: {len(batch.accepted)} samples")
        
        return GeneratedDataset(
            samples=batch,
            spec=spec,
            stats=batch.get_stats(),
        )
    
    async def generate_streaming(self, spec: TaskSpec):
        """
        Generate with streaming output.
        
        Yields samples as they are accepted.
        
        Args:
            spec: Task specification
            
        Yields:
            Sample objects as they are generated
        """
        self._pipeline = GenerationPipeline(
            generator_provider=self.generator_provider,
            critic_provider=self.critic_provider,
            config=self.config,
        )
        
        async for sample in self._pipeline.run_streaming(spec):
            yield sample

    def quick_generate(
        self,
        task_type: Union[str, TaskType],
        domain: str,
        num_samples: int = 10,
        **kwargs
    ) -> "GeneratedDataset":
        """
        Quickly generate a dataset with minimal configuration.
        
        Example:
            generator.quick_generate("instruction", "history", num_samples=5)
        """
        spec = TaskSpec(
            task_type=TaskType(task_type) if isinstance(task_type, str) else task_type,
            domain=domain,
            num_samples=num_samples,
            **kwargs
        )
        return self.generate(spec)

    @classmethod
    def with_ollama(cls, model: str = "gemma:7b", base_url: str = None, **kwargs) -> "SyntheticDataGenerator":
        """Create a generator using Ollama provider."""
        from synthetica.providers import OllamaProvider
        return cls(generator_provider=OllamaProvider(model=model, base_url=base_url, **kwargs))

    @classmethod
    def with_lmstudio(cls, model: str = "local-model", base_url: str = None, **kwargs) -> "SyntheticDataGenerator":
        """Create a generator using LM Studio provider."""
        from synthetica.providers import LMStudioProvider
        return cls(generator_provider=LMStudioProvider(model=model, base_url=base_url, **kwargs))

    @classmethod
    def with_gemini(cls, model: str = "gemini-3-flash-preview", api_key: str = None, **kwargs) -> "SyntheticDataGenerator":
        """Create a generator using Google Gemini provider."""
        from synthetica.providers import GeminiProvider
        return cls(generator_provider=GeminiProvider(model=model, api_key=api_key, **kwargs))
    
    def generate_batch(
        self,
        specs: List[TaskSpec],
        parallel: bool = False,
    ) -> List["GeneratedDataset"]:
        """
        Generate multiple datasets.
        
        Args:
            specs: List of task specifications
            parallel: Whether to run in parallel
            
        Returns:
            List of GeneratedDataset objects
        """
        if parallel:
            return asyncio.run(self._generate_batch_parallel(specs))
        else:
            return [self.generate(spec) for spec in specs]
    
    async def _generate_batch_parallel(
        self,
        specs: List[TaskSpec]
    ) -> List["GeneratedDataset"]:
        """Run batch generation in parallel."""
        tasks = [self.generate_async(spec) for spec in specs]
        return await asyncio.gather(*tasks)
    
    @classmethod
    def from_config(cls, config_path: Union[str, Path]) -> "SyntheticDataGenerator":
        """
        Create generator from YAML configuration file.
        
        Args:
            config_path: Path to YAML config file
            
        Returns:
            Configured SyntheticDataGenerator instance
        """
        import yaml
        
        config_path = Path(config_path)
        with open(config_path) as f:
            config = yaml.safe_load(f)
        
        # Parse provider configs
        generator_config = config.get("generator", {})
        critic_config = config.get("critic", generator_config)
        
        generator_provider = cls._create_provider(generator_config)
        critic_provider = cls._create_provider(critic_config)
        
        # Parse pipeline config
        pipeline_config = PipelineConfig(**config.get("pipeline", {}))
        
        return cls(
            generator_provider=generator_provider,
            critic_provider=critic_provider,
            config=pipeline_config,
        )
    
    @staticmethod
    def _create_provider(config: Dict[str, Any]):
        """Create provider from config dict."""
        provider_type = config.get("type", "ollama").lower()
        
        if provider_type == "ollama":
            from synthetica.providers import OllamaProvider
            return OllamaProvider(
                model=config.get("model", "gemma:7b"),
                base_url=config.get("base_url"),
            )
        elif provider_type == "gemini":
            from synthetica.providers import GeminiProvider
            return GeminiProvider(
                model=config.get("model"),
                api_key=config.get("api_key"),
            )
        elif provider_type == "lmstudio":
            from synthetica.providers import LMStudioProvider
            return LMStudioProvider(
                model=config.get("model"),
                base_url=config.get("base_url"),
            )
        else:
            raise ValueError(f"Unknown provider type: {provider_type}")


class GeneratedDataset:
    """
    Container for generated dataset with export capabilities.
    
    Provides:
    - Access to generated samples
    - Statistics and quality metrics
    - Multiple export formats
    """
    
    def __init__(
        self,
        samples: SampleBatch,
        spec: TaskSpec,
        stats: Dict[str, Any],
    ):
        self.samples = samples
        self.spec = spec
        self.stats = stats
    
    def __len__(self) -> int:
        return len(self.samples.accepted)
    
    def __iter__(self):
        return iter(self.samples.accepted)
    
    def __getitem__(self, idx: int):
        return self.samples.accepted[idx]
    
    @property
    def accepted_count(self) -> int:
        """Number of accepted samples."""
        return len(self.samples.accepted)
    
    @property
    def avg_quality_score(self) -> float:
        """Average quality score of accepted samples."""
        return self.stats.get("avg_quality_score", 0.0)
    
    def to_list(self) -> List[Dict[str, Any]]:
        """Export as list of dictionaries."""
        return self.samples.to_list()
    
    def to_training_list(self) -> List[Dict[str, Any]]:
        """Export as list for training (no metadata)."""
        return self.samples.to_training_list()
    
    def export_jsonl(self, path: Union[str, Path], include_metadata: bool = False):
        """
        Export to JSONL format.
        
        Args:
            path: Output file path
            include_metadata: Whether to include quality metadata
        """
        from synthetica.export import JSONLExporter
        exporter = JSONLExporter()
        exporter.export(self.samples, path, include_metadata=include_metadata)
    
    def export_csv(self, path: Union[str, Path]):
        """
        Export to CSV format.
        
        Args:
            path: Output file path
        """
        from synthetica.export import CSVExporter
        exporter = CSVExporter()
        exporter.export(self.samples, path)
    
    def export_huggingface(
        self,
        path: Union[str, Path] = None,
        push_to_hub: bool = False,
        repo_id: str = None,
    ):
        """
        Export to HuggingFace Datasets format.
        
        Args:
            path: Local save path (optional)
            push_to_hub: Whether to push to HuggingFace Hub
            repo_id: Repository ID for Hub upload
        """
        from synthetica.export import HuggingFaceExporter
        exporter = HuggingFaceExporter()
        
        if path:
            exporter.export(self.samples, path)
        
        if push_to_hub and repo_id:
            exporter.push_to_hub(self.samples, repo_id)
    
    def filter(
        self,
        min_quality: float = None,
        difficulty: str = None,
    ) -> "GeneratedDataset":
        """
        Filter samples.
        
        Args:
            min_quality: Minimum quality score
            difficulty: Filter by difficulty level
            
        Returns:
            New GeneratedDataset with filtered samples
        """
        filtered = self.samples
        
        if min_quality is not None:
            filtered = filtered.filter_by_quality(min_quality)
        
        if difficulty is not None:
            filtered = filtered.filter_by_difficulty(difficulty)
        
        return GeneratedDataset(
            samples=filtered,
            spec=self.spec,
            stats=filtered.get_stats(),
        )
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary statistics."""
        return {
            "task_type": self.spec.task_type,
            "domain": self.spec.domain,
            "target_samples": self.spec.num_samples,
            "accepted_samples": self.accepted_count,
            "avg_quality_score": self.avg_quality_score,
            "difficulty_distribution": self.stats.get("difficulty_distribution", {}),
            "acceptance_rate": self.stats.get("acceptance_rate", 0),
        }
    
    def print_summary(self):
        """Print summary to console."""
        summary = self.get_summary()
        print("\n" + "=" * 50)
        print("GENERATION SUMMARY")
        print("=" * 50)
        for key, value in summary.items():
            print(f"  {key}: {value}")
        print("=" * 50 + "\n")
