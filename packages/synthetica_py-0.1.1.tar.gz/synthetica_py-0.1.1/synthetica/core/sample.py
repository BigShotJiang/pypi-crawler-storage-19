"""
Sample - Core data structures for generated samples.

A Sample represents a single generated data point with:
    - Raw content (task-specific)
    - Quality metadata
    - Provenance information
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import hashlib
import json


class SampleStatus(str, Enum):
    """Status of a sample in the pipeline."""
    
    GENERATED = "generated"      # Just created
    CRITIQUED = "critiqued"      # Passed through critique
    VALIDATED = "validated"      # Passed validation
    ACCEPTED = "accepted"        # Final accepted
    REJECTED = "rejected"        # Filtered out


@dataclass
class CritiqueResult:
    """Result of a critique evaluation."""
    
    critic_model: str
    scores: Dict[str, float]  # metric_name -> score
    feedback: str
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    passed: bool = True
    
    @property
    def overall_score(self) -> float:
        """Calculate weighted overall score."""
        if not self.scores:
            return 0.0
        return sum(self.scores.values()) / len(self.scores)


@dataclass
class SampleMetadata:
    """Metadata for tracking sample provenance and quality."""
    
    # Generation info
    generator_model: str = ""
    generation_timestamp: datetime = field(default_factory=datetime.now)
    generation_params: Dict[str, Any] = field(default_factory=dict)
    
    # Task info
    task_type: str = ""
    domain: str = ""
    difficulty: str = "medium"
    
    # Quality info
    quality_score: float = 0.0
    critique_results: List[CritiqueResult] = field(default_factory=list)
    
    # Deduplication
    content_hash: str = ""
    embedding_vector: Optional[List[float]] = None
    
    # Pipeline tracking
    status: SampleStatus = SampleStatus.GENERATED
    rejection_reason: Optional[str] = None
    
    def add_critique(self, critique: CritiqueResult):
        """Add a critique result and update quality score."""
        self.critique_results.append(critique)
        # Update quality score as average of all critiques
        if self.critique_results:
            self.quality_score = sum(c.overall_score for c in self.critique_results) / len(self.critique_results)


@dataclass
class Sample:
    """
    A single synthetic data sample.
    
    The content structure depends on the task type:
    - instruction: {"instruction": str, "input": str|None, "output": str}
    - classification: {"text": str, "label": str}
    - tool_calling: {"query": str, "tools": list, "call": dict}
    - etc.
    
    Metadata tracks generation and quality information.
    """
    
    id: str
    content: Dict[str, Any]
    metadata: SampleMetadata = field(default_factory=SampleMetadata)
    
    def __post_init__(self):
        """Compute content hash after initialization."""
        if not self.metadata.content_hash:
            self.metadata.content_hash = self._compute_hash()
    
    def _compute_hash(self) -> str:
        """Compute deterministic hash of content."""
        content_str = json.dumps(self.content, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(content_str.encode()).hexdigest()[:16]
    
    @property
    def is_valid(self) -> bool:
        """Check if sample passed validation."""
        return self.metadata.status in (SampleStatus.VALIDATED, SampleStatus.ACCEPTED)
    
    @property
    def quality_score(self) -> float:
        """Get current quality score."""
        return self.metadata.quality_score
    
    def to_dict(self) -> Dict[str, Any]:
        """Export sample to dictionary format."""
        return {
            "id": self.id,
            **self.content,
            "_metadata": {
                "quality_score": self.metadata.quality_score,
                "difficulty": self.metadata.difficulty,
                "generator_model": self.metadata.generator_model,
                "domain": self.metadata.domain,
            }
        }
    
    def to_training_format(self) -> Dict[str, Any]:
        """Export sample in clean training format (no metadata)."""
        return self.content.copy()
    
    def reject(self, reason: str):
        """Mark sample as rejected with reason."""
        self.metadata.status = SampleStatus.REJECTED
        self.metadata.rejection_reason = reason
    
    def accept(self):
        """Mark sample as accepted."""
        self.metadata.status = SampleStatus.ACCEPTED


@dataclass
class SampleBatch:
    """
    A batch of samples for batch processing.
    
    Provides utilities for:
    - Batch operations
    - Filtering and selection
    - Statistics
    """
    
    samples: List[Sample] = field(default_factory=list)
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def __iter__(self):
        return iter(self.samples)
    
    def __getitem__(self, idx: int) -> Sample:
        return self.samples[idx]
    
    def add(self, sample: Sample):
        """Add a sample to the batch."""
        self.samples.append(sample)
    
    def extend(self, samples: List[Sample]):
        """Add multiple samples to the batch."""
        self.samples.extend(samples)
    
    @property
    def accepted(self) -> List[Sample]:
        """Get all accepted samples."""
        return [s for s in self.samples if s.metadata.status == SampleStatus.ACCEPTED]
    
    @property
    def rejected(self) -> List[Sample]:
        """Get all rejected samples."""
        return [s for s in self.samples if s.metadata.status == SampleStatus.REJECTED]
    
    @property
    def pending(self) -> List[Sample]:
        """Get samples still pending processing."""
        return [s for s in self.samples if s.metadata.status not in (SampleStatus.ACCEPTED, SampleStatus.REJECTED)]
    
    def filter_by_quality(self, min_score: float) -> "SampleBatch":
        """Filter samples by minimum quality score."""
        return SampleBatch(
            samples=[s for s in self.samples if s.quality_score >= min_score]
        )
    
    def filter_by_difficulty(self, difficulty: str) -> "SampleBatch":
        """Filter samples by difficulty level."""
        return SampleBatch(
            samples=[s for s in self.samples if s.metadata.difficulty == difficulty]
        )
    
    def get_stats(self) -> Dict[str, Any]:
        """Get batch statistics."""
        accepted = self.accepted
        quality_scores = [s.quality_score for s in accepted]
        
        return {
            "total": len(self.samples),
            "accepted": len(accepted),
            "rejected": len(self.rejected),
            "pending": len(self.pending),
            "acceptance_rate": len(accepted) / len(self.samples) if self.samples else 0,
            "avg_quality_score": sum(quality_scores) / len(quality_scores) if quality_scores else 0,
            "min_quality_score": min(quality_scores) if quality_scores else 0,
            "max_quality_score": max(quality_scores) if quality_scores else 0,
            "difficulty_distribution": self._get_difficulty_dist(),
        }
    
    def _get_difficulty_dist(self) -> Dict[str, int]:
        """Get distribution of difficulty levels."""
        dist = {"easy": 0, "medium": 0, "hard": 0, "adversarial": 0}
        for sample in self.accepted:
            diff = sample.metadata.difficulty
            if diff in dist:
                dist[diff] += 1
        return dist
    
    def to_list(self) -> List[Dict[str, Any]]:
        """Export all accepted samples as list of dicts."""
        return [s.to_dict() for s in self.accepted]
    
    def to_training_list(self) -> List[Dict[str, Any]]:
        """Export all accepted samples in training format."""
        return [s.to_training_format() for s in self.accepted]
