"""
Task Specification - Defines what kind of dataset to generate.

A TaskSpec encapsulates:
    - Task type (instruction, classification, etc.)
    - Domain context
    - Difficulty distribution
    - Sample count and constraints
"""

from enum import Enum
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from pydantic import BaseModel, Field, validator


class TaskType(str, Enum):
    """Supported synthetic data task types."""
    
    INSTRUCTION = "instruction"
    CLASSIFICATION = "classification"
    TOOL_CALLING = "tool_calling"
    AGENT_TRAJECTORY = "agent_trajectory"
    RAG_EVAL = "rag_eval"
    ADVERSARIAL = "adversarial"
    CUSTOM = "custom"


class Difficulty(str, Enum):
    """Difficulty levels for generated samples."""
    
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"
    ADVERSARIAL = "adversarial"


class DifficultyDistribution(BaseModel):
    """Distribution of difficulty levels in generated dataset."""
    
    easy: float = Field(default=0.3, ge=0.0, le=1.0)
    medium: float = Field(default=0.4, ge=0.0, le=1.0)
    hard: float = Field(default=0.2, ge=0.0, le=1.0)
    adversarial: float = Field(default=0.1, ge=0.0, le=1.0)
    
    @validator("adversarial")
    def validate_distribution(cls, v, values):
        total = values.get("easy", 0) + values.get("medium", 0) + values.get("hard", 0) + v
        if abs(total - 1.0) > 0.01:
            raise ValueError(f"Difficulty distribution must sum to 1.0, got {total}")
        return v


class TaskSpec(BaseModel):
    """
    Complete specification for a synthetic data generation task.
    
    This is the primary input to the generation pipeline. It defines:
    - What type of data to generate
    - Domain and context constraints
    - Quality and difficulty requirements
    - Generation parameters
    
    Example:
        spec = TaskSpec(
            task_type=TaskType.INSTRUCTION,
            domain="python_coding",
            num_samples=1000,
            difficulty_distribution=DifficultyDistribution(
                easy=0.2, medium=0.5, hard=0.25, adversarial=0.05
            ),
            constraints={"max_output_tokens": 512}
        )
    """
    
    # Core identification
    task_type: TaskType = Field(default=TaskType.INSTRUCTION, description="Type of task to generate data for")
    name: Optional[str] = Field(default=None, description="Human-readable task name")
    description: Optional[str] = Field(default=None, description="Task description")
    instruction: Optional[str] = Field(default=None, description="Direct instruction for custom generation")
    fields: List[str] = Field(default_factory=list, description="Target fields for structured output")
    
    # Domain specification
    domain: str = Field(default="general", description="Domain/topic area (e.g., 'python_coding', 'medical_qa')")
    subdomain: Optional[str] = Field(default=None, description="More specific subdomain")
    language: str = Field(default="en", description="Target language code")
    
    # Generation parameters
    num_samples: int = Field(default=100, ge=1, le=100000, description="Number of samples to generate")
    difficulty_distribution: DifficultyDistribution = Field(
        default_factory=DifficultyDistribution,
        description="Distribution of difficulty levels"
    )
    
    # Quality constraints
    min_quality_score: float = Field(default=0.7, ge=0.0, le=1.0, description="Minimum quality score to accept")
    deduplication_threshold: float = Field(default=0.85, ge=0.0, le=1.0, description="Semantic similarity threshold for dedup")
    
    # Task-specific configuration
    constraints: Dict[str, Any] = Field(
        default_factory=dict,
        description="Task-specific constraints and parameters"
    )
    
    # Schema override (optional)
    custom_schema: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Custom schema override for CUSTOM task type"
    )
    
    # Seed data (optional)
    seed_examples: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="Seed examples to guide generation style"
    )
    
    # Generation hints
    topics: List[str] = Field(
        default_factory=list,
        description="Specific topics to cover within the domain"
    )
    avoid_patterns: List[str] = Field(
        default_factory=list,
        description="Patterns or topics to avoid"
    )
    
    class Config:
        use_enum_values = True
    
    def get_difficulty_counts(self) -> Dict[Difficulty, int]:
        """Calculate exact counts for each difficulty level."""
        return {
            Difficulty.EASY: int(self.num_samples * self.difficulty_distribution.easy),
            Difficulty.MEDIUM: int(self.num_samples * self.difficulty_distribution.medium),
            Difficulty.HARD: int(self.num_samples * self.difficulty_distribution.hard),
            Difficulty.ADVERSARIAL: int(self.num_samples * self.difficulty_distribution.adversarial),
        }
    
    def to_prompt_context(self) -> str:
        """Generate context string for prompt templates."""
        context_parts = [
            f"Domain: {self.domain}",
            f"Task Type: {self.task_type}",
        ]
        if self.subdomain:
            context_parts.append(f"Subdomain: {self.subdomain}")
        if self.description:
            context_parts.append(f"Description: {self.description}")
        if self.topics:
            context_parts.append(f"Topics: {', '.join(self.topics)}")
        if self.avoid_patterns:
            context_parts.append(f"Avoid: {', '.join(self.avoid_patterns)}")
        
        return "\n".join(context_parts)


@dataclass
class TaskContext:
    """
    Runtime context for a generation task.
    
    Maintains state during generation:
    - Progress tracking
    - Generated samples so far (for dedup)
    - Quality statistics
    """
    
    spec: TaskSpec
    generated_count: int = 0
    accepted_count: int = 0
    rejected_count: int = 0
    current_difficulty: Difficulty = Difficulty.MEDIUM
    quality_scores: List[float] = field(default_factory=list)
    
    @property
    def acceptance_rate(self) -> float:
        """Calculate current acceptance rate."""
        total = self.accepted_count + self.rejected_count
        return self.accepted_count / total if total > 0 else 0.0
    
    @property
    def avg_quality_score(self) -> float:
        """Calculate average quality score."""
        return sum(self.quality_scores) / len(self.quality_scores) if self.quality_scores else 0.0
    
    @property
    def is_complete(self) -> bool:
        """Check if generation target is met."""
        return self.accepted_count >= self.spec.num_samples
    
    @property
    def progress_pct(self) -> float:
        """Calculate progress percentage."""
        return min(100.0, (self.accepted_count / self.spec.num_samples) * 100)
