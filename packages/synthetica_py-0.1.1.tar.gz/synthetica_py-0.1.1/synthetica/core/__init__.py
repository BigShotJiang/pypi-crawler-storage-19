"""Core module - Generator, Pipeline, and Task Specification"""

from synthetica.core.generator import SyntheticDataGenerator
from synthetica.core.task_spec import TaskSpec, TaskType
from synthetica.core.pipeline import GenerationPipeline
from synthetica.core.schema import SchemaEngine, SchemaRegistry
from synthetica.core.sample import Sample, SampleBatch

__all__ = [
    "SyntheticDataGenerator",
    "TaskSpec",
    "TaskType",
    "GenerationPipeline",
    "SchemaEngine",
    "SchemaRegistry",
    "Sample",
    "SampleBatch",
]
