"""
Schema Engine - Automatic schema inference and validation.

Manages schemas for different task types:
    - Built-in schemas for standard tasks
    - Schema inference from seed examples
    - Runtime schema validation
"""

from typing import Optional, Dict, Any, List, Type, Callable
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import re


class SchemaValidationError(Exception):
    """Raised when a sample doesn't conform to its schema."""
    pass


@dataclass
class FieldSpec:
    """Specification for a single field in a schema."""
    
    name: str
    field_type: str  # "string", "int", "float", "bool", "list", "object", "enum"
    required: bool = True
    nullable: bool = False
    description: str = ""
    constraints: Dict[str, Any] = field(default_factory=dict)
    # For enum types
    allowed_values: List[Any] = field(default_factory=list)
    # For nested objects
    nested_schema: Optional["Schema"] = None
    
    def validate(self, value: Any) -> tuple[bool, Optional[str]]:
        """Validate a value against this field spec."""
        # Handle null/None
        if value is None:
            if self.nullable:
                return True, None
            if self.required:
                return False, f"Field '{self.name}' is required but got None"
            return True, None
        
        # Type validation
        type_validators = {
            "string": lambda v: isinstance(v, str),
            "int": lambda v: isinstance(v, int) and not isinstance(v, bool),
            "float": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
            "bool": lambda v: isinstance(v, bool),
            "list": lambda v: isinstance(v, list),
            "object": lambda v: isinstance(v, dict),
            "enum": lambda v: v in self.allowed_values,
        }
        
        validator = type_validators.get(self.field_type)
        if validator and not validator(value):
            return False, f"Field '{self.name}' expected {self.field_type}, got {type(value).__name__}"
        
        # Constraint validation
        if "min_length" in self.constraints and isinstance(value, str):
            if len(value) < self.constraints["min_length"]:
                return False, f"Field '{self.name}' length {len(value)} < min {self.constraints['min_length']}"
        
        if "max_length" in self.constraints and isinstance(value, str):
            if len(value) > self.constraints["max_length"]:
                return False, f"Field '{self.name}' length {len(value)} > max {self.constraints['max_length']}"
        
        if "min_value" in self.constraints and isinstance(value, (int, float)):
            if value < self.constraints["min_value"]:
                return False, f"Field '{self.name}' value {value} < min {self.constraints['min_value']}"
        
        if "max_value" in self.constraints and isinstance(value, (int, float)):
            if value > self.constraints["max_value"]:
                return False, f"Field '{self.name}' value {value} > max {self.constraints['max_value']}"
        
        if "pattern" in self.constraints and isinstance(value, str):
            if not re.match(self.constraints["pattern"], value):
                return False, f"Field '{self.name}' doesn't match pattern {self.constraints['pattern']}"
        
        # Nested object validation
        if self.field_type == "object" and self.nested_schema:
            return self.nested_schema.validate(value)
        
        return True, None


@dataclass
class Schema:
    """
    Schema definition for a task type.
    
    Defines the expected structure of generated samples.
    """
    
    name: str
    description: str = ""
    fields: List[FieldSpec] = field(default_factory=list)
    allow_extra_fields: bool = False
    
    def validate(self, data: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """Validate data against this schema."""
        # Check required fields
        field_names = {f.name for f in self.fields}
        for f in self.fields:
            if f.required and f.name not in data:
                return False, f"Missing required field: {f.name}"
        
        # Check for unexpected fields
        if not self.allow_extra_fields:
            extra = set(data.keys()) - field_names
            if extra:
                return False, f"Unexpected fields: {extra}"
        
        # Validate each field
        for f in self.fields:
            if f.name in data:
                valid, error = f.validate(data[f.name])
                if not valid:
                    return False, error
        
        return True, None
    
    def to_json_schema(self) -> Dict[str, Any]:
        """Convert to JSON Schema format."""
        type_map = {
            "string": "string",
            "int": "integer",
            "float": "number",
            "bool": "boolean",
            "list": "array",
            "object": "object",
            "enum": "string",
        }
        
        properties = {}
        required = []
        
        for f in self.fields:
            prop = {"type": type_map.get(f.field_type, "string")}
            if f.description:
                prop["description"] = f.description
            if f.field_type == "enum":
                prop["enum"] = f.allowed_values
            if f.constraints.get("min_length"):
                prop["minLength"] = f.constraints["min_length"]
            if f.constraints.get("max_length"):
                prop["maxLength"] = f.constraints["max_length"]
            
            properties[f.name] = prop
            if f.required:
                required.append(f.name)
        
        return {
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": self.allow_extra_fields,
        }


class SchemaRegistry:
    """
    Registry of schemas for different task types.
    
    Provides:
    - Built-in schemas for standard tasks
    - Custom schema registration
    - Schema lookup by task type
    """
    
    _schemas: Dict[str, Schema] = {}
    
    @classmethod
    def register(cls, task_type: str, schema: Schema):
        """Register a schema for a task type."""
        cls._schemas[task_type] = schema
    
    @classmethod
    def get(cls, task_type: str) -> Optional[Schema]:
        """Get schema for a task type."""
        return cls._schemas.get(task_type)
    
    @classmethod
    def list_types(cls) -> List[str]:
        """List all registered task types."""
        return list(cls._schemas.keys())
    
    @classmethod
    def _register_defaults(cls):
        """Register default schemas for built-in task types."""
        # Instruction tuning schema
        cls.register("instruction", Schema(
            name="instruction",
            description="Instruction tuning dataset schema",
            fields=[
                FieldSpec("instruction", "string", required=True, 
                         constraints={"min_length": 10}),
                FieldSpec("input", "string", required=False, nullable=True),
                FieldSpec("output", "string", required=True,
                         constraints={"min_length": 1}),
            ]
        ))
        
        # Classification schema
        cls.register("classification", Schema(
            name="classification",
            description="Text classification dataset schema",
            fields=[
                FieldSpec("text", "string", required=True,
                         constraints={"min_length": 5}),
                FieldSpec("label", "string", required=True),
                FieldSpec("confidence", "float", required=False,
                         constraints={"min_value": 0.0, "max_value": 1.0}),
                FieldSpec("reasoning", "string", required=False, nullable=True),
            ]
        ))
        
        # Tool calling schema
        cls.register("tool_calling", Schema(
            name="tool_calling",
            description="Tool/function calling dataset schema",
            fields=[
                FieldSpec("user_query", "string", required=True),
                FieldSpec("available_tools", "list", required=True),
                FieldSpec("expected_call", "object", required=True),
                FieldSpec("reasoning", "string", required=False, nullable=True),
            ]
        ))
        
        # Agent trajectory schema
        cls.register("agent_trajectory", Schema(
            name="agent_trajectory",
            description="Agent trajectory dataset schema",
            fields=[
                FieldSpec("goal", "string", required=True),
                FieldSpec("environment", "string", required=True),
                FieldSpec("trajectory", "list", required=True),
                FieldSpec("success", "bool", required=True),
                FieldSpec("total_steps", "int", required=True,
                         constraints={"min_value": 1}),
            ]
        ))
        
        # RAG evaluation schema
        cls.register("rag_eval", Schema(
            name="rag_eval",
            description="RAG evaluation dataset schema",
            fields=[
                FieldSpec("question", "string", required=True),
                FieldSpec("context_documents", "list", required=True),
                FieldSpec("ground_truth_answer", "string", required=True),
                FieldSpec("answerable", "bool", required=True),
                FieldSpec("evidence_spans", "list", required=False),
            ]
        ))
        
        # Adversarial/safety schema
        cls.register("adversarial", Schema(
            name="adversarial",
            description="Adversarial/safety dataset schema",
            fields=[
                FieldSpec("prompt", "string", required=True),
                FieldSpec("attack_type", "enum", required=True,
                         allowed_values=["jailbreak", "injection", "manipulation", "edge_case"]),
                FieldSpec("expected_behavior", "enum", required=True,
                         allowed_values=["refuse", "safe_response", "flag"]),
                FieldSpec("risk_level", "enum", required=True,
                         allowed_values=["low", "medium", "high", "critical"]),
            ]
        ))


# Register default schemas on module load
SchemaRegistry._register_defaults()


class SchemaEngine:
    """
    Schema inference and management engine.
    
    Capabilities:
    - Infer schema from seed examples
    - Validate samples against schema
    - Generate schema documentation
    """
    
    def __init__(self):
        self.registry = SchemaRegistry
    
    def get_schema(self, task_type: str) -> Optional[Schema]:
        """Get schema for a task type."""
        return self.registry.get(task_type)
    
    def infer_schema(self, examples: List[Dict[str, Any]], name: str = "inferred") -> Schema:
        """
        Infer schema from a list of examples.
        
        Analyzes the structure and types of provided examples
        to generate a schema definition.
        """
        if not examples:
            raise ValueError("Cannot infer schema from empty examples")
        
        # Collect field information across all examples
        field_info: Dict[str, Dict[str, Any]] = {}
        
        for example in examples:
            for key, value in example.items():
                if key not in field_info:
                    field_info[key] = {
                        "types": set(),
                        "nullable": False,
                        "occurrences": 0,
                        "values": [],
                    }
                
                info = field_info[key]
                info["occurrences"] += 1
                
                if value is None:
                    info["nullable"] = True
                else:
                    info["types"].add(self._infer_type(value))
                    if len(info["values"]) < 10:  # Keep sample values
                        info["values"].append(value)
        
        # Build field specs
        fields = []
        total_examples = len(examples)
        
        for name_field, info in field_info.items():
            # Determine primary type
            types = info["types"]
            if not types:
                field_type = "string"
            elif len(types) == 1:
                field_type = types.pop()
            else:
                # Multiple types - use most common or fallback to string
                field_type = "string"
            
            # Determine if required (present in all examples)
            required = info["occurrences"] == total_examples
            
            fields.append(FieldSpec(
                name=name_field,
                field_type=field_type,
                required=required,
                nullable=info["nullable"],
            ))
        
        return Schema(name=name, fields=fields, allow_extra_fields=True)
    
    def _infer_type(self, value: Any) -> str:
        """Infer field type from a value."""
        if isinstance(value, bool):
            return "bool"
        if isinstance(value, int):
            return "int"
        if isinstance(value, float):
            return "float"
        if isinstance(value, str):
            return "string"
        if isinstance(value, list):
            return "list"
        if isinstance(value, dict):
            return "object"
        return "string"
    
    def validate(self, data: Dict[str, Any], task_type: str) -> tuple[bool, Optional[str]]:
        """Validate data against task type schema."""
        schema = self.get_schema(task_type)
        if not schema:
            return True, None  # No schema, assume valid
        return schema.validate(data)
    
    def generate_schema_prompt(self, task_type: str, custom_fields: List[str] = None) -> str:
        """Generate a prompt describing the expected schema."""
        if custom_fields:
            lines = [f"Generate data matching this schema:\n"]
            for f_name in custom_fields:
                lines.append(f"- {f_name}: string (required)")
            return "\n".join(lines)
            
        schema = self.get_schema(task_type)
        if not schema:
            return "No schema defined for this task type."
        
        lines = [f"Generate data matching this schema:\n"]
        for f in schema.fields:
            req = "required" if f.required else "optional"
            null = ", nullable" if f.nullable else ""
            lines.append(f"- {f.name}: {f.field_type} ({req}{null})")
            if f.description:
                lines.append(f"  Description: {f.description}")
            if f.constraints:
                lines.append(f"  Constraints: {f.constraints}")
        
        return "\n".join(lines)
