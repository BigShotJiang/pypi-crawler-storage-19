"""
Generation Pipeline - Orchestrates the multi-stage data generation process.

Pipeline stages:
    1. Seed Management - Initialize generation with seeds/topics
    2. Generation - Multi-model candidate generation
    3. Critique - Cross-model quality evaluation
    4. Filtering - Remove low-quality/duplicate samples
    5. Scoring - Final quality scoring
"""

from typing import Optional, Dict, Any, List, Callable, AsyncIterator
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from enum import Enum
import asyncio
import logging

from synthetica.core.task_spec import TaskSpec, TaskContext, Difficulty
from synthetica.core.sample import Sample, SampleBatch, SampleStatus, CritiqueResult
from synthetica.core.schema import SchemaEngine


logger = logging.getLogger(__name__)


class PipelineStage(str, Enum):
    """Pipeline processing stages."""
    
    SEED = "seed"
    GENERATE = "generate"
    CRITIQUE = "critique"
    FILTER = "filter"
    SCORE = "score"
    COMPLETE = "complete"


@dataclass
class PipelineConfig:
    """Configuration for the generation pipeline."""
    
    # Generation
    batch_size: int = 10
    max_retries: int = 3
    parallel_generations: int = 4
    
    # Critique
    enable_critique: bool = True
    cross_model_critique: bool = True
    critique_samples_ratio: float = 1.0  # Ratio of samples to critique
    
    # Filtering
    min_quality_score: float = 0.7
    dedup_threshold: float = 0.85
    enable_semantic_dedup: bool = True
    
    # Callbacks
    on_sample_generated: Optional[Callable[[Sample], None]] = None
    on_batch_complete: Optional[Callable[[SampleBatch], None]] = None
    on_progress: Optional[Callable[[float, str], None]] = None


class PipelineHook(ABC):
    """Base class for pipeline hooks."""
    
    @abstractmethod
    async def on_before_stage(self, stage: PipelineStage, context: TaskContext):
        """Called before a pipeline stage."""
        pass
    
    @abstractmethod
    async def on_after_stage(self, stage: PipelineStage, context: TaskContext, batch: SampleBatch):
        """Called after a pipeline stage."""
        pass


class GenerationPipeline:
    """
    Main generation pipeline orchestrator.
    
    Coordinates the flow of data through:
    Seed → Generate → Critique → Filter → Score
    
    Supports:
    - Async streaming generation
    - Multi-model orchestration
    - Quality-aware batching
    - Progress tracking
    """
    
    def __init__(
        self,
        generator_provider,  # BaseProvider
        critic_provider = None,  # BaseProvider, optional
        config: Optional[PipelineConfig] = None,
    ):
        self.generator = generator_provider
        self.critic = critic_provider or generator_provider
        self.config = config or PipelineConfig()
        self.schema_engine = SchemaEngine()
        self.hooks: List[PipelineHook] = []
        
        # Pipeline state
        self._current_stage = PipelineStage.SEED
        self._all_samples: SampleBatch = SampleBatch()
        self._sample_embeddings: Dict[str, List[float]] = {}
    
    def add_hook(self, hook: PipelineHook):
        """Add a pipeline hook."""
        self.hooks.append(hook)
    
    async def run(self, spec: TaskSpec) -> SampleBatch:
        """
        Run the complete generation pipeline.
        
        Args:
            spec: Task specification
            
        Returns:
            SampleBatch with all accepted samples
        """
        context = TaskContext(spec=spec)
        
        logger.info(f"Starting pipeline for {spec.task_type} task: {spec.num_samples} samples")
        
        # Reset state
        self._all_samples = SampleBatch()
        self._sample_embeddings = {}
        
        try:
            while not context.is_complete:
                # Generate batch
                batch = await self._run_generation_batch(context)
                
                # Critique
                if self.config.enable_critique:
                    batch = await self._run_critique(batch, context)
                
                # Filter
                batch = await self._run_filtering(batch, context)
                
                # Score and accept
                batch = await self._run_scoring(batch, context)
                
                # Update context
                for sample in batch:
                    if sample.metadata.status == SampleStatus.ACCEPTED:
                        context.accepted_count += 1
                        context.quality_scores.append(sample.quality_score)
                    else:
                        context.rejected_count += 1
                
                self._all_samples.extend(batch.samples)
                
                # Progress callback
                if self.config.on_progress:
                    self.config.on_progress(
                        context.progress_pct,
                        f"Accepted: {context.accepted_count}/{spec.num_samples}"
                    )
                
                logger.info(
                    f"Progress: {context.accepted_count}/{spec.num_samples} "
                    f"(acceptance rate: {context.acceptance_rate:.2%})"
                )
        
        except Exception as e:
            logger.error(f"Pipeline error: {e}")
            raise
        
        return SampleBatch(samples=self._all_samples.accepted)
    
    async def run_streaming(self, spec: TaskSpec) -> AsyncIterator[Sample]:
        """
        Run pipeline with streaming output.
        
        Yields samples as they are accepted.
        """
        context = TaskContext(spec=spec)
        
        while not context.is_complete:
            batch = await self._run_generation_batch(context)
            
            if self.config.enable_critique:
                batch = await self._run_critique(batch, context)
            
            batch = await self._run_filtering(batch, context)
            batch = await self._run_scoring(batch, context)
            
            for sample in batch:
                if sample.metadata.status == SampleStatus.ACCEPTED:
                    context.accepted_count += 1
                    context.quality_scores.append(sample.quality_score)
                    yield sample
                else:
                    context.rejected_count += 1
    
    async def _run_generation_batch(self, context: TaskContext) -> SampleBatch:
        """Generate a batch of candidate samples."""
        await self._notify_hooks(PipelineStage.GENERATE, context)
        
        spec = context.spec
        batch_size = min(
            self.config.batch_size,
            spec.num_samples - context.accepted_count
        )
        
        # Determine difficulty distribution for this batch
        difficulty_counts = spec.get_difficulty_counts()
        
        # Generate samples in parallel
        tasks = []
        for i in range(batch_size):
            # Select difficulty based on distribution and current counts
            difficulty = self._select_difficulty(difficulty_counts, context)
            tasks.append(self._generate_single(spec, difficulty, i))
        
        samples = await asyncio.gather(*tasks, return_exceptions=True)
        
        batch = SampleBatch()
        for result in samples:
            if isinstance(result, Sample):
                batch.add(result)
            elif isinstance(result, Exception):
                logger.warning(f"Generation failed: {result}")
        
        context.generated_count += len(batch)
        
        return batch
    
    async def _generate_single(
        self,
        spec: TaskSpec,
        difficulty: Difficulty,
        index: int
    ) -> Sample:
        """Generate a single sample."""
        from synthetica.prompts import PromptEngine
        
        prompt_engine = PromptEngine()
        prompt = prompt_engine.build_generation_prompt(spec, difficulty)
        
        # Get schema for structured generation
        schema = self.schema_engine.get_schema(spec.task_type)
        json_schema = schema.to_json_schema() if schema else None
        
        # Generate using provider (try structured first if schema exists)
        if json_schema and not spec.custom_schema:
            try:
                content = await self.generator.generate_structured(
                    prompt=prompt,
                    schema=json_schema,
                    temperature=self._get_temperature(difficulty),
                    max_tokens=spec.constraints.get("max_output_tokens", 1024),
                )
                
                # If content is already a dict, we're good
                if isinstance(content, dict) and content:
                    # Success, wrap in Sample
                    import uuid
                    from synthetica.core.sample import SampleMetadata
                    return Sample(
                        id=str(uuid.uuid4()),
                        content=content,
                        metadata=SampleMetadata(
                            generator_model=self.generator.model_name,
                            task_type=spec.task_type,
                            domain=spec.domain,
                            difficulty=difficulty.value,
                        )
                    )
            except Exception as e:
                logger.warning(f"Structured generation failed, falling back to text: {e}")
        
        # Fallback to plain text generation
        response = await self.generator.generate(
            prompt=prompt,
            temperature=self._get_temperature(difficulty),
            max_tokens=spec.constraints.get("max_output_tokens", 1024),
        )
        
        # Parse response into sample
        sample = self._parse_generation_response(response, spec, difficulty, index)
        
        return sample
    
    async def _run_critique(self, batch: SampleBatch, context: TaskContext) -> SampleBatch:
        """Run critique stage on batch."""
        await self._notify_hooks(PipelineStage.CRITIQUE, context)
        
        from synthetica.prompts import PromptEngine
        prompt_engine = PromptEngine()
        
        for sample in batch:
            # Build critique prompt
            critique_prompt = prompt_engine.build_critique_prompt(
                sample,
                context.spec
            )
            
            # Get critique from critic model
            response = await self.critic.generate(
                prompt=critique_prompt,
                temperature=0.3,  # Lower temperature for critique
                max_tokens=512,
            )
            
            # Parse critique result
            critique = self._parse_critique_response(response)
            sample.metadata.add_critique(critique)
            sample.metadata.status = SampleStatus.CRITIQUED
        
        return batch
    
    async def _run_filtering(self, batch: SampleBatch, context: TaskContext) -> SampleBatch:
        """Run filtering stage on batch."""
        await self._notify_hooks(PipelineStage.FILTER, context)
        
        for sample in batch:
            # Schema validation
            valid, error = self.schema_engine.validate(
                sample.content,
                context.spec.task_type
            )
            if not valid:
                sample.reject(f"Schema validation failed: {error}")
                continue
            
            # Quality threshold
            if sample.quality_score < self.config.min_quality_score:
                sample.reject(f"Quality score {sample.quality_score:.2f} below threshold")
                continue
            
            # Deduplication
            if self.config.enable_semantic_dedup:
                is_dup = await self._check_duplicate(sample)
                if is_dup:
                    sample.reject("Duplicate sample detected")
                    continue
            
            sample.metadata.status = SampleStatus.VALIDATED
        
        return batch
    
    async def _run_scoring(self, batch: SampleBatch, context: TaskContext) -> SampleBatch:
        """Run final scoring stage."""
        await self._notify_hooks(PipelineStage.SCORE, context)
        
        for sample in batch:
            if sample.metadata.status == SampleStatus.VALIDATED:
                # Final quality score adjustment
                final_score = self._compute_final_score(sample, context)
                sample.metadata.quality_score = final_score
                
                if final_score >= context.spec.min_quality_score:
                    sample.accept()
                else:
                    sample.reject(f"Final score {final_score:.2f} below threshold")
        
        return batch
    
    async def _check_duplicate(self, sample: Sample) -> bool:
        """Check if sample is a duplicate of existing samples."""
        # Exact hash check
        for existing in self._all_samples.accepted:
            if existing.metadata.content_hash == sample.metadata.content_hash:
                return True
        
        # Semantic similarity check (if embeddings available)
        if self._sample_embeddings:
            sample_embedding = await self._get_embedding(sample)
            if sample_embedding:
                for sample_id, embedding in self._sample_embeddings.items():
                    similarity = self._cosine_similarity(sample_embedding, embedding)
                    if similarity > self.config.dedup_threshold:
                        return True
                
                # Store embedding for future checks
                self._sample_embeddings[sample.id] = sample_embedding
        
        return False
    
    async def _get_embedding(self, sample: Sample) -> Optional[List[float]]:
        """Get embedding for sample content."""
        # This would use the embedding provider
        # For now, return None (skip semantic dedup)
        return None
    
    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Compute cosine similarity between two vectors."""
        dot_product = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x ** 2 for x in a) ** 0.5
        norm_b = sum(x ** 2 for x in b) ** 0.5
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot_product / (norm_a * norm_b)
    
    def _select_difficulty(
        self,
        target_counts: Dict[Difficulty, int],
        context: TaskContext
    ) -> Difficulty:
        """Select difficulty level for next sample based on distribution."""
        # Count current distribution
        current_counts = {d: 0 for d in Difficulty}
        for sample in self._all_samples.accepted:
            diff = Difficulty(sample.metadata.difficulty)
            current_counts[diff] += 1
        
        # Find most underrepresented difficulty
        max_deficit = -1
        selected = Difficulty.MEDIUM
        
        for diff, target in target_counts.items():
            deficit = target - current_counts[diff]
            if deficit > max_deficit:
                max_deficit = deficit
                selected = diff
        
        return selected
    
    def _get_temperature(self, difficulty: Difficulty) -> float:
        """Get generation temperature for difficulty level."""
        temp_map = {
            Difficulty.EASY: 0.5,
            Difficulty.MEDIUM: 0.7,
            Difficulty.HARD: 0.9,
            Difficulty.ADVERSARIAL: 1.0,
        }
        return temp_map.get(difficulty, 0.7)
    
    def _parse_generation_response(
        self,
        response: str,
        spec: TaskSpec,
        difficulty: Difficulty,
        index: int
    ) -> Sample:
        """Parse LLM response into a Sample."""
        import json
        import uuid
        import re
        
        # Try to extract JSON from response
        content = {}
        json_str = ""
        try:
            # Clean response
            clean_response = response.strip()
            
            # 1. Look for JSON block in markdown
            if "```json" in clean_response:
                json_start = clean_response.index("```json") + 7
                json_end = clean_response.index("```", json_start)
                json_str = clean_response[json_start:json_end].strip()
            # 2. Look for any triple backtick block
            elif "```" in clean_response:
                json_start = clean_response.index("```") + 3
                json_end = clean_response.index("```", json_start)
                json_str = clean_response[json_start:json_end].strip()
            # 3. Look for the outermost braces
            elif "{" in clean_response:
                json_start = clean_response.index("{")
                json_end = clean_response.rindex("}") + 1
                json_str = clean_response[json_start:json_end]
            else:
                json_str = clean_response
            
            # Basic cleaning: remove trailing commas that break json.loads
            # Search for a comma followed by a closing brace or bracket
            json_str = re.sub(r',\s*([\]}])', r'\1', json_str)
            
            content = json.loads(json_str)
        except (json.JSONDecodeError, ValueError) as e:
            # Fallback: treat as raw text
            logger.warning(f"Failed to parse JSON response: {e}")
            logger.debug(f"Attempted to parse: {json_str}")
            content = {"raw_response": response}
        
        from synthetica.core.sample import SampleMetadata
        
        return Sample(
            id=str(uuid.uuid4()),
            content=content,
            metadata=SampleMetadata(
                generator_model=self.generator.model_name,
                task_type=spec.task_type,
                domain=spec.domain,
                difficulty=difficulty.value,
            )
        )
    
    def _parse_critique_response(self, response: str) -> CritiqueResult:
        """Parse critique response into CritiqueResult."""
        import json
        
        try:
            if "```json" in response:
                json_start = response.index("```json") + 7
                json_end = response.index("```", json_start)
                json_str = response[json_start:json_end].strip()
            elif "{" in response:
                json_start = response.index("{")
                json_end = response.rindex("}") + 1
                json_str = response[json_start:json_end]
            else:
                json_str = response
            
            data = json.loads(json_str)
            
            return CritiqueResult(
                critic_model=self.critic.model_name,
                scores=data.get("scores", {}),
                feedback=data.get("feedback", ""),
                issues=data.get("issues", []),
                suggestions=data.get("suggestions", []),
                passed=data.get("passed", True),
            )
        except (json.JSONDecodeError, ValueError):
            # Conservative default on parse failure
            return CritiqueResult(
                critic_model=self.critic.model_name,
                scores={"overall": 0.5},
                feedback=response,
                passed=False,
            )
    
    def _compute_final_score(self, sample: Sample, context: TaskContext) -> float:
        """Compute final quality score for sample."""
        base_score = sample.quality_score
        
        # Adjust for difficulty alignment
        target_difficulty = sample.metadata.difficulty
        # Add small bonus for harder samples (they're more valuable)
        difficulty_bonus = {
            "easy": 0.0,
            "medium": 0.02,
            "hard": 0.05,
            "adversarial": 0.08,
        }.get(target_difficulty, 0.0)
        
        return min(1.0, base_score + difficulty_bonus)
    
    async def _notify_hooks(self, stage: PipelineStage, context: TaskContext):
        """Notify all hooks of stage transition."""
        for hook in self.hooks:
            await hook.on_before_stage(stage, context)
