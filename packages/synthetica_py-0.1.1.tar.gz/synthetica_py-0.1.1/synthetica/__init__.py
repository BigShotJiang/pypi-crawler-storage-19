"""
Synthetica - Production-Ready Synthetic Data Generator Library

Task-aware, model-agnostic synthetic data generation optimized for
local LLMs and Gemini free tier. Designed for fine-tuning, evaluation,
and agent training workflows.

Core Principles:
    - Quality over quantity
    - Local-first, cloud-optional
    - Cross-model critique and validation
    - Curriculum-aware difficulty calibration
"""

__version__ = "0.1.0"
__author__ = "C. Emre Karataş"

from synthetica.core.generator import SyntheticDataGenerator
from synthetica.core.task_spec import TaskSpec, TaskType
from synthetica.core.pipeline import GenerationPipeline
from synthetica.providers import OllamaProvider, GeminiProvider, LMStudioProvider
from synthetica.tasks import (
    InstructionTask,
    ClassificationTask,
    ToolCallingTask,
    AgentTrajectoryTask,
    RAGEvalTask,
    AdversarialTask,
)
from synthetica.export import JSONLExporter, CSVExporter, HuggingFaceExporter

__all__ = [
    # Core
    "SyntheticDataGenerator",
    "TaskSpec",
    "TaskType",
    "GenerationPipeline",
    # Providers
    "OllamaProvider",
    "GeminiProvider", 
    "LMStudioProvider",
    # Tasks
    "InstructionTask",
    "ClassificationTask",
    "ToolCallingTask",
    "AgentTrajectoryTask",
    "RAGEvalTask",
    "AdversarialTask",
    # Export
    "JSONLExporter",
    "CSVExporter",
    "HuggingFaceExporter",
]
