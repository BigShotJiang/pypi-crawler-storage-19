"""
Gemini Provider - Google Gemini API integration.

Optimized for free tier usage with:
    - Rate limiting
    - Request batching
    - Automatic retry with backoff
"""

from typing import Optional, Dict, Any, List, AsyncIterator
import aiohttp
import asyncio
import json
import os
import logging
from datetime import datetime, timedelta

from synthetica.providers.base import BaseProvider, ProviderType


logger = logging.getLogger(__name__)


class RateLimiter:
    """Simple rate limiter for API calls."""
    
    def __init__(self, requests_per_minute: int = 15):
        self.rpm = requests_per_minute
        self.requests = []
    
    async def acquire(self):
        """Wait if rate limit would be exceeded."""
        now = datetime.now()
        cutoff = now - timedelta(minutes=1)
        
        # Remove old requests
        self.requests = [r for r in self.requests if r > cutoff]
        
        if len(self.requests) >= self.rpm:
            # Wait until oldest request expires
            wait_time = (self.requests[0] - cutoff).total_seconds()
            if wait_time > 0:
                logger.info(f"Rate limit reached, waiting {wait_time:.1f}s")
                await asyncio.sleep(wait_time)
        
        self.requests.append(now)


class GeminiProvider(BaseProvider):
    """
    Google Gemini provider.
    
    Optimized for free tier with built-in rate limiting.
    
    Example:
        provider = GeminiProvider(
            model="gemini-3-flash-preview",
            api_key="your-api-key"
        )
        
        response = await provider.generate(
            prompt="Explain quantum computing",
            temperature=0.7
        )
    
    Free Tier Limits (as of 2024):
        - 15 requests per minute
        - 1 million tokens per month
    """
    
    DEFAULT_MODEL = "gemini-3-flash-preview"
    API_BASE = "https://generativelanguage.googleapis.com/v1beta"
    
    def __init__(
        self,
        model: str = None,
        api_key: str = None,
        requests_per_minute: int = 15,
        timeout: int = 60,
        **kwargs
    ):
        """
        Initialize Gemini provider.
        
        Args:
            model: Model name (default: gemini-3-flash-preview)
            api_key: API key (or set GOOGLE_API_KEY env var)
            requests_per_minute: Rate limit for free tier
            timeout: Request timeout in seconds
        """
        model = model or self.DEFAULT_MODEL
        super().__init__(model, **kwargs)
        
        self.api_key = api_key or os.environ.get("GOOGLE_API_KEY")
        if not self.api_key:
            raise ValueError("Gemini API key required. Set GOOGLE_API_KEY or pass api_key.")
        
        self.rate_limiter = RateLimiter(requests_per_minute)
        self.timeout = aiohttp.ClientTimeout(total=timeout)
    
    @property
    def provider_type(self) -> ProviderType:
        return ProviderType.GEMINI
    
    async def generate(
        self,
        prompt: str,
        system_prompt: str = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        **kwargs
    ) -> str:
        """Generate text using Gemini."""
        
        await self.rate_limiter.acquire()
        
        # Build request
        contents = []
        
        if system_prompt:
            contents.append({
                "role": "user",
                "parts": [{"text": f"System instruction: {system_prompt}"}]
            })
            contents.append({
                "role": "model",
                "parts": [{"text": "Understood. I will follow these instructions."}]
            })
        
        contents.append({
            "role": "user",
            "parts": [{"text": prompt}]
        })
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": temperature,
                "maxOutputTokens": max_tokens,
                "topP": kwargs.get("top_p", 0.95),
                "topK": kwargs.get("top_k", 40),
            }
        }
        
        # Add safety settings (permissive for data generation)
        payload["safetySettings"] = [
            {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
            {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
        ]
        
        url = f"{self.API_BASE}/models/{self._model}:generateContent?key={self.api_key}"
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(url, json=payload) as response:
                if response.status != 200:
                    error_text = await response.text()
                    
                    # Handle rate limiting
                    if response.status == 429:
                        logger.warning("Rate limited, waiting 60s...")
                        await asyncio.sleep(60)
                        return await self.generate(prompt, system_prompt, temperature, max_tokens, **kwargs)
                    
                    raise RuntimeError(f"Gemini error ({response.status}): {error_text}")
                
                data = await response.json()
                
                # Extract text from response
                candidates = data.get("candidates", [])
                if candidates:
                    content = candidates[0].get("content", {})
                    parts = content.get("parts", [])
                    if parts:
                        return parts[0].get("text", "")
                
                return ""
    
    async def generate_structured(
        self,
        prompt: str,
        schema: Dict[str, Any],
        system_prompt: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Generate structured JSON output."""
        
        schema_instruction = f"""
You must respond ONLY with valid JSON matching this exact schema:
{json.dumps(schema, indent=2)}

Do not include any text before or after the JSON.
"""
        
        full_system = schema_instruction
        if system_prompt:
            full_system = system_prompt + "\n\n" + schema_instruction
        
        response = await self.generate(
            prompt=prompt,
            system_prompt=full_system,
            temperature=kwargs.get("temperature", 0.5),  # Lower temp for structured
            max_tokens=kwargs.get("max_tokens", 1024),
        )
        
        # Parse JSON from response
        try:
            # Try to extract JSON if wrapped in markdown
            if "```json" in response:
                start = response.index("```json") + 7
                end = response.index("```", start)
                response = response[start:end].strip()
            elif "```" in response:
                start = response.index("```") + 3
                end = response.index("```", start)
                response = response[start:end].strip()
            
            return json.loads(response)
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Failed to parse Gemini JSON response: {e}")
            return {"raw": response}
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: str = None,
        **kwargs
    ) -> AsyncIterator[str]:
        """Generate with streaming output."""
        
        await self.rate_limiter.acquire()
        
        contents = []
        if system_prompt:
            contents.append({
                "role": "user",
                "parts": [{"text": f"System: {system_prompt}"}]
            })
            contents.append({
                "role": "model", 
                "parts": [{"text": "Understood."}]
            })
        
        contents.append({
            "role": "user",
            "parts": [{"text": prompt}]
        })
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": kwargs.get("temperature", 0.7),
                "maxOutputTokens": kwargs.get("max_tokens", 1024),
            }
        }
        
        url = f"{self.API_BASE}/models/{self._model}:streamGenerateContent?key={self.api_key}"
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(url, json=payload) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Gemini stream error: {error_text}")
                
                async for line in response.content:
                    if line:
                        try:
                            # Parse SSE format
                            line_str = line.decode("utf-8").strip()
                            if line_str.startswith("data: "):
                                data = json.loads(line_str[6:])
                                candidates = data.get("candidates", [])
                                if candidates:
                                    content = candidates[0].get("content", {})
                                    parts = content.get("parts", [])
                                    if parts:
                                        yield parts[0].get("text", "")
                        except (json.JSONDecodeError, UnicodeDecodeError):
                            continue
    
    async def embed(self, text: str) -> List[float]:
        """Generate embedding using Gemini."""
        
        await self.rate_limiter.acquire()
        
        payload = {
            "model": f"models/embedding-001",
            "content": {
                "parts": [{"text": text}]
            }
        }
        
        url = f"{self.API_BASE}/models/embedding-001:embedContent?key={self.api_key}"
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(url, json=payload) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Gemini embedding error: {error_text}")
                
                data = await response.json()
                embedding = data.get("embedding", {})
                return embedding.get("values", [])
    
    async def health_check(self) -> bool:
        """Check if Gemini API is available."""
        try:
            url = f"{self.API_BASE}/models?key={self.api_key}"
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as session:
                async with session.get(url) as response:
                    return response.status == 200
        except Exception:
            return False
    
    async def list_models(self) -> List[str]:
        """List available Gemini models."""
        try:
            url = f"{self.API_BASE}/models?key={self.api_key}"
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        data = await response.json()
                        return [m["name"].replace("models/", "") for m in data.get("models", [])]
                    return []
        except Exception:
            return []
