"""
Base Provider - Abstract interface for LLM backends.

All model providers must implement this interface to ensure
consistent behavior across different backends.
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any, List, AsyncIterator
from dataclasses import dataclass
from enum import Enum


class ProviderType(str, Enum):
    """Supported provider types."""
    
    OLLAMA = "ollama"
    GEMINI = "gemini"
    LMSTUDIO = "lmstudio"
    LLAMACPP = "llamacpp"
    CUSTOM = "custom"


@dataclass
class GenerationConfig:
    """Configuration for a generation request."""
    
    temperature: float = 0.7
    max_tokens: int = 1024
    top_p: float = 0.95
    top_k: int = 40
    stop_sequences: List[str] = None
    
    # Provider-specific options
    extra_params: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.stop_sequences is None:
            self.stop_sequences = []
        if self.extra_params is None:
            self.extra_params = {}


@dataclass
class GenerationResult:
    """Result from a generation request."""
    
    text: str
    finish_reason: str = "stop"
    usage: Dict[str, int] = None
    model: str = ""
    
    # Raw response for debugging
    raw_response: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.usage is None:
            self.usage = {}


class BaseProvider(ABC):
    """
    Abstract base class for LLM providers.
    
    Defines the interface that all model providers must implement.
    Supports both synchronous and asynchronous generation.
    
    Implementations must provide:
    - generate(): Main generation method
    - generate_stream(): Streaming generation
    - embed(): Text embedding (optional)
    - health_check(): Provider health status
    """
    
    def __init__(self, model: str, **kwargs):
        """
        Initialize provider.
        
        Args:
            model: Model identifier
            **kwargs: Provider-specific options
        """
        self._model = model
        self._options = kwargs
    
    @property
    def model_name(self) -> str:
        """Get model name/identifier."""
        return self._model
    
    @property
    @abstractmethod
    def provider_type(self) -> ProviderType:
        """Get provider type."""
        pass
    
    @abstractmethod
    async def generate(
        self,
        prompt: str,
        system_prompt: str = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        **kwargs
    ) -> str:
        """
        Generate text completion.
        
        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            temperature: Sampling temperature
            max_tokens: Maximum tokens to generate
            **kwargs: Additional generation parameters
            
        Returns:
            Generated text
        """
        pass
    
    @abstractmethod
    async def generate_structured(
        self,
        prompt: str,
        schema: Dict[str, Any],
        system_prompt: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Generate structured output matching schema.
        
        Args:
            prompt: User prompt
            schema: JSON schema for output
            system_prompt: Optional system prompt
            **kwargs: Additional generation parameters
            
        Returns:
            Parsed structured output
        """
        pass
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: str = None,
        **kwargs
    ) -> AsyncIterator[str]:
        """
        Generate with streaming output.
        
        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            **kwargs: Additional generation parameters
            
        Yields:
            Text chunks as they are generated
        """
        # Default implementation: no streaming, return full result
        result = await self.generate(prompt, system_prompt, **kwargs)
        yield result
    
    async def embed(self, text: str) -> List[float]:
        """
        Generate embedding for text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        raise NotImplementedError("Embedding not supported by this provider")
    
    async def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts.
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors
        """
        # Default: sequential embedding
        return [await self.embed(text) for text in texts]
    
    @abstractmethod
    async def health_check(self) -> bool:
        """
        Check if provider is healthy and available.
        
        Returns:
            True if provider is available
        """
        pass
    
    async def list_models(self) -> List[str]:
        """
        List available models.
        
        Returns:
            List of model identifiers
        """
        return [self._model]
    
    def get_token_count(self, text: str) -> int:
        """
        Estimate token count for text.
        
        Uses simple heuristic by default.
        Override for accurate counting.
        
        Args:
            text: Text to count tokens for
            
        Returns:
            Estimated token count
        """
        # Rough estimate: ~4 chars per token
        return len(text) // 4
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={self._model})"
