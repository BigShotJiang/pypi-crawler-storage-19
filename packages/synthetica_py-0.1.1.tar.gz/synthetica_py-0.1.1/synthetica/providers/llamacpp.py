"""
llama.cpp Provider - Direct llama.cpp server integration.

For use with llama.cpp's built-in HTTP server.
"""

from typing import Optional, Dict, Any, List, AsyncIterator
import aiohttp
import json
import logging

from synthetica.providers.base import BaseProvider, ProviderType


logger = logging.getLogger(__name__)


class LlamaCppProvider(BaseProvider):
    """
    llama.cpp server provider.
    
    Connects to llama.cpp's built-in HTTP server.
    Start server with: ./server -m model.gguf --host 0.0.0.0 --port 8080
    
    Example:
        provider = LlamaCppProvider(
            model="llama-7b",
            base_url="http://localhost:8080"
        )
        
        response = await provider.generate(
            prompt="Explain recursion",
            temperature=0.7
        )
    """
    
    DEFAULT_BASE_URL = "http://localhost:8080"
    
    def __init__(
        self,
        model: str = "llama",
        base_url: str = None,
        timeout: int = 120,
        **kwargs
    ):
        """
        Initialize llama.cpp provider.
        
        Args:
            model: Model name (for identification)
            base_url: llama.cpp server URL
            timeout: Request timeout in seconds
        """
        super().__init__(model, **kwargs)
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = aiohttp.ClientTimeout(total=timeout)
    
    @property
    def provider_type(self) -> ProviderType:
        return ProviderType.LLAMACPP
    
    async def generate(
        self,
        prompt: str,
        system_prompt: str = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        **kwargs
    ) -> str:
        """Generate text using llama.cpp."""
        
        # Build full prompt
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"### System:\n{system_prompt}\n\n### User:\n{prompt}\n\n### Assistant:\n"
        
        payload = {
            "prompt": full_prompt,
            "n_predict": max_tokens,
            "temperature": temperature,
            "top_p": kwargs.get("top_p", 0.95),
            "top_k": kwargs.get("top_k", 40),
            "stop": kwargs.get("stop", ["### User:", "### System:"]),
            "stream": False,
        }
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/completion",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"llama.cpp error: {error_text}")
                
                data = await response.json()
                return data.get("content", "")
    
    async def generate_structured(
        self,
        prompt: str,
        schema: Dict[str, Any],
        system_prompt: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Generate structured JSON output."""
        
        schema_instruction = f"""
Output ONLY valid JSON matching this schema:
{json.dumps(schema, indent=2)}
"""
        
        full_system = schema_instruction
        if system_prompt:
            full_system = system_prompt + "\n\n" + schema_instruction
        
        response = await self.generate(
            prompt=prompt,
            system_prompt=full_system,
            temperature=kwargs.get("temperature", 0.5),
            max_tokens=kwargs.get("max_tokens", 1024),
        )
        
        try:
            # Extract JSON
            if "```json" in response:
                start = response.index("```json") + 7
                end = response.index("```", start)
                response = response[start:end].strip()
            elif "{" in response:
                start = response.index("{")
                end = response.rindex("}") + 1
                response = response[start:end]
            
            return json.loads(response)
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Failed to parse JSON: {e}")
            return {"raw": response}
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: str = None,
        **kwargs
    ) -> AsyncIterator[str]:
        """Generate with streaming output."""
        
        full_prompt = prompt
        if system_prompt:
            full_prompt = f"### System:\n{system_prompt}\n\n### User:\n{prompt}\n\n### Assistant:\n"
        
        payload = {
            "prompt": full_prompt,
            "n_predict": kwargs.get("max_tokens", 1024),
            "temperature": kwargs.get("temperature", 0.7),
            "stream": True,
        }
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/completion",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"llama.cpp stream error: {error_text}")
                
                async for line in response.content:
                    if line:
                        try:
                            line_str = line.decode("utf-8").strip()
                            if line_str.startswith("data: "):
                                data = json.loads(line_str[6:])
                                content = data.get("content", "")
                                if content:
                                    yield content
                                if data.get("stop"):
                                    break
                        except (json.JSONDecodeError, UnicodeDecodeError):
                            continue
    
    async def embed(self, text: str) -> List[float]:
        """Generate embedding."""
        
        payload = {
            "content": text,
        }
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/embedding",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"llama.cpp embedding error: {error_text}")
                
                data = await response.json()
                return data.get("embedding", [])
    
    async def health_check(self) -> bool:
        """Check if llama.cpp server is available."""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                async with session.get(f"{self.base_url}/health") as response:
                    return response.status == 200
        except Exception:
            return False
    
    async def get_model_info(self) -> Dict[str, Any]:
        """Get information about loaded model."""
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.get(f"{self.base_url}/props") as response:
                    if response.status == 200:
                        return await response.json()
                    return {}
        except Exception:
            return {}
