"""
LM Studio Provider - Local LLM inference via LM Studio.

LM Studio exposes an OpenAI-compatible API, so this provider
uses the OpenAI API format.
"""

from typing import Optional, Dict, Any, List, AsyncIterator
import aiohttp
import json
import logging

from synthetica.providers.base import BaseProvider, ProviderType


logger = logging.getLogger(__name__)


class LMStudioProvider(BaseProvider):
    """
    LM Studio provider for local LLM inference.
    
    LM Studio provides an OpenAI-compatible API endpoint.
    
    Example:
        provider = LMStudioProvider(
            model="local-model",
            base_url="http://localhost:1234/v1"
        )
        
        response = await provider.generate(
            prompt="Write a haiku about coding",
            temperature=0.8
        )
    """
    
    DEFAULT_BASE_URL = "http://localhost:1234/v1"
    
    def __init__(
        self,
        model: str = "local-model",
        base_url: str = None,
        timeout: int = 120,
        **kwargs
    ):
        """
        Initialize LM Studio provider.
        
        Args:
            model: Model identifier (used for logging)
            base_url: LM Studio API base URL
            timeout: Request timeout in seconds
        """
        super().__init__(model, **kwargs)
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = aiohttp.ClientTimeout(total=timeout)
    
    @property
    def provider_type(self) -> ProviderType:
        return ProviderType.LMSTUDIO
    
    async def generate(
        self,
        prompt: str,
        system_prompt: str = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        **kwargs
    ) -> str:
        """Generate text using LM Studio."""
        
        messages = []
        
        if system_prompt:
            messages.append({
                "role": "system",
                "content": system_prompt
            })
        
        messages.append({
            "role": "user",
            "content": prompt
        })
        
        payload = {
            "model": self._model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        
        if kwargs.get("top_p"):
            payload["top_p"] = kwargs["top_p"]
        if kwargs.get("stop"):
            payload["stop"] = kwargs["stop"]
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/chat/completions",
                json=payload,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"LM Studio error: {error_text}")
                
                data = await response.json()
                choices = data.get("choices", [])
                if choices:
                    return choices[0].get("message", {}).get("content", "")
                return ""
    
    async def generate_structured(
        self,
        prompt: str,
        schema: Dict[str, Any],
        system_prompt: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Generate structured JSON output."""
        
        schema_instruction = f"""
You must respond with valid JSON matching this schema:
{json.dumps(schema, indent=2)}
Only output the JSON, no other text.
"""
        
        full_system = schema_instruction
        if system_prompt:
            full_system = system_prompt + "\n\n" + schema_instruction
        
        response = await self.generate(
            prompt=prompt,
            system_prompt=full_system,
            temperature=kwargs.get("temperature", 0.5),
            max_tokens=kwargs.get("max_tokens", 1024),
        )
        
        try:
            # Extract JSON from response
            if "```json" in response:
                start = response.index("```json") + 7
                end = response.index("```", start)
                response = response[start:end].strip()
            elif "```" in response:
                start = response.index("```") + 3
                end = response.index("```", start)
                response = response[start:end].strip()
            
            return json.loads(response)
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Failed to parse JSON: {e}")
            return {"raw": response}
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: str = None,
        **kwargs
    ) -> AsyncIterator[str]:
        """Generate with streaming output."""
        
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        
        payload = {
            "model": self._model,
            "messages": messages,
            "temperature": kwargs.get("temperature", 0.7),
            "max_tokens": kwargs.get("max_tokens", 1024),
            "stream": True,
        }
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/chat/completions",
                json=payload,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"LM Studio stream error: {error_text}")
                
                async for line in response.content:
                    if line:
                        line_str = line.decode("utf-8").strip()
                        if line_str.startswith("data: "):
                            data_str = line_str[6:]
                            if data_str == "[DONE]":
                                break
                            try:
                                data = json.loads(data_str)
                                choices = data.get("choices", [])
                                if choices:
                                    delta = choices[0].get("delta", {})
                                    content = delta.get("content", "")
                                    if content:
                                        yield content
                            except json.JSONDecodeError:
                                continue
    
    async def embed(self, text: str) -> List[float]:
        """Generate embedding using LM Studio."""
        
        payload = {
            "model": self._model,
            "input": text,
        }
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/embeddings",
                json=payload,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"LM Studio embedding error: {error_text}")
                
                data = await response.json()
                embeddings = data.get("data", [])
                if embeddings:
                    return embeddings[0].get("embedding", [])
                return []
    
    async def health_check(self) -> bool:
        """Check if LM Studio is available."""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                async with session.get(f"{self.base_url}/models") as response:
                    return response.status == 200
        except Exception:
            return False
    
    async def list_models(self) -> List[str]:
        """List available models."""
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.get(f"{self.base_url}/models") as response:
                    if response.status == 200:
                        data = await response.json()
                        return [m["id"] for m in data.get("data", [])]
                    return []
        except Exception:
            return []
