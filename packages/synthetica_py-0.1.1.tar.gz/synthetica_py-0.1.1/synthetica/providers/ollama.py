"""
Ollama Provider - Local LLM inference via Ollama.

Supports:
    - Text generation
    - Structured output (JSON mode)
    - Embeddings
    - Streaming
"""

from typing import Optional, Dict, Any, List, AsyncIterator
import aiohttp
import json
import logging

from synthetica.providers.base import BaseProvider, ProviderType


logger = logging.getLogger(__name__)


class OllamaProvider(BaseProvider):
    """
    Ollama provider for local LLM inference.
    
    Requires Ollama to be running locally or on a specified host.
    
    Example:
        provider = OllamaProvider(
            model="gemma:7b",
            base_url="http://localhost:11434"
        )
        
        response = await provider.generate(
            prompt="Write a Python function to sort a list",
            temperature=0.7
        )
    """
    
    DEFAULT_BASE_URL = "http://localhost:11434"
    
    def __init__(
        self,
        model: str = "gemma:7b",
        base_url: str = None,
        timeout: int = 120,
        **kwargs
    ):
        """
        Initialize Ollama provider.
        
        Args:
            model: Model name (e.g., "gemma:7b", "llama3:8b")
            base_url: Ollama API base URL
            timeout: Request timeout in seconds
        """
        super().__init__(model, **kwargs)
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = aiohttp.ClientTimeout(total=timeout)
    
    @property
    def provider_type(self) -> ProviderType:
        return ProviderType.OLLAMA
    
    async def generate(
        self,
        prompt: str,
        system_prompt: str = None,
        temperature: float = 0.7,
        max_tokens: int = 1024,
        **kwargs
    ) -> str:
        """Generate text using Ollama."""
        
        payload = {
            "model": self._model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            }
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        # Add any extra options
        if kwargs.get("top_p"):
            payload["options"]["top_p"] = kwargs["top_p"]
        if kwargs.get("top_k"):
            payload["options"]["top_k"] = kwargs["top_k"]
        if kwargs.get("stop"):
            payload["options"]["stop"] = kwargs["stop"]
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Ollama error: {error_text}")
                
                data = await response.json()
                return data.get("response", "")
    
    async def generate_structured(
        self,
        prompt: str,
        schema: Dict[str, Any],
        system_prompt: str = None,
        **kwargs
    ) -> Dict[str, Any]:
        """Generate structured JSON output."""
        
        # Build prompt with schema instruction
        schema_instruction = f"\nRespond ONLY with valid JSON matching this schema:\n{json.dumps(schema, indent=2)}"
        
        if system_prompt:
            system_prompt = system_prompt + schema_instruction
        else:
            system_prompt = schema_instruction
        
        payload = {
            "model": self._model,
            "prompt": prompt,
            "system": system_prompt,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": kwargs.get("temperature", 0.7),
                "num_predict": kwargs.get("max_tokens", 1024),
            }
        }
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Ollama error: {error_text}")
                
                data = await response.json()
                response_text = data.get("response", "{}")
                
                try:
                    return json.loads(response_text)
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse JSON response: {e}")
                    return {"raw": response_text}
    
    async def generate_stream(
        self,
        prompt: str,
        system_prompt: str = None,
        **kwargs
    ) -> AsyncIterator[str]:
        """Generate with streaming output."""
        
        payload = {
            "model": self._model,
            "prompt": prompt,
            "stream": True,
            "options": {
                "temperature": kwargs.get("temperature", 0.7),
                "num_predict": kwargs.get("max_tokens", 1024),
            }
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Ollama error: {error_text}")
                
                async for line in response.content:
                    if line:
                        try:
                            data = json.loads(line.decode("utf-8"))
                            if "response" in data:
                                yield data["response"]
                            if data.get("done"):
                                break
                        except json.JSONDecodeError:
                            continue
    
    async def embed(self, text: str) -> List[float]:
        """Generate embedding using Ollama."""
        
        payload = {
            "model": self._model,
            "prompt": text,
        }
        
        async with aiohttp.ClientSession(timeout=self.timeout) as session:
            async with session.post(
                f"{self.base_url}/api/embeddings",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Ollama embedding error: {error_text}")
                
                data = await response.json()
                return data.get("embedding", [])
    
    async def health_check(self) -> bool:
        """Check if Ollama is available."""
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                async with session.get(f"{self.base_url}/api/tags") as response:
                    return response.status == 200
        except Exception:
            return False
    
    async def list_models(self) -> List[str]:
        """List available Ollama models."""
        try:
            async with aiohttp.ClientSession(timeout=self.timeout) as session:
                async with session.get(f"{self.base_url}/api/tags") as response:
                    if response.status == 200:
                        data = await response.json()
                        return [m["name"] for m in data.get("models", [])]
                    return []
        except Exception:
            return []
    
    async def pull_model(self, model: str = None):
        """Pull/download a model."""
        model = model or self._model
        
        payload = {"name": model}
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.base_url}/api/pull",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Failed to pull model: {error_text}")
                
                # Stream progress
                async for line in response.content:
                    if line:
                        try:
                            data = json.loads(line.decode("utf-8"))
                            status = data.get("status", "")
                            logger.info(f"Pull progress: {status}")
                        except json.JSONDecodeError:
                            continue
