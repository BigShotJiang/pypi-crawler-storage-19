"""
Base Task - Abstract base for task type implementations.

Each task type can define:
    - Custom validation logic
    - Post-processing
    - Domain-specific quality checks
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class BaseTask(ABC):
    """
    Abstract base class for task type implementations.
    
    Subclasses can override:
    - validate(): Custom validation logic
    - post_process(): Sample post-processing
    - get_quality_checks(): Task-specific quality checks
    """
    
    task_type: str = "base"
    
    @classmethod
    @abstractmethod
    def validate_sample(cls, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """
        Validate a sample for this task type.
        
        Args:
            sample: Sample to validate
            spec: Task specification
            
        Returns:
            Tuple of (is_valid, error_message)
        """
        pass
    
    @classmethod
    def post_process(cls, sample: Sample, spec: TaskSpec) -> Sample:
        """
        Post-process a sample after generation.
        
        Override for task-specific post-processing.
        
        Args:
            sample: Sample to process
            spec: Task specification
            
        Returns:
            Processed sample
        """
        return sample
    
    @classmethod
    def get_quality_checks(cls) -> List[Dict[str, Any]]:
        """
        Get task-specific quality checks.
        
        Returns:
            List of quality check definitions
        """
        return []
    
    @classmethod
    def get_difficulty_adjustments(cls) -> Dict[str, Any]:
        """
        Get difficulty-specific adjustments.
        
        Returns:
            Dict mapping difficulty levels to adjustments
        """
        return {
            "easy": {"complexity_factor": 0.5},
            "medium": {"complexity_factor": 1.0},
            "hard": {"complexity_factor": 1.5},
            "adversarial": {"complexity_factor": 2.0},
        }
