"""Agent Trajectory Task - For multi-step agent behavior datasets."""

from typing import Optional, Dict, Any, List
from synthetica.tasks.base import BaseTask
from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class AgentTrajectoryTask(BaseTask):
    """
    Agent trajectory task.
    
    Schema:
        - goal: What the agent needs to accomplish
        - environment: Description of the environment
        - trajectory: List of (state, thought, action, observation) tuples
        - success: Whether the goal was achieved
        - total_steps: Number of steps taken
    
    Used for:
        - Agent behavior cloning
        - Reinforcement learning
        - Chain-of-thought training
    """
    
    task_type = "agent_trajectory"
    
    @classmethod
    def validate_sample(cls, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Validate an agent trajectory sample."""
        content = sample.content
        
        # Required fields
        required = ["goal", "environment", "trajectory", "success", "total_steps"]
        for field in required:
            if field not in content:
                return False, f"Missing '{field}' field"
        
        goal = content.get("goal", "")
        trajectory = content.get("trajectory", [])
        total_steps = content.get("total_steps", 0)
        success = content.get("success")
        
        # Validate goal
        if len(goal) < 5:
            return False, "Goal too short"
        
        # Validate trajectory
        if not isinstance(trajectory, list):
            return False, "Trajectory must be a list"
        
        if len(trajectory) == 0:
            return False, "Trajectory cannot be empty"
        
        # Validate each step
        for i, step in enumerate(trajectory):
            if not isinstance(step, dict):
                return False, f"Step {i} is not a dict"
            
            step_fields = ["step", "state", "thought", "action", "observation"]
            for field in step_fields:
                if field not in step:
                    return False, f"Step {i} missing '{field}'"
            
            # Validate step number
            if step.get("step") != i + 1:
                return False, f"Step {i} has wrong step number: {step.get('step')}"
        
        # Validate total_steps matches trajectory
        if total_steps != len(trajectory):
            return False, f"total_steps ({total_steps}) doesn't match trajectory length ({len(trajectory)})"
        
        # Validate success is boolean
        if not isinstance(success, bool):
            return False, "success must be a boolean"
        
        return True, None
    
    @classmethod
    def post_process(cls, sample: Sample, spec: TaskSpec) -> Sample:
        """Post-process agent trajectory sample."""
        content = sample.content
        
        # Ensure step numbers are correct
        if "trajectory" in content:
            for i, step in enumerate(content["trajectory"]):
                step["step"] = i + 1
            content["total_steps"] = len(content["trajectory"])
        
        sample.content = content
        return sample
    
    @classmethod
    def get_quality_checks(cls) -> List[Dict[str, Any]]:
        """Get agent trajectory quality checks."""
        return [
            {
                "name": "goal_clarity",
                "description": "Is the goal well-defined?",
                "weight": 0.20,
            },
            {
                "name": "action_validity",
                "description": "Are actions valid in the environment?",
                "weight": 0.25,
            },
            {
                "name": "reasoning_chain",
                "description": "Is the thought process logical?",
                "weight": 0.25,
            },
            {
                "name": "trajectory_coherence",
                "description": "Do steps follow logically?",
                "weight": 0.20,
            },
            {
                "name": "success_accuracy",
                "description": "Does success flag match outcome?",
                "weight": 0.10,
            },
        ]
