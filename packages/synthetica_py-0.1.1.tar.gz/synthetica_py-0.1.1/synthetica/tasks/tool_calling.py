"""Tool Calling Task - For function/tool use datasets."""

from typing import Optional, Dict, Any, List
from synthetica.tasks.base import BaseTask
from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class ToolCallingTask(BaseTask):
    """
    Tool/function calling task.
    
    Schema:
        - user_query: Natural language request
        - available_tools: List of tool definitions
        - expected_call: Correct tool and arguments
        - reasoning: Explanation of selection
    
    Used for:
        - Function calling training
        - Agent tool use
        - API interaction learning
    """
    
    task_type = "tool_calling"
    
    @classmethod
    def validate_sample(cls, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Validate a tool calling sample."""
        content = sample.content
        
        # Required fields
        required = ["user_query", "available_tools", "expected_call"]
        for field in required:
            if field not in content:
                return False, f"Missing '{field}' field"
        
        query = content.get("user_query", "")
        tools = content.get("available_tools", [])
        expected = content.get("expected_call", {})
        
        # Validate query
        if len(query) < 5:
            return False, "Query too short"
        
        # Validate tools
        if not isinstance(tools, list) or len(tools) == 0:
            return False, "available_tools must be a non-empty list"
        
        for i, tool in enumerate(tools):
            if not isinstance(tool, dict):
                return False, f"Tool {i} is not a dict"
            if "name" not in tool:
                return False, f"Tool {i} missing 'name'"
        
        # Validate expected call
        if not isinstance(expected, dict):
            return False, "expected_call must be a dict"
        
        if "tool_name" not in expected:
            return False, "expected_call missing 'tool_name'"
        
        # Check tool exists
        tool_names = [t["name"] for t in tools]
        if expected["tool_name"] not in tool_names:
            return False, f"Expected tool '{expected['tool_name']}' not in available tools"
        
        return True, None
    
    @classmethod
    def post_process(cls, sample: Sample, spec: TaskSpec) -> Sample:
        """Post-process tool calling sample."""
        content = sample.content
        
        # Ensure arguments is a dict
        if "expected_call" in content:
            if "arguments" not in content["expected_call"]:
                content["expected_call"]["arguments"] = {}
        
        sample.content = content
        return sample
    
    @classmethod
    def get_quality_checks(cls) -> List[Dict[str, Any]]:
        """Get tool calling quality checks."""
        return [
            {
                "name": "query_clarity",
                "description": "Is the query clear about what tool is needed?",
                "weight": 0.25,
            },
            {
                "name": "tool_selection",
                "description": "Is the correct tool selected?",
                "weight": 0.30,
            },
            {
                "name": "argument_extraction",
                "description": "Are arguments correctly extracted?",
                "weight": 0.30,
            },
            {
                "name": "reasoning_quality",
                "description": "Is the reasoning valid?",
                "weight": 0.15,
            },
        ]
