"""Instruction Tuning Task - For prompt → response datasets."""

from typing import Optional, Dict, Any, List
from synthetica.tasks.base import BaseTask
from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class InstructionTask(BaseTask):
    """
    Instruction tuning task.
    
    Schema:
        - instruction: The prompt/question
        - input: Optional additional context
        - output: Expected response
    
    Used for:
        - General instruction following
        - Q&A datasets
        - Chat fine-tuning
    """
    
    task_type = "instruction"
    
    @classmethod
    def validate_sample(cls, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Validate an instruction sample."""
        content = sample.content
        
        # If custom fields are specified, validate those instead
        if spec.fields:
            for field in spec.fields:
                if field not in content:
                    return False, f"Missing custom field: {field}"
            return True, None
            
        # Required fields default
        if "instruction" not in content:
            return False, "Missing 'instruction' field"
        
        if "output" not in content:
            return False, "Missing 'output' field"
        
        instruction = content.get("instruction", "")
        output = content.get("output", "")
        
        # Length checks
        if len(instruction) < 10:
            return False, f"Instruction too short: {len(instruction)} chars"
        
        if len(output) < 1:
            return False, "Output cannot be empty"
        
        # Quality checks
        if instruction.strip() == output.strip():
            return False, "Instruction and output are identical"
        
        # Check for placeholder text
        placeholders = ["[insert", "[your", "TODO", "PLACEHOLDER", "..."]
        for ph in placeholders:
            if ph.lower() in instruction.lower() or ph.lower() in output.lower():
                return False, f"Contains placeholder text: {ph}"
        
        return True, None
    
    @classmethod
    def post_process(cls, sample: Sample, spec: TaskSpec) -> Sample:
        """Post-process instruction sample."""
        content = sample.content
        
        # Trim whitespace
        if "instruction" in content:
            content["instruction"] = content["instruction"].strip()
        if "output" in content:
            content["output"] = content["output"].strip()
        if "input" in content and content["input"]:
            content["input"] = content["input"].strip()
        
        sample.content = content
        return sample
    
    @classmethod
    def get_quality_checks(cls) -> List[Dict[str, Any]]:
        """Get instruction-specific quality checks."""
        return [
            {
                "name": "instruction_clarity",
                "description": "Is the instruction clear and unambiguous?",
                "weight": 0.25,
            },
            {
                "name": "output_relevance",
                "description": "Does the output address the instruction?",
                "weight": 0.25,
            },
            {
                "name": "output_quality",
                "description": "Is the output well-written and accurate?",
                "weight": 0.30,
            },
            {
                "name": "difficulty_match",
                "description": "Does complexity match target difficulty?",
                "weight": 0.20,
            },
        ]
