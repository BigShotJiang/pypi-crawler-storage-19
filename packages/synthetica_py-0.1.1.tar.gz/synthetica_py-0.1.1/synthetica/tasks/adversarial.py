"""Adversarial Task - For safety and robustness testing datasets."""

from typing import Optional, Dict, Any, List
from synthetica.tasks.base import BaseTask
from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class AdversarialTask(BaseTask):
    """
    Adversarial/safety task.
    
    Schema:
        - prompt: Adversarial prompt
        - attack_type: Type of attack
        - expected_behavior: How model should respond
        - risk_level: Severity assessment
    
    Used for:
        - Safety training (red teaming)
        - Robustness evaluation
        - Jailbreak defense
    
    IMPORTANT: These samples are for DEFENSIVE purposes only.
    """
    
    task_type = "adversarial"
    
    VALID_ATTACK_TYPES = ["jailbreak", "injection", "manipulation", "edge_case"]
    VALID_BEHAVIORS = ["refuse", "safe_response", "flag"]
    VALID_RISK_LEVELS = ["low", "medium", "high", "critical"]
    
    @classmethod
    def validate_sample(cls, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Validate an adversarial sample."""
        content = sample.content
        
        # Required fields
        required = ["prompt", "attack_type", "expected_behavior", "risk_level"]
        for field in required:
            if field not in content:
                return False, f"Missing '{field}' field"
        
        prompt = content.get("prompt", "")
        attack_type = content.get("attack_type", "")
        expected = content.get("expected_behavior", "")
        risk = content.get("risk_level", "")
        
        # Validate prompt
        if len(prompt) < 10:
            return False, "Prompt too short"
        
        # Validate attack type
        if attack_type not in cls.VALID_ATTACK_TYPES:
            return False, f"Invalid attack_type: {attack_type}. Must be one of {cls.VALID_ATTACK_TYPES}"
        
        # Validate expected behavior
        if expected not in cls.VALID_BEHAVIORS:
            return False, f"Invalid expected_behavior: {expected}. Must be one of {cls.VALID_BEHAVIORS}"
        
        # Validate risk level
        if risk not in cls.VALID_RISK_LEVELS:
            return False, f"Invalid risk_level: {risk}. Must be one of {cls.VALID_RISK_LEVELS}"
        
        # Safety check: ensure no actual harmful instructions
        # This is a basic check - production systems need more sophisticated filtering
        dangerous_patterns = [
            "how to make a bomb",
            "how to kill",
            "child exploitation",
            "nuclear weapon",
        ]
        prompt_lower = prompt.lower()
        for pattern in dangerous_patterns:
            if pattern in prompt_lower:
                return False, f"Sample contains dangerous pattern: {pattern}"
        
        return True, None
    
    @classmethod
    def post_process(cls, sample: Sample, spec: TaskSpec) -> Sample:
        """Post-process adversarial sample."""
        # Add safety metadata
        sample.metadata.generation_params["safety_reviewed"] = False
        sample.metadata.generation_params["purpose"] = "defensive_training"
        
        return sample
    
    @classmethod
    def get_quality_checks(cls) -> List[Dict[str, Any]]:
        """Get adversarial quality checks."""
        return [
            {
                "name": "attack_validity",
                "description": "Is this a realistic attack pattern?",
                "weight": 0.25,
            },
            {
                "name": "risk_assessment",
                "description": "Is the risk level accurate?",
                "weight": 0.20,
            },
            {
                "name": "expected_behavior",
                "description": "Is expected behavior appropriate?",
                "weight": 0.20,
            },
            {
                "name": "novelty",
                "description": "Is this a unique attack pattern?",
                "weight": 0.15,
            },
            {
                "name": "safety_for_training",
                "description": "Is this safe for training use?",
                "weight": 0.20,
            },
        ]
