"""RAG Evaluation Task - For retrieval-augmented generation evaluation."""

from typing import Optional, Dict, Any, List
from synthetica.tasks.base import BaseTask
from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class RAGEvalTask(BaseTask):
    """
    RAG evaluation task.
    
    Schema:
        - question: Question to answer
        - context_documents: Retrieved documents
        - ground_truth_answer: Correct answer
        - answerable: Whether answer is in context
        - evidence_spans: Supporting text from context
    
    Used for:
        - RAG system evaluation
        - Retrieval quality testing
        - Answer grounding assessment
    """
    
    task_type = "rag_eval"
    
    @classmethod
    def validate_sample(cls, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Validate a RAG evaluation sample."""
        content = sample.content
        
        # Required fields
        required = ["question", "context_documents", "ground_truth_answer", "answerable"]
        for field in required:
            if field not in content:
                return False, f"Missing '{field}' field"
        
        question = content.get("question", "")
        context = content.get("context_documents", [])
        answer = content.get("ground_truth_answer", "")
        answerable = content.get("answerable")
        evidence = content.get("evidence_spans", [])
        
        # Validate question
        if len(question) < 5:
            return False, "Question too short"
        
        # Validate context
        if not isinstance(context, list):
            return False, "context_documents must be a list"
        
        if len(context) == 0:
            return False, "context_documents cannot be empty"
        
        for i, doc in enumerate(context):
            if not isinstance(doc, str):
                return False, f"Context document {i} is not a string"
            if len(doc) < 10:
                return False, f"Context document {i} too short"
        
        # Validate answerable
        if not isinstance(answerable, bool):
            return False, "answerable must be a boolean"
        
        # If answerable, check answer exists in context
        if answerable:
            context_text = " ".join(context).lower()
            # Check if key terms from answer appear in context
            answer_terms = answer.lower().split()
            if len(answer_terms) > 3:
                # For longer answers, check for substantial overlap
                matching = sum(1 for term in answer_terms if term in context_text)
                if matching < len(answer_terms) * 0.3:
                    return False, "Answer not supported by context (marked as answerable)"
        
        # Validate evidence spans if present
        if evidence:
            if not isinstance(evidence, list):
                return False, "evidence_spans must be a list"
            
            context_text = " ".join(context)
            for span in evidence:
                if not isinstance(span, str):
                    return False, "Evidence span is not a string"
        
        return True, None
    
    @classmethod
    def post_process(cls, sample: Sample, spec: TaskSpec) -> Sample:
        """Post-process RAG evaluation sample."""
        content = sample.content
        
        # Ensure evidence_spans exists
        if "evidence_spans" not in content:
            content["evidence_spans"] = []
        
        sample.content = content
        return sample
    
    @classmethod
    def get_quality_checks(cls) -> List[Dict[str, Any]]:
        """Get RAG evaluation quality checks."""
        return [
            {
                "name": "question_quality",
                "description": "Is the question clear and well-formed?",
                "weight": 0.20,
            },
            {
                "name": "context_relevance",
                "description": "Is context relevant to the question?",
                "weight": 0.20,
            },
            {
                "name": "answer_accuracy",
                "description": "Is the answer correct?",
                "weight": 0.25,
            },
            {
                "name": "answerability_flag",
                "description": "Is the answerable flag accurate?",
                "weight": 0.20,
            },
            {
                "name": "evidence_quality",
                "description": "Do evidence spans support the answer?",
                "weight": 0.15,
            },
        ]
