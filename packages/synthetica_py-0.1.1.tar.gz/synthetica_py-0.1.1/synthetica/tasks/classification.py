"""Classification Task - For text → label datasets."""

from typing import Optional, Dict, Any, List
from synthetica.tasks.base import BaseTask
from synthetica.core.sample import Sample
from synthetica.core.task_spec import TaskSpec


class ClassificationTask(BaseTask):
    """
    Text classification task.
    
    Schema:
        - text: Input text to classify
        - label: Classification label
        - confidence: Optional confidence score
        - reasoning: Optional explanation
    
    Used for:
        - Sentiment analysis
        - Topic classification
        - Intent detection
    """
    
    task_type = "classification"
    
    @classmethod
    def validate_sample(cls, sample: Sample, spec: TaskSpec) -> tuple[bool, Optional[str]]:
        """Validate a classification sample."""
        content = sample.content
        
        # Required fields
        if "text" not in content:
            return False, "Missing 'text' field"
        
        if "label" not in content:
            return False, "Missing 'label' field"
        
        text = content.get("text", "")
        label = content.get("label", "")
        
        # Length checks
        if len(text) < 5:
            return False, f"Text too short: {len(text)} chars"
        
        if len(label) < 1:
            return False, "Label cannot be empty"
        
        # Validate confidence if present
        if "confidence" in content:
            conf = content["confidence"]
            if not isinstance(conf, (int, float)) or conf < 0 or conf > 1:
                return False, f"Invalid confidence value: {conf}"
        
        # Check for valid label if label_set is defined
        label_set = spec.constraints.get("label_set", [])
        if label_set and label not in label_set:
            return False, f"Label '{label}' not in allowed set: {label_set}"
        
        return True, None
    
    @classmethod
    def post_process(cls, sample: Sample, spec: TaskSpec) -> Sample:
        """Post-process classification sample."""
        content = sample.content
        
        # Normalize text
        if "text" in content:
            content["text"] = content["text"].strip()
        
        # Normalize label
        if "label" in content:
            content["label"] = content["label"].strip()
        
        sample.content = content
        return sample
    
    @classmethod
    def get_quality_checks(cls) -> List[Dict[str, Any]]:
        """Get classification-specific quality checks."""
        return [
            {
                "name": "label_accuracy",
                "description": "Is the label correct for the text?",
                "weight": 0.40,
            },
            {
                "name": "text_naturalness",
                "description": "Is the text natural and realistic?",
                "weight": 0.25,
            },
            {
                "name": "reasoning_validity",
                "description": "Is the reasoning (if any) valid?",
                "weight": 0.15,
            },
            {
                "name": "difficulty_match",
                "description": "Does ambiguity match difficulty?",
                "weight": 0.20,
            },
        ]
