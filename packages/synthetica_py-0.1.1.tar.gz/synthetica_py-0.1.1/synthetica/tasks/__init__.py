"""Task Definitions - Specific task type implementations."""

from synthetica.tasks.instruction import InstructionTask
from synthetica.tasks.classification import ClassificationTask
from synthetica.tasks.tool_calling import ToolCallingTask
from synthetica.tasks.agent_trajectory import AgentTrajectoryTask
from synthetica.tasks.rag_eval import RAGEvalTask
from synthetica.tasks.adversarial import AdversarialTask

__all__ = [
    "InstructionTask",
    "ClassificationTask",
    "ToolCallingTask",
    "AgentTrajectoryTask",
    "RAGEvalTask",
    "AdversarialTask",
]
