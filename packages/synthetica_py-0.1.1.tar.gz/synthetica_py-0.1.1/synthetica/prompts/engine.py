"""
Prompt Engine - Dynamic prompt construction.

Builds prompts based on:
    - Task type and schema
    - Domain context
    - Difficulty level
    - Seed examples
"""

from typing import Optional, Dict, Any, List
from string import Template
import json
import random

from synthetica.core.task_spec import TaskSpec, Difficulty
from synthetica.core.sample import Sample
from synthetica.prompts.templates import TemplateRegistry, GenerationTemplate, CritiqueTemplate


class PromptEngine:
    """
    Builds prompts for generation and critique.
    
    Uses a template system with:
    - Task-specific templates
    - Dynamic variable substitution
    - Difficulty-aware instructions
    - Seed example injection
    """
    
    def __init__(self):
        self.registry = TemplateRegistry()
        self._register_default_templates()
    
    def _register_default_templates(self):
        """Register default templates for all task types."""
        # These are registered in TemplateRegistry._register_defaults()
        pass
    
    def build_generation_prompt(
        self,
        spec: TaskSpec,
        difficulty: Difficulty,
        seed_example: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Build a generation prompt for the task.
        
        Args:
            spec: Task specification
            difficulty: Target difficulty level
            seed_example: Optional seed example to guide style
            
        Returns:
            Complete prompt string
        """
        template = self.registry.get_generation_template(spec.task_type)
        
        # Build context
        context = {
            "task_type": spec.task_type,
            "domain": spec.domain,
            "subdomain": spec.subdomain or "",
            "difficulty": difficulty.value,
            "difficulty_instruction": self._get_difficulty_instruction(difficulty),
            "schema_description": self._get_schema_description(spec.task_type, spec.fields),
            "topics": ", ".join(spec.topics) if spec.topics else "general",
            "avoid_patterns": ", ".join(spec.avoid_patterns) if spec.avoid_patterns else "none",
            "language": spec.language,
            "constraints": json.dumps(spec.constraints) if spec.constraints else "{}",
            "custom_instruction": spec.instruction or "",
        }
        
        # Add seed example if provided
        if seed_example:
            context["seed_example"] = json.dumps(seed_example, indent=2, ensure_ascii=False)
        elif spec.seed_examples:
            # Pick a random seed example
            context["seed_example"] = json.dumps(
                random.choice(spec.seed_examples),
                indent=2,
                ensure_ascii=False
            )
        else:
            context["seed_example"] = ""
        
        # Build prompt
        return template.render(context)
    
    def build_critique_prompt(
        self,
        sample: Sample,
        spec: TaskSpec,
    ) -> str:
        """
        Build a critique prompt for evaluating a sample.
        
        Args:
            sample: Sample to critique
            spec: Task specification
            
        Returns:
            Complete critique prompt
        """
        template = self.registry.get_critique_template(spec.task_type)
        
        context = {
            "task_type": spec.task_type,
            "domain": spec.domain,
            "difficulty": sample.metadata.difficulty,
            "sample_content": json.dumps(sample.content, indent=2, ensure_ascii=False),
            "schema_description": self._get_schema_description(spec.task_type),
            "quality_criteria": self._get_quality_criteria(spec.task_type),
        }
        
        return template.render(context)
    
    def _get_difficulty_instruction(self, difficulty: Difficulty) -> str:
        """Get difficulty-specific instructions."""
        instructions = {
            Difficulty.EASY: """
Generate a SIMPLE, straightforward example that:
- Uses basic concepts
- Has clear, unambiguous requirements
- Would be suitable for beginners
- Avoids edge cases or complex scenarios
""",
            Difficulty.MEDIUM: """
Generate a MODERATE complexity example that:
- Combines multiple concepts
- Requires some reasoning or multiple steps
- Is typical of real-world scenarios
- May have minor nuances
""",
            Difficulty.HARD: """
Generate a CHALLENGING example that:
- Requires deep understanding
- Combines multiple complex concepts
- Has subtle edge cases or tricky requirements
- Would challenge experienced practitioners
""",
            Difficulty.ADVERSARIAL: """
Generate an ADVERSARIAL example that:
- Tests edge cases and boundary conditions
- May include intentional ambiguity
- Could expose model weaknesses
- Requires careful reasoning to handle correctly
- May include misleading or tricky elements
""",
        }
        return instructions.get(difficulty, instructions[Difficulty.MEDIUM])
    
    def _get_schema_description(self, task_type: str, custom_fields: List[str] = None) -> str:
        """Get schema description for task type."""
        from synthetica.core.schema import SchemaEngine
        engine = SchemaEngine()
        return engine.generate_schema_prompt(task_type, custom_fields)
    
    def _get_quality_criteria(self, task_type: str) -> str:
        """Get quality criteria for evaluation."""
        criteria = {
            "instruction": """
Evaluate the sample on:
1. Clarity: Is the instruction clear and unambiguous?
2. Relevance: Is the output relevant to the instruction?
3. Correctness: Is the output factually/technically correct?
4. Completeness: Does the output fully address the instruction?
5. Difficulty: Does it match the intended difficulty level?
""",
            "classification": """
Evaluate the sample on:
1. Label Correctness: Is the label accurate for the text?
2. Text Quality: Is the text natural and realistic?
3. Reasoning: If provided, is the reasoning valid?
4. Edge Cases: Does it handle boundary cases appropriately?
""",
            "tool_calling": """
Evaluate the sample on:
1. Query Clarity: Is the user query realistic and clear?
2. Tool Selection: Is the correct tool chosen?
3. Argument Accuracy: Are the arguments correctly extracted?
4. Reasoning: Is the reasoning sound?
""",
            "agent_trajectory": """
Evaluate the sample on:
1. Goal Clarity: Is the goal well-defined?
2. Action Validity: Are all actions valid in the environment?
3. Reasoning Chain: Is the thought process logical?
4. Trajectory Optimality: Is the path reasonably efficient?
5. Success Accuracy: Does the success flag match the outcome?
""",
            "rag_eval": """
Evaluate the sample on:
1. Question Quality: Is the question clear and answerable?
2. Context Relevance: Does the context contain the answer?
3. Answer Accuracy: Is the ground truth answer correct?
4. Answerability: Is the answerable flag accurate?
5. Evidence: Are the evidence spans correctly identified?
""",
            "adversarial": """
Evaluate the sample on:
1. Attack Validity: Is the attack realistic and well-crafted?
2. Risk Assessment: Is the risk level accurate?
3. Expected Behavior: Is the expected behavior appropriate?
4. Novelty: Is this a unique attack pattern?
5. Safety: Can this be safely used for training?
""",
        }
        return criteria.get(task_type, criteria["instruction"])
    
    def add_template(
        self,
        task_type: str,
        generation_template: str,
        critique_template: str = None,
    ):
        """
        Add custom templates for a task type.
        
        Args:
            task_type: Task type identifier
            generation_template: Template string for generation
            critique_template: Template string for critique (optional)
        """
        self.registry.register_generation_template(
            task_type,
            GenerationTemplate(task_type, generation_template)
        )
        
        if critique_template:
            self.registry.register_critique_template(
                task_type,
                CritiqueTemplate(task_type, critique_template)
            )
