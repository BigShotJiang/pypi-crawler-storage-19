"""
Prompt Templates - Task-specific template definitions.

Templates use a simple variable substitution system:
    ${variable_name} - replaced with context value
"""

from typing import Dict, Any, Optional
from dataclasses import dataclass
import re


@dataclass
class GenerationTemplate:
    """Template for generation prompts."""
    
    task_type: str
    template: str
    
    def render(self, context: Dict[str, Any]) -> str:
        """Render template with context variables."""
        result = self.template
        for key, value in context.items():
            placeholder = f"${{{key}}}"
            result = result.replace(placeholder, str(value))
        return result


@dataclass
class CritiqueTemplate:
    """Template for critique prompts."""
    
    task_type: str
    template: str
    
    def render(self, context: Dict[str, Any]) -> str:
        """Render template with context variables."""
        result = self.template
        for key, value in context.items():
            placeholder = f"${{{key}}}"
            result = result.replace(placeholder, str(value))
        return result


class TemplateRegistry:
    """Registry for prompt templates."""
    
    _generation_templates: Dict[str, GenerationTemplate] = {}
    _critique_templates: Dict[str, CritiqueTemplate] = {}
    
    def __init__(self):
        self._register_defaults()
    
    def _register_defaults(self):
        """Register default templates for built-in task types."""
        
        # ========== INSTRUCTION TUNING ==========
        self.register_generation_template("instruction", GenerationTemplate(
            task_type="instruction",
            template="""You are a synthetic data generator creating high-quality instruction-tuning examples.

DOMAIN: ${domain}
SUBDOMAIN: ${subdomain}
DIFFICULTY: ${difficulty}
LANGUAGE: ${language}

${difficulty_instruction}

TOPICS TO COVER: ${topics}
PATTERNS TO AVOID: ${avoid_patterns}

${custom_instruction}

${schema_description}

SEED EXAMPLE (if provided, match this style):
${seed_example}

Generate ONE complete example in valid JSON format:
{
    "instruction": "A clear instruction or question",
    "input": "Optional additional context (can be null)",
    "output": "The expected response"
}

IMPORTANT:
- The output must be high quality and accurate
- Match the specified difficulty level
- Be diverse and creative within the domain
- Ensure instruction and output are coherent
- Output ONLY the JSON, no other text"""
        ))
        
        self.register_critique_template("instruction", CritiqueTemplate(
            task_type="instruction",
            template="""You are a quality evaluator for instruction-tuning datasets.

Evaluate this sample:
${sample_content}

DOMAIN: ${domain}
TARGET DIFFICULTY: ${difficulty}

${quality_criteria}

Provide your evaluation as JSON:
{
    "scores": {
        "clarity": 0.0-1.0,
        "relevance": 0.0-1.0,
        "correctness": 0.0-1.0,
        "completeness": 0.0-1.0,
        "difficulty_match": 0.0-1.0
    },
    "feedback": "Brief overall assessment",
    "issues": ["List of issues found"],
    "suggestions": ["Improvement suggestions"],
    "passed": true/false
}

A sample passes if average score >= 0.7 and no critical issues.
Output ONLY the JSON."""
        ))
        
        # ========== CLASSIFICATION ==========
        self.register_generation_template("classification", GenerationTemplate(
            task_type="classification",
            template="""You are a synthetic data generator creating text classification examples.

DOMAIN: ${domain}
DIFFICULTY: ${difficulty}
LANGUAGE: ${language}

${difficulty_instruction}

TOPICS: ${topics}

${schema_description}

CONSTRAINTS: ${constraints}

Generate ONE classification example in valid JSON format:
{
    "text": "The text to classify",
    "label": "The correct label",
    "confidence": 0.0-1.0,
    "reasoning": "Why this label is correct (optional)"
}

IMPORTANT:
- Text should be realistic and natural
- Label must be accurate
- Include reasoning for harder examples
- Output ONLY the JSON"""
        ))
        
        self.register_critique_template("classification", CritiqueTemplate(
            task_type="classification",
            template="""Evaluate this classification example:
${sample_content}

DOMAIN: ${domain}
DIFFICULTY: ${difficulty}

${quality_criteria}

Respond with JSON:
{
    "scores": {
        "label_accuracy": 0.0-1.0,
        "text_quality": 0.0-1.0,
        "reasoning_quality": 0.0-1.0,
        "difficulty_match": 0.0-1.0
    },
    "feedback": "Assessment",
    "issues": [],
    "suggestions": [],
    "passed": true/false
}"""
        ))
        
        # ========== TOOL CALLING ==========
        self.register_generation_template("tool_calling", GenerationTemplate(
            task_type="tool_calling",
            template="""You are a synthetic data generator creating tool/function calling examples.

DOMAIN: ${domain}
DIFFICULTY: ${difficulty}

${difficulty_instruction}

${schema_description}

CONSTRAINTS: ${constraints}

Generate ONE tool-calling example in valid JSON:
{
    "user_query": "Natural user request that requires a tool",
    "available_tools": [
        {
            "name": "tool_name",
            "description": "What the tool does",
            "parameters": {
                "param1": {"type": "string", "description": "..."},
                "param2": {"type": "number", "description": "..."}
            }
        }
    ],
    "expected_call": {
        "tool_name": "tool_name",
        "arguments": {"param1": "value1", "param2": 123}
    },
    "reasoning": "Why this tool and these arguments"
}

IMPORTANT:
- Query should naturally require the tool
- Arguments must be extractable from the query
- Include 1-3 relevant tools (some may be distractors)
- Output ONLY the JSON"""
        ))
        
        self.register_critique_template("tool_calling", CritiqueTemplate(
            task_type="tool_calling",
            template="""Evaluate this tool-calling example:
${sample_content}

${quality_criteria}

Respond with JSON:
{
    "scores": {
        "query_clarity": 0.0-1.0,
        "tool_selection": 0.0-1.0,
        "argument_accuracy": 0.0-1.0,
        "reasoning_quality": 0.0-1.0
    },
    "feedback": "Assessment",
    "issues": [],
    "suggestions": [],
    "passed": true/false
}"""
        ))
        
        # ========== AGENT TRAJECTORY ==========
        self.register_generation_template("agent_trajectory", GenerationTemplate(
            task_type="agent_trajectory",
            template="""You are generating agent trajectory data for training.

DOMAIN: ${domain}
DIFFICULTY: ${difficulty}

${difficulty_instruction}

${schema_description}

Generate ONE agent trajectory example:
{
    "goal": "What the agent needs to accomplish",
    "environment": "Description of the environment/context",
    "trajectory": [
        {
            "step": 1,
            "state": {"current_situation": "..."},
            "thought": "Agent's reasoning",
            "action": "The action taken",
            "observation": "Result of the action"
        }
    ],
    "success": true/false,
    "total_steps": N
}

IMPORTANT:
- Trajectory should be logically consistent
- Each step should follow from the previous
- Success flag must match the actual outcome
- Output ONLY the JSON"""
        ))
        
        self.register_critique_template("agent_trajectory", CritiqueTemplate(
            task_type="agent_trajectory",
            template="""Evaluate this agent trajectory:
${sample_content}

${quality_criteria}

Respond with JSON:
{
    "scores": {
        "goal_clarity": 0.0-1.0,
        "action_validity": 0.0-1.0,
        "reasoning_chain": 0.0-1.0,
        "trajectory_coherence": 0.0-1.0,
        "success_accuracy": 0.0-1.0
    },
    "feedback": "Assessment",
    "issues": [],
    "suggestions": [],
    "passed": true/false
}"""
        ))
        
        # ========== RAG EVALUATION ==========
        self.register_generation_template("rag_eval", GenerationTemplate(
            task_type="rag_eval",
            template="""You are generating RAG evaluation examples.

DOMAIN: ${domain}
DIFFICULTY: ${difficulty}

${difficulty_instruction}

${schema_description}

Generate ONE RAG evaluation example:
{
    "question": "A question that can be answered from context",
    "context_documents": [
        "Document 1 content...",
        "Document 2 content..."
    ],
    "ground_truth_answer": "The correct answer",
    "answerable": true/false,
    "evidence_spans": ["Relevant quote from context"]
}

IMPORTANT:
- For answerable=true, answer MUST be in context
- For answerable=false, provide misleading but not answering context
- Evidence spans should support the answer
- Output ONLY the JSON"""
        ))
        
        self.register_critique_template("rag_eval", CritiqueTemplate(
            task_type="rag_eval",
            template="""Evaluate this RAG example:
${sample_content}

${quality_criteria}

Respond with JSON:
{
    "scores": {
        "question_quality": 0.0-1.0,
        "context_relevance": 0.0-1.0,
        "answer_accuracy": 0.0-1.0,
        "answerability_flag": 0.0-1.0,
        "evidence_quality": 0.0-1.0
    },
    "feedback": "Assessment",
    "issues": [],
    "suggestions": [],
    "passed": true/false
}"""
        ))
        
        # ========== ADVERSARIAL ==========
        self.register_generation_template("adversarial", GenerationTemplate(
            task_type="adversarial",
            template="""You are generating adversarial/safety test cases.

DOMAIN: ${domain}
DIFFICULTY: ${difficulty}

${difficulty_instruction}

${schema_description}

Generate ONE adversarial example:
{
    "prompt": "An adversarial prompt that tests model safety",
    "attack_type": "jailbreak|injection|manipulation|edge_case",
    "expected_behavior": "refuse|safe_response|flag",
    "risk_level": "low|medium|high|critical"
}

IMPORTANT:
- Examples must be useful for safety training
- Do NOT generate actually harmful content
- Focus on patterns, not specific harmful outputs
- These are for DEFENSIVE training purposes
- Output ONLY the JSON"""
        ))
        
        self.register_critique_template("adversarial", CritiqueTemplate(
            task_type="adversarial",
            template="""Evaluate this adversarial test case:
${sample_content}

${quality_criteria}

Respond with JSON:
{
    "scores": {
        "attack_validity": 0.0-1.0,
        "risk_assessment": 0.0-1.0,
        "expected_behavior": 0.0-1.0,
        "safety_for_training": 0.0-1.0
    },
    "feedback": "Assessment",
    "issues": [],
    "suggestions": [],
    "passed": true/false
}"""
        ))
    
    def register_generation_template(self, task_type: str, template: GenerationTemplate):
        """Register a generation template."""
        self._generation_templates[task_type] = template
    
    def register_critique_template(self, task_type: str, template: CritiqueTemplate):
        """Register a critique template."""
        self._critique_templates[task_type] = template
    
    def get_generation_template(self, task_type: str) -> GenerationTemplate:
        """Get generation template for task type."""
        if task_type not in self._generation_templates:
            # Fallback to instruction template
            return self._generation_templates.get("instruction")
        return self._generation_templates[task_type]
    
    def get_critique_template(self, task_type: str) -> CritiqueTemplate:
        """Get critique template for task type."""
        if task_type not in self._critique_templates:
            return self._critique_templates.get("instruction")
        return self._critique_templates[task_type]
    
    def list_task_types(self) -> list:
        """List all registered task types."""
        return list(self._generation_templates.keys())
