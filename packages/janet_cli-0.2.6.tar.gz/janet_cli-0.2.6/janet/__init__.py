"""Janet AI CLI - Sync tickets to local markdown files."""

__version__ = "0.2.6"
