# 🌤️ Weather Dashboard CLI

A Python-based weather dashboard command-line application that displays current weather,
forecasts, and alerts using a clean, modular architecture and Rich-based output.

## ✨ Features

- 🌍 Current weather for any city
- 🌧️ Forecast-based rain detection and weather alerts
- ⭐ Manage favorite cities (add, remove, list, clear)
- 🔁 Interactive menu mode **and** one-off CLI commands
- 🌡️ Celsius / Fahrenheit unit support
- 📊 Rich tables and formatted terminal output

## 🧠 Design Overview

The application is structured with a clear separation of responsibilities:

- **Weather service** — centralized API access and error handling
- **View models** — transform raw API data into display-ready objects
- **UI helpers** — render weather tables, alerts, and errors using Rich
- **CLI layer** — Typer-based commands and interactive workflows

This structure keeps the code easy to reason about, test, and extend.

## 🛠️ Installation

```bash
git clone https://github.com/<your-username>/weather-dashboard.git
cd weather-dashboard
uv sync
```

## 🚀 Usage

### One-off commands
```bash
uv run python cli_weather.py current Singapore
python cli_weather.py current "New York" --units f
python cli_weather.py current Tokyo --json
```

### Interactive mode
```bash
python cli_weather.py interactive
```

### Favorites
```bash
python cli_weather.py fav add London
python cli_weather.py fav list
python cli_weather.py fav show
python cli_weather.py fav clear
```

## 🧪 Testing
Run all tests with:
```bash
uv run pytest
```

## 📁 Project Structure
```text
weather_app/
├── client.py          # HTTP + API error handling
├── weather_service.py # High-level weather fetch + orchestration
├── models.py          # View models for presentation
├── ui.py              # Rich-based rendering helpers
├── cli_weather.py     # Typer CLI commands + interactive mode
├── favorites.py       # Persistence helpers for favorites
├── alerts.py          # Weather alert logic
├── units.py           # Units and temperature conversion
├── conditions.py      # Condition mappings and emojis
└── tests/
```
