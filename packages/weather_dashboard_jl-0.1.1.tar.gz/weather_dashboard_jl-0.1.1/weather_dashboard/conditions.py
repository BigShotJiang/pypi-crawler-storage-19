"""
Weather condition mappings and helpers.

Defines mappings from API condition codes to:
- Human-readable condition text
- Display-friendly emojis

Used when building view models for presentation.
"""

import json
from importlib.resources import files
from pathlib import Path
from typing import NamedTuple


# Represents the text for a condition in day and night
class Condition(NamedTuple):
    day: str
    night: str


# Build the full path to the JSON file
CONDITION_LIST_PATH = files("weather_dashboard").joinpath("data/weather_conditions.json")


def load_condition_data(path: Path) -> list[dict]:
    """
    Load the raw condition list from the JSON file.
    """

    with path.open("r") as f:
        return json.load(f)


def create_condition_mapping(raw_conditions: list[dict]) -> dict[int, Condition]:
    """
    Convert the raw condition list into a mapping:
    condition code (int) -> Condition(day, night)
    """

    mapping: dict[int, Condition] = {}

    for item in raw_conditions:
        code = item["code"]
        day_text = item["day"]
        night_text = item["night"]

        mapping[code] = Condition(day=day_text, night=night_text)

    return mapping


# Load once at import time
CONDITION_DATA = load_condition_data(CONDITION_LIST_PATH)
CONDITION_MAP = create_condition_mapping(CONDITION_DATA)


# Emoji map stays a normal dict: code -> {"day": emoji, "night": emoji}
EMOJI_MAP = {
    # --- Clear / Sunny ---
    1000: {"day": "☀️", "night": "🌙"},
    # --- Clouds & Fog ---
    1003: {"day": "🌤️", "night": "☁️"},  # Partly cloudy
    1006: {"day": "☁️", "night": "☁️"},  # Cloudy
    1009: {"day": "☁️", "night": "☁️"},  # Overcast
    1030: {"day": "🌫️", "night": "🌫️"},  # Mist
    1135: {"day": "🌫️", "night": "🌫️"},  # Fog
    1147: {"day": "🌫️", "night": "🌫️"},  # Freezing fog
    # --- Rain / Drizzle ---
    1063: {"day": "🌦️", "night": "🌧️"},  # Patchy rain possible
    1150: {"day": "🌦️", "night": "🌧️"},  # Patchy light drizzle
    1153: {"day": "🌧️", "night": "🌧️"},  # Light drizzle
    1168: {"day": "🌧️", "night": "🌧️"},  # Freezing drizzle
    1171: {"day": "🌧️", "night": "🌧️"},  # Heavy freezing drizzle
    1180: {"day": "🌦️", "night": "🌧️"},  # Patchy light rain
    1183: {"day": "🌧️", "night": "🌧️"},  # Light rain
    1186: {"day": "🌧️", "night": "🌧️"},  # Moderate rain at times
    1189: {"day": "🌧️", "night": "🌧️"},  # Moderate rain
    1192: {"day": "🌧️", "night": "🌧️"},  # Heavy rain at times
    1195: {"day": "🌧️", "night": "🌧️"},  # Heavy rain
    # --- Freezing Rain / Ice ---
    1198: {"day": "🌧️", "night": "🌧️"},  # Light freezing rain
    1201: {"day": "🌧️", "night": "🌧️"},  # Moderate or heavy freezing rain
    1237: {"day": "🧊", "night": "🧊"},  # Ice pellets
    # --- Sleet ---
    1069: {"day": "🌨️", "night": "🌨️"},  # Patchy sleet possible
    1072: {"day": "🌨️", "night": "🌨️"},  # Patchy freezing drizzle possible
    1204: {"day": "🌨️", "night": "🌨️"},  # Light sleet
    1207: {"day": "🌨️", "night": "🌨️"},  # Moderate or heavy sleet
    1249: {"day": "🌨️", "night": "🌨️"},  # Light sleet showers
    1252: {"day": "🌨️", "night": "🌨️"},  # Moderate or heavy sleet showers
    1261: {"day": "🌨️", "night": "🌨️"},  # Light showers of ice pellets
    1264: {"day": "🌨️", "night": "🌨️"},  # Heavy showers of ice pellets
    # --- Snow ---
    1066: {"day": "❄️", "night": "❄️"},  # Patchy snow possible
    1114: {"day": "❄️", "night": "❄️"},  # Blowing snow
    1117: {"day": "❄️", "night": "❄️"},  # Blizzard
    1210: {"day": "❄️", "night": "❄️"},  # Patchy light snow
    1213: {"day": "❄️", "night": "❄️"},  # Light snow
    1216: {"day": "❄️", "night": "❄️"},  # Patchy moderate snow
    1219: {"day": "❄️", "night": "❄️"},  # Moderate snow
    1222: {"day": "❄️", "night": "❄️"},  # Patchy heavy snow
    1225: {"day": "❄️", "night": "❄️"},  # Heavy snow
    1255: {"day": "❄️", "night": "❄️"},  # Light snow showers
    1258: {"day": "❄️", "night": "❄️"},  # Moderate or heavy snow showers
    # --- Showers (Rain) ---
    1240: {"day": "🌦️", "night": "🌧️"},  # Light rain shower
    1243: {"day": "🌧️", "night": "🌧️"},  # Moderate or heavy rain shower
    1246: {"day": "🌧️", "night": "🌧️"},  # Torrential rain shower
    # --- Thunderstorms ---
    1087: {"day": "⛈️", "night": "🌩️"},  # Thundery outbreaks possible
    1273: {"day": "⛈️", "night": "🌩️"},  # Patchy light rain with thunder
    1276: {"day": "⛈️", "night": "🌩️"},  # Moderate or heavy rain with thunder
    1279: {"day": "⛈️", "night": "🌩️"},  # Patchy light snow with thunder
    1282: {"day": "⛈️", "night": "🌩️"},  # Moderate or heavy snow with thunder
}
