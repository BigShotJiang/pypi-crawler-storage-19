"""
Credentials for WeatherApi.com and base URL configuration.
"""

import os

from dotenv import load_dotenv

load_dotenv()

# Base URLs for WeatherApi.com API

CURRENT_WEATHER_BASE_URL = "https://api.weatherapi.com/v1/current.json"
FORECAST_WEATHER_BASE_URL = "https://api.weatherapi.com/v1/forecast.json"

# Get API key from environment variable

def get_weather_api_key() -> str:
    """Return WEATHER_API_KEY from env, raising a clear error only when needed."""
    key = os.getenv("WEATHER_API_KEY")
    if not key:
        raise RuntimeError("WEATHER_API_KEY environment variable is not set")
    return key