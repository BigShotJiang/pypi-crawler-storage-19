"""
Command-line interface for the weather application.

This module defines all Typer commands and CLI workflows:
- One-off commands (e.g. current, fav)
- Interactive menu-based mode
- Argument parsing and user input handling

It delegates rendering to ui.py and data fetching to weather_service.py.
"""

import json

import typer
from rich.console import Console
from rich.panel import Panel

from weather_dashboard.client import get_current_weather
from weather_dashboard.favorites import add_favorite, clear_favorites, load_favorites, remove_favorite
from weather_dashboard.ui import (
    render_weather_result,
    show_city_weather,
)
from weather_dashboard.units import CELSIUS, UnitType, normalize_units
from weather_dashboard.weather_service import fetch_weather_for_city

app = typer.Typer(help="Weather dashboard CLI")
fav_app = typer.Typer(help="Manage favorite cities")
app.add_typer(fav_app, name="fav")

console = Console()


def handle_current(city_name: str, json_output: bool, units: UnitType) -> None:
    """
    Handle the 'current' command: fetch and display weather for a city.
    """

    result = fetch_weather_for_city(city_name)

    # JSON mode: only if we actually have current data
    if json_output and result.ok and result.current is not None:
        # Raw JSON output for scripting / piping
        console.print("=== CURRENT WEATHER JSON ===")
        console.print(json.dumps(result.current, indent=2))

        console.print("\n=== FORECAST WEATHER JSON ===")
        console.print(json.dumps(result.forecast, indent=2))

    else:
        # Pretty Rich table output
        render_weather_result(city_name, result, units)


@app.command()
def current(
    city_name: str = typer.Argument(..., help="City name to fetch weather for"),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of a formatted table",
    ),
    units: str = typer.Option(
        CELSIUS,
        "--units",
        help="Unit system: c or f",
    ),
) -> None:
    """
    Get the current weather for a city.

    Examples:
        uv run python cli_weather.py current Singapore
        uv run python cli_weather.py current "New York"
        uv run python cli_weather.py current "Singapore" --units f
        uv run python cli_weather.py current "Singapore" --json
        uv run python cli_weather.py current "Singapore" --units f --json
    """

    normalized_units = normalize_units(units)
    handle_current(city_name, json_output, normalized_units)


@fav_app.command("list")
def list_favorites() -> None:
    """
    List all favorite cities.

    Examples:
        uv run python cli_weather.py fav list
    """

    favorites = load_favorites()

    if not favorites:
        console.print("[yellow]No favorites saved yet.[/yellow]")
        return

    console.print("[bold]Favorite cities:[/bold]")
    for idx, city in enumerate(favorites, start=1):
        console.print(f"{idx}. {city}")


@fav_app.command("add")
def add_favorite_city_cmd(
    city_name: str = typer.Argument(..., help="City name to add to favorites"),
) -> None:
    """
    Add a city to the favorites list (after validating with the API).

    Examples:
        uv run python cli_weather.py fav add singapore
        uv run python cli_weather.py fav add "New York"
    """

    # Validate city by fetching its weather data from the API

    result = get_current_weather(city_name)
    if not result.ok or result.data is None:
        console.print(
            Panel.fit(
                "Cannot add favorite: failed to validate city with the weather API.",
                title="Validation error",
                border_style="red",
            )
        )
        return

    # Check for duplicates
    current_favorites = load_favorites()
    updated_favorites = add_favorite(city_name)

    normalized_city = city_name.strip().title()

    if len(updated_favorites) == len(current_favorites):
        console.print(
            f"[yellow]{normalized_city} is already in your favorites.[/yellow]"
        )
    else:
        console.print(f"[green]{normalized_city} added to favorites.[/green]")

    console.print(f"Now tracking {len(updated_favorites)} favorite(s).")


@fav_app.command("remove")
def remove_favorite_city_cmd(
    city_name: str = typer.Argument(..., help="City name to remove from favorites"),
) -> None:
    """
    Remove a city from your favorites list.

    Examples:
        uv run python cli_weather.py fav remove singapore
        uv run python cli_weather.py fav remove "New York"
    """

    # Check if there are any favorites in the list
    current_favorites = load_favorites()
    if not current_favorites:
        console.print("[yellow]No favorites to remove from.[/yellow]")
        return

    # Remove the city
    updated_favorites = remove_favorite(city_name)
    if len(updated_favorites) == len(current_favorites):
        console.print(
            f"[yellow]{city_name.strip().title()} was not in favorites.[/yellow]"
        )
    else:
        console.print(
            f"[green]{city_name.strip().title()} removed from favorites.[/green]"
        )

    console.print(f"Now tracking {len(updated_favorites)} favorite(s).")


@fav_app.command("show")
def show_weather_favorites(
    limit: int = typer.Option(
        3,
        "--limit",
        "-n",
        min=1,
        help="Maximum number of favorites to show",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output raw JSON instead of a formatted table",
    ),
    units: str = typer.Option(
        CELSIUS,
        "--units",
        help="Unit system: c or f",
    ),
) -> None:
    """
    Show weather for your saved favorite cities.

    Examples:
        uv run python cli_weather.py fav show
        uv run python cli_weather.py fav show --limit 3
        uv run python cli_weather.py fav show --json
        uv run python cli_weather.py fav show --units f
    """

    favorites = load_favorites()

    if not favorites:
        console.print("[yellow]No favorites saved yet.[/yellow]")
        return

    selected = favorites[:limit]

    normalized_units = normalize_units(units)

    for city in selected:
        console.print(
            Panel.fit(
                f"[bold]Favorite: {city}[/bold]",
                border_style="cyan",
            )
        )
        handle_current(city, json_output, normalized_units)
        console.print()  # blank line between cities


@fav_app.command("clear")
def clear_favorite_cities_cmd(
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Confirm clearing all favorites without prompting",
    ),
) -> None:
    """
    Clear all saved favorite cities.

    Examples:
        uv run python cli_weather.py fav clear
        uv run python cli_weather.py fav clear --yes
    """

    current_favorites = load_favorites()
    if not current_favorites:
        console.print("[yellow]No favorites to clear.[/yellow]")
        return

    # Explicitly say --yes, skip confirmation

    if yes:
        clear_favorites()
        console.print(f"[green]Cleared {len(current_favorites)} favorite(s).[/green]")
        return

    # Did not type --yes directly, seek for confirmation
    confirmed = typer.confirm(
        f"Are you sure you want to clear all {len(current_favorites)} favorite(s)?"
    )

    if confirmed:
        clear_favorites()
        console.print(f"[green]Cleared {len(current_favorites)} favorite(s).[/green]")
    else:
        console.print("[yellow]Cancelled. Favorites were not cleared.[/yellow]")


def interactive_loop():
    """
    Interactive CLI for the weather app.
    Lets the user:
    - check weather for any city
    - manage favorite cities
    - view weather for favorites
    """

    console.print("[bold]Hello from Weather Dashboard (interactive mode)![/bold]")

    while True:
        console.print("\nChoose an option:")
        console.print("  1. Show current weather for a city")
        console.print("  2. List favorite cities")
        console.print("  3. Add a favorite city")
        console.print("  4. Remove a favorite city")
        console.print("  5. Show weather for favorite cities")
        console.print("  6. Clear all favorite cities")
        console.print("  0. Exit")

        choice = console.input("Enter your choice: ").strip()

        if choice == "0":
            console.print("Goodbye!")
            break

        elif choice == "1":
            city_name = console.input("Enter city name: ").strip()
            if not city_name:
                console.print("[yellow]No city entered.[/yellow]")
                continue

            units_input = console.input("Units? (c/f, default c): ").strip() or CELSIUS
            units = normalize_units(units_input)

            show_city_weather(city_name, units)

        elif choice == "2":
            favorites = load_favorites()
            if not favorites:
                console.print("[yellow]No favorites saved yet.[/yellow]")
                continue

            console.print("[bold]Favorite cities:[/bold]")
            for idx, city in enumerate(favorites, start=1):
                console.print(f"{idx}. {city}")

        elif choice == "3":
            city_name = console.input("Enter city name to add: ").strip()
            if not city_name:
                console.print("[yellow]No city entered.[/yellow]")
                continue

            current_favorites = load_favorites()
            updated_favorites = add_favorite(city_name)
            normalized_city = city_name.strip().title()

            if len(updated_favorites) == len(current_favorites):
                console.print(
                    f"[yellow]{normalized_city} is already in your favorites.[/yellow]"
                )
            else:
                console.print(f"[green]{normalized_city} added to favorites.[/green]")
            console.print(f"Now tracking {len(updated_favorites)} favorite(s).")

        elif choice == "4":
            city_name = console.input("Enter city name to remove: ").strip()
            if not city_name:
                console.print("[yellow]No city entered.[/yellow]")
                continue

            current_favorites = load_favorites()
            if not current_favorites:
                console.print("[yellow]No favorites to remove from.[/yellow]")
                continue

            updated_favorites = remove_favorite(city_name)
            normalized_city = city_name.strip().title()

            if len(updated_favorites) == len(current_favorites):
                console.print(
                    f"[yellow]{normalized_city} was not in favorites.[/yellow]"
                )
            else:
                console.print(
                    f"[green]{normalized_city} removed from favorites.[/green]"
                )
            console.print(f"Now tracking {len(updated_favorites)} favorite(s).")

        elif choice == "5":
            favorites = load_favorites()
            if not favorites:
                console.print("[yellow]No favorites saved yet.[/yellow]")
            else:
                units_input = (
                    console.input("Units? (c/f, default c): ").strip() or CELSIUS
                )
                units = normalize_units(units_input)

                console.print("[bold]Showing weather for favorite cities:[/bold]")
                for city in favorites:
                    console.print(
                        Panel.fit(
                            f"[bold]Favorite: {city}[/bold]",
                            border_style="cyan",
                        )
                    )
                    show_city_weather(city, units)
                    console.print()  # blank line between cities

        elif choice == "6":
            favorites = load_favorites()

            if not favorites:
                console.print("[yellow]No favorites to clear.[/yellow]")
                continue

            confirm = (
                console.input(
                    f"Are you sure you want to clear all {len(favorites)} favorite(s)? (y/n): "
                )
                .strip()
                .lower()
            )

            if confirm == "y":
                clear_favorites()
                console.print(f"[green]Cleared {len(favorites)} favorite(s).[/green]")
            else:
                console.print("[yellow]Cancelled. Favorites were not cleared.[/yellow]")

        else:
            console.print("[red]Invalid choice. Please enter a valid option.[/red]")


@app.command()
def interactive() -> None:
    """
    Run the interactive menu-based CLI.

    Examples:
        uv run python cli_weather.py interactive
    """

    interactive_loop()


if __name__ == "__main__":
    app()
