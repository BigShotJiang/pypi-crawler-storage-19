# Autodroid

> pip install autodroid

## Usage
# device = ur serial number (the device u wanna control)
### swipe()

`swipe(x1, y1, x2, y2, duration, device=xxxxxxxxxxxxxxx)`
x1, y1, x2, y2 = position, from - to (must be integer)
duration = amount of time swiped (in milliseconds not seconds)

*Example:*

```python
swipe(520, 1730, 520, 400, 1000)
```

### tap()

`tap(x, y, device=xxxxxxxxxxxx)`
x, y = position (must be integer)

*Example:*

```python
tap(173, 200)
```

### screenshot()

`screenshot(device=xxxxxxxx)`
saves to `/sdcard/autodroid/screencap`

### holdtap()

`holdtap(x, y, duration, device=xxxxx)`
x, y = position (must be integer)
duration = amount of time held (in milliseconds)

*Example:*

```python
holdtap(167, 853, 4000, device=ABCD123)
```

### type()

`type(text, device=xxxxxxxxxxxxxxxx)`
text = the text you want to type (must be string)

*Example:*

```python
type("hello world", device="abcd1234")
```

### get_connected_devices()

`get_connected_devices()` prints the connected device S/N

### scrcpy()

`scrcpy(device=xxxxx)` starts a session of scrcpy

### key()

`key(device=xxxxx)` executes a key event

| Key Name    | Alternate Names  | Key Code |
| ----------- | ---------------- | -------- |
| Home        | –                | 3        |
| Back        | –                | 4        |
| Recent Apps | recent, recents  | 187      |
| Power       | pwr              | 26       |
| Volume Up   | v_up, vol_up     | 24       |
| Volume Down | v_down, vol_down | 25       |
| Mute        | –                | 164      |
| Media Play  | mplay, play      | 85       |
| Wake        | wakeup           | 224      |

*Example:*

```python
key("pwr", device=xxxxxxxxx)
```
> ADDED MULTI-DEVICE SUPPORT