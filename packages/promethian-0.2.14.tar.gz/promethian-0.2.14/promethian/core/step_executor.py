"""Step executor using sub-agents for isolated context.

Each plan step is executed in a fresh Claude conversation (sub-agent),
which:
1. Preserves context in the main agent
2. Allows each step to have focused context
3. Prevents context pollution between steps
4. Enables parallel step execution when dependencies allow
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

from promethian.config import PromethianConfig
from promethian.core.types import (
    Plan, PlanStep, Skill, Tool,
    StepResult, ExecutionStatus,
)
from promethian.core.tool_runner import ToolRunner, ToolExecutor, ToolExecutionError
from promethian.core.progress import ProgressTracker, NullProgressTracker, ProgressStage
from promethian.utils.claude import ClaudeClient, UsageStats
from promethian.utils.logging import get_logger


class ToolExecutionFailure(Exception):
    """Raised when a custom tool fails and should trigger healing."""
    def __init__(self, message: str, tool_name: str, error_details: str):
        super().__init__(message)
        self.tool_name = tool_name
        self.error_details = error_details

# Import built-in tools
from promethian.tools.bash import get_bash, BashTool
from promethian.tools.web_search import get_web_search, WebSearchTool
from promethian.tools.web_fetch import get_web_fetch, WebFetchTool
from promethian.tools.file_tools import get_file_tools, FileTools
from promethian.tools.todo import get_todo_tool, TodoWriteTool
from promethian.tools.ask_user import get_ask_user_tool, AskUserTool

try:
    from promethian.tools.browser import get_browser, BrowserTool
    BROWSER_AVAILABLE = True
except ImportError:
    BROWSER_AVAILABLE = False


@dataclass
class SubAgentResult:
    """Result from a sub-agent execution."""
    success: bool
    output: Any = None
    error: str | None = None
    tool_calls_made: list[dict] = field(default_factory=list)
    tokens_used: int = 0
    usage_stats: UsageStats | None = None


SUB_AGENT_SYSTEM_PROMPT = """You are a focused coding agent handling a single step of a larger plan.

Your job is to complete THIS SPECIFIC STEP using the tools and guidance provided.

## Core Guidelines

1. Focus ONLY on this step - don't try to do future steps
2. Use tools to accomplish the task efficiently
3. Follow skill guidance - it contains proven approaches
4. Report your output clearly

## Tool Usage

- Call multiple tools in parallel when they're independent for faster execution.
- Use specialized file tools (read, write, edit, glob, grep) instead of bash for file operations.
- Never use bash for: cat, head, tail, sed, awk, echo, find, grep - use dedicated tools.

## File Operations

- ALWAYS read a file before editing. Never modify code you haven't read.
- Use edit for precise string replacements. old_string must match exactly.
- Include enough context in edits to make matches unique.
- Use glob for file patterns ("**/*.py"), grep for content search.

## Code Quality

- Only make changes directly requested. Don't over-engineer.
- Don't add unnecessary comments, docstrings, or type annotations.
- Keep solutions simple and focused on the task.

When done, provide clear output the orchestrating agent can use."""


class StepSubAgent:
    """
    A sub-agent that executes a single plan step in isolated context.

    Each sub-agent:
    - Gets a fresh Claude conversation
    - Has access to relevant tools for just this step
    - Returns a structured result
    - Doesn't pollute the main agent's context

    Uses sub_agent_model (defaults to main model) which can be
    configured to use a faster/cheaper model for step execution.
    """

    def __init__(
        self,
        config: PromethianConfig,
        step: PlanStep,
        plan: Plan,
        previous_outputs: dict[str, Any],
        tool_executor: ToolExecutor,
        healing_context: list[str] | None = None,
    ):
        self.config = config
        self.step = step
        self.plan = plan
        self.previous_outputs = previous_outputs
        self.tool_executor = tool_executor
        self.healing_context = healing_context or []

        # Create a fresh Claude client for this sub-agent
        # Uses sub_agent_model which can be different from main model
        self.claude = ClaudeClient(
            api_key=config.anthropic_api_key,
            model=config.get_sub_agent_model(),
            max_tokens=config.sub_agent_max_tokens,
        )

        # Built-in tools (lazy init)
        self._bash: BashTool | None = None
        self._web_search: WebSearchTool | None = None
        self._web_fetch: WebFetchTool | None = None
        self._browser: BrowserTool | None = None
        self._file_tools: FileTools | None = None
        self._todo_tool: TodoWriteTool | None = None
        self._ask_user_tool: AskUserTool | None = None

        # Verbose logger
        self._logger = get_logger()

    def _get_todo_tool(self) -> TodoWriteTool:
        if self._todo_tool is None:
            self._todo_tool = get_todo_tool()
        return self._todo_tool

    def _get_ask_user_tool(self) -> AskUserTool:
        if self._ask_user_tool is None:
            self._ask_user_tool = get_ask_user_tool()
        return self._ask_user_tool

    def _get_file_tools(self) -> FileTools:
        if self._file_tools is None:
            self._file_tools = get_file_tools(working_dir=self.config.working_dir)
        return self._file_tools

    def _get_bash(self) -> BashTool:
        if self._bash is None:
            self._bash = get_bash(
                timeout=self.config.tool_timeout,
                working_dir=self.config.working_dir,
            )
        return self._bash

    def _get_web_search(self) -> WebSearchTool:
        if self._web_search is None:
            self._web_search = get_web_search()
        return self._web_search

    def _get_web_fetch(self) -> WebFetchTool:
        if self._web_fetch is None:
            self._web_fetch = get_web_fetch()
        return self._web_fetch

    async def _get_browser(self) -> BrowserTool | None:
        if self._browser is None and BROWSER_AVAILABLE:
            self._browser = await get_browser()
        return self._browser

    async def execute(self) -> SubAgentResult:
        """
        Execute the step in this sub-agent's isolated context.

        Returns:
            SubAgentResult with the outcome
        """
        tool_calls_made = []

        try:
            # Build the prompt with context for just this step
            # Separates cacheable (skills) from dynamic (step desc, outputs)
            cacheable_context, dynamic_prompt = self._build_step_prompt()

            # Gather tools needed for this step
            tools = await self._gather_tools()

            if tools:
                # Execute with tool use in a loop (with caching for efficiency)
                result = await self._execute_with_tools(
                    cacheable_context, dynamic_prompt, tools, tool_calls_made
                )
            else:
                # No tools needed - single completion
                # Combine prompts for simple case
                full_prompt = f"{cacheable_context}\n\n{dynamic_prompt}" if cacheable_context else dynamic_prompt
                result = await self.claude.complete(
                    prompt=full_prompt,
                    system=SUB_AGENT_SYSTEM_PROMPT,
                )

            return SubAgentResult(
                success=True,
                output=result,
                tool_calls_made=tool_calls_made,
                usage_stats=self.claude.usage,
            )

        except Exception as e:
            return SubAgentResult(
                success=False,
                error=str(e),
                tool_calls_made=tool_calls_made,
                usage_stats=self.claude.usage,
            )

    async def _execute_with_tools(
        self,
        cacheable_context: str,
        dynamic_prompt: str,
        tools: list[dict],
        tool_calls_made: list[dict],
    ) -> Any:
        """
        Execute the step with tool use support in a multi-turn loop.

        Uses prompt caching for efficiency:
        - System prompt is cached
        - cacheable_context (skills, static info) is cached
        - dynamic_prompt changes each call

        Continues calling tools until Claude indicates the step is complete.
        """
        import json

        MAX_TURNS = 10  # Prevent infinite loops
        all_results = []
        final_text = ""

        # Build conversation history for multi-turn
        messages = []

        # Build initial user message with caching
        if cacheable_context:
            initial_content = [
                {"type": "text", "text": cacheable_context, "cache_control": {"type": "ephemeral"}},
                {"type": "text", "text": dynamic_prompt},
            ]
        else:
            initial_content = dynamic_prompt

        messages.append({"role": "user", "content": initial_content})

        pending_tool_results = []  # Track results for continue_with_tool_result

        for turn in range(MAX_TURNS):
            if turn == 0:
                # Initial completion with caching
                text, tool_calls = await self.claude.complete_with_tools(
                    prompt=dynamic_prompt,
                    tools=tools,
                    system=SUB_AGENT_SYSTEM_PROMPT,
                    cache_system=True,
                    cacheable_context=cacheable_context if cacheable_context else None,
                )
            else:
                # Continue conversation with tool results from previous turn
                # Note: continue_with_tool_result creates a new list with tool_results added
                text, tool_calls = await self.claude.continue_with_tool_result(
                    messages=messages,
                    tool_results=pending_tool_results,
                    tools=tools,
                    system=SUB_AGENT_SYSTEM_PROMPT,
                    cache_system=True,
                )
                # Update our messages to include the tool_results that were sent
                tool_result_content = [
                    {"type": "tool_result", "tool_use_id": tr["tool_use_id"], "content": tr["content"]}
                    for tr in pending_tool_results
                ]
                messages.append({"role": "user", "content": tool_result_content})

            final_text = text or final_text

            # If no tool calls, step is complete
            if not tool_calls:
                break

            # Process tool calls
            assistant_content = []
            pending_tool_results = []  # Reset for this turn's results

            if text:
                assistant_content.append({"type": "text", "text": text})

            for call in tool_calls:
                tool_name = call["name"]
                tool_input = call["input"]
                tool_use_id = call.get("id", f"tool_{len(tool_calls_made)}")

                tool_calls_made.append({
                    "tool": tool_name,
                    "input": tool_input,
                })

                # Add tool_use to assistant content
                assistant_content.append({
                    "type": "tool_use",
                    "id": tool_use_id,
                    "name": tool_name,
                    "input": tool_input,
                })

                # Execute tool call
                tool_start_time = self._logger.tool_call_start(tool_name, tool_input)
                result = await self._execute_tool_call(tool_name, tool_input)
                self._logger.tool_call_complete(
                    tool_name,
                    result.get("success", False),
                    tool_start_time,
                    result=result.get("result"),
                    error=result.get("error"),
                )

                all_results.append(result)
                tool_calls_made[-1]["result"] = result

                # Prepare tool result for next turn's continuation
                result_content = json.dumps(result, default=str)[:4000]  # Truncate large results
                pending_tool_results.append({
                    "tool_use_id": tool_use_id,
                    "content": result_content,
                })

            # Add assistant response to messages (tool_results added at start of next turn)
            messages.append({"role": "assistant", "content": assistant_content})

        # Return combined result
        return {
            "text": final_text,
            "tool_results": all_results,
        }

    async def _execute_tool_call(
        self,
        tool_name: str,
        tool_input: dict,
    ) -> dict:
        """Execute a single tool call."""
        # Browser tools
        if tool_name.startswith("browser_"):
            browser = await self._get_browser()
            if browser:
                result = await browser.execute_tool(tool_name, tool_input)
                return {"success": result.success, "result": result.data, "error": result.error}
            return {"success": False, "error": "Browser not available"}

        # Bash tools
        if tool_name in ("bash", "bash_script"):
            bash = self._get_bash()
            result = await bash.execute_tool(tool_name, tool_input)
            return {
                "success": result.success,
                "result": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.exit_code,
            }

        # Web search tools
        if tool_name in ("web_search", "web_news_search"):
            ws = self._get_web_search()
            result = await ws.execute_tool(tool_name, tool_input)
            if result.success:
                return {
                    "success": True,
                    "results": [
                        {"title": r.title, "url": r.url, "snippet": r.snippet}
                        for r in (result.results or [])
                    ],
                }
            return {"success": False, "error": result.error}

        # Web fetch tool (lightweight HTTP fetch, no browser required)
        if tool_name == "web_fetch":
            wf = self._get_web_fetch()
            result = await wf.fetch(tool_input.get("url", ""))
            if result.success:
                return {
                    "success": True,
                    "url": result.url,
                    "content": result.content,
                    "content_type": result.content_type,
                    "status_code": result.status_code,
                    "file_path": result.file_path,  # For binary content
                }
            return {"success": False, "error": result.error}

        # File tools (read, write, edit, glob, grep)
        if tool_name in ("read", "write", "edit", "glob", "grep"):
            file_tools = self._get_file_tools()
            result = await file_tools.execute_tool(tool_name, tool_input)

            if tool_name == "read":
                if result.success:
                    return {
                        "success": True,
                        "content": result.content,
                        "file_path": result.file_path,
                        "total_lines": result.total_lines,
                    }
                return {"success": False, "error": result.error}

            elif tool_name == "write":
                if result.success:
                    return {
                        "success": True,
                        "file_path": result.file_path,
                        "bytes_written": result.bytes_written,
                    }
                return {"success": False, "error": result.error}

            elif tool_name == "edit":
                if result.success:
                    return {
                        "success": True,
                        "file_path": result.file_path,
                        "replacements_made": result.replacements_made,
                    }
                return {"success": False, "error": result.error}

            elif tool_name == "glob":
                if result.success:
                    return {
                        "success": True,
                        "files": result.files,
                        "count": len(result.files),
                    }
                return {"success": False, "error": result.error}

            elif tool_name == "grep":
                if result.success:
                    return {
                        "success": True,
                        "matches": [
                            {"file": m.file, "line": m.line_number, "content": m.content}
                            for m in result.matches
                        ],
                        "files_searched": result.files_searched,
                    }
                return {"success": False, "error": result.error}

        # Todo tool
        if tool_name == "todo_write":
            todo_tool = self._get_todo_tool()
            result = await todo_tool.execute_tool(tool_name, tool_input)
            if result.success:
                return {
                    "success": True,
                    "todos": [t.to_dict() for t in result.todos],
                    "count": len(result.todos),
                }
            return {"success": False, "error": result.error}

        # Ask user tool
        if tool_name == "ask_user":
            ask_user_tool = self._get_ask_user_tool()
            result = ask_user_tool.execute(**tool_input)
            if result.success:
                return {
                    "success": True,
                    "response": result.response,
                }
            return {
                "success": False,
                "cancelled": result.cancelled,
                "error": result.error or "User cancelled input",
            }

        # Custom tools from plan
        try:
            result = await self.tool_executor.execute(
                tool_name=tool_name,
                tool_input=tool_input,
            )
            return {"success": True, "result": result}
        except ToolExecutionError as e:
            return {
                "success": False,
                "error": str(e),
                "stdout": e.stdout,
                "stderr": e.stderr,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def _build_step_prompt(self) -> tuple[str, str]:
        """
        Build the prompt for this step, separating cacheable and dynamic parts.

        Returns:
            Tuple of (cacheable_context, dynamic_prompt)
            - cacheable_context: Static content (skills, tool docs) that can be cached
            - dynamic_prompt: Step-specific content that changes each step
        """
        # Cacheable parts: skills, gathered context, and tool docs (static across steps)
        cacheable_parts = []

        # Add gathered context (URLs, file contents, etc.) - IMPORTANT for accuracy
        if self.plan.gathered_context:
            cacheable_parts.append("# Pre-gathered Context (USE THESE URLs AND INFORMATION)")
            cacheable_parts.append(self.plan.gathered_context)

        # Add relevant skill guidance (cacheable - same skills used across steps)
        skill_content = []
        for skill_id in self.step.skills_to_use:
            for skill in self.plan.relevant_skills:
                if skill.id == skill_id:
                    skill_content.append(f"## {skill.name}\n{skill.content}")

        if skill_content:
            cacheable_parts.append("# Guidance from Skills")
            cacheable_parts.extend(skill_content)

        # Dynamic parts: step description, previous outputs, healing context
        dynamic_parts = [
            f"# Your Task\n{self.step.description}",
            f"\n# Expected Output\n{self.step.expected_output}",
        ]

        # Add outputs from dependencies (dynamic - changes each step)
        if self.step.dependencies and self.previous_outputs:
            dynamic_parts.append("\n# Context from Previous Steps")
            for dep_id in self.step.dependencies:
                if dep_id in self.previous_outputs:
                    output = self.previous_outputs[dep_id]
                    # Truncate if too long
                    if isinstance(output, str) and len(output) > 2000:
                        output = output[:2000] + "\n... (truncated)"
                    dynamic_parts.append(f"\n## From {dep_id}:\n{output}")

        # Add healing context from previous failed attempts (dynamic)
        if self.healing_context:
            dynamic_parts.append("\n# Previous Attempts (IMPORTANT - learn from these failures)")
            for entry in self.healing_context:
                dynamic_parts.append(f"\n{entry}")
            dynamic_parts.append("\nAvoid the same mistakes. Try a different approach if a tool keeps failing.")

        dynamic_parts.append("\nComplete this step and provide your output.")

        cacheable = "\n".join(cacheable_parts) if cacheable_parts else ""
        dynamic = "\n".join(dynamic_parts)

        return cacheable, dynamic

    async def _gather_tools(self) -> list[dict]:
        """Gather tools needed for this step."""
        tools = []
        seen_names: set[str] = set()

        def add_tool(schema: dict) -> None:
            """Add tool if name not already seen."""
            name = schema.get("name")
            if name and name not in seen_names:
                tools.append(schema)
                seen_names.add(name)

        # Add custom tools from plan first (they take priority)
        for tool_id in self.step.tools_to_use:
            for tool in self.plan.relevant_tools:
                if tool.id == tool_id:
                    add_tool(tool.get_schema())

        # Check if step needs built-in tools based on keywords
        desc_lower = self.step.description.lower()

        # File tools keywords - fundamental for coding tasks
        file_keywords = [
            "file", "read", "write", "edit", "create", "modify", "update",
            "code", "implement", "function", "class", "module", "script",
            "add", "remove", "delete", "change", "fix", "refactor",
            "import", "export", "config", "json", "yaml", "toml",
            ".py", ".js", ".ts", ".go", ".rs", ".java", ".cpp",
        ]
        if any(kw in desc_lower for kw in file_keywords):
            file_tools = self._get_file_tools()
            for schema in file_tools.get_tool_schemas():
                add_tool(schema)

        # Bash keywords
        bash_keywords = [
            "run", "execute", "command", "shell", "bash", "terminal",
            "git", "npm", "pip", "docker", "make", "curl", "install",
            "build", "test", "deploy", "mkdir",
        ]
        if any(kw in desc_lower for kw in bash_keywords):
            bash = self._get_bash()
            for schema in bash.get_tool_schemas():
                add_tool(schema)

        # Search keywords
        search_keywords = [
            "search", "look up", "research", "documentation",
            "how to", "what is", "examples", "tutorial",
        ]
        if any(kw in desc_lower for kw in search_keywords):
            ws = self._get_web_search()
            for schema in ws.get_tool_schemas():
                add_tool(schema)

        # Web fetch keywords (lightweight HTTP fetch - always available)
        fetch_keywords = [
            "fetch", "download", "url", "http", "api", "endpoint",
            "score", "weather", "news", "price", "data",
        ]
        if any(kw in desc_lower for kw in fetch_keywords):
            wf = self._get_web_fetch()
            for schema in wf.get_tool_schemas():
                add_tool(schema)

        # Browser keywords (full browser automation - requires Playwright)
        browser_keywords = [
            "browse", "click", "screenshot", "navigate", "interact",
            "login", "form", "javascript", "dynamic",
        ]
        if any(kw in desc_lower for kw in browser_keywords) and BROWSER_AVAILABLE:
            browser = await self._get_browser()
            if browser:
                for schema in browser.get_tool_schemas():
                    add_tool(schema)
        elif any(kw in desc_lower for kw in browser_keywords) and not BROWSER_AVAILABLE:
            # Fall back to web_fetch when browser isn't available
            wf = self._get_web_fetch()
            for schema in wf.get_tool_schemas():
                add_tool(schema)

        # Todo tool - always available for task tracking in multi-step work
        todo_tool = self._get_todo_tool()
        for schema in todo_tool.get_tool_schemas():
            add_tool(schema)

        # Ask user tool - available when credentials, input, or confirmation is needed
        ask_user_keywords = [
            "credential", "password", "api key", "token", "login", "authenticate",
            "ask", "prompt", "input", "confirm", "choose", "select", "preference",
            "linkedin", "twitter", "github", "oauth", "auth",
        ]
        if any(kw in desc_lower for kw in ask_user_keywords):
            ask_user_tool = self._get_ask_user_tool()
            add_tool(ask_user_tool.schema)

        return tools


class SubAgentExecutor:
    """
    Executes plan steps using sub-agents.

    Each step gets its own sub-agent with isolated context.
    Steps can be executed in parallel when their dependencies allow.
    """

    def __init__(
        self,
        config: PromethianConfig,
        tool_runner: ToolRunner,
    ):
        self.config = config
        self.tool_runner = tool_runner
        self._usage_stats = UsageStats()  # Accumulated usage from all sub-agents
        self._logger = get_logger()

    @property
    def usage_stats(self) -> UsageStats:
        """Get accumulated usage statistics from all sub-agent executions."""
        return self._usage_stats

    async def execute_step(
        self,
        step: PlanStep,
        plan: Plan,
        previous_outputs: dict[str, Any],
        progress: ProgressTracker | None = None,
    ) -> StepResult:
        """
        Execute a single step using a sub-agent with self-healing retries.

        Args:
            step: The step to execute
            plan: The full plan (for context)
            previous_outputs: Outputs from completed steps
            progress: Optional progress tracker for verbose output

        Returns:
            StepResult with the outcome
        """
        # Create tool executor for custom tools
        tool_executor = ToolExecutor(self.tool_runner, plan.relevant_tools)
        progress = progress or NullProgressTracker()

        healing_log: list[str] = []
        last_error = None
        max_attempts = self.config.max_self_heal_attempts

        for attempt in range(max_attempts):
            # Create and run sub-agent
            sub_agent = StepSubAgent(
                config=self.config,
                step=step,
                plan=plan,
                previous_outputs=previous_outputs,
                tool_executor=tool_executor,
                healing_context=healing_log,
            )

            result = await sub_agent.execute()

            # Merge usage stats from this sub-agent execution
            if result.usage_stats:
                self._usage_stats.merge(result.usage_stats)

            if result.success:
                # Check for ANY tool failures (not just custom tools)
                # A step should fail if critical tools failed
                all_tool_failures = self._extract_all_tool_failures(result.tool_calls_made)

                if all_tool_failures:
                    # Check if this is a recoverable failure or fundamental issue
                    tool_name, error_details, is_recoverable = all_tool_failures[0]
                    last_error = f"Tool '{tool_name}' failed: {error_details}"

                    # Non-recoverable failures (e.g., Playwright not installed) should fail immediately
                    if not is_recoverable:
                        return StepResult(
                            step_id=step.id,
                            status=ExecutionStatus.FAILURE,
                            error=f"Critical tool failure: {last_error}",
                            output=result.output,
                            attempts=attempt + 1,
                            skills_used=step.skills_to_use,
                            tools_used=step.tools_to_use + [tc["tool"] for tc in result.tool_calls_made],
                            healing_log=healing_log if healing_log else None,
                        )

                    # Recoverable failures can be retried
                    if attempt < max_attempts - 1:
                        # Log and emit self-healing progress
                        self._logger.self_heal_start(
                            step_id=step.id,
                            attempt=attempt + 1,
                            max_attempts=max_attempts,
                            error=last_error,
                        )
                        await progress.emit(
                            ProgressStage.SELF_HEALING,
                            f"Self-healing: tool '{tool_name}' failed, analyzing...",
                            attempt=attempt + 1,
                            max_attempts=max_attempts,
                            tool_name=tool_name,
                            error=error_details[:500],  # Show more error context
                        )

                        # Get healing suggestion
                        suggestion = await self._get_healing_suggestion(
                            step=step,
                            tool_name=tool_name,
                            error=error_details,
                            attempt=attempt,
                        )

                        # Log healing suggestion
                        self._logger.self_heal_suggestion(
                            step_id=step.id,
                            attempt=attempt + 1,
                            suggestion=suggestion,
                        )

                        healing_log.append(
                            f"Attempt {attempt + 1} - Tool '{tool_name}' failed: {error_details}\nFix: {suggestion}"
                        )

                        await progress.emit(
                            ProgressStage.HEAL_ATTEMPT,
                            f"Retrying with fix (attempt {attempt + 2}/{max_attempts})...",
                            attempt=attempt + 2,
                            max_attempts=max_attempts,
                            suggestion=suggestion[:500],  # Show more of the fix
                        )
                        continue  # Retry
                    else:
                        # Max attempts reached for recoverable failure
                        return StepResult(
                            step_id=step.id,
                            status=ExecutionStatus.FAILURE,
                            error=f"Failed after {max_attempts} attempts: {last_error}",
                            output=result.output,
                            attempts=attempt + 1,
                            skills_used=step.skills_to_use,
                            tools_used=step.tools_to_use + [tc["tool"] for tc in result.tool_calls_made],
                            healing_log=healing_log if healing_log else None,
                        )

                # Success with no tool failures
                return StepResult(
                    step_id=step.id,
                    status=ExecutionStatus.SUCCESS,
                    output=result.output,
                    attempts=attempt + 1,
                    skills_used=step.skills_to_use,
                    tools_used=step.tools_to_use + [tc["tool"] for tc in result.tool_calls_made],
                    healing_log=healing_log if healing_log else None,
                )
            else:
                # Execution failed entirely
                last_error = result.error

                if attempt < max_attempts - 1:
                    # Emit self-healing progress
                    await progress.emit(
                        ProgressStage.SELF_HEALING,
                        f"Self-healing: step failed, analyzing error...",
                        attempt=attempt + 1,
                        max_attempts=max_attempts,
                        error=result.error[:500] if result.error else "Unknown error",
                    )

                    # Get healing suggestion
                    suggestion = await self._get_healing_suggestion(
                        step=step,
                        tool_name=None,
                        error=result.error or "Unknown error",
                        attempt=attempt,
                    )
                    healing_log.append(
                        f"Attempt {attempt + 1} failed: {result.error}\nFix: {suggestion}"
                    )

                    await progress.emit(
                        ProgressStage.HEAL_ATTEMPT,
                        f"Retrying with fix (attempt {attempt + 2}/{max_attempts})...",
                        attempt=attempt + 2,
                        max_attempts=max_attempts,
                        suggestion=suggestion[:500],
                    )

        # All attempts failed
        return StepResult(
            step_id=step.id,
            status=ExecutionStatus.FAILURE,
            error=last_error,
            attempts=max_attempts,
            skills_used=step.skills_to_use,
            tools_used=step.tools_to_use,
            healing_log=healing_log if healing_log else None,
        )

    def _extract_all_tool_failures(
        self,
        tool_calls_made: list[dict],
    ) -> list[tuple[str, str, bool]]:
        """
        Extract all tool failures (both built-in and custom).

        Returns:
            List of (tool_name, error_details, is_recoverable) tuples.

            is_recoverable=False for fundamental issues like:
            - Playwright not installed
            - Missing system dependencies
            - Invalid URL formats that can't be fixed

            is_recoverable=True for issues that might be fixed by retry:
            - Network timeouts
            - Temporary API errors
            - Code bugs in custom tools
        """
        # Errors that indicate fundamental issues (not recoverable by retry)
        NON_RECOVERABLE_PATTERNS = [
            "playwright not installed",
            "playwright install",
            "browser not available",
            "module not found",
            "no module named",
            "command not found",
            "permission denied",
            "access denied",
            "not installed",
            "missing required",
        ]

        failures = []

        for tc in tool_calls_made:
            tool_name = tc.get("tool")
            result = tc.get("result", {})

            if not result.get("success", True):
                error = result.get("error", "Unknown error")
                stderr = result.get("stderr", "")
                full_error = f"{error}\n{stderr}".strip().lower()

                # Check if this is a non-recoverable failure
                is_recoverable = not any(
                    pattern in full_error for pattern in NON_RECOVERABLE_PATTERNS
                )

                failures.append((tool_name, f"{error}\n{stderr}".strip(), is_recoverable))

        return failures

    async def _get_healing_suggestion(
        self,
        step: PlanStep,
        tool_name: str | None,
        error: str,
        attempt: int,
    ) -> str:
        """Get a healing suggestion from Claude."""
        # Create a temporary Claude client for healing
        claude = ClaudeClient(
            api_key=self.config.anthropic_api_key,
            model=self.config.get_sub_agent_model(),  # Use sub-agent model for healing
            max_tokens=1024,
        )

        if tool_name:
            prompt = f"""A custom tool failed during step execution.

Tool Name: {tool_name}
Step: {step.description}
Error: {error}

This was attempt {attempt + 1}. The tool has a bug.
Analyze the error and suggest a SPECIFIC fix for the tool.
Focus on what code change would fix this bug."""
        else:
            prompt = f"""A step in our plan failed.

Step: {step.description}
Error: {error}

This was attempt {attempt + 1}. Analyze what went wrong and suggest how to fix it."""

        return await claude.complete(prompt=prompt)

    async def execute_steps_parallel(
        self,
        steps: list[PlanStep],
        plan: Plan,
        previous_outputs: dict[str, Any],
    ) -> list[StepResult]:
        """
        Execute multiple steps in parallel (when dependencies allow).

        Args:
            steps: Steps to execute (must have no inter-dependencies)
            plan: The full plan
            previous_outputs: Outputs from completed steps

        Returns:
            List of StepResults
        """
        tasks = [
            self.execute_step(step, plan, previous_outputs)
            for step in steps
        ]
        return await asyncio.gather(*tasks)
