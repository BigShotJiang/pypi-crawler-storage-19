# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListVmsCallbacksMode:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'callbacks': 'list[VmsCallBack]'
    }

    attribute_map = {
        'callbacks': 'callbacks'
    }

    def __init__(self, callbacks=None):
        r"""ListVmsCallbacksMode

        The model defined in huaweicloud sdk

        :param callbacks: 回执接口列表。
        :type callbacks: list[:class:`huaweicloudsdkkoomessage.v1.VmsCallBack`]
        """
        
        

        self._callbacks = None
        self.discriminator = None

        if callbacks is not None:
            self.callbacks = callbacks

    @property
    def callbacks(self):
        r"""Gets the callbacks of this ListVmsCallbacksMode.

        回执接口列表。

        :return: The callbacks of this ListVmsCallbacksMode.
        :rtype: list[:class:`huaweicloudsdkkoomessage.v1.VmsCallBack`]
        """
        return self._callbacks

    @callbacks.setter
    def callbacks(self, callbacks):
        r"""Sets the callbacks of this ListVmsCallbacksMode.

        回执接口列表。

        :param callbacks: The callbacks of this ListVmsCallbacksMode.
        :type callbacks: list[:class:`huaweicloudsdkkoomessage.v1.VmsCallBack`]
        """
        self._callbacks = callbacks

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListVmsCallbacksMode):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
