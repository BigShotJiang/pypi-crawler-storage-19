"""MidTry tests."""
