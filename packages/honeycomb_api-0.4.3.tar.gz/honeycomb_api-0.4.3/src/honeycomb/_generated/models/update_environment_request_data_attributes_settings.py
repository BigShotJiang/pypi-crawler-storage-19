from typing import (TYPE_CHECKING, Any, BinaryIO, Optional, TextIO, TypeVar,
                    Union)

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateEnvironmentRequestDataAttributesSettings")



@_attrs_define
class UpdateEnvironmentRequestDataAttributesSettings:
    """ 
        Attributes:
            delete_protected (Union[Unset, bool]): If true, the environment cannot be deleted.
     """

    delete_protected: Union[Unset, bool] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> dict[str, Any]:
        delete_protected = self.delete_protected


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if delete_protected is not UNSET:
            field_dict["delete_protected"] = delete_protected

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        d = src_dict.copy()
        delete_protected = d.pop("delete_protected", UNSET)

        update_environment_request_data_attributes_settings = cls(
            delete_protected=delete_protected,
        )


        update_environment_request_data_attributes_settings.additional_properties = d
        return update_environment_request_data_attributes_settings

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
