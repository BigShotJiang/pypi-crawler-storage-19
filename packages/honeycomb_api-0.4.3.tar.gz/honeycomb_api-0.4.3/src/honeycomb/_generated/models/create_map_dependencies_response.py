from typing import (TYPE_CHECKING, Any, BinaryIO, Optional, TextIO, TypeVar,
                    Union)

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.create_map_dependencies_response_status import \
    CreateMapDependenciesResponseStatus
from ..types import UNSET, Unset

T = TypeVar("T", bound="CreateMapDependenciesResponse")



@_attrs_define
class CreateMapDependenciesResponse:
    """ Response for a Map Dependency Request.

        Attributes:
            request_id (Union[Unset, str]): Unique identifier for the Map Dependency Request.
                 Example: abc123.
            status (Union[Unset, CreateMapDependenciesResponseStatus]): Status of the Map Dependency Request.
                 Example: pending.
     """

    request_id: Union[Unset, str] = UNSET
    status: Union[Unset, CreateMapDependenciesResponseStatus] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> dict[str, Any]:
        request_id = self.request_id

        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if request_id is not UNSET:
            field_dict["request_id"] = request_id
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        d = src_dict.copy()
        request_id = d.pop("request_id", UNSET)

        _status = d.pop("status", UNSET)
        status: Union[Unset, CreateMapDependenciesResponseStatus]
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = CreateMapDependenciesResponseStatus(_status)




        create_map_dependencies_response = cls(
            request_id=request_id,
            status=status,
        )


        create_map_dependencies_response.additional_properties = d
        return create_map_dependencies_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
