from typing import (TYPE_CHECKING, Any, BinaryIO, Optional, TextIO, TypeVar,
                    cast)

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.marker_create_request_data_type import \
    MarkerCreateRequestDataType
from ..types import UNSET, Unset

if TYPE_CHECKING:
  from ..models.marker_create_request_data_attributes import \
      MarkerCreateRequestDataAttributes
  from ..models.marker_create_request_data_relationships import \
      MarkerCreateRequestDataRelationships





T = TypeVar("T", bound="MarkerCreateRequestData")



@_attrs_define
class MarkerCreateRequestData:
    """ 
        Attributes:
            type_ (MarkerCreateRequestDataType):
            attributes (MarkerCreateRequestDataAttributes):
            relationships (MarkerCreateRequestDataRelationships):
     """

    type_: MarkerCreateRequestDataType
    attributes: 'MarkerCreateRequestDataAttributes'
    relationships: 'MarkerCreateRequestDataRelationships'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> dict[str, Any]:
        from ..models.marker_create_request_data_attributes import \
            MarkerCreateRequestDataAttributes
        from ..models.marker_create_request_data_relationships import \
            MarkerCreateRequestDataRelationships
        type_ = self.type_.value

        attributes = self.attributes.to_dict()

        relationships = self.relationships.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "attributes": attributes,
            "relationships": relationships,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        from ..models.marker_create_request_data_attributes import \
            MarkerCreateRequestDataAttributes
        from ..models.marker_create_request_data_relationships import \
            MarkerCreateRequestDataRelationships
        d = src_dict.copy()
        type_ = MarkerCreateRequestDataType(d.pop("type"))




        attributes = MarkerCreateRequestDataAttributes.from_dict(d.pop("attributes"))




        relationships = MarkerCreateRequestDataRelationships.from_dict(d.pop("relationships"))




        marker_create_request_data = cls(
            type_=type_,
            attributes=attributes,
            relationships=relationships,
        )


        marker_create_request_data.additional_properties = d
        return marker_create_request_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
