from typing import (TYPE_CHECKING, Any, BinaryIO, Optional, TextIO, TypeVar,
                    cast)

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
  from ..models.update_pipeline_configuration_rollout import \
      UpdatePipelineConfigurationRollout





T = TypeVar("T", bound="UpdatePipelineConfigurationRolloutResponse")



@_attrs_define
class UpdatePipelineConfigurationRolloutResponse:
    """ 
        Attributes:
            data (UpdatePipelineConfigurationRollout):
     """

    data: 'UpdatePipelineConfigurationRollout'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)


    def to_dict(self) -> dict[str, Any]:
        from ..models.update_pipeline_configuration_rollout import \
            UpdatePipelineConfigurationRollout
        data = self.data.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "data": data,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: dict[str, Any]) -> T:
        from ..models.update_pipeline_configuration_rollout import \
            UpdatePipelineConfigurationRollout
        d = src_dict.copy()
        data = UpdatePipelineConfigurationRollout.from_dict(d.pop("data"))




        update_pipeline_configuration_rollout_response = cls(
            data=data,
        )


        update_pipeline_configuration_rollout_response.additional_properties = d
        return update_pipeline_configuration_rollout_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
