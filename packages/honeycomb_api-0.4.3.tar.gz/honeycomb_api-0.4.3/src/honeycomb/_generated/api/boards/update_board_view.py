from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.board_view_response import BoardViewResponse
from ...models.detailed_error import DetailedError
from ...models.error import Error
from ...models.update_board_view_request import UpdateBoardViewRequest
from ...models.validation_error import ValidationError
from ...types import UNSET, Response


def _get_kwargs(
    board_id: str,
    view_id: str,
    *,
    body: UpdateBoardViewRequest,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/1/boards/{board_id}/views/{view_id}".format(board_id=board_id,view_id=view_id,),
    }

    _body = body.to_dict()


    _kwargs["json"] = _body
    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[BoardViewResponse, DetailedError, Error, ValidationError]]:
    if response.status_code == 200:
        response_200 = BoardViewResponse.from_dict(response.json())



        return response_200
    if response.status_code == 400:
        response_400 = DetailedError.from_dict(response.json())



        return response_400
    if response.status_code == 401:
        response_401 = Error.from_dict(response.json())



        return response_401
    if response.status_code == 404:
        response_404 = Error.from_dict(response.json())



        return response_404
    if response.status_code == 409:
        response_409 = Error.from_dict(response.json())



        return response_409
    if response.status_code == 422:
        response_422 = ValidationError.from_dict(response.json())



        return response_422
    if response.status_code == 429:
        response_429 = Error.from_dict(response.json())



        return response_429
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[BoardViewResponse, DetailedError, Error, ValidationError]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    board_id: str,
    view_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateBoardViewRequest,

) -> Response[Union[BoardViewResponse, DetailedError, Error, ValidationError]]:
    """ Update a Board View

     Update a Board View by specifying its ID and full details.

    Args:
        board_id (str):
        view_id (str):
        body (UpdateBoardViewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[BoardViewResponse, DetailedError, Error, ValidationError]]
     """


    kwargs = _get_kwargs(
        board_id=board_id,
view_id=view_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    board_id: str,
    view_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateBoardViewRequest,

) -> Optional[Union[BoardViewResponse, DetailedError, Error, ValidationError]]:
    """ Update a Board View

     Update a Board View by specifying its ID and full details.

    Args:
        board_id (str):
        view_id (str):
        body (UpdateBoardViewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[BoardViewResponse, DetailedError, Error, ValidationError]
     """


    return sync_detailed(
        board_id=board_id,
view_id=view_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    board_id: str,
    view_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateBoardViewRequest,

) -> Response[Union[BoardViewResponse, DetailedError, Error, ValidationError]]:
    """ Update a Board View

     Update a Board View by specifying its ID and full details.

    Args:
        board_id (str):
        view_id (str):
        body (UpdateBoardViewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[BoardViewResponse, DetailedError, Error, ValidationError]]
     """


    kwargs = _get_kwargs(
        board_id=board_id,
view_id=view_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    board_id: str,
    view_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateBoardViewRequest,

) -> Optional[Union[BoardViewResponse, DetailedError, Error, ValidationError]]:
    """ Update a Board View

     Update a Board View by specifying its ID and full details.

    Args:
        board_id (str):
        view_id (str):
        body (UpdateBoardViewRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[BoardViewResponse, DetailedError, Error, ValidationError]
     """


    return (await asyncio_detailed(
        board_id=board_id,
view_id=view_id,
client=client,
body=body,

    )).parsed
