"""Biathlon CLI package."""
