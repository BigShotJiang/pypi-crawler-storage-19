"""Command-line interface for pinviz."""

import argparse
import asyncio
import sys
from pathlib import Path
from typing import Any

from rich_argparse import RichHelpFormatter

from .config_loader import load_diagram
from .logging_config import configure_logging, get_logger
from .model import Diagram
from .render_svg import SVGRenderer
from .validation import DiagramValidator, ValidationLevel


class CustomHelpFormatter(RichHelpFormatter):
    """Custom formatter that preserves epilog formatting."""

    # Class variable to store the original epilog
    original_epilog = None

    def format_help(self):
        """Override to handle epilog separately."""
        # Get the normal formatted help
        help_text = super().format_help()

        # If there's an epilog that got wrapped, replace it with the original
        if CustomHelpFormatter.original_epilog and "Examples:" in help_text:
            # Split at "Examples:" and replace everything after
            parts = help_text.split("Examples:", 1)
            if len(parts) == 2:
                # Add back our properly formatted epilog
                help_text = parts[0] + CustomHelpFormatter.original_epilog

        return help_text


# Get version from package metadata
try:
    from importlib.metadata import version

    __version__ = version("pinviz")
except Exception:
    __version__ = "unknown"


def main() -> int:
    """Main CLI entry point."""

    # Define custom epilog with examples
    # Using a more compact format that works better with formatters
    epilog = "\n".join(
        [
            "Examples:",
            "  pinviz render diagram.yaml                     # Generate diagram from YAML config",
            "  pinviz render diagram.yaml -o out/wiring.svg   # Specify output path",
            "  pinviz validate diagram.yaml                   # Validate wiring configuration",
            "  pinviz example bh1750                          # Use a built-in example",
            "  pinviz list                                     # List available templates",
            "  pinviz add-device                              # Create a new device interactively",
            "  pinviz validate-devices                        # Validate all device configs",
            "",
            "For more information, visit: https://github.com/nordstad/PinViz",
        ]
    )

    # Store epilog in formatter class for later use
    CustomHelpFormatter.original_epilog = epilog

    parser = argparse.ArgumentParser(
        prog="pinviz",
        description="Generate Raspberry Pi GPIO connection diagrams",
        formatter_class=CustomHelpFormatter,
        epilog=epilog,
    )

    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    # Global logging options
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        default="WARNING",
        help="Set logging verbosity (default: WARNING)",
    )
    parser.add_argument(
        "--log-format",
        choices=["json", "console"],
        default="console",
        help="Log output format: json (machine-readable) or console (human-readable)",
    )

    subparsers = parser.add_subparsers(
        dest="command",
        title="Commands",
        metavar="COMMAND",
        required=True,
    )

    # Main render command
    render_parser = subparsers.add_parser(
        "render",
        help="Render a diagram from a configuration file",
        description="Render a diagram from a YAML or JSON configuration file",
    )
    render_parser.add_argument(
        "config",
        metavar="CONFIG_FILE",
        help="Path to YAML or JSON configuration file",
    )
    render_parser.add_argument(
        "-o",
        "--output",
        metavar="PATH",
        help="Output SVG file path (default: <config>.svg)",
    )
    render_parser.add_argument(
        "--no-title",
        action="store_true",
        help="Hide the diagram title in the SVG output",
    )
    render_parser.add_argument(
        "--no-board-name",
        action="store_true",
        help="Hide the board name in the SVG output",
    )

    # Example command
    example_parser = subparsers.add_parser(
        "example",
        help="Generate a built-in example diagram",
        description="Generate one of the built-in example diagrams",
    )
    example_parser.add_argument(
        "name",
        metavar="NAME",
        choices=["bh1750", "ir_led", "i2c_spi"],
        help="Example name: bh1750, ir_led, i2c_spi",
    )
    example_parser.add_argument(
        "-o",
        "--output",
        metavar="PATH",
        help="Output SVG file path (default: ./out/<name>.svg)",
    )
    example_parser.add_argument(
        "--no-title",
        action="store_true",
        help="Hide the diagram title in the SVG output",
    )
    example_parser.add_argument(
        "--no-board-name",
        action="store_true",
        help="Hide the board name in the SVG output",
    )

    # Validate command
    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate a diagram configuration",
        description="Check for wiring mistakes, pin conflicts, and compatibility issues",
    )
    validate_parser.add_argument(
        "config",
        metavar="CONFIG_FILE",
        help="Path to YAML or JSON configuration file",
    )
    validate_parser.add_argument(
        "--strict",
        action="store_true",
        help="Treat warnings as errors (exit with error code if warnings found)",
    )

    # List command
    subparsers.add_parser(
        "list",
        help="List available board and device templates",
        description="List all available board models, device templates, and examples",
    )

    # Add-device command
    subparsers.add_parser(
        "add-device",
        help="Interactive wizard to create a new device configuration",
        description="Launch an interactive wizard to create a new device configuration file",
    )

    # Validate-devices command
    validate_devices_parser = subparsers.add_parser(
        "validate-devices",
        help="Validate all device configuration files",
        description="Check all device JSON files for errors and common issues",
    )
    validate_devices_parser.add_argument(
        "--strict",
        action="store_true",
        help="Treat warnings as errors (exit with error code if warnings found)",
    )

    args = parser.parse_args()

    # Configure logging based on CLI arguments
    configure_logging(level=args.log_level, format=args.log_format)
    log = get_logger(__name__)

    log.debug("cli_started", command=args.command, args=vars(args))

    # Handle commands
    if args.command == "render":
        return render_command(args)
    elif args.command == "example":
        return example_command(args)
    elif args.command == "validate":
        return validate_command(args)
    elif args.command == "list":
        return list_command()
    elif args.command == "add-device":
        return add_device_command()
    elif args.command == "validate-devices":
        return validate_devices_command(args)
    else:
        parser.print_help()
        return 1


def _apply_cli_flags(diagram: Diagram, args: Any) -> None:
    """Apply CLI flags to diagram visibility settings.

    Args:
        diagram: Diagram to modify
        args: CLI arguments containing flag values
    """
    if hasattr(args, "no_title") and args.no_title:
        diagram.show_title = False
    if hasattr(args, "no_board_name") and args.no_board_name:
        diagram.show_board_name = False


def _render_diagram(diagram: Diagram, output_path: Path) -> None:
    """Render diagram to SVG file with status messages.

    Args:
        diagram: Diagram to render
        output_path: Path where SVG will be saved
    """
    log = get_logger(__name__)

    log.info("rendering_started", output_path=str(output_path))
    print(f"Rendering diagram to {output_path}...")
    renderer = SVGRenderer()
    renderer.render(diagram, output_path)

    log.info("diagram_generated", output_path=str(output_path))
    print(f"✓ Diagram generated successfully: {output_path}")


def render_command(args: Any) -> int:
    """Render a diagram from a configuration file."""
    log = get_logger(__name__)
    config_path = Path(args.config)

    if not config_path.exists():
        log.error(
            "config_file_not_found",
            config_path=str(config_path),
            cwd=str(Path.cwd()),
        )
        print(f"Error: Configuration file not found: {config_path}", file=sys.stderr)
        return 1

    # Determine output path
    output_path = Path(args.output) if args.output else config_path.with_suffix(".svg")

    # Create output directory if needed
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        log.info("loading_config", config_path=str(config_path))
        print(f"Loading configuration from {config_path}...")
        diagram = load_diagram(config_path)

        log.debug(
            "config_loaded",
            device_count=len(diagram.devices),
            connection_count=len(diagram.connections),
            board=diagram.board.name,
        )

        # Apply CLI flags for visibility
        _apply_cli_flags(diagram, args)

        # Validate diagram and show warnings
        validator = DiagramValidator()
        issues = validator.validate(diagram)

        if issues:
            print("\nValidation Issues:")
            errors = [i for i in issues if i.level == ValidationLevel.ERROR]
            warnings = [i for i in issues if i.level == ValidationLevel.WARNING]
            infos = [i for i in issues if i.level == ValidationLevel.INFO]

            log.info(
                "validation_completed",
                total_issues=len(issues),
                errors=len(errors),
                warnings=len(warnings),
                infos=len(infos),
            )

            for issue in errors:
                print(f"  {issue}")
            for issue in warnings:
                print(f"  {issue}")
            for issue in infos:
                print(f"  {issue}")

            if errors:
                log.error("validation_failed", error_count=len(errors))
                print(f"\n❌ Found {len(errors)} error(s). Cannot generate diagram.")
                return 1

            if warnings:
                log.warning("validation_warnings", warning_count=len(warnings))
                print(f"\n⚠️  Found {len(warnings)} warning(s). Review your wiring carefully.")
            print()

        _render_diagram(diagram, output_path)
        return 0

    except Exception as e:
        log.exception(
            "render_failed",
            config_path=str(config_path),
            output_path=str(output_path),
            error_type=type(e).__name__,
            error_message=str(e),
        )
        print(f"Error: {e}", file=sys.stderr)
        return 1


def validate_command(args: Any) -> int:
    """Validate a diagram configuration."""
    log = get_logger(__name__)
    config_path = Path(args.config)

    if not config_path.exists():
        log.error(
            "config_file_not_found",
            config_path=str(config_path),
            cwd=str(Path.cwd()),
        )
        print(f"Error: Configuration file not found: {config_path}", file=sys.stderr)
        return 1

    try:
        log.info("validation_started", config_path=str(config_path), strict_mode=args.strict)
        print(f"Validating configuration: {config_path}")
        diagram = load_diagram(config_path)

        log.debug(
            "config_loaded",
            device_count=len(diagram.devices),
            connection_count=len(diagram.connections),
        )

        validator = DiagramValidator()
        issues = validator.validate(diagram)

        if not issues:
            log.info("validation_passed", config_path=str(config_path))
            print("\n✓ Validation passed! No issues found.")
            print("✓ Current limits OK")
            return 0

        # Categorize issues
        errors = [i for i in issues if i.level == ValidationLevel.ERROR]
        warnings = [i for i in issues if i.level == ValidationLevel.WARNING]
        infos = [i for i in issues if i.level == ValidationLevel.INFO]

        log.info(
            "validation_issues_found",
            total_issues=len(issues),
            errors=len(errors),
            warnings=len(warnings),
            infos=len(infos),
        )

        # Display all issues
        print()
        for issue in errors:
            print(issue)
        for issue in warnings:
            print(issue)
        for issue in infos:
            print(issue)

        # Summary
        print()
        error_count = len(errors)
        warning_count = len(warnings)

        if error_count > 0 or warning_count > 0:
            print(f"Found {error_count} error(s), {warning_count} warning(s)")

        # Return appropriate exit code
        if errors:
            log.error("validation_failed", error_count=error_count)
            return 1
        if warnings and args.strict:
            log.warning("strict_mode_warnings_as_errors", warning_count=warning_count)
            print("\n❌ Treating warnings as errors (--strict mode)")
            return 1

        log.info("validation_completed_with_warnings", warning_count=warning_count)
        return 0

    except Exception as e:
        log.exception(
            "validation_error",
            config_path=str(config_path),
            error_type=type(e).__name__,
            error_message=str(e),
        )
        print(f"Error: {e}", file=sys.stderr)
        return 1


def example_command(args: Any) -> int:
    """Generate a built-in example diagram."""
    log = get_logger(__name__)

    # Determine output path
    if args.output:
        output_path = Path(args.output)
    else:
        output_dir = Path("./out")
        output_dir.mkdir(exist_ok=True)
        output_path = output_dir / f"{args.name}.svg"

    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        log.info("example_generation_started", example_name=args.name, output_path=str(output_path))
        print(f"Generating example diagram: {args.name}")

        # Create the example diagram
        if args.name == "bh1750":
            diagram = create_bh1750_example()
        elif args.name == "ir_led":
            diagram = create_ir_led_example()
        elif args.name == "i2c_spi":
            diagram = create_i2c_spi_example()
        else:
            log.error("unknown_example", example_name=args.name)
            print(f"Error: Unknown example: {args.name}", file=sys.stderr)
            return 1

        log.debug(
            "example_diagram_created",
            device_count=len(diagram.devices),
            connection_count=len(diagram.connections),
        )

        # Apply CLI flags for visibility
        _apply_cli_flags(diagram, args)

        # Validate diagram before rendering
        validator = DiagramValidator()
        issues = validator.validate(diagram)

        if issues:
            errors = [i for i in issues if i.level == ValidationLevel.ERROR]
            warnings = [i for i in issues if i.level == ValidationLevel.WARNING]
            infos = [i for i in issues if i.level == ValidationLevel.INFO]

            log.info(
                "validation_completed",
                total_issues=len(issues),
                errors=len(errors),
                warnings=len(warnings),
                infos=len(infos),
            )

            # Show validation issues
            if errors or warnings or infos:
                print("\nValidation Issues:")
                for issue in errors:
                    print(f"  {issue}")
                for issue in warnings:
                    print(f"  {issue}")
                for issue in infos:
                    print(f"  {issue}")

            # Fail on errors
            if errors:
                log.error("example_validation_failed", error_count=len(errors))
                print(f"\n❌ Found {len(errors)} error(s). Cannot generate example diagram.")
                return 1

            if warnings:
                log.warning("example_validation_warnings", warning_count=len(warnings))
                print(f"\n⚠️  Found {len(warnings)} warning(s). Review the example carefully.")
            print()

        log.info("rendering_example", output_path=str(output_path))
        _render_diagram(diagram, output_path)

        log.info("example_generated", example_name=args.name, output_path=str(output_path))
        return 0

    except Exception as e:
        log.exception(
            "example_generation_failed",
            example_name=args.name,
            output_path=str(output_path),
            error_type=type(e).__name__,
            error_message=str(e),
        )
        print(f"Error: {e}", file=sys.stderr)
        return 1


def list_command() -> int:
    """List available templates."""
    log = get_logger(__name__)
    from .devices import get_registry

    log.info("listing_templates")

    print("Available Boards:")
    print("  - raspberry_pi_5 (aliases: rpi5, rpi)")
    print()

    # List devices by category
    registry = get_registry()
    categories = registry.get_categories()

    log.debug("device_categories_found", category_count=len(categories))

    print("Available Device Templates:")
    for category in categories:
        devices = registry.list_by_category(category)
        print(f"\n  {category.title()}:")
        for device in devices:
            if device.url:
                print(f"    - {device.type_id}: {device.description}")
                print(f"      📖 {device.url}")
            else:
                print(f"    - {device.type_id}: {device.description}")

    print()
    print("Available Examples:")
    print("  - bh1750: BH1750 light sensor connected via I2C")
    print("  - ir_led: IR LED ring connected to GPIO")
    print("  - i2c_spi: Multiple I2C and SPI devices")
    print()

    log.info("templates_listed")
    return 0


def add_device_command() -> int:
    """Launch interactive device wizard."""
    log = get_logger(__name__)
    from .device_wizard import main as wizard_main

    log.info("device_wizard_started")

    try:
        # Run the async wizard
        return asyncio.run(wizard_main())
    except KeyboardInterrupt:
        print("\n\n❌ Wizard cancelled by user.")
        log.info("device_wizard_cancelled")
        return 1
    except Exception as e:
        log.exception("device_wizard_error", error_type=type(e).__name__, error_message=str(e))
        print(f"Error: {e}", file=sys.stderr)
        return 1


def validate_devices_command(args: Any) -> int:
    """Validate all device configuration files."""
    log = get_logger(__name__)
    from .device_validator import validate_devices

    log.info("device_validation_started", strict_mode=args.strict)
    print("Validating device configurations...")
    print()

    try:
        result = validate_devices()

        log.debug(
            "validation_completed",
            total_files=result.total_files,
            valid_files=result.valid_files,
            errors=result.error_count,
            warnings=result.warning_count,
        )

        # Display errors
        if result.errors:
            print("Errors:")
            for error in result.errors:
                print(f"  {error}")
            print()

        # Display warnings
        if result.warnings:
            print("Warnings:")
            for warning in result.warnings:
                print(f"  {warning}")
            print()

        # Summary
        print(f"Scanned {result.total_files} device configuration files")
        print(f"Valid: {result.valid_files}")

        if result.error_count > 0:
            print(f"Errors: {result.error_count}")
        if result.warning_count > 0:
            print(f"Warnings: {result.warning_count}")

        # Exit codes
        if result.has_errors:
            log.error("validation_failed", error_count=result.error_count)
            print("\n❌ Validation failed with errors")
            return 1

        if result.has_warnings and args.strict:
            log.warning("strict_mode_warnings_as_errors", warning_count=result.warning_count)
            print("\n❌ Validation failed: warnings in strict mode")
            return 1

        if result.has_warnings:
            log.info("validation_completed_with_warnings", warning_count=result.warning_count)
            print("\n⚠️  Validation completed with warnings")
            return 0

        log.info("validation_passed")
        print("\n✓ All device configurations are valid!")
        return 0

    except Exception as e:
        log.exception(
            "validation_error",
            error_type=type(e).__name__,
            error_message=str(e),
        )
        print(f"Error during validation: {e}", file=sys.stderr)
        return 1


def create_bh1750_example():
    """Create BH1750 example diagram."""
    from . import boards
    from .devices import get_registry
    from .model import Connection, Diagram

    board = boards.raspberry_pi_5()
    registry = get_registry()
    sensor = registry.create("bh1750")

    connections = [
        Connection(1, "BH1750 Light Sensor", "VCC"),  # 3V3 to VCC
        Connection(6, "BH1750 Light Sensor", "GND"),  # GND to GND
        Connection(5, "BH1750 Light Sensor", "SCL"),  # GPIO3/SCL to SCL
        Connection(3, "BH1750 Light Sensor", "SDA"),  # GPIO2/SDA to SDA
    ]

    return Diagram(
        title="BH1750 Light Sensor Wiring",
        board=board,
        devices=[sensor],
        connections=connections,
    )


def create_ir_led_example() -> Diagram:
    """Create IR LED ring example diagram."""
    from . import boards
    from .devices import get_registry
    from .model import Connection, Diagram

    board = boards.raspberry_pi_5()
    registry = get_registry()
    ir_led = registry.create("ir_led_ring", num_leds=12)

    connections = [
        Connection(2, "IR LED Ring (12)", "VCC"),  # 5V to VCC
        Connection(6, "IR LED Ring (12)", "GND"),  # GND to GND
        Connection(7, "IR LED Ring (12)", "CTRL"),  # GPIO4 to CTRL
    ]

    return Diagram(
        title="IR LED Ring Wiring",
        board=board,
        devices=[ir_led],
        connections=connections,
    )


def create_i2c_spi_example():
    """Create example with multiple I2C and SPI devices."""
    from . import boards
    from .devices import get_registry
    from .model import Connection, Diagram

    board = boards.raspberry_pi_5()
    registry = get_registry()

    bh1750 = registry.create("bh1750")
    spi_device = registry.create("spi_device", name="OLED Display")
    led = registry.create("led", color_name="Red")

    connections = [
        # BH1750 I2C sensor
        Connection(1, "BH1750 Light Sensor", "VCC"),
        Connection(9, "BH1750 Light Sensor", "GND"),
        Connection(5, "BH1750 Light Sensor", "SCL"),
        Connection(3, "BH1750 Light Sensor", "SDA"),
        # SPI OLED display
        Connection(17, "OLED Display", "VCC"),
        Connection(20, "OLED Display", "GND"),
        Connection(23, "OLED Display", "SCLK"),
        Connection(19, "OLED Display", "MOSI"),
        Connection(21, "OLED Display", "MISO"),
        Connection(24, "OLED Display", "CS"),
        # Simple LED
        Connection(11, "Red LED", "+"),  # GPIO17
        Connection(14, "Red LED", "-"),
    ]

    return Diagram(
        title="I2C and SPI Devices Example",
        board=board,
        devices=[bh1750, spi_device, led],
        connections=connections,
    )


if __name__ == "__main__":
    sys.exit(main())
