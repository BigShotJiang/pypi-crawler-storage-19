smf-mcp[elasticsearch]>={version}
