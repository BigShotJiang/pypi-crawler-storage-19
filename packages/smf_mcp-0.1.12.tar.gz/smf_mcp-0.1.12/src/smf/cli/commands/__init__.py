"""SMF CLI command implementations."""
