"""Templates for init command."""
