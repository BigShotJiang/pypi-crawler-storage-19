"""Pytest fixtures for Midjourney Proxy MCP tests."""

import os
from pathlib import Path

import pytest


def _load_env_file() -> None:
    """프로젝트 루트의 .env 파일에서 환경변수 로드."""
    env_file = Path(__file__).parent.parent / ".env"
    if not env_file.exists():
        return

    for line in env_file.read_text().strip().split("\n"):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        if key not in os.environ:
            os.environ[key] = value


_load_env_file()

# Unit 테스트용 더미 토큰 설정 (HTTP 호출은 pytest-httpx가 mock)
if "IMAGINEAPI_TOKEN" not in os.environ:
    os.environ["IMAGINEAPI_TOKEN"] = "test-dummy-token"


def pytest_configure(config: pytest.Config) -> None:
    """pytest 설정 시 integration 마커 정의."""
    config.addinivalue_line(
        "markers",
        "integration: 실제 ImagineAPI 호출 테스트 (IMAGINEAPI_TOKEN 필요)",
    )


def pytest_collection_modifyitems(
    config: pytest.Config,
    items: list[pytest.Item],  # noqa: ARG001
) -> None:
    """토큰이 없으면 integration 테스트 자동 skip."""
    if os.environ.get("IMAGINEAPI_TOKEN"):
        return

    skip_integration = pytest.mark.skip(reason="IMAGINEAPI_TOKEN 환경변수가 설정되지 않음")
    for item in items:
        if "integration" in item.keywords:
            item.add_marker(skip_integration)


@pytest.fixture
def sample_image_data() -> dict:
    """Sample image data for testing."""
    return {
        "id": "test-123",
        "prompt": "A beautiful sunset",
        "status": "pending",
        "result": None,
        "url": None,
        "results": None,
        "progress": None,
        "upscaled_urls": None,
        "upscaled": None,
        "ref": None,
        "error": None,
        "user_created": "user-abc",
        "date_created": "2024-01-01T00:00:00Z",
    }


@pytest.fixture
def completed_image_data() -> dict:
    """Completed image data for testing."""
    return {
        "id": "test-456",
        "prompt": "A majestic mountain",
        "status": "completed",
        "result": "https://cdn.imagineapi.dev/images/test.png",
        "url": "https://cdn.imagineapi.dev/images/test.png",
        "results": None,
        "progress": 100,
        "upscaled_urls": [
            "https://cdn.imagineapi.dev/images/test-u1.png",
            "https://cdn.imagineapi.dev/images/test-u2.png",
        ],
        "upscaled": ["u1-id", "u2-id"],
        "ref": "my-ref-123",
        "error": None,
        "user_created": "user-xyz",
        "date_created": "2024-01-01T00:00:00Z",
    }
