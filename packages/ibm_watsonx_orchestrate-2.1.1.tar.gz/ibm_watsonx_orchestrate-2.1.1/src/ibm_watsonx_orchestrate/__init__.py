#  -----------------------------------------------------------------------------------------
#  (C) Copyright IBM Corp. 2023-2024.
#  https://opensource.org/licenses/BSD-3-Clause
#  -----------------------------------------------------------------------------------------

pkg_name = "ibm-watsonx-orchestrate"


__version__ = "2.1.1"



from ibm_watsonx_orchestrate.utils.logging.logger import setup_logging

setup_logging()

