from __future__ import annotations

from django.db import models


class NotificationChannel(models.Model):
	TYPE_SLACK = "slack"
	TYPE_WEBHOOK = "webhook"
	TYPE_SMTP = "email"
	TYPE_CHOICES = [
		(TYPE_SLACK, "Slack"),
		(TYPE_WEBHOOK, "Webhook"),
		(TYPE_SMTP, "Email (SMTP)"),
	]

	name = models.CharField(max_length=200, unique=True)
	channel_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
	config = models.JSONField(default=dict)
	is_active = models.BooleanField(default=True)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self) -> str:
		return f"{self.name} ({self.channel_type})"


class DataSource(models.Model):
	CONNECTOR_POSTGRES = "postgres"
	CONNECTOR_MYSQL = "mysql"
	CONNECTOR_SQLSERVER = "sqlserver"
	CONNECTOR_MONGODB = "mongodb"

	name = models.CharField(max_length=200)
	connector_type = models.CharField(max_length=50)
	connector_config = models.JSONField(default=dict)
	topic = models.CharField(max_length=200, blank=True, default="")
	status = models.CharField(max_length=50, blank=True, default="")
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self) -> str:
		return self.name


class Rule(models.Model):
	name = models.CharField(max_length=200, unique=True)
	description = models.TextField(blank=True, default="")
	is_active = models.BooleanField(default=True)

	# Data source configuration
	datasource = models.ForeignKey(DataSource, on_delete=models.CASCADE, related_name="rules", null=True, blank=True)
	schema_name = models.CharField(max_length=200, blank=True, default="")
	table_name = models.CharField(max_length=200, blank=True, default="")
	object_type = models.CharField(max_length=20, default="table", choices=[("table", "Table"), ("view", "View")])
	# For views: store the base tables that we need to monitor
	base_tables = models.JSONField(default=list, blank=True)

	# Filters and conditions
	filters = models.JSONField(default=list, blank=True)
	condition = models.JSONField(default=dict)

	# Log retention
	log_retention_days = models.PositiveIntegerField(default=30)

	# Notification channels (stored as JSON for alert-specific channel configs)
	notification_channels = models.JSONField(default=list, blank=True)
	target_channels = models.ManyToManyField(NotificationChannel, related_name="rules", blank=True)

	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self) -> str:
		return self.name


class TriggerLog(models.Model):
	STATUS_SUCCESS = "success"
	STATUS_FILTER_ONLY = "filter_only"
	STATUS_FAILED = "failed"
	STATUS_CHOICES = [
		(STATUS_SUCCESS, "Success"),
		(STATUS_FILTER_ONLY, "Filter Only"),
		(STATUS_FAILED, "Failed"),
	]

	rule = models.ForeignKey(Rule, on_delete=models.CASCADE, related_name="trigger_logs")
	event = models.JSONField(default=dict)
	dispatch_results = models.JSONField(default=dict)
	status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_SUCCESS)
	error_message = models.TextField(blank=True, default="")
	created_at = models.DateTimeField(auto_now_add=True)

	def __str__(self) -> str:
		return f"{self.rule_id} {self.status} {self.created_at.isoformat()}"


class CDCEvent(models.Model):
	"""Stores CDC events for the Watch Live UI feature."""
	rule = models.ForeignKey(Rule, on_delete=models.CASCADE, related_name="cdc_events")
	stage = models.CharField(max_length=50)  # received, filter, condition, notification
	event_data = models.JSONField(default=dict)
	created_at = models.DateTimeField(auto_now_add=True)

	class Meta:
		ordering = ['-created_at']
		indexes = [
			models.Index(fields=['rule', '-created_at']),
		]

	def __str__(self) -> str:
		return f"Rule {self.rule_id} - {self.stage} @ {self.created_at.isoformat()}"


class RestApiTestLog(models.Model):
	"""Stores incoming requests to the mock REST API test endpoint."""
	method = models.CharField(max_length=10)  # GET, POST, PUT, PATCH, DELETE
	path = models.CharField(max_length=500)
	query_params = models.JSONField(default=dict)
	headers = models.JSONField(default=dict)
	body = models.TextField(blank=True, default="")
	body_json = models.JSONField(default=dict, blank=True, null=True)
	source_ip = models.CharField(max_length=50, blank=True, default="")
	response_status = models.IntegerField(default=200)
	created_at = models.DateTimeField(auto_now_add=True)

	class Meta:
		ordering = ['-created_at']
		indexes = [
			models.Index(fields=['-created_at']),
		]

	def __str__(self) -> str:
		return f"{self.method} {self.path} @ {self.created_at.isoformat()}"


