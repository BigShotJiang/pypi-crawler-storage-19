# needed for package discovery
