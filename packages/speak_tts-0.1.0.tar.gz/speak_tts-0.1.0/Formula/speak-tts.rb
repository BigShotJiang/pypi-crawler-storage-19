class SpeakTts < Formula
  include Language::Python::Virtualenv

  desc "Voice cloning CLI for Mac using F5-TTS"
  homepage "https://github.com/danielsinai/speak-tts"
  url "https://files.pythonhosted.org/packages/source/s/speak-tts/speak_tts-0.1.0.tar.gz"
  sha256 "REPLACE_WITH_ACTUAL_SHA256"
  license "MIT"

  depends_on "python@3.12"
  depends_on :macos
  depends_on arch: :arm64

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match "Voice cloning CLI", shell_output("#{bin}/speak --help")
  end
end
