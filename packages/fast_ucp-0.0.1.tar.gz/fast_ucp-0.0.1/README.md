# fast-ucp

Fast UCP Library for Python.

## Installation

```bash
pip install fast-ucp
```
