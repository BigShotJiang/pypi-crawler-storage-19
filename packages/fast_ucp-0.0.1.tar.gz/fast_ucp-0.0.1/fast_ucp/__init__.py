"""Fast UCP Library for Python."""

__version__ = "0.0.1"
