"""
Data models for reports.

Defines ReportSpec, ReportResult, and related structures.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ReportCategory(str, Enum):
    """Report category tags."""

    SAFE = "safe"  # Safe inventory, analysis
    ACCOUNT = "acct"  # Account management, compliance
    USER = "user"  # User population, activity
    PERMISSION = "perm"  # Access rights, ownership
    SESSION = "sess"  # PSM sessions, recordings
    RECORDING = "rec"  # Recording analysis
    SECURITY = "sec"  # Security assessments
    COMPLIANCE = "comp"  # Compliance checks
    PERFORMANCE = "perf"  # Performance metrics
    AUDIT = "audit"  # Audit trail, logs
    CPM = "cpm"  # CPM status, password management
    PLATFORM = "plat"  # Platform/policy analysis


class ReportStatus(str, Enum):
    """Report execution status."""

    NOT_STARTED = "not_started"
    RUNNING = "running"
    COMPLETED = "completed"
    BLOCKED = "blocked"
    ERROR = "error"


@dataclass
class ReportSpec:
    """
    Specification for a single report.

    Attributes:
        id: Unique report ID (e.g., "SAFE-001")
        title: Human-readable title
        description: What the report shows and why it's useful
        category: Primary category tag
        sql: SQL SELECT statement (no CREATE TABLE wrapper)
        output_table: Default output table name
        depends_on_tables: List of required source tables
        depends_on_columns: Dict of table -> required columns
        tags: Additional category tags
        priority: Execution priority (1=high, 3=low)
        chart_type: Suggested Superset chart type
        implemented: Whether the SQL is ready
    """

    id: str
    title: str
    description: str
    category: ReportCategory
    sql: str
    output_table: str = ""
    depends_on_tables: list[str] = field(default_factory=list)
    depends_on_columns: dict[str, list[str]] = field(default_factory=dict)
    tags: list[str] = field(default_factory=list)
    priority: int = 2
    chart_type: str = "table"
    implemented: bool = True

    def __post_init__(self) -> None:
        """Auto-generate output table name if not provided."""
        if not self.output_table:
            # SAFE-001 -> safe_001_<sanitized_title>
            prefix = self.id.lower().replace("-", "_")
            title_part = self.title.lower()[:30]
            title_part = "".join(c if c.isalnum() else "_" for c in title_part)
            title_part = "_".join(p for p in title_part.split("_") if p)
            self.output_table = f"{prefix}_{title_part}"

    @property
    def all_tags(self) -> list[str]:
        """Get all tags including category."""
        return [self.category.value] + self.tags

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "category": self.category.value,
            "output_table": self.output_table,
            "tags": self.all_tags,
            "priority": self.priority,
            "chart_type": self.chart_type,
            "implemented": self.implemented,
            "depends_on_tables": self.depends_on_tables,
            "sql": self.sql,
        }


@dataclass
class ReportResult:
    """Result of running a single report."""

    report_id: str
    status: ReportStatus
    row_count: int = 0
    duration_seconds: float = 0.0
    output_table: str = ""
    error: str | None = None

    @property
    def success(self) -> bool:
        """Whether the report completed successfully."""
        return self.status == ReportStatus.COMPLETED


@dataclass
class FeasibilityResult:
    """Result of feasibility check for a report."""

    report_id: str
    feasible: bool
    missing_tables: list[str] = field(default_factory=list)
    missing_columns: dict[str, list[str]] = field(default_factory=dict)
    reason: str = ""

    @property
    def status(self) -> ReportStatus:
        """Get status based on feasibility."""
        return ReportStatus.NOT_STARTED if self.feasible else ReportStatus.BLOCKED
