"""
Compliance reports - 10 reports for compliance checks.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

COMPLIANCE_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="COMP-001",
        title="Compliance Dashboard",
        description="Key compliance metrics at a glance",
        category=ReportCategory.COMPLIANCE,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.users", f"{EVD}.safes"],
        sql="""
            SELECT
                (SELECT COUNT(*) FROM evd.files WHERE type = 2 AND last_used_date IS NULL) AS accounts_never_used,
                (SELECT COUNT(*) FROM evd.files WHERE type = 2 AND last_used_date < CURRENT_DATE - INTERVAL '90 days') AS accounts_inactive_90d,
                (SELECT COUNT(*) FROM evd.users WHERE last_login_date IS NULL) AS users_never_logged_in,
                (SELECT COUNT(*) FROM evd.safes WHERE COALESCE(total_objects, 0) = 0) AS empty_safes,
                CURRENT_TIMESTAMP AS generated_at
        """,
    ),
    ReportSpec(
        id="COMP-002",
        title="Password Age Compliance",
        description="Accounts by password age bands",
        category=ReportCategory.COMPLIANCE,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH pwd_ages AS (
                SELECT
                    f.file_id,
                    MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' 
                        THEN TRY_CAST(op.object_property_value AS DATE) END) AS last_change
                FROM evd.files f
                LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id
            )
            SELECT
                CASE
                    WHEN last_change IS NULL THEN 'Unknown'
                    WHEN last_change >= CURRENT_DATE - INTERVAL '30 days' THEN '< 30 days'
                    WHEN last_change >= CURRENT_DATE - INTERVAL '60 days' THEN '30-60 days'
                    WHEN last_change >= CURRENT_DATE - INTERVAL '90 days' THEN '60-90 days'
                    ELSE '> 90 days (Non-Compliant)'
                END AS age_band,
                COUNT(*) AS account_count
            FROM pwd_ages
            GROUP BY 1
            ORDER BY COUNT(*) DESC
        """,
    ),
    ReportSpec(
        id="COMP-003",
        title="Account Access Review List",
        description="Accounts requiring access review (90+ days inactive)",
        category=ReportCategory.COMPLIANCE,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                safe_name,
                file_name AS account_name,
                created_by,
                creation_date,
                last_used_by,
                last_used_date,
                DATEDIFF('day', COALESCE(last_used_date, creation_date), CURRENT_DATE) AS days_since_activity
            FROM evd.files
            WHERE type = 2
              AND COALESCE(deleted_by, '') = ''
              AND (last_used_date < CURRENT_DATE - INTERVAL '90 days' OR last_used_date IS NULL)
            ORDER BY days_since_activity DESC
        """,
    ),
    ReportSpec(
        id="COMP-004",
        title="User Access Review List",
        description="Users requiring access review",
        category=ReportCategory.COMPLIANCE,
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_name,
                origin,
                creation_date,
                last_login_date,
                DATEDIFF('day', COALESCE(last_login_date, creation_date), CURRENT_DATE) AS days_since_activity,
                CASE WHEN UPPER(COALESCE(disabled, 'NO')) IN ('YES', 'TRUE', '1') THEN 'Yes' ELSE 'No' END AS is_disabled
            FROM evd.users
            WHERE last_login_date < CURRENT_DATE - INTERVAL '90 days'
               OR last_login_date IS NULL
            ORDER BY days_since_activity DESC
        """,
    ),
    ReportSpec(
        id="COMP-005",
        title="Safes Without Owners Compliance",
        description="Safes requiring owner assignment",
        category=ReportCategory.COMPLIANCE,
        chart_type="table",
        depends_on_tables=[f"{EVD}.safes", f"{EVD}.owners"],
        sql="""
            SELECT
                s.safe_id,
                s.safe_name,
                s.creation_date,
                s.total_accounts,
                'No Owner Assigned' AS compliance_issue
            FROM evd.safes s
            LEFT JOIN evd.owners o ON s.safe_id = o.safe_id
            WHERE o.owner_id IS NULL
            ORDER BY s.total_accounts DESC NULLS LAST
        """,
    ),
    ReportSpec(
        id="COMP-006",
        title="CPM Compliance Status",
        description="Accounts by CPM management status",
        category=ReportCategory.COMPLIANCE,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH cpm_status AS (
                SELECT
                    f.file_id,
                    MAX(CASE WHEN op.object_property_name = 'CPMDisabled' THEN op.object_property_value END) AS cpm_disabled,
                    MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) AS cpm_status
                FROM evd.files f
                LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id
            )
            SELECT
                CASE
                    WHEN cpm_disabled IN ('yes', 'Yes', 'true', 'True', '1') THEN 'CPM Disabled'
                    WHEN cpm_status IN ('success', 'Success') THEN 'CPM Managed - OK'
                    WHEN cpm_status IS NOT NULL THEN 'CPM Managed - Issues'
                    ELSE 'Not CPM Managed'
                END AS status,
                COUNT(*) AS account_count
            FROM cpm_status
            GROUP BY 1
            ORDER BY account_count DESC
        """,
    ),
    ReportSpec(
        id="COMP-007",
        title="Account Naming Convention Compliance",
        description="Accounts not following naming standards",
        category=ReportCategory.COMPLIANCE,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                safe_name,
                file_name AS account_name,
                CASE
                    WHEN LENGTH(file_name) < 5 THEN 'Too Short'
                    WHEN file_name LIKE '% %' THEN 'Contains Spaces'
                    WHEN file_name LIKE '%@%' THEN 'Contains @ Symbol'
                    WHEN file_name ~ '^[0-9]' THEN 'Starts with Number'
                    ELSE 'Other Pattern Issue'
                END AS issue
            FROM evd.files
            WHERE type = 2
              AND COALESCE(deleted_by, '') = ''
              AND (LENGTH(file_name) < 5 OR file_name LIKE '% %')
            ORDER BY safe_name, file_name
        """,
    ),
    ReportSpec(
        id="COMP-008",
        title="Dual Control Compliance",
        description="Safes with insufficient owner count for dual control",
        category=ReportCategory.COMPLIANCE,
        chart_type="table",
        depends_on_tables=[f"{EVD}.safes", f"{EVD}.owners"],
        sql="""
            SELECT
                s.safe_id,
                s.safe_name,
                s.total_accounts,
                COUNT(o.owner_id) AS owner_count,
                CASE
                    WHEN COUNT(o.owner_id) = 0 THEN 'No Owners'
                    WHEN COUNT(o.owner_id) = 1 THEN 'Single Owner'
                    ELSE 'Compliant'
                END AS dual_control_status
            FROM evd.safes s
            LEFT JOIN evd.owners o ON s.safe_id = o.safe_id
            GROUP BY s.safe_id, s.safe_name, s.total_accounts
            HAVING COUNT(o.owner_id) < 2
            ORDER BY s.total_accounts DESC NULLS LAST
        """,
    ),
    ReportSpec(
        id="COMP-009",
        title="Platform Coverage",
        description="Accounts by platform with coverage gaps",
        category=ReportCategory.COMPLIANCE,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH platforms AS (
                SELECT
                    MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform
                FROM evd.files f
                LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id
            )
            SELECT
                COALESCE(platform, 'NO PLATFORM') AS platform,
                COUNT(*) AS account_count,
                CASE WHEN platform IS NULL THEN 'Non-Compliant' ELSE 'OK' END AS status
            FROM platforms
            GROUP BY 1
            ORDER BY account_count DESC
        """,
    ),
    ReportSpec(
        id="COMP-010",
        title="Compliance Summary by Safe",
        description="Per-safe compliance scorecard",
        category=ReportCategory.COMPLIANCE,
        chart_type="table",
        depends_on_tables=[f"{EVD}.safes", f"{EVD}.files", f"{EVD}.owners"],
        sql="""
            SELECT
                s.safe_id,
                s.safe_name,
                s.total_accounts,
                (SELECT COUNT(*) FROM evd.owners o WHERE o.safe_id = s.safe_id) AS owner_count,
                (SELECT COUNT(*) FROM evd.files f WHERE f.safe_id = s.safe_id AND f.type = 2 AND f.last_used_date IS NULL) AS never_used_accounts,
                CASE
                    WHEN (SELECT COUNT(*) FROM evd.owners o WHERE o.safe_id = s.safe_id) >= 2 THEN 'Pass'
                    ELSE 'Fail'
                END AS dual_control_check,
                CASE
                    WHEN s.total_accounts > 0 THEN 'Pass'
                    ELSE 'Empty'
                END AS has_accounts_check
            FROM evd.safes s
            ORDER BY s.safe_name
        """,
    ),
]
