"""
Account reports - 15 reports for privileged account management.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

ACCOUNT_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="ACCT-001",
        title="Accounts Overview Dashboard",
        description="High-level account statistics: total, active, deleted, by type",
        category=ReportCategory.ACCOUNT,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                COUNT(*) FILTER (WHERE type = 2) AS total_accounts,
                COUNT(*) FILTER (WHERE type = 2 AND COALESCE(deleted_by, '') = '') AS active_accounts,
                COUNT(*) FILTER (WHERE type = 2 AND COALESCE(deleted_by, '') != '') AS deleted_accounts,
                COUNT(*) FILTER (WHERE type = 1) AS total_files,
                COUNT(DISTINCT safe_id) AS safes_with_objects,
                CURRENT_TIMESTAMP AS generated_at
            FROM evd.files
        """,
    ),
    ReportSpec(
        id="ACCT-002",
        title="Accounts by Platform",
        description="Distribution of accounts by platform/policy ID",
        category=ReportCategory.ACCOUNT,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH account_platforms AS (
                SELECT
                    f.file_id,
                    f.safe_id,
                    COALESCE(LOWER(TRIM(op.object_property_value)), 'unknown') AS policy_id
                FROM evd.files f
                LEFT JOIN evd.object_properties op
                    ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                    AND op.object_property_name = 'PolicyID'
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            )
            SELECT
                policy_id AS platform,
                COUNT(*) AS account_count,
                ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentage
            FROM account_platforms
            GROUP BY 1
            ORDER BY account_count DESC
        """,
    ),
    ReportSpec(
        id="ACCT-003",
        title="Accounts by Device Type",
        description="Distribution of accounts by target device type",
        category=ReportCategory.ACCOUNT,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH account_devices AS (
                SELECT
                    f.file_id,
                    f.safe_id,
                    COALESCE(LOWER(op.object_property_value), 'unknown') AS device_type
                FROM evd.files f
                LEFT JOIN evd.object_properties op
                    ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                    AND op.object_property_name = 'DeviceType'
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            )
            SELECT
                device_type,
                COUNT(*) AS account_count,
                ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentage
            FROM account_devices
            GROUP BY 1
            ORDER BY account_count DESC
        """,
    ),
    ReportSpec(
        id="ACCT-004",
        title="Accounts by Safe",
        description="Distribution of accounts across safes",
        category=ReportCategory.ACCOUNT,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.safes"],
        sql="""
            SELECT
                s.safe_id,
                s.safe_name,
                COUNT(*) FILTER (WHERE f.type = 2) AS account_count,
                COUNT(*) FILTER (WHERE f.type = 1) AS file_count
            FROM evd.safes s
            LEFT JOIN evd.files f ON s.safe_id = f.safe_id
            GROUP BY s.safe_id, s.safe_name
            HAVING COUNT(*) FILTER (WHERE f.type = 2) > 0
            ORDER BY account_count DESC
        """,
    ),
    ReportSpec(
        id="ACCT-005",
        title="Privileged Account Full Inventory",
        description="Complete exportable account list with all key properties",
        category=ReportCategory.ACCOUNT,
        priority=1,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.file_id,
                f.safe_id,
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'UserName' THEN op.object_property_value END) AS user_name,
                MAX(CASE WHEN op.object_property_name = 'Address' THEN op.object_property_value END) AS address,
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform,
                MAX(CASE WHEN op.object_property_name = 'DeviceType' THEN op.object_property_value END) AS device_type,
                MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) AS cpm_status,
                f.created_by,
                f.creation_date,
                f.last_used_by,
                f.last_used_date,
                CASE WHEN COALESCE(f.deleted_by, '') = '' THEN 'Active' ELSE 'Deleted' END AS status
            FROM evd.files f
            LEFT JOIN evd.object_properties op
                ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name,
                     f.created_by, f.creation_date, f.last_used_by, f.last_used_date, f.deleted_by
            ORDER BY f.safe_name, f.file_name
        """,
    ),
    ReportSpec(
        id="ACCT-006",
        title="Accounts Created Over Time",
        description="Account creation timeline for growth analysis",
        category=ReportCategory.ACCOUNT,
        chart_type="line",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                DATE_TRUNC('month', creation_date) AS month,
                COUNT(*) AS accounts_created,
                SUM(COUNT(*)) OVER (ORDER BY DATE_TRUNC('month', creation_date)) AS cumulative
            FROM evd.files
            WHERE type = 2 AND creation_date IS NOT NULL
            GROUP BY 1
            ORDER BY 1
        """,
    ),
    ReportSpec(
        id="ACCT-007",
        title="Recently Created Accounts (30 days)",
        description="Accounts created in the last 30 days",
        category=ReportCategory.ACCOUNT,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                file_id,
                safe_name,
                file_name AS account_name,
                created_by,
                creation_date
            FROM evd.files
            WHERE type = 2
              AND creation_date >= CURRENT_DATE - INTERVAL '30 days'
            ORDER BY creation_date DESC
        """,
    ),
    ReportSpec(
        id="ACCT-008",
        title="Deleted Accounts",
        description="All deleted accounts with deletion details",
        category=ReportCategory.ACCOUNT,
        tags=["audit"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                file_id,
                safe_name,
                file_name AS account_name,
                created_by,
                creation_date,
                deleted_by,
                deletion_date,
                DATEDIFF('day', creation_date, deletion_date) AS days_existed
            FROM evd.files
            WHERE type = 2 AND COALESCE(deleted_by, '') != ''
            ORDER BY deletion_date DESC
        """,
    ),
    ReportSpec(
        id="ACCT-009",
        title="Never Used Accounts",
        description="Accounts that have never been accessed",
        category=ReportCategory.ACCOUNT,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                file_id,
                safe_name,
                file_name AS account_name,
                created_by,
                creation_date,
                DATEDIFF('day', creation_date, CURRENT_DATE) AS days_since_creation
            FROM evd.files
            WHERE type = 2
              AND COALESCE(deleted_by, '') = ''
              AND last_used_date IS NULL
            ORDER BY creation_date
        """,
    ),
    ReportSpec(
        id="ACCT-010",
        title="Inactive Accounts (90+ Days)",
        description="Accounts not accessed in 90+ days",
        category=ReportCategory.ACCOUNT,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                file_id,
                safe_name,
                file_name AS account_name,
                last_used_by,
                last_used_date,
                DATEDIFF('day', last_used_date, CURRENT_DATE) AS days_inactive
            FROM evd.files
            WHERE type = 2
              AND COALESCE(deleted_by, '') = ''
              AND last_used_date < CURRENT_DATE - INTERVAL '90 days'
            ORDER BY last_used_date
        """,
    ),
    ReportSpec(
        id="ACCT-011",
        title="Most Frequently Used Accounts",
        description="Top accounts by access frequency (based on last_accessed_by count pattern)",
        category=ReportCategory.ACCOUNT,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                safe_name,
                file_name AS account_name,
                last_used_by,
                last_used_date,
                retrieve_count
            FROM evd.files
            WHERE type = 2
              AND COALESCE(deleted_by, '') = ''
              AND retrieve_count IS NOT NULL
            ORDER BY retrieve_count DESC
            LIMIT 50
        """,
    ),
    ReportSpec(
        id="ACCT-012",
        title="Accounts by Creator",
        description="Who onboarded the most accounts",
        category=ReportCategory.ACCOUNT,
        tags=["audit"],
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                COALESCE(created_by, 'Unknown') AS creator,
                COUNT(*) AS accounts_created,
                MIN(creation_date) AS first_created,
                MAX(creation_date) AS last_created
            FROM evd.files
            WHERE type = 2
            GROUP BY 1
            ORDER BY accounts_created DESC
        """,
    ),
    ReportSpec(
        id="ACCT-013",
        title="Duplicate Account Detection",
        description="Accounts with same username+address across safes",
        category=ReportCategory.ACCOUNT,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH account_keys AS (
                SELECT
                    f.file_id,
                    f.safe_id,
                    f.safe_name,
                    f.file_name,
                    MAX(CASE WHEN op.object_property_name = 'UserName' THEN op.object_property_value END) AS user_name,
                    MAX(CASE WHEN op.object_property_name = 'Address' THEN op.object_property_value END) AS address
                FROM evd.files f
                LEFT JOIN evd.object_properties op
                    ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name
            ),
            duplicates AS (
                SELECT user_name, address, COUNT(*) AS count
                FROM account_keys
                WHERE user_name IS NOT NULL AND address IS NOT NULL
                GROUP BY user_name, address
                HAVING COUNT(*) > 1
            )
            SELECT
                ak.user_name,
                ak.address,
                ak.safe_name,
                ak.file_name AS account_name,
                d.count AS duplicate_count
            FROM account_keys ak
            INNER JOIN duplicates d ON ak.user_name = d.user_name AND ak.address = d.address
            ORDER BY d.count DESC, ak.user_name, ak.address
        """,
    ),
    ReportSpec(
        id="ACCT-014",
        title="Account Age Distribution",
        description="Accounts grouped by age in days",
        category=ReportCategory.ACCOUNT,
        chart_type="histogram",
        depends_on_tables=[f"{EVD}.files"],
        sql="""
            SELECT
                CASE
                    WHEN DATEDIFF('day', creation_date, CURRENT_DATE) < 30 THEN '< 30 days'
                    WHEN DATEDIFF('day', creation_date, CURRENT_DATE) < 90 THEN '30-90 days'
                    WHEN DATEDIFF('day', creation_date, CURRENT_DATE) < 180 THEN '90-180 days'
                    WHEN DATEDIFF('day', creation_date, CURRENT_DATE) < 365 THEN '180-365 days'
                    ELSE '> 1 year'
                END AS age_range,
                COUNT(*) AS account_count
            FROM evd.files
            WHERE type = 2 AND COALESCE(deleted_by, '') = '' AND creation_date IS NOT NULL
            GROUP BY 1
            ORDER BY MIN(DATEDIFF('day', creation_date, CURRENT_DATE))
        """,
    ),
    ReportSpec(
        id="ACCT-015",
        title="Accounts Missing Key Properties",
        description="Accounts without UserName, Address, or PolicyID",
        category=ReportCategory.ACCOUNT,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH account_props AS (
                SELECT
                    f.file_id,
                    f.safe_id,
                    f.safe_name,
                    f.file_name,
                    MAX(CASE WHEN op.object_property_name = 'UserName' THEN 1 ELSE 0 END) AS has_username,
                    MAX(CASE WHEN op.object_property_name = 'Address' THEN 1 ELSE 0 END) AS has_address,
                    MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN 1 ELSE 0 END) AS has_platform
                FROM evd.files f
                LEFT JOIN evd.object_properties op
                    ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name
            )
            SELECT
                safe_name,
                file_name AS account_name,
                CASE WHEN has_username = 0 THEN 'Missing' ELSE 'OK' END AS username_status,
                CASE WHEN has_address = 0 THEN 'Missing' ELSE 'OK' END AS address_status,
                CASE WHEN has_platform = 0 THEN 'Missing' ELSE 'OK' END AS platform_status
            FROM account_props
            WHERE has_username = 0 OR has_address = 0 OR has_platform = 0
            ORDER BY safe_name, file_name
        """,
    ),
]
