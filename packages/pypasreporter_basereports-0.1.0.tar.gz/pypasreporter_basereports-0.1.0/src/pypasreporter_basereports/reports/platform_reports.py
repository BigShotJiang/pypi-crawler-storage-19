"""
Platform reports - 8 reports for platform/policy analysis.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

PLATFORM_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="PLAT-001",
        title="Platform Overview",
        description="Account distribution by platform/policy",
        category=ReportCategory.PLATFORM,
        priority=1,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                COALESCE(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END), 'NO PLATFORM') AS platform,
                COUNT(*) AS account_count
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id
        """,
    ),
    ReportSpec(
        id="PLAT-002",
        title="Platform Account Details",
        description="Detailed account list by platform",
        category=ReportCategory.PLATFORM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                COALESCE(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END), 'NO PLATFORM') AS platform,
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'Address' THEN op.object_property_value END) AS address,
                MAX(CASE WHEN op.object_property_name = 'UserName' THEN op.object_property_value END) AS username
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name
            ORDER BY 1, 2, 3
        """,
    ),
    ReportSpec(
        id="PLAT-003",
        title="Accounts Without Platform",
        description="Accounts missing PolicyID assignment",
        category=ReportCategory.PLATFORM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                f.creation_date,
                f.created_by
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                AND op.object_property_name = 'PolicyID'
            WHERE f.type = 2 
              AND COALESCE(f.deleted_by, '') = ''
              AND op.object_property_value IS NULL
            ORDER BY f.safe_name, f.file_name
        """,
    ),
    ReportSpec(
        id="PLAT-004",
        title="Platform by Safe",
        description="Platform distribution per safe",
        category=ReportCategory.PLATFORM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                COALESCE(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END), 'NO PLATFORM') AS platform,
                COUNT(DISTINCT f.file_id) AS account_count
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.safe_name, f.file_id
        """,
        implemented=False,  # Needs aggregation rewrite
    ),
    ReportSpec(
        id="PLAT-005",
        title="Platform Statistics",
        description="Statistics per platform",
        category=ReportCategory.PLATFORM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH platform_accounts AS (
                SELECT
                    f.file_id,
                    f.safe_name,
                    f.last_used_date,
                    COALESCE(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END), 'NO PLATFORM') AS platform
                FROM evd.files f
                LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id, f.safe_name, f.last_used_date
            )
            SELECT
                platform,
                COUNT(*) AS total_accounts,
                COUNT(DISTINCT safe_name) AS safe_count,
                COUNT(*) FILTER (WHERE last_used_date IS NOT NULL) AS used_accounts,
                COUNT(*) FILTER (WHERE last_used_date IS NULL) AS never_used
            FROM platform_accounts
            GROUP BY platform
            ORDER BY total_accounts DESC
        """,
    ),
    ReportSpec(
        id="PLAT-006",
        title="Windows Platforms Summary",
        description="Windows-based platform accounts",
        category=ReportCategory.PLATFORM,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform,
                COUNT(*) AS account_count
            FROM evd.files f
            INNER JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id
            HAVING LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%win%'
        """,
    ),
    ReportSpec(
        id="PLAT-007",
        title="Unix/Linux Platforms Summary",
        description="Unix/Linux-based platform accounts",
        category=ReportCategory.PLATFORM,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform,
                COUNT(*) AS account_count
            FROM evd.files f
            INNER JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id
            HAVING LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%unix%'
                OR LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%linux%'
                OR LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%ssh%'
        """,
    ),
    ReportSpec(
        id="PLAT-008",
        title="Database Platforms Summary",
        description="Database platform accounts",
        category=ReportCategory.PLATFORM,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform,
                COUNT(*) AS account_count
            FROM evd.files f
            INNER JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id
            HAVING LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%oracle%'
                OR LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%mysql%'
                OR LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%sql%'
                OR LOWER(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END)) LIKE '%db%'
        """,
    ),
]
