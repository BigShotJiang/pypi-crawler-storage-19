"""
Audit reports - 5 reports for audit trail and log analysis.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

AUDIT_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="AUDIT-001",
        title="Audit Trail Summary",
        description="Activity summary from Italog",
        category=ReportCategory.AUDIT,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                COUNT(*) AS total_events,
                COUNT(DISTINCT user_name) AS unique_users,
                COUNT(DISTINCT safe_name) AS unique_safes,
                MIN(event_date) AS earliest_event,
                MAX(event_date) AS latest_event,
                CURRENT_TIMESTAMP AS generated_at
            FROM evd.italog
        """,
    ),
    ReportSpec(
        id="AUDIT-002",
        title="Audit Events by Type",
        description="Event distribution by action type",
        category=ReportCategory.AUDIT,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                COALESCE(action, 'Unknown') AS event_type,
                COUNT(*) AS event_count
            FROM evd.italog
            GROUP BY action
            ORDER BY event_count DESC
        """,
    ),
    ReportSpec(
        id="AUDIT-003",
        title="Audit Events Over Time",
        description="Event timeline by date",
        category=ReportCategory.AUDIT,
        chart_type="line",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                CAST(event_date AS DATE) AS event_day,
                COUNT(*) AS event_count
            FROM evd.italog
            WHERE event_date IS NOT NULL
            GROUP BY CAST(event_date AS DATE)
            ORDER BY event_day
        """,
    ),
    ReportSpec(
        id="AUDIT-004",
        title="High-Volume Users (Audit)",
        description="Users with most audit events",
        category=ReportCategory.AUDIT,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                COALESCE(user_name, 'Unknown') AS user_name,
                COUNT(*) AS event_count,
                COUNT(DISTINCT action) AS action_types,
                COUNT(DISTINCT safe_name) AS safes_accessed
            FROM evd.italog
            GROUP BY user_name
            ORDER BY event_count DESC
            LIMIT 50
        """,
    ),
    ReportSpec(
        id="AUDIT-005",
        title="Recent Audit Events",
        description="Most recent audit trail entries",
        category=ReportCategory.AUDIT,
        chart_type="table",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                event_date,
                user_name,
                action,
                safe_name,
                file_name,
                description
            FROM evd.italog
            WHERE event_date IS NOT NULL
            ORDER BY event_date DESC
            LIMIT 500
        """,
    ),
]
