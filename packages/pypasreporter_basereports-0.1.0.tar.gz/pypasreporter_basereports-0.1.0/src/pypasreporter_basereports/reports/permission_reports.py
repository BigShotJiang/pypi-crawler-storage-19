"""
Permission reports - 10 reports for access rights and ownership analysis.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

PERMISSION_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="PERM-001",
        title="Permission Overview Dashboard",
        description="High-level permission statistics across safes and users",
        category=ReportCategory.PERMISSION,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.owners"],
        sql="""
            SELECT
                COUNT(*) AS total_permissions,
                COUNT(DISTINCT safe_id) AS safes_with_permissions,
                COUNT(DISTINCT owner_name) AS unique_owners,
                COUNT(*) FILTER (WHERE COALESCE(owner_type, 'User') = 'User') AS user_permissions,
                COUNT(*) FILTER (WHERE COALESCE(owner_type, 'User') = 'Group') AS group_permissions,
                CURRENT_TIMESTAMP AS generated_at
            FROM evd.owners
        """,
    ),
    ReportSpec(
        id="PERM-002",
        title="Safe Owners Full List",
        description="Complete list of all safe ownership assignments",
        category=ReportCategory.PERMISSION,
        chart_type="table",
        depends_on_tables=[f"{EVD}.owners", f"{EVD}.safes"],
        sql="""
            SELECT
                s.safe_name,
                o.owner_name,
                o.owner_type,
                o.permissions,
                o.is_owner,
                o.is_read_only
            FROM evd.owners o
            INNER JOIN evd.safes s ON o.safe_id = s.safe_id
            ORDER BY s.safe_name, o.owner_name
        """,
    ),
    ReportSpec(
        id="PERM-003",
        title="Safes by Owner Count",
        description="Safes ranked by number of owners/members",
        category=ReportCategory.PERMISSION,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.owners", f"{EVD}.safes"],
        sql="""
            SELECT
                s.safe_id,
                s.safe_name,
                COUNT(*) AS owner_count,
                COUNT(*) FILTER (WHERE o.owner_type = 'User') AS user_owners,
                COUNT(*) FILTER (WHERE o.owner_type = 'Group') AS group_owners
            FROM evd.safes s
            LEFT JOIN evd.owners o ON s.safe_id = o.safe_id
            GROUP BY s.safe_id, s.safe_name
            ORDER BY owner_count DESC
            LIMIT 50
        """,
    ),
    ReportSpec(
        id="PERM-004",
        title="Users with Most Safe Access",
        description="Users/groups with access to most safes",
        category=ReportCategory.PERMISSION,
        tags=["security"],
        chart_type="bar",
        depends_on_tables=[f"{EVD}.owners"],
        sql="""
            SELECT
                owner_name,
                owner_type,
                COUNT(DISTINCT safe_id) AS safe_count,
                COUNT(*) FILTER (WHERE is_owner = 'Yes' OR is_owner = '1') AS owner_of_count
            FROM evd.owners
            GROUP BY owner_name, owner_type
            ORDER BY safe_count DESC
            LIMIT 50
        """,
    ),
    ReportSpec(
        id="PERM-005",
        title="Safes with No Owners",
        description="Safes with no assigned owners (orphaned)",
        category=ReportCategory.PERMISSION,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.safes", f"{EVD}.owners"],
        sql="""
            SELECT
                s.safe_id,
                s.safe_name,
                s.creation_date,
                s.total_accounts
            FROM evd.safes s
            LEFT JOIN evd.owners o ON s.safe_id = o.safe_id
            WHERE o.owner_id IS NULL
            ORDER BY s.safe_name
        """,
    ),
    ReportSpec(
        id="PERM-006",
        title="Safes with Single Owner",
        description="Safes with only one owner - single point of failure",
        category=ReportCategory.PERMISSION,
        tags=["security", "compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.owners", f"{EVD}.safes"],
        sql="""
            WITH owner_counts AS (
                SELECT safe_id, COUNT(*) AS owner_count
                FROM evd.owners
                GROUP BY safe_id
                HAVING COUNT(*) = 1
            )
            SELECT
                s.safe_id,
                s.safe_name,
                o.owner_name,
                o.owner_type,
                s.total_accounts
            FROM owner_counts oc
            INNER JOIN evd.safes s ON oc.safe_id = s.safe_id
            INNER JOIN evd.owners o ON s.safe_id = o.safe_id
            ORDER BY s.safe_name
        """,
    ),
    ReportSpec(
        id="PERM-007",
        title="Overly Permissive Safes",
        description="Safes with more than 10 owners - review access",
        category=ReportCategory.PERMISSION,
        tags=["security"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.owners", f"{EVD}.safes"],
        sql="""
            SELECT
                s.safe_id,
                s.safe_name,
                COUNT(*) AS owner_count,
                STRING_AGG(o.owner_name, ', ' ORDER BY o.owner_name) AS owners
            FROM evd.safes s
            INNER JOIN evd.owners o ON s.safe_id = o.safe_id
            GROUP BY s.safe_id, s.safe_name
            HAVING COUNT(*) > 10
            ORDER BY COUNT(*) DESC
        """,
    ),
    ReportSpec(
        id="PERM-008",
        title="Group Membership Summary",
        description="Groups and their member counts",
        category=ReportCategory.PERMISSION,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.groups", f"{EVD}.group_members"],
        sql="""
            SELECT
                g.group_id,
                g.group_name,
                g.location_name,
                COUNT(gm.member_user_id) AS member_count
            FROM evd.groups g
            LEFT JOIN evd.group_members gm ON g.group_id = gm.group_id
            GROUP BY g.group_id, g.group_name, g.location_name
            ORDER BY member_count DESC
        """,
    ),
    ReportSpec(
        id="PERM-009",
        title="Empty Groups",
        description="Groups with no members",
        category=ReportCategory.PERMISSION,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.groups", f"{EVD}.group_members"],
        sql="""
            SELECT
                g.group_id,
                g.group_name,
                g.location_name,
                g.description
            FROM evd.groups g
            LEFT JOIN evd.group_members gm ON g.group_id = gm.group_id
            WHERE gm.member_user_id IS NULL
            ORDER BY g.group_name
        """,
    ),
    ReportSpec(
        id="PERM-010",
        title="Users in Multiple Groups",
        description="Users who belong to more than 5 groups",
        category=ReportCategory.PERMISSION,
        tags=["security"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.group_members", f"{EVD}.users", f"{EVD}.groups"],
        sql="""
            SELECT
                u.user_name,
                u.origin,
                COUNT(DISTINCT gm.group_id) AS group_count,
                STRING_AGG(g.group_name, ', ' ORDER BY g.group_name) AS groups
            FROM evd.group_members gm
            INNER JOIN evd.users u ON gm.member_user_id = u.user_id
            INNER JOIN evd.groups g ON gm.group_id = g.group_id
            GROUP BY u.user_id, u.user_name, u.origin
            HAVING COUNT(DISTINCT gm.group_id) > 5
            ORDER BY COUNT(DISTINCT gm.group_id) DESC
        """,
    ),
]
