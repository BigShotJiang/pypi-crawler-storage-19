"""
Security reports - 10 reports for security assessments.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

SECURITY_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="SEC-001",
        title="Security Overview Dashboard",
        description="High-level security metrics and risk indicators",
        category=ReportCategory.SECURITY,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.users", f"{EVD}.safes", f"{EVD}.files"],
        sql="""
            SELECT
                (SELECT COUNT(*) FROM evd.users WHERE UPPER(COALESCE(disabled, 'NO')) IN ('YES', 'TRUE', '1')) AS disabled_users,
                (SELECT COUNT(*) FROM evd.safes WHERE COALESCE(total_objects, 0) = 0) AS empty_safes,
                (SELECT COUNT(*) FROM evd.files WHERE type = 2 AND last_used_date IS NULL) AS never_used_accounts,
                CURRENT_TIMESTAMP AS generated_at
        """,
    ),
    ReportSpec(
        id="SEC-002",
        title="Accounts with CPM Issues",
        description="Accounts with CPM errors or warnings",
        category=ReportCategory.SECURITY,
        tags=["cpm"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) AS cpm_status,
                MAX(CASE WHEN op.object_property_name = 'CPMErrorDetails' THEN op.object_property_value END) AS error_details,
                MAX(CASE WHEN op.object_property_name = 'LastTask' THEN op.object_property_value END) AS last_task
            FROM evd.files f
            INNER JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name
            HAVING MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) NOT IN ('success', 'Success', '')
               AND MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) IS NOT NULL
            ORDER BY f.safe_name, f.file_name
        """,
    ),
    ReportSpec(
        id="SEC-003",
        title="Disabled Accounts Still in Use",
        description="Accounts marked disabled but with recent activity",
        category=ReportCategory.SECURITY,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                f.last_used_date,
                f.last_used_by,
                MAX(CASE WHEN op.object_property_name = 'DisabledReason' THEN op.object_property_value END) AS disabled_reason
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2
              AND f.last_used_date >= CURRENT_DATE - INTERVAL '30 days'
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name, f.last_used_date, f.last_used_by
            HAVING MAX(CASE WHEN op.object_property_name = 'DisabledReason' THEN op.object_property_value END) IS NOT NULL
            ORDER BY f.last_used_date DESC
        """,
    ),
    ReportSpec(
        id="SEC-004",
        title="High Privilege Accounts",
        description="Accounts with admin/root/privileged access",
        category=ReportCategory.SECURITY,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'UserName' THEN op.object_property_value END) AS user_name,
                MAX(CASE WHEN op.object_property_name = 'Address' THEN op.object_property_value END) AS address,
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name
            HAVING LOWER(MAX(CASE WHEN op.object_property_name = 'UserName' THEN op.object_property_value END)) 
                IN ('administrator', 'admin', 'root', 'sa', 'sys', 'system')
            ORDER BY f.safe_name, f.file_name
        """,
    ),
    ReportSpec(
        id="SEC-005",
        title="Accounts Without Password Rotation",
        description="Accounts not managed by CPM (no rotation)",
        category=ReportCategory.SECURITY,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform,
                MAX(CASE WHEN op.object_property_name = 'CPMDisabled' THEN op.object_property_value END) AS cpm_disabled,
                f.creation_date
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name, f.creation_date
            HAVING MAX(CASE WHEN op.object_property_name = 'CPMDisabled' THEN op.object_property_value END) IN ('yes', 'Yes', 'true', 'True', '1')
            ORDER BY f.creation_date
        """,
    ),
    ReportSpec(
        id="SEC-006",
        title="Vault Administrators",
        description="Users with vault admin privileges",
        category=ReportCategory.SECURITY,
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                user_type,
                creation_date,
                last_login_date
            FROM evd.users
            WHERE LOWER(user_type) LIKE '%admin%'
               OR LOWER(user_name) IN ('administrator', 'master', 'vault_admin')
            ORDER BY user_name
        """,
    ),
    ReportSpec(
        id="SEC-007",
        title="Failed Operations Log",
        description="Recent failed operations from italog",
        category=ReportCategory.SECURITY,
        tags=["audit"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                timestamp,
                user_name,
                action_id,
                safe_name,
                target_address,
                reason
            FROM evd.italog
            WHERE LOWER(action_id) LIKE '%fail%'
               OR LOWER(reason) LIKE '%fail%'
               OR LOWER(reason) LIKE '%denied%'
            ORDER BY timestamp DESC
            LIMIT 500
        """,
    ),
    ReportSpec(
        id="SEC-008",
        title="Orphaned Accounts",
        description="Accounts in safes with no owners",
        category=ReportCategory.SECURITY,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.safes", f"{EVD}.owners"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                f.creation_date,
                f.created_by
            FROM evd.files f
            INNER JOIN evd.safes s ON f.safe_id = s.safe_id
            LEFT JOIN evd.owners o ON s.safe_id = o.safe_id
            WHERE f.type = 2
              AND COALESCE(f.deleted_by, '') = ''
              AND o.owner_id IS NULL
            ORDER BY f.safe_name, f.file_name
        """,
    ),
    ReportSpec(
        id="SEC-009",
        title="Accounts with Old Passwords",
        description="Accounts with passwords older than 90 days",
        category=ReportCategory.SECURITY,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' THEN op.object_property_value END) AS last_change,
                f.creation_date
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name, f.creation_date
            HAVING MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' THEN TRY_CAST(op.object_property_value AS DATE) END) < CURRENT_DATE - INTERVAL '90 days'
                OR MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' THEN op.object_property_value END) IS NULL
            ORDER BY f.safe_name
        """,
    ),
    ReportSpec(
        id="SEC-010",
        title="Suspicious Activity Patterns",
        description="Unusual access patterns - off-hours, high volume",
        category=ReportCategory.SECURITY,
        tags=["audit"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            WITH user_activity AS (
                SELECT
                    user_name,
                    DATE_TRUNC('day', timestamp) AS day,
                    COUNT(*) AS daily_actions,
                    COUNT(*) FILTER (WHERE EXTRACT(HOUR FROM timestamp) < 6 OR EXTRACT(HOUR FROM timestamp) > 22) AS off_hours_actions
                FROM evd.italog
                WHERE timestamp >= CURRENT_DATE - INTERVAL '7 days'
                GROUP BY user_name, DATE_TRUNC('day', timestamp)
            )
            SELECT
                user_name,
                day,
                daily_actions,
                off_hours_actions,
                ROUND(100.0 * off_hours_actions / NULLIF(daily_actions, 0), 1) AS off_hours_pct
            FROM user_activity
            WHERE daily_actions > 100 OR off_hours_actions > 10
            ORDER BY day DESC, daily_actions DESC
        """,
    ),
]
