"""
Session reports - 10 reports for PSM session analysis.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

SESSION_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="SESS-001",
        title="Sessions Overview Dashboard",
        description="High-level session statistics",
        category=ReportCategory.SESSION,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                COUNT(*) AS total_sessions,
                COUNT(DISTINCT user_name) AS unique_users,
                COUNT(DISTINCT safe_name) AS unique_safes,
                COUNT(DISTINCT target_address) AS unique_targets,
                CURRENT_TIMESTAMP AS generated_at
            FROM evd.italog
            WHERE action_id = 'Connect'
        """,
    ),
    ReportSpec(
        id="SESS-002",
        title="Sessions by User",
        description="Session count per user",
        category=ReportCategory.SESSION,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                user_name,
                COUNT(*) AS session_count,
                COUNT(DISTINCT target_address) AS unique_targets,
                MIN(timestamp) AS first_session,
                MAX(timestamp) AS last_session
            FROM evd.italog
            WHERE action_id = 'Connect'
            GROUP BY user_name
            ORDER BY session_count DESC
            LIMIT 50
        """,
    ),
    ReportSpec(
        id="SESS-003",
        title="Sessions Over Time",
        description="Session volume by day",
        category=ReportCategory.SESSION,
        chart_type="line",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                DATE_TRUNC('day', timestamp) AS day,
                COUNT(*) AS session_count,
                COUNT(DISTINCT user_name) AS unique_users
            FROM evd.italog
            WHERE action_id = 'Connect' AND timestamp IS NOT NULL
            GROUP BY 1
            ORDER BY 1
        """,
    ),
    ReportSpec(
        id="SESS-004",
        title="Sessions by Target",
        description="Most accessed targets",
        category=ReportCategory.SESSION,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                target_address,
                COUNT(*) AS session_count,
                COUNT(DISTINCT user_name) AS unique_users
            FROM evd.italog
            WHERE action_id = 'Connect' AND target_address IS NOT NULL
            GROUP BY target_address
            ORDER BY session_count DESC
            LIMIT 50
        """,
    ),
    ReportSpec(
        id="SESS-005",
        title="Sessions by Safe",
        description="Session distribution across safes",
        category=ReportCategory.SESSION,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                COALESCE(safe_name, 'Unknown') AS safe_name,
                COUNT(*) AS session_count
            FROM evd.italog
            WHERE action_id = 'Connect'
            GROUP BY 1
            ORDER BY session_count DESC
        """,
    ),
    ReportSpec(
        id="SESS-006",
        title="Sessions by Hour of Day",
        description="Session distribution by hour - identify peak usage",
        category=ReportCategory.SESSION,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                EXTRACT(HOUR FROM timestamp) AS hour_of_day,
                COUNT(*) AS session_count
            FROM evd.italog
            WHERE action_id = 'Connect' AND timestamp IS NOT NULL
            GROUP BY 1
            ORDER BY 1
        """,
    ),
    ReportSpec(
        id="SESS-007",
        title="Sessions by Day of Week",
        description="Session volume by weekday",
        category=ReportCategory.SESSION,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                DAYNAME(timestamp) AS day_of_week,
                DAYOFWEEK(timestamp) AS day_num,
                COUNT(*) AS session_count
            FROM evd.italog
            WHERE action_id = 'Connect' AND timestamp IS NOT NULL
            GROUP BY 1, 2
            ORDER BY day_num
        """,
    ),
    ReportSpec(
        id="SESS-008",
        title="Recent Sessions (24 Hours)",
        description="Sessions in the last 24 hours",
        category=ReportCategory.SESSION,
        chart_type="table",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                timestamp,
                user_name,
                safe_name,
                target_address,
                target_user,
                client_ip
            FROM evd.italog
            WHERE action_id = 'Connect'
              AND timestamp >= CURRENT_TIMESTAMP - INTERVAL '24 hours'
            ORDER BY timestamp DESC
        """,
    ),
    ReportSpec(
        id="SESS-009",
        title="Long Sessions (4+ Hours)",
        description="Sessions lasting more than 4 hours",
        category=ReportCategory.SESSION,
        tags=["security"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                session_id,
                user_name,
                target_address,
                start_time,
                end_time,
                duration_minutes
            FROM evd.italog
            WHERE action_id = 'Disconnect'
              AND duration_minutes > 240
            ORDER BY duration_minutes DESC
            LIMIT 100
        """,
        implemented=False,  # Requires session pairing logic
    ),
    ReportSpec(
        id="SESS-010",
        title="Session Connection Methods",
        description="Sessions by protocol/connection type",
        category=ReportCategory.SESSION,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.italog"],
        sql="""
            SELECT
                COALESCE(protocol, 'Unknown') AS protocol,
                COUNT(*) AS session_count,
                ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentage
            FROM evd.italog
            WHERE action_id = 'Connect'
            GROUP BY 1
            ORDER BY session_count DESC
        """,
    ),
]
