"""
User reports - 12 reports for user population and activity analysis.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

USER_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="USER-001",
        title="Users Overview Dashboard",
        description="User population statistics: total, active, disabled, by origin",
        category=ReportCategory.USER,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                COUNT(*) AS total_users,
                COUNT(*) FILTER (WHERE UPPER(COALESCE(disabled, 'NO')) NOT IN ('YES', 'TRUE', '1')) AS active_users,
                COUNT(*) FILTER (WHERE UPPER(COALESCE(disabled, 'NO')) IN ('YES', 'TRUE', '1')) AS disabled_users,
                COUNT(*) FILTER (WHERE origin = 'Internal') AS internal_users,
                COUNT(*) FILTER (WHERE origin = 'External') AS external_users,
                CURRENT_TIMESTAMP AS generated_at
            FROM evd.users
        """,
    ),
    ReportSpec(
        id="USER-002",
        title="User Inventory Full List",
        description="Complete list of all vault users with key attributes",
        category=ReportCategory.USER,
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                CASE WHEN UPPER(COALESCE(disabled, 'NO')) IN ('YES', 'TRUE', '1') THEN 'Disabled' ELSE 'Active' END AS status,
                user_type,
                location_name,
                first_name,
                last_name,
                email,
                creation_date,
                last_login_date,
                expiry_date
            FROM evd.users
            ORDER BY user_name
        """,
    ),
    ReportSpec(
        id="USER-003",
        title="Users by Origin",
        description="Distribution of users by authentication origin (LDAP, Internal, etc.)",
        category=ReportCategory.USER,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                COALESCE(origin, 'Unknown') AS origin,
                COUNT(*) AS user_count,
                ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentage
            FROM evd.users
            GROUP BY 1
            ORDER BY user_count DESC
        """,
    ),
    ReportSpec(
        id="USER-004",
        title="Users by Location",
        description="Distribution of users across vault locations",
        category=ReportCategory.USER,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                COALESCE(location_name, 'Root') AS location,
                COUNT(*) AS user_count,
                COUNT(*) FILTER (WHERE UPPER(COALESCE(disabled, 'NO')) NOT IN ('YES', 'TRUE', '1')) AS active_users
            FROM evd.users
            GROUP BY 1
            ORDER BY user_count DESC
        """,
    ),
    ReportSpec(
        id="USER-005",
        title="Disabled Users",
        description="All disabled user accounts",
        category=ReportCategory.USER,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                location_name,
                creation_date,
                last_login_date
            FROM evd.users
            WHERE UPPER(COALESCE(disabled, 'NO')) IN ('YES', 'TRUE', '1')
            ORDER BY user_name
        """,
    ),
    ReportSpec(
        id="USER-006",
        title="Users Never Logged In",
        description="Users who have never accessed the vault",
        category=ReportCategory.USER,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                creation_date,
                DATEDIFF('day', creation_date, CURRENT_DATE) AS days_since_creation
            FROM evd.users
            WHERE last_login_date IS NULL
              AND UPPER(COALESCE(disabled, 'NO')) NOT IN ('YES', 'TRUE', '1')
            ORDER BY creation_date
        """,
    ),
    ReportSpec(
        id="USER-007",
        title="Inactive Users (90+ Days)",
        description="Users not logged in for 90+ days",
        category=ReportCategory.USER,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                last_login_date,
                DATEDIFF('day', last_login_date, CURRENT_DATE) AS days_inactive
            FROM evd.users
            WHERE last_login_date < CURRENT_DATE - INTERVAL '90 days'
              AND UPPER(COALESCE(disabled, 'NO')) NOT IN ('YES', 'TRUE', '1')
            ORDER BY last_login_date
        """,
    ),
    ReportSpec(
        id="USER-008",
        title="Users Created Over Time",
        description="User creation timeline for growth analysis",
        category=ReportCategory.USER,
        chart_type="line",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                DATE_TRUNC('month', creation_date) AS month,
                COUNT(*) AS users_created,
                SUM(COUNT(*)) OVER (ORDER BY DATE_TRUNC('month', creation_date)) AS cumulative
            FROM evd.users
            WHERE creation_date IS NOT NULL
            GROUP BY 1
            ORDER BY 1
        """,
    ),
    ReportSpec(
        id="USER-009",
        title="Users with Expiring Accounts",
        description="Users with expiry date within next 30 days",
        category=ReportCategory.USER,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                expiry_date,
                DATEDIFF('day', CURRENT_DATE, expiry_date) AS days_until_expiry
            FROM evd.users
            WHERE expiry_date IS NOT NULL
              AND expiry_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days'
            ORDER BY expiry_date
        """,
    ),
    ReportSpec(
        id="USER-010",
        title="Expired User Accounts",
        description="Users with past expiry dates",
        category=ReportCategory.USER,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                expiry_date,
                DATEDIFF('day', expiry_date, CURRENT_DATE) AS days_expired,
                CASE WHEN UPPER(COALESCE(disabled, 'NO')) IN ('YES', 'TRUE', '1') THEN 'Yes' ELSE 'No' END AS is_disabled
            FROM evd.users
            WHERE expiry_date IS NOT NULL AND expiry_date < CURRENT_DATE
            ORDER BY expiry_date DESC
        """,
    ),
    ReportSpec(
        id="USER-011",
        title="Users by Type",
        description="Distribution of users by user type",
        category=ReportCategory.USER,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                COALESCE(user_type, 'Standard') AS user_type,
                COUNT(*) AS user_count,
                ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentage
            FROM evd.users
            GROUP BY 1
            ORDER BY user_count DESC
        """,
    ),
    ReportSpec(
        id="USER-012",
        title="Recent User Logins (7 Days)",
        description="Users who logged in within the last 7 days",
        category=ReportCategory.USER,
        chart_type="table",
        depends_on_tables=[f"{EVD}.users"],
        sql="""
            SELECT
                user_id,
                user_name,
                origin,
                last_login_date,
                DATEDIFF('day', last_login_date, CURRENT_DATE) AS days_ago
            FROM evd.users
            WHERE last_login_date >= CURRENT_DATE - INTERVAL '7 days'
            ORDER BY last_login_date DESC
        """,
    ),
]
