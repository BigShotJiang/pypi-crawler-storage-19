"""
Report definitions registry.

All 100 pre-built reports organized by category.
"""

from __future__ import annotations

from ..models import ReportSpec

from .safe_reports import SAFE_REPORTS
from .account_reports import ACCOUNT_REPORTS
from .user_reports import USER_REPORTS
from .permission_reports import PERMISSION_REPORTS
from .session_reports import SESSION_REPORTS
from .security_reports import SECURITY_REPORTS
from .compliance_reports import COMPLIANCE_REPORTS
from .cpm_reports import CPM_REPORTS
from .platform_reports import PLATFORM_REPORTS
from .audit_reports import AUDIT_REPORTS

# Combined registry of all reports
REPORTS: list[ReportSpec] = (
    SAFE_REPORTS
    + ACCOUNT_REPORTS
    + USER_REPORTS
    + PERMISSION_REPORTS
    + SESSION_REPORTS
    + SECURITY_REPORTS
    + COMPLIANCE_REPORTS
    + CPM_REPORTS
    + PLATFORM_REPORTS
    + AUDIT_REPORTS
)

# Report lookup by ID
REPORTS_BY_ID: dict[str, ReportSpec] = {r.id: r for r in REPORTS}


def get_report(report_id: str) -> ReportSpec | None:
    """Get report by ID."""
    return REPORTS_BY_ID.get(report_id)


def get_reports_by_category(category: str) -> list[ReportSpec]:
    """Get all reports in a category."""
    return [r for r in REPORTS if r.category.value == category]


def get_reports_by_tag(tag: str) -> list[ReportSpec]:
    """Get all reports with a specific tag."""
    return [r for r in REPORTS if tag in r.all_tags]


__all__ = [
    "REPORTS",
    "REPORTS_BY_ID",
    "get_report",
    "get_reports_by_category",
    "get_reports_by_tag",
]
