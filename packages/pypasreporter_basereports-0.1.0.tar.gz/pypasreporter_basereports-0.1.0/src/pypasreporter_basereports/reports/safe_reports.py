"""
Safe reports - 12 reports for safe inventory and analysis.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

# Schema constants
EVD = "evd"  # Raw EVD data schema
DERIVED = "evd"  # Derived/enriched schema (same for now)

SAFE_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="SAFE-001",
        title="Safes Overview Dashboard",
        description="High-level safe statistics: total count, objects, accounts, size metrics",
        category=ReportCategory.SAFE,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                COUNT(*) AS total_safes,
                COALESCE(SUM(total_objects), 0) AS total_objects,
                COALESCE(SUM(total_accounts), 0) AS total_accounts,
                COALESCE(SUM(used_size_mb), 0) AS total_size_mb,
                ROUND(AVG(total_objects), 2) AS avg_objects_per_safe,
                ROUND(AVG(total_accounts), 2) AS avg_accounts_per_safe,
                COUNT(*) FILTER (WHERE COALESCE(total_objects, 0) = 0) AS empty_safes,
                CURRENT_TIMESTAMP AS generated_at
            FROM evd.safes
        """,
    ),
    ReportSpec(
        id="SAFE-002",
        title="Safe Inventory Full List",
        description="Complete list of all safes with key attributes for export",
        category=ReportCategory.SAFE,
        chart_type="table",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                safe_id,
                safe_name,
                location_name,
                COALESCE(total_objects, 0) AS total_objects,
                COALESCE(total_accounts, 0) AS total_accounts,
                COALESCE(used_size_mb, 0) AS size_mb,
                creation_date,
                last_used_date,
                description
            FROM evd.safes
            ORDER BY safe_name
        """,
    ),
    ReportSpec(
        id="SAFE-003",
        title="Top 50 Safes by Object Count",
        description="Safes with most objects - identify high-capacity safes",
        category=ReportCategory.SAFE,
        chart_type="bar",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                safe_id,
                safe_name,
                COALESCE(total_objects, 0) AS total_objects,
                COALESCE(total_accounts, 0) AS total_accounts,
                COALESCE(used_size_mb, 0) AS size_mb
            FROM evd.safes
            ORDER BY total_objects DESC NULLS LAST
            LIMIT 50
        """,
    ),
    ReportSpec(
        id="SAFE-004",
        title="Safes by Location",
        description="Distribution of safes across locations",
        category=ReportCategory.SAFE,
        chart_type="pie",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                COALESCE(location_name, 'Root') AS location,
                COUNT(*) AS safe_count,
                SUM(total_objects) AS total_objects,
                ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentage
            FROM evd.safes
            GROUP BY 1
            ORDER BY safe_count DESC
        """,
    ),
    ReportSpec(
        id="SAFE-005",
        title="Safes Created Over Time",
        description="Safe creation timeline for growth analysis",
        category=ReportCategory.SAFE,
        chart_type="line",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                DATE_TRUNC('month', creation_date) AS month,
                COUNT(*) AS safes_created,
                SUM(COUNT(*)) OVER (ORDER BY DATE_TRUNC('month', creation_date)) AS cumulative_safes
            FROM evd.safes
            WHERE creation_date IS NOT NULL
            GROUP BY 1
            ORDER BY 1
        """,
    ),
    ReportSpec(
        id="SAFE-006",
        title="Safe Size Distribution",
        description="Safes grouped by size ranges",
        category=ReportCategory.SAFE,
        chart_type="histogram",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                CASE
                    WHEN COALESCE(used_size_mb, 0) = 0 THEN 'Empty'
                    WHEN used_size_mb < 1 THEN '< 1 MB'
                    WHEN used_size_mb < 10 THEN '1-10 MB'
                    WHEN used_size_mb < 100 THEN '10-100 MB'
                    ELSE '> 100 MB'
                END AS size_range,
                COUNT(*) AS safe_count,
                ROUND(SUM(used_size_mb), 2) AS total_size_mb
            FROM evd.safes
            GROUP BY 1
            ORDER BY MIN(COALESCE(used_size_mb, 0))
        """,
    ),
    ReportSpec(
        id="SAFE-007",
        title="Empty Safes",
        description="Safes with no objects - candidates for cleanup",
        category=ReportCategory.SAFE,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                safe_id,
                safe_name,
                location_name,
                creation_date,
                DATEDIFF('day', creation_date, CURRENT_DATE) AS days_since_creation
            FROM evd.safes
            WHERE COALESCE(total_objects, 0) = 0
            ORDER BY creation_date
        """,
    ),
    ReportSpec(
        id="SAFE-008",
        title="Recently Created Safes (30 days)",
        description="Safes created in the last 30 days",
        category=ReportCategory.SAFE,
        chart_type="table",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                safe_id,
                safe_name,
                location_name,
                creation_date,
                total_objects,
                total_accounts
            FROM evd.safes
            WHERE creation_date >= CURRENT_DATE - INTERVAL '30 days'
            ORDER BY creation_date DESC
        """,
    ),
    ReportSpec(
        id="SAFE-009",
        title="Inactive Safes (No Activity 90+ Days)",
        description="Safes with no recent activity - review for archival",
        category=ReportCategory.SAFE,
        tags=["compliance"],
        chart_type="table",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                safe_id,
                safe_name,
                location_name,
                last_used_date,
                DATEDIFF('day', last_used_date, CURRENT_DATE) AS days_inactive,
                total_objects,
                total_accounts
            FROM evd.safes
            WHERE last_used_date < CURRENT_DATE - INTERVAL '90 days'
               OR last_used_date IS NULL
            ORDER BY last_used_date NULLS FIRST
        """,
    ),
    ReportSpec(
        id="SAFE-010",
        title="Safe Naming Patterns",
        description="Analysis of safe naming conventions",
        category=ReportCategory.SAFE,
        chart_type="bar",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                CASE
                    WHEN safe_name LIKE 'D-%' THEN 'D-* (Domain)'
                    WHEN safe_name LIKE 'PSM%' THEN 'PSM* (Sessions)'
                    WHEN safe_name LIKE 'VaultInternal%' THEN 'VaultInternal*'
                    WHEN safe_name LIKE 'System%' THEN 'System*'
                    WHEN safe_name LIKE '%Reconcile%' THEN '*Reconcile*'
                    WHEN LENGTH(safe_name) <= 10 THEN 'Short Names (<= 10)'
                    ELSE 'Custom'
                END AS naming_pattern,
                COUNT(*) AS safe_count,
                ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS percentage
            FROM evd.safes
            GROUP BY 1
            ORDER BY safe_count DESC
        """,
    ),
    ReportSpec(
        id="SAFE-011",
        title="Safes with High Object Count",
        description="Safes exceeding 1000 objects - capacity planning",
        category=ReportCategory.SAFE,
        tags=["performance"],
        chart_type="table",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                safe_id,
                safe_name,
                total_objects,
                total_accounts,
                used_size_mb,
                CASE
                    WHEN total_objects > 5000 THEN 'Critical (> 5000)'
                    WHEN total_objects > 2000 THEN 'Warning (> 2000)'
                    ELSE 'Elevated (> 1000)'
                END AS capacity_status
            FROM evd.safes
            WHERE COALESCE(total_objects, 0) > 1000
            ORDER BY total_objects DESC
        """,
    ),
    ReportSpec(
        id="SAFE-012",
        title="Safe Summary by Description Pattern",
        description="Safes grouped by common description keywords",
        category=ReportCategory.SAFE,
        chart_type="pie",
        depends_on_tables=[f"{DERIVED}.safes"],
        sql="""
            SELECT
                CASE
                    WHEN description IS NULL OR description = '' THEN 'No Description'
                    WHEN LOWER(description) LIKE '%windows%' THEN 'Windows'
                    WHEN LOWER(description) LIKE '%linux%' OR LOWER(description) LIKE '%unix%' THEN 'Linux/Unix'
                    WHEN LOWER(description) LIKE '%database%' OR LOWER(description) LIKE '%oracle%' OR LOWER(description) LIKE '%sql%' THEN 'Database'
                    WHEN LOWER(description) LIKE '%network%' OR LOWER(description) LIKE '%cisco%' THEN 'Network'
                    WHEN LOWER(description) LIKE '%application%' OR LOWER(description) LIKE '%app%' THEN 'Application'
                    ELSE 'Other'
                END AS description_category,
                COUNT(*) AS safe_count,
                SUM(total_accounts) AS total_accounts
            FROM evd.safes
            GROUP BY 1
            ORDER BY safe_count DESC
        """,
    ),
]
