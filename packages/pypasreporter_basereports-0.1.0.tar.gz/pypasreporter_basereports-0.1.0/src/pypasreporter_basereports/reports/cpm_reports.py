"""
CPM reports - 8 reports for CPM status and password management.
"""

from __future__ import annotations

from ..models import ReportCategory, ReportSpec

EVD = "evd"

CPM_REPORTS: list[ReportSpec] = [
    ReportSpec(
        id="CPM-001",
        title="CPM Overview Dashboard",
        description="CPM management statistics",
        category=ReportCategory.CPM,
        priority=1,
        chart_type="big_number_total",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH cpm_status AS (
                SELECT
                    f.file_id,
                    MAX(CASE WHEN op.object_property_name = 'CPMDisabled' THEN op.object_property_value END) AS cpm_disabled,
                    MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) AS cpm_status
                FROM evd.files f
                LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id
            )
            SELECT
                COUNT(*) AS total_accounts,
                COUNT(*) FILTER (WHERE cpm_disabled NOT IN ('yes', 'Yes', 'true', 'True', '1') OR cpm_disabled IS NULL) AS cpm_enabled,
                COUNT(*) FILTER (WHERE cpm_disabled IN ('yes', 'Yes', 'true', 'True', '1')) AS cpm_disabled,
                COUNT(*) FILTER (WHERE cpm_status IN ('success', 'Success')) AS cpm_success,
                COUNT(*) FILTER (WHERE cpm_status IS NOT NULL AND cpm_status NOT IN ('success', 'Success', '')) AS cpm_issues,
                CURRENT_TIMESTAMP AS generated_at
            FROM cpm_status
        """,
    ),
    ReportSpec(
        id="CPM-002",
        title="CPM Status Distribution",
        description="Accounts by CPM status value",
        category=ReportCategory.CPM,
        chart_type="pie",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                COALESCE(MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END), 'No Status') AS cpm_status,
                COUNT(*) AS account_count
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id
            ORDER BY account_count DESC
        """,
    ),
    ReportSpec(
        id="CPM-003",
        title="CPM Failed Accounts",
        description="Accounts with CPM errors requiring attention",
        category=ReportCategory.CPM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) AS cpm_status,
                MAX(CASE WHEN op.object_property_name = 'CPMErrorDetails' THEN op.object_property_value END) AS error_details,
                MAX(CASE WHEN op.object_property_name = 'LastTask' THEN op.object_property_value END) AS last_task,
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform
            FROM evd.files f
            INNER JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name
            HAVING LOWER(MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END)) LIKE '%fail%'
                OR LOWER(MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END)) LIKE '%error%'
            ORDER BY f.safe_name, f.file_name
        """,
    ),
    ReportSpec(
        id="CPM-004",
        title="CPM Disabled Accounts",
        description="Accounts with CPM explicitly disabled",
        category=ReportCategory.CPM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform,
                MAX(CASE WHEN op.object_property_name = 'DisabledReason' THEN op.object_property_value END) AS disabled_reason,
                f.creation_date
            FROM evd.files f
            INNER JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name, f.creation_date
            HAVING MAX(CASE WHEN op.object_property_name = 'CPMDisabled' THEN op.object_property_value END) IN ('yes', 'Yes', 'true', 'True', '1')
            ORDER BY f.safe_name, f.file_name
        """,
    ),
    ReportSpec(
        id="CPM-005",
        title="Password Change Frequency",
        description="Accounts by days since last password change",
        category=ReportCategory.CPM,
        chart_type="histogram",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            WITH pwd_change AS (
                SELECT
                    MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' 
                        THEN TRY_CAST(op.object_property_value AS DATE) END) AS last_change
                FROM evd.files f
                LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
                WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
                GROUP BY f.file_id
            )
            SELECT
                CASE
                    WHEN last_change IS NULL THEN 'Never Changed'
                    WHEN DATEDIFF('day', last_change, CURRENT_DATE) < 7 THEN '< 7 days'
                    WHEN DATEDIFF('day', last_change, CURRENT_DATE) < 30 THEN '7-30 days'
                    WHEN DATEDIFF('day', last_change, CURRENT_DATE) < 60 THEN '30-60 days'
                    WHEN DATEDIFF('day', last_change, CURRENT_DATE) < 90 THEN '60-90 days'
                    ELSE '> 90 days'
                END AS change_age,
                COUNT(*) AS account_count
            FROM pwd_change
            GROUP BY 1
        """,
    ),
    ReportSpec(
        id="CPM-006",
        title="CPM Status by Platform",
        description="CPM success rate per platform",
        category=ReportCategory.CPM,
        chart_type="bar",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                COALESCE(MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END), 'Unknown') AS platform,
                COUNT(*) AS total_accounts,
                COUNT(*) FILTER (WHERE MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) IN ('success', 'Success')) AS success_count,
                ROUND(100.0 * COUNT(*) FILTER (WHERE MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) IN ('success', 'Success')) / COUNT(*), 1) AS success_rate
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id
        """,
        implemented=False,  # Needs subquery rewrite
    ),
    ReportSpec(
        id="CPM-007",
        title="Recent Password Changes",
        description="Accounts with password changes in last 7 days",
        category=ReportCategory.CPM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' THEN op.object_property_value END) AS last_change,
                MAX(CASE WHEN op.object_property_name = 'PolicyID' THEN op.object_property_value END) AS platform
            FROM evd.files f
            INNER JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name
            HAVING TRY_CAST(MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' THEN op.object_property_value END) AS DATE) >= CURRENT_DATE - INTERVAL '7 days'
            ORDER BY MAX(CASE WHEN op.object_property_name = 'LastPasswordChange' THEN op.object_property_value END) DESC
        """,
    ),
    ReportSpec(
        id="CPM-008",
        title="Accounts Pending Verification",
        description="Accounts awaiting CPM verification",
        category=ReportCategory.CPM,
        chart_type="table",
        depends_on_tables=[f"{EVD}.files", f"{EVD}.object_properties"],
        sql="""
            SELECT
                f.safe_name,
                f.file_name AS account_name,
                MAX(CASE WHEN op.object_property_name = 'CPMStatus' THEN op.object_property_value END) AS cpm_status,
                MAX(CASE WHEN op.object_property_name = 'LastTask' THEN op.object_property_value END) AS last_task,
                f.creation_date
            FROM evd.files f
            LEFT JOIN evd.object_properties op ON f.file_id = op.file_id AND f.safe_id = op.safe_id
            WHERE f.type = 2 AND COALESCE(f.deleted_by, '') = ''
            GROUP BY f.file_id, f.safe_id, f.safe_name, f.file_name, f.creation_date
            HAVING LOWER(MAX(CASE WHEN op.object_property_name = 'LastTask' THEN op.object_property_value END)) LIKE '%verify%'
            ORDER BY f.creation_date DESC
        """,
    ),
]
