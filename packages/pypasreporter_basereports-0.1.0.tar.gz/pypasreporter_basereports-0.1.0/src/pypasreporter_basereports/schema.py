"""
Schema generator - Generate schema documentation and AI prompts.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import duckdb

from .models import ReportSpec

logger = logging.getLogger(__name__)


class SchemaGenerator:
    """Generate schema documentation and AI prompts."""

    def __init__(self, db_path: str | Path | None = None, connection: "duckdb.DuckDBPyConnection | None" = None):
        """
        Initialize generator.

        Args:
            db_path: Path to DuckDB database file
            connection: Existing DuckDB connection
        """
        self._db_path = Path(db_path) if db_path else None
        self._connection = connection
        self._owns_connection = connection is None

    def _get_connection(self) -> "duckdb.DuckDBPyConnection":
        """Get or create database connection."""
        import duckdb

        if self._connection is not None:
            return self._connection

        if self._db_path is None:
            self._connection = duckdb.connect(":memory:")
        else:
            self._connection = duckdb.connect(str(self._db_path))

        return self._connection

    def close(self) -> None:
        """Close database connection if owned."""
        if self._owns_connection and self._connection is not None:
            self._connection.close()
            self._connection = None

    def get_schemas(self) -> list[str]:
        """Get list of schema names."""
        con = self._get_connection()
        result = con.execute("""
            SELECT DISTINCT schema_name 
            FROM information_schema.tables 
            WHERE schema_name NOT IN ('information_schema', 'pg_catalog')
            ORDER BY schema_name
        """)
        return [row[0] for row in result.fetchall()]

    def get_tables(self, schema: str = "evd") -> list[str]:
        """Get list of tables in schema."""
        con = self._get_connection()
        result = con.execute(f"""
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = '{schema}'
            ORDER BY table_name
        """)
        return [row[0] for row in result.fetchall()]

    def get_table_schema(self, table: str, schema: str = "evd") -> list[dict]:
        """
        Get column definitions for a table.

        Returns:
            List of dicts with column_name, data_type, is_nullable
        """
        con = self._get_connection()
        result = con.execute(f"""
            SELECT 
                column_name,
                data_type,
                is_nullable
            FROM information_schema.columns
            WHERE table_schema = '{schema}'
              AND table_name = '{table}'
            ORDER BY ordinal_position
        """)
        return [
            {"column_name": row[0], "data_type": row[1], "is_nullable": row[2]}
            for row in result.fetchall()
        ]

    def get_table_sample(self, table: str, schema: str = "evd", limit: int = 3) -> list[dict]:
        """Get sample rows from a table."""
        con = self._get_connection()
        result = con.execute(f"SELECT * FROM {schema}.{table} LIMIT {limit}")
        columns = [desc[0] for desc in result.description]
        return [dict(zip(columns, row)) for row in result.fetchall()]

    def generate_schema_markdown(
        self,
        schemas: list[str] | None = None,
        include_samples: bool = True,
        sample_rows: int = 2,
    ) -> str:
        """
        Generate Markdown documentation for database schema.

        Args:
            schemas: List of schema names (None = all)
            include_samples: Include sample data
            sample_rows: Number of sample rows

        Returns:
            Markdown string
        """
        if schemas is None:
            schemas = self.get_schemas()

        lines = ["# Database Schema Documentation", ""]

        for schema in schemas:
            lines.append(f"## Schema: `{schema}`")
            lines.append("")

            tables = self.get_tables(schema)
            for table in tables:
                lines.append(f"### Table: `{schema}.{table}`")
                lines.append("")

                # Column definitions
                columns = self.get_table_schema(table, schema)
                lines.append("| Column | Type | Nullable |")
                lines.append("|--------|------|----------|")
                for col in columns:
                    lines.append(f"| {col['column_name']} | {col['data_type']} | {col['is_nullable']} |")
                lines.append("")

                # Sample data
                if include_samples:
                    try:
                        samples = self.get_table_sample(table, schema, sample_rows)
                        if samples:
                            lines.append("**Sample Data:**")
                            lines.append("```json")
                            lines.append(json.dumps(samples, indent=2, default=str))
                            lines.append("```")
                            lines.append("")
                    except Exception as e:
                        lines.append(f"*Sample data unavailable: {e}*")
                        lines.append("")

        return "\n".join(lines)

    def generate_ai_prompt(
        self,
        schemas: list[str] | None = None,
        task: str = "analyze data",
        include_samples: bool = True,
        sample_rows: int = 2,
    ) -> str:
        """
        Generate AI prompt with schema context.

        Args:
            schemas: List of schema names (None = all)
            task: Description of the analysis task
            include_samples: Include sample data
            sample_rows: Number of sample rows

        Returns:
            Complete prompt string for AI
        """
        schema_doc = self.generate_schema_markdown(
            schemas=schemas,
            include_samples=include_samples,
            sample_rows=sample_rows,
        )

        prompt = f"""You are a data analyst working with a CyberArk PAM database. Your task is to: {task}

The database uses DuckDB (PostgreSQL-compatible SQL syntax).

{schema_doc}

## Instructions

1. Analyze the schema and sample data above
2. Write SQL queries to accomplish the task
3. Explain your approach and findings
4. Suggest additional insights that could be derived

## Notes

- All tables are in the `evd` schema (from EVD exports)
- Use standard SQL aggregations, CTEs, and window functions
- Consider NULL handling for optional fields
- Account records have type=2 in the files table
"""
        return prompt

    def generate_report_prompt(self, report: ReportSpec) -> str:
        """
        Generate AI prompt for understanding a specific report.

        Args:
            report: Report specification

        Returns:
            Prompt explaining the report
        """
        return f"""## Report: {report.id} - {report.title}

**Category:** {report.category.value}
**Description:** {report.description}
**Chart Type:** {report.chart_type or 'table'}

### SQL Query

```sql
{report.sql}
```

### Dependent Tables

{', '.join(report.depends_on_tables) or 'Not specified'}

### Analysis Request

Please explain:
1. What this SQL query does step by step
2. What business question it answers
3. How to interpret the results
4. Potential improvements or variations
"""

    def generate_report_documentation(
        self,
        reports: list[ReportSpec],
        include_sql: bool = True,
    ) -> str:
        """
        Generate documentation for multiple reports.

        Args:
            reports: List of report specifications
            include_sql: Include SQL in documentation

        Returns:
            Markdown documentation
        """
        lines = ["# Report Documentation", ""]

        # Group by category
        categories: dict[str, list[ReportSpec]] = {}
        for r in reports:
            cat = r.category.value
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(r)

        for category in sorted(categories.keys()):
            lines.append(f"## {category.title()} Reports")
            lines.append("")

            for report in sorted(categories[category], key=lambda r: r.id):
                lines.append(f"### {report.id}: {report.title}")
                lines.append("")
                lines.append(f"*{report.description}*")
                lines.append("")
                lines.append(f"- **Priority:** {report.priority}")
                lines.append(f"- **Chart Type:** {report.chart_type or 'table'}")
                lines.append(f"- **Tags:** {', '.join(report.tags) or 'none'}")
                lines.append(f"- **Implemented:** {'Yes' if report.implemented else 'No'}")
                lines.append("")

                if include_sql:
                    lines.append("**SQL:**")
                    lines.append("```sql")
                    lines.append(report.sql.strip())
                    lines.append("```")
                    lines.append("")

                lines.append("---")
                lines.append("")

        return "\n".join(lines)

    def export_schema_json(self, schemas: list[str] | None = None) -> dict:
        """
        Export schema as JSON structure.

        Args:
            schemas: List of schema names (None = all)

        Returns:
            Dict with schema structure
        """
        if schemas is None:
            schemas = self.get_schemas()

        result: dict = {"schemas": {}}

        for schema in schemas:
            result["schemas"][schema] = {"tables": {}}
            tables = self.get_tables(schema)

            for table in tables:
                columns = self.get_table_schema(table, schema)
                result["schemas"][schema]["tables"][table] = {
                    "columns": columns,
                }

        return result
