"""
CLI for pyPASreporter-baseReports.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import click

from .exporter import ReportExporter
from .models import ReportCategory
from .reports import REPORTS, get_report, get_reports_by_category, get_reports_by_tag
from .runner import ReportRunner
from .schema import SchemaGenerator

logger = logging.getLogger(__name__)


@click.group()
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output")
@click.option("-q", "--quiet", is_flag=True, help="Suppress output")
@click.version_option()
def cli(verbose: bool, quiet: bool) -> None:
    """pyPASreporter Base Reports - 100 pre-built CyberArk reports."""
    level = logging.DEBUG if verbose else logging.WARNING if quiet else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )


@cli.command("list")
@click.option("-c", "--category", help="Filter by category")
@click.option("-t", "--tag", help="Filter by tag")
@click.option("--implemented/--all", default=True, help="Show only implemented reports")
def list_reports(category: str | None, tag: str | None, implemented: bool) -> None:
    """List available reports."""
    reports = REPORTS

    if category:
        reports = get_reports_by_category(category)

    if tag:
        reports = get_reports_by_tag(tag)

    if implemented:
        reports = [r for r in reports if r.implemented]

    click.echo(f"{'ID':<12} {'Category':<12} {'Title'}")
    click.echo("-" * 60)
    for r in sorted(reports, key=lambda x: (x.category.value, x.id)):
        click.echo(f"{r.id:<12} {r.category.value:<12} {r.title}")

    click.echo(f"\nTotal: {len(reports)} reports")


@cli.command("info")
@click.argument("report_id")
def info(report_id: str) -> None:
    """Show detailed information about a report."""
    report = get_report(report_id)
    if not report:
        click.echo(f"Report not found: {report_id}", err=True)
        sys.exit(1)

    click.echo(f"ID: {report.id}")
    click.echo(f"Title: {report.title}")
    click.echo(f"Description: {report.description}")
    click.echo(f"Category: {report.category.value}")
    click.echo(f"Priority: {report.priority}")
    click.echo(f"Chart Type: {report.chart_type or 'table'}")
    click.echo(f"Tags: {', '.join(report.tags) or 'none'}")
    click.echo(f"Implemented: {'Yes' if report.implemented else 'No'}")
    click.echo(f"Output Table: {report.output_table or 'none'}")
    click.echo(f"Dependencies: {', '.join(report.depends_on_tables) or 'none'}")
    click.echo()
    click.echo("SQL:")
    click.echo(report.sql)


@cli.command("run")
@click.argument("report_id")
@click.option("-d", "--database", required=True, type=click.Path(exists=True), help="DuckDB database path")
@click.option("-o", "--output", type=click.Path(), help="Output file path")
@click.option("-f", "--format", "fmt", type=click.Choice(["csv", "excel", "table"]), default="table")
@click.option("--create-table", is_flag=True, help="Create persistent table in database")
def run(report_id: str, database: str, output: str | None, fmt: str, create_table: bool) -> None:
    """Execute a single report."""
    report = get_report(report_id)
    if not report:
        click.echo(f"Report not found: {report_id}", err=True)
        sys.exit(1)

    runner = ReportRunner(db_path=database)
    result = runner.run(report, create_table=create_table)

    if result.status.value != "success":
        click.echo(f"Report failed: {result.error_message}", err=True)
        sys.exit(1)

    if result.data is None:
        click.echo("No data returned")
        return

    if fmt == "table":
        click.echo(result.data.to_string())
    elif output:
        output_path = Path(output)
        if fmt == "excel":
            result.data.to_excel(output_path, index=False, engine="openpyxl")
        else:
            result.data.to_csv(output_path, index=False)
        click.echo(f"Exported to {output_path}")
    else:
        click.echo(result.data.to_csv(index=False))

    runner.close()


@cli.command("run-all")
@click.option("-d", "--database", required=True, type=click.Path(exists=True), help="DuckDB database path")
@click.option("-o", "--output-dir", type=click.Path(), help="Output directory")
@click.option("-f", "--format", "fmt", type=click.Choice(["csv", "excel"]), default="csv")
@click.option("-c", "--category", help="Filter by category")
@click.option("--create-tables", is_flag=True, help="Create persistent tables")
@click.option("--stop-on-error", is_flag=True, help="Stop on first error")
def run_all(
    database: str,
    output_dir: str | None,
    fmt: str,
    category: str | None,
    create_tables: bool,
    stop_on_error: bool,
) -> None:
    """Execute multiple reports."""
    reports = REPORTS
    if category:
        reports = get_reports_by_category(category)

    # Only implemented reports
    reports = [r for r in reports if r.implemented]

    runner = ReportRunner(db_path=database)
    results = runner.run_all(reports, create_tables=create_tables, stop_on_error=stop_on_error)

    # Summary
    success = sum(1 for r in results if r.status.value == "success")
    failed = sum(1 for r in results if r.status.value == "failed")
    skipped = sum(1 for r in results if r.status.value == "skipped")

    click.echo(f"Completed: {success} success, {failed} failed, {skipped} skipped")

    # Export if output dir specified
    if output_dir:
        exporter = ReportExporter(output_dir, runner=runner)
        for result in results:
            if result.data is not None:
                exporter.export_result(result, format=fmt)
        exporter.export_summary(results)
        click.echo(f"Results exported to {output_dir}")

    runner.close()


@cli.command("validate")
@click.argument("report_id", required=False)
@click.option("-d", "--database", required=True, type=click.Path(exists=True), help="DuckDB database path")
@click.option("--all", "validate_all", is_flag=True, help="Validate all reports")
def validate(report_id: str | None, database: str, validate_all: bool) -> None:
    """Validate report SQL syntax."""
    runner = ReportRunner(db_path=database)

    if validate_all:
        reports = [r for r in REPORTS if r.implemented]
    elif report_id:
        report = get_report(report_id)
        if not report:
            click.echo(f"Report not found: {report_id}", err=True)
            sys.exit(1)
        reports = [report]
    else:
        click.echo("Specify report ID or --all", err=True)
        sys.exit(1)

    valid_count = 0
    invalid_count = 0

    for report in reports:
        is_valid, error = runner.validate(report)
        if is_valid:
            valid_count += 1
            click.echo(f"✓ {report.id}")
        else:
            invalid_count += 1
            click.echo(f"✗ {report.id}: {error}")

    click.echo(f"\n{valid_count} valid, {invalid_count} invalid")
    runner.close()

    if invalid_count > 0:
        sys.exit(1)


@cli.command("docs")
@click.option("-o", "--output", type=click.Path(), help="Output file (default: stdout)")
@click.option("-c", "--category", help="Filter by category")
@click.option("--include-sql/--no-sql", default=True, help="Include SQL in docs")
def docs(output: str | None, category: str | None, include_sql: bool) -> None:
    """Generate report documentation."""
    from .schema import SchemaGenerator

    reports = REPORTS
    if category:
        reports = get_reports_by_category(category)

    gen = SchemaGenerator()
    markdown = gen.generate_report_documentation(reports, include_sql=include_sql)

    if output:
        Path(output).write_text(markdown)
        click.echo(f"Documentation written to {output}")
    else:
        click.echo(markdown)


@cli.command("schema")
@click.option("-d", "--database", required=True, type=click.Path(exists=True), help="DuckDB database path")
@click.option("-s", "--schema", "schemas", multiple=True, help="Schema(s) to include")
@click.option("-o", "--output", type=click.Path(), help="Output file")
@click.option("--format", "fmt", type=click.Choice(["markdown", "json"]), default="markdown")
@click.option("--samples/--no-samples", default=True, help="Include sample data")
def schema(database: str, schemas: tuple[str, ...], output: str | None, fmt: str, samples: bool) -> None:
    """Generate schema documentation."""
    gen = SchemaGenerator(db_path=database)

    schema_list = list(schemas) if schemas else None

    if fmt == "json":
        import json
        result = json.dumps(gen.export_schema_json(schema_list), indent=2)
    else:
        result = gen.generate_schema_markdown(schemas=schema_list, include_samples=samples)

    if output:
        Path(output).write_text(result)
        click.echo(f"Schema documentation written to {output}")
    else:
        click.echo(result)

    gen.close()


@cli.command("prompt")
@click.option("-d", "--database", required=True, type=click.Path(exists=True), help="DuckDB database path")
@click.option("-s", "--schema", "schemas", multiple=True, help="Schema(s) to include")
@click.option("-t", "--task", default="analyze data and generate insights", help="Analysis task")
@click.option("-o", "--output", type=click.Path(), help="Output file")
@click.option("--samples/--no-samples", default=True, help="Include sample data")
def prompt(database: str, schemas: tuple[str, ...], task: str, output: str | None, samples: bool) -> None:
    """Generate AI prompt with schema context."""
    gen = SchemaGenerator(db_path=database)

    schema_list = list(schemas) if schemas else None
    result = gen.generate_ai_prompt(schemas=schema_list, task=task, include_samples=samples)

    if output:
        Path(output).write_text(result)
        click.echo(f"Prompt written to {output}")
    else:
        click.echo(result)

    gen.close()


@cli.command("categories")
def categories() -> None:
    """List available report categories."""
    for cat in ReportCategory:
        count = len([r for r in REPORTS if r.category == cat])
        click.echo(f"{cat.value:<15} ({count} reports)")


def main() -> None:
    """Entry point."""
    cli()


if __name__ == "__main__":
    main()
