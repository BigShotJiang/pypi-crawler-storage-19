"""
Report runner - Execute SQL reports against DuckDB.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import duckdb
    import pandas as pd

from .models import ReportResult, ReportSpec, ReportStatus

logger = logging.getLogger(__name__)


class ReportRunner:
    """Execute SQL reports against DuckDB database."""

    def __init__(self, db_path: str | Path | None = None, connection: "duckdb.DuckDBPyConnection | None" = None):
        """
        Initialize runner with database path or existing connection.

        Args:
            db_path: Path to DuckDB database file (optional if connection provided)
            connection: Existing DuckDB connection (optional)
        """
        self._db_path = Path(db_path) if db_path else None
        self._connection = connection
        self._owns_connection = connection is None

    def _get_connection(self) -> "duckdb.DuckDBPyConnection":
        """Get or create database connection."""
        import duckdb

        if self._connection is not None:
            return self._connection

        if self._db_path is None:
            # In-memory database
            self._connection = duckdb.connect(":memory:")
        else:
            self._connection = duckdb.connect(str(self._db_path))
        
        return self._connection

    def close(self) -> None:
        """Close database connection if owned."""
        if self._owns_connection and self._connection is not None:
            self._connection.close()
            self._connection = None

    def run(
        self,
        report: ReportSpec,
        create_table: bool = False,
        schema: str = "reports",
    ) -> ReportResult:
        """
        Execute a single report.

        Args:
            report: Report specification to execute
            create_table: If True, create a persistent table with results
            schema: Schema name for output tables

        Returns:
            ReportResult with execution status and data
        """
        start_time = datetime.now()
        con = self._get_connection()

        try:
            # Check if report is implemented
            if not report.implemented:
                return ReportResult(
                    report=report,
                    status=ReportStatus.SKIPPED,
                    started_at=start_time,
                    completed_at=datetime.now(),
                    error_message="Report not implemented",
                )

            # Execute the SQL
            result = con.execute(report.sql)
            df: "pd.DataFrame" = result.fetchdf()

            # Optionally create table
            if create_table and report.output_table:
                con.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")
                table_name = f"{schema}.{report.output_table}"
                con.execute(f"DROP TABLE IF EXISTS {table_name}")
                con.execute(f"CREATE TABLE {table_name} AS {report.sql}")
                logger.info(f"Created table {table_name}")

            return ReportResult(
                report=report,
                status=ReportStatus.SUCCESS,
                started_at=start_time,
                completed_at=datetime.now(),
                row_count=len(df),
                data=df,
            )

        except Exception as e:
            logger.error(f"Report {report.id} failed: {e}")
            return ReportResult(
                report=report,
                status=ReportStatus.FAILED,
                started_at=start_time,
                completed_at=datetime.now(),
                error_message=str(e),
            )

    def run_all(
        self,
        reports: list[ReportSpec],
        create_tables: bool = False,
        schema: str = "reports",
        stop_on_error: bool = False,
    ) -> list[ReportResult]:
        """
        Execute multiple reports.

        Args:
            reports: List of report specifications
            create_tables: If True, create persistent tables with results
            schema: Schema name for output tables
            stop_on_error: If True, stop execution on first error

        Returns:
            List of ReportResult for each report
        """
        results: list[ReportResult] = []

        for report in reports:
            result = self.run(report, create_table=create_tables, schema=schema)
            results.append(result)

            if stop_on_error and result.status == ReportStatus.FAILED:
                logger.warning(f"Stopping due to error in {report.id}")
                break

        return results

    def run_by_category(
        self,
        category: str,
        reports: list[ReportSpec],
        create_tables: bool = False,
        schema: str = "reports",
    ) -> list[ReportResult]:
        """Run all reports in a category."""
        filtered = [r for r in reports if r.category.value == category]
        return self.run_all(filtered, create_tables=create_tables, schema=schema)

    def run_by_tag(
        self,
        tag: str,
        reports: list[ReportSpec],
        create_tables: bool = False,
        schema: str = "reports",
    ) -> list[ReportResult]:
        """Run all reports with a specific tag."""
        filtered = [r for r in reports if tag in r.tags]
        return self.run_all(filtered, create_tables=create_tables, schema=schema)

    def preview(self, report: ReportSpec, limit: int = 10) -> "pd.DataFrame":
        """
        Preview report results with limited rows.

        Args:
            report: Report specification
            limit: Maximum rows to return

        Returns:
            DataFrame with preview data
        """
        con = self._get_connection()
        limited_sql = f"SELECT * FROM ({report.sql}) AS subq LIMIT {limit}"
        result = con.execute(limited_sql)
        return result.fetchdf()

    def validate(self, report: ReportSpec) -> tuple[bool, str | None]:
        """
        Validate report SQL without full execution.

        Args:
            report: Report specification

        Returns:
            Tuple of (is_valid, error_message)
        """
        con = self._get_connection()
        try:
            # Use EXPLAIN to validate without executing
            con.execute(f"EXPLAIN {report.sql}")
            return (True, None)
        except Exception as e:
            return (False, str(e))

    def check_dependencies(
        self,
        report: ReportSpec,
    ) -> tuple[bool, list[str]]:
        """
        Check if report dependencies (tables) exist.

        Args:
            report: Report specification

        Returns:
            Tuple of (all_exist, missing_tables)
        """
        con = self._get_connection()
        missing: list[str] = []

        for table in report.depends_on_tables:
            try:
                con.execute(f"SELECT 1 FROM {table} LIMIT 0")
            except Exception:
                missing.append(table)

        return (len(missing) == 0, missing)
