"""
Report exporter - Export reports to CSV/Excel files.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd

from .models import ReportResult, ReportSpec, ReportStatus
from .runner import ReportRunner

logger = logging.getLogger(__name__)


class ReportExporter:
    """Export report results to files."""

    def __init__(self, output_dir: str | Path, runner: ReportRunner | None = None):
        """
        Initialize exporter.

        Args:
            output_dir: Directory for output files
            runner: Optional ReportRunner to execute reports
        """
        self._output_dir = Path(output_dir)
        self._output_dir.mkdir(parents=True, exist_ok=True)
        self._runner = runner

    def _sanitize_filename(self, name: str) -> str:
        """Make string safe for filename."""
        return "".join(c if c.isalnum() or c in "-_" else "_" for c in name)

    def export_result(
        self,
        result: ReportResult,
        format: str = "csv",
        include_timestamp: bool = True,
    ) -> Path | None:
        """
        Export a single report result to file.

        Args:
            result: ReportResult with data
            format: Output format ('csv' or 'excel')
            include_timestamp: Add timestamp to filename

        Returns:
            Path to created file, or None if no data
        """
        if result.data is None or result.status != ReportStatus.SUCCESS:
            logger.warning(f"Skipping {result.report.id}: no data or failed")
            return None

        # Build filename
        base_name = self._sanitize_filename(result.report.id)
        if include_timestamp:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            base_name = f"{base_name}_{ts}"

        if format == "excel":
            filepath = self._output_dir / f"{base_name}.xlsx"
            result.data.to_excel(filepath, index=False, engine="openpyxl")
        else:
            filepath = self._output_dir / f"{base_name}.csv"
            result.data.to_csv(filepath, index=False)

        logger.info(f"Exported {result.report.id} to {filepath}")
        return filepath

    def export_report(
        self,
        report: ReportSpec,
        format: str = "csv",
        include_timestamp: bool = True,
    ) -> Path | None:
        """
        Execute and export a single report.

        Args:
            report: Report specification
            format: Output format ('csv' or 'excel')
            include_timestamp: Add timestamp to filename

        Returns:
            Path to created file, or None if failed
        """
        if self._runner is None:
            raise ValueError("ReportRunner required to export reports directly")

        result = self._runner.run(report)
        return self.export_result(result, format=format, include_timestamp=include_timestamp)

    def export_all(
        self,
        reports: list[ReportSpec],
        format: str = "csv",
        include_timestamp: bool = True,
    ) -> dict[str, Path | None]:
        """
        Execute and export multiple reports.

        Args:
            reports: List of report specifications
            format: Output format ('csv' or 'excel')
            include_timestamp: Add timestamp to filename

        Returns:
            Dict mapping report ID to file path (or None if failed)
        """
        if self._runner is None:
            raise ValueError("ReportRunner required to export reports directly")

        results: dict[str, Path | None] = {}

        for report in reports:
            try:
                path = self.export_report(
                    report,
                    format=format,
                    include_timestamp=include_timestamp,
                )
                results[report.id] = path
            except Exception as e:
                logger.error(f"Failed to export {report.id}: {e}")
                results[report.id] = None

        return results

    def export_workbook(
        self,
        results: list[ReportResult],
        filename: str = "reports.xlsx",
    ) -> Path:
        """
        Export multiple reports to a single Excel workbook.

        Each report becomes a separate worksheet.

        Args:
            results: List of ReportResults with data
            filename: Output filename

        Returns:
            Path to created workbook
        """
        import pandas as pd

        filepath = self._output_dir / filename

        with pd.ExcelWriter(filepath, engine="openpyxl") as writer:
            for result in results:
                if result.data is None or result.status != ReportStatus.SUCCESS:
                    continue

                # Truncate sheet name to Excel limit (31 chars)
                sheet_name = result.report.id[:31]
                result.data.to_excel(writer, sheet_name=sheet_name, index=False)

        logger.info(f"Exported {len(results)} reports to {filepath}")
        return filepath

    def export_summary(
        self,
        results: list[ReportResult],
        filename: str = "summary.csv",
    ) -> Path:
        """
        Export execution summary.

        Args:
            results: List of ReportResults
            filename: Output filename

        Returns:
            Path to summary file
        """
        import pandas as pd

        summary_data = []
        for r in results:
            summary_data.append({
                "report_id": r.report.id,
                "title": r.report.title,
                "category": r.report.category.value,
                "status": r.status.value,
                "row_count": r.row_count,
                "duration_seconds": r.duration.total_seconds() if r.duration else None,
                "error": r.error_message,
            })

        df = pd.DataFrame(summary_data)
        filepath = self._output_dir / filename
        df.to_csv(filepath, index=False)

        logger.info(f"Exported summary to {filepath}")
        return filepath
