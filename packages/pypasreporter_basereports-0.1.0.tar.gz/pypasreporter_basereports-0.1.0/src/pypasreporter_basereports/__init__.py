"""
pyPASreporter-baseReports: CyberArk PAM reports generator.

Provides 100 pre-built SQL reports for analyzing CyberArk PAM data including:
- Safe inventory and analysis
- Account statistics and compliance
- User activity and permissions
- Session and recording analytics
- Security and risk assessments

Features:
- Execute reports against DuckDB database
- Export to CSV/Excel formats
- Generate report documentation
- Generate AI prompts with schema context
- Prepare datasets for Superset visualization

Usage:
    basereports run --db ./data.duckdb --category safe
    basereports export --db ./data.duckdb --format excel -o reports/
    basereports docs --output docs/reports/
    basereports schema --tables users,safes,files
"""

from __future__ import annotations

__version__ = "0.1.0"
__all__ = [
    "ReportSpec",
    "ReportResult",
    "ReportCategory",
    "ReportRunner",
    "ReportExporter",
    "SchemaGenerator",
    "REPORTS",
    "__version__",
]

from .models import ReportCategory, ReportResult, ReportSpec
from .reports import REPORTS
from .runner import ReportRunner
from .exporter import ReportExporter
from .schema import SchemaGenerator
