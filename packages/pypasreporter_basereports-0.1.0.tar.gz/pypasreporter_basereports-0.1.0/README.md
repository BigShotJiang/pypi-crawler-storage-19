# pyPASreporter-baseReports

**CyberArk PAM reports generator** with 100 pre-built SQL queries, CSV/Excel exports, and Apache Superset integration.

Part of the [pyPASreporter](https://github.com/itpamltd/pyPASreporter) ecosystem.

## Installation

```bash
pip install pyPASreporter-baseReports
```

## Features

- **100 pre-built reports** across 10 categories
- **SQL-based** - Pure SQL queries optimized for DuckDB
- **Export to CSV/Excel** - Single or batch export
- **AI prompt generation** - Generate prompts with full schema context
- **Superset integration** - Prepare datasets and dashboards
- **Extensible** - Add custom reports easily

## Report Categories

| Category | Reports | Description |
|----------|---------|-------------|
| Safe | 12 | Safe inventory and analysis |
| Account | 15 | Account management reports |
| User | 12 | User activity analysis |
| Permission | 10 | Permission and ownership |
| Session | 10 | PSM session analysis |
| Security | 10 | Security assessments |
| Compliance | 10 | Compliance checks |
| CPM | 8 | Password management |
| Platform | 8 | Platform/policy analysis |
| Audit | 5 | Audit trail reports |

## Quick Start

### List available reports

```bash
basereports list
basereports list --category safe
```

### Run a single report

```bash
basereports run SAFE-001 -d vault.duckdb
basereports run ACCT-001 -d vault.duckdb -o accounts.csv -f csv
```

### Run all reports

```bash
basereports run-all -d vault.duckdb -o ./exports --format csv
```

### Generate documentation

```bash
basereports docs -o reports.md
```

### Generate AI prompt with schema

```bash
basereports prompt -d vault.duckdb -t "find security issues" -o prompt.txt
```

## Python API

```python
from pypasreporter_basereports import REPORTS, ReportRunner, ReportExporter

# List reports
for report in REPORTS:
    print(f"{report.id}: {report.title}")

# Run a report
runner = ReportRunner(db_path="vault.duckdb")
result = runner.run(REPORTS[0])
print(result.data)

# Export to Excel
exporter = ReportExporter("./exports", runner=runner)
exporter.export_all(REPORTS, format="excel")
```

## Report Structure

Each report is defined as a `ReportSpec`:

```python
ReportSpec(
    id="SAFE-001",
    title="Safe Inventory",
    description="Complete list of all safes",
    category=ReportCategory.SAFE,
    sql="SELECT * FROM evd.safes ORDER BY safe_name",
    chart_type="table",
    depends_on_tables=["evd.safes"],
)
```

## Related Packages

- [pyPASreporter-EVDparser](https://pypi.org/project/pyPASreporter-EVDparser/) - Parse EVD exports to DuckDB
- [pyPASreporter-PACLIparser](https://pypi.org/project/pyPASreporter-PACLIparser/) - Parse PACLI exports
- [pyPASreporter-superset](https://pypi.org/project/pyPASreporter-superset/) - Superset integration

## License

MIT License - see [LICENSE](LICENSE) for details.
