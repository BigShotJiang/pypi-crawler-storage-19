CryoEM validation analysis pipeline

