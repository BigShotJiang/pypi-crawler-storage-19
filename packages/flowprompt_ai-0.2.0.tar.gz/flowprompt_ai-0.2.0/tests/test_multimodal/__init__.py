"""Tests for multimodal support."""
