"""FlowPrompt test suite."""
