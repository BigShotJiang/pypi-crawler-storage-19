# 🧙‍♂️ Agewizard

**Agewizard** is a world-class, magic-like Python library designed to handle all your age and date of birth (DOB) calculations with zero effort. Whether you need an exact age, zodiac signs, or next birthday countdowns, Agewizard does it all in a single line.

[![PyPI Version](https://img.shields.io/pypi/v/agewizard.svg)](https://pypi.org/project/agewizard/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## ✨ Features

- **🚀 Instant Age**: Calculate age in years, months, weeks, or days.
- **📅 Flexible Parsing**: Automatically handles formats like `YYYY-MM-DD`, `YYYY.MM.DD`, `YYYY/MM/DD`, or even spaces.
- **♈ Zodiac Magic**: Get star signs (Aries, Leo, etc.) instantly from a DOB.
- **🎂 Birthday Insights**: Countdown to the next birthday and find out what day of the week it falls on.
- **👶 Age Classification**: Automatically classify life stages (Infant, Child, Teen, Adult, Senior).
- **🌗 Multi-Cultural**: Includes basic Hijri lunar age approximation.
- **🤝 Comparisons**: Compare two different birth dates to see who is older and by exactly how many days.

---

## 🛠 Installation

```bash
pip install agewizard
```

---

## 📖 Detailed Usage

### 1. Interactive User Input (The Easiest Way)
Agewizard is built for real-world apps where users provide input.

```python
from agewizard import Age

# Get input from user
user_dob = input("Enter your Date of Birth (YYYY-MM-DD): ")

try:
    person = Age(user_dob)
    print(f"Wizard says you are {person.years} years old!")
    print(f"Your star sign is {person.zodiac}.")
    print(f"Days until your next cake: {person.next_birthday_days}")
except Exception as e:
    print(f"Error: {e}")
```

### 2. The Comprehensive `Age` Object
One object, all the data.

```python
from agewizard import Age

p = Age("1995-05-15")

print(p.years)           # 30
print(p.months)          # 368
print(p.days)            # 11210
print(p.readable)        # "30 years, 7 months, 24 days"
print(p.category)        # "Adult"
print(p.is_today)        # True if it's their birthday!
```

### 3. Comparing Two People
Perfect for social apps or family statistics.

```python
from agewizard import compare_ages

result = compare_ages("1990-01-01", "1995-05-15")
print(result) # "Person 1 is older by approx 5 years (1960 days)."
```

### 4. Specialized Logic
```python
from agewizard import is_leap_year, next_birthday_weekday

print(is_leap_year("2000-01-01")) # True
print(next_birthday_weekday("2000-01-01")) # "Thursday"
```

---

## 💎 Why Agewizard?

Most libraries require complex `datetime` arithmetic. Agewizard wraps all that complexity into a **Fluent API** that reads like a story. It's built for developers who value their time and want clean, production-ready code.

---

## 👨‍💻 Author
**Kamran Hussain**  
- **Email**: [contact.kamrankami@gmail.com](mailto:contact.kamrankami@gmail.com)  
- **GitHub**: [KamranProjects](https://github.com/KamranProjects)

---

## 📜 License
Agewizard is open-source software licensed under the **MIT License**.
