"""Version information for isage-flow."""

__version__ = "0.1.1"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
