# Compresr Python SDK

Intelligent prompt compression to optimize LLM costs and performance.

## Project Structure

```
sdk/python/
├── compresr/                    # Main SDK package
│   ├── __init__.py             
│   ├── clients.py              # API clients (CompletionClient, etc.)
│   ├── config.py               # SDK configuration
│   ├── schemas/                # Request/response schemas (synced from backend)
│   │   ├── __init__.py
│   │   ├── base.py            # Base response schemas
│   │   ├── compress.py        # Compression schemas
│   │   ├── completion.py      # Completion schemas
│   │   └── usage.py           # Usage/billing schemas
│   ├── exceptions/            # Exception classes (synced from backend)
│   │   ├── __init__.py
│   │   └── exceptions.py      # All error types and exceptions
│   └── services/              # Core SDK services
├── tests/                     # Test suite
├── tutorial/                  # SDK tutorial notebooks
├── build-local-sdk.sh         # Local development build (with tests)
├── build-and-deploy.sh        # Build + deployment script
├── sync_schemas.py            # Schema sync utility (exact copies)
├── build_sdk_old.py           # Legacy build script (with transformations)
├── pre_deploy_test.py         # Pre-deployment tests
├── deploy.py                  # Deployment script
├── test_clients.py            # Client integration tests
├── pyproject.toml             # Package configuration
└── requirements.txt           # Dependencies
```

## Quick Start

### 1. Environment Setup

**Option A: Conda (Recommended)**
```bash
# Create conda environment with Python 3.12
conda create --name compresr-sdk python=3.12 -y

# Activate environment
conda activate compresr-sdk

# Navigate to SDK directory
cd sdk/python

# Install dependencies
pip install -r requirements.txt
```

**Option B: Python venv**
```bash
# Create virtual environment
python -m venv compresr-sdk-env
source compresr-sdk-env/bin/activate  # macOS/Linux
# OR
compresr-sdk-env\Scripts\activate     # Windows

# Navigate to SDK directory
cd sdk/python

# Install dependencies
pip install -r requirements.txt
```

### 2. Build Options

**Local Development Build (with verification)**
```bash
./build-local-sdk.sh
```
- Same as standard build
- + Runs import tests to verify build
- + Shows detailed success/warning messages
- Best for active development

**Build and Deploy**
```bash
./build-and-deploy.sh
```
- Builds SDK
- Runs pre-deployment tests
- Deploys to PyPI (production)

### 3. Manual Build Steps

If you prefer manual control:
```bash
# Sync schemas from backend (exact copies)
python sync_schemas.py

# Install SDK in development mode
pip install -e .
```

## Testing

### Test Structure

```
tests/
├── __init__.py
├── test_*.py           # Individual test modules
└── conftest.py         # Test configuration
```

### Running Tests

**Basic Test Suite**
```bash
# Run all tests
python -m pytest tests/ -v

# Run specific test file
python -m pytest tests/test_clients.py -v

# Run with coverage
python -m pytest tests/ --cov=compresr -v
```

**Integration Tests**
```bash
# Run client integration tests (requires API keys)
python test_clients.py
```

**Pre-Deployment Tests**
```bash
# Run comprehensive pre-deployment test suite
python pre_deploy_test.py
```

### Tutorial Notebook

The SDK includes an interactive tutorial notebook:

```
tutorial/
└── sdk_tutorial.ipynb  # Interactive SDK tutorial and examples
```

**Why Use the Notebook?**
- **Interactive Learning**: Step-by-step SDK exploration
- **Live Testing**: Test API calls with your own keys
- **Examples**: Real-world usage patterns
- **Documentation**: Self-documenting code examples
- **Debugging**: Easy to modify and test individual components

**Running the Tutorial**
```bash
# Install Jupyter (if not already installed)
pip install jupyter

# Start Jupyter notebook
jupyter notebook tutorial/sdk_tutorial.ipynb
```

## Deployment Workflow

### Development → Production Pipeline

**1. Development & Testing**
```bash
# Build for local development
./build-local-sdk.sh

# Run and fix any issues
python test_clients.py
python -m pytest tests/ -v

# Work through tutorial notebook
jupyter notebook tutorial/sdk_tutorial.ipynb
```

**2. Pre-Deployment Validation**
```bash
# Run comprehensive pre-deployment tests
python pre_deploy_test.py
```

**3. Deployment**
```bash
# Deploy to PyPI
python deploy.py
```

**Complete Build and Deploy**
```bash
# One-command build, test, and deploy
./build-and-deploy.sh
```

### Build Scripts Explained

| Script | Purpose | When to Use |
|--------|---------|-------------|
| `sync_schemas.py` | Copies exact schemas from backend | Manual schema updates |
| `build-local-sdk.sh` | Build with verification tests | Active development |
| `build-and-deploy.sh` | Full pipeline (build + test + deploy) | Production releases |

## Environment Configuration

### API Keys Setup

Create a `.env` file in the SDK directory with your API keys:

```bash
# .env file
# Compression Service API Key (for CompressionClient)
COMPRESSION_API_KEY=cmp_compression_api_key_here

# Completion Service API Key (for CompletionClient) 
COMPLETION_API_KEY=cmp_completion_api_key_here

# Legacy: Single API Key (for backward compatibility)
# COMPRESR_API_KEY=cmp_your_actual_api_key_here
```

**Important: API Key Authentication Required**

The Compresr SDK **requires** API key authentication. JWT tokens are NOT supported for SDK usage.

| Endpoint Type | Authentication | Description |
|---------------|----------------|-------------|
| Compression (`/compress/*`) | API Key Only | `X-API-Key: cmp_...` header required |
| Completion (`/completion/*`) | API Key Only | `X-API-Key: cmp_...` header required |
| Demo (`/compress/demo`) | JWT Only | Browser-based demo (not for SDK) |

**Key Benefits:**
- 🔐 **Separate Services**: Use different API keys for compression vs completion
- 💰 **Cost Control**: Track usage separately by service type
- 🛡️ **Security**: Limit access scope per service
- 📊 **Analytics**: Better insights into service usage patterns

**Getting API Keys:**
1. Visit [compresr.io](https://compresr.io) and create an account
2. Navigate to your API Keys section
3. Generate separate keys for:
   - **Compression Service**: Text compression operations (`scope: compress`)
   - **Completion Service**: Compression + LLM completion (`scope: completion`)
4. Copy keys to your `.env` file

## Quick Start

```python
from compresr import CompletionClient, CompressionClient
from compresr.services.proxy import BaseClient

# Initialize base client with API key
base_client = BaseClient(api_key="cmp_your_api_key")

# Completion: Compress + LLM call
completion_client = CompletionClient(base_client)
response = completion_client.generate(
    prompt="Your long prompt here...",
    target_model="gpt-4o-mini"
)
print(response.data.target_model_response)

# Compression only: Just compress text
compression_client = CompressionClient(base_client)
response = compression_client.generate(
    prompt="Your long prompt here...",
    target_model="gpt-4o-mini"
)
print(response.data.compressed_prompt)
```

## Streaming

```python
# Stream completion
for chunk in completion_client.generate_stream(
    prompt="Write a story about...",
    target_model="gpt-4o-mini"
):
    print(chunk.content, end="", flush=True)
```
python build_sdk.py
pip install -e .
```

## Testing Installation

```bash
## Troubleshooting

### Common Issues

**Schema Import Errors**
```bash
# If you see backend dependency errors in schemas
# Run schema sync to get fresh copies from backend
python sync_schemas.py

# Then reinstall
pip install -e .
```

**Build Script Permissions**
```bash
# Make shell scripts executable
chmod +x *.sh
```

**Environment Issues**
```bash
# Verify conda environment is active
conda info --active

# Check Python version (should be 3.12)
python --version

# Verify SDK installation
python -c "import compresr; print('SDK installed successfully')"
```

**Backend Dependencies**
- The schemas contain references to `app.config` and `app.schemas`
- This is expected - the schemas are exact copies from backend
- The SDK handles these dependencies internally
- Use shell scripts for proper build process

### Development Workflow

**Recommended Development Cycle:**

1. **Setup Environment** (once)
   ```bash
   conda create --name compresr-sdk python=3.12 -y
   conda activate compresr-sdk
   cd sdk/python
   pip install -r requirements.txt
   ```

2. **Daily Development**
   ```bash
   # Quick build and test
   ./build-local-sdk.sh
   
   # Work on changes...
   
   # Test your changes
   python test_clients.py
   python -m pytest tests/ -v
   ```

3. **Pre-Release Testing**
   ```bash
   # Comprehensive testing
   python pre_deploy_test.py
   
   # Tutorial verification
   jupyter notebook tutorial/sdk_tutorial.ipynb
   ```

4. **Release**
   ```bash
   # Full build, test, and deploy
   ./build-and-deploy.sh
   ```

### File Descriptions

| File | Purpose |
|------|---------|
| `sync_schemas.py` | Copies exact schemas from backend (no transformations) |
| `build_sdk_old.py` | Legacy build script (with import transformations) |
| `build-local-sdk.sh` | Development build with verification tests |
| `build-and-deploy.sh` | Complete build and deployment pipeline |
| `pre_deploy_test.py` | Comprehensive pre-deployment test suite |
| `deploy.py` | PyPI deployment script |
| `test_clients.py` | Integration tests for API clients |
| `tutorial/sdk_tutorial.ipynb` | Interactive tutorial and examples |
conda activate compresr-sdk

# Test basic import
python -c "import compresr; print('✅ SDK imported successfully!')"

# Check available clients
python -c "from compresr import CompletionClient, CompressionClient; print('✅ Clients available!')"
```

## Quick Start

### Completion Client (Compression + LLM)

```python
from compresr import CompletionClient

client = CompletionClient(api_key="cmp_your_api_key")

# Generate completion
result = client.generate(
    text="Your long prompt here...",
    target_model="gpt-4o-mini"
)
print(result.data.target_model_response)
```

### Compression Client (Compression Only)

```python
from compresr import CompressionClient

client = CompressionClient(api_key="cmp_your_api_key")

# Get compressed prompt for your own LLM
result = client.generate(
    prompt="Your long prompt here...",
    target_model="gpt-4o-mini"
)
compressed = result.data.compressed_prompt
# Use with your own LLM: your_llm(compressed)
```

## Features

- **2 Dedicated Clients**: Completion (compression + LLM) and Compression (compression only)
- **Async Support**: All methods have async variants
- **Streaming**: Real-time response streaming
- **Batch Processing**: Process multiple requests efficiently
- **Usage Tracking**: Monitor credits and costs

## Examples

### Streaming

```python
# Completion streaming
for chunk in client.generate_stream(text="...", target_model="gpt-4o-mini"):
    print(chunk.content, end="")

# Compression streaming
compression_client = CompressionClient(api_key="...")
for chunk in compression_client.generate_stream(prompt="..."):
    print(chunk.content, end="")
```

### Async Operations

```python
import asyncio

async def main():
    client = CompletionClient(api_key="...")
    result = await client.generate_async(text="...", target_model="gpt-4o-mini")
    await client.close()

asyncio.run(main())
```

### Batch Processing

```python
client = CompressionClient(api_key="...")
results = client.generate_batch([
    {"prompt": "Text 1...", "target_model": "gpt-4o-mini"},
    {"prompt": "Text 2...", "target_model": "gpt-4o-mini"}
])
```

### Usage Tracking

```python
usage = client.get_usage()
print(f"Credits: {usage.data.credits_remaining}")
print(f"Balance: ${usage.data.balance_usd}")
```

## Architecture

```
compresr/
├── __init__.py              # Exports: CompletionClient, CompressionClient
├── clients.py               # Both client classes + BaseCompresrClient
├── services/                # Service implementations
│   ├── completion.py        # Completion service
│   ├── compression.py       # Compression service
│   └── proxy_client.py      # HTTP client base
├── schemas/                 # Data models (copied from backend)
└── exceptions/              # Exception classes (copied from backend)
```

## Architecture Summary

The SDK maintains exact schema copies from the backend, ensuring consistency while providing a clean API interface. The build system automates the sync process and provides different build options for various development needs.

**Key Design Principles:**
- ✅ **Single Source of Truth**: Schemas live in backend, copied to SDK
- ✅ **Exact Copies**: No transformations to maintain consistency  
- ✅ **Automated Sync**: Build scripts handle schema copying
- ✅ **Multiple Build Options**: Standard, local development, and deployment builds
- ✅ **Comprehensive Testing**: Unit tests, integration tests, and notebook tutorials

## Next Steps

1. **Setup**: Follow the environment setup instructions
2. **Build**: Run `./build-local-sdk.sh` for development
3. **Test**: Run the test suite to verify everything works
4. **Tutorial**: Work through the Jupyter notebook
5. **Develop**: Start building with the SDK!

## Support

For issues, questions, or contributions, please refer to the main project documentation or create an issue in the repository.

## License

MIT License