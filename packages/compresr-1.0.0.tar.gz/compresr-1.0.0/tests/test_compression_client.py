"""
Integration Tests for CompressionClient

Tests for the CompressionClient which handles compression-only operations.
Uses ADMIN keys for full functional testing (no rate limits).
Uses USER keys for rate limit testing.

Run with: pytest tests/test_compression_client.py -v
"""

import os
import time
import pytest
from pathlib import Path
from dotenv import load_dotenv

from compresr import CompressionClient
from compresr.schemas import (
    CompressResponse,
    BatchCompressResponse,
    StreamChunk,
)
from compresr.exceptions import RateLimitError, ServerError, AuthenticationError

# Load environment variables from project root .env.test
env_path = Path(__file__).parent.parent.parent.parent / ".env.test"
load_dotenv(env_path)

# Default compression model
DEFAULT_COMPRESSION_MODEL = "cmprsr-v1"


def handle_admin_usage_limit(e):
    """Helper to handle unexpected usage limits in admin tests."""
    if "usage limit" in str(e).lower() or "insufficient credits" in str(e).lower() or "rpd limit" in str(e).lower():
        pytest.skip(f"Admin account hit usage limit (should not happen): {e}")
    raise e


def handle_usage_limits(func):
    """Decorator to handle usage limit errors gracefully."""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except (ServerError, RateLimitError) as e:
            if "usage limit" in str(e) or "budget" in str(e) or "credits" in str(e):
                pytest.skip(f"Skipping due to API usage limits: {e}")
            raise
    return wrapper


# =============================================================================
# Fixtures - Admin Keys (No Rate Limit)
# =============================================================================

@pytest.fixture
def admin_api_key():
    """Get ADMIN API key (no rate limit) for comprehensive testing."""
    key = os.getenv("COMPRESSION_SERVICE_ADMIN_KEY")
    if not key:
        pytest.skip("COMPRESSION_SERVICE_ADMIN_KEY not set in .env.test")
    return key


@pytest.fixture
def user_api_key():
    """Get USER API key (with rate limit) for rate limit testing."""
    key = os.getenv("COMPRESSION_SERVICE_USER_KEY")
    if not key:
        pytest.skip("COMPRESSION_SERVICE_USER_KEY not set in .env.test")
    return key


@pytest.fixture
def base_url():
    """Get base URL from environment."""
    return os.getenv("COMPRESR_BASE_URL", "http://localhost:8000")


@pytest.fixture
def admin_client(admin_api_key, base_url):
    """Create CompressionClient with ADMIN key (no rate limit)."""
    return CompressionClient(api_key=admin_api_key, base_url=base_url)


@pytest.fixture
def user_client(user_api_key, base_url):
    """Create CompressionClient with USER key (with rate limit)."""
    return CompressionClient(api_key=user_api_key, base_url=base_url)


@pytest.fixture
def completion_api_key():
    """Get completion service API key that should NOT work with compression-only service."""
    key = os.getenv("COMPLETION_SERVICE_ADMIN_KEY")
    if not key:
        pytest.skip("COMPLETION_SERVICE_ADMIN_KEY not set in .env.test")
    return key


# =============================================================================
# FUNCTIONAL TESTS - Using Admin Key (No Rate Limit)
# =============================================================================

class TestBasicCompression:
    """Basic compression tests using admin key."""

    def test_basic_compression(self, admin_client):
        """Test basic sync compression with simple prompt."""
        try:
            response = admin_client.generate(
                prompt="Explain the concept of machine learning and its applications in modern technology.",
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
            )
        except (ServerError, RateLimitError) as e:
            handle_admin_usage_limit(e)
        
        assert response is not None
        assert isinstance(response, CompressResponse)
        assert response.success is True
        assert response.data is not None
        assert response.data.original_tokens > 0
        assert response.data.compressed_tokens > 0
        assert response.data.compressed_prompt is not None
        assert len(response.data.compressed_prompt) > 0

    def test_compression_returns_metrics(self, admin_client):
        """Test that compression returns all expected metrics."""
        response = admin_client.generate(
            prompt="Explain the theory of relativity and its implications for modern physics.",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.data.original_tokens is not None
        assert response.data.compressed_tokens is not None
        assert response.data.actual_compression_ratio is not None


class TestCompressionRatio:
    """Tests for compression ratio control."""

    def test_compression_with_ratio(self, admin_client):
        """Test compression with specified compression ratio."""
        prompt = """
        Please explain the concept of machine learning in detail, 
        including supervised learning, unsupervised learning, and 
        reinforcement learning approaches. Cover the history, 
        applications, and future trends in this field.
        """
        
        response = admin_client.generate(
            prompt=prompt,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
            compression_ratio=0.5,
        )
        
        assert response.success is True
        assert response.data.actual_compression_ratio is not None


class TestAsyncCompression:
    """Tests for asynchronous compression."""

    @pytest.mark.asyncio
    async def test_async_compression(self, admin_client):
        """Test basic async compression."""
        response = await admin_client.generate_async(
            prompt="What is the meaning of artificial intelligence?",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert response.data.compressed_prompt is not None


class TestBatchCompression:
    """Tests for batch compression."""

    def test_batch_compression(self, admin_client):
        """Test batch compression with multiple prompts."""
        prompts = [
            "Explain what artificial intelligence is and how it works.",
            "Describe the process of machine learning model training.",
            "What are neural networks and how do they function?"
        ]
        
        response = admin_client.generate_batch(
            prompts=prompts,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert len(response.data.results) >= 2  # Mock has 2 results
        assert len(response.data.results) == len(prompts)


class TestStreamingCompression:
    """Tests for streaming compression."""

    def test_streaming_compression(self, admin_client):
        """Test streaming compression yields chunks."""
        chunks = []
        content = ""
        
        for chunk in admin_client.generate_stream(
            prompt="Write a detailed explanation of how blockchain technology works.",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        ):
            chunks.append(chunk)
            assert isinstance(chunk, StreamChunk)
            if chunk.content:
                content += chunk.content
        
        assert len(chunks) > 0
        assert chunks[-1].done is True
        assert len(content) > 0


class TestTokenCounting:
    """Tests for token counting accuracy."""

    def test_compressed_fewer_tokens(self, admin_client):
        """Test that compressed text has fewer or equal tokens."""
        response = admin_client.generate(
            prompt="Explain quantum computing and its potential applications in cryptography and security.",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
            compression_ratio=0.5,
        )
        
        assert response.data.compressed_tokens <= response.data.original_tokens


class TestLargePrompts:
    """Tests for handling large prompts."""

    def test_large_prompt_compression(self, admin_client):
        """Test handling of large prompts and token counting."""
        large_prompt = """
        The history of artificial intelligence (AI) began in antiquity, with myths, 
        stories and rumors of artificial beings endowed with intelligence or consciousness 
        by master craftsmen. The seeds of modern AI were planted by classical philosophers 
        who attempted to describe the process of human thinking as the mechanical manipulation 
        of symbols. This work culminated in the invention of the programmable digital computer 
        in the 1940s, a machine based on the abstract essence of mathematical reasoning.
        
        This device and the ideas behind it inspired a handful of scientists to begin seriously 
        discussing the possibility of building an electronic brain. The field of AI research 
        was founded at a workshop held on the campus of Dartmouth College during the summer of 1956.
        
        Machine learning, a subset of AI, allows systems to learn from data without being 
        explicitly programmed. Deep learning, a subset of machine learning, uses neural networks 
        with many layers to model complex patterns in data.
        """
        
        response = admin_client.generate(
            prompt=large_prompt,
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        assert response.success is True
        assert response.data.original_tokens > 100
        assert response.data.compressed_tokens <= response.data.original_tokens


class TestResponseStructure:
    """Tests for response structure validation."""

    def test_response_structure(self, admin_client):
        """Test response has all expected fields."""
        response = admin_client.generate(
            prompt="Test prompt for validation of response structure.",
            compression_model_name=DEFAULT_COMPRESSION_MODEL,
        )
        
        # Check top-level response
        assert hasattr(response, 'success')
        assert isinstance(response.success, bool)
        assert hasattr(response, 'data')
        assert response.data is not None
        
        # Check data fields
        data = response.data
        assert hasattr(data, 'original_tokens')
        assert hasattr(data, 'compressed_tokens')
        assert hasattr(data, 'compressed_prompt')
        assert hasattr(data, 'actual_compression_ratio')
        assert hasattr(data, 'compressed_prompt')
        assert isinstance(data.compressed_prompt, str)


# =============================================================================
# RATE LIMIT TESTS - Using User Key (With Rate Limit)
# =============================================================================

class TestRateLimit:
    """Tests for rate limit behavior using USER key."""

    def test_rate_limit_triggered(self, user_client):
        """Test that rate limit is triggered after multiple rapid requests."""
        # Make rapid requests to trigger rate limit
        responses = []
        rate_limited = False
        
        for i in range(10):  # Try 10 rapid requests
            try:
                response = user_client.generate(
                    prompt=f"Test prompt number {i} for rate limit testing.",
                    compression_model_name=DEFAULT_COMPRESSION_MODEL,
                )
                responses.append(response)
            except RateLimitError:
                rate_limited = True
                break
            except Exception as e:
                if "rate limit" in str(e).lower() or "429" in str(e):
                    rate_limited = True
                    break
        
        # Either we got rate limited (expected) or all requests succeeded (admin-like key)
        assert rate_limited or len(responses) > 0, "Expected either rate limit or successful responses"


# =============================================================================
# ERROR HANDLING TESTS - No API calls needed
# =============================================================================

class TestErrorHandling:
    """Tests for error handling - validation errors."""

    def test_empty_prompt_error(self, admin_client):
        """Test that empty prompt raises error."""
        with pytest.raises(Exception):
            admin_client.generate(
                prompt="",
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
            )

    def test_invalid_compression_ratio_high(self, admin_client):
        """Test that compression ratio > 0.9 raises error."""
        with pytest.raises(Exception):
            admin_client.generate(
                prompt="Test prompt",
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
                compression_ratio=1.5,
            )

    def test_invalid_compression_ratio_low(self, admin_client):
        """Test that compression ratio < 0.1 raises error."""
        with pytest.raises(Exception):
            admin_client.generate(
                prompt="Test prompt",
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
                compression_ratio=0.05,
            )


class TestAPIKeyIsolation:
    """Tests for API key isolation - completion keys should not work for compression service."""

    def test_completion_key_fails_for_compression_service(self, completion_api_key, base_url):
        """Test that completion service API key cannot be used for compression service."""
        client = CompressionClient(
            api_key=completion_api_key,  # Use completion key for compression service (should fail)
            base_url=base_url
        )
        
        # Should fail with authentication error since completion key can't access compression service
        with pytest.raises((AuthenticationError, Exception)) as exc_info:
            client.generate(
                prompt="Test prompt for compression service.",
                compression_model_name=DEFAULT_COMPRESSION_MODEL,
            )
        
        # Verify it's a scope error - completion key used for compression service
        error_msg = str(exc_info.value).lower()
        assert any(word in error_msg for word in ['scope', 'completion', 'compress', 'not allowed']), \
            f"Expected scope error for wrong API key type, got: {exc_info.value}"


# =============================================================================
# Run tests if executed directly
# =============================================================================
if __name__ == "__main__":
    pytest.main([__file__, "-v"])
