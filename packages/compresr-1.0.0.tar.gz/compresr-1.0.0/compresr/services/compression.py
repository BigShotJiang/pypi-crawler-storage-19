"""
CompressionClient - Compression Only

Compresses prompts without calling an LLM.
Use when you want to integrate with your own LLM pipeline.
"""

from typing import Optional, List, Generator
from .proxy import HTTPClient
from ..config import ENDPOINTS
from ..schemas import (
    StreamChunk,
    CompressRequest,
    CompressResponse,
    BatchCompressRequest,
    BatchCompressResponse,
)


class CompressionClient(HTTPClient):
    """
    Compression client - compression only, no LLM call.
    
    Args:
        api_key: Your Compresr API key (required) - "cmp_..."
        base_url: API base URL (optional)
        timeout: Request timeout in seconds (optional)
    
    Example:
        client = CompressionClient(api_key="cmp_...")
        
        response = client.generate(
            prompt="Your long prompt...",
            compression_model_name="cmprsr-v1"
        )
        print(response.data.compressed_prompt)
    """
    
    # ==================== Sync ====================
    
    def generate(
        self,
        prompt: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> CompressResponse:
        """
        Compress text (sync).
        
        Args:
            prompt: Text to compress
            compression_model_name: Compression model to use (e.g., "cmprsr-v1") - REQUIRED
            compression_ratio: Target ratio 0.1-0.9 (optional)
        
        Returns:
            CompressResponse with compressed text and metrics
        """
        req = CompressRequest(
            prompt=prompt,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPRESS, req.model_dump(exclude_none=True))
        return CompressResponse.model_validate(data)
    
    def generate_batch(
        self,
        prompts: List[str],
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> BatchCompressResponse:
        """
        Batch compression (sync).
        
        Args:
            prompts: List of prompts (max 100)
            compression_model_name: Compression model to use - REQUIRED
            compression_ratio: Target ratio (optional)
        """
        req = BatchCompressRequest(
            prompts=prompts,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPRESS_BATCH, req.model_dump(exclude_none=True))
        return BatchCompressResponse.model_validate(data)
    
    def generate_stream(
        self,
        prompt: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> Generator[StreamChunk, None, None]:
        """
        Stream compression (sync).
        
        Yields:
            StreamChunk objects with compressed content
        """
        req = CompressRequest(
            prompt=prompt,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        for content in self.stream(ENDPOINTS.COMPRESS_STREAM, req.model_dump(exclude_none=True)):
            yield StreamChunk(content=content, done=False)
        yield StreamChunk(content="", done=True)
    
    # ==================== Async ====================
    
    async def generate_async(
        self,
        prompt: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> CompressResponse:
        """Compress text (async)."""
        req = CompressRequest(
            prompt=prompt,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPRESS, req.model_dump(exclude_none=True))
        return CompressResponse.model_validate(data)
    
    async def generate_batch_async(
        self,
        prompts: List[str],
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> BatchCompressResponse:
        """Batch compression (async)."""
        req = BatchCompressRequest(
            prompts=prompts,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPRESS_BATCH, req.model_dump(exclude_none=True))
        return BatchCompressResponse.model_validate(data)
