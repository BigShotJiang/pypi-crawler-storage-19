"""
CompletionClient - Compress + LLM Call

Compresses prompts and sends them to target LLMs using YOUR API key.
"""

from typing import Optional, List, Generator
from .proxy import HTTPClient
from ..config import ENDPOINTS
from ..exceptions import AuthenticationError, ValidationError
from ..schemas import (
    StreamChunk,
    CompletionRequest,
    CompletionResponse,
    BatchCompletionRequest,
    BatchCompletionResponse,
)


class CompletionClient(HTTPClient):
    """
    Completion client - compress + LLM call.
    
    Args:
        api_key: Your Compresr API key (required) - "cmp_..."
        target_api_key: Your LLM API key (required) - OpenAI "sk-...", Anthropic "sk-ant-..."
        default_model: Default target model (optional) - e.g., "gpt-4o-mini"
        base_url: API base URL (optional)
        timeout: Request timeout in seconds (optional)
    
    Example:
        client = CompletionClient(
            api_key="cmp_...",
            target_api_key="sk-...",  # Your OpenAI key
            default_model="gpt-4o-mini"
        )
        
        response = client.generate(prompt="Explain AI...")
        print(response.data.target_model_response)
    """
    
    def __init__(
        self,
        api_key: str,
        target_api_key: str,
        default_model: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[int] = None,
    ):
        super().__init__(api_key, base_url, timeout)
        
        if not target_api_key:
            raise AuthenticationError("target_api_key is required (your OpenAI/Anthropic API key)")
        
        self._target_api_key = target_api_key
        self._default_model = default_model
    
    def _model(self, target_model: Optional[str]) -> str:
        """Get model, using default if not provided."""
        model = target_model or self._default_model
        if not model:
            raise ValidationError("target_model required (or set default_model in __init__)")
        return model
    
    # ==================== Sync ====================
    
    def generate(
        self,
        prompt: str,
        target_model: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> CompletionResponse:
        """
        Generate completion (sync).
        
        Args:
            prompt: Text to compress and send to LLM
            target_model: LLM model - REQUIRED (e.g., "gpt-4o-mini", "claude-3-sonnet")
            compression_model_name: Compression model to use - REQUIRED (e.g., "cmprsr-v1")
            compression_ratio: Target ratio 0.3-0.7 (optional)
        
        Returns:
            CompletionResponse with metrics and LLM response
        """
        req = CompletionRequest(
            prompt=prompt,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPLETION, req.model_dump(exclude_none=True))
        return CompletionResponse.model_validate(data)
    
    def generate_batch(
        self,
        prompts: List[str],
        target_model: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> BatchCompletionResponse:
        """
        Batch completion (sync).
        
        Args:
            prompts: List of prompts (max 100)
            target_model: LLM model - REQUIRED
            compression_model_name: Compression model to use - REQUIRED
            compression_ratio: Target ratio (optional)
        """
        req = BatchCompletionRequest(
            prompts=prompts,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = self.post(ENDPOINTS.COMPLETION_BATCH, req.model_dump(exclude_none=True))
        return BatchCompletionResponse.model_validate(data)
    
    def generate_stream(
        self,
        prompt: str,
        target_model: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> Generator[StreamChunk, None, None]:
        """
        Stream completion (sync).
        
        Yields:
            StreamChunk objects with content
        """
        req = CompletionRequest(
            prompt=prompt,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        for content in self.stream(ENDPOINTS.COMPLETION_STREAM, req.model_dump(exclude_none=True)):
            yield StreamChunk(content=content, done=False)
        yield StreamChunk(content="", done=True)
    
    # ==================== Async ====================
    
    async def generate_async(
        self,
        prompt: str,
        target_model: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> CompletionResponse:
        """Generate completion (async)."""
        req = CompletionRequest(
            prompt=prompt,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPLETION, req.model_dump(exclude_none=True))
        return CompletionResponse.model_validate(data)
    
    async def generate_batch_async(
        self,
        prompts: List[str],
        target_model: str,
        compression_model_name: str,
        compression_ratio: Optional[float] = None,
    ) -> BatchCompletionResponse:
        """Batch completion (async)."""
        req = BatchCompletionRequest(
            prompts=prompts,
            target_model=target_model,
            target_api_key=self._target_api_key,
            target_compression_ratio=compression_ratio,
            compression_model_name=compression_model_name,
        )
        data = await self.post_async(ENDPOINTS.COMPLETION_BATCH, req.model_dump(exclude_none=True))
        return BatchCompletionResponse.model_validate(data)
