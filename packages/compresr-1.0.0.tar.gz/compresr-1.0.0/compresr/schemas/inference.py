"""
Inference Schemas

Generic, reusable schemas for all inference endpoints (compression + completion).

Architecture:
- Base classes define common fields
- Specific classes inherit and extend as needed
- DRY principle: No duplication

Schema Types:
1. Request - Input data
2. Result - Output data
3. Response - API response wrapper
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
# CompressionConfig constants (copied from backend)
class CompressionConfig:
    MIN_RATIO = 0.1
    MAX_RATIO = 0.9
    DEFAULT_RATIO = 0.5
from .base import BaseResponse


# =============================================================================
# Streaming Schemas
# =============================================================================

class StreamChunk(BaseModel):
    """A chunk of streamed response."""
    content: str
    done: bool = False
    error: Optional[str] = None


# =============================================================================
# Base Request Schemas (Common Fields)
# =============================================================================

class BaseInferenceRequest(BaseModel):
    """Base request with common inference fields."""
    prompt: str = Field(..., min_length=1, description="Prompt to compress")
    compression_model_name: str = Field(
        ...,
        description="Compression model to use (e.g., 'cmprsr-v1') - REQUIRED"
    )
    target_compression_ratio: Optional[float] = Field(
        None, 
        ge=CompressionConfig.MIN_RATIO, 
        le=CompressionConfig.MAX_RATIO, 
        description=f"Target compression ratio {CompressionConfig.MIN_RATIO}-{CompressionConfig.MAX_RATIO} (optional)"
    )


class BaseBatchInferenceRequest(BaseModel):
    """Base batch request with common fields."""
    prompts: List[str] = Field(..., min_length=1, max_length=100, description="List of prompts to compress")
    compression_model_name: str = Field(
        ...,
        description="Compression model to use (e.g., 'cmprsr-v1') - REQUIRED"
    )
    target_compression_ratio: Optional[float] = Field(
        None, 
        ge=CompressionConfig.MIN_RATIO, 
        le=CompressionConfig.MAX_RATIO, 
        description=f"Target compression ratio {CompressionConfig.MIN_RATIO}-{CompressionConfig.MAX_RATIO} (optional)"
    )


# =============================================================================
# Compression Request Schemas (no LLM call)
# =============================================================================

class CompressRequest(BaseInferenceRequest):
    """Request to compress prompt only (no LLM call)."""
    pass


class BatchCompressRequest(BaseBatchInferenceRequest):
    """Request to compress multiple prompts (no LLM call)."""
    pass


# =============================================================================
# Completion Request Schemas (compression + LLM call)
# =============================================================================

class CompletionRequest(BaseInferenceRequest):
    """Request to compress text and call target model."""
    target_api_key: str = Field(..., min_length=1, description="User's API key for the target model provider (required)")
    
    # Override target_model to make it required (no default)
    target_model: str = Field(..., description="Target LLM model (required) - e.g., gpt-4o, gpt-4o-mini, claude-3-sonnet")


class BatchCompletionRequest(BaseBatchInferenceRequest):
    """Request to compress multiple texts and call target model."""
    target_api_key: str = Field(..., min_length=1, description="User's API key for the target model provider (required)")
    
    # Override target_model to make it required (no default)
    target_model: str = Field(..., description="Target LLM model (required)")


# =============================================================================
# Base Result Schemas (Common Output Fields)
# =============================================================================

class BaseInferenceResult(BaseModel):
    """Base result with common inference output fields."""
    original_prompt: str = Field(..., description="Original input prompt")
    original_tokens: int = Field(..., description="Token count of original prompt")
    compressed_tokens: int = Field(..., description="Token count after compression")
    target_compression_ratio: Optional[float] = Field(None, description="User-requested compression ratio (if provided)")
    actual_compression_ratio: float = Field(..., description="Actual achieved compression ratio (0-1)")
    tokens_saved: int = Field(..., description="Number of tokens saved")
    duration_ms: int = Field(..., description="Processing time in milliseconds")

    model_config = {
        'from_attributes': True,
        'protected_namespaces': (),
    }


class BaseBatchResult(BaseModel):
    """Base batch result with aggregated metrics."""
    total_original_tokens: int = 0
    total_compressed_tokens: int = 0
    total_tokens_saved: int = 0
    average_compression_ratio: float = 0.0
    count: int = 0


# =============================================================================
# Compression Result Schemas (compression only, no LLM)
# =============================================================================

class CompressResult(BaseInferenceResult):
    """Compression result - metrics and compressed text."""
    compressed_prompt: str = Field(..., description="Compressed prompt")


class BatchCompressResult(BaseBatchResult):
    """Results for batch compression."""
    results: List[CompressResult] = []


# =============================================================================
# Completion Result Schemas (compression + LLM)
# =============================================================================

class CompletionResult(BaseInferenceResult):
    """
    Completion result - compression metrics and target model response.
    
    Public response (compressed_text is NOT included for non-admin users).
    """
    target_model: str = Field(..., description="Target model used")
    target_model_response: str = Field(..., description="Response content from target model")
    target_model_usage: Dict[str, Any] = Field(..., description="Token usage from target model (prompt_tokens, completion_tokens, total_tokens)")
    cost_usd: Optional[float] = Field(None, description="Cost in USD")


class AdminCompletionResult(CompletionResult):
    """
    Admin completion result - includes compressed text.
    
    Only returned to admin users. Contains the actual compressed text
    which is proprietary and should not be exposed to regular users.
    """
    compressed_text: str = Field(..., description="Compressed text (admin only)")


class BatchCompletionResult(BaseBatchResult):
    """Results for batch completion."""
    results: List[CompletionResult] = []
    total_cost_usd: Optional[float] = None


class AdminBatchCompletionResult(BaseBatchResult):
    """Admin results for batch completion (includes compressed texts)."""
    results: List[AdminCompletionResult] = []
    total_cost_usd: Optional[float] = None


# =============================================================================
# Response Schemas - Compression Only
# =============================================================================

class CompressResponse(BaseResponse):
    """Response for single compression."""
    data: Optional[CompressResult] = None


class BatchCompressResponse(BaseResponse):
    """Response for batch compression."""
    data: Optional[BatchCompressResult] = None


# =============================================================================
# Response Schemas - Completion
# =============================================================================

class CompletionResponse(BaseResponse):
    """Response for single completion."""
    data: Optional[CompletionResult] = None


class AdminCompletionResponse(BaseResponse):
    """Admin response for single completion (includes compressed text)."""
    data: Optional[AdminCompletionResult] = None


class BatchCompletionResponse(BaseResponse):
    """Response for batch completion."""
    data: Optional[BatchCompletionResult] = None


class AdminBatchCompletionResponse(BaseResponse):
    """Admin response for batch completion."""
    data: Optional[AdminBatchCompletionResult] = None


# =============================================================================
# Demo Data Schemas
# =============================================================================

class SampleText(BaseModel):
    """Sample text for demo interface."""
    name: str
    text: str


class ModelInfo(BaseModel):
    """Model info for demo interface."""
    value: str
    label: str
    provider: str


class DemoData(BaseModel):
    """Demo data container with samples and models."""
    sample_texts: List[SampleText]
    available_models: List[ModelInfo]


class DemoDataResponse(BaseResponse):
    """Response for demo data endpoint."""
    data: DemoData
