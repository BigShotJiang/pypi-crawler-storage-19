"""OpenTelemetry helpers for capturing tool calls during task execution.

This module provides the capture_tool_calls() context manager that captures
tool calls from OTEL-instrumented code (e.g., OpenAI via OpenInference).

The actual extraction logic is delegated to pluggable extractors in the
extractors module, allowing support for different instrumentation libraries.
"""

from __future__ import annotations

import logging
import os
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from threading import Lock
from typing import Any, Dict, Iterator, List, Optional

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import SERVICE_NAME, Resource
from opentelemetry.sdk.trace import ReadableSpan, SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor

from .extractors import DEFAULT_EXTRACTORS, ToolCallExtractor

logger = logging.getLogger(__name__)

# Context variable to track the current run for tool call collection
_CURRENT_RUN_ID: ContextVar[Optional[str]] = ContextVar(
    "cat_experiments_current_trace_run", default=None
)

# Storage for collected tool calls per run
_TOOL_CALLS: Dict[str, List[dict[str, Any]]] = {}
_TOOL_CALL_LOCK = Lock()


@dataclass
class ToolCallCapture:
    """Container for captured tool calls."""

    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    _run_id: str = field(default="", repr=False)


class ToolCallCollectorProcessor(SpanProcessor):
    """Span processor that collects tool calls from OTEL spans.

    Uses pluggable extractors to support different instrumentation libraries.
    """

    def __init__(self, extractors: list[ToolCallExtractor] | None = None):
        """Initialize with extractors.

        Args:
            extractors: List of extractors to try, in priority order.
                       Defaults to DEFAULT_EXTRACTORS.
        """
        self.extractors = extractors if extractors is not None else DEFAULT_EXTRACTORS

    def on_start(self, span: ReadableSpan, parent_context: Any = None) -> None:
        pass

    def on_end(self, span: ReadableSpan) -> None:
        run_id = _CURRENT_RUN_ID.get()
        if not run_id:
            return

        attributes = dict(span.attributes or {})

        # Try each extractor until one handles the span
        for extractor in self.extractors:
            if extractor.can_handle(span, attributes):
                tool_calls = extractor.extract(span, attributes)
                if tool_calls:
                    with _TOOL_CALL_LOCK:
                        _TOOL_CALLS.setdefault(run_id, []).extend(tool_calls)
                break  # Only use first matching extractor

    def shutdown(self) -> None:
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def _consume_collected_tool_calls(run_id: str) -> list[dict[str, Any]]:
    """Return and clear collected tool calls for a run."""
    with _TOOL_CALL_LOCK:
        return _TOOL_CALLS.pop(run_id, [])


def _parse_otlp_headers(header_str: str) -> dict[str, str]:
    """Parse OTEL_EXPORTER_OTLP_HEADERS environment variable."""
    headers: dict[str, str] = {}
    for pair in header_str.split(","):
        if not pair.strip() or "=" not in pair:
            continue
        key, value = pair.split("=", 1)
        headers[key.strip()] = value.strip()
    return headers


# Global collector processor - added once to the tracer provider
_collector_processor: Optional[ToolCallCollectorProcessor] = None
_provider_setup_done = False


def _ensure_tracing_setup(
    extractors: list[ToolCallExtractor] | None = None,
) -> None:
    """Set up tracing infrastructure for tool call capture.

    This creates a TracerProvider with our tool call collector if one doesn't exist.
    IMPORTANT: This should be called BEFORE any instrumentors (e.g., OpenInference)
    are set up, so that spans from instrumented libraries are captured.

    Args:
        extractors: Optional list of extractors to use. Defaults to DEFAULT_EXTRACTORS.
    """
    global _collector_processor, _provider_setup_done

    if _provider_setup_done:
        return

    provider = trace.get_tracer_provider()

    # If there's already a real TracerProvider, add our processor to it
    if isinstance(provider, TracerProvider):
        _collector_processor = ToolCallCollectorProcessor(extractors)
        provider.add_span_processor(_collector_processor)
        _provider_setup_done = True
        logger.debug("Added tool call collector to existing TracerProvider")
        return

    # Create a new TracerProvider with our collector
    resource = Resource({SERVICE_NAME: "cat-experiments"})
    new_provider = TracerProvider(resource=resource)

    # Add OTLP exporter if configured
    endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")
    if endpoint:
        try:
            headers = _parse_otlp_headers(os.getenv("OTEL_EXPORTER_OTLP_HEADERS", ""))
            new_provider.add_span_processor(
                SimpleSpanProcessor(OTLPSpanExporter(endpoint=endpoint, headers=headers))
            )
        except Exception as exc:
            logger.debug("Failed to configure OTLP exporter: %s", exc)

    # Add our tool call collector
    _collector_processor = ToolCallCollectorProcessor(extractors)
    new_provider.add_span_processor(_collector_processor)

    # Set as global provider
    trace.set_tracer_provider(new_provider)
    _provider_setup_done = True
    logger.debug("Created TracerProvider with tool call collector")


@contextmanager
def capture_tool_calls(
    extractors: list[ToolCallExtractor] | None = None,
) -> Iterator[ToolCallCapture]:
    """Capture tool calls from OTEL-instrumented code.

    Use this context manager in your @task function to automatically capture
    tool calls made by instrumented libraries (e.g., OpenAI via OpenInference).

    Example:
        from cat.experiments import task, TaskInput, TaskOutput
        from cat.experiments.tracing import capture_tool_calls

        @task
        async def my_task(input: TaskInput) -> TaskOutput:
            with capture_tool_calls() as captured:
                result = await my_agent.run(input.input["question"])

            return TaskOutput(output={
                "answer": result,
                "tool_calls": captured.tool_calls,
            })

    Args:
        extractors: Optional list of extractors to use for this capture.
                   Defaults to DEFAULT_EXTRACTORS which includes OpenInference,
                   OpenLLMetry, and generic tool span support.

    Yields:
        ToolCallCapture containing the captured tool calls after the context exits
    """
    # Ensure tracing infrastructure is set up
    _ensure_tracing_setup(extractors)

    run_id = f"capture-{uuid.uuid4().hex[:8]}"
    capture = ToolCallCapture(_run_id=run_id)

    # Set current run ID for tool call collection
    token = _CURRENT_RUN_ID.set(run_id)

    try:
        yield capture
    finally:
        # Reset run ID
        _CURRENT_RUN_ID.reset(token)

        # Collect tool calls into the capture object
        capture.tool_calls = _consume_collected_tool_calls(run_id)
