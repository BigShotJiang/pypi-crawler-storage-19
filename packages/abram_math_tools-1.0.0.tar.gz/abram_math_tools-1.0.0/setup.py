from setuptools import setup

setup(
    name="abram-math-tools",  
    version="1.0.0",
    description="A math tool library made by a 10-year-old developer.",
    author="Abram Jindal",
    py_modules=["tools"],      
    install_requires=["rich"], 
)