import subprocess
import sys

subprocess.run([sys.executable, "-m", "pip", "install", "rich"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

from rich import print

def show_creator():
    print("""
The creator of this module is Abram Jindal. He wanted to
create this after he learned that it is easy to make a
module of your own. This was made so that it is easy for
other people to perform calculations without any long or
advanced code. He created this module at the age of ten
and really wants more people to use it. I hope you found
this module useful to you. """ + ":grinning: "*5)

class Math:
    
    @staticmethod
    def __validate(value):
        if not isinstance(value, (int, float)):
            raise TypeError("You have to give a number only!")

    @staticmethod
    def add(*args):
        for n in args:
            Math.__validate(n)
        return sum(args)

    @staticmethod
    def subtract(num1, num2):
        Math.__validate(num1)
        Math.__validate(num2)
        return num1 - num2

    @staticmethod
    def multiply(*args):
        if not args:
            return 0
        result = 1
        for n in args:
            Math.__validate(n)
            result *= n
        return result

    @staticmethod
    def divide(num1, num2):
        Math.__validate(num1)
        Math.__validate(num2)
        if num2 == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return num1 / num2
    
    @staticmethod
    def powers(base, *exponents):
        if not exponents:
            return base
        Math.__validate(base)
        result = base
        for exponent in exponents: 
            Math.__validate(exponent)
            result = result ** exponent
        return result
    
    @staticmethod
    def sqrt(num1):
        Math.__validate(num1)
        return num1**0.5