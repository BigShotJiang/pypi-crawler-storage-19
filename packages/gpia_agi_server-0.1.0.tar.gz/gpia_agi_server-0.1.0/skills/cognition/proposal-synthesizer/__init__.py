"""Proposal synthesizer skill."""
