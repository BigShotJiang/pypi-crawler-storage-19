"""Reflex patch validator skill."""
