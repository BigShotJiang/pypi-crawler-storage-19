"""Resonant kernel package."""
