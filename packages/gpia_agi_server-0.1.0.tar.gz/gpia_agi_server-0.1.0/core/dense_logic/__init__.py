"""Dense logic helpers."""
