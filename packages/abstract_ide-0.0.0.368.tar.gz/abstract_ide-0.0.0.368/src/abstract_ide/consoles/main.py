from src import *
startIdeConsole()
