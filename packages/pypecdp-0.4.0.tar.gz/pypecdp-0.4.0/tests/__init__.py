"""Tests for pypecdp package."""
