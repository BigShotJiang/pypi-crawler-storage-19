"""
Metabase MCP Server Package
A Model Context Protocol server for interacting with Metabase.
"""

__version__ = "0.1.3"
__author__ = "Manish Balot"
