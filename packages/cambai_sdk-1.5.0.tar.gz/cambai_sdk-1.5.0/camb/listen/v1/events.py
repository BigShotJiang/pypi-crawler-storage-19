from enum import Enum

class EventType(str, Enum):
    OPEN = "open"
    MESSAGE = "message"
    CLOSE = "close"
    ERROR = "error"
