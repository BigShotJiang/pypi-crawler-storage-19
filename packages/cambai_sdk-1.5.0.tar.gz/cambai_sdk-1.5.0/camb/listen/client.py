from ..core.client_wrapper import AsyncClientWrapper, SyncClientWrapper
from .v1.client import AsyncListenV1Client, ListenV1Client

class ListenClient:
    def __init__(self, *, client_wrapper: SyncClientWrapper):
        self._client_wrapper = client_wrapper
        self._v1 = None

    @property
    def v1(self) -> ListenV1Client:
        if self._v1 is None:
            self._v1 = ListenV1Client(client_wrapper=self._client_wrapper)
        return self._v1

class AsyncListenClient:
    def __init__(self, *, client_wrapper: AsyncClientWrapper):
        self._client_wrapper = client_wrapper
        self._v1 = None

    @property
    def v1(self) -> AsyncListenV1Client:
        if self._v1 is None:
            self._v1 = AsyncListenV1Client(client_wrapper=self._client_wrapper)
        return self._v1
