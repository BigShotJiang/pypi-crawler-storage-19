"""Shared utilities for tool type detection.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

import ast
from typing import Any


def is_langchain_tool(ref: Any) -> bool:
    """Check if ref is a LangChain BaseTool class or instance.

    Shared by:
    - ToolRegistry._is_custom_tool() (for upload detection)
    - LangChainToolAdapter._is_langchain_tool() (for adaptation)

    Args:
        ref: Object to check.

    Returns:
        True if ref is a LangChain BaseTool class or instance.
    """
    try:
        from langchain_core.tools import BaseTool  # noqa: PLC0415

        if isinstance(ref, type) and issubclass(ref, BaseTool):
            return True
        if isinstance(ref, BaseTool):
            return True
    except ImportError:
        pass

    return False


def is_tool_plugin_decorator(decorator: ast.expr) -> bool:
    """Check if an AST decorator node is @tool_plugin.

    Shared by:
    - ToolBundler._has_tool_plugin_decorator() (for bundling)
    - ImportResolver._is_tool_plugin_decorator() (for import resolution)

    Args:
        decorator: AST decorator expression node to check.

    Returns:
        True if decorator is @tool_plugin.
    """
    if isinstance(decorator, ast.Name) and decorator.id == "tool_plugin":
        return True
    if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Name) and decorator.func.id == "tool_plugin":
        return True
    return False
