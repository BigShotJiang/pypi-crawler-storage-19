import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="llm_serving",
    version="0.0.6",
    author="Unergy/Solenium",
    author_email="pablo@solenium.co",
    description="A package to perform LLM inference in Solenium/Unergy HQ",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitlab.com/unergy-dev/ai/llm_serving_module",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires = [
        "requests",
        "httpx",
        "langchain",
        "langchain-core"
    ],
)