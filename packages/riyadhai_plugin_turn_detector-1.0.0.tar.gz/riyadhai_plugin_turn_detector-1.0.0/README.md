# riyadhai-plugin-turn-detector

Meta-package that installs turn-detector runtime dependencies for the RiyadhAI SDK.
