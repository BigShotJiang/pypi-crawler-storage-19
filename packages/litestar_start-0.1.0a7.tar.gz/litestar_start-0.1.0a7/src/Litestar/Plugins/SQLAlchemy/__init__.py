"""SQLAlchemy plugin for Litestar."""
