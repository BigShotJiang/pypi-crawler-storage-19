import json
import sys
from pathlib import Path
from colorama import Fore, Style, init
from m2h_ai.core import ask_ai

init(autoreset=True)

CONFIG_DIR = Path.home() / ".m2h-ai"
CONFIG_FILE = CONFIG_DIR / "config.json"


def banner():
    print(Fore.CYAN + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print(Fore.GREEN + "   M2H AI CLI")
    print(Fore.YELLOW + "   Powered by M2H Web Solution")
    print(Fore.MAGENTA + "   Type 'exit' to quit")
    print(Fore.CYAN + "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n")


def save_api_key():
    print(Fore.YELLOW + "🔐 OpenRouter API Key Required")
    key = input("Enter API key: ").strip()

    if not key.startswith("sk-or-"):
        print(Fore.RED + "❌ Invalid OpenRouter key format")
        sys.exit(1)

    CONFIG_DIR.mkdir(exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump({"api_key": key}, f)

    print(Fore.GREEN + "✅ API key saved successfully!\n")


def ensure_login():
    if not CONFIG_FILE.exists():
        save_api_key()


def run():
    ensure_login()
    banner()

    while True:
        try:
            user_input = input(Fore.BLUE + "m2h-ai ❯ ").strip()

            if user_input.lower() in ("exit", "quit"):
                print(Fore.GREEN + "\n👋 Goodbye from M2H AI")
                break

            if not user_input:
                continue

            print(Fore.YELLOW + "\nThinking...\n")
            response = ask_ai(user_input)
            print(Fore.WHITE + response + "\n")

        except KeyboardInterrupt:
            print(Fore.GREEN + "\n👋 Session ended")
            break
