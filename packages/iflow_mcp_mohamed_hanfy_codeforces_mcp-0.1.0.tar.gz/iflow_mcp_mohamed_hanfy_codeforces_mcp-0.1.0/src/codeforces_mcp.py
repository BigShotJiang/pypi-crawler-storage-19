from mcp.server.fastmcp import FastMCP
import logging
import json
from typing import Dict, Optional, Any
from urllib.parse import urlencode
import httpx

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CodeforcesAPI:
    BASE_URL = "https://codeforces.com/api"

    def __init__(self):
        self.client = httpx.AsyncClient(timeout=30.0)

    async def request(self, endpoint: str, params: Dict[str, Any] = None) -> Dict[str, Any]:
        url = f"{self.BASE_URL}/{endpoint}"
        if params:
            url += "?" + urlencode({k: v for k, v in params.items() if v is not None})
        try:
            response = await self.client.get(url)
            response.raise_for_status()
            data = response.json()
            if data.get("status") != "OK":
                raise Exception(f"API Error: {data.get('comment', 'Unknown error')}")
            return data.get("result", {})
        except Exception as e:
            logger.error(f"API request failed: {str(e)}")
            raise

api = CodeforcesAPI()

def create_server():
    server = FastMCP(name="codeforces-api-server")

    @server.tool(name="get_contest_list", description="Get list of contests")
    async def get_contest_list(gym: bool = False, group_code: Optional[str] = None) -> str:
        try:
            params = {"gym": "true" if gym else None, "groupCode": group_code}
            result = await api.request("contest.list", params)
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"


    @server.tool(name="get_contest_rating_changes", description="Get rating changes after a contest")
    async def get_contest_rating_changes(contest_id: int) -> str:
        try:
            result = await api.request("contest.ratingChanges", {"contestId": contest_id})
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"


    @server.tool(name="get_contest_standings", description="Get contest standings")
    async def get_contest_standings(contest_id: int, from_rank: Optional[int] = None,
                                    count: Optional[int] = None, handles: Optional[str] = None,
                                    show_unofficial: bool = False) -> str:
        try:
            params = {
                "contestId": contest_id,
                "from": from_rank,
                "count": count,
                "handles": handles,
                "showUnofficial": "true" if show_unofficial else None
            }
            result = await api.request("contest.standings", params)
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"


    @server.tool(name="get_contest_status", description="Get contest submissions")
    async def get_contest_status(contest_id: int, handle: Optional[str] = None,
                                 from_index: Optional[int] = None, count: Optional[int] = None) -> str:
        try:
            params = {
                "contestId": contest_id,
                "handle": handle,
                "from": from_index,
                "count": count
            }
            result = await api.request("contest.status", params)
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"

   

    @server.tool(name="get_recent_submissions", description="Get recent submissions")
    async def get_recent_submissions(count: int) -> str:
        try:
            result = await api.request("problemset.recentStatus", {"count": count})
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"


    @server.tool(name="get_user_info", description="Get user information")
    async def get_user_info(handles: str) -> str:
        try:
            result = await api.request("user.info", {"handles": handles})
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"


    @server.tool(name="get_user_rating", description="Get user's rating history")
    async def get_user_rating(handle: str) -> str:
        try:
            result = await api.request("user.rating", {"handle": handle})
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"


    @server.tool(name="get_user_submissions", description="Get user's submissions")
    async def get_user_submissions(handle: str, from_index: Optional[int] = None,
                                   count: Optional[int] = None) -> str:
        try:
            result = await api.request("user.status", {
                "handle": handle,
                "from": from_index,
                "count": count
            })
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"


    @server.tool(name="get_rated_users", description="Get list of rated users")
    async def get_rated_users(active_only: bool = False) -> str:
        try:
            result = await api.request("user.ratedList", {"activeOnly": "true" if active_only else None})
            return json.dumps(result, indent=2)
        except Exception as e:
            return f"Error: {str(e)}"

    return server

def main():
    server = create_server()
    logger.info("Starting Codeforces MCP server...")
    server.run(transport='stdio')

if __name__ == "__main__":
    main()
