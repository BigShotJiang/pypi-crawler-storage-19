"""Indexing layer for bloatcheck."""

from __future__ import annotations

import ast
import tokenize
from dataclasses import dataclass, field
from pathlib import Path

from .config import Config
from .fs import collect_py_files
from .util import read_text, repo_relative_path


@dataclass(frozen=True)
class TokenIndex:
    used_names: dict[str, int]
    comments: list[tuple[int, str]]


@dataclass(frozen=True)
class ImportIndex:
    aliases: dict[str, str]
    exported_names: set[str]
    modules: set[str]


@dataclass(frozen=True)
class SymbolInfo:
    path: str
    name: str
    qualname: str
    kind: str
    lineno: int
    end_lineno: int


@dataclass(frozen=True)
class FunctionInfo:
    symbol: SymbolInfo
    node: ast.AST


@dataclass(frozen=True)
class ClassInfo:
    symbol: SymbolInfo
    node: ast.ClassDef


@dataclass
class FileIndex:
    path: Path
    rel_path: str
    tokens: TokenIndex
    tree: ast.Module
    imports: ImportIndex
    symbols: list[SymbolInfo] = field(default_factory=list)
    functions: list[FunctionInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)


@dataclass
class RepoIndex:
    repo_root: Path
    files: list[FileIndex]
    symbols: list[SymbolInfo]
    functions: list[FunctionInfo]
    classes: list[ClassInfo]
    by_path: dict[str, FileIndex]


def build_index(config: Config) -> RepoIndex:
    roots = config.resolve_dirs(config.src_dirs + config.test_dirs + config.extra_dirs)
    py_files = collect_py_files(roots, config.exclude_globs, config.repo_root)

    file_indexes: list[FileIndex] = []
    all_symbols: list[SymbolInfo] = []
    all_functions: list[FunctionInfo] = []
    all_classes: list[ClassInfo] = []

    for path in py_files:
        src = read_text(path)
        rel_path = repo_relative_path(path, config.repo_root)

        try:
            tree = ast.parse(src, filename=str(path))
        except SyntaxError:
            continue

        tokens = _token_index(src)
        imports = _import_index(tree)
        symbols, functions, classes = _extract_symbols(
            tree, rel_path, config, module_name_for_path(rel_path, config)
        )

        file_index = FileIndex(
            path=path,
            rel_path=rel_path,
            tokens=tokens,
            tree=tree,
            imports=imports,
            symbols=symbols,
            functions=functions,
            classes=classes,
        )
        file_indexes.append(file_index)
        all_symbols.extend(symbols)
        all_functions.extend(functions)
        all_classes.extend(classes)

    by_path = {f.rel_path: f for f in file_indexes}
    return RepoIndex(
        repo_root=config.repo_root,
        files=sorted(file_indexes, key=lambda f: f.rel_path),
        symbols=all_symbols,
        functions=all_functions,
        classes=all_classes,
        by_path=by_path,
    )


def _token_index(src: str) -> TokenIndex:
    used_names: dict[str, int] = {}
    comments: list[tuple[int, str]] = []

    for token in tokenize.generate_tokens(iter(src.splitlines(keepends=True)).__next__):
        tok_type, tok_str, (line, _), _, _ = token
        if tok_type == tokenize.NAME:
            used_names[tok_str] = used_names.get(tok_str, 0) + 1
        elif tok_type == tokenize.COMMENT:
            comments.append((line, tok_str))

    return TokenIndex(used_names=used_names, comments=comments)


def _import_index(tree: ast.Module) -> ImportIndex:
    aliases: dict[str, str] = {}
    exported_names: set[str] = set()
    modules: set[str] = set()

    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            _collect_import_aliases(node, aliases, modules)
        elif isinstance(node, ast.Assign):
            exported_names.update(_extract_all_from_assign(node))
        elif isinstance(node, ast.Import):
            _collect_import_modules(node, modules)

    return ImportIndex(aliases=aliases, exported_names=exported_names, modules=modules)


def _collect_import_aliases(
    node: ast.ImportFrom, aliases: dict[str, str], modules: set[str]
) -> None:
    for alias in node.names:
        aliases[alias.asname or alias.name] = alias.name
    if node.module:
        modules.add(node.module)


def _collect_import_modules(node: ast.Import, modules: set[str]) -> None:
    for alias in node.names:
        modules.add(alias.name)


def _extract_all_from_assign(node: ast.Assign) -> set[str]:
    for target in node.targets:
        if isinstance(target, ast.Name) and target.id == "__all__":
            return _extract_all(node.value)
    return set()


def _extract_all(node: ast.AST) -> set[str]:
    values: set[str] = set()
    if isinstance(node, (ast.List, ast.Tuple)):
        for elt in node.elts:
            if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                values.add(elt.value)
    return values


def _extract_symbols(
    tree: ast.Module, rel_path: str, config: Config, module_name: str | None
) -> tuple[list[SymbolInfo], list[FunctionInfo], list[ClassInfo]]:
    symbols: list[SymbolInfo] = []
    functions: list[FunctionInfo] = []
    classes: list[ClassInfo] = []

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            sym = _symbol_from_node(node, rel_path, module_name, None, "function")
            symbols.append(sym)
            functions.append(FunctionInfo(symbol=sym, node=node))
        elif isinstance(node, ast.ClassDef):
            class_symbols, class_functions, class_classes = _collect_class_symbols(
                node, rel_path, module_name
            )
            symbols.extend(class_symbols)
            functions.extend(class_functions)
            classes.extend(class_classes)

    return symbols, functions, classes


def _collect_class_symbols(
    node: ast.ClassDef,
    rel_path: str,
    module_name: str | None,
) -> tuple[list[SymbolInfo], list[FunctionInfo], list[ClassInfo]]:
    symbols: list[SymbolInfo] = []
    functions: list[FunctionInfo] = []
    classes: list[ClassInfo] = []
    class_sym = _symbol_from_node(node, rel_path, module_name, None, "class")
    symbols.append(class_sym)
    classes.append(ClassInfo(symbol=class_sym, node=node))

    for item in node.body:
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
            meth_sym = _symbol_from_node(
                item, rel_path, module_name, node.name, "method"
            )
            symbols.append(meth_sym)
            functions.append(FunctionInfo(symbol=meth_sym, node=item))
    return symbols, functions, classes


def _symbol_from_node(
    node: ast.AST,
    rel_path: str,
    module_name: str | None,
    class_name: str | None,
    kind: str,
) -> SymbolInfo:
    name = getattr(node, "name", "<unknown>")
    qualname = _qualname(rel_path, module_name, class_name, name)
    lineno = getattr(node, "lineno", 1)
    end_lineno = getattr(node, "end_lineno", lineno)
    return SymbolInfo(
        path=rel_path,
        name=name,
        qualname=qualname,
        kind=kind,
        lineno=lineno,
        end_lineno=end_lineno,
    )


def module_name_for_path(rel_path: str, config: Config) -> str | None:
    parts = Path(rel_path).parts
    for src in config.src_dirs:
        src_parts = Path(src).parts
        if parts[: len(src_parts)] == src_parts:
            suffix = parts[len(src_parts) :]
            if not suffix:
                return None
            if suffix[-1].endswith(".py"):
                suffix = suffix[:-1] + (suffix[-1][:-3],)
            if suffix and suffix[-1] == "__init__":
                suffix = suffix[:-1]
            if not suffix:
                return None
            return ".".join(suffix)
    return None


def _qualname(
    rel_path: str, module_name: str | None, class_name: str | None, name: str
) -> str:
    if module_name:
        base = module_name
    else:
        base = rel_path
    if class_name:
        return f"{base}:{class_name}.{name}"
    return f"{base}:{name}"
