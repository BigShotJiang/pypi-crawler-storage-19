"""Filesystem helpers for bloatcheck."""

from __future__ import annotations

import fnmatch
from pathlib import Path, PurePosixPath


def collect_py_files(
    roots: list[Path], exclude_globs: list[str], repo_root: Path
) -> list[Path]:
    files: list[Path] = []
    for root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*.py"):
            if _is_excluded(path, exclude_globs, repo_root):
                continue
            files.append(path)
    return sorted(set(files), key=lambda p: str(p))


def _is_excluded(path: Path, exclude_globs: list[str], repo_root: Path) -> bool:
    rel_path: str | None = None
    try:
        rel_path = str(path.resolve().relative_to(repo_root.resolve()))
    except ValueError:
        rel_path = None
    rel_posix = PurePosixPath(rel_path) if rel_path else None

    path_posix = path.as_posix()
    rel_posix_str = rel_posix.as_posix() if rel_posix else None
    for pattern in exclude_globs:
        if fnmatch.fnmatchcase(path_posix, pattern):
            return True
        if rel_posix_str and fnmatch.fnmatchcase(rel_posix_str, pattern):
            return True
    return False
