from __future__ import annotations

from decimal import Decimal

from typing_extensions import (
    Self,  # PY311
)

from ._ast import PaddedRange, ParsedLooseSequence, Ranges
from ._base import BasePurePathSequence, PurePathT_co
from ._error import ParseError
from ._file_num_seq import FileNumSequence
from ._parse_loose_path_sequence import parse_path_sequence


class LoosePurePathSequence(BasePurePathSequence[PurePathT_co]):
    """A sequence of PurePath objects.

    Raises:
        NotASequenceError: When the given path does not represent a sequence,
            but a regular path.
        ParseError: When the given path is not a valid path sequence.
    """

    _parsed: ParsedLooseSequence

    def _parse(self, name: str) -> ParsedLooseSequence:
        return parse_path_sequence(name)

    @property
    def parsed(self) -> ParsedLooseSequence:
        """The parsed sequence string, as a tree of objects."""
        return self._parsed

    @property
    def suffix(self) -> str:
        """The file extension of the paths in the sequence.

        If there is no suffix, this will be the empty string.

        .. code-block:: pycon

            >>> LoosePurePathSequence('file1-3###').suffix
            ''
        """
        return super().suffix

    def with_suffix(self, suffix: str) -> Self:
        """Return a new path sequence with the suffix changed.

        If the given suffix is the empty string, the existing suffix will be removed.
        But if the path sequence has only one suffix,
        then a :exc:`ValueError` will be raised because removing the suffix will result in
        an invalid path sequence.

        Args:
            suffix: The new suffix to replace the existing suffix with.

        Raises:
            ValueError: If the given suffix would result in an invalid path sequence.
        """
        parsed = self._parsed.with_suffix(suffix)
        try:
            return self.with_segments(self._path.parent, str(parsed))
        except ParseError:
            raise ValueError(
                f"Cannot use suffix '{suffix}' because"
                " it would result in an invalid path sequence"
            )

    @property
    def stem(self) -> str:
        """The final path component, without any prefix, ranges, postfix, or suffixes.

        .. code-block:: pycon

            >>> LoosePurePathSequence('/path/to/images.1-3####.exr').stem
            'images'
            >>> LoosePurePathSequence('/path/to/1-3####_images.exr').stem
            'images'
            >>> LoosePurePathSequence('/path/to/images.exr.1-3####').stem
            'images'

        Unlike :attr:`pathlib.PurePath.stem`, this will never contain a suffix
        if the paths have multiple suffixes:

        .. code-block:: pycon

            >>> LoosePurePathSequence('/path/to/images.tar.gz.1-3####').stem
            'images'

        If the paths have no stem, then the empty string is returned:

        .. code-block:: pycon

            >>> LoosePurePathSequence('1-3#.tar.gz').stem
            ''
        """
        return super().stem

    def with_file_num_seqs(
        self, *seqs: FileNumSequence[int] | FileNumSequence[Decimal]
    ) -> Self:
        """Return a new sequence with the file number sequences changed.

        Raises:
            TypeError: If the given number of file number sequences does not match
                the sequence's number of file number sequences.
        """
        if len(seqs) != len(self._parsed.ranges.ranges):
            raise TypeError(
                f"Need {len(self._parsed.ranges.ranges)} sequences, but got {len(seqs)}"
            )

        new_ranges = tuple(
            PaddedRange(seq, range_.pad_format)
            for seq, range_ in zip(seqs, self._parsed.ranges.ranges)
        )
        new = self._parsed.__class__(
            stem=self._parsed.stem,
            prefix=self._parsed.prefix,  # type: ignore[arg-type]
            ranges=Ranges(new_ranges, self._parsed.ranges.inter_ranges),
            postfix=self._parsed.postfix,  # type: ignore[arg-type]
            suffixes=self._parsed.suffixes,
        )
        return self.__class__(self._path.with_name(str(new)))
