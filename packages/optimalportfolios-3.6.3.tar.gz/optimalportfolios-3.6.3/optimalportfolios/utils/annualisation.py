import warnings
import re


def get_annualization_factor(freq: str) -> float:
    """
    Calculate annualization factor from pandas frequency string.
    Handles various frequency formats including multipliers and anchors.

    Examples:
        'D' -> 252.0
        'W' -> 52.0
        'W-FRI' -> 52.0
        '2W' -> 26.0
        'ME' -> 12.0
        'Q-DEC' -> 4.0
        '3ME' -> 4.0
    """

    # Base annualization factors
    freq_to_annual = {
        'D': 252.0,  # Daily (trading days)
        'B': 252.0,  # Business days
        'W': 52.0,  # Weekly
        'WE': 52.0,  # Weekly
        'ME': 12.0,  # Month end (new pandas)
        'M': 12.0,  # Month end (old pandas)
        'MS': 12.0,  # Month start
        'BM': 12.0,  # Business month end
        'BMS': 12.0,  # Business month start
        'QE': 4.0,  # Quarter end (new pandas)
        'Q': 4.0,  # Quarter end (old pandas)
        'QS': 4.0,  # Quarter start
        'BQ': 4.0,  # Business quarter end
        'BQS': 4.0,  # Business quarter start
        'YE': 1.0,  # Year end (new pandas)
        'Y': 1.0,  # Year end (old pandas)
        'A': 1.0,  # Year end (old pandas)
        'YS': 1.0,  # Year start
        'AS': 1.0,  # Year start (old pandas)
        'BA': 1.0,  # Business year end
        'BAS': 1.0,  # Business year start
        'H': 252.0 * 2,  # Half-day (if needed)
        'T': 252.0 * 390,  # Minute (trading minutes per year)
        'MIN': 252.0 * 390,
    }

    # Parse frequency string to extract multiplier and base frequency
    # Handles: '2W', 'W-FRI', 'Q-DEC', '3ME', etc.
    match = re.match(r'^(\d+)?([A-Z]+)(?:-[A-Z]+)?$', freq.upper())

    if not match:
        # Fallback for unrecognized format
        return 1.0

    multiplier_str, base_freq = match.groups()
    multiplier = int(multiplier_str) if multiplier_str else 1

    # Get base annualization factor with default to one
    if base_freq not in freq_to_annual:
        warnings.warn(
            f"Unknown frequency '{base_freq}' (from '{freq}'). Using annualization factor of 1.0. "
            f"Supported frequencies: {', '.join(sorted(freq_to_annual.keys()))}",
            UserWarning,
            stacklevel=2
        )
        return 1.0

    base_factor = freq_to_annual[base_freq]
    # Adjust for multiplier (e.g., '2W' means every 2 weeks, so half the frequency)
    return base_factor / multiplier
