import os
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError


class SlackBot:
    def __init__(self):
        self.bot_token = os.environ.get("SLACK_BOT_TOKEN")
        if not self.bot_token:
            raise ValueError("SLACK_BOT_TOKEN environment variable not set.")
        
        self.slack_user_id = os.environ.get("SLACK_USER_ID")
        if not self.slack_user_id:
            raise ValueError("SLACK_USER_ID environment variable not set.")
        
        self.client = WebClient(token=self.bot_token)

    def send_message(self, message: str) -> bool:
        try:
            self.client.chat_postMessage(
                channel=self.slack_user_id, # Target your direct message channel
                text=message
            )
        except SlackApiError as e:
            print(f"Error sending message: {e.response['error']}")
