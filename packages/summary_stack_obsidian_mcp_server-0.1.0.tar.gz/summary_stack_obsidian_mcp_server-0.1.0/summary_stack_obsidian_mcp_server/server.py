"""MCP Server for creating Summary Stack notes in local Obsidian vaults."""

import logging

from fastmcp import FastMCP

from summary_stack_mcp_core import (
    get_related_stacks,
    get_stack,
    list_stacks,
    search_stacks,
)
from summary_stack_obsidian_mcp_server.config import load_config
from summary_stack_obsidian_mcp_server.services import (
    SummaryStackAPIClient,
    VaultService,
)

logger = logging.getLogger(__name__)

mcp = FastMCP("summary-stack-obsidian")

# Register core tools from summary_stack_mcp_core
mcp.tool()(search_stacks)
mcp.tool()(get_stack)
mcp.tool()(list_stacks)
mcp.tool()(get_related_stacks)


@mcp.tool
async def create_summary_stack(url: str, vault: str | None = None) -> str:
    """Create a Summary Stack from a URL and save it as an Obsidian note.

    Processes the URL through the Summary Stack API and generates a structured note.
    Related notes are linked via wiki-links; Obsidian handles bidirectional linking
    automatically through its Linked Mentions feature.

    Args:
        url: URL to process into a Summary Stack note
        vault: Name of the vault to save to (uses default if not specified)

    Returns:
        Summary of the created note including path and related notes count
    """
    config = load_config()
    vault_name = vault or config.default_vault

    # Validate vault exists
    config.get_vault(vault_name)

    api_client = SummaryStackAPIClient(config.api.url, config.api.key)
    vault_service = VaultService(config.vaults)

    # Step 1: Call API and get manifest
    logger.info(f"Creating summary stack for URL: {url}")
    manifest = await api_client.create_obsidian_manifest(url)

    # Step 2: Write note to vault
    logger.info(f"Writing note to vault: {vault_name}")
    note_path = await vault_service.write_note(vault_name, manifest)

    related_count = len(manifest.relationships) if manifest.relationships else 0

    return (
        f"Created Summary Stack note:\n"
        f"  Title: {manifest.title}\n"
        f"  Path: {note_path}\n"
        f"  ID: {manifest.summary_stack_id}\n"
        f"  Related notes linked: {related_count}"
    )


@mcp.tool
async def list_vault_stacks(limit: int = 10, vault: str | None = None) -> str:
    """List Summary Stack notes in your local Obsidian vault.

    Scans the vault for notes with summary_stack_id in frontmatter.
    Use 'list_stacks' to list stacks from the API instead.

    Args:
        limit: Maximum number of notes to return (default: 10)
        vault: Name of the vault to search (uses default if not specified)

    Returns:
        List of Summary Stack note paths found in the vault
    """
    config = load_config()
    vault_name = vault or config.default_vault

    vault_service = VaultService(config.vaults)

    async with vault_service.get_client(vault_name) as client:
        results = await client.search_notes(
            query="summary_stack_id",
            limit=limit,
            search_content=False,
            search_frontmatter=True,
        )

        if not results:
            return f"No Summary Stack notes found in vault '{vault_name}'"

        lines = [f"Found {len(results)} Summary Stack note(s) in '{vault_name}':"]
        for note in results:
            lines.append(f"  - {note.get('path', 'unknown')}")

        return "\n".join(lines)
