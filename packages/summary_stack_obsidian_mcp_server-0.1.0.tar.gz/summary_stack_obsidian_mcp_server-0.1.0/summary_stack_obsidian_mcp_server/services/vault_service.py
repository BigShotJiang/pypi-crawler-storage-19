"""Service for local Obsidian vault operations via MCP-Obsidian."""

import json
import logging
from contextlib import AsyncExitStack
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.types import TextContent

from summary_stack_obsidian_mcp_server.config import VaultConfig
from summary_stack_obsidian_mcp_server.models import ObsidianManifestResult


logger = logging.getLogger(__name__)


class VaultServiceError(Exception):
    """Error during vault operations."""

    pass


class ObsidianMCPClient:
    """Low-level wrapper around mcp-obsidian server.

    Uses the official MCP Python SDK to spawn mcp-obsidian as a subprocess
    and communicate via stdio transport.

    Usage:
        async with ObsidianMCPClient(vault_path) as client:
            result = await client.write_note("path/to/note.md", "# Content")
    """

    def __init__(self, vault_path: str):
        """Initialize the client.

        Args:
            vault_path: Absolute path to the Obsidian vault
        """
        self.vault_path = vault_path
        self._session: ClientSession | None = None
        self._exit_stack: AsyncExitStack | None = None

    async def __aenter__(self) -> "ObsidianMCPClient":
        """Start mcp-obsidian subprocess and establish connection."""
        self._exit_stack = AsyncExitStack()
        await self._exit_stack.__aenter__()

        server_params = StdioServerParameters(
            command="npx",
            args=["@mauricio.wolff/mcp-obsidian@0.7.3", self.vault_path],
        )

        try:
            stdio_transport = await self._exit_stack.enter_async_context(stdio_client(server_params))
            read_stream, write_stream = stdio_transport

            self._session = await self._exit_stack.enter_async_context(ClientSession(read_stream, write_stream))
            await self._session.initialize()

            logger.info(f"Connected to mcp-obsidian for vault: {self.vault_path}")

        except Exception as e:
            if self._exit_stack:
                await self._exit_stack.__aexit__(type(e), e, e.__traceback__)
            raise VaultServiceError(f"Failed to connect to mcp-obsidian: {e}") from e

        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Cleanup subprocess and close connection."""
        if self._exit_stack:
            await self._exit_stack.__aexit__(exc_type, exc_val, exc_tb)
            self._exit_stack = None
            self._session = None
            logger.info("Disconnected from mcp-obsidian")

    def _ensure_connected(self) -> ClientSession:
        """Ensure client is connected and return session."""
        if self._session is None:
            raise VaultServiceError("Client not connected. Use 'async with ObsidianMCPClient(...) as client:'")
        return self._session

    async def _call_tool(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any] | list[Any]:
        """Call a tool on the mcp-obsidian server."""
        session = self._ensure_connected()
        result = await session.call_tool(tool_name, arguments)

        if result.isError:
            first_content = result.content[0] if result.content else None
            error_msg = first_content.text if isinstance(first_content, TextContent) else "Unknown error"
            raise VaultServiceError(f"MCP tool '{tool_name}' failed: {error_msg}")

        if result.content and len(result.content) > 0:
            content = result.content[0]
            if isinstance(content, TextContent):
                try:
                    parsed: dict[str, Any] | list[Any] = json.loads(content.text)
                    return parsed
                except json.JSONDecodeError:
                    return {"message": content.text}

        return {}

    async def write_note(
        self,
        path: str,
        content: str,
        mode: str = "overwrite",
    ) -> dict[str, Any]:
        """Write a note to the vault."""
        args: dict[str, Any] = {"path": path, "content": content, "mode": mode}
        result = await self._call_tool("write_note", args)
        return result if isinstance(result, dict) else {}

    async def read_note(self, path: str) -> dict[str, Any]:
        """Read note content and frontmatter."""
        result = await self._call_tool("read_note", {"path": path, "prettyPrint": False})
        return result if isinstance(result, dict) else {}

    async def search_notes(
        self,
        query: str,
        limit: int = 10,
        search_content: bool = True,
        search_frontmatter: bool = False,
    ) -> list[dict[str, Any]]:
        """Search notes by content or frontmatter."""
        result = await self._call_tool(
            "search_notes",
            {
                "query": query,
                "limit": limit,
                "searchContent": search_content,
                "searchFrontmatter": search_frontmatter,
                "prettyPrint": False,
            },
        )
        return result if isinstance(result, list) else []

    async def find_note_by_summary_stack_id(self, summary_stack_id: str) -> str | None:
        """Find note path by searching frontmatter for summary_stack_id."""
        results = await self.search_notes(
            query=summary_stack_id,
            limit=1,
            search_content=False,
            search_frontmatter=True,
        )

        if results:
            path = results[0].get("path")
            if path and isinstance(path, str):
                logger.info(f"Found note for summary_stack {summary_stack_id} at: {path}")
                return path

        logger.warning(f"Note not found for summary_stack: {summary_stack_id}")
        return None


class VaultService:
    """Service for local Obsidian vault operations."""

    def __init__(self, vaults: dict[str, VaultConfig]):
        """Initialize the vault service.

        Args:
            vaults: Dict of vault name to VaultConfig
        """
        self.vaults = vaults

    async def write_note(self, vault_name: str, result: ObsidianManifestResult) -> str:
        """Write note to vault and return path.

        Args:
            vault_name: Name of the vault to write to
            result: Manifest result containing note content

        Returns:
            Path where the note was written

        Raises:
            ValueError: If vault not found
            VaultServiceError: If write fails
        """
        if vault_name not in self.vaults:
            raise ValueError(f"Vault '{vault_name}' not found")

        vault = self.vaults[vault_name]
        note_path = result.filename

        async with ObsidianMCPClient(vault.path) as client:
            await client.write_note(note_path, result.markdown_content)

        logger.info(f"Wrote note to {vault_name}:{note_path}")
        return note_path

    def get_client(self, vault_name: str) -> ObsidianMCPClient:
        """Get an MCP client for a vault (must be used as async context manager).

        Args:
            vault_name: Name of the vault

        Returns:
            ObsidianMCPClient instance (use with 'async with')

        Raises:
            ValueError: If vault not found
        """
        if vault_name not in self.vaults:
            raise ValueError(f"Vault '{vault_name}' not found")

        vault = self.vaults[vault_name]
        return ObsidianMCPClient(vault.path)
