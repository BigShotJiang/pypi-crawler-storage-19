"""Configuration loading for the MCP server."""

import os
from pathlib import Path

import yaml
from pydantic import BaseModel, Field


class APIConfig(BaseModel):
    """API connection configuration."""

    url: str = Field(default="http://localhost:8019", description="Summary Stack API URL")
    key: str = Field(default="", description="API key for authentication")


class VaultConfig(BaseModel):
    """Single vault configuration."""

    path: str = Field(description="Absolute path to the Obsidian vault")


class Config(BaseModel):
    """MCP server configuration."""

    api: APIConfig = Field(default_factory=APIConfig)
    default_vault: str = Field(default="main", description="Default vault name")
    vaults: dict[str, VaultConfig] = Field(default_factory=dict)

    def get_vault(self, name: str | None = None) -> VaultConfig:
        """Get vault config by name, or default vault.

        Args:
            name: Vault name, or None for default vault

        Returns:
            VaultConfig for the requested vault

        Raises:
            ValueError: If vault not found
        """
        vault_name = name or self.default_vault
        if vault_name not in self.vaults:
            available = ", ".join(self.vaults.keys()) or "(none configured)"
            raise ValueError(f"Vault '{vault_name}' not found. Available: {available}")
        return self.vaults[vault_name]


def _load_from_env() -> Config | None:
    """Load configuration from environment variables.

    Required env vars:
        SUMMARY_STACK_API_URL: API base URL
        SUMMARY_STACK_VAULT_PATH: Path to Obsidian vault

    Optional env vars:
        SUMMARY_STACK_API_KEY: API key for authentication

    Returns:
        Config if env vars are set, None otherwise
    """
    api_url = os.environ.get("SUMMARY_STACK_API_URL")
    vault_path = os.environ.get("SUMMARY_STACK_VAULT_PATH")

    if not api_url or not vault_path:
        return None

    return Config(
        api=APIConfig(
            url=api_url,
            key=os.environ.get("SUMMARY_STACK_API_KEY", ""),
        ),
        default_vault="main",
        vaults={
            "main": VaultConfig(
                path=vault_path,
            )
        },
    )


def _get_config_path() -> Path:
    """Get the configuration file path.

    Checks in order:
    1. SUMMARY_STACK_OBSIDIAN_CONFIG env var
    2. ~/.config/summary-stack-obsidian-mcp/config.yaml

    Returns:
        Path to config file
    """
    if env_path := os.environ.get("SUMMARY_STACK_OBSIDIAN_CONFIG"):
        return Path(env_path)
    return Path.home() / ".config" / "summary-stack-obsidian-mcp" / "config.yaml"


def _load_from_file() -> Config:
    """Load configuration from YAML file.

    Returns:
        Config object with loaded settings

    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If config is invalid
    """
    config_path = _get_config_path()

    if not config_path.exists():
        raise FileNotFoundError(
            f"Config file not found at {config_path}. "
            f"Either set SUMMARY_STACK_API_URL and SUMMARY_STACK_VAULT_PATH env vars, "
            f"or create a config file."
        )

    with open(config_path) as f:
        data = yaml.safe_load(f)

    return Config.model_validate(data)


def load_config() -> Config:
    """Load configuration from environment variables or file.

    Priority:
    1. Environment variables (if SUMMARY_STACK_API_URL and SUMMARY_STACK_VAULT_PATH are set)
    2. YAML config file

    Returns:
        Config object with loaded settings
    """
    # Try env vars first
    if config := _load_from_env():
        return config

    # Fall back to file
    return _load_from_file()
