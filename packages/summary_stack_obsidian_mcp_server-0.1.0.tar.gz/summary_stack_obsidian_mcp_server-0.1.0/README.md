# Summary Stack Obsidian MCP Server

Local MCP server for writing Summary Stack notes to Obsidian vaults.

## Installation

```bash
pip install summary-stack-obsidian-mcp-server
```

Or with uv:

```bash
uv pip install summary-stack-obsidian-mcp-server
```

## Overview

This MCP server runs on the user's machine and provides tools to:
- Create Summary Stack notes from URLs
- Write notes to configured Obsidian vaults
- Create backlinks in related notes

## Configuration

Create a config file at `~/.config/summary-stack-obsidian-mcp/config.yaml`:

```yaml
api:
  url: "https://api.summarystack.com"  # or http://localhost:8019 for local dev
  key: "ss-prod-xxxxxxxx"

default_vault: "main"

vaults:
  main:
    path: "/Users/you/Obsidian/MainVault"
    target_folder: "03_Resources/_parking_lot"
```

## MCP Tools

- `create_summary_stack` - Create a Summary Stack from a URL and save as an Obsidian note
- `list_summary_stacks` - List Summary Stack notes in your vault

## Usage

### With Claude Desktop

After installing via pip, add to your Claude Desktop MCP settings (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "summary-stack-obsidian": {
      "command": "summary-stack-obsidian-mcp"
    }
  }
}
```

### With Claude Code

Add to your Claude Code settings:

```json
{
  "mcpServers": {
    "summary-stack-obsidian": {
      "command": "summary-stack-obsidian-mcp"
    }
  }
}
```

### Development

```bash
# Run the server
pnpm nx run summary_stack_obsidian_mcp_server:serve

# Run tests
pnpm nx run summary_stack_obsidian_mcp_server:test

# Run linter
pnpm nx run summary_stack_obsidian_mcp_server:lint
```
