array[*start:*end]
