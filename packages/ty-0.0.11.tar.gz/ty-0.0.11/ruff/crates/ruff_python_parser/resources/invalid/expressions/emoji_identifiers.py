a = (🐶
    # comment 🐶
)

a = (🐶 +
    # comment
🐶)
