{x:

def foo():
    pass