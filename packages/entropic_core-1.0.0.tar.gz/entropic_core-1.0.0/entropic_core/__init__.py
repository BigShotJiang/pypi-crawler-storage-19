"""
Entropic Core - Sistema de monitoreo y regulación de entropía para sistemas multiagente
Version: 1.0.0

100% Free and Open Source - All features available to everyone.
"""

from .brain import EntropyBrain
from .config import Config, Tier
from .core.agent_adapter import AgentAdapter

# Core modules (always available)
from .core.entropy_monitor import EntropyMonitor
from .core.entropy_regulator import EntropyRegulator
from .core.evolutionary_memory import EvolutionaryMemory

__version__ = "1.0.0"
__all__ = [
    "EntropyBrain",
    "EntropyMonitor",
    "EntropyRegulator",
    "EvolutionaryMemory",
    "AgentAdapter",
    "Config",
    "Tier",
]

# Advanced modules (always available - 100% free)
try:
    pass

    __all__.extend(["CausalAnalyzer", "PredictiveEngine"])
except ImportError:
    pass
