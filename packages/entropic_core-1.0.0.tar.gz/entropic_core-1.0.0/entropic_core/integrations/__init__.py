"""
Entropic Core - Framework Integrations
Plug-and-play adapters for popular multi-agent frameworks
"""

from .autogen_adapter import AutoGenEntropyPlugin
from .custom_builder import CustomAdapterBuilder
from .langchain_adapter import LangChainEntropyHandler

__all__ = ["AutoGenEntropyPlugin", "LangChainEntropyHandler", "CustomAdapterBuilder"]
