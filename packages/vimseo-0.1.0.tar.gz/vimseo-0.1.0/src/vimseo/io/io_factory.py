# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License version 3 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# Copyright (c) 2019 IRT-AESE.
# All rights reserved.
#
# Contributors:
#    INITIAL AUTHORS - API and implementation and/or documentation
#        :author: XXXXXXXXXXX
#    OTHER AUTHORS   - MACROSCOPIC CHANGES
from __future__ import annotations

import logging

from gemseo.core.base_factory import BaseFactory

from vimseo.io.base_tool_io import BaseToolFileIO

LOGGER = logging.getLogger(__name__)


class IOFactory(BaseFactory):
    """Analysis tool factory to create an analysis tool from a name or a class."""

    _CLASS = BaseToolFileIO
    _PACKAGE_NAMES = ("vimseo.io",)

    def create(
        self,
        name: str,
        **options,
    ) -> BaseToolFileIO:
        """Create an analysis tool.

        Args:
            name: The name of the IO (its class name).
            **options: The options of the IO.
        """
        return super().create(name, **options)
