# Copyright 2021 IRT Saint Exupéry, https://www.irt-saintexupery.com
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License version 3 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# Copyright (c) 2019 IRT-AESE.
# All rights reserved.
#
# Contributors:
#    INITIAL AUTHORS - API and implementation and/or documentation
#        :author: XXXXXXXXXXX
#    OTHER AUTHORS   - MACROSCOPIC CHANGES
from __future__ import annotations

import logging

from gemseo.core.base_factory import BaseFactory

from vimseo.tools.post_tools.sensitivity_plots import SensitivityPlot

LOGGER = logging.getLogger(__name__)


class SensitivityPlotFactory(BaseFactory):
    """Sensitivity plot factory to create a :class:`~.SensitivityPlot` from a name or a
    class."""

    _CLASS = SensitivityPlot
    _PACKAGE_NAMES = ("vimseo.tools.post_tools",)

    def create(
        self,
        sensitivity_plot_name: str,
        **options,
    ) -> SensitivityPlot:
        """Create a sensitivity plot.

        Args:
            sensitivity_plot_name: The name of the sensitivity plots (its class name).
            **options: The options of the sensitivity plots.
        """
        return super().create(sensitivity_plot_name, **options)

    @property
    def sensitivity_plots(self) -> list[str]:
        """The names of the available sensitivity plots."""
        return self.class_names
