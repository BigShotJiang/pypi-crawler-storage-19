"""
分页显示工具
支持文件列表的分页显示和交互控制
"""
import sys
import os
import tty
import termios
from typing import List, Dict, Any, Callable, Optional
from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji


class PaginatedDisplay:
    """分页显示类"""
    
    def __init__(self, items: List[Dict[str, Any]], items_per_page: int = 10):
        """
        初始化分页显示
        
        Args:
            items: 要显示的项目列表
            items_per_page: 每页显示的项目数量
        """
        self.items = items
        self.items_per_page = items_per_page
        self.total_pages = max(1, (len(items) + items_per_page - 1) // items_per_page)
        self.current_page = 1
        self.is_collapsed = len(items) > items_per_page
        
    def display_page(self, page_num: int = 1) -> None:
        """显示指定页码的内容"""
        if page_num < 1 or page_num > self.total_pages:
            return
        
        self.current_page = page_num
        start_idx = (page_num - 1) * self.items_per_page
        end_idx = min(start_idx + self.items_per_page, len(self.items))
        
        print(f"\n{'='*60}")
        print(f"📄 第 {page_num}/{self.total_pages} 页 (显示 {start_idx+1}-{end_idx} 项，共 {len(self.items)} 项)")
        print(f"{'='*60}")
        
        for i in range(start_idx, end_idx):
            item = self.items[i]
            self._display_item(i + 1, item)
        
        print(f"{'='*60}")
        
        # 显示分页导航
        self._show_navigation()
    
    def _display_item(self, index: int, item: Dict[str, Any]) -> None:
        """显示单个项目"""
        file_name = item.get("name", "未知文件")
        file_path = item.get("path", "未知路径")
        file_size = item.get("size", "未知")
        file_type = item.get("type", "未知")
        download_url = item.get("download_url", "")
        
        print(f"{index}. {file_name}")
        print(f"   路径: {file_path}")
        print(f"   类型: {file_type}")
        print(f"   大小: {file_size} 字节")
        if download_url:
            print(f"   下载: {download_url}")
        print()
    
    def _show_navigation(self) -> None:
        """显示分页导航信息"""
        if self.total_pages > 1:
            print(f"{KAOMOJI['info']} 分页导航:")
            print(f"  ← A / ← 键: 上一页")
            print(f"  → D / → 键: 下一页")
            print(f"  数字键 1-{min(9, self.total_pages)}: 跳转到指定页")
            print(f"  ESC / Ctrl+C: 退出分页模式")
            print()
        
        if self.is_collapsed:
            print(f"{KAOMOJI['info']} 当前显示模式: 折叠显示 ({self.items_per_page} 项/页)")
        else:
            print(f"{KAOMOJI['info']} 当前显示模式: 完整显示")
    
    def interactive_mode(self) -> None:
        """进入交互模式，支持键盘控制"""
        if len(self.items) <= self.items_per_page:
            # 不需要分页，直接显示所有
            self.display_page(1)
            return
        
        print(f"{KAOMOJI['info']} 文件数量较多 ({len(self.items)} 个)，已启用分页显示模式")
        print(f"{KAOMOJI['info']} 按任意键进入交互模式...")
        
        # 等待用户按键
        try:
            self._getch()
        except KeyboardInterrupt:
            return
        
        # 进入交互循环
        self._interactive_loop()
    
    def _interactive_loop(self) -> None:
        """交互循环"""
        while True:
            # 清屏并显示当前页
            self._clear_screen()
            self.display_page(self.current_page)
            
            try:
                # 获取用户输入
                key = self._getch()
                
                if key in ('\x1b', '\x03'):  # ESC 或 Ctrl+C
                    print(f"\n{KAOMOJI['info']} 退出分页模式")
                    break
                elif key in ('a', 'A', '\x1b[D'):  # A 或左箭头
                    if self.current_page > 1:
                        self.current_page -= 1
                elif key in ('d', 'D', '\x1b[C'):  # D 或右箭头
                    if self.current_page < self.total_pages:
                        self.current_page += 1
                elif key.isdigit():
                    page_num = int(key)
                    if 1 <= page_num <= min(9, self.total_pages):
                        self.current_page = page_num
                elif key == 'q' or key == 'Q':
                    print(f"\n{KAOMOJI['info']} 退出分页模式")
                    break
                
            except KeyboardInterrupt:
                print(f"\n{KAOMOJI['info']} 退出分页模式")
                break
            except Exception as e:
                print(f"\n{KAOMOJI['error']} 输入错误: {e}")
                continue
    
    def _clear_screen(self) -> None:
        """清屏"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def _getch(self) -> str:
        """获取单个字符输入（不等待回车）"""
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
            
            # 检查是否是箭头键
            if ch == '\x1b':
                # 读取接下来的两个字符
                ch2 = sys.stdin.read(1)
                ch3 = sys.stdin.read(1)
                if ch2 == '[':
                    if ch3 == 'A':  # 上箭头
                        return '\x1b[A'
                    elif ch3 == 'B':  # 下箭头
                        return '\x1b[B'
                    elif ch3 == 'C':  # 右箭头
                        return '\x1b[C'
                    elif ch3 == 'D':  # 左箭头
                        return '\x1b[D'
            
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def display_paginated(items: List[Dict[str, Any]], items_per_page: int = 10) -> None:
    """
    分页显示项目列表
    
    Args:
        items: 要显示的项目列表
        items_per_page: 每页显示的项目数量
    """
    if not items:
        print(f"{KAOMOJI['info']} 没有项目可显示")
        return
    
    display = PaginatedDisplay(items, items_per_page)
    
    if len(items) <= items_per_page:
        # 直接显示所有项目
        print(f"\n{KAOMOJI['success']} 找到 {len(items)} 个项目:")
        display.display_page(1)
    else:
        # 进入交互模式
        display.interactive_mode()


def simple_pagination(items: List[Any], page_size: int = 10) -> None:
    """
    简单的分页显示（不包含交互控制）
    
    Args:
        items: 要显示的项目列表
        page_size: 每页显示的项目数量
    """
    if not items:
        print(f"{KAOMOJI['info']} 没有项目可显示")
        return
    
    total_pages = max(1, (len(items) + page_size - 1) // page_size)
    
    for page in range(1, total_pages + 1):
        start_idx = (page - 1) * page_size
        end_idx = min(start_idx + page_size, len(items))
        
        print(f"\n{'='*60}")
        print(f"📄 第 {page}/{total_pages} 页 (显示 {start_idx+1}-{end_idx} 项，共 {len(items)} 项)")
        print(f"{'='*60}")
        
        for i in range(start_idx, end_idx):
            print(f"{i+1}. {items[i]}")
        
        print(f"{'='*60}")
        
        if page < total_pages:
            input(f"{KAOMOJI['info']} 按回车键查看下一页...")
