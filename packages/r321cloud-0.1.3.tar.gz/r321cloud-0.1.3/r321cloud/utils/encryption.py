"""
文件加密工具
将任意文件加密成一段文本
"""

import base64
import json
from typing import Dict, Any, Optional
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import os


PBKDF2_ITERATIONS = 480000
SALT_LENGTH = 16


class FileEncryption:
    def __init__(self, password: Optional[str] = None):
        self.password = password or "default_password"

    def _generate_key(self, salt: bytes) -> bytes:
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=PBKDF2_ITERATIONS,
        )
        key = base64.urlsafe_b64encode(kdf.derive(self.password.encode()))
        return key

    def encrypt_file(self, file_path: str, description: str = "", uploader: str = "", progress_callback=None, no_lock: str = "false") -> str:
        with open(file_path, 'rb') as f:
            file_data = f.read()

        if progress_callback:
            progress_callback(0, 100, "生成密钥...")

        salt = os.urandom(16)
        
        # 如果no_lock为true，使用固定密码
        if no_lock == "true":
            # 无密码保护模式，使用固定密码
            temp_password = "no_lock_mode"
            key = self._generate_key_with_password(salt, temp_password)
        else:
            # 正常模式，使用用户提供的密码
            key = self._generate_key(salt)
            
        fernet = Fernet(key)

        if progress_callback:
            progress_callback(50, 100, "加密数据...")

        encrypted_data = fernet.encrypt(file_data)

        if progress_callback:
            progress_callback(100, 100, "完成！")

        metadata: Dict[str, Any] = {
            "description": description,
            "uploader": uploader,
            "original_filename": os.path.basename(file_path),
            "file_size": len(file_data),
            "encrypted_at": "2026-01-10",  # 添加加密时间
            "algorithm": "AES-256-CBC",
            "no_lock": no_lock  # 添加no_lock标记
        }

        result: Dict[str, Any] = {
            "metadata": metadata,
            "salt": base64.b64encode(salt).decode(),
            "encrypted_data": base64.b64encode(encrypted_data).decode()
        }

        return json.dumps(result, ensure_ascii=False, indent=2)
    
    def _generate_key_with_password(self, salt: bytes, password: str) -> bytes:
        """使用指定密码生成密钥"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=PBKDF2_ITERATIONS,
        )
        key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
        return key

    def decrypt_file(self, encrypted_text: str, output_path: Optional[str] = None, password: Optional[str] = None, progress_callback=None) -> bytes:
        data = json.loads(encrypted_text)

        if progress_callback:
            progress_callback(0, 100, "解析数据...")

        salt = base64.b64decode(data["salt"])
        encrypted_data = base64.b64decode(data["encrypted_data"])
        
        # 检查是否有no_lock标记
        metadata = data.get("metadata", {})
        no_lock = metadata.get("no_lock", "false")

        if progress_callback:
            progress_callback(30, 100, "生成密钥...")

        # 如果no_lock为true，使用固定密码
        if no_lock == "true":
            # 无密码保护模式，使用固定密码
            temp_password = "no_lock_mode"
            key = self._generate_key_with_password(salt, temp_password)
        else:
            # 正常模式，使用用户提供的密码或默认密码
            if password:
                key = self._generate_key_with_password(salt, password)
            else:
                key = self._generate_key(salt)
            
        fernet = Fernet(key)

        if progress_callback:
            progress_callback(60, 100, "解密数据...")

        decrypted_data = fernet.decrypt(encrypted_data)

        if progress_callback:
            progress_callback(90, 100, "保存文件...")

        if output_path:
            with open(output_path, 'wb') as f:
                f.write(decrypted_data)

        if progress_callback:
            progress_callback(100, 100, "完成！")

        return decrypted_data

    def get_metadata(self, encrypted_text: str) -> Dict[str, Any]:
        data = json.loads(encrypted_text)
        return data.get("metadata", {})