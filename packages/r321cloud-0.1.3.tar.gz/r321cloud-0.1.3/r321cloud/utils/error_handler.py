"""
错误处理工具模块
提供统一的错误处理和用户友好的错误消息
"""

import os
import json
import base64
from typing import Any, Callable, TypeVar, Optional
from cryptography.fernet import Fernet, InvalidToken

T = TypeVar('T')


class R321Error(Exception):
    """r321cloud 自定义异常基类"""
    def __init__(self, message: str, details: Optional[str] = None):
        self.message = message
        self.details = details
        super().__init__(message)


class FileNotFoundError(R321Error):
    """文件未找到异常"""
    pass


class EncryptionError(R321Error):
    """加密/解密错误"""
    pass


class ConfigError(R321Error):
    """配置错误"""
    pass


class NetworkError(R321Error):
    """网络错误"""
    pass


def handle_errors(func: Callable[..., T]) -> Callable[..., T]:
    """错误处理装饰器，将异常转换为用户友好的消息"""
    def wrapper(*args, **kwargs) -> T:
        try:
            return func(*args, **kwargs)
        except FileNotFoundError as e:
            print(f"❌ 文件错误: {e.message}")
            if e.details:
                print(f"   详情: {e.details}")
        except EncryptionError as e:
            print(f"🔒 加密错误: {e.message}")
            if e.details:
                print(f"   详情: {e.details}")
        except ConfigError as e:
            print(f"⚙️ 配置错误: {e.message}")
            if e.details:
                print(f"   详情: {e.details}")
        except NetworkError as e:
            print(f"🌐 网络错误: {e.message}")
            print("   请检查:")
            print("   1. 网络连接是否正常")
            print("   2. API密钥是否正确")
            print("   3. 仓库配置是否正确")
            if e.details:
                print(f"   详情: {e.details}")
        except json.JSONDecodeError as e:
            print(f"📄 JSON解析错误: 文件格式不正确")
            print(f"   位置: 第{e.lineno}行, 列{e.colno}")
            print(f"   详情: {e.msg}")
        except InvalidToken as e:
            print(f"🔑 密钥错误: 密码不正确或加密文件已损坏")
            print("   请检查:")
            print("   1. 输入的密码是否正确")
            print("   2. 加密文件是否完整")
        except PermissionError as e:
            print(f"🚫 权限错误: 无法访问文件或目录")
            print(f"   路径: {e.filename if hasattr(e, 'filename') else '未知'}")
            print("   请检查:")
            print("   1. 文件权限是否正确")
            print("   2. 是否有读写权限")
        except Exception as e:
            print(f"⚠️ 未知错误: {type(e).__name__}")
            print(f"   消息: {str(e)}")
            print("\n💡 建议:")
            print("   1. 检查输入参数是否正确")
            print("   2. 查看日志获取更多信息")
            print("   3. 联系开发者寻求帮助")
        return None
    return wrapper


def handle_exception(func: Callable[..., T]) -> Callable[..., T]:
    """handle_errors的别名"""
    return handle_errors(func)


def safe_file_path(user_path: str) -> str:
    """安全地处理文件路径，防止路径遍历攻击"""
    # 规范化路径
    normalized = os.path.normpath(user_path)
    
    # 防止路径遍历
    if ".." in normalized or normalized.startswith("/"):
        raise FileNotFoundError(
            "无效的文件路径",
            f"路径 '{user_path}' 可能包含不安全字符"
        )
    
    # 检查文件是否存在
    if not os.path.exists(normalized):
        raise FileNotFoundError(
            "文件不存在",
            f"无法找到文件: {normalized}"
        )
    
    return normalized


def validate_password(password: str, min_length: int = 6) -> bool:
    """验证密码强度"""
    if not password:
        return False
    
    if len(password) < min_length:
        raise EncryptionError(
            "密码太短",
            f"密码至少需要 {min_length} 个字符"
        )
    
    # 检查密码复杂度（可选）
    # 这里可以添加更复杂的密码策略
    
    return True


def format_error_message(error_type: str, message: str, suggestions: list = None) -> str:
    """格式化错误消息"""
    lines = [f"❌ {error_type}: {message}"]
    
    if suggestions:
        lines.append("\n💡 建议:")
        for i, suggestion in enumerate(suggestions, 1):
            lines.append(f"   {i}. {suggestion}")
    
    return "\n".join(lines)


# 常用的错误消息模板
ERROR_TEMPLATES = {
    "file_not_found": lambda path: format_error_message(
        "文件错误",
        f"找不到文件: {path}",
        ["检查文件路径是否正确", "确认文件是否存在", "检查文件权限"]
    ),
    "network_error": lambda url: format_error_message(
        "网络错误",
        f"无法连接到: {url}",
        ["检查网络连接", "验证API密钥", "确认仓库配置"]
    ),
    "encryption_error": lambda: format_error_message(
        "加密错误",
        "加密或解密失败",
        ["检查密码是否正确", "确认加密文件完整", "尝试使用默认密码"]
    ),
    "config_error": lambda: format_error_message(
        "配置错误",
        "配置文件无效或缺失",
        ["运行 'r321-cloud config' 检查配置", "重新设置API密钥", "导入有效的配置"]
    )
}