"""
分流文件处理工具
用于处理分流文件的显示、下载和合并
"""

import os
import re
import json
from typing import Dict, List, Optional, Tuple, Set
from r321cloud.utils.kaomoji import KAOMOJI


class SplitFileHandler:
    """分流文件处理器"""
    
    @staticmethod
    def is_split_file(filename: str) -> bool:
        """检查文件是否为分流文件的分块
        
        Args:
            filename: 文件名
            
        Returns:
            bool: 是否为分流文件分块
        """
        # 匹配模式：filename.encrypted.001, filename.encrypted.002 等
        pattern = r'\.encrypted\.\d{3}$'
        return bool(re.search(pattern, filename))
    
    @staticmethod
    def is_split_metadata(filename: str) -> bool:
        """检查文件是否为分流文件的元数据文件
        
        Args:
            filename: 文件名
            
        Returns:
            bool: 是否为分流文件元数据
        """
        return filename.endswith('.split.metadata.json')
    
    @staticmethod
    def get_base_filename(filename: str) -> str:
        """从分流文件分块名获取基础文件名
        
        Args:
            filename: 分流文件分块名（如：large_file.encrypted.001）
            
        Returns:
            str: 基础文件名（如：large_file.encrypted）
        """
        # 移除最后的 .001, .002 等后缀
        pattern = r'\.encrypted\.\d{3}$'
        if re.search(pattern, filename):
            return re.sub(pattern, '.encrypted', filename)
        return filename
    
    @staticmethod
    def get_original_filename(filename: str) -> str:
        """从分流文件分块名获取原始文件名
        
        Args:
            filename: 分流文件分块名（如：large_file.encrypted.001）
            
        Returns:
            str: 原始文件名（如：large_file）
        """
        # 先获取基础文件名
        base_name = SplitFileHandler.get_base_filename(filename)
        # 移除 .encrypted 后缀
        if base_name.endswith('.encrypted'):
            return base_name[:-10]  # 移除 .encrypted (10个字符)
        return base_name
    
    @staticmethod
    def group_split_files(file_list: List[Dict]) -> Tuple[List[Dict], Set[str]]:
        """将分流文件分组并合并显示
        
        Args:
            file_list: 原始文件列表
            
        Returns:
            Tuple[List[Dict], Set[str]]: 
                - 处理后的文件列表（分流文件已合并）
                - 需要隐藏的文件名集合（分流文件分块和元数据文件）
        """
        processed_files = []
        files_to_hide = set()
        
        # 首先收集所有分流文件分块和元数据文件
        split_chunks = {}  # 基础文件名 -> [分块文件列表]
        metadata_files = {}  # 基础文件名 -> 元数据文件
        
        for file_info in file_list:
            filename = file_info.get("name", "")
            
            if SplitFileHandler.is_split_metadata(filename):
                # 这是元数据文件
                base_name = filename.replace('.split.metadata.json', '.encrypted')
                metadata_files[base_name] = file_info
                files_to_hide.add(filename)
            elif SplitFileHandler.is_split_file(filename):
                # 这是分流文件分块
                base_name = SplitFileHandler.get_base_filename(filename)
                if base_name not in split_chunks:
                    split_chunks[base_name] = []
                split_chunks[base_name].append(file_info)
                files_to_hide.add(filename)
            else:
                # 普通文件，直接添加到处理后的列表
                processed_files.append(file_info)
        
        # 处理每个分流文件组
        for base_name, chunks in split_chunks.items():
            if chunks:
                # 按分块编号排序
                chunks.sort(key=lambda x: int(x["name"].split(".")[-1]))
                
                # 创建合并后的文件信息
                first_chunk = chunks[0]
                merged_file = {
                    "name": base_name,  # 显示基础文件名
                    "path": base_name,
                    "size": None,
                    "type": "split_file",
                    "download_url": first_chunk.get("download_url", ""),
                    "original_name": SplitFileHandler.get_original_filename(base_name),
                    "chunk_count": len(chunks),
                    "is_split_file": True,
                    "chunks": [chunk["name"] for chunk in chunks]
                }
                
                # 如果有元数据文件，添加元数据信息
                if base_name in metadata_files:
                    merged_file["has_metadata"] = True
                    merged_file["metadata_file"] = metadata_files[base_name]["name"]
                
                processed_files.append(merged_file)
        
        return processed_files, files_to_hide
    
    @staticmethod
    def get_split_file_info(filename: str, file_list: List[Dict]) -> Optional[Dict]:
        """获取分流文件的详细信息
        
        Args:
            filename: 文件名（可以是基础文件名或原始文件名）
            file_list: 文件列表
            
        Returns:
            Optional[Dict]: 分流文件信息，如果不是分流文件则返回None
        """
        # 首先检查是否是分流文件的基础文件名
        for file_info in file_list:
            if file_info.get("name") == filename and file_info.get("is_split_file", False):
                return file_info
        
        # 如果不是基础文件名，检查是否是原始文件名
        for file_info in file_list:
            if file_info.get("original_name") == filename and file_info.get("is_split_file", False):
                return file_info
        
        return None
    
    @staticmethod
    def format_split_file_display(file_info: Dict) -> str:
        """格式化分流文件的显示信息
        
        Args:
            file_info: 分流文件信息
            
        Returns:
            str: 格式化后的显示字符串
        """
        name = file_info.get("name", "")
        original_name = file_info.get("original_name", "")
        chunk_count = file_info.get("chunk_count", 0)
        
        display = f"{name}"
        if original_name and original_name != name:
            display += f" (原始文件: {original_name})"
        
        if chunk_count > 0:
            display += f" [分流文件: {chunk_count}个分块]"
        
        return display
    
    @staticmethod
    def download_and_merge_split_file(
        client, 
        split_file_info: Dict, 
        output_path: str = None,
        show_progress: bool = True
    ) -> Optional[str]:
        """下载并合并分流文件
        
        Args:
            client: GiteeClient实例
            split_file_info: 分流文件信息
            output_path: 输出文件路径（如果为None，则使用原始文件名）
            show_progress: 是否显示进度
            
        Returns:
            Optional[str]: 合并后的文件路径，如果失败则返回None
        """
        try:
            from r321cloud.utils.kaomoji import KAOMOJI
            
            original_name = split_file_info.get("original_name", "")
            base_name = split_file_info.get("name", "")
            chunk_count = split_file_info.get("chunk_count", 0)
            chunks = split_file_info.get("chunks", [])
            
            if not chunks:
                print(f"{KAOMOJI['error']} 分流文件信息不完整")
                return None
            
            # 确定输出路径
            if not output_path:
                if original_name:
                    output_path = original_name
                else:
                    # 从基础文件名推断原始文件名
                    if base_name.endswith('.encrypted'):
                        output_path = base_name[:-10]  # 移除 .encrypted
                    else:
                        output_path = base_name
            
            print(f"{KAOMOJI['download']} 正在下载分流文件: {base_name}")
            print(f"{KAOMOJI['info']} 原始文件: {original_name}")
            print(f"{KAOMOJI['info']} 分块数量: {chunk_count} 个")
            
            # 下载所有分块
            chunk_contents = []
            for i, chunk_name in enumerate(chunks, 1):
                if show_progress:
                    print(f"{KAOMOJI['progress_mid']} 下载分块 {i}/{chunk_count}: {chunk_name}")
                
                chunk_content = client.get_file_content(chunk_name)
                if chunk_content is None:
                    print(f"{KAOMOJI['error']} 下载分块失败: {chunk_name}")
                    return None
                
                chunk_contents.append(chunk_content)
                
                if show_progress:
                    print(f"{KAOMOJI['success']} 分块 {i}/{chunk_count} 下载完成")
            
            # 合并分块
            print(f"{KAOMOJI['loading']} 正在合并分块...")
            merged_content = "".join(chunk_contents)
            
            # 保存合并后的文件
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(merged_content)
            
            print(f"{KAOMOJI['success']} 分流文件合并完成！")
            print(f"{KAOMOJI['info']} 文件已保存到: {output_path}")
            
            return output_path
            
        except Exception as e:
            print(f"{KAOMOJI['error']} 下载并合并分流文件失败: {e}")
            return None
    
    @staticmethod
    def find_split_file_by_name(filename: str, file_list: List[Dict]) -> Optional[Dict]:
        """通过文件名查找分流文件信息
        
        Args:
            filename: 文件名（可以是基础文件名、原始文件名或分块文件名）
            file_list: 文件列表
            
        Returns:
            Optional[Dict]: 分流文件信息，如果找不到则返回None
        """
        from r321cloud.utils.split_file_handler import SplitFileHandler
        
        # 首先处理文件列表，合并分流文件
        processed_files, _ = SplitFileHandler.group_split_files(file_list)
        
        # 查找匹配的分流文件
        for file_info in processed_files:
            if file_info.get("is_split_file", False):
                # 检查是否匹配基础文件名
                if file_info.get("name") == filename:
                    return file_info
                
                # 检查是否匹配原始文件名
                if file_info.get("original_name") == filename:
                    return file_info
                
                # 检查是否匹配分块文件名（去掉.001等后缀）
                base_name = SplitFileHandler.get_base_filename(filename)
                if file_info.get("name") == base_name:
                    return file_info
        
        return None