#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
文件操作命令模块
包含所有文件相关的命令函数
"""

import os
import json
import platform
from typing import Dict, Any, Optional, List
from getpass import getpass

from r321cloud.gitee import GiteeClient
from r321cloud.utils.encryption import FileEncryption
from r321cloud.utils.config import Config
from r321cloud.utils.kaomoji import KAOMOJI
from r321cloud.utils.interactive import ask_yes_no, ask_input, ask_password
from r321cloud.utils.error_handler import handle_exception


def get_windows_desktop_path() -> str:
    """获取 Windows 桌面路径，如果不可用则返回 C 盘根目录"""
    if platform.system() == "Windows":
        # 尝试桌面路径
        desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')
        
        try:
            # 测试可写性
            test_file = os.path.join(desktop_path, '.test_write')
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return desktop_path
        except (PermissionError, OSError):
            # 桌面不可用，尝试 C 盘
            c_drive = "C:\\"
            try:
                test_file = os.path.join(c_drive, '.test_write')
                with open(test_file, 'w') as f:
                    f.write('test')
                os.remove(test_file)
                return c_drive
            except (PermissionError, OSError):
                # 都不可用，使用当前目录
                return os.getcwd()
    
    return os.getcwd()


def get_output_path(user_path: Optional[str], default_filename: str) -> str:
    """获取输出文件路径"""
    if user_path:
        return user_path
    
    # 获取基础路径
    base_path = get_windows_desktop_path()
    
    # 确保目录存在
    os.makedirs(base_path, exist_ok=True)
    
    # 返回完整路径
    return os.path.join(base_path, default_filename)


def cmd_get(args) -> None:
    """从云端获取文件列表"""
    print(f"{KAOMOJI['cloud']} 云端同步中... 正在获取文件列表...")
    
    try:
        client = GiteeClient()
        file_list = client.get_file_list()
        
        if file_list is None:
            print(f"{KAOMOJI['error']} 获取文件列表失败")
            print(f"{KAOMOJI['info']} 请检查：")
            print("  1. 网络连接是否正常")
            print("  2. API密钥是否正确配置")
            print("  3. 仓库配置是否正确")
            return
        
        if not file_list:
            print(f"{KAOMOJI['info']} 云端暂无文件")
            return
        
        # 保存到本地
        local_path = os.path.join(os.getcwd(), "files.json")
        with open(local_path, "w", encoding="utf-8") as f:
            json.dump(file_list, f, ensure_ascii=False, indent=2)
        
        print(f"{KAOMOJI['success']} 文件列表已更新 ovo")
        print(f"{KAOMOJI['info']} 本地文件列表已保存到: {local_path}")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")


def cmd_list(args) -> None:
    """显示本地文件列表"""
    try:
        local_path = os.path.join(os.getcwd(), "files.json")
        
        if not os.path.exists(local_path):
            print(f"{KAOMOJI['info']} 本地文件列表不存在")
            print(f"{KAOMOJI['info']} 请先使用 'r321-cloud get' 获取云端文件列表")
            return
        
        with open(local_path, "r", encoding="utf-8") as f:
            file_list = json.load(f)
        
        if not file_list:
            print(f"{KAOMOJI['info']} 本地文件列表为空")
            return
        
        # 导入分流文件处理器
        from r321cloud.utils.split_file_handler import SplitFileHandler
        
        # 处理分流文件，合并显示
        processed_files, files_to_hide = SplitFileHandler.group_split_files(file_list)
        
        print(f"{KAOMOJI['list']} 本地文件列表:")
        print(f"{KAOMOJI['info']} 分流文件已合并显示")
        print(f"{'='*60}")
        
        for i, file_info in enumerate(processed_files, 1):
            file_name = file_info.get("name", "未知文件")
            file_size = file_info.get("size", "未知")
            file_type = file_info.get("type", "未知")
            
            # 如果是分流文件，特殊显示
            if file_info.get("is_split_file", False):
                original_name = file_info.get("original_name", "")
                chunk_count = file_info.get("chunk_count", 0)
                
                print(f"{i}. {file_name}")
                print(f"   类型: {file_type} [分流文件]")
                print(f"   原始文件: {original_name}")
                print(f"   分块数量: {chunk_count} 个")
                if file_info.get("has_metadata", False):
                    print(f"   元数据: 已包含")
            else:
                print(f"{i}. {file_name}")
                print(f"   类型: {file_type}")
                print(f"   大小: {file_size} 字节")
            print()
        
        print(f"{'='*60}")
        print(f"{KAOMOJI['happy']} 共 {len(processed_files)} 个文件 ovo")
        
        # 如果有隐藏的文件，显示提示
        if files_to_hide:
            print(f"{KAOMOJI['info']} 已隐藏 {len(files_to_hide)} 个分流文件分块和元数据文件")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")


def cmd_search(args) -> None:
    """搜索本地文件列表"""
    if not args.keyword:
        print(f"{KAOMOJI['error']} 请提供搜索关键词")
        print(f"{KAOMOJI['info']} 用法: r321-cloud search <关键词>")
        return
    
    try:
        local_path = os.path.join(os.getcwd(), "files.json")
        
        if not os.path.exists(local_path):
            print(f"{KAOMOJI['info']} 本地文件列表不存在")
            print(f"{KAOMOJI['info']} 请先使用 'r321-cloud get' 获取云端文件列表")
            return
        
        with open(local_path, "r", encoding="utf-8") as f:
            file_list = json.load(f)
        
        # 搜索文件
        results = []
        for file_info in file_list:
            file_name = file_info.get("name", "")
            if args.keyword.lower() in file_name.lower():
                results.append(file_info)
        
        if not results:
            print(f"{KAOMOJI['info']} 未找到包含关键词 '{args.keyword}' 的文件")
            return
        
        # 导入分流文件处理器
        from r321cloud.utils.split_file_handler import SplitFileHandler
        
        # 处理分流文件，合并显示
        processed_files, files_to_hide = SplitFileHandler.group_split_files(results)
        
        if not processed_files:
            print(f"{KAOMOJI['info']} 未找到包含关键词 '{args.keyword}' 的文件")
            return
        
        print(f"{KAOMOJI['search']} 搜索结果:")
        print(f"{KAOMOJI['info']} 分流文件已合并显示")
        print(f"{'='*60}")
        
        for i, file_info in enumerate(processed_files, 1):
            file_name = file_info.get("name", "未知文件")
            file_size = file_info.get("size", "未知")
            file_type = file_info.get("type", "未知")
            
            # 如果是分流文件，特殊显示
            if file_info.get("is_split_file", False):
                original_name = file_info.get("original_name", "")
                chunk_count = file_info.get("chunk_count", 0)
                
                print(f"{i}. {file_name}")
                print(f"   类型: {file_type} [分流文件]")
                print(f"   原始文件: {original_name}")
                print(f"   分块数量: {chunk_count} 个")
                if file_info.get("has_metadata", False):
                    print(f"   元数据: 已包含")
            else:
                print(f"{i}. {file_name}")
                print(f"   类型: {file_type}")
                print(f"   大小: {file_size} 字节")
            print()
        
        print(f"{'='*60}")
        print(f"{KAOMOJI['happy']} 共找到 {len(processed_files)} 个匹配的文件 ovo")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")


def cmd_filelock(args) -> None:
    """加密文件"""
    try:
        if not os.path.exists(args.file):
            print(f"{KAOMOJI['error']} 文件不存在: {args.file}")
            return
        
        # 获取文件信息
        description = args.description
        uploader = args.uploader
        
        if not description:
            description = ask_input("请输入文件描述（可选）: ", default="")
        
        if not uploader:
            uploader = ask_input("请输入上传者名称（可选）: ", default="")
        
        # 获取密码
        password = None
        if not args.no_lock:
            password = ask_password("请输入加密密码（留空使用默认密码）: ", confirm=True)
            if not password:
                password = "default_password"
        
        print(f"{KAOMOJI['loading']} 正在处理中...")
        
        # 加密文件
        encryption = FileEncryption()
        encrypted_text = encryption.encrypt_file(
            args.file, 
            description=description, 
            uploader=uploader,
            password=password if not args.no_lock else None,
            progress_callback=lambda p: print(f"{KAOMOJI['progress']} 加密进度: {p}%", end='\r')
        )
        
        # 保存加密文件
        output_path = args.output
        if not output_path:
            output_path = args.file + ".encrypted"
        
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(encrypted_text)
        
        print(f"\n{KAOMOJI['success']} 文件已加密保护 🔒")
        print(f"{KAOMOJI['info']} 加密文件已保存到: {output_path}")
        
        # 显示文件信息
        metadata = encryption.get_metadata(encrypted_text)
        if metadata:
            print(f"\n{KAOMOJI['info']} 文件信息:")
            print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
            print(f"  文件描述: {metadata.get('description', '无')}")
            print(f"  上传者: {metadata.get('uploader', '未知')}")
            print(f"  加密时间: {metadata.get('encryption_time', '未知')}")
            print(f"  文件大小: {metadata.get('file_size', '未知')} 字节")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")


def cmd_fileunlock(args) -> None:
    """解密文件"""
    try:
        if not os.path.exists(args.file):
            print(f"{KAOMOJI['error']} 文件不存在: {args.file}")
            return
        
        # 读取加密文件
        with open(args.file, "r", encoding="utf-8") as f:
            encrypted_text = f.read()
        
        # 获取文件信息
        encryption = FileEncryption()
        metadata = encryption.get_metadata(encrypted_text)
        
        if metadata:
            print(f"{KAOMOJI['info']} 文件信息:")
            print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
            print(f"  文件描述: {metadata.get('description', '无')}")
            print(f"  上传者: {metadata.get('uploader', '未知')}")
            print(f"  加密时间: {metadata.get('encryption_time', '未知')}")
            print(f"  文件大小: {metadata.get('file_size', '未知')} 字节")
        
        # 询问是否查看内容
        view_content = ask_yes_no("是否要查看文件内容?", default=True)
        
        if view_content:
            # 获取密码
            password = None
            if metadata and metadata.get('password_protected', False):
                password = ask_password("请输入解密密码: ")
                if not password:
                    password = "default_password"
            
            # 解密文件
            print(f"{KAOMOJI['loading']} 正在解密...")
            decrypted_content = encryption.decrypt_file(
                encrypted_text,
                password=password
            )
            
            print(f"\n{KAOMOJI['success']} 文件内容:")
            print(f"{'='*60}")
            print(decrypted_content)
            print(f"{'='*60}")
            
            # 询问是否保存
            save_file = ask_yes_no("是否要保存解密后的文件?", default=True)
            
            if save_file:
                # 获取输出路径
                output_path = args.output
                if not output_path:
                    original_name = metadata.get('original_filename', 'decrypted.txt') if metadata else 'decrypted.txt'
                    output_path = get_output_path(None, original_name)
                
                # 保存文件
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(decrypted_content)
                
                print(f"{KAOMOJI['success']} 文件已保存到: {output_path}")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")


def cmd_download(args) -> None:
    """下载文件（支持分流文件的智能下载和合并）"""
    try:
        print(f"{KAOMOJI['download']} 下载文件中... 正在获取文件信息... (｡•̀ᴗ-)✧")
        
        client = GiteeClient()
        
        # 首先获取云端所有文件列表，用于检测分流文件
        print(f"{KAOMOJI['loading']} 正在获取云端文件列表...")
        all_files = client.get_file_list()
        
        if all_files is None:
            print(f"{KAOMOJI['error']} 获取文件列表失败")
            return
        
        # 导入分流文件处理器
        from r321cloud.utils.split_file_handler import SplitFileHandler
        
        # 检查是否为分流文件
        split_file_info = SplitFileHandler.find_split_file_by_name(args.filename, all_files)
        
        if split_file_info:
            # 这是分流文件，进行智能下载和合并
            print(f"{KAOMOJI['info']} 检测到分流文件，开始智能下载...")
            
            # 获取输出路径
            output_path = args.output
            if not output_path:
                # 使用原始文件名作为输出路径
                original_name = split_file_info.get("original_name", "")
                if original_name:
                    output_path = get_output_path(None, original_name)
                else:
                    # 从基础文件名推断
                    base_name = split_file_info.get("name", "")
                    if base_name.endswith('.encrypted'):
                        output_path = get_output_path(None, base_name[:-10])  # 移除 .encrypted
                    else:
                        output_path = get_output_path(None, base_name)
            
            # 下载并合并分流文件
            merged_file_path = SplitFileHandler.download_and_merge_split_file(
                client, split_file_info, output_path, show_progress=True
            )
            
            if merged_file_path:
                print(f"{KAOMOJI['success']} 分流文件下载并合并完成！ ovo")
                
                # 询问是否要处理加密文件
                if merged_file_path.endswith('.encrypted'):
                    encryption = FileEncryption()
                    try:
                        with open(merged_file_path, "r", encoding="utf-8") as f:
                            merged_content = f.read()
                        
                        metadata = encryption.get_metadata(merged_content)
                        if metadata:
                            print(f"\n{KAOMOJI['info']} 检测到加密文件:")
                            print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
                            print(f"  文件描述: {metadata.get('description', '无')}")
                            print(f"  上传者: {metadata.get('uploader', '未知')}")
                            
                            # 询问是否解密
                            decrypt_file = ask_yes_no("是否要解密文件?", default=True)
                            if decrypt_file:
                                password = None
                                if metadata.get('password_protected', False):
                                    password = ask_password("请输入解密密码: ")
                                    if not password:
                                        password = "default_password"
                                
                                print(f"{KAOMOJI['loading']} 正在解密...")
                                decrypted_content = encryption.decrypt_file(
                                    merged_content,
                                    password=password
                                )
                                
                                # 获取解密后的输出路径
                                decrypted_output = get_output_path(
                                    None, 
                                    metadata.get('original_filename', 'decrypted.txt')
                                )
                                
                                # 保存解密后的文件
                                if isinstance(decrypted_content, bytes):
                                    decrypted_content = decrypted_content.decode('utf-8')
                                with open(decrypted_output, "w", encoding="utf-8") as f:
                                    f.write(decrypted_content)
                                
                                print(f"{KAOMOJI['success']} 文件已解密并保存到: {decrypted_output} ovo")
                    except Exception as e:
                        print(f"{KAOMOJI['warning']} 处理加密文件时出错: {e}")
            
            return
        
        # 如果不是分流文件，按普通文件处理
        print(f"{KAOMOJI['info']} 按普通文件处理: {args.filename}")
        
        # 获取文件内容
        file_content = client.get_file_content(args.filename)
        
        if file_content is None:
            print(f"{KAOMOJI['error']} 未找到文件: {args.filename}")
            print(f"{KAOMOJI['info']} 请检查文件名是否正确")
            return
        
        # 显示文件信息
        print(f"{KAOMOJI['happy']} 文件信息:")
        print(f"  文件名: {args.filename}")
        
        # 如果是加密文件，显示元数据
        encryption = FileEncryption()
        try:
            metadata = encryption.get_metadata(file_content)
            if metadata:
                print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
                print(f"  文件描述: {metadata.get('description', '无')}")
                print(f"  上传者: {metadata.get('uploader', '未知')}")
                print(f"  加密时间: {metadata.get('encryption_time', '未知')}")
                print(f"  文件大小: {metadata.get('file_size', '未知')} 字节")
        except:
            pass
        
        # 询问是否查看内容
        view_content = ask_yes_no("是否要查看文件内容?", default=True)
        
        if view_content:
            # 如果是加密文件，尝试解密
            try:
                metadata = encryption.get_metadata(file_content)
                if metadata:
                    password = None
                    if metadata.get('password_protected', False):
                        password = ask_password("请输入解密密码: ")
                        if not password:
                            password = "default_password"
                    
                    print(f"{KAOMOJI['loading']} 正在解密...")
                    decrypted_content = encryption.decrypt_file(
                        file_content,
                        password=password
                    )
                    
                    print(f"\n{KAOMOJI['success']} 文件内容:")
                    print(f"{'='*60}")
                    # 如果是字节，转换为字符串
                    if isinstance(decrypted_content, bytes):
                        decrypted_content = decrypted_content.decode('utf-8')
                    print(decrypted_content)
                    print(f"{'='*60}")
                    
                    # 询问是否保存
                    save_file = ask_yes_no("是否要保存文件?", default=True)
                    
                    if save_file:
                        # 获取输出路径
                        output_path = args.output
                        if not output_path:
                            original_name = metadata.get('original_filename', args.filename)
                            output_path = get_output_path(None, original_name)
                        
                        # 保存文件（将字节转换为字符串）
                        if isinstance(decrypted_content, bytes):
                            decrypted_content = decrypted_content.decode('utf-8')
                        with open(output_path, "w", encoding="utf-8") as f:
                            f.write(decrypted_content)
                        
                        print(f"{KAOMOJI['success']} 文件已保存到: {output_path} ovo")
                else:
                    # 不是加密文件，直接显示
                    print(f"\n{KAOMOJI['success']} 文件内容:")
                    print(f"{'='*60}")
                    print(file_content)
                    print(f"{'='*60}")
                    
                    # 询问是否保存
                    save_file = ask_yes_no("是否要保存文件?", default=True)
                    
                    if save_file:
                        # 获取输出路径
                        output_path = args.output
                        if not output_path:
                            output_path = get_output_path(None, args.filename)
                        
                        # 保存文件
                        with open(output_path, "w", encoding="utf-8") as f:
                            f.write(file_content)
                        
                        print(f"{KAOMOJI['success']} 文件已保存到: {output_path} ovo")
            except Exception as e:
                print(f"{KAOMOJI['error']} 处理文件时出错: {e}")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")


def cmd_preview(args) -> None:
    """预览文件信息（不解密）"""
    try:
        if not os.path.exists(args.file):
            print(f"{KAOMOJI['error']} 文件不存在: {args.file}")
            return
        
        # 读取文件
        with open(args.file, "r", encoding="utf-8") as f:
            file_content = f.read()
        
        # 获取文件信息
        encryption = FileEncryption()
        metadata = encryption.get_metadata(file_content)
        
        if not metadata:
            print(f"{KAOMOJI['info']} 这不是一个有效的加密文件")
            return
        
        print(f"{KAOMOJI['info']} 文件信息:")
        print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
        print(f"  文件描述: {metadata.get('description', '无')}")
        print(f"  上传者: {metadata.get('uploader', '未知')}")
        print(f"  加密时间: {metadata.get('encryption_time', '未知')}")
        print(f"  文件大小: {metadata.get('file_size', '未知')} 字节")
        print(f"  密码保护: {'是' if metadata.get('password_protected', False) else '否'}")
        
        # 显示加密信息
        if 'encryption_info' in metadata:
            enc_info = metadata['encryption_info']
            print(f"\n{KAOMOJI['info']} 加密信息:")
            print(f"  算法: {enc_info.get('algorithm', '未知')}")
            print(f"  密钥派生算法: {enc_info.get('key_derivation', '未知')}")
            print(f"  迭代次数: {enc_info.get('iterations', '未知')}")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")


def cmd_search_direct(args) -> None:
    """直接搜索云端所有文件（免files.json）"""
    if not args.keyword:
        print(f"{KAOMOJI['error']} 请提供搜索关键词")
        print(f"{KAOMOJI['info']} 用法: r321-cloud search-direct <关键词>")
        return
    
    print(f"{KAOMOJI['thinking']} 直接搜索云端文件")
    print(f"(｡•̀ᴗ-)✧ 正在搜索关键词: '{args.keyword}'")
    print(f"{KAOMOJI['info']} 注意：此功能直接调用 Gitee API，无需本地 files.json 文件")
    
    try:
        client = GiteeClient()
        print(f"{KAOMOJI['loading']} 正在获取云端所有文件列表...")
        
        # 使用搜索功能
        results = client.search_files(args.keyword)
        
        if not results:
            print(f"\n{KAOMOJI['info']} 未找到包含关键词 '{args.keyword}' 的文件")
            print(f"{KAOMOJI['happy']} 云端文件搜索完成！")
            return
        
        # 导入分流文件处理器
        from r321cloud.utils.split_file_handler import SplitFileHandler
        
        # 处理分流文件，合并显示
        processed_files, files_to_hide = SplitFileHandler.group_split_files(results)
        
        if not processed_files:
            print(f"\n{KAOMOJI['info']} 未找到包含关键词 '{args.keyword}' 的文件")
            print(f"{KAOMOJI['happy']} 云端文件搜索完成！")
            return
        
        print(f"\n{KAOMOJI['success']} 找到 {len(processed_files)} 个匹配的文件:")
        print(f"{KAOMOJI['info']} 分流文件已合并显示")
        print(f"{'='*60}")
        
        for i, file_info in enumerate(processed_files, 1):
            file_name = file_info.get("name", "未知文件")
            file_path = file_info.get("path", "未知路径")
            file_size = file_info.get("size", "未知")
            file_type = file_info.get("type", "未知")
            download_url = file_info.get("download_url", "")
            
            # 如果是分流文件，特殊显示
            if file_info.get("is_split_file", False):
                original_name = file_info.get("original_name", "")
                chunk_count = file_info.get("chunk_count", 0)
                
                print(f"{i}. {file_name}")
                print(f"   路径: {file_path}")
                print(f"   类型: {file_type} [分流文件]")
                print(f"   原始文件: {original_name}")
                print(f"   分块数量: {chunk_count} 个")
                if file_info.get("has_metadata", False):
                    print(f"   元数据: 已包含")
                if download_url:
                    print(f"   下载: {download_url}")
            else:
                print(f"{i}. {file_name}")
                print(f"   路径: {file_path}")
                print(f"   类型: {file_type}")
                print(f"   大小: {file_size} 字节")
                if download_url:
                    print(f"   下载: {download_url}")
            print()
        
        print(f"{'='*60}")
        print(f"{KAOMOJI['happy']} 搜索完成！共找到 {len(processed_files)} 个文件 ovo")
        
        # 提供下载建议
        if results:
            print(f"\n{KAOMOJI['info']} 下载建议:")
            print(f"  使用 'r321-cloud download <文件名>' 下载文件")
            print(f"  例如: r321-cloud download {results[0].get('name', '')}")
            
    except Exception as e:
        print(f"{KAOMOJI['error']} 操作失败: {e}")