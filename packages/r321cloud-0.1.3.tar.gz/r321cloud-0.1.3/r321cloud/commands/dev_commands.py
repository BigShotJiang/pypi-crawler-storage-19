"""
开发者模式命令模块
处理开发者模式相关功能
"""

import sys
import os
import json
from r321cloud.utils.config import Config
from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji, format_with_kaomoji
from r321cloud.utils.pagination import display_paginated
from r321cloud.gitee import GiteeClient


def cmd_devmode_upload(args) -> None:
    """开发者模式：上传文件到云端 (开发中)"""
    print(f"{KAOMOJI['thinking']} 开发者模式上传功能 (开发中)")
    print(f"(｡•̀ᴗ-)✧ 正在尝试上传文件: {args.file}")
    print(f"提交信息: {args.message}")
    
    # 尝试导入上传函数
    try:
        # 由于upload_files.py在py目录下，需要调整导入路径
        import sys
        import os
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))
        
        from upload_files import upload_file_to_gitee
        
        print(f"{KAOMOJI['loading']} 正在上传文件...")
        
        # 调用上传函数
        upload_file_to_gitee(args.file, args.message)
        
        print(f"{KAOMOJI['success']} 文件上传成功！文件: {args.file}")
        
    except ImportError as e:
        print(f"{KAOMOJI['error']} 导入上传模块失败: {e}")
        print(f"{KAOMOJI['info']} 请确保 upload_files.py 文件存在")
        print(f"{KAOMOJI['happy']} 模拟上传完成！文件: {args.file}")
    except Exception as e:
        print(f"{KAOMOJI['error']} 上传过程中出现错误: {e}")
        print(f"{KAOMOJI['info']} 此功能仍在开发中，可能存在不稳定情况")


def cmd_devmode_status(args) -> None:
    """开发者模式：查看状态"""
    dev_mode_enabled = Config.get("dev_mode", False)
    print(f"{KAOMOJI['info']} 开发者模式状态:")
    print(f"  启用状态: {'已启用 ✓' if dev_mode_enabled else '未启用 ✗'}")
    if dev_mode_enabled:
        print(f"\n  可用功能 (开发中):")
        print(f"    • upload <文件> [--message] - 上传文件到云端")
        print(f"    • search <关键词> - 直接搜索云端所有文件")
        print(f"    • get - 获取云端文件列表并保存到本地")
        print(f"    • status - 查看当前状态")
        
        print(f"\n{KAOMOJI['info']} 管理开发者模式:")
        print(f"  启用: r321-cloud config --set-dev-mode true")
        print(f"  禁用: r321-cloud config --set-dev-mode false")
        
        print(f"\n{KAOMOJI['happy']} 输入 'r321-cloud devmode --help' 查看详细帮助 ovo")
    else:
        print(f"\n{KAOMOJI['info']} 如何启用开发者模式:")
        print(f"  运行: r321-cloud config --set-dev-mode true")
        print(f"  启用后会有安全警告提示，输入 'y' 确认即可")


def cmd_devmode_search(args) -> None:
    """开发者模式：直接搜索云端所有文件（免files.json）"""
    if not args.keyword:
        print(f"{KAOMOJI['error']} 请提供搜索关键词")
        print(f"{KAOMOJI['info']} 用法: r321-cloud devmode search <关键词>")
        return
    
    print(f"{KAOMOJI['thinking']} 开发者模式：直接搜索云端文件")
    print(f"(｡•̀ᴗ-)✧ 正在搜索关键词: '{args.keyword}'")
    print(f"{KAOMOJI['info']} 注意：此功能直接调用 Gitee API，无需本地 files.json 文件")
    
    try:
        client = GiteeClient()
        print(f"{KAOMOJI['loading']} 正在获取云端所有文件列表...")
        
        # 使用新的搜索功能
        results = client.search_files(args.keyword)
        
        if not results:
            print(f"\n{KAOMOJI['info']} 未找到包含关键词 '{args.keyword}' 的文件")
            print(f"{KAOMOJI['happy']} 云端文件搜索完成！")
            return
        
        # 使用分页显示
        print(f"\n{KAOMOJI['success']} 找到 {len(results)} 个匹配的文件")
        display_paginated(results, items_per_page=10)
        
        print(f"\n{KAOMOJI['happy']} 搜索完成！共找到 {len(results)} 个文件 ovo")
        
        # 提供下载建议
        if results:
            print(f"\n{KAOMOJI['info']} 下载建议:")
            print(f"  使用 'r321-cloud download <文件名>' 下载文件")
            print(f"  例如: r321-cloud download {results[0].get('name', '')}")
            
    except Exception as e:
        print(f"{KAOMOJI['error']} 搜索过程中出现错误: {e}")
        print(f"{KAOMOJI['info']} 请检查网络连接和 API 配置")


def cmd_devmode_get(args) -> None:
    """开发者模式：获取云端文件列表并保存到本地"""
    print(f"{KAOMOJI['thinking']} 开发者模式：获取云端文件列表")
    print(f"{KAOMOJI['cloud']} 云端同步中... 正在获取文件列表...")
    
    try:
        client = GiteeClient()
        print(f"{KAOMOJI['loading']} 正在获取云端所有文件列表...")
        
        # 获取所有文件
        all_files = client.get_all_files()
        
        if not all_files:
            print(f"{KAOMOJI['info']} 云端暂无文件")
            return
        
        # 转换为标准格式
        file_list = []
        for file_info in all_files:
            if file_info.get("type") == "file":  # 只处理文件，忽略目录
                file_list.append({
                    "name": file_info.get("name", ""),
                    "path": file_info.get("path", ""),
                    "size": file_info.get("size", 0),
                    "type": file_info.get("type", "file"),
                    "download_url": file_info.get("download_url", ""),
                    "sha": file_info.get("sha", "")
                })
        
        # 保存到本地
        local_path = os.path.join(os.getcwd(), "files.json")
        with open(local_path, "w", encoding="utf-8") as f:
            json.dump(file_list, f, ensure_ascii=False, indent=2)
        
        print(f"{KAOMOJI['success']} 文件列表已更新 ovo")
        print(f"{KAOMOJI['info']} 本地文件列表已保存到: {local_path}")
        print(f"{KAOMOJI['info']} 共获取 {len(file_list)} 个文件")
        
        # 显示前10个文件
        if file_list:
            print(f"\n{KAOMOJI['list']} 前10个文件:")
            print(f"{'='*60}")
            for i, file_info in enumerate(file_list[:10], 1):
                print(f"{i}. {file_info['name']} ({file_info['size']} 字节)")
            
            if len(file_list) > 10:
                print(f"... 还有 {len(file_list) - 10} 个文件")
            print(f"{'='*60}")
        
    except Exception as e:
        print(f"{KAOMOJI['error']} 获取文件列表失败: {e}")
        print(f"{KAOMOJI['info']} 请检查：")
        print("  1. 网络连接是否正常")
        print("  2. API密钥是否正确配置")
        print("  3. 仓库配置是否正确")
