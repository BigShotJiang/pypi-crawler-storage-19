"""
Gitee API 客户端
用于从 Gitee 获取文件列表和上传文件
"""

import json
import base64
import os
from typing import Dict, List, Optional, Any
import requests

from r321cloud.utils.config import Config


class GiteeClient:
    def __init__(self):
        config = Config.load()
        self._auth = config.get("access_token", "")
        self._owner = config.get("owner", "ruin321")
        self._repo = config.get("repo", "r321cloud")
        self._branch = config.get("branch", "master")
        self._api_base = config.get("api_base", "https://gitee.com/api/v5")
        self._raw_base = config.get("raw_base", "https://gitee.com")

    def _get_raw_url(self, file_path: str) -> str:
        return f"{self._raw_base}/{self._owner}/{self._repo}/raw/{self._branch}/{file_path}"

    def get_file_content(self, file_path: str) -> Optional[str]:
        """通过 Gitee API 获取文件内容"""
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/{file_path}"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        params = {
            "access_token": self._auth,
            "ref": self._branch
        }

        try:
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()

            # 如果返回的是列表，说明是目录，无法获取内容
            if isinstance(data, list):
                print(f"错误: {file_path} 是一个目录，不是文件")
                return None

            content = data.get("content", "")

            if content:
                return base64.b64decode(content).decode("utf-8")
            return None

        except requests.exceptions.RequestException as e:
            print(f"获取文件内容失败: {e}")
            return None

    def get_file_list(self) -> Optional[List[Dict[str, Any]]]:
        """通过 Gitee API 获取文件列表"""
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        params = {
            "access_token": self._auth,
            "ref": self._branch
        }

        try:
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()

            # 如果返回的是空列表，说明没有文件
            if isinstance(data, list) and len(data) == 0:
                return []

            # 如果返回的是字典，说明是单个文件
            if isinstance(data, dict):
                return [data]

            # 返回文件列表
            return data

        except requests.exceptions.RequestException as e:
            print(f"获取文件列表失败: {e}")
            return None

    def get_all_files(self, path: str = "") -> List[Dict[str, Any]]:
        """递归获取仓库中的所有文件"""
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/{path}"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        params = {
            "access_token": self._auth,
            "ref": self._branch
        }

        all_files = []
        
        try:
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()

            if not isinstance(data, list):
                # 如果是单个文件，直接返回
                if isinstance(data, dict) and data.get("type") == "file":
                    all_files.append(data)
                return all_files

            for item in data:
                if item.get("type") == "file":
                    all_files.append(item)
                elif item.get("type") == "dir":
                    # 递归获取子目录文件
                    sub_path = item.get("path", "")
                    sub_files = self.get_all_files(sub_path)
                    all_files.extend(sub_files)

            return all_files

        except requests.exceptions.RequestException as e:
            print(f"获取文件列表失败: {e}")
            return []

    def search_files(self, keyword: str) -> List[Dict[str, Any]]:
        """搜索仓库中的文件（通过文件名）"""
        all_files = self.get_all_files()
        if not all_files:
            return []

        results = []
        keyword_lower = keyword.lower()
        
        for file_info in all_files:
            file_name = file_info.get("name", "").lower()
            file_path = file_info.get("path", "").lower()
            
            if keyword_lower in file_name or keyword_lower in file_path:
                results.append(file_info)
        
        return results