"""Queue service removed."""
