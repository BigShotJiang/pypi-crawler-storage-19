import os
from os.path import exists
from random import randint
import json

from selenium import webdriver
from selenium.webdriver import Chrome
from math import floor
import pathlib

# Warn for old lib
print("WARN: util.py is a depreciated library. Use utilities.py or relevant files instead.")

class Path(pathlib.Path):
    """A brief extension of the Path class from pathlib to allow for addition operations."""
    def __add__(self, otherPath:str|pathlib.Path):
        return Path(f"{self}/{otherPath}")

# A simple set of configuration options to use for creating a chrome webdriver.
def get_driver() -> Chrome:
    print("Loading webdriver...")
    options = webdriver.ChromeOptions()
    options.add_argument(rf"--user-data-dir=C:\Users\Romayne\AppData\Local\Google\Chrome\User Data")
    options.add_argument(rf'--profile-directory=Profile 1')
    options.add_experimental_option('excludeSwitches', ['enable-logging'])
    options.binary_location = rf'C:\Program Files\Google\Chrome\Application\chrome.exe'
    driver = webdriver.Chrome(options)
    driver.implicitly_wait(5)
    return driver

# Returns whether the given file exists. If create is True, creates the file
# Returns True if the file already existed, False otherwise.
def ensure_file_exists(file_path:str, create = False):
    if exists(file_path):
        return True
    else:
        if create:
            with open(file_path, "x"):
                pass
        return False

# Read something from the given file. This returns None if the file doesn't exist.
def read_file_contents(file_path:str,
                       lines = False,
                       encoding = "utf-8",
                       read_mode = "r"):
    if not ensure_file_exists(file_path):
        return None
    if "b" in read_mode:
        encoding = None # Binary files do not take encoding arguments
    else:
        file = open(file = file_path, mode = read_mode, encoding = encoding)
        if lines:
            return file.readlines()
        else:
            return file.read()

def read_file_json(file_path:str|Path):
    if not ensure_file_exists(file_path):
        return {}
    try:
        return json.loads(open(str(file_path), "r").read())
    except TypeError:
        return {}

# Write out some string to the file path given. This will create the file if it does not yet exist.
def write_file_contents(file_path:str,
                        contents:str,
                        write_mode = "w"):
    ensure_file_exists(file_path, create = True)
    if (not "w" in write_mode) and (not "a" in write_mode):
        print(f"WARN: No valid 'w' or 'a' mode passed to write_mode {write_mode}. File writing will probably fail!")
    with open(file = file_path, mode = write_mode) as file:
        file.write(contents)

def delete_file(file_path:str|Path, confirm=True):
    if confirm:
        print(f"Delete {file_path}?")
        if not user_confirm():
            return
    os.remove(str(file_path))

# Write out a python list to a given file. Will cast each content to a string unless string_method is provided.
# Delimiter is newlines by default
def write_list_contents(file_path:str,
                        py_list:list,
                        delimiter = "\n",
                        string_method = str):
    outfile_contents = ""
    for item in py_list:
        string_item = string_method(item)
        outfile_contents += f"{string_item}{delimiter}"
    write_file_contents(file_path, outfile_contents)

# Pick a random entry from a list.
def pick(py_list:list):
    return py_list[randint(0, len(py_list)-1)]

# Pick a random entry from a list, and additionally prepend its index
def pick_rank(py_list:list) -> str:
    index = randint(0, len(py_list))
    return f"#{index}: {py_list[index]}"

# Beautify a list for printing.
def pretty_print_list(py_list:list, nesting = 0) -> str:
    outstr = ""
    nesting += 1
    for item in py_list:
        outstr += "".ljust(nesting*2, " ")
        if isinstance(item, dict):
            outstr += pretty_print_dict(item, nesting)
        elif isinstance(item, list):
            outstr += pretty_print_list(item, nesting)
        else:
            outstr += str(item)
        outstr += ",\n"
    outstr = outstr.rstrip("\n")
    nesting -= 1
    return outstr

# Beautify a dictionary for printing.
def pretty_print_dict(py_dict:dict, nesting = 0) -> str:
    outstr = ""
    for key in py_dict.keys():
        format_key = ""
        format_value = ""

        nesting += 1
        if isinstance(py_dict[key], dict):
            format_value += "\n"
            format_value += pretty_print_dict(py_dict[key], nesting)
        elif isinstance(py_dict[key], list):
            format_value += "\n"
            format_value += pretty_print_list(py_dict[key], nesting)
        else:
            format_value += f" {py_dict[key]}\n"
        nesting -= 1

        format_key += f"{"".ljust(nesting*2, " ")}{str(key).title()}:"
        outstr += f"{format_key}{format_value}"
    return outstr

def combineIntDicts(dict_into:dict[str,int], dict_from:dict[str,int], starting_value=0, del_from_dict=True):
    for key in dict_from.keys():
        # Prevent errors by creating new entries where needed
        new_key(dict_into, key, starting_value)
        dict_into[key] += dict_from[key]
    if del_from_dict:
        del(dict_from)

def first_key(d:dict):
    return next(iter(d))

def new_key(d:dict, new_key, new_value=None):
    if d[new_key]:
        return
    d[new_key] = new_value

def plural(n:int|float) -> str:
    return "s" if n != 1 else ''

def user_confirm() -> bool:
    max_tries = 10
    while max_tries > 0:
        max_tries -= 1
        confirm = input("Y/N: ").lower()[0]
        if confirm == 'y':
            return True
        if confirm == 'n':
            return False
    return False

def format_seconds_to_times(seconds:float|int) -> str:
    # Largest to smallest denominator
    seconds_in_one_minute = 1 * 60
    seconds_in_one_hour = 60 * seconds_in_one_minute
    seconds_in_one_day = seconds_in_one_hour * 24
    seconds_in_one_week = seconds_in_one_day * 7
    seconds_in_one_year = seconds_in_one_day * 365.25 # Slightly innacurate, but i dont care
    seconds_in_one_month = seconds_in_one_day * (365.25/12) # Also slightly innacurate, and i still dont care

    years = floor(seconds/seconds_in_one_year)
    seconds -= years * seconds_in_one_year

    months = floor(seconds/seconds_in_one_month)
    seconds -= months * seconds_in_one_month

    weeks = floor(seconds/seconds_in_one_week)
    seconds -= weeks * seconds_in_one_week

    days = floor(seconds/seconds_in_one_day)
    seconds -= days * seconds_in_one_day

    hours = floor(seconds/seconds_in_one_hour)
    seconds -= hours * seconds_in_one_hour

    minutes = floor(seconds/seconds_in_one_minute)
    seconds -= minutes * seconds_in_one_minute

    # and then seconds is left as it ought to be
    seconds = floor(seconds)

    toformat = [[years, "year"], [months, "month"], [weeks, "week"], [days, "day"], [hours, "hour"], [minutes, "minute"], [seconds, "second"]]
    output_str = ""
    for num_unit, unit in toformat:
        if num_unit == 0:
            continue
        output_str += f"{num_unit} {unit}{plural(num_unit)}, "
    output_str = output_str.rstrip(", ")
    return output_str

def save(filePath:str, newPath:str):
    if (not ensure_file_exists(str(filePath))):
        print(f"ERROR: {filePath} does not exist.")
        return False
    contents = read_file_contents(str(filePath))
    write_file_contents(str(newPath), contents)
    return True

def try_save(filePath:str, newPath:str):
    if (not save(filePath, newPath)):
        # Save unsuccessful, likely due to filePath not existing. Suggest loading (save in reverse)
        if (not ensure_file_exists(newPath)):
            print(f"Neither {newPath} or {filePath} exists. Uh oh!")
            return False # TODO: Just create a new file at filePath. Not done yet because its 
        print(f"Save of {filePath} failed. Load from {newPath} instead?")
        if (user_confirm()):
            save(newPath, filePath)
        else:
            return False
    return True

def sync_files(path1:str, path2:str, bidirectional=False):
    """
    file1: File to copy to file2 / recieve file1 if bidirectional
    file2: File to recieve copy1 / recieve file2 if bidirectional
    bidirectional: Whether or not to overwrite both ways.
    """
    # Edge case: If file1 is gone, load in file2
    if not ensure_file_exists(path1):
        print(f"Did not detect {path1}. Loading from {path2}")
        return try_save(path2, path1)
    
    file1_mtime = os.path.getmtime(str(path1)) if (ensure_file_exists(str(path1))) else 0
    file2_mtime = os.path.getmtime(str(path2)) if (ensure_file_exists(str(path2))) else 0

    # TODO: comment this tidbit when im not tired
    if file1_mtime > file2_mtime:
        return try_save(path1, path2)
    else:
        if bidirectional:
            return try_save(path2, path1)

def profile(func, *args, **kwargs):
    import time
    start = time.perf_counter()
    func(*args, **kwargs)
    return time.perf_counter() - start
