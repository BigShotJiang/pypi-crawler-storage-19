
def first_key(d:dict):
    return next(iter(d))

def new_key(d:dict, new_key, new_value=None):
    try:
        d[new_key]
        return
    except KeyError:
        d[new_key] = new_value

def combineIntDicts(dict_into:dict[str,int], dict_from:dict[str,int], starting_value=0, del_from_dict=True):
    for key in dict_from.keys():
        # Prevent errors by creating new entries where needed
        new_key(dict_into, key, starting_value)
        dict_into[key] += dict_from[key]
    if del_from_dict:
        del(dict_from)