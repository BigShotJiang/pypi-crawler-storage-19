from setuptools import setup, find_packages
from distutils.core import Extension

# read the contents of README.md file
from os import path
this_directory = path.abspath(path.dirname(__file__))
with open(path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()


VLM_VERSION = '2026.1.11'
ION_VERSION = '0.13.0'
PYNNG_VERSION = '0.8.1'

# print(find_packages())

setup(
  name = 'vl-messaging',
  url='https://github.com/DangerMouseB/VLMessaging',

  packages=[
    'vlmessaging',
    'vlmessaging._utils',
    'vlmessaging.utils',
  ],

  install_requires=[
    f'amazon.ion >= {ION_VERSION}',
    f'pynng >= {PYNNG_VERSION}',
  ],
  python_requires='>=3.11',

  version=VLM_VERSION,
  license='OSI Approved :: Apache Software License',
  description = 'Light-weight peer-to-peer messaging',
  long_description_content_type='text/markdown',
  long_description=long_description,
  author = 'David Briant',
  author_email = 'dangermouseb@forwarding.cc',
  download_url = '',
  keywords = [
    'messaging', 'distributed' , 'parallel'
  ],
  include_package_data=True,
  classifiers=[
    'Development Status :: 3 - Alpha',
    'Intended Audience :: Developers',
    'Intended Audience :: End Users/Desktop',
    'Intended Audience :: Science/Research',
    'Topic :: Utilities',
    'License :: OSI Approved :: Apache Software License',
    'Programming Language :: Python :: 3.11',
  ],
  zip_safe=False,
)
