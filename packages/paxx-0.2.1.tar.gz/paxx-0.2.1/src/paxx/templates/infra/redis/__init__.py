"""Redis infrastructure component."""
