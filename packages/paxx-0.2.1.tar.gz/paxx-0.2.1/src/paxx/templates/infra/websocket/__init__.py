"""WebSocket infrastructure component."""
