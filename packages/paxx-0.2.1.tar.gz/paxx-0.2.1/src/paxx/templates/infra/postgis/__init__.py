"""PostGIS infrastructure component."""
