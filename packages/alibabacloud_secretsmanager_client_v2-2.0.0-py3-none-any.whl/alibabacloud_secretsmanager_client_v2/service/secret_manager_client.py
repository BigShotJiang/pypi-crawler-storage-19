# coding=utf-8
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License


import abc


class SecretManagerClient(object):
    """
    密钥管理客户端抽象基类
    定义了密钥管理客户端的基本接口
    """
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def init(self):
        """
        初始化方法
        """

    @abc.abstractmethod
    def get_secret_value(self, get_secret_value_req):
        """
        获取指定凭据信息
        
        :param get_secret_value_req: 获取密钥值的请求
        """

    @abc.abstractmethod
    def close(self):
        """
        关闭资源
        """