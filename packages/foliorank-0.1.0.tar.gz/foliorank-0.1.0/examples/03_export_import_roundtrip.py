#!/usr/bin/env python3
"""
Example 3: Export and import roundtrip.

This example demonstrates the complete export/import pipeline for
sharing and storing simulation results safely.
"""

import sys
import os
import json
import tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sdk'))

from foliorank.agent import ControlledAgent

def main():
    print("Foliorank SDK Example 3: Export/Import Roundtrip")
    print("=" * 50)

    # Initialize the controlled agent
    agent = ControlledAgent()

    # Plan a portfolio
    portfolio = agent.plan("Create a conservative portfolio for simulation")
    print(f"Created portfolio: {portfolio['portfolio_name']}")
    print()

    # Run simulation
    simulation = agent.simulate(portfolio)
    print("Ran simulation with results:")
    print(f"  Expected return: {simulation['expected_return']:.1f}%")
    print()

    # Export the complete results
    export_bundle = agent.export_last_run()
    print("✅ Exported results to bundle")
    print(f"  Bundle keys: {list(export_bundle.keys())}")
    print()

    # Save to temporary file (simulating file storage)
    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        json.dump(export_bundle, f, indent=2)
        temp_file = f.name

    print(f"Saved bundle to temporary file: {os.path.basename(temp_file)}")
    print()

    # Load from file and import
    try:
        with open(temp_file, 'r') as f:
            loaded_bundle = json.load(f)

        imported_results = agent.import_bundle(loaded_bundle)
        print("✅ Imported bundle successfully!")
        print("Imported data matches original:"
        print(f"  Portfolio: {imported_results['portfolio_spec']['portfolio_name']}")
        print(f"  Simulation return: {imported_results['simulation_result']['expected_return']:.1f}%")
        print(f"  Audit hash: {imported_results['audit_hash'][:16]}...")

    except Exception as e:
        print(f"❌ Import error: {e}")
        return 1
    finally:
        # Clean up temporary file
        os.unlink(temp_file)

    return 0

if __name__ == "__main__":
    exit(main())