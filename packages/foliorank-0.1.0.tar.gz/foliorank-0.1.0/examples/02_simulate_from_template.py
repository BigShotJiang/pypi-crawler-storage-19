#!/usr/bin/env python3
"""
Example 2: Simulate a portfolio from template.

This example demonstrates how to load a portfolio template and run
deterministic simulation to generate performance metrics.
"""

import sys
import os
import json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sdk'))

from foliorank.agent import ControlledAgent

def main():
    print("Foliorank SDK Example 2: Simulate from Template")
    print("=" * 50)

    # Initialize the controlled agent
    agent = ControlledAgent()

    # Load a portfolio template
    template_path = os.path.join(os.path.dirname(__file__), '..', 'sdk', 'foliorank', 'templates', 'balanced.json')

    try:
        with open(template_path, 'r') as f:
            portfolio_template = json.load(f)

        print(f"Loaded template: {portfolio_template['portfolio_name']}")
        print()

        # Import the template (validates schema)
        imported_portfolio = agent.import_bundle({
            "portfolio_spec": portfolio_template,
            "simulation_result": {},  # Empty for template
            "audit_hash": "template",  # Placeholder
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        })

        print("✅ Template import successful!")
        print()

        # Run simulation
        simulation_result = agent.simulate(imported_portfolio["portfolio_spec"])
        print("Simulation results:")
        print(f"  Expected return: {simulation_result['expected_return']:.1f}%")
        print(f"  Volatility: {simulation_result['volatility']:.1f}%")
        print(f"  Time horizon: {simulation_result['time_horizon']}")
        print(f"  Version: {simulation_result['simulation_version']}")

    except Exception as e:
        print(f"❌ Error: {e}")
        return 1

    return 0

if __name__ == "__main__":
    exit(main())