#!/usr/bin/env python3
"""
Example 1: Plan a portfolio from natural language text.

This example demonstrates how to use Foliorank SDK to convert natural language
descriptions into structured portfolio specifications through MCP validation.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'sdk'))

from foliorank.agent import ControlledAgent

def main():
    print("Foliorank SDK Example 1: Plan from Text")
    print("=" * 50)

    # Initialize the controlled agent
    agent = ControlledAgent()

    # Example natural language input
    description = "I want a balanced portfolio for long-term simulation purposes"

    print(f"Input description: {description}")
    print()

    # Plan the portfolio (goes through MCP validation)
    try:
        portfolio = agent.plan(description)
        print("✅ Portfolio planning successful!")
        print()
        print("Generated portfolio:")
        print(f"  Name: {portfolio['portfolio_name']}")
        print("  Allocation:")
        for item in portfolio['allocation']:
            print(f"    - {item['asset']}: {item['weight']}%")
        print(f"  Rationale: {portfolio['rationale']}")

    except Exception as e:
        print(f"❌ Error: {e}")
        return 1

    return 0

if __name__ == "__main__":
    exit(main())