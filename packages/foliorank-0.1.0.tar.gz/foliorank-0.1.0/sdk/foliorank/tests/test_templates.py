"""
Template Validation Tests

This module tests that portfolio templates conform to schema requirements
and contain valid, simulation-safe asset specifications.
"""

import sys
import os
import json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from foliorank.schemas import portfolio_validator

def test_template_balanced():
    """Test balanced portfolio template."""
    template_path = os.path.join(os.path.dirname(__file__), '..', 'templates', 'balanced.json')

    with open(template_path, 'r') as f:
        template = json.load(f)

    # Validate against schema
    portfolio_validator.validate(template)

    # Check required fields
    assert template['portfolio_name'] == 'Balanced Simulation Portfolio'
    assert len(template['allocation']) == 3
    assert 'Large-cap equities' in [item['asset'] for item in template['allocation']]
    assert 'Government bonds' in [item['asset'] for item in template['allocation']]
    assert 'Cash equivalents' in [item['asset'] for item in template['allocation']]

    # Check weights sum to 100
    total_weight = sum(item['weight'] for item in template['allocation'])
    assert total_weight == 100

    print("✓ Balanced template validation passed")


def test_template_growth():
    """Test growth portfolio template."""
    template_path = os.path.join(os.path.dirname(__file__), '..', 'templates', 'growth.json')

    with open(template_path, 'r') as f:
        template = json.load(f)

    portfolio_validator.validate(template)

    assert template['portfolio_name'] == 'Growth Simulation Portfolio'
    assert len(template['allocation']) == 3
    assert 'Large-cap equities' in [item['asset'] for item in template['allocation']]

    # Growth should have higher equity weight
    equity_weight = next(item['weight'] for item in template['allocation'] if item['asset'] == 'Large-cap equities')
    assert equity_weight > 50

    total_weight = sum(item['weight'] for item in template['allocation'])
    assert total_weight == 100

    print("✓ Growth template validation passed")


def test_template_conservative():
    """Test conservative portfolio template."""
    template_path = os.path.join(os.path.dirname(__file__), '..', 'templates', 'conservative.json')

    with open(template_path, 'r') as f:
        template = json.load(f)

    portfolio_validator.validate(template)

    assert template['portfolio_name'] == 'Conservative Simulation Portfolio'
    assert len(template['allocation']) >= 1
    assert 'Government bonds' in [item['asset'] for item in template['allocation']]

    total_weight = sum(item['weight'] for item in template['allocation'])
    assert total_weight == 100

    print("✓ Conservative template validation passed")


def test_templates_abstract_assets_only():
    """Test that all templates use only abstract asset classes."""
    template_dir = os.path.join(os.path.dirname(__file__), '..', 'templates')
    allowed_assets = {
        'Large-cap equities',
        'Government bonds',
        'Cash equivalents',
        'Investment-grade credit'
    }

    for filename in os.listdir(template_dir):
        if filename.endswith('.json'):
            with open(os.path.join(template_dir, filename), 'r') as f:
                template = json.load(f)

            for item in template['allocation']:
                asset = item['asset']
                assert asset in allowed_assets, f"Template {filename} contains non-abstract asset: {asset}"

    print("✓ Abstract assets only validation passed")


if __name__ == "__main__":
    test_template_balanced()
    test_template_growth()
    test_template_conservative()
    test_templates_abstract_assets_only()

    print("\n🎉 All template tests passed!")