"""
Ranking Core Tests

This module contains tests for the Foliorank ranking functionality.
All tests ensure deterministic, neutral comparison of simulation results.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from foliorank.ranking import rank_bundles, RankingViolation


def test_rank_basic_ordering():
    """Test that ranking produces correct deterministic ordering."""
    # Create dummy bundles with different simulation metrics
    bundles = [
        {
            "portfolio_spec": {
                "portfolio_name": "High Return Portfolio",
                "allocation": [{"asset": "Large-cap equities", "weight": 80}, {"asset": "Government bonds", "weight": 20}],
                "rationale": "Portfolio focused on equity exposure"
            },
            "simulation_result": {
                "expected_return": 8.0,
                "volatility": 12.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "a" * 64,
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        },
        {
            "portfolio_spec": {
                "portfolio_name": "Balanced Portfolio",
                "allocation": [{"asset": "Large-cap equities", "weight": 50}, {"asset": "Government bonds", "weight": 40}, {"asset": "Cash equivalents", "weight": 10}],
                "rationale": "Balanced asset allocation"
            },
            "simulation_result": {
                "expected_return": 5.0,
                "volatility": 8.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "b" * 64,
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        },
        {
            "portfolio_spec": {
                "portfolio_name": "Conservative Portfolio",
                "allocation": [{"asset": "Government bonds", "weight": 70}, {"asset": "Cash equivalents", "weight": 30}],
                "rationale": "Conservative bond-focused portfolio"
            },
            "simulation_result": {
                "expected_return": 3.0,
                "volatility": 4.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "c" * 64,
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        }
    ]

    # Rank the bundles
    report = rank_bundles(bundles)

    # Verify report structure
    assert report["schema_version"] == "ranking_report_v1"
    assert report["scoring_profile"] == "v1_balanced"
    assert report["created_by"] == "foliorank-sdk"
    assert report["total_candidates"] == 3
    assert report["valid_candidates"] == 3
    assert len(report["ranked_items"]) == 3
    assert len(report["rejected_candidates"]) == 0

    # Verify ranking order (based on weighted scoring: return + risk + others)
    # High Return: high return but high volatility
    # Conservative: low return but very low volatility (highest risk_score)
    # Balanced: moderate return and volatility
    items = report["ranked_items"]
    assert items[0]["portfolio_name"] == "High Return Portfolio"  # Highest return score
    assert items[1]["portfolio_name"] == "Conservative Portfolio"  # Highest risk score (lowest volatility)
    assert items[2]["portfolio_name"] == "Balanced Portfolio"  # Middle scores

    # Verify scores are reasonable
    for item in items:
        assert 0 <= item["total_score"] <= 100
        assert "score_breakdown" in item
        assert "notes" in item

    print("✓ Basic ranking ordering test passed")


def test_rank_tie_breaking():
    """Test deterministic tie-breaking rules."""
    # Create bundles with identical scores but different hashes
    bundles = [
        {
            "portfolio_spec": {
                "portfolio_name": "Portfolio A",
                "allocation": [{"asset": "Large-cap equities", "weight": 50}, {"asset": "Government bonds", "weight": 50}],
                "rationale": "Test portfolio A"
            },
            "simulation_result": {
                "expected_return": 5.0,
                "volatility": 8.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "b" * 64,  # Higher lexicographic value
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        },
        {
            "portfolio_spec": {
                "portfolio_name": "Portfolio B",
                "allocation": [{"asset": "Large-cap equities", "weight": 50}, {"asset": "Government bonds", "weight": 50}],
                "rationale": "Test portfolio B"
            },
            "simulation_result": {
                "expected_return": 5.0,
                "volatility": 8.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "a" * 64,  # Lower lexicographic value
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        }
    ]

    report = rank_bundles(bundles)
    items = report["ranked_items"]

    # With identical scores, lexicographic hash should determine order
    # "a" * 64 comes before "b" * 64, so Portfolio B should rank higher
    assert items[0]["portfolio_name"] == "Portfolio B"
    assert items[1]["portfolio_name"] == "Portfolio A"

    print("✓ Tie-breaking test passed")


def test_rank_reject_invalid_bundle():
    """Test that invalid bundles are rejected with reason codes."""
    valid_bundle = {
        "portfolio_spec": {
            "portfolio_name": "Valid Portfolio",
            "allocation": [{"asset": "Large-cap equities", "weight": 50}, {"asset": "Government bonds", "weight": 50}],
            "rationale": "Test portfolio with complete allocation"
        },
        "simulation_result": {
            "expected_return": 5.0,
            "volatility": 8.0,
            "time_horizon": "long_term",
            "simulation_version": "v0.1"
        },
        "audit_hash": "a" * 64,
        "schema_version": "export_bundle_v1",
        "mcp_version": "v0.1"
    }

    # Create invalid bundle (wrong schema version)
    invalid_bundle = {
        "portfolio_spec": {
            "portfolio_name": "Invalid Portfolio",
            "allocation": [{"asset": "Large-cap equities", "weight": 100}],
            "rationale": "Invalid test portfolio"
        },
        "simulation_result": {
            "expected_return": 5.0,
            "volatility": 8.0,
            "time_horizon": "long_term",
            "simulation_version": "v0.1"
        },
        "audit_hash": "x" * 64,
        "schema_version": "invalid_schema",  # This should cause rejection
        "mcp_version": "v0.1"
    }

    bundles = [valid_bundle, invalid_bundle]
    report = rank_bundles(bundles)

    # Should have 1 valid, 1 rejected
    assert report["total_candidates"] == 2
    assert report["valid_candidates"] == 1
    assert len(report["ranked_items"]) == 1
    assert len(report["rejected_candidates"]) == 1

    # Check rejection reason
    rejected = report["rejected_candidates"][0]
    assert rejected["reason_code"] == "validation_failed"
    assert "schema" in rejected["reason"].lower()

    print("✓ Invalid bundle rejection test passed")


def test_rank_normalization_edge_case():
    """Test normalization with identical metric values."""
    # Create bundles with identical metrics
    bundles = [
        {
            "portfolio_spec": {
                "portfolio_name": "Portfolio A",
                "allocation": [{"asset": "Large-cap equities", "weight": 50}, {"asset": "Government bonds", "weight": 50}],
                "rationale": "Test portfolio A with identical metrics"
            },
            "simulation_result": {
                "expected_return": 5.0,
                "volatility": 8.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "a" * 64,
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        },
        {
            "portfolio_spec": {
                "portfolio_name": "Portfolio B",
                "allocation": [{"asset": "Large-cap equities", "weight": 50}, {"asset": "Government bonds", "weight": 50}],
                "rationale": "Test portfolio B with identical metrics"
            },
            "simulation_result": {
                "expected_return": 5.0,
                "volatility": 8.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "b" * 64,
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        }
    ]

    # Should not crash and assign default normalized scores
    report = rank_bundles(bundles)
    items = report["ranked_items"]

    # Both should have valid scores
    for item in items:
        assert isinstance(item["total_score"], (int, float))
        assert 0 <= item["total_score"] <= 100

        # Check normalization handled identical values
        breakdown = item["score_breakdown"]
        for metric_name, metric_data in breakdown.items():
            assert "normalized" in metric_data

    print("✓ Normalization edge case test passed")


def test_rank_neutral_language():
    """Test that ranking output uses neutral, non-prescriptive language."""
    bundles = [
        {
            "portfolio_spec": {
                "portfolio_name": "Test Portfolio",
                "allocation": [{"asset": "Large-cap equities", "weight": 50}, {"asset": "Government bonds", "weight": 50}],
                "rationale": "Test portfolio for ranking with neutral language"
            },
            "simulation_result": {
                "expected_return": 5.0,
                "volatility": 8.0,
                "time_horizon": "long_term",
                "simulation_version": "v0.1"
            },
            "audit_hash": "a" * 64,
            "schema_version": "export_bundle_v1",
            "mcp_version": "v0.1"
        }
    ]

    report = rank_bundles(bundles)
    item = report["ranked_items"][0]
    notes = item["notes"]

    # Check for banned prescriptive words
    banned_words = ["should", "recommend", "must buy", "guarantee", "advice"]
    notes_lower = notes.lower()

    for banned in banned_words:
        assert banned not in notes_lower, f"Found banned word '{banned}' in notes: {notes}"

    # Should contain neutral comparison language
    assert "ranking score" in notes
    assert "Simulation showed" in notes

    print("✓ Neutral language test passed")


def test_rank_empty_bundles():
    """Test that empty bundle list raises appropriate error."""
    try:
        rank_bundles([])
        assert False, "Should have raised RankingViolation"
    except RankingViolation as e:
        assert "No bundles provided" in str(e)

    print("✓ Empty bundles test passed")


if __name__ == "__main__":
    # Run all tests
    test_rank_basic_ordering()
    test_rank_tie_breaking()
    test_rank_reject_invalid_bundle()
    test_rank_normalization_edge_case()
    test_rank_neutral_language()
    test_rank_empty_bundles()

    print("\n🎉 All ranking tests passed!")