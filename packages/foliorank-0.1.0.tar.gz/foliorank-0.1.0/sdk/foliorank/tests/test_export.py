"""
Export/Import Pipeline Tests

This module contains tests for the export/import functionality of Foliorank SDK.
All tests ensure that simulation results can be safely shared and validated
without enabling any trading or execution activities.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from foliorank.agent import ControlledAgent
from foliorank.export import export_bundle, import_bundle, ExportViolation


def test_export_import_roundtrip():
    """Test that export and import preserves data integrity."""
    agent = ControlledAgent()

    # Create and run a full cycle
    original_results = agent.run_full_cycle("balanced portfolio")

    # Export the results
    export_bundle_result = agent.export_last_run()

    # Import the bundle
    imported_bundle = agent.import_bundle(export_bundle_result)

    # Verify that imported data matches original
    assert imported_bundle["portfolio_spec"] == original_results["portfolio"]
    assert imported_bundle["simulation_result"] == original_results["simulation"]
    assert imported_bundle["audit_hash"] == original_results["audit_hash"]

    print("✓ Export/import roundtrip test passed")


def test_export_hash_integrity():
    """Test that exported bundles maintain hash integrity."""
    agent = ControlledAgent()

    # Run full cycle and export
    agent.run_full_cycle("growth portfolio")
    exported = agent.export_last_run()

    # Verify export bundle has required fields
    required_fields = ["portfolio_spec", "simulation_result", "audit_hash", "schema_version", "mcp_version"]
    for field in required_fields:
        assert field in exported, f"Missing required field: {field}"

    # Verify schema version
    assert exported["schema_version"] == "export_bundle_v1"

    # Verify audit hash is proper SHA256 format
    audit_hash = exported["audit_hash"]
    assert len(audit_hash) == 64, f"Invalid hash length: {len(audit_hash)}"
    assert audit_hash.isalnum(), "Hash contains non-alphanumeric characters"

    print("✓ Export hash integrity test passed")


def test_reject_tampered_bundle():
    """Test that bundles with forbidden content are rejected."""
    agent = ControlledAgent()

    # Create a valid export bundle
    agent.run_full_cycle("balanced portfolio")
    valid_bundle = agent.export_last_run()

    # Add forbidden content (trading-related terms)
    tampered_bundle = valid_bundle.copy()
    tampered_bundle["portfolio_spec"]["rationale"] = "This portfolio is great for buying stocks on the exchange"

    # Attempt to import tampered bundle should fail
    try:
        agent.import_bundle(tampered_bundle)
        assert False, "Should have rejected tampered bundle"
    except ExportViolation:
        pass  # Expected behavior

    print("✓ Tampered bundle rejection test passed")


def test_reject_invalid_schema_version():
    """Test that bundles with invalid schema versions are rejected."""
    agent = ControlledAgent()

    # Create a valid export bundle
    agent.run_full_cycle("balanced portfolio")
    valid_bundle = agent.export_last_run()

    # Modify schema version to invalid value
    invalid_bundle = valid_bundle.copy()
    invalid_bundle["schema_version"] = "invalid_schema_v999"

    # Attempt to import should fail
    try:
        agent.import_bundle(invalid_bundle)
        assert False, "Should have rejected invalid schema version"
    except ExportViolation:
        pass  # Expected behavior

    print("✓ Invalid schema version rejection test passed")


def test_reject_forbidden_content():
    """Test that bundles with forbidden trading content are rejected."""
    agent = ControlledAgent()

    # Create a valid bundle
    agent.run_full_cycle("balanced portfolio")
    valid_bundle = agent.export_last_run()

    # Add forbidden content
    forbidden_bundle = valid_bundle.copy()
    forbidden_bundle["portfolio_spec"]["rationale"] = "This portfolio is great for buying stocks on the exchange"

    # Attempt to import should fail
    try:
        agent.import_bundle(forbidden_bundle)
        assert False, "Should have rejected forbidden content"
    except ExportViolation:
        pass  # Expected behavior

    print("✓ Forbidden content rejection test passed")


def test_export_without_previous_run():
    """Test that exporting without a previous run fails gracefully."""
    agent = ControlledAgent()

    # Try to export without running anything first
    try:
        agent.export_last_run()
        assert False, "Should have failed without previous run"
    except ExportViolation:
        pass  # Expected behavior

    print("✓ Export without previous run test passed")


if __name__ == "__main__":
    # Run all tests
    test_export_import_roundtrip()
    test_export_hash_integrity()
    test_reject_tampered_bundle()
    test_reject_invalid_schema_version()
    test_reject_forbidden_content()
    test_export_without_previous_run()

    print("\n🎉 All export/import tests passed!")