# -*- coding: utf-8 -*-
"""
Created on Sun Dec 28 20:10:51 2025

@author: Ronny JMD
"""

import napari
import numpy as np
from typing import Optional
from collections.abc import Iterable

import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, Normalize, TwoSlopeNorm, CenteredNorm, SymLogNorm

def to_1d_array(x, dtype=None):
    
    """
    Convert x into a numpy 1Dim array
    """
    
    if isinstance(x, np.ndarray):
        return np.atleast_1d(x)

    if isinstance(x, Iterable) and not isinstance(x, (str, bytes)):
        try:
            return np.fromiter(x, dtype=dtype)
        except TypeError:
            return np.atleast_1d(np.asarray(x, dtype=dtype))

    return np.atleast_1d(np.array(x, dtype=dtype))


def setIscale(frames,
              scale,
              Imin: Optional[float]= None, Imax: Optional[float]= None,
              Imed: Optional[float]= 0,
              linwidth: Optional[float]= 0.5, linsc: Optional[float]= 1):
    
    """
    To set the intensity scale mode
    https://fr.matplotlib.net/stable/api/colors_api.html#color-norms
    Arg:
        
        frames: np.ndarray containing your data to scale
        scale: lin | log | symctr | asymctr | symlog. symctr correspond to CenteredNorm operation, asymctr to TwoSlopeNorm, and symlog to SymLogNorm
        Imin: Fix lowest value of the color scale intensity
        Imax: Fix highest value of the color scale intensity
        Imed: Fix the median value, only used in symctr and asymctr. Default value is 0
        linwidth: Used in symlog, correspond to linthresh define by SymLogNorm function. Default value 0.5
        linsc: Used in symlog, correspond to linscale define by SymLogNorm function. Default value 1
    """   
    
    """
    🔹 Attribute Imin and Imax default value
    """
    if Imin is None:
        Imin = np.min(frames)
    
    if Imax is None:
        Imax = np.max(frames)
    
    """
    🔹 Set the norm value
    """
    scale = scale.lower()
    if scale == "lin":
        norm = Normalize(vmin=Imin, vmax=Imax)
    elif scale == "log":
        norm = LogNorm(vmin=Imin, vmax=Imax)
    elif scale == "symctr":
        norm = CenteredNorm(vcenter=Imed)
    elif scale == "asymctr":
        norm = TwoSlopeNorm(vcenter=Imed, vmin=Imin, vmax=Imax)
    elif scale == "symlog":
        norm = SymLogNorm(linthresh=linwidth, linscale=linsc, vmin=Imin, vmax=Imax)    

    return norm

def subtract_backgnd(minuend: np.ndarray, subtrahend: np.ndarray):
    
    """
    A simple subtraction function that can be use to remove background
    If subtrahend is an array to which the size of 0-axis is > 1, only the mean value along this axis is considered
    WARNING : The output only return positive values. All the negative ones are clipped
    Args:
        minuend: Generally the data to be subtracted
        subtrahend: The set that is subtracting
    """
    output = np.empty_like(minuend)
    
    if len(np.shape(subtrahend)) == len(np.shape(minuend)) and len(subtrahend) > 1:
        subtrahend = np.mean(subtrahend, axis=0, keepdims=True, out=output) # Use the mean from a set of frame
        np.subtract(minuend, output, out=output)
    elif len(np.shape(subtrahend)) == 2:
        np.subtract(minuend, subtrahend, out=output)
        
    return np.clip(output, 0, None) # Set all negative values to 0

def setROI(frames: np.ndarray, shape: dict = {"top":None, "left":None, "height":None, "width":None}) -> np.ndarray:
    
    """
    Crops a numpy array given top-left coordinates and crop size.
    This function can be used to define a zone or region of interest, from which you want to extract data (Vertical temporal evolution for example)
    Args:
        frames: Data to reshape
        shape: (top:int, _ Starting row index
                left:int, _ Starting column index
                height:int, _ Number of row to crop
                width:int) _ Number of column to crop
    Return: cropped frames
    """
    h, w = frames.shape[-2:]
    
    """
    🔹 Check for attributed value
    """
    if not isinstance(frames, np.ndarray):
        raise TypeError("Input must be a numpy.ndarray")

    if shape["top"] is not None and shape["height"] is None:
        raise ValueError("Height size need to be assigned")
    if shape["left"] is not None and shape["width"] is None:
        raise ValueError("Width size need to be assigned")

    if shape["top"] is None:
        shape["top"] = 0
        shape["height"] = h
    if shape["left"] is None:
        shape["left"] = 0
        shape["width"] = w

    if shape["top"] < 0 or shape["left"] < 0 or shape["height"] <= 0 or shape["width"] <= 0:
        raise ValueError("Crop coordinates and size must be positive")
    if shape["top"] + shape["height"] > h or shape["left"] + shape["width"] > w:
        raise ValueError("Crop exceeds array bounds")
    
    """
    🔹 Crop by slicing method
    """
    return frames[:, shape["top"]:shape["top"] + shape["height"], shape["left"]:shape["left"] + shape["width"]]

def centerROI(frames: np.ndarray, crop_height: int, crop_width: int) -> np.ndarray:
            
    """
    Crops a numpy array given crop size.
    Args:
        frames: Data to reshape
        crop_height: height to be cropped
        crop_width: width to be cropped
    Return: centered cropped frames
    """
    h, w = frames.shape[-2:]
    start_y = (h - crop_height) // 2
    start_x = (w - crop_width) // 2
    return frames[:, start_y:start_y+crop_height, start_x:start_x+crop_width]

def collapse_axis(frames: np.ndarray, axis: int, method: str = "mean", weights: np.ndarray | None = None, normalize: bool = False, keepdims: bool = False,):
    
    """
    Collapse one axis of an array using a specified method.
    Usually 0-axis = time, 1-axis = vertical axis| y | height, 2-axis = horizontal axis| x | width
    Can be used in the case you want to display a 2D plot from a 3D data for example, and highlight specific vertical behavior

    Args:
        data : np.ndarray _ e.g. shape (t, y, x)
        axis : int >= 0 _ Axis to collapse
        method : {'mean', 'sum', 'median', 'max', 'min'} _ Reduction method
        weights : np.ndarray, optional _ Weights for weighted mean (only for method='mean')
        normalize : bool _ Normalize result by axis length (only for method='sum')
        keepdims : bool _ Whether to keep the collapsed dimension

    Return: np.ndarray _ Collapsed array
    """
    frames = np.asarray(frames) # Ensure to work with an array if input is another Iterable

    if axis < 0 or axis >= frames.ndim:
        raise ValueError(f"Invalid axis {axis} for array with {frames.ndim} dims")

    method = method.lower()

    if method == "mean":
        if weights is not None:
            return np.average(frames, axis=axis, weights=weights, keepdims=keepdims)
        return np.mean(frames, axis=axis, keepdims=keepdims)

    if method == "sum":
        result = np.sum(frames, axis=axis, keepdims=keepdims)
        if normalize:
            norm = frames.shape[axis]
            if norm == 0:
                raise ValueError("Cannot normalize over an empty axis")
            result = result / norm
        return result

    if method == "median":
        return np.median(frames, axis=axis, keepdims=keepdims)

    if method == "max":
        return np.max(frames, axis=axis, keepdims=keepdims)

    if method == "min":
        return np.min(frames, axis=axis, keepdims=keepdims)

    raise ValueError(f"Unknown method '{method}'. "
                     "Choose from 'mean', 'sum', 'median', 'max', 'min'.")

def plot2D(frames,
           x: np.ndarray | None = None, y: np.ndarray | None = None,
           *,
           x0: float = 0, dx: float = None, 
           y0: float = 0, dy: float = None,
           ax: plt.Axes | None = None,
           cmap: str = "turbo",
           levels: int | np.ndarray = 20,
           norm: Normalize | None = None,
           cbar: bool = False,
           scale='lin'):
    
    """
    Perfom a 2D plot using contourf matplotlib
    Args:
        frames: Data to plot, must be a 2 dimensionnal array
        x0, y0: Starting value on the x-axis (resp. y-axis), the default value is 0
        dx, dy: Spacing between x (resp. y) adjacent values, the default value is 1
        x, y: If these parameter are given, ignore previous ones (x0, y0, dx, dy)
        ax: Existing axis if there is
        cmap: Default is "turbo"
        levels: Optionnal int or array input. Set the number of minor scale, the more the smoother the image will appear
        norm: Value returned by the setIscale function
        cbar: To display the color bar scale, default is False
    Return: the ax containing the plot
    """
    frames = np.asarray(frames) # Ensure to work with an array if input is another Iterable
    if frames.npdim != 2:
        raise ValueError("Input data to plot must be 2D")
        
    Nx, Ny = frames.shape

    if x or y is not None:
        raise ValueError("If parameter x (resp. y) is given, the parameter y (resp. x) need also to be assigned")
        
    elif x and y is None:
        x = np.linspace(start = x0,
                        stop = Nx,
                        num = abs((Nx-x0)*dx))
        y = np.linspace(start = y0,
                        stop = Nx,
                        num = abs((Ny-y0)*dy))

    else:
        x = np.asarray(x) # Ensure to work with an array if input is another Iterable
        y = np.asarray(y) # Ensure to work with an array if input is another Iterable
        
    X, Y = np.meshgrid(x, y)
    Z = frames.transpose()
    
    if ax is None:
        fig, ax = plt.subplots()
        
    cs = ax.contourf(X, Y, Z, 
                     levels=levels, 
                     cmap=cmap, 
                     norm=norm,
                     extend = 'both')
    
    if cbar:
        plt.colorbar(cs, ax=ax, label="Intensity")
        
    return ax

def add_lines(ax, lines):
    
    """
    Add 1 or more lines to the ax
    If you only want to add just an horizontal line, just set x = your x-scale and reversly for a vertical line
    Indented to the ax scales
    lines = list of dicts:
                dict(x=..., y=..., color=..., lw=..., label=...)
    """
    for line in lines:
        ax.plot(
            line["x"],
            line["y"],
            color=line.get("color", "r"),
            lw=line.get("lw", 2),
            ls=line.get("ls", "--"),
            label=line.get("label"),
        )
    if any("label" in l for l in lines):
        ax.legend()

def add_titles(ax, x_label: str = None, y_label: str = None, title: str = None):
    
    """
    Add titles where it is specified
    """
    if x_label is not None:
        ax.set_xlabel(y_label)
    if y_label is not None:
        ax.set_ylabel(y_label)
    if title is not None:
        ax.set_title(title)


def viewFrames(frames: np.ndarray, t: Optional[np.ndarray] = None, t_unit: Optional[str] = None):
    
    """
    To visualize frames data
    Arg:
        frames: np.ndarray of data
    """
    if t and t_unit is not None:
        
        #Check input validity
        if not isinstance(t, Iterable) or not isinstance(t_unit, str):
            raise TypeError("t must be a iterable class variable and t_unit a string")
        else:
            
            t.to_1d_array()
               
            def time_bar(viewer, t, t_unit):
                def update(event=None):
                    i = viewer.dims.current_step[0]
                    viewer.status = f"t = {t[i]:.1f} {t_unit}    (frame {i})"
            
                viewer.dims.events.current_step.connect(update)
                update()
                
            viewer, _= napari.imshow(frames,
                                     name="Current data",
                                     scale=(t[1]-t[0], 1.0, 1.0), # Δt
                                     translate=(t[0], 0.0, 0.0),
                                     axis_labels=(f"time ({t_unit})", "y", "x"))
            
            time_bar(viewer, t, t_unit)
            
    else: # Show data without time information
        napari.imshow(frames)
        
    napari.run()

        

"""============================================================================
                                PANNEAU DE TEST
============================================================================"""

if __name__ == "__main__":
    import os
    from concatenate_frames import concatenateRTV
    
    os.chdir(os.path.join(os.pardir, 'Example'))
    test = concatenateRTV(("Test.rtv","Test2.rtv","Test3.rtv"), 40, 48)

# # Test de la commande video
#     ani = video(test)
#     plt.show()
#     ani.save("output_10fps.mp4", writer="ffmpeg", dpi=150)
    
# # Test de la commande pour visualiser data
#     viewFrames(test)

# Test pour la fonction setROI
    viewFrames(setROI(test, (465, 200, 450, 450)))
    
#     add_lines(ax, [
#     dict(x=t, y=y1, color="w", label="front"),
#     dict(x=t, y=y2, color="c", ls="--", label="back"),
# ])
    # ax2.add_patch(einf)
    # ax2.add_patch(esup)
    # ax2.axhline(370, color='white', linestyle='--', linewidth=5)
    # ax2.axhline(500, color='white', linestyle='--', linewidth=5)
    # ax2.axhline(820, color='white', linestyle='--', linewidth=5)
    # ax2.axhline(925, color='white', linestyle='--', linewidth=5)
    # einf = patches.Rectangle((0, 370), max(x), 140, hatch='++', fill=None, color='peru', zorder=1)
    # esup = patches.Rectangle((0, 815), max(x), 140, hatch='++', fill=None, color='peru', zorder=1)
    
    # ax2.text(max(x)/2, 370+130/2, 'HV electrode', color='white', ha='center', va='center', wrap=True)
    # ax2.text(max(x)/2, 815+130/2, 'GND electrode', color='white', ha='center', va='center', wrap=True)
    # ax2.axis([x.min(), x.max(), y.max(), y.min()])
    # ax2.set_xlabel('Time (ns)')
    # ax2.set_ylabel('Position (pix)')


