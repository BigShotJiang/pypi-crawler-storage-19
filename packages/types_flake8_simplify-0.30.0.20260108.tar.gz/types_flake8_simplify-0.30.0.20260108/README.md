## Typing stubs for flake8-simplify

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`flake8-simplify`](https://github.com/MartinThoma/flake8-simplify) package. It can be used by type checkers
to check code that uses `flake8-simplify`. This version of
`types-flake8-simplify` aims to provide accurate annotations for
`flake8-simplify==0.30.*`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/flake8-simplify`](https://github.com/python/typeshed/tree/main/stubs/flake8-simplify)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.18.2
* [pyright](https://github.com/microsoft/pyright) 1.1.407

It was generated from typeshed commit
[`a564787bf23386e57338b750bf4733f3c978b701`](https://github.com/python/typeshed/commit/a564787bf23386e57338b750bf4733f3c978b701).