"""skill-upd: CLI tool for updating Claude Code, Codex, OpenCode, Amp, Clawdbot agent skills."""

__version__ = "0.0.1"
