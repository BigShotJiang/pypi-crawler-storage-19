# Synthetica-py 🚀

[![Latest Version](https://img.shields.io/pypi/v/synthetica-py.svg?color=blue&style=for-the-badge)](https://pypi.org/project/synthetica-py/)
[![Python Versions](https://img.shields.io/pypi/pyversions/synthetica-py.svg?style=for-the-badge)](https://pypi.org/project/synthetica-py/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)

**Synthetica-py** is a high-performance synthetic data generation engine. Designed for the 2026 AI landscape, it bridges the gap between local models (Ollama, LM Studio) and frontier APIs (Gemini 3 Flash).

---

### 🌟 New in v0.1.3
*   **Bulletproof JSON Parsing:** Advanced regex extraction and cleanup for inconsistent LLM responses.
*   **Enhanced Rate Limiting:** Smarter backoff and request pacing for Gemini Free Tier (10 RPM cap).
*   **Zero-Config Mode:** TaskSpec now supports sane defaults for instant data generation.

## 🚀 Quick Start

### Installation
```bash
pip install synthetica-py
```

### Ultra-Fast Usage
```python
import asyncio
from synthetica import SyntheticDataGenerator
from synthetica.core.task_spec import TaskSpec

async def main():
    # Uses gemini-3-flash-preview by default
    gen = SyntheticDataGenerator.with_gemini()
    
    task = TaskSpec(
        instruction="Generate healthy recipes",
        fields=["dish_name", "calories", "ingredients"],
        num_samples=5
    )
    
    dataset = await gen.generate_async(task)
    dataset.export_csv("recipes.csv")

if __name__ == "__main__":
    asyncio.run(main())
```

## 🛠 Features

-   **🎯 Task-Centric:** Specialized logic for Instruction Tuning, RAG Evaluation (Grounding), AGENT Trajectories, and Adversarial Safety testing.
-   **⚖️ Curriculum Difficulty:** Automatic calibration of difficulty levels (Easy -> Adversarial) to improve model convergence.
-   **🛠 Model Provider Agnostic:** Unified API for **Ollama**, **LM Studio**, **Google Gemini**, and **llama.cpp**.
-   **🔍 Multi-Stage Pipeline:** Automated generation -> Cross-model Critique -> Schema Validation -> Semantic Deduplication.
-   **📦 Cloud-Ready Export:** Native support for HuggingFace `datasets`, JSONL, and flattened CSV formats.

## 👨‍💻 Developer
**C. Emre Karataş**

## 📄 License
MIT License - Developed for the open-source AI community.

