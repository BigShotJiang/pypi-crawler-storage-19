# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


from ansys.edb.core.definition.component_model import (
    NPortComponentModel as GrpcNPortComponentModel,
)


class NPortComponentModel:
    """Class managing :class:`NPortComponentModel <ansys.edb.core.definition.component_model.NPortComponentModel>`"""

    def __init__(self, edb_object):
        self.core = edb_object

    @classmethod
    def create(cls, name: str = None) -> "NPortComponentModel":
        """Create a new NPortComponentModel object.

        Returns
        -------
        NPortComponentModel
            The newly created NPortComponentModel object.
        """
        if not name:
            raise ValueError("Name must be provided to create NPortComponentModel.")
        grpc_nport_component_model = GrpcNPortComponentModel.create(name=name)
        if grpc_nport_component_model.is_null:
            raise ValueError("Failed to create NPortComponentModel.")
        return cls(grpc_nport_component_model)
