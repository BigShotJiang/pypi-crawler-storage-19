# koruspy/__init__.py

__all__ = [
    "Some", "nothing", "SomeList", "println", "Okay", "Err",
    "option_of", "AsyncOption", "async_option",
    "ResultUnwrapError", "KoruspyError", "OptionUnwrapError", "LazyList"
]

from .Option import Some, nothing, option_of, _NoneOption, SomeList, LazyList
from .Result import Err, Okay, result_of
from .Async_option import AsyncOption, async_option
from .errors import ResultUnwrapError, OptionUnwrapError, KoruspyError

# Tenta importar a versão Cython já compilada
try:
    from .printlnUtils.cythonprintln import println
except ImportError:
    # Fallback em Python puro
    def println(*args, **kwargs):
        print(*args, **kwargs)