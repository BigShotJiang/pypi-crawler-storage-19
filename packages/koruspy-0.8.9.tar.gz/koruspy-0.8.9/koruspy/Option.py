from __future__ import annotations
from typing import TypeVar, Generic, Callable, overload
from .errors import OptionUnwrapError
import collections
from collections import deque
from itertools import dropwhile

T = TypeVar("T")
U = TypeVar("U")

class Some(Generic[T]):

    __slots__ = ("value",)
    __match_args__ = ("value",)

    def __eq__(self, other):
        if isinstance(other, Some):
            return self.value == other.value
        return self.value == other
    
    def to_list(self):
        return SomeList([self.value])

    def __iter__(self):
        yield self.value

    def unwrap_or_else(self, func: Callable[[], U]):
        return self.value
        
    def flatten(self):
        if isinstance(self.value, (Some, _NoneOption)):
            return self.value
        return self    

    def on_nothing(self, func):
        return self

    def and_then(self, func: Callable[[T], Some[T] | _NoneOption]):
        try:
            return func(self.value)
        except Exception:
            return nothing
   
    def filter(self, condition: Callable[[T], bool]):
        try:
            if condition(self.value):
                return self
            return nothing
        except Exception:
            return nothing

    def getattr(self, attr_name):
        try:
            val = getattr(self.value, attr_name)
            return Some(val)
        except AttributeError:
            return nothing

    def __init__(self, value: T):
        self.value = value

    def unwrap_or(self, default):
        return self.value

    def finalize(self):
        return self.value

    def __repr__(self):
        return f"\033[92m{self.value}\033[0m"

    def if_present(self, func):
        return func(self.value)

    def to_int(self):
        try:
            return Some(int(self.value))
        except ValueError:
            return nothing

    def to_float(self):
           try:
               return Some(float(self.value))  
           except (ValueError, TypeError):
               return nothing   

    @overload
    def map(self, func: Callable[[T], U]) -> Some[U]:
        ...

    def map(self, func: Callable[[T], U]) -> Some[U] | _NoneOption:
        result = func(self.value)
        if result is None:
            return nothing
        return Some(result)    

    @overload
    def get_value(self) -> Some[T]:
        ...

    def get_value(self) -> Some[T] | _NoneOption:
        return Some(self.value)

    def is_present(self):
        return True


class _NoneOption(Generic[T]):
    _instance = None
    __match_args__ = ()
    __slots__ = ()

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def to_list(self):
        return nothing

    def __iter__(self):
        yield from ()

    def to_float(self):
        return nothing

    
    def unwrap_or_else(self, func: Callable[[], U]):
        return func()

    def flatten(self):
        return nothing


    def on_nothing(self, func: Callable[[], None]):
        func()
        return nothing

    def filter(self, condition: Callable[[T], bool]):
        return nothing

    def and_then(self, func: Callable[[T], nothing]):
        return nothing

    def getattr(self, attr_name):
        return nothing
   
    def unwrap_or(self, default):
        return default

    def finalize(self):
        raise OptionUnwrapError("Option doesnt has a value, try using `unwrap_or()` or `unwrap_or_else()` for fallback value")

    def __repr__(self):
        return "\033[1;91mnothing\033[0m"


    def if_present(self, func):
        return nothing 

    def to_int(self):
        return nothing

    def map(self, func):
        return nothing

    def get_value(self):
        return nothing

    def is_present(self):
        return False

nothing = _NoneOption()


def option_of(value, default):
    if value is None or isinstance(value, _NoneOption):
        if default is not None and default is not nothing:
            return Some(default)
    if isinstance(value, Some):
        return value
    return Some(value)

class SomeList(Generic[T], collections.abc.MutableSequence):
    __slots__ = ("value", "frozen",)

    def __init__(self, value, frozen=False):
        self.frozen = frozen
        if value is nothing or value is None:
            self.value = []
        elif isinstance(value, SomeList):
            self.value = value.value.copy()
        # Dentro do __init__ da SomeList
        elif isinstance(value, LazyList):
            self.value = list(value) # 

        elif isinstance(value, Some):
            inner = value.value
            self.value = list(inner) if isinstance(inner, list) else [inner]

        elif isinstance(value, list):
            self.value = value

        elif hasattr(value, '__iter__') and not isinstance(value, (str, bytes)):
            self.value = list(value)
        else:
            self.value = [value]    
    @property
    def val(self):
        return self.value

    @classmethod
    def as_frozen(cls, value):
        return cls(value, frozen=True)

    def __getitem__(self, index):
        return self.value[index]

    def __setitem__(self, index, change):
        if self.frozen: return 
        self.value[index] = change
        
    def __bool__(self):
        return bool(self.value)

    def __delitem__(self, index):
        if self.frozen: return
        del self.value[index]

    def map(self, fn: Callable[[T], U]) -> SomeList[T] | nothing:
        try:
            return SomeList(fn(item) for item in self.value)
        except Exception:
            return nothing
            
    @classmethod
    def to_somelist(cls, valor):
        return cls(valor)

    def to_integerlist(self):
        if not self.value or not isinstance(self.value, list):
            return nothing
        try:
            return SomeList([int(item if not isinstance(item, Some) else item.value) for item in self.value])
        except (TypeError, ValueError):
            return nothing    

    def to_floatlist(self):
        if not self.value or not isinstance(self.value, list):
            return nothing
        try:
            return SomeList([float(item if not isinstance(item, Some) else item.value) for item in self.value]) 
        except (TypeError, ValueError):
            return nothing     

    def unwrap_list(self) -> Some[T] | nothing:
        results = []
        for item in self.value:
            if item is nothing:
                return nothing
            elif isinstance(item, Some):
                results.append(item.value)
            else:
                results.append(item)
        return Some(results)    

    def unwrap_list_or_else(self, func: Callable[[], T]) -> Some[T]:
        results = []
        for item in self.value:
            if item is nothing:
                return Some(func())
            elif isinstance(item, Some):
                results.append(item.value)
            else:
                results.append(item)
        return Some(results)     
                

    def unwrap_list_or(self, default: T) -> Some[T]:
        results = []
        for item in self.value:
            if item is nothing:
                return Some(default)
            elif isinstance(item, Some):
                results.append(item.value)
            else:
                results.append(item)
        return Some(results)                 

    def pop(self, index=-1):
        if self.frozen:
            return self

        if not self.value:
            return nothing
        try:
            item = self.value.pop(index)
            return item if isinstance(item, Some) else Some(item)
        except (IndexError, AttributeError):
            pass
        return nothing 
    
    def remove(self, val):
        try:
            item = self.value.remove(val)
        except(ValueError, AttributeError):
            pass

    def insert(self, index, content):
        if self.frozen:
            return self
        
        self.value.insert(index, content)
        return self

    def __iter__(self):
        yield from self.value  
    
    def sum(self):
        if self.value is nothing or self.value is None:
            return 0
        total = 0
        for item in self.value:
            if isinstance(item, Some):
                val = item.value
            else:
                val = item
            if isinstance(val, (int, float)):
                total += val
        return total 

    def append(self, item):
        if self.frozen:
            return self

        if item is not nothing and item is not None:
            self.value.append(item)
        return self

    def head(self):
        if not self.value:
            return nothing
        first = self.value[0]  
        return first if isinstance(first, Some) else Some(first)

    def last(self):
        if not self.value:
            return nothing
        last_item = self.value[-1] 
        return last_item if isinstance(last_item, Some) else Some(last_item)  
    
    def tail(self):
        if not self.value:
            return nothing
        if len(self.value) <= 1:
            return nothing
        if isinstance(self.value, list):
            return SomeList(self.value[1:])
        return nothing    
        
    def filter_nothing(self):
        return SomeList([x for x in self.value if x is not nothing and x is not None])    

    def filter(self, cond):
        result = [item for item in self.value if cond(item)]
        return SomeList(result)

    def extend(self, items):
        if self.frozen:
            return self

        if isinstance(items, SomeList):
            to_add = items.value
        elif isinstance(items, list):
            to_add = items
        elif hasattr(items, "__iter__"):
            to_add = list(items)      
        else:
            return self
        self.value.extend([v for v in to_add if v is not nothing and v is not None])  
        return self        
    
    def __contains__(self, other):
        return other in self.value

    def __eq__(self, other):
        if isinstance(other, SomeList):
            return other.value == self.value
        return self.value == other    

    def __repr__(self):
        return f"\033[92mSomeList({self.value})\033[0m"    

    def clear(self):
        self.value.clear()
        return self  

    # Dentro da SomeList
    def for_each(self, fn: Callable[[T], None]):
        for item in self.value:
            fn(item)
        return self # Retorna self para permitir encadeamento

    def find(self, cond):
        if not isinstance(self.value, list):
            return nothing
        for v in self.value:
            valor_real = v.value if isinstance(v, Some) else v
            if cond(valor_real):
                return v if isinstance(v, Some) else Some(v)
        return nothing        

    def safe_reduce(self, func, initial = None):
        if not self.value:
            return nothing if initial is None else Some(initial)
        try:
            if initial is None:
                iterator = iter(self.value)
                try:
                    accumulator = next(iterator)
                    if isinstance(accumulator, Some): accumulator = accumulator.value
                    items_to_process = iterator
                except StopIteration:
                    return nothing
            else:
                accumulator = initial
                items_to_process = self.value
            for item in items_to_process:
                val = item.value if isinstance(item, Some) else item
                accumulator = func(accumulator, val)
            return Some(accumulator)
        except Exception:
            return nothing        
                         
            
    def as_lazy(self):
        return LazyList(lambda: (item for item in self.value))

    def __len__(self):
        try:
            return len(self.value)   
        except TypeError:
            return 1 if self.value is not nothing else 0    


class LazyList(Generic[T]):
    __slots__ = ("value",)

    def __init__(self, value):
        self.value = value

    def __iter__(self):
        return self.value()

    def __repr__(self):
        return f"LazyList({self.value})"

    def lazy_map(self, fn):
        gen = lambda: (fn(v) for v in self.value())
        return LazyList(gen)

    def as_SomeList(self):
        return SomeList(list(self.value()))

    def lazy_filter(self, cond):
        gen = lambda: (v for v in self.value() if cond(v))
        return LazyList(gen)
    def lazy_sum(self):
        total = 0
        for item in self.value():
            if isinstance(item, Some):
                val = item.value
            else:
                val = item
            if isinstance(val, (int, float)):
                total += val
        return total     
    
    # Dentro da classe LazyList
    def take(self, n: int):
        def gen():
            count = 0
            for item in self.value():
                if count >= n: break
                yield item
                count += 1
        return LazyList(gen)

    def drop(self, n: int):
        def gen():
            it = self.value()
            for _ in range(n):
                try:
                    next(it)
                except StopIteration:
                    return
            yield from it
        return LazyList(gen)    

    def drop_last(self, n: int):
        if n <= 0: return self
        def gen():
            it = self.value
            queue = deque()
            for _ in range(n):
                try:
                    queue.append(next(it))
                except StopIteration:
                    return
            for item in it:
                yield queue.popleft()
                queue.append(item)
        return LazyList(gen)        
    def drop_while(self, cond):
        return LazyList(dropwhile(cond, self.value()))

    def for_each(self, fn: Callable[[T], None]):
        for item in self.value():
            fn(item)
        

