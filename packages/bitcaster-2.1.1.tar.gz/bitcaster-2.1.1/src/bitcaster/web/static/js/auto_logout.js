(function() {
  document.addEventListener("DOMContentLoaded", () => {
    const body = document.body;
    const timeout = parseInt(body.dataset.timeout, 10);
    const logoutUrl = body.dataset.logoutUrl;

    if (!timeout || !logoutUrl) {
      console.error("Auto-logout: missing data-timeout or data-logout-url on <body>");
      return;
    }

    let timer;

    function resetTimer() {
      clearTimeout(timer);
      timer = setTimeout(() => {
        window.location.href = logoutUrl;
      }, timeout);
    }

    ["click", "mousemove", "keydown", "scroll", "touchstart"].forEach(evt => {
      document.addEventListener(evt, resetTimer, true);
    });

    resetTimer();
  });
})();
