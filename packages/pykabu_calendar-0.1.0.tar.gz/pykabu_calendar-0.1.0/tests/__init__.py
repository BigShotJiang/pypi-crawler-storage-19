"""Tests for pykabu-calendar."""
