import cx_Oracle
import oracledb
from dbutils.pooled_db import PooledDB
from .db_abstract import BaseDBSync, BaseDBAsync
from himile_log import logger


class OracleSync(BaseDBSync):
    """同步Oracle客户端"""

    def __init__(self, cfg: dict):
        """
        初始化 Oracle 同步客户端
        :param cfg: 配置信息
        """
        host = cfg.get("host", "127.0.0.1")
        port = cfg.get("port", 1521)
        user = cfg.get("user")
        password = cfg.get("password")
        service_name = cfg.get("name")  # Oracle 对应 service_name
        min_cached = cfg.get("min_cached", 2)
        max_cached = cfg.get("max_cached", 10)

        dsn = cx_Oracle.makedsn(host, port, service_name=service_name)

        self.pool = PooledDB(
            creator=cx_Oracle,
            user=user,
            password=password,
            dsn=dsn,
            mincached=min_cached,
            maxconnections=max_cached,
            autocommit=True,
        )
        self.conn = None

    def connect(self):
        """
        获取数据库连接
        :return: 数据库连接对象
        """
        self.conn = self.pool.connection()
        return self.conn

    def close(self):
        """
        关闭数据库连接
        """
        if self.conn:
            self.conn.close()

    def execute(self, sql, params=None):
        """
        执行SQL语句
        :param sql: SQL语句
        :param params: 参数
        :return: 影响行数
        """
        try:
            with self.pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql, params or {})
                    return cursor.rowcount
        except Exception as e:
            logger.error(f"OracleSync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"OracleSync execute failed: sql={sql}, params={params}, err={e}"
            )

    def fetch_one(self, sql, params=None):
        """
        查询一条记录
        :param sql: SQL语句
        :param params: 参数
        :return: 查询结果
        """
        try:
            with self.pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql, params or {})
                    return cursor.fetchone()
        except Exception as e:
            logger.error(f"OracleSync fetch_one failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"OracleSync fetch_one failed: sql={sql}, params={params}, err={e}"
            )

    def fetch_all(self, sql, params=None):
        """
        查询所有记录
        :param sql: SQL语句
        :param params: 参数
        :return: 查询结果
        """
        try:
            with self.pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql, params or {})
                    return cursor.fetchall()
        except Exception as e:
            logger.error(f"OracleSync fetch_all failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"OracleSync fetch_all failed: sql={sql}, params={params}, err={e}"
            )


class OracleAsync(BaseDBAsync):
    """异步Oracle客户端"""

    def __init__(self, cfg: dict):
        """
        初始化 Oracle 异步客户端
        :param cfg: 配置信息
        """
        host = cfg.get("host", "127.0.0.1")
        port = cfg.get("port", 1521)
        user = cfg.get("user")
        password = cfg.get("password")
        service_name = cfg.get("name")

        self.dsn = f"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST={host})(PORT={port}))" \
                   f"(CONNECT_DATA=(SERVICE_NAME={service_name})))"

        self.db_config = dict(
            user=user,
            password=password,
            dsn=self.dsn,
        )

        self.minsize = cfg.get("min_cached", 2)
        self.maxsize = cfg.get("max_cached", 10)

        self.pool = None

    async def connect(self):
        """连接数据库"""
        if not self.pool:
            self.pool = oracledb.create_pool(
                **self.db_config,
                min=self.minsize,
                max=self.maxsize,
                increment=1,
                threaded=True,
                getmode=oracledb.POOL_GETMODE_WAIT
            )

    async def close(self):
        """关闭数据库连接"""
        if self.pool:
            await self.pool.close()
            self.pool = None

    async def execute(self, sql, params=None):
        """
        执行SQL语句
        :param sql: SQL语句
        :param params: 参数
        :return: 影响行数
        """
        await self.connect()
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(sql, params or {})
                    return cur.rowcount
        except Exception as e:
            logger.error(f"OracleAsync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"OracleAsync execute failed: sql={sql}, params={params}, err={e}"
            )

    async def fetch_one(self, sql, params=None):
        """
        查询一条记录
        :param sql: SQL语句
        :param params: 参数
        :return: 查询结果
        """
        await self.connect()
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(sql, params or {})
                    return await cur.fetchone()
        except Exception as e:
            logger.error(f"OracleAsync fetch_one failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"OracleAsync fetch_one failed: sql={sql}, params={params}, err={e}"
            )

    async def fetch_all(self, sql, params=None):
        """
        查询所有记录
        :param sql: SQL语句
        :param params: 参数
        :return: 查询结果
        """
        await self.connect()
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(sql, params or {})
                    return await cur.fetchall()
        except Exception as e:
            logger.error(f"OracleAsync fetch_all failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"OracleAsync fetch_all failed: sql={sql}, params={params}, err={e}"
            )
