from dbutils.pooled_db import PooledDB
from .db_abstract import BaseDBSync, BaseDBAsync
from himile_log import logger

import aiomysql
import pymysql


class MySQLSync(BaseDBSync):
    """
    同步 MySQL 客户端
    """

    def __init__(self, cfg: dict):
        """
        初始化 MySQL 同步客户端
        :arg cfg: 数据库配置信息
        """
        # 数据库配置信息
        host = cfg.get("host", "127.0.0.1")
        port = cfg.get("port", 3306)
        user = cfg.get("user")
        password = cfg.get("password")
        db = cfg.get("name")
        min_cached = cfg.get("min_cached", 2)
        max_cached = cfg.get("max_cached", 10)

        self.pool = PooledDB(
            creator=pymysql,
            maxconnections=max_cached,
            mincached=min_cached,
            host=host,
            port=port,
            user=user,
            password=password,
            database=db,
            charset="utf8mb4",
            autocommit=True,
        )
        self.conn = None

    def connect(self):
        """
        拿一个连接（供 execute 使用）
        """
        self.conn = self.pool.connection()
        return self.conn

    def close(self):
        """
        关闭当前连接
        """
        if hasattr(self, "conn") and self.conn:
            self.conn.close()

    def execute(self, sql, params=None):
        """
        执行 SQL 语句
        :arg sql: SQL 语句
        :arg params: 参数
        :return: 影响行数
        """
        try:
            with self.pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql, params)
                    return cursor.rowcount
        except Exception as e:
            logger.error(f"MySQLSync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(f"MySQLSync execute failed. SQL={sql}, params={params}, err={e}")

    def fetch_one(self, sql, params=None):
        """
        执行查询，返回一条记录
        :arg sql: SQL 语句
        :arg params: 参数
        :return: 记录
        """
        try:
            with self.pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql, params)
                    return cursor.fetchone()
        except Exception as e:
            logger.error(f"MySQLSync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"MySQLSync fetch_one failed: sql={sql}, params={params}, err={e}"
            )

    def fetch_all(self, sql, params=None):
        """
        执行查询，返回全部记录
        :arg sql: SQL 语句
        :arg params: 参数
        :return: 记录列表
        """
        try:
            with self.pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql, params)
                    return cursor.fetchall()
        except Exception as e:
            logger.error(f"MySQLSync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"MySQLSync fetch_all failed: sql={sql}, params={params}, err={e}"
            )


class MySQLAsync(BaseDBAsync):
    """
    异步 MySQL 客户端
    """

    def __init__(self, cfg: dict):
        """
        初始化 MySQL 异步客户端
        :arg cfg: 数据库配置信息
        """
        # 数据库配置信息
        host = cfg.get("host", "127.0.0.1")
        port = cfg.get("port", 3306)
        user = cfg.get("user")
        password = cfg.get("password")
        db = cfg.get("name")
        min_cached = cfg.get("min_cached", 2)  # 同步 min_cached
        max_cached = cfg.get("max_cached", 10)  # 同步 max_cached

        self.db_config = dict(
            host=host,
            port=port,
            user=user,
            password=password,
            db=db,
            charset="utf8mb4",
        )
        # aiomysql 参数对应 minsize/maxsize
        self.minsize = min_cached
        self.maxsize = max_cached

        self.pool = None

    async def connect(self):
        """拿一个连接（供 execute使用）"""
        if not self.pool:
            self.pool = await aiomysql.create_pool(
                **self.db_config,
                minsize=self.minsize,
                maxsize=self.maxsize,
                autocommit=True
            )

    async def close(self):
        if self.pool:
            self.pool.close()
            await self.pool.wait_closed()
            self.pool = None

    async def execute(self, sql, params=None):
        await self.connect()
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(sql, params)
                    return cur.rowcount

        except Exception as e:
            logger.error(f"MySQLAsync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"MySQLAsync execute failed: sql={sql}, params={params}, err={e}"
            )

    async def fetch_one(self, sql, params=None):
        """
        执行查询，返回一条记录
        :arg sql: SQL 语句
        :arg params: 参数
        :return: 记录
        """
        await self.connect()  # lazy init pool
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(sql, params)
                    return await cur.fetchone()
        except Exception as e:
            logger.error(f"MySQLAsync fetch_one failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"MySQLAsync fetch_one failed: sql={sql}, params={params}, err={e}"
            )

    async def fetch_all(self, sql, params=None):
        """
        执行查询，返回全部记录
        :arg sql: SQL 语句
        :arg params: 参数
        :return: 记录列表
        """
        await self.connect()
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(sql, params)
                    return await cur.fetchall()
        except Exception as e:
            logger.error(f"MySQLAsync fetch_all failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"MySQLAsync fetch_all failed: sql={sql}, params={params}, err={e}"
            )
