import asyncodbc
import pyodbc
from dbutils.pooled_db import PooledDB
from .db_abstract import BaseDBSync, BaseDBAsync
from himile_log import logger


class SQLServerSync(BaseDBSync):
    """
    同步 SQLServer 客户端
    """

    def __init__(self, cfg: dict):
        """
        初始化 SQLServer 同步客户端
        :arg cfg: 数据库配置信息
        """
        host = cfg.get("host")
        port = cfg.get("port", 1433)
        user = cfg.get("user")
        password = cfg.get("password")
        db = cfg.get("name")
        min_cached = cfg.get("min_cached", 2)
        max_cached = cfg.get("max_cached", 10)

        self.pool = PooledDB(
            creator=pyodbc,
            maxconnections=max_cached,
            mincached=min_cached,
            host=host,
            port=port,
            user=user,
            password=password,
            database=db,
            charset="utf8mb4",
            autocommit=True,
        )
        self.conn = None

    def connect(self):
        """
        拿一个连接（供 execute 使用）
        """
        self.conn = self.pool.connection()
        return self.conn

    def close(self):
        """
        关闭当前连接
        """
        if hasattr(self, "conn") and self.conn:
            self.conn.close()

    def execute(self, sql, params=None):
        try:
            with self.pool.connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(sql, params)
                    return cursor.rowcount
        except Exception as e:
            logger.error(f"SQLServerSync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"SQLServerSync execute failed: sql={sql}, params={params}, err={e}"
            )

    def fetch_one(self, sql, params=None):
        try:
            with self.pool.connection() as conn:
                with conn.cursor(as_dict=True) as cursor:
                    cursor.execute(sql, params)
                    return cursor.fetchone()
        except Exception as e:
            logger.error(f"SQLServerSync fetch_one failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"SQLServerSync fetch_one failed: sql={sql}, params={params}, err={e}"
            )

    def fetch_all(self, sql, params=None):
        try:
            with self.pool.connection() as conn:
                with conn.cursor(as_dict=True) as cursor:
                    cursor.execute(sql, params)
                    return cursor.fetchall()
        except Exception as e:
            logger.error(f"SQLServerSync fetch_all failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"SQLServerSync fetch_all failed: sql={sql}, params={params}, err={e}"
            )


class SQLServerAsync(BaseDBAsync):
    """
    异步 SQLServer 客户端
    """

    def __init__(self, cfg: dict):
        host = cfg.get("host")
        port = cfg.get("port", 1433)
        user = cfg.get("user")
        password = cfg.get("password")
        db = cfg.get("name")

        min_cached = cfg.get("min_cached", 2)
        max_cached = cfg.get("max_cached", 10)

        # ODBC 连接字符串
        self.conn_str = (
            "Driver={SQL Server};"
            f"SERVER={host},{port};"
            f"DATABASE={db};"
            f"UID={user};"
            f"PWD={password};"
            f"TrustServerCertificate=yes;"
        )

        self.minsize = min_cached
        self.maxsize = max_cached
        self.pool = None

    async def connect(self):
        if not self.pool:
            self.pool = await asyncodbc.create_pool(
                dsn=self.conn_str,
                minsize=self.minsize,
                maxsize=self.maxsize,
                autocommit=True,
            )

    async def close(self):
        if self.pool:
            self.pool.close()
            await self.pool.wait_closed()
            self.pool = None

    async def execute(self, sql, params=None):
        await self.connect()
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    await cur.execute(sql, params)
                    return cur.rowcount
        except Exception as e:
            logger.error(f"SQLServerAsync execute failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"SQLServerAsync execute failed: sql={sql}, params={params}, err={e}"
            )

    # async def fetch_one(self, sql, params=None):
    #     await self.connect()
    #     try:
    #         async with self.pool.acquire() as conn:
    #             async with conn.cursor() as cur:
    #                 if params is None:
    #                     await cur.execute(sql)
    #                 else:
    #                     await cur.execute(sql, params)
    #                 row = await cur.fetchone()
    #                 return row
    #     except Exception as e:
    #         logger.error(f"SQLServerAsync fetch_one failed. SQL={sql}, params={params}, err={e}")
    #         raise RuntimeError(
    #             f"SQLServerAsync fetch_one failed: sql={sql}, params={params}, err={e}"
    #         )

    async def fetch_one(self, sql, params=None):
        await self.connect()
        conn = None
        try:
            conn = await self.pool.acquire()

            async with conn.cursor() as cur:
                if params:
                    await cur.execute(sql, params)
                else:
                    await cur.execute(sql)

                return await cur.fetchone()

        except Exception as e:
            logger.error(f"SQLServerAsync fetch_one failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"SQLServerAsync fetch_one failed: sql={sql}, params={params}, err={e}"
            )

        finally:
            if conn:
                await self.pool.release(conn)

    async def fetch_all(self, sql, params=None):
        await self.connect()
        try:
            async with self.pool.acquire() as conn:
                async with conn.cursor() as cur:
                    if params is None:
                        await cur.execute(sql)
                    else:
                        await cur.execute(sql, params)
                    headers = [col[0] for col in cur.description] if cur.description else []
                    rows = await cur.fetchall()
                    return headers, rows
        except Exception as e:
            logger.error(f"SQLServerAsync fetch_all failed. SQL={sql}, params={params}, err={e}")
            raise RuntimeError(
                f"SQLServerAsync fetch_all failed: sql={sql}, params={params}, err={e}"
            )
