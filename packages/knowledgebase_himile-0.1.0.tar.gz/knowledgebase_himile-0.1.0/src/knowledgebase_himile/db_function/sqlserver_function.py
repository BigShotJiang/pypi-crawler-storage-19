import datetime
from decimal import Decimal

from ..db.db_abstract import BaseDBAsync
from ..db.database_factory import DatabaseFactory, DatabaseType

from typing import List, Tuple, Callable, Any, Dict, Union
from himile_log import logger


class AsyncSqlserverService:
    """
    异步SQLserver操作类
    """

    def __init__(
            self,
            ss_client: BaseDBAsync = None,
            ss_config: Dict = None
    ):
        """
        初始化ES
        :param ss_client: 已初始化的异步SQLserver客户端（来自工厂类）
        :param ss_config: sqlserver配置字典（优先级低于已传入的ss_client）
                          格式: {"hosts": [...], "user": "...", "password": "..."}
        """
        self.logger = logger
        self.ss_client = ss_client

        # 如果未传入客户端，则通过工厂类创建
        if not self.ss_client:
            self.ss_client = DatabaseFactory.get_database(
                DatabaseType.SQLSERVER_ASYNC,
                ss_config
            )

        if not self.ss_client:
            raise ValueError("必须提供sqlserver_client或sqlserver_config初始化ES客户端")

    async def format_conversion(self, headers, rows) -> Dict[str, Any]:
        """
        处理数据类型并进行格式转化
        Args:
            headers: 查询表头
            rows: 查询数据
        returns:
            result:转化后的数据格式
        """
        processed_data = []
        for row in rows:
            converted_row = []
            for value in row:
                if isinstance(value, (datetime.date, datetime.datetime)):
                    converted_value = value.isoformat()
                elif isinstance(value, Decimal):
                    converted_value = float(value)
                else:
                    converted_value = value
                converted_row.append(converted_value)
            processed_data.append(converted_row)
        # 构建传递数据
        result = {
            "schema": headers,
            "data": processed_data
        }
        return result

    async def get_expert_info(self):
        """
        获取数据库中专家库的数据
        """
        query = """
                        SELECT *
                        FROM [情报管理_专家库]
                        WHERE [guids] IN (
                            SELECT [guids] 
                            FROM [dbo].[情报管理_head]
                            WHERE [状态] IN ('发布', '免审发布')
                            AND [类型] = '专家库'
                        )
                """
        headers, rows = await self.ss_client.fetch_all(query)
        result = await self.format_conversion(headers, rows)
        return result

    async def get_data_classify(self):
        """
        获取情报网中数据分类
        :return:
        """
        query = """
                SELECT DISTINCT 类型
                FROM [情报管理_head]

        """
        headers, rows = await self.ss_client.fetch_all(query)
        result = await self.format_conversion(headers, rows)
        return result

    async def get_table_data(self, table_name, classify):
        """
        获取情报网中任意分类表中的数据
        :param table_name: 表名
        :param classify: 分类
        :return:
        """
        query = f"""
                SELECT *
                FROM {table_name}
                WHERE [guids] IN (
                    SELECT [guids] 
                    FROM [dbo].[情报管理_head]
                    WHERE [状态] IN ('发布', '免审发布')
                    AND [类型] = ?
                )
        """
        headers, rows = await self.ss_client.fetch_all(query, (classify, ))
        result = await self.format_conversion(headers, rows)
        return result

    async def get_data_file(self, classify):
        """
        获取一条数据对应的附件
        :param classify: 分类
        :return:
        """
        query = """
                SELECT did, name, [模块]
                FROM Z_D7
                WHERE [did] IN (
                    SELECT [guids] 
                    FROM [dbo].[情报管理_head]
                    WHERE [状态] IN ('发布', '免审发布')
                    AND [类型] = ?
                )
        """
        headers, rows = await self.ss_client.fetch_all(query, (classify,))
        result = await self.format_conversion(headers, rows)
        return result

    async def get_data_by_guids(self, guid):
        """
        根据guids获取Z_D7
        :param guid:
        :return:
        """
        query = """
                    SELECT did, name, [模块]
                    FROM Z_D7
                    WHERE did = ?
                """
        headers, rows = await self.ss_client.fetch_all(query, (guid,))
        result = await self.format_conversion(headers, rows)
        return result

    async def file_link_element(self):
        """
        获取文件链接的元素
        :return:
        """
        query = """
               SELECT 
                    z.did,
                    z.name,
                    z.模块,
                    q.guids,
                    q.情报标题
               FROM 
                    Z_D7 z
               LEFT JOIN 
                    情报管理_head q ON z.did = q.guids
               WHERE 
                    z.模块 != '标准'   
        """
        headers, rows = await self.ss_client.fetch_all(query)
        result = await self.format_conversion(headers, rows)
        return result