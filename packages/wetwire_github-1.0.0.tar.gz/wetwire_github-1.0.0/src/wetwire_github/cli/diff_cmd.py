"""Diff command implementation.

Per wetwire spec Section 4, the diff command compares generated output
vs existing config in text or semantic mode.
"""

import difflib
from pathlib import Path

from wetwire_github.discover import discover_in_directory
from wetwire_github.runner import extract_workflows
from wetwire_github.serialize import to_yaml
from wetwire_github.testing.semantic_compare import compare_yaml


def _sanitize_filename(name: str) -> str:
    """Convert a workflow name to a safe filename.

    Args:
        name: Workflow name (may contain spaces, special chars)

    Returns:
        Sanitized filename without extension
    """
    result = name.lower()
    result = result.replace(" ", "-")
    result = result.replace("_", "-")
    result = "".join(c for c in result if c.isalnum() or c == "-")
    while "--" in result:
        result = result.replace("--", "-")
    result = result.strip("-")
    return result or "workflow"


def compare_workflows(
    package_path: str,
    output_dir: str,
    output_format: str = "text",
    semantic: bool = False,
) -> tuple[int, str]:
    """Compare Python declarations with generated YAML.

    Args:
        package_path: Path to Python package with workflow declarations.
        output_dir: Path to directory with existing YAML files.
        output_format: Output format ('text' or 'unified').
        semantic: If True, ignore formatting differences.

    Returns:
        Tuple of (exit_code, output_string).
        exit_code is 0 if no differences, 1 if differences found.
    """
    package = Path(package_path)
    output = Path(output_dir)

    if not package.exists():
        return 1, f"Error: Package path does not exist: {package_path}"

    if not output.exists():
        return 1, f"Error: Output directory does not exist: {output_dir}"

    # Discover workflow files using AST
    try:
        discovered = discover_in_directory(str(package))
    except Exception as e:
        return 1, f"Error discovering workflows: {e}"

    workflow_files = {r.file_path for r in discovered if r.type == "Workflow"}

    if not workflow_files:
        return 0, "No workflows found in package."

    # Extract actual workflow objects
    all_workflows = []
    for file_path in workflow_files:
        try:
            extracted = extract_workflows(file_path)
            all_workflows.extend(extracted)
        except Exception as e:
            return 1, f"Error extracting workflows from {file_path}: {e}"

    if not all_workflows:
        return 0, "No workflows could be extracted."

    differences: list[str] = []
    files_checked = 0

    for extracted in all_workflows:
        workflow = extracted.workflow
        name = workflow.name or extracted.name
        safe_name = _sanitize_filename(name)

        # Generate YAML from Python
        try:
            generated_yaml = to_yaml(workflow)
        except Exception as e:
            differences.append(f"Error generating YAML for {name}: {e}")
            continue

        # Find corresponding YAML file
        yaml_path = None
        for ext in [".yaml", ".yml"]:
            candidate = output / f"{safe_name}{ext}"
            if candidate.exists():
                yaml_path = candidate
                break

        if yaml_path is None:
            differences.append(f"Missing YAML file for workflow: {safe_name}")
            continue

        # Read existing YAML
        try:
            existing_yaml = yaml_path.read_text()
        except Exception as e:
            differences.append(f"Error reading {yaml_path}: {e}")
            continue

        files_checked += 1

        if semantic:
            # Semantic comparison - ignores formatting
            diffs = compare_yaml(generated_yaml, existing_yaml)
            if diffs:
                differences.append(f"\n{safe_name}.yaml has semantic differences:")
                for diff in diffs:
                    differences.append(f"  {diff}")
        else:
            # Text comparison
            generated_lines = generated_yaml.splitlines(keepends=True)
            existing_lines = existing_yaml.splitlines(keepends=True)

            if generated_lines != existing_lines:
                if output_format == "unified":
                    diff = difflib.unified_diff(
                        existing_lines,
                        generated_lines,
                        fromfile=f"a/{yaml_path.name}",
                        tofile=f"b/{yaml_path.name}",
                    )
                    differences.append("".join(diff))
                else:
                    # Simple text diff
                    diff = difflib.ndiff(existing_lines, generated_lines)
                    diff_lines = [
                        line for line in diff if line.startswith(("-", "+", "?"))
                    ]
                    if diff_lines:
                        differences.append(f"\n{safe_name}.yaml differs:")
                        differences.extend(diff_lines)

    if not differences:
        return 0, f"No differences found ({files_checked} files checked)."

    return 1, "\n".join(differences)


def diff_files(
    source_yaml: str,
    target_yaml: str,
    semantic: bool = False,
) -> tuple[int, str]:
    """Compare two YAML strings.

    Args:
        source_yaml: Source YAML content.
        target_yaml: Target YAML content.
        semantic: If True, ignore formatting differences.

    Returns:
        Tuple of (exit_code, output_string).
    """
    if semantic:
        diffs = compare_yaml(source_yaml, target_yaml)
        if not diffs:
            return 0, "No differences."
        return 1, "\n".join(str(d) for d in diffs)

    source_lines = source_yaml.splitlines(keepends=True)
    target_lines = target_yaml.splitlines(keepends=True)

    if source_lines == target_lines:
        return 0, "No differences."

    diff = difflib.unified_diff(
        source_lines,
        target_lines,
        fromfile="source",
        tofile="target",
    )
    return 1, "".join(diff)
