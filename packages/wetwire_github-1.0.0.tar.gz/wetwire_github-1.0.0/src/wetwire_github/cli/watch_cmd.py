"""Watch command implementation.

Per wetwire spec Section 4, the watch command monitors source files
and auto-rebuilds on changes.
"""

import signal
import sys
import time
from pathlib import Path
from typing import Any

from wetwire_github.cli.build import build_workflows
from wetwire_github.cli.lint_cmd import lint_package


class WatchHandler:
    """Handles file watching and rebuild triggers."""

    def __init__(
        self,
        package_path: str,
        output_dir: str,
        debounce: int = 1,
        lint_only: bool = False,
    ):
        """Initialize watch handler.

        Args:
            package_path: Path to Python package to watch.
            output_dir: Output directory for generated YAML.
            debounce: Debounce delay in seconds.
            lint_only: If True, only run lint, don't build.
        """
        self.package_path = Path(package_path)
        self.output_dir = output_dir
        self.debounce = debounce
        self.lint_only = lint_only
        self.running = True
        self.last_modified: dict[Path, float] = {}

    def get_python_files(self) -> list[Path]:
        """Get all Python files in the package."""
        return list(self.package_path.rglob("*.py"))

    def check_for_changes(self) -> bool:
        """Check if any files have been modified.

        Returns:
            True if changes detected.
        """
        changed = False
        for py_file in self.get_python_files():
            try:
                mtime = py_file.stat().st_mtime
                if py_file not in self.last_modified:
                    self.last_modified[py_file] = mtime
                elif mtime > self.last_modified[py_file]:
                    self.last_modified[py_file] = mtime
                    changed = True
            except OSError:
                # File might have been deleted
                pass
        return changed

    def run_lint(self) -> tuple[int, str]:
        """Run linter on package."""
        return lint_package(
            package_path=str(self.package_path),
            output_format="text",
            fix=False,
            no_cache=True,
        )

    def run_build(self) -> tuple[int, list[str]]:
        """Run build on package."""
        return build_workflows(
            package_path=str(self.package_path),
            output_dir=self.output_dir,
            output_format="yaml",
            no_cache=True,
        )

    def handle_signal(self, signum: int, frame: Any) -> None:
        """Handle interrupt signal."""
        self.running = False

    def run(self, timeout: int | None = None) -> int:
        """Run the watch loop.

        Args:
            timeout: Optional timeout in seconds.

        Returns:
            Exit code.
        """
        # Set up signal handlers
        signal.signal(signal.SIGINT, self.handle_signal)
        signal.signal(signal.SIGTERM, self.handle_signal)

        print(f"Watching {self.package_path} for changes...")
        print(f"Output: {self.output_dir}")
        print(f"Debounce: {self.debounce}s")
        if self.lint_only:
            print("Mode: lint-only")
        print("Press Ctrl+C to stop.")
        print()

        # Initial build
        if not self.lint_only:
            print("Initial build...")
            exit_code, messages = self.run_build()
            for msg in messages:
                print(f"  {msg}")
            if exit_code != 0:
                print("Initial build failed.", file=sys.stderr)

        # Initialize file tracking
        self.check_for_changes()

        start_time = time.time()

        while self.running:
            if timeout is not None:
                elapsed = time.time() - start_time
                if elapsed >= timeout:
                    print(f"\nTimeout reached ({timeout}s).")
                    break

            time.sleep(self.debounce)

            if self.check_for_changes():
                print(f"\nChange detected at {time.strftime('%H:%M:%S')}")

                # Run lint
                print("  Running lint...")
                lint_code, lint_output = self.run_lint()
                if lint_output:
                    for line in lint_output.split("\n")[:10]:  # Limit output
                        print(f"    {line}")

                if lint_code != 0:
                    print("  Lint failed, skipping build.")
                    continue

                if self.lint_only:
                    print("  Lint passed.")
                    continue

                # Run build
                print("  Running build...")
                build_code, build_messages = self.run_build()
                for msg in build_messages[:5]:  # Limit output
                    print(f"    {msg}")

                if build_code == 0:
                    print("  Build complete.")
                else:
                    print("  Build failed.", file=sys.stderr)

        print("\nWatch stopped.")
        return 0


def watch_package(
    package_path: str,
    output_dir: str,
    debounce: int = 1,
    lint_only: bool = False,
    timeout: int | None = None,
) -> int:
    """Watch a Python package and rebuild on changes.

    Args:
        package_path: Path to Python package to watch.
        output_dir: Output directory for generated YAML.
        debounce: Debounce delay in seconds.
        lint_only: If True, only run lint, don't build.
        timeout: Optional timeout in seconds.

    Returns:
        Exit code.
    """
    package = Path(package_path)

    if not package.exists():
        print(f"Error: Package path does not exist: {package_path}", file=sys.stderr)
        return 1

    if not package.is_dir():
        print(
            f"Error: Package path is not a directory: {package_path}", file=sys.stderr
        )
        return 1

    handler = WatchHandler(
        package_path=package_path,
        output_dir=output_dir,
        debounce=debounce,
        lint_only=lint_only,
    )

    return handler.run(timeout=timeout)
