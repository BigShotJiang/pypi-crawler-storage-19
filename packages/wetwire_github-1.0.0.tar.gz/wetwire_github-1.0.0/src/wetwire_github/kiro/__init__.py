"""Kiro CLI integration for wetwire-github.

This module provides integration with Kiro CLI for AI-assisted
workflow design using the wetwire-github toolchain.

Uses wetwire-core's centralized provider abstraction per spec 3.4.

Usage:
    from wetwire_github.kiro import install_kiro_configs, launch_kiro

    # Install configurations (first run)
    install_kiro_configs()

    # Launch Kiro with wetwire-github-runner agent
    launch_kiro(prompt="Create a CI workflow for Python")
"""

# Re-export check_kiro_installed from core (same interface)
# Re-export core's install_configs for advanced usage
from wetwire_core.kiro import check_kiro_installed, install_configs

# Domain-specific configuration
from wetwire_github.kiro.config import GITHUB_KIRO_CONFIG

# Backwards-compatible wrapper functions (use these for CLI integration)
from wetwire_github.kiro.installer import (
    install_kiro_configs,
    launch_kiro,
    run_kiro_scenario,
)

__all__ = [
    # Core re-exports
    "check_kiro_installed",
    "install_configs",
    # Domain config
    "GITHUB_KIRO_CONFIG",
    # Backwards-compatible wrappers (primary API)
    "install_kiro_configs",
    "launch_kiro",
    "run_kiro_scenario",
]
