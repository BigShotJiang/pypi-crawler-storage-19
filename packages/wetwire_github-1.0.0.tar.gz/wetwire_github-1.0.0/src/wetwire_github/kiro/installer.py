"""Kiro CLI configuration installer.

This module provides backwards-compatible wrapper functions that delegate
to wetwire-core's centralized kiro module.

For new code, prefer using wetwire-core directly:
    from wetwire_core.kiro import install_configs, launch_kiro
    from wetwire_github.kiro.config import GITHUB_KIRO_CONFIG
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Any

from wetwire_core.kiro import check_kiro_installed, generate_agent_config
from wetwire_core.kiro import install_configs as core_install_configs

from wetwire_github.kiro.config import GITHUB_KIRO_CONFIG

# Backwards-compatible: expose AGENT_CONFIG as dict for existing tests
AGENT_CONFIG: dict[str, Any] = {
    "name": GITHUB_KIRO_CONFIG.agent_name,
    "description": "GitHub Actions workflow generator using wetwire-github Python syntax",
    "model": "claude-sonnet-4",
    "tools": ["*"],
    "mcpServers": {},  # Populated dynamically
    "prompt": GITHUB_KIRO_CONFIG.agent_prompt,
}


def get_agent_config_path() -> Path:
    """Get the path to the agent config file.

    Backwards-compatible function that returns the expected path.
    """
    return Path.home() / ".kiro" / "agents" / f"{GITHUB_KIRO_CONFIG.agent_name}.json"


def get_mcp_config_path(project_dir: Path | None = None) -> Path:
    """Get the path to the MCP config file.

    Backwards-compatible function that returns the expected path.
    """
    if project_dir is None:
        project_dir = Path.cwd()
    return project_dir / ".kiro" / "mcp.json"


def install_agent_config(force: bool = False) -> bool:
    """Install the wetwire-github-runner agent config.

    Backwards-compatible wrapper that delegates to wetwire-core.

    Args:
        force: Overwrite existing config if True.

    Returns:
        True if config was installed, False if skipped.
    """
    import json

    config_path = get_agent_config_path()

    if config_path.exists() and not force:
        return False

    # Use core's config generator (returns dict)
    config_dict = generate_agent_config(GITHUB_KIRO_CONFIG)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config_dict, indent=2))
    return True


def install_mcp_config(project_dir: Path | None = None, force: bool = False) -> bool:
    """Install the MCP server config in project directory.

    Backwards-compatible wrapper that delegates to wetwire-core.

    Args:
        project_dir: Project directory. Defaults to current directory.
        force: Overwrite existing config if True.

    Returns:
        True if config was installed, False if skipped.
    """
    import json

    if project_dir is None:
        project_dir = Path.cwd()

    config_path = get_mcp_config_path(project_dir)

    # Load existing config or create new one
    if config_path.exists():
        if not force:
            # Check if wetwire-github-mcp is already configured
            existing = json.loads(config_path.read_text())
            if "wetwire-github-mcp" in existing.get("mcpServers", {}):
                return False
            # Merge with existing
            mcp_config = existing
        else:
            mcp_config = {"mcpServers": {}}
    else:
        mcp_config = {"mcpServers": {}}

    # Add wetwire-github-mcp configuration
    mcp_config["mcpServers"]["wetwire-github-mcp"] = {
        "command": GITHUB_KIRO_CONFIG.mcp_command,
        "args": GITHUB_KIRO_CONFIG.mcp_args,
    }

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(mcp_config, indent=2))
    return True


def install_kiro_configs(
    project_dir: Path | None = None, force: bool = False, verbose: bool = False
) -> dict[str, bool]:
    """Install all Kiro configurations.

    Backwards-compatible wrapper that delegates to wetwire-core.

    Args:
        project_dir: Project directory for MCP config. Defaults to cwd.
        force: Overwrite existing configs if True.
        verbose: Print status messages.

    Returns:
        Dict with 'agent' and 'mcp' keys indicating what was installed.
    """
    # Install using core function - returns (mcp_path, agent_path)
    mcp_path, agent_path = core_install_configs(
        GITHUB_KIRO_CONFIG,
        project_dir=project_dir,
    )

    # Determine what was installed for backwards-compatible return value
    results = {
        "agent": agent_path.exists(),
        "mcp": mcp_path.exists(),
    }

    if verbose:
        if results["agent"]:
            print(f"Installed agent config: {agent_path}", file=sys.stderr)
        if results["mcp"]:
            print(f"Installed MCP config: {mcp_path}", file=sys.stderr)

    return results


def launch_kiro(prompt: str | None = None, project_dir: Path | None = None) -> int:
    """Launch Kiro CLI with the wetwire-github-runner agent.

    Backwards-compatible wrapper. Uses direct subprocess call as
    wetwire-core's kiro-cli command builder has compatibility issues.

    Args:
        prompt: Optional initial prompt for the conversation.
        project_dir: Project directory. Defaults to current directory.

    Returns:
        Exit code from kiro-cli.
    """
    if not check_kiro_installed():
        print(
            "Error: Kiro CLI not found. Install from https://kiro.dev/docs/cli/",
            file=sys.stderr,
        )
        return 1

    # Install configs
    install_kiro_configs(project_dir=project_dir, force=True, verbose=True)

    # Use default prompt if none provided
    if prompt is None:
        prompt = "Hello! I'm ready to design some GitHub Actions workflows."

    # Build command - kiro-cli expects prompt as positional argument
    cmd = [
        "kiro-cli",
        "chat",
        "--agent",
        GITHUB_KIRO_CONFIG.agent_name,
        "--trust-all-tools",
        prompt,
    ]

    # Launch Kiro
    try:
        result = subprocess.run(cmd, cwd=project_dir)
        return result.returncode
    except FileNotFoundError:
        print("Error: Failed to launch kiro-cli.", file=sys.stderr)
        return 1


def run_kiro_scenario(
    prompt: str,
    project_dir: Path | None = None,
    timeout: int = 300,
    auto_exit: bool = True,
) -> dict[str, Any]:
    """Run a Kiro CLI scenario non-interactively for testing.

    Args:
        prompt: The workflow prompt to send to Kiro.
        project_dir: Project directory. Defaults to temp directory.
        timeout: Maximum time in seconds to wait (default: 300).
        auto_exit: If True, append instruction to exit after completion.

    Returns:
        Dict with keys:
            - success: bool - Whether the scenario completed successfully
            - exit_code: int - Process exit code
            - stdout: str - Captured stdout
            - stderr: str - Captured stderr
            - workflow_valid: bool - Whether build produced valid YAML
    """
    import tempfile

    if not check_kiro_installed():
        return {
            "success": False,
            "exit_code": 1,
            "stdout": "",
            "stderr": "Kiro CLI not found",
            "workflow_valid": False,
        }

    # Use temp directory if not specified
    if project_dir is None:
        temp_dir = tempfile.mkdtemp(prefix="kiro_github_test_")
        project_dir = Path(temp_dir)
    else:
        project_dir = Path(project_dir)
        project_dir.mkdir(parents=True, exist_ok=True)

    # Ensure configs are installed
    install_kiro_configs(project_dir=project_dir, verbose=False)

    # Build the full prompt with auto-exit instruction
    full_prompt = prompt
    if auto_exit:
        full_prompt = (
            f"{prompt}\n\n"
            "After successfully creating the workflow and running lint and build, "
            "output 'SCENARIO_COMPLETE' and exit."
        )

    # Build command for non-interactive execution
    # Note: kiro-cli expects prompt as positional argument and uses --no-interactive
    cmd = [
        "kiro-cli",
        "chat",
        "--agent",
        GITHUB_KIRO_CONFIG.agent_name,
        "--no-interactive",
        "--trust-all-tools",
        full_prompt,
    ]

    try:
        result = subprocess.run(
            cmd,
            cwd=project_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        exit_code = result.returncode
        stdout = result.stdout
        stderr = result.stderr
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "exit_code": -1,
            "stdout": "",
            "stderr": f"Timeout after {timeout} seconds",
            "workflow_valid": False,
        }
    except FileNotFoundError:
        return {
            "success": False,
            "exit_code": 1,
            "stdout": "",
            "stderr": "Failed to launch kiro-cli",
            "workflow_valid": False,
        }

    # Check if YAML was generated
    workflow_valid = False
    github_dir = project_dir / ".github" / "workflows"
    if github_dir.exists():
        yaml_files = list(github_dir.glob("*.yml")) + list(github_dir.glob("*.yaml"))
        workflow_valid = len(yaml_files) > 0

    return {
        "success": exit_code == 0 and workflow_valid,
        "exit_code": exit_code,
        "stdout": stdout,
        "stderr": stderr,
        "workflow_valid": workflow_valid,
    }


# Re-export check_kiro_installed for backwards compatibility
__all__ = [
    "AGENT_CONFIG",
    "check_kiro_installed",
    "get_agent_config_path",
    "get_mcp_config_path",
    "install_agent_config",
    "install_mcp_config",
    "install_kiro_configs",
    "launch_kiro",
    "run_kiro_scenario",
]
