"""Persona-based testing for wetwire-core integration.

Provides personas for testing workflow quality from different perspectives.

Uses wetwire-core's centralized Persona dataclass per spec 3.4 and issue #217.

The personas are organized into two categories:

Standard Personas (from wetwire-core):
- beginner: Vague requirements, defers to suggestions
- intermediate: Mixed clarity, asks clarifying questions
- expert: Precise requirements, corrects mistakes
- terse: Minimal responses
- verbose: Over-explains, adds tangents

Domain Personas (GitHub Actions specific):
- reviewer: Code review perspective
- senior-dev: Reliability and performance focus
- security: Supply chain and access control focus
"""

from typing import Any

from wetwire_core.personas import (
    BEGINNER,
    EXPERT,
    INTERMEDIATE,
    TERSE,
    VERBOSE,
    Persona,
)
from wetwire_core.personas import (
    PERSONAS as CORE_PERSONAS,
)

from wetwire_github.core_integration.scoring import score_workflow

# Domain-specific personas using core Persona dataclass
REVIEWER = Persona(
    name="reviewer",
    description="Code reviewer focused on maintainability and best practices",
    system_prompt=(
        "You are a code reviewer evaluating GitHub Actions workflows. "
        "You focus on maintainability, best practices, and reproducibility. "
        "You care about clear naming, pinned action versions, and proper permissions."
    ),
    traits=["thorough", "standards-focused", "detail-oriented"],
)

SENIOR_DEV = Persona(
    name="senior-dev",
    description="Senior developer focused on reliability and performance",
    system_prompt=(
        "You are a senior developer evaluating GitHub Actions workflows. "
        "You focus on reliability, performance, and efficiency. "
        "You care about caching, timeouts, and concurrency control."
    ),
    traits=["experienced", "performance-focused", "reliability-conscious"],
)

SECURITY = Persona(
    name="security",
    description="Security engineer focused on supply chain and access control",
    system_prompt=(
        "You are a security engineer evaluating GitHub Actions workflows. "
        "You focus on supply chain security and least-privilege access. "
        "You care about pinned actions, minimal permissions, and secret handling."
    ),
    traits=["security-conscious", "risk-aware", "protective"],
)

# Domain personas list
DOMAIN_PERSONAS = [REVIEWER, SENIOR_DEV, SECURITY]

# Weight overrides for workflow scoring (domain-specific extension)
# These customize how each persona evaluates workflow quality
DOMAIN_WEIGHT_OVERRIDES: dict[str, dict[str, float]] = {
    "reviewer": {
        "has_name": 1.5,
        "job_naming": 1.5,
        "uses_pinned_actions": 2.0,
        "has_permissions": 2.0,
    },
    "senior-dev": {
        "uses_cache": 2.0,
        "has_timeout": 2.0,
        "has_concurrency": 2.0,
        "uses_checkout": 1.5,
    },
    "security": {
        "has_permissions": 3.0,
        "uses_pinned_actions": 3.0,
    },
    # Standard personas get equal weights (no overrides)
    "beginner": {},
    "intermediate": {},
    "expert": {
        "uses_pinned_actions": 2.5,
        "uses_cache": 2.0,
        "has_concurrency": 2.0,
        "has_permissions": 2.5,
        "has_timeout": 1.5,
    },
    "terse": {},
    "verbose": {},
}


def get_standard_personas() -> list[Persona]:
    """Get the 5 standard personas from wetwire-core.

    Returns:
        List of standard Persona objects
    """
    return [BEGINNER, INTERMEDIATE, EXPERT, TERSE, VERBOSE]


def get_domain_personas() -> list[Persona]:
    """Get domain-specific personas for GitHub Actions.

    Returns:
        List of domain Persona objects
    """
    return DOMAIN_PERSONAS.copy()


def get_all_personas() -> list[Persona]:
    """Get all personas (standard + domain).

    Returns:
        Combined list of all Persona objects
    """
    return get_standard_personas() + get_domain_personas()


def get_available_personas() -> list[dict[str, Any]]:
    """Get list of available testing personas.

    Returns:
        List of persona dictionaries with name, description, and criteria

    Note:
        This is a backwards-compatible function. New code should use
        get_all_personas() which returns Persona objects.
    """
    # Convert Persona objects to dicts for backwards compatibility
    result = []
    for persona in get_all_personas():
        result.append(
            {
                "name": persona.name,
                "description": persona.description,
                "criteria": persona.traits,  # Map traits to criteria
                "weight_overrides": DOMAIN_WEIGHT_OVERRIDES.get(persona.name, {}),
            }
        )
    return result


def get_persona(name: str) -> dict[str, Any] | None:
    """Get a specific persona by name.

    Args:
        name: Persona name

    Returns:
        Persona dictionary or None if not found

    Note:
        This is a backwards-compatible function. New code should use
        get_persona_obj() which returns a Persona object.
    """
    for persona in get_available_personas():
        if persona["name"] == name:
            return persona.copy()
    return None


def get_persona_obj(name: str) -> Persona | None:
    """Get a specific persona by name as Persona object.

    Args:
        name: Persona name

    Returns:
        Persona object or None if not found
    """
    # Check standard personas
    if name in CORE_PERSONAS:
        return CORE_PERSONAS[name]

    # Check domain personas
    for persona in DOMAIN_PERSONAS:
        if persona.name == name:
            return persona

    return None


def run_persona_test(
    persona_name: str,
    workflow_path: str,
    scenario: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run a persona-based test against a workflow.

    Args:
        persona_name: Name of persona to use
        workflow_path: Path to workflow YAML file
        scenario: Optional scenario configuration

    Returns:
        Test result with passed status and feedback
    """
    persona = get_persona(persona_name)
    if persona is None:
        return {
            "passed": False,
            "feedback": f"Unknown persona: {persona_name}",
            "score": 0,
        }

    # Score the workflow (now on 0-15 scale)
    base_score = score_workflow(workflow_path)

    # Apply persona weight overrides
    weighted_score = _apply_persona_weights(base_score, persona)

    # Determine pass/fail based on threshold (0-15 scale, default 6 = Partial pass)
    threshold = scenario.get("threshold", 6) if scenario else 6
    passed = weighted_score["total_score"] >= threshold

    # Generate feedback based on persona perspective
    feedback = _generate_persona_feedback(persona, base_score, weighted_score, passed)

    return {
        "passed": passed,
        "persona": persona_name,
        "score": weighted_score["total_score"],
        "threshold": threshold,
        "feedback": feedback,
        "details": weighted_score.get("details", {}),
    }


def _apply_persona_weights(
    score: dict[str, Any],
    persona: dict[str, Any],
) -> dict[str, Any]:
    """Apply persona-specific weights to scores.

    Args:
        score: Base score from score_workflow
        persona: Persona with weight_overrides

    Returns:
        Weighted score dictionary
    """
    weights = persona.get("weight_overrides", {})
    details = score.get("details", {})
    checks = details.get("checks", [])

    if not checks:
        return score.copy()

    # Apply weights to checks
    weighted_points = 0
    weighted_max = 0

    for check in checks:
        check_name = check.get("name", "")
        weight = weights.get(check_name, 1.0)

        weighted_points += check.get("score", 0) * weight
        weighted_max += check.get("max_score", 0) * weight

    # Calculate score on 0-15 scale
    if weighted_max > 0:
        percentage = weighted_points / weighted_max
        # Map to 0-15 scale
        total_score = round(percentage * 15, 1)
    else:
        total_score = 0

    return {
        "total_score": total_score,
        "weighted_points": round(weighted_points, 1),
        "weighted_max": round(weighted_max, 1),
        "details": details,
        "grade": _get_grade(total_score),
    }


def _get_grade(score: float) -> str:
    """Get letter grade based on score (0-15 scale).

    Args:
        score: Score on 0-15 scale

    Returns:
        Grade string
    """
    if score >= 13:
        return "Excellent"
    elif score >= 10:
        return "Success"
    elif score >= 6:
        return "Partial"
    else:
        return "Failure"


def _generate_persona_feedback(
    persona: dict[str, Any],
    base_score: dict[str, Any],
    weighted_score: dict[str, Any],
    passed: bool,
) -> str:
    """Generate feedback from persona's perspective.

    Args:
        persona: Persona dictionary
        base_score: Original score
        weighted_score: Persona-weighted score
        passed: Whether the test passed

    Returns:
        Feedback string
    """
    persona_name = persona["name"]
    score = weighted_score["total_score"]
    grade = weighted_score.get("grade", _get_grade(score))

    if passed:
        intro = f"As a {persona_name}, this workflow meets my standards."
    else:
        intro = f"As a {persona_name}, this workflow needs improvement."

    # Find failed checks
    details = base_score.get("details", {})
    checks = details.get("checks", [])
    failed_checks = [c for c in checks if not c.get("passed", True)]

    feedback_lines = [intro, f"Score: {score}/15 ({grade})", ""]

    if failed_checks:
        feedback_lines.append("Issues to address:")
        for check in failed_checks:
            desc = check.get("description", check.get("name", "unknown"))
            feedback_lines.append(f"  - {desc}")

    # Add persona-specific advice
    weights = persona.get("weight_overrides", {})
    priority_checks = [c for c in failed_checks if c.get("name") in weights]

    if priority_checks:
        feedback_lines.append("")
        feedback_lines.append("Priority improvements for this persona:")
        for check in priority_checks:
            desc = check.get("description", check.get("name", "unknown"))
            feedback_lines.append(f"  * {desc}")

    return "\n".join(feedback_lines)


def run_all_persona_tests(
    workflow_path: str,
    scenario: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run all persona tests against a workflow.

    Args:
        workflow_path: Path to workflow YAML file
        scenario: Optional scenario configuration

    Returns:
        Combined test results from all personas
    """
    all_personas = get_all_personas()
    results: dict[str, dict[str, Any]] = {}
    all_passed = True

    for persona in all_personas:
        persona_name = persona.name
        result = run_persona_test(persona_name, workflow_path, scenario)
        results[persona_name] = result
        if not result["passed"]:
            all_passed = False

    return {
        "all_passed": all_passed,
        "results": results,
        "personas_passed": sum(1 for r in results.values() if r["passed"]),
        "personas_total": len(all_personas),
    }
