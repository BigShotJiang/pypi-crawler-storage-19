"""Semantic comparison for round-trip testing.

Per wetwire spec v1.1 section 11.2.1, round-trip tests SHOULD use semantic
comparison that ignores formatting differences:
- Whitespace and indentation differences
- Key ordering in maps/objects
- Quote style variations

This module provides recursive structure comparison with path reporting.
"""

from dataclasses import dataclass
from typing import Any

import yaml


@dataclass
class Difference:
    """Represents a difference between two structures.

    Attributes:
        path: Dot-separated path to the difference (e.g., 'jobs.build.steps[0]')
        left: Value in the left (expected) structure
        right: Value in the right (actual) structure
    """

    path: str
    left: Any
    right: Any

    def __str__(self) -> str:
        """Return human-readable difference description."""
        if self.left is None:
            return f"{self.path}: missing in left, found {self.right!r} in right"
        elif self.right is None:
            return f"{self.path}: found {self.left!r} in left, missing in right"
        else:
            return f"{self.path}: {self.left!r} != {self.right!r}"

    def __repr__(self) -> str:
        """Return debug representation."""
        return (
            f"Difference(path={self.path!r}, left={self.left!r}, right={self.right!r})"
        )


def compare(left: Any, right: Any, path: str = "") -> list[Difference]:
    """Compare two structures semantically.

    Compares structures recursively, ignoring:
    - Key ordering in dictionaries
    - Type differences that are semantically equivalent

    Args:
        left: Expected structure
        right: Actual structure
        path: Current path (for recursive calls)

    Returns:
        List of differences found, empty if structures are semantically equal.
    """
    differences: list[Difference] = []

    # Handle None cases
    if left is None and right is None:
        return []
    if left is None:
        return [Difference(path=path or "root", left=None, right=right)]
    if right is None:
        return [Difference(path=path or "root", left=left, right=None)]

    # Different types (but both non-None)
    if type(left) is not type(right):
        return [Difference(path=path or "root", left=left, right=right)]

    # Compare dictionaries
    if isinstance(left, dict):
        all_keys = set(left.keys()) | set(right.keys())

        for key in all_keys:
            key_path = f"{path}.{key}" if path else key

            if key not in left:
                differences.append(
                    Difference(path=key_path, left=None, right=right[key])
                )
            elif key not in right:
                differences.append(
                    Difference(path=key_path, left=left[key], right=None)
                )
            else:
                differences.extend(compare(left[key], right[key], key_path))

        return differences

    # Compare lists
    if isinstance(left, list):
        max_len = max(len(left), len(right))

        for i in range(max_len):
            item_path = f"{path}[{i}]" if path else f"[{i}]"

            if i >= len(left):
                differences.append(
                    Difference(path=item_path, left=None, right=right[i])
                )
            elif i >= len(right):
                differences.append(Difference(path=item_path, left=left[i], right=None))
            else:
                differences.extend(compare(left[i], right[i], item_path))

        return differences

    # Compare scalar values
    if left != right:
        return [Difference(path=path or "root", left=left, right=right)]

    return []


def compare_yaml(left_yaml: str, right_yaml: str) -> list[Difference]:
    """Compare two YAML strings semantically.

    Parses both YAML strings and compares the resulting structures.
    This ignores formatting differences like whitespace, indentation,
    key ordering, and quote styles.

    Args:
        left_yaml: Expected YAML string
        right_yaml: Actual YAML string

    Returns:
        List of differences found, empty if YAMLs are semantically equal.
    """
    left_data = yaml.safe_load(left_yaml)
    right_data = yaml.safe_load(right_yaml)

    return compare(left_data, right_data)
