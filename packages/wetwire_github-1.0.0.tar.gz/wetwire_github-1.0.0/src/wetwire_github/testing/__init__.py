"""Testing utilities for wetwire-github.

Per wetwire spec v1.1 section 11.2.1, round-trip tests SHOULD use semantic
comparison that ignores formatting differences.
"""

from wetwire_github.testing.semantic_compare import (
    Difference,
    compare,
    compare_yaml,
)

__all__ = [
    "Difference",
    "compare",
    "compare_yaml",
]
