"""Tests for the diff command.

Per wetwire spec Section 4, the diff command compares generated output
vs existing config in text or semantic mode.
"""

import subprocess
import sys


class TestDiffCommand:
    """Tests for wetwire-github diff command."""

    def test_diff_help_shows_usage(self):
        """Diff command should show help text."""
        result = subprocess.run(
            [sys.executable, "-m", "wetwire_github.cli", "diff", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "diff" in result.stdout.lower() or "compare" in result.stdout.lower()

    def test_diff_no_changes(self, tmp_path):
        """Diff should report no changes when output matches."""
        # Create a simple workflow
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "ci.py"
        workflow_py.write_text(
            '''"""CI workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

ci = Workflow(
    name="CI",
    on=Triggers(push=PushTrigger(branches=["main"])),
    jobs={
        "test": Job(
            runs_on="ubuntu-latest",
            steps=[Step(run="echo hello")],
        ),
    },
)
'''
        )

        # Build the workflow first
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        build_result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "build",
                "-o",
                str(output_dir),
                str(workflows_dir),
            ],
            capture_output=True,
            text=True,
        )
        assert build_result.returncode == 0

        # Run diff - should show no changes
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "diff",
                str(workflows_dir),
                "--output",
                str(output_dir),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "no differences" in result.stdout.lower() or result.stdout.strip() == ""

    def test_diff_detects_changes(self, tmp_path):
        """Diff should detect when source and output differ."""
        # Create a workflow
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "ci.py"
        workflow_py.write_text(
            '''"""CI workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

ci = Workflow(
    name="CI",
    on=Triggers(push=PushTrigger(branches=["main"])),
    jobs={
        "test": Job(
            runs_on="ubuntu-latest",
            steps=[Step(run="echo hello")],
        ),
    },
)
'''
        )

        # Create a different YAML manually
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        yaml_file = output_dir / "ci.yaml"
        yaml_file.write_text(
            """name: CI
on:
  push:
    branches: ["main"]
jobs:
  test:
    runs-on: ubuntu-22.04  # Different runner
    steps:
      - run: echo hello
"""
        )

        # Run diff - should detect difference
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "diff",
                str(workflows_dir),
                "--output",
                str(output_dir),
            ],
            capture_output=True,
            text=True,
        )

        # Should indicate differences exist
        assert (
            result.returncode != 0
            or "differs" in result.stdout.lower()
            or "-" in result.stdout
            or "+" in result.stdout
        )

    def test_diff_semantic_mode(self, tmp_path):
        """Diff with --semantic should ignore formatting differences."""
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "ci.py"
        workflow_py.write_text(
            '''"""CI workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

ci = Workflow(
    name="CI",
    on=Triggers(push=PushTrigger(branches=["main"])),
    jobs={
        "test": Job(
            runs_on="ubuntu-latest",
            steps=[Step(run="echo test")],
        ),
    },
)
'''
        )

        # Create YAML with different formatting but same content
        output_dir = tmp_path / "output"
        output_dir.mkdir()

        yaml_file = output_dir / "ci.yaml"
        yaml_file.write_text(
            """name: CI
"on":
  push:
    branches:
      - "main"
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - run: echo test
"""
        )

        # Semantic diff should show no differences
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "diff",
                str(workflows_dir),
                "--output",
                str(output_dir),
                "--semantic",
            ],
            capture_output=True,
            text=True,
        )

        assert result.returncode == 0


class TestDiffOutput:
    """Tests for diff output formats."""

    def test_diff_text_format(self, tmp_path):
        """Diff should support text output format."""
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "test.py"
        workflow_py.write_text(
            '''"""Test workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

test = Workflow(
    name="Test",
    on=Triggers(push=PushTrigger()),
    jobs={"build": Job(runs_on="ubuntu-latest", steps=[Step(run="make")])},
)
'''
        )

        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Build first
        subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "build",
                "-o",
                str(output_dir),
                str(workflows_dir),
            ],
            capture_output=True,
        )

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "diff",
                str(workflows_dir),
                "--output",
                str(output_dir),
                "--format",
                "text",
            ],
            capture_output=True,
            text=True,
        )

        assert result.returncode == 0
