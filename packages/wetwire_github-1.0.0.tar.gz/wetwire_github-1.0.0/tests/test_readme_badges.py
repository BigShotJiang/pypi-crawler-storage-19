"""Tests for README badges per WETWIRE_SPEC.md Section 12.4."""

from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).parent.parent
README_PATH = PROJECT_ROOT / "README.md"


class TestReadmeBadges:
    """Verify README contains required badges."""

    @pytest.fixture
    def readme_content(self) -> str:
        """Load README content."""
        return README_PATH.read_text()

    def test_readme_has_ci_badge(self, readme_content: str) -> None:
        """README should have CI status badge."""
        assert "actions/workflows/ci.yml/badge.svg" in readme_content
        assert "[![CI]" in readme_content

    def test_readme_has_pypi_badge(self, readme_content: str) -> None:
        """README should have PyPI version badge."""
        assert "img.shields.io/pypi/v/wetwire-github" in readme_content
        assert "[![PyPI]" in readme_content

    def test_readme_has_python_version_badge(self, readme_content: str) -> None:
        """README should have Python version badge."""
        assert "python-3.11" in readme_content or "python--3.11" in readme_content
        assert "[![Python]" in readme_content

    def test_readme_has_license_badge(self, readme_content: str) -> None:
        """README should have license badge."""
        assert "license-MIT" in readme_content or "license--MIT" in readme_content
        assert "[![License]" in readme_content

    def test_badges_are_at_top(self, readme_content: str) -> None:
        """Badges should appear before main content."""
        lines = readme_content.split("\n")
        # Find first badge line
        badge_line_idx = None
        for i, line in enumerate(lines):
            if "[![" in line and "badge" in line.lower():
                badge_line_idx = i
                break

        assert badge_line_idx is not None, "No badge found in README"
        # Badges should be in the first 10 lines (after title)
        assert badge_line_idx < 10, f"Badges at line {badge_line_idx}, expected in first 10 lines"

    def test_badges_in_correct_order(self, readme_content: str) -> None:
        """Badges should be in order: CI, PyPI, Python, License."""
        ci_pos = readme_content.find("[![CI]")
        pypi_pos = readme_content.find("[![PyPI]")
        python_pos = readme_content.find("[![Python]")
        license_pos = readme_content.find("[![License]")

        positions = [ci_pos, pypi_pos, python_pos, license_pos]
        assert all(p >= 0 for p in positions), "Not all badges found"
        assert positions == sorted(positions), "Badges not in correct order: CI, PyPI, Python, License"
