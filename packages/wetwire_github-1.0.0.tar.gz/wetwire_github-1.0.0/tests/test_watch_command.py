"""Tests for the watch command.

Per wetwire spec Section 4, the watch command monitors source files
and auto-rebuilds on changes.
"""

import subprocess
import sys


class TestWatchCommand:
    """Tests for wetwire-github watch command."""

    def test_watch_help_shows_usage(self):
        """Watch command should show help text."""
        result = subprocess.run(
            [sys.executable, "-m", "wetwire_github.cli", "watch", "--help"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0
        assert "watch" in result.stdout.lower()

    def test_watch_lint_only_mode(self, tmp_path):
        """Watch with --lint-only should not rebuild."""
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "ci.py"
        workflow_py.write_text(
            '''"""CI workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

ci = Workflow(
    name="CI",
    on=Triggers(push=PushTrigger()),
    jobs={"test": Job(runs_on="ubuntu-latest", steps=[Step(run="echo test")])},
)
'''
        )

        # Run watch with --lint-only for a brief moment
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "watch",
                str(workflows_dir),
                "--lint-only",
                "--timeout",
                "1",  # Exit after 1 second
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should exit cleanly
        assert result.returncode in [0, 130]  # 130 = timeout/interrupt

    def test_watch_debounce_option(self, tmp_path):
        """Watch should accept debounce option."""
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "ci.py"
        workflow_py.write_text(
            '''"""CI workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

ci = Workflow(
    name="CI",
    on=Triggers(push=PushTrigger()),
    jobs={"test": Job(runs_on="ubuntu-latest", steps=[Step(run="echo test")])},
)
'''
        )

        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Run watch with debounce
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "watch",
                str(workflows_dir),
                "--output",
                str(output_dir),
                "--debounce",
                "2",
                "--timeout",
                "1",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should exit cleanly
        assert result.returncode in [0, 130]


class TestWatchBehavior:
    """Tests for watch command behavior."""

    def test_watch_initial_build(self, tmp_path):
        """Watch should perform initial build on start."""
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "ci.py"
        workflow_py.write_text(
            '''"""CI workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

ci = Workflow(
    name="CI",
    on=Triggers(push=PushTrigger()),
    jobs={"test": Job(runs_on="ubuntu-latest", steps=[Step(run="echo test")])},
)
'''
        )

        output_dir = tmp_path / "output"
        output_dir.mkdir()

        # Run watch briefly
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "watch",
                str(workflows_dir),
                "--output",
                str(output_dir),
                "--timeout",
                "2",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should have generated output
        yaml_files = list(output_dir.glob("*.yaml")) + list(output_dir.glob("*.yml"))
        assert (
            len(yaml_files) > 0
            or "build" in result.stdout.lower()
            or "generated" in result.stdout.lower()
        )

    def test_watch_reports_status(self, tmp_path):
        """Watch should report its status."""
        workflows_dir = tmp_path / "workflows"
        workflows_dir.mkdir()

        workflow_py = workflows_dir / "ci.py"
        workflow_py.write_text(
            '''"""CI workflow."""
from wetwire_github.workflow import Workflow, Job, Step, Triggers, PushTrigger

ci = Workflow(
    name="CI",
    on=Triggers(push=PushTrigger()),
    jobs={"test": Job(runs_on="ubuntu-latest", steps=[Step(run="test")])},
)
'''
        )

        output_dir = tmp_path / "output"
        output_dir.mkdir()

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "wetwire_github.cli",
                "watch",
                str(workflows_dir),
                "--output",
                str(output_dir),
                "--timeout",
                "1",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )

        # Should report watching status
        combined_output = result.stdout + result.stderr
        assert (
            "watch" in combined_output.lower()
            or "monitor" in combined_output.lower()
            or result.returncode in [0, 130]
        )
