"""Tests for semantic comparison module.

Per wetwire spec v1.1 section 11.2.1, round-trip tests SHOULD use semantic
comparison that ignores formatting differences.
"""

from wetwire_github.testing.semantic_compare import (
    Difference,
    compare,
    compare_yaml,
)


class TestSemanticCompare:
    """Test semantic comparison functionality."""

    def test_identical_dicts_are_equal(self):
        """Identical dictionaries should have no differences."""
        a = {"name": "test", "jobs": {"build": {"runs-on": "ubuntu-latest"}}}
        b = {"name": "test", "jobs": {"build": {"runs-on": "ubuntu-latest"}}}

        diffs = compare(a, b)
        assert diffs == []

    def test_key_ordering_ignored(self):
        """Different key ordering should not produce differences."""
        a = {"name": "test", "jobs": {}}
        b = {"jobs": {}, "name": "test"}

        diffs = compare(a, b)
        assert diffs == []

    def test_nested_key_ordering_ignored(self):
        """Different key ordering in nested dicts should not produce differences."""
        a = {"jobs": {"build": {"runs-on": "ubuntu", "steps": []}}}
        b = {"jobs": {"build": {"steps": [], "runs-on": "ubuntu"}}}

        diffs = compare(a, b)
        assert diffs == []

    def test_value_difference_detected(self):
        """Different values should produce differences."""
        a = {"name": "test-a"}
        b = {"name": "test-b"}

        diffs = compare(a, b)
        assert len(diffs) == 1
        assert diffs[0].path == "name"
        assert diffs[0].left == "test-a"
        assert diffs[0].right == "test-b"

    def test_nested_value_difference_path(self):
        """Nested differences should have full paths."""
        a = {"jobs": {"build": {"runs-on": "ubuntu-latest"}}}
        b = {"jobs": {"build": {"runs-on": "ubuntu-22.04"}}}

        diffs = compare(a, b)
        assert len(diffs) == 1
        assert diffs[0].path == "jobs.build.runs-on"

    def test_list_differences_with_index(self):
        """List differences should include index in path."""
        a = {"steps": [{"name": "a"}, {"name": "b"}]}
        b = {"steps": [{"name": "a"}, {"name": "c"}]}

        diffs = compare(a, b)
        assert len(diffs) == 1
        assert diffs[0].path == "steps[1].name"

    def test_missing_key_detected(self):
        """Missing keys should be detected."""
        a = {"name": "test", "on": "push"}
        b = {"name": "test"}

        diffs = compare(a, b)
        assert len(diffs) == 1
        assert diffs[0].path == "on"
        assert diffs[0].left == "push"
        assert diffs[0].right is None

    def test_extra_key_detected(self):
        """Extra keys should be detected."""
        a = {"name": "test"}
        b = {"name": "test", "on": "push"}

        diffs = compare(a, b)
        assert len(diffs) == 1
        assert diffs[0].path == "on"
        assert diffs[0].left is None
        assert diffs[0].right == "push"

    def test_list_length_difference(self):
        """Different list lengths should be detected."""
        a = {"steps": [{"name": "a"}, {"name": "b"}]}
        b = {"steps": [{"name": "a"}]}

        diffs = compare(a, b)
        assert len(diffs) >= 1
        # Should detect that steps[1] is missing

    def test_type_difference_detected(self):
        """Different types should be detected."""
        a = {"value": "123"}
        b = {"value": 123}

        diffs = compare(a, b)
        assert len(diffs) == 1
        assert diffs[0].path == "value"

    def test_empty_structures_equal(self):
        """Empty structures should be equal."""
        assert compare({}, {}) == []
        assert compare([], []) == []

    def test_none_values_compared(self):
        """None values should be compared correctly."""
        a = {"value": None}
        b = {"value": None}
        assert compare(a, b) == []

        c = {"value": None}
        d = {"value": "test"}
        diffs = compare(c, d)
        assert len(diffs) == 1

    def test_boolean_values_compared(self):
        """Boolean values should be compared correctly."""
        a = {"enabled": True}
        b = {"enabled": False}

        diffs = compare(a, b)
        assert len(diffs) == 1
        assert diffs[0].path == "enabled"


class TestYamlComparison:
    """Test YAML string comparison."""

    def test_yaml_strings_compared(self):
        """YAML strings should be parsed and compared."""
        yaml_a = """
name: test
jobs:
  build:
    runs-on: ubuntu-latest
"""
        yaml_b = """
name: test
jobs:
  build:
    runs-on: ubuntu-latest
"""
        diffs = compare_yaml(yaml_a, yaml_b)
        assert diffs == []

    def test_yaml_whitespace_ignored(self):
        """Different whitespace/indentation should not matter."""
        yaml_a = """
name: test
jobs:
  build:
    runs-on: ubuntu-latest
"""
        yaml_b = """
name:   test
jobs:
  build:
    runs-on:    ubuntu-latest
"""
        diffs = compare_yaml(yaml_a, yaml_b)
        assert diffs == []

    def test_yaml_key_ordering_ignored(self):
        """Different key ordering in YAML should not matter."""
        yaml_a = """
name: test
on: push
"""
        yaml_b = """
on: push
name: test
"""
        diffs = compare_yaml(yaml_a, yaml_b)
        assert diffs == []


class TestDifferenceReporting:
    """Test difference object formatting."""

    def test_difference_str_format(self):
        """Difference should have readable string format."""
        diff = Difference(
            path="jobs.build.runs-on",
            left="ubuntu-latest",
            right="ubuntu-22.04",
        )

        s = str(diff)
        assert "jobs.build.runs-on" in s
        assert "ubuntu-latest" in s or "ubuntu-22.04" in s

    def test_difference_repr(self):
        """Difference should have useful repr."""
        diff = Difference(
            path="name",
            left="a",
            right="b",
        )

        r = repr(diff)
        assert "Difference" in r
        assert "name" in r


class TestComplexWorkflows:
    """Test with realistic workflow structures."""

    def test_complex_workflow_identical(self):
        """Complex identical workflows should have no differences."""
        workflow = {
            "name": "CI",
            "on": {
                "push": {"branches": ["main"]},
                "pull_request": {"branches": ["main"]},
            },
            "permissions": {"contents": "read"},
            "jobs": {
                "build": {
                    "runs-on": "ubuntu-latest",
                    "steps": [
                        {"uses": "actions/checkout@v4"},
                        {"name": "Setup", "run": "npm install"},
                        {"name": "Test", "run": "npm test"},
                    ],
                },
                "deploy": {
                    "needs": ["build"],
                    "runs-on": "ubuntu-latest",
                    "steps": [{"run": "deploy.sh"}],
                },
            },
        }

        diffs = compare(workflow, workflow.copy())
        assert diffs == []

    def test_complex_workflow_step_difference(self):
        """Detect step differences in complex workflows."""
        workflow_a = {
            "name": "CI",
            "jobs": {
                "build": {
                    "steps": [
                        {"uses": "actions/checkout@v4"},
                        {"run": "npm install"},
                    ],
                },
            },
        }
        workflow_b = {
            "name": "CI",
            "jobs": {
                "build": {
                    "steps": [
                        {"uses": "actions/checkout@v4"},
                        {"run": "npm ci"},  # Different
                    ],
                },
            },
        }

        diffs = compare(workflow_a, workflow_b)
        assert len(diffs) == 1
        assert "steps[1].run" in diffs[0].path
