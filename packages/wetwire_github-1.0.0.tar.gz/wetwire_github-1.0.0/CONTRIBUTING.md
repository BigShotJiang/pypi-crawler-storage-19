# Contributing to wetwire-github

Thank you for your interest in contributing to wetwire-github! This guide will help you get started.

## Development Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/lex00/wetwire-github-python.git
   cd wetwire-github-python
   ```

2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   pip install -e ".[dev]"
   ```

   Or using uv:
   ```bash
   uv sync --all-extras
   ```

3. Verify installation:
   ```bash
   pytest
   wetwire-github --help
   ```

## Code Style

- Follow [PEP 8](https://pep8.org/) style guidelines
- Use type hints for all function signatures
- Maximum line length: 88 characters (configured in ruff)
- Use double quotes for strings

### Linting and Formatting

Run linting before committing:
```bash
ruff check src/ tests/
ruff format src/ tests/
```

Run type checking:
```bash
ty check src/
```

## Testing

Run the test suite:
```bash
pytest
```

Run with coverage:
```bash
pytest --cov=wetwire_github --cov-report=term-missing
```

Run a specific test:
```bash
pytest tests/test_workflow.py::TestWorkflow::test_workflow_creation
```

## Pull Request Process

1. **Create a feature branch:**
   ```bash
   git checkout -b feat/your-feature-name
   ```

2. **Make your changes:**
   - Write tests for new functionality
   - Update documentation if needed
   - Follow the code style guidelines

3. **Run checks locally:**
   ```bash
   ruff check src/ tests/
   ruff format --check src/ tests/
   pytest
   ```

4. **Commit with a descriptive message:**
   ```bash
   git commit -m "feat: Add new feature description"
   ```

   Follow [Conventional Commits](https://www.conventionalcommits.org/) format:
   - `feat:` New feature
   - `fix:` Bug fix
   - `docs:` Documentation changes
   - `refactor:` Code refactoring
   - `test:` Test additions/changes
   - `chore:` Maintenance tasks

5. **Push and create a PR:**
   ```bash
   git push -u origin feat/your-feature-name
   ```

   Then open a pull request on GitHub with:
   - Clear description of changes
   - Link to related issue (if any)
   - Test plan or verification steps

6. **Wait for CI to pass** and address any review feedback.

## Project Structure

```
wetwire-github-python/
├── src/wetwire_github/
│   ├── workflow/          # Core workflow types
│   ├── actions/           # Typed action wrappers
│   ├── cli/               # CLI commands
│   ├── linter/            # Lint rules (WAG001-WAG016)
│   ├── serialize/         # Python to YAML conversion
│   └── ...
├── tests/                 # Test suite
├── docs/                  # Documentation
└── examples/              # Example workflows
```

## Adding New Features

### Adding a New Action Wrapper

1. Create wrapper in `src/wetwire_github/actions/`
2. Add tests in `tests/test_actions/`
3. Export from `src/wetwire_github/actions/__init__.py`

### Adding a New Lint Rule

1. Create rule in `src/wetwire_github/linter/rules/`
2. Register in `src/wetwire_github/linter/rules/__init__.py`
3. Add tests in `tests/test_linter.py`
4. Document in `docs/LINT_RULES.md`

## Questions?

- Open an [issue](https://github.com/lex00/wetwire-github-python/issues) for discussion
- Check existing issues for similar questions
