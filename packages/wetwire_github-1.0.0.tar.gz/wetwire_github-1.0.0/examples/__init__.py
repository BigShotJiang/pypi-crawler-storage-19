"""Examples for wetwire-github."""
