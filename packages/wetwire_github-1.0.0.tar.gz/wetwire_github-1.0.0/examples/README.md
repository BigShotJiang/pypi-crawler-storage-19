# Examples

This directory contains example workflows and configurations for wetwire-github.

## Hand-Written Examples

| File | Description |
|------|-------------|
| `attestation_example.py` | Artifact attestation workflow patterns |
| `branch_protection_example.py` | Branch protection rules configuration |
| `composite_action_example.py` | Composite action patterns |
| `repository_settings_example.py` | Repository settings configuration |
| `secret_scanning_example.py` | Secret scanning configuration |

## Imported Starter Workflows

The `github-starter-workflows/` directory contains workflows imported from GitHub's official starter-workflows repository for round-trip testing.

| Directory | Source | License |
|-----------|--------|---------|
| `github-starter-workflows/` | [actions/starter-workflows](https://github.com/actions/starter-workflows) | MIT |

**Import date:** 2025-01-09

### Included Workflows

| File | Language/Platform |
|------|-------------------|
| `android.yml` | Android |
| `blank.yml` | Blank template |
| `cmake-single-platform.yml` | CMake |
| `deno.yml` | Deno |
| `django.yml` | Django (Python) |
| `docker-image.yml` | Docker |
| `dotnet.yml` | .NET |
| `elixir.yml` | Elixir |
| `go.yml` | Go |
| `gradle.yml` | Gradle (Java) |
| `ios.yml` | iOS/Swift |
| `makefile.yml` | Makefile |
| `maven.yml` | Maven (Java) |
| `node.js.yml` | Node.js |
| `php.yml` | PHP |
| `python-package.yml` | Python |
| `python-publish.yml` | Python (PyPI publish) |
| `ruby.yml` | Ruby |
| `rust.yml` | Rust |
| `scala.yml` | Scala |
| `swift.yml` | Swift |

These workflows are used for:
- Round-trip testing (YAML -> Python -> YAML)
- Validating the importer's ability to handle real-world workflows
- Ensuring compatibility with GitHub Actions standards

## License

The hand-written examples in this directory are part of wetwire-github and follow the project's license.

The imported starter workflows in `github-starter-workflows/` are from [actions/starter-workflows](https://github.com/actions/starter-workflows) and are licensed under the MIT License:

```
MIT License

Copyright (c) GitHub, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
