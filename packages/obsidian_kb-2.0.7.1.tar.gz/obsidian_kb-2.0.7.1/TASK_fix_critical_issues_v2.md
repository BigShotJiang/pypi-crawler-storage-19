# Задача: Исправление критических проблем obsidian-kb v2.0

## Контекст

Проведено полное тестирование инструментов obsidian-kb на vault "Naumen_CTO". Выявлены критические проблемы, блокирующие продуктивное использование системы.

---

## 🚨 Проблема 0: Рассинхронизация LanceDB ↔ Documents (БЛОКЕР)

### Симптомы

При поиске `"Кардашин"` получаем **71 warning** вида:
```
WARNING - Document Naumen_CTO::07_PEOPLE/nkardashin/nkardashin.md not found, skipping
WARNING - Document Naumen_CTO::07_PEOPLE/vshadrin/vshadrin.md not found, skipping
WARNING - Document Naumen_CTO::06_CURRENT/projects/psb/memos/2025-12-05_shtab.md not found, skipping
... (ещё 68 документов)
```

**Результат:** из ~71 релевантных чанков в LanceDB только **3 документа** вернулись пользователю, причём с **релевантностью 0.00**.

### Масштаб проблемы

- **71 документ** не найден за один запрос
- Затронуты ВСЕ ключевые директории: `07_PEOPLE/`, `06_CURRENT/`, `08_COMMITTEES/`, `01_CONTEXT/`, `02_TECHNOLOGY/`, `04_TEMPLATES/`
- Профиль `nkardashin/nkardashin.md` (целевой результат поиска) — **не возвращается**

### Root Cause гипотезы

1. **Dual-write сломан**: чанки пишутся в LanceDB, но документы не пишутся в SQLite
2. **Индекс устарел**: файлы переименованы/перемещены после индексации
3. **Путь не совпадает**: в LanceDB хранится `07_PEOPLE/vshadrin/vshadrin.md`, а в SQLite `07_PEOPLE/vshadrin.md` (без вложенной папки)
4. **Change detection не сработал**: incremental indexer не обнаружил изменения структуры

### Влияние

**🔴 КРИТИЧЕСКОЕ / БЛОКЕР** — поиск фактически неработоспособен. ~95% релевантных результатов теряется.

### Требуемая диагностика

```bash
# 1. Проверить количество документов в SQLite vs LanceDB
sqlite3 ~/.obsidian-kb/lancedb/metadata.db "SELECT COUNT(*) FROM documents WHERE vault_id = 'Naumen_CTO'"

# 2. Проверить, есть ли конкретный документ в SQLite
sqlite3 ~/.obsidian-kb/lancedb/metadata.db "SELECT * FROM documents WHERE path LIKE '%nkardashin%'"

# 3. Проверить пути чанков в LanceDB
# (через Python или CLI)

# 4. Сравнить структуру путей
```

### Требуемое исправление

1. **Диагностика**: добавить инструмент `diagnose_sync` для сравнения LanceDB ↔ SQLite
2. **Исправление lookup**: `ChunkLevelStrategy` должен корректно резолвить document_id → document
3. **Consistency check**: при старте сервера проверять согласованность
4. **Repair tool**: `repair_index` для исправления рассинхронизации

### Acceptance Criteria
- [ ] `search_vault("Кардашин")` возвращает профиль `nkardashin.md` в топ-3
- [ ] Количество warnings "Document not found" = 0 для валидного индекса
- [ ] `index_coverage` показывает 100% (или объясняет причину <100%)

---

## Сводка результатов тестирования

### ✅ Работает (12 инструментов)
`search_text`, `search_regex`, `find_files`, `list_tags`, `timeline`, `recent_changes`, `system_health`, `provider_health`, `index_coverage`, `export_to_csv`, `search_vault` (по точному ID)

### ❌ Критично сломано
| Инструмент | Проблема |
|------------|----------|
| `search_vault` (семантика) | 95% результатов теряется из-за "Document not found" |
| `type:` фильтры | Frontmatter не парсится |
| `find_connected`, `get_backlinks` | Wikilinks не резолвятся |

### ⚠️ Частично работает
`search_vault` (FTS), `find_orphans`, `find_broken_links`

---

## Проблема 1: Frontmatter не парсится в отдельные поля

### Симптомы
- Фильтр `type:person` не возвращает результатов
- `list_doc_types` возвращает пустой список
- `aggregate_by_property("status")` не находит значений
- `dataview_query` с WHERE условиями не работает

### Ожидаемое поведение
Frontmatter вида:
```yaml
---
type: person
status: active
role: developer
---
```
должен парситься в отдельные свойства, доступные для фильтрации.

### Фактическое поведение
Весь frontmatter хранится как единое поле `metadata` (JSON blob), фильтрация невозможна.

### Влияние
**Критическое** — 6 инструментов полностью неработоспособны, это ~30% функциональности.

### Требуемое исправление
1. При индексации парсить frontmatter в `document_properties` (SQLite)
2. Обеспечить dual-write свойств в SQLite
3. Реализовать фильтрацию через SQLite в `search_vault`, `list_doc_types`, `aggregate_by_property`, `dataview_query`

---

## Проблема 2: Wikilinks с относительными путями не резолвятся

### Симптомы
- `find_connected("People/vshadrin.md")` не находит связей
- `get_backlinks` возвращает пустой результат
- `find_orphans` показывает 210 orphans (ложные срабатывания)
- `find_broken_links` показывает 377 битых ссылок (многие — ложные)

### Ожидаемое поведение
Wikilink `[[vshadrin]]` должен резолвиться в `People/vshadrin.md` по имени файла.

### Фактическое поведение
Система ищет точное совпадение пути, не учитывая Obsidian-семантику wikilinks (имя файла без расширения).

### Влияние
**Высокое** — анализ графа знаний полностью неработоспособен.

### Требуемое исправление
1. При индексации извлекать wikilinks из markdown
2. Резолвить `[[target]]` → найти файл `**/target.md` в vault
3. Сохранять resolved links в `document_links` (SQLite)
4. Использовать SQLite для `find_connected`, `get_backlinks`, `find_orphans`, `find_broken_links`

---

## Проблема 3: Релевантность = 0.00

### Симптомы

Все 3 возвращённых результата имеют `Релевантность: 0.00 (минимальная)`:

```
│ 1 │ Структура вебинара... │ ... │ 0.00 (минимальная) │
│ 2 │ Структура вебинара... │ ... │ 0.00 (минимальная) │
│ 3 │ Вебинар Экосистема... │ ... │ 0.00 (минимальная) │
```

### Ожидаемое поведение
Релевантность должна быть в диапазоне 0.0–1.0, где >0.7 — высокая релевантность.

### Фактическое поведение
Все результаты показывают 0.00, что делает ранжирование бессмысленным.

### Влияние
**Среднее** — пользователь не может оценить качество результатов.

### Требуемое исправление
1. Проверить, как вычисляется score в `ChunkLevelStrategy`
2. Возможно, score не передаётся из LanceDB или нормализуется некорректно
3. Добавить логирование raw scores из LanceDB

---

## Проблема 4: FTS не работает для русского языка

### Симптомы
- `search_vault("Всеволод Шадрин", search_type="fts")` — 0 результатов
- `search_vault("vshadrin", search_type="fts")` — работает

### Ожидаемое поведение
FTS должен находить документы по русскоязычному контенту.

### Влияние
**Среднее** — workaround через `search_text` работает.

### Требуемое исправление
1. Проверить настройки FTS в LanceDB (токенизатор, стоп-слова)
2. Возможно, нужен ICU tokenizer или специальная обработка для кириллицы
3. Добавить тесты на русскоязычный FTS

---

## Проблема 5: Качество чанков и enrichment

### Симптомы
- 76.9% чанков слишком маленькие (< минимального порога)
- 100% чанков без `context_prefix`
- Семантический поиск работает, но релевантность низкая

### Ожидаемое поведение
- Чанки должны быть оптимального размера (300-500 токенов)
- Каждый чанк должен иметь `context_prefix` для Contextual Retrieval

### Влияние
**Среднее** — поиск работает, но качество снижено.

### Требуемое исправление
1. Пересмотреть chunking стратегию (увеличить `chunk_size`, настроить `chunk_overlap`)
2. Исправить enrichment pipeline — `context_prefix` должен генерироваться
3. Добавить метрики качества чанков в `audit_index`

---

## Приоритизация

| # | Проблема | Приоритет | Effort | Блокирует |
|---|----------|-----------|--------|-----------|
| **0** | **LanceDB ↔ Documents sync** | **🔴 P-1 BLOCKER** | M | **95% поиска** |
| 1 | Frontmatter парсинг | P0 Critical | L | 6 инструментов |
| 2 | Wikilinks resolution | P0 Critical | M | 4 инструмента |
| 3 | Релевантность = 0.00 | P1 High | S | UX ранжирования |
| 4 | FTS для русского | P2 Medium | S | Частично поиск |
| 5 | Качество чанков | P2 Medium | M | Качество поиска |

---

## Рекомендуемый порядок исправления

```
1. [BLOCKER] Диагностика sync → найти root cause "Document not found"
2. [BLOCKER] Исправить lookup document_id → document  
3. [BLOCKER] Добавить repair_index / reindex с проверкой
4. Проверить, решилась ли проблема релевантности = 0.00
5. Frontmatter парсинг (если не часть sync проблемы)
6. Wikilinks resolution
7. FTS русский, качество чанков
```

---

## Acceptance Criteria (полные)

### Проблема 0 — Sync (БЛОКЕР)
- [ ] `search_vault("Кардашин")` возвращает `nkardashin.md` без warnings
- [ ] Количество "Document not found" warnings = 0
- [ ] Новый инструмент `diagnose_sync` показывает статус согласованности
- [ ] `repair_index` исправляет рассинхронизацию

### Проблема 1 — Frontmatter
- [ ] `list_doc_types("Naumen_CTO")` возвращает: person, project, 1-1, meeting, etc.
- [ ] `search_vault("type:person")` возвращает документы с `type: person`
- [ ] `aggregate_by_property("status")` показывает распределение

### Проблема 2 — Wikilinks
- [ ] `get_backlinks("07_PEOPLE/vshadrin/vshadrin.md")` возвращает ссылающиеся документы
- [ ] `find_orphans()` — только реальные orphans

### Проблема 3 — Релевантность
- [ ] Score в результатах поиска > 0 для релевантных документов
- [ ] Топ результаты имеют score > 0.5

---

## Вопросы для диагностики

1. **Сколько документов в SQLite vs чанков в LanceDB?**
2. **Какой формат `document_id` в чанках LanceDB?** (`vault::path` или `uuid`?)
3. **Как `ChunkLevelStrategy` ищет документ по document_id?**
4. **Когда последний раз была полная переиндексация?**
5. **Менялась ли структура папок vault после индексации?**

---

## Технические заметки

### Целевая архитектура БД
См. `Целевая архитектура БД v2.1.mermaid` в проекте:
- `DOCUMENT_PROPERTIES` — нормализованное хранение frontmatter
- `LINKS` — резолвленные wikilinks с `target_doc_id`
- `PROPERTY_SCHEMAS` — автоопределение типов свойств

### Ключевые файлы для исследования
- `src/obsidian_kb/search/strategies/chunk_level.py` — где происходит "Document not found"
- `src/obsidian_kb/storage/sqlite/document_repository.py` — lookup документов
- `src/obsidian_kb/storage/unified_document_service.py` — dual-write логика
- `src/obsidian_kb/indexing/` — индексация и change detection

### Dual-Write паттерн
При исправлении помнить:
1. Запись в LanceDB (основное хранилище)
2. Запись в SQLite (метаданные) — graceful degradation
