"""Brainless DB main client."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from brainlessdb.bucket import Bucket
from brainlessdb.collection import Collection

_log = logging.getLogger(__name__)


class BrainlessDB:
    """Schema-first async persistence for NATS JetStream KV

    Manages collections backed by NATS JetStream KV buckets. Schema is stored
    in NATS itself, allowing data access without predefined classes.

    Access collections as attributes: db.users, db.calls, etc.
    """

    def __init__(
        self,
        nats: Any = None,
        namespace: str = "default",
        location: str = "local",
        flush_interval: float = 0.5,
    ) -> None:
        """Initialize Brainless DB client

        @param nats: Connected NATS client (optional for in-memory only mode)
        @param namespace: Bucket prefix for isolation (e.g., "myapp" -> "myapp-calls")
        @param location: Name of this site/node (e.g., "prague-1"), used as prefix
                         in record UUIDs and for ownership in multi-location sync
        @param flush_interval: Background flush interval in seconds
        """
        self._nats = nats
        self._namespace = namespace
        self._location = location
        self._flush_interval = flush_interval
        self._started = False
        self._collections: dict[str, Collection] = {}
        self._js: Any = None
        self._flush_task: asyncio.Task | None = None

    @property
    def namespace(self) -> str:
        return self._namespace

    @property
    def location(self) -> str:
        return self._location

    @property
    def connected(self) -> bool:
        """True if connected to NATS."""
        return self._nats is not None and self._js is not None

    def _bucket_name(self, collection: str) -> str:
        """Generate bucket name for collection."""
        return f"{self._namespace}-{collection}"

    async def get_bucket(self, collection: str) -> Bucket | None:
        """Get or create bucket for collection."""
        if not self.connected:
            return None
        name = self._bucket_name(collection)
        return await Bucket.create(self._js, name)

    def collection(self, name: str) -> Collection:
        """Get or create a collection by name

        @param name: Collection name
        @return: Collection instance
        """
        if name not in self._collections:
            self._collections[name] = Collection(self, name)
        return self._collections[name]

    def __getattr__(self, name: str) -> Collection:
        """Access collections as attributes: db.users, db.calls, etc."""
        if name.startswith("_"):
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")
        return self.collection(name)

    async def _flush_loop(self) -> None:
        """Background task to flush dirty entities."""
        try:
            while self._started:
                await asyncio.sleep(self._flush_interval)
                await self.flush()
        except asyncio.CancelledError:
            pass

    async def flush(self) -> int:
        """Flush all dirty entities to NATS

        @return: Number of entities flushed
        """
        total = 0
        for collection in self._collections.values():
            total += await collection.flush()
        return total

    async def start(self) -> None:
        """Start the client and connect to NATS."""
        if self._started:
            return

        # Get JetStream context if NATS is available
        if self._nats is not None:
            self._js = self._nats.jetstream()

        self._started = True

        # Start background flush task
        if self.connected:
            self._flush_task = asyncio.create_task(self._flush_loop())

        _log.info(
            "Brainless DB started (namespace=%s, location=%s, connected=%s)",
            self._namespace,
            self._location,
            self.connected,
        )

    async def stop(self) -> None:
        """Stop the client and flush pending changes."""
        if not self._started:
            return

        self._started = False

        # Cancel flush task
        if self._flush_task is not None:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
            self._flush_task = None

        # Final flush
        flushed = await self.flush()
        if flushed > 0:
            _log.info("Flushed %d entities on shutdown", flushed)

        _log.info("Brainless DB stopped")
