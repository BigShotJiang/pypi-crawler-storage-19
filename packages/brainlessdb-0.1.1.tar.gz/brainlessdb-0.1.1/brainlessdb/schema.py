"""Schema inference and storage."""

from __future__ import annotations

from dataclasses import MISSING, fields, is_dataclass
from typing import Any, get_type_hints

# Type mapping for schema storage
TYPE_MAP = {
    str: "str",
    int: "int",
    float: "float",
    bool: "bool",
    list: "list",
    dict: "dict",
}


def _python_type_to_schema(value: Any) -> str:
    """Infer schema type from Python value."""
    if value is None:
        return "any"
    for py_type, schema_type in TYPE_MAP.items():
        if isinstance(value, py_type):
            return schema_type
    return "any"


def _type_hint_to_schema(hint: Any) -> str:
    """Convert type hint to schema type string."""
    # Handle Optional, Union, etc. by getting the origin
    origin = getattr(hint, "__origin__", None)
    if origin is not None:
        # For Optional[X], Union[X, None], etc.
        args = getattr(hint, "__args__", ())
        # Filter out NoneType
        non_none = [a for a in args if a is not type(None)]
        if non_none:
            return _type_hint_to_schema(non_none[0])
        return "any"

    return TYPE_MAP.get(hint, "any")


class FieldDef:
    """Field definition in a schema."""

    __slots__ = ("name", "type", "required", "default")

    def __init__(
        self,
        name: str,
        type_name: str = "any",
        required: bool = True,
        default: Any = None,
    ) -> None:
        self.name = name
        self.type = type_name
        self.required = required
        self.default = default

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"type": self.type, "required": self.required}
        if not self.required and self.default is not None:
            result["default"] = self.default
        return result


class Schema:
    """Collection schema with field definitions."""

    def __init__(self, name: str, version: int = 1) -> None:
        self.name = name
        self.version = version
        self.fields: dict[str, FieldDef] = {}
        self._locked = False

    def add_field(
        self,
        name: str,
        type_name: str = "any",
        required: bool = True,
        default: Any = None,
    ) -> None:
        """Add field definition."""
        if self._locked:
            raise RuntimeError(f"Schema '{self.name}' is locked, cannot add fields")
        self.fields[name] = FieldDef(name, type_name, required, default)

    def lock(self) -> None:
        """Lock schema to prevent modifications."""
        self._locked = True

    def validate(self, data: dict[str, Any]) -> None:
        """Validate data against schema."""
        for field in self.fields.values():
            if field.required and field.name not in data:
                raise ValueError(f"Missing required field: {field.name}")

        for key in data:
            if key == "uuid":
                continue  # uuid stored as key, not in schema
            if key not in self.fields:
                raise ValueError(f"Unknown field: {key}")

    def apply_defaults(self, data: dict[str, Any]) -> dict[str, Any]:
        """Apply default values for missing optional fields."""
        result = dict(data)
        for field in self.fields.values():
            if field.name not in result and not field.required:
                result[field.name] = field.default
        return result

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "fields": {name: f.to_dict() for name, f in self.fields.items()},
        }


def infer_schema_from_dict(name: str, data: dict[str, Any]) -> Schema:
    """Infer schema from a dictionary of values.

    UUID field is always excluded - it's stored as the key, not in data.
    """
    schema = Schema(name)
    for key, value in data.items():
        if key == "uuid":
            continue
        schema.add_field(key, _python_type_to_schema(value), required=True)
    return schema


def infer_schema_from_dataclass(name: str, cls: type) -> Schema:
    """Infer schema from a dataclass.

    UUID field is always excluded - it's stored as the key, not in data.
    """
    if not is_dataclass(cls):
        raise TypeError(f"{cls} is not a dataclass")

    schema = Schema(name)
    hints = get_type_hints(cls)

    # noinspection PyDataclass
    for field in fields(cls):
        if field.name == "uuid":
            continue

        type_hint = hints.get(field.name, Any)
        type_name = _type_hint_to_schema(type_hint)

        has_default = field.default is not MISSING or field.default_factory is not MISSING

        default = None
        if field.default is not MISSING:
            default = field.default
        elif field.default_factory is not MISSING:
            default = field.default_factory()

        schema.add_field(field.name, type_name, required=not has_default, default=default)

    return schema
