
{
    "version": "2026.1.12",
    "target": "default",
    "variant": "cpu"
}
