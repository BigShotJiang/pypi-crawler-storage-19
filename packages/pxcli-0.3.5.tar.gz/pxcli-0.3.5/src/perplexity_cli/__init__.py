"""Perplexity CLI - Command-line interface for Perplexity.ai."""

__version__ = "0.3.5"
