# aktuarya.hesaplama
