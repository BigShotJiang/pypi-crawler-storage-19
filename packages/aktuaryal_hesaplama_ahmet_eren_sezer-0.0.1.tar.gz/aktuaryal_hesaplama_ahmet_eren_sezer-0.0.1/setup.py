from setuptools import setup, find_packages

setup(
    name="aktuaryal_hesaplama_Ahmet_Eren_Sezer",
    version="0.0.1",
    author="Ahmet Eren Sezer",
    author_email="erensezer001@gmail.com",
    description="Türkçe isimlendirilmiş aktüeryal hesaplama ve MLE tahmin paketi.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/kullaniciadiniz/projeniz", 
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "numpy",
        "scipy"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)