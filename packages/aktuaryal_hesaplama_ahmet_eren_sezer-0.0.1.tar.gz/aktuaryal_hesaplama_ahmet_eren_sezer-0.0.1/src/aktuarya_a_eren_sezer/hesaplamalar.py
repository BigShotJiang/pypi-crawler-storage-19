import numpy as np
from scipy.optimize import minimize
from scipy.special import gammaln

# --- TEMEL AKTÜERYAL HESAPLAMALAR ---

def iskonto_faktoru_hesapla(faiz_orani, donem_sayisi):
    """
    Belirli bir faiz oranı ve dönem için iskonto faktörünü (v^n) hesaplar.
    """
    if faiz_orani < 0:
        raise ValueError("Faiz oranı negatif olamaz.")
    v = 1 / (1 + faiz_orani)
    return v ** donem_sayisi

def tek_prim_hesapla(olum_olasiligi, faiz_orani, teminat_tutari):
    """
    Basit bir yaşam sigortası için Tek Prim (Net Single Premium) hesaplar.
    """
    v = 1 / (1 + faiz_orani)
    return teminat_tutari * v * olum_olasiligi

# --- MLE (EN ÇOK OLABİLİRLİK) TAHMİN FONKSİYONLARI ---

def normal_dagilim_mle(veri_seti):
    """
    Verilen veri seti için Normal Dağılım parametrelerini (mu, sigma) 
    MLE yöntemiyle tahmin eder.
    
    Aktüeryal Kullanım: Toplam hasar tutarlarının modellenmesi.
    
    Dönüş: (ortalama_mu, standart_sapma_sigma)
    """
    def neg_log_lik(params, veri):
        mu, sigma = params
        if sigma <= 0: return np.inf
        n = len(veri)
        # Log-Likelihood: -n/2*ln(2*pi) - n*ln(sigma) - sum((x-mu)^2)/(2*sigma^2)
        log_lik = -0.5 * n * np.log(2 * np.pi) - n * np.log(sigma) - np.sum((veri - mu)**2) / (2 * sigma**2)
        return -log_lik

    baslangic = [np.mean(veri_seti), np.std(veri_seti)]
    sonuc = minimize(neg_log_lik, baslangic, args=(np.array(veri_seti),), method='Nelder-Mead')
    return sonuc.x

def ustel_dagilim_mle(veri_seti):
    """
    Verilen veri seti için Üstel Dağılım parametresini (lambda) tahmin eder.
    
    Aktüeryal Kullanım: İki hasar arasında geçen sürenin modellenmesi.
    
    Dönüş: lambda_orani
    """
    def neg_log_lik(params, veri):
        lam = params[0]
        if lam <= 0: return np.inf
        # Log-Likelihood: n*ln(lambda) - lambda*sum(x)
        log_lik = len(veri) * np.log(lam) - lam * np.sum(veri)
        return -log_lik

    baslangic = [1.0]
    sonuc = minimize(neg_log_lik, baslangic, args=(np.array(veri_seti),), method='Nelder-Mead')
    return sonuc.x[0]

def pareto_dagilim_mle(veri_seti):
    """
    Verilen veri seti için Pareto Dağılımı (Tip 1) parametresi (alpha) tahmin eder.
    (xm parametresi veri setindeki minimum değer olarak varsayılır).
    
    Aktüeryal Kullanım: Büyük hasarların (reasürans) modellenmesi.
    
    Dönüş: alpha (şekil parametresi)
    """
    veri = np.array(veri_seti)
    xm = np.min(veri) # Pareto için alt sınır genelde verinin en küçüğüdür.
    
    def neg_log_lik(params, veri):
        alpha = params[0]
        if alpha <= 0: return np.inf
        n = len(veri)
        # Log-Likelihood: n*ln(alpha) + n*alpha*ln(xm) - (alpha+1)*sum(ln(x))
        log_lik = n * np.log(alpha) + n * alpha * np.log(xm) - (alpha + 1) * np.sum(np.log(veri))
        return -log_lik

    baslangic = [2.0]
    sonuc = minimize(neg_log_lik, baslangic, args=(veri,), method='Nelder-Mead')
    return sonuc.x[0]

def beta_dagilim_mle(veri_seti):
    """
    Verilen veri seti için Beta Dağılımı parametrelerini (alpha, beta) tahmin eder.
    Dikkat: Veriler 0 ile 1 arasında olmalıdır.
    
    Aktüeryal Kullanım: Hasar oranlarının (loss ratios) modellenmesi.
    
    Dönüş: (alpha, beta)
    """
    veri = np.array(veri_seti)
    # Veri kontrolü (0-1 arasında olmalı)
    if np.min(veri) <= 0 or np.max(veri) >= 1:
        raise ValueError("Beta dağılımi için veriler 0 ile 1 arasında olmalıdır.")

    def neg_log_lik(params, veri):
        a, b = params
        if a <= 0 or b <= 0: return np.inf
        # Log-Likelihood: (a-1)sum(ln(x)) + (b-1)sum(ln(1-x)) - n*ln(Beta(a,b))
        # ln(Beta(a,b)) = gammaln(a) + gammaln(b) - gammaln(a+b)
        n = len(veri)
        log_beta_func = gammaln(a) + gammaln(b) - gammaln(a + b)
        log_lik = (a - 1) * np.sum(np.log(veri)) + (b - 1) * np.sum(np.log(1 - veri)) - n * log_beta_func
        return -log_lik

    baslangic = [2.0, 2.0]
    sonuc = minimize(neg_log_lik, baslangic, args=(veri,), method='Nelder-Mead')
    return sonuc.x