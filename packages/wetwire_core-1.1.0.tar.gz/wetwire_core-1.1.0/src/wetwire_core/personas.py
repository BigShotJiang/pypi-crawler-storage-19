"""Persona loading and configuration.

This module re-exports from wetwire_core.agent.personas for convenience.
"""

from wetwire_core.agent.personas import (
    BEGINNER,
    EXPERT,
    INTERMEDIATE,
    PERSONAS,
    TERSE,
    VERBOSE,
    Persona,
    all_personas,
    get_persona,
    load_persona,
    load_persona_from_file,
    persona_names,
)

__all__ = [
    "BEGINNER",
    "EXPERT",
    "INTERMEDIATE",
    "PERSONAS",
    "TERSE",
    "VERBOSE",
    "Persona",
    "all_personas",
    "get_persona",
    "load_persona",
    "load_persona_from_file",
    "persona_names",
]
