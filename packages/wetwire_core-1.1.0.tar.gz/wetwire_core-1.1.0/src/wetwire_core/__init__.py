"""wetwire-core: Shared agent infrastructure for wetwire domain packages."""

__version__ = "1.1.0"
