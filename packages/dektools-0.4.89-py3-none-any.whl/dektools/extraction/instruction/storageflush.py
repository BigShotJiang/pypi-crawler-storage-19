from .base import InstructionBase
from ..produce import DefaultProduce
from ...output import obj2str


class DebugStorageFlushInstruction(InstructionBase):
    head = '$<<'

    def run(self, variables, storage):
        prefix = ""
        if self.key:
            prefix = f"{self.key}: "
        self.output(prefix + obj2str(storage.value, self.obj2str))
        return []

    def output(self, s):
        print(s)

    def obj2str(self, o):
        return repr(o)


class StorageFlushInstruction(InstructionBase):
    head = '$<'
    produce_cls = DefaultProduce

    def run(self, variables, storage):
        if self.value is None:
            reset = True
        else:
            reset = self.instruction_set.eval_expression(None, self.value, variables)
        return [storage.flush(self.produce_cls.wrapper(self.key), reset)]


class VarStorageFlushInstruction(InstructionBase):
    head = '$$<'
    produce_cls = DefaultProduce

    def run(self, variables, storage):
        if self.value is None:
            reset = True
        else:
            reset = self.instruction_set.eval_expression(None, self.value, variables)
        if self.key in storage.value:
            name = storage.value[self.key]
        else:
            name = self.instruction_set.eval_expression(None, self.key, variables)
        return [storage.flush(self.produce_cls.wrapper(name), reset)]
