import os
import tempfile
import tarfile
import zipfile
import shutil
from io import BytesIO
from ._zip import ZipFilePlus
from ..file import remove_path, sure_dir, sure_read, normal_path, clear_dir, sure_parent_dir


def compress_files(
        src, path_zip=None, path_set=None, combine=False, prefix=None,
        compression=zipfile.ZIP_BZIP2,
        allowZip64=True,
        compresslevel=9,
        typed='zip',
        **kwargs):
    if not os.path.exists(src):
        raise FileNotFoundError(src)
    src = normal_path(src)
    if path_zip is None:
        zip_file = BytesIO()
    else:
        path_zip = normal_path(path_zip)
        sure_parent_dir(path_zip)
        if not combine:
            remove_path(path_zip)
        zip_file = path_zip
    cls = tarfile.TarFile.open
    kw = dict(mode='w:gz', **kwargs)
    if typed == 'zip':
        cls = ZipFilePlus
        kw.update(dict(
            mode='w',
            compression=compression,
            allowZip64=allowZip64,
            compresslevel=compresslevel
        ))
    with cls(zip_file, **kw) as zf:
        write = zf.add if isinstance(zf, tarfile.TarFile) else zf.write
        if os.path.isfile(src):
            pp = os.path.basename(src)
            if prefix:
                pp = f"{prefix}/{pp}"
            write(src, pp)
        else:
            if path_set is None:
                need_normal = os.sep == '/'
                for base, _, files in os.walk(src):
                    for file in files:
                        p = os.path.join(base, file)
                        pp = p[len(src):]
                        if prefix:
                            pp = f"{prefix}/{pp}"
                        if need_normal and os.path.islink(p):
                            p = os.path.realpath(p).replace('\\', '/')
                        try:
                            write(p, pp)
                        except FileNotFoundError:
                            pass
            else:
                for p in path_set:
                    p = normal_path(p)
                    if not p.startswith(src + os.path.sep):
                        raise ValueError(f'[{p}] not child of [{src}]')
                    pp = p[len(src):]
                    if prefix:
                        pp = f"{prefix}/{pp}"
                    write(os.path.normpath(os.path.realpath(p)), pp)
    return zip_file.getvalue() if path_zip is None else zip_file


def decompress_files(zip_file, dest_dir=None, combine=False, typed='zip'):
    if not dest_dir:
        dest_dir = tempfile.mkdtemp()
    dest_dir = normal_path(dest_dir)
    sure_dir(dest_dir)
    if not combine:
        clear_dir(dest_dir)
    try:
        cls = tarfile.TarFile.open
        kw = dict(mode='r:gz')
        if typed == 'zip':
            kw.update(dict(mode='r'))
            cls = ZipFilePlus
        with cls(sure_read(zip_file), **kw) as zip_ref:
            zip_ref.extractall(dest_dir)
    except (zipfile.BadZipfile, tarfile.ReadError):
        shutil.unpack_archive(zip_file, dest_dir)
    return dest_dir


def take_bytes(zip_file, path_in_zip, typed='zip'):  # path_in_zip is a relative path in zip file
    cls = tarfile.TarFile.open
    kw = dict(mode='r:gz')
    if typed == 'zip':
        cls = ZipFilePlus
        kw.update(dict(mode='r'))
    with cls(sure_read(zip_file), **kw) as zip_ref:
        try:
            if isinstance(zip_ref, tarfile.TarFile):
                return zip_ref.extractfile(path_in_zip).read()
            return zip_ref.read(path_in_zip)
        except KeyError:
            return None


def take_file(zip_file, path_in_zip, path_out, typed='zip'):
    path_out = normal_path(path_out)
    sure_parent_dir(path_out)
    cls = tarfile.TarFile.open
    kw = dict(mode='r:gz')
    if typed == 'zip':
        cls = ZipFilePlus
        kw.update(dict(mode='r'))
    with cls(sure_read(zip_file), **kw) as zip_ref:
        try:
            with (
                    zip_ref.extractfile(path_in_zip) if isinstance(zip_ref, tarfile.TarFile)
                    else zip_ref.open(path_in_zip)
            ) as zf, open(path_out, 'wb') as f:
                shutil.copyfileobj(zf, f)
                if isinstance(zip_ref, tarfile.TarFile):
                    member = zip_ref.getmember(path_in_zip)
                else:
                    member = zip_ref.getinfo(zf.name)
            if isinstance(zip_ref, tarfile.TarFile):
                zip_ref.chown(member, path_out, False)
                if not member.issym():
                    zip_ref.chmod(member, path_out)
                    zip_ref.utime(member, path_out)
            else:
                zip_ref.set_member_attributes(path_out, member)
            return True
        except KeyError:
            return False
