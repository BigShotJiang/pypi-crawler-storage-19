"""Tests for TabularEntry specialized subclass (Plugin)."""

from axm.catalog.entries import Identity, Owner
from axm.catalog.entries.data import Location
from axm_tabular.entries.tabular import (
    Column,
    TabularEntry,
    TabularSchema,
    TabularSpec,
)


class TestTabularEntry:
    """Tests for TabularEntry specialized subclass."""

    def test_tabular_entry_format(self) -> None:
        """TabularEntry has format='tabular'."""
        owner = Owner(team="data", contact="d@d.com")
        identity = Identity(
            display_name="Users Table",
            description="Test",
            domain="core",
            owner=owner,
        )
        entry = TabularEntry(
            name="test_users",
            version="1.0.0",
            identity=identity,
            data_schema=TabularSchema(spec=TabularSpec(columns=[])),
            location=Location(
                storage="filesystem", path_template="/data/users.parquet"
            ),
        )
        assert entry.format == "tabular"

    def test_tabular_entry_columns(self) -> None:
        """TabularEntry has typed columns."""
        owner = Owner(team="data", contact="d@d.com")
        identity = Identity(
            display_name="Users Table",
            description="Test",
            domain="core",
            owner=owner,
        )
        cols = [
            Column(name="id", type="int64"),
            Column(name="email", type="string", nullable=False),
        ]
        entry = TabularEntry(
            name="test_users",
            version="1.0.0",
            identity=identity,
            data_schema=TabularSchema(spec=TabularSpec(columns=cols)),
            location=Location(
                storage="filesystem", path_template="/data/users.parquet"
            ),
        )
        assert len(entry.data_schema.spec.columns) == 2
        assert entry.data_schema.spec.columns[0].name == "id"
        assert entry.data_schema.spec.columns[1].nullable is False
