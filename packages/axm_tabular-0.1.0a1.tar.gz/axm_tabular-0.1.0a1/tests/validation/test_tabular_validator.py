"""Tests for TabularValidator edge cases."""

import polars as pl
import pytest

from axm.catalog.entries import Identity, Location, Owner
from axm.core import Severity
from axm_tabular.entries.tabular import TabularEntry, TabularSchema, TabularSpec
from axm_tabular.validation.tabular import TabularValidator


class TestTabularValidatorCoverage:
    """Tests to improve coverage of TabularValidator."""

    @pytest.fixture
    def basic_entry(self) -> TabularEntry:
        """Create a basic tabular entry for testing."""
        return TabularEntry(
            name="test_entry",
            version="1.0",
            identity=Identity(
                display_name="Test",
                description="Test",
                domain="test",
                owner=Owner(team="test", contact="test@test.com"),
            ),
            data_schema=TabularSchema(
                spec=TabularSpec(
                    columns=[
                        {"name": "id", "type": "int64", "nullable": False},
                        {"name": "name", "type": "string", "nullable": True},
                    ]
                )
            ),
            location=Location(storage="fs", path_template="/"),
        )

    def test_invalid_input_type(self, basic_entry: TabularEntry) -> None:
        """Should return error if input is not a DataFrame."""
        validator = TabularValidator(basic_entry)
        result = validator.validate({"not": "a dataframe"})
        assert not result.is_valid
        assert "Expected polars DataFrame" in result.errors[0].message

    def test_missing_column(self, basic_entry: TabularEntry) -> None:
        """Should return error if required column is missing."""
        validator = TabularValidator(basic_entry)
        df = pl.DataFrame({"id": [1]})
        result = validator.validate(df)

        assert not result.is_valid
        error_msgs = [e.message for e in result.errors]
        assert "Missing column: name" in error_msgs[0]

    def test_type_mismatch(self, basic_entry: TabularEntry) -> None:
        """Should return error if column type doesn't match."""
        validator = TabularValidator(basic_entry)
        df = pl.DataFrame({"id": ["1"], "name": ["alice"]})
        result = validator.validate(df)

        assert not result.is_valid
        error_msgs = [e.message for e in result.errors]
        assert "Type mismatch for column 'id'" in error_msgs[0]

    def test_non_nullable_constraint(self, basic_entry: TabularEntry) -> None:
        """Should return error if non-nullable column has nulls."""
        validator = TabularValidator(basic_entry)
        df = pl.DataFrame({"id": [1, None], "name": ["alice", "bob"]})
        result = validator.validate(df)

        assert not result.is_valid
        error_msgs = [e.message for e in result.errors]
        assert "Column 'id' is not nullable" in error_msgs[0]

    def test_unknown_rule(self) -> None:
        """Should return warning for unknown rule."""
        entry = TabularEntry(
            name="rule_test",
            version="1.0",
            identity=Identity(
                display_name="T",
                description="D",
                domain="D",
                owner=Owner(team="T", contact="C"),
            ),
            data_schema=TabularSchema(
                spec=TabularSpec(
                    columns=[
                        {"name": "id", "type": "int64", "rules": ["non_existent_rule"]}
                    ]
                )
            ),
            location=Location(storage="fs", path_template="/"),
        )
        validator = TabularValidator(entry)
        df = pl.DataFrame({"id": [1]})

        result = validator.validate(df)
        assert not result.is_valid
        assert len(result.errors) == 1
        assert result.errors[0].severity == Severity.WARNING
        assert "Rule 'non_existent_rule' not found" in result.errors[0].message

    def test_unknown_type_mapping(self) -> None:
        """Should return error (fail check) for unknown type mapping."""
        entry = TabularEntry(
            name="type_test",
            version="1.0",
            identity=Identity(
                display_name="T",
                description="D",
                domain="D",
                owner=Owner(team="T", contact="C"),
            ),
            data_schema=TabularSchema(
                spec=TabularSpec(
                    columns=[
                        # 'complex_type' is not in _check_type mapping
                        {"name": "data", "type": "complex_type"}
                    ]
                )
            ),
            location=Location(storage="fs", path_template="/"),
        )
        validator = TabularValidator(entry)
        # We provide match for 'unknown' just to see it fail type check
        df = pl.DataFrame({"data": ["some string"]})

        result = validator.validate(df)
        assert not result.is_valid
        assert "Type mismatch" in result.errors[0].message

    def test_generic_data_entry_support(self) -> None:
        """Should support generic DataEntry with dict usage for spec."""
        from axm.catalog.entries import DataEntry, Schema, SchemaFormat

        entry = DataEntry(
            name="generic_test",
            version="1.0",
            identity=Identity(
                display_name="T",
                description="D",
                domain="D",
                owner=Owner(team="T", contact="C"),
            ),
            data_schema=Schema(
                format=SchemaFormat.TABULAR,
                spec={"columns": [{"name": "id", "type": "int64"}]},
            ),
            location=Location(storage="fs", path_template="/"),
        )
        validator = TabularValidator(entry)
        df = pl.DataFrame({"id": [1]})
        result = validator.validate(df)
        assert result.is_valid
