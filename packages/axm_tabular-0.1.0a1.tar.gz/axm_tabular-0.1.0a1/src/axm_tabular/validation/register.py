"""Registration module for tabular validators."""

from axm.catalog.validation.registry import ValidatorRegistry
from axm_tabular.validation.tabular import TabularValidator


def register_validators() -> None:
    """Register tabular validators."""
    ValidatorRegistry.register("tabular", TabularValidator)
