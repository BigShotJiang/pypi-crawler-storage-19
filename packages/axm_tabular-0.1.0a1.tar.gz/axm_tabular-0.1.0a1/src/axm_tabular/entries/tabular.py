"""TabularEntry model for AXM Data Catalog (Plugin).

Moved from axm-core to axm-tabular.
"""

from typing import Literal

from pydantic import BaseModel, Field

from axm.catalog.entries.data import (
    DataEntry,
    Schema,
    SchemaFormat,
)


class Column(BaseModel):
    """Column definition for tabular schema.

    Attributes:
        name: Column name.
        type: Data type (int64, float64, string, bool, datetime).
        nullable: Whether nulls are allowed.
        rules: List of validation rule names to apply.
    """

    name: str
    type: str
    nullable: bool = False
    rules: list[str] = Field(default_factory=list)


class TabularSpec(BaseModel):
    """Specific attributes for tabular data."""

    columns: list[Column]
    evolution_policy: str | None = None


class TabularSchema(Schema):
    """Schema definition for tabular data.

    Matches the YAML structure where details are nested in 'spec'.
    """

    format: Literal[SchemaFormat.TABULAR] = SchemaFormat.TABULAR
    spec: TabularSpec


class TabularEntry(DataEntry):
    """A data catalog entry for tabular data.

    Specialized entry with typed schema for columnar data.
    """

    # Override schema with specialized TabularSchema
    data_schema: TabularSchema = Field(alias="schema")

    @property
    def format(self) -> str:
        """Return the data format identifier."""
        return "tabular"
