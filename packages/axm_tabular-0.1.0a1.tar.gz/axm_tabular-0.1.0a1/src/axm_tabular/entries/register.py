"""Registration logic for tabular entry types."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from axm.catalog.entries.registry import EntryTypeRegistry


def register_entries(registry: type["EntryTypeRegistry"]) -> None:
    """Register tabular entry types."""
    from axm_tabular.entries.tabular import TabularEntry

    registry.register("data", "tabular", TabularEntry)
