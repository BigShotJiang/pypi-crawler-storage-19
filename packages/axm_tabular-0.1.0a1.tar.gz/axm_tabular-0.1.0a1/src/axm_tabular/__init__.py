"""Tabular data fields and logic for AXM."""

from axm.catalog.validation.registry import ValidatorRegistry
from axm_tabular.entries.tabular import TabularEntry as TabularEntry
from axm_tabular.operations import register_operations
from axm_tabular.validation.tabular import TabularValidator

# Register the validator
ValidatorRegistry.register("tabular", TabularValidator)

# Register operations
register_operations()

__version__ = "0.1.0"
