"""Save operation for writing tabular data."""

from pathlib import Path
from typing import Any

import polars as pl

from axm.operations import OperationProtocol, OperationResult


class SaveOperation(OperationProtocol):
    """Save a tabular file using Polars.

    Context:
        path: Path to the target file.
    """

    @property
    def name(self) -> str:
        return "tabular.save"

    def execute(
        self,
        data: Any,
        context: dict[str, Any],
        config: dict[str, Any],
    ) -> OperationResult:
        if not isinstance(data, pl.DataFrame):
            return OperationResult(
                data=None, success=False, error="Input data must be a Polars DataFrame"
            )

        path_str = context.get("path")
        if not path_str:
            return OperationResult(
                data=None, success=False, error="Missing 'path' in context"
            )

        path = Path(path_str)
        path.parent.mkdir(parents=True, exist_ok=True)

        try:
            if path.suffix == ".parquet":
                data.write_parquet(path)
            elif path.suffix == ".csv":
                data.write_csv(path)
            else:
                return OperationResult(
                    data=None,
                    success=False,
                    error=f"Unsupported extension: {path.suffix}",
                )

            return OperationResult(data=None, success=True)
        except Exception as e:
            return OperationResult(data=None, success=False, error=str(e))
