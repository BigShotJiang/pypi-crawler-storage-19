"""Tabular operations for AXM."""

from axm.operations import OperationRegistry
from axm_tabular.operations.load import LoadOperation
from axm_tabular.operations.save import SaveOperation


def register_operations(registry: type[OperationRegistry] = OperationRegistry) -> None:
    """Register tabular operations in the registry."""
    registry.register("tabular.load", LoadOperation)
    registry.register("tabular.save", SaveOperation)
