# Copyright (C) 2024  rasmunk
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

from network_manager_provider.defaults import default_persistence_path
from network_manager_provider.utils.io import makedirs, exists, removedirs


def create_persistence_directory(path=default_persistence_path):
    if not exists(path):
        return makedirs(path)
    return True


def persistence_directory_exists(path=default_persistence_path):
    return exists(path)


def remove_persistence_directory(path=default_persistence_path):
    if not exists(path):
        return True
    return removedirs(path)
