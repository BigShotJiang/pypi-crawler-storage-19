"""
Extensions module tests
"""

