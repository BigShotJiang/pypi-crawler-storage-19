# Copyright 2025 PhonePe Private Limited
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass
from dataclasses import field
from typing import Optional, Any

from dataclasses_json import dataclass_json


@dataclass_json
@dataclass
class PhonePeResponse:
    success: Optional[bool] = field(default=None)
    code: Optional[str] = field(default=None)
    message: Optional[str] = field(default=None)
    data: Optional[Any] = field(default=None)
    errorCode: Optional[str] = field(default=None)  # errorCode for auth-response
    context: Optional[Any] = field(default=None)  # context for auth-response
