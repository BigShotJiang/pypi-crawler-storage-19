# 🎬 Sir's ThisVid Ripper

Bulk download videos from ThisVid. Concurrent downloads, resume support, cross-platform.

## ⚡ Install

```bash
pip install sirsthisvid
```

## 🚀 Run

```bash
sirsthisvid
```

You'll see:

```
═══════════════════════════════════════════════════════════
  🎬 SIR'S THISVID RIPPER  v2.2.1
═══════════════════════════════════════════════════════════

  What do you want to download?

  [1] 🏷️  Tag — videos with a specific tag
  [2] 👤 Profile — all videos from a user
  [3] 📺 All Videos — newest gay or straight
  [4] ⏩ Resume — continue where you left off
  [5] 🔄 Check for updates
  [0] 🚪 Exit

  Choice:
```

Pick a number, follow the prompts, done.

## ✨ What's New in v2.2.1

- **6x faster** — 6 concurrent downloads instead of sequential
- **Fixed folder paths** — drag-drop works with spaces, apostrophes, special chars
- **Live progress** — shows speed (downloads/min) and ETA
- **Better retries** — socket timeouts and 3 retries per video

## 📁 Files Created

In your download folder:

| File | Purpose |
|------|---------|
| `download_status.csv` | Tracks completed/failed/pending |
| `scraped_pages.txt` | Which pages have been indexed |
| `session.json` | Resume data |

## 🔧 Troubleshooting

**"yt-dlp not found"**
```bash
pip install yt-dlp
```

**Some videos fail**
They might be private or deleted. Check `download_status.csv` — change `failed` to `pending` and resume to retry.

**Want more concurrent downloads?**
Edit the script: change `DOWNLOAD_WORKERS = 6` to 8 or 10 (careful of rate limits).

## 📜 License

[CC0](LICENSE) — Do whatever you want.

---

<p align="center">
  <a href="https://thevault.locker">🔒 The Vault+</a> · 
  <a href="https://cultofsir.com">👁️ The Cult of Sir</a> · 
  <a href="https://sirdominic.store">🛒 Sir Store</a>
</p>
