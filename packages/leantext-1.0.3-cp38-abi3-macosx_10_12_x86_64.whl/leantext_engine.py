import json
import uuid
import os
import leantext
import atexit
import gc
import time
import threading
import copy
import math
from typing import List, Dict, Any, Optional

class LeanTextEngine:
    """
    A high-level wrapper for LeanText that supports:
    - Multiple collections (subdirectories).
    - Automatic background persistence (maintenance loop).
    - Metadata sanitization (NaN handling).
    - Batch operations.
    - Automatic cleanup on exit.
    """
    def __init__(self, base_path: str = 'leantext_root', auto_persist: bool = True):
        self.base_path = base_path
        if not os.path.exists(base_path):
            os.makedirs(base_path)

        self.collections: Dict[str, leantext.LeanText] = {}
        
        # Maintenance settings
        self.start_time = time.time()
        self.last_access_time = time.time()
        self.maintenance_interval = 86400  # 24 hours
        self.idle_threshold = 3600         # 1 hour
        self.stop_maintenance = False
        
        self.m_thread = threading.Thread(target=self._maintenance_loop, daemon=True)
        self.m_thread.start()

        if auto_persist:
            atexit.register(self.persist_all)

    def _get_col_path(self, name: str) -> str:
        return os.path.join(self.base_path, name)

    def _ensure_collection(self, name: str) -> leantext.LeanText:
        self.last_access_time = time.time()
        if name not in self.collections:
            path = self._get_col_path(name)
            if not os.path.exists(path):
                os.makedirs(path)
            self.collections[name] = leantext.LeanText(path)
        return self.collections[name]

    def list_collections(self) -> List[str]:
        # Lists subdirectories in base_path that look like collections
        cols = set(self.collections.keys())
        if os.path.exists(self.base_path):
            for name in os.listdir(self.base_path):
                if os.path.isdir(self._get_col_path(name)):
                    cols.add(name)
        return list(cols)

    def add(self, content: str, metadata: Optional[Dict[str, Any]] = None, doc_id: Optional[str] = None, collection: str = "default") -> str:
        """Adds a single document. Returns the document ID."""
        return self.add_batch([content], [metadata] if metadata else None, [doc_id] if doc_id else None, collection)[0]

    def add_batch(
        self,
        contents: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        ids: Optional[List[str]] = None,
        collection: str = "default"
    ) -> List[str]:
        if not contents:
            return []
            
        db = self._ensure_collection(collection)
        
        # Prepare inputs
        if metadatas is None:
            metadatas = [{} for _ in range(len(contents))]
        if ids is None:
            ids = [None] * len(contents)
            
        result_ids = []
        
        for i, text in enumerate(contents):
            # Metadata handling
            meta_orig = metadatas[i] if i < len(metadatas) else {}
            meta = copy.deepcopy(meta_orig) if meta_orig else {}
            meta = self._sanitize_metadata(meta)

            # ID handling
            provided_id = ids[i] if i < len(ids) else None
            doc_id = str(provided_id or meta.get("id") or meta.get("_id") or uuid.uuid4())
            meta["id"] = doc_id

            # Serialization safety
            try:
                meta_json = json.dumps(meta, allow_nan=False)
            except ValueError:
                meta_json = json.dumps({"id": doc_id})

            db.add(doc_id, text, meta_json)
            result_ids.append(doc_id)
            
        return result_ids

    def _sanitize_metadata(self, meta: Any) -> Any:
        """Recursively cleans metadata for JSON compatibility (handles NaN/Inf)."""
        if isinstance(meta, float):
            if math.isnan(meta) or math.isinf(meta):
                return None
        elif isinstance(meta, dict):
            return {k: self._sanitize_metadata(v) for k, v in meta.items()}
        elif isinstance(meta, list):
            return [self._sanitize_metadata(v) for v in meta]
        return meta
    
    def search(
        self, 
        query: str, 
        k: int = 10, 
        filters: Optional[Dict[str, Any]] = None, 
        collection: str = "default", 
        fuzzy_dist: int = 0,
        title_boost: float = 1.0,
        body_boost: float = 1.0,
        return_content: bool = False
    ) -> List[Dict[str, Any]]:
        
        db = self._ensure_collection(collection)
        filter_str = json.dumps(filters) if filters else None
        
        # Returns: Vec<(String, f32, String, Option<String>)>
        raw_results = db.search(
            query, 
            filter_str, 
            k, 
            fuzzy_dist, 
            title_boost, 
            body_boost, 
            return_content
        )
        
        results = []
        for doc_id, score, meta_str, content in raw_results:
            try:
                meta = json.loads(meta_str)
            except (TypeError, json.JSONDecodeError):
                meta = {}
            
            res = {
                "id": doc_id,
                "score": score,
                "metadata": meta
            }
            if return_content:
                res["content"] = content
                
            results.append(res)

        return results

    def get_content(self, doc_id: str, collection: str = "default") -> Optional[str]:
        if collection not in self.collections:
             # Try loading if it exists on disk
             path = self._get_col_path(collection)
             if not os.path.exists(path):
                 return None
        
        return self._ensure_collection(collection).get_content(doc_id)

    def delete(self, doc_id: str, collection: str = "default") -> None:
        if collection in self.collections or os.path.exists(self._get_col_path(collection)):
            self._ensure_collection(collection).delete(doc_id)

    def delete_by_filter(self, metadata_filter: Dict[str, Any], collection: str = "default") -> int:
        if collection in self.collections or os.path.exists(self._get_col_path(collection)):
            return self._ensure_collection(collection).delete_by_filter(json.dumps(metadata_filter))
        return 0

    def count(self, collection: str = "default") -> int:
        if collection in self.collections or os.path.exists(self._get_col_path(collection)):
            return self._ensure_collection(collection).count()
        return 0

    def persist_all(self):
        if not os.path.exists(self.base_path):
            return
            
        for name, db in list(self.collections.items()):
            try:
                gc.collect()
                db.persist()
            except Exception:
                pass

    def persist(self, collection: str = "default"):
        if collection in self.collections:
            self.collections[collection].persist()

    def _maintenance_loop(self):
        while not self.stop_maintenance:
            time.sleep(1)
            uptime = time.time() - self.start_time
            idle_time = time.time() - self.last_access_time
            if uptime > self.maintenance_interval and idle_time > self.idle_threshold:
                self.persist_all()
                self.start_time = time.time()

    def vacuum(self, collection: str = "default"):
        """Defragments the storage files for a specific collection."""
        if collection in self.collections or os.path.exists(self._get_col_path(collection)):
            self._ensure_collection(collection).vacuum()
