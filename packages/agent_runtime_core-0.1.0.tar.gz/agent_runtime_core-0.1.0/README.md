# agent_runtime

Framework-agnostic agent runtime library for Python.

## Installation

```bash
pip install agent_runtime
```

## Quick Start

```python
from agent_runtime import configure, get_llm_client

# Configure
configure(
    model_provider="openai",
    openai_api_key="sk-..."
)

# Get LLM client
llm = get_llm_client()
```

## Features

- Pluggable backends (memory, redis, sqlite)
- LLM client abstractions (OpenAI, Anthropic, LiteLLM)
- Event streaming
- State management
- Queue-based execution
