"""
Trace Manager for LLMOps Observability
Handles tracing and tracking of LLM operations with direct Langfuse integration
"""
from __future__ import annotations
import uuid
import threading
import time
import traceback
import functools
import inspect
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from .models import SpanContext
from .config import get_langfuse_client


# ============================================================
# Core Trace Manager
# ============================================================

class TraceManager:
    _lock = threading.Lock()
    _active: Dict[str, Any] = {
        "trace_id": None,
        "trace_obj": None,  # Langfuse trace object
        "spans": [],
        "stack": [],
        "metadata": {},
    }

    @classmethod
    def has_active_trace(cls) -> bool:
        """Check if there's an active trace"""
        with cls._lock:
            return cls._active["trace_id"] is not None

    @classmethod
    def _id(cls) -> str:
        """Generate a unique ID compatible with Langfuse (32 lowercase hex chars)"""
        return uuid.uuid4().hex  # Returns 32 lowercase hex chars without hyphens

    @classmethod
    def _now(cls) -> str:
        """Get current timestamp in ISO format"""
        return datetime.now(timezone.utc).isoformat()

    @classmethod
    def start_trace(
        cls,
        *,
        name: str,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ):
        """
        Start a new trace in Langfuse.
        
        Args:
            name: Name of the trace
            user_id: Optional user ID
            session_id: Optional session ID
            metadata: Optional metadata dictionary
            tags: Optional list of tags
        """
        with cls._lock:
            if cls._active["trace_id"]:
                print("[LLMOps-Observability] WARNING: Trace already active. Ending previous trace.")
                cls.end_trace()

            trace_id = cls._id()
            
            # Store trace information (Langfuse creates trace automatically when first observation is added)
            cls._active["trace_id"] = trace_id
            cls._active["trace_obj"] = {
                "name": name,
                "user_id": user_id,
                "session_id": session_id,
                "metadata": metadata or {},
                "tags": tags or [],
            }
            cls._active["spans"] = []
            cls._active["stack"] = []
            cls._active["metadata"] = metadata or {}
            
            print(f"[LLMOps-Observability] Trace started: {name} (ID: {trace_id})")
            return trace_id

    @classmethod
    def end_trace(cls) -> Optional[str]:
        """
        End the current trace and flush to Langfuse.
        """
        with cls._lock:
            trace_id = cls._active["trace_id"]
            
            if not trace_id:
                return None
            
            # Clear the active trace
            cls._active["trace_id"] = None
            cls._active["trace_obj"] = None
            cls._active["spans"] = []
            cls._active["stack"] = []
            cls._active["metadata"] = {}
            
            # Flush to Langfuse immediately (no batching)
            langfuse = get_langfuse_client()
            langfuse.flush()
            
            print(f"[LLMOps-Observability] Trace ended and flushed: {trace_id}")
            return trace_id

    @classmethod
    def get_span_context(
        cls,
        span_name: str,
        span_type: str = "span",
        tags: Optional[Dict[str, Any]] = None
    ) -> Optional[SpanContext]:
        """
        Create a SpanContext if there's an active trace.
        Returns None if no active trace.
        """
        if not cls.has_active_trace():
            return None
        
        with cls._lock:
            parent_span_id = (
                cls._active["stack"][-1]["span_id"]
                if cls._active["stack"]
                else None
            )
            trace_id = cls._active["trace_id"]
            metadata = cls._active.get("metadata", {})
        
        return SpanContext(
            trace_id=trace_id,
            span_id=cls._id(),
            parent_span_id=parent_span_id,
            start_time=time.time(),
            span_name=span_name,
            span_type=span_type,
            tags=tags,
            metadata=metadata,
        )

    @classmethod
    def send_span_to_langfuse(cls, ctx: SpanContext):
        """
        Send a span directly to Langfuse using start/end pattern.
        
        Args:
            ctx: SpanContext with all span data
        """
        with cls._lock:
            trace_obj = cls._active.get("trace_obj")
            if not trace_obj:
                print(f"[LLMOps-Observability] WARNING: No active trace for span: {ctx.span_name}")
                return
            
            trace_id = cls._active.get("trace_id")
        
        langfuse = get_langfuse_client()
        
        # Build metadata
        span_metadata = {**(ctx.tags or {}), **ctx.metadata}
        
        # Calculate timestamps
        start_time = datetime.fromtimestamp(ctx.start_time, tz=timezone.utc)
        end_time = datetime.fromtimestamp(ctx.start_time + (ctx.duration_ms / 1000), tz=timezone.utc)
        
        # Build trace context
        trace_context = {
            "trace_id": trace_id,
            "user_id": trace_obj.get("user_id"),
            "session_id": trace_obj.get("session_id"),
        }
        
        # Prepare common kwargs
        common_kwargs = {
            "name": ctx.span_name,
            "input": ctx.input_data,
            "output": ctx.output_data,
            "metadata": span_metadata,
            "level": "ERROR" if ctx.error else "DEFAULT",
        }
        
        # Add status message if error
        if ctx.error:
            common_kwargs["status_message"] = str(ctx.error)
        
        # Create observation using the correct method
        try:
            if ctx.span_type == "generation":
                # For LLM calls, use start_generation
                obs = langfuse.start_generation(
                    trace_context=trace_context,
                    **common_kwargs
                )
            else:
                # For regular functions, use start_span
                obs = langfuse.start_span(
                    trace_context=trace_context,
                    **common_kwargs
                )
            
            # Immediately end the observation (since we already have the complete data)
            obs.end()
            
        except Exception as e:
            print(f"[LLMOps-Observability] ERROR sending to Langfuse: {e}")
            import traceback
            traceback.print_exc()
            return
        
        # Flush immediately (no batching)
        langfuse.flush()
        
        status_str = "(error)" if ctx.error else ""
        print(f"[LLMOps-Observability] Span sent{status_str}: {ctx.span_name} ({ctx.duration_ms}ms)")


# ============================================================
# Decorator: track_function
# ============================================================

def track_function(
    name: Optional[str] = None,
    *,
    tags: Optional[Dict[str, Any]] = None,
):
    """
    Decorator to track function execution with Langfuse.
    
    Similar to veriskGO's @track_function but sends directly to Langfuse.
    
    Usage:
        @track_function()
        def process_data(input_data):
            # Your code here
            return result
            
        @track_function(name="custom_name", tags={"version": "1.0"})
        async def async_function():
            # Async code
            return result
    
    Args:
        name: Optional custom name for the span
        tags: Optional metadata tags
    """
    def decorator(func):
        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)
        
        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                ctx = TraceManager.get_span_context(span_name, span_type="span", tags=tags)
                
                if not ctx:
                    # No active trace, execute without tracing
                    return await func(*args, **kwargs)
                
                # Capture input
                ctx.input_data = {
                    "args": args,
                    "kwargs": kwargs,
                }
                
                try:
                    result = await func(*args, **kwargs)
                    ctx.output_data = result
                    return result
                except Exception as e:
                    ctx.error = e
                    raise
                finally:
                    TraceManager.send_span_to_langfuse(ctx)
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                ctx = TraceManager.get_span_context(span_name, span_type="span", tags=tags)
                
                if not ctx:
                    # No active trace, execute without tracing
                    return func(*args, **kwargs)
                
                # Capture input
                ctx.input_data = {
                    "args": args,
                    "kwargs": kwargs,
                }
                
                try:
                    result = func(*args, **kwargs)
                    ctx.output_data = result
                    return result
                except Exception as e:
                    ctx.error = e
                    raise
                finally:
                    TraceManager.send_span_to_langfuse(ctx)
            
            return sync_wrapper
    
    return decorator
