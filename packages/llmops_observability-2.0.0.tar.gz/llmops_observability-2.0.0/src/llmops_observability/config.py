"""
Configuration management for LLMOps Observability
Direct Langfuse client configuration
"""
import os
from typing import Optional
from langfuse import Langfuse
import httpx
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Global Langfuse client
_langfuse_client: Optional[Langfuse] = None


def get_langfuse_client() -> Langfuse:
    """
    Get or create the global Langfuse client.
    
    Environment variables:
        - LANGFUSE_PUBLIC_KEY: Langfuse public key
        - LANGFUSE_SECRET_KEY: Langfuse secret key
        - LANGFUSE_BASE_URL: Langfuse base URL
        - LANGFUSE_VERIFY_SSL: Whether to verify SSL (default: true)
    
    Returns:
        Langfuse: Configured Langfuse client
    """
    global _langfuse_client
    
    if _langfuse_client is None:
        verify_ssl = os.getenv("LANGFUSE_VERIFY_SSL", "true").lower() == "true"
        
        # Create custom HTTP client with optional SSL verification
        httpx_client = httpx.Client(verify=verify_ssl) if not verify_ssl else None
        
        _langfuse_client = Langfuse(
            public_key=os.getenv("LANGFUSE_PUBLIC_KEY"),
            secret_key=os.getenv("LANGFUSE_SECRET_KEY"),
            base_url=os.getenv("LANGFUSE_BASE_URL"),
            httpx_client=httpx_client,
        )
        
        print(f"[LLMOps-Observability] Langfuse client initialized: {os.getenv('LANGFUSE_BASE_URL')}")
    
    return _langfuse_client


def configure(
    public_key: Optional[str] = None,
    secret_key: Optional[str] = None,
    base_url: Optional[str] = None,
    verify_ssl: bool = True
):
    """
    Manually configure Langfuse client.
    
    Args:
        public_key: Langfuse public key
        secret_key: Langfuse secret key
        base_url: Langfuse base URL
        verify_ssl: Whether to verify SSL certificates
    """
    global _langfuse_client
    
    httpx_client = httpx.Client(verify=verify_ssl) if not verify_ssl else None
    
    _langfuse_client = Langfuse(
        public_key=public_key,
        secret_key=secret_key,
        base_url=base_url,
        httpx_client=httpx_client,
    )
    
    print(f"[LLMOps-Observability] Langfuse client configured: {base_url}")
