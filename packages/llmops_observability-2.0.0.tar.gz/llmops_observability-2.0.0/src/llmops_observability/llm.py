"""
LLM tracking decorator for LLMOps Observability
Direct Langfuse integration for tracking LLM calls
"""
from __future__ import annotations
import functools
import inspect
from typing import Optional, Dict, Any
from .trace_manager import TraceManager


def extract_text(resp: Any) -> str:
    """
    Extract text from various LLM response formats.
    Supports: Bedrock Converse, Bedrock InvokeModel, OpenAI, LangChain, etc.
    """
    if isinstance(resp, str):
        return resp

    if not isinstance(resp, dict):
        return str(resp)

    # Bedrock Converse API
    try:
        return resp["output"]["message"]["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Anthropic Messages API
    try:
        return resp["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Amazon Titan
    try:
        return resp["results"][0]["outputText"]
    except (KeyError, IndexError, TypeError):
        pass

    # Cohere
    try:
        return resp["generation"]
    except (KeyError, TypeError):
        pass

    # AI21
    try:
        return resp["outputs"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Generic text field
    try:
        return resp["text"]
    except (KeyError, TypeError):
        pass

    # OpenAI format
    try:
        return resp["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        pass

    return str(resp)


def track_llm_call(
    name: Optional[str] = None,
    *,
    tags: Optional[Dict[str, Any]] = None,
    extract_output: bool = True,
):
    """
    Decorator to track LLM calls with Langfuse.
    
    Similar to veriskGO's @track_llm_call but sends directly to Langfuse as a generation.
    
    Usage:
        @track_llm_call()
        def call_bedrock(prompt):
            response = bedrock.converse(...)
            return response
            
        @track_llm_call(name="summarize", tags={"model": "claude-3"})
        async def summarize(text):
            return await chain.ainvoke(...)
    
    Args:
        name: Optional custom name for the generation
        tags: Optional metadata tags
        extract_output: Whether to extract text from LLM response
    """
    def decorator(func):
        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)
        
        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                ctx = TraceManager.get_span_context(
                    span_name,
                    span_type="generation",
                    tags=tags
                )
                
                if not ctx:
                    # No active trace, execute without tracing
                    return await func(*args, **kwargs)
                
                # Capture input - extract prompt if first arg is string
                if args and isinstance(args[0], str):
                    ctx.input_data = {
                        "prompt": args[0],
                        "args": args[1:],
                        "kwargs": kwargs,
                    }
                else:
                    ctx.input_data = {
                        "args": args,
                        "kwargs": kwargs,
                    }
                
                try:
                    result = await func(*args, **kwargs)
                    
                    # Extract text from response if enabled
                    if extract_output:
                        try:
                            text_output = extract_text(result)
                            ctx.output_data = {
                                "text": text_output,
                                "raw": result,
                            }
                        except Exception:
                            ctx.output_data = result
                    else:
                        ctx.output_data = result
                    
                    return result
                except Exception as e:
                    ctx.error = e
                    raise
                finally:
                    TraceManager.send_span_to_langfuse(ctx)
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                ctx = TraceManager.get_span_context(
                    span_name,
                    span_type="generation",
                    tags=tags
                )
                
                if not ctx:
                    # No active trace, execute without tracing
                    return func(*args, **kwargs)
                
                # Capture input - extract prompt if first arg is string
                if args and isinstance(args[0], str):
                    ctx.input_data = {
                        "prompt": args[0],
                        "args": args[1:],
                        "kwargs": kwargs,
                    }
                else:
                    ctx.input_data = {
                        "args": args,
                        "kwargs": kwargs,
                    }
                
                try:
                    result = func(*args, **kwargs)
                    
                    # Extract text from response if enabled
                    if extract_output:
                        try:
                            text_output = extract_text(result)
                            ctx.output_data = {
                                "text": text_output,
                                "raw": result,
                            }
                        except Exception:
                            ctx.output_data = result
                    else:
                        ctx.output_data = result
                    
                    return result
                except Exception as e:
                    ctx.error = e
                    raise
                finally:
                    TraceManager.send_span_to_langfuse(ctx)
            
            return sync_wrapper
    
    return decorator
