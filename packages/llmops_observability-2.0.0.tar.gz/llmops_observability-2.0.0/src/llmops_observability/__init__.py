"""
LLMOps Observability SDK – Public API
Direct Langfuse integration for LLM tracing without SQS/batching.
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("llmops-observability")
except PackageNotFoundError:
    __version__ = "0.0.0"

# Core components
from .trace_manager import TraceManager, track_function
from .llm import track_llm_call
from .config import get_langfuse_client, configure

__all__ = [
    "TraceManager",
    "track_function",
    "track_llm_call",
    "get_langfuse_client",
    "configure",
    "__version__",
]
