import logging
from struct import pack
from time import time
from typing import List, Optional

import numpy as np

from .client_core import ClientProtocol, CoreClient

LOGGER = logging.getLogger("kernel.sdk.daq")
LOGGER.setLevel(logging.INFO)


DAQ_MAGIC_TYPE = b"Rn"
DAQ_VERSION = 1
DAQ_MAGIC_FORMAT = "2BH"  # 4 bytes total


class DAQ:

    @staticmethod
    def data_encode(
        data: np.array,
        column_indicies: List[int],
        id: int,
        timestamp: int,
        stream_rate: int,
    ):

        encoded_columns = bytes(column_indicies)
        shape = data.shape
        encoded_data = data.astype(">f8").tobytes()

        encoded = pack(
            f">{DAQ_MAGIC_FORMAT}2Q2H{len(encoded_columns)}B2H{len(encoded_data)}B",
            *DAQ_MAGIC_TYPE,
            DAQ_VERSION,
            id,  # Q
            timestamp,  # Q
            stream_rate,  # H
            len(encoded_columns),  # H
            *encoded_columns,  # bytes
            shape[0],  # H
            shape[1],  # H
            *encoded_data,  # bytes
        )

        # header format:
        # 1 byte for magic packet type
        # 8 bytes for packet id
        # 8 bytes for timestamp

        # body format:
        # 8 bytes for length of column names (column_names_len)
        # column_names_len many bytes for JSON encoded array of strings (column names)
        # 8 bytes for numpy x-dimension
        # 8 bytes for numpy y-dimension
        # remaining bytes are numpy array of dtype float64 with shape (x-dimension,y-dimension)

        return encoded


class DAQClient(CoreClient):
    def __init__(self, ip, port, debug=False):
        super().__init__(ip, port, protocol=ClientProtocol.TCP, debug=debug)

    def send_event(
        self,
        data_matrix: np.ndarray,
        column_indicies: List[int],
        stream_rate: int,
        event_end_timestamp: Optional[float] = None,
    ):
        """
        This will send a raw event, with data_matrix and column_indicies encoded as DAQ packet

        timestamp should be seconds since epoch (as from time.time()) of the last sample in data_matrix

        expects data_matrix shape to be columns x rows
        """
        if event_end_timestamp is None:
            event_end_timestamp = time()
        LOGGER.info(
            "Received event [#{} @ {}]".format(
                self._id + 1, int(event_end_timestamp * 1e9)
            )
        )

        encoded = DAQ.data_encode(
            data_matrix,
            column_indicies,
            self._id,
            int(event_end_timestamp * 1e9),
            stream_rate,
        )

        self._send_event(encoded)
        self._id += 1
