"""A prelude is a collection of utilities which will be used extensively by the main program,
borrowing a Rust idiom into Python here.
"""

TIMESTAMP_URN = "urn:kernel.com/field/timestamp"


class SDKError(Exception):
    """Parent for errors from the sdk"""


class Disconnected(SDKError):
    """Raised when the client has not yet connected and cannot send a command."""


class TimeoutError(TimeoutError, SDKError):
    """TimeoutError that also inherets from SDKError"""


class CommandFailure(SDKError):
    """Exception thrown by a command failing to execute"""
