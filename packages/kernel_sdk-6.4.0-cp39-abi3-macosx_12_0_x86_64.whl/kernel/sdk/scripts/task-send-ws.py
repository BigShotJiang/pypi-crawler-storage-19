import asyncio
import json

import websockets


async def send_message():
    uri = "ws://localhost:7892"
    async with websockets.connect(uri) as websocket:
        message = {"timestamp": "2024-01-01T12:00:00", "data": {"key1": "value1", "key2": 42}}
        await websocket.send(json.dumps(message))


asyncio.run(send_message())
