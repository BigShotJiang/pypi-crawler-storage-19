import logging
import os
import sys
import time
from pathlib import Path
from typing import Tuple

import click
import numpy as np
from kernel.sdk.client_core import ClientProtocol
from kernel.sdk.daq import DAQClient

LOGGER = logging.getLogger("Kodirect")
LOGGER.setLevel(logging.INFO)


def data_local_dir() -> Path:
    # """
    # /// Returns the path to the user's local data directory.
    # ///
    # /// The returned value depends on the operating system and is either a `Some`, containing a value from the following table, or a `None`.
    # ///
    # /// |Platform | Value                                    | Example                                  |
    # /// | ------- | ---------------------------------------- | ---------------------------------------- |
    # /// | Linux   | `$XDG_DATA_HOME` or `$HOME`/.local/share | /home/alice/.local/share                 |
    # /// | macOS   | `$HOME`/Library/Application Support      | /Users/Alice/Library/Application Support |
    # /// | Windows | `{FOLDERID_LocalAppData}`                | C:\Users\Alice\AppData\Local             |
    # """
    if sys.platform == "win32":
        return Path(os.getenv("LOCALAPPDATA"))
    elif sys.platform == "darwin":
        return Path.home() / "Library/Application Support"
    else:
        return Path.home() / ".local/share"


MEASUREMENT_PERIOD = 100  # in ms
STREAM_RATE = int(1 / (MEASUREMENT_PERIOD / 1000))


class NotConnectedError(RuntimeError):
    pass


def open_usb() -> Tuple["GoDirect", "GoDirectDeviceUSB"]:
    """Discovers all Go Direct devices with a USB connection and opens those devices
    for data collection.
    """
    from godirect import GoDirect
    from godirect.backend_usb import GoDirectDeviceUSB

    # Call the godirect module to open a USB connection
    g = GoDirect(use_ble=False, use_usb=True)

    found_devices = g.list_devices()
    if len(found_devices) == 0:
        LOGGER.error("open_usb() - no device connected")
        raise NotConnectedError

    LOGGER.info("attempting to open %i device(s)...", len(found_devices))
    for device in found_devices:
        open_success = device.open()
        if open_success:
            LOGGER.info(f"opened device {device}")

    return g, found_devices


@click.group()
def cli():
    pass


def _start(tcp_ip, tcp_port, stream_period):
    import yaml

    stream_rate = int(1 / (stream_period / 1000))
    LOGGER.info(
        f"starting godirect measurement with period {stream_period}ms and stream_rate {stream_rate}Hz"
    )

    daq_client = None
    device = None
    err = None
    try:

        # dump channel->name to file for soma
        godirect_config = {"godirect": {"0": "force", "1": "breath_rate"}}
        with open(
            data_local_dir() / "daq-config.yml", "w"
        ) as f:  # TODO: change this path to match kortex
            yaml.dump(godirect_config, f)

        _go_direct_guard, open_devices = open_usb()

        if len(open_devices) != 1:
            LOGGER.error(
                f"expected only 1 godirect device, found {len(open_devices)} instead"
            )
            raise RuntimeError("Unexpected number of godirects connected")

        device = open_devices[0]

        device.enable_sensors([1, 2])  # force sensor (1) and respiration rate (2)
        device.start(stream_period)

        daq_client = DAQClient(tcp_ip, tcp_port)

        while True:
            device.read()
            cycle_data = []
            for sensor in device.get_enabled_sensors():
                print(f"sensor {sensor.sensor_number} values {sensor.values}")
                cycle_data.append(sensor.values.pop(0))
                sensor.clear()
            data = np.array(cycle_data)[
                :, np.newaxis
            ]  # needs to be 2-d, so add extra axis
            LOGGER.info(data)
            daq_client.send_event(data, [0, 1], stream_rate=stream_rate)
    except Exception as e:
        LOGGER.error(f"Error in godirect measurement: {e}")
        err = e

    finally:
        if device is not None:
            device.stop()
        LOGGER.info("Exited godirect measurement")
        if daq_client is not None:
            daq_client._socket._socket.shutdown(1)
            daq_client._socket._socket.close()
            del daq_client
        if err is not None:
            raise err


@cli.command()
@click.option("--tcp_ip", default="127.0.0.1")
@click.option("--tcp_port", default=6766)
@click.option("--stream_period", default=MEASUREMENT_PERIOD, type=int)
def start(tcp_ip, tcp_port, stream_period):

    while True:
        try:
            _start(tcp_ip, tcp_port, stream_period)
        except KeyboardInterrupt:
            LOGGER.error("Exiting due to keyboard interrupt")
            break
        except ImportError:
            LOGGER.error(
                f"required modules not found for kodirect\nRun {sys.executable} -m pip install -r {Path(__file__).parent / 'kodirect_requirements.txt'}"
            )
            break
        except Exception as e:

            LOGGER.warning(f"Error during godirect loop: {e}")
            LOGGER.warning("Restarting godirect loop after 5 seconds")
            time.sleep(5)


@cli.command()
def install_mac():
    """
    create plist with launchd for kodirect
    """
    try:
        import godirect
        import yaml
    except ImportError:
        LOGGER.error(
            f"required modules not found for kodirect\nRun {sys.executable} -m pip install -r {Path(__file__).parent / 'kodirect_requirements.txt'}"
        )

        return
    interpreter_path = sys.executable
    kodirect_path = Path(__file__)
    with open(kodirect_path.parent / "kodirect_plist_template") as f:
        plist = f.read()
    plist = plist.replace("{{interpreter_path}}", interpreter_path)
    plist = plist.replace("{{kodirect_path}}", str(kodirect_path))

    # write plist to ~/Library/LaunchAgents
    launchd = Path("/Library/LaunchDaemons/com.kernel.kodirect.plist")
    try:
        with open(launchd, "w") as f:
            f.write(plist)
    except PermissionError:
        LOGGER.error(
            f"Permission denied to write to /Library/LaunchDaemons. Try running with sudo\nsudo {sys.executable} {kodirect_path} install-mac"
        )
        return
    LOGGER.info(f"created launchd plist at {launchd}")
    os.system(f"launchctl load -w {launchd}")


if __name__ == "__main__":
    cli()
