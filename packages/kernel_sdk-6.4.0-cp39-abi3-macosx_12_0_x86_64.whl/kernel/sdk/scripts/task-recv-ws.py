"""
Create a websocket server to mock kortex for receiving and writing task events to disk

Also listen to stdio for '5' key press, and write it as a task event to disk as well
"""

import asyncio
import json
import logging
import select
import sys
import termios
import time
import tty
from pathlib import Path

import websockets

# Configure logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# Global flag to manage shutdown
shutdown_requested = False

# same as defaults for kortex ws
WS_HOST = "127.0.0.1"
WS_PORT = 7892
OUTPUT_FILE = Path(__file__).parent / "task_events.json"

# make an async mutex for writing to the file
mutex = asyncio.Lock()


async def handle_messages(websocket, path=None):
    """
    Handle incoming WebSocket connections and write received JSON messages to a file.

    Args:
        websocket (websockets.WebSocketServerProtocol): The WebSocket connection
        path (str): The connection path (not used in this implementation)
    """
    try:
        # Get client address for logging
        client = websocket.remote_address
        logger.info(f"New connection from {client}")

        while True:

            try:
                message = await websocket.recv()
                # Parse the incoming message as JSON
                json_data = json.loads(message)

                await mutex.acquire()
                # Write the JSON message to a file
                with open(OUTPUT_FILE, "r") as f:
                    # read existing data, append to list
                    try:
                        existing_data = json.load(f)
                    except json.JSONDecodeError:
                        existing_data = []
                existing_data.append([time.time(), json_data])
                with open(OUTPUT_FILE, "w") as f:
                    json.dump(existing_data, f)
                mutex.release()
                logger.info(f"Received and saved message to {OUTPUT_FILE}")

            except json.JSONDecodeError:
                logger.error(f"Invalid JSON received: {message}")
            except websockets.ConnectionClosedOK:
                logger.info("Connection closed by client")
                break
    except Exception as e:
        logger.exception(f"Error handling message: {e}")
        raise e


KEYBOARD_EVENT_ID = 0


async def write_task_event():
    """
    Write a task event to disk when '5' key is pressed.
    """
    global KEYBOARD_EVENT_ID
    await mutex.acquire()
    # Write the task event to a file
    with open(OUTPUT_FILE, "r") as f:
        # read existing data, append to list
        try:
            existing_data = json.load(f)
        except json.JSONDecodeError:
            existing_data = []
    existing_data.append(
        [
            time.time(),
            {
                "timestamp": int(time.time() * 1e6),
                "event": "sync",
                "value": "",
                "id": KEYBOARD_EVENT_ID,
            },
        ]
    )
    KEYBOARD_EVENT_ID += 1
    with open(OUTPUT_FILE, "w") as f:
        json.dump(existing_data, f)
    mutex.release()


def is_input_available():
    """
    Check if input is available to be read.
    """
    return sys.stdin in select.select([sys.stdin], [], [], 0)[0]


EXIT_KEYS = set(["\x03", "\x1B"])  # Ctrl-C or esc


async def listen_for_key():
    """
    Async function to check for keyboard input without blocking.
    """
    # Save original terminal settings
    old_settings = termios.tcgetattr(sys.stdin)
    try:
        # Set terminal to raw mode
        tty.setraw(sys.stdin.fileno())

        while True:
            # Wait a bit to prevent high CPU usage
            await asyncio.sleep(0.1)

            # Check if input is available
            if is_input_available():
                # Read a single character
                key = sys.stdin.read(1)

                if key == "5":
                    logger.info("5 key pressed! Performing custom action...")
                    # Write task event to disk
                    await write_task_event()

                elif key in EXIT_KEYS:
                    raise KeyboardInterrupt

    except KeyboardInterrupt:
        raise

    except Exception as e:
        logger.error(f"Error in keyboard input: {e}")

    finally:
        # Restore original terminal settings
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old_settings)


async def start_server():
    """
    Start the WebSocket server.
    """

    # clear existing file
    with open(OUTPUT_FILE, "w") as f:
        json.dump([], f)
    server = await websockets.serve(
        handle_messages, WS_HOST, WS_PORT, ping_interval=20, ping_timeout=20
    )
    logger.info(f"WebSocket server started on ws://{WS_HOST}:{WS_PORT}")

    # Create tasks for server and keyboard listener
    try:
        # Use asyncio.gather to run tasks concurrently
        await asyncio.gather(server.wait_closed(), listen_for_key())
    except asyncio.CancelledError:
        logger.info("Server shutdown initiated")
    finally:
        server.close()
        await server.wait_closed()


def main():
    # Run the WebSocket server
    asyncio.run(start_server())


if __name__ == "__main__":
    main()
