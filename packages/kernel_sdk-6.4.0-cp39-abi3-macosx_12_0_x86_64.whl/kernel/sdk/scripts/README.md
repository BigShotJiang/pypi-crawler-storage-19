# kernel.sdk.scripts

## Description

Scripts for specialized applications of kernel.sdk

### kernel.sdk.scripts.kodirect

#### Description

Script to receive data from a GoDirect respiration belt and send to kortex data aquisition driver via TCP

##### Install prerequisites

See https://vernierst.github.io/godirect-examples/python/ for full installation instructions


###### Mac

```bash
brew install libusb
```

###### Python

```bash
pip install godirect pyyaml
```


##### Kortex configuration

`kodirect start` will emit TCP packets to 127.0.0.1:6766 by default, so your kortex.json configuration should include

```json
{
    "DAQSource": 
        {
			"name": "daq",
			"tcp_addr": "0.0.0.0:6766"
	}
}
```

in the "sources" section

##### kodirect Usage

kodirect will be installed as a console script when the shell environment is using a python environment with kernel.sdk installed (e.g. via pyenv / venv). The default ip/port/stream rate are 127.0.0.1:6766 and 100ms, but these may be overridden via cli arguments


###### Default args

```bash
kodirect start
```
###### Override args

```bash
kodirect start --port xxxx --ip xxx.xxx.xxx.xxx --stream_period 100
```

##### Monitor

When kodirect is connected to kortex and streaming data, you should see output like

```bash
sensor 1 values [-4.519508361816406]
sensor 2 values [0.0]
2022-04-29 17:39:24 [INFO] Kodirect: [[-4.51950836  0.        ]]
2022-04-29 17:39:24 [INFO] kernel.sdk.daq: Received event [#1 @ 1651279164777712128]
sensor 1 values [-4.519508361816406]
sensor 2 values [nan]
2022-04-29 17:39:24 [INFO] Kodirect: [[-4.51950836         nan]]
2022-04-29 17:39:24 [INFO] kernel.sdk.daq: Received event [#2 @ 1651279164870739968]
sensor 1 values [-4.522064208984375]
sensor 2 values [nan]
```

If this continues, you're good to go! You should leave this terminal window running as long as you want to be sending data to kortex.

kodirect will automatically restart in case of TCP or USB errors, with a 5 second delay between restarts. If there are errors, you should see a warning on the Portal UI


###### Connection refused

If you see repeated output like

```bash
ConnectionRefusedError: [Errno 61] Connection refused
```

Follow the acquisition driver documentation available in your organization settings at https://portal.kernel.com to restart kortex.

If it is running and the error persists, check that your kortex.json has the DAQSource section mentioned above in "Kortex configuration".

#### Install System service

You can install kodirect as a system service using 
```bash
kodirect install-mac
```

since you will need to run this as sudo, the above command will print further instructions like

```bash
sudo /absolute/path/to/python /absolute/path/to/python/site-packages/kernel/sdk/scipts/kodirect.py install-mac
```