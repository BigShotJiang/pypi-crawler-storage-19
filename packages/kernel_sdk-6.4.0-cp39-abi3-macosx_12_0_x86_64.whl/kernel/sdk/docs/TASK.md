# Task Client

Install `pip install kernel_sdk` into your environment and within the code of your task, use the following to send events:

```python
from kernel.sdk.task import TaskClient

tc = TaskClient(kortex_ip, kortex_port) # Pass debug=True to only log to console (good for testing tasks!)
```

# Available Methods
## experiment(num=1, type=None) task(num=1, type=None), block(num=1, type=None), trial(num=1, type=None)

If `num==1` (default): These will act as a context manager when you use a `with` statement. Internally, they will send a start/end event at the beginning/end of the context.

If `num>1`: These are iterators and are meant used with `for ... in ...` constructs. Internally, they will send a start/end event at the beginning/end of each loop as well as keep track of the current counter.

The counters always go up and never reset.

Calling `experiment()` is required and must be the first call made to task client.

New tasks can only happen within experiments, new blocks can only happen within tasks/experiments, and new trials can only happen within blocks/tasks/experiments.

If providing a `type`, they will send a type event. type also supports lambdas for dynamic execution and a list of types for specifying fixed types.

The return object from these methods supports `start()`/`stop()` (when you don't use a context), getting the current number with `current_count()`, and getting the current type with `current_type()`.

```python
import random

with tc.experiment() as e: # sends `start_experiment: 1`
    with tc.block(type='practice') as b: # sends `start_block: 1`
                                         # sends `block_type: 'practice'`
        for t in tc.trial(
          num=5,
          type=lambda n: random.choice(['left', 'right'])
        ): # sends `start_trial: 1 through 5`
           # `trial_type: 'left'` or 'right'

            print(e.current_count()) # prints 1
            print(b.current_count()) # prints 1
            print(t.current_count()) # prints 1 through 5

            print(b.current_type())    # prints 'practice'
            print(t.current_type())    # prints 'left' or 'right'

            # sends `end_trial: 1 through 5`
        # sends `end_block: 1`

    with tc.block(type='actual') as b: # sends `start_block: 2`
                                       # sends `block_type: 'actual'`
        with tc.trial() as t: # sends `start_trial: 6`
            print(e.current_count()) # prints 1
            print(b.current_count()) # prints 2
            print(t.current_count()) # prints 6

            print(b.current_type())    # prints 'actual'

            # sends `end_trial: 6`
        with tc.trial() as t: # sends `start_trial: 7`
            print(e.current_count()) # prints 1
            print(b.current_count()) # prints 2
            print(t.current_count()) # prints 7
            # sends `end_trial: 7`

        trial_list = ['type1', 'type2', 'type3']
        for tc.trial(num=6, type=trial_list):
            print(t.current_count(), t.current_type())
            # prints 8 type1
            # prints 9 type2
            # prints 10 type3
            # prints 11 type1
            # prints 12 type2
            # prints 13 type3

            # sends `end_trial: 8 through 13`

        # sends `end_block: 2`
    # sends `end_experiment: 1`

# no context manager
e = tc.experiment().start() # sends `start_experiment: 2`
print(e.current_count()) # prints 2
e.stop() # sends `end_experiment: 2`
```

## iti(time_in_seconds, sleep=time.sleep or lambda), inter_trial_interval(time_in_seconds, sleep=time.sleep or lambda)

Sends a `start_inter_trial_interval` event with the value being an incremented counter followed immediately by a `inter_trial_interval` event with the value being `time_in_seconds`. `sleep` is a lambda (default is `time.sleep`) and the lambda will be called with the `time_in_seconds` – this allows for custom high performance sleeps. Once the lambda returns, sends an `end_inter_trial_interval` event with the value being the same counter.

```python
with tc.experiment() as e:
    for t in tc.trial(num=10):
        # trial code
        tc.iti(5.3) # sends `start_inter_trial_interval: 1` (... through 10)
                    # sends `inter_trial_interval: 5.3`
                    # sleeps 5.3 seconds
        # sends `end_inter_trial_interval: 1` (... through 10, matches start)
```

## rest(time_in_seconds, sleep=time.sleep or lambda)

Sends a `start_rest` event with the value being an incremented counter followed immediately by a `rest_interval` event with the value being `time_in_seconds`. `sleep` is a lambda (default is `time.sleep`) and the lambda will be called with the `time_in_seconds` – this allows for custom high performance sleeps. Once the lambda returns, sends an `end_rest` event with the value being the same counter.

```python
with tc.experiment() as e:
    for t in tc.trial(num=10):
        # trial code
        tc.rest(5.3) # sends `start_rest: 1` (... through 10)
                     # sends `rest_interval: 5.3`
                     # sleeps 5.3 seconds
        # sends `end_rest: 1` (... through 10, matches start)
```

## stim(value, **kwargs), stimulus(value, **kwargs)

Sends a `stimulus` event. All kwargs will be sent up as individual events.

```python
with tc.experiment() as e:
    for t in tc.trial(max=9):
        key_to_press = get_random_key()
        tc.stim(key_to_press) # sends `stimulus: k`
with tc.experiment() as e:
    for t in tc.trial(max=10):
        photo_img, photo_gender, photo_age = random_photo()
        tc.stim(
            photo_img,
            photo_gender=photo_gender,
            photo_age=photo_age) # sends `stimulus: 'img_2345.png'
                                 # sends `photo_gender: 'male'`
                                 # sends `photo_age: 42`
        # show photo_img
```

## rt(), reaction_time()

Sends a `reaction_time` event as time from the given stimulus. Call on the return value of `stimulus()`. Returns the reaction time in seconds.

```python
with tc.experiment() as e:
    for t in tc.trial(max=9):
        key_to_press = get_random_key()
        s1 = tc.stim(key_to_press) # sends `stimulus: k`
        # show key to user
        s2 = tc.stim('photo323.png') # sends `stimulus: photo323.png`
        # show photo to user to distract
        # wait for key
        rt1 = s1.rt() # sends `reaction_time: 0.5` where 0.5 is the time from the stim s1 to this line.
        print(rt1) # prints 0.5
        tc.iti(5.0)
```

## sync(), flash()

Sends a start/end sync event with an incrementing counter. This acts as a context manager and should be used with the `with` statement.

```python
for e in tc.new_experiment():
    for t in tc.new_trial(max=10):
        with tc.sync(): # sends `start_sync: 1`
            # show white square
            # sleep
            # hide white square
        # sends `end_sync: 1`
```

## event(name), epoch(name)

This acts as a context manager and will send a `start_{name}` and `end_{name}` event with an incrementing counter and should be used with the `with` statement.

```python
with tc.event('instructions'): # sends `start_instructions: 1`
    pass # show instructions, wait for key
# sends `end_instructions: 1`

with tc.event('instructions'): # sends `start_instructions: 2`
    pass # show instructions, wait for key
# sends `end_instructions: 2`
```

## send_event(**kwargs)

This will send raw events, one for each `kwarg`.

```python
tc.send_event(pressed='k') # sends `pressed: 'k'`
```
