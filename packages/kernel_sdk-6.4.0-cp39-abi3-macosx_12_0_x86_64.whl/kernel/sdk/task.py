import json
import logging
import os
import platform
import sys
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from time import perf_counter, sleep
from typing import Callable, List, Optional, Union

from .client_core import DEFAULT_POST_SESSION_PATH, ClientProtocol, CoreClient
from .task_registry import TaskRegistry

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)


class InvalidTaskType(ValueError):
    """
    Thrown by TaskClient in case provided experiment type is not in the task registry
    """

    pass


class Stimulus:
    def __init__(self, task_client, start_time: float) -> None:
        self._task_client = task_client
        self._start_time = start_time

    def rt(self):
        """
        Sends a reaction_time event as time from the given stimulus.
        Call on the return value of stimulus().
        Returns the reaction time in seconds.
        """
        end_time = perf_counter()
        reaction_time = end_time - self._start_time
        self._task_client.send_event(reaction_time=reaction_time)
        return reaction_time

    reaction_time = rt  # alias


class Grouping:
    def __init__(
        self,
        task_client,
        name,
        num: int = 1,
        type: Optional[Union[str, Callable[[int], str], list]] = None,
    ) -> None:
        self._task_client = task_client
        self._name = name
        self._num: int = num
        self._type: Optional[Union[str, Callable[[int], str], list]] = type
        self._current_count: Optional[int] = None
        self._starting_count: Optional[int] = None
        self._current_type: Optional[str] = None

    # Start: No context manager

    def start(self):
        if self._num != 1:
            raise ValueError("cannot start unless num == 1")
        return self._next()

    def stop(self):
        if self._current_count is None:
            raise ValueError("cannot start unless started")
        try:
            self._next()
        except StopIteration:
            pass

    # End: No context manager

    # Start: Context manager

    def __enter__(self):
        if self._num != 1:
            raise ValueError("cannot use context unless num == 1")
        return self._next()

    def __exit__(self, exc_type, exc_value, exc_traceback):
        try:
            self._next()
        except StopIteration:
            pass

    # End: Context manager

    # Start: Loop

    def __iter__(self):
        return self

    def __next__(self):
        return self._next()

    # End: Loop

    def current_count(self):
        return self._current_count

    def current_type(self):
        return self._current_type

    def _next(self):
        if self._current_count is not None:
            self._task_client._send_end(self._name, self._current_count)

            if self._current_count + 1 - self._starting_count >= self._num:
                self._task_client._pop_grouping()
                raise StopIteration

        self._current_count = self._task_client._send_start(self._name)
        if self._starting_count is None:
            self._starting_count = self._current_count

        self._set_current_type()
        return self

    def _set_current_type(self):
        if self._type is None:
            return
        elif isinstance(self._type, str):
            self._current_type = self._type
        elif isinstance(self._type, TaskRegistry):
            self._current_type = self._type.value
        elif isinstance(self._type, list):
            self._current_type = self._type[
                (self._current_count - self._starting_count) % len(self._type)
            ]
        else:  # lambda
            self._current_type = self._type(self._current_count)

        self._task_client.send_event(
            **{"{}_type".format(self._name): self._current_type}
        )



class TaskClient(CoreClient):
    def __init__(
        self,
        multicast_ip: str,
        multicast_port: int,
        post_session_object_path: Optional[Path] =  None,
        debug: bool = False,
        experiment_name: Optional[str] = None,
        experiment_version: Optional[str] = None,
        enforce_registry_entry: bool = False,
        multicast_ttl_override: Optional[int] = None,
        protocol: ClientProtocol = ClientProtocol.UDP,
    ):
        if post_session_object_path is None:
            post_session_object_path = DEFAULT_POST_SESSION_PATH
        super().__init__(
            multicast_ip,
            multicast_port,
            post_session_object_path=post_session_object_path,
            debug=debug,
            multicast_ttl_override=multicast_ttl_override,
            protocol=protocol,
        )
        self.experiment_name = experiment_name
        self.experiment_version = experiment_version
        self.enforce_registry_entry = enforce_registry_entry

        meta_filename = "meta.json"
        if experiment_name is not None:
            start = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
            meta_filename = f"{start}-{experiment_name}-meta.json"

        self._meta_file = self._post_session_file(meta_filename)
        self._write_meta()

    def send_event(self, **kwargs):
        """
        This will send raw events, one for each `kwarg`.
        """

        timestamp = time.time()
        for name, value in kwargs.items():
            self._id += 1
            LOGGER.info(
                "Received event [#{} @ {}] {}: {}".format(
                    self._id, timestamp, name, value
                )
            )
            data_to_send = {
                "id": self._id,
                "timestamp": int(timestamp * 1e6),  # scale to microseconds
                "event": name,
                "value": str(value),
            }

            self._send_event(json.dumps(data_to_send).encode("utf-8"))

    def _push_grouping(self, name):
        if name == "experiment" and len(self._groupings) > 0:
            raise ValueError("can only start experiment at root")
        if name == "task" and (
            len(self._groupings) == 0 or self._groupings[-1] != "experiment"
        ):
            raise ValueError("can only start task within an experiment")
        if name == "block" and (
            len(self._groupings) == 0
            or self._groupings[-1] not in ["experiment", "task"]
        ):
            raise ValueError("can only start task within an experiment or task")
        if name == "trial" and (
            len(self._groupings) == 0
            or self._groupings[-1] not in ["experiment", "task", "block"]
        ):
            raise ValueError("can only start task within an experiment, task, or block")

        self._groupings.append(name)

    def _pop_grouping(self):
        # kortex deleted meta file?
        if not self._meta_file.exists():
            self._write_meta()

        self._groupings.pop()

    def experiment(
        self, num: int = 1, type: Optional[Union[str, Callable[[int], str]]] = None
    ):
        """
        If num==1 (default): These will act as a context manager when you use a with statement.
        Internally, they will send a start/end event at the beginning/end of the context.

        If num>1: These are iterators and are meant used with for ... in ... constructs.
        Internally, they will send a start/end event at the beginning/end of each loop
        as well as keep track of the current counter.

        The counters always go up and never reset.

        Calling experiment() is required and must be the first call made to task client.

        New tasks can only happen within experiments, new blocks can only happen within tasks/experiments,
        and new trials can only happen within blocks/tasks/experiments.

        If providing a type, they will send a type event. type also supports lambdas for dynamic execution.

        The return object from these methods supports start()/stop() (when you don't use a context),
        getting the current number with current_count(), and getting the current type with current_type().
        """
        try:
            registry_entry = TaskRegistry(type)
            self.send_event(
                experiment_meta=json.dumps(
                    {"task_urn": registry_entry.value, "meta": self.meta}
                )
            )
        except:
            invalid_exception = InvalidTaskType(
                f"Task {type} missing from registry - bad task configuration"
            )
            LOGGER.warning(invalid_exception)
            if self.enforce_registry_entry:
                raise invalid_exception

        self._push_grouping("experiment")
        return Grouping(self, "experiment", num, type)

    def task(
        self, num: int = 1, type: Optional[Union[str, Callable[[int], str]]] = None
    ):
        """
        If num==1 (default): These will act as a context manager when you use a with statement.
        Internally, they will send a start/end event at the beginning/end of the context.

        If num>1: These are iterators and are meant used with for ... in ... constructs.
        Internally, they will send a start/end event at the beginning/end of each loop
        as well as keep track of the current counter.

        The counters always go up and never reset.

        Calling experiment() is required and must be the first call made to task client.

        New tasks can only happen within experiments, new blocks can only happen within tasks/experiments,
        and new trials can only happen within blocks/tasks/experiments.

        If providing a type, they will send a type event. type also supports lambdas for dynamic execution.

        The return object from these methods supports start()/stop() (when you don't use a context),
        getting the current number with current_count(), and getting the current type with current_type().
        """
        self._push_grouping("task")
        return Grouping(self, "task", num, type)

    def block(
        self, num: int = 1, type: Optional[Union[str, Callable[[int], str]]] = None
    ):
        """
        If num==1 (default): These will act as a context manager when you use a with statement.
        Internally, they will send a start/end event at the beginning/end of the context.

        If num>1: These are iterators and are meant used with for ... in ... constructs.
        Internally, they will send a start/end event at the beginning/end of each loop
        as well as keep track of the current counter.

        The counters always go up and never reset.

        Calling experiment() is required and must be the first call made to task client.

        New tasks can only happen within experiments, new blocks can only happen within tasks/experiments,
        and new trials can only happen within blocks/tasks/experiments.

        If providing a type, they will send a type event. type also supports lambdas for dynamic execution.

        The return object from these methods supports start()/stop() (when you don't use a context),
        getting the current number with current_count(), and getting the current type with current_type().
        """
        self._push_grouping("block")
        return Grouping(self, "block", num, type)

    def trial(
        self,
        num: int = 1,
        type: Optional[Union[str, Callable[[int], str], list]] = None,
    ):
        """
        If num==1 (default): These will act as a context manager when you use a with statement.
        Internally, they will send a start/end event at the beginning/end of the context.

        If num>1: These are iterators and are meant used with for ... in ... constructs.
        Internally, they will send a start/end event at the beginning/end of each loop
        as well as keep track of the current counter.

        The counters always go up and never reset.

        Calling experiment() is required and must be the first call made to task client.

        New tasks can only happen within experiments, new blocks can only happen within tasks/experiments,
        and new trials can only happen within blocks/tasks/experiments.

        If providing a type, they will send a type event. type also supports lambdas for dynamic execution
        and lists for specifying fixed trial types when num>1

        The return object from these methods supports start()/stop() (when you don't use a context),
        getting the current number with current_count(), and getting the current type with current_type().
        """
        self._push_grouping("trial")
        return Grouping(self, "trial", num, type)

    def iti(self, time_in_seconds: float, sleep: Callable[[float], None] = sleep):
        """

        Sends a start_inter_trial_interval event with the value being an incremented counter
        followed immediately by an iti event with the value being time_in_seconds.

        sleep is a lambda (default is time.sleep) and the lambda will be called with the time_in_seconds.
        this allows for custom high performance sleeps.

        Once the lambda returns, sends an end_inter_trial_interval event with the value being the same counter.
        """
        with self.event("inter_trial_interval"):
            self.send_event(inter_trial_interval=time_in_seconds)
            sleep(time_in_seconds)

    inter_trial_interval = iti  # alias

    def rest(self, time_in_seconds: float, sleep: Callable[[float], None] = sleep):
        """
        Sends a start_rest event with the value being an incremented counter
        followed immediately by a rest_interval event with the value being time_in_seconds.

        sleep is a lambda (default is time.sleep) and the lambda will be called with the time_in_seconds.
        this allows for custom high performance sleeps.

        Once the lambda returns, sends an end_rest event with the value being the same counter.
        """
        with self.event("rest"):
            self.send_event(rest_interval=time_in_seconds)
            sleep(time_in_seconds)

    def cue(self, time_in_seconds: float, sleep: Callable[[float], None] = sleep):
        """
        Sends a start_cue event with the value being an incremented counter
        followed immediately by a cue_duration event with the value being time_in_seconds.

        sleep is a lambda (default is time.sleep) and the lambda will be called with the time_in_seconds.
        this allows for custom high performance sleeps.

        Once the lambda returns, sends an end_cue event with the value being the same counter.
        """
        with self.event("cue"):
            self.send_event(cue_duration=time_in_seconds)
            sleep(time_in_seconds)

    def stim(self, name: str, **kwargs):
        """
        Sends a stimulus event.
        All kwargs will be sent up as individual events.
        """
        start_time = perf_counter()
        self.send_event(stimulus=name, **kwargs)
        return Stimulus(self, start_time)

    stimulus = stim  # alias

    @contextmanager
    def sync(self):
        """
        Sends a start/end sync event with an incrementing counter. This acts as a context manager and should be used with the with statement.
        """
        yield from self.event("sync")

    flash = sync  # alias

    def _send_start(self, name: str):
        self._event_counter.update([name])
        current_count = self._event_counter[name]
        self.send_event(**{"start_{}".format(name): current_count})
        return current_count

    def _send_end(self, name: str, current_count: int):
        self.send_event(**{"end_{}".format(name): current_count})

    def _write_meta(self):
        git = None
        try:
            git = os.popen("git rev-parse HEAD").read().strip()
        except Exception:
            pass
        self.meta = {
            "cmd": sys.argv,
            "file": os.getcwd(),
            "git": git,
            "experiment_name": self.experiment_name,
            "experiment_version": self.experiment_version,
        }
        self._meta_file.write_text(json.dumps(self.meta))

    @contextmanager
    def event(self, name: str):
        """
        This acts as a context manager and will send a `start_{name}` and `end_{name}` event
        with an incrementing counter and should be used with the with statement.
        """
        current_count = self._send_start(name)
        yield current_count
        self._send_end(name, current_count)

    epoch = event  # alias

    @property
    def debug_events(self) -> List[dict]:
        return [json.loads(event.decode("utf-8")) for event in self._debug_events]
