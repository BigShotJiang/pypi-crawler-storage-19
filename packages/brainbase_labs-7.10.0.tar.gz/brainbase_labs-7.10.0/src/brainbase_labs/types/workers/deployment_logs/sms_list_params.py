# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from ...._utils import PropertyInfo

__all__ = ["SMSListParams"]


class SMSListParams(TypedDict, total=False):
    deployment_id: Annotated[str, PropertyInfo(alias="deploymentId")]

    flow_id: Annotated[str, PropertyInfo(alias="flowId")]

    limit: int

    page: int
