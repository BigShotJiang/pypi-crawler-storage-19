Sale Channel Module
###################
