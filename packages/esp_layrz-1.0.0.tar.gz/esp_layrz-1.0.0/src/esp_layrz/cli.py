import click
import serial.tools.list_ports
import shutil
import os
from rich.console import Console
from rich.table import Table
from .environment import run_idf, IDF_PATH, PYTHON_ENV

console = Console()

def find_esp_port():
    ports = serial.tools.list_ports.comports()
    for p in ports:
        desc = p.description.upper()
        if any(x in desc for x in ["CP210", "CH340", "USB SERIAL", "UART", "JTAG"]):
            return p.device
    return None

def get_port(user_port):
    if user_port: return user_port
    detected = find_esp_port()
    if detected:
        console.print(f"🔍 [green]Auto-detected ESP32 at {detected}[/green]")
        return detected
    return "COM4"

@click.group()
@click.option('--verbose', '-v', is_flag=True, help="Show all output, including deprecated warnings.")
@click.pass_context
def main(ctx, verbose):
    """esp-layrz: Professional ESP-IDF Shield Toolchain"""
    ctx.ensure_object(dict)
    ctx.obj['VERBOSE'] = verbose

@main.command(short_help="Show environment and path information.")
def info():
    """Displays the detected paths for ESP-IDF and Python environment."""
    table = Table(title="esp-layrz Environment Info")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="magenta")
    
    table.add_row("IDF_PATH", IDF_PATH)
    table.add_row("Python Executable", PYTHON_ENV)
    table.add_row("Project Root", os.getcwd())
    
    console.print(table)

@main.command(short_help="Run an incremental build.")
@click.pass_context
def build(ctx):
    run_idf(["build"], show_warnings=ctx.obj['VERBOSE'])

@main.command(context_settings=dict(ignore_unknown_options=True), short_help="Flash firmware.")
@click.option('--port', '-p', default=None)
@click.option('--baud', '-b', default=None)
@click.argument('extra_args', nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def flash(ctx, port, baud, extra_args):
    p = get_port(port)
    cmd = ["-p", p]
    if baud: cmd += ["-b", baud]
    cmd += ["flash"] + list(extra_args)
    run_idf(cmd, show_warnings=ctx.obj['VERBOSE'])

@main.command(context_settings=dict(ignore_unknown_options=True), short_help="Open monitor.")
@click.option('--port', '-p', default=None)
@click.argument('extra_args', nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def monitor(ctx, port, extra_args):
    p = get_port(port)
    cmd = ["-p", p, "monitor"] + list(extra_args)
    run_idf(cmd, show_warnings=ctx.obj['VERBOSE'])

@main.command(context_settings=dict(ignore_unknown_options=True), short_help="Generic passthrough for idf.py.")
@click.argument('idf_args', nargs=-1, type=click.UNPROCESSED)
@click.pass_context
def run(ctx, idf_args):
    """Pass any command directly to idf.py."""
    run_idf(list(idf_args), show_warnings=ctx.obj['VERBOSE'])

@main.command(short_help="Set target chip.")
@click.argument('target', type=click.Choice(['esp32', 'esp32s2', 'esp32s3', 'esp32c3', 'esp32c6']))
@click.pass_context
def set_target(ctx, target):
    console.print(f"🎯 [yellow]Setting target to:[/yellow] [bold cyan]{target}[/bold cyan]...")
    run_idf(['set-target', target], show_warnings=ctx.obj['VERBOSE'])

@main.command(short_help="Full project clean.")
def full_clean():
    if os.path.exists("build"):
        shutil.rmtree("build")
    if os.path.exists("sdkconfig"):
        os.remove("sdkconfig")
    console.print("🧹 [green]Project cleaned successfully.[/green]")

if __name__ == '__main__':
    main()