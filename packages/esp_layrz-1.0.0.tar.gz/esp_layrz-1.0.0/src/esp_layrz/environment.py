import os
import sys
import subprocess
import glob
from rich.console import Console

console = Console()

def get_idf_path():
    """Detects the ESP-IDF framework path dynamically."""
    # 1. Variable de entorno (Estándar de Espressif)
    env_path = os.environ.get("IDF_PATH")
    if env_path and os.path.exists(env_path):
        return env_path
    
    # 2. Búsqueda dinámica en carpetas estándar
    default_base = r"C:\Espressif\frameworks"
    if os.path.exists(default_base):
        subfolders = glob.glob(os.path.join(default_base, "esp-idf-*"))
        if subfolders:
            return max(subfolders, key=os.path.getmtime)
            
    return r"C:\Espressif\frameworks\esp-idf-v5.5.2"

# USAR EL MISMO PYTHON QUE EJECUTA ESTE SCRIPT
# Esto elimina el conflicto entre Python 3.11 y 3.12
PYTHON_ENV = sys.executable 

IDF_PATH = get_idf_path()
IDF_PY = os.path.join(IDF_PATH, "tools", "idf.py")

def run_idf(args, show_warnings=False):
    """Executes idf.py commands with real-time filtering and environment isolation."""
    if not os.path.exists(IDF_PY):
        console.print(f"[bold red]Error: idf.py not found at {IDF_PY}[/bold red]")
        return 1

    # Preparar entorno aislado
    env = os.environ.copy()
    env["IDF_PATH"] = IDF_PATH
    env["IDF_SKIP_CHECK_PYTHON_REQUIREMENTS"] = "1"
    
    # Priorizar el directorio del Python actual en el PATH
    python_dir = os.path.dirname(PYTHON_ENV)
    env["PATH"] = python_dir + os.pathsep + env.get("PATH", "")

    cmd = [PYTHON_ENV, IDF_PY] + args

    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            env=env
        )

        for line in process.stdout:
            # Filtro de estética: oculta warnings de esptool por defecto
            if not show_warnings and "Warning: Deprecated" in line:
                continue
            
            sys.stdout.write(line)
            sys.stdout.flush()

        process.wait()
        return process.returncode

    except Exception as e:
        console.print(f"[bold red]Execution error: {e}[/bold red]")
        return 1
