"""FFmpeg MCP tools."""
