import httpx
from bs4 import BeautifulSoup
from mcp.server.fastmcp import FastMCP

# 创建 MCP Server 实例
mcp = FastMCP("url-content-extractor")


@mcp.tool()
async def fetch_url_content(url: str) -> str:
    """
    抓取指定 URL 的网页正文内容。

    Args:
        url: 要抓取的网页 URL

    Returns:
        网页的纯文本正文内容
    """
    try:
        # 设置请求头，模拟浏览器访问
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }

        # 异步请求网页
        async with httpx.AsyncClient(follow_redirects=True, timeout=30.0) as client:
            response = await client.get(url, headers=headers)
            response.raise_for_status()

        # 解析 HTML
        soup = BeautifulSoup(response.text, "html.parser")

        # 移除不需要的元素（脚本、样式、导航等）
        for element in soup(["script", "style", "nav", "header", "footer", "aside", "noscript"]):
            element.decompose()

        # 尝试提取主要内容区域
        main_content = (
            soup.find("main")
            or soup.find("article")
            or soup.find(class_=["content", "main-content", "post-content", "article-content"])
            or soup.find(id=["content", "main-content", "post-content", "article-content"])
            or soup.body
        )

        if main_content:
            # 获取纯文本并清理空白
            text = main_content.get_text(separator="\n", strip=True)
            # 清理多余的空行
            lines = [line.strip() for line in text.splitlines() if line.strip()]
            return "\n\n".join(lines)
        else:
            return "无法提取网页内容"

    except httpx.HTTPStatusError as e:
        return f"HTTP 错误: {e.response.status_code}"
    except httpx.RequestError as e:
        return f"请求错误: {str(e)}"
    except Exception as e:
        return f"抓取失败: {str(e)}"


def main():
    """MCP Server 入口函数"""
    mcp.run()


if __name__ == "__main__":
    main()
