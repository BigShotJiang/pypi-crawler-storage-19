# url-content-extractor

一个简单的 MCP Server，提供 `fetch_url_content` 工具，用于抓取网页正文。

## 功能

- 支持抓取任意 URL 的正文内容。
- 自动提取主要内容区域（`<main>`, `<article>` 等）。
- 移除干扰元素（脚本、样式、导航栏等）。

## 安装

你可以通过 `uvx` 直接运行：

```bash
uvx url-content-extractor
```

或者通过 `pip` 安装：

```bash
pip install url-content-extractor
```

## MCP 配置

在 Cursor 或 Claude Desktop 的 MCP 配置文件中添加：

```json
{
  "mcpServers": {
    "url-content-extractor": {
      "command": "uvx",
      "args": ["url-content-extractor"]
    }
  }
}
```

## 开发

1. 克隆仓库
2. 使用 `uv sync` 安装依赖
3. 运行 `uv run server.py` 启动服务
