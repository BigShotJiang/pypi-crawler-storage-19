# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListVhostsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'size': 'int',
        'total': 'int',
        'items': 'list[ShowVhostDetailResp]'
    }

    attribute_map = {
        'size': 'size',
        'total': 'total',
        'items': 'items'
    }

    def __init__(self, size=None, total=None, items=None):
        r"""ListVhostsResponse

        The model defined in huaweicloud sdk

        :param size: **参数解释**： 当前显示的Vhost数量 **取值范围**： 不涉及。
        :type size: int
        :param total: **参数解释**： 查询到的Vhost总数 **取值范围**： 不涉及。
        :type total: int
        :param items: **参数解释**： 查询的Vhost信息列表
        :type items: list[:class:`huaweicloudsdkrabbitmq.v2.ShowVhostDetailResp`]
        """
        
        super().__init__()

        self._size = None
        self._total = None
        self._items = None
        self.discriminator = None

        if size is not None:
            self.size = size
        if total is not None:
            self.total = total
        if items is not None:
            self.items = items

    @property
    def size(self):
        r"""Gets the size of this ListVhostsResponse.

        **参数解释**： 当前显示的Vhost数量 **取值范围**： 不涉及。

        :return: The size of this ListVhostsResponse.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        r"""Sets the size of this ListVhostsResponse.

        **参数解释**： 当前显示的Vhost数量 **取值范围**： 不涉及。

        :param size: The size of this ListVhostsResponse.
        :type size: int
        """
        self._size = size

    @property
    def total(self):
        r"""Gets the total of this ListVhostsResponse.

        **参数解释**： 查询到的Vhost总数 **取值范围**： 不涉及。

        :return: The total of this ListVhostsResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListVhostsResponse.

        **参数解释**： 查询到的Vhost总数 **取值范围**： 不涉及。

        :param total: The total of this ListVhostsResponse.
        :type total: int
        """
        self._total = total

    @property
    def items(self):
        r"""Gets the items of this ListVhostsResponse.

        **参数解释**： 查询的Vhost信息列表

        :return: The items of this ListVhostsResponse.
        :rtype: list[:class:`huaweicloudsdkrabbitmq.v2.ShowVhostDetailResp`]
        """
        return self._items

    @items.setter
    def items(self, items):
        r"""Sets the items of this ListVhostsResponse.

        **参数解释**： 查询的Vhost信息列表

        :param items: The items of this ListVhostsResponse.
        :type items: list[:class:`huaweicloudsdkrabbitmq.v2.ShowVhostDetailResp`]
        """
        self._items = items

    def to_dict(self):
        import warnings
        warnings.warn("ListVhostsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListVhostsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
