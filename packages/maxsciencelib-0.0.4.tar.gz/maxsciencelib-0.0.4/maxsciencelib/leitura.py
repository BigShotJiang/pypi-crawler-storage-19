import os
import sys
import warnings
import snowflake.connector
import pandas as pd
import polars as pl


def ler_excel(caminho):
    df = pd.read_excel(f'{caminho}'.xlsx)
    return df

def leitura_snowflake(
    email_corporativo: str,
    token_account: str,
    query: str
) -> pl.DataFrame:
    """
    Executa uma query no Snowflake e retorna um DataFrame Polars.

    Parâmetros
    ----------
    email_corporativo : str
        Email corporativo usado no login (externalbrowser)
    token_account : str
        Account do Snowflake
    query : str
        Query SQL a ser executada

    Retorno
    -------
    pl.DataFrame
    """

    warnings.filterwarnings("ignore", message=".*keyring.*")

    sys_stdout, sys_stderr = sys.stdout, sys.stderr

    try:
        sys.stdout = open(os.devnull, 'w')
        sys.stderr = open(os.devnull, 'w')

        conn = snowflake.connector.connect(
            user=email_corporativo,
            account=token_account,
            database='MAXPAR',
            schema='ESTATISTICA',
            role='GL_SNOWFLAKE_ACESSO_MAX_CED_DADOS',
            warehouse='WH_USE_CED',
            authenticator='externalbrowser',
            network_timeout=600
        )

        cursor = conn.cursor()
        try:
            cursor.execute(query)

            # 🔥 Snowflake -> Arrow -> Polars
            arrow_table = cursor.fetch_arrow_all()
            df = pl.from_arrow(arrow_table)

        finally:
            cursor.close()

    finally:
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout, sys.stderr = sys_stdout, sys_stderr

        try:
            conn.close()
        except Exception:
            pass

    return df
