"""Tests for riff-observe."""
