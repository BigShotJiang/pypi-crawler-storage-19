"""
MAG controller tools.
"""
