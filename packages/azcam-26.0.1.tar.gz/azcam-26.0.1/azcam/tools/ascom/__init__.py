"""
ASCOM camera tools.
"""
