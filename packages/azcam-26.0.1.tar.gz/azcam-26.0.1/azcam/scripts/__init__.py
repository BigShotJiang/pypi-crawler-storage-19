"""
azcamserver scripts
"""
