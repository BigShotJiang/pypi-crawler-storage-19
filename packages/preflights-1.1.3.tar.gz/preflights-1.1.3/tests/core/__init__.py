"""Preflights Core tests."""
