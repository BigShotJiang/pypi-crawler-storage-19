"""Preflights CLI."""
