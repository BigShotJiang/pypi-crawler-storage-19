"""Tests for path derivation."""

from pathlib import Path

import pytest

from legionnaire.paths import (
    NotInGitRepoError,
    child_branch_name,
    child_worktree_path,
    get_repo_root,
    get_worktrees_root,
    parent_branch_name,
    parent_dir,
    parent_worktree_path,
)


class TestGetRepoRoot:
    """Tests for get_repo_root function."""

    def test_finds_repo_root(self, git_repo: Path):
        result = get_repo_root(git_repo)
        assert result == git_repo

    def test_finds_repo_from_subdir(self, git_repo: Path):
        subdir = git_repo / "subdir"
        subdir.mkdir()
        result = get_repo_root(subdir)
        assert result == git_repo

    def test_raises_when_not_in_repo(self, tmp_path: Path):
        not_a_repo = tmp_path / "not_a_repo"
        not_a_repo.mkdir()
        with pytest.raises(NotInGitRepoError, match="Not in a git repository"):
            get_repo_root(not_a_repo)


class TestGetWorktreesRoot:
    """Tests for get_worktrees_root function."""

    def test_worktrees_root_sibling(self):
        repo_root = Path("/home/user/src/my-project")
        result = get_worktrees_root(repo_root)
        assert result == Path("/home/user/src/my-project_worktrees")

    def test_worktrees_root_preserves_name(self):
        repo_root = Path("/repos/slurm-sdk")
        result = get_worktrees_root(repo_root)
        assert result == Path("/repos/slurm-sdk_worktrees")


class TestParentDir:
    """Tests for parent_dir function."""

    def test_simple_parent_id(self):
        worktrees_root = Path("/repos/project_worktrees")
        result = parent_dir(worktrees_root, "feature-x")
        assert result == Path("/repos/project_worktrees/feature-x")

    def test_nested_parent_id(self):
        worktrees_root = Path("/repos/project_worktrees")
        result = parent_dir(worktrees_root, "team-a/feature-x")
        assert result == Path("/repos/project_worktrees/team-a/feature-x")


class TestParentWorktreePath:
    """Tests for parent_worktree_path function."""

    def test_adds_parent_suffix(self):
        worktrees_root = Path("/repos/project_worktrees")
        result = parent_worktree_path(worktrees_root, "feature-x")
        assert result == Path("/repos/project_worktrees/feature-x/parent")

    def test_nested_parent_id(self):
        worktrees_root = Path("/repos/project_worktrees")
        result = parent_worktree_path(worktrees_root, "team/feature")
        assert result == Path("/repos/project_worktrees/team/feature/parent")


class TestChildWorktreePath:
    """Tests for child_worktree_path function."""

    def test_child_path(self):
        worktrees_root = Path("/repos/project_worktrees")
        result = child_worktree_path(worktrees_root, "feature-x", "task-1")
        assert result == Path("/repos/project_worktrees/feature-x/task-1")

    def test_nested_parent(self):
        worktrees_root = Path("/repos/project_worktrees")
        result = child_worktree_path(worktrees_root, "team/feature", "task")
        assert result == Path("/repos/project_worktrees/team/feature/task")


class TestBranchNames:
    """Tests for branch name functions."""

    def test_parent_branch_name(self):
        assert parent_branch_name("feature-x") == "feature-x/parent"

    def test_parent_branch_name_nested(self):
        assert parent_branch_name("team/feature") == "team/feature/parent"

    def test_child_branch_name(self):
        assert child_branch_name("feature-x", "task-1") == "feature-x/task-1"

    def test_child_branch_name_nested_parent(self):
        assert child_branch_name("team/feature", "task") == "team/feature/task"
