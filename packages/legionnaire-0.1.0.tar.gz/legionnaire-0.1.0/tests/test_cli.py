"""Tests for CLI commands."""

from pathlib import Path

from legionnaire.cli import create_parser, main


class TestParser:
    """Tests for argument parsing."""

    def test_init_parser(self):
        parser = create_parser()
        args = parser.parse_args(["init", "my-parent"])
        assert args.command == "init"
        assert args.parent == "my-parent"
        assert args.children == []
        assert args.agent == "claude"

    def test_init_with_children(self):
        parser = create_parser()
        args = parser.parse_args(["init", "parent", "child1", "child2"])
        assert args.parent == "parent"
        assert args.children == ["child1", "child2"]

    def test_init_with_options(self):
        parser = create_parser()
        args = parser.parse_args(
            [
                "init",
                "parent",
                "--agent",
                "cursor",
                "--no-tmux",
                "--dry-run",
                "--verbose",
            ]
        )
        assert args.agent == "cursor"
        assert args.no_tmux is True
        assert args.dry_run is True
        assert args.verbose is True

    def test_remove_parser(self):
        parser = create_parser()
        args = parser.parse_args(["remove", "my-parent"])
        assert args.command == "remove"
        assert args.parent == "my-parent"
        assert args.children == []

    def test_remove_with_children(self):
        parser = create_parser()
        args = parser.parse_args(["remove", "parent", "child1"])
        assert args.children == ["child1"]

    def test_remove_with_force(self):
        parser = create_parser()
        args = parser.parse_args(["remove", "parent", "--force"])
        assert args.force is True

    def test_list_all_parents(self):
        parser = create_parser()
        args = parser.parse_args(["list"])
        assert args.command == "list"
        assert args.parent is None

    def test_list_specific_parent(self):
        parser = create_parser()
        args = parser.parse_args(["list", "my-parent"])
        assert args.parent == "my-parent"


class TestInitCommand:
    """Integration tests for init command."""

    def test_init_dry_run(self, git_repo: Path, capsys):
        """Test init with --dry-run doesn't create anything."""
        import sys

        original_argv = sys.argv
        try:
            sys.argv = [
                "legion",
                "init",
                "test-parent",
                "--repo",
                str(git_repo),
                "--dry-run",
                "--no-tmux",
            ]
            result = main()
            assert result == 0

            # Check nothing was created
            worktrees_root = git_repo.parent / f"{git_repo.name}_worktrees"
            assert not worktrees_root.exists()
        finally:
            sys.argv = original_argv

    def test_init_creates_parent_worktree(self, git_repo: Path):
        """Test init creates parent worktree."""
        import sys

        original_argv = sys.argv
        try:
            sys.argv = ["legion", "init", "test-parent", "--repo", str(git_repo), "--no-tmux"]
            result = main()
            assert result == 0

            # Check worktree was created
            worktrees_root = git_repo.parent / f"{git_repo.name}_worktrees"
            parent_wt = worktrees_root / "test-parent" / "parent"
            assert parent_wt.exists()
            assert (parent_wt / ".git").exists()
        finally:
            sys.argv = original_argv

    def test_init_creates_children(self, git_repo: Path):
        """Test init creates child worktrees."""
        import sys

        original_argv = sys.argv
        try:
            sys.argv = [
                "legion",
                "init",
                "test-parent",
                "child-a",
                "child-b",
                "--repo",
                str(git_repo),
                "--no-tmux",
            ]
            result = main()
            assert result == 0

            worktrees_root = git_repo.parent / f"{git_repo.name}_worktrees"
            child_a = worktrees_root / "test-parent" / "child-a"
            child_b = worktrees_root / "test-parent" / "child-b"
            assert child_a.exists()
            assert child_b.exists()
        finally:
            sys.argv = original_argv

    def test_init_is_idempotent(self, git_repo: Path):
        """Test init can be run multiple times safely."""
        import sys

        original_argv = sys.argv
        try:
            sys.argv = [
                "legion",
                "init",
                "test-parent",
                "child",
                "--repo",
                str(git_repo),
                "--no-tmux",
            ]

            # First run
            result1 = main()
            assert result1 == 0

            # Second run (should be idempotent)
            result2 = main()
            assert result2 == 0

            worktrees_root = git_repo.parent / f"{git_repo.name}_worktrees"
            child_wt = worktrees_root / "test-parent" / "child"
            assert child_wt.exists()
        finally:
            sys.argv = original_argv


class TestRemoveCommand:
    """Integration tests for remove command."""

    def test_remove_child(self, git_repo: Path):
        """Test removing a specific child."""
        import sys

        original_argv = sys.argv
        try:
            # First create
            sys.argv = [
                "legion",
                "init",
                "test-parent",
                "child-a",
                "child-b",
                "--repo",
                str(git_repo),
                "--no-tmux",
            ]
            main()

            worktrees_root = git_repo.parent / f"{git_repo.name}_worktrees"

            # Then remove child-a
            sys.argv = ["legion", "remove", "test-parent", "child-a", "--repo", str(git_repo)]
            result = main()
            assert result == 0

            # child-a should be gone, child-b should remain
            assert not (worktrees_root / "test-parent" / "child-a").exists()
            assert (worktrees_root / "test-parent" / "child-b").exists()
        finally:
            sys.argv = original_argv

    def test_remove_parent_removes_all(self, git_repo: Path):
        """Test removing parent removes everything."""
        import sys

        original_argv = sys.argv
        try:
            # First create
            sys.argv = [
                "legion",
                "init",
                "test-parent",
                "child",
                "--repo",
                str(git_repo),
                "--no-tmux",
            ]
            main()

            worktrees_root = git_repo.parent / f"{git_repo.name}_worktrees"

            # Then remove parent
            sys.argv = ["legion", "remove", "test-parent", "--repo", str(git_repo), "--force"]
            result = main()
            assert result == 0

            # Everything should be gone
            assert not (worktrees_root / "test-parent").exists()
        finally:
            sys.argv = original_argv


class TestListCommand:
    """Integration tests for list command."""

    def test_list_empty(self, git_repo: Path, capsys):
        """Test list when no parents exist."""
        import sys

        original_argv = sys.argv
        try:
            sys.argv = ["legion", "list", "--repo", str(git_repo)]
            result = main()
            assert result == 0

            captured = capsys.readouterr()
            assert "No parents found" in captured.out
        finally:
            sys.argv = original_argv

    def test_list_shows_parents(self, git_repo: Path, capsys):
        """Test list shows existing parents."""
        import sys

        original_argv = sys.argv
        try:
            # Create a parent
            sys.argv = ["legion", "init", "test-parent", "--repo", str(git_repo), "--no-tmux"]
            main()

            # List
            sys.argv = ["legion", "list", "--repo", str(git_repo)]
            result = main()
            assert result == 0

            captured = capsys.readouterr()
            assert "test-parent" in captured.out
        finally:
            sys.argv = original_argv

    def test_list_parent_children(self, git_repo: Path, capsys):
        """Test list shows children of a parent."""
        import sys

        original_argv = sys.argv
        try:
            # Create parent with children
            sys.argv = [
                "legion",
                "init",
                "test-parent",
                "child-a",
                "child-b",
                "--repo",
                str(git_repo),
                "--no-tmux",
            ]
            main()

            # List children
            sys.argv = ["legion", "list", "test-parent", "--repo", str(git_repo)]
            result = main()
            assert result == 0

            captured = capsys.readouterr()
            assert "child-a" in captured.out
            assert "child-b" in captured.out
        finally:
            sys.argv = original_argv
