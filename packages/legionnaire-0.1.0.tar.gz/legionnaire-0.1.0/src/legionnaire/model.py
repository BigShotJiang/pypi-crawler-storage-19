"""Data models for Legionnaire."""

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path


class AgentType(Enum):
    """Supported LLM agent types."""

    CLAUDE = "claude"
    CURSOR = "cursor"


class AgentStatus(Enum):
    """Status of an agent process."""

    RUNNING = "running"
    STOPPED = "stopped"
    UNKNOWN = "unknown"


@dataclass
class WorktreeEntry:
    """Represents a git worktree from 'git worktree list --porcelain'."""

    path: Path
    head: str | None = None
    branch: str | None = None
    bare: bool = False
    detached: bool = False
    locked: bool = False
    prunable: bool = False


@dataclass
class ChildInfo:
    """Information about a child worktree/window."""

    child_id: str
    parent_id: str
    worktree_path: Path | None = None
    branch: str | None = None
    tmux_window_exists: bool = False
    agent_status: AgentStatus = AgentStatus.UNKNOWN
    agent_pid: int | None = None


@dataclass
class ParentInfo:
    """Information about a parent worktree/session."""

    parent_id: str
    worktree_path: Path | None = None
    branch: str | None = None
    tmux_session_exists: bool = False
    tmux_session_managed: bool = False
    children: list[ChildInfo] = field(default_factory=list)
