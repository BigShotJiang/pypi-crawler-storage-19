"""Legionnaire: CLI tool for orchestrating git worktrees + tmux + LLM CLIs."""

__version__ = "0.1.0"
