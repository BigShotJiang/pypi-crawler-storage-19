# Legionnaire

CLI tool that orchestrates git worktrees + tmux + LLM CLIs using a two-layer parent/child model.

## Installation

```bash
uv add legionnaire
```

## Usage

### Initialize a parent with children

```bash
legion init perf-logging schema-v2 report-generator
```

### List parents and children

```bash
legion list                 # List all parents
legion list perf-logging    # List children of a parent
```

### Remove worktrees

```bash
legion remove perf-logging schema-v2    # Remove specific child
legion remove perf-logging              # Remove parent and all children
```

## Development

```bash
# Install dependencies
uv sync

# Run tests
uv run pytest

# Lint
uv run ruff check --fix
```
