# Tutorials

Tutorials are **learning-oriented** lessons that guide you through practical exercises to build competence with Legionnaire.

## Available Tutorials

### [Getting Started](getting-started.md)

Your first steps with Legionnaire. Learn how to:

- Set up a parent worktree
- Create child worktrees for parallel work
- Navigate between windows
- Clean up when you're done

## What You'll Learn

By completing these tutorials, you will understand:

- The parent/child hierarchy model
- How git worktrees integrate with tmux
- Basic workflow patterns for parallel LLM-driven development
