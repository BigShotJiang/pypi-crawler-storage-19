# Legionnaire

Legionnaire is a CLI tool that orchestrates **git worktrees + tmux + LLM CLIs** using a two-layer parent/child model.

## What is Legionnaire?

Legionnaire makes it trivial to spin up parallel LLM-driven work items with:

- Dedicated git worktrees and branches
- Deterministic tmux session/window structure
- Deterministic per-window colors
- Easy listing and clean removal

## Two-Level Hierarchy

Legionnaire uses a simple hierarchy:

- **Parent** = Integration branch/worktree and tmux session
- **Child** = Feature branch/worktree and tmux window inside parent session

```mermaid
graph TD
    P[Parent: perf-logging] --> C1[Child: schema-v2]
    P --> C2[Child: report-generator]
    P --> C3[Child: tests]

    subgraph tmux session
        P
        C1
        C2
        C3
    end
```

## Quick Start

```bash
# Initialize a parent with children
legion init perf-logging schema-v2 report-generator

# List what exists
legion list perf-logging

# Remove a child
legion remove perf-logging schema-v2

# Remove everything
legion remove perf-logging
```

## Documentation Structure

This documentation follows the [Diataxis framework](https://diataxis.fr/):

- **[Tutorials](tutorials/index.md)** - Learning-oriented lessons to get you started
- **[How-To Guides](how-to/index.md)** - Task-oriented guides for specific goals
- **[Reference](reference/index.md)** - Technical specifications and API documentation
- **[Explanation](explanation/index.md)** - Understanding-oriented discussion of concepts

## Installation

```bash
# Using uv
uv add legionnaire

# Using pip
pip install legionnaire
```

## Requirements

- Python 3.11+
- tmux (for session management)
- Git
