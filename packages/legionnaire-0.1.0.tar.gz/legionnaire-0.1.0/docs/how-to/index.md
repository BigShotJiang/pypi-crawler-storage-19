# How-To Guides

How-to guides are **task-oriented** recipes that help you accomplish specific goals with Legionnaire.

## Available Guides

### Setup & Initialization

- [Initialize a Project](initialize-project.md) - Set up parents and children

### Day-to-Day Operations

- [Manage Children](manage-children.md) - Add, list, and work with children

### Cleanup & Maintenance

- [Remove Worktrees](remove-worktrees.md) - Clean up children and parents

### Configuration

- [Configure tmux](configure-tmux.md) - Optimize tmux for pane splits in worktrees

## Quick Reference

| Task | Command |
|------|---------|
| Create parent only | `legion init my-feature` |
| Create with children | `legion init my-feature child1 child2` |
| Add child to existing | `legion init my-feature new-child` |
| List all parents | `legion list` |
| List children | `legion list my-feature` |
| Remove child | `legion remove my-feature child1` |
| Remove everything | `legion remove my-feature` |
