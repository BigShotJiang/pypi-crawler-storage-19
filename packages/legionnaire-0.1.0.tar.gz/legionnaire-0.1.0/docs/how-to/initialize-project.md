# How to Initialize a Project

## Problem

You want to set up a new Legionnaire parent with optional children for parallel work.

## Prerequisites

- Inside a git repository
- tmux available (or use `--no-tmux`)

## Steps

### 1. Create a Parent Only

```bash
legion init my-feature
```

This creates:
- Worktree: `../<repo>_worktrees/my-feature/parent`
- Branch: `my-feature/parent`
- tmux session: `my-feature`

### 2. Create Parent with Children

```bash
legion init my-feature task-a task-b task-c
```

Each child gets its own worktree, branch, and tmux window.

### 3. Add Children to Existing Parent

Run `init` again with new children:

```bash
legion init my-feature task-d
```

Existing children are preserved; new ones are added.

### 4. Use a Different Agent

```bash
legion init my-feature task-a --agent cursor
```

Options: `claude` (default), `cursor`

### 5. Skip Agent Launch

```bash
legion init my-feature task-a --no-agent
```

Creates worktrees and windows but doesn't start agents.

### 6. Git-Only Mode

```bash
legion init my-feature task-a --no-tmux
```

Creates worktrees and branches without tmux sessions.

## Verification

Check what was created:

```bash
legion list my-feature
```

## Troubleshooting

**Session name conflict:**
If a tmux session with the same name exists and wasn't created by Legionnaire:

```
Error: Session 'my-feature' exists but is not managed by Legionnaire.
```

Solution: Rename the existing session or choose a different parent name.

**Not in a git repo:**

```
Error: Not in a git repository
```

Solution: Navigate to a git repository first.

## See Also

- [CLI Reference: init](../reference/cli.md#init)
- [Managing Children](manage-children.md)
