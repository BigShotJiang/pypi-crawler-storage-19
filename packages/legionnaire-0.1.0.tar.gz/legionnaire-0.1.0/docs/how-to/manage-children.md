# How to Manage Children

## Problem

You need to add, list, or work with child worktrees in an existing parent.

## Prerequisites

- An existing parent (created with `legion init`)

## Steps

### Add New Children

```bash
legion init my-feature new-child-1 new-child-2
```

This is idempotent: existing children are unchanged, new ones are added.

### List Children

```bash
legion list my-feature
```

Shows each child with:
- Branch name
- Worktree path
- tmux window status
- Agent status (running/stopped/unknown)

### View All Parents

```bash
legion list
```

Shows all parents with child counts.

### Navigate to Child Worktree

Each child's worktree is at:

```
../<repo>_worktrees/<parent>/<child>/
```

For example:
```bash
cd ../my-repo_worktrees/my-feature/task-a/
```

### Attach to tmux Session

```bash
tmux attach -t my-feature
```

Navigate windows:
- `Ctrl+b 0` - Parent window
- `Ctrl+b 1` - First child
- `Ctrl+b n` - Next window
- `Ctrl+b p` - Previous window

### Work Across Children

Each child has:
- Independent working directory
- Separate git branch
- Own agent process

Changes in one child don't affect others until merged.

## Verification

Check agent status:

```bash
legion list my-feature -v
```

Verbose output shows paths and PIDs.

## See Also

- [Initialize a Project](initialize-project.md)
- [Remove Worktrees](remove-worktrees.md)
