# How to Configure tmux for Legionnaire

## Problem

When you split a pane in a Legionnaire child window, the new pane may open in an unexpected directory instead of the child's worktree.

## Prerequisites

- tmux installed and running
- Basic familiarity with tmux configuration

## Solution

Add these lines to your `~/.tmux.conf`:

```bash
# Split panes using the current pane's working directory
bind-key % split-window -h -c "#{pane_current_path}"
bind-key '"' split-window -v -c "#{pane_current_path}"

# Also apply to new windows
bind-key c new-window -c "#{pane_current_path}"
```

After editing, reload your tmux configuration:

```bash
tmux source-file ~/.tmux.conf
```

## Verification

1. Start a Legionnaire session: `legion init my-feature task1`
2. Attach to the session: `tmux attach -t my-feature`
3. Navigate to a child window
4. Split the pane with `prefix + %` or `prefix + "`
5. Verify the new pane opens in the child's worktree

## Why This Is Needed

By default, tmux's `split-window` command doesn't inherit the current pane's working directory. Instead, it may use:

- The directory where the tmux server was started
- The session's default directory
- Your home directory

The `#{pane_current_path}` variable tells tmux to use the current pane's actual working directory, which is what Legionnaire sets for each child window.

## See Also

- [Initialize a Project](initialize-project.md)
- [Architecture](../explanation/architecture.md) - Understanding the tmux integration
