# How to Remove Worktrees

## Problem

You need to clean up child worktrees, parent worktrees, or everything.

## Prerequisites

- Existing parent/children to remove

## Steps

### Remove Specific Children

```bash
legion remove my-feature child-a child-b
```

This removes:
- tmux windows
- Agent processes
- Git worktrees
- Git branches

### Remove All Children and Parent

```bash
legion remove my-feature
```

Without specifying children, removes everything.

### Force Remove Dirty Worktrees

If a worktree has uncommitted changes:

```bash
legion remove my-feature child-a --force
```

Without `--force`, dirty worktrees are protected.

### Dry Run

Preview what would be removed:

```bash
legion remove my-feature --dry-run
```

Shows actions without executing them.

## Verification

After removal, verify:

```bash
legion list
# Parent should not appear

tmux list-sessions
# Session should not exist
```

## Troubleshooting

**Uncommitted changes error:**

```
Error: Worktree has uncommitted changes. Use --force to remove anyway.
```

Solution: Commit or stash changes, or use `--force`.

**Branch not merged:**

```
Error deleting branch: not fully merged
```

Solution: Merge the branch first, or use `--force` for `-D` deletion.

## See Also

- [CLI Reference: remove](../reference/cli.md#remove)
- [Managing Children](manage-children.md)
