# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- GitHub Actions workflow for publishing documentation to GitHub Pages
- Coverage gate in CI that fails if coverage drops below 73%
- GitHub Actions CI workflow for running tests and linting on pull requests
- Coverage reporting with pytest-cov for local development
- Initial implementation of Legionnaire CLI
- `legion init` command for creating parent/child worktrees with tmux sessions
- `legion remove` command for cleaning up worktrees, branches, and sessions
- `legion list` command for discovering existing parents and children
- Support for Claude and Cursor agents
- Deterministic window coloring in tmux
- Stateless design with PID file-based agent tracking
- MkDocs Material documentation following Diataxis framework
- Tutorials, how-to guides, reference, and explanation sections

### Fixed

- Agent launch command now explicitly changes to the child worktree directory

### Added

- Test verifying child window panes start in correct directory
- How-to guide for configuring tmux pane splits to use current directory
