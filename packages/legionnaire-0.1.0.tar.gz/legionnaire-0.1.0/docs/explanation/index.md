# Explanation

Explanation documentation provides **understanding-oriented** discussion of concepts and design decisions.

## Available Topics

### Architecture

- [Architecture](architecture.md) - How Legionnaire's components work together

### Design

- [Design Decisions](design-decisions.md) - Why Legionnaire works the way it does
