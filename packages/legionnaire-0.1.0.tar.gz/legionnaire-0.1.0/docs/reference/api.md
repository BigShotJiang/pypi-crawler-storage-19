# API Reference

Legionnaire's Python modules can be used programmatically.

---

## legionnaire.ids

ID slugification and validation.

::: legionnaire.ids
    options:
      show_root_heading: false
      members:
        - slugify
        - validate_id
        - slugify_and_validate
        - InvalidIdError

---

## legionnaire.paths

Path derivation for worktrees and directories.

::: legionnaire.paths
    options:
      show_root_heading: false
      members:
        - get_repo_root
        - get_worktrees_root
        - parent_dir
        - parent_worktree_path
        - child_worktree_path
        - parent_branch_name
        - child_branch_name
        - NotInGitRepoError

---

## legionnaire.git_ops

Git subprocess wrappers.

::: legionnaire.git_ops
    options:
      show_root_heading: false
      members:
        - current_head
        - current_branch
        - current_upstream
        - rev_parse
        - branch_exists
        - worktree_list_porcelain
        - ensure_worktree_add
        - set_branch_upstream
        - worktree_remove
        - branch_delete
        - is_worktree_dirty
        - list_branches_with_prefix
        - GitError
        - WorktreeEntry

---

## legionnaire.agent

Agent process management.

::: legionnaire.agent
    options:
      show_root_heading: false
      members:
        - pidfile_path
        - read_pid
        - pid_alive
        - get_agent_status
        - launch_command
        - kill_agent_if_running
        - delete_pidfile
        - AgentType
        - AgentStatus
        - PIDFILE_NAME

---

## legionnaire.tmux_ops

tmux operations using libtmux.

::: legionnaire.tmux_ops
    options:
      show_root_heading: false
      members:
        - get_server
        - session_exists
        - is_session_managed
        - ensure_managed_session
        - ensure_parent_window
        - ensure_child_window
        - list_child_windows
        - kill_window
        - kill_session
        - reorder_windows
        - apply_colors
        - send_keys_to_window
        - get_session
        - TmuxError
        - SessionNotManagedError
        - PARENT_RED
        - CHILD_PALETTE
