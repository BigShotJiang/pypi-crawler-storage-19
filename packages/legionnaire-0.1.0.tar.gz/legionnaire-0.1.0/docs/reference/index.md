# Reference

Reference documentation provides **information-oriented** technical descriptions of Legionnaire's components.

## Available References

### Command Line

- [CLI Reference](cli.md) - Complete command-line interface documentation

### Configuration

- [Configuration](configuration.md) - Naming rules, paths, and settings

### Programmatic Access

- [API Reference](api.md) - Python module documentation
