"""Tests for auth module."""

