class ExcelObjects:
    pass
