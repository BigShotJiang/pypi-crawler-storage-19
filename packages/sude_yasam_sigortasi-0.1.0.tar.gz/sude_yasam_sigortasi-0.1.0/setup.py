from setuptools import setup, find_packages

# README.md dosyasını uzun açıklama olarak kullanmak için okuyoruz
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="sude-yasam-sigortasi", 
    version="0.1.0",             
    author="Sude Sert",
    author_email="sudesert81@gmail.com",
    description="Aktüeryal Yaşam Sigortaları Hesaplama Modülü",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/sudesert", 
    packages=find_packages(),    
    include_package_data=True,   
    install_requires=[           
        "pandas",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)