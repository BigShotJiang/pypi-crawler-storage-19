import time
from typing import Callable, Iterable, Literal

from ..utils import BlockingThreadPool, secs_to_readable
from .base import BaseABC, ElemType, ElemTypeNames
from .block import Block, BlockABC, StandaloneBlockInput
from .content import Content, ContentABC, ContentInput
from .doc import Doc, DocABC, DocInput
from .elem import DocElement
from .embedding import EmbeddingABC
from .error import (
    DocExistsError,
    ElementExistsError,
    ElementNotFoundError,
    NotFoundError,
    PageExistsError,
)
from .eval import EvalABC
from .io import IO_ABC
from .layout import Layout, LayoutABC, LayoutInput
from .management import ManagementABC, User
from .page import Page, PageABC, PageInput
from .tagging import TaggingABC
from .task import Task, TaskABC
from .trigger import TriggerABC
from .value import Value, ValueABC


class DocStoreABC(
    BaseABC,
    DocABC,
    PageABC,
    LayoutABC,
    BlockABC,
    ContentABC,
    EvalABC,
    ValueABC,
    TaggingABC,
    TaskABC,
    IO_ABC,
    ManagementABC,
    EmbeddingABC,
    TriggerABC,
):
    """
    Abstract base class containing all abstract methods for DocStoreInterface.
    This class combines all specialized abstract classes.
    """


class DocStoreInterface(DocStoreABC):
    """Added non-abstract methods for DocStoreABC."""

    def get(self, elem_id: str) -> DocElement:
        """Get an element by its ID."""
        if elem_id.startswith("doc-"):
            return self.get_doc(elem_id)
        if elem_id.startswith("page-"):
            return self.get_page(elem_id)
        if elem_id.startswith("layout-"):
            if ".block-" in elem_id:
                return self.get_block(elem_id)
            if ".content-" in elem_id:
                return self.get_content(elem_id)
            return self.get_layout(elem_id)
        if elem_id.startswith("block-"):
            return self.get_block(elem_id)
        if elem_id.startswith("content-"):
            return self.get_content(elem_id)
        if elem_id.startswith("evallayout-"):
            return self.get_eval_layout(elem_id)
        if elem_id.startswith("evalcontent-"):
            return self.get_eval_content(elem_id)
        # TODO: fallback to block for now.
        return self.get_block(elem_id)

    def try_get(self, elem_id: str) -> DocElement | None:
        """Try to get a element by its ID, return None if not found."""
        try:
            return self.get(elem_id)
        except ElementNotFoundError:
            return None

    def try_get_doc(self, doc_id: str) -> Doc | None:
        """Try to get a doc by its ID, return None if not found."""
        try:
            return self.get_doc(doc_id)
        except ElementNotFoundError:
            return None

    def try_get_doc_by_pdf_path(self, pdf_path: str) -> Doc | None:
        """Try to get a doc by its PDF path, return None if not found."""
        try:
            return self.get_doc_by_pdf_path(pdf_path)
        except ElementNotFoundError:
            return None

    def try_get_doc_by_pdf_hash(self, pdf_hash: str) -> Doc | None:
        """Try to get a doc by its PDF sha256sum hex-string, return None if not found."""
        try:
            return self.get_doc_by_pdf_hash(pdf_hash)
        except ElementNotFoundError:
            return None

    def try_get_page(self, page_id: str) -> Page | None:
        """Try to get a page by its ID, return None if not found."""
        try:
            return self.get_page(page_id)
        except ElementNotFoundError:
            return None

    def try_get_page_by_image_path(self, image_path: str) -> Page | None:
        """Try to get a page by its image path, return None if not found."""
        try:
            return self.get_page_by_image_path(image_path)
        except ElementNotFoundError:
            return None

    def try_get_page_by_image_hash(self, image_hash: str) -> Page | None:
        """Try to get a page by its image sha256sum hex-string, return None if not found."""
        try:
            return self.get_page_by_image_hash(image_hash)
        except ElementNotFoundError:
            return None

    def try_get_layout(self, layout_id: str, expand: bool = False) -> Layout | None:
        """Try to get a layout by its ID, return None if not found."""
        try:
            return self.get_layout(layout_id, expand)
        except ElementNotFoundError:
            return None

    def try_get_layout_by_page_id_and_provider(self, page_id: str, provider: str, expand: bool = False) -> Layout | None:
        """Try to get a layout by its page ID and provider, return None if not found."""
        try:
            return self.get_layout_by_page_id_and_provider(page_id, provider, expand)
        except ElementNotFoundError:
            return None

    def try_get_block(self, block_id: str) -> Block | None:
        """Try to get a block by its ID, return None if not found."""
        try:
            return self.get_block(block_id)
        except ElementNotFoundError:
            return None

    def try_get_block_by_image_path(self, image_path: str) -> Block | None:
        """Try to get a block by its image path, return None if not found."""
        try:
            return self.get_block_by_image_path(image_path)
        except ElementNotFoundError:
            return None

    def try_get_content(self, content_id: str) -> Content | None:
        """Try to get a content by its ID, return None if not found."""
        try:
            return self.get_content(content_id)
        except ElementNotFoundError:
            return None

    def try_get_content_by_block_id_and_version(self, block_id: str, version: str) -> Content | None:
        """Try to get a content by its block ID and version, return None if not found."""
        try:
            return self.get_content_by_block_id_and_version(block_id, version)
        except ElementNotFoundError:
            return None

    def try_get_value(self, value_id: str) -> Value | None:
        """Try to get a value by its ID, return None if not found."""
        try:
            return self.get_value(value_id)
        except ElementNotFoundError:
            return None

    def try_get_value_by_elem_id_and_key(self, elem_id: str, key: str) -> Value | None:
        """Try to get a value by its elem_id and key, return None if not found."""
        try:
            return self.get_value_by_elem_id_and_key(elem_id, key)
        except ElementNotFoundError:
            return None

    def try_get_user(self, name: str) -> User | None:
        """Try to get a user by its name, return None if not found."""
        try:
            return self.get_user(name)
        except NotFoundError:
            return None

    def doc_tags(self) -> list[str]:
        """Get all distinct tags for docs."""
        return self.distinct_values("doc", "tags")

    def page_tags(self) -> list[str]:
        """Get all distinct tags for pages."""
        return self.distinct_values("page", "tags")

    def page_providers(self) -> list[str]:
        """Get all distinct providers for pages."""
        return self.distinct_values("page", "providers")

    def layout_providers(self) -> list[str]:
        """Get all distinct layout providers."""
        return self.distinct_values("layout", "provider")

    def layout_tags(self) -> list[str]:
        """Get all distinct tags for layouts."""
        return self.distinct_values("layout", "tags")

    def block_tags(self) -> list[str]:
        """Get all distinct tags for blocks."""
        return self.distinct_values("block", "tags")

    def block_versions(self) -> list[str]:
        """Get all distinct versions for blocks."""
        return self.distinct_values("block", "versions")

    def content_versions(self) -> list[str]:
        """Get all distinct content versions."""
        return self.distinct_values("content", "version")

    def content_tags(self) -> list[str]:
        """Get all distinct tags for contents."""
        return self.distinct_values("content", "tags")

    def find_docs(
        self,
        query: dict | list[dict] | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Doc]:
        """List docs by filters."""
        query = query or {}
        for elem in self.find("doc", query, skip=skip, limit=limit):
            assert isinstance(elem, Doc)
            yield elem

    def find_pages(
        self,
        query: dict | list[dict] | None = None,
        doc_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Page]:
        """List pages by filters."""
        query = query or {}
        if doc_id is not None:
            if not isinstance(query, dict):
                raise ValueError("doc_id filter cannot be used with pipeline query.")
            query["doc_id"] = doc_id
        for elem in self.find("page", query, skip=skip, limit=limit):
            assert isinstance(elem, Page)
            yield elem

    def find_layouts(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Layout]:
        """List layouts by filters."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        for elem in self.find("layout", query, skip=skip, limit=limit):
            assert isinstance(elem, Layout)
            yield elem

    def find_blocks(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Block]:
        """List blocks by filters."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        for elem in self.find("block", query, skip=skip, limit=limit):
            assert isinstance(elem, Block)
            yield elem

    def find_contents(
        self,
        query: dict | list[dict] | None = None,
        page_id: str | None = None,
        block_id: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Content]:
        """List contents by filters."""
        query = query or {}
        if page_id is not None:
            if not isinstance(query, dict):
                raise ValueError("page_id filter cannot be used with pipeline query.")
            query["page_id"] = page_id
        if block_id is not None:
            if not isinstance(query, dict):
                raise ValueError("block_id filter cannot be used with pipeline query.")
            query["block_id"] = block_id
        for elem in self.find("content", query, skip=skip, limit=limit):
            assert isinstance(elem, Content)
            yield elem

    def find_values(
        self,
        query: dict | list[dict] | None = None,
        elem_id: str | None = None,
        key: str | None = None,
        skip: int | None = None,
        limit: int | None = None,
    ) -> Iterable[Value]:
        """List values by filters."""
        query = query or {}
        if elem_id is not None:
            if not isinstance(query, dict):
                raise ValueError("elem_id filter cannot be used with pipeline query.")
            query["elem_id"] = elem_id
        if key is not None:
            if not isinstance(query, dict):
                raise ValueError("key filter cannot be used with pipeline query.")
            query["key"] = key
        for elem in self.find("value", query, skip=skip, limit=limit):
            assert isinstance(elem, Value)
            yield elem

    def insert_local_doc(self, local_pdf_path: str) -> Doc:
        s3_pdf_path = self.upload_local_file("doc", local_pdf_path)
        try:
            return self.insert_doc(DocInput(pdf_path=s3_pdf_path))
        except DocExistsError as e:
            return self.get_doc_by_pdf_hash(e.pdf_hash) if e.pdf_hash else self.get_doc_by_pdf_path(e.pdf_path)

    def insert_local_page(self, local_image_path: str) -> Page:
        s3_image_path = self.upload_local_file("page", local_image_path)
        try:
            return self.insert_page(PageInput(image_path=s3_image_path))
        except PageExistsError as e:
            return self.get_page_by_image_hash(e.image_hash) if e.image_hash else self.get_page_by_image_path(e.image_path)

    def insert_local_block(self, type: str, local_image_path: str) -> Block:
        s3_image_path = self.upload_local_file("block", local_image_path)
        try:
            return self.insert_standalone_block(StandaloneBlockInput(type=type, image_path=s3_image_path))
        except ElementExistsError:
            return self.get_block_by_image_path(s3_image_path)

    def upsert_layout(self, page_id: str, provider: str, layout_input: LayoutInput, insert_blocks=False) -> Layout:
        """Upsert a layout for a page."""
        return self.insert_layout(page_id, provider, layout_input, insert_blocks, upsert=True)

    def upsert_content(self, block_id: str, version: str, content_input: ContentInput) -> Content:
        """Upsert content for a block."""
        return self.insert_content(block_id, version, content_input, upsert=True)

    def try_get_task(self, task_id: str) -> Task | None:
        """Try to get a task by its ID, return None if not found."""
        try:
            return self.get_task(task_id)
        except ElementNotFoundError:
            return None

    def grab_new_task(self, command: str, hold_sec=3600) -> Task | None:
        """Grab a new task for processing."""
        grabbed_tasks = self.grab_new_tasks(command=command, num=1, hold_sec=hold_sec)
        return grabbed_tasks[0] if grabbed_tasks else None

    def update_grabbed_task(
        self,
        task: Task,
        status: Literal["done", "error", "skipped"],
        error_message: str | None = None,
    ) -> None:
        """Update a task after processing."""
        send_task = (status == "error") or bool(task.batch_id)
        return self.update_task(
            task_id=task.id,
            command=task.command,
            status=status,
            error_message=error_message,
            task=task if send_task else None,
        )

    def iterate(
        self,
        elem_type: ElemType | type,
        func: Callable[[int, DocElement], None],
        query: dict | list[dict] | None = None,
        query_from: ElemType | type | None = None,
        max_workers: int = 10,
        total: int | None = None,
    ) -> None:
        if isinstance(elem_type, type):
            elem_type_name = elem_type.__name__.lower()
            assert elem_type_name in ElemTypeNames
            elem_type = elem_type_name

        if isinstance(query_from, type):
            query_type_name = query_from.__name__.lower()
            assert query_type_name in ElemTypeNames
            query_from = query_type_name

        if query is None:
            query = {}

        if total is None:
            print("Estimating element count...")
            begin = time.time()
            cnt = self.count(
                elem_type=elem_type,
                query=query,
                query_from=query_from,
                estimated=True,
            )
            elapsed = round(time.time() - begin, 2)
            print(f"Estimation done. Found {cnt} elements in {elapsed} seconds.")
        else:
            cnt = max(0, total)

        print("Iterating over elements...")
        begin = time.time()
        cursor = self.find(
            elem_type=elem_type,
            query=query,
            query_from=query_from,
        )

        last_report_time = time.time()
        with BlockingThreadPool(max_workers) as executor:
            for idx, elem_data in enumerate(cursor):
                now = time.time()
                if idx > 0 and (now - last_report_time) > 10:
                    curr = str(idx).rjust(len(str(cnt)))
                    curr = f"{curr}/{cnt}" if cnt > 0 else curr
                    elapsed = round(now - begin, 2)
                    rps = round(idx / elapsed, 2) if elapsed > 0 else idx
                    message = f"Processed {curr} elements in {elapsed}s, {rps}r/s"
                    if cnt > 0:
                        prog = round(idx / cnt * 100, 2)
                        remaining_secs = int(elapsed * (cnt - idx) / idx)
                        rtime = secs_to_readable(remaining_secs)
                        message = f"[{prog:5.2f}%] {message}, remaining time: {rtime}"
                    print(message)
                    last_report_time = now
                executor.submit(func, idx, elem_data)
            executor.shutdown(wait=True)
