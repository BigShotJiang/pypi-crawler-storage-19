from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from .base import InputModel
from .elem import DocElement

if TYPE_CHECKING:
    from .block import Block
    from .page import Page


class ContentInput(InputModel):
    format: str
    content: str
    is_human_label: bool = False
    tags: list[str] | None = None


class Content(DocElement):
    """Content of a block, representing the text or data within a block."""

    # layout_id: str | None = None
    # provider: str | None = None

    page_id: str | None
    block_id: str
    version: str
    format: str
    content: str
    is_human_label: bool = False

    @property
    def page(self) -> "Page | None":
        """Get the page associated with this content."""
        if self.page_id is None:
            return None
        return self.store.get_page(self.page_id)

    @property
    def block(self) -> "Block":
        """Get the block associated with this content."""
        return self.store.get_block(self.block_id)


class ContentABC(ABC):
    """Abstract class for content operations."""

    @abstractmethod
    def get_content(self, content_id: str) -> Content:
        """Get a content by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_content_by_block_id_and_version(self, block_id: str, version: str) -> Content:
        """Get a content by its block ID and version."""
        raise NotImplementedError()

    @abstractmethod
    def insert_content(self, block_id: str, version: str, content_input: ContentInput, upsert=False) -> Content:
        """Insert a new content for a block."""
        raise NotImplementedError()
