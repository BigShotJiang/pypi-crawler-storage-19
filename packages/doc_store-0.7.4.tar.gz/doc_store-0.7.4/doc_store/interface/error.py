import json
import logging

__logger__ = logging.getLogger(__name__)


class UnauthorizedError(Exception):
    pass


class NotFoundError(Exception):
    pass


class ElementNotFoundError(NotFoundError):
    pass


class AlreadyExistsError(Exception):
    pass


class ElementExistsError(AlreadyExistsError):
    pass


class DocExistsError(ElementExistsError):
    def __init__(self, message: str, pdf_path: str, pdf_hash: str | None):
        super().__init__(message)
        self.pdf_path = pdf_path
        self.pdf_hash = pdf_hash


class PageExistsError(ElementExistsError):
    def __init__(self, message: str, image_path: str, image_hash: str | None) -> None:
        super().__init__(message)
        self.image_path = image_path
        self.image_hash = image_hash


class TaskMismatchError(Exception):
    pass


def encode_error(e: Exception, logger: logging.Logger = __logger__) -> tuple[int, dict]:
    from fastapi import status

    if isinstance(e, UnauthorizedError):
        return (
            status.HTTP_401_UNAUTHORIZED,
            {"error": "UnauthorizedError", "message": str(e)},
        )
    if isinstance(e, ElementNotFoundError):
        return (
            status.HTTP_404_NOT_FOUND,
            {"error": "ElementNotFoundError", "message": str(e)},
        )
    if isinstance(e, NotFoundError):
        return (
            status.HTTP_404_NOT_FOUND,
            {"error": "NotFoundError", "message": str(e)},
        )
    if isinstance(e, DocExistsError):
        return (
            status.HTTP_409_CONFLICT,
            {"error": "DocExistsError", "message": str(e), "pdf_path": e.pdf_path, "pdf_hash": e.pdf_hash},
        )
    if isinstance(e, PageExistsError):
        return (
            status.HTTP_409_CONFLICT,
            {"error": "PageExistsError", "message": str(e), "image_path": e.image_path, "image_hash": e.image_hash},
        )
    if isinstance(e, ElementExistsError):
        return (
            status.HTTP_409_CONFLICT,
            {"error": "ElementExistsError", "message": str(e)},
        )
    if isinstance(e, AlreadyExistsError):
        return (
            status.HTTP_409_CONFLICT,
            {"error": "AlreadyExistsError", "message": str(e)},
        )
    if isinstance(e, TaskMismatchError):
        return (
            status.HTTP_400_BAD_REQUEST,
            {"error": "TaskMismatchError", "message": str(e)},
        )
    if isinstance(e, PermissionError):
        return (
            status.HTTP_403_FORBIDDEN,
            {"error": "PermissionError", "message": str(e)},
        )
    if isinstance(e, ValueError):
        logger.error("Unhandled exception occurred", exc_info=e)
        return (
            status.HTTP_400_BAD_REQUEST,
            {"error": "ValueError", "message": str(e)},
        )
    logger.error("Unhandled exception occurred", exc_info=e)
    return (
        status.HTTP_500_INTERNAL_SERVER_ERROR,
        {"error": "InternalServerError", "message": str(e)},
    )


def decode_error(status_code: int, response_text: str) -> Exception:
    from fastapi import status

    if status_code == status.HTTP_422_UNPROCESSABLE_CONTENT:
        return ValueError(f"Validation error: {response_text}")

    try:
        error_info = json.loads(response_text)
    except json.JSONDecodeError:
        return Exception(f"Status: {status_code}, response text: {response_text}")
    if not isinstance(error_info, dict):
        return Exception(f"Status: {status_code}, response text: {response_text}")

    error = error_info.get("error")
    message = error_info.get("message", "") or response_text

    if status_code == status.HTTP_401_UNAUTHORIZED:
        return UnauthorizedError(message)
    if status_code == status.HTTP_403_FORBIDDEN:
        return PermissionError(message)
    if status_code == status.HTTP_404_NOT_FOUND:
        if error == "ElementNotFoundError":
            return ElementNotFoundError(message)
        # if error == "NotFoundError"
        return NotFoundError(message)
    if status_code == status.HTTP_409_CONFLICT:
        if error == "DocExistsError":
            pdf_path = error_info.get("pdf_path", "")
            pdf_hash = error_info.get("pdf_hash", None)
            return DocExistsError(message, pdf_path, pdf_hash)
        if error == "PageExistsError":
            image_path = error_info.get("image_path", "")
            image_hash = error_info.get("image_hash", None)
            return PageExistsError(message, image_path, image_hash)
        if error == "ElementExistsError":
            return ElementExistsError(message)
        # if error == "AlreadyExistsError"
        return AlreadyExistsError(message)
    if status_code == status.HTTP_400_BAD_REQUEST:
        if error == "TaskMismatchError":
            return TaskMismatchError(message)
        # if error == "ValueError"
        return ValueError(message)
    return Exception(f"Status: {status_code}, response text: {response_text}")
