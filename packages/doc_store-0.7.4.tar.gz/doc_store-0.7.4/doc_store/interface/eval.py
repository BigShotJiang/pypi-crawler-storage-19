from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Literal

from .base import InputModel
from .elem import DocElement


class EvalLayoutBlock(InputModel):
    id: str
    type: str
    bbox: list[float]
    angle: Literal[0, 90, 180, 270] | None = None
    format: str
    content: str


class EvalStatus(StrEnum):
    PENDING = "pending"
    SUCCESS = "success"
    FAILED = "failed"


class EvalLayout(DocElement):
    """Eval layout of a page."""

    layout_id: str  # gt layout_id
    provider: str  # eval target provider
    blocks: list[EvalLayoutBlock] = []
    relations: list[dict] = []
    status: EvalStatus = EvalStatus.PENDING


class EvalContent(DocElement):
    """Eval content of a block."""

    content_id: str  # gt content_id
    version: str  # eval target version
    format: str
    content: str
    status: EvalStatus = EvalStatus.PENDING


class EvalABC(ABC):
    """Abstract class for eval operations."""

    @abstractmethod
    def get_eval_layout(self, eval_layout_id: str) -> EvalLayout:
        """Get an eval layout by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_eval_content(self, eval_content_id: str) -> EvalContent:
        """Get an eval content by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def insert_eval_layout(
        self,
        layout_id: str,
        provider: str,
        blocks: list[EvalLayoutBlock] | None = None,
        relations: list[dict] | None = None,
    ) -> EvalLayout:
        """Insert a new eval layout into the database."""
        raise NotImplementedError()

    @abstractmethod
    def insert_eval_content(
        self,
        content_id: str,
        version: str,
        format: str,
        content: str,
    ) -> EvalContent:
        """Insert a new eval content into the database."""
        raise NotImplementedError()
