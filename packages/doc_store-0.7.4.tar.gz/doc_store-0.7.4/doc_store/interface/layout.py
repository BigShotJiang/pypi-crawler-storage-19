from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any, Literal

from PIL import Image

from ..drawing import draw_layout_blocks, draw_mask_blocks
from .base import DictModel, InputModel
from .block import Block, BlockInput
from .content import Content
from .elem import DocElement

if TYPE_CHECKING:
    from .page import Page


class MaskBlock(InputModel, DictModel):
    type: str
    bbox: list[float]
    angle: Literal[0, 90, 180, 270] | None = None
    attrs: dict[str, Any] | None = None


class ContentBlockInput(BlockInput):
    format: str | None = None
    content: str | None = None
    content_tags: list[str] | None = None


class LayoutInput(InputModel):
    blocks: list[ContentBlockInput]
    masks: list[MaskBlock] = []
    relations: list[dict] | None = None
    is_human_label: bool = False
    tags: list[str] | None = None


class Layout(DocElement):
    """Layout of a page, containing blocks and relations."""

    page_id: str
    provider: str
    masks: list[MaskBlock] = []
    blocks: list[Block] = []
    relations: list[dict] = []
    contents: list[Content] = []
    is_human_label: bool = False

    @property
    def page(self) -> "Page":
        """Get the page associated with the layout."""
        return self.store.get_page(self.page_id)

    @property
    def masked_image(self) -> Image.Image:
        """Get the masked image of the layout."""
        page_image = self.page.image
        return draw_mask_blocks(page_image, self.masks)

    @property
    def framed_image(self) -> Image.Image:
        """Get the framed image of the layout."""
        page_image = self.page.image
        return draw_layout_blocks(page_image, self.blocks)

    def list_versions(self) -> list[str]:
        """List all content versions of the layout."""
        block_ids = [block.id for block in self.blocks]
        if not block_ids:
            return []

        versions = set()
        query = {"block_id": {"$in": block_ids}}
        for content in self.store.find_contents(query=query):
            versions.add(content.version)
        return sorted(versions)

    def list_blocks(self) -> list[Block]:
        """Get all blocks of the layout."""
        block_ids = [block.id for block in self.blocks]
        if not block_ids:
            return []
        blocks = [*self.blocks]
        indices = {b.id: idx for idx, b in enumerate(self.blocks)}
        for block in self.store.find_blocks(query={"id": {"$in": block_ids}}):
            block_idx = indices.get(block.id)
            if block_idx is not None:
                blocks[block_idx] = block
        return blocks

    def list_contents(self, version: str | None = None) -> list[Content]:
        """Get all contents of the layout by version."""
        block_ids = [block.id for block in self.blocks]
        if not block_ids:
            return []
        if not version:
            version = self.provider
        contents = {}
        if version == self.provider:
            contents = {c.block_id: c for c in self.contents}
        query = {"block_id": {"$in": block_ids}, "version": version}
        for content in self.store.find_contents(query=query):
            contents[content.block_id] = content
        return [contents[bid] for bid in block_ids if bid in contents]

    def expand(self) -> "Layout":
        """Expand the layout by loading all blocks and contents."""
        self.blocks = self.list_blocks()
        self.contents = self.list_contents()
        return self


class LayoutABC(ABC):
    """Abstract class for layout operations."""

    @abstractmethod
    def get_layout(self, layout_id: str, expand: bool = False) -> Layout:
        """Get a layout by its ID."""
        raise NotImplementedError()

    @abstractmethod
    def get_layout_by_page_id_and_provider(self, page_id: str, provider: str, expand: bool = False) -> Layout:
        """Get a layout by its page ID and provider."""
        raise NotImplementedError()

    @abstractmethod
    def insert_layout(
        self, page_id: str, provider: str, layout_input: LayoutInput, insert_blocks=False, upsert=False
    ) -> Layout:
        """Insert a new layout into the database."""
        raise NotImplementedError()

    @abstractmethod
    def insert_content_blocks_layout(
        self,
        page_id: str,
        provider: str,
        content_blocks: list[ContentBlockInput],
        upsert: bool = False,
    ) -> Layout:
        """Import content blocks and create a layout for a page."""
        raise NotImplementedError()
