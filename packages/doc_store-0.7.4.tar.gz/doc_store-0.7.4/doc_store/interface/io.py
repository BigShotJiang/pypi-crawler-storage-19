import hashlib
import io
import os
from abc import ABC, abstractmethod
from functools import lru_cache
from typing import Literal

import boto3
import httpx
from botocore.client import Config
from PIL import Image, ImageDraw

from ..s3 import head_s3_object, put_s3_object, read_s3_object_bytes, split_s3_path
from ..utils import timed_property
from .base import DictModel

Image.MAX_IMAGE_PIXELS = None


_UPLOAD_DIRS = {
    "doc": "s3://doc-store/docs-by-hash/",
    "page": "s3://doc-store/pages-by-hash/",
    "block": "s3://doc-store/blocks-by-hash/",
}

# bucket -> url
_ACCESSIBLE_URL: dict[str, str] = {}


class S3Bucket(DictModel):
    name: str
    endpoint_urls: list[str]
    addressing_style: str = "path"  # Enum(path, virtual)
    aws_access_key_id: str
    aws_secret_access_key: str


def _read_local_file(file_path: str) -> bytes:
    if not os.path.isfile(file_path):
        raise ValueError(f"Local file {file_path} does not exist.")
    with open(file_path, "rb") as f:
        return f.read()


def _try_read_pdf(file_bytes: bytes) -> None:
    from ..pdf_doc import PDFDocument

    if PDFDocument(file_bytes).num_pages <= 0:
        raise ValueError("PDF document has no pages.")


def _try_read_image(file_bytes: bytes) -> None:
    image = Image.open(io.BytesIO(file_bytes))
    image.convert("RGB")  # Some broken image may raise.


def _is_url_accessible(url: str) -> bool:
    try:
        _ = httpx.get(url, timeout=2.0)
        return True
    except httpx.RequestError:
        return False


def _get_accessible_url(bucket: S3Bucket) -> str:
    if bucket.name in _ACCESSIBLE_URL:
        return _ACCESSIBLE_URL[bucket.name]
    for url in bucket.endpoint_urls:
        if _is_url_accessible(url):
            _ACCESSIBLE_URL[bucket.name] = url
            return url
    raise ValueError(f"No accessible endpoint URL found for bucket {bucket.name}.")


class IO_ABC(ABC):
    """Base abstract class for io operations."""

    @timed_property(ttl=60)
    def s3_buckets(self) -> dict[str, S3Bucket]:
        return {bkt.name: bkt for bkt in self.list_s3_buckets()}

    @abstractmethod
    def list_s3_buckets(self) -> list[S3Bucket]:
        """List all S3 buckets in the system."""
        raise NotImplementedError()

    @lru_cache
    def read_file(self, file_path: str, allow_local=True) -> bytes:
        if file_path.startswith("s3://"):
            s3_client = self.get_s3_client(file_path)
            return read_s3_object_bytes(file_path, client=s3_client)
        elif allow_local and os.path.isfile(file_path):
            with open(file_path, "rb") as f:
                return f.read()
        raise ValueError(f"File {file_path} does not exist or is not accessible.")

    def upload_local_file(self, file_type: Literal["doc", "page", "block"], file_path: str) -> str:
        file_ext = file_path.split(".")[-1].lower()
        if file_type == "doc" and file_ext != "pdf":
            raise ValueError("file_path must end with .pdf for doc type.")
        if file_type in ("page", "block") and file_ext not in ("jpg", "jpeg", "png", "webp"):
            raise ValueError("file_path must end with .jpg, .jpeg, .png, or .webp for page/block type.")
        file_bytes = _read_local_file(file_path)
        if file_type == "doc":
            _try_read_pdf(file_bytes)
        elif file_type in ("page", "block"):
            _try_read_image(file_bytes)
        file_hash = hashlib.sha256(file_bytes).hexdigest()
        upload_file_path = f"{_UPLOAD_DIRS[file_type]}{file_hash}.{file_ext}"
        s3_client = self.get_s3_client(upload_file_path)
        if not head_s3_object(upload_file_path, client=s3_client):
            put_s3_object(upload_file_path, file_bytes, client=s3_client)
        return upload_file_path

    def read_image(self, file_path: str) -> Image.Image:
        content = self.read_file(file_path)
        image = Image.open(io.BytesIO(content))
        try:
            return image.convert("RGB")
        except Exception:
            # image is broken, return fake image
            fake_size = [*image.size]
            fake_image = Image.new("RGB", fake_size, (255, 255, 255))
            draw = ImageDraw.Draw(fake_image)
            draw.line((0, 0, *fake_size), fill=(255, 0, 0), width=10)
            draw.line((0, fake_size[1], fake_size[0], 0), fill=(255, 0, 0), width=10)
            return fake_image

    def get_s3_client(self, path: str):
        bucket, _ = split_s3_path(path)
        config: S3Bucket | None = self.s3_buckets.get(bucket)
        if not config:
            raise ValueError(f"Bucket {bucket} not found in S3 config.")
        endpoint_url = _get_accessible_url(config)
        return boto3.client(
            "s3",
            aws_access_key_id=config.aws_access_key_id,
            aws_secret_access_key=config.aws_secret_access_key,
            endpoint_url=endpoint_url,
            config=Config(
                s3={"addressing_style": config.addressing_style},
                retries={"max_attempts": 8},
            ),
        )
