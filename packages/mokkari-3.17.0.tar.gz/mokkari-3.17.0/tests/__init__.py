"""Tests for mokkari."""
