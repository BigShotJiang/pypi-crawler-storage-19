:::mokkari.schemas.variant.Variant
