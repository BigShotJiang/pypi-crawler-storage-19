version = "0.7.5"

# Notes:
#   - 0.7.0 Merge redis code into DocStore, add `batch_id`.
#   - 0.7.0 Has bug, `task.store` is not accessable.
#   - 0.7.1 Recover Task as sub-class of Element.
#   - 0.7.2:
#     - split `interface.py` into many small files.
#     - add `PageExistsError`.
#     - http error encode/decode is more correctly.
#     - add `get_page_by_image_hash()`.
#     - change class `ElementTagging` to `TaggingInput`.
#     - `insert_page()` add parameter `skip_hash_check`.
#     - `update_task()` add parameter `check_mismatch`.
#     - block DocEvent can have `layout_provider` field.
#     - add `display_order` to Trigger.
#     - Trigger support update and delete.
#     - add `doc_trigger.py`
#   - 0.7.3:
#     - store/read S3 bucket configs on server.
#     - surrogates in PDF metadata are removed.
#   - 0.7.4:
#     - support reading user_home in spark executor.
#   - 0.7.5:
#     - remove EvalStatus (which is not supported by py3.10)

# Define the minimum required version for compatibility checks
# Please update this value when making breaking changes
min_required_version = "0.6.0"
