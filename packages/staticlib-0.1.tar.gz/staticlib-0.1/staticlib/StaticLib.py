"""StaticLib is a module that provides classes for defining immutable objects."""


import inspect
from typing import Any, Union


class StaticNull(object):
    """A custom null type to replace None."""

    __slots__: frozenset[str] = frozenset({})

    def __new__(cls: type["StaticNull"], /) -> "StaticNull":
        """Create a new StaticNull instance."""

        cls._instance: Union[StaticNull, None] = None

        if cls._instance is None:
            cls._instance = super(StaticNull, cls).__new__(cls)
            return cls._instance
        else:
            return cls._instance


# A type alias for the Null class
Null: StaticNull = StaticNull()


class StaticError(BaseException):
    """A custom exception for the StaticKind type."""

    __slots__: frozenset[str] = frozenset({"_message"})

    def __new__(cls: type["StaticError"], message: str, /) -> "StaticError":
        """Create a new StaticError instance."""

        if not isinstance(message, str):
            raise TypeError(f"'{message}' must have type 'str'")
        else:
            return super(StaticError, cls).__new__(cls)

    def __init__(self: "StaticError", message: str, /) -> None:
        self._message = message
        super().__init__(self._message)



class StaticObject(object):
    """Define a type and its value both whom can't be changed.

    - kind: valuetype for a given object
    - value: an instance of the given valuetype
    """

    __slots__: frozenset[str] = frozenset({})

    def __new__(cls: type["StaticObject"], kind: type[Any], value: Any, /, freeze_value: bool = True) -> "StaticObject":
        """Create a new StaticObject instance."""

        if not inspect.isclass(kind):
            cls.error = StaticError(f"[StaticObject] -> '{kind}' must be a class")
            return super(StaticObject, cls).__new__(cls)
        elif not isinstance(value, kind):
            cls.error = StaticError(f"[StaticObject] -> '{value}' must have type '{kind}'")
            return super(StaticObject, cls).__new__(cls)
        elif not isinstance(freeze_value, bool):
            cls.error = StaticError(f"[StaticObject] -> 'freeze_value' option must have type 'bool'")
            return super(StaticObject, cls).__new__(cls)
        else:
            cls.kind = kind
            cls.value = value
            cls.freeze_value = freeze_value
            return super(StaticObject, cls).__new__(cls)

    
    @classmethod
    def view(cls: type["StaticObject"], /) -> str:
        """Create a string representation of the StaticObject instance."""
        return f"StaticObject(kind=cls.kind, value=cls.value, freeze_value=cls.freeze_value)" if all([cls.kind, cls.value, cls.freeze_value]) else f"StaticObject()"


    @classmethod
    def modify(cls: type["StaticObject"], value: Any, /) -> bool:
        """Allow for the modification of the value without modifying the underlying type."""

        if cls.freeze_value:
            cls.error: StaticError = StaticError(f"[StaticObject.modify] -> kwarg 'freeze_value' must be False")
            return False
        elif not isinstance(value, cls.kind):
            cls.error: StaticError = StaticError(f"[StaticKind.modify] -> '{value}' must have type '{cls.kind}'")
            return False
        else:
            cls.value = value
            return True
