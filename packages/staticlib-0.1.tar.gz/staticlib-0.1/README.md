                ███████╗████████╗ █████╗ ████████╗██╗ ██████╗██╗     ██╗██████╗ 
                ██╔════╝╚══██╔══╝██╔══██╗╚══██╔══╝██║██╔════╝██║     ██║██╔══██╗
                ███████╗   ██║   ███████║   ██║   ██║██║     ██║     ██║██████╔╝
                ╚════██║   ██║   ██╔══██║   ██║   ██║██║     ██║     ██║██╔══██╗
                ███████║   ██║   ██║  ██║   ██║   ██║╚██████╗███████╗██║██████╔╝
                ╚══════╝   ╚═╝   ╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝╚══════╝╚═╝╚═════╝ 
                                                                                
--- 

> _**StaticLib** is a module that provides a single class for defining a static object._

> _There're two option for a StaticObject instance:_

>   _**freeze_value=True**: the value declared within the StaticObject instance is immutable._

>   _**freeze_value=False**: the value declared within the StaticObject instance is mutable._

> _For values to become mutable, the freeze_value option have to be set to True during object instanciation._

> _The value can them be modified by invoking the 'modify' method._

> _A type that is declared during object instanciation is always immutable, meaning it can never be changed._


## Examples:
```python
from StaticLib import StaticObject

# Unmodifiable
user: StaticObject = StaticObject(str, "Admin", freeze_value=True)

if hasattr(user, "error"):
    raise user.error
else:
    print(user.value)

# Trying to modify the value results in an error
# if user.modify("Hello") is False:
#    raise user.error    # we'll see this error
# else:
#    print(user.value)

##################################################################

# Modifiable
age: StaticObject = StaticObject(int, 22, freeze_value=False)

if hasattr(age, "error"):
    raise age.error
elif not age.modify(15):
    raise age.error
else:
    print(age.value)


# The instance object can be viewed as a string representation using the 'view' method
print(user.view())
print(age.view())


###################################################################
# When using StaticLib the None type is replaced with a custom type named Null
# which can be imported and used as a type and a value without the hassle of using None
# as it isn't considered a type and doesn't work well with isinstance. The name of the
# Null type is StaticNull where Null is its alias.
```
