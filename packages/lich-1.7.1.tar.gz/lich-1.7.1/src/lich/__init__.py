"""
Lich Toolkit - AI-Ready Full-Stack Project Generator.
"""

__version__ = "1.7.1"
