"""
API views for agent runtime.

Supports both authenticated users and anonymous sessions via X-Anonymous-Token header.
"""

import asyncio
import json
from uuid import UUID

from django.http import StreamingHttpResponse
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication, SessionAuthentication

# Try to import JWT authentication (optional dependency)
try:
    from rest_framework_simplejwt.authentication import JWTAuthentication
    HAS_JWT = True
except ImportError:
    HAS_JWT = False

from django_agent_runtime.models import AgentRun, AgentConversation, AgentEvent
from django_agent_runtime.models.base import RunStatus
from django_agent_runtime.api.serializers import (
    AgentRunSerializer,
    AgentRunCreateSerializer,
    AgentRunDetailSerializer,
    AgentConversationSerializer,
    AgentEventSerializer,
)
from django_agent_runtime.api.permissions import (
    AnonymousSessionAuthentication,
    IsAuthenticatedOrAnonymousSession,
    get_anonymous_session,
)
from django_agent_runtime.conf import runtime_settings, get_hook


# Build authentication classes list dynamically
_AUTH_CLASSES = [TokenAuthentication, SessionAuthentication, AnonymousSessionAuthentication]
if HAS_JWT:
    _AUTH_CLASSES.insert(0, JWTAuthentication)


class AgentConversationViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing agent conversations.

    Supports both authenticated users and anonymous sessions.
    """

    serializer_class = AgentConversationSerializer
    authentication_classes = _AUTH_CLASSES
    permission_classes = [IsAuthenticatedOrAnonymousSession]

    def get_queryset(self):
        """Filter conversations by user or anonymous session."""
        if self.request.user and self.request.user.is_authenticated:
            return AgentConversation.objects.filter(user=self.request.user)

        # For anonymous sessions, filter by anonymous_session
        session = get_anonymous_session(self.request)
        if session:
            return AgentConversation.objects.filter(anonymous_session=session)

        return AgentConversation.objects.none()

    def perform_create(self, serializer):
        """Set user or anonymous session on creation."""
        if self.request.user and self.request.user.is_authenticated:
            serializer.save(user=self.request.user)
        else:
            session = get_anonymous_session(self.request)
            serializer.save(anonymous_session=session)


class AgentRunViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing agent runs.

    Endpoints:
    - POST /runs/ - Create a new run
    - GET /runs/ - List runs
    - GET /runs/{id}/ - Get run details
    - POST /runs/{id}/cancel/ - Cancel a run
    - GET /runs/{id}/events/ - Get events (SSE)

    Supports both authenticated users and anonymous sessions.
    """

    authentication_classes = _AUTH_CLASSES
    permission_classes = [IsAuthenticatedOrAnonymousSession]

    def get_serializer_class(self):
        if self.action == "create":
            return AgentRunCreateSerializer
        elif self.action == "retrieve":
            return AgentRunDetailSerializer
        return AgentRunSerializer

    def get_queryset(self):
        """Filter runs by user's conversations or anonymous session."""
        from django.db.models import Q

        if self.request.user and self.request.user.is_authenticated:
            # Include runs with user's conversations OR runs without conversation
            # that were created by this user (stored in metadata)
            return AgentRun.objects.filter(
                Q(conversation__user=self.request.user) |
                Q(conversation__isnull=True, metadata__user_id=self.request.user.id)
            ).select_related("conversation")

        # For anonymous sessions
        session = get_anonymous_session(self.request)
        if session:
            return AgentRun.objects.filter(
                Q(conversation__anonymous_session=session) |
                Q(conversation__isnull=True, metadata__anonymous_token=session.token)
            ).select_related("conversation")

        return AgentRun.objects.none()

    def create(self, request, *args, **kwargs):
        """Create a new agent run."""
        serializer = self.get_serializer(data=request.data)
        serializer.validate(request.data)
        serializer.is_valid(raise_exception=True)

        data = serializer.validated_data

        # Check authorization (skip for anonymous sessions)
        settings = runtime_settings()
        if request.user and request.user.is_authenticated:
            authz_hook = get_hook(settings.AUTHZ_HOOK)
            if authz_hook and not authz_hook(request.user, "create_run", data):
                return Response(
                    {"error": "Not authorized to create this run"},
                    status=status.HTTP_403_FORBIDDEN,
                )

            # Check quota
            quota_hook = get_hook(settings.QUOTA_HOOK)
            if quota_hook and not quota_hook(request.user, data["agent_key"]):
                return Response(
                    {"error": "Quota exceeded"},
                    status=status.HTTP_429_TOO_MANY_REQUESTS,
                )

        # Get or create conversation
        conversation = None
        session = get_anonymous_session(request)

        if data.get("conversation_id"):
            try:
                if request.user and request.user.is_authenticated:
                    conversation = AgentConversation.objects.get(
                        id=data["conversation_id"],
                        user=request.user,
                    )
                elif session:
                    conversation = AgentConversation.objects.get(
                        id=data["conversation_id"],
                        anonymous_session=session,
                    )
            except AgentConversation.DoesNotExist:
                return Response(
                    {"error": "Conversation not found"},
                    status=status.HTTP_404_NOT_FOUND,
                )

        # Check idempotency
        if data.get("idempotency_key"):
            existing = AgentRun.objects.filter(
                idempotency_key=data["idempotency_key"]
            ).first()
            if existing:
                return Response(
                    AgentRunSerializer(existing).data,
                    status=status.HTTP_200_OK,
                )

        # Build metadata with session/user info
        metadata = {
            **data.get("metadata", {}),
            "conversation_id": str(conversation.id) if conversation else None,
        }
        if request.user and request.user.is_authenticated:
            metadata["user_id"] = request.user.id
        if session:
            metadata["anonymous_token"] = session.token

        # Create the run
        run = AgentRun.objects.create(
            conversation=conversation,
            agent_key=data["agent_key"],
            input={
                "messages": data["messages"],
                "params": data.get("params", {}),
            },
            max_attempts=data.get("max_attempts", 3),
            idempotency_key=data.get("idempotency_key"),
            metadata=metadata,
        )

        # Enqueue to Redis if using Redis queue
        if settings.QUEUE_BACKEND == "redis_streams":
            asyncio.run(self._enqueue_to_redis(run))

        return Response(
            AgentRunSerializer(run).data,
            status=status.HTTP_201_CREATED,
        )

    async def _enqueue_to_redis(self, run: AgentRun):
        """Enqueue run to Redis stream."""
        from django_agent_runtime.runtime.queue.redis_streams import RedisStreamsQueue

        settings = runtime_settings()
        queue = RedisStreamsQueue(redis_url=settings.REDIS_URL)
        await queue.enqueue(run.id, run.agent_key)
        await queue.close()

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        """Cancel a running agent run."""
        run = self.get_object()

        if run.is_terminal:
            return Response(
                {"error": "Run is already complete"},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Request cancellation
        from django.utils import timezone

        run.cancel_requested_at = timezone.now()
        run.save(update_fields=["cancel_requested_at"])

        return Response({"status": "cancellation_requested"})

    def _event_stream(self, run_id: UUID, from_seq: int):
        """Generate SSE event stream."""
        import time
        from django_agent_runtime.runtime.events import get_event_bus

        settings = runtime_settings()

        # Use sync event fetching for SSE (simpler than async in Django views)
        current_seq = from_seq
        keepalive_interval = settings.SSE_KEEPALIVE_SECONDS

        while True:
            # Get new events from database
            events = list(
                AgentEvent.objects.filter(
                    run_id=run_id,
                    seq__gte=current_seq,
                ).order_by("seq")
            )

            for event in events:
                data = {
                    "run_id": str(event.run_id),
                    "seq": event.seq,
                    "type": event.event_type,
                    "payload": event.payload,
                    "ts": event.timestamp.isoformat(),
                }
                yield f"data: {json.dumps(data)}\n\n"
                current_seq = event.seq + 1

                # Check for terminal events
                if event.event_type in (
                    "run.succeeded",
                    "run.failed",
                    "run.cancelled",
                    "run.timed_out",
                ):
                    return

            # Check if run is complete
            try:
                run = AgentRun.objects.get(id=run_id)
                if run.is_terminal:
                    return
            except AgentRun.DoesNotExist:
                return

            # Send keepalive
            yield f": keepalive\n\n"

            # Wait before polling again
            time.sleep(0.5)


# Async SSE view for ASGI deployments
def sync_event_stream(request, run_id: str):
    """
    Sync SSE endpoint for streaming events.

    This is a plain Django view (not DRF) to avoid content negotiation issues.
    Supports both authenticated users, JWT tokens, and anonymous sessions.
    """
    import time
    from django.http import JsonResponse

    try:
        run_uuid = UUID(run_id)
    except ValueError:
        return JsonResponse({"error": "Invalid run ID"}, status=400)

    from_seq = int(request.GET.get("from_seq", 0))

    # Check authorization - support multiple auth methods
    anonymous_token = request.headers.get('X-Anonymous-Token') or request.GET.get('anonymous_token')
    jwt_token = request.GET.get('token')  # JWT token passed as query param for SSE

    try:
        run = AgentRun.objects.select_related("conversation").get(id=run_uuid)
    except AgentRun.DoesNotExist:
        return JsonResponse({"error": "Run not found"}, status=404)

    # Check access
    has_access = False
    authenticated_user = None

    # First check if user is already authenticated via session
    if request.user and request.user.is_authenticated:
        authenticated_user = request.user
    # Try JWT token authentication
    elif jwt_token and HAS_JWT:
        try:
            from rest_framework_simplejwt.tokens import AccessToken
            from django.contrib.auth import get_user_model
            User = get_user_model()

            token = AccessToken(jwt_token)
            user_id = token.get('user_id')
            if user_id:
                authenticated_user = User.objects.get(id=user_id)
        except Exception:
            pass

    # Check access based on authenticated user
    if authenticated_user:
        if run.conversation and run.conversation.user == authenticated_user:
            has_access = True
        elif not run.conversation:
            has_access = True
    # Check anonymous token
    elif anonymous_token:
        try:
            from django_agent_runtime.api.permissions import _get_anonymous_session_model
            AnonymousSession = _get_anonymous_session_model()
            if AnonymousSession:
                session = AnonymousSession.objects.get(token=anonymous_token)
                is_expired = getattr(session, 'is_expired', False)
                if not is_expired:
                    if run.conversation and run.conversation.anonymous_session == session:
                        has_access = True
                    elif not run.conversation:
                        # Run without conversation - check metadata
                        if run.metadata.get("anonymous_token") == anonymous_token:
                            has_access = True
        except Exception:
            pass

    if not has_access:
        return JsonResponse({"error": "Not authorized"}, status=403)

    settings = runtime_settings()
    if not settings.ENABLE_SSE:
        return JsonResponse({"error": "SSE streaming is disabled"}, status=503)

    def event_generator():
        current_seq = from_seq

        while True:
            # Get new events from database
            events = list(
                AgentEvent.objects.filter(
                    run_id=run_uuid,
                    seq__gte=current_seq,
                ).order_by("seq")
            )

            for event in events:
                data = {
                    "run_id": str(event.run_id),
                    "seq": event.seq,
                    "type": event.event_type,
                    "payload": event.payload,
                    "ts": event.timestamp.isoformat(),
                }
                yield f"data: {json.dumps(data)}\n\n"
                current_seq = event.seq + 1

                # Check for terminal events
                if event.event_type in (
                    "run.succeeded",
                    "run.failed",
                    "run.cancelled",
                    "run.timed_out",
                ):
                    return

            # Check if run is complete
            try:
                run_check = AgentRun.objects.get(id=run_uuid)
                if run_check.is_terminal:
                    return
            except AgentRun.DoesNotExist:
                return

            # Send keepalive
            yield ": keepalive\n\n"

            # Wait before polling again
            time.sleep(0.5)

    response = StreamingHttpResponse(
        event_generator(),
        content_type="text/event-stream",
    )
    response["Cache-Control"] = "no-cache"
    response["X-Accel-Buffering"] = "no"
    response["Access-Control-Allow-Origin"] = "*"
    return response


async def async_event_stream(request, run_id: str):
    """
    Async SSE endpoint for streaming events.

    Use this with ASGI servers (uvicorn, daphne) for better performance.
    """
    from django.http import StreamingHttpResponse
    from asgiref.sync import sync_to_async

    run_id = UUID(run_id)
    from_seq = int(request.GET.get("from_seq", 0))

    # Check authorization
    @sync_to_async
    def check_access():
        try:
            run = AgentRun.objects.select_related("conversation").get(id=run_id)
            if run.conversation and run.conversation.user != request.user:
                return None
            return run
        except AgentRun.DoesNotExist:
            return None

    run = await check_access()
    if not run:
        from django.http import JsonResponse

        return JsonResponse({"error": "Not found"}, status=404)

    async def event_generator():
        from django_agent_runtime.runtime.events import get_event_bus

        settings = runtime_settings()
        event_bus = get_event_bus(settings.EVENT_BUS_BACKEND)

        try:
            async for event in event_bus.subscribe(run_id, from_seq=from_seq):
                data = event.to_dict()
                yield f"data: {json.dumps(data)}\n\n"

                # Check for terminal events
                if event.event_type in (
                    "run.succeeded",
                    "run.failed",
                    "run.cancelled",
                    "run.timed_out",
                ):
                    break
        finally:
            await event_bus.close()

    response = StreamingHttpResponse(
        event_generator(),
        content_type="text/event-stream",
    )
    response["Cache-Control"] = "no-cache"
    response["X-Accel-Buffering"] = "no"
    return response
