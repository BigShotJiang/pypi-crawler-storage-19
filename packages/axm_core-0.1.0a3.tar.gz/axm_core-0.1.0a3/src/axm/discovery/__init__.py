"""AXM Discovery module.

This module is reserved for future extensibility.
Current discovery is handled via AST parsing in axm_cli.commands.discover.
"""
