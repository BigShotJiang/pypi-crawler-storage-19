"""Connector protocol for pluggable file I/O.

This module defines the abstract Connector protocol that allows
AXM operations to work with different storage backends.
"""

from pathlib import Path
from typing import Protocol, runtime_checkable


@runtime_checkable
class Connector(Protocol):
    """Abstract file connector for pluggable I/O.

    Implementations can support local filesystem, S3, GCS, etc.
    """

    def read_bytes(self, path: str) -> bytes:
        """Read raw bytes from path.

        Args:
            path: Path to read from.

        Returns:
            File content as bytes.

        Raises:
            FileNotFoundError: If path does not exist.
        """
        ...

    def write_bytes(self, path: str, data: bytes) -> None:
        """Write raw bytes to path.

        Args:
            path: Path to write to.
            data: Bytes to write.
        """
        ...

    def exists(self, path: str) -> bool:
        """Check if path exists.

        Args:
            path: Path to check.

        Returns:
            True if path exists, False otherwise.
        """
        ...


class LocalConnector:
    """Local filesystem connector.

    Default implementation using pathlib for local file operations.
    """

    def read_bytes(self, path: str) -> bytes:
        """Read raw bytes from local path."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"File not found: {path}")
        return p.read_bytes()

    def write_bytes(self, path: str, data: bytes) -> None:
        """Write raw bytes to local path."""
        Path(path).write_bytes(data)

    def exists(self, path: str) -> bool:
        """Check if local path exists."""
        return Path(path).exists()
