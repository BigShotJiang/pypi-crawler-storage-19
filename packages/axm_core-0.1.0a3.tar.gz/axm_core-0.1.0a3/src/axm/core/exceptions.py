"""AXM custom exceptions hierarchy.

Provides a unified exception hierarchy for all AXM components.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from axm.catalog.rules.engine import DataQualityReport


class AXMError(Exception):
    """Base exception for all AXM errors."""


class CatalogError(AXMError):
    """Raised for catalog-related errors (entry not found, invalid schema)."""


class ExecutionError(AXMError):
    """Raised when pipeline or operation execution fails.

    Attributes:
        operation: Name of the operation that failed (optional).
    """

    def __init__(self, message: str, operation: str | None = None) -> None:
        """Initialize ExecutionError.

        Args:
            message: Error message.
            operation: Optional operation name for context.
        """
        self.operation = operation
        if operation:
            message = f"[{operation}] {message}"
        super().__init__(message)


class SchemaValidationError(AXMError):
    """Raised when data validation fails against schema.

    Attributes:
        field: Name of the field that failed validation.
    """

    def __init__(self, message: str, field: str | None = None) -> None:
        """Initialize SchemaValidationError.

        Args:
            message: Error message.
            field: Optional field name for context.
        """
        self.field = field
        if field:
            message = f"Field '{field}': {message}"
        super().__init__(message)


class DataQualityError(AXMError):
    """Raised when data fails quality checks with ERROR severity.

    This exception is raised by PipelineRunner when output data
    violates quality rules that are configured with severity="error"
    and the violation percentage exceeds the threshold.

    Attributes:
        report: The DataQualityReport with detailed violation info.
    """

    def __init__(self, message: str, report: DataQualityReport | None = None) -> None:
        """Initialize DataQualityError.

        Args:
            message: Error message describing the quality failure.
            report: Optional DataQualityReport with full details.
        """
        super().__init__(message)
        self.report = report

    def __str__(self) -> str:
        """Return error message with report summary if available."""
        if self.report:
            return f"{self.args[0]!s}\n{self.report.summary()}"
        return str(self.args[0])
