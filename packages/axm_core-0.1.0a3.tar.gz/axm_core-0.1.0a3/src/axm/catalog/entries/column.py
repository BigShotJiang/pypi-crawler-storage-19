"""Column schema models with data quality rules.

This module defines the Column model used in tabular schemas with
support for column-level validation rules.
"""

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class ColumnRuleConfig(BaseModel):
    """Configuration for a column validation rule.

    Attributes:
        rule: Rule type.
        severity: Error or warning level.
        threshold: Max percentage of violations allowed (0.0 - 1.0).
        min: Minimum value for range rule.
        max: Maximum value for range rule.
        pattern: Regex pattern for pattern rule.
        allowed: List of allowed values for in_set rule.
        min_len: Minimum string length for length rule.
        max_len: Maximum string length for length rule.
    """

    rule: Literal[
        "range",
        "pattern",
        "unique",
        "not_null",
        "in_set",
        "not_empty",
        "email",
        "positive",
        "length",
    ]
    severity: Literal["error", "warning"] = "error"
    threshold: float = 0.0

    # Range rule params
    min: float | None = None
    max: float | None = None

    # Pattern rule params
    pattern: str | None = None

    # InSet rule params
    allowed: list[Any] | None = None

    # Length rule params
    min_len: int | None = None
    max_len: int | None = None


class Column(BaseModel):
    """Column definition for tabular schemas.

    Attributes:
        name: Column name.
        type: Data type (int, float, string, bool, datetime).
        nullable: Whether nulls are allowed.
        description: Column description.
        rules: List of validation rules to apply.

    Example:
        >>> col = Column(
        ...     name="age",
        ...     type="int",
        ...     rules=[
        ...         ColumnRuleConfig(rule="range", min=0, max=120),
        ...         ColumnRuleConfig(rule="not_null", threshold=0.01),
        ...     ],
        ... )
    """

    name: str
    type: str
    nullable: bool = False
    description: str = ""
    rules: list[ColumnRuleConfig] = Field(default_factory=list)


class TabularSpec(BaseModel):
    """Spec wrapper for YAML compatibility.

    Matches the nested 'spec.columns' structure in .axm files.

    Attributes:
        columns: List of column definitions.
        evolution_policy: How schema changes are handled.
    """

    columns: list[Column] = Field(default_factory=list)
    evolution_policy: str | None = None


class TabularSchema(BaseModel):
    """Schema specification for tabular data.

    Supports both flat and nested access patterns:
    - Flat: schema.columns (for RuleEngine backward compat)
    - Nested: schema.spec.columns (for YAML loading)

    Attributes:
        format: Schema format type.
        spec: Nested spec containing columns.
        columns: Flat column list (synced with spec).
    """

    format: str = "tabular"
    spec: TabularSpec | None = None
    columns: list[Column] = Field(default_factory=list)

    @model_validator(mode="after")
    def sync_columns(self) -> "TabularSchema":
        """Sync columns between spec and flat access."""
        if self.spec and self.spec.columns and not self.columns:
            object.__setattr__(self, "columns", self.spec.columns)
        elif self.columns and not self.spec:
            object.__setattr__(self, "spec", TabularSpec(columns=self.columns))
        return self
