"""DataCatalog container for AXM catalog entries."""

from collections.abc import Iterator
from pathlib import Path
from typing import Any, Self

from axm.catalog.entries.data import DataEntry
from axm.catalog.entries.operation import OperationEntry
from axm.catalog.entries.pipeline import PipelineEntry
from axm.catalog.loading.yaml_loader import CatalogEntry, load_catalog_entry
from axm.logging import get_logger

logger = get_logger("axm-core")


class DataCatalog:
    """A catalog of entries loaded from YAML files.

    Entries are stored in separate registries by kind to avoid name collisions.
    """

    def __init__(self) -> None:
        """Initialize empty catalog with separate registries."""
        self._data: dict[str, DataEntry] = {}
        self._operations: dict[str, OperationEntry] = {}
        self._pipelines: dict[str, PipelineEntry] = {}

    @property
    def data(self) -> dict[str, DataEntry]:
        """Access data entries registry."""
        return self._data

    @property
    def operations(self) -> dict[str, OperationEntry]:
        """Access operation entries registry."""
        return self._operations

    @property
    def pipelines(self) -> dict[str, PipelineEntry]:
        """Access pipeline entries registry."""
        return self._pipelines

    def __getitem__(self, key: str) -> CatalogEntry:
        """Get entry by namespaced key or legacy name.

        Supports: 'data:name', 'operation:name', 'pipeline:name'
        Or legacy: 'name' (searches in order: data, operations, pipelines)
        """
        if ":" in key:
            kind, name = key.split(":", 1)
            if kind == "data":
                return self._data[name]
            elif kind == "operation":
                return self._operations[name]
            elif kind == "pipeline":
                return self._pipelines[name]
            else:
                raise KeyError(f"Unknown kind: {kind}")

        # Legacy: search in order
        if key in self._data:
            return self._data[key]
        if key in self._operations:
            return self._operations[key]
        if key in self._pipelines:
            return self._pipelines[key]
        raise KeyError(key)

    def __contains__(self, key: str) -> bool:
        """Check if entry exists (any registry)."""
        if ":" in key:
            kind, name = key.split(":", 1)
            if kind == "data":
                return name in self._data
            elif kind == "operation":
                return name in self._operations
            elif kind == "pipeline":
                return name in self._pipelines
            return False
        return key in self._data or key in self._operations or key in self._pipelines

    def __iter__(self) -> Iterator[CatalogEntry]:
        """Iterate over all entries (all registries)."""
        yield from self._data.values()
        yield from self._operations.values()
        yield from self._pipelines.values()

    def __len__(self) -> int:
        """Total number of entries across all registries."""
        return len(self._data) + len(self._operations) + len(self._pipelines)

    def register(self, entry: CatalogEntry) -> None:
        """Register an entry in the appropriate registry by kind."""
        if isinstance(entry, DataEntry):
            self._data[entry.name] = entry
        elif isinstance(entry, OperationEntry):
            self._operations[entry.name] = entry
        elif isinstance(entry, PipelineEntry):
            self._pipelines[entry.name] = entry
        else:
            # Fallback: detect by kind field
            kind = getattr(entry, "kind", None)
            if kind == "data":
                self._data[entry.name] = entry  # type: ignore
            elif kind == "operation":
                self._operations[entry.name] = entry  # type: ignore
            elif kind == "pipeline":
                self._pipelines[entry.name] = entry  # type: ignore
            else:
                logger.warning(f"Unknown entry kind for {entry.name}, skipping")

    def get(self, key: str, default: Any = None) -> CatalogEntry | Any:
        """Get entry by name with default."""
        try:
            return self[key]
        except KeyError:
            return default

    @classmethod
    def from_directory(cls, path: Path | str) -> Self:
        """Load catalog from a directory of YAML files.

        Args:
            path: Directory containing .axm files.

        Returns:
            DataCatalog with all loaded entries.
        """
        path = Path(path)
        catalog = cls()
        patterns = ["*.axm"]
        for pattern in patterns:
            for yaml_file in path.rglob(pattern):
                try:
                    entry = load_catalog_entry(yaml_file)
                    catalog.register(entry)
                except Exception as e:
                    logger.error(f"Failed to load {yaml_file}: {e}")
        return catalog
