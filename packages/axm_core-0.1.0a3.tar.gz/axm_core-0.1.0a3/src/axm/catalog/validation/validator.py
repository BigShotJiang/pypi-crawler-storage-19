"""Validator for DataEntry schemas."""

import time
from typing import Any

from axm.catalog.entries import DataEntry
from axm.catalog.validation.registry import ValidatorRegistry
from axm.core import BaseValidator, Severity, ValidationError, ValidationResult
from axm.observability.hooks import get_audit_hook


class SchemaValidator(BaseValidator):
    """Validates data against DataEntry schema using registered validators."""

    def __init__(self, entry: DataEntry) -> None:
        """Initialize validator with data entry definition."""
        self.entry = entry

    def validate(self, data: Any) -> ValidationResult:
        """Validate data against schema.

        Args:
            data: The data object to validate (type depends on format).

        Returns:
            ValidationResult containing status and errors.
        """
        hook = get_audit_hook()
        hook.on_validate_start(self.entry.name)
        start = time.perf_counter_ns()

        try:
            result = self._do_validate(data)
        finally:
            duration_ns = time.perf_counter_ns() - start
            hook.on_validate_end(self.entry.name, result.is_valid, duration_ns)

        return result

    def _do_validate(self, data: Any) -> ValidationResult:
        """Internal validation logic."""
        fmt = self.entry.data_schema.format

        # Look up validator class for the format
        validator_cls = ValidatorRegistry.get(fmt)

        if not validator_cls:
            return ValidationResult(
                is_valid=False,
                errors=[
                    ValidationError(
                        field="schema.format",
                        message=f"No validator registered for format: {fmt}",
                        severity=Severity.ERROR,
                    )
                ],
            )

        # Instantiate and delegate
        try:
            validator = validator_cls(self.entry)
            return validator.validate(data)
        except Exception as e:
            return ValidationResult(
                is_valid=False,
                errors=[
                    ValidationError(
                        field="validator",
                        message=f"Validator execution failed: {e}",
                        severity=Severity.ERROR,
                    )
                ],
            )
