"""Column-level validation rules using Polars.

This module provides rules for validating DataFrame columns with thresholds
and severity levels for Zero-Trust data quality enforcement.
"""

from typing import Any

import polars as pl
from pydantic import BaseModel, Field

from axm.core import Severity


class ColumnValidationResult(BaseModel):
    """Result of validating a column against a rule."""

    column: str
    rule: str
    total_rows: int
    violations: int
    violation_percent: float
    threshold: float
    severity: Severity
    sample_violations: list[Any] = Field(default_factory=list)

    @property
    def passed(self) -> bool:
        """Check if validation passed (violations within threshold)."""
        return self.violation_percent <= self.threshold


class ColumnRule(BaseModel):
    """Base class for column-level validation rules."""

    severity: Severity = Severity.ERROR
    threshold: float = 0.0

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Validate a Polars Series against this rule.

        Args:
            series: The Polars Series to validate.

        Returns:
            ColumnValidationResult with violation statistics.
        """
        raise NotImplementedError("Subclasses must implement validate_column")

    def _build_result(
        self,
        series: pl.Series,
        rule_name: str,
        violations: int,
        sample_violations: list[Any] | None = None,
    ) -> ColumnValidationResult:
        """Build a validation result from violation count."""
        total = len(series)
        return ColumnValidationResult(
            column=series.name,
            rule=rule_name,
            total_rows=total,
            violations=violations,
            violation_percent=violations / total if total > 0 else 0.0,
            threshold=self.threshold,
            severity=self.severity,
            sample_violations=sample_violations or [],
        )


class RangeRule(ColumnRule):
    """Validate numeric values are within a range.

    Example:
        >>> rule = RangeRule(min=0, max=120)
        >>> result = rule.validate_column(pl.Series("age", [25, -5, 150]))
        >>> result.violations
        2
    """

    min: float | None = None
    max: float | None = None

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count values outside the allowed range."""
        # Build boolean mask for valid values
        valid_mask = pl.Series([True] * len(series))

        if self.min is not None:
            valid_mask = valid_mask & (series >= self.min)
        if self.max is not None:
            valid_mask = valid_mask & (series <= self.max)

        violations = int((~valid_mask).sum())

        # Get sample violations
        invalid_values = series.filter(~valid_mask).head(5).to_list()

        return self._build_result(series, "range", violations, invalid_values)


class PatternRule(ColumnRule):
    """Validate string values match a regex pattern.

    Example:
        >>> rule = PatternRule(pattern=r"^[a-z]+@.+$")
        >>> result = rule.validate_column(pl.Series("email", ["a@b.com", "invalid"]))
        >>> result.violations
        1
    """

    pattern: str

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count values not matching the pattern."""
        matches = series.str.contains(self.pattern)
        violations = int((~matches).sum())

        # Get sample violations
        invalid_values = series.filter(~matches).head(5).to_list()

        return self._build_result(series, "pattern", violations, invalid_values)


class UniqueRule(ColumnRule):
    """Validate column values are unique (no duplicates).

    Violations = total rows - unique values count.

    Example:
        >>> rule = UniqueRule()
        >>> result = rule.validate_column(pl.Series("id", [1, 2, 2, 3]))
        >>> result.violations
        1
    """

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count duplicate values."""
        unique_count = series.n_unique()
        total = len(series)
        violations = total - unique_count

        # Get sample duplicates
        value_counts = series.value_counts()
        duplicates = value_counts.filter(pl.col("count") > 1)
        sample_violations = duplicates.head(5)[series.name].to_list()

        return self._build_result(series, "unique", violations, sample_violations)


class NotNullRule(ColumnRule):
    """Validate column has no null values (with optional threshold).

    Example:
        >>> rule = NotNullRule(threshold=0.1)  # Allow up to 10% nulls
        >>> result = rule.validate_column(pl.Series("name", ["A", None, "B"]))
        >>> result.violations
        1
    """

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count null values."""
        violations = series.null_count()

        return self._build_result(series, "not_null", violations)


class InSetRule(ColumnRule):
    """Validate values are in an allowed set.

    Example:
        >>> rule = InSetRule(allowed=["active", "inactive"])
        >>> result = rule.validate_column(pl.Series("status", ["active", "unknown"]))
        >>> result.violations
        1
    """

    allowed: list[str | int | float]

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count values not in allowed set."""
        is_valid = series.is_in(self.allowed)
        violations = int((~is_valid).sum())

        # Get sample violations
        invalid_values = series.filter(~is_valid).head(5).to_list()

        return self._build_result(series, "in_set", violations, invalid_values)


class NotEmptyRule(ColumnRule):
    """Validate string values are not empty or whitespace-only.

    Checks for: null values, empty strings, whitespace-only strings.

    Example:
        >>> rule = NotEmptyRule()
        >>> result = rule.validate_column(pl.Series("name", ["Alice", "", "   "]))
        >>> result.violations
        2
    """

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count empty/null/whitespace-only values."""
        # Null check
        is_null = series.is_null()

        # Empty or whitespace-only check (for strings)
        is_empty = series.str.strip_chars().str.len_chars() == 0

        # Combine: violation if null OR empty/whitespace
        violation_mask = is_null | is_empty
        violations = int(violation_mask.sum())

        # Get sample violations
        invalid_values = series.filter(violation_mask).head(5).to_list()

        return self._build_result(series, "not_empty", violations, invalid_values)


class EmailRule(ColumnRule):
    """Validate string values are valid email addresses.

    Uses a practical regex pattern for email validation.

    Example:
        >>> rule = EmailRule()
        >>> result = rule.validate_column(pl.Series("email", ["a@b.com", "invalid"]))
        >>> result.violations
        1
    """

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count invalid email addresses."""
        # Practical email regex: local@domain.tld
        # Allows: letters, numbers, dots, plus, underscore, dash
        # Requires: @ followed by domain with at least one dot
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"

        matches = series.str.contains(pattern)
        violations = int((~matches).sum())

        # Get sample violations
        invalid_values = series.filter(~matches).head(5).to_list()

        return self._build_result(series, "email", violations, invalid_values)


class PositiveRule(ColumnRule):
    """Validate numeric values are strictly positive (> 0).

    Zero is NOT considered positive and will be a violation.

    Example:
        >>> rule = PositiveRule()
        >>> result = rule.validate_column(pl.Series("amount", [1, 0, -5]))
        >>> result.violations
        2
    """

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count non-positive values (zero and negatives)."""
        valid_mask = series > 0
        violations = int((~valid_mask).sum())

        # Get sample violations
        invalid_values = series.filter(~valid_mask).head(5).to_list()

        return self._build_result(series, "positive", violations, invalid_values)


class LengthRule(ColumnRule):
    """Validate string length is within bounds.

    Example:
        >>> rule = LengthRule(min_len=2, max_len=10)
        >>> result = rule.validate_column(pl.Series("code", ["A", "ABCDEFGHIJK"]))
        >>> result.violations
        2
    """

    min_len: int | None = None
    max_len: int | None = None

    def validate_column(self, series: pl.Series) -> ColumnValidationResult:
        """Count strings outside length bounds."""
        char_lengths = series.str.len_chars()

        # Start with all valid
        valid_mask = pl.Series([True] * len(series))

        if self.min_len is not None:
            valid_mask = valid_mask & (char_lengths >= self.min_len)
        if self.max_len is not None:
            valid_mask = valid_mask & (char_lengths <= self.max_len)

        violations = int((~valid_mask).sum())

        # Get sample violations
        invalid_values = series.filter(~valid_mask).head(5).to_list()

        return self._build_result(series, "length", violations, invalid_values)
