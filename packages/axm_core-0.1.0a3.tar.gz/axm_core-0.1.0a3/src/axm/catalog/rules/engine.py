"""RuleEngine - Validates DataFrames against column rules.

This module provides the core validation engine that applies column rules
to Polars DataFrames and generates quality reports.
"""

from datetime import UTC, datetime

import polars as pl
from pydantic import BaseModel, Field

from axm.catalog.entries.column import ColumnRuleConfig, TabularSchema
from axm.catalog.rules.column_rules import (
    ColumnRule,
    ColumnValidationResult,
    EmailRule,
    InSetRule,
    LengthRule,
    NotEmptyRule,
    NotNullRule,
    PatternRule,
    PositiveRule,
    RangeRule,
    UniqueRule,
)
from axm.core import Severity


class DataQualityReport(BaseModel):
    """Complete data quality validation report.

    Attributes:
        timestamp: When the validation was performed.
        total_columns: Number of columns validated.
        results: List of validation results per rule.
        passed: Overall pass/fail status (no ERROR violations over threshold).
        has_errors: Whether any ERROR severity rules failed.
        has_warnings: Whether any WARNING severity rules exceeded threshold.
    """

    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    total_columns: int = 0
    results: list[ColumnValidationResult] = Field(default_factory=list)

    @property
    def passed(self) -> bool:
        """Report passes if no ERROR severity violations exceed threshold."""
        for result in self.results:
            if result.severity == Severity.ERROR and not result.passed:
                return False
        return True

    @property
    def has_errors(self) -> bool:
        """Check if any ERROR severity rules failed."""
        return any(r.severity == Severity.ERROR and not r.passed for r in self.results)

    @property
    def has_warnings(self) -> bool:
        """Check if any WARNING severity rules exceeded threshold."""
        return any(
            r.severity == Severity.WARNING and not r.passed for r in self.results
        )

    def summary(self) -> str:
        """Generate one-line summary of validation results."""
        if not self.results:
            return "No rules to validate"

        failed = [r for r in self.results if not r.passed]
        if not failed:
            return f"✅ All {len(self.results)} rules passed"

        parts = []
        for r in failed:
            icon = "❌" if r.severity == Severity.ERROR else "⚠️"
            parts.append(f"{icon} {r.column}: {r.violations} violations ({r.rule})")

        return " | ".join(parts)


class RuleEngine:
    """Engine for validating DataFrames against column rules.

    Example:
        >>> schema = TabularSchema(columns=[...])
        >>> df = pl.DataFrame({...})
        >>> engine = RuleEngine()
        >>> report = engine.validate(df, schema)
        >>> if not report.passed:
        ...     raise DataQualityError(report.summary())
    """

    def validate(self, df: pl.DataFrame, schema: TabularSchema) -> DataQualityReport:
        """Validate a DataFrame against a TabularSchema.

        Args:
            df: The Polars DataFrame to validate.
            schema: The TabularSchema with column rules.

        Returns:
            DataQualityReport with all validation results.
        """
        results: list[ColumnValidationResult] = []

        for column in schema.columns:
            if column.name not in df.columns:
                continue

            series = df[column.name]

            for rule_config in column.rules:
                rule = self._create_rule(rule_config)
                result = rule.validate_column(series)
                results.append(result)

        return DataQualityReport(
            total_columns=len(schema.columns),
            results=results,
        )

    def _create_rule(self, config: ColumnRuleConfig) -> "ColumnRule":
        """Create a ColumnRule from configuration."""
        severity = Severity.ERROR if config.severity == "error" else Severity.WARNING

        if config.rule == "range":
            return RangeRule(
                min=config.min,
                max=config.max,
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "pattern":
            return PatternRule(
                pattern=config.pattern or "",
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "unique":
            return UniqueRule(
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "not_null":
            return NotNullRule(
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "in_set":
            return InSetRule(
                allowed=config.allowed or [],
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "not_empty":
            return NotEmptyRule(
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "email":
            return EmailRule(
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "positive":
            return PositiveRule(
                severity=severity,
                threshold=config.threshold,
            )
        elif config.rule == "length":
            return LengthRule(
                min_len=config.min_len,
                max_len=config.max_len,
                severity=severity,
                threshold=config.threshold,
            )
        else:
            raise ValueError(f"Unknown rule type: {config.rule}")

    def validate_batch(
        self, df: pl.DataFrame, schema: TabularSchema
    ) -> DataQualityReport:
        """Validate all rules in a single Polars pass.

        This is more efficient than validate() for large DataFrames
        as it combines all rule checks into one expression evaluation.

        Args:
            df: The Polars DataFrame to validate.
            schema: The TabularSchema with column rules.

        Returns:
            DataQualityReport with all validation results.
        """
        exprs: list[pl.Expr] = []
        rule_meta: list[tuple[str, ColumnRuleConfig]] = []

        for column in schema.columns:
            if column.name not in df.columns:
                continue
            for rule_config in column.rules:
                expr = self._rule_to_expr(column.name, rule_config)
                if expr is not None:
                    alias = f"_valid_{column.name}_{rule_config.rule}"
                    exprs.append(expr.alias(alias))
                    rule_meta.append((column.name, rule_config))

        if not exprs:
            return DataQualityReport(total_columns=len(schema.columns))

        # Single pass: compute all validity masks together
        masks_df = df.select(exprs)

        # Build results from mask columns
        results: list[ColumnValidationResult] = []
        for (col_name, config), mask_col in zip(
            rule_meta, masks_df.columns, strict=True
        ):
            mask = masks_df[mask_col]
            total_rows = len(mask)
            valid_count = mask.sum()
            violations = total_rows - valid_count
            violation_percent = violations / total_rows if total_rows > 0 else 0.0
            sev = Severity.ERROR if config.severity == "error" else Severity.WARNING

            results.append(
                ColumnValidationResult(
                    column=col_name,
                    rule=config.rule,
                    violations=violations,
                    total_rows=total_rows,
                    violation_percent=violation_percent,
                    threshold=config.threshold,
                    severity=sev,
                )
            )

        return DataQualityReport(
            total_columns=len(schema.columns),
            results=results,
        )

    def _rule_to_expr(self, col_name: str, config: ColumnRuleConfig) -> pl.Expr | None:
        """Convert rule config to Polars expression returning boolean mask."""
        col = pl.col(col_name)

        if config.rule == "range":
            return col.is_between(config.min, config.max)
        elif config.rule == "pattern":
            return col.str.contains(config.pattern or "")
        elif config.rule == "in_set":
            return col.is_in(config.allowed or [])
        elif config.rule == "not_null":
            return col.is_not_null()
        elif config.rule == "not_empty":
            return col.str.len_chars() > 0
        elif config.rule == "positive":
            return col > 0
        elif config.rule == "email":
            # Simple email pattern
            return col.str.contains(r"^[^@]+@[^@]+\.[^@]+$")
        elif config.rule == "length":
            expr = pl.lit(True)
            if config.min_len is not None:
                expr = expr & (col.str.len_chars() >= config.min_len)
            if config.max_len is not None:
                expr = expr & (col.str.len_chars() <= config.max_len)
            return expr
        elif config.rule == "unique":
            # Unique requires special handling - not expressible as simple mask
            return col.is_unique()
        else:
            return None
