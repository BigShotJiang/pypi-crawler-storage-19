"""Observability module for AXM."""

from axm.observability.hooks import AuditHook, NullHook, get_audit_hook, set_audit_hook

__all__ = ["AuditHook", "NullHook", "get_audit_hook", "set_audit_hook"]
