"""Audit hooks for optional observability integration.

This module provides the AuditHook protocol and a NullHook default
that allows axm-audit to optionally inject timing instrumentation.
"""

from typing import Protocol, runtime_checkable


@runtime_checkable
class AuditHook(Protocol):
    """Protocol for audit hooks (optional axm-audit integration).

    Implementations receive notifications for validation events
    to measure the 'Trust Tax' (validation overhead).
    """

    def on_validate_start(self, entry_name: str) -> None:
        """Called before validation begins.

        Args:
            entry_name: Name of the entry being validated.
        """
        ...

    def on_validate_end(
        self, entry_name: str, is_valid: bool, duration_ns: int
    ) -> None:
        """Called after validation completes.

        Args:
            entry_name: Name of the entry that was validated.
            is_valid: Whether validation passed.
            duration_ns: Validation duration in nanoseconds.
        """
        ...

    def on_pipeline_start(self, pipeline_name: str) -> None:
        """Called before pipeline execution begins.

        Args:
            pipeline_name: Name of the pipeline being executed.
        """
        ...

    def on_pipeline_end(self, pipeline_name: str, duration_ns: int) -> None:
        """Called after pipeline execution completes.

        Args:
            pipeline_name: Name of the pipeline that was executed.
            duration_ns: Total pipeline execution duration in nanoseconds.
        """
        ...


class NullHook:
    """No-op hook when axm-audit is not installed.

    This is the default hook that does nothing, ensuring
    the system works without axm-audit.
    """

    def on_validate_start(self, entry_name: str) -> None:
        """No-op."""
        pass

    def on_validate_end(
        self, entry_name: str, is_valid: bool, duration_ns: int
    ) -> None:
        """No-op."""
        pass

    def on_pipeline_start(self, pipeline_name: str) -> None:
        """No-op."""
        pass

    def on_pipeline_end(self, pipeline_name: str, duration_ns: int) -> None:
        """No-op."""
        pass


# Global hook registry
_current_hook: AuditHook = NullHook()


def set_audit_hook(hook: AuditHook) -> None:
    """Set the global audit hook.

    Args:
        hook: The audit hook implementation to use.
    """
    global _current_hook
    _current_hook = hook


def get_audit_hook() -> AuditHook:
    """Get the current global audit hook.

    Returns:
        The current audit hook (NullHook by default).
    """
    return _current_hook
