"""Centralized logging configuration for AXM packages.

This module provides a standardized loguru configuration for all AXM packages,
ensuring consistent logging format and behavior across the monorepo.
"""

import sys
from typing import TYPE_CHECKING

from loguru import logger

if TYPE_CHECKING:
    from loguru import Logger

# Standard AXM format with package context
_AXM_FORMAT = (
    "<green>{time:HH:mm:ss}</green> | "
    "<level>{level: <8}</level> | "
    "<cyan>{extra[package]}</cyan> | "
    "{message}"
)

# Default format when package is not bound
_DEFAULT_FORMAT = (
    "<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}"
)


def configure_logging(
    level: str = "INFO",
    json_output: bool = False,
) -> None:
    """Configure loguru for AXM packages.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR).
        json_output: If True, output JSON for observability tools.
    """
    logger.remove()

    if json_output:
        logger.add(sys.stderr, serialize=True, level=level)
    else:
        logger.add(sys.stderr, format=_DEFAULT_FORMAT, level=level)


def get_logger(package: str) -> "Logger":
    """Get a logger bound to a specific package.

    Args:
        package: The package name (e.g., "axm-core", "axm-engine").

    Returns:
        A loguru logger instance bound with the package context.
    """
    return logger.bind(package=package)
