"""Tests for connector protocol and implementations."""

from pathlib import Path

import pytest

from axm.connectors import Connector, LocalConnector


class TestConnectorProtocol:
    """Tests for Connector protocol compliance."""

    def test_local_connector_satisfies_protocol(self) -> None:
        """LocalConnector implements Connector protocol."""
        connector = LocalConnector()
        assert isinstance(connector, Connector)

    def test_connector_has_read_bytes(self) -> None:
        """Connector has read_bytes method."""
        connector = LocalConnector()
        assert hasattr(connector, "read_bytes")

    def test_connector_has_write_bytes(self) -> None:
        """Connector has write_bytes method."""
        connector = LocalConnector()
        assert hasattr(connector, "write_bytes")

    def test_connector_has_exists(self) -> None:
        """Connector has exists method."""
        connector = LocalConnector()
        assert hasattr(connector, "exists")


class TestLocalConnector:
    """Tests for LocalConnector implementation."""

    def test_exists_returns_true_for_existing_file(self, tmp_path: Path) -> None:
        """exists returns True for existing file."""
        connector = LocalConnector()
        file = tmp_path / "test.txt"
        file.write_text("hello")

        assert connector.exists(str(file)) is True

    def test_exists_returns_false_for_missing_file(self, tmp_path: Path) -> None:
        """exists returns False for missing file."""
        connector = LocalConnector()
        missing = tmp_path / "missing.txt"

        assert connector.exists(str(missing)) is False

    def test_read_bytes_returns_file_content(self, tmp_path: Path) -> None:
        """read_bytes returns file content as bytes."""
        connector = LocalConnector()
        file = tmp_path / "test.bin"
        file.write_bytes(b"binary data")

        result = connector.read_bytes(str(file))

        assert result == b"binary data"

    def test_read_bytes_raises_for_missing_file(self, tmp_path: Path) -> None:
        """read_bytes raises FileNotFoundError for missing file."""
        connector = LocalConnector()
        missing = tmp_path / "missing.bin"

        with pytest.raises(FileNotFoundError):
            connector.read_bytes(str(missing))

    def test_write_bytes_creates_file(self, tmp_path: Path) -> None:
        """write_bytes creates file with content."""
        connector = LocalConnector()
        file = tmp_path / "output.bin"

        connector.write_bytes(str(file), b"written data")

        assert file.exists()
        assert file.read_bytes() == b"written data"

    def test_write_bytes_overwrites_existing(self, tmp_path: Path) -> None:
        """write_bytes overwrites existing file."""
        connector = LocalConnector()
        file = tmp_path / "existing.bin"
        file.write_bytes(b"old")

        connector.write_bytes(str(file), b"new")

        assert file.read_bytes() == b"new"
