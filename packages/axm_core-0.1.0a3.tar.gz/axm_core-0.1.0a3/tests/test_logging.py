"""Tests for centralized logging configuration."""


class TestGetLogger:
    """Tests for get_logger function."""

    def test_get_logger_returns_bound_logger(self) -> None:
        """get_logger returns a logger bound to package name."""
        from axm.logging import get_logger

        logger = get_logger("axm-test")
        # Should have bind capability
        assert hasattr(logger, "info")
        assert hasattr(logger, "error")

    def test_get_logger_binds_package_name(self) -> None:
        """Logger should include package in context."""
        from axm.logging import get_logger

        logger = get_logger("axm-core")
        # Bind returns a new logger with context
        bound = logger.bind(extra="data")
        assert hasattr(bound, "info")


class TestConfigureLogging:
    """Tests for configure_logging function."""

    def test_configure_logging_default_level(self) -> None:
        """configure_logging sets INFO level by default."""
        from axm.logging import configure_logging

        # Should not raise
        configure_logging()

    def test_configure_logging_json_output(self) -> None:
        """configure_logging can enable JSON serialization."""
        from axm.logging import configure_logging

        # Should not raise
        configure_logging(json_output=True)

    def test_configure_logging_custom_level(self) -> None:
        """configure_logging accepts custom log level."""
        from axm.logging import configure_logging

        configure_logging(level="DEBUG")
        configure_logging(level="WARNING")
