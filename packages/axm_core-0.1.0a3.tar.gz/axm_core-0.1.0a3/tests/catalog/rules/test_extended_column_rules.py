"""Tests for Extended Column Rules — RED Phase.

These tests cover the new ColumnRules that replace the legacy scalar rules.
"""

import polars as pl

from axm.catalog.rules.column_rules import (
    EmailRule,
    LengthRule,
    NotEmptyRule,
    PositiveRule,
)
from axm.core import Severity


class TestNotEmptyRule:
    """Tests for NotEmptyRule — replace scalar not_empty."""

    def test_not_empty_all_valid(self) -> None:
        """Non-empty strings should pass."""
        rule = NotEmptyRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("name", ["Alice", "Bob", "Charlie"])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_not_empty_with_empty_strings(self) -> None:
        """Empty strings should be counted as violations."""
        rule = NotEmptyRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("name", ["Alice", "", "Charlie", ""])

        result = rule.validate_column(series)

        assert result.violations == 2
        assert result.passed is False

    def test_not_empty_with_nulls(self) -> None:
        """Nulls should also be counted as violations."""
        rule = NotEmptyRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("name", ["Alice", None, "Charlie"])

        result = rule.validate_column(series)

        assert result.violations == 1

    def test_not_empty_with_whitespace_only(self) -> None:
        """Whitespace-only strings should be violations."""
        rule = NotEmptyRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("name", ["Alice", "   ", "\t", "Bob"])

        result = rule.validate_column(series)

        assert result.violations == 2


class TestEmailRule:
    """Tests for EmailRule — replace scalar is_email."""

    def test_email_all_valid(self) -> None:
        """Valid emails should pass."""
        rule = EmailRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("email", ["user@example.com", "test@domain.org"])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_email_with_invalid(self) -> None:
        """Invalid emails should be violations."""
        rule = EmailRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("email", ["user@example.com", "invalid", "no-at-sign"])

        result = rule.validate_column(series)

        assert result.violations == 2

    def test_email_edge_cases(self) -> None:
        """Edge cases for email validation."""
        rule = EmailRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series(
            "email",
            [
                "user.name+tag@example.co.uk",  # Valid
                "@missing-local.com",  # Invalid
                "missing-domain@",  # Invalid
                "spaces in@email.com",  # Invalid
            ],
        )

        result = rule.validate_column(series)

        assert result.violations == 3


class TestPositiveRule:
    """Tests for PositiveRule — replace scalar is_positive."""

    def test_positive_all_valid(self) -> None:
        """Positive numbers should pass."""
        rule = PositiveRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("amount", [1.0, 100.0, 0.5, 999.0])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_positive_with_zero(self) -> None:
        """Zero is NOT positive and should be a violation."""
        rule = PositiveRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("amount", [1, 0, 5])

        result = rule.validate_column(series)

        assert result.violations == 1

    def test_positive_with_negatives(self) -> None:
        """Negative numbers should be violations."""
        rule = PositiveRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("amount", [10, -5, 20, -10, 0])

        result = rule.validate_column(series)

        assert result.violations == 3  # -5, -10, 0


class TestLengthRule:
    """Tests for LengthRule — validates string length."""

    def test_length_within_bounds(self) -> None:
        """Strings within length bounds should pass."""
        rule = LengthRule(min_len=2, max_len=10, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("code", ["AB", "ABCDE", "ABCDEFGHIJ"])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_length_too_short(self) -> None:
        """Strings too short should be violations."""
        rule = LengthRule(min_len=3, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("code", ["AB", "ABC", "ABCD"])

        result = rule.validate_column(series)

        assert result.violations == 1

    def test_length_too_long(self) -> None:
        """Strings too long should be violations."""
        rule = LengthRule(max_len=5, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("code", ["ABC", "ABCDEF", "ABCDEFG"])

        result = rule.validate_column(series)

        assert result.violations == 2

    def test_length_min_only(self) -> None:
        """Should work with only min_len."""
        rule = LengthRule(min_len=5, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("code", ["ABCD", "ABCDE", "ABCDEF"])

        result = rule.validate_column(series)

        assert result.violations == 1

    def test_length_max_only(self) -> None:
        """Should work with only max_len."""
        rule = LengthRule(max_len=3, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("code", ["AB", "ABC", "ABCD"])

        result = rule.validate_column(series)

        assert result.violations == 1
