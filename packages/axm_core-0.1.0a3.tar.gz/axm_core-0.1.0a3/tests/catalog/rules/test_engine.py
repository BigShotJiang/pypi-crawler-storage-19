"""Tests for RuleEngine - DataFrame validation against column rules."""

import polars as pl

from axm.catalog.entries.column import Column, ColumnRuleConfig, TabularSchema
from axm.catalog.rules.engine import RuleEngine


class TestRuleEngine:
    """Tests for RuleEngine class."""

    def test_validate_all_pass(self):
        """All rules pass should return passed report."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="age",
                    type="int",
                    rules=[
                        ColumnRuleConfig(rule="range", min=0, max=120),
                    ],
                ),
            ]
        )
        df = pl.DataFrame({"age": [25, 30, 45]})
        engine = RuleEngine()

        report = engine.validate(df, schema)

        assert report.passed is True
        assert report.has_errors is False
        assert len(report.results) == 1

    def test_validate_with_error_violations(self):
        """Error violations should fail the report."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="age",
                    type="int",
                    rules=[
                        ColumnRuleConfig(
                            rule="range", min=0, max=120, severity="error"
                        ),
                    ],
                ),
            ]
        )
        df = pl.DataFrame({"age": [25, -5, 150]})  # 2 violations
        engine = RuleEngine()

        report = engine.validate(df, schema)

        assert report.passed is False
        assert report.has_errors is True
        assert report.results[0].violations == 2

    def test_validate_with_warning_only(self):
        """Warning violations should not fail the report."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="age",
                    type="int",
                    rules=[
                        ColumnRuleConfig(
                            rule="range", min=0, max=120, severity="warning"
                        ),
                    ],
                ),
            ]
        )
        df = pl.DataFrame({"age": [25, -5, 150]})  # 2 violations
        engine = RuleEngine()

        report = engine.validate(df, schema)

        assert report.passed is True  # Warnings don't fail
        assert report.has_errors is False
        assert report.has_warnings is True

    def test_validate_with_threshold(self):
        """Violations under threshold should pass."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="value",
                    type="float",
                    rules=[
                        ColumnRuleConfig(
                            rule="range",
                            min=0,
                            max=100,
                            severity="error",
                            threshold=0.2,  # Allow 20% violations
                        ),
                    ],
                ),
            ]
        )
        df = pl.DataFrame({"value": [50, 60, -10]})  # 1/3 = 33% > 20%
        engine = RuleEngine()

        report = engine.validate(df, schema)
        assert report.passed is False

        # Now with lower violation rate
        df2 = pl.DataFrame({"value": [50, 60, 70, 80, -10]})  # 1/5 = 20%
        report2 = engine.validate(df2, schema)
        assert report2.passed is True

    def test_validate_multiple_columns(self):
        """Validate multiple columns with different rules."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="age",
                    type="int",
                    rules=[ColumnRuleConfig(rule="range", min=0, max=120)],
                ),
                Column(
                    name="status",
                    type="string",
                    rules=[
                        ColumnRuleConfig(rule="in_set", allowed=["active", "inactive"])
                    ],
                ),
            ]
        )
        df = pl.DataFrame(
            {
                "age": [25, 30],
                "status": ["active", "unknown"],  # 1 violation
            }
        )
        engine = RuleEngine()

        report = engine.validate(df, schema)

        assert len(report.results) == 2
        assert report.has_errors is True


class TestDataQualityReport:
    """Tests for DataQualityReport model."""

    def test_to_summary(self):
        """Report can generate summary string."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="age",
                    type="int",
                    rules=[ColumnRuleConfig(rule="range", min=0, max=120)],
                ),
            ]
        )
        df = pl.DataFrame({"age": [25, -5]})
        engine = RuleEngine()

        report = engine.validate(df, schema)

        summary = report.summary()
        assert "age" in summary
        assert "1 violation" in summary or "1 error" in summary.lower()


class TestValidateBatch:
    """Tests for batch validation (single Polars pass)."""

    def test_validate_batch_same_results_as_validate(self):
        """validate_batch should return same results as validate."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="age",
                    type="int",
                    rules=[ColumnRuleConfig(rule="range", min=0, max=120)],
                ),
                Column(
                    name="status",
                    type="string",
                    rules=[
                        ColumnRuleConfig(rule="in_set", allowed=["active", "inactive"])
                    ],
                ),
            ]
        )
        df = pl.DataFrame(
            {
                "age": [25, -5, 150],  # 2 violations
                "status": ["active", "unknown", "inactive"],  # 1 violation
            }
        )
        engine = RuleEngine()

        # Both methods should return same results
        report_seq = engine.validate(df, schema)
        report_batch = engine.validate_batch(df, schema)

        assert report_batch.passed == report_seq.passed
        assert len(report_batch.results) == len(report_seq.results)
        assert report_batch.has_errors == report_seq.has_errors

    def test_validate_batch_pattern_rule(self):
        """Pattern rules should work in batch mode."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="code",
                    type="string",
                    rules=[ColumnRuleConfig(rule="pattern", pattern=r"^[A-Z]{3}$")],
                ),
            ]
        )
        df = pl.DataFrame({"code": ["ABC", "invalid", "XYZ"]})
        engine = RuleEngine()

        report = engine.validate_batch(df, schema)

        assert report.passed is False
        assert report.results[0].violations == 1
