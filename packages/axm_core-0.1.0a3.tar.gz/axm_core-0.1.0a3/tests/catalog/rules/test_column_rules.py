"""Tests for Column Rules - Data Quality validation rules.

TDD RED Phase: These tests should FAIL initially.
"""

import polars as pl

from axm.catalog.rules.column_rules import (
    ColumnValidationResult,
    InSetRule,
    NotNullRule,
    PatternRule,
    RangeRule,
    UniqueRule,
)
from axm.core import Severity


class TestColumnValidationResult:
    """Tests for ColumnValidationResult model."""

    def test_result_passed_when_under_threshold(self):
        """Result should pass if violation_percent <= threshold."""
        result = ColumnValidationResult(
            column="age",
            rule="range",
            total_rows=1000,
            violations=5,
            violation_percent=0.005,
            threshold=0.01,
            severity=Severity.ERROR,
        )
        assert result.passed is True

    def test_result_failed_when_over_threshold(self):
        """Result should fail if violation_percent > threshold."""
        result = ColumnValidationResult(
            column="age",
            rule="range",
            total_rows=1000,
            violations=20,
            violation_percent=0.02,
            threshold=0.01,
            severity=Severity.ERROR,
        )
        assert result.passed is False


class TestRangeRule:
    """Tests for RangeRule - validates numeric ranges."""

    def test_range_rule_all_valid(self):
        """All values within range should pass."""
        rule = RangeRule(min=0, max=120, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("age", [25, 30, 45, 100])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_range_rule_with_violations(self):
        """Values outside range should be counted as violations."""
        rule = RangeRule(min=0, max=120, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("age", [25, -5, 150, 45])  # 2 violations

        result = rule.validate_column(series)

        assert result.violations == 2
        assert result.violation_percent == 0.5
        assert result.passed is False

    def test_range_rule_with_threshold(self):
        """Should pass if violations are under threshold."""
        rule = RangeRule(min=0, max=120, severity=Severity.WARNING, threshold=0.1)
        series = pl.Series(
            "age", [25, -5, 45, 50, 60, 70, 80, 90, 100, 110]
        )  # 1/10 = 10%

        result = rule.validate_column(series)

        assert result.violations == 1
        assert result.passed is True  # 10% == threshold

    def test_range_rule_min_only(self):
        """Should work with only min specified."""
        rule = RangeRule(min=0, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("amount", [-10, 0, 50, 100])

        result = rule.validate_column(series)

        assert result.violations == 1

    def test_range_rule_max_only(self):
        """Should work with only max specified."""
        rule = RangeRule(max=100, severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("score", [50, 100, 150])

        result = rule.validate_column(series)

        assert result.violations == 1


class TestPatternRule:
    """Tests for PatternRule - validates string patterns."""

    def test_pattern_rule_email_valid(self):
        """Valid emails should pass."""
        rule = PatternRule(
            pattern=r"^[\w.]+@[\w.]+\.\w+$",
            severity=Severity.ERROR,
            threshold=0.0,
        )
        series = pl.Series("email", ["user@example.com", "test@domain.org"])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_pattern_rule_with_violations(self):
        """Invalid patterns should be counted."""
        rule = PatternRule(
            pattern=r"^[\w.]+@[\w.]+\.\w+$",
            severity=Severity.ERROR,
            threshold=0.0,
        )
        series = pl.Series("email", ["user@example.com", "invalid", "test@domain.org"])

        result = rule.validate_column(series)

        assert result.violations == 1


class TestUniqueRule:
    """Tests for UniqueRule - validates column uniqueness."""

    def test_unique_rule_all_unique(self):
        """All unique values should pass."""
        rule = UniqueRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("id", [1, 2, 3, 4, 5])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_unique_rule_with_duplicates(self):
        """Duplicates should be counted as violations."""
        rule = UniqueRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("id", [1, 2, 2, 3, 3, 3])  # 3 duplicate values

        result = rule.validate_column(series)

        # Violations = total - unique count
        assert result.violations == 3  # 6 - 3 unique = 3 duplicates
        assert result.passed is False


class TestNotNullRule:
    """Tests for NotNullRule - validates null presence."""

    def test_not_null_rule_no_nulls(self):
        """No nulls should pass."""
        rule = NotNullRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("name", ["Alice", "Bob", "Charlie"])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_not_null_rule_with_nulls(self):
        """Nulls should be counted as violations."""
        rule = NotNullRule(severity=Severity.ERROR, threshold=0.0)
        series = pl.Series("name", ["Alice", None, "Charlie", None])

        result = rule.validate_column(series)

        assert result.violations == 2
        assert result.passed is False

    def test_not_null_rule_with_threshold(self):
        """Should pass if nulls are under threshold."""
        rule = NotNullRule(severity=Severity.WARNING, threshold=0.1)
        series = pl.Series("name", ["A", "B", "C", "D", "E", "F", "G", "H", "I", None])

        result = rule.validate_column(series)

        assert result.violations == 1
        assert result.passed is True  # 10% == threshold


class TestInSetRule:
    """Tests for InSetRule - validates allowed values."""

    def test_in_set_rule_all_valid(self):
        """All values in allowed set should pass."""
        rule = InSetRule(
            allowed=["active", "inactive", "pending"],
            severity=Severity.ERROR,
            threshold=0.0,
        )
        series = pl.Series("status", ["active", "inactive", "active", "pending"])

        result = rule.validate_column(series)

        assert result.violations == 0
        assert result.passed is True

    def test_in_set_rule_with_violations(self):
        """Values not in set should be counted."""
        rule = InSetRule(
            allowed=["active", "inactive"],
            severity=Severity.ERROR,
            threshold=0.0,
        )
        series = pl.Series("status", ["active", "unknown", "inactive", "deleted"])

        result = rule.validate_column(series)

        assert result.violations == 2
        assert result.passed is False
