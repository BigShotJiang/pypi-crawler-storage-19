"""Tests for Column model with rules integration."""

from axm.catalog.entries.column import Column, ColumnRuleConfig, TabularSchema


class TestColumnRuleConfig:
    """Tests for ColumnRuleConfig model."""

    def test_range_rule_config(self):
        """Range rule config with min/max."""
        config = ColumnRuleConfig(
            rule="range",
            min=0,
            max=120,
            severity="error",
            threshold=0.01,
        )
        assert config.rule == "range"
        assert config.min == 0
        assert config.max == 120
        assert config.threshold == 0.01

    def test_pattern_rule_config(self):
        """Pattern rule config with regex."""
        config = ColumnRuleConfig(
            rule="pattern",
            pattern=r"^[a-z]+@.+$",
            severity="warning",
        )
        assert config.rule == "pattern"
        assert config.pattern == r"^[a-z]+@.+$"
        assert config.severity == "warning"

    def test_in_set_rule_config(self):
        """InSet rule config with allowed values."""
        config = ColumnRuleConfig(
            rule="in_set",
            allowed=["active", "inactive"],
        )
        assert config.rule == "in_set"
        assert "active" in config.allowed


class TestColumn:
    """Tests for Column model."""

    def test_column_without_rules(self):
        """Column can be created without rules."""
        col = Column(name="id", type="int")
        assert col.name == "id"
        assert col.type == "int"
        assert col.rules == []

    def test_column_with_rules(self):
        """Column with multiple rules."""
        col = Column(
            name="age",
            type="int",
            description="User age",
            rules=[
                ColumnRuleConfig(rule="range", min=0, max=120),
                ColumnRuleConfig(rule="not_null"),
            ],
        )
        assert len(col.rules) == 2
        assert col.rules[0].rule == "range"
        assert col.rules[1].rule == "not_null"


class TestTabularSchema:
    """Tests for TabularSchema model."""

    def test_schema_with_columns(self):
        """Schema with multiple columns."""
        schema = TabularSchema(
            columns=[
                Column(name="id", type="int"),
                Column(
                    name="email",
                    type="string",
                    rules=[ColumnRuleConfig(rule="pattern", pattern=r"^.+@.+$")],
                ),
            ]
        )
        assert len(schema.columns) == 2
        assert schema.columns[1].rules[0].rule == "pattern"

    def test_schema_serialization(self):
        """Schema can be serialized to dict."""
        schema = TabularSchema(
            columns=[
                Column(
                    name="age",
                    type="int",
                    rules=[ColumnRuleConfig(rule="range", min=0, max=120)],
                ),
            ]
        )
        data = schema.model_dump()
        assert data["columns"][0]["name"] == "age"
        assert data["columns"][0]["rules"][0]["rule"] == "range"


class TestTabularSchemaUnification:
    """Tests for unified TabularSchema with spec support."""

    def test_schema_with_spec_nested_columns(self):
        """Schema can be created with spec.columns (YAML format)."""
        from axm.catalog.entries.column import TabularSpec

        spec = TabularSpec(
            columns=[
                Column(name="id", type="int"),
                Column(name="name", type="string"),
            ]
        )
        schema = TabularSchema(spec=spec)

        # Should access columns via spec
        assert len(schema.spec.columns) == 2
        assert schema.spec.columns[0].name == "id"

    def test_schema_columns_synced_from_spec(self):
        """Flat columns access is synced from spec."""
        from axm.catalog.entries.column import TabularSpec

        spec = TabularSpec(columns=[Column(name="age", type="int")])
        schema = TabularSchema(spec=spec)

        # Should also be accessible via flat columns
        assert len(schema.columns) == 1
        assert schema.columns[0].name == "age"

    def test_schema_spec_synced_from_columns(self):
        """spec is synced from flat columns for backward compat."""
        schema = TabularSchema(columns=[Column(name="email", type="string")])

        # spec should be auto-created
        assert schema.spec is not None
        assert len(schema.spec.columns) == 1
        assert schema.spec.columns[0].name == "email"
