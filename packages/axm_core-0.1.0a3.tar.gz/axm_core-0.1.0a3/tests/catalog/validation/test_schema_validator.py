"""Tests for SchemaValidator."""

from unittest.mock import MagicMock, patch

import pytest

from axm.catalog.entries import (
    DataEntry,
    Identity,
    Location,
    Owner,
    Schema,
    SchemaFormat,
)
from axm.catalog.validation.validator import SchemaValidator
from axm.core import Severity, ValidationResult


@pytest.fixture
def sample_data_entry() -> DataEntry:
    """Create a sample DataEntry for testing."""
    return DataEntry(
        name="test_data",
        version="1.0.0",
        identity=Identity(
            display_name="Test Data",
            description="Test",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        data_schema=Schema(format=SchemaFormat.TABULAR, spec={"columns": []}),
        location=Location(storage="fs", path_template="/tmp/test"),  # noqa: S108
    )


class TestSchemaValidator:
    """Tests for SchemaValidator class."""

    def test_validate_with_registered_validator(
        self, sample_data_entry: DataEntry
    ) -> None:
        """Test validation delegates to registered validator."""
        mock_validator_cls = MagicMock()
        mock_validator_instance = MagicMock()
        mock_validator_instance.validate.return_value = ValidationResult(
            is_valid=True, errors=[]
        )
        mock_validator_cls.return_value = mock_validator_instance

        with patch(
            "axm.catalog.validation.validator.ValidatorRegistry.get",
            return_value=mock_validator_cls,
        ):
            validator = SchemaValidator(sample_data_entry)
            result = validator.validate({"test": "data"})

            assert result.is_valid
            mock_validator_cls.assert_called_once_with(sample_data_entry)
            mock_validator_instance.validate.assert_called_once_with({"test": "data"})

    def test_validate_no_registered_validator(
        self, sample_data_entry: DataEntry
    ) -> None:
        """Test validation returns error when no validator registered."""
        with patch(
            "axm.catalog.validation.validator.ValidatorRegistry.get",
            return_value=None,
        ):
            validator = SchemaValidator(sample_data_entry)
            result = validator.validate({"test": "data"})

            assert not result.is_valid
            assert len(result.errors) == 1
            assert "No validator registered" in result.errors[0].message
            assert result.errors[0].severity == Severity.ERROR

    def test_validate_handles_validator_exception(
        self, sample_data_entry: DataEntry
    ) -> None:
        """Test validation handles validator exceptions gracefully."""
        mock_validator_cls = MagicMock()
        mock_validator_cls.side_effect = Exception("Validator crashed")

        with patch(
            "axm.catalog.validation.validator.ValidatorRegistry.get",
            return_value=mock_validator_cls,
        ):
            validator = SchemaValidator(sample_data_entry)
            result = validator.validate({"test": "data"})

            assert not result.is_valid
            assert len(result.errors) == 1
            assert "Validator execution failed" in result.errors[0].message

    def test_init_stores_entry(self, sample_data_entry: DataEntry) -> None:
        """Test that __init__ stores the data entry."""
        validator = SchemaValidator(sample_data_entry)
        assert validator.entry == sample_data_entry
