"""Tests for ValidatorRegistry."""

from unittest.mock import MagicMock, patch

from axm.catalog.validation.registry import ValidatorRegistry
from axm.core import ValidationResult


class MockValidator:
    """Mock validator for testing."""

    def __init__(self, entry):
        self.entry = entry

    def validate(self, data):
        return ValidationResult(is_valid=True, errors=[])


class TestValidatorRegistry:
    """Tests for ValidatorRegistry class."""

    def setup_method(self):
        """Clear registry before each test."""
        ValidatorRegistry._registry.clear()

    def test_register_validator(self) -> None:
        """Test registering a validator for a format."""
        ValidatorRegistry.register("test_format", MockValidator)

        assert "test_format" in ValidatorRegistry._registry
        assert ValidatorRegistry._registry["test_format"] == MockValidator

    def test_get_validator_returns_registered(self) -> None:
        """Test getting a registered validator."""
        ValidatorRegistry._registry["my_format"] = MockValidator

        result = ValidatorRegistry.get("my_format")

        assert result == MockValidator

    def test_get_validator_not_found_returns_none(self) -> None:
        """Test getting non-existent validator returns None."""
        # Fill registry so discover isn't called
        ValidatorRegistry._registry["dummy"] = MockValidator

        result = ValidatorRegistry.get("unknown_format")

        assert result is None

    def test_get_triggers_discovery_when_empty(self) -> None:
        """Test that get() triggers discovery when registry is empty."""
        with patch.object(ValidatorRegistry, "discover_validators") as mock_discover:
            ValidatorRegistry.get("some_format")
            mock_discover.assert_called_once()

    def test_discover_validators_loads_entry_points(self) -> None:
        """Test that discover_validators loads from entry points."""
        mock_ep = MagicMock()
        mock_ep.name = "test_plugin"
        mock_register_func = MagicMock()
        mock_ep.load.return_value = mock_register_func

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            ValidatorRegistry.discover_validators()

            mock_ep.load.assert_called_once()
            mock_register_func.assert_called_once()

    def test_discover_validators_handles_load_error(self) -> None:
        """Test that discover_validators handles errors gracefully."""
        mock_ep = MagicMock()
        mock_ep.name = "broken_plugin"
        mock_ep.load.side_effect = Exception("Load failed")

        with patch("importlib.metadata.entry_points", return_value=[mock_ep]):
            # Should not raise
            ValidatorRegistry.discover_validators()


class TestDataValidatorProtocol:
    """Tests for DataValidator protocol."""

    def test_mock_validator_is_data_validator(self) -> None:
        """Test that a proper class satisfies DataValidator protocol."""
        # This is a structural check
        assert hasattr(MockValidator, "__init__")
        assert hasattr(MockValidator, "validate")
