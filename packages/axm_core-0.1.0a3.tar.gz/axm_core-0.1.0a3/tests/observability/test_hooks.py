"""Tests for audit hooks."""


class TestAuditHook:
    """Tests for AuditHook protocol and NullHook."""

    def test_null_hook_on_validate_start(self) -> None:
        """NullHook.on_validate_start does nothing."""
        from axm.observability.hooks import NullHook

        hook = NullHook()
        # Should not raise
        hook.on_validate_start("test_entry")

    def test_null_hook_on_validate_end(self) -> None:
        """NullHook.on_validate_end does nothing."""
        from axm.observability.hooks import NullHook

        hook = NullHook()
        # Should not raise
        hook.on_validate_end("test_entry", is_valid=True, duration_ns=1000)

    def test_get_audit_hook_returns_null_by_default(self) -> None:
        """get_audit_hook returns NullHook when reset to default."""
        from axm.observability.hooks import NullHook, get_audit_hook, set_audit_hook

        # Reset to default state (may have been modified by other tests)
        set_audit_hook(NullHook())
        hook = get_audit_hook()
        assert isinstance(hook, NullHook)

    def test_set_audit_hook_changes_hook(self) -> None:
        """set_audit_hook changes the global hook."""
        from axm.observability.hooks import (
            NullHook,
            get_audit_hook,
            set_audit_hook,
        )

        class CustomHook:
            def on_validate_start(self, entry_name: str) -> None:
                pass

            def on_validate_end(
                self, entry_name: str, is_valid: bool, duration_ns: int
            ) -> None:
                pass

            def on_pipeline_start(self, pipeline_name: str) -> None:
                pass

            def on_pipeline_end(self, pipeline_name: str, duration_ns: int) -> None:
                pass

        custom = CustomHook()
        set_audit_hook(custom)
        assert get_audit_hook() is custom

        # Reset
        set_audit_hook(NullHook())


class TestAuditHookProtocol:
    """Tests for protocol compliance."""

    def test_custom_hook_satisfies_protocol(self) -> None:
        """Custom hook class satisfies AuditHook protocol."""
        from axm.observability.hooks import AuditHook

        class MyHook:
            def on_validate_start(self, entry_name: str) -> None:
                pass

            def on_validate_end(
                self, entry_name: str, is_valid: bool, duration_ns: int
            ) -> None:
                pass

            def on_pipeline_start(self, pipeline_name: str) -> None:
                pass

            def on_pipeline_end(self, pipeline_name: str, duration_ns: int) -> None:
                pass

        assert isinstance(MyHook(), AuditHook)
