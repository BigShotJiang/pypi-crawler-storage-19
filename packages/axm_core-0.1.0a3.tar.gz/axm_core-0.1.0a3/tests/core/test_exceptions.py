"""Tests for AXM custom exceptions."""

import pytest

from axm.core.exceptions import (
    AXMError,
    CatalogError,
    ExecutionError,
    SchemaValidationError,
)


class TestExceptionHierarchy:
    """Tests for exception class hierarchy."""

    def test_axm_error_is_base(self) -> None:
        """AXMError should be the base for all custom exceptions."""
        assert issubclass(CatalogError, AXMError)
        assert issubclass(ExecutionError, AXMError)
        assert issubclass(SchemaValidationError, AXMError)

    def test_exceptions_are_catchable_as_axm_error(self) -> None:
        """All custom exceptions should be catchable as AXMError."""
        with pytest.raises(AXMError):
            raise CatalogError("test")

        with pytest.raises(AXMError):
            raise ExecutionError("test")

        with pytest.raises(AXMError):
            raise SchemaValidationError("test", field="name")

    def test_validation_error_has_field(self) -> None:
        """SchemaValidationError should include field information."""
        err = SchemaValidationError("Invalid value", field="email")
        assert err.field == "email"
        assert "email" in str(err)
        assert "Invalid value" in str(err)

    def test_catalog_error_message(self) -> None:
        """CatalogError should preserve message."""
        err = CatalogError("Entry not found: users")
        assert str(err) == "Entry not found: users"

    def test_execution_error_with_operation(self) -> None:
        """ExecutionError should optionally include operation name."""
        err = ExecutionError("Timeout", operation="clean_users")
        assert err.operation == "clean_users"
        assert "clean_users" in str(err)
