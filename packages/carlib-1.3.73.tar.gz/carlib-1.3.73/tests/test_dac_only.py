#!/usr/bin/env python3
"""
Simple DAC test to verify the fix for encoded_latents key
"""
import sys
import os
from pathlib import Path
import tempfile
import shutil

def test_dac_basic():
    """Test basic DAC functionality with our fix"""
    print("🧪 Testing DAC with encoded_latents fix")
    print("=" * 40)
    
    # Find MP3 file
    project_root = Path(__file__).parent.parent
    assets_dir = project_root / "assets"
    mp3_files = list(assets_dir.glob("*.mp3"))
    
    if not mp3_files:
        print("❌ No MP3 files found in assets directory")
        return False
    
    test_mp3 = mp3_files[0]
    print(f"🎵 Test file: {test_mp3.name}")
    
    try:
        # Import and test DAC processor
        from carlib.processors.audio_codecs import DACAudioProcessor, AudioConfig
        
        # Create config
        config = AudioConfig(
            model_name="dac_24khz",  # Use 24kHz for faster testing
            model_type="dac",
            device="cpu",
            target_sample_rate=24000,
            max_duration=3.0  # Very short for quick test
        )
        
        print("🔧 Initializing DAC processor...")
        processor = DACAudioProcessor(config)
        print("✅ DAC processor initialized")
        
        # Create temp output
        with tempfile.TemporaryDirectory() as temp_dir:
            output_path = Path(temp_dir) / "test_dac.car"
            
            print("🎵 Processing audio...")
            result = processor.process_single_file(
                audio_path=str(test_mp3),
                output_path=str(output_path)
            )
            
            if output_path.exists():
                size_kb = output_path.stat().st_size / 1024
                print(f"✅ CAR file created: {size_kb:.1f} KB")
                
                # Test loading
                print("📖 Testing CAR file loading...")
                from carlib.loaders import load_single_car
                data = load_single_car(str(output_path))
                
                print(f"📊 Loaded keys: {list(data.keys())}")
                if 'data' in data:
                    print(f"📊 Data keys: {list(data['data'].keys())}")
                    if 'encoded_latents' in data['data']:
                        latents = data['data']['encoded_latents']
                        print(f"✅ encoded_latents found: shape {latents.shape}")
                        return True
                    else:
                        print("❌ encoded_latents not found in data")
                        return False
                else:
                    print("❌ No data key in loaded CAR")
                    return False
            else:
                print("❌ CAR file not created")
                return False
                
    except Exception as e:
        print(f"❌ DAC test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_dac_basic()
    sys.exit(0 if success else 1)