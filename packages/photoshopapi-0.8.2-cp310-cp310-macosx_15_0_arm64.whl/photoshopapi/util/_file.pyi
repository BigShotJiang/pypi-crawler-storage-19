

class File:
    ...