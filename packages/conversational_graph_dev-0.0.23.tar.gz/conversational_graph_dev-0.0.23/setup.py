from setuptools import setup, find_packages
from setuptools.command.build_py import build_py
import os
import shutil

class CustomBuildPy(build_py):
    def run(self):
        super().run()
        internal_build_dir = os.path.join(
            self.build_lib, "conversational_graph", "_internal"
        )
        parent_build_dir = os.path.join(
            self.build_lib, "conversational_graph"
        )

        if os.path.exists(internal_build_dir):
            # Copy _internal files to parent package with _internal_ prefix
            # and rewrite imports
            for filename in os.listdir(internal_build_dir):
                if filename.endswith(".py") and filename != "__init__.py":
                    src = os.path.join(internal_build_dir, filename)
                    dst = os.path.join(parent_build_dir, f"_internal_{filename}")
                    
                    # Read and rewrite imports
                    with open(src, 'r') as f:
                        content = f.read()
                    
                    # Replace relative imports within _internal package
                    # from .module import -> from ._internal_module import
                    import re
                    content = re.sub(
                        r'from \.(\w+) import',
                        r'from ._internal_\1 import',
                        content
                    )
                    
                    # Write modified content
                    with open(dst, 'w') as f:
                        f.write(content)

            # Remove the _internal directory
            shutil.rmtree(internal_build_dir)

setup(
    name="conversational-graph-dev",
    version="0.0.23",
    packages=find_packages(),
    cmdclass={"build_py": CustomBuildPy},
    include_package_data=True,
)
