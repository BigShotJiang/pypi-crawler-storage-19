# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class IamBpAttachHighRiskSysIdentityPolicyToUserDetails:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'user_id': 'str',
        'policy_name': 'str'
    }

    attribute_map = {
        'user_id': 'user_id',
        'policy_name': 'policy_name'
    }

    def __init__(self, user_id=None, policy_name=None):
        r"""IamBpAttachHighRiskSysIdentityPolicyToUserDetails

        The model defined in huaweicloud sdk

        :param user_id: 用户的唯一标识符（ID）。
        :type user_id: str
        :param policy_name: 策略名称。
        :type policy_name: str
        """
        
        

        self._user_id = None
        self._policy_name = None
        self.discriminator = None

        self.user_id = user_id
        self.policy_name = policy_name

    @property
    def user_id(self):
        r"""Gets the user_id of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.

        用户的唯一标识符（ID）。

        :return: The user_id of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.
        :rtype: str
        """
        return self._user_id

    @user_id.setter
    def user_id(self, user_id):
        r"""Sets the user_id of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.

        用户的唯一标识符（ID）。

        :param user_id: The user_id of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.
        :type user_id: str
        """
        self._user_id = user_id

    @property
    def policy_name(self):
        r"""Gets the policy_name of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.

        策略名称。

        :return: The policy_name of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.
        :rtype: str
        """
        return self._policy_name

    @policy_name.setter
    def policy_name(self, policy_name):
        r"""Sets the policy_name of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.

        策略名称。

        :param policy_name: The policy_name of this IamBpAttachHighRiskSysIdentityPolicyToUserDetails.
        :type policy_name: str
        """
        self._policy_name = policy_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, IamBpAttachHighRiskSysIdentityPolicyToUserDetails):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
