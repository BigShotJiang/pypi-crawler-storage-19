# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowNotificationSettingRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'notification_setting_id': 'str'
    }

    attribute_map = {
        'notification_setting_id': 'notification_setting_id'
    }

    def __init__(self, notification_setting_id=None):
        r"""ShowNotificationSettingRequest

        The model defined in huaweicloud sdk

        :param notification_setting_id: 消息通知配置的唯一标识符。
        :type notification_setting_id: str
        """
        
        

        self._notification_setting_id = None
        self.discriminator = None

        self.notification_setting_id = notification_setting_id

    @property
    def notification_setting_id(self):
        r"""Gets the notification_setting_id of this ShowNotificationSettingRequest.

        消息通知配置的唯一标识符。

        :return: The notification_setting_id of this ShowNotificationSettingRequest.
        :rtype: str
        """
        return self._notification_setting_id

    @notification_setting_id.setter
    def notification_setting_id(self, notification_setting_id):
        r"""Sets the notification_setting_id of this ShowNotificationSettingRequest.

        消息通知配置的唯一标识符。

        :param notification_setting_id: The notification_setting_id of this ShowNotificationSettingRequest.
        :type notification_setting_id: str
        """
        self._notification_setting_id = notification_setting_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowNotificationSettingRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
