# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateArchiveRuleRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'analyzer_id': 'str',
        'archive_rule_id': 'str',
        'body': 'UpdateArchiveRuleReqBody'
    }

    attribute_map = {
        'analyzer_id': 'analyzer_id',
        'archive_rule_id': 'archive_rule_id',
        'body': 'body'
    }

    def __init__(self, analyzer_id=None, archive_rule_id=None, body=None):
        r"""UpdateArchiveRuleRequest

        The model defined in huaweicloud sdk

        :param analyzer_id: 分析器的唯一标识符。
        :type analyzer_id: str
        :param archive_rule_id: 存档规则的唯一标识符。
        :type archive_rule_id: str
        :param body: Body of the UpdateArchiveRuleRequest
        :type body: :class:`huaweicloudsdkiamaccessanalyzer.v1.UpdateArchiveRuleReqBody`
        """
        
        

        self._analyzer_id = None
        self._archive_rule_id = None
        self._body = None
        self.discriminator = None

        self.analyzer_id = analyzer_id
        self.archive_rule_id = archive_rule_id
        if body is not None:
            self.body = body

    @property
    def analyzer_id(self):
        r"""Gets the analyzer_id of this UpdateArchiveRuleRequest.

        分析器的唯一标识符。

        :return: The analyzer_id of this UpdateArchiveRuleRequest.
        :rtype: str
        """
        return self._analyzer_id

    @analyzer_id.setter
    def analyzer_id(self, analyzer_id):
        r"""Sets the analyzer_id of this UpdateArchiveRuleRequest.

        分析器的唯一标识符。

        :param analyzer_id: The analyzer_id of this UpdateArchiveRuleRequest.
        :type analyzer_id: str
        """
        self._analyzer_id = analyzer_id

    @property
    def archive_rule_id(self):
        r"""Gets the archive_rule_id of this UpdateArchiveRuleRequest.

        存档规则的唯一标识符。

        :return: The archive_rule_id of this UpdateArchiveRuleRequest.
        :rtype: str
        """
        return self._archive_rule_id

    @archive_rule_id.setter
    def archive_rule_id(self, archive_rule_id):
        r"""Sets the archive_rule_id of this UpdateArchiveRuleRequest.

        存档规则的唯一标识符。

        :param archive_rule_id: The archive_rule_id of this UpdateArchiveRuleRequest.
        :type archive_rule_id: str
        """
        self._archive_rule_id = archive_rule_id

    @property
    def body(self):
        r"""Gets the body of this UpdateArchiveRuleRequest.

        :return: The body of this UpdateArchiveRuleRequest.
        :rtype: :class:`huaweicloudsdkiamaccessanalyzer.v1.UpdateArchiveRuleReqBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this UpdateArchiveRuleRequest.

        :param body: The body of this UpdateArchiveRuleRequest.
        :type body: :class:`huaweicloudsdkiamaccessanalyzer.v1.UpdateArchiveRuleReqBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateArchiveRuleRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
