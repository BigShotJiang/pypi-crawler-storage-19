import{K as i}from"./index.BuCGo7-5.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
