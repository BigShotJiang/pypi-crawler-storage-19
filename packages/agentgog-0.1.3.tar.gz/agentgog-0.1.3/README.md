# TESTS


uv run p20260105-oneagent "Hi, tomorrow there is a meeting."
uv run p20260105-oneagent "Hi, you need to pick up an item from AlzaBox."
i... in classify_message Classification: MEMO
uv run p20260105-oneagent "What is the time?"
