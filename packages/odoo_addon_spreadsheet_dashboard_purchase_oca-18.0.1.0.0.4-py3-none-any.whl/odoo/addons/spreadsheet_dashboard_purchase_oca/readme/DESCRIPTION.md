Spreadsheet dashboard for vendors.
