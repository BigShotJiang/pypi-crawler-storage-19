from setuptools import setup, find_packages

setup(
    name="autodroid",
    version="1.11",
    packages=find_packages(),
    install_requires=[],
)
