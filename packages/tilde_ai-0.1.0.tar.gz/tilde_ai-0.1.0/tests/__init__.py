"""Tests for tilde."""
