"""
Fine-tuning Module for Sarvam-1
Trains the Sarvam-1 model on the distilled dataset using LoRA.
"""

import sys
import logging
from pathlib import Path
from typing import Dict, Any, Optional

import torch
from datasets import load_dataset
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    BitsAndBytesConfig
)
from trl import SFTTrainer
from rich.console import Console

console = Console()
logger = logging.getLogger(__name__)

class LLMTrainer:
    """
    Fine-tunes a base model using QLoRA.
    """
    
    def __init__(self, model_id: str = "sarvamai/sarvam-1", adapter_path: Optional[str] = None, config: Dict[str, Any] = None):
        self.config = config or {}
        self.model_id = model_id
        self.adapter_path = adapter_path
        
        if adapter_path:
             # Create a unique name for the continuation
             base_name = model_id.split('/')[-1]
             parent_name = Path(adapter_path).parent.name
             self.output_dir = Path(f"models/{parent_name}-refined")
        else:
             self.output_dir = Path(f"models/{model_id.split('/')[-1]}-finetuned")
        
        # Training hyperparameters (optimized for CPU)
        self.train_params = {
            "learning_rate": 2e-4,
            "per_device_train_batch_size": 1,  # Small batch for CPU memory
            "gradient_accumulation_steps": 8,  # Accumulate for effective batch of 8
            "num_train_epochs": 1,             # 1 epoch for testing
            "max_seq_length": 512,             # Reduced for CPU memory
            "logging_steps": 5,                # More frequent logging
            "save_steps": 100,                 # Less frequent saves
            "optim": "adamw_torch",            # Standard optimizer (fused not on CPU)
            "warmup_steps": 10,                # Quick warmup
            "dataloader_pin_memory": False,    # Disable for CPU
            "fp16": False,                     # No fp16 on CPU
            "bf16": False,                     # No bf16 on CPU
        }

    def train(self, data_path: str, resume_from_checkpoint: Optional[str] = None):
        """
        Start fine-tuning process.
        
        Args:
            data_path: Path to the JSONL training data
            resume_from_checkpoint: Path to a checkpoint to resume from (optional)
        """
        from rich.table import Table
        from rich.panel import Panel
        from peft import PeftModel
        
        # Display training configuration in a nice table
        config_table = Table(title="🚀 Fine-tuning Configuration", show_header=True, header_style="bold cyan")
        config_table.add_column("Parameter", style="green")
        config_table.add_column("Value", style="yellow")
        
        config_table.add_row("Base Model", self.model_id)
        if self.adapter_path:
            config_table.add_row("Starting Adapter", self.adapter_path)
            
        if isinstance(data_path, list):
            config_table.add_row("Training Data", f"{len(data_path)} files (batch mode)")
        else:
            config_table.add_row("Training Data", str(data_path))
        config_table.add_row("Output Directory", str(self.output_dir))
        config_table.add_row("Batch Size", str(self.train_params["per_device_train_batch_size"]))
        config_table.add_row("Learning Rate", str(self.train_params["learning_rate"]))
        config_table.add_row("Epochs", str(self.train_params["num_train_epochs"]))
        config_table.add_row("Max Seq Length", str(self.train_params["max_seq_length"]))
        if resume_from_checkpoint:
            config_table.add_row("Resume From", resume_from_checkpoint)
        
        console.print(config_table)
        console.print()
        
        # 1. Load Dataset (supports single file or list of files)
        try:
            from datasets import concatenate_datasets
            
            if isinstance(data_path, list):
                # Batch loading - load each file and concatenate
                console.print(f"[yellow]Loading {len(data_path)} files...[/yellow]")
                datasets_list = []
                
                for i, file_path in enumerate(data_path):
                    try:
                        ds = load_dataset("json", data_files=file_path, split="train")
                        datasets_list.append(ds)
                        console.print(f"  [dim]+ {Path(file_path).name}: {len(ds)} samples[/dim]")
                    except Exception as e:
                        console.print(f"  [red]Skipped {Path(file_path).name}: {e}[/red]")
                
                if not datasets_list:
                    console.print("[red]Failed to load any datasets![/red]")
                    return
                
                # Concatenate all datasets
                dataset = concatenate_datasets(datasets_list)
                console.print(f"[green]✅ Loaded {len(dataset)} total training examples from {len(datasets_list)} files[/green]")
            else:
                # Single file loading
                dataset = load_dataset("json", data_files=data_path, split="train")
                console.print(f"[green]✅ Loaded {len(dataset)} training examples[/green]")
                
        except Exception as e:
            console.print(f"[red]Failed to load dataset: {e}[/red]")
            return
        
        # 1.5 Data Preparation (Optional optimization)
        dataset = self._prepare_dataset(dataset)

        console.print(f"\n[bold yellow]🔄 Pulling/Loading Model & Tokenizer: {self.model_id}...[/bold yellow]")

        # 2. Load Tokenizer
        try:
            tokenizer = AutoTokenizer.from_pretrained(self.model_id)
            tokenizer.pad_token = tokenizer.eos_token
            console.print("✅ Tokenizer Loaded")
        except Exception as e:
            console.print(f"[red]Failed to load tokenizer: {e}[/red]")
            return
        
        # 3. Load Base Model (Quantized)
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_use_double_quant=True,
        )
        
        model = AutoModelForCausalLM.from_pretrained(
            self.model_id,
            quantization_config=bnb_config,
            device_map="auto",
            trust_remote_code=True 
        )
        
        model.config.use_cache = False # Silence warnings
        model.config.pretraining_tp = 1
        model = prepare_model_for_kbit_training(model)
        
        peft_config = None
        
        if self.adapter_path:
            # 4a. Load existing adapter
            console.print(f"[bold cyan]🔄 Loading existing adapter: {self.adapter_path}...[/bold cyan]")
            model = PeftModel.from_pretrained(model, self.adapter_path, is_trainable=True)
            console.print("[green]✅ Adapter loaded and set to trainable[/green]")
        else:
            # 4b. Create new LoRA Config
            peft_config = LoraConfig(
                lora_alpha=16,
                lora_dropout=0.1,
                r=32,
                bias="none",
                task_type="CAUSAL_LM", 
                target_modules=[
                    "q_proj",
                    "k_proj",
                    "v_proj",
                    "o_proj",
                    "gate_proj",
                    "up_proj",
                    "down_proj",
                ],
            )
            model = get_peft_model(model, peft_config)
            
        model.print_trainable_parameters()
        
        # 5. Training Config (using SFTConfig for new TRL API)
        from trl import SFTConfig
        
        training_args = SFTConfig(
            output_dir=str(self.output_dir),
            num_train_epochs=self.train_params["num_train_epochs"],
            per_device_train_batch_size=self.train_params["per_device_train_batch_size"],
            gradient_accumulation_steps=self.train_params["gradient_accumulation_steps"],
            optim=self.train_params["optim"],
            save_steps=self.train_params["save_steps"],
            logging_steps=self.train_params["logging_steps"],
            learning_rate=self.train_params["learning_rate"],
            weight_decay=0.001,
            fp16=True,
            bf16=False,
            max_grad_norm=0.3,
            max_steps=-1,
            warmup_steps=self.train_params["warmup_steps"],
            group_by_length=True,
            lr_scheduler_type="linear",  # Faster than cosine for short runs
            report_to="tensorboard",
            max_length=self.train_params["max_seq_length"],
            gradient_checkpointing=True,  # Reduce memory usage
        )
        
        # 6. Initialize Trainer
        trainer = SFTTrainer(
            model=model,
            train_dataset=dataset,
            peft_config=peft_config,
            processing_class=tokenizer,
            args=training_args,
            formatting_func=self._format_prompts
        )
        
        # 7. Train
        console.print("\n[bold green]▶️ Starting training loop...[/bold green]\n")
        trainer.train(resume_from_checkpoint=resume_from_checkpoint)
        
        # 8. Save
        adapter_path = self.output_dir / "final_adapter"
        console.print("\n[bold cyan]💾 Saving adapter model...[/bold cyan]")
        trainer.model.save_pretrained(adapter_path)
        
        # Display success summary
        from rich.panel import Panel
        success_msg = f"""
[bold green]✅ Training Complete![/bold green]

[yellow]Adapter Model Saved To:[/yellow]
  {adapter_path}

[yellow]To use this model:[/yellow]
  from peft import PeftModel
  model = PeftModel.from_pretrained(base_model, "{adapter_path}")
"""
        console.print(Panel(success_msg, title="🎉 Success", border_style="green"))
        
        # Auto-sync to Google Drive if enabled
        self._try_auto_sync_to_drive(str(self.output_dir))

    def _try_auto_sync_to_drive(self, model_path: str):
        """Attempt to auto-sync model to Google Drive if enabled."""
        try:
            from saara.cloud_storage import GoogleDriveStorage
            
            storage = GoogleDriveStorage(console)
            if storage.is_connected() and storage.config.auto_sync:
                console.print("\n[cyan]☁️ Auto-syncing to Google Drive...[/cyan]")
                
                results = storage.upload_directory(model_path, "models")
                uploaded = len([v for v in results.values() if v])
                
                if uploaded > 0:
                    console.print(f"[green]✓ Uploaded {uploaded} files to Google Drive[/green]")
                else:
                    console.print("[dim]No new files to upload.[/dim]")
        except ImportError:
            pass  # Google Drive dependencies not installed
        except Exception as e:
            console.print(f"[dim]Auto-sync skipped: {e}[/dim]")


    def _format_prompts(self, example):
        """
        Dynamically format prompts based on the dataset structure.
        Supports: ShareGPT, Alpaca, Q&A, and Raw Text.
        New TRL API - receives single example, returns single string.
        """
        
        # 1. ShareGPT Format (Multi-turn conversation)
        if 'conversations' in example:
            conversation_list = example['conversations']
            text = ""
            for msg in conversation_list:
                role = msg.get('from', msg.get('role', ''))
                content = msg.get('value', msg.get('content', ''))
                # Handle both ShareGPT (human/gpt) and standard (user/assistant) formats
                if role in ['human', 'user']:
                    text += f"User: {content}\n"
                elif role in ['gpt', 'assistant']:
                    text += f"Assistant: {content}\n"
                elif role == 'system':
                    text += f"System: {content}\n"
            return text
                
        # 2. Alpaca Format (Instruction following)
        elif 'instruction' in example and 'output' in example:
            instr = example['instruction']
            inp = example.get('input', '')
            out = example['output']
            
            if inp:
                return f"Instruction: {instr}\nInput: {inp}\nResponse: {out}"
            else:
                return f"Instruction: {instr}\nResponse: {out}"
        
        # 3. Q&A Format (New Support)
        elif 'question' in example and 'answer' in example:
            return f"Question: {example['question']}\nAnswer: {example['answer']}"
                
        # 4. Raw Text Format (Pre-training / Completion)
        elif 'text' in example:
            return example['text']
            
        else:
            # Fallback for unknown format
            # Try to return first available column to avoid crashing with None
            try:
                first_col = list(example.keys())[0]
                return str(example[first_col])
            except Exception:
                return "" # Safest fallback (will likely be filtered out by tokenizer or short length)

    def _prepare_dataset(self, dataset):
        """
        Prepare and optimize dataset for training.
        Uses Granite 4 via Ollama to validate and fix data issues.
        """
        console.print("\n[bold yellow]🔧 Preparing Dataset...[/bold yellow]")
        
        original_count = len(dataset)
        
        # Step 0: Normalize role names (ShareGPT human/gpt -> user/assistant)
        def normalize_roles(example):
            if 'conversations' in example and example['conversations'] is not None:
                convs = example['conversations']
                if isinstance(convs, list):
                    for msg in convs:
                        if isinstance(msg, dict):
                            if msg.get('from') == 'human':
                                msg['from'] = 'user'
                            elif msg.get('from') == 'gpt':
                                msg['from'] = 'assistant'
                            # Also handle 'role' key
                            if msg.get('role') == 'human':
                                msg['role'] = 'user'
                            elif msg.get('role') == 'gpt':
                                msg['role'] = 'assistant'
            return example
        
        dataset = dataset.map(normalize_roles)
        
        # Step 1: Filter out empty/invalid samples
        def is_valid(example):
            try:
                if 'conversations' in example:
                    convs = example['conversations']
                    if convs is None or not isinstance(convs, list) or len(convs) < 2:
                        return False
                    # Check that at least 2 messages have valid content
                    valid_msgs = 0
                    for msg in convs:
                        if msg is None or not isinstance(msg, dict):
                            continue
                        content = msg.get('value') or msg.get('content')
                        if content and len(str(content).strip()) > 0:
                            valid_msgs += 1
                    return valid_msgs >= 2
                elif 'instruction' in example and 'output' in example:
                    return bool(example['instruction']) and bool(example['output'])
                elif 'question' in example and 'answer' in example:
                    return bool(example['question']) and bool(example['answer'])
                elif 'text' in example:
                    text = example['text']
                    return text is not None and bool(text) and len(str(text)) > 50
                return False
            except Exception:
                return False
        
        dataset = dataset.filter(is_valid)
        filtered_count = len(dataset)
        
        if filtered_count < original_count:
            console.print(f"  [dim]Removed {original_count - filtered_count} invalid samples[/dim]")
        
        # Step 2: Truncate very long samples for faster training
        def truncate_sample(example):
            max_chars = 4000  # ~1000 tokens
            if 'conversations' in example and example['conversations'] is not None:
                convs = example['conversations']
                if isinstance(convs, list):
                    for msg in convs:
                        if msg is None or not isinstance(msg, dict):
                            continue
                        # Handle both 'value' (ShareGPT) and 'content' (standard) keys
                        for key in ['value', 'content']:
                            if key in msg and msg[key] is not None and len(str(msg[key])) > max_chars:
                                msg[key] = str(msg[key])[:max_chars] + "..."
            elif 'text' in example and example['text'] is not None:
                if len(str(example['text'])) > max_chars:
                    example['text'] = str(example['text'])[:max_chars] + "..."
            return example
        
        dataset = dataset.map(truncate_sample)
        
        # Step 3: Shuffle for better training
        dataset = dataset.shuffle(seed=42)
        
        console.print(f"  [green]✅ Dataset ready: {len(dataset)} samples[/green]")
        
        return dataset


# ============================================================================
# Autonomous Fine-tuning with Teacher AI
# ============================================================================

class AutonomousFineTuner:
    """
    Autonomous fine-tuning pipeline with teacher AI (Sarvam/Gemini).
    
    The teacher generates high-quality Q&A pairs for fine-tuning,
    which is much more practical than pre-training from scratch.
    """
    
    def __init__(self,
                 base_model: str = "google/gemma-2-2b",
                 teacher_config: Dict[str, Any] = None,
                 output_dir: str = "datasets"):
        
        self.base_model = base_model
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        # Teacher configuration
        self.teacher_config = teacher_config or {
            "provider": "google",
            "model": "gemini-2.0-flash-exp"
        }
        
        self.teacher = None
        
    def _init_teacher(self):
        """Initialize teacher model."""
        from saara.evaluator import TeacherClient
        self.teacher = TeacherClient(self.teacher_config)
        
    def generate_qa_pairs(self, topic: str, num_pairs: int = 10) -> list:
        """Generate Q&A pairs on a topic."""
        if not self.teacher:
            self._init_teacher()
        
        prompt = f"""Generate {num_pairs} high-quality question-answer pairs about: {topic}

Requirements:
- Questions should be diverse (what, why, how, when, compare, explain)
- Answers should be detailed (50-200 words each)
- Include specific facts, examples, and explanations
- Cover different difficulty levels (beginner to advanced)

Format EXACTLY as:
Q: [question]
A: [detailed answer]

Q: [question]
A: [detailed answer]

Generate Q&A pairs about {topic}:"""

        response = self.teacher.generate(prompt)
        
        # Parse Q&A pairs
        pairs = []
        lines = response.split('\n')
        current_q = None
        current_a = []
        
        for line in lines:
            line = line.strip()
            if line.startswith('Q:'):
                if current_q and current_a:
                    pairs.append({
                        "question": current_q,
                        "answer": ' '.join(current_a)
                    })
                current_q = line[2:].strip()
                current_a = []
            elif line.startswith('A:'):
                current_a = [line[2:].strip()]
            elif current_a is not None and line:
                current_a.append(line)
        
        # Don't forget the last pair
        if current_q and current_a:
            pairs.append({
                "question": current_q,
                "answer": ' '.join(current_a)
            })
        
        return pairs
    
    def generate_curriculum(self, domain: str, num_topics: int = 20) -> list:
        """Generate curriculum topics for the domain."""
        if not self.teacher:
            self._init_teacher()
            
        prompt = f"""Generate {num_topics} specific topics for teaching an AI about: {domain}

Order from basic to advanced. Output ONLY a numbered list.

Topics for {domain}:"""
        
        response = self.teacher.generate(prompt)
        
        topics = []
        for line in response.split('\n'):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                topic = line.lstrip('0123456789.-) ').strip()
                if topic and len(topic) > 5:
                    topics.append(topic)
        
        # Fallback if parsing fails
        if not topics:
            topics = [
                f"Introduction to {domain}",
                f"Basic concepts of {domain}",
                f"History of {domain}",
                f"Key principles in {domain}",
                f"Practical applications of {domain}",
            ]
        
        return topics[:num_topics]
    
    def run_autonomous_generation(self,
                                  domain: str,
                                  target_pairs: int = 500,
                                  quality_threshold: int = 7) -> str:
        """
        Autonomously generate fine-tuning dataset.
        
        Returns path to generated JSONL file.
        """
        from rich.panel import Panel
        from rich.progress import Progress, SpinnerColumn, TextColumn
        import json
        
        console.print(Panel.fit(
            f"[bold cyan]🤖 Autonomous Fine-tuning Data Generation[/bold cyan]\n\n"
            f"Domain: {domain}\n"
            f"Target Q&A Pairs: {target_pairs}\n"
            f"Quality Threshold: {quality_threshold}/10\n"
            f"Teacher: {self.teacher_config['provider']}/{self.teacher_config['model']}",
            title="Autonomous Fine-tuning",
            border_style="green"
        ))
        
        if not self.teacher:
            self._init_teacher()
        
        # Step 1: Generate curriculum
        console.print("\n[bold yellow]Step 1: Generating Curriculum[/bold yellow]")
        topics = self.generate_curriculum(domain, num_topics=25)
        console.print(f"[green]✓ Generated {len(topics)} topics[/green]")
        
        for i, t in enumerate(topics[:5], 1):
            console.print(f"  [dim]{i}. {t}[/dim]")
        if len(topics) > 5:
            console.print(f"  [dim]... and {len(topics) - 5} more[/dim]")
        
        # Step 2: Generate Q&A pairs
        console.print("\n[bold yellow]Step 2: Generating Q&A Pairs[/bold yellow]")
        
        all_pairs = []
        pairs_per_topic = max(5, target_pairs // len(topics))
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            task = progress.add_task(f"Generating Q&A pairs...", total=len(topics))
            
            for topic in topics:
                try:
                    pairs = self.generate_qa_pairs(f"{domain}: {topic}", num_pairs=pairs_per_topic)
                    all_pairs.extend(pairs)
                    console.print(f"  [dim]Generated {len(pairs)} pairs for: {topic[:40]}...[/dim]")
                except Exception as e:
                    console.print(f"  [yellow]⚠ Error for {topic}: {e}[/yellow]")
                
                progress.advance(task)
                
                if len(all_pairs) >= target_pairs * 1.2:
                    break
        
        console.print(f"[green]✓ Generated {len(all_pairs)} total Q&A pairs[/green]")
        
        # Step 3: Convert to ShareGPT format
        console.print("\n[bold yellow]Step 3: Formatting for Fine-tuning[/bold yellow]")
        
        formatted_data = []
        for pair in all_pairs:
            if pair['question'] and pair['answer'] and len(pair['answer']) > 20:
                formatted_data.append({
                    "conversations": [
                        {"role": "user", "content": pair['question']},
                        {"role": "assistant", "content": pair['answer']}
                    ]
                })
        
        # Step 4: Save dataset
        output_file = self.output_dir / f"{domain.replace(' ', '_').lower()}_finetune.jsonl"
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for item in formatted_data:
                f.write(json.dumps(item, ensure_ascii=False) + '\n')
        
        console.print(Panel(f"""
[bold green]✅ Fine-tuning Dataset Ready![/bold green]

[yellow]Q&A Pairs:[/yellow] {len(formatted_data)}
[yellow]Output File:[/yellow] {output_file}
[yellow]Format:[/yellow] ShareGPT (conversations)

[bold]Next Step - Fine-tune your model:[/bold]
  saara run → Model Training → Select base model
  → Use dataset: {output_file}
""", title="Generation Complete", border_style="green"))
        
        return str(output_file)
    
    def run_full_pipeline(self,
                          domain: str,
                          target_pairs: int = 500,
                          train_model: bool = True) -> Optional[str]:
        """Run full autonomous fine-tuning pipeline."""
        
        # Generate dataset
        dataset_path = self.run_autonomous_generation(domain, target_pairs)
        
        if not train_model:
            return dataset_path
        
        # Fine-tune model
        console.print("\n[bold yellow]Step 4: Fine-tuning Model[/bold yellow]")
        
        trainer = LLMTrainer(model_id=self.base_model)
        trainer.train(dataset_path)
        
        return str(trainer.output_dir)


# ============================================================================
# Autonomous Dataset Generator - Create datasets from any LLM
# ============================================================================

class AutonomousDatasetGenerator:
    """
    Generate high-quality training datasets from various LLM providers.
    
    This is a standalone generator that creates datasets without requiring
    a base model - perfect for creating training data before model selection.
    
    Supports:
    - Multiple LLM providers (Google AI, OpenAI, Sarvam, Groq, DeepSeek, Ollama)
    - Multiple dataset types (Q&A, instruction, conversational, raw text)
    - Multiple output formats (ShareGPT, Alpaca, simple Q&A)
    """
    
    # Dataset type configurations
    DATASET_TYPES = {
        "qa": {
            "name": "Question & Answer",
            "description": "Generate Q&A pairs for knowledge domains",
            "prompt_template": """Generate {count} high-quality question-answer pairs about: {topic}

Requirements:
- Questions should be diverse (what, why, how, when, compare, explain)
- Answers should be detailed (50-200 words each)
- Include specific facts, examples, and explanations
- Cover different difficulty levels (beginner to advanced)

Format EXACTLY as:
Q: [question]
A: [detailed answer]

Q: [question]
A: [detailed answer]

Generate Q&A pairs:"""
        },
        "instruction": {
            "name": "Instruction Following",
            "description": "Generate instruction-response pairs for task completion",
            "prompt_template": """Generate {count} high-quality instruction-response pairs about: {topic}

Requirements:
- Instructions should be clear and specific
- Include both simple and complex tasks
- Responses should be helpful, accurate, and complete
- Cover various task types (summarize, explain, analyze, create, compare)

Format EXACTLY as:
INSTRUCTION: [clear task instruction]
RESPONSE: [detailed, helpful response]

INSTRUCTION: [instruction]
RESPONSE: [response]

Generate instruction pairs:"""
        },
        "conversation": {
            "name": "Multi-turn Conversation",
            "description": "Generate realistic multi-turn dialogues",
            "prompt_template": """Generate a realistic multi-turn conversation about: {topic}

Requirements:
- At least {count} exchanges (user + assistant turns)
- Natural, flowing dialogue
- Include follow-up questions and clarifications
- Cover the topic thoroughly

Format EXACTLY as:
USER: [user message]
ASSISTANT: [assistant response]
USER: [follow-up question]
ASSISTANT: [helpful response]

Generate conversation:"""
        },
        "text": {
            "name": "Raw Text/Articles",
            "description": "Generate informative articles and passages",
            "prompt_template": """Write {count} informative paragraphs about: {topic}

Requirements:
- Each paragraph should be 100-200 words
- Cover different aspects of the topic
- Include facts, examples, and explanations
- Use clear, educational language

Generate informative content:"""
        }
    }
    
    # Output format configurations  
    OUTPUT_FORMATS = {
        "sharegpt": {
            "name": "ShareGPT",
            "description": "Conversation format with roles",
            "extension": "_sharegpt.jsonl"
        },
        "alpaca": {
            "name": "Alpaca",
            "description": "Instruction-input-output format",
            "extension": "_alpaca.jsonl"
        },
        "simple": {
            "name": "Simple Q&A",
            "description": "Plain question-answer pairs",
            "extension": "_qa.jsonl"
        }
    }
    
    def __init__(self, 
                 teacher_config: Dict[str, Any] = None,
                 output_dir: str = "datasets"):
        """
        Initialize the Autonomous Dataset Generator.
        
        Args:
            teacher_config: Configuration for the LLM provider
                - provider: "google", "openai", "sarvam", "groq", "deepseek", "ollama"
                - model: Model name
                - api_key: API key (not needed for ollama)
            output_dir: Directory to save generated datasets
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        
        self.teacher_config = teacher_config or {
            "provider": "google",
            "model": "gemini-2.0-flash-exp"
        }
        
        self.teacher = None
        
    def _init_teacher(self):
        """Initialize the teacher/LLM client."""
        from saara.evaluator import TeacherClient
        self.teacher = TeacherClient(self.teacher_config)
        
    def generate_curriculum(self, domain: str, num_topics: int = 20) -> list:
        """Generate a curriculum of topics for the domain."""
        if not self.teacher:
            self._init_teacher()
            
        prompt = f"""Generate {num_topics} specific topics for creating training data about: {domain}

Order from basic to advanced concepts. Be specific and comprehensive.
Output ONLY a numbered list.

Topics for {domain}:"""
        
        response = self.teacher.generate(prompt)
        
        topics = []
        for line in response.split('\n'):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                topic = line.lstrip('0123456789.-) ').strip()
                if topic and len(topic) > 5:
                    topics.append(topic)
        
        # Fallback if parsing fails
        if not topics:
            topics = [
                f"Introduction to {domain}",
                f"Core concepts of {domain}",
                f"History and evolution of {domain}",
                f"Key principles in {domain}",
                f"Practical applications of {domain}",
                f"Advanced topics in {domain}",
                f"Best practices for {domain}",
                f"Common challenges in {domain}",
                f"Future trends in {domain}",
                f"Case studies in {domain}",
            ]
        
        return topics[:num_topics]
    
    def _parse_qa_response(self, response: str) -> list:
        """Parse Q&A pairs from LLM response."""
        pairs = []
        lines = response.split('\n')
        current_q = None
        current_a = []
        
        for line in lines:
            line = line.strip()
            if line.startswith('Q:') or line.startswith('Question:'):
                if current_q and current_a:
                    pairs.append({
                        "question": current_q,
                        "answer": ' '.join(current_a)
                    })
                # Handle both Q: and Question: prefixes
                current_q = line.split(':', 1)[1].strip() if ':' in line else line
                current_a = []
            elif line.startswith('A:') or line.startswith('Answer:'):
                current_a = [line.split(':', 1)[1].strip() if ':' in line else line]
            elif current_a is not None and line:
                current_a.append(line)
        
        # Don't forget the last pair
        if current_q and current_a:
            pairs.append({
                "question": current_q,
                "answer": ' '.join(current_a)
            })
        
        return pairs
    
    def _parse_instruction_response(self, response: str) -> list:
        """Parse instruction-response pairs from LLM response."""
        pairs = []
        lines = response.split('\n')
        current_instr = None
        current_resp = []
        
        for line in lines:
            line = line.strip()
            if line.startswith('INSTRUCTION:') or line.startswith('Instruction:'):
                if current_instr and current_resp:
                    pairs.append({
                        "instruction": current_instr,
                        "input": "",
                        "output": ' '.join(current_resp)
                    })
                current_instr = line.split(':', 1)[1].strip() if ':' in line else line
                current_resp = []
            elif line.startswith('RESPONSE:') or line.startswith('Response:'):
                current_resp = [line.split(':', 1)[1].strip() if ':' in line else line]
            elif current_resp is not None and line:
                current_resp.append(line)
        
        # Don't forget the last pair
        if current_instr and current_resp:
            pairs.append({
                "instruction": current_instr,
                "input": "",
                "output": ' '.join(current_resp)
            })
        
        return pairs
    
    def _parse_conversation_response(self, response: str) -> list:
        """Parse multi-turn conversation from LLM response."""
        messages = []
        lines = response.split('\n')
        
        for line in lines:
            line = line.strip()
            if line.startswith('USER:') or line.startswith('User:'):
                content = line.split(':', 1)[1].strip() if ':' in line else line
                if content:
                    messages.append({"role": "user", "content": content})
            elif line.startswith('ASSISTANT:') or line.startswith('Assistant:'):
                content = line.split(':', 1)[1].strip() if ':' in line else line
                if content:
                    messages.append({"role": "assistant", "content": content})
        
        # Return as single conversation if valid
        if len(messages) >= 2:
            return [{"conversations": messages}]
        return []
    
    def _parse_text_response(self, response: str) -> list:
        """Parse raw text content from LLM response."""
        # Split into paragraphs
        paragraphs = [p.strip() for p in response.split('\n\n') if p.strip() and len(p.strip()) > 50]
        
        return [{"text": p} for p in paragraphs]
    
    def generate_samples(self, 
                        topic: str, 
                        dataset_type: str = "qa",
                        count: int = 10) -> list:
        """
        Generate samples for a specific topic.
        
        Args:
            topic: The topic to generate samples for
            dataset_type: Type of dataset ("qa", "instruction", "conversation", "text")
            count: Number of samples to generate
            
        Returns:
            List of generated samples
        """
        if not self.teacher:
            self._init_teacher()
        
        if dataset_type not in self.DATASET_TYPES:
            dataset_type = "qa"
        
        template = self.DATASET_TYPES[dataset_type]["prompt_template"]
        prompt = template.format(topic=topic, count=count)
        
        response = self.teacher.generate(prompt)
        
        # Parse based on type
        if dataset_type == "qa":
            return self._parse_qa_response(response)
        elif dataset_type == "instruction":
            return self._parse_instruction_response(response)
        elif dataset_type == "conversation":
            return self._parse_conversation_response(response)
        elif dataset_type == "text":
            return self._parse_text_response(response)
        
        return []
    
    def _convert_to_format(self, samples: list, dataset_type: str, output_format: str) -> list:
        """Convert samples to the specified output format."""
        formatted = []
        
        for sample in samples:
            if output_format == "sharegpt":
                # Convert to ShareGPT conversation format
                if dataset_type == "qa":
                    formatted.append({
                        "conversations": [
                            {"role": "user", "content": sample.get("question", "")},
                            {"role": "assistant", "content": sample.get("answer", "")}
                        ]
                    })
                elif dataset_type == "instruction":
                    instr = sample.get("instruction", "")
                    inp = sample.get("input", "")
                    content = f"{instr}\n\nInput: {inp}" if inp else instr
                    formatted.append({
                        "conversations": [
                            {"role": "user", "content": content},
                            {"role": "assistant", "content": sample.get("output", "")}
                        ]
                    })
                elif dataset_type == "conversation":
                    formatted.append(sample)  # Already in format
                elif dataset_type == "text":
                    formatted.append({
                        "conversations": [
                            {"role": "user", "content": "Continue this text:"},
                            {"role": "assistant", "content": sample.get("text", "")}
                        ]
                    })
                    
            elif output_format == "alpaca":
                # Convert to Alpaca format
                if dataset_type == "qa":
                    formatted.append({
                        "instruction": sample.get("question", ""),
                        "input": "",
                        "output": sample.get("answer", "")
                    })
                elif dataset_type == "instruction":
                    formatted.append(sample)  # Already in format
                elif dataset_type == "conversation":
                    # Flatten to single Q&A
                    convs = sample.get("conversations", [])
                    if len(convs) >= 2:
                        formatted.append({
                            "instruction": convs[0].get("content", ""),
                            "input": "",
                            "output": convs[1].get("content", "")
                        })
                elif dataset_type == "text":
                    formatted.append({
                        "instruction": "Generate informative content:",
                        "input": "",
                        "output": sample.get("text", "")
                    })
                    
            elif output_format == "simple":
                # Simple Q&A format
                if dataset_type == "qa":
                    formatted.append(sample)  # Already in format
                elif dataset_type == "instruction":
                    formatted.append({
                        "question": sample.get("instruction", ""),
                        "answer": sample.get("output", "")
                    })
                elif dataset_type == "conversation":
                    convs = sample.get("conversations", [])
                    if len(convs) >= 2:
                        formatted.append({
                            "question": convs[0].get("content", ""),
                            "answer": convs[1].get("content", "")
                        })
                elif dataset_type == "text":
                    formatted.append(sample)
        
        return formatted
    
    def generate_dataset(self,
                        domain: str,
                        dataset_type: str = "qa",
                        output_format: str = "sharegpt",
                        target_samples: int = 500,
                        samples_per_topic: int = 10,
                        system_prompt: str = None,
                        dataset_name: str = None) -> str:
        """
        Generate a complete dataset for a domain.
        
        Args:
            domain: The knowledge domain (e.g., "Machine Learning", "Sanskrit Grammar")
            dataset_type: Type of data to generate ("qa", "instruction", "conversation", "text")
            output_format: Output format ("sharegpt", "alpaca", "simple")
            target_samples: Target number of samples to generate
            samples_per_topic: Samples to generate per topic
            system_prompt: Optional system prompt to include in conversations
            dataset_name: Optional custom name for the output file
            
        Returns:
            Path to the generated dataset file
        """
        from rich.panel import Panel
        from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
        import json
        
        type_info = self.DATASET_TYPES.get(dataset_type, self.DATASET_TYPES["qa"])
        format_info = self.OUTPUT_FORMATS.get(output_format, self.OUTPUT_FORMATS["sharegpt"])
        
        console.print(Panel.fit(
            f"[bold cyan]🤖 Autonomous Dataset Generation[/bold cyan]\n\n"
            f"[yellow]Domain:[/yellow] {domain}\n"
            f"[yellow]Type:[/yellow] {type_info['name']}\n"
            f"[yellow]Format:[/yellow] {format_info['name']}\n"
            f"[yellow]Target Samples:[/yellow] {target_samples}\n"
            f"[yellow]LLM Provider:[/yellow] {self.teacher_config['provider']}/{self.teacher_config['model']}",
            title="📊 Dataset Generator",
            border_style="green"
        ))
        
        if not self.teacher:
            self._init_teacher()
        
        # Step 1: Generate curriculum
        console.print("\n[bold yellow]Step 1: Generating Curriculum[/bold yellow]")
        num_topics = max(5, target_samples // samples_per_topic)
        topics = self.generate_curriculum(domain, num_topics=min(num_topics, 50))
        console.print(f"[green]✓ Generated {len(topics)} topics[/green]")
        
        for i, t in enumerate(topics[:5], 1):
            console.print(f"  [dim]{i}. {t}[/dim]")
        if len(topics) > 5:
            console.print(f"  [dim]... and {len(topics) - 5} more[/dim]")
        
        # Step 2: Generate samples
        console.print(f"\n[bold yellow]Step 2: Generating {type_info['name']} Samples[/bold yellow]")
        
        all_samples = []
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            console=console
        ) as progress:
            task = progress.add_task("Generating samples...", total=len(topics))
            
            for topic in topics:
                try:
                    samples = self.generate_samples(
                        topic=f"{domain}: {topic}",
                        dataset_type=dataset_type,
                        count=samples_per_topic
                    )
                    all_samples.extend(samples)
                    console.print(f"  [dim]Generated {len(samples)} samples for: {topic[:40]}...[/dim]")
                except Exception as e:
                    console.print(f"  [yellow]⚠ Error for {topic}: {e}[/yellow]")
                
                progress.advance(task)
                
                # Stop if we have enough samples
                if len(all_samples) >= target_samples * 1.2:
                    break
        
        console.print(f"[green]✓ Generated {len(all_samples)} raw samples[/green]")
        
        # Step 3: Format samples
        console.print(f"\n[bold yellow]Step 3: Converting to {format_info['name']} Format[/bold yellow]")
        
        formatted_samples = self._convert_to_format(all_samples, dataset_type, output_format)
        
        # Add system prompt if provided and format supports it
        if system_prompt and output_format == "sharegpt":
            for sample in formatted_samples:
                if "conversations" in sample:
                    sample["conversations"].insert(0, {
                        "role": "system",
                        "content": system_prompt
                    })
        
        # Filter out empty/invalid samples
        valid_samples = []
        for sample in formatted_samples:
            if output_format == "sharegpt":
                if sample.get("conversations") and len(sample["conversations"]) >= 2:
                    valid_samples.append(sample)
            elif output_format == "alpaca":
                if sample.get("instruction") and sample.get("output"):
                    valid_samples.append(sample)
            else:
                if sample.get("question") or sample.get("text"):
                    valid_samples.append(sample)
        
        console.print(f"[green]✓ Formatted {len(valid_samples)} valid samples[/green]")
        
        # Step 4: Save dataset
        console.print("\n[bold yellow]Step 4: Saving Dataset[/bold yellow]")
        
        safe_domain = domain.replace(' ', '_').lower()[:30]
        if dataset_name:
            filename = f"{dataset_name}{format_info['extension']}"
        else:
            filename = f"{safe_domain}_{dataset_type}{format_info['extension']}"
        
        output_file = self.output_dir / filename
        
        with open(output_file, 'w', encoding='utf-8') as f:
            for sample in valid_samples:
                f.write(json.dumps(sample, ensure_ascii=False) + '\n')
        
        # Also save metadata
        metadata = {
            "domain": domain,
            "dataset_type": dataset_type,
            "output_format": output_format,
            "total_samples": len(valid_samples),
            "topics_covered": len(topics),
            "llm_provider": self.teacher_config['provider'],
            "llm_model": self.teacher_config['model'],
            "system_prompt": system_prompt,
            "generated_at": str(Path(output_file).stat().st_mtime) if output_file.exists() else None
        }
        
        metadata_file = output_file.with_suffix('.meta.json')
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
        
        # Display success summary
        console.print(Panel(f"""
[bold green]✅ Dataset Generated Successfully![/bold green]

[yellow]Total Samples:[/yellow] {len(valid_samples)}
[yellow]Topics Covered:[/yellow] {len(topics)}
[yellow]Output File:[/yellow] {output_file}
[yellow]Format:[/yellow] {format_info['name']} ({format_info['description']})
[yellow]Metadata:[/yellow] {metadata_file}

[bold]Next Steps:[/bold]
  • Fine-tune a model: [cyan]saara run → Model Training[/cyan]
  • View dataset: [cyan]head {output_file}[/cyan]
  • Generate more data: [cyan]saara generate[/cyan]
""", title="🎉 Generation Complete", border_style="green"))
        
        return str(output_file)


if __name__ == "__main__":
    # Test
    if len(sys.argv) > 1:
        path = sys.argv[1]
    else:
        path = "datasets/distilled_train.jsonl"
        
    trainer = LLMTrainer()
    trainer.train(path)

