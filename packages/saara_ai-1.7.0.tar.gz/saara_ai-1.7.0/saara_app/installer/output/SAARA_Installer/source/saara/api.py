"""
FastAPI Web Interface for SAARA Data Engine
Provides REST endpoints for Flutter frontend and other clients.

This API exposes all CLI functionality while keeping the CLI fully operational.
The CLI commands continue to work via terminal, and the API provides the same
functionality for GUI applications.

© 2024-2026 Kilani Sai Nikhil. All Rights Reserved.
"""

from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any
import shutil
import os
import json
import asyncio
from pathlib import Path
import logging
from datetime import datetime
import uuid
import threading

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("saara_api")

# =============================================================================
# FastAPI Application
# =============================================================================

app = FastAPI(
    title="SAARA Data Engine API",
    description="""
    🧠 SAARA - Autonomous Document-to-LLM Data Factory
    
    REST API for Flutter frontend integration. Exposes all CLI functionality:
    - Dataset creation from PDFs
    - AI-powered dataset generation
    - Model training (fine-tuning & pre-training)
    - Model evaluation & autonomous learning
    - Deployment (Ollama, HuggingFace, Cloud)
    - Google Drive sync
    - SAARA Hub authentication
    """,
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Enable CORS for Flutter
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =============================================================================
# In-Memory Storage (for job tracking)
# =============================================================================

jobs: Dict[str, Dict] = {}
training_jobs: Dict[str, Dict] = {}
websocket_clients: Dict[str, WebSocket] = {}

# =============================================================================
# Pydantic Models for Request/Response
# =============================================================================

# --- Common ---
class JobStatus(BaseModel):
    job_id: str
    job_type: str = "processing"
    status: str  # pending, running, completed, failed
    progress: float = 0.0
    message: str = ""
    created_at: str
    completed_at: Optional[str] = None
    result: Optional[Dict] = None
    error: Optional[str] = None

class HealthResponse(BaseModel):
    status: str
    ollama_connected: bool
    gpu_available: bool
    model_info: Dict

# --- Hardware ---
class HardwareInfo(BaseModel):
    cpu: str
    ram_gb: float
    gpu_name: Optional[str] = None
    vram_gb: Optional[float] = None
    cuda_available: bool
    recommended_tier: str
    gpu_util: Optional[float] = 0.0
    gpu_temp: Optional[float] = 0.0
    fan_speed: Optional[float] = 0.0
    vram_used_gb: Optional[float] = 0.0

# --- Models ---
class OllamaModel(BaseModel):
    name: str
    size_gb: float
    is_installed: bool
    category: str  # vision, analyzer, base
    description: str

class ModelCatalog(BaseModel):
    vision_models: List[OllamaModel]
    analyzer_models: List[OllamaModel]
    base_models: List[OllamaModel]
    recommended: Dict[str, str]

class InstallModelRequest(BaseModel):
    model_name: str

# --- Datasets ---
class DatasetInfo(BaseModel):
    name: str
    path: str
    samples: int
    format: str
    created_at: str
    size_bytes: int

class CreateDatasetRequest(BaseModel):
    input_path: str
    dataset_name: str
    vision_model: str = "qwen2.5vl:3b"
    use_llm_enhancement: bool = False
    llm_model: str = "granite4:latest"

class GenerateDatasetRequest(BaseModel):
    domain: str
    samples: int = 500
    dataset_type: str = "qa"  # qa, instruction, conversation, text
    output_format: str = "sharegpt"  # sharegpt, alpaca, simple
    provider: str = "google"  # google, openai, ollama, groq, deepseek, sarvam
    teacher_model: Optional[str] = None
    system_prompt: Optional[str] = None

# --- Training ---
class TrainingRequest(BaseModel):
    dataset_path: str
    base_model: str = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"
    output_name: str = "my_model"
    epochs: int = 3
    batch_size: int = 2
    learning_rate: float = 2e-4
    quantization: str = "4bit"  # 4bit, 8bit, none
    use_lora: bool = True
    lora_r: int = 16
    lora_alpha: int = 32

class PretrainRequest(BaseModel):
    dataset_path: str
    architecture: str = "nano"  # nano, micro, mini, small, base, large
    model_name: str = "my_pretrained_model"
    epochs: int = 1
    batch_size: int = 4
    learning_rate: float = 1e-4
    train_tokenizer: bool = True
    vocab_size: int = 32000

class TrainingStatus(BaseModel):
    job_id: str
    status: str
    epoch: int = 0
    total_epochs: int = 0
    step: int = 0
    total_steps: int = 0
    loss: float = 0.0
    learning_rate: float = 0.0
    eta_seconds: int = 0
    metrics: Dict[str, float] = {}

# --- Evaluation ---
class EvaluateRequest(BaseModel):
    base_model_id: str
    adapter_path: str
    num_samples: int = 20

class AutonomousLearningRequest(BaseModel):
    base_model_id: str
    adapter_path: str
    topic: str
    iterations: int = 5
    teacher_provider: str = "ollama"
    teacher_model: str = "granite4:latest"

# --- Deployment ---
class DeployOllamaRequest(BaseModel):
    base_model_id: str
    adapter_path: str
    model_name: str

class DeployHuggingFaceRequest(BaseModel):
    base_model_id: str
    adapter_path: str
    repo_name: str
    private: bool = True

# --- Chat/Inference ---
class ChatRequest(BaseModel):
    model_type: str = "ollama"  # "ollama", "trained", "hf"
    model_name: str  # For ollama: model name, for trained: adapter path
    message: str
    system_prompt: Optional[str] = None
    base_model: Optional[str] = None  # Required for trained models
    temperature: float = 0.7
    max_tokens: int = 512
    history: List[Dict[str, str]] = []

class ChatResponse(BaseModel):
    response: str
    model: str
    latency_ms: float
    tokens_generated: int = 0

# --- HuggingFace Hub ---
class HubPushModelRequest(BaseModel):
    model_path: str
    repo_name: str
    domain: str = "general"
    private: bool = False

class HubPushDatasetRequest(BaseModel):
    dataset_path: str
    repo_name: str
    domain: str = "general"
    private: bool = False

class HubStatus(BaseModel):
    logged_in: bool
    username: Optional[str] = None
    repos_count: int = 0

# --- Tokenizer ---
class TrainTokenizerRequest(BaseModel):
    data_path: str
    output_name: str
    vocab_size: int = 32000
    domain: str = "general"
    use_ai: bool = True

# --- Authentication ---
class AuthStatus(BaseModel):
    logged_in: bool
    user_id: Optional[str] = None
    email: Optional[str] = None
    name: Optional[str] = None
    plan: str = "free"

class LoginRequest(BaseModel):
    email: str
    name: str

# --- API Keys ---
class APIKeyStatus(BaseModel):
    provider: str
    configured: bool
    masked_key: Optional[str] = None

class SetAPIKeyRequest(BaseModel):
    provider: str
    key: str

# --- Cloud Storage ---
class DriveStatus(BaseModel):
    connected: bool
    account_email: Optional[str] = None
    storage_used: Optional[str] = None
    last_sync: Optional[str] = None

class DriveSyncRequest(BaseModel):
    target: str = "all"  # all, models, datasets, tokenizers
    direction: str = "both"  # upload, download, both

# --- Trained Models ---
class TrainedModel(BaseModel):
    name: str
    path: str
    base_model: str
    created_at: str
    size_mb: float
    type: str  # finetuned, pretrained

# =============================================================================
# WebSocket Manager for Real-time Updates
# =============================================================================

class WebSocketManager:
    """Manages WebSocket connections for real-time progress updates."""
    
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
    
    async def connect(self, client_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.info(f"WebSocket client connected: {client_id}")
    
    def disconnect(self, client_id: str):
        if client_id in self.active_connections:
            del self.active_connections[client_id]
            logger.info(f"WebSocket client disconnected: {client_id}")
    
    async def send_progress(self, client_id: str, data: dict):
        if client_id in self.active_connections:
            try:
                await self.active_connections[client_id].send_json(data)
            except Exception as e:
                logger.error(f"Failed to send to {client_id}: {e}")
    
    async def broadcast(self, job_id: str, data: dict):
        """Broadcast progress to all connected clients."""
        for client_id, websocket in self.active_connections.items():
            try:
                await websocket.send_json({"job_id": job_id, **data})
            except Exception as e:
                logger.error(f"Broadcast failed for {client_id}: {e}")

ws_manager = WebSocketManager()

# =============================================================================
# Health & System Endpoints
# =============================================================================

@app.get("/health", response_model=HealthResponse, tags=["System"])
async def health_check():
    """Check API and system health."""
    ollama_connected = False
    gpu_available = False
    model_info = {}
    
    try:
        from .ollama_client import OllamaClient
        client = OllamaClient()
        ollama_connected = client.check_health()
        if ollama_connected:
            model_info = client.get_model_info()
    except Exception as e:
        logger.error(f"Ollama check failed: {e}")
    
    try:
        import torch
        gpu_available = torch.cuda.is_available()
    except:
        pass
    
    return {
        "status": "healthy" if ollama_connected else "degraded",
        "ollama_connected": ollama_connected,
        "gpu_available": gpu_available,
        "model_info": model_info
    }

@app.get("/hardware", response_model=HardwareInfo, tags=["System"])
async def get_hardware_info():
    """Get system hardware capabilities."""
    try:
        from .model_manager import HardwareDetector
        detector = HardwareDetector()
        info = detector.get_system_info()
        tier = detector.get_recommended_tier(info)
        
        return {
            "cpu": info.get("cpu", "Unknown"),
            "ram_gb": info.get("ram_gb", 0),
            "gpu_name": info.get("gpu_name"),
            "vram_gb": info.get("vram_gb"),
            "cuda_available": info.get("cuda_available", False),
            "recommended_tier": tier,
            "gpu_util": info.get("gpu_util", 0.0),
            "gpu_temp": info.get("gpu_temp", 0.0),
            "fan_speed": info.get("fan_speed", 0.0)
        }
    except Exception as e:
        logger.error(f"Hardware detection failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# Model Management Endpoints
# =============================================================================

@app.get("/models/installed", response_model=List[OllamaModel], tags=["Models"])
async def list_installed_models():
    """List all installed Ollama models."""
    try:
        from .model_manager import ModelManager
        manager = ModelManager()
        installed = manager.get_installed_models()
        
        models = []
        for model in installed:
            models.append({
                "name": model.get("name", ""),
                "size_gb": model.get("size", 0) / (1024**3),
                "is_installed": True,
                "category": _categorize_model(model.get("name", "")),
                "description": model.get("details", {}).get("family", "")
            })
        return models
    except Exception as e:
        logger.error(f"Failed to list models: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/models/catalog", response_model=ModelCatalog, tags=["Models"])
async def get_model_catalog():
    """Get full model catalog with recommendations."""
    try:
        from .model_manager import ModelManager, HardwareDetector, MODEL_CATALOG
        
        manager = ModelManager()
        detector = HardwareDetector()
        
        installed_list = manager.get_installed_models()
        installed_names = {m.get("name", "").split(":")[0] for m in installed_list if isinstance(m, dict)}
        hardware = detector.get_system_info()
        
        # Helper to convert ModelInfo to OllamaModel
        def to_api_model(info):
            return {
                "name": info.name,
                "size_gb": info.size_gb,
                "is_installed": info.name in installed_names,
                "category": info.category,
                "description": info.description
            }
        
        vision_models = [to_api_model(m) for m in MODEL_CATALOG.get("vision", [])]
        analyzer_models = [to_api_model(m) for m in MODEL_CATALOG.get("analyzer", [])]
        
        # Base models - manually defined for now or add to catalog
        base_models = [
            {"name": "TinyLlama/TinyLlama-1.1B-Chat-v1.0", "size_gb": 2.2, "category": "base",
             "description": "1.1B params, good for low VRAM", "is_installed": False},
            {"name": "microsoft/phi-2", "size_gb": 5.5, "category": "base",
             "description": "2.7B params, excellent reasoning", "is_installed": False},
            {"name": "google/gemma-2-2b", "size_gb": 5.0, "category": "base",
             "description": "2B params, Google's latest", "is_installed": False},
        ]
        
        # Recommendations based on hardware
        vram = hardware.get("vram_gb", 0)
        recommended = {
            "vision": "moondream" if vram < 4 else "qwen2.5vl:3b",
            "analyzer": "phi3:mini" if vram < 6 else "granite3.1-dense:8b",
            "base": "TinyLlama/TinyLlama-1.1B-Chat-v1.0" if vram < 8 else "google/gemma-2-2b"
        }
        
        return {
            "vision_models": vision_models,
            "analyzer_models": analyzer_models,
            "base_models": base_models,
            "recommended": recommended
        }
    except Exception as e:
        logger.error(f"Failed to get catalog: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/models/install", tags=["Models"])
async def install_model(request: InstallModelRequest, background_tasks: BackgroundTasks):
    """Install an Ollama model."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "model_install",
        "status": "pending",
        "progress": 0.0,
        "message": f"Installing {request.model_name}...",
        "created_at": datetime.now().isoformat()
    }
    
    def install_task():
        try:
            from .model_manager import ModelManager
            manager = ModelManager()
            
            jobs[job_id]["status"] = "running"
            success = manager.install_model(request.model_name)
            
            if success:
                jobs[job_id]["status"] = "completed"
                jobs[job_id]["progress"] = 100.0
                jobs[job_id]["message"] = f"Successfully installed {request.model_name}"
            else:
                jobs[job_id]["status"] = "failed"
                jobs[job_id]["error"] = "Installation failed"
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(install_task)
    return {"job_id": job_id, "message": f"Installation started for {request.model_name}"}

@app.delete("/models/{model_name}", tags=["Models"])
async def uninstall_model(model_name: str):
    """Uninstall an Ollama model."""
    try:
        from .model_manager import ModelManager
        manager = ModelManager()
        success = manager.uninstall_model(model_name)
        
        if success:
            return {"message": f"Successfully uninstalled {model_name}"}
        else:
            raise HTTPException(status_code=400, detail="Uninstallation failed")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# Dataset Endpoints
# =============================================================================

@app.get("/datasets", response_model=List[DatasetInfo], tags=["Datasets"])
async def list_datasets():
    """List all available datasets."""
    datasets = []
    datasets_dir = Path("datasets")
    
    if not datasets_dir.exists():
        return []
    
    for file in datasets_dir.glob("*.jsonl"):
        try:
            stat = file.stat()
            # Count lines (samples)
            with open(file, "r", encoding="utf-8") as f:
                samples = sum(1 for _ in f)
            
            datasets.append({
                "name": file.stem,
                "path": str(file),
                "samples": samples,
                "format": "jsonl",
                "created_at": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "size_bytes": stat.st_size
            })
        except Exception as e:
            logger.error(f"Error reading dataset {file}: {e}")
    
    return datasets

@app.post("/datasets/create", tags=["Datasets"])
async def create_dataset(request: CreateDatasetRequest, background_tasks: BackgroundTasks):
    """Create dataset from PDF documents."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "dataset_creation",
        "status": "pending",
        "progress": 0.0,
        "message": "Starting dataset creation...",
        "created_at": datetime.now().isoformat()
    }
    
    def create_task():
        try:
            jobs[job_id]["status"] = "running"
            jobs[job_id]["message"] = "Loading pipeline..."
            
            from .pipeline import load_pipeline
            pipeline = load_pipeline("config.yaml")
            
            input_path = Path(request.input_path)
            
            if input_path.is_file():
                jobs[job_id]["message"] = f"Processing {input_path.name}..."
                result = pipeline.process_file(str(input_path), dataset_name=request.dataset_name)
            else:
                jobs[job_id]["message"] = f"Processing directory {input_path}..."
                result = pipeline.process_directory(str(input_path), dataset_name=request.dataset_name)
            
            if result.success:
                jobs[job_id]["status"] = "completed"
                jobs[job_id]["progress"] = 100.0
                jobs[job_id]["result"] = {
                    "documents_processed": result.documents_processed,
                    "total_samples": result.total_samples,
                    "output_files": result.output_files
                }
            else:
                jobs[job_id]["status"] = "failed"
                jobs[job_id]["error"] = "; ".join(result.errors)
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
            logger.exception("Dataset creation failed")
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(create_task)
    return {"job_id": job_id}

@app.post("/datasets/generate", tags=["Datasets"])
async def generate_dataset(request: GenerateDatasetRequest, background_tasks: BackgroundTasks):
    """Generate dataset using AI (without source documents)."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "dataset_generation",
        "status": "pending",
        "progress": 0.0,
        "message": "Starting AI dataset generation...",
        "created_at": datetime.now().isoformat()
    }
    
    def generate_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .train import AutonomousDatasetGenerator
            from .config_manager import get_teacher_config
            
            teacher_config = get_teacher_config(request.provider, request.teacher_model)
            
            generator = AutonomousDatasetGenerator(
                teacher_config=teacher_config,
                output_dir="datasets"
            )
            
            def progress_callback(current, total, message):
                jobs[job_id]["progress"] = (current / total) * 100
                jobs[job_id]["message"] = message
            
            output_path = generator.generate_dataset(
                domain=request.domain,
                target_samples=request.samples,
                dataset_type=request.dataset_type,
                output_format=request.output_format,
                system_prompt=request.system_prompt,
                progress_callback=progress_callback
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["progress"] = 100.0
            jobs[job_id]["result"] = {"output_path": str(output_path)}
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
            logger.exception("Dataset generation failed")
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(generate_task)
    return {"job_id": job_id}

# =============================================================================
# Training Endpoints
# =============================================================================

@app.post("/training/start", tags=["Training"])
async def start_training(request: TrainingRequest, background_tasks: BackgroundTasks):
    """Start model fine-tuning."""
    job_id = str(uuid.uuid4())
    
    training_jobs[job_id] = {
        "job_id": job_id,
        "status": "pending",
        "epoch": 0,
        "total_epochs": request.epochs,
        "step": 0,
        "total_steps": 0,
        "loss": 0.0,
        "learning_rate": request.learning_rate,
        "created_at": datetime.now().isoformat()
    }
    
    def train_task():
        try:
            training_jobs[job_id]["status"] = "running"
            
            from .train import LLMTrainer
            
            trainer = LLMTrainer(
                model_id=request.base_model,
                config={
                    "training": {
                        "output_name": request.output_name,
                        "epochs": request.epochs,
                        "batch_size": request.batch_size,
                        "learning_rate": request.learning_rate,
                        "quantization": request.quantization,
                        "lora_r": request.lora_r,
                        "lora_alpha": request.lora_alpha
                    }
                }
            )
            
            # Train with progress tracking
            result = trainer.train(request.dataset_path)
            
            training_jobs[job_id]["status"] = "completed"
            training_jobs[job_id]["result"] = {
                "model_path": str(result) if result else None
            }
        except Exception as e:
            training_jobs[job_id]["status"] = "failed"
            training_jobs[job_id]["error"] = str(e)
            logger.exception("Training failed")
        finally:
            training_jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(train_task)
    return {"job_id": job_id}

@app.get("/training/models", response_model=List[TrainedModel], tags=["Training"])
async def list_trained_models():
    """List all trained models."""
    models = []
    models_dir = Path.cwd() / "models"
    
    # Debug logging
    with open("debug_api_models.txt", "a") as log:
        log.write(f"\n[{datetime.now()}] Listing models from {models_dir}, Exists: {models_dir.exists()}\n")

    if not models_dir.exists():
        return []
    
    for model_dir in models_dir.iterdir():
        if model_dir.is_dir():
            try:

                search_paths = [
                    (model_dir / "adapter_config.json", "finetuned", model_dir),
                    (model_dir / "final_adapter" / "adapter_config.json", "finetuned", model_dir / "final_adapter"),
                    (model_dir / "final" / "adapter_config.json", "finetuned", model_dir / "final"),
                    (model_dir / "final" / "config.json", "pretrained", model_dir / "final"),
                    (model_dir / "config.json", "pretrained", model_dir),
                ]

                config_path = None
                model_type = "unknown"
                actual_model_dir = model_dir

                for path, mtype, mdir in search_paths:
                    if path.exists():
                        config_path = path
                        model_type = mtype
                        actual_model_dir = mdir
                        break
                
                if config_path:
                    with open(config_path) as f:
                        config = json.load(f)
                    
                    # Calculate size of the actual model directory (recursively if it's the root, or just that folder)
                    # If it's a subdir, we might want to count the whole model_dir size or just the subdir?
                    # Usually user cares about the whole artifact size.
                    size_mb = sum(f.stat().st_size for f in model_dir.rglob("*") if f.is_file()) / (1024 * 1024)
                    
                    base_model = config.get("base_model_name_or_path", "Unknown")
                    # For pretrained, it might be different
                    if model_type == "pretrained" and base_model == "Unknown":
                         base_model = config.get("_name_or_path", "None")

                    models.append({
                        "name": model_dir.name,
                        "path": str(actual_model_dir),
                        "base_model": base_model,
                        "created_at": datetime.fromtimestamp(model_dir.stat().st_mtime).isoformat(),
                        "size_mb": round(size_mb, 2),
                        "type": model_type
                    })
            except Exception as e:
                logger.error(f"Error reading model {model_dir}: {e}")
    
    return models

@app.get("/training/{job_id}", response_model=TrainingStatus, tags=["Training"])
async def get_training_status(job_id: str):
    """Get training job status."""
    if job_id not in training_jobs:
        raise HTTPException(status_code=404, detail="Training job not found")
    return training_jobs[job_id]

@app.post("/training/{job_id}/stop", tags=["Training"])
async def stop_training(job_id: str):
    """Stop a running training job."""
    if job_id not in training_jobs:
        raise HTTPException(status_code=404, detail="Training job not found")
    
    # Signal to stop (implementation depends on trainer)
    training_jobs[job_id]["status"] = "stopping"
    return {"message": "Stop signal sent"}



# =============================================================================
# Pre-training Endpoints
# =============================================================================

@app.get("/pretrain/architectures", tags=["Pre-training"])
async def get_pretrain_architectures():
    """Get available pre-training architectures."""
    return {
        "architectures": [
            {"name": "nano", "params": "~15M", "vram": "2GB+", "description": "Tiny model for testing"},
            {"name": "micro", "params": "~50M", "vram": "4GB+", "description": "Small model for experimentation"},
            {"name": "mini", "params": "~125M", "vram": "6GB+", "description": "GPT-2 Small equivalent"},
            {"name": "small", "params": "~350M", "vram": "8GB+", "description": "Medium capacity"},
            {"name": "base", "params": "~1B", "vram": "16GB+", "description": "Production-ready size"},
            {"name": "large", "params": "~3B", "vram": "24GB+", "description": "High capacity model"}
        ]
    }

@app.post("/pretrain/start", tags=["Pre-training"])
async def start_pretraining(request: PretrainRequest, background_tasks: BackgroundTasks):
    """Start model pre-training from scratch."""
    job_id = str(uuid.uuid4())
    
    training_jobs[job_id] = {
        "job_id": job_id,
        "job_type": "pretraining",
        "status": "pending",
        "epoch": 0,
        "total_epochs": request.epochs,
        "created_at": datetime.now().isoformat()
    }
    
    def pretrain_task():
        try:
            training_jobs[job_id]["status"] = "running"
            
            from .pretrain import PreTrainer
            
            pretrainer = PreTrainer(
                architecture=request.architecture,
                model_name=request.model_name,
                vocab_size=request.vocab_size
            )
            
            result = pretrainer.train(
                data_path=request.dataset_path,
                epochs=request.epochs,
                batch_size=request.batch_size,
                learning_rate=request.learning_rate
            )
            
            training_jobs[job_id]["status"] = "completed"
            training_jobs[job_id]["result"] = {"model_path": str(result)}
        except Exception as e:
            training_jobs[job_id]["status"] = "failed"
            training_jobs[job_id]["error"] = str(e)
            logger.exception("Pre-training failed")
        finally:
            training_jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(pretrain_task)
    return {"job_id": job_id}

# =============================================================================
# Evaluation Endpoints
# =============================================================================

@app.post("/evaluate/start", tags=["Evaluation"])
async def start_evaluation(request: EvaluateRequest, background_tasks: BackgroundTasks):
    """Start model evaluation."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "evaluation",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def eval_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .evaluator import ModelEvaluator
            
            evaluator = ModelEvaluator(
                base_model_id=request.base_model_id,
                adapter_path=request.adapter_path
            )
            
            results = evaluator.run_evaluation(num_samples=request.num_samples)
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = results
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(eval_task)
    return {"job_id": job_id}

@app.post("/evaluate/autonomous", tags=["Evaluation"])
async def start_autonomous_learning(request: AutonomousLearningRequest, background_tasks: BackgroundTasks):
    """Start autonomous learning with teacher model."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "autonomous_learning",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def autonomous_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .evaluator import ModelEvaluator
            from .config_manager import get_teacher_config
            
            teacher_config = get_teacher_config(request.teacher_provider)
            teacher_config["model"] = request.teacher_model
            
            evaluator = ModelEvaluator(
                base_model_id=request.base_model_id,
                adapter_path=request.adapter_path
            )
            
            results = evaluator.run_autonomous_learning(
                topic=request.topic,
                iterations=request.iterations,
                teacher_config=teacher_config
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = results
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(autonomous_task)
    return {"job_id": job_id}

# =============================================================================
# Deployment Endpoints
# =============================================================================

@app.post("/deploy/ollama", tags=["Deployment"])
async def deploy_to_ollama(request: DeployOllamaRequest, background_tasks: BackgroundTasks):
    """Export model to Ollama (GGUF format)."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "deploy_ollama",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def deploy_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .deployer import ModelDeployer
            deployer = ModelDeployer()
            
            result = deployer.export_to_ollama(
                request.base_model_id,
                request.adapter_path
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = {"model_name": request.model_name}
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(deploy_task)
    return {"job_id": job_id}

@app.post("/deploy/huggingface", tags=["Deployment"])
async def deploy_to_huggingface(request: DeployHuggingFaceRequest, background_tasks: BackgroundTasks):
    """Push model to HuggingFace Hub."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "deploy_huggingface",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def deploy_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .deployer import ModelDeployer
            deployer = ModelDeployer()
            
            result = deployer.push_to_huggingface(
                request.base_model_id,
                request.adapter_path
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = {"repo_name": request.repo_name}
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(deploy_task)
    return {"job_id": job_id}

# =============================================================================
# Chat / Model Testing Endpoints
# =============================================================================

@app.post("/chat", response_model=ChatResponse, tags=["Chat"])
async def chat_with_model(request: ChatRequest):
    """Chat with a model (Ollama or fine-tuned)."""
    import time
    start_time = time.time()
    
    try:
        if request.model_type == "ollama":
            # Chat with Ollama model
            import requests
            
            messages = []
            if request.system_prompt:
                messages.append({"role": "system", "content": request.system_prompt})
            
            # Add history
            for msg in request.history:
                messages.append(msg)
            
            # Add current message
            messages.append({"role": "user", "content": request.message})
            
            response = requests.post(
                "http://localhost:11434/api/chat",
                json={
                    "model": request.model_name,
                    "messages": messages,
                    "stream": False,
                    "options": {
                        "temperature": request.temperature,
                        "num_predict": request.max_tokens
                    }
                },
                timeout=120
            )
            
            if response.status_code == 200:
                data = response.json()
                latency = (time.time() - start_time) * 1000
                return ChatResponse(
                    response=data.get("message", {}).get("content", ""),
                    model=request.model_name,
                    latency_ms=latency,
                    tokens_generated=data.get("eval_count", 0)
                )
            else:
                raise HTTPException(status_code=response.status_code, detail="Ollama request failed")
                
        elif request.model_type == "trained":
            # Chat with fine-tuned model
            if not request.base_model:
                raise HTTPException(status_code=400, detail="base_model required for trained models")
            
            from .deployer import ModelDeployer
            deployer = ModelDeployer()
            
            # Build prompt from history
            full_prompt = ""
            if request.system_prompt:
                full_prompt = f"System: {request.system_prompt}\n\n"
            
            for msg in request.history:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                full_prompt += f"{role.capitalize()}: {content}\n"
            
            full_prompt += f"User: {request.message}\nAssistant:"
            
            response_text = deployer.generate(
                base_model_id=request.base_model,
                adapter_path=request.model_name,
                prompt=full_prompt,
                max_tokens=request.max_tokens,
                temperature=request.temperature
            )
            
            latency = (time.time() - start_time) * 1000
            return ChatResponse(
                response=response_text,
                model=f"{request.base_model}+{request.model_name}",
                latency_ms=latency
            )
        elif request.model_type == "pretrained":
            # Chat with pretrained model (no adapter)
            from .deployer import ModelDeployer
            deployer = ModelDeployer()
            
            # Build prompt from history
            full_prompt = ""
            if request.system_prompt:
                full_prompt = f"System: {request.system_prompt}\n\n"
            
            for msg in request.history:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                full_prompt += f"{role.capitalize()}: {content}\n"
            
            full_prompt += f"User: {request.message}\nAssistant:"
            
            response_text = deployer.generate(
                base_model_id=request.model_name,  # model_name is the path for pretrained
                adapter_path=None,
                prompt=full_prompt,
                max_tokens=request.max_tokens,
                temperature=request.temperature
            )
            
            latency = (time.time() - start_time) * 1000
            return ChatResponse(
                response=response_text,
                model=request.model_name,
                latency_ms=latency
            )
        else:
            raise HTTPException(status_code=400, detail=f"Unknown model_type: {request.model_type}")
            
    except Exception as e:
        logger.exception("Chat failed")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/chat/models", tags=["Chat"])
async def get_chat_models():
    """Get available models for chat (both Ollama and trained)."""
    models = []
    
    # Get Ollama models
    try:
        import requests
        response = requests.get("http://localhost:11434/api/tags", timeout=5)
        if response.status_code == 200:
            data = response.json()
            for model in data.get("models", []):
                models.append({
                    "name": model.get("name"),
                    "type": "ollama",
                    "size_gb": model.get("size", 0) / (1024**3),
                    "ready": True
                })
    except:
        pass
    
    # Get trained models
    try:
        models_dir = Path.cwd() / "models"
        if models_dir.exists():
            for model_dir in models_dir.iterdir():
                if model_dir.is_dir():
                    adapter_path = model_dir / "final_adapter"
                    final_path = model_dir / "final"
                    
                    # Check for fine-tuned model (with adapter)
                    if adapter_path.exists():
                        config_path = adapter_path / "adapter_config.json"
                        base_model = "unknown"
                        if config_path.exists():
                            import json
                            with open(config_path) as f:
                                config = json.load(f)
                                base_model = config.get("base_model_name_or_path", "unknown")
                        
                        models.append({
                            "name": model_dir.name,
                            "type": "trained",
                            "path": str(adapter_path),
                            "base_model": base_model,
                            "ready": True
                        })
                    # Check for pretrained model (no adapter, just the model)
                    elif final_path.exists():
                        config_path = final_path / "config.json"
                        if config_path.exists():
                            models.append({
                                "name": model_dir.name,
                                "type": "pretrained",
                                "path": str(final_path),
                                "base_model": None,
                                "ready": True
                            })
    except Exception as e:
        logger.error(f"Error listing trained models: {e}")
    
    return {"models": models}

# =============================================================================
# HuggingFace Hub Endpoints
# =============================================================================

@app.get("/hub/status", response_model=HubStatus, tags=["HuggingFace Hub"])
async def get_hub_status():
    """Get HuggingFace Hub login status."""
    try:
        from huggingface_hub import HfApi
        api = HfApi()
        user_info = api.whoami()
        return HubStatus(
            logged_in=True,
            username=user_info.get("name"),
            repos_count=len(api.list_models(author=user_info.get("name")))
        )
    except:
        return HubStatus(logged_in=False)

@app.post("/hub/push-model", tags=["HuggingFace Hub"])
async def hub_push_model(request: HubPushModelRequest, background_tasks: BackgroundTasks):
    """Push a model to HuggingFace Hub."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "hub_push_model",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def push_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .model_hub import ModelHub
            hub = ModelHub()
            
            result = hub.push_model(
                model_path=request.model_path,
                repo_name=request.repo_name,
                domain=request.domain,
                private=request.private
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = {"url": result}
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(push_task)
    return {"job_id": job_id}

@app.post("/hub/push-dataset", tags=["HuggingFace Hub"])
async def hub_push_dataset(request: HubPushDatasetRequest, background_tasks: BackgroundTasks):
    """Push a dataset to HuggingFace Hub."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "hub_push_dataset",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def push_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .model_hub import ModelHub
            hub = ModelHub()
            
            result = hub.push_dataset(
                dataset_path=request.dataset_path,
                repo_name=request.repo_name,
                domain=request.domain,
                private=request.private
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = {"url": result}
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(push_task)
    return {"job_id": job_id}

# =============================================================================
# Tokenizer Endpoints
# =============================================================================

@app.post("/tokenizer/train", tags=["Tokenizer"])
async def train_tokenizer(request: TrainTokenizerRequest, background_tasks: BackgroundTasks):
    """Train a custom tokenizer with optional AI enhancement."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "train_tokenizer",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def train_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .ai_tokenizer import AIEnhancedTokenizer
            
            tokenizer = AIEnhancedTokenizer(
                vocab_size=request.vocab_size,
                output_dir=f"tokenizers/{request.output_name}"
            )
            
            result = tokenizer.train(
                data_path=request.data_path,
                domain=request.domain,
                use_ai=request.use_ai
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = {"path": str(result)}
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(train_task)
    return {"job_id": job_id}

@app.get("/tokenizer/list", tags=["Tokenizer"])
async def list_tokenizers():
    """List available tokenizers."""
    tokenizers = []
    
    tokenizers_dir = Path.cwd() / "tokenizers"
    if tokenizers_dir.exists():
        for tok_dir in tokenizers_dir.iterdir():
            if tok_dir.is_dir() and (tok_dir / "tokenizer.json").exists():
                tokenizers.append({
                    "name": tok_dir.name,
                    "path": str(tok_dir),
                    "vocab_size": None  # Could parse from config
                })
    
    return {"tokenizers": tokenizers}

# =============================================================================
# Authentication Endpoints
# =============================================================================

@app.get("/auth/status", response_model=AuthStatus, tags=["Authentication"])
async def get_auth_status():
    """Get current authentication status."""
    try:
        from .config_manager import get_hub_user, is_hub_logged_in
        
        if is_hub_logged_in():
            user = get_hub_user()
            return {
                "logged_in": True,
                "user_id": user.user_id,
                "email": user.email,
                "name": user.name,
                "plan": user.plan
            }
        else:
            return {"logged_in": False, "plan": "free"}
    except Exception as e:
        logger.error(f"Auth status check failed: {e}")
        return {"logged_in": False, "plan": "free"}

@app.post("/auth/login", tags=["Authentication"])
async def login(request: LoginRequest):
    """Save login session (after browser auth)."""
    try:
        from .auth import login as auth_login
        auth_login(email=request.email, name=request.name)
        return {"message": "Login successful", "email": request.email}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/auth/logout", tags=["Authentication"])
async def logout():
    """Logout from SAARA Hub."""
    try:
        from .config_manager import hub_logout
        hub_logout()
        return {"message": "Logged out successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# =============================================================================
# API Keys Endpoints
# =============================================================================

@app.get("/keys/status", response_model=List[APIKeyStatus], tags=["API Keys"])
async def get_api_keys_status():
    """Get status of configured API keys."""
    try:
        from .config_manager import get_configured_providers
        providers = get_configured_providers()
        
        return [
            {
                "provider": name,
                "configured": info["configured"],
                "masked_key": f"***{info['key'][-4:]}" if info.get("key") else None
            }
            for name, info in providers.items()
        ]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/keys/set", tags=["API Keys"])
async def set_api_key(request: SetAPIKeyRequest):
    """Set API key for a provider."""
    try:
        from .config_manager import set_api_key
        set_api_key(request.provider, request.key)
        return {"message": f"API key set for {request.provider}"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/keys/clear", tags=["API Keys"])
async def clear_api_keys():
    """Clear all API keys."""
    try:
        from .config_manager import save_api_keys, APIKeyConfig
        save_api_keys(APIKeyConfig())
        return {"message": "All API keys cleared"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# Google Drive Endpoints
# =============================================================================

@app.get("/drive/status", response_model=DriveStatus, tags=["Cloud Storage"])
async def get_drive_status():
    """Get Google Drive connection status."""
    try:
        from .cloud_storage import GoogleDriveManager
        manager = GoogleDriveManager()
        
        if manager.is_connected():
            info = manager.get_account_info()
            return {
                "connected": True,
                "account_email": info.get("email"),
                "storage_used": info.get("storage_used"),
                "last_sync": info.get("last_sync")
            }
        else:
            return {"connected": False}
    except Exception as e:
        logger.error(f"Drive status check failed: {e}")
        return {"connected": False}

@app.post("/drive/connect", tags=["Cloud Storage"])
def connect_drive():
    """Connect to Google Drive (opens browser)."""
    try:
        from .cloud_storage import GoogleDriveManager
        manager = GoogleDriveManager()
        if manager.connect():
            return {"status": "connected", "message": "Successfully connected to Google Drive"}
        else:
            raise HTTPException(status_code=400, detail="Authentication failed or cancelled")
    except Exception as e:
        logger.error(f"Drive connection failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/drive/disconnect", tags=["Cloud Storage"])
def disconnect_drive():
    """Disconnect from Google Drive."""
    try:
        from .cloud_storage import GoogleDriveManager
        manager = GoogleDriveManager()
        if manager.disconnect():
            return {"status": "disconnected", "message": "Disconnected from Google Drive"}
        return {"status": "error", "message": "Failed to disconnect"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/drive/sync", tags=["Cloud Storage"])
async def sync_drive(request: DriveSyncRequest, background_tasks: BackgroundTasks):
    """Sync files with Google Drive."""
    job_id = str(uuid.uuid4())
    
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "drive_sync",
        "status": "pending",
        "created_at": datetime.now().isoformat()
    }
    
    def sync_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .cloud_storage import GoogleDriveManager
            manager = GoogleDriveManager()
            
            result = manager.sync(
                target=request.target,
                direction=request.direction
            )
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = result
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(sync_task)
    return {"job_id": job_id}

# =============================================================================
# Job Status Endpoints
# =============================================================================

@app.get("/jobs/{job_id}", response_model=JobStatus, tags=["Jobs"])
async def get_job_status(job_id: str):
    """Get status of any job."""
    if job_id in jobs:
        return jobs[job_id]
    elif job_id in training_jobs:
        return training_jobs[job_id]
    else:
        raise HTTPException(status_code=404, detail="Job not found")

@app.get("/jobs", tags=["Jobs"])
async def list_all_jobs(
    job_type: Optional[str] = Query(None, description="Filter by job type"),
    status: Optional[str] = Query(None, description="Filter by status")
):
    """List all jobs with optional filtering."""
    all_jobs = list(jobs.values()) + list(training_jobs.values())
    
    if job_type:
        all_jobs = [j for j in all_jobs if j.get("job_type") == job_type]
    if status:
        all_jobs = [j for j in all_jobs if j.get("status") == status]
    
    return all_jobs

# =============================================================================
# WebSocket Endpoint for Real-time Updates
# =============================================================================

@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    """WebSocket endpoint for real-time progress updates."""
    await ws_manager.connect(client_id, websocket)
    try:
        while True:
            # Keep connection alive and receive any control messages
            data = await websocket.receive_text()
            
            # Handle subscription requests
            if data.startswith("subscribe:"):
                job_id = data.split(":")[1]
                # Send current status immediately
                if job_id in jobs:
                    await websocket.send_json(jobs[job_id])
                elif job_id in training_jobs:
                    await websocket.send_json(training_jobs[job_id])
    except WebSocketDisconnect:
        ws_manager.disconnect(client_id)

# =============================================================================
# Swarm Endpoints
# =============================================================================

class SwarmHostRequest(BaseModel):
    port: int = 23456
    model_name: str = "saara-swarm-model"
    max_nodes: int = 5

class SwarmJoinRequest(BaseModel):
    join_code: str

class SwarmPeerInfo(BaseModel):
    peer_id: str
    hostname: str
    ip_address: str
    gpu_name: str
    vram_gb: float
    status: str
    is_self: bool = False
    steps_completed: int = 0
    current_loss: float = 0.0
    throughput: float = 0.0

class SwarmStatusResponse(BaseModel):
    active: bool
    role: str = "none"  # host, worker, none
    swarm_id: Optional[str] = None
    peer_id: Optional[str] = None
    join_code: Optional[str] = None
    peers_count: int = 0
    total_vram: float = 0.0

# Global Swarm Instance
swarm_instance = None

@app.get("/swarm/status", response_model=SwarmStatusResponse, tags=["Swarm"])
async def get_swarm_status():
    """Get current swarm status."""
    global swarm_instance
    if not swarm_instance or not swarm_instance._running:
        return {
            "active": False,
            "peers_count": 0,
            "total_vram": 0.0
        }
    
    state = swarm_instance.state
    return {
        "active": True,
        "role": "host" if state.is_host else "worker",
        "swarm_id": state.swarm_id,
        "peer_id": swarm_instance.identity.peer_id,
        "join_code": f"{state.host_ip}:{state.host_port}" if state.is_host else None,
        "peers_count": len(state.peers),
        "total_vram": state.total_vram_gb
    }

@app.post("/swarm/host", tags=["Swarm"])
async def start_swarm_host(request: SwarmHostRequest, background_tasks: BackgroundTasks):
    """Start hosting a new swarm."""
    global swarm_instance
    
    # Lazy load to avoid circular deps
    from .swarm import SaaraSwarm
    
    if swarm_instance and swarm_instance._running:
        raise HTTPException(status_code=400, detail="Swarm already running")
    
    try:
        swarm_instance = SaaraSwarm()
        success = swarm_instance.host(
            port=request.port,
            max_nodes=request.max_nodes,
            model_name=request.model_name
        )
        
        if not success:
             raise HTTPException(status_code=500, detail="Failed to start swarm host")
             
        return {"message": "Swarm host started", "join_code": f"{swarm_instance._get_local_ip()}:{request.port}"}
    except Exception as e:
        logger.error(f"Swarm host error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/swarm/join", tags=["Swarm"])
async def join_swarm(request: SwarmJoinRequest, background_tasks: BackgroundTasks):
    """Join an existing swarm."""
    global swarm_instance
    from .swarm import SaaraSwarm
    
    if swarm_instance and swarm_instance._running:
        raise HTTPException(status_code=400, detail="Already in a swarm")
        
    try:
        swarm_instance = SaaraSwarm()
        success = swarm_instance.join(request.join_code)
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to join swarm")
            
        return {"message": "Successfully joined swarm"}
    except Exception as e:
        logger.error(f"Swarm join error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/swarm/leave", tags=["Swarm"])
async def leave_swarm():
    """Leave the current swarm."""
    global swarm_instance
    if swarm_instance:
        swarm_instance._running = False
        swarm_instance = None
    return {"message": "Left swarm"}

@app.get("/swarm/peers", response_model=List[SwarmPeerInfo], tags=["Swarm"])
async def list_swarm_peers():
    """List connected peers."""
    global swarm_instance
    if not swarm_instance or not swarm_instance.state:
        return []
        
    peers = []
    my_id = swarm_instance.identity.peer_id
    
    for p in swarm_instance.state.peers.values():
        peers.append({
            "peer_id": p.peer_id,
            "hostname": p.hostname,
            "ip_address": p.ip_address,
            "gpu_name": p.gpu_name,
            "vram_gb": p.vram_gb,
            "status": p.status,
            "is_self": p.peer_id == my_id,
            "steps_completed": p.steps_completed,
            "current_loss": p.current_loss,
            "throughput": p.throughput
        })
    return peers

@app.post("/upload", tags=["Datasets"])
async def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    dataset_name: Optional[str] = None
):
    """Upload a PDF document for processing."""
    if not file.filename.lower().endswith('.pdf'):
        raise HTTPException(status_code=400, detail="Only PDF files are supported")
    
    job_id = str(uuid.uuid4())
    
    # Save uploaded file
    upload_dir = Path("uploads")
    upload_dir.mkdir(exist_ok=True)
    
    file_path = upload_dir / f"{job_id}_{file.filename}"
    
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {e}")
    
    if not dataset_name:
        dataset_name = Path(file.filename).stem
    
    # Create job and process
    jobs[job_id] = {
        "job_id": job_id,
        "job_type": "processing",
        "status": "pending",
        "progress": 0.0,
        "message": "File uploaded, processing...",
        "filename": file.filename,
        "dataset_name": dataset_name,
        "created_at": datetime.now().isoformat()
    }
    
    def process_task():
        try:
            jobs[job_id]["status"] = "running"
            
            from .pipeline import load_pipeline
            pipeline = load_pipeline("config.yaml")
            
            result = pipeline.process_file(str(file_path), dataset_name=dataset_name)
            
            if result.success:
                jobs[job_id]["status"] = "completed"
                jobs[job_id]["progress"] = 100.0
                jobs[job_id]["result"] = {
                    "documents_processed": result.documents_processed,
                    "total_samples": result.total_samples,
                    "output_files": result.output_files
                }
            else:
                jobs[job_id]["status"] = "failed"
                jobs[job_id]["error"] = "; ".join(result.errors)
        except Exception as e:
            jobs[job_id]["status"] = "failed"
            jobs[job_id]["error"] = str(e)
        finally:
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
    
    background_tasks.add_task(process_task)
    return jobs[job_id]

# --- RAG ---
class RagKbConfig(BaseModel):
    name: str
    description: str = ""
    chunk_size: int = 512
    chunk_overlap: int = 50
    embedding_model: str = "all-MiniLM-L6-v2"
    llm_model: str = "granite4:latest"

class RagQueryRequest(BaseModel):
    query: str
    top_k: int = 5
    stream: bool = False

class RagAddDocRequest(BaseModel):
    path: str

class RagResponse(BaseModel):
    answer: str
    sources: List[Dict[str, Any]]
    latency_ms: float

# Global Manager
rag_manager = None

@app.on_event("startup")
async def init_rag():
    global rag_manager
    from .rag_engine import RAGManager
    rag_manager = RAGManager()

@app.get("/rag/kbs", tags=["RAG"])
async def list_kbs():
    if not rag_manager: return []
    return rag_manager.list()

@app.post("/rag/kbs", tags=["RAG"])
async def create_kb(config: RagKbConfig):
    try:
        rag_manager.create(
            name=config.name,
            description=config.description,
            chunk_size=config.chunk_size,
            chunk_overlap=config.chunk_overlap,
            embedding_model=config.embedding_model,
            llm_model=config.llm_model
        )
        return {"status": "created", "name": config.name}
    except Exception as e:
        logger.exception("Failed to create KB")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/rag/kbs/{name}", tags=["RAG"])
async def delete_kb(name: str):
    try:
        rag_manager.delete(name)
        return {"status": "deleted"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/rag/kbs/{name}/documents", tags=["RAG"])
async def add_document(name: str, request: RagAddDocRequest, background_tasks: BackgroundTasks):
    """Add existing file path to KB"""
    try:
        engine = rag_manager.get(name)
        if not engine:
            raise HTTPException(status_code=404, detail="KB not found")
            
        def task():
            try:
                engine.add(request.path)
            except Exception as e:
                logger.error(f"Failed to add document: {e}")
            
        background_tasks.add_task(task)
        return {"status": "processing", "message": "Document addition started in background"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/rag/kbs/{name}/upload", tags=["RAG"])
async def upload_document_to_kb(name: str, background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    """Upload and add file to KB"""
    try:
        engine = rag_manager.get(name)
        if not engine:
            raise HTTPException(status_code=404, detail="KB not found")
            
        # Save temp
        temp_dir = Path("uploads") / name
        temp_dir.mkdir(parents=True, exist_ok=True)
        file_path = temp_dir / file.filename
        
        with open(file_path, "wb") as f:
            shutil.copyfileobj(file.file, f)
            
        def task():
            try:
                engine.add(str(file_path))
            except Exception as e:
                logger.error(f"Failed to add document: {e}")
            
        background_tasks.add_task(task)
        return {"status": "processing", "message": "File uploaded and processing started"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/rag/kbs/{name}/chat", tags=["RAG"])
async def chat_kb(name: str, request: RagQueryRequest):
    try:
        engine = rag_manager.get(name)
        if not engine:
            raise HTTPException(status_code=404, detail="KB not found")
            
        response = engine.query(request.query, top_k=request.top_k)
        
        # Convert sources object to dict safest way
        sources = []
        for s in response.sources:
            if hasattr(s, "chunk"):
                sources.append({
                    "content": s.chunk.content if s.chunk else "",
                    "score": s.score,
                    "metadata": s.doc_metadata
                })
        
        return {
            "answer": response.answer,
            "sources": sources,
            "latency_ms": response.latency_ms
        }
    except Exception as e:
        logger.exception("RAG Chat failed")
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# Helper Functions
# =============================================================================

def _categorize_model(model_name: str) -> str:
    """Categorize an Ollama model."""
    vision_keywords = ["moondream", "llava", "qwen2.5vl", "bakllava", "vision"]
    
    name_lower = model_name.lower()
    for keyword in vision_keywords:
        if keyword in name_lower:
            return "vision"
    
    return "analyzer"

# =============================================================================
# Startup Event
# =============================================================================

@app.on_event("startup")
async def startup_event():
    """Initialize on startup."""
    logger.info("🚀 SAARA API Server starting...")
    
    # Ensure directories exist
    Path("uploads").mkdir(exist_ok=True)
    Path("datasets").mkdir(exist_ok=True)
    Path("models").mkdir(exist_ok=True)
    Path("exports").mkdir(exist_ok=True)
    
    logger.info("✅ SAARA API Server ready!")
    logger.info("📚 API docs available at /docs")
