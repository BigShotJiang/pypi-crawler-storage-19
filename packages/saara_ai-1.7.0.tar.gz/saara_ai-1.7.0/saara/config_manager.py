"""
Configuration Manager for SAARA

Handles API key storage, retrieval, and management.
Stores keys securely in user's home directory.

© 2024-2026 Kilani Sai Nikhil. All Rights Reserved.
"""

import os
import json
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, field, asdict
import logging

logger = logging.getLogger(__name__)

# Config file location
CONFIG_DIR = Path.home() / ".saara"
CONFIG_FILE = CONFIG_DIR / "config.json"
KEYS_FILE = CONFIG_DIR / "api_keys.json"


@dataclass
class APIKeyConfig:
    """Configuration for API keys."""
    google_ai: str = ""
    openai: str = ""
    sarvam_ai: str = ""
    deepseek: str = ""
    groq: str = ""
    huggingface: str = ""
    anthropic: str = ""
    
    def to_dict(self) -> Dict[str, str]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> "APIKeyConfig":
        return cls(
            google_ai=data.get("google_ai", ""),
            openai=data.get("openai", ""),
            sarvam_ai=data.get("sarvam_ai", ""),
            deepseek=data.get("deepseek", ""),
            groq=data.get("groq", ""),
            huggingface=data.get("huggingface", ""),
            anthropic=data.get("anthropic", "")
        )


# API Provider Information
API_PROVIDERS = {
    "google_ai": {
        "name": "Google AI (Gemini)",
        "env_var": "GOOGLE_API_KEY",
        "url": "https://aistudio.google.com/apikey",
        "description": "Gemini models - Free tier available, excellent for most tasks",
        "recommended": True
    },
    "openai": {
        "name": "OpenAI",
        "env_var": "OPENAI_API_KEY",
        "url": "https://platform.openai.com/api-keys",
        "description": "GPT-4, GPT-4o - Industry standard, paid only",
        "recommended": False
    },
    "sarvam_ai": {
        "name": "Sarvam AI",
        "env_var": "SARVAM_API_KEY",
        "url": "https://www.sarvam.ai",
        "description": "Best for Sanskrit & Indian languages",
        "recommended": True
    },
    "deepseek": {
        "name": "DeepSeek",
        "env_var": "DEEPSEEK_API_KEY",
        "url": "https://platform.deepseek.com/api_keys",
        "description": "Very affordable, good quality reasoning",
        "recommended": False
    },
    "groq": {
        "name": "Groq",
        "env_var": "GROQ_API_KEY",
        "url": "https://console.groq.com/keys",
        "description": "Ultra-fast inference, free tier available",
        "recommended": True
    },
    "huggingface": {
        "name": "HuggingFace",
        "env_var": "HF_TOKEN",
        "url": "https://huggingface.co/settings/tokens",
        "description": "Access gated models (Llama 3, Gemma, etc.)",
        "recommended": True
    },
    "anthropic": {
        "name": "Anthropic (Claude)",
        "env_var": "ANTHROPIC_API_KEY",
        "url": "https://console.anthropic.com/settings/keys",
        "description": "Claude models - Excellent reasoning",
        "recommended": False
    }
}


def ensure_config_dir() -> Path:
    """Ensure the config directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def save_api_keys(keys: APIKeyConfig) -> bool:
    """Save API keys to config file."""
    try:
        ensure_config_dir()
        with open(KEYS_FILE, 'w') as f:
            json.dump(keys.to_dict(), f, indent=2)
        # Set restrictive permissions on Unix-like systems
        try:
            os.chmod(KEYS_FILE, 0o600)
        except:
            pass
        return True
    except Exception as e:
        logger.error(f"Failed to save API keys: {e}")
        return False


def load_api_keys() -> APIKeyConfig:
    """Load API keys from config file."""
    try:
        if KEYS_FILE.exists():
            with open(KEYS_FILE, 'r') as f:
                data = json.load(f)
            return APIKeyConfig.from_dict(data)
    except Exception as e:
        logger.error(f"Failed to load API keys: {e}")
    return APIKeyConfig()


def get_api_key(provider: str) -> Optional[str]:
    """
    Get API key for a provider.
    Checks environment variables first, then saved config.
    """
    # Check environment variable first
    if provider in API_PROVIDERS:
        env_var = API_PROVIDERS[provider]["env_var"]
        env_value = os.environ.get(env_var)
        if env_value:
            return env_value
    
    # Check saved config
    keys = load_api_keys()
    saved_key = getattr(keys, provider, None)
    if saved_key:
        return saved_key
    
    return None


def set_api_key(provider: str, key: str) -> bool:
    """Set API key for a provider."""
    keys = load_api_keys()
    if hasattr(keys, provider):
        setattr(keys, provider, key)
        return save_api_keys(keys)
    return False


def get_configured_providers() -> Dict[str, bool]:
    """Get status of all API providers (configured or not)."""
    result = {}
    keys = load_api_keys()
    
    for provider in API_PROVIDERS:
        # Check environment variable
        env_var = API_PROVIDERS[provider]["env_var"]
        has_env = bool(os.environ.get(env_var))
        
        # Check saved config
        has_saved = bool(getattr(keys, provider, ""))
        
        result[provider] = has_env or has_saved
    
    return result


def apply_api_keys_to_env() -> None:
    """Load saved API keys into environment variables."""
    keys = load_api_keys()
    
    for provider, info in API_PROVIDERS.items():
        saved_key = getattr(keys, provider, "")
        if saved_key and not os.environ.get(info["env_var"]):
            os.environ[info["env_var"]] = saved_key


def get_teacher_config(provider: str, model_name: Optional[str] = None) -> Optional[Dict[str, Any]]:
    """Get teacher config for autonomous fine-tuning."""
    api_key = get_api_key(provider)
    if not api_key and provider != "ollama": # Ollama doesn't need a key usually
        return None
    
    configs = {
        "google_ai": {
            "provider": "google",
            "api_key": api_key,
            "model": "gemini-2.0-flash-exp"
        },
        "google": { # Alias
            "provider": "google",
            "api_key": api_key,
            "model": "gemini-2.0-flash-exp"
        },
        "openai": {
            "provider": "openai",
            "api_key": api_key,
            "model": "gpt-4o"
        },
        "sarvam_ai": {
            "provider": "sarvam",
            "api_key": api_key,
            "model": "sarvam-1"
        },
        "deepseek": {
            "provider": "deepseek",
            "api_key": api_key,
            "model": "deepseek-chat"
        },
        "groq": {
            "provider": "groq",
            "api_key": api_key,
            "model": "llama-3.3-70b-versatile"
        },
        "anthropic": {
            "provider": "anthropic",
            "api_key": api_key,
            "model": "claude-3-5-sonnet-latest"
        },
        "ollama": {
            "provider": "ollama",
            "base_url": "http://localhost:11434/v1",
            "api_key": "ollama",
            "model": "llama3.2:3b" # Default
        }
    }
    
    config = configs.get(provider) or configs.get(provider.lower())
    
    if config and model_name:
        config["model"] = model_name
        
    return config


def display_api_status(console=None) -> None:
    """Display API key configuration status."""
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.table import Table
    from rich.panel import Panel
    
    status = get_configured_providers()
    
    table = Table(title="🔑 API Key Status", show_header=True, header_style="bold cyan")
    table.add_column("#", style="dim", width=3)
    table.add_column("Provider", style="green")
    table.add_column("Status", width=15)
    table.add_column("Description", style="dim")
    
    for i, (provider, info) in enumerate(API_PROVIDERS.items(), 1):
        is_configured = status.get(provider, False)
        
        if is_configured:
            status_str = "[bold green]✓ Configured[/bold green]"
        else:
            status_str = "[dim]○ Not set[/dim]"
        
        name = info["name"]
        if info.get("recommended"):
            name = f"⭐ {name}"
        
        table.add_row(str(i), name, status_str, info["description"])
    
    console.print(table)


def run_api_setup_wizard(console=None) -> APIKeyConfig:
    """Interactive wizard to configure API keys."""
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich.table import Table
    
    console.print(Panel.fit(
        "[bold cyan]🔑 API Key Configuration[/bold cyan]\n\n"
        "Configure API keys for cloud AI services.\n"
        "[dim]Keys are stored securely in your home directory.[/dim]",
        title="Step: API Keys",
        border_style="cyan"
    ))
    
    # Load existing keys
    keys = load_api_keys()
    status = get_configured_providers()
    
    # Display current status
    display_api_status(console)
    
    console.print("\n[bold]Options:[/bold]")
    console.print("  • Enter a number (1-7) to configure that provider")
    console.print("  • Enter [cyan]all[/cyan] to configure all providers")
    console.print("  • Enter [cyan]skip[/cyan] to skip this step")
    console.print()
    
    choice = Prompt.ask(
        "What would you like to configure?",
        default="skip"
    ).lower().strip()
    
    if choice == "skip":
        console.print("[dim]Skipping API key configuration.[/dim]")
        return keys
    
    providers_to_configure = []
    
    if choice == "all":
        providers_to_configure = list(API_PROVIDERS.keys())
    elif choice.isdigit():
        idx = int(choice) - 1
        provider_list = list(API_PROVIDERS.keys())
        if 0 <= idx < len(provider_list):
            providers_to_configure = [provider_list[idx]]
        else:
            console.print("[yellow]Invalid selection.[/yellow]")
            return keys
    else:
        # Try to match by name
        for provider, info in API_PROVIDERS.items():
            if choice in provider.lower() or choice in info["name"].lower():
                providers_to_configure.append(provider)
                break
    
    if not providers_to_configure:
        console.print("[yellow]No providers selected.[/yellow]")
        return keys
    
    # Configure each selected provider
    for provider in providers_to_configure:
        info = API_PROVIDERS[provider]
        current_key = getattr(keys, provider, "")
        
        console.print(f"\n[bold]Configuring {info['name']}[/bold]")
        console.print(f"[dim]Get your API key from: [cyan]{info['url']}[/cyan][/dim]")
        
        if current_key:
            masked = current_key[:8] + "..." + current_key[-4:] if len(current_key) > 12 else "***"
            console.print(f"[dim]Current key: {masked}[/dim]")
            if not Confirm.ask("Update this key?", default=False):
                continue
        
        new_key = Prompt.ask(
            f"Enter {info['name']} API key",
            password=True,
            default=""
        )
        
        if new_key.strip():
            setattr(keys, provider, new_key.strip())
            console.print(f"[green]✓ {info['name']} key saved![/green]")
            
            # Also set in environment for immediate use
            os.environ[info["env_var"]] = new_key.strip()
        else:
            console.print(f"[dim]Skipped {info['name']}.[/dim]")
    
    # Save all keys
    if save_api_keys(keys):
        console.print(f"\n[green]✓ API keys saved to: {KEYS_FILE}[/green]")
    else:
        console.print(f"\n[red]Failed to save API keys.[/red]")
    
    return keys


# =============================================================================
# SAARA Hub Authentication
# =============================================================================

SAARA_HUB_URL = "https://saara.onslate.in"
SAARA_HUB_API = "https://saara.onslate.in/api"
AUTH_FILE = CONFIG_DIR / "auth.json"


@dataclass
class SARAHubUser:
    """SAARA Hub user information."""
    user_id: str = ""
    email: str = ""
    name: str = ""
    access_token: str = ""
    refresh_token: str = ""
    expires_at: str = ""
    plan: str = "free"  # free, pro, enterprise
    
    def to_dict(self) -> Dict[str, str]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, str]) -> "SARAHubUser":
        return cls(
            user_id=data.get("user_id", ""),
            email=data.get("email", ""),
            name=data.get("name", ""),
            access_token=data.get("access_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_at=data.get("expires_at", ""),
            plan=data.get("plan", "free")
        )
    
    def is_logged_in(self) -> bool:
        return bool(self.access_token and self.user_id)


def save_hub_auth(user: SARAHubUser) -> bool:
    """Save SAARA Hub authentication."""
    try:
        ensure_config_dir()
        with open(AUTH_FILE, 'w') as f:
            json.dump(user.to_dict(), f, indent=2)
        try:
            os.chmod(AUTH_FILE, 0o600)
        except:
            pass
        return True
    except Exception as e:
        logger.error(f"Failed to save hub auth: {e}")
        return False


def load_hub_auth() -> SARAHubUser:
    """Load SAARA Hub authentication."""
    try:
        if AUTH_FILE.exists():
            with open(AUTH_FILE, 'r') as f:
                data = json.load(f)
            return SARAHubUser.from_dict(data)
    except Exception as e:
        logger.error(f"Failed to load hub auth: {e}")
    return SARAHubUser()


def clear_hub_auth() -> bool:
    """Clear SAARA Hub authentication (logout)."""
    try:
        if AUTH_FILE.exists():
            AUTH_FILE.unlink()
        return True
    except Exception as e:
        logger.error(f"Failed to clear hub auth: {e}")
        return False


def is_hub_logged_in() -> bool:
    """Check if user is logged into SAARA Hub."""
    user = load_hub_auth()
    return user.is_logged_in()


def get_hub_user() -> Optional[SARAHubUser]:
    """Get current SAARA Hub user if logged in."""
    user = load_hub_auth()
    if user.is_logged_in():
        return user
    return None


def generate_device_code() -> str:
    """Generate a unique device code for authentication."""
    import uuid
    import hashlib
    device_id = str(uuid.uuid4())
    return hashlib.sha256(device_id.encode()).hexdigest()[:32]


def run_hub_login_wizard(console=None) -> Optional[SARAHubUser]:
    """
    Interactive SAARA Hub login wizard.
    Uses device-based authentication flow.
    """
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    import webbrowser
    import time
    
    # Check if already logged in
    existing_user = load_hub_auth()
    if existing_user.is_logged_in():
        console.print(f"\n[green]✓ Already signed in as: {existing_user.name or existing_user.email}[/green]")
        if not Confirm.ask("Sign in with a different account?", default=False):
            return existing_user
    
    console.print(Panel.fit(
        "[bold cyan]🌐 SAARA Hub Sign In[/bold cyan]\n\n"
        "Sign in to access:\n"
        "• Cloud model storage & sync\n"
        "• Pre-trained model marketplace\n"
        "• Usage analytics & monitoring\n"
        "• Community shared datasets\n\n"
        f"[dim]Hub URL: {SAARA_HUB_URL}[/dim]",
        title="SAARA Hub",
        border_style="cyan"
    ))
    
    console.print("\n[bold]Choose sign-in method:[/bold]")
    console.print("  1. 📝 Quick Register (create local profile)")
    console.print("  2. 🌐 Sign in with Browser (opens SAARA Hub)")
    console.print("  3. 🔑 Enter API Token manually")
    console.print("  4. ⏭️  Skip for now")
    
    choice = Prompt.ask("Select option", choices=["1", "2", "3", "4"], default="1")
    
    if choice == "4":
        console.print("[dim]Skipping SAARA Hub sign-in.[/dim]")
        return None
    
    if choice == "1":
        # Quick local registration
        console.print("\n[bold cyan]📝 Quick Register[/bold cyan]")
        console.print("[dim]Create a local profile. You can sync with SAARA Hub later.[/dim]\n")
        
        name = Prompt.ask("Your name", default="SAARA User")
        email = Prompt.ask("Email (optional)", default="")
        
        import uuid
        user = SARAHubUser(
            user_id=str(uuid.uuid4())[:16],
            email=email or f"{name.lower().replace(' ', '.')}@saara.local",
            name=name,
            access_token=f"local_{uuid.uuid4().hex[:24]}",
            plan="free"
        )
        
        if save_hub_auth(user):
            console.print(f"\n[bold green]✅ Profile created![/bold green]")
            console.print(f"[green]Welcome, {user.name}![/green]")
            console.print(f"[dim]Visit {SAARA_HUB_URL} to sync your profile later.[/dim]")
            return user
        else:
            console.print("[red]Failed to create profile.[/red]")
            return None
    
    if choice == "2":
        # Open browser to SAARA Hub
        console.print(f"\n[bold]Opening SAARA Hub...[/bold]")
        console.print(f"[cyan]{SAARA_HUB_URL}[/cyan]\n")
        
        # Try to open browser
        try:
            webbrowser.open(SAARA_HUB_URL)
        except:
            pass
        
        console.print("[yellow]SAARA Hub is opening in your browser.[/yellow]")
        console.print("[dim]Note: Full authentication coming soon![/dim]\n")
        
        # For now, offer quick register
        if Confirm.ask("Create a local profile for now?", default=True):
            name = Prompt.ask("Your name", default="SAARA User")
            
            import uuid
            user = SARAHubUser(
                user_id=str(uuid.uuid4())[:16],
                email=f"{name.lower().replace(' ', '.')}@saara.local",
                name=name,
                access_token=f"local_{uuid.uuid4().hex[:24]}",
                plan="free"
            )
            
            if save_hub_auth(user):
                console.print(f"\n[bold green]✅ Profile created![/bold green]")
                console.print(f"[green]Welcome, {user.name}![/green]")
                return user
        
        return None
    
    else:  # choice == "3"
        console.print(f"\n[bold]Get your API token from:[/bold]")
        console.print(f"[cyan]{SAARA_HUB_URL}/settings/tokens[/cyan]")
        console.print("[dim](Token authentication coming soon)[/dim]\n")
        
        token = Prompt.ask("Enter your SAARA Hub API token", password=True)
        
        if not token.strip():
            console.print("[yellow]No token provided. Sign-in cancelled.[/yellow]")
            return None
        
        user = _validate_and_save_token(token.strip(), console)
        return user


def _validate_and_save_token(token: str, console) -> Optional[SARAHubUser]:
    """Validate token with SAARA Hub and save user info."""
    import requests
    
    console.print("[dim]Validating token...[/dim]")
    
    try:
        # Try to validate token with the API
        response = requests.get(
            f"{SAARA_HUB_API}/auth/me",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10
        )
        
        if response.ok:
            data = response.json()
            user = SARAHubUser(
                user_id=data.get("id", ""),
                email=data.get("email", ""),
                name=data.get("name", data.get("email", "").split("@")[0]),
                access_token=token,
                plan=data.get("plan", "free")
            )
            
            if save_hub_auth(user):
                console.print(f"\n[bold green]✅ Successfully signed in![/bold green]")
                console.print(f"[green]Welcome, {user.name}![/green]")
                if user.plan != "free":
                    console.print(f"[cyan]Plan: {user.plan.title()}[/cyan]")
                return user
            else:
                console.print("[red]Failed to save authentication.[/red]")
                return None
        else:
            # If API validation fails, store token anyway (offline mode)
            console.print("[yellow]Could not verify token with server (may be offline).[/yellow]")
            
    except requests.exceptions.RequestException:
        # Network error - store token anyway for offline use
        console.print("[yellow]Could not connect to SAARA Hub (network issue).[/yellow]")
    
    # Fallback: Save token anyway for later validation
    if Confirm.ask("Save token anyway for later use?", default=True):
        # Extract email from token if possible (JWT)
        email = _extract_email_from_token(token)
        
        user = SARAHubUser(
            user_id=token[:16],
            email=email or "user@saara.local",
            name=email.split("@")[0] if email else "SAARA User",
            access_token=token,
            plan="free"
        )
        
        if save_hub_auth(user):
            console.print(f"\n[green]✓ Token saved. Will validate when online.[/green]")
            return user
    
    return None


def _extract_email_from_token(token: str) -> Optional[str]:
    """Try to extract email from JWT token."""
    try:
        import base64
        # JWT tokens have 3 parts separated by dots
        parts = token.split(".")
        if len(parts) == 3:
            # Decode the payload (second part)
            payload = parts[1]
            # Add padding if needed
            padding = 4 - len(payload) % 4
            if padding != 4:
                payload += "=" * padding
            decoded = base64.b64decode(payload)
            data = json.loads(decoded)
            return data.get("email")
    except:
        pass
    return None


def display_hub_status(console=None) -> None:
    """Display SAARA Hub connection status."""
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    
    user = load_hub_auth()
    
    if user.is_logged_in():
        plan_badge = {
            "free": "[dim]Free[/dim]",
            "pro": "[cyan]Pro[/cyan]",
            "enterprise": "[gold1]Enterprise[/gold1]"
        }.get(user.plan, "[dim]Free[/dim]")
        
        console.print(Panel.fit(
            f"[bold green]✓ Signed in to SAARA Hub[/bold green]\n\n"
            f"[bold]User:[/bold] {user.name}\n"
            f"[bold]Email:[/bold] {user.email}\n"
            f"[bold]Plan:[/bold] {plan_badge}\n\n"
            f"[dim]Hub: {SAARA_HUB_URL}[/dim]",
            title="🌐 SAARA Hub",
            border_style="green"
        ))
    else:
        console.print(Panel.fit(
            "[dim]Not signed in to SAARA Hub[/dim]\n\n"
            "Sign in to access:\n"
            "• Cloud model sync\n"
            "• Model marketplace\n"
            "• Usage analytics\n\n"
            f"[bold]Run:[/bold] [cyan]saara login[/cyan]",
            title="🌐 SAARA Hub",
            border_style="dim"
        ))


def hub_logout(console=None) -> bool:
    """Log out from SAARA Hub."""
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.prompt import Confirm
    
    user = load_hub_auth()
    
    if not user.is_logged_in():
        console.print("[dim]Not currently signed in to SAARA Hub.[/dim]")
        return True
    
    console.print(f"[bold]Currently signed in as:[/bold] {user.name} ({user.email})")
    
    if Confirm.ask("Are you sure you want to sign out?", default=False):
        if clear_hub_auth():
            console.print("[green]✓ Successfully signed out from SAARA Hub.[/green]")
            return True
        else:
            console.print("[red]Failed to sign out.[/red]")
            return False
    else:
        console.print("[dim]Sign out cancelled.[/dim]")
        return False


# Auto-load keys when module is imported
try:
    apply_api_keys_to_env()
except:
    pass
