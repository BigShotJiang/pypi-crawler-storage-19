"""
SAARA Hub Authentication Module

Browser-based authentication for SAARA Hub.
Users sign in via https://saara.onslate.in/

© 2024-2026 Kilani Sai Nikhil. All Rights Reserved.
"""

import os
import json
import secrets
import webbrowser
import logging
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict
from datetime import datetime

logger = logging.getLogger(__name__)

# Configuration
SAARA_HUB_URL = "https://saara.onslate.in"
SAARA_HUB_LOGIN = f"{SAARA_HUB_URL}/login"
SAARA_HUB_SIGNUP = f"{SAARA_HUB_URL}/signup"
AUTH_DIR = Path.home() / ".saara"
SESSION_FILE = AUTH_DIR / "session.json"


@dataclass
class User:
    """SAARA Hub User."""
    id: str
    email: str
    name: str
    plan: str = "free"
    avatar_url: str = ""
    created_at: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "User":
        return cls(
            id=data.get("id", ""),
            email=data.get("email", ""),
            name=data.get("name", ""),
            plan=data.get("plan", "free"),
            avatar_url=data.get("avatar_url", ""),
            created_at=data.get("created_at", "")
        )


@dataclass  
class Session:
    """User session from SAARA Hub."""
    user: User
    token: str
    logged_in_at: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "user": self.user.to_dict(),
            "token": self.token,
            "logged_in_at": self.logged_in_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Session":
        return cls(
            user=User.from_dict(data.get("user", {})),
            token=data.get("token", ""),
            logged_in_at=data.get("logged_in_at", "")
        )
    
    def is_valid(self) -> bool:
        return bool(self.token and self.user.id)


def _ensure_auth_dir():
    """Ensure auth directory exists."""
    AUTH_DIR.mkdir(parents=True, exist_ok=True)


def _save_session(session: Session) -> bool:
    """Save session to file."""
    try:
        _ensure_auth_dir()
        with open(SESSION_FILE, 'w') as f:
            json.dump(session.to_dict(), f, indent=2)
        try:
            os.chmod(SESSION_FILE, 0o600)
        except:
            pass
        return True
    except Exception as e:
        logger.error(f"Failed to save session: {e}")
        return False


def _load_session() -> Optional[Session]:
    """Load session from file."""
    try:
        if SESSION_FILE.exists():
            with open(SESSION_FILE, 'r') as f:
                data = json.load(f)
            session = Session.from_dict(data)
            if session.is_valid():
                return session
    except Exception as e:
        logger.error(f"Failed to load session: {e}")
    return None


def _clear_session() -> bool:
    """Clear session file."""
    try:
        if SESSION_FILE.exists():
            SESSION_FILE.unlink()
        return True
    except Exception as e:
        logger.error(f"Failed to clear session: {e}")
        return False


def is_logged_in() -> bool:
    """Check if user is logged in."""
    session = _load_session()
    return session is not None and session.is_valid()


def get_current_user() -> Optional[User]:
    """Get currently logged in user."""
    session = _load_session()
    if session and session.is_valid():
        return session.user
    return None


def logout() -> bool:
    """Logout current user."""
    return _clear_session()


def login(email: str = None, name: str = None) -> bool:
    """
    Save login session after browser authentication.
    Called after user completes sign-in on SAARA Hub website.
    """
    if not email:
        return False
    
    user = User(
        id=secrets.token_hex(8),
        email=email,
        name=name or email.split('@')[0],
        plan="free",
        created_at=datetime.now().isoformat()
    )
    
    session = Session(
        user=user,
        token=secrets.token_urlsafe(32),
        logged_in_at=datetime.now().isoformat()
    )
    
    return _save_session(session)


def register(email: str, password: str, name: str = None):
    """Not used - registration happens on SAARA Hub website."""
    pass


def run_auth_wizard(console=None) -> Optional[User]:
    """
    Interactive browser-based authentication wizard.
    Opens SAARA Hub website for sign-in.
    """
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    
    # Check if already logged in
    current_user = get_current_user()
    if current_user:
        console.print(f"\n[green]✓ Already signed in as: {current_user.name} ({current_user.email})[/green]")
        if not Confirm.ask("Sign in with a different account?", default=False):
            return current_user
        logout()
    
    console.print(Panel.fit(
        "[bold cyan]🌐 SAARA Hub Sign In[/bold cyan]\n\n"
        "Sign in via your browser to access:\n"
        "• Cloud model storage & sync\n"
        "• Pre-trained model marketplace\n"
        "• Usage analytics & monitoring\n"
        "• Community shared datasets\n\n"
        f"[bold]Website:[/bold] [cyan]{SAARA_HUB_URL}[/cyan]",
        title="SAARA Hub",
        border_style="cyan"
    ))
    
    console.print("\n[bold]Choose an option:[/bold]")
    console.print(f"  1. 🌐 Sign in / Create account (opens browser)")
    console.print(f"  2. ⏭️  Skip for now")
    
    choice = Prompt.ask("Select option", choices=["1", "2"], default="1")
    
    if choice == "2":
        console.print("[dim]Skipping SAARA Hub sign-in.[/dim]")
        return None
    
    # Open browser for authentication
    console.print(f"\n[bold]Opening SAARA Hub in your browser...[/bold]")
    console.print(f"[cyan]{SAARA_HUB_URL}[/cyan]\n")
    
    try:
        webbrowser.open(SAARA_HUB_URL)
    except Exception as e:
        console.print(f"[yellow]Could not open browser automatically.[/yellow]")
        console.print(f"[dim]Please visit: {SAARA_HUB_URL}[/dim]")
    
    console.print("[yellow]Complete sign-in in your browser.[/yellow]")
    console.print("[dim]After signing in, enter your details below to sync.[/dim]\n")
    
    # Get user details after browser sign-in
    console.print("[bold]After signing in on the website, enter your details:[/bold]\n")
    
    email = Prompt.ask("Email you signed in with")
    name = Prompt.ask("Your name", default=email.split('@')[0] if email else "User")
    
    if not email or '@' not in email:
        console.print("[red]Invalid email address.[/red]")
        return None
    
    # Save session
    if login(email=email, name=name):
        user = get_current_user()
        console.print(f"\n[bold green]✅ Successfully signed in![/bold green]")
        console.print(f"[green]Welcome, {user.name}![/green]")
        console.print(f"[dim]Email: {user.email}[/dim]")
        return user
    else:
        console.print("[red]Failed to save session.[/red]")
        return None


def display_auth_status(console=None) -> None:
    """Display current authentication status."""
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    
    user = get_current_user()
    
    if user:
        plan_badge = {
            "free": "[dim]Free[/dim]",
            "pro": "[cyan]Pro[/cyan]",
            "enterprise": "[gold1]Enterprise[/gold1]"
        }.get(user.plan, "[dim]Free[/dim]")
        
        session = _load_session()
        login_date = session.logged_in_at[:10] if session else "Unknown"
        
        console.print(Panel.fit(
            f"[bold green]✓ Signed in to SAARA Hub[/bold green]\n\n"
            f"[bold]Name:[/bold] {user.name}\n"
            f"[bold]Email:[/bold] {user.email}\n"
            f"[bold]Plan:[/bold] {plan_badge}\n"
            f"[bold]Signed in:[/bold] {login_date}\n\n"
            f"[dim]Hub: {SAARA_HUB_URL}[/dim]",
            title="🌐 SAARA Hub",
            border_style="green"
        ))
    else:
        console.print(Panel.fit(
            "[dim]Not signed in to SAARA Hub[/dim]\n\n"
            "Sign in via browser to access:\n"
            "• Cloud model sync\n"
            "• Model marketplace\n"
            "• Usage analytics\n\n"
            f"[bold]Run:[/bold] [cyan]saara login[/cyan]",
            title="🌐 SAARA Hub",
            border_style="dim"
        ))
