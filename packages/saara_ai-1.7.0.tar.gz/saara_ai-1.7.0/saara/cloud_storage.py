"""
Google Drive Cloud Storage Module for SAARA

Enables seamless integration with Google Drive for:
- Model storage & sync
- Dataset backup & sharing
- Cross-device synchronization

© 2024-2026 Kilani Sai Nikhil. All Rights Reserved.
"""

import os
import io
import json
import pickle
import logging
import hashlib
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import threading
from concurrent.futures import ThreadPoolExecutor

logger = logging.getLogger(__name__)

# Configuration
CONFIG_DIR = Path.home() / ".saara"
GDRIVE_TOKEN_FILE = CONFIG_DIR / "gdrive_token.pickle"
GDRIVE_CREDENTIALS_FILE = CONFIG_DIR / "gdrive_credentials.json"
GDRIVE_CONFIG_FILE = CONFIG_DIR / "gdrive_config.json"

# OAuth2 Scopes
SCOPES = ['https://www.googleapis.com/auth/drive.file']

# SAARA folder structure on Google Drive
SAARA_ROOT_FOLDER = "SAARA_AI"
FOLDER_STRUCTURE = {
    "models": "Trained Models",
    "datasets": "Datasets", 
    "tokenizers": "Tokenizers",
    "checkpoints": "Training Checkpoints",
    "exports": "Exported Models"
}


@dataclass
class GDriveConfig:
    """Google Drive configuration."""
    enabled: bool = False
    auto_sync: bool = False
    sync_models: bool = True
    sync_datasets: bool = True
    sync_tokenizers: bool = True
    sync_checkpoints: bool = False  # Large files, off by default
    last_sync: str = ""
    root_folder_id: str = ""
    folder_ids: Dict[str, str] = None
    
    def __post_init__(self):
        if self.folder_ids is None:
            self.folder_ids = {}
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GDriveConfig":
        return cls(
            enabled=data.get("enabled", False),
            auto_sync=data.get("auto_sync", False),
            sync_models=data.get("sync_models", True),
            sync_datasets=data.get("sync_datasets", True),
            sync_tokenizers=data.get("sync_tokenizers", True),
            sync_checkpoints=data.get("sync_checkpoints", False),
            last_sync=data.get("last_sync", ""),
            root_folder_id=data.get("root_folder_id", ""),
            folder_ids=data.get("folder_ids", {})
        )


@dataclass
class SyncItem:
    """Item to sync between local and cloud."""
    name: str
    local_path: str
    remote_id: str = ""
    local_hash: str = ""
    remote_hash: str = ""
    local_modified: str = ""
    remote_modified: str = ""
    size_bytes: int = 0
    sync_status: str = "pending"  # pending, synced, conflict, error


class GoogleDriveStorage:
    """
    Google Drive cloud storage integration for SAARA.
    
    Features:
    - OAuth2 authentication with web browser flow
    - Automatic folder structure creation
    - Bidirectional sync for models, datasets, tokenizers
    - Progress tracking and resumable uploads
    - Conflict detection and resolution
    """
    
    def __init__(self, console=None):
        """Initialize Google Drive storage."""
        self.console = console
        self.service = None
        self.config = self._load_config()
        self._credentials = None
        
    def _load_config(self) -> GDriveConfig:
        """Load Google Drive configuration."""
        try:
            if GDRIVE_CONFIG_FILE.exists():
                with open(GDRIVE_CONFIG_FILE, 'r') as f:
                    return GDriveConfig.from_dict(json.load(f))
        except Exception as e:
            logger.error(f"Failed to load GDrive config: {e}")
        return GDriveConfig()
    
    def _save_config(self) -> bool:
        """Save Google Drive configuration."""
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            with open(GDRIVE_CONFIG_FILE, 'w') as f:
                json.dump(self.config.to_dict(), f, indent=2)
            return True
        except Exception as e:
            logger.error(f"Failed to save GDrive config: {e}")
            return False
    
    def is_connected(self) -> bool:
        """Check if connected to Google Drive."""
        return self.config.enabled and GDRIVE_TOKEN_FILE.exists()
    
    def _get_credentials(self):
        """Get or refresh OAuth2 credentials."""
        try:
            from google.oauth2.credentials import Credentials
            from google.auth.transport.requests import Request
            from google_auth_oauthlib.flow import InstalledAppFlow
        except ImportError:
            raise ImportError(
                "Google Drive dependencies not installed. "
                "Run: pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client"
            )
        
        creds = None
        
        # Load existing token
        if GDRIVE_TOKEN_FILE.exists():
            with open(GDRIVE_TOKEN_FILE, 'rb') as token:
                creds = pickle.load(token)
        
        # Refresh if expired
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
            except Exception:
                creds = None
        
        # Need new authentication
        if not creds or not creds.valid:
            if not GDRIVE_CREDENTIALS_FILE.exists():
                raise FileNotFoundError(
                    f"Google Drive credentials not found at {GDRIVE_CREDENTIALS_FILE}. "
                    "Please download OAuth2 credentials from Google Cloud Console."
                )
            
            flow = InstalledAppFlow.from_client_secrets_file(
                str(GDRIVE_CREDENTIALS_FILE), SCOPES
            )
            creds = flow.run_local_server(port=0)
            
            # Save credentials
            with open(GDRIVE_TOKEN_FILE, 'wb') as token:
                pickle.dump(creds, token)
            
            try:
                os.chmod(GDRIVE_TOKEN_FILE, 0o600)
            except:
                pass
        
        self._credentials = creds
        return creds
    
    def _get_service(self):
        """Get Google Drive API service."""
        if self.service:
            return self.service
        
        try:
            from googleapiclient.discovery import build
        except ImportError:
            raise ImportError(
                "Google API client not installed. "
                "Run: pip install google-api-python-client"
            )
        
        creds = self._get_credentials()
        self.service = build('drive', 'v3', credentials=creds)
        return self.service
    
    def connect(self, credentials_json: str = None) -> bool:
        """
        Connect to Google Drive.
        
        Args:
            credentials_json: Optional path to OAuth2 credentials JSON file.
                            If not provided, will use default location.
        """
        try:
            # Copy credentials if provided
            if credentials_json:
                import shutil
                src = Path(credentials_json)
                if src.exists():
                    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
                    shutil.copy(src, GDRIVE_CREDENTIALS_FILE)
                    logger.info(f"Copied credentials to {GDRIVE_CREDENTIALS_FILE}")
            
            # Authenticate
            self._get_credentials()
            
            # Test connection
            service = self._get_service()
            about = service.about().get(fields="user").execute()
            user_email = about.get('user', {}).get('emailAddress', 'Unknown')
            
            # Setup folder structure
            self._setup_folder_structure()
            
            # Update config
            self.config.enabled = True
            self._save_config()
            
            logger.info(f"Connected to Google Drive as {user_email}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to connect to Google Drive: {e}")
            return False
    
    def disconnect(self) -> bool:
        """Disconnect from Google Drive."""
        try:
            if GDRIVE_TOKEN_FILE.exists():
                GDRIVE_TOKEN_FILE.unlink()
            
            self.config.enabled = False
            self.service = None
            self._credentials = None
            self._save_config()
            
            return True
        except Exception as e:
            logger.error(f"Failed to disconnect: {e}")
            return False
    
    def get_user_info(self) -> Optional[Dict[str, str]]:
        """Get connected user information."""
        try:
            service = self._get_service()
            about = service.about().get(fields="user, storageQuota").execute()
            
            user = about.get('user', {})
            quota = about.get('storageQuota', {})
            
            # Calculate storage
            used = int(quota.get('usage', 0))
            limit = int(quota.get('limit', 0)) if quota.get('limit') else None
            
            return {
                "email": user.get('emailAddress', ''),
                "name": user.get('displayName', ''),
                "photo_url": user.get('photoLink', ''),
                "storage_used": used,
                "storage_limit": limit,
                "storage_used_gb": round(used / (1024**3), 2),
                "storage_limit_gb": round(limit / (1024**3), 2) if limit else None
            }
        except Exception as e:
            logger.error(f"Failed to get user info: {e}")
            return None
    
    def _setup_folder_structure(self) -> bool:
        """Create SAARA folder structure on Google Drive."""
        try:
            service = self._get_service()
            
            # Create/find root folder
            root_id = self._get_or_create_folder(SAARA_ROOT_FOLDER)
            self.config.root_folder_id = root_id
            
            # Create subfolders
            for key, name in FOLDER_STRUCTURE.items():
                folder_id = self._get_or_create_folder(name, parent_id=root_id)
                self.config.folder_ids[key] = folder_id
            
            self._save_config()
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup folder structure: {e}")
            return False
    
    def _get_or_create_folder(self, name: str, parent_id: str = None) -> str:
        """Get existing folder or create new one."""
        service = self._get_service()
        
        # Search for existing folder
        query = f"name='{name}' and mimeType='application/vnd.google-apps.folder' and trashed=false"
        if parent_id:
            query += f" and '{parent_id}' in parents"
        
        results = service.files().list(
            q=query,
            spaces='drive',
            fields='files(id, name)'
        ).execute()
        
        files = results.get('files', [])
        if files:
            return files[0]['id']
        
        # Create new folder
        file_metadata = {
            'name': name,
            'mimeType': 'application/vnd.google-apps.folder'
        }
        if parent_id:
            file_metadata['parents'] = [parent_id]
        
        folder = service.files().create(
            body=file_metadata,
            fields='id'
        ).execute()
        
        return folder.get('id')
    
    def upload_file(
        self, 
        local_path: str, 
        folder_type: str = "models",
        progress_callback=None
    ) -> Optional[str]:
        """
        Upload a file to Google Drive.
        
        Args:
            local_path: Path to local file
            folder_type: Target folder (models, datasets, tokenizers, etc.)
            progress_callback: Optional callback for progress updates
        
        Returns:
            File ID on success, None on failure
        """
        try:
            from googleapiclient.http import MediaFileUpload
        except ImportError:
            logger.error("Google API client not installed")
            return None
        
        try:
            local_path = Path(local_path)
            if not local_path.exists():
                logger.error(f"File not found: {local_path}")
                return None
            
            service = self._get_service()
            folder_id = self.config.folder_ids.get(folder_type, self.config.root_folder_id)
            
            # Check if file already exists
            existing_id = self._find_file(local_path.name, folder_id)
            
            file_metadata = {'name': local_path.name}
            if not existing_id:
                file_metadata['parents'] = [folder_id]
            
            # Determine MIME type
            mime_type = self._get_mime_type(local_path)
            
            media = MediaFileUpload(
                str(local_path),
                mimetype=mime_type,
                resumable=True
            )
            
            if existing_id:
                # Update existing file
                file = service.files().update(
                    fileId=existing_id,
                    body=file_metadata,
                    media_body=media,
                    fields='id, name, size'
                ).execute()
            else:
                # Create new file
                file = service.files().create(
                    body=file_metadata,
                    media_body=media,
                    fields='id, name, size'
                ).execute()
            
            logger.info(f"Uploaded {local_path.name} to Google Drive ({folder_type})")
            return file.get('id')
            
        except Exception as e:
            logger.error(f"Upload failed for {local_path}: {e}")
            return None
    
    def upload_directory(
        self, 
        local_dir: str, 
        folder_type: str = "models",
        progress_callback=None
    ) -> Dict[str, str]:
        """
        Upload a directory and its contents to Google Drive.
        
        Args:
            local_dir: Path to local directory
            folder_type: Target folder type
            progress_callback: Optional progress callback
        
        Returns:
            Dict mapping local paths to Drive file IDs
        """
        results = {}
        local_dir = Path(local_dir)
        
        if not local_dir.exists() or not local_dir.is_dir():
            logger.error(f"Directory not found: {local_dir}")
            return results
        
        try:
            service = self._get_service()
            parent_id = self.config.folder_ids.get(folder_type, self.config.root_folder_id)
            
            # Create folder for this directory
            folder_id = self._get_or_create_folder(local_dir.name, parent_id)
            results[str(local_dir)] = folder_id
            
            # Upload all files
            all_files = list(local_dir.rglob("*"))
            total = len([f for f in all_files if f.is_file()])
            
            for i, item in enumerate(all_files):
                if item.is_file():
                    # Determine parent folder
                    rel_path = item.relative_to(local_dir)
                    parent = folder_id
                    
                    # Create intermediate folders
                    for part in rel_path.parts[:-1]:
                        parent = self._get_or_create_folder(part, parent)
                    
                    # Upload file
                    file_id = self.upload_file(str(item), folder_type=None)
                    if file_id:
                        results[str(item)] = file_id
                    
                    if progress_callback:
                        progress_callback(i + 1, total, item.name)
            
            return results
            
        except Exception as e:
            logger.error(f"Directory upload failed: {e}")
            return results
    
    def download_file(
        self, 
        file_id: str, 
        local_path: str,
        progress_callback=None
    ) -> bool:
        """
        Download a file from Google Drive.
        
        Args:
            file_id: Google Drive file ID
            local_path: Path to save file locally
            progress_callback: Optional progress callback
        
        Returns:
            True on success
        """
        try:
            from googleapiclient.http import MediaIoBaseDownload
        except ImportError:
            logger.error("Google API client not installed")
            return False
        
        try:
            service = self._get_service()
            local_path = Path(local_path)
            local_path.parent.mkdir(parents=True, exist_ok=True)
            
            request = service.files().get_media(fileId=file_id)
            
            with open(local_path, 'wb') as fh:
                downloader = MediaIoBaseDownload(fh, request)
                done = False
                while not done:
                    status, done = downloader.next_chunk()
                    if progress_callback and status:
                        progress_callback(int(status.progress() * 100))
            
            logger.info(f"Downloaded {local_path.name} from Google Drive")
            return True
            
        except Exception as e:
            logger.error(f"Download failed for {file_id}: {e}")
            return False
    
    def _find_file(self, name: str, folder_id: str = None) -> Optional[str]:
        """Find a file by name in a folder."""
        try:
            service = self._get_service()
            
            query = f"name='{name}' and trashed=false"
            if folder_id:
                query += f" and '{folder_id}' in parents"
            
            results = service.files().list(
                q=query,
                spaces='drive',
                fields='files(id)'
            ).execute()
            
            files = results.get('files', [])
            return files[0]['id'] if files else None
            
        except Exception as e:
            logger.error(f"File search failed: {e}")
            return None
    
    def _get_mime_type(self, path: Path) -> str:
        """Get MIME type for a file."""
        suffix = path.suffix.lower()
        mime_types = {
            '.json': 'application/json',
            '.jsonl': 'application/jsonl',
            '.safetensors': 'application/octet-stream',
            '.bin': 'application/octet-stream',
            '.pt': 'application/octet-stream',
            '.pth': 'application/octet-stream',
            '.pkl': 'application/octet-stream',
            '.pickle': 'application/octet-stream',
            '.txt': 'text/plain',
            '.md': 'text/markdown',
            '.yaml': 'application/x-yaml',
            '.yml': 'application/x-yaml',
            '.zip': 'application/zip',
            '.tar': 'application/x-tar',
            '.gz': 'application/gzip',
        }
        return mime_types.get(suffix, 'application/octet-stream')
    
    def list_drive_files(self, folder_type: str = None) -> List[Dict[str, Any]]:
        """
        List files in a SAARA folder on Google Drive.
        
        Args:
            folder_type: Folder to list (models, datasets, etc.)
        
        Returns:
            List of file metadata dicts
        """
        try:
            service = self._get_service()
            
            if folder_type:
                folder_id = self.config.folder_ids.get(folder_type, self.config.root_folder_id)
                query = f"'{folder_id}' in parents and trashed=false"
            else:
                query = f"'{self.config.root_folder_id}' in parents and trashed=false"
            
            results = service.files().list(
                q=query,
                spaces='drive',
                fields='files(id, name, mimeType, size, modifiedTime, webViewLink)',
                orderBy='name'
            ).execute()
            
            files = []
            for f in results.get('files', []):
                files.append({
                    'id': f.get('id'),
                    'name': f.get('name'),
                    'type': 'folder' if 'folder' in f.get('mimeType', '') else 'file',
                    'size': int(f.get('size', 0)),
                    'modified': f.get('modifiedTime', ''),
                    'link': f.get('webViewLink', '')
                })
            
            return files
            
        except Exception as e:
            logger.error(f"Failed to list drive files: {e}")
            return []
    
    def delete_file(self, file_id: str) -> bool:
        """Delete a file from Google Drive."""
        try:
            service = self._get_service()
            service.files().delete(fileId=file_id).execute()
            return True
        except Exception as e:
            logger.error(f"Delete failed: {e}")
            return False
    
    def sync_models(
        self, 
        models_dir: str = "models",
        direction: str = "both",
        progress_callback=None
    ) -> Dict[str, Any]:
        """
        Sync models between local and Google Drive.
        
        Args:
            models_dir: Local models directory
            direction: "upload", "download", or "both"
            progress_callback: Optional progress callback
        
        Returns:
            Sync results dict
        """
        results = {
            "uploaded": [],
            "downloaded": [],
            "errors": [],
            "skipped": []
        }
        
        if not self.is_connected():
            results["errors"].append("Not connected to Google Drive")
            return results
        
        models_dir = Path(models_dir)
        folder_id = self.config.folder_ids.get("models", self.config.root_folder_id)
        
        try:
            # Get local models
            local_models = set()
            if models_dir.exists():
                for item in models_dir.iterdir():
                    if item.is_dir():
                        local_models.add(item.name)
            
            # Get remote models
            remote_files = self.list_drive_files("models")
            remote_models = {f['name']: f for f in remote_files if f['type'] == 'folder'}
            
            # Upload new/updated models
            if direction in ["upload", "both"]:
                for model_name in local_models:
                    if model_name not in remote_models:
                        model_path = models_dir / model_name
                        upload_result = self.upload_directory(str(model_path), "models")
                        if upload_result:
                            results["uploaded"].append(model_name)
                        else:
                            results["errors"].append(f"Upload failed: {model_name}")
                    else:
                        results["skipped"].append(model_name)
            
            # Download missing models
            if direction in ["download", "both"]:
                for model_name, remote_info in remote_models.items():
                    if model_name not in local_models:
                        # Would need to implement recursive download
                        results["downloaded"].append(f"{model_name} (needs download)")
            
            # Update last sync time
            self.config.last_sync = datetime.now().isoformat()
            self._save_config()
            
        except Exception as e:
            results["errors"].append(str(e))
        
        return results
    
    def sync_datasets(
        self, 
        datasets_dir: str = "datasets",
        direction: str = "both"
    ) -> Dict[str, Any]:
        """Sync datasets between local and cloud."""
        results = {"uploaded": [], "downloaded": [], "errors": [], "skipped": []}
        
        if not self.is_connected():
            results["errors"].append("Not connected to Google Drive")
            return results
        
        datasets_dir = Path(datasets_dir)
        
        try:
            if datasets_dir.exists():
                for item in datasets_dir.iterdir():
                    if item.is_file() and item.suffix in ['.jsonl', '.json', '.txt', '.csv']:
                        file_id = self.upload_file(str(item), "datasets")
                        if file_id:
                            results["uploaded"].append(item.name)
                        else:
                            results["errors"].append(f"Upload failed: {item.name}")
            
            self.config.last_sync = datetime.now().isoformat()
            self._save_config()
            
        except Exception as e:
            results["errors"].append(str(e))
        
        return results
    
    def get_sync_status(self) -> Dict[str, Any]:
        """Get current sync status."""
        return {
            "connected": self.is_connected(),
            "enabled": self.config.enabled,
            "auto_sync": self.config.auto_sync,
            "last_sync": self.config.last_sync,
            "sync_settings": {
                "models": self.config.sync_models,
                "datasets": self.config.sync_datasets,
                "tokenizers": self.config.sync_tokenizers,
                "checkpoints": self.config.sync_checkpoints
            }
        }
    
    def update_sync_settings(
        self,
        auto_sync: bool = None,
        sync_models: bool = None,
        sync_datasets: bool = None,
        sync_tokenizers: bool = None,
        sync_checkpoints: bool = None
    ) -> bool:
        """Update sync settings."""
        if auto_sync is not None:
            self.config.auto_sync = auto_sync
        if sync_models is not None:
            self.config.sync_models = sync_models
        if sync_datasets is not None:
            self.config.sync_datasets = sync_datasets
        if sync_tokenizers is not None:
            self.config.sync_tokenizers = sync_tokenizers
        if sync_checkpoints is not None:
            self.config.sync_checkpoints = sync_checkpoints
        
        return self._save_config()


def run_gdrive_setup_wizard(console=None) -> Optional[GoogleDriveStorage]:
    """
    Interactive wizard to setup Google Drive integration.
    """
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich.table import Table
    
    console.print(Panel.fit(
        "[bold cyan]☁️ Google Drive Integration Setup[/bold cyan]\n\n"
        "Connect SAARA to your Google Drive for:\n"
        "• 💾 Automatic model backup & sync\n"
        "• 📊 Dataset cloud storage\n"
        "• 🔄 Cross-device synchronization\n"
        "• 🌐 Easy sharing & collaboration\n\n"
        "[dim]Your data stays in YOUR Google Drive![/dim]",
        title="Cloud Storage",
        border_style="cyan"
    ))
    
    storage = GoogleDriveStorage(console)
    
    # Check if already connected
    if storage.is_connected():
        user_info = storage.get_user_info()
        if user_info:
            console.print(f"\n[green]✓ Already connected to Google Drive[/green]")
            console.print(f"[dim]Account: {user_info.get('email', 'Unknown')}[/dim]")
            console.print(f"[dim]Storage: {user_info.get('storage_used_gb', 0)}GB used[/dim]")
            
            if not Confirm.ask("Would you like to reconnect?", default=False):
                return storage
            
            storage.disconnect()
    
    console.print("\n[bold]Setup Options:[/bold]")
    console.print("  1. 🔐 Connect with Google Account (opens browser)")
    console.print("  2. 📁 Use existing credentials file")
    console.print("  3. ℹ️  How to get credentials")
    console.print("  4. ⏭️  Skip for now")
    
    choice = Prompt.ask("Select option", choices=["1", "2", "3", "4"], default="1")
    
    if choice == "4":
        console.print("[dim]Skipping Google Drive setup.[/dim]")
        return None
    
    if choice == "3":
        console.print(Panel.fit(
            "[bold]How to get Google Drive credentials:[/bold]\n\n"
            "1. Go to [cyan]https://console.cloud.google.com[/cyan]\n"
            "2. Create a new project (or use existing)\n"
            "3. Enable 'Google Drive API'\n"
            "4. Go to 'Credentials' → 'Create Credentials' → 'OAuth client ID'\n"
            "5. Select 'Desktop app'\n"
            "6. Download the JSON file\n"
            "7. Copy it to: [cyan]~/.saara/gdrive_credentials.json[/cyan]\n\n"
            "[dim]Or use option 2 to specify the file path.[/dim]",
            title="📋 Instructions",
            border_style="cyan"
        ))
        return run_gdrive_setup_wizard(console)
    
    credentials_path = None
    
    if choice == "2":
        credentials_path = Prompt.ask(
            "Enter path to credentials JSON file",
            default=str(GDRIVE_CREDENTIALS_FILE)
        )
        
        if not Path(credentials_path).exists():
            console.print(f"[red]File not found: {credentials_path}[/red]")
            return None
    
    # Check for credentials
    if not credentials_path and not GDRIVE_CREDENTIALS_FILE.exists():
        console.print(f"\n[yellow]⚠️ No credentials file found at:[/yellow]")
        console.print(f"[cyan]{GDRIVE_CREDENTIALS_FILE}[/cyan]\n")
        console.print("[dim]You need to set up OAuth2 credentials first.[/dim]")
        console.print("[dim]Choose option 3 for instructions.[/dim]")
        return None
    
    console.print("\n[bold]Connecting to Google Drive...[/bold]")
    console.print("[dim]A browser window will open for authentication.[/dim]")
    
    try:
        if storage.connect(credentials_path):
            user_info = storage.get_user_info()
            
            console.print(f"\n[bold green]✅ Successfully connected to Google Drive![/bold green]")
            
            if user_info:
                console.print(f"[green]Account: {user_info.get('name', '')} ({user_info.get('email', '')})[/green]")
                
                used = user_info.get('storage_used_gb', 0)
                limit = user_info.get('storage_limit_gb')
                if limit:
                    console.print(f"[dim]Storage: {used}GB / {limit}GB[/dim]")
                else:
                    console.print(f"[dim]Storage: {used}GB used[/dim]")
            
            # Configure sync settings
            console.print("\n[bold]Configure sync settings:[/bold]")
            
            storage.config.sync_models = Confirm.ask("Sync trained models?", default=True)
            storage.config.sync_datasets = Confirm.ask("Sync datasets?", default=True)
            storage.config.sync_tokenizers = Confirm.ask("Sync tokenizers?", default=True)
            storage.config.sync_checkpoints = Confirm.ask("Sync checkpoints (can be large)?", default=False)
            storage.config.auto_sync = Confirm.ask("Enable auto-sync after training?", default=False)
            
            storage._save_config()
            
            console.print(f"\n[green]✓ Google Drive setup complete![/green]")
            console.print("[dim]Use 'saara drive sync' to manually sync files.[/dim]")
            
            return storage
        else:
            console.print("[red]Failed to connect to Google Drive.[/red]")
            return None
            
    except ImportError as e:
        console.print(f"\n[red]Missing dependencies:[/red] {e}")
        console.print("\n[bold]Install required packages:[/bold]")
        console.print("[cyan]pip install google-auth-oauthlib google-auth-httplib2 google-api-python-client[/cyan]")
        return None
        
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        return None


def display_gdrive_status(console=None) -> None:
    """Display Google Drive connection status."""
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    from rich.table import Table
    
    storage = GoogleDriveStorage(console)
    
    if storage.is_connected():
        user_info = storage.get_user_info()
        status = storage.get_sync_status()
        
        # User info
        name = user_info.get('name', 'Unknown') if user_info else 'Unknown'
        email = user_info.get('email', '') if user_info else ''
        used = user_info.get('storage_used_gb', 0) if user_info else 0
        limit = user_info.get('storage_limit_gb') if user_info else None
        
        storage_str = f"{used}GB"
        if limit:
            storage_str += f" / {limit}GB"
        
        # Sync settings
        settings = status.get('sync_settings', {})
        sync_items = []
        if settings.get('models'): sync_items.append("Models")
        if settings.get('datasets'): sync_items.append("Datasets")
        if settings.get('tokenizers'): sync_items.append("Tokenizers")
        if settings.get('checkpoints'): sync_items.append("Checkpoints")
        
        last_sync = status.get('last_sync', 'Never')
        if last_sync and last_sync != 'Never':
            try:
                dt = datetime.fromisoformat(last_sync)
                last_sync = dt.strftime("%Y-%m-%d %H:%M")
            except:
                pass
        
        content = (
            f"[bold green]✓ Connected to Google Drive[/bold green]\n\n"
            f"[bold]Account:[/bold] {name}\n"
            f"[bold]Email:[/bold] {email}\n"
            f"[bold]Storage:[/bold] {storage_str}\n"
            f"[bold]Last Sync:[/bold] {last_sync}\n"
            f"[bold]Auto-sync:[/bold] {'Enabled' if status.get('auto_sync') else 'Disabled'}\n"
            f"[bold]Syncing:[/bold] {', '.join(sync_items) if sync_items else 'None'}"
        )
        
        console.print(Panel.fit(content, title="☁️ Google Drive", border_style="green"))
        
    else:
        console.print(Panel.fit(
            "[dim]Not connected to Google Drive[/dim]\n\n"
            "Connect to enable:\n"
            "• Cloud model backup\n"
            "• Dataset sync\n"
            "• Cross-device access\n\n"
            "[bold]Run:[/bold] [cyan]saara drive connect[/cyan]",
            title="☁️ Google Drive",
            border_style="dim"
        ))


class KaggleStorage:
    """
    Kaggle cloud storage integration for SAARA.
    
    Features:
    - Kaggle Secrets management
    - Kaggle Datasets integration
    - Model output saving to /kaggle/working
    - Google Cloud Storage from Kaggle
    """
    
    def __init__(self, console=None):
        """Initialize Kaggle storage."""
        self.console = console
        self.platform = self._detect_platform()
        self._kaggle_working = Path("/kaggle/working")
        self._kaggle_input = Path("/kaggle/input")
        
    def _detect_platform(self) -> str:
        """Detect the current cloud notebook platform."""
        # Check for Kaggle
        if os.environ.get('KAGGLE_KERNEL_RUN_TYPE'):
            return "kaggle"
        
        # Check for Google Colab
        try:
            from google.colab import drive
            return "colab"
        except ImportError:
            pass
        
        # Check for other indicators
        if Path("/kaggle").exists():
            return "kaggle"
        
        return "local"
    
    def is_kaggle(self) -> bool:
        """Check if running in Kaggle environment."""
        return self.platform == "kaggle"
    
    def is_colab(self) -> bool:
        """Check if running in Google Colab."""
        return self.platform == "colab"
    
    def is_cloud_notebook(self) -> bool:
        """Check if running in any cloud notebook environment."""
        return self.platform in ["kaggle", "colab"]
    
    def get_working_dir(self) -> Path:
        """Get the appropriate working directory for the platform."""
        if self.is_kaggle():
            return self._kaggle_working
        elif self.is_colab():
            return Path("/content")
        else:
            return Path.cwd()
    
    def get_output_dir(self) -> Path:
        """Get the output directory for saving models/datasets."""
        if self.is_kaggle():
            output_dir = self._kaggle_working / "saara_output"
        elif self.is_colab():
            output_dir = Path("/content/saara_output")
        else:
            output_dir = Path.cwd() / "output"
        
        output_dir.mkdir(parents=True, exist_ok=True)
        return output_dir
    
    def get_secret(self, secret_name: str) -> Optional[str]:
        """
        Get a secret value from the platform's secret store.
        
        Args:
            secret_name: Name of the secret (e.g., 'GOOGLE_API_KEY')
        
        Returns:
            Secret value or None if not found
        """
        # Try environment variable first
        value = os.environ.get(secret_name)
        if value:
            return value
        
        # Try Kaggle secrets
        if self.is_kaggle():
            try:
                from kaggle_secrets import UserSecretsClient
                secrets = UserSecretsClient()
                return secrets.get_secret(secret_name)
            except Exception as e:
                logger.debug(f"Kaggle secret not found: {e}")
        
        # Try Colab userdata
        if self.is_colab():
            try:
                from google.colab import userdata
                return userdata.get(secret_name)
            except Exception as e:
                logger.debug(f"Colab secret not found: {e}")
        
        return None
    
    def setup_gcs_from_secret(self) -> bool:
        """
        Setup Google Cloud Storage connection using Kaggle/Colab secrets.
        
        Returns:
            True if GCS is configured successfully
        """
        try:
            gcp_key = self.get_secret("GCP_SERVICE_ACCOUNT")
            if not gcp_key:
                return False
            
            # Write credentials to temp file
            import tempfile
            creds_file = Path(tempfile.gettempdir()) / "gcp_credentials.json"
            creds_file.write_text(gcp_key)
            
            os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(creds_file)
            return True
            
        except Exception as e:
            logger.error(f"Failed to setup GCS credentials: {e}")
            return False
    
    def list_input_datasets(self) -> List[Dict[str, Any]]:
        """List available input datasets (Kaggle only)."""
        datasets = []
        
        if self.is_kaggle() and self._kaggle_input.exists():
            for item in self._kaggle_input.iterdir():
                if item.is_dir():
                    # Count files
                    files = list(item.rglob("*"))
                    file_count = len([f for f in files if f.is_file()])
                    total_size = sum(f.stat().st_size for f in files if f.is_file())
                    
                    datasets.append({
                        "name": item.name,
                        "path": str(item),
                        "file_count": file_count,
                        "size_mb": round(total_size / (1024 * 1024), 2)
                    })
        
        return datasets
    
    def save_to_output(
        self, 
        source_path: str, 
        output_name: str = None
    ) -> Optional[Path]:
        """
        Save a file/directory to the platform's output directory.
        
        In Kaggle, files in /kaggle/working become part of the notebook output
        and can be saved as a new dataset.
        
        Args:
            source_path: Path to file or directory to save
            output_name: Optional custom name for the output
        
        Returns:
            Path to the saved output, or None on failure
        """
        try:
            import shutil
            
            source = Path(source_path)
            if not source.exists():
                logger.error(f"Source not found: {source}")
                return None
            
            output_dir = self.get_output_dir()
            dest_name = output_name or source.name
            dest = output_dir / dest_name
            
            if source.is_file():
                shutil.copy2(source, dest)
            else:
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(source, dest)
            
            logger.info(f"Saved to output: {dest}")
            return dest
            
        except Exception as e:
            logger.error(f"Failed to save to output: {e}")
            return None
    
    def download_from_gcs(
        self,
        bucket_name: str,
        blob_name: str,
        local_path: str
    ) -> bool:
        """
        Download a file from Google Cloud Storage.
        
        Args:
            bucket_name: GCS bucket name
            blob_name: Path within the bucket
            local_path: Local destination path
        
        Returns:
            True on success
        """
        try:
            from google.cloud import storage
        except ImportError:
            logger.error("google-cloud-storage not installed")
            return False
        
        try:
            self.setup_gcs_from_secret()
            
            client = storage.Client()
            bucket = client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            
            local_path = Path(local_path)
            local_path.parent.mkdir(parents=True, exist_ok=True)
            
            blob.download_to_filename(str(local_path))
            logger.info(f"Downloaded gs://{bucket_name}/{blob_name} to {local_path}")
            return True
            
        except Exception as e:
            logger.error(f"GCS download failed: {e}")
            return False
    
    def upload_to_gcs(
        self,
        local_path: str,
        bucket_name: str,
        blob_name: str = None
    ) -> bool:
        """
        Upload a file to Google Cloud Storage.
        
        Args:
            local_path: Local file path
            bucket_name: GCS bucket name
            blob_name: Optional path within bucket (defaults to filename)
        
        Returns:
            True on success
        """
        try:
            from google.cloud import storage
        except ImportError:
            logger.error("google-cloud-storage not installed")
            return False
        
        try:
            self.setup_gcs_from_secret()
            
            local_path = Path(local_path)
            if not local_path.exists():
                logger.error(f"File not found: {local_path}")
                return False
            
            blob_name = blob_name or local_path.name
            
            client = storage.Client()
            bucket = client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            
            blob.upload_from_filename(str(local_path))
            logger.info(f"Uploaded {local_path} to gs://{bucket_name}/{blob_name}")
            return True
            
        except Exception as e:
            logger.error(f"GCS upload failed: {e}")
            return False
    
    def mount_google_drive(self) -> Optional[Path]:
        """
        Mount Google Drive in Colab environment.
        
        Returns:
            Path to mounted drive, or None if not in Colab
        """
        if not self.is_colab():
            logger.warning("Google Drive mounting only available in Colab")
            return None
        
        try:
            from google.colab import drive
            
            mount_point = Path("/content/drive")
            if not mount_point.exists():
                drive.mount("/content/drive")
            
            return mount_point / "MyDrive"
            
        except Exception as e:
            logger.error(f"Failed to mount Google Drive: {e}")
            return None
    
    def get_drive_saara_folder(self) -> Optional[Path]:
        """
        Get or create SAARA folder in Google Drive (Colab only).
        
        Returns:
            Path to SAARA folder in Drive, or None
        """
        drive_root = self.mount_google_drive()
        if not drive_root:
            return None
        
        saara_folder = drive_root / "SAARA_AI"
        saara_folder.mkdir(exist_ok=True)
        
        # Create subfolders
        for folder in ["models", "datasets", "tokenizers", "checkpoints"]:
            (saara_folder / folder).mkdir(exist_ok=True)
        
        return saara_folder
    
    def sync_to_drive(
        self,
        source_path: str,
        category: str = "models"
    ) -> bool:
        """
        Sync a file/directory to Google Drive SAARA folder.
        
        Args:
            source_path: Local path to sync
            category: Category folder (models, datasets, tokenizers, checkpoints)
        
        Returns:
            True on success
        """
        if not self.is_colab():
            logger.warning("Drive sync only available in Colab")
            return False
        
        try:
            import shutil
            
            saara_folder = self.get_drive_saara_folder()
            if not saara_folder:
                return False
            
            source = Path(source_path)
            dest = saara_folder / category / source.name
            
            if source.is_file():
                shutil.copy2(source, dest)
            else:
                if dest.exists():
                    shutil.rmtree(dest)
                shutil.copytree(source, dest)
            
            logger.info(f"Synced to Google Drive: {dest}")
            return True
            
        except Exception as e:
            logger.error(f"Drive sync failed: {e}")
            return False
    
    def get_platform_info(self) -> Dict[str, Any]:
        """Get information about the current platform."""
        info = {
            "platform": self.platform,
            "is_cloud": self.is_cloud_notebook(),
            "working_dir": str(self.get_working_dir()),
            "output_dir": str(self.get_output_dir()),
        }
        
        if self.is_kaggle():
            info["kaggle"] = {
                "datasets": self.list_input_datasets(),
                "kernel_type": os.environ.get("KAGGLE_KERNEL_RUN_TYPE", "unknown"),
                "has_gpu": os.environ.get("KAGGLE_ACCELERATOR_TYPE") is not None
            }
        
        if self.is_colab():
            info["colab"] = {
                "has_gpu": "GPU" in os.environ.get("COLAB_TPU_ADDR", "") or 
                          os.path.exists("/dev/nvidia0"),
                "drive_mounted": Path("/content/drive/MyDrive").exists()
            }
        
        return info


def detect_cloud_environment() -> Dict[str, Any]:
    """
    Detect the current cloud notebook environment and return info.
    
    Returns:
        Dictionary with platform info and capabilities
    """
    storage = KaggleStorage()
    return storage.get_platform_info()


def get_cloud_storage() -> KaggleStorage:
    """
    Get a KaggleStorage instance configured for the current environment.
    
    Returns:
        KaggleStorage instance
    """
    return KaggleStorage()


def run_gdrive_sync_wizard(console=None) -> Dict[str, Any]:
    """
    Interactive wizard to sync with Google Drive.
    """
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.prompt import Prompt, Confirm
    from rich.progress import Progress, SpinnerColumn, TextColumn
    
    storage = GoogleDriveStorage(console)
    
    if not storage.is_connected():
        console.print("[red]Not connected to Google Drive.[/red]")
        console.print("[dim]Run 'saara drive connect' first.[/dim]")
        return {"error": "Not connected"}
    
    console.print("[bold]☁️ Google Drive Sync[/bold]\n")
    
    console.print("[bold]What would you like to sync?[/bold]")
    console.print("  1. 📦 Models only")
    console.print("  2. 📊 Datasets only")
    console.print("  3. 🔤 Tokenizers only")
    console.print("  4. 📁 Everything")
    console.print("  5. ⬆️  Upload all (local → cloud)")
    console.print("  6. ⬇️  Download all (cloud → local)")
    
    choice = Prompt.ask("Select option", choices=["1", "2", "3", "4", "5", "6"], default="4")
    
    results = {
        "models": None,
        "datasets": None,
        "tokenizers": None
    }
    
    direction = "both"
    if choice == "5":
        direction = "upload"
    elif choice == "6":
        direction = "download"
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        
        if choice in ["1", "4", "5", "6"]:
            task = progress.add_task("Syncing models...", total=None)
            results["models"] = storage.sync_models(direction=direction)
            progress.remove_task(task)
        
        if choice in ["2", "4", "5", "6"]:
            task = progress.add_task("Syncing datasets...", total=None)
            results["datasets"] = storage.sync_datasets(direction=direction)
            progress.remove_task(task)
        
        if choice in ["3", "4", "5", "6"]:
            task = progress.add_task("Syncing tokenizers...", total=None)
            # Similar sync for tokenizers
            progress.remove_task(task)
    
    # Display results
    console.print("\n[bold]Sync Results:[/bold]")
    
    for category, result in results.items():
        if result:
            uploaded = len(result.get("uploaded", []))
            downloaded = len(result.get("downloaded", []))
            errors = len(result.get("errors", []))
            
            status = "[green]✓[/green]" if errors == 0 else "[yellow]⚠[/yellow]"
            console.print(f"{status} {category.title()}: ⬆️{uploaded} ⬇️{downloaded} {'❌' + str(errors) if errors else ''}")
    
    console.print(f"\n[dim]Last sync: {datetime.now().strftime('%Y-%m-%d %H:%M')}[/dim]")
    
    return results
