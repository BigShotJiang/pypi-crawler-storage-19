"""
Saara: Autonomous Document-to-LLM Data Factory SDK.

🪔 ज्ञानस्य सारः - The Essence of Knowledge

Powered by Google Gemini 2.0 Flash & Gemma 2 Models

© 2025-2026 Kilani Sai Nikhil. All Rights Reserved.
"""

__version__ = "1.6.1"
__author__ = "Kilani Sai Nikhil"
__copyright__ = "© 2025-2026 Kilani Sai Nikhil. All Rights Reserved."
__license__ = "Proprietary"

# Core imports (always available)
from .cleaner import TextCleaner, SemanticChunker
from .chunker import TextChunker

# Lazy imports for optional heavy dependencies
def __getattr__(name):
    """Lazy import for heavy dependencies."""
    
    # Training module (requires torch)
    if name == "LLMTrainer":
        from .train import LLMTrainer
        return LLMTrainer
    
    # Evaluator (requires torch)
    if name == "ModelEvaluator":
        from .evaluator import ModelEvaluator
        return ModelEvaluator
    
    # Deployer (may require torch)
    if name == "ModelDeployer":
        from .deployer import ModelDeployer
        return ModelDeployer
    
    # Pipeline (requires ollama, pdfplumber)
    if name == "DataPipeline":
        from .pipeline import DataPipeline
        return DataPipeline
    
    if name == "PipelineResult":
        from .pipeline import PipelineResult
        return PipelineResult
    
    # Dataset generator
    if name == "DatasetGenerator":
        from .dataset_generator import DatasetGenerator
        return DatasetGenerator
    
    # Labeler
    if name == "DataLabeler":
        from .labeler import DataLabeler
        return DataLabeler
    
    # PDF Extractor
    if name == "PDFExtractor":
        from .pdf_extractor import PDFExtractor
        return PDFExtractor
    
    # Synthetic generator
    if name == "SyntheticDataGenerator":
        from .synthetic_generator import SyntheticDataGenerator
        return SyntheticDataGenerator
    
    if name == "DataType":
        from .synthetic_generator import DataType
        return DataType
    
    if name == "QualityJudge":
        from .synthetic_generator import QualityJudge
        return QualityJudge
    
    # Accelerator
    if name == "NeuralAccelerator":
        from .accelerator import NeuralAccelerator
        return NeuralAccelerator
    
    if name == "create_accelerator":
        from .accelerator import create_accelerator
        return create_accelerator
    
    # Visualizer
    if name == "TrainingDashboard":
        from .visualizer import TrainingDashboard
        return TrainingDashboard
    
    if name == "ModelAnalyzer":
        from .visualizer import ModelAnalyzer
        return ModelAnalyzer
    
    if name == "create_visualizer":
        from .visualizer import create_visualizer
        return create_visualizer
    
    # Cloud Runtime
    if name == "CloudRuntime":
        from .cloud_runtime import CloudRuntime
        return CloudRuntime
    
    if name == "setup_colab":
        from .cloud_runtime import setup_colab
        return setup_colab
    
    if name == "is_cloud_environment":
        from .cloud_runtime import is_cloud_environment
        return is_cloud_environment
    
    # AI Tokenizer
    if name == "AIEnhancedTokenizer":
        from .ai_tokenizer import AIEnhancedTokenizer
        return AIEnhancedTokenizer
    
    if name == "create_ai_tokenizer":
        from .ai_tokenizer import create_ai_tokenizer
        return create_ai_tokenizer
    
    # RAG Engine
    if name == "RAGEngine":
        from .rag_engine import RAGEngine
        return RAGEngine
    
    if name == "RAGManager":
        from .rag_engine import RAGManager
        return RAGManager
    
    if name == "create_rag_engine":
        from .rag_engine import create_rag_engine
        return create_rag_engine
    
    if name == "quick_rag":
        from .rag_engine import quick_rag
        return quick_rag
    
    # Config Manager
    if name == "get_api_key":
        from .config_manager import get_api_key
        return get_api_key
    
    if name == "set_api_key":
        from .config_manager import set_api_key
        return set_api_key
    
    if name == "load_api_keys":
        from .config_manager import load_api_keys
        return load_api_keys
    
    # SAARA Hub
    if name == "is_hub_logged_in":
        from .config_manager import is_hub_logged_in
        return is_hub_logged_in
    
    if name == "get_hub_user":
        from .config_manager import get_hub_user
        return get_hub_user
    
    # Authentication
    if name == "login":
        from .auth import login
        return login
    
    if name == "register":
        from .auth import register
        return register
    
    if name == "is_logged_in":
        from .auth import is_logged_in
        return is_logged_in
    
    if name == "get_current_user":
        from .auth import get_current_user
        return get_current_user
    
    # Google Drive Cloud Storage
    if name == "GoogleDriveStorage":
        from .cloud_storage import GoogleDriveStorage
        return GoogleDriveStorage
    
    if name == "is_gdrive_connected":
        from .cloud_storage import GoogleDriveStorage
        return GoogleDriveStorage().is_connected
    
    # Kaggle/Cloud Storage
    if name == "KaggleStorage":
        from .cloud_storage import KaggleStorage
        return KaggleStorage
    
    if name == "detect_cloud_environment":
        from .cloud_storage import detect_cloud_environment
        return detect_cloud_environment
    
    if name == "get_cloud_storage":
        from .cloud_storage import get_cloud_storage
        return get_cloud_storage
    
    # Swarm (Decentralized Training)
    if name == "SaaraSwarm":
        from .swarm import SaaraSwarm
        return SaaraSwarm
    
    if name == "run_swarm_wizard":
        from .swarm import run_swarm_wizard
        return run_swarm_wizard
    
    if name == "SaaraIdentity":
        from .swarm import SaaraIdentity
        return SaaraIdentity
    
    if name == "get_or_create_identity":
        from .swarm import get_or_create_identity
        return get_or_create_identity
    
    # HuggingFace Hub
    if name == "ModelHub":
        from .model_hub import ModelHub
        return ModelHub
    
    if name == "push_model_to_hub":
        from .model_hub import push_model_to_hub
        return push_model_to_hub
    
    if name == "push_dataset_to_hub":
        from .model_hub import push_dataset_to_hub
        return push_dataset_to_hub
    
    if name == "get_hub_status":
        from .model_hub import get_hub_status
        return get_hub_status
    
    # Autonomous Dataset Generation
    if name == "AutonomousDatasetGenerator":
        from .train import AutonomousDatasetGenerator
        return AutonomousDatasetGenerator
    
    if name == "AutonomousFineTuner":
        from .train import AutonomousFineTuner
        return AutonomousFineTuner
    
    raise AttributeError(f"module 'saara' has no attribute '{name}'")


__all__ = [
    # Core Pipeline
    "DataPipeline",
    "PipelineResult",
    "DatasetGenerator",
    "DataLabeler",
    "PDFExtractor",
    "TextChunker",
    "TextCleaner",
    "SemanticChunker", 
    "SyntheticDataGenerator",
    "DataType",
    "QualityJudge",
    
    # Training & Evaluation
    "LLMTrainer",
    "ModelEvaluator",
    "ModelDeployer",
    
    # Accelerator & Visualizer
    "NeuralAccelerator",
    "create_accelerator",
    "TrainingDashboard",
    "ModelAnalyzer",
    "create_visualizer",
    
    # Cloud Runtime
    "CloudRuntime",
    "setup_colab",
    "is_cloud_environment",
    
    # AI Tokenizer
    "AIEnhancedTokenizer",
    "create_ai_tokenizer",
    
    # RAG Engine
    "RAGEngine",
    "RAGManager",
    "create_rag_engine",
    "quick_rag",
    
    # Config Manager
    "get_api_key",
    "set_api_key",
    "load_api_keys",
    
    # SAARA Hub
    "is_hub_logged_in",
    "get_hub_user",
    
    # Google Drive Cloud Storage
    "GoogleDriveStorage",
    "is_gdrive_connected",
    
    # Kaggle/Cloud Storage
    "KaggleStorage",
    "detect_cloud_environment",
    "get_cloud_storage",
    
    # Autonomous Dataset Generation
    "AutonomousDatasetGenerator",
    "AutonomousFineTuner",
    
    # Swarm Training
    "SaaraSwarm",
    "run_swarm_wizard",
]

