"""
SAARA Model Hub: HuggingFace Integration

Automatically push models and datasets to HuggingFace Hub for:
- Cloud-friendly storage (no local files needed)
- Easy sharing and collaboration
- Version control with Git LFS
- One-line model loading with from_pretrained()

© 2024-2026 Kilani Sai Nikhil. All Rights Reserved.
"""

import os
import json
import shutil
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List, Union
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)

# HuggingFace Hub configuration
HF_NAMESPACE_PREFIX = "saara"
MODEL_CARD_TEMPLATE = """---
license: apache-2.0
tags:
- saara
- {tags}
library_name: transformers
pipeline_tag: text-generation
---

# {model_name}

This model was trained using [SAARA](https://github.com/nikhil49023/Data-engine) - Autonomous Document-to-LLM Data Engine.

## Model Details

- **Base Model**: {base_model}
- **Training Date**: {date}
- **Domain**: {domain}
- **Parameters**: {params}

## Training Configuration

{training_config}

## Usage

```python
from transformers import AutoModelForCausalLM, AutoTokenizer

model = AutoModelForCausalLM.from_pretrained("{repo_id}")
tokenizer = AutoTokenizer.from_pretrained("{repo_id}")

# Generate text
inputs = tokenizer("Hello, ", return_tensors="pt")
outputs = model.generate(**inputs, max_new_tokens=50)
print(tokenizer.decode(outputs[0]))
```

## Training Metrics

{metrics}

---
*Trained with SAARA - ज्ञानस्य सारः (The Essence of Knowledge)*
"""

DATASET_CARD_TEMPLATE = """---
license: apache-2.0
tags:
- saara
- {tags}
task_categories:
- text-generation
- question-answering
language:
- en
size_categories:
- {size_category}
---

# {dataset_name}

Dataset generated using [SAARA](https://github.com/nikhil49023/Data-engine) - Autonomous Document-to-LLM Data Engine.

## Dataset Details

- **Created**: {date}
- **Samples**: {num_samples}
- **Format**: {format}
- **Domain**: {domain}

## Dataset Structure

{structure}

## Usage

```python
from datasets import load_dataset

dataset = load_dataset("{repo_id}")
print(dataset)
```

## Sample

```json
{sample}
```

---
*Generated with SAARA - ज्ञानस्य सारः (The Essence of Knowledge)*
"""


@dataclass
class HubConfig:
    """Configuration for HuggingFace Hub integration."""
    token: Optional[str] = None
    username: Optional[str] = None
    auto_push_models: bool = True
    auto_push_datasets: bool = True
    private_repos: bool = False
    model_prefix: str = "saara-model"
    dataset_prefix: str = "saara-dataset"


class ModelHub:
    """
    HuggingFace Hub integration for SAARA.
    
    Features:
    - Automatic repo creation
    - Model and dataset pushing
    - Model cards and dataset cards
    - Version control
    - Private/public repos
    """
    
    def __init__(self, console=None, token: Optional[str] = None):
        """
        Initialize the Model Hub.
        
        Args:
            console: Rich console for output
            token: HuggingFace token (or uses HF_TOKEN env var)
        """
        if console is None:
            from rich.console import Console
            console = Console()
        
        self.console = console
        self.config = self._load_config()
        
        # Set token from parameter, config, or environment
        self.token = token or self.config.token or os.environ.get("HF_TOKEN") or os.environ.get("HUGGINGFACE_TOKEN")
        
        # Check if huggingface_hub is available
        self._hub_available = self._check_hub()
        self._api = None
        self._username = None
    
    def _check_hub(self) -> bool:
        """Check if huggingface_hub is installed."""
        try:
            import huggingface_hub
            return True
        except ImportError:
            return False
    
    def _load_config(self) -> HubConfig:
        """Load hub configuration from file."""
        config_path = Path.home() / ".saara" / "hub_config.json"
        
        if config_path.exists():
            try:
                with open(config_path) as f:
                    data = json.load(f)
                return HubConfig(**data)
            except Exception as e:
                logger.warning(f"Failed to load hub config: {e}")
        
        return HubConfig()
    
    def _save_config(self):
        """Save hub configuration to file."""
        config_path = Path.home() / ".saara" / "hub_config.json"
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(config_path, "w") as f:
            json.dump({
                "token": self.config.token,
                "username": self.config.username,
                "auto_push_models": self.config.auto_push_models,
                "auto_push_datasets": self.config.auto_push_datasets,
                "private_repos": self.config.private_repos,
                "model_prefix": self.config.model_prefix,
                "dataset_prefix": self.config.dataset_prefix,
            }, f, indent=2)
    
    def _get_api(self):
        """Get the HuggingFace API instance."""
        if not self._hub_available:
            raise ImportError(
                "huggingface_hub not installed. Run: pip install huggingface_hub"
            )
        
        if self._api is None:
            from huggingface_hub import HfApi
            self._api = HfApi(token=self.token)
        
        return self._api
    
    def is_authenticated(self) -> bool:
        """Check if we're authenticated with HuggingFace."""
        if not self.token:
            return False
        
        try:
            api = self._get_api()
            user = api.whoami()
            self._username = user.get("name", user.get("fullname", "unknown"))
            self.config.username = self._username
            return True
        except Exception:
            return False
    
    def login(self, token: Optional[str] = None) -> bool:
        """
        Login to HuggingFace Hub.
        
        Args:
            token: HuggingFace token (will prompt if not provided)
        
        Returns:
            True if login successful
        """
        from rich.panel import Panel
        from rich.prompt import Prompt
        
        if not self._hub_available:
            self.console.print("[red]huggingface_hub not installed.[/red]")
            self.console.print("[dim]Run: pip install huggingface_hub[/dim]")
            return False
        
        self.console.print(Panel.fit(
            "[bold cyan]🤗 HuggingFace Hub Login[/bold cyan]\n\n"
            "To push models and datasets to HuggingFace Hub,\n"
            "you need a HuggingFace account and access token.\n\n"
            "[dim]Get your token at: https://huggingface.co/settings/tokens[/dim]",
            title="Authentication",
            border_style="cyan"
        ))
        
        if not token:
            token = Prompt.ask("Enter your HuggingFace token", password=True)
        
        self.token = token
        self.config.token = token
        
        if self.is_authenticated():
            self._save_config()
            self.console.print(f"[green]✅ Logged in as: {self._username}[/green]")
            return True
        else:
            self.console.print("[red]❌ Invalid token[/red]")
            return False
    
    def logout(self):
        """Logout from HuggingFace Hub."""
        self.token = None
        self.config.token = None
        self._username = None
        self._api = None
        self._save_config()
        self.console.print("[yellow]Logged out from HuggingFace Hub[/yellow]")
    
    def get_username(self) -> Optional[str]:
        """Get the current username."""
        if self._username:
            return self._username
        
        if self.is_authenticated():
            return self._username
        
        return None
    
    def create_repo(
        self,
        name: str,
        repo_type: str = "model",  # "model" or "dataset"
        private: bool = False,
        exist_ok: bool = True
    ) -> str:
        """
        Create a new repository on HuggingFace Hub.
        
        Args:
            name: Repository name (without username prefix)
            repo_type: "model" or "dataset"
            private: Whether the repo should be private
            exist_ok: If True, don't error if repo exists
        
        Returns:
            Full repo ID (username/name)
        """
        if not self.is_authenticated():
            raise ValueError("Not authenticated. Run login() first.")
        
        api = self._get_api()
        username = self.get_username()
        
        repo_id = f"{username}/{name}"
        
        try:
            api.create_repo(
                repo_id=repo_id,
                repo_type=repo_type,
                private=private or self.config.private_repos,
                exist_ok=exist_ok
            )
            self.console.print(f"[green]✅ Created repo: {repo_id}[/green]")
        except Exception as e:
            if "already exists" in str(e).lower():
                self.console.print(f"[dim]Repo already exists: {repo_id}[/dim]")
            else:
                raise
        
        return repo_id
    
    def push_model(
        self,
        model_path: Union[str, Path],
        repo_name: Optional[str] = None,
        base_model: str = "unknown",
        domain: str = "general",
        training_config: Optional[Dict] = None,
        metrics: Optional[Dict] = None,
        private: bool = False,
        commit_message: str = "Update model"
    ) -> str:
        """
        Push a model to HuggingFace Hub.
        
        Args:
            model_path: Local path to the model directory
            repo_name: Name for the repo (auto-generated if None)
            base_model: Name of the base model used
            domain: Domain/task of the model
            training_config: Training configuration dict
            metrics: Training metrics dict
            private: Whether the repo should be private
            commit_message: Git commit message
        
        Returns:
            Full repo ID
        """
        from rich.progress import Progress, SpinnerColumn, TextColumn
        
        model_path = Path(model_path)
        
        if not model_path.exists():
            raise FileNotFoundError(f"Model path not found: {model_path}")
        
        # Generate repo name if not provided
        if not repo_name:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            repo_name = f"{self.config.model_prefix}-{model_path.name}-{timestamp}"
        
        # Create the repo
        repo_id = self.create_repo(repo_name, repo_type="model", private=private)
        
        # Create model card
        self._create_model_card(
            model_path, repo_id, base_model, domain,
            training_config or {}, metrics or {}
        )
        
        # Upload the model
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console
        ) as progress:
            task = progress.add_task("Uploading model to HuggingFace Hub...", total=None)
            
            api = self._get_api()
            api.upload_folder(
                folder_path=str(model_path),
                repo_id=repo_id,
                repo_type="model",
                commit_message=commit_message
            )
            
            progress.update(task, description="✅ Model uploaded!")
        
        url = f"https://huggingface.co/{repo_id}"
        self.console.print(f"\n[bold green]🎉 Model pushed successfully![/bold green]")
        self.console.print(f"[blue]🔗 {url}[/blue]")
        
        return repo_id
    
    def _create_model_card(
        self,
        model_path: Path,
        repo_id: str,
        base_model: str,
        domain: str,
        training_config: Dict,
        metrics: Dict
    ):
        """Create a model card (README.md) for the model."""
        
        # Calculate model size
        total_size = sum(f.stat().st_size for f in model_path.rglob("*") if f.is_file())
        size_mb = total_size / (1024 * 1024)
        
        # Format training config
        config_str = ""
        for key, value in training_config.items():
            config_str += f"- **{key}**: {value}\n"
        
        # Format metrics
        metrics_str = ""
        for key, value in metrics.items():
            if isinstance(value, float):
                metrics_str += f"- **{key}**: {value:.4f}\n"
            else:
                metrics_str += f"- **{key}**: {value}\n"
        
        card = MODEL_CARD_TEMPLATE.format(
            model_name=model_path.name,
            base_model=base_model,
            date=datetime.now().strftime("%Y-%m-%d"),
            domain=domain,
            params=f"{size_mb:.1f} MB",
            training_config=config_str or "Not available",
            metrics=metrics_str or "Not available",
            repo_id=repo_id,
            tags=domain.lower().replace(" ", "-")
        )
        
        readme_path = model_path / "README.md"
        with open(readme_path, "w", encoding="utf-8") as f:
            f.write(card)
    
    def push_dataset(
        self,
        dataset_path: Union[str, Path],
        repo_name: Optional[str] = None,
        domain: str = "general",
        format: str = "jsonl",
        private: bool = False,
        commit_message: str = "Update dataset"
    ) -> str:
        """
        Push a dataset to HuggingFace Hub.
        
        Args:
            dataset_path: Local path to dataset file or directory
            repo_name: Name for the repo (auto-generated if None)
            domain: Domain/topic of the dataset
            format: Dataset format (jsonl, csv, parquet)
            private: Whether the repo should be private
            commit_message: Git commit message
        
        Returns:
            Full repo ID
        """
        from rich.progress import Progress, SpinnerColumn, TextColumn
        
        dataset_path = Path(dataset_path)
        
        if not dataset_path.exists():
            raise FileNotFoundError(f"Dataset path not found: {dataset_path}")
        
        # Generate repo name if not provided
        if not repo_name:
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            name = dataset_path.stem if dataset_path.is_file() else dataset_path.name
            repo_name = f"{self.config.dataset_prefix}-{name}-{timestamp}"
        
        # Create the repo
        repo_id = self.create_repo(repo_name, repo_type="dataset", private=private)
        
        # Prepare upload folder
        if dataset_path.is_file():
            # Create a temp folder with the file
            temp_dir = dataset_path.parent / f".{dataset_path.stem}_upload"
            temp_dir.mkdir(exist_ok=True)
            shutil.copy(dataset_path, temp_dir / dataset_path.name)
            upload_path = temp_dir
            cleanup = True
        else:
            upload_path = dataset_path
            cleanup = False
        
        try:
            # Create dataset card
            self._create_dataset_card(upload_path, repo_id, domain, format, dataset_path)
            
            # Upload the dataset
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=self.console
            ) as progress:
                task = progress.add_task("Uploading dataset to HuggingFace Hub...", total=None)
                
                api = self._get_api()
                api.upload_folder(
                    folder_path=str(upload_path),
                    repo_id=repo_id,
                    repo_type="dataset",
                    commit_message=commit_message
                )
                
                progress.update(task, description="✅ Dataset uploaded!")
        finally:
            if cleanup and temp_dir.exists():
                shutil.rmtree(temp_dir)
        
        url = f"https://huggingface.co/datasets/{repo_id}"
        self.console.print(f"\n[bold green]🎉 Dataset pushed successfully![/bold green]")
        self.console.print(f"[blue]🔗 {url}[/blue]")
        
        return repo_id
    
    def _create_dataset_card(
        self,
        upload_path: Path,
        repo_id: str,
        domain: str,
        format: str,
        original_path: Path
    ):
        """Create a dataset card (README.md) for the dataset."""
        
        # Count samples and get size
        num_samples = 0
        sample = {}
        
        # Find data files
        data_files = list(upload_path.glob("*.jsonl")) + list(upload_path.glob("*.json"))
        if data_files:
            with open(data_files[0], encoding="utf-8") as f:
                for i, line in enumerate(f):
                    if i == 0:
                        try:
                            sample = json.loads(line)
                        except:
                            sample = {"error": "Could not parse sample"}
                    num_samples = i + 1
        
        # Size category
        if num_samples < 1000:
            size_cat = "n<1K"
        elif num_samples < 10000:
            size_cat = "1K<n<10K"
        elif num_samples < 100000:
            size_cat = "10K<n<100K"
        else:
            size_cat = "100K<n<1M"
        
        # Structure description
        if sample:
            structure = "### Fields\n\n"
            for key in sample.keys():
                structure += f"- `{key}`: {type(sample[key]).__name__}\n"
        else:
            structure = "See data files for structure."
        
        card = DATASET_CARD_TEMPLATE.format(
            dataset_name=original_path.stem,
            date=datetime.now().strftime("%Y-%m-%d"),
            num_samples=f"{num_samples:,}",
            format=format.upper(),
            domain=domain,
            structure=structure,
            repo_id=repo_id,
            sample=json.dumps(sample, indent=2, ensure_ascii=False)[:500],
            size_category=size_cat,
            tags=domain.lower().replace(" ", "-")
        )
        
        readme_path = upload_path / "README.md"
        with open(readme_path, "w", encoding="utf-8") as f:
            f.write(card)
    
    def list_my_repos(self, repo_type: str = "model") -> List[Dict]:
        """
        List all repos owned by the current user.
        
        Args:
            repo_type: "model" or "dataset"
        
        Returns:
            List of repo info dicts
        """
        if not self.is_authenticated():
            return []
        
        api = self._get_api()
        username = self.get_username()
        
        try:
            if repo_type == "model":
                repos = api.list_models(author=username)
            else:
                repos = api.list_datasets(author=username)
            
            return [
                {
                    "id": repo.id,
                    "private": getattr(repo, "private", False),
                    "downloads": getattr(repo, "downloads", 0),
                    "likes": getattr(repo, "likes", 0),
                    "last_modified": str(getattr(repo, "last_modified", ""))
                }
                for repo in repos
            ]
        except Exception as e:
            logger.error(f"Failed to list repos: {e}")
            return []
    
    def delete_repo(self, repo_id: str, repo_type: str = "model") -> bool:
        """
        Delete a repository.
        
        Args:
            repo_id: Full repo ID (username/name)
            repo_type: "model" or "dataset"
        
        Returns:
            True if deleted successfully
        """
        if not self.is_authenticated():
            return False
        
        try:
            api = self._get_api()
            api.delete_repo(repo_id=repo_id, repo_type=repo_type)
            self.console.print(f"[green]✅ Deleted: {repo_id}[/green]")
            return True
        except Exception as e:
            self.console.print(f"[red]Failed to delete: {e}[/red]")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """Get current hub status."""
        authenticated = self.is_authenticated()
        
        return {
            "authenticated": authenticated,
            "username": self._username if authenticated else None,
            "hub_available": self._hub_available,
            "auto_push_models": self.config.auto_push_models,
            "auto_push_datasets": self.config.auto_push_datasets,
            "private_repos": self.config.private_repos
        }
    
    def configure(
        self,
        auto_push_models: Optional[bool] = None,
        auto_push_datasets: Optional[bool] = None,
        private_repos: Optional[bool] = None,
        model_prefix: Optional[str] = None,
        dataset_prefix: Optional[str] = None
    ):
        """
        Configure hub settings.
        
        Args:
            auto_push_models: Auto-push models after training
            auto_push_datasets: Auto-push datasets after generation
            private_repos: Make repos private by default
            model_prefix: Prefix for model repo names
            dataset_prefix: Prefix for dataset repo names
        """
        if auto_push_models is not None:
            self.config.auto_push_models = auto_push_models
        if auto_push_datasets is not None:
            self.config.auto_push_datasets = auto_push_datasets
        if private_repos is not None:
            self.config.private_repos = private_repos
        if model_prefix is not None:
            self.config.model_prefix = model_prefix
        if dataset_prefix is not None:
            self.config.dataset_prefix = dataset_prefix
        
        self._save_config()
        self.console.print("[green]✅ Hub settings saved[/green]")


def run_hub_wizard(console=None) -> Optional[ModelHub]:
    """
    Interactive wizard for HuggingFace Hub setup.
    """
    if console is None:
        from rich.console import Console
        console = Console()
    
    from rich.panel import Panel
    from rich.prompt import Prompt, Confirm
    from rich.table import Table
    
    hub = ModelHub(console)
    
    console.print(Panel.fit(
        "[bold cyan]🤗 HuggingFace Hub Integration[/bold cyan]\n\n"
        "Push your models and datasets to HuggingFace Hub for:\n"
        "• Cloud-friendly storage\n"
        "• Easy sharing with the community\n"
        "• Version control\n"
        "• One-line loading: `from_pretrained()`",
        title="Model Hub Setup",
        border_style="cyan"
    ))
    
    # Check current status
    status = hub.get_status()
    
    console.print("\n[bold]Current Status:[/bold]")
    if status["authenticated"]:
        console.print(f"  [green]✓ Logged in as: {status['username']}[/green]")
    else:
        console.print("  [yellow]○ Not logged in[/yellow]")
    
    console.print(f"  Auto-push models: {'✓' if status['auto_push_models'] else '✗'}")
    console.print(f"  Auto-push datasets: {'✓' if status['auto_push_datasets'] else '✗'}")
    console.print(f"  Private repos: {'✓' if status['private_repos'] else '✗'}")
    
    console.print("\n[bold]Options:[/bold]")
    console.print("  1. 🔑 Login to HuggingFace")
    console.print("  2. 📤 Push a model")
    console.print("  3. 📊 Push a dataset")
    console.print("  4. 📋 List my repos")
    console.print("  5. ⚙️  Configure settings")
    console.print("  6. 🚪 Logout")
    console.print("  7. ⬅️  Back")
    
    choice = Prompt.ask("Select option", choices=["1", "2", "3", "4", "5", "6", "7"], default="1")
    
    if choice == "1":
        hub.login()
        return hub
    
    elif choice == "2":
        if not hub.is_authenticated():
            console.print("[yellow]Please login first[/yellow]")
            hub.login()
        
        model_path = Prompt.ask("Model path", default="models/")
        base_model = Prompt.ask("Base model used", default="unknown")
        domain = Prompt.ask("Domain/task", default="general")
        private = Confirm.ask("Private repo?", default=False)
        
        hub.push_model(model_path, base_model=base_model, domain=domain, private=private)
        return hub
    
    elif choice == "3":
        if not hub.is_authenticated():
            console.print("[yellow]Please login first[/yellow]")
            hub.login()
        
        dataset_path = Prompt.ask("Dataset path", default="datasets/")
        domain = Prompt.ask("Domain/topic", default="general")
        private = Confirm.ask("Private repo?", default=False)
        
        hub.push_dataset(dataset_path, domain=domain, private=private)
        return hub
    
    elif choice == "4":
        if not hub.is_authenticated():
            console.print("[yellow]Not logged in[/yellow]")
            return hub
        
        console.print("\n[bold]My Models:[/bold]")
        models = hub.list_my_repos("model")
        for m in models[:10]:
            console.print(f"  • {m['id']} (↓{m['downloads']} ❤️{m['likes']})")
        
        console.print("\n[bold]My Datasets:[/bold]")
        datasets = hub.list_my_repos("dataset")
        for d in datasets[:10]:
            console.print(f"  • {d['id']} (↓{d['downloads']})")
        
        return hub
    
    elif choice == "5":
        console.print("\n[bold]Configure Hub Settings[/bold]\n")
        
        auto_models = Confirm.ask("Auto-push models after training?", default=True)
        auto_datasets = Confirm.ask("Auto-push datasets after generation?", default=True)
        private = Confirm.ask("Make repos private by default?", default=False)
        
        hub.configure(
            auto_push_models=auto_models,
            auto_push_datasets=auto_datasets,
            private_repos=private
        )
        return hub
    
    elif choice == "6":
        hub.logout()
        return hub
    
    return hub


# Utility functions for easy integration

def push_model_to_hub(
    model_path: str,
    repo_name: Optional[str] = None,
    token: Optional[str] = None,
    **kwargs
) -> Optional[str]:
    """
    Quick function to push a model to HuggingFace Hub.
    
    Args:
        model_path: Path to model directory
        repo_name: Repository name (auto-generated if None)
        token: HuggingFace token (uses saved token if None)
        **kwargs: Additional arguments for push_model()
    
    Returns:
        Repo ID if successful, None otherwise
    """
    try:
        hub = ModelHub(token=token)
        if not hub.is_authenticated():
            print("Not authenticated with HuggingFace. Please login first.")
            return None
        return hub.push_model(model_path, repo_name=repo_name, **kwargs)
    except Exception as e:
        print(f"Failed to push model: {e}")
        return None


def push_dataset_to_hub(
    dataset_path: str,
    repo_name: Optional[str] = None,
    token: Optional[str] = None,
    **kwargs
) -> Optional[str]:
    """
    Quick function to push a dataset to HuggingFace Hub.
    
    Args:
        dataset_path: Path to dataset file/directory
        repo_name: Repository name (auto-generated if None)
        token: HuggingFace token (uses saved token if None)
        **kwargs: Additional arguments for push_dataset()
    
    Returns:
        Repo ID if successful, None otherwise
    """
    try:
        hub = ModelHub(token=token)
        if not hub.is_authenticated():
            print("Not authenticated with HuggingFace. Please login first.")
            return None
        return hub.push_dataset(dataset_path, repo_name=repo_name, **kwargs)
    except Exception as e:
        print(f"Failed to push dataset: {e}")
        return None


def get_hub_status() -> Dict[str, Any]:
    """Get current HuggingFace Hub status."""
    hub = ModelHub()
    return hub.get_status()
