"""CLI tests for tmuxp."""
