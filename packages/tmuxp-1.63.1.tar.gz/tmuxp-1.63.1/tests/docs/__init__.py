"""Tests for documentation extensions."""
