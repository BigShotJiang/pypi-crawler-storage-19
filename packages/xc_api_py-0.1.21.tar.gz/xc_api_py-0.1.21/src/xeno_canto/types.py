from typing import Literal
from enum import IntEnum


class XcQualityRating(IntEnum):
  A = 1  # Best
  B = 2
  C = 3
  D = 4
  E = 5  # Worst


Area = Literal[
  'africa',
  'america',
  'asia',
  'australia',
  'europe',
]

Sex = Literal[
  'male',
  'female',
]

LifeStage = Literal[
  'adult',
  'juvenile',
  'nestling',
  'nymph',
  'subadult',
]

RecordingMethod = Literal[
  'emerging from roost',
  'field recording',
  'fluorescent light tag',
  'hand-release',
  'in enclosure',
  'in net',
  'in the hand',
  'roosting',
  'roped',
  'studio recording',
]

Group = Literal[
  'grasshoppers',
  'bats',
  'birds',
  'frogs',
  'land mammals',
]

SoundType = Literal[
  'aberrant',
  'advertisement call',
  'agonistic call',
  'alarm call',
  'begging call',
  'call',
  'calling song',
  'courtship song',
  'dawn song',
  'defensive call',
  'distress call',
  'disturbance song',
  'drumming',
  'duet',
  'echolocation',
  'feeding buzz',
  'female song',
  'flight call',
  'flight song',
  'imitation',
  'mating call',
  'mechanical sound',
  'nocturnal flight call',
  'release call',
  'rivalry song',
  'searching song',
  'social call',
  'song',
  'subsong',
  'territorial call',
]
