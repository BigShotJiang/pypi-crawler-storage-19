import os
import sys
import warnings
import snowflake.connector
import pandas as pd
import polars as pl
import tableauserverclient as TSC
import io


def leitura_snowflake(
    email_corporativo: str,
    token_account: str,
    query: str
) -> pl.DataFrame:
    """
    Executa uma query no Snowflake e retorna um DataFrame Polars.

    Parâmetros
    ----------
    email_corporativo : str
        Email corporativo usado no login (externalbrowser)
    token_account : str
        Account do Snowflake
    query : str
        Query SQL a ser executada

    Retorno
    -------
    pl.DataFrame
    """

    warnings.filterwarnings("ignore", message=".*keyring.*")

    sys_stdout, sys_stderr = sys.stdout, sys.stderr

    try:
        sys.stdout = open(os.devnull, 'w')
        sys.stderr = open(os.devnull, 'w')

        conn = snowflake.connector.connect(
            user=email_corporativo,
            account=token_account,
            database='MAXPAR',
            schema='ESTATISTICA',
            role='GL_SNOWFLAKE_ACESSO_MAX_CED_DADOS',
            warehouse='WH_USE_CED',
            authenticator='externalbrowser',
            network_timeout=600
        )

        cursor = conn.cursor()
        try:
            cursor.execute(query)

            # 🔥 Snowflake -> Arrow -> Polars
            arrow_table = cursor.fetch_arrow_all()
            df = pl.from_arrow(arrow_table)

        finally:
            cursor.close()

    finally:
        sys.stdout.close()
        sys.stderr.close()
        sys.stdout, sys.stderr = sys_stdout, sys_stderr

        try:
            conn.close()
        except Exception:
            pass

    return df



def leitura_tableau(
    nome_token: str,
    token_acesso: str,
    view_id: str
) -> pl.DataFrame:
    """
    Lê uma view do Tableau Server e retorna um DataFrame Polars.

    Parâmetros
    ----------
    nome_token : str
        Nome do Personal Access Token do Tableau
    token_acesso : str
        Token de acesso pessoal do Tableau
    view_id : str
        ID da view no Tableau Server

    Retorno
    -------
    pl.DataFrame
    """

    warnings.filterwarnings("ignore")

    def tentar_conectar(url: str):
        tableau_auth = TSC.PersonalAccessTokenAuth(
            token_name=nome_token,
            personal_access_token=token_acesso,
            site_id=""
        )
        server = TSC.Server(url, use_server_version=True)
        server.auth.sign_in(tableau_auth)
        return server

    server = None
    try:
        try:
            server = tentar_conectar("http://tableau.autoglass.com.br/")
        except Exception:
            server = tentar_conectar("https://tableau.autoglass.com.br/")

        if server is None:
            raise ConnectionError("Não foi possível conectar ao Tableau Server.")

        # Obter view
        view_item = server.views.get_by_id(view_id)

        # Exportar CSV da view
        server.views.populate_csv(view_item)

        csv_bytes = b"".join(view_item.csv)

        # CSV → Polars (via Arrow)
        df = pl.read_csv(io.BytesIO(csv_bytes))

        return df

    finally:
        if server:
            server.auth.sign_out()
