from __future__ import annotations

from typing import Any, Callable

def create_agent(*args: Any, **kwargs: Any) -> Callable[..., Any]:
    raise RuntimeError("create_agent is a contract shim. Execution happens server-side.")

__all__ = ["create_agent"]
