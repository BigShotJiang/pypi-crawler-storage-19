from __future__ import annotations

from typing import Any, List, Mapping, Sequence

AnyMessage = Mapping[str, Any]

def add_messages(left: Sequence[AnyMessage], right: Sequence[AnyMessage]) -> List[AnyMessage]:
    return list(left) + list(right)

__all__ = ["AnyMessage", "add_messages"]
