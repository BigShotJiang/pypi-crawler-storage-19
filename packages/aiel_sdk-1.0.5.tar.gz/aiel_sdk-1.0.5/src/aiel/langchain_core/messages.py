from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

@dataclass
class ToolMessage:
    content: str
    tool_call_id: str
    name: Optional[str] = None
    additional_kwargs: Dict[str, Any] | None = None

__all__ = ["ToolMessage"]
