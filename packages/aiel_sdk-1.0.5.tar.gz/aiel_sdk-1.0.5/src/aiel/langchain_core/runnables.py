from __future__ import annotations

from typing import Any, Callable, Optional

from aiel_sdk.sdk.langchain_shim import RunnableConfig

class RunnableLambda:
    def __init__(self, fn: Callable[[Any], Any]):
        self._fn = fn

    def invoke(self, input: Any, config: Optional[RunnableConfig] = None) -> Any:
        return self._fn(input)

__all__ = ["RunnableLambda"]
