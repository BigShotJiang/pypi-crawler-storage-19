"""
Permissions checks for the Doctor CLI module.

Validates filesystem permissions for OverAI directories.
"""

import os
import tempfile
from pathlib import Path

from ..models import (
    CheckCategory,
    CheckResult,
    CheckStatus,
    CheckSeverity,
    DoctorConfig,
)
from ..registry import register_check


def _check_dir_writable(path: Path) -> tuple:
    """Check if a directory is writable."""
    try:
        if not path.exists():
            return False, "does not exist"
        
        if not path.is_dir():
            return False, "not a directory"
        
        # Try to create a temp file
        test_file = path / ".overai_write_test"
        try:
            test_file.write_text("test")
            test_file.unlink()
            return True, "writable"
        except PermissionError:
            return False, "permission denied"
        except Exception as e:
            return False, str(e)
    except Exception as e:
        return False, str(e)


@register_check(
    id="permissions_home_overai",
    title="~/.overai Directory",
    description="Check ~/.overai directory permissions",
    category=CheckCategory.PERMISSIONS,
    severity=CheckSeverity.MEDIUM,
)
def check_permissions_home_overai(config: DoctorConfig) -> CheckResult:
    """Check ~/.overai directory permissions."""
    overai_dir = Path.home() / ".overai"
    
    if not overai_dir.exists():
        # Try to create it
        try:
            overai_dir.mkdir(parents=True, exist_ok=True)
            return CheckResult(
                id="permissions_home_overai",
                title="~/.overai Directory",
                category=CheckCategory.PERMISSIONS,
                status=CheckStatus.PASS,
                message="~/.overai created successfully",
                metadata={"path": str(overai_dir)},
            )
        except PermissionError:
            return CheckResult(
                id="permissions_home_overai",
                title="~/.overai Directory",
                category=CheckCategory.PERMISSIONS,
                status=CheckStatus.FAIL,
                message="Cannot create ~/.overai directory",
                remediation="Check home directory permissions",
                severity=CheckSeverity.HIGH,
            )
    
    writable, reason = _check_dir_writable(overai_dir)
    
    if writable:
        return CheckResult(
            id="permissions_home_overai",
            title="~/.overai Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.PASS,
            message=f"~/.overai is writable",
            metadata={"path": str(overai_dir)},
        )
    else:
        return CheckResult(
            id="permissions_home_overai",
            title="~/.overai Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.FAIL,
            message=f"~/.overai is not writable: {reason}",
            remediation="Fix permissions: chmod 755 ~/.overai",
            severity=CheckSeverity.HIGH,
        )


@register_check(
    id="permissions_project_overai",
    title=".overai Directory (Project)",
    description="Check project .overai directory permissions",
    category=CheckCategory.PERMISSIONS,
    severity=CheckSeverity.LOW,
)
def check_permissions_project_overai(config: DoctorConfig) -> CheckResult:
    """Check project .overai directory permissions."""
    overai_dir = Path.cwd() / ".overai"
    
    if not overai_dir.exists():
        return CheckResult(
            id="permissions_project_overai",
            title=".overai Directory (Project)",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.SKIP,
            message="No .overai directory in current project",
        )
    
    writable, reason = _check_dir_writable(overai_dir)
    
    if writable:
        return CheckResult(
            id="permissions_project_overai",
            title=".overai Directory (Project)",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.PASS,
            message=".overai is writable",
            metadata={"path": str(overai_dir)},
        )
    else:
        return CheckResult(
            id="permissions_project_overai",
            title=".overai Directory (Project)",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.WARN,
            message=f".overai is not writable: {reason}",
            remediation="Fix permissions or use ~/.overai instead",
        )


@register_check(
    id="permissions_temp_dir",
    title="Temp Directory",
    description="Check temp directory permissions",
    category=CheckCategory.PERMISSIONS,
    severity=CheckSeverity.MEDIUM,
)
def check_permissions_temp_dir(config: DoctorConfig) -> CheckResult:
    """Check temp directory permissions."""
    temp_dir = Path(tempfile.gettempdir())
    
    try:
        # Try to create a temp file
        with tempfile.NamedTemporaryFile(delete=True) as f:
            f.write(b"test")
        
        return CheckResult(
            id="permissions_temp_dir",
            title="Temp Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.PASS,
            message=f"Temp directory writable: {temp_dir}",
            metadata={"path": str(temp_dir)},
        )
    except Exception as e:
        return CheckResult(
            id="permissions_temp_dir",
            title="Temp Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.FAIL,
            message=f"Temp directory not writable: {e}",
            remediation="Check TMPDIR environment variable and permissions",
            severity=CheckSeverity.HIGH,
        )


@register_check(
    id="permissions_cwd",
    title="Current Working Directory",
    description="Check current directory permissions",
    category=CheckCategory.PERMISSIONS,
    severity=CheckSeverity.INFO,
)
def check_permissions_cwd(config: DoctorConfig) -> CheckResult:
    """Check current directory permissions."""
    cwd = Path.cwd()
    
    writable, reason = _check_dir_writable(cwd)
    
    if writable:
        return CheckResult(
            id="permissions_cwd",
            title="Current Working Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.PASS,
            message=f"Current directory writable: {cwd}",
        )
    else:
        return CheckResult(
            id="permissions_cwd",
            title="Current Working Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.WARN,
            message=f"Current directory not writable: {reason}",
            details="Some features may not work without write access",
        )


@register_check(
    id="permissions_config_dir",
    title="Config Directory",
    description="Check ~/.config/overai directory",
    category=CheckCategory.PERMISSIONS,
    severity=CheckSeverity.LOW,
)
def check_permissions_config_dir(config: DoctorConfig) -> CheckResult:
    """Check ~/.config/overai directory."""
    config_dir = Path.home() / ".config" / "overai"
    
    if not config_dir.exists():
        # Check if we can create it
        try:
            config_dir.mkdir(parents=True, exist_ok=True)
            return CheckResult(
                id="permissions_config_dir",
                title="Config Directory",
                category=CheckCategory.PERMISSIONS,
                status=CheckStatus.PASS,
                message="~/.config/overai created successfully",
            )
        except Exception:
            return CheckResult(
                id="permissions_config_dir",
                title="Config Directory",
                category=CheckCategory.PERMISSIONS,
                status=CheckStatus.SKIP,
                message="~/.config/overai does not exist (will use ~/.overai)",
            )
    
    writable, reason = _check_dir_writable(config_dir)
    
    if writable:
        return CheckResult(
            id="permissions_config_dir",
            title="Config Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.PASS,
            message="~/.config/overai is writable",
        )
    else:
        return CheckResult(
            id="permissions_config_dir",
            title="Config Directory",
            category=CheckCategory.PERMISSIONS,
            status=CheckStatus.WARN,
            message=f"~/.config/overai not writable: {reason}",
        )
