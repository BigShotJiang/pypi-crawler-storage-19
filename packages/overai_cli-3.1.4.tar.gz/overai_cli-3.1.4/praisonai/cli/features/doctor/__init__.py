"""
Doctor CLI module for OverAI.

Provides comprehensive health checks, diagnostics, and validation for the OverAI ecosystem.

Commands:
    overai doctor              - Run fast default checks
    overai doctor env          - Environment and API key validation
    overai doctor config       - Configuration file validation
    overai doctor tools        - Tool availability checks
    overai doctor db           - Database connectivity checks
    overai doctor mcp          - MCP server validation
    overai doctor obs          - Observability provider checks
    overai doctor skills       - Agent skills validation
    overai doctor memory       - Memory/session storage checks
    overai doctor permissions  - Filesystem permission checks
    overai doctor network      - Network connectivity checks
    overai doctor performance  - Import time analysis
    overai doctor ci           - CI-optimized checks
    overai doctor selftest     - Minimal agent dry-run
"""

__version__ = "1.0.0"

__all__ = [
    "DoctorHandler",
    "DoctorEngine",
    "CheckResult",
    "CheckStatus",
    "DoctorReport",
    "CheckRegistry",
    "TextFormatter",
    "JsonFormatter",
]


def __getattr__(name: str):
    """Lazy load doctor components to minimize import overhead."""
    if name == "DoctorHandler":
        from .handler import DoctorHandler
        return DoctorHandler
    elif name == "DoctorEngine":
        from .engine import DoctorEngine
        return DoctorEngine
    elif name == "CheckResult":
        from .models import CheckResult
        return CheckResult
    elif name == "CheckStatus":
        from .models import CheckStatus
        return CheckStatus
    elif name == "DoctorReport":
        from .models import DoctorReport
        return DoctorReport
    elif name == "CheckRegistry":
        from .registry import CheckRegistry
        return CheckRegistry
    elif name == "TextFormatter":
        from .formatters import TextFormatter
        return TextFormatter
    elif name == "JsonFormatter":
        from .formatters import JsonFormatter
        return JsonFormatter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
