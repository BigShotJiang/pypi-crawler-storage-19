"""
OverAI CLI Package

This package provides the command-line interface for OverAI.

Structure:
- main.py: Main CLI entry point (PraisonAI class)
- features/: Feature handlers for CLI flags and commands
"""

__all__ = ["PraisonAI", "OverAI"]


def __getattr__(name):
    """Lazy load PraisonAI to avoid slow imports."""
    if name == "PraisonAI":
        from .main import PraisonAI
        return PraisonAI
    if name == "OverAI":
        from .main import OverAI
        return OverAI
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def main():
    """CLI entry point function."""
    from .main import OverAI
    over_ai = OverAI()
    over_ai.main()
