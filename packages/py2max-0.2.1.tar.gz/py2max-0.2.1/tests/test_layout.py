from py2max import Patcher
from py2max.core.common import Rect
from py2max.maxref import MAXCLASS_DEFAULTS


def test_layout():
    p = Patcher()
    rect = p._layout_mgr.patcher_rect
    assert isinstance(rect, Rect)
    maxclasses = ["filtergraph~", "ezdac~", "ezadc~"]
    for mc in maxclasses:
        r = p._layout_mgr.get_pos(maxclass=mc)
        assert isinstance(r, Rect)
