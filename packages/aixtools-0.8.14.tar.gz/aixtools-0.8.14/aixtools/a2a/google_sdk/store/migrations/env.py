import os
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

from aixtools.a2a.google_sdk.pydantic_ai_adapter.db.storage import PydanticAIMessage  # noqa
from aixtools.a2a.google_sdk.store.config import POSTGRES_URL
from aixtools.a2a.google_sdk.store.models import BaseModel
from aixtools.logging.logging_config import get_logger

logger = get_logger(__name__)

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config
# Convert asyncpg URL to psycopg2 for Alembic
postgres_url_sync = POSTGRES_URL.replace("postgresql+asyncpg://", "postgresql+psycopg2://")
logger.info(f"Using database URL for migrations: {postgres_url_sync}")
config.set_main_option("sqlalchemy.url", postgres_url_sync)

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
target_metadata = BaseModel.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    url = config.get_main_option("sqlalchemy.url")
    # Override with environment variable if set
    if os.environ.get("DATABASE_URL"):
        url = os.environ["DATABASE_URL"]

    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    configuration = config.get_section(config.config_ini_section, {})

    # Override with environment variable if set
    if os.environ.get("DATABASE_URL"):
        configuration["sqlalchemy.url"] = os.environ["DATABASE_URL"]

    configuration["sqlalchemy.connect_args"] = {
        "gssencmode": "disable",
    }

    connectable = engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
