# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class BackupInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'instance_id': 'str',
        'name': 'str',
        'description': 'str',
        'databases': 'list[BackupDatabase]',
        'begin_time': 'str',
        'status': 'str',
        'type': 'str'
    }

    attribute_map = {
        'id': 'id',
        'instance_id': 'instance_id',
        'name': 'name',
        'description': 'description',
        'databases': 'databases',
        'begin_time': 'begin_time',
        'status': 'status',
        'type': 'type'
    }

    def __init__(self, id=None, instance_id=None, name=None, description=None, databases=None, begin_time=None, status=None, type=None):
        r"""BackupInfo

        The model defined in huaweicloud sdk

        :param id: 备份ID。
        :type id: str
        :param instance_id: 实例ID。
        :type instance_id: str
        :param name: 备份名称。
        :type name: str
        :param description: 备份描述。
        :type description: str
        :param databases: 只支持Microsoft SQL Server，局部备份的用户自建数据库名列表，当有此参数时以局部备份为准。
        :type databases: list[:class:`huaweicloudsdkrds.v3.BackupDatabase`]
        :param begin_time: 备份开始时间，格式为“yyyy-mm-ddThh:mm:ssZ”。  其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。
        :type begin_time: str
        :param status: 备份状态，取值：  - BUILDING: 备份中。 - COMPLETED: 备份完成。 - FAILED：备份失败。 - DELETING：备份删除中。
        :type status: str
        :param type: 备份类型，取值：  - “auto”: 自动全量备份 - “manual”: 手动全量备份 - “fragment”: 差异全量备份 - “incremental”: 自动增量备份
        :type type: str
        """
        
        

        self._id = None
        self._instance_id = None
        self._name = None
        self._description = None
        self._databases = None
        self._begin_time = None
        self._status = None
        self._type = None
        self.discriminator = None

        self.id = id
        self.instance_id = instance_id
        self.name = name
        if description is not None:
            self.description = description
        if databases is not None:
            self.databases = databases
        self.begin_time = begin_time
        self.status = status
        self.type = type

    @property
    def id(self):
        r"""Gets the id of this BackupInfo.

        备份ID。

        :return: The id of this BackupInfo.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this BackupInfo.

        备份ID。

        :param id: The id of this BackupInfo.
        :type id: str
        """
        self._id = id

    @property
    def instance_id(self):
        r"""Gets the instance_id of this BackupInfo.

        实例ID。

        :return: The instance_id of this BackupInfo.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this BackupInfo.

        实例ID。

        :param instance_id: The instance_id of this BackupInfo.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def name(self):
        r"""Gets the name of this BackupInfo.

        备份名称。

        :return: The name of this BackupInfo.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this BackupInfo.

        备份名称。

        :param name: The name of this BackupInfo.
        :type name: str
        """
        self._name = name

    @property
    def description(self):
        r"""Gets the description of this BackupInfo.

        备份描述。

        :return: The description of this BackupInfo.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this BackupInfo.

        备份描述。

        :param description: The description of this BackupInfo.
        :type description: str
        """
        self._description = description

    @property
    def databases(self):
        r"""Gets the databases of this BackupInfo.

        只支持Microsoft SQL Server，局部备份的用户自建数据库名列表，当有此参数时以局部备份为准。

        :return: The databases of this BackupInfo.
        :rtype: list[:class:`huaweicloudsdkrds.v3.BackupDatabase`]
        """
        return self._databases

    @databases.setter
    def databases(self, databases):
        r"""Sets the databases of this BackupInfo.

        只支持Microsoft SQL Server，局部备份的用户自建数据库名列表，当有此参数时以局部备份为准。

        :param databases: The databases of this BackupInfo.
        :type databases: list[:class:`huaweicloudsdkrds.v3.BackupDatabase`]
        """
        self._databases = databases

    @property
    def begin_time(self):
        r"""Gets the begin_time of this BackupInfo.

        备份开始时间，格式为“yyyy-mm-ddThh:mm:ssZ”。  其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。

        :return: The begin_time of this BackupInfo.
        :rtype: str
        """
        return self._begin_time

    @begin_time.setter
    def begin_time(self, begin_time):
        r"""Sets the begin_time of this BackupInfo.

        备份开始时间，格式为“yyyy-mm-ddThh:mm:ssZ”。  其中，T指某个时间的开始；Z指时区偏移量，例如北京时间偏移显示为+0800。

        :param begin_time: The begin_time of this BackupInfo.
        :type begin_time: str
        """
        self._begin_time = begin_time

    @property
    def status(self):
        r"""Gets the status of this BackupInfo.

        备份状态，取值：  - BUILDING: 备份中。 - COMPLETED: 备份完成。 - FAILED：备份失败。 - DELETING：备份删除中。

        :return: The status of this BackupInfo.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this BackupInfo.

        备份状态，取值：  - BUILDING: 备份中。 - COMPLETED: 备份完成。 - FAILED：备份失败。 - DELETING：备份删除中。

        :param status: The status of this BackupInfo.
        :type status: str
        """
        self._status = status

    @property
    def type(self):
        r"""Gets the type of this BackupInfo.

        备份类型，取值：  - “auto”: 自动全量备份 - “manual”: 手动全量备份 - “fragment”: 差异全量备份 - “incremental”: 自动增量备份

        :return: The type of this BackupInfo.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this BackupInfo.

        备份类型，取值：  - “auto”: 自动全量备份 - “manual”: 手动全量备份 - “fragment”: 差异全量备份 - “incremental”: 自动增量备份

        :param type: The type of this BackupInfo.
        :type type: str
        """
        self._type = type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BackupInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
