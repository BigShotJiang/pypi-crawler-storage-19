import requests
import time,json
import uuid
import os

#
# Functions
#
#

def get_processor_stats(pg_id: str,NIFI_URL:str):
    """
    Return running / stopped processor counts inside a Process Group
    """
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
    r.raise_for_status()

    processors = r.json()["processGroupFlow"]["flow"].get("processors", [])

    running = 0
    stopped = 0

    for p in processors:
        state = p["component"].get("state")
        if state == "RUNNING":
            running += 1
        else:
            stopped += 1

    return {
        "running": running,
        "stopped": stopped,
        "total": len(processors)
    }

def get_root_flows(NIFI_URL:str):
    """
    Get all flows under ROOT process group
    + processor running/stopped counts per PG
    """
    url = f"{NIFI_URL}/flow/process-groups/root"
    r = requests.get(url)
    r.raise_for_status()

    data = r.json()["processGroupFlow"]
    flow = data["flow"]

    results = []

    # 🔹 Process Groups (with processor stats)
    for pg in flow.get("processGroups", []):
        comp = pg["component"]

        stats = get_processor_stats(comp["id"],NIFI_URL)
        s_status=comp.get("state")
        if stats["running"]==stats["total"]:
            s_status="RUNNING"

            
        results.append({
            "id": comp["id"],
            "name": comp["name"],
            "type": "PROCESS_GROUP",
            "state": s_status or comp.get("statelessGroupScheduledState"),
            "processors": {
                "running": stats["running"],
                "stopped": stats["stopped"],
                "total": stats["total"]
            }
        })

    # 🔹 Processors directly under ROOT (rare but valid)
    for p in flow.get("processors", []):
        comp = p["component"]
        results.append({
            "id": comp["id"],
            "name": comp["name"],
            "type": "PROCESSOR",
            "state": comp.get("state")
        })

    # 🔹 Input Ports
    for ip in flow.get("inputPorts", []):
        comp = ip["component"]
        results.append({
            "id": comp["id"],
            "name": comp["name"],
            "type": "INPUT_PORT",
            "state": comp.get("state")
        })

    # 🔹 Output Ports
    for op in flow.get("outputPorts", []):
        comp = op["component"]
        results.append({
            "id": comp["id"],
            "name": comp["name"],
            "type": "OUTPUT_PORT",
            "state": comp.get("state")
        })

    return {
        "status": True,
        "root_id": data["id"],
        "flows": results
    }

def controller_service_exists(pg_id, name,NIFI_URL):
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services")
    print(r)
    for cs in r.json()["controllerServices"]:
        if cs["component"]["name"] == name:
            return cs
    return None

def create_controller_service(pg_id, cs_def,NIFI_URL):
    existing = controller_service_exists(pg_id, cs_def["name"],NIFI_URL)
    if existing:
        print(f"Controller service '{cs_def['name']}' already exists")
        return existing

    payload = {
        "revision": {"version": 0},
        "component": {
            "type": cs_def["type"],
            "bundle": cs_def["bundle"],
            "name": cs_def["name"],
            "properties": cs_def["properties"],
            "comments": cs_def.get("comments", "")
        }
    }

    r = requests.post(
        f"{NIFI_URL}/process-groups/{pg_id}/controller-services",
        json=payload
    )

    if r.status_code == 409:
        print("NiFi error:", r.text)

    r.raise_for_status()
    return r.json()

def create_process_orch_group(parent_pg_id, name,NIFI_URL, position=(200, 200)):
    url = f"{NIFI_URL}/process-groups/{parent_pg_id}/process-groups"
    payload = {
        "revision": {"version": 0},
        "component": {
            "name": f"{name}_orch",
            "position": {"x": position[0], "y": position[1]}
        }
    }
    r = requests.post(url, json=payload)
    r.raise_for_status()
    return r.json()

def enable_controller_service(cs_id,NIFI_URL):
    # get fresh revision
    r = requests.get(f"{NIFI_URL}/controller-services/{cs_id}")
    r.raise_for_status()
    
    rev = r.json()["revision"]["version"]

    payload = {
        "revision": {"version": rev},
        "component": { "id": cs_id,"state": "ENABLED"}
    }
    #print(payload)
    r2 = requests.put(
        f"{NIFI_URL}/controller-services/{cs_id}",
        json=payload
    )



    # NiFi may return 200 but still fail logically
    print("Enable response:", r2.text)
    return  r2.json()

def import_controller_services(pg_id, file_path,NIFI_URL):
    with open(file_path) as f:
        services = json.load(f)

    created = []
    for cs in services:
        cs_entity = create_controller_service(pg_id, cs,NIFI_URL)
        created.append(cs_entity)
    for cs in created:
        enable_controller_service(cs["id"],NIFI_URL)
    return cs["id"]

def create_processor_in_pg(pg_id, comp,NIFI_URL):
    time.sleep(4)
    """
    Create a processor in a PG using component JSON from export.
    """
    url = f"{NIFI_URL}/process-groups/{pg_id}/processors"
    payload = {
        "revision": {"version": 0},
        "component": {
            
            "type": comp["type"],
            "name": comp["name"],
            "position": {"x": comp["position"]["x"], "y": comp["position"]["y"]},
            "config": comp.get("config", {})
        }
    }
    r = requests.post(url, json=payload)
    r.raise_for_status()
    print(f"Created processor: {comp['name']} - {r.json()['id']}")
    return r.json()

def get_processor_by_type(pg_id, processor_type,NIFI_URL):
    time.sleep(5)
    #print("get_processor_by_type")
    #print("pg_id==> ",pg_id)
    #print("processor_type==> ",processor_type)
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
    r.raise_for_status()
    #print("get_processor_by_type")
    #print(r.status_code)
    #print(r.json())
    for p in r.json()["processGroupFlow"]["flow"]["processors"]:
        if p["component"]["type"] == processor_type:
            return p
    raise Exception("Processor not found")

def bind_websocket_controller_service(processor_id, cs_id,NIFI_URL):
    # get fresh processor
#     #print(f"""
# #{processor_id['id']}
# {cs_id}


# """)
    r = requests.get(f"{NIFI_URL}/processors/{processor_id['id']}")
    r.raise_for_status()

    proc = r.json()

    rev = proc["revision"]["version"]
    properties = proc["component"]["config"]["properties"]
    properties["WebSocket Server Controller Service"] = cs_id

    # 🔗 bind controller service
    #props["WebSocket Server Controller Service"] = cs_id
    #print("--111--proc  ",props)
    payload = {
        "revision": {"version": rev},
        "component": {
            "id": processor_id['id'],      # 🔥 REQUIRED
             "config": {"properties": properties}
        }
    }

    r2 = requests.put(
        f"{NIFI_URL}/processors/{processor_id['id']}",
        json=payload
    )

def create_connection(pg_id, conn, NIFI_URL):
    print("####### connect")
    
    time.sleep(5)
    url = f"{NIFI_URL}/process-groups/{pg_id}/connections"

    src_old = conn["component"]["source"]["id"]
    dst_old = conn["component"]["destination"]["id"]


    print("id_map[src_old] ==> ",src_old)
    print("id_map[dst_old] ==> ",dst_old)
    payload = {
        "revision": {"version": 0},
        "component": {
            "name": conn["component"].get("selectedRelationships", ["success"])[0],
            "parentGroupId": pg_id,
            "source": {
                "id": src_old,
                "type": conn["component"]["source"]["type"],
                "groupId":pg_id,
                "name":conn["component"]["source"]["name"]
            },
            "destination": {
                "id": dst_old,
                "type": conn["component"]["destination"]["type"],
                "groupId":pg_id,
                "name":conn["component"]["source"]["name"]
            },
            "selectedRelationships": conn["component"].get("selectedRelationships", ["success"]),
            "flowFileExpiration": conn["component"].get("flowFileExpiration", "0 sec"),
            "backPressureObjectThreshold": conn["component"].get("backPressureObjectThreshold", 10000),
            "backPressureDataSizeThreshold": conn["component"].get("backPressureDataSizeThreshold", "1 GB"),
            "availableRelationships":conn["component"].get("availableRelationships", [])
        }
    }
    print(f"""########## 
          body 
          {conn["component"]["source"]["name"]}
          {conn["component"].get("selectedRelationships", ["success"])}
          {conn["component"].get("availableRelationships", [])}
          
          ##############""")
    r = requests.post(url, json=payload,headers={'Content-Type': 'application/json'})
    r.raise_for_status()

    print("Created connection")
    return r.json()

def get_process_group_full(pg_id: str,NIFI_URL: str):
    time.sleep(5)
    """
    Get full Process Group data:
    - processors
    - input/output ports
    - connections
    - controller services
    - child process groups
    - funnels
    - labels
    - remote process groups
    """
    url = f"{NIFI_URL}/flow/process-groups/{pg_id}"

    r = requests.get(url)
    r.raise_for_status()
    return r.json()

def create_controller_service_by_type(pg_id, cs_type, name,NIFI_URL, properties=None):
    """Create a controller service in a PG."""
    print("====  >  ",NIFI_URL)
    payload = {
        "revision": {"version": 0},
        "component": {
            "type": cs_type,
            "name": name,
            "properties": properties or {}
        }
    }
    r = requests.post(f"{NIFI_URL}/process-groups/{pg_id}/controller-services", json=payload)
    r.raise_for_status()
    cs_id = r.json()["id"]
    print(f"Created Controller Service: {name}")
    return cs_id

def start_processor(processor_id,NIFI_URL):
    # 1️⃣ Get current revision
    url_get = f"{NIFI_URL}/processors/{processor_id}"
    resp = requests.get(url_get)
    resp.raise_for_status()
    processor = resp.json()
    revision = processor['revision']['version']

    # 2️⃣ Start processor
    url_put = f"{NIFI_URL}/processors/{processor_id}/run-status"
    payload = {
        "revision": {"version": revision},
        "state": "RUNNING"
    }
    r = requests.put(url_put, json=payload)
    r.raise_for_status()

def connect_components(
    pg_id: str,
    source_id: str,
    source_type: str,
    destination_id: str,
    destination_type: str,
    NIFI_URL:str,
    relationships=None,
    name=None,
    flowfile_expiration="0 sec",
    backpressure_count=10000,
    backpressure_size="1 GB"
):
    """
    Create a connection between any two NiFi components.

    source_type / destination_type:
      - PROCESSOR
      - INPUT_PORT
      - OUTPUT_PORT

    relationships:
      - None or [] → auto-detect (success for processors)
      - ["success", "failure"] etc.

    """
    
    print(f"""

    source con : {source_id}

    dist con : {destination_id}



""")

    if source_type.startswith("org.apache.nifi.processors"):
        source_type="PROCESSOR"
    if destination_type.startswith("org.apache.nifi.processors"):
        destination_type="PROCESSOR"
    if relationships is None:
        relationships = ["success"]
    if source_type =="INPUT_PORT":
        relationships =None
    url = f"{NIFI_URL}/process-groups/{pg_id}/connections"

    payload = {
        "revision": {"version": 0},
        "component": {
            "parentGroupId": pg_id,
            "name": name or f"{source_id[:6]}_to_{destination_id[:6]}",
            "source": {
                "id": source_id,
                "type": source_type,
                "groupId": pg_id
            },
            "destination": {
                "id": destination_id,
                "type": destination_type,
                "groupId": pg_id
            },
            "selectedRelationships": relationships,
            "flowFileExpiration": flowfile_expiration,
            "backPressureObjectThreshold": backpressure_count,
            "backPressureDataSizeThreshold": backpressure_size
        }
    }
    #print("body ==> ",payload)
    r = requests.post(url, json=payload)
    r.raise_for_status()

    print(
        f"Connected {source_type} ({source_id}) "
        f"→ {destination_type} ({destination_id}) "
        f"relationships={relationships}"
    )

    return r.json()

def get_processor_by_id(processor_id,NIFI_URL):
    url = f"{NIFI_URL}/processors/{processor_id}"
    r = requests.get(url)
    r.raise_for_status()
    return r.json()

def get_processors_in_pg(pg_id,NIFI_URL):
    url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
    r = requests.get(url)
    r.raise_for_status()
    #print(r.json()["processGroupFlow"]["flow"]["processors"])
    return r.json()["processGroupFlow"]["flow"]["processors"]

def export_process_group(pg_id, filename,NIFI_URL):
    """
    Export a NiFi Process Group as JSON.
    """
    url = f"{NIFI_URL}/flow/process-groups/{pg_id}"
    r = requests.get(url)
    r.raise_for_status()
    pg_json = r.json()["processGroupFlow"]
    
    if filename:
        with open(filename, "w") as f:
            import json
            json.dump(pg_json, f, indent=2)
        print(f"Process Group exported to {filename}")
    
    return pg_json

def get_all_child_process_group_ids(parent_pg_id: str,NIFI_URL:str) -> list[str]:
    """
    Recursively get all Process Group IDs under a parent PG in NiFi 2.7.

    :param nifi_url: Base NiFi URL (e.g. https://host:8443/nifi-api)
    :param parent_pg_id: Parent Process Group ID
    :param session: Optional requests.Session with auth/SSL config
    :return: List of process group IDs (children only)
    """


    all_pg_ids = []

    def _walk(pg_id: str):
        url = f"{NIFI_URL}/process-groups/{pg_id}/process-groups"
        r = requests.get(url)
        r.raise_for_status()

        data = r.json()

        child_pgs = data["processGroups"]

        for pg in child_pgs:
            child_id = pg["id"]
            all_pg_ids.append(child_id)
            _walk(child_id)

    _walk(parent_pg_id)
    return all_pg_ids

def stop_all_processors(pg_id,NIFI_URL):
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
    r.raise_for_status()

    processors = r.json()["processGroupFlow"]["flow"].get("processors", [])

    for p in processors:
        if p["component"]["state"] != "STOPPED":
            proc_id = p["id"]

            # fetch fresh revision
            pr = requests.get(f"{NIFI_URL}/processors/{proc_id}")
            pr.raise_for_status()

            rev = pr.json()["revision"]["version"]

            payload = {
                "revision": {"version": rev},
                "state": "STOPPED"
            }

            requests.put(
                f"{NIFI_URL}/processors/{proc_id}/run-status",
                json=payload
            )

    print(f"✔ Processors stopped in PG {pg_id}")

def stop_all_ports(pg_id,NIFI_URL):
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
    r.raise_for_status()

    flow = r.json()["processGroupFlow"]["flow"]

    for port_type in ["inputPorts", "outputPorts"]:
        for p in flow.get(port_type, []):
            if p["component"]["state"] != "STOPPED":
                port_id = p["id"]
                print("{port_type[:-1] ==> ",port_type[:-1])
                #port_type: "input-ports" or "output-ports"
                if port_type[:-1] == 'inputPort':
                    port_type_ = 'input-ports'
                if port_type[:-1] == 'outputPort':
                     port_type_ = 'output-ports'

                pr = requests.get(f"{NIFI_URL}/{port_type_}/{port_id}")
                pr.raise_for_status()
                
                rev = pr.json()["revision"]["version"]

                payload = {
                    "revision": {"version": rev},
                    "state": "STOPPED"
                }

                requests.put(
                    f"{NIFI_URL}/{port_type_}/{port_id}/run-status",
                    json=payload
                )

    print(f"✔ Ports stopped in PG {pg_id}")

def empty_all_queues(pg_id,NIFI_URL):
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
    r.raise_for_status()

    connections = r.json()["processGroupFlow"]["flow"].get("connections", [])

    for c in connections:
        conn_id = c["id"]

        requests.post(
            f"{NIFI_URL}/flowfile-queues/{conn_id}/drop-requests"
        )

    print(f"✔ Queues emptied in PG {pg_id}")

def disable_all_controller_services(pg_id,NIFI_URL):
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services")
    r.raise_for_status()

    for cs in r.json().get("controllerServices", []):
        cs_id = cs["id"]

        cr = requests.get(f"{NIFI_URL}/controller-services/{cs_id}")
        cr.raise_for_status()

        rev = cr.json()["revision"]["version"]

        payload = {
            "revision": {"version": rev},
            "component": {
                "id": cs_id,
                "state": "DISABLED"
            }
        }

        requests.put(
            f"{NIFI_URL}/controller-services/{cs_id}",
            json=payload
        )

    print(f"✔ Controller services disabled in PG {pg_id}")

def delete_process_group(pg_id,NIFI_URL):
    r = requests.get(f"{NIFI_URL}/process-groups/{pg_id}")
    r.raise_for_status()

    rev = r.json()["revision"]["version"]

    requests.delete(
        f"{NIFI_URL}/process-groups/{pg_id}",
        params={"version": rev}
    )

    print(f"🗑 Process Group {pg_id} deleted")

def get_controller_service_by_name(
    pg_id: str,
    service_name: str,
    NIFI_URL:str
):
    """
    Get a Controller Service by name inside a specific Process Group.
    Returns the full controller service entity or None if not found.
    """

    url = f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services"
    r = requests.get(url)
    r.raise_for_status()

    services = r.json().get("controllerServices", [])

    for cs in services:
        if cs["component"]["name"] == service_name:
            return cs

    return None

def create_process_group_inside_pg(
    parent_pg_id: str,
    name: str,
    NIFI_URL:str,
    position=(200.0, 200.0),
    fail_if_exists=True
):
    """
    Create a Process Group inside an existing Process Group.

    :param parent_pg_id: ID of the parent Process Group
    :param name: Name of the new Process Group
    :param position: (x, y) position on the canvas
    :param fail_if_exists: If True, raise error if PG with same name exists
    :return: dict {status, id, name}
    """

    # 1️⃣ Check if PG already exists under parent
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{parent_pg_id}")
    r.raise_for_status()

    existing_pgs = r.json()["processGroupFlow"]["flow"]["processGroups"]

    for pg in existing_pgs:
        if pg["component"]["name"] == name:
            if fail_if_exists:
                return {
                    "status": False,
                    "id": pg["component"]["id"],
                    "name": name,
                    "message": "Process Group already exists"
                }

    # 2️⃣ Create Process Group
    payload = {
        "revision": {"version": 0},
        "component": {
            "name": name,
            "position": {
                "x": float(position[0]),
                "y": float(position[1])
            }
        }
    }

    r = requests.post(
        f"{NIFI_URL}/process-groups/{parent_pg_id}/process-groups",
        json=payload
    )
    r.raise_for_status()

    pg_id = r.json()["id"]

    print(f"Created Process Group '{name}' inside PG '{parent_pg_id}'")

    return {
        "status": True,
        "id": pg_id,
        "name": name
    }

def create_input_port(
    pg_id: str,
    name: str,
    NIFI_URL:str,
    position_id=0,
    allow_remote_access=False
):
    position=(400*position_id, 0.0)
    """
    Create an Input Port inside a given Process Group.

    :param pg_id: Process Group ID where the input port will be created
    :param name: Input Port name
    :param position: (x, y) canvas position
    :param allow_remote_access: Allow access from remote PGs
    :return: dict {status, id, name}
    """

    url = f"{NIFI_URL}/process-groups/{pg_id}/input-ports"

    payload = {
        "revision": {"version": 0},
        "component": {
            "name": name,
            "position": {
                "x": float(position[0]),
                "y": float(position[1])
            },
            "allowRemoteAccess": allow_remote_access
        }
    }

    r = requests.post(url, json=payload)
    r.raise_for_status()

    port_id = r.json()["id"]

    print(f"Created Input Port '{name}' in PG '{pg_id}'")

    return {
        "status": True,
        "id": port_id,
        "name": name,
        "data":r.json()}


def create_execute_stream_command(
    pg_id: str,
    NIFI_URL:str,
    name: str = "ExecuteStreamCommand",
    command: str = "",
    command_arguments: str = "",
    working_dir: str = "",
    position_id=1,
    scheduling_period="0 sec",
    environment=None
):
    position=(500*position_id, 0.0)
    """
    Create an ExecuteStreamCommand processor inside a Process Group.

    :param pg_id: Target Process Group ID
    :param name: Processor name
    :param command: Command to execute (absolute path recommended)
    :param command_arguments: Arguments passed to the command
    :param working_dir: Working directory for the command
    :param position: (x, y) canvas position
    :param scheduling_period: Scheduling period (e.g. '0 sec', '1 sec')
    :param environment: dict of environment variables
    :return: dict {status, id, name}
    """

    url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

    properties = {
        "Command Path": command,
        "Command Arguments": command_arguments,
        "Working Directory": working_dir,
        "Ignore STDIN": "false",
        "Redirect STDERR": "true",
        "Argument Delimiter": ";",
        "Max Attribute Length": "5000",
        "Output MIME Type": "application/json"
    }

    if environment:
        properties["Environment Variables"] = "\n".join(
            f"{k}={v}" for k, v in environment.items()
        )

    payload = {
        "revision": {"version": 0},
        "component": {
            "type": "org.apache.nifi.processors.standard.ExecuteStreamCommand",
            "name": name,
            "position": {
                "x": float(position[0]),
                "y": float(position[1])
            },
            "config": {
                "properties": properties,
                "schedulingPeriod": scheduling_period,
                "executionNode": "ALL",
                 "autoTerminatedRelationships": [
                    "original",
                    "nonzero status"
                ]
            }
        }
    }

    r = requests.post(url, json=payload)
    r.raise_for_status()

    proc_id = r.json()["id"]

    print(f"Created ExecuteStreamCommand '{name}' in PG '{pg_id}'")

    return {
        "status": True,
        "id": proc_id,
        "name": name,
        "data":r.json()
    }

def create_output_port(
    pg_id: str,
    name: str,
    NIFI_URL:str,
    position_id=2,
    allow_remote_access=False
):
    position=(500*position_id, 0.0)
    """
    Create an Output Port inside a given Process Group.

    :param pg_id: Process Group ID
    :param name: Output Port name
    :param position: (x, y) canvas position
    :param allow_remote_access: Allow Remote Process Groups to connect
    :return: dict {status, id, name}
    """

    url = f"{NIFI_URL}/process-groups/{pg_id}/output-ports"

    payload = {
        "revision": {"version": 0},
        "component": {
            "name": name,
            "position": {
                "x": float(position[0]),
                "y": float(position[1])
            },
            "allowRemoteAccess": allow_remote_access
        }
    }

    r = requests.post(url, json=payload)
    r.raise_for_status()

    port_id = r.json()["id"]

    print(f"Created Output Port '{name}' in PG '{pg_id}'")

    return {
        "status": True,
        "id": port_id,
        "name": name,
        "data":r.json()
    }

def create_put_websocket(
    pg_id: str,
    name: str,
    comp:dict,
    NIFI_URL:str,
    position_id: int=0


):
    """
    Create a PutWebSocket processor directly via NiFi REST API
    (no dependency on any helper functions)
    """

    url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

    payload = {
        "revision": {"version": 0},
        "component": {
            "type": "org.apache.nifi.processors.websocket.PutWebSocket",
            "name": name,
            "position": {
                "x": 400 + (position_id * 150),
                "y": 300
            },
            "config": {
                "properties": {
                    "WebSocket Session Id": comp["WebSocket Session Id"],
                    "WebSocket Controller Service Id": comp["WebSocket Controller Service Id"],
                    "WebSocket Endpoint Id": comp["WebSocket Endpoint Id"],
                    "WebSocket Message Type":comp["WebSocket Message Type"]
                },
                "autoTerminatedRelationships": ["failure","success"],
                "schedulingPeriod": "0 sec",
                "executionNode": "ALL"
            }
        }
    }

    response = requests.post(
        url,
        json=payload
    )

    response.raise_for_status()
    return response.json()

def add_handle_http_response(
    pg_id: str,
    http_cs_id: str,
    NIFI_URL:str,
    processor_name: str = "HandleHttpResponse",
):
    """
    Create a HandleHttpResponse processor in a NiFi Process Group.
    """

    url = f"{NIFI_URL}/process-groups/{pg_id}/processors"

    payload = {
        "revision": {"version": 0},
        "component": {
            "name": f"{processor_name}_HTTP_rep",
            "type": "org.apache.nifi.processors.standard.HandleHttpResponse",
            "config": {
                "properties": {
                    "HTTP Status Code": "${http.status.code}",
                    "HTTP Context Map": http_cs_id,
                    "Attributes for HTTP Response": "Content-Type:application/json"
                },
                "autoTerminatedRelationships": ["failure","success"]
            }
        }
    }

    headers = {"Content-Type": "application/json"}
    r = requests.post(url, headers=headers, data=json.dumps(payload))
    r.raise_for_status()

    return r.json()

def add_route_on_attribute_rule(
    route_proc_id: str,
    rule_name: str,
    expression: str,
    NIFI_URL:str
):
    """
    Adds a new rule (dynamic property) to RouteOnAttribute.
    """
    # Get processor
    proc = requests.get(f"{NIFI_URL}/processors/{route_proc_id}").json()
    rev = proc["revision"]["version"]

    properties = proc["component"]["config"]["properties"] or {}

    # Add dynamic rule
    properties[rule_name] = expression

    payload = {
        "revision": {"version": rev},
        "component": {
            "id": route_proc_id,
            "config": {
                "properties": properties
            }
        }
    }

    r = requests.put(f"{NIFI_URL}/processors/{route_proc_id}", json=payload)
    r.raise_for_status()
    time.sleep(5)
    print(f"Added RouteOnAttribute rule: {rule_name}")

def connect_processor_to_child_pg(parent_pg_id: str, processor_id: str, child_pg_id: str,NIFI_URL:str,relationships):
    """
    Connects a processor in a parent PG to a child PG's input port via the output port of the processor.
    
    :param parent_pg_id: ID of the parent process group
    :param processor_id: ID of the processor in the parent PG
    :param child_pg_id: ID of the child process group
    """
    # 1️⃣ Get the child PG's input ports
    r = requests.get(f"{NIFI_URL}/process-groups/{child_pg_id}/input-ports")
    r.raise_for_status()
    input_ports = r.json()["inputPorts"]
    if not input_ports:
        raise Exception(f"Child PG {child_pg_id} has no input ports")
    
    # Use the first input port (or you can filter by name)
    input_port = input_ports[0]

    # 2️⃣ Get the processor info to connect from
    r = requests.get(f"{NIFI_URL}/processors/{processor_id}")
    r.raise_for_status()
    processor = r.json()

    # 3️⃣ Prepare the connection payload
    connection_payload = {
        "revision": {"version": 0},
        "component": {
            "name": f"Connection_to_{input_port['component']['name']}",
            "source": {
                "id": processor_id,
                "type": "PROCESSOR",
                "groupId": parent_pg_id
            },
            "destination": {
                "id": input_port['id'],
                "type": "INPUT_PORT",
                "groupId": child_pg_id
            },
            "selectedRelationships": relationships,  # pick first relationship
            "flowFileExpiration": "0 sec",
            "backPressureDataSizeThreshold": "1 GB",
            "backPressureObjectThreshold": 10000
        }
    }

    # 4️⃣ Create the connection in the parent PG
    url = f"{NIFI_URL}/process-groups/{parent_pg_id}/connections"
    r = requests.post(url, json=connection_payload)
    r.raise_for_status()
    
    print(f"Connected processor '{processor['component']['name']}' to input port '{input_port['component']['name']}' of child PG.")

def start_port_by_id(port_id: str, port_type: str,NIFI_URL:str):
    """
    Start an InputPort or OutputPort by ID.

    port_type: "input-ports" or "output-ports"
    """

    # 1️⃣ Get current revision
    r = requests.get(f"{NIFI_URL}/{port_type}/{port_id}")
    r.raise_for_status()

    revision = r.json()["revision"]["version"]
    name = r.json()["component"]["name"]

    # 2️⃣ Start port
    payload = {
        "revision": {"version": revision},
        "state": "RUNNING"
    }

    sr = requests.put(
        f"{NIFI_URL}/{port_type}/{port_id}/run-status",
        json=payload
    )
    sr.raise_for_status()

    print(f"✔ Started {port_type[:-1]}: {name} ({port_id})")

def get_processor_stats(pg_id: str,NIFI_URL:str):
    """
    Return running / stopped processor counts inside a Process Group
    """
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}")
    r.raise_for_status()

    processors = r.json()["processGroupFlow"]["flow"].get("processors", [])

    running = 0
    stopped = 0

    for p in processors:
        state = p["component"].get("state")
        if state == "RUNNING":
            running += 1
        else:
            stopped += 1

    return {
        "running": running,
        "stopped": stopped,
        "total": len(processors)
    }


def stop_processor(processor,NIFI_URL):
    processors = get_processor(processor,NIFI_URL)
    url = f"{NIFI_URL}/processors/{processor}/run-status"
    payload = {
        "revision": processors["revision"],
        "state": "STOPPED"
    }
    r = requests.put(url, json=payload)
    r.raise_for_status()
    print(f"Stopped processor: {processors['component']['name']}")

def get_processor(id,NIFI_URL):
    url = f"{NIFI_URL}/processors/{id}"
    r = requests.get(url)
    r.raise_for_status()
    #print(r.json()["processGroupFlow"]["flow"]["processors"])
    return r.json()
def stop_process_group(pg_id,NIFI_URL):
    print(pg_id)
    processors = get_processors_in_pg(pg_id,NIFI_URL)
    if not processors:
        print("No processors in process group")
        return
    for p in processors:
        if p["component"]["state"] != "STOPPED":
            stop_processor(p,NIFI_URL)

def remove_route_on_attribute_rule(
    route_proc_id: str,
    rule_name: str,
    NIFI_URL:str

):
    """
    Adds a new rule (dynamic property) to RouteOnAttribute.
    """
    # Get processor
    proc = requests.get(f"{NIFI_URL}/processors/{route_proc_id}").json()
    rev = proc["revision"]["version"]

    properties = proc["component"]["config"]["properties"] or {}
    print(f""" bef--
    properties
            
            {type(properties)}


    """)

    # Add dynamic rule
    properties[rule_name] = None
    print(f"""
properties
          
          {properties}


""")

    payload = {
        "revision": {"version": rev},
        "component": {
            "id": route_proc_id,
            "config": {
                "properties": properties
            }
        }
    }

    r = requests.put(f"{NIFI_URL}/processors/{route_proc_id}", json=payload)
    r.raise_for_status()
    time.sleep(5)
    
    print(f"delete RouteOnAttribute rule: {rule_name}")

def delete_all_connections_to_pg(pg_id: str, NIFI_URL: str):
    """
    Deletes all connections where source OR destination belongs to pg_id.
    """

    # Get ALL connections from root flow
    r = requests.get(f"{NIFI_URL}/process-groups/{pg_id}/connections")
    r.raise_for_status()

    def walk_pg(flow):
        conns = flow.get("connections", [])
        for pg in flow.get("processGroups", []):
            conns += walk_pg(pg["component"]["flow"])
        return conns
    print("###### r.json()     ",r.json())
    all_connections = walk_pg(r.json())

    for c in all_connections:
        src = c["component"]["source"]
        dest = c["component"]["destination"]

        if src.get("groupId") == pg_id or dest.get("groupId") == pg_id:
            cid = c["id"]
            ver = c["revision"]["version"]

            requests.delete(
                f"{NIFI_URL}/connections/{cid}",
                params={"version": ver}
            ).raise_for_status()

            print(f"🧹 Deleted connection {cid}")

def delete_processor_to_child_pg_connection(
    parent_pg_id: str,
    processor_id: str,
    child_pg_id: str,
    NIFI_URL:str

):
    """
    Deletes the connection from a processor in a parent PG
    to a child PG input port.
    """

    # 1️⃣ Get all connections in the parent PG
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{parent_pg_id}")
    r.raise_for_status()
    connections = r.json()["processGroupFlow"]["flow"].get("connections", [])

    # 2️⃣ Find matching connection
    target = None
    for c in connections:
        src = c["component"]["source"]
        dst = c["component"]["destination"]

        if (
            src["type"] == "PROCESSOR"
            and src["id"] == processor_id
            and src["groupId"] == parent_pg_id
            and dst["type"] == "INPUT_PORT"
            and dst["groupId"] == child_pg_id
        ):
            target = c
            break

    if not target:
        print("⚠️ Connection not found — nothing to delete")
        return

    conn_id = target["id"]
    version = target["revision"]["version"]

    # 3️⃣ Delete connection
    r = requests.delete(
        f"{NIFI_URL}/connections/{conn_id}",
        params={"version": version}
    )
    r.raise_for_status()

    print(f"✅ Deleted connection {conn_id}")


#
# FLOW
#
#



def safe_delete_process_group(pg_id,NIFI_URL):
    print(f"⚠ Deleting Process Group {pg_id}")

    stop_all_processors(pg_id,NIFI_URL)
    stop_all_ports(pg_id,NIFI_URL)
    empty_all_queues(pg_id,NIFI_URL)
    disable_all_controller_services(pg_id,NIFI_URL)

    time.sleep(2)  # allow NiFi to settle

    delete_process_group(pg_id,NIFI_URL)

    return {"status": True, "message": "Process Group deleted safely"}


def start_process_group(pg_id,NIFI_URL):
    processors = get_processors_in_pg(pg_id,NIFI_URL)
    if not processors:
        print("No processors in process group")
        return
    for p in processors:
        if p["component"]["state"] != "RUNNING":
            print(p)
            start_processor(p['id'],NIFI_URL)

def create_execute_sql_processor(
    pg_id: str,
    name: str,
    position_x: float,
    position_y: float,
    dbcp_id: str,
    sql_query: str,
    NIFI_URL:str,
    run_every_minutes: int = 10,
    concurrent_tasks: int = 1,
    parameters: dict | None = None,
    start: bool = True
):
    """
    Create ExecuteSQL processor using a DBCPConnectionPool service
    with scheduling and optional parameters.
    """

    # Merge parameters into SQL using NiFi Expression Language
    # Example: WHERE env = '${env}'
    if parameters:
        for k, v in parameters.items():
            sql_query = sql_query.replace(f"${{{k}}}", v)

    payload = {
        "revision": {"version": 0},
        "component": {
            "type": "org.apache.nifi.processors.standard.ExecuteSQL",
            "name": name,
            "position": {"x": position_x, "y": position_y},
            "config": {
                "schedulingStrategy": "TIMER_DRIVEN",
                "schedulingPeriod": f"{run_every_minutes} min",
                "concurrentlySchedulableTaskCount": concurrent_tasks,
                "properties": {
                    "Database Connection Pooling Service": dbcp_id,
                    "SQL Query": sql_query,
                    "Max Rows Per Flow File": "0",
                    "Output Format": "JSON"
                },
                "autoTerminatedRelationships": ["failure"]
            }
        }
    }

    r = requests.post(
        f"{NIFI_URL}/process-groups/{pg_id}/processors",
        json=payload
    )
    r.raise_for_status()

    processor_id = r.json()["id"]
    print(f"✔ ExecuteSQL processor created: {processor_id}")

    if start:
        start_processor(r.json(),NIFI_URL)

    return processor_id
def setup_avro_to_json_services(pg_id,NIFI_URL):
    # 1️⃣ AvroReader
    avro_reader_props = {}  # default properties
    avro_reader_id = create_controller_service_by_type(
        pg_id,
        "org.apache.nifi.avro.AvroReader",
        "AvroReader",NIFI_URL,
        avro_reader_props
    )
    enable_controller_service(avro_reader_id,NIFI_URL)

    # 2️⃣ JsonWriter
    json_writer_props = {}  # default properties
    json_writer_id = create_controller_service_by_type(
        pg_id,
        "org.apache.nifi.json.JsonRecordSetWriter",
        "JsonWriter",
        json_writer_props
    )
    enable_controller_service(json_writer_id,NIFI_URL)

    return avro_reader_id, json_writer_id
def recreate_process_group(parent_pg_id,name, pg_json,NIFI_URL, position=(0, 0), id_map=None,orch_dir=None):
    """
    Recreate a Process Group, its processors, sub-groups, and connections from exported JSON.
    id_map: dictionary to track old_id -> new_id mapping
    """
    if id_map is None:
        id_map = {}

    # Handle root PG
    pg_name = name
    
    # 1️⃣ Create the Process Group
    new_pg_id = create_process_orch_group(parent_pg_id, pg_name,NIFI_URL, position)
    cs_def={"name":"http_cs","type":"org.apache.nifi.http.StandardHttpContextMap",
            "bundle":{'group': 'org.apache.nifi', 'artifact': 'nifi-http-context-map-nar', 'version': '2.7.2'},
            "properties":{"Request Expiration": "5 min"}
            }
    
    id_map[pg_json["id"]] = new_pg_id['id']
    print(f"Created new PG: {pg_name}, id={new_pg_id['id']}")
    #create service
    http_cs = create_controller_service(pg_id=new_pg_id['id'],cs_def=cs_def,NIFI_URL=NIFI_URL)
 
    enable_controller_service(cs_id=http_cs["id"],NIFI_URL=NIFI_URL)

    # http_req=add_handle_http_request(pg_id=new_pg_id['id'],listen_port=7778,http_cs_id=http_cs["id"],
    #                         Allowed_Paths="/"+pg_name,processor_name=pg_name+"_http_req",
    #                         )
    cs_id=import_controller_services(pg_id=new_pg_id['id'],file_path="/work/progs/nifi_aut/nifi_srv/nifi_aut/service_controller.json",NIFI_URL=NIFI_URL)
    print(f"""
        #### cs_id
                {cs_id}



        """)
    if not os.path.exists(f"{orch_dir}/{new_pg_id['id']}"):
            os.makedirs(f"{orch_dir}/{new_pg_id['id']}")
    # 2️⃣ Recreate processors
    print("################### Createing proceses")
    for proc in pg_json["flow"]["processors"]:
        time.sleep(2)
        print("--2--  ",proc["component"]["name"])
        comp = proc["component"]
        if comp['type']=='org.apache.nifi.processors.websocket.ListenWebSocket':
            comp['config']['properties']['WebSocket Server Controller Service']=cs_id
        if comp['type']=='org.apache.nifi.processors.standard.HandleHttpRequest':
            comp['config']['properties']['HTTP Context Map']=http_cs["id"]
            comp['config']['properties']['Allowed Paths']="/"+pg_name+"_hr"
        if comp['type']=='org.apache.nifi.processors.standard.ExecuteStreamCommand':
            comp["config"]["properties"]['Working Directory']=f"{orch_dir}/{new_pg_id['id']}"
            comp["config"]["properties"]['Command Arguments']=f"main_orch.py"
        if comp['type']=='org.apache.nifi.processors.standard.EvaluateJsonPath': 
              comp["config"]["properties"]['question']="$.question"
              comp["config"]["descriptors"]['question']= {
                "name": "question",
                "displayName": "question",
                "description": "",
                "required": False,
                "sensitive": False,
                "dynamic": False,
                "supportsEl": False,
                "expressionLanguageScope": "Not Supported",
                "dependencies": []
              }
        if comp['type']=='org.apache.nifi.processors.jolt.JoltTransformJSON':
            comp["config"]["properties"]['Jolt Specification']="""[\n  {\n    \"operation\": \"shift\",\n    \"spec\": {\"question\": \"question\",\n      \"session_id\": \"session_id\",\n      \"timestamp\": \"timestamp\",\n      \"status\": \"status\",\n      \"sources\": \"sources\",\n      \"selected_agents\": \"selected_agents\"\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent_tmp\": \"=join('--,--', @(1,selected_agents))\"\n    }\n  },\n  {\n    \"operation\": \"modify-overwrite-beta\",\n    \"spec\": {\n      \"agent\": \"=concat('--', @(1,agent_tmp), '--')\"\n    }\n  },\n  {\n    \"operation\": \"remove\",\n    \"spec\": {\n      \"agent_tmp\": \"\"\n    }\n  }\n]"""

            

        print(new_pg_id['id'])
        print( comp["name"])
        print(f"""####
              comp


              {comp}



""")
        new_proc = create_processor_in_pg(new_pg_id['id'], comp,NIFI_URL)
        id_map[comp["id"]] = new_proc["id"]

    # 3️⃣ Recreate sub-groups recursively
    for sub_pg in pg_json["flow"]["processGroups"]:
        recreate_process_group(new_pg_id['id'], sub_pg, position=(position[0]+300, position[1]+300), id_map=id_map,NIFI_URL=NIFI_URL)
    #create webservice controllers:
    print("new_pg_id==> ",new_pg_id['id'])
    ws_cs=get_processor_by_type(pg_id=new_pg_id['id'],processor_type="org.apache.nifi.processors.websocket.ListenWebSocket",NIFI_URL=NIFI_URL)
 
    bs=bind_websocket_controller_service(ws_cs,cs_id,NIFI_URL)
    print("######## bs")
    #4️⃣ Recreate connections
    print("START connections ###################")
    for conn in pg_json["flow"]["connections"]:
        
        # Map old source/destination IDs to new IDs
        src_old = conn["component"]["source"]["id"]
        dst_old = conn["component"]["destination"]["id"]

        # Skip connection if source or destination not in id_map yet
        print("id_map   ",id_map)
        if src_old not in id_map or dst_old not in id_map:
            print(f"""
            #################################
                        ######################
                    src_old   -    {src_old}  
                    dst_old   -    {src_old}

                    id_map
                    {id_map}



###########################################################
            """)
            print(f"Skipping connection {conn['component'].get('name', '')} because IDs not mapped yet")
            continue

        conn_copy = conn.copy()
        conn_copy["component"]["source"]["id"] = id_map[src_old]
        conn_copy["component"]["destination"]["id"] = id_map[dst_old]
        # print(f"""
        # ##### 
        # # connection
        #         {conn_copy}
        # ################     
        #       """)
        create_connection(new_pg_id['id'], conn_copy,NIFI_URL)
       # break

    print(f"Process Group {pg_name} recreated successfully")
    return new_pg_id

def create_and_enable_dbcp_service(
    pg_id: str,
    name: str,
    jdbc_url: str,
    driver_class: str,
    driver_location: str,
    username: str,
    password: str,
    NIFI_URL: str,
    max_total_connections: str = "10"
):
    """
    Create and enable a DBCPConnectionPool controller service.
    Returns: controller_service_id
    """

    # 1️⃣ Check if service already exists
    r = requests.get(f"{NIFI_URL}/flow/process-groups/{pg_id}/controller-services")
    r.raise_for_status()

    for cs in r.json().get("controllerServices", []):
        if cs["component"]["name"] == name:
            cs_id = cs["id"]
            print(f"✔ Controller service '{name}' already exists")
            enable_controller_service(cs_id,NIFI_URL)
            return cs_id

    # 2️⃣ Create controller service
    payload = {
        "revision": {"version": 0},
        "component": {
            "type": "org.apache.nifi.dbcp.DBCPConnectionPool",
            "name": name,
            "properties": {
                "Database Connection URL": jdbc_url,
                "Database Driver Class Name": driver_class,
                "Database Driver Locations": driver_location,
                "Database User": username,
                "Password": password,
                "Max Total Connections": max_total_connections
            }
        }
    }

    r = requests.post(
        f"{NIFI_URL}/process-groups/{pg_id}/controller-services",
        json=payload
    )
    r.raise_for_status()

    cs_id = r.json()["id"]
    print(f"✔ Created controller service '{name}'")

    # 3️⃣ Enable controller service
    enable_controller_service(cs_id,NIFI_URL)

    return cs_id

def create_sql_to_json_jsonfile_flow(
    pg_id: str,
    sql_name: str,
    sql_query: str,
    dbcp_id: str,
    output_dir: str,
    output_filename: str,
    NIFI_URL:str,
    position_x: float = 0,
    position_y: float = 0,
    run_every_minutes: int = 10,
    start: bool = True
):
    """
    NiFi 2.7 compliant flow:
    ExecuteSQL (Avro) → ConvertRecord (JSON) → UpdateAttribute (filename) → PutFile
    """

    # 1️⃣ Controller Services
    avro_reader_id, json_writer_id = setup_avro_to_json_services(pg_id,NIFI_URL)

    # 2️⃣ ExecuteSQL
    exec_sql_proc_id = create_execute_sql_processor(
        pg_id=pg_id,
        name=sql_name,
        position_x=position_x,
        position_y=position_y,
        dbcp_id=dbcp_id,
        sql_query=sql_query,
        run_every_minutes=run_every_minutes,
        start=False,
        NIFI_URL=NIFI_URL
    )

    # 3️⃣ ConvertRecord (Avro → JSON)
    convert_payload = {
        "revision": {"version": 0},
        "component": {
            "type": "org.apache.nifi.processors.standard.ConvertRecord",
            "name": f"{sql_name}_AvroToJson",
            "position": {"x": position_x + 300, "y": position_y},
            "config": {
                "properties": {
                    "Record Reader": avro_reader_id,
                    "Record Writer": json_writer_id
                },
                "autoTerminatedRelationships": ["failure"]
            }
        }
    }
    r = requests.post(
        f"{NIFI_URL}/process-groups/{pg_id}/processors",
        json=convert_payload
    )
    r.raise_for_status()
    convert_proc_id = r.json()["id"]

    # 4️⃣ UpdateAttribute (set filename)
    update_attr_payload = {
        "revision": {"version": 0},
        "component": {
            "type": "org.apache.nifi.processors.attributes.UpdateAttribute",
            "name": f"{sql_name}_SetFilename",
            "position": {"x": position_x + 450, "y": position_y},
            "config": {
                "properties": {
                    "filename": output_filename
                },
                "autoTerminatedRelationships": ["failure"]
            }
        }
    }
    r = requests.post(
        f"{NIFI_URL}/process-groups/{pg_id}/processors",
        json=update_attr_payload
    )
    r.raise_for_status()
    update_attr_id = r.json()["id"]

    # 5️⃣ PutFile
    putfile_payload = {
        "revision": {"version": 0},
        "component": {
            "type": "org.apache.nifi.processors.standard.PutFile",
            "name": f"{sql_name}_PutFile",
            "position": {"x": position_x + 650, "y": position_y},
            "config": {
                "properties": {
                    "Directory": output_dir+"/"+pg_id,
                    "Conflict Resolution Strategy": "replace",
                    "Create Missing Directories": "true"
                },
                "autoTerminatedRelationships": ["failure","success"]
            }
        }
    }
    r = requests.post(
        f"{NIFI_URL}/process-groups/{pg_id}/processors",
        json=putfile_payload
    )
    r.raise_for_status()
    putfile_id = r.json()["id"]

    # 6️⃣ Connections
    connect_components(
        pg_id=pg_id, exec_sql_proc_id=exec_sql_proc_id,source_type= "PROCESSOR",
        destination_id= convert_proc_id,destination_type= "PROCESSOR",relationships= ["success"],NIFI_URL=NIFI_URL
    )

    connect_components(
        pg_id=pg_id, exec_sql_proc_id=convert_proc_id, source_type="PROCESSOR",
        destination_id=update_attr_id, destination_type="PROCESSOR", relationships=["success"],NIFI_URL=NIFI_URL
    )

    connect_components(
        pg_id=pg_id, exec_sql_proc_id=update_attr_id,source_type= "PROCESSOR",
        destination_id=putfile_id, destination_type="PROCESSOR", relationships=["success"],NIFI_URL=NIFI_URL
    )
    print ("------ ")
    print (" ######### ",exec_sql_proc_id)
    print (" ######### ",convert_proc_id)
    print (" ######### ",update_attr_id)
    print (" ######### ",putfile_id)
    # 7️⃣ Start processors (fresh revision fetch)
    if start:
        for pid in [exec_sql_proc_id, convert_proc_id, update_attr_id, putfile_id]:
            proc = get_processor_by_id(pid,NIFI_URL)
            start_processor(proc['id'],NIFI_URL)

    return {
        "status": True,
        "pg_id": pg_id,
        "processors": {
            "execute_sql": exec_sql_proc_id,
            "convert_record": convert_proc_id,
            "update_attribute": update_attr_id,
            "putfile": putfile_id
        },
        "output": {
            "directory": output_dir,
            "filename": output_filename
        }
    }

def create_and_start_stream_flow(
    parent_pg_id: str,
    child_pg_name: str,
    command: str,
    http_cs_id:str,
    NIFI_URL:str,
    command_arguments: str = "",
    working_dir: str = "",

    
):
    """
    Create a full flow:
    PG
     └─ InputPort → ExecuteStreamCommand → OutputPort
    Then start everything.
    """

    # 1️⃣ Create child Process Group
    pg = create_process_group_inside_pg(
        parent_pg_id=parent_pg_id,
        name=child_pg_name,
        NIFI_URL=NIFI_URL,
        position=(200, 200),
        fail_if_exists=False
    )

    child_pg_id = pg["id"]

    # 2️⃣ Create Input Port
    in_port = create_input_port(
        pg_id=child_pg_id,
        name="IN",
        NIFI_URL=NIFI_URL,
        position_id=0
    )

    # 3️⃣ Create ExecuteStreamCommand
    exec_proc = create_execute_stream_command(
        pg_id=child_pg_id,
        NIFI_URL=NIFI_URL,
        name="Execute_Command",
        command=command,
        command_arguments=command_arguments,
        working_dir=working_dir,
        position_id=1
    )

    # 4️⃣ Create Output Port
    out_port = create_output_port(
        pg_id=child_pg_id,
        name="OUT",
        NIFI_URL=NIFI_URL,
        position_id=2
    )
    # create websocket_out
    ws_out=create_put_websocket(pg_id=child_pg_id,
                         name=child_pg_name+"_WS_out",NIFI_URL=NIFI_URL,comp={"WebSocket Session Id":"${websocket.session.id}",
                        "WebSocket Controller Service Id":"${websocket.controller.service.id}",
                        "WebSocket Endpoint Id":"${websocket.endpoint.id}",
                        "WebSocket Message Type":"TEXT"})
    # 5️⃣ Connect Input → ExecuteStreamCommand

    http_res=add_handle_http_response(pg_id=pg["id"],processor_name=child_pg_name,NIFI_URL=NIFI_URL,
                                      http_cs_id=http_cs_id)
    connect_components(
        pg_id=child_pg_id,
        source_id=in_port["id"],
        source_type="INPUT_PORT",
        destination_id=exec_proc["id"],
        destination_type="PROCESSOR",NIFI_URL=NIFI_URL
    )

    # 6️⃣ Connect ExecuteStreamCommand → Output
    connect_components(
        pg_id=child_pg_id,
        source_id=exec_proc["id"],
        source_type="PROCESSOR",
        destination_id=out_port["id"],
        destination_type="OUTPUT_PORT",
        relationships=["output stream"],NIFI_URL=NIFI_URL
    )
    time.sleep(6)
    connect_components(
        pg_id=child_pg_id,
        source_id=exec_proc["id"],
        source_type="PROCESSOR",
        destination_id=ws_out["id"],
        destination_type="PROCESSOR",
        relationships=["output stream"],NIFI_URL=NIFI_URL
    )

    connect_components(
        pg_id=child_pg_id,
        source_id=exec_proc["id"],
        source_type="PROCESSOR",
        destination_id=http_res["id"],
        destination_type="PROCESSOR",
        relationships=["output stream"],NIFI_URL=NIFI_URL
    )
    
    print(f"""
IN port
          
          {in_port}



""")
    time.sleep(4)
    print("--33--")
    start_processor(exec_proc['id'],NIFI_URL)
    time.sleep(4)
    print("--33-44--")
    start_processor(ws_out['id'],NIFI_URL)
    time.sleep(4)
    start_processor(http_res['id'],NIFI_URL)
    time.sleep(4)
    print("✅ Flow created, connected, and started successfully")

    return {
        "process_group_id": child_pg_id,
        "input_port_id": in_port,
        "processor_id": exec_proc,
        "output_port_id": out_port,
        "output_port_id": ws_out,
        "child_pg_id":pg['id'],
        "http_res":http_res
    }


def remove_agent(parent_pg_id,agent_pg_id,router_id,rule_name,NIFI_URL):
    stop_process_group(agent_pg_id,NIFI_URL)
    stop_processor(router_id,NIFI_URL)
    remove_route_on_attribute_rule(route_proc_id=router_id,rule_name=rule_name,NIFI_URL=NIFI_URL)
    delete_all_connections_to_pg(agent_pg_id,NIFI_URL)
    delete_processor_to_child_pg_connection(parent_pg_id,router_id,agent_pg_id,NIFI_URL)
    delete_process_group(agent_pg_id,NIFI_URL)
    start_processor(router_id,NIFI_URL)