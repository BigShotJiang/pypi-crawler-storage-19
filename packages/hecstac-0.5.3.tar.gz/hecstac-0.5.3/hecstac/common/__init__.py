"""Common scripts."""
