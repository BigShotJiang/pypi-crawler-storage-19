"""Schema parsing."""
