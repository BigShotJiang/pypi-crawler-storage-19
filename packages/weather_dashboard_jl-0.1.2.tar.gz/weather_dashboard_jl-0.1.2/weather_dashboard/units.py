"""
Units and temperature conversion helpers.

Defines supported unit types, normalization of user input,
and conversion utilities used across the application.
"""

from typing import Literal

UnitType = Literal["c", "f"]

CELSIUS: UnitType = "c"
FAHRENHEIT: UnitType = "f"


def normalize_units(units: str) -> UnitType:
    """
    Normalise any user input to "c" or "f"

    Defaults to Celsius if something unexpected is passed.
    """

    value = units.strip().lower()
    if value == FAHRENHEIT:
        return FAHRENHEIT
    return CELSIUS


def convert_temperature(temperature_in_celsius: float, units: UnitType) -> float:
    """
    Convert a temperature in Celsius to the requested units.

    - units == "c"": return Celsius unchanged
    - units == "f": convert to Farenheit
    """

    if units == FAHRENHEIT:
        return round((temperature_in_celsius * 9 / 5) + 32, 1)
    return temperature_in_celsius
