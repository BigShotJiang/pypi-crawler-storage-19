from weather_dashboard.cli_weather import app

app()
