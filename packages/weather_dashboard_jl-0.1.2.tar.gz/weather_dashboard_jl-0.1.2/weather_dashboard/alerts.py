"""
Alert logic for the weather app.
"""

from typing import Any

FREEZING_TEMPERATURE_C = 0.0
HOT_TEMPERATURE_C = 25.0
RAIN_CHANCE_THRESHOLD = 70  # percent
HIGH_WIND_SPEED_KPH = 40.0

FORECAST_DAY_INDEX = 0


def temperature_alert(temp_c: float) -> str | None:
    """
    Generate an alert message based on the temperature.
    """

    if temp_c <= FREEZING_TEMPERATURE_C:
        return "Alert: Freezing temperatures! Stay warm and watch for ice."
    elif temp_c >= HOT_TEMPERATURE_C:
        return "Alert: Hot weather! Stay hydrated and avoid prolonged sun exposure."
    return None


def rain_alert(will_it_rain: bool, chance_of_rain: int | None = None) -> str | None:
    """
    Generate an alert message based on rain conditions.
    """

    # Guaranteed rain
    if will_it_rain:
        return "Alert: Rain expected! Don't forget your umbrella."

    # High chance of rain, not a guaranteed event

    if chance_of_rain is not None and chance_of_rain >= RAIN_CHANCE_THRESHOLD:
        return f"Alert: High chance of rain ({chance_of_rain}%)! Be prepared and consider carrying an umbrella."

    return None


def wind_alert(wind_kph: float) -> str | None:
    """
    Generate an alert message based on wind speed.
    """

    if wind_kph >= HIGH_WIND_SPEED_KPH:
        return "Alert: High winds! Secure loose objects and be cautious outdoors."
    return None


def generate_weather_alerts(
    current_data: dict[str, Any],
    forecast_data: dict[str, Any] | None = None,
) -> list[str]:
    """
    Generate a list of alert messages based on the current weather data and forecast data.
    """

    alerts: list[str] = []

    # Extract relevant weather data from current.json API response

    temp_c = current_data["current"]["temp_c"]
    wind_speed = current_data["current"]["wind_kph"]

    # Extract relevant weather data from rain function

    will_it_rain, chance_of_rain = extract_rain_info(forecast_data)

    msg = temperature_alert(temp_c)
    if msg:
        alerts.append(msg)

    msg = rain_alert(will_it_rain, chance_of_rain)
    if msg:
        alerts.append(msg)

    msg = wind_alert(wind_speed)
    if msg:
        alerts.append(msg)

    return alerts


def extract_rain_info(
    forecast_data: dict[str, Any] | None,
) -> tuple[bool, int | None]:
    """
    Extract relevant weather data from forecast.json API response
    """

    will_it_rain = False
    chance_of_rain: int | None = None

    if forecast_data is not None:
        forecast = forecast_data.get("forecast", {})
        forecast_days = forecast.get("forecastday", [])

        if len(forecast_days) > FORECAST_DAY_INDEX:
            selected_day = forecast_days[FORECAST_DAY_INDEX]
            day_info = selected_day.get("day", {})

            raw_will_it_rain = day_info.get("daily_will_it_rain", 0)
            will_it_rain = bool(raw_will_it_rain)
            chance_of_rain = day_info.get("daily_chance_of_rain")

    return will_it_rain, chance_of_rain
