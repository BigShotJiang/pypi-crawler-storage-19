"""
UI helpers for rendering weather data.

This module handles all Rich-based output:
- Weather tables
- Alerts and warnings
- User-facing error messages

It contains no CLI command logic or API calls.
"""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from weather_dashboard.client import WeatherError
from weather_dashboard.models import WeatherView, build_weather_view
from weather_dashboard.units import CELSIUS, UnitType
from weather_dashboard.weather_service import WeatherFetchResult, fetch_weather_for_city

console = Console()


def display_current_weather(view: WeatherView) -> None:
    """
    Renders a WeatherView as a Rich table + alerts
    """

    table = Table(title=f"Weather for {view.city_name}")
    table.add_column("Metric", style="bold")
    table.add_column("Value")

    table.add_row("Local Time", view.local_time)

    table.add_row(view.temp_label, f"{view.temperature:.1f}")
    table.add_row(view.feels_label, f"{view.feels_like:.1f}")

    table.add_row("Humidity (%)", str(view.humidity))
    table.add_row("Wind Speed (kph)", str(view.wind_speed_kph))

    table.add_row("Condition", f"{view.condition_text} {view.emoji}")

    will_it_rain_str = "Yes" if view.will_it_rain else "No"

    table.add_row("Will it rain?", will_it_rain_str)
    table.add_row("Chance of Rain (%)", str(view.chance_of_rain))

    console.print(table)

    if view.alerts:
        console.print("\n[bold red]Weather Alerts:[/bold red]")
        for alert in view.alerts:
            console.print(f"- {alert}")


def display_forecast_warning(err: WeatherError) -> None:
    """
    Display a softer warning when forecast data cannot be loaded,
    while still allowing current weather to be displayed.
    """

    # Base message
    if err.code is not None:
        message = f"Could not load forecast data (code {err.code}).\n{err.message}"
    else:
        message = f"Could not load forecast data.\n{err.message}"

    console.print(
        Panel.fit(
            message,
            title="Forecast warning",
            border_style="yellow",
        )
    )


def display_error(err: WeatherError) -> None:
    """
    Display errors using a Rich panel for better visibility
    """

    message = err.message

    if err.code is not None:
        message = f"Error code: {err.code}\n{err.message}"

    console.print(
        Panel.fit(
            message,
            title=err.type.replace("_", " ").title(),
            border_style="red",
        )
    )


def render_weather_result(
    city_name: str,
    result: WeatherFetchResult,
    units: UnitType,
) -> None:
    """
    Shared helper to render a WeatherFetchResult in a human-friendly way.

    Used by both the Typer CLI and the interactive menu.
    """
    # Fatal error (current weather failed)
    if not result.ok or result.current is None:
        if isinstance(result.error, WeatherError):
            display_error(result.error)
        else:
            console.print(
                Panel.fit(
                    "An unknown error occurred.",
                    title="Error",
                    border_style="red",
                )
            )
        return

    current_data = result.current
    forecast_data = result.forecast

    # Non-fatal forecast error: we can still show current
    if result.forecast_error is not None:
        display_forecast_warning(result.forecast_error)

    # Display both current and forecast weather with units
    view = build_weather_view(
        city_name=city_name,
        current_data=current_data,
        forecast_data=forecast_data,
        units=units,
    )
    display_current_weather(view)


def show_city_weather(city_name: str, units: UnitType = CELSIUS) -> None:
    """
    Fetch and display weather for a single city using the shared weather service.
    """

    result = fetch_weather_for_city(city_name)
    render_weather_result(city_name, result, units)
