"""
Data models used for presenting weather information.

Defines view-level objects (e.g. WeatherView) and helpers
that transform raw API data into structured, display-ready data.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from weather_dashboard.alerts import extract_rain_info, generate_weather_alerts
from weather_dashboard.conditions import CONDITION_MAP, EMOJI_MAP
from weather_dashboard.units import FAHRENHEIT, UnitType, convert_temperature

START_HOUR = 6
END_HOUR = 18


@dataclass(frozen=True)
class WeatherView:
    """
    View model: everything the CLI needs to display to the user.
    """

    city_name: str

    # time / day-night
    local_time: str
    is_day: bool

    # temperatures
    temperature: float
    feels_like: float
    temp_label: str
    feels_label: str
    units: UnitType

    # other metrics
    humidity: int
    wind_speed_kph: float
    wind_label: str

    # condition / emoji
    condition_text: str
    emoji: str

    # rain info
    will_it_rain: bool
    chance_of_rain: int | None

    # derived alerts
    alerts: list[str]


def _get_hour_from_localtime(local_time: str) -> int:
    """
    Extract the hour number (0-23) from a datetime string.
    Example input from the API response: "2025-11-23 19:45" (format: "YYYY-MM-DD HH:MM")
    Example output: 19
    """

    dt = datetime.strptime(local_time, "%Y-%m-%d %H:%M")

    return dt.hour


def build_weather_view(
    city_name: str,
    current_data: dict[str, Any],
    forecast_data: dict[str, Any] | None,
    units: UnitType,
) -> WeatherView:
    """
    Turn raw API JSON (+ units) into a WeatherView.
    No printing, no Rich, pure data transformation.
    """

    # --- raw values from API ---
    temp_c = float(current_data["current"]["temp_c"])
    feels_like_c = float(current_data["current"]["feelslike_c"])
    humidity = int(current_data["current"]["humidity"])
    wind_kph = float(current_data["current"]["wind_kph"])

    local_time = current_data["location"]["localtime"]
    hour = _get_hour_from_localtime(local_time)
    is_day = START_HOUR <= hour < END_HOUR
    time_of_day = "day" if is_day else "night"

    condition_code = int(current_data["current"]["condition"]["code"])
    condition = CONDITION_MAP.get(condition_code)

    if condition is not None:
        condition_text = condition.day if is_day else condition.night
    else:
        # Fallback to the raw text from the API
        condition_text = str(current_data["current"]["condition"]["text"])

    emoji_info = EMOJI_MAP.get(condition_code, {})
    emoji = emoji_info.get(time_of_day, "🌡️")

    # --- units + labels ---
    temperature = convert_temperature(temp_c, units)
    feels_like = convert_temperature(feels_like_c, units)

    if units == FAHRENHEIT:
        temp_label = "Temperature (°F)"
        feels_label = "Feels Like (°F)"
    else:
        temp_label = "Temperature (°C)"
        feels_label = "Feels Like (°C)"

    wind_label = "Wind (kph)"  # we keep kph for now

    # --- rain + alerts ---
    will_it_rain, chance_of_rain = extract_rain_info(forecast_data)
    alerts = generate_weather_alerts(current_data, forecast_data)

    return WeatherView(
        city_name=city_name,
        local_time=local_time,
        is_day=is_day,
        temperature=temperature,
        feels_like=feels_like,
        temp_label=temp_label,
        feels_label=feels_label,
        units=units,
        humidity=humidity,
        wind_speed_kph=wind_kph,
        wind_label=wind_label,
        condition_text=condition_text,
        emoji=emoji,
        will_it_rain=will_it_rain,
        chance_of_rain=chance_of_rain,
        alerts=alerts,
    )
