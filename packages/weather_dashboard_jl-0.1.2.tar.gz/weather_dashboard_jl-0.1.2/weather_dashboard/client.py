"""
HTTP client for talking to the weather API.

This module is responsible for:
- Making API requests (current and forecast)
- Handling network / HTTP / API errors
- Returning structured results for higher-level services

"""

import json
from typing import Any, Literal, NamedTuple

import requests

from weather_dashboard.config import (
    CURRENT_WEATHER_BASE_URL,
    FORECAST_WEATHER_BASE_URL,
    get_weather_api_key,
)

ErrorType = Literal["network_error", "json_error", "api_error"]

TIMEOUT = 5
FORECAST_DAYS = 1


class WeatherError(NamedTuple):
    type: ErrorType
    message: str
    code: int | None = None


class WeatherResult(NamedTuple):
    ok: bool
    data: dict[str, Any] | None = None
    error: WeatherError | None = None


def _request_weather(
    base_url: str,
    city_name: str,
    extra: dict[str, str | int] | None = None,
) -> WeatherResult:
    """
    Shared helper to call the Weather API and handle errors consistently.
    """

    api_key: str = get_weather_api_key()

    params: dict[str, str | int] = {
        "key": api_key,
        "q": city_name,
        "aqi": "no",
    }

    if extra is not None:
        params.update(extra)

    # 1) Network / HTTP level issues
    try:
        response = requests.get(base_url, params=params, timeout=TIMEOUT)
    except requests.RequestException as ex:
        return WeatherResult(
            ok=False,
            error=WeatherError("network_error", str(ex)),
        )

    # 2) JSON parsing issues
    try:
        data = response.json()
        # print("\n=== RAW JSON FROM API ===")
        # print(json.dumps(data, indent=4))
    except json.JSONDecodeError as ex:
        return WeatherResult(
            ok=False,
            error=WeatherError("json_error", str(ex)),
        )

    # 3) API-level error (e.g. bad city)
    if "error" in data:
        err = data["error"]
        return WeatherResult(
            ok=False,
            error=WeatherError(
                "api_error",
                message=err.get("message", "Unknown API error"),
                code=err.get("code"),
            ),
        )

    # 4) Success
    return WeatherResult(ok=True, data=data)


def get_current_weather(city_name: str) -> WeatherResult:
    """
    Get current weather for a single city.
    """

    return _request_weather(
        CURRENT_WEATHER_BASE_URL,
        city_name,
    )


def get_forecast_weather(city_name: str) -> WeatherResult:
    return _request_weather(
        FORECAST_WEATHER_BASE_URL,
        city_name,
        {"days": FORECAST_DAYS},
    )
