"""
High-level weather data service.

Coordinates fetching current and forecast weather data,
handles partial failures, and returns combined results
for use by the CLI and UI layers.
"""

from typing import Any, NamedTuple

from weather_dashboard.client import (
    WeatherError,
    WeatherResult,
    get_current_weather,
    get_forecast_weather,
)


class WeatherFetchResult(NamedTuple):
    """
    Result of fetching weather for a single city.

        - ok: True if the current weather call succeeded (we have something to show).
              The forecast call may still have failed; see `forecast` and
              `forecast_error`.
        - current: current weather data, or None if the current call failed.
        - forecast: forecast weather data, or None if the forecast call failed.
        - error: fatal error from the current weather call (None on success).
        - forecast_error: non-fatal error from the forecast call (None on success).
    """

    ok: bool
    current: dict[str, Any] | None
    forecast: dict[str, Any] | None
    error: WeatherError | None
    forecast_error: WeatherError | None


def fetch_weather_for_city(city_name: str) -> WeatherFetchResult:
    """
    Fetch current + forecast weather for a given city.

    - If the current weather call fails, we treat that as fatal:
        - ok = False
        - current = None
        - forecast = None
        - error = (the WeatherError)
        - forecast_error = None

    - If current weather succeeds but forecast fails:
        - ok = True
        - current = current data
        - forecast = None
        - error = (the WeatherError)
        - forecast_error = (the WeatherError from the forecast call)
    """

    # Current weather

    current_result: WeatherResult = get_current_weather(city_name)

    if not current_result.ok or current_result.data is None:
        # Treat as fatal: nothing to display

        return WeatherFetchResult(
            ok=False,
            current=None,
            forecast=None,
            error=current_result.error,
            forecast_error=None,
        )

    current_data = current_result.data

    # Forecast weather (non-fatal if this fails)

    forecast_result: WeatherResult = get_forecast_weather(city_name)

    if not forecast_result.ok or forecast_result.data is None:
        # Still show current weather, but record forecast error.

        return WeatherFetchResult(
            ok=True,
            current=current_data,
            forecast=None,
            error=None,
            forecast_error=forecast_result.error,
        )

    forecast_data = forecast_result.data

    return WeatherFetchResult(
        ok=True,
        current=current_data,
        forecast=forecast_data,
        error=None,
        forecast_error=None,
    )
