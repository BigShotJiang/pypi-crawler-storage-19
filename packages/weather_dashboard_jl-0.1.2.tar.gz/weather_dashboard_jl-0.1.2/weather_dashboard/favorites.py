"""
Persistence helpers for managing favorite cities.

Handles loading, saving, adding, removing, and clearing
favorite city names from local storage.

Contains no CLI or UI logic.
"""

import json
from pathlib import Path

FAV_PATH = Path.home() / ".weatherapp_favorites.json"


def load_favorites() -> list[str]:
    """
    Load favorite cities from the JSON file.
    Returns a list of city names.
    """
    if not FAV_PATH.exists():
        return []

    try:
        favorites = json.loads(FAV_PATH.read_text())
        if isinstance(favorites, list):
            return favorites
        return []
    except (json.JSONDecodeError, IOError):
        return []


def save_favorites(favorites: list[str]) -> None:
    """
    Save favorite cities to the JSON file.
    """
    try:
        FAV_PATH.write_text(json.dumps(favorites, indent=2, ensure_ascii=False))
    except IOError:
        pass


def add_favorite(city_name: str) -> list[str]:
    """
    Add a city to the favorites list if it's not already present.
    Returns the updated list.
    """
    favorites = load_favorites()
    normalized_city = city_name.strip().title()

    if normalized_city not in favorites:
        favorites.append(normalized_city)
        save_favorites(favorites)

    return favorites


def remove_favorite(city_name: str) -> list[str]:
    """
    Remove a city from the favorites list if it exists.
    Returns the updated list.
    """
    favorites = load_favorites()
    normalized_city = city_name.strip().title()

    if normalized_city in favorites:
        favorites.remove(normalized_city)
        save_favorites(favorites)

    return favorites


def clear_favorites() -> None:
    """
    Clear all favorite cities.
    """
    save_favorites([])
