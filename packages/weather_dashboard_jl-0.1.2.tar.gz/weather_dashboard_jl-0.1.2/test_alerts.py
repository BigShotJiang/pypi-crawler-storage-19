"""
Tests for weather alert detection logic.

Covers cases related to rain detection and alert
generation based on current and forecast weather data.
"""

from weather_dashboard.alerts import (
    FREEZING_TEMPERATURE_C,
    HIGH_WIND_SPEED_KPH,
    HOT_TEMPERATURE_C,
    RAIN_CHANCE_THRESHOLD,
    rain_alert,
    temperature_alert,
    wind_alert,
)

# test temperature alerts


def test_temperature_alert_freezing():
    msg = temperature_alert(FREEZING_TEMPERATURE_C - 5)
    assert msg is not None


def test_temperature_alert_normal():
    msg = temperature_alert(20)
    assert msg is None


def test_temperature_alert_hot():
    msg = temperature_alert(HOT_TEMPERATURE_C + 5)
    assert msg is not None


# test rain alerts


def test_rain_alert_yes():
    msg = rain_alert(True, None)
    assert msg is not None


def test_rain_alert_high_chance_without_rain():
    msg = rain_alert(False, RAIN_CHANCE_THRESHOLD + 10)
    assert msg is not None


def test_rain_alert_no():
    msg = rain_alert(False, None)
    assert msg is None


# test wind alerts


def test_wind_alert_high():
    msg = wind_alert(HIGH_WIND_SPEED_KPH + 10)
    assert msg is not None


def test_wind_alert_normal():
    msg = wind_alert(20)
    assert msg is None
