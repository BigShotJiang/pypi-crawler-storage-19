# 🌤️ Weather Dashboard CLI

A Python command-line weather dashboard built with Typer and Rich.
Fetch current weather and forecasts, manage favorite cities, and explore weather data via an interactive CLI.

## ✨ Features

- 🌤️ Current weather for any city
- ⭐ Manage favorite cities (add, list, remove, clear)
- 🧭 Interactive menu-based mode
- 🌡️ Celsius / Fahrenheit support
- 📊 Rich-formatted terminal output
- ⚠️ Basic weather alerts (rain, etc.)

## 📦 Installation (from PyPI)

### Using pip
```bash
pip install weather-dashboard-jl
```

### Using uv (no project needed)
```bash
uv run --with weather-dashboard-jl --no-project -- weather --help
```

## 🔑 API Key Setup

This CLI uses **WeatherAPI.com**.

**1) Get an API key**

Create an account and generate a key at:
https://www.weatherapi.com/

**2) Set the environment variable**

macOS / Linux
```bash
export WEATHER_API_KEY="YOUR_API_KEY"
```

Windows (PowerShell)
```bash
$env:WEATHER_API_KEY="YOUR_API_KEY"
```

**Optional: .env file (local convenience)**

Create a .env file in the directory you run the command from:
```env
WEATHER_API_KEY=YOUR_API_KEY
```

✅ `weather --help` works without the API key.
The key is only required for commands that call the API.

## 🧪 Development Setup

```bash
git clone https://github.com/<your-username>/weather-dashboard.git
cd weather-dashboard
uv sync
```

## 🚀 Usage

### Help
```bash
weather --help
```

### Current weather
```bash
weather current Singapore
weather current "New York" --units f
```

### Interactive mode
```bash
weather interactive
```

### Favorites
```bash
weather fav add London
weather fav list
weather fav remove London
weather fav clear
```

## 📁 Project Structure
```text
weather_dashboard/
├── cli_weather.py        # Typer CLI commands
├── client.py             # WeatherAPI HTTP client
├── conditions.py         # Weather condition mappings
├── models.py             # View models
├── ui.py                 # Rich UI helpers
├── weather_service.py    # Domain logic
├── favorites.py          # Favorites persistence
├── units.py              # Unit handling (C/F)
├── alerts.py             # Alert logic
└── data/
    └── weather_conditions.json
```
