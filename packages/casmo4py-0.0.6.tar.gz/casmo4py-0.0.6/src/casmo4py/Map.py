#! /usr/bin/env python3

""" """
import pygmt as pg
import pandas as pd
import numpy as np
from casmo4py.Setup import Setup


class Map:
    def __init__(self,  lon, lat, qual, reg, typ):
        """
        Args:
            bla (test.type): does blub
        """
        self.region = [lon[0], lon[1], lat[0], lat[1]]
        self.order = [
            "FMS",
            "FMF",
            "OC",
            "GFI",
            "GVA",
            "BO",
            "DIF",
            "HF",
            "PP",
            "MAG",
            "DIR",
        ]
        self.order_q = ["D", "C", "B", "A", "DIR"]
        self.regime = reg
        self.typ = typ
        self.quality = qual

        self.col = Setup.colors

        self.fig = pg.Figure()

    def hillshade(self, grid, normalize=10, azimuth=45):
        grd = pg.grdgradient(
            grid=grid,  # /home/tim/casmo_ap/gmt_files_casmo/ETOPO1_Bed_g_gmt4.grd
            region=self.region,
            normalize=normalize,
            azimuth=azimuth,
        )
        self.fig.grdimage(
            grid=grid,
            shading=grd,
            cmap="/home/tim/casmo_ap/gmt_files_casmo/blue_gray.cpt",
            transparency=50,
        )

    def plot_stress_data(self, data):
        grp = data.groupby(["TYPE", "QUALITY", "REGIME"])
        for t in self.order:
            if t not in self.typ:
                continue
            if t == "PP" or t == "MAG":
                try:
                    g = grp.get_group((t, t, t))
                    self.fig.plot(
                        x=g.LON,
                        y=g.LAT,
                        style="{}.5".format("c" if t == "PP" else "t"),
                        pen=f".01c,black",
                        fill=f"{self.col[t]}",
                    )
                except:
                    continue

            for q in self.order_q:
                if q not in self.quality:
                    continue
                for r in self.regime:
                    try:
                        g = grp.get_group((t, q, r))
                        if t == "FMS":
                            g = g.sort_values(by="DEPTH", ascending=False)
                        g = g[["LON", "LAT", "AZI", "LEN"]]
                        self.fig.plot(
                            x=g.LON,
                            y=g.LAT,
                            style="V0c+jc",
                            pen=f".01c,{self.col[r]}",
                            direction=[g.AZI, g.LEN],
                        )
                        if not t == "DIR":
                            self.fig.plot(
                                g,
                                style="{}".format(
                                    "c.3" if t == "FMS" or t == "FMA" else f"k{t}/.5c"
                                ),
                                pen=f".01c,{self.col[r]}",
                            )
                    except:
                        continue

    def create_base(self, frame="af", projection="M20.5c"):
        self.fig.basemap(
            region=self.region,
            frame=frame,
            projection=projection,
        )

    def plot_coastline(self, grid):
        self.fig.grdcontour(
            grid=grid,
            levels=[0],
            pen=".5pt,black",
        )

        self.fig.coast(
            resolution="intermediate", area_thresh="400/2", water="22/135/183"
        )

    def convert(self, name, fmt):
        self.fig.psconvert(prefix=name, fmt=fmt)


if __name__ == "__main__":
    grid = "/home/tim/casmo_ap/gmt_files_casmo/ETOPO1_Bed_g_gmt4.grd"
    data = pd.read_csv(
        "/home/tim/casmo_ap/gmt_files_casmo/stress_data/wsm2025.csv",
    )
    test_data = data[
        (data["LAT"] > 57) & (data["LAT"] < 63) & (data["LON"] > 3) & (data["LON"] < 15)
    ]
    head = test_data.columns
    pm = [
        [60, 10, 0, "PP", 0, "PP", "PP"],
        [59, 10, 0, "PP", 0, "PP", "PP"],
        [60, 10, 0, "MAG", 0, "MAG", "MAG"],
        [59, 10, 0, "MAG", 0, "MAG", "MAG"],
        [59, 11, 0, "DIR", 0, "DIR", "DIR"],
        [59, 12, 0, "DIR", 0, "DIR", "DIR"],
    ]
    add_data = pd.DataFrame.from_records(pm, columns=head)
    test_data = pd.concat([test_data, add_data])
    test_data["LEN"] = np.ones(len(test_data.LON))

    reg = ["NF", "TF", "SS", "TS", "NS", "U", "DIR"]
    typ = ["FMS", "FMF", "OC", "GFI", "GVA", "BO", "DIF", "HF", "PP", "MAG", "DIR"]
    qual = ["A", "B", "C", "D", "DIR"]

    m = Map((3,15),(57, 63), qual, reg, typ)
    m.create_base()
    m.hillshade(grid)
    m.plot_coastline(grid)
    m.plot_stress_data(test_data)
    m.convert("test", "g")
    print(test_data.head())
