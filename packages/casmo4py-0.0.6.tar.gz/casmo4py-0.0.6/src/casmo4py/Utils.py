#! /usr/bin/env python3

""" """
from casmo4py.Setup import Setup 




def land_vs_port(self, coordinates):
    return

def map_width(self, orientation, coordinates):
    return
def vec_len(row):
    x = row.QUALITY
    try:
        return Setup.vec_len_qual[x]
    except:
        return 0


if __name__ == "__main__":
    m = Utils()
