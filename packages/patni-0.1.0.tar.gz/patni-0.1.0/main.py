def main():
    print("Hello from pati!")


if __name__ == "__main__":
    main()
