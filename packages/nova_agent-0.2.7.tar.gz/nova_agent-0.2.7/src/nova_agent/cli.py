"""Nova Agent CLI."""

from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import webbrowser

import structlog
import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from nova_agent import __version__
from nova_agent.config import get_config_manager
from nova_agent.settings import get_settings, set_verbose

logger = structlog.get_logger(__name__)
console = Console()


def _is_pipx_installed() -> bool:
    """nova-agent가 pipx로 설치되었는지 확인."""
    from pathlib import Path

    pipx_venv = Path.home() / ".local" / "pipx" / "venvs" / "nova-agent"
    return pipx_venv.exists()


def _do_update() -> bool:
    """실제 업데이트 수행.

    Returns:
        True if update succeeded, False otherwise
    """
    if _is_pipx_installed():
        cmd = ["pipx", "upgrade", "nova-agent"]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "nova-agent"]

    console.print(f"[dim]실행: {' '.join(cmd)}[/dim]")
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode == 0


def _parse_version(version: str) -> tuple[int, ...]:
    """버전 문자열을 비교 가능한 튜플로 변환."""
    return tuple(int(x) for x in version.split("."))


def _check_for_updates() -> None:
    """PyPI에서 최신 버전 확인 후 업데이트 여부 확인."""
    try:
        import urllib.request

        url = "https://pypi.org/pypi/nova-agent/json"
        with urllib.request.urlopen(url, timeout=3) as response:
            import json

            data = json.loads(response.read().decode())
            latest_version = data["info"]["version"]

            # 최신 버전이 현재 버전보다 높을 때만 알림
            if _parse_version(latest_version) > _parse_version(__version__):
                console.print(
                    f"[yellow]새 버전이 있습니다: {__version__} → {latest_version}[/yellow]"
                )
                if typer.confirm("지금 업데이트하시겠습니까?", default=True):
                    _do_update()
                    console.print(
                        "[green]업데이트 완료! 다시 실행해주세요.[/green]"
                    )
                    raise typer.Exit(0)
                console.print()  # 줄바꿈
    except typer.Exit:
        raise
    except Exception:
        # 네트워크 오류 등은 무시 (업데이트 체크 실패해도 실행은 계속)
        pass


def _ensure_browser_installed() -> bool:
    """Playwright 브라우저(Chromium) 설치 확인.

    이미 설치되어 있으면 빠르게 스킵됩니다.

    Returns:
        True if browser is ready, False if installation failed
    """
    try:
        console.print(
            "[dim]브라우저 확인 중... "
            "(최초 실행 시 다운로드에 1-3분 소요될 수 있습니다)[/dim]"
        )
        # Node.js deprecation 경고 숨김
        env = os.environ.copy()
        env["NODE_NO_WARNINGS"] = "1"

        # stdout/stderr를 실시간으로 표시하여 다운로드 진행 상태 확인 가능
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            env=env,
        )
        if result.returncode != 0:
            console.print("[red]브라우저 설치 실패[/red]")
            return False
        return True
    except Exception as e:
        console.print(f"[red]브라우저 설치 확인 실패: {e}[/red]")
        return False


app = typer.Typer(
    name="nova-agent",
    help="Nova Agent - Browser automation agent for Nova QA platform",
    add_completion=False,
)


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        console.print(f"Nova Agent v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
) -> None:
    """Nova Agent - Browser automation agent for Nova QA platform."""
    pass


@app.command()
def login(
    frontend_url: str | None = typer.Option(
        None,
        "--url",
        "-u",
        help="Frontend URL for agent registration",
    ),
) -> None:
    """Agent 등록 및 토큰 발급.

    브라우저에서 Nova 플랫폼에 로그인 후 Agent를 등록하고,
    발급된 토큰을 입력합니다.
    """
    config = get_config_manager()

    # 이미 토큰이 있는 경우 확인
    if config.has_token():
        overwrite = typer.confirm(
            "이미 등록된 토큰이 있습니다. 새로 등록하시겠습니까?",
            default=False,
        )
        if not overwrite:
            console.print("[yellow]취소되었습니다.[/yellow]")
            raise typer.Exit()

    # 설정 로드
    settings = get_settings()
    url = frontend_url or settings.frontend_url

    # 브라우저 열기
    register_url = f"{url.rstrip('/')}{settings.agent_register_path}"
    console.print(
        Panel(
            f"[bold]Agent 등록 페이지를 엽니다.[/bold]\n\n"
            f"1. 브라우저에서 Nova 플랫폼에 로그인하세요\n"
            f"2. Agent 이름을 입력하고 등록하세요\n"
            f"3. 발급된 토큰을 복사하세요\n\n"
            f"URL: {register_url}",
            title="Nova Agent 등록",
            border_style="blue",
        )
    )

    try:
        webbrowser.open(register_url)
        console.print("[green]브라우저가 열렸습니다.[/green]\n")
    except Exception as e:
        console.print(f"[yellow]브라우저를 열 수 없습니다: {e}[/yellow]")
        console.print(f"직접 접속하세요: {register_url}\n")

    # 토큰 입력 받기
    token = Prompt.ask(
        "[bold]발급받은 토큰을 붙여넣으세요[/bold]",
        password=True,  # 토큰 숨김
    )

    if not token.strip():
        console.print("[red]토큰이 입력되지 않았습니다.[/red]")
        raise typer.Exit(1)

    # 토큰 저장
    config.save_token(token)
    console.print(
        Panel(
            "[bold green]Agent 등록 완료![/bold green]\n\n"
            f"토큰이 저장되었습니다: {config.token_file}\n\n"
            "[dim]'nova-agent start' 명령으로 Agent를 실행하세요.[/dim]",
            border_style="green",
        )
    )


@app.command()
def start(
    headless: bool | None = typer.Option(
        None,
        "--headless/--no-headless",
        help="브라우저 헤드리스 모드",
    ),
    gateway_url: str | None = typer.Option(
        None,
        "--gateway-url",
        "-g",
        help="Gateway WebSocket URL",
    ),
    pool_size: int | None = typer.Option(
        None,
        "--pool-size",
        "-p",
        help="최대 동시 브라우저 수 (기본: 1)",
        min=1,
        max=10,
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="상세 로그 출력",
    ),
) -> None:
    """Agent 실행.

    Gateway에 연결하여 Job을 대기합니다.
    """
    # 업데이트 확인
    _check_for_updates()

    config = get_config_manager()

    # 토큰 확인
    token = config.load_token()
    if not token:
        console.print(
            "[red]등록된 토큰이 없습니다.[/red]\n"
            "[dim]'nova-agent login' 명령으로 먼저 Agent를 등록하세요.[/dim]"
        )
        raise typer.Exit(1)

    # 설정 로드
    settings = get_settings()
    actual_gateway_url = gateway_url or settings.gateway_url
    actual_headless = headless if headless is not None else settings.headless
    actual_pool_size = pool_size or settings.pool_size

    # 로그 레벨 및 verbose 모드 설정
    set_verbose(verbose)
    if verbose:
        structlog.configure(
            wrapper_class=structlog.make_filtering_bound_logger(10),  # DEBUG
        )

    # 브라우저 설치 확인
    if not _ensure_browser_installed():
        raise typer.Exit(1)

    console.print(
        Panel(
            f"[bold]Nova Agent 시작[/bold]\n\n"
            f"Gateway: {actual_gateway_url}\n"
            f"Headless: {actual_headless}\n"
            f"Pool Size: {actual_pool_size}\n"
            f"Verbose: {verbose}",
            border_style="blue",
        )
    )

    # Agent 실행
    try:
        asyncio.run(_run_agent(token, actual_gateway_url, actual_headless, actual_pool_size))
    except KeyboardInterrupt:
        console.print("\n[yellow]Agent가 종료되었습니다.[/yellow]")
    except Exception as e:
        console.print(f"[red]오류 발생: {e}[/red]")
        raise typer.Exit(1) from None


async def _run_agent(
    token: str,
    gateway_url: str,
    headless: bool,
    pool_size: int,
) -> None:
    """Agent 메인 루프 실행.

    Args:
        token: JWT 토큰
        gateway_url: Gateway WebSocket URL
        headless: 헤드리스 모드 여부
        pool_size: 브라우저 풀 크기
    """
    from nova_agent.browser.pool import BrowserPool
    from nova_agent.executor.job_manager import JobManager
    from nova_agent.websocket.client import AgentWebSocketClient

    settings = get_settings()

    # 브라우저 풀 초기화 (브라우저는 Job 할당 시 시작됨)
    browser_pool = BrowserPool(
        max_size=pool_size,
        headless=headless,
        viewport_width=settings.viewport_width,
        viewport_height=settings.viewport_height,
    )
    console.print(f"[green]브라우저 풀 초기화됨 (최대 {pool_size}개)[/green]")

    # Job 매니저 초기화
    job_manager = JobManager(browser_pool=browser_pool)

    # WebSocket 클라이언트 초기화
    ws_client = AgentWebSocketClient(
        gateway_url=gateway_url,
        token=token,
        job_manager=job_manager,
    )

    # JobManager에 client 참조 설정
    job_manager.set_client(ws_client)

    try:
        # WebSocket 연결 및 메인 루프
        await ws_client.connect_and_run()

    finally:
        # 정리
        await job_manager.shutdown()
        console.print("[yellow]브라우저 풀이 종료되었습니다.[/yellow]")


@app.command()
def status() -> None:
    """Agent 상태 확인.

    등록된 토큰 및 연결 상태를 확인합니다.
    """
    config = get_config_manager()

    if config.has_token():
        console.print(
            Panel(
                f"[bold green]Agent 등록됨[/bold green]\n\n"
                f"토큰 파일: {config.token_file}\n\n"
                "[dim]'nova-agent start' 명령으로 Agent를 실행할 수 있습니다.[/dim]",
                border_style="green",
            )
        )
    else:
        console.print(
            Panel(
                "[bold yellow]Agent 미등록[/bold yellow]\n\n"
                "[dim]'nova-agent login' 명령으로 Agent를 등록하세요.[/dim]",
                border_style="yellow",
            )
        )


@app.command()
def logout() -> None:
    """토큰 삭제 및 로그아웃.

    저장된 토큰을 삭제합니다.
    """
    config = get_config_manager()

    if not config.has_token():
        console.print("[yellow]등록된 토큰이 없습니다.[/yellow]")
        raise typer.Exit()

    confirm = typer.confirm("토큰을 삭제하시겠습니까?", default=False)
    if not confirm:
        console.print("[yellow]취소되었습니다.[/yellow]")
        raise typer.Exit()

    config.delete_token()
    console.print("[green]토큰이 삭제되었습니다.[/green]")


@app.command()
def update() -> None:
    """Nova Agent 업데이트.

    PyPI에서 최신 버전을 설치합니다.
    """
    console.print("[dim]업데이트 확인 중...[/dim]")

    if _do_update():
        console.print("[green]업데이트 완료![/green]")
    else:
        console.print("[red]업데이트 실패[/red]")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
