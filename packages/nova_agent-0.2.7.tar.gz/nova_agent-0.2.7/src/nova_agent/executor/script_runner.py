"""Script runner for executing Playwright scripts."""

from __future__ import annotations

import time
from typing import Any

import structlog
from playwright.async_api import Page

logger = structlog.get_logger(__name__)


class ScriptRunner:
    """Playwright 스크립트 실행기.

    Runner가 생성한 Playwright 스크립트를 실행합니다.

    Responsibilities:
        1. 스크립트 파싱 및 검증
        2. 스크립트 실행
        3. 실행 결과 반환
    """

    def __init__(self, page: Page) -> None:
        """Initialize script runner.

        Args:
            page: Playwright 페이지
        """
        self._page = page

    async def run(self, script: str) -> dict[str, Any]:
        """스크립트 실행.

        Args:
            script: 실행할 Playwright 스크립트

        Returns:
            실행 결과:
            - success: 성공 여부
            - error: 에러 메시지 (실패 시)
            - duration_ms: 실행 시간 (밀리초)
        """
        logger.debug("running_script", script_length=len(script))
        start_time = time.time()

        try:
            # 스크립트 실행
            # 스크립트는 page를 사용하는 Python 코드
            # exec()를 사용하여 실행하되, 안전한 환경에서 실행
            await self._execute_script(script)

            duration_ms = int((time.time() - start_time) * 1000)
            logger.info("script_executed_successfully", duration_ms=duration_ms)

            return {
                "success": True,
                "duration_ms": duration_ms,
            }

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(
                "script_execution_failed",
                error=str(e),
                duration_ms=duration_ms,
            )

            return {
                "success": False,
                "error": str(e),
                "duration_ms": duration_ms,
            }

    async def _execute_script(self, script: str) -> None:
        """스크립트 실행 (내부).

        Args:
            script: 실행할 스크립트

        Raises:
            Exception: 실행 실패 시
        """
        # 스크립트 실행 컨텍스트 설정
        # page 객체를 전역으로 제공
        local_vars: dict[str, Any] = {
            "page": self._page,
        }

        # async 스크립트 실행을 위한 래퍼
        # 스크립트가 await를 포함할 수 있으므로 async 함수로 래핑
        wrapped_script = f"""
async def __run_script__():
{self._indent_script(script)}

__result__ = __run_script__()
"""

        # 스크립트 컴파일 및 실행
        exec(wrapped_script, local_vars)

        # 비동기 함수 실행
        coro = local_vars.get("__result__")
        if coro:
            await coro

    def _indent_script(self, script: str) -> str:
        """스크립트 들여쓰기.

        Args:
            script: 원본 스크립트

        Returns:
            4칸 들여쓰기된 스크립트
        """
        lines = script.split("\n")
        indented = ["    " + line for line in lines]
        return "\n".join(indented)

    async def run_action(self, action: str, selector: str | None = None, value: str | None = None) -> dict[str, Any]:
        """단일 액션 실행.

        스크립트 대신 간단한 액션을 직접 실행합니다.

        Args:
            action: 액션 타입 (click, fill, select, etc.)
            selector: CSS 선택자
            value: 입력값 (fill, select 등)

        Returns:
            실행 결과
        """
        logger.debug(
            "running_action",
            action=action,
            selector=selector,
            value=value,
        )
        start_time = time.time()

        try:
            if action == "click" and selector:
                await self._page.click(selector)
            elif action == "fill" and selector and value is not None:
                await self._page.fill(selector, value)
            elif action == "select" and selector and value is not None:
                await self._page.select_option(selector, value)
            elif action == "check" and selector:
                await self._page.check(selector)
            elif action == "uncheck" and selector:
                await self._page.uncheck(selector)
            elif action == "hover" and selector:
                await self._page.hover(selector)
            elif action == "press" and value:
                await self._page.keyboard.press(value)
            elif action == "type" and value:
                await self._page.keyboard.type(value)
            elif action == "wait":
                wait_ms = int(value) if value else 1000
                await self._page.wait_for_timeout(wait_ms)
            elif action == "goto" and value:
                await self._page.goto(value)
            else:
                raise ValueError(f"Unknown action: {action}")

            duration_ms = int((time.time() - start_time) * 1000)
            logger.info(
                "action_executed_successfully",
                action=action,
                duration_ms=duration_ms,
            )

            return {
                "success": True,
                "duration_ms": duration_ms,
            }

        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            logger.error(
                "action_execution_failed",
                action=action,
                error=str(e),
                duration_ms=duration_ms,
            )

            return {
                "success": False,
                "error": str(e),
                "duration_ms": duration_ms,
            }
