print('New')
