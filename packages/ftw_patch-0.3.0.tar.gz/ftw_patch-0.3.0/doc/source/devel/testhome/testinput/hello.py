print('Old')
