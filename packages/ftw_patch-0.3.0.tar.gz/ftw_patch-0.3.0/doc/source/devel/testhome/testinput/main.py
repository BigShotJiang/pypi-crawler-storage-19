# Initial comment
print('start')
