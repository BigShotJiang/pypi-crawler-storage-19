# Code Frequency Checker

A Python package to analyze frequency of code elements.

## Installation
```bash
pip install codefrequencychecker
