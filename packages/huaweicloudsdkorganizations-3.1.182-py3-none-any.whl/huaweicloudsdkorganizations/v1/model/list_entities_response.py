# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListEntitiesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'entities': 'list[EntityDto]',
        'page_info': 'PageInfoDto'
    }

    attribute_map = {
        'entities': 'entities',
        'page_info': 'page_info'
    }

    def __init__(self, entities=None, page_info=None):
        r"""ListEntitiesResponse

        The model defined in huaweicloud sdk

        :param entities: 组织中的根、组织单元和账号的列表。
        :type entities: list[:class:`huaweicloudsdkorganizations.v1.EntityDto`]
        :param page_info: 
        :type page_info: :class:`huaweicloudsdkorganizations.v1.PageInfoDto`
        """
        
        super().__init__()

        self._entities = None
        self._page_info = None
        self.discriminator = None

        if entities is not None:
            self.entities = entities
        if page_info is not None:
            self.page_info = page_info

    @property
    def entities(self):
        r"""Gets the entities of this ListEntitiesResponse.

        组织中的根、组织单元和账号的列表。

        :return: The entities of this ListEntitiesResponse.
        :rtype: list[:class:`huaweicloudsdkorganizations.v1.EntityDto`]
        """
        return self._entities

    @entities.setter
    def entities(self, entities):
        r"""Sets the entities of this ListEntitiesResponse.

        组织中的根、组织单元和账号的列表。

        :param entities: The entities of this ListEntitiesResponse.
        :type entities: list[:class:`huaweicloudsdkorganizations.v1.EntityDto`]
        """
        self._entities = entities

    @property
    def page_info(self):
        r"""Gets the page_info of this ListEntitiesResponse.

        :return: The page_info of this ListEntitiesResponse.
        :rtype: :class:`huaweicloudsdkorganizations.v1.PageInfoDto`
        """
        return self._page_info

    @page_info.setter
    def page_info(self, page_info):
        r"""Sets the page_info of this ListEntitiesResponse.

        :param page_info: The page_info of this ListEntitiesResponse.
        :type page_info: :class:`huaweicloudsdkorganizations.v1.PageInfoDto`
        """
        self._page_info = page_info

    def to_dict(self):
        import warnings
        warnings.warn("ListEntitiesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListEntitiesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
