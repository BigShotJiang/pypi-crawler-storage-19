All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

This project uses [*towncrier*](https://towncrier.readthedocs.io/) and the changes for the upcoming release can be found in <https://git.sr.ht/~csevast/scene_rir>.

<!-- towncrier release notes start -->

# scene_rir scene_rir-v1.2.1 (2026-01-11)

## Changed

- Minor corrections in license files and documentation. (#1)


# Scene_Rir 1.2.0 (2025-08-03)

### Added

- Help option added.

### Changed

- Minor documentation corrections.


# Scene_Rir 1.1.0 (2025-08-03)

### Changed

- Prints the version with help when the package is invoked as a command.


# Scene_Rir 1.0.0 (2025-08-02)

### Changed

- First official release with new version scheme.
