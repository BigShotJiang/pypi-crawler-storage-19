# -*- coding: utf-8 -*-
# tests\other_signals_tests.py

# SCENE-RIR Python distribution package
# Copyright (C) 2026 Christos Sevastiadis <csevast@auth.gr>
#
# This file is part of SCENE-RIR Python distribution package.
#
# SCENE-RIR is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program. If not, see <https://www.gnu.org/licenses/>.
"""
    Module for the testing of the `scene_rir` package, saving all WAV formats.

    This module tests the `scene_rir.rir` module. It saves the default excitation
    signal in all the available encoding formats (only different sample data type).

    Usage:
    ```>python.exe test_formats.py```

    or
    ```>python3 test_formats.py```

"""

__author__ = "Christos Sevastiadis <csevast@ece.auth.gr>"

import scene_rir.rir as rir
import scipy as sp

formats = [None, "uint8", "int16", "int32", "float32", "float64"]
signal = rir.SweptSineSignal()
for f in formats:
    signal.save(f"output/ss-signal-{f}.wav", f)
    filename = f"output/ss-signal-{f}.wav"
    smprte, sglvec = sp.io.wavfile.read(filename)
    print(f"File: {filename}, Data type: {sglvec.dtype}")
