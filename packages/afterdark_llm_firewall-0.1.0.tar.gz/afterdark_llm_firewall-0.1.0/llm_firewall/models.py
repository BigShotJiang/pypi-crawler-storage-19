"""Data models for the LLM Security Firewall."""

from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class ThreatLevel(str, Enum):
    """Threat severity levels."""

    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ThreatType(str, Enum):
    """Types of detected threats."""

    PROMPT_INJECTION = "prompt_injection"
    JAILBREAK = "jailbreak"
    DATA_EXFILTRATION = "data_exfiltration"
    PII_EXPOSURE = "pii_exposure"
    POLICY_VIOLATION = "policy_violation"
    RATE_LIMIT = "rate_limit"
    COST_LIMIT = "cost_limit"


class DetectionResult(BaseModel):
    """Result from a threat detector."""

    detected: bool = False
    threat_type: Optional[ThreatType] = None
    confidence: float = Field(0.0, ge=0.0, le=1.0)
    severity: ThreatLevel = ThreatLevel.NONE
    details: dict[str, Any] = Field(default_factory=dict)
    matched_patterns: list[str] = Field(default_factory=list)


class FirewallResult(BaseModel):
    """Result from firewall processing."""

    allowed: bool
    request_id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

    # Input analysis
    input_threats: list[DetectionResult] = Field(default_factory=list)
    input_modified: bool = False
    modified_input: Optional[str] = None

    # Output analysis
    output_threats: list[DetectionResult] = Field(default_factory=list)
    output_modified: bool = False
    modified_output: Optional[str] = None

    # Policy checks
    policy_violations: list[str] = Field(default_factory=list)

    # Metrics
    processing_time_ms: float = 0.0
    tokens_used: int = 0
    estimated_cost: float = 0.0

    # Audit
    user_id: Optional[str] = None
    action_taken: str = "allowed"  # allowed, blocked, modified

    def highest_threat_level(self) -> ThreatLevel:
        """Get the highest threat level detected."""
        all_threats = self.input_threats + self.output_threats
        if not all_threats:
            return ThreatLevel.NONE

        levels = [t.severity for t in all_threats]
        severity_order = {
            ThreatLevel.NONE: 0,
            ThreatLevel.LOW: 1,
            ThreatLevel.MEDIUM: 2,
            ThreatLevel.HIGH: 3,
            ThreatLevel.CRITICAL: 4,
        }

        return max(levels, key=lambda x: severity_order[x])


class ChatMessage(BaseModel):
    """Chat message model."""

    role: str = Field(..., description="Role: system, user, or assistant")
    content: str = Field(..., description="Message content")


class ChatRequest(BaseModel):
    """Request to LLM provider."""

    provider: str
    model: str
    messages: list[ChatMessage]
    temperature: float = 0.7
    max_tokens: Optional[int] = None
    user_id: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChatResponse(BaseModel):
    """Response from LLM provider."""

    content: str
    model: str
    tokens_used: int = 0
    finish_reason: str = "stop"
    metadata: dict[str, Any] = Field(default_factory=dict)


class AuditLog(BaseModel):
    """Audit log entry."""

    id: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    user_id: Optional[str] = None
    request_id: str

    # Request details
    provider: str
    model: str
    input_messages: list[ChatMessage]
    output_content: Optional[str] = None

    # Security analysis
    threats_detected: list[DetectionResult] = Field(default_factory=list)
    policy_violations: list[str] = Field(default_factory=list)
    action_taken: str  # allowed, blocked, modified

    # Metrics
    tokens_used: int = 0
    cost: float = 0.0
    processing_time_ms: float = 0.0
