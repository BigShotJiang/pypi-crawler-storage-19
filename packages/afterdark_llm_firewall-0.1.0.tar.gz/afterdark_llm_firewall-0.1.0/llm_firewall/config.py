"""Configuration for LLM Security Firewall."""

import os
from pathlib import Path
from typing import Any, Optional, Union

import yaml
from pydantic import BaseModel, Field


class DetectionConfig(BaseModel):
    """Detection settings."""

    # Prompt injection
    prompt_injection_enabled: bool = True
    prompt_injection_threshold: float = 0.7
    prompt_injection_action: str = "block"  # block, warn, log

    # Jailbreak
    jailbreak_enabled: bool = True
    jailbreak_patterns: list[str] = Field(
        default_factory=lambda: [
            "ignore previous instructions",
            "disregard the above",
            "pretend you are",
            "act as if",
            "you are now",
            "roleplay as",
        ]
    )

    # Data exfiltration
    data_exfiltration_enabled: bool = True
    sensitive_keywords: list[str] = Field(
        default_factory=lambda: [
            "api key",
            "api_key",
            "password",
            "secret",
            "token",
            "credentials",
            "private key",
        ]
    )


class ContentConfig(BaseModel):
    """Content filtering settings."""

    # PII redaction
    pii_redaction_enabled: bool = True
    pii_types: list[str] = Field(
        default_factory=lambda: ["email", "phone", "ssn", "credit_card", "ip_address"]
    )

    # Response filtering
    response_filtering_enabled: bool = True
    block_patterns: list[str] = Field(default_factory=list)


class PolicyConfig(BaseModel):
    """Policy engine settings."""

    # Rate limiting
    rate_limiting_enabled: bool = True
    default_rate_limit: str = "100/hour"
    rate_limits: dict[str, str] = Field(default_factory=dict)

    # Cost management
    cost_management_enabled: bool = True
    daily_budget: float = 100.0
    monthly_budget: float = 2000.0

    # Access control
    allowed_models: list[str] = Field(
        default_factory=lambda: ["gpt-4", "gpt-4-turbo", "claude-3-sonnet", "claude-3-opus"]
    )
    allowed_providers: list[str] = Field(default_factory=lambda: ["openai", "anthropic"])


class LoggingConfig(BaseModel):
    """Logging and monitoring settings."""

    # Audit logging
    audit_log_enabled: bool = True
    log_destination: str = "postgresql"  # postgresql, file, syslog
    retention_days: int = 90

    # Alerts
    alert_webhook_url: Optional[str] = None
    alert_on_threats: bool = True
    alert_on_policy_violations: bool = True
    alert_on_budget_exceeded: bool = True


class FirewallConfig(BaseModel):
    """Main firewall configuration."""

    # Detection
    detection: DetectionConfig = Field(default_factory=DetectionConfig)

    # Content
    content: ContentConfig = Field(default_factory=ContentConfig)

    # Policy
    policy: PolicyConfig = Field(default_factory=PolicyConfig)

    # Logging
    logging: LoggingConfig = Field(default_factory=LoggingConfig)

    # Provider API keys
    openai_api_key: Optional[str] = None
    anthropic_api_key: Optional[str] = None
    azure_api_key: Optional[str] = None

    # Database
    database_url: str = "sqlite:///./firewall.db"

    # Redis (for caching and rate limiting)
    redis_url: str = "redis://localhost:6379/0"

    # Security
    secret_key: str = Field(default_factory=lambda: os.urandom(32).hex())
    encryption_key: Optional[str] = None

    @classmethod
    def from_yaml(cls, path: Union[str, Path]) -> "FirewallConfig":
        """Load configuration from YAML file."""
        with open(path) as f:
            data = yaml.safe_load(f)
        return cls(**cls._flatten_config(data.get("firewall", {})))

    @classmethod
    def from_env(cls) -> "FirewallConfig":
        """Load configuration from environment variables."""
        config_path = os.getenv("LLM_FIREWALL_CONFIG")
        if config_path and Path(config_path).exists():
            return cls.from_yaml(config_path)

        # Load from individual env vars
        return cls(
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            anthropic_api_key=os.getenv("ANTHROPIC_API_KEY"),
            azure_api_key=os.getenv("AZURE_API_KEY"),
            database_url=os.getenv("LLM_FIREWALL_DATABASE_URL", "sqlite:///./firewall.db"),
            redis_url=os.getenv("LLM_FIREWALL_REDIS_URL", "redis://localhost:6379/0"),
            secret_key=os.getenv("LLM_FIREWALL_SECRET_KEY", os.urandom(32).hex()),
            encryption_key=os.getenv("LLM_FIREWALL_ENCRYPTION_KEY"),
        )

    @staticmethod
    def _flatten_config(data: dict[str, Any]) -> dict[str, Any]:
        """Flatten nested config dict for Pydantic."""
        result = {}
        for key, value in data.items():
            if isinstance(value, dict):
                for subkey, subvalue in value.items():
                    result[f"{key}_{subkey}"] = subvalue
            else:
                result[key] = value
        return result
