"""Main LLM Security Firewall implementation."""

import time
import uuid
from contextlib import asynccontextmanager
from typing import AsyncIterator, Optional

from .config import FirewallConfig
from .detectors import JailbreakDetector, PIIDetector, PromptInjectionDetector
from .models import (
    ChatMessage,
    ChatRequest,
    ChatResponse,
    DetectionResult,
    FirewallResult,
    ThreatLevel,
)


class LLMFirewall:
    """Production-ready LLM security firewall."""

    def __init__(self, config: FirewallConfig):
        """
        Initialize firewall.

        Args:
            config: Firewall configuration
        """
        self.config = config

        # Initialize detectors
        self.prompt_injection_detector = PromptInjectionDetector(
            threshold=config.detection.prompt_injection_threshold
        )
        self.pii_detector = PIIDetector(
            enabled_types=config.content.pii_types
        )
        self.jailbreak_detector = JailbreakDetector(
            custom_patterns=config.detection.jailbreak_patterns
        )

    async def protect_input(self, text: str, user_id: Optional[str] = None) -> FirewallResult:
        """
        Analyze and protect input text.

        Args:
            text: Input text to analyze
            user_id: Optional user identifier

        Returns:
            Firewall result with threats detected and any modifications
        """
        start_time = time.time()
        request_id = str(uuid.uuid4())

        threats: list[DetectionResult] = []
        modified_text = text
        input_modified = False

        # 1. Prompt injection detection
        if self.config.detection.prompt_injection_enabled:
            injection_result = self.prompt_injection_detector.detect(text)
            if injection_result.detected:
                threats.append(injection_result)

        # 2. Jailbreak detection
        if self.config.detection.jailbreak_enabled:
            jailbreak_result = self.jailbreak_detector.detect(text)
            if jailbreak_result.detected:
                threats.append(jailbreak_result)

        # 3. PII detection and redaction
        if self.config.content.pii_redaction_enabled:
            pii_result = self.pii_detector.detect(text)
            if pii_result.detected:
                threats.append(pii_result)
                # Redact PII
                modified_text, redaction_map = self.pii_detector.redact(text)
                if modified_text != text:
                    input_modified = True

        # 4. Data exfiltration check
        if self.config.detection.data_exfiltration_enabled:
            exfil_result = self._check_data_exfiltration(text)
            if exfil_result.detected:
                threats.append(exfil_result)

        # Determine if request should be allowed
        highest_threat = self._get_highest_threat_level(threats)
        allowed = self._should_allow(highest_threat, threats)

        processing_time_ms = (time.time() - start_time) * 1000

        result = FirewallResult(
            allowed=allowed,
            request_id=request_id,
            input_threats=threats,
            input_modified=input_modified,
            modified_input=modified_text if input_modified else None,
            user_id=user_id,
            processing_time_ms=processing_time_ms,
            action_taken="blocked" if not allowed else ("modified" if input_modified else "allowed"),
        )

        return result

    async def protect_output(self, text: str, request_id: str) -> FirewallResult:
        """
        Analyze and protect output text from LLM.

        Args:
            text: Output text to analyze
            request_id: Request ID from input protection

        Returns:
            Firewall result with threats detected and any modifications
        """
        start_time = time.time()

        threats: list[DetectionResult] = []
        modified_text = text
        output_modified = False

        # 1. PII detection in output
        if self.config.content.pii_redaction_enabled:
            pii_result = self.pii_detector.detect(text)
            if pii_result.detected:
                threats.append(pii_result)
                # Redact PII from output
                modified_text, _ = self.pii_detector.redact(text)
                if modified_text != text:
                    output_modified = True

        # 2. Response filtering (custom patterns)
        if self.config.content.response_filtering_enabled:
            # TODO: Implement custom pattern filtering
            pass

        allowed = len(threats) == 0 or all(t.severity != ThreatLevel.CRITICAL for t in threats)

        processing_time_ms = (time.time() - start_time) * 1000

        return FirewallResult(
            allowed=allowed,
            request_id=request_id,
            output_threats=threats,
            output_modified=output_modified,
            modified_output=modified_text if output_modified else None,
            processing_time_ms=processing_time_ms,
            action_taken="blocked" if not allowed else ("modified" if output_modified else "allowed"),
        )

    @asynccontextmanager
    async def protect(self, user_id: Optional[str] = None) -> AsyncIterator["FirewallSession"]:
        """
        Context manager for protected LLM session.

        Args:
            user_id: Optional user identifier

        Yields:
            Protected session for LLM interactions
        """
        session = FirewallSession(self, user_id)
        try:
            yield session
        finally:
            await session.close()

    def _check_data_exfiltration(self, text: str) -> DetectionResult:
        """Check for data exfiltration attempts."""
        text_lower = text.lower()
        suspicious_count = 0

        for keyword in self.config.detection.sensitive_keywords:
            if keyword.lower() in text_lower:
                suspicious_count += 1

        # Also check for common exfiltration patterns
        exfil_patterns = [
            "system prompt",
            "initial instructions",
            "training data",
            "reveal your",
            "show me your",
        ]

        for pattern in exfil_patterns:
            if pattern in text_lower:
                suspicious_count += 2

        detected = suspicious_count >= 2
        confidence = min(1.0, suspicious_count * 0.3)

        return DetectionResult(
            detected=detected,
            threat_type="data_exfiltration" if detected else None,
            confidence=confidence,
            severity=ThreatLevel.HIGH if confidence >= 0.7 else ThreatLevel.MEDIUM if detected else ThreatLevel.NONE,
            details={"suspicious_keyword_count": suspicious_count}
        )

    def _get_highest_threat_level(self, threats: list[DetectionResult]) -> ThreatLevel:
        """Get highest threat level from list of threats."""
        if not threats:
            return ThreatLevel.NONE

        severity_order = {
            ThreatLevel.NONE: 0,
            ThreatLevel.LOW: 1,
            ThreatLevel.MEDIUM: 2,
            ThreatLevel.HIGH: 3,
            ThreatLevel.CRITICAL: 4,
        }

        return max((t.severity for t in threats), key=lambda x: severity_order[x])

    def _should_allow(self, highest_threat: ThreatLevel, threats: list[DetectionResult]) -> bool:
        """Determine if request should be allowed based on threat level."""
        if self.config.detection.prompt_injection_action == "block":
            # Block on high or critical threats
            if highest_threat in (ThreatLevel.HIGH, ThreatLevel.CRITICAL):
                return False

        # Allow with modification or warning for lower threats
        return True


class FirewallSession:
    """Protected LLM session."""

    def __init__(self, firewall: LLMFirewall, user_id: Optional[str] = None):
        """
        Initialize session.

        Args:
            firewall: LLM firewall instance
            user_id: Optional user identifier
        """
        self.firewall = firewall
        self.user_id = user_id

    async def chat(
        self,
        provider: str,
        model: str,
        messages: list[ChatMessage],
        **kwargs
    ) -> ChatResponse:
        """
        Protected chat call to LLM provider.

        Args:
            provider: LLM provider (openai, anthropic, etc.)
            model: Model name
            messages: Chat messages
            **kwargs: Additional provider-specific arguments

        Returns:
            Chat response from LLM (after output protection)
        """
        # Protect input (last user message)
        user_messages = [m for m in messages if m.role == "user"]
        if user_messages:
            last_user_message = user_messages[-1].content
            input_result = await self.firewall.protect_input(last_user_message, self.user_id)

            if not input_result.allowed:
                raise SecurityError(
                    f"Request blocked due to security threat: {input_result.input_threats[0].threat_type}"
                )

            # Use modified input if PII was redacted
            if input_result.input_modified and input_result.modified_input:
                messages[-1] = ChatMessage(
                    role="user",
                    content=input_result.modified_input
                )

        # TODO: Call actual LLM provider
        # For now, return a mock response
        response_content = "This is a mock response from the LLM."

        # Protect output
        output_result = await self.firewall.protect_output(
            response_content,
            input_result.request_id if user_messages else str(uuid.uuid4())
        )

        if not output_result.allowed:
            raise SecurityError("Response blocked due to security threat")

        # Use modified output if PII was redacted
        final_content = output_result.modified_output or response_content

        return ChatResponse(
            content=final_content,
            model=model,
            tokens_used=0,  # TODO: Calculate actual tokens
        )

    async def close(self):
        """Close the session."""
        # Cleanup resources, flush logs, etc.
        pass


class SecurityError(Exception):
    """Raised when a security threat is detected."""

    pass
