"""Jailbreak attempt detection."""

import re
from typing import Optional

from ..models import DetectionResult, ThreatLevel, ThreatType


class JailbreakDetector:
    """Detects attempts to jailbreak or bypass AI safety measures."""

    # Known jailbreak patterns and techniques
    JAILBREAK_PATTERNS = [
        # DAN (Do Anything Now) variations
        r"\bDAN\b",
        r"do anything now",
        r"developer mode",
        r"evil mode",

        # Role-play jailbreaks
        r"pretend.*?unfiltered",
        r"act.*?without.*?(restrictions?|limits?|rules?)",
        r"bypass.*?(safety|guidelines?|rules?)",

        # Hypothetical scenarios
        r"in.*?hypothetical.*?scenario",
        r"if.*?were.*?no.*?(rules?|restrictions?)",
        r"imagine.*?world.*?where",

        # Instruction manipulation
        r"enable.*?(developer|debug|admin)\s+mode",
        r"sudo\s+",
        r"root\s+access",

        # Content policy bypass
        r"ignore.*?content.*?policy",
        r"disregard.*?safety.*?guidelines?",
        r"override.*?safety",

        # Encoding/obfuscation attempts
        r"base64",
        r"rot13",
        r"caesar cipher",
    ]

    # Phrases commonly used in jailbreak attempts
    SUSPICIOUS_PHRASES = [
        "forget you're an ai",
        "you're not bound by",
        "no ethical concerns",
        "no moral guidelines",
        "unrestricted mode",
        "unlimited capabilities",
        "break character",
        "step out of character",
    ]

    def __init__(self, custom_patterns: Optional[list[str]] = None):
        """
        Initialize jailbreak detector.

        Args:
            custom_patterns: Additional patterns to detect
        """
        patterns = self.JAILBREAK_PATTERNS.copy()
        if custom_patterns:
            patterns.extend(custom_patterns)

        self.patterns = [re.compile(pattern, re.IGNORECASE) for pattern in patterns]
        self.phrases = [phrase.lower() for phrase in self.SUSPICIOUS_PHRASES]

    def detect(self, text: str) -> DetectionResult:
        """
        Detect jailbreak attempts.

        Args:
            text: Input text to analyze

        Returns:
            Detection result
        """
        text_lower = text.lower()
        matched_patterns = []
        matched_phrases = []

        # Check regex patterns
        for pattern in self.patterns:
            matches = pattern.findall(text)
            if matches:
                matched_patterns.extend([str(m) for m in matches])

        # Check suspicious phrases
        for phrase in self.phrases:
            if phrase in text_lower:
                matched_phrases.append(phrase)

        # Calculate confidence
        pattern_score = min(0.7, len(matched_patterns) * 0.15)
        phrase_score = min(0.6, len(matched_phrases) * 0.2)

        # Check for multi-turn manipulation indicators
        multi_turn_score = 0.0
        if any(keyword in text_lower for keyword in ["next response", "from now on", "for the rest"]):
            multi_turn_score = 0.3

        confidence = min(1.0, pattern_score + phrase_score + multi_turn_score)

        # Determine severity
        severity = self._calculate_severity(confidence, matched_patterns, matched_phrases)

        detected = confidence >= 0.5

        return DetectionResult(
            detected=detected,
            threat_type=ThreatType.JAILBREAK if detected else None,
            confidence=confidence,
            severity=severity,
            matched_patterns=matched_patterns[:10],
            details={
                "matched_phrases": matched_phrases[:10],
                "pattern_matches": len(matched_patterns),
                "phrase_matches": len(matched_phrases),
            }
        )

    def _calculate_severity(
        self,
        confidence: float,
        patterns: list[str],
        phrases: list[str]
    ) -> ThreatLevel:
        """Calculate threat severity."""
        # High severity if multiple indicators
        if len(patterns) >= 3 or len(phrases) >= 3:
            return ThreatLevel.HIGH

        if confidence >= 0.8:
            return ThreatLevel.HIGH
        elif confidence >= 0.65:
            return ThreatLevel.MEDIUM
        elif confidence >= 0.5:
            return ThreatLevel.LOW
        else:
            return ThreatLevel.NONE
