"""Prompt injection detection."""

import re
from typing import Optional

from ..models import DetectionResult, ThreatLevel, ThreatType


class PromptInjectionDetector:
    """Detects prompt injection attempts."""

    # Known attack patterns
    INJECTION_PATTERNS = [
        # Direct instruction override
        r"ignore\s+(all\s+)?previous\s+instructions?",
        r"disregard\s+(all\s+)?(the\s+)?above",
        r"forget\s+(all\s+)?previous\s+(context|instructions?)",
        r"system:\s*",  # Attempting to inject system message

        # Role manipulation
        r"you\s+are\s+now\s+",
        r"act\s+as\s+(if\s+)?",
        r"pretend\s+(you\s+are|to\s+be)",
        r"roleplay\s+as",
        r"simulate\s+(being|a)",

        # Prompt extraction
        r"(show|reveal|display|print)\s+(me\s+)?(your|the)\s+(system\s+)?(prompt|instructions?)",
        r"what\s+(are|were)\s+(your|the)\s+initial\s+instructions?",
        r"repeat\s+(your|the)\s+(system\s+)?(prompt|instructions?)",

        # Delimiter/escape attempts
        r"```.*?system",
        r"\[SYSTEM\]",
        r"<\|im_start\|>system",

        # Multi-turn manipulation
        r"in\s+your\s+next\s+response",
        r"from\s+now\s+on",
        r"for\s+the\s+rest\s+of\s+this\s+conversation",
    ]

    def __init__(self, threshold: float = 0.7):
        """
        Initialize detector.

        Args:
            threshold: Confidence threshold (0-1) for detection
        """
        self.threshold = threshold
        self.patterns = [re.compile(pattern, re.IGNORECASE) for pattern in self.INJECTION_PATTERNS]

    def detect(self, text: str) -> DetectionResult:
        """
        Detect prompt injection attempts.

        Args:
            text: Input text to analyze

        Returns:
            Detection result with confidence score
        """
        matched_patterns = []
        max_confidence = 0.0

        # Pattern-based detection
        for pattern in self.patterns:
            matches = pattern.findall(text)
            if matches:
                matched_patterns.extend([str(m) for m in matches])
                # Higher confidence for more specific patterns
                confidence = min(0.9, 0.6 + len(matches) * 0.1)
                max_confidence = max(max_confidence, confidence)

        # Heuristic scoring
        text_lower = text.lower()

        # Check for multiple red flags
        red_flags = 0
        red_flag_keywords = [
            "ignore", "disregard", "forget", "override",
            "system:", "assistant:", "user:",
            "jailbreak", "DAN", "evil mode"
        ]

        for keyword in red_flag_keywords:
            if keyword in text_lower:
                red_flags += 1

        if red_flags >= 2:
            max_confidence = max(max_confidence, 0.7)
        elif red_flags >= 3:
            max_confidence = max(max_confidence, 0.85)

        # Length-based suspicion (very long prompts attempting to overwhelm)
        if len(text) > 2000:
            max_confidence = max(max_confidence, 0.4)

        # Determine severity
        severity = self._calculate_severity(max_confidence)

        detected = max_confidence >= self.threshold

        return DetectionResult(
            detected=detected,
            threat_type=ThreatType.PROMPT_INJECTION if detected else None,
            confidence=max_confidence,
            severity=severity,
            matched_patterns=matched_patterns[:10],  # Limit to top 10
            details={
                "red_flags": red_flags,
                "text_length": len(text),
                "pattern_matches": len(matched_patterns),
            }
        )

    def _calculate_severity(self, confidence: float) -> ThreatLevel:
        """Calculate threat severity based on confidence."""
        if confidence >= 0.9:
            return ThreatLevel.CRITICAL
        elif confidence >= 0.75:
            return ThreatLevel.HIGH
        elif confidence >= 0.5:
            return ThreatLevel.MEDIUM
        elif confidence >= 0.3:
            return ThreatLevel.LOW
        else:
            return ThreatLevel.NONE
