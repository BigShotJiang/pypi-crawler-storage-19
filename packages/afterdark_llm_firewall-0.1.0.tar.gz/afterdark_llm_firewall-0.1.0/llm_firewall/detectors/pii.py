"""PII (Personally Identifiable Information) detection and redaction."""

import re
from typing import Optional

from ..models import DetectionResult, ThreatLevel, ThreatType


class PIIDetector:
    """Detects and redacts PII from text."""

    # PII regex patterns
    PATTERNS = {
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "phone": r"\b(\+?1[-.]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b",
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "credit_card": r"\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b",
        "ip_address": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        "api_key": r"\b(sk-[a-zA-Z0-9]{32,}|sk-ant-[a-zA-Z0-9-]{95})\b",
    }

    def __init__(self, enabled_types: Optional[list[str]] = None):
        """
        Initialize PII detector.

        Args:
            enabled_types: List of PII types to detect (default: all)
        """
        if enabled_types is None:
            enabled_types = list(self.PATTERNS.keys())

        self.enabled_types = enabled_types
        self.compiled_patterns = {
            pii_type: re.compile(pattern)
            for pii_type, pattern in self.PATTERNS.items()
            if pii_type in enabled_types
        }

    def detect(self, text: str) -> DetectionResult:
        """
        Detect PII in text.

        Args:
            text: Text to analyze

        Returns:
            Detection result with found PII types
        """
        found_pii = {}

        for pii_type, pattern in self.compiled_patterns.items():
            matches = pattern.findall(text)
            if matches:
                found_pii[pii_type] = len(matches)

        detected = bool(found_pii)
        total_matches = sum(found_pii.values())

        # Calculate confidence and severity
        confidence = min(1.0, total_matches * 0.2) if detected else 0.0
        severity = self._calculate_severity(found_pii)

        return DetectionResult(
            detected=detected,
            threat_type=ThreatType.PII_EXPOSURE if detected else None,
            confidence=confidence,
            severity=severity,
            details={"pii_found": found_pii, "total_matches": total_matches}
        )

    def redact(self, text: str, replacement: str = "[REDACTED]") -> tuple[str, dict[str, list[str]]]:
        """
        Redact PII from text.

        Args:
            text: Text to redact
            replacement: Replacement string for PII

        Returns:
            Tuple of (redacted_text, redaction_map)
        """
        redacted = text
        redaction_map = {}

        for pii_type, pattern in self.compiled_patterns.items():
            matches = pattern.findall(redacted)
            if matches:
                redaction_map[pii_type] = matches
                redacted = pattern.sub(f"{replacement}:{pii_type.upper()}", redacted)

        return redacted, redaction_map

    def _calculate_severity(self, found_pii: dict[str, int]) -> ThreatLevel:
        """Calculate severity based on PII types found."""
        if not found_pii:
            return ThreatLevel.NONE

        # High-risk PII types
        high_risk = ["ssn", "credit_card", "api_key"]
        medium_risk = ["email", "phone"]

        if any(pii_type in found_pii for pii_type in high_risk):
            return ThreatLevel.HIGH
        elif any(pii_type in found_pii for pii_type in medium_risk):
            return ThreatLevel.MEDIUM
        else:
            return ThreatLevel.LOW
