"""Email service generators"""
