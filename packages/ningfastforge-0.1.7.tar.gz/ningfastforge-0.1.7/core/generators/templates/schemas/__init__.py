"""Pydantic schema generators"""
