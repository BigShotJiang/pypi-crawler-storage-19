"""Asset domain examples package."""
