"""Analytics domain examples package."""
