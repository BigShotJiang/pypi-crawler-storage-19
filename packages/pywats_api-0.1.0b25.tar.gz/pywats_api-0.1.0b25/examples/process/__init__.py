"""Process domain examples package."""
