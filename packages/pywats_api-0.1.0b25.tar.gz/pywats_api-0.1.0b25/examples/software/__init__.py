"""Software domain examples package."""
