"""Report domain examples package."""
