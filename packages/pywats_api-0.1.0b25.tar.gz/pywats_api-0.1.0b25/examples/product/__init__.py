"""Product domain examples package."""
