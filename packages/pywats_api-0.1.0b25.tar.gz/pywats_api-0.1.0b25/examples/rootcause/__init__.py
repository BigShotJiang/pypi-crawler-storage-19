"""RootCause domain examples package."""
