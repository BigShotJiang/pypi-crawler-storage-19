from pathlib import Path

from . import config_manager

PROMPTS_DIR = Path(__file__).parent / "prompts"


def read_prompt(filename: str) -> str:
    return (PROMPTS_DIR / filename).read_text(encoding="utf-8")


def get_system_prompt(selected_mode: str) -> str:
    core = read_prompt("core.md")
    mode = read_prompt("modes/mcp.md") if selected_mode == "mcp" else read_prompt("modes/basic.md")
    return f"{core}\n\n---\n\n{mode}"


def get_dynamic_system_prompt(prompt: str, selected_mode: str) -> str:
    if selected_mode == "mcp":
        working_path = config_manager.get_working_path()
        prompt = prompt.replace("{{WORKING_PATH}}", str(working_path))
    return prompt
