from . import config_manager


def validate_config():
    errors = []

    provider = config_manager.get("provider")
    if not provider:
        errors.append("Provider is required. Go to Config > Provider to set one.")

    model = config_manager.get("model")
    if not model:
        errors.append("Model is required. Go to Config > Model to set one.")

    api_key = config_manager.get_api_key(provider) if provider else None

    if provider in ("openai", "google", "anthropic", "groq") and not api_key:
        errors.append(
            f"API Key is required for {provider.capitalize()}. Go to Config > API Key to set one."
        )

    ollama_base_url = config_manager.get("ollama_base_url")
    if provider == "ollama" and not ollama_base_url:
        errors.append("Ollama base URL is required. Go to Config to set ollama_base_url.")

    if errors:
        raise SystemExit("Configuration errors:\n  - " + "\n  - ".join(errors))
