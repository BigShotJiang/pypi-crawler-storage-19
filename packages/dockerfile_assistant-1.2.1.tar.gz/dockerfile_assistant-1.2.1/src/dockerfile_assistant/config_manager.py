import contextlib
import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "dockerfile-assistant"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "provider": None,
    "model": None,
    "ollama_base_url": "http://localhost:11434",
    "api_keys": {
        "openai": None,
        "anthropic": None,
        "google": None,
        "groq": None,
    },
}


def load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            loaded = json.loads(CONFIG_FILE.read_text())
        except json.JSONDecodeError:
            return DEFAULT_CONFIG.copy()
        if not isinstance(loaded, dict):
            return DEFAULT_CONFIG.copy()
        return {**DEFAULT_CONFIG, **loaded}
    return DEFAULT_CONFIG.copy()


def save_config(config: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))
    with contextlib.suppress(OSError):
        CONFIG_FILE.chmod(0o600)


def get(key: str, default=None):
    return load_config().get(key, default)


def set(key: str, value):
    config = load_config()
    config[key] = value
    save_config(config)


def get_api_key(provider: str) -> str | None:
    return load_config().get("api_keys", {}).get(provider)


def set_api_key(provider: str, key: str):
    config = load_config()
    config.setdefault("api_keys", {})[provider] = key
    save_config(config)


def get_working_path() -> Path:
    return Path.cwd()
