from pydantic_ai import Agent

from .mcp_fs import fs_mcp
from .model import get_model, get_model_settings
from .system_prompt import get_dynamic_system_prompt, get_system_prompt


def get_agent(selected_mode: str) -> Agent:
    model = get_model()
    model_settings = get_model_settings()
    system_prompt = get_dynamic_system_prompt(get_system_prompt(selected_mode), selected_mode)

    if selected_mode == "mcp" and fs_mcp:
        return Agent(
            model=model,
            system_prompt=system_prompt,
            toolsets=[fs_mcp],
            model_settings=model_settings,
            retries=5,
        )
    return Agent(
        model=model,
        system_prompt=system_prompt,
        model_settings=model_settings,
        retries=5,
    )
