import asyncio

from . import config_manager
from .agent import get_agent
from .config import validate_config
from .tui import run_tui, show_mode_confirmation


async def run_agent(selected_mode: str):
    agent = get_agent(selected_mode)
    await agent.to_cli(prog_name="")


def cli():
    try:
        selected_mode = run_tui()
        validate_config()
        show_mode_confirmation(selected_mode, config_manager.get_working_path())

        asyncio.run(run_agent(selected_mode))
    except KeyboardInterrupt:
        pass
    except SystemExit:
        raise
    except Exception as exception:
        raise SystemExit(f"Fatal error running CLI: {exception}") from exception


if __name__ == "__main__":
    cli()
