from pathlib import Path

from prompt_toolkit import print_formatted_text, prompt
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.shortcuts import choice
from prompt_toolkit.styles import Style
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from . import config_manager

console = Console()

DOCKER_WHALE = [
    "           ▓▓            ",
    "     ▒▒ ▒▒ ▒▒ ▐█▄▄█▌     ",
    "  ░░ ░░ ░░ ░░  ▀██▀      ",
    " ▟███████████████▛       ",
    " ████▄█████████▀         ",
    " ▜███████████▀           ",
]


def show_banner():
    cwd = Path.cwd()
    home = Path.home()
    try:
        display_path = "~/" + str(cwd.relative_to(home))
    except ValueError:
        display_path = str(cwd)

    provider = config_manager.get("provider") or "Not set"
    model = config_manager.get("model") or "Not set"
    api_key = config_manager.get_api_key(provider) if provider != "Not set" else None
    api_key_status = "Set" if api_key else "Not set"

    config_lines = [
        "",
        f"[cyan]Provider:[/cyan] {provider.capitalize()}",
        f"[cyan]Model:[/cyan] {model}",
        f"[cyan]API Key:[/cyan] {api_key_status}",
        "",
        "",
    ]

    table = Table.grid(padding=(0, 2))
    table.add_column(style="cyan")
    table.add_column()

    for whale_line, config_line in zip(DOCKER_WHALE, config_lines, strict=False):
        table.add_row(whale_line, config_line)

    content = Text()
    content.append("\nDockerfile Assistant\n", style="bold cyan")
    content.append("Working on: ", style="cyan")
    content.append(display_path, style="white")

    panel_content = Table.grid()
    panel_content.add_row(table)
    panel_content.add_row(content)

    console.print(Panel(panel_content, border_style="cyan"))


style = Style.from_dict(
    {
        "input-selection": "",
        "number": "bold",
        "frame.border": "ansicyan",
        "selected-option": "bold underline",
        "bottom-toolbar": "bg:ansicyan fg:black",
    }
)


def get_user_choice():
    return choice(
        message=HTML("<b><ansicyan>Select a mode:</ansicyan></b>"),
        options=[
            ("mcp", HTML("<b>Analyze:</b> Reads your project to generate a matching Dockerfile")),
            ("basic", HTML("<b>Describe:</b> Generates a Dockerfile from your description")),
            ("config", HTML("<b>Config:</b> Configure provider, API key and model")),
        ],
        style=style,
        show_frame=True,
        bottom_toolbar=HTML(
            "Press <b>[Up]</b>/<b>[Down]</b> to select, <b>[Enter]</b> to accept, "
            "<b>[Ctrl+C]</b> to exit."
        ),
    )


def get_config_choice():
    return choice(
        message=HTML("<b><ansicyan>Configuration:</ansicyan></b>"),
        options=[
            ("provider", HTML("<b>Provider:</b> Select your desired AI provider")),
            ("api_key", HTML("<b>API Key:</b> Set your API key for the selected provider")),
            ("model", HTML("<b>Model:</b> Set the model to use")),
            ("back", HTML("<b>Back:</b> Return to main menu")),
        ],
        style=style,
        show_frame=True,
        bottom_toolbar=HTML(
            "Press <b>[Up]</b>/<b>[Down]</b> to select, <b>[Enter]</b> to accept, "
            "<b>[Ctrl+C]</b> to exit."
        ),
    )


def show_mode_confirmation(mode, working_path=None):
    if mode == "mcp":
        print_formatted_text(
            HTML(
                "\n<ansigreen>✓</ansigreen> <b>Analyze</b> selected\n"
                f"  <ansicyan>Working directory:</ansicyan> {working_path}\n"
            ),
            style=style,
        )
    elif mode == "basic":
        print_formatted_text(
            HTML("\n<ansigreen>✓</ansigreen> <b>Describe</b> selected\n"), style=style
        )


def select_provider():
    return choice(
        message=HTML("<b><ansicyan>Select an Option:</ansicyan></b>"),
        options=[
            ("openai", "OpenAI"),
            ("anthropic", "Anthropic"),
            ("google", "Google"),
            ("groq", "Groq"),
            ("ollama", "Ollama"),
        ],
        style=style,
        show_frame=True,
        bottom_toolbar=HTML(
            "Press <b>[Up]</b>/<b>[Down]</b> to select, <b>[Enter]</b> to accept, "
            "<b>[Ctrl+C]</b> to exit."
        ),
    )


def show_provider_confirmation(provider):
    provider_names = {
        "openai": "OpenAI",
        "anthropic": "Anthropic",
        "google": "Google",
        "groq": "Groq",
        "ollama": "Ollama",
    }
    name = provider_names.get(provider, provider)
    print_formatted_text(
        HTML(f"\n<ansigreen>✓</ansigreen> <b>{name}</b> provider selected"), style=style
    )


def set_api_key_prompt():
    provider = config_manager.get("provider")
    if not provider:
        print_formatted_text(
            HTML("<ansiyellow>No provider selected. Select one first.</ansiyellow>")
        )
        provider = select_provider()
        config_manager.set("provider", provider)

    key = prompt(HTML(f"<b>Enter {provider.capitalize()} API key:</b> "), is_password=True)
    config_manager.set_api_key(provider, key)
    print_formatted_text(
        HTML(f"<ansigreen>✓</ansigreen> API key saved for {provider.capitalize()}")
    )


MODEL_DOCS = {
    "openai": "https://platform.openai.com/docs/models",
    "anthropic": "https://platform.claude.com/docs/en/about-claude/models/overview",
    "google": "https://ai.google.dev/gemini-api/docs/models",
    "groq": "https://console.groq.com/docs/models",
    "ollama": "Run 'ollama list' to see installed models",
}


def set_model_prompt():
    provider = config_manager.get("provider")
    if not provider:
        print_formatted_text(
            HTML("<ansiyellow>No provider selected. Select one first.</ansiyellow>")
        )
        provider = select_provider()
        config_manager.set("provider", provider)

    docs_url = MODEL_DOCS.get(provider, "")
    print_formatted_text(HTML(f"\n<ansicyan>Available models:</ansicyan> {docs_url}\n"))

    model = prompt(HTML("<b>Enter model name:</b> "))
    config_manager.set("model", model)
    print_formatted_text(HTML(f"<ansigreen>✓</ansigreen> Model set to {model}"))


def handle_config_menu():
    config_choice = get_config_choice()
    while config_choice != "back":
        if config_choice == "provider":
            provider = select_provider()
            config_manager.set("provider", provider)
            show_provider_confirmation(provider)
        elif config_choice == "api_key":
            set_api_key_prompt()
        elif config_choice == "model":
            set_model_prompt()
        config_choice = get_config_choice()


def run_tui() -> str:
    try:
        show_banner()
        selected_choice = get_user_choice()
        while selected_choice == "config":
            handle_config_menu()
            selected_choice = get_user_choice()
        return selected_choice
    except KeyboardInterrupt:
        print_formatted_text(HTML("\n<ansicyan>Bye!</ansicyan>"))
        raise SystemExit(0) from None
