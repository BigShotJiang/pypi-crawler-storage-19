from pathlib import Path

from pydantic_ai.mcp import MCPServerStdio
from pydantic_ai.toolsets import AbstractToolset

from . import config_manager

ALLOWED_TOOLS = [
    "list_directory",
    "read_file",
    "write_file",
]
BLOCKED_FILENAMES = {
    "id_rsa",
    "id_dsa",
    "id_ecdsa",
    "id_ed25519",
}
BLOCKED_SUFFIXES = (".pem", ".key", ".crt")


async def block_dotenv(ctx, call_tool, tool_name: str, args: dict):
    if tool_name in {"read_file", "write_file"}:
        path = args.get("path", "")
        if isinstance(path, str):
            name = Path(path).name
            if name.startswith(".env"):
                return "Access denied"
            if name in BLOCKED_FILENAMES or name.endswith(BLOCKED_SUFFIXES):
                return "Access denied"
    return await call_tool(tool_name, args, None)


def get_filesystem_mcp() -> AbstractToolset | None:
    working_path = config_manager.get_working_path()

    fs_server = MCPServerStdio(
        "npx",
        args=[
            "-y",
            "@modelcontextprotocol/server-filesystem",
            str(working_path),
        ],
        process_tool_call=block_dotenv,
    )

    return fs_server.filtered(lambda _ctx, tool_def: tool_def.name in ALLOWED_TOOLS)


fs_mcp = get_filesystem_mcp()
