from pydantic_ai.models import Model
from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.models.google import GoogleModel
from pydantic_ai.models.groq import GroqModel
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.anthropic import AnthropicProvider
from pydantic_ai.providers.google import GoogleProvider
from pydantic_ai.providers.groq import GroqProvider
from pydantic_ai.providers.ollama import OllamaProvider
from pydantic_ai.providers.openai import OpenAIProvider
from pydantic_ai.settings import ModelSettings

from . import config_manager


def get_model() -> Model:
    provider = config_manager.get("provider")
    if provider is None:
        raise ValueError("Missing provider configuration")

    model_name = config_manager.get("model")
    if not model_name:
        raise ValueError("Missing model configuration")

    api_key = config_manager.get_api_key(provider)
    ollama_base_url = config_manager.get("ollama_base_url")

    if provider == "openai":
        return OpenAIChatModel(model_name=model_name, provider=OpenAIProvider(api_key=api_key))
    if provider == "ollama":
        if not ollama_base_url:
            raise ValueError("Missing Ollama base URL configuration")
        return OpenAIChatModel(
            model_name=model_name, provider=OllamaProvider(base_url=ollama_base_url)
        )
    if provider == "google":
        return GoogleModel(model_name=model_name, provider=GoogleProvider(api_key=api_key))
    if provider == "anthropic":
        return AnthropicModel(
            model_name=model_name,
            provider=AnthropicProvider(api_key=api_key),
        )
    if provider == "groq":
        return GroqModel(model_name=model_name, provider=GroqProvider(api_key=api_key))
    raise ValueError(f"Unsupported provider: {provider!r}")


def get_model_settings():
    return ModelSettings(
        temperature=0.1,
        top_p=0.9,
        max_tokens=4096,
        frequency_penalty=0.0,
        presence_penalty=0.0,
        timeout=60.0,
    )
