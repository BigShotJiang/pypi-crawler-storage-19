"use strict";
(self["webpackChunkdeepanalyze"] = self["webpackChunkdeepanalyze"] || []).push([["lib_index_js"],{

/***/ "./lib/deepanalyze/api.js":
/*!********************************!*\
  !*** ./lib/deepanalyze/api.js ***!
  \********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.streamRewriteCellSource = exports.rewriteCellSource = exports.sendFrontendLog = exports.streamAgentFeedback = exports.sendAgentFeedback = exports.streamChatMessage = exports.sendChatMessage = exports.upsertModelConfig = exports.setModelApiKey = exports.fetchModels = void 0;
const coreutils_1 = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
const services_1 = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
const storage_1 = __webpack_require__(/*! ./storage */ "./lib/deepanalyze/storage.js");
async function fetchModels() {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'models');
    const response = await services_1.ServerConnection.makeRequest(requestUrl, { method: 'GET' }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    return (await response.json());
}
exports.fetchModels = fetchModels;
async function setModelApiKey(model_id, api_key) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'models', 'key');
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify({ model_id, api_key }),
        headers: { 'Content-Type': 'application/json' }
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    const data = (await response.json());
    return (data?.api_key_status ?? { model_id, status: 'invalid', has_key: Boolean(api_key) });
}
exports.setModelApiKey = setModelApiKey;
async function upsertModelConfig(payload) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'models', 'upsert');
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify(payload),
        headers: { 'Content-Type': 'application/json' }
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    const data = (await response.json());
    if (!data?.model) {
        throw new Error('upsertModelConfig: invalid response');
    }
    return data.model;
}
exports.upsertModelConfig = upsertModelConfig;
async function sendChatMessage(message, model_id, prompt_lang) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'chat');
    const sessionId = (0, storage_1.getDeepAnalyzeItem)('sessionId').trim();
    const session_id = sessionId ? sessionId : undefined;
    const context = {
        workspaceDir: (0, storage_1.getDeepAnalyzeItem)('activeWorkspaceDir') || undefined,
        outputPath: (0, storage_1.getDeepAnalyzeItem)('activeOutputPath') || undefined,
        scratchPath: (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') || undefined
    };
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify({ message, context, session_id, model_id, prompt_lang }),
        headers: { 'Content-Type': 'application/json' }
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    return (await response.json());
}
exports.sendChatMessage = sendChatMessage;
async function* streamChatMessage(message, model_id, prompt_lang) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'chat', 'stream');
    const sessionId = (0, storage_1.getDeepAnalyzeItem)('sessionId').trim();
    const session_id = sessionId ? sessionId : undefined;
    const context = {
        workspaceDir: (0, storage_1.getDeepAnalyzeItem)('activeWorkspaceDir') || undefined,
        outputPath: (0, storage_1.getDeepAnalyzeItem)('activeOutputPath') || undefined,
        scratchPath: (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') || undefined
    };
    // 注意：这里用 `ServerConnection.makeRequest`，以便自动带上 Jupyter 的 baseUrl 与鉴权（token/cookie）。
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify({ message, context, session_id, model_id, prompt_lang }),
        headers: { 'Content-Type': 'application/json' }
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    if (!response.body) {
        throw new Error('stream response.body is empty');
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
    // SSE 基本格式：一段事件由若干行组成，以空行结束；这里仅消费 `data:` 行并拼成 JSON。
    const parseEvent = (chunk) => {
        const lines = chunk
            .split('\n')
            .map(line => line.trimEnd())
            .filter(line => line.length > 0);
        const dataLines = lines
            .filter(line => line.startsWith('data:'))
            .map(line => line.slice('data:'.length).trim());
        if (dataLines.length === 0) {
            return null;
        }
        const payloadText = dataLines.join('\n').trim();
        if (!payloadText) {
            return null;
        }
        try {
            return JSON.parse(payloadText);
        }
        catch {
            return null;
        }
    };
    while (true) {
        const { value, done } = await reader.read();
        if (done) {
            break;
        }
        buffer += decoder.decode(value, { stream: true });
        while (true) {
            const idx = buffer.indexOf('\n\n');
            if (idx < 0) {
                break;
            }
            const raw = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 2);
            const event = parseEvent(raw);
            if (event) {
                yield event;
                if (event.type === 'final') {
                    return;
                }
            }
        }
    }
}
exports.streamChatMessage = streamChatMessage;
async function sendAgentFeedback(payload) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'agent', 'feedback');
    const context = {
        workspaceDir: (0, storage_1.getDeepAnalyzeItem)('activeWorkspaceDir') || undefined,
        outputPath: (0, storage_1.getDeepAnalyzeItem)('activeOutputPath') || undefined,
        scratchPath: (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') || undefined
    };
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify({ ...payload, context }),
        headers: { 'Content-Type': 'application/json' }
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    return (await response.json());
}
exports.sendAgentFeedback = sendAgentFeedback;
async function* streamAgentFeedback(payload) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'agent', 'feedback', 'stream');
    const context = {
        workspaceDir: (0, storage_1.getDeepAnalyzeItem)('activeWorkspaceDir') || undefined,
        outputPath: (0, storage_1.getDeepAnalyzeItem)('activeOutputPath') || undefined,
        scratchPath: (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') || undefined
    };
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify({ ...payload, context }),
        headers: { 'Content-Type': 'application/json' }
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    if (!response.body) {
        throw new Error('stream response.body is empty');
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
    // 事件解析逻辑与 `streamChatMessage` 一致（start/delta/final）。
    const parseEvent = (chunk) => {
        const lines = chunk
            .split('\n')
            .map(line => line.trimEnd())
            .filter(line => line.length > 0);
        const dataLines = lines
            .filter(line => line.startsWith('data:'))
            .map(line => line.slice('data:'.length).trim());
        if (dataLines.length === 0) {
            return null;
        }
        const payloadText = dataLines.join('\n').trim();
        if (!payloadText) {
            return null;
        }
        try {
            return JSON.parse(payloadText);
        }
        catch {
            return null;
        }
    };
    while (true) {
        const { value, done } = await reader.read();
        if (done) {
            break;
        }
        buffer += decoder.decode(value, { stream: true });
        while (true) {
            const idx = buffer.indexOf('\n\n');
            if (idx < 0) {
                break;
            }
            const raw = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 2);
            const event = parseEvent(raw);
            if (event) {
                yield event;
                if (event.type === 'final') {
                    return;
                }
            }
        }
    }
}
exports.streamAgentFeedback = streamAgentFeedback;
async function sendFrontendLog(payload) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'frontend', 'log');
    const context = {
        workspaceDir: (0, storage_1.getDeepAnalyzeItem)('activeWorkspaceDir') || undefined,
        outputPath: (0, storage_1.getDeepAnalyzeItem)('activeOutputPath') || undefined,
        scratchPath: (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') || undefined
    };
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify({ ...payload, context }),
        headers: { 'Content-Type': 'application/json' }
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    return (await response.json());
}
exports.sendFrontendLog = sendFrontendLog;
async function rewriteCellSource(payload) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'cell', 'rewrite');
    const { signal, ...body } = payload;
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify(body),
        headers: { 'Content-Type': 'application/json' },
        signal
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    return (await response.json());
}
exports.rewriteCellSource = rewriteCellSource;
async function* streamRewriteCellSource(payload) {
    const settings = services_1.ServerConnection.makeSettings();
    const requestUrl = coreutils_1.URLExt.join(settings.baseUrl, 'deepanalyze', 'cell', 'rewrite', 'stream');
    const { signal, ...body } = payload;
    const response = await services_1.ServerConnection.makeRequest(requestUrl, {
        method: 'POST',
        body: JSON.stringify(body),
        headers: { 'Content-Type': 'application/json' },
        signal
    }, settings);
    if (!response.ok) {
        throw new services_1.ServerConnection.ResponseError(response);
    }
    if (!response.body) {
        throw new Error('stream response.body is empty');
    }
    const reader = response.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
    // 单元格改写的流式协议与 chat 类似（start/delta/final），单独定义事件类型便于最终携带 error。
    const parseEvent = (chunk) => {
        const lines = chunk
            .split('\n')
            .map(line => line.trimEnd())
            .filter(line => line.length > 0);
        const dataLines = lines
            .filter(line => line.startsWith('data:'))
            .map(line => line.slice('data:'.length).trim());
        if (dataLines.length === 0) {
            return null;
        }
        const payloadText = dataLines.join('\n').trim();
        if (!payloadText) {
            return null;
        }
        try {
            return JSON.parse(payloadText);
        }
        catch {
            return null;
        }
    };
    while (true) {
        const { value, done } = await reader.read();
        if (done) {
            break;
        }
        buffer += decoder.decode(value, { stream: true });
        while (true) {
            const idx = buffer.indexOf('\n\n');
            if (idx < 0) {
                break;
            }
            const raw = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 2);
            const event = parseEvent(raw);
            if (event) {
                yield event;
                if (event.type === 'final') {
                    return;
                }
            }
        }
    }
}
exports.streamRewriteCellSource = streamRewriteCellSource;


/***/ }),

/***/ "./lib/deepanalyze/chatPanel.js":
/*!**************************************!*\
  !*** ./lib/deepanalyze/chatPanel.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DeepAnalyzeChatPanel = void 0;
const widgets_1 = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
const apputils_1 = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
const api_1 = __webpack_require__(/*! ./api */ "./lib/deepanalyze/api.js");
const storage_1 = __webpack_require__(/*! ./storage */ "./lib/deepanalyze/storage.js");
class DeepAnalyzeChatPanel extends widgets_1.Widget {
    messagesNode;
    inputNode;
    sendButtonNode;
    continueButtonNode;
    abortButtonNode;
    autoToggleNode;
    modelSelectorNode;
    modelButtonNode;
    modelButtonDotNode;
    modelButtonLabelNode;
    promptLangSelectNode;
    modelMenuNode;
    documentClickHandler = null;
    wheelChainingHandler = null;
    models = [];
    activeModelId = '';
    promptLang = 'zh';
    hiddenTabBarNode = null;
    onReset;
    onNavigateToCell;
    onModelStream;
    onToolResult;
    // UI 状态机：
    // - isBusy: 防止并发发送
    // - isModelGenerating: 控制“生成中...”提示与按钮状态
    // - isAwaitingFeedback: 表示需要执行回环（通常：模型给了 Code 但还没给 Answer）
    isBusy = false;
    isModelGenerating = false;
    isAwaitingFeedback = false;
    historyKey;
    history = [];
    markedModule = null;
    markedModulePromise = null;
    markdownRenderer = null;
    workingMessageNode = null;
    workingMessageLabelNode = null;
    activeTraceTurnId = null;
    currentTurnId = null;
    traceStateByTurnId = new Map();
    traceBubblesByTurnId = new Map();
    assistantBubbleByTurnId = new Map();
    streamUiByTurnId = new Map();
    awaitingDecisionPromise = null;
    awaitingDecisionResolve = null;
    autoContinueKey = (0, storage_1.deepAnalyzeStorageKey)('autoContinue');
    constructor(options = {}) {
        super();
        this.addClass('deepanalyze-chat-panel');
        this.title.label = 'DeepAnalyze 对话';
        this.title.closable = false;
        this.onReset = options.onReset;
        this.onNavigateToCell = options.onNavigateToCell;
        this.onModelStream = options.onModelStream;
        this.onToolResult = options.onToolResult;
        const card = document.createElement('div');
        card.className = 'deepanalyze-chat-card';
        const header = document.createElement('div');
        header.className = 'deepanalyze-chat-panel-header';
        const headerTitle = document.createElement('div');
        headerTitle.className = 'deepanalyze-chat-panel-title';
        headerTitle.textContent = 'DeepAnalyze';
        header.appendChild(headerTitle);
        const headerActions = document.createElement('div');
        headerActions.className = 'deepanalyze-chat-panel-actions';
        const resetButton = document.createElement('button');
        resetButton.className = 'deepanalyze-chat-exit-button';
        resetButton.type = 'button';
        resetButton.textContent = '重置';
        resetButton.addEventListener('click', () => void this.handleReset());
        headerActions.appendChild(resetButton);
        const exitButton = document.createElement('button');
        exitButton.className = 'deepanalyze-chat-exit-button';
        exitButton.type = 'button';
        exitButton.textContent = '返回';
        exitButton.addEventListener('click', () => options.onExit?.());
        headerActions.appendChild(exitButton);
        header.appendChild(headerActions);
        const messages = document.createElement('div');
        messages.className = 'deepanalyze-chat-messages';
        this.messagesNode = messages;
        this.installWheelScrollChaining();
        const inputWrapper = document.createElement('div');
        inputWrapper.className = 'deepanalyze-chat-input-wrapper';
        const composer = document.createElement('div');
        composer.className = 'deepanalyze-chat-composer';
        const input = document.createElement('textarea');
        input.className = 'deepanalyze-chat-input';
        input.placeholder = '输入消息，Enter 发送，Shift+Enter 换行…';
        input.rows = 2;
        composer.appendChild(input);
        this.inputNode = input;
        const actions = document.createElement('div');
        actions.className = 'deepanalyze-chat-actions';
        const modelSelector = document.createElement('div');
        modelSelector.className = 'deepanalyze-chat-model-selector';
        const modelButton = document.createElement('button');
        modelButton.className = 'deepanalyze-chat-model-button';
        modelButton.type = 'button';
        const modelDot = document.createElement('span');
        modelDot.className = 'deepanalyze-model-dot deepanalyze-model-dot-ok';
        modelButton.appendChild(modelDot);
        const modelLabel = document.createElement('span');
        modelLabel.className = 'deepanalyze-chat-model-label';
        modelLabel.textContent = 'DeepAnalyze 8B';
        modelButton.appendChild(modelLabel);
        const modelCaret = document.createElement('span');
        modelCaret.className = 'deepanalyze-chat-model-caret';
        modelCaret.textContent = '▾';
        modelButton.appendChild(modelCaret);
        const modelMenu = document.createElement('div');
        modelMenu.className = 'deepanalyze-chat-model-menu';
        modelMenu.style.display = 'none';
        const langSelect = document.createElement('select');
        langSelect.className = 'deepanalyze-chat-lang-select';
        langSelect.title = '语言偏好（决定使用中文或英文 system prompt）';
        const optZh = document.createElement('option');
        optZh.value = 'zh';
        optZh.textContent = '中文';
        const optEn = document.createElement('option');
        optEn.value = 'en';
        optEn.textContent = 'English';
        langSelect.appendChild(optZh);
        langSelect.appendChild(optEn);
        modelSelector.appendChild(modelButton);
        modelSelector.appendChild(langSelect);
        modelSelector.appendChild(modelMenu);
        actions.appendChild(modelSelector);
        this.modelSelectorNode = modelSelector;
        this.modelButtonNode = modelButton;
        this.modelButtonDotNode = modelDot;
        this.modelButtonLabelNode = modelLabel;
        this.promptLangSelectNode = langSelect;
        this.modelMenuNode = modelMenu;
        const continueButton = document.createElement('button');
        continueButton.className = 'deepanalyze-chat-control-button deepanalyze-chat-continue-button';
        continueButton.type = 'button';
        continueButton.textContent = '继续';
        actions.appendChild(continueButton);
        this.continueButtonNode = continueButton;
        const abortButton = document.createElement('button');
        abortButton.className = 'deepanalyze-chat-control-button deepanalyze-chat-abort-button';
        abortButton.type = 'button';
        abortButton.textContent = '中止';
        actions.appendChild(abortButton);
        this.abortButtonNode = abortButton;
        const autoLabel = document.createElement('label');
        autoLabel.className = 'deepanalyze-chat-auto-toggle';
        const autoToggle = document.createElement('input');
        autoToggle.type = 'checkbox';
        autoToggle.checked = this.getAutoContinueEnabled();
        autoLabel.appendChild(autoToggle);
        const autoText = document.createElement('span');
        autoText.textContent = '自动';
        autoLabel.appendChild(autoText);
        actions.appendChild(autoLabel);
        this.autoToggleNode = autoToggle;
        const sendButton = document.createElement('button');
        sendButton.className = 'deepanalyze-chat-send-button';
        sendButton.type = 'button';
        sendButton.textContent = '发送';
        actions.appendChild(sendButton);
        this.sendButtonNode = sendButton;
        composer.appendChild(actions);
        inputWrapper.appendChild(composer);
        card.appendChild(header);
        card.appendChild(messages);
        card.appendChild(inputWrapper);
        this.node.appendChild(card);
        this.inputNode.addEventListener('keydown', event => {
            if (event.key !== 'Enter') {
                return;
            }
            if (event.shiftKey) {
                return;
            }
            event.preventDefault();
            void this.handleSend();
        });
        this.sendButtonNode.addEventListener('click', () => void this.handleSend());
        this.continueButtonNode.addEventListener('click', () => this.resolveAwaitDecision('continue'));
        this.abortButtonNode.addEventListener('click', () => this.resolveAwaitDecision('abort'));
        this.autoToggleNode.addEventListener('change', () => this.setAutoContinueEnabled(this.autoToggleNode.checked));
        this.activeModelId = ((0, storage_1.getDeepAnalyzeItem)('modelId') || '').trim();
        if (!this.normalizeModelId(this.activeModelId)) {
            this.setActiveModelId('deepanalyze_8b');
        }
        const storedPromptLang = ((0, storage_1.getDeepAnalyzeItem)('promptLang') || '').trim();
        this.promptLang = this.normalizePromptLang(storedPromptLang || 'zh');
        this.promptLangSelectNode.value = this.promptLang;
        if (!storedPromptLang) {
            (0, storage_1.setDeepAnalyzeItem)('promptLang', this.promptLang);
        }
        this.modelButtonNode.addEventListener('click', event => {
            event.preventDefault();
            event.stopPropagation();
            this.toggleModelMenu();
        });
        this.promptLangSelectNode.addEventListener('change', () => {
            const next = this.normalizePromptLang(this.promptLangSelectNode.value);
            this.promptLang = next;
            (0, storage_1.setDeepAnalyzeItem)('promptLang', next);
        });
        this.documentClickHandler = event => {
            const target = event.target;
            if (!target) {
                return;
            }
            if (!this.modelSelectorNode.contains(target)) {
                this.hideModelMenu();
            }
        };
        document.addEventListener('click', this.documentClickHandler, true);
        void this.refreshModels();
        this.historyKey = this.buildHistoryKey();
        void this.ensureMarkdownReady();
        const restored = this.restoreHistory();
        if (!restored) {
            this.addMessage('assistant', '这里是 DeepAnalyze 对话框。');
        }
        this.syncControlState();
    }
    onAfterAttach() {
        this.inputNode.focus();
        const tabSelector = `.lm-DockPanel-tabBar .lm-TabBar-tab[data-id="${this.id}"], .jp-DockPanel-tabBar .lm-TabBar-tab[data-id="${this.id}"]`;
        const tab = document.querySelector(tabSelector);
        const tabBar = tab?.closest('.lm-DockPanel-tabBar, .jp-DockPanel-tabBar');
        tabBar?.classList.add('deepanalyze-hidden-tabbar');
        this.hiddenTabBarNode = tabBar;
    }
    dispose() {
        if (this.isDisposed) {
            return;
        }
        if (this.documentClickHandler) {
            document.removeEventListener('click', this.documentClickHandler, true);
            this.documentClickHandler = null;
        }
        if (this.wheelChainingHandler) {
            this.messagesNode.removeEventListener('wheel', this.wheelChainingHandler, true);
            this.wheelChainingHandler = null;
        }
        this.hiddenTabBarNode?.classList.remove('deepanalyze-hidden-tabbar');
        this.hiddenTabBarNode = null;
        super.dispose();
    }
    installWheelScrollChaining() {
        if (this.wheelChainingHandler) {
            return;
        }
        const handler = (event) => {
            const target = event.target;
            if (!target) {
                return;
            }
            const inner = target.closest('.deepanalyze-chat-stream-block-content-code, .deepanalyze-chat-stream-block-content-markdown');
            if (!inner) {
                return;
            }
            const outer = this.messagesNode;
            let deltaY = event.deltaY;
            if (event.deltaMode === 1) {
                deltaY *= 16;
            }
            else if (event.deltaMode === 2) {
                deltaY *= outer.clientHeight;
            }
            if (!deltaY) {
                return;
            }
            const eps = 1;
            const atTop = inner.scrollTop <= eps;
            const atBottom = inner.scrollTop + inner.clientHeight >= inner.scrollHeight - eps;
            const wantsUp = deltaY < 0;
            const wantsDown = deltaY > 0;
            if ((wantsUp && atTop) || (wantsDown && atBottom)) {
                outer.scrollTop += deltaY;
                event.preventDefault();
                event.stopPropagation();
            }
        };
        this.wheelChainingHandler = handler;
        this.messagesNode.addEventListener('wheel', handler, { passive: false, capture: true });
    }
    buildHistoryKey() {
        const sessionId = (0, storage_1.getDeepAnalyzeItem)('sessionId');
        const workspaceDir = (0, storage_1.getDeepAnalyzeItem)('activeWorkspaceDir');
        const suffix = (sessionId || workspaceDir || 'default').trim();
        const modelId = ((0, storage_1.getDeepAnalyzeItem)('modelId') || 'default').trim();
        const scope = (0, storage_1.deepAnalyzeScopeId)();
        return `deepanalyze.chatHistory@${scope}:${suffix}:${modelId}`;
    }
    persistHistory() {
        const maxItems = 200;
        const trimmed = this.history.slice(Math.max(0, this.history.length - maxItems));
        try {
            window.localStorage.setItem(this.historyKey, JSON.stringify(trimmed));
        }
        catch {
            // ignore quota errors
        }
    }
    restoreHistory() {
        try {
            const raw = window.localStorage.getItem(this.historyKey);
            if (!raw) {
                return false;
            }
            const parsed = JSON.parse(raw);
            if (!Array.isArray(parsed) || parsed.length === 0) {
                return false;
            }
            const items = [];
            for (const item of parsed) {
                const role = item?.role;
                const text = String(item?.text ?? '');
                if (!role || !text) {
                    continue;
                }
                if (role !== 'user' && role !== 'assistant' && role !== 'system') {
                    continue;
                }
                const turnIdRaw = item?.turnId;
                const turnId = typeof turnIdRaw === 'string' && turnIdRaw.trim() ? turnIdRaw.trim() : undefined;
                const hidden = Boolean(item?.hidden);
                const traceRaw = item?.trace;
                let trace = undefined;
                if (traceRaw && typeof traceRaw === 'object') {
                    const list = Array.isArray(traceRaw?.items) ? traceRaw.items : [];
                    const restoredItems = [];
                    for (const t of list) {
                        const id = String(t?.id ?? '').trim();
                        const tag = String(t?.tag ?? '').trim();
                        const label = String(t?.label ?? '').trim();
                        const path = String(t?.path ?? '').trim();
                        const index = Number.isFinite(t?.index) ? Number(t.index) : NaN;
                        if (!id || !tag || !label || !path || !Number.isFinite(index) || index < 0) {
                            continue;
                        }
                        restoredItems.push({ id, tag, label, path, index });
                    }
                    const activeId = String(traceRaw?.activeId ?? '').trim() || undefined;
                    if (restoredItems.length > 0) {
                        trace = { items: restoredItems, activeId };
                    }
                }
                items.push({ role, text, turnId, hidden, trace });
            }
            if (items.length === 0) {
                return false;
            }
            const hiddenAssistantByTurnId = new Map();
            for (const record of items) {
                if (record.role !== 'assistant' || !record.hidden) {
                    continue;
                }
                const id = record.turnId;
                if (!id) {
                    continue;
                }
                const list = hiddenAssistantByTurnId.get(id) ?? [];
                list.push(record.text);
                hiddenAssistantByTurnId.set(id, list);
            }
            // 兼容旧版本：历史里可能存在“仅用于恢复的 assistant_raw_updates”，它们在运行时并未渲染到 UI。
            // 旧格式缺少 `hidden` 标记，因此这里按“同一轮 user 之后出现多条带标签的 assistant”做一次折叠。
            let seenTaggedAssistant = false;
            for (const record of items) {
                if (record.role === 'user') {
                    seenTaggedAssistant = false;
                    continue;
                }
                if (record.role !== 'assistant' || record.hidden) {
                    continue;
                }
                if (record.turnId) {
                    continue;
                }
                const tagged = /<(Analyze|Understand|Code|Answer)>/i.test(record.text);
                if (!tagged) {
                    continue;
                }
                if (seenTaggedAssistant) {
                    record.hidden = true;
                    continue;
                }
                seenTaggedAssistant = true;
            }
            for (const item of items) {
                if (item.hidden) {
                    continue;
                }
                if (item.role === 'assistant' && item.turnId && item.trace?.items?.length) {
                    this.restoreTraceState(item.turnId, item.trace);
                }
                let displayText = item.text;
                if (item.role === 'assistant' && item.turnId) {
                    const hiddenList = hiddenAssistantByTurnId.get(item.turnId) ?? [];
                    if (hiddenList.length > 0) {
                        const countTags = (s) => (String(s ?? '').match(/<(Analyze|Understand|Code|Answer)>/gi) ?? []).length;
                        const combined = hiddenList.join('\n\n').trim();
                        if (countTags(combined) > countTags(displayText)) {
                            displayText = combined;
                        }
                    }
                }
                this.addMessage(item.role, displayText, { persist: false, turnId: item.turnId });
            }
            this.history.push(...items);
            return true;
        }
        catch {
            return false;
        }
    }
    normalizeModelId(raw) {
        return String(raw ?? '')
            .trim()
            .toLowerCase()
            .replace(/\s+/g, '_');
    }
    normalizePromptLang(raw) {
        const v = String(raw ?? '')
            .trim()
            .toLowerCase();
        if (v === 'zh' || v === 'zh-cn' || v === 'zh_cn' || v === 'cn') {
            return 'zh';
        }
        if (v === 'en' || v === 'en-us' || v === 'en_us') {
            return 'en';
        }
        return 'zh';
    }
    getPromptLang() {
        return this.normalizePromptLang(this.promptLang || 'zh');
    }
    getSelectedModel() {
        const current = this.normalizeModelId(this.activeModelId);
        if (!current) {
            return null;
        }
        for (const model of this.models) {
            if (this.normalizeModelId(model.id) === current) {
                return model;
            }
        }
        return null;
    }
    getModelDotStatus(model) {
        if (!model) {
            return 'ok';
        }
        if (!model.requires_api_key) {
            return 'ok';
        }
        const status = String(model.api_key_status?.status ?? '').toLowerCase().trim();
        return status === 'ok' ? 'ok' : 'bad';
    }
    setActiveModelId(modelId) {
        const normalized = this.normalizeModelId(modelId);
        this.activeModelId = normalized;
        (0, storage_1.setDeepAnalyzeItem)('modelId', normalized);
    }
    renderModelButton() {
        const selected = this.getSelectedModel();
        const label = selected?.label || this.activeModelId || 'DeepAnalyze 8B';
        this.modelButtonLabelNode.textContent = label;
        const status = this.getModelDotStatus(selected);
        this.modelButtonDotNode.className =
            status === 'ok' ? 'deepanalyze-model-dot deepanalyze-model-dot-ok' : 'deepanalyze-model-dot deepanalyze-model-dot-bad';
    }
    renderModelMenu() {
        const menu = this.modelMenuNode;
        menu.innerHTML = '';
        const models = this.models.length > 0
            ? this.models
            : [
                {
                    id: 'deepanalyze_8b',
                    label: 'DeepAnalyze 8B',
                    backend: 'vllm',
                    prompt_name: 'deepanalyze_8b',
                    requires_api_key: false
                }
            ];
        const selectedId = this.normalizeModelId(this.activeModelId);
        for (const model of models) {
            const row = document.createElement('div');
            row.className = 'deepanalyze-chat-model-item';
            if (this.normalizeModelId(model.id) === selectedId) {
                row.classList.add('is-active');
            }
            const dot = document.createElement('span');
            const dotStatus = this.getModelDotStatus(model);
            dot.className =
                dotStatus === 'ok' ? 'deepanalyze-model-dot deepanalyze-model-dot-ok' : 'deepanalyze-model-dot deepanalyze-model-dot-bad';
            row.appendChild(dot);
            const text = document.createElement('span');
            text.className = 'deepanalyze-chat-model-item-label';
            text.textContent = model.label || model.id;
            row.appendChild(text);
            const gear = document.createElement('button');
            gear.type = 'button';
            gear.className = 'deepanalyze-chat-model-gear';
            gear.title = '配置该模型';
            gear.textContent = '⚙';
            row.appendChild(gear);
            dot.addEventListener('click', event => {
                event.preventDefault();
                event.stopPropagation();
                if (dotStatus === 'ok') {
                    this.setActiveModelId(model.id);
                    this.renderModelButton();
                    this.hideModelMenu();
                }
                else {
                    void this.openApiKeyDialog(model);
                }
            });
            gear.addEventListener('click', event => {
                event.preventDefault();
                event.stopPropagation();
                void this.openModelConfigDialog(model);
            });
            row.addEventListener('click', () => {
                if (dotStatus === 'ok') {
                    this.setActiveModelId(model.id);
                    this.renderModelButton();
                    this.hideModelMenu();
                }
                else {
                    void this.openApiKeyDialog(model);
                }
            });
            menu.appendChild(row);
        }
        const addRow = document.createElement('div');
        addRow.className = 'deepanalyze-chat-model-item deepanalyze-chat-model-item-add';
        addRow.textContent = '+ 添加自定义模型';
        addRow.addEventListener('click', () => void this.openAddCustomModelDialog());
        menu.appendChild(addRow);
    }
    toggleModelMenu() {
        if (this.modelMenuNode.style.display === 'none') {
            this.modelMenuNode.style.display = 'block';
            // 展开时尽量刷新一次状态（比如用户刚设置过 key）
            void this.refreshModels();
            return;
        }
        this.hideModelMenu();
    }
    hideModelMenu() {
        this.modelMenuNode.style.display = 'none';
    }
    async refreshModels() {
        try {
            const data = await (0, api_1.fetchModels)();
            const models = Array.isArray(data?.models) ? data.models : [];
            this.models = models;
            const defaultId = this.normalizeModelId(String(data?.default_model_id ?? 'deepanalyze_8b'));
            let nextId = this.normalizeModelId(this.activeModelId) || defaultId || 'deepanalyze_8b';
            if (models.length > 0 && !models.some(m => this.normalizeModelId(m.id) === nextId)) {
                nextId = defaultId || this.normalizeModelId(models[0]?.id ?? '') || 'deepanalyze_8b';
            }
            this.setActiveModelId(nextId);
            this.renderModelButton();
            this.renderModelMenu();
        }
        catch {
            if (!this.normalizeModelId(this.activeModelId)) {
                this.setActiveModelId('deepanalyze_8b');
            }
            this.renderModelButton();
            this.renderModelMenu();
        }
    }
    async openApiKeyDialog(model) {
        const wrapper = document.createElement('div');
        wrapper.className = 'deepanalyze-chat-model-key-dialog';
        const hint = document.createElement('div');
        hint.className = 'deepanalyze-chat-model-key-hint';
        hint.textContent = `为「${model.label || model.id}」设置 API Key（保存后将进行一次校验）。`;
        wrapper.appendChild(hint);
        const input = document.createElement('input');
        input.type = 'password';
        input.placeholder = '请输入 API Key（例如 sk-...）';
        input.className = 'deepanalyze-chat-model-key-input';
        wrapper.appendChild(input);
        const body = new widgets_1.Widget({ node: wrapper });
        const result = await (0, apputils_1.showDialog)({
            title: `设置 ${model.label || model.id} API Key`,
            body,
            buttons: [apputils_1.Dialog.cancelButton(), apputils_1.Dialog.okButton({ label: '保存' })]
        });
        if (!result.button.accept) {
            return;
        }
        const value = String(input.value ?? '').trim();
        try {
            const status = await (0, api_1.setModelApiKey)(model.id, value);
            await this.refreshModels();
            const ok = String(status?.status ?? '').toLowerCase() === 'ok';
            if (!ok) {
                const msg = String(status?.last_error ?? '').trim() || '该 API Key 未通过校验，请检查后重试。';
                await (0, apputils_1.showDialog)({
                    title: 'API Key 校验失败',
                    body: msg,
                    buttons: [apputils_1.Dialog.okButton({ label: '知道了' })]
                });
            }
            else {
                // 校验通过后直接选中该模型
                this.setActiveModelId(model.id);
                this.renderModelButton();
                this.hideModelMenu();
            }
        }
        catch (err) {
            await (0, apputils_1.showDialog)({
                title: '设置失败',
                body: String(err),
                buttons: [apputils_1.Dialog.okButton({ label: '知道了' })]
            });
        }
    }
    async openModelConfigDialog(model) {
        const wrapper = document.createElement('div');
        wrapper.className = 'deepanalyze-chat-model-config-dialog';
        const makeField = (label, input) => {
            const row = document.createElement('div');
            row.className = 'deepanalyze-chat-model-config-row';
            const l = document.createElement('div');
            l.className = 'deepanalyze-chat-model-config-label';
            l.textContent = label;
            row.appendChild(l);
            row.appendChild(input);
            return row;
        };
        const baseUrlInput = document.createElement('input');
        baseUrlInput.className = 'deepanalyze-chat-model-key-input';
        baseUrlInput.placeholder = 'https://.../v1';
        baseUrlInput.value = String(model.base_url ?? '');
        const modelNameInput = document.createElement('input');
        modelNameInput.className = 'deepanalyze-chat-model-key-input';
        modelNameInput.placeholder = '模型名称（例如 gpt-4o-mini / deepseek-chat）';
        modelNameInput.value = String(model.model ?? '');
        const tempInput = document.createElement('input');
        tempInput.type = 'number';
        tempInput.step = '0.1';
        tempInput.min = '0';
        tempInput.max = '2';
        tempInput.className = 'deepanalyze-chat-model-key-input';
        tempInput.value =
            model.temperature === undefined || model.temperature === null ? '' : String(model.temperature);
        wrapper.appendChild(makeField('Base URL', baseUrlInput));
        wrapper.appendChild(makeField('Model', modelNameInput));
        wrapper.appendChild(makeField('温度 (temperature)', tempInput));
        let apiKeyInput = null;
        if (model.requires_api_key) {
            apiKeyInput = document.createElement('input');
            apiKeyInput.type = 'password';
            apiKeyInput.className = 'deepanalyze-chat-model-key-input';
            apiKeyInput.placeholder = '留空则不修改已保存的 API Key';
            wrapper.appendChild(makeField('API Key', apiKeyInput));
        }
        const body = new widgets_1.Widget({ node: wrapper });
        const result = await (0, apputils_1.showDialog)({
            title: `配置 ${model.label || model.id}`,
            body,
            buttons: [apputils_1.Dialog.cancelButton(), apputils_1.Dialog.okButton({ label: '保存' })]
        });
        if (!result.button.accept) {
            return;
        }
        const payload = {
            model_id: model.id,
            base_url: String(baseUrlInput.value ?? '').trim(),
            model: String(modelNameInput.value ?? '').trim()
        };
        const tempRaw = String(tempInput.value ?? '').trim();
        if (tempRaw) {
            const t = Number(tempRaw);
            if (!Number.isNaN(t)) {
                payload.temperature = t;
            }
        }
        const key = apiKeyInput ? String(apiKeyInput.value ?? '').trim() : '';
        if (key) {
            payload.api_key = key;
        }
        try {
            await (0, api_1.upsertModelConfig)(payload);
            await this.refreshModels();
            // 配置完成后保持当前选中不变
            this.hideModelMenu();
        }
        catch (err) {
            await (0, apputils_1.showDialog)({
                title: '保存失败',
                body: String(err),
                buttons: [apputils_1.Dialog.okButton({ label: '知道了' })]
            });
        }
    }
    async openAddCustomModelDialog() {
        const wrapper = document.createElement('div');
        wrapper.className = 'deepanalyze-chat-model-config-dialog';
        const makeField = (label, input) => {
            const row = document.createElement('div');
            row.className = 'deepanalyze-chat-model-config-row';
            const l = document.createElement('div');
            l.className = 'deepanalyze-chat-model-config-label';
            l.textContent = label;
            row.appendChild(l);
            row.appendChild(input);
            return row;
        };
        const labelInput = document.createElement('input');
        labelInput.className = 'deepanalyze-chat-model-key-input';
        labelInput.placeholder = '展示名称（例如 My LLM）';
        const baseUrlInput = document.createElement('input');
        baseUrlInput.className = 'deepanalyze-chat-model-key-input';
        baseUrlInput.placeholder = 'https://.../v1';
        const modelNameInput = document.createElement('input');
        modelNameInput.className = 'deepanalyze-chat-model-key-input';
        modelNameInput.placeholder = '模型名称（例如 gpt-4o-mini / deepseek-chat）';
        const tempInput = document.createElement('input');
        tempInput.type = 'number';
        tempInput.step = '0.1';
        tempInput.min = '0';
        tempInput.max = '2';
        tempInput.className = 'deepanalyze-chat-model-key-input';
        tempInput.placeholder = '默认 0.4';
        const apiKeyInput = document.createElement('input');
        apiKeyInput.type = 'password';
        apiKeyInput.className = 'deepanalyze-chat-model-key-input';
        apiKeyInput.placeholder = 'API Key（可选，保存后会校验）';
        wrapper.appendChild(makeField('名称', labelInput));
        wrapper.appendChild(makeField('Base URL', baseUrlInput));
        wrapper.appendChild(makeField('Model', modelNameInput));
        wrapper.appendChild(makeField('温度 (temperature)', tempInput));
        wrapper.appendChild(makeField('API Key', apiKeyInput));
        const body = new widgets_1.Widget({ node: wrapper });
        const result = await (0, apputils_1.showDialog)({
            title: '添加自定义模型',
            body,
            buttons: [apputils_1.Dialog.cancelButton(), apputils_1.Dialog.okButton({ label: '添加' })]
        });
        if (!result.button.accept) {
            return;
        }
        const payload = {
            label: String(labelInput.value ?? '').trim(),
            base_url: String(baseUrlInput.value ?? '').trim(),
            model: String(modelNameInput.value ?? '').trim()
        };
        const tempRaw = String(tempInput.value ?? '').trim();
        if (tempRaw) {
            const t = Number(tempRaw);
            if (!Number.isNaN(t)) {
                payload.temperature = t;
            }
        }
        const key = String(apiKeyInput.value ?? '').trim();
        if (key) {
            payload.api_key = key;
        }
        try {
            const created = await (0, api_1.upsertModelConfig)(payload);
            await this.refreshModels();
            if (created?.id) {
                this.setActiveModelId(created.id);
                this.renderModelButton();
            }
            this.hideModelMenu();
        }
        catch (err) {
            await (0, apputils_1.showDialog)({
                title: '添加失败',
                body: String(err),
                buttons: [apputils_1.Dialog.okButton({ label: '知道了' })]
            });
        }
    }
    addMessage(role, text, options) {
        const shouldScroll = this.isNearBottom();
        const item = document.createElement('div');
        item.className = `deepanalyze-chat-message deepanalyze-chat-message-${role}`;
        const bubble = document.createElement('div');
        bubble.className = 'deepanalyze-chat-bubble';
        if (role === 'assistant') {
            bubble.dataset.assistantText = String(text ?? '');
            this.renderAssistantContent(bubble, text);
            const turnId = options?.turnId ?? this.currentTurnId ?? '';
            if (turnId) {
                bubble.dataset.deepanalyzeTurnId = turnId;
                const set = this.traceBubblesByTurnId.get(turnId) ?? new Set();
                set.add(bubble);
                this.traceBubblesByTurnId.set(turnId, set);
                if (!options?.turnId) {
                    this.activeTraceTurnId = turnId;
                }
                this.renderTraceBarFromTurn(bubble, turnId);
            }
            else {
                if (!options?.turnId) {
                    this.activeTraceTurnId = null;
                }
            }
        }
        else {
            bubble.textContent = text;
        }
        item.appendChild(bubble);
        const beforeNode = options?.before ?? null;
        if (beforeNode) {
            this.messagesNode.insertBefore(item, beforeNode);
        }
        else {
            this.messagesNode.appendChild(item);
        }
        this.scrollToBottomIfNeeded(shouldScroll);
        const persist = options?.persist === false ? false : true;
        if (persist) {
            const turnId = role === 'assistant' ? options?.turnId ?? this.currentTurnId ?? undefined : undefined;
            const trace = turnId ? this.buildTraceSnapshot(turnId) : undefined;
            this.history.push({ role, text, turnId, trace });
            this.persistHistory();
        }
        return bubble;
    }
    ensureTaggedText(raw) {
        const text = String(raw ?? '').trim();
        if (!text) {
            return '';
        }
        const hasKnownTags = /<(Analyze|Understand|Code|Answer)>\s*[\s\S]*?<\/\1>/i.test(text);
        if (hasKnownTags) {
            return text;
        }
        if (text.includes('<') && text.includes('>')) {
            return text;
        }
        return `<Answer>\n${text}\n</Answer>`;
    }
    showWorkingIndicator() {
        if (this.workingMessageNode) {
            return;
        }
        const shouldScroll = this.isNearBottom();
        const item = document.createElement('div');
        item.className =
            'deepanalyze-chat-message deepanalyze-chat-message-assistant deepanalyze-chat-message-working';
        const bubble = document.createElement('div');
        bubble.className = 'deepanalyze-chat-bubble deepanalyze-chat-working-bubble';
        const indicator = document.createElement('div');
        indicator.className = 'deepanalyze-chat-working-indicator';
        const dot = document.createElement('span');
        dot.className = 'deepanalyze-chat-working-dot';
        indicator.appendChild(dot);
        const label = document.createElement('span');
        label.className = 'deepanalyze-chat-working-text';
        label.textContent = this.isAwaitingFeedback ? 'waiting for user choice' : 'working';
        indicator.appendChild(label);
        this.workingMessageLabelNode = label;
        if (this.isAwaitingFeedback) {
            item.classList.add('deepanalyze-chat-message-working-waiting');
        }
        bubble.appendChild(indicator);
        item.appendChild(bubble);
        this.messagesNode.appendChild(item);
        this.workingMessageNode = item;
        this.scrollToBottomIfNeeded(shouldScroll);
    }
    finalizeWorkingIndicator() {
        const node = this.workingMessageNode;
        if (!node) {
            return;
        }
        node.classList.remove('deepanalyze-chat-message-working-waiting');
        node.classList.add('deepanalyze-chat-message-working-done');
        if (this.workingMessageLabelNode) {
            this.workingMessageLabelNode.textContent = 'done';
        }
        this.workingMessageNode = null;
        this.workingMessageLabelNode = null;
    }
    isAsyncIterable(value) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return typeof value?.[Symbol.asyncIterator] === 'function';
    }
    applyToolResultChunk(chunk) {
        if (!chunk) {
            return;
        }
        const insertBefore = this.workingMessageNode;
        if (typeof chunk === 'string') {
            const text = chunk.trim();
            if (text) {
                this.addMessage('system', text, { before: insertBefore });
            }
            return;
        }
        if (typeof chunk !== 'object') {
            return;
        }
        const update = chunk;
        const systemText = String(update.system_text ?? '').trim();
        if (systemText) {
            this.addMessage('system', systemText, { before: insertBefore });
        }
        const trace = update.trace_update;
        if (trace && typeof trace === 'object') {
            const tag = String(trace.tag ?? '').trim();
            const path = String(trace.path ?? '').trim();
            const index = Number.isFinite(trace.index) ? Number(trace.index) : NaN;
            if (tag && path && Number.isFinite(index) && index >= 0) {
                this.applyTraceUpdateToTurn({ tag, path, index });
            }
        }
        const raws = Array.isArray(update.assistant_raw_updates)
            ? update.assistant_raw_updates
            : [];
        for (const raw of raws) {
            const normalized = this.fixUnclosedTags(this.ensureTaggedText(String(raw ?? '')));
            if (normalized.trim()) {
                // 不在 UI 中重复追加 assistant 消息（会导致 trace 链重复渲染）。
                // 仅保留首条链式标签显示，assistant 原文仍写入本地历史用于恢复。
                const turnId = this.activeTraceTurnId ?? this.currentTurnId ?? undefined;
                this.appendHistoryOnly('assistant', normalized, { hidden: true, turnId });
            }
        }
    }
    appendHistoryOnly(role, text, options) {
        const turnId = options?.turnId;
        const trace = options?.trace;
        const hidden = Boolean(options?.hidden);
        this.history.push({ role, text, turnId, hidden, trace });
        this.persistHistory();
    }
    async loadMarked() {
        if (this.markedModule) {
            return this.markedModule;
        }
        if (!this.markedModulePromise) {
            this.markedModulePromise = __webpack_require__.e(/*! import() */ "webpack_sharing_consume_default_marked_marked").then(__webpack_require__.t.bind(__webpack_require__, /*! marked */ "webpack/sharing/consume/default/marked/marked", 23)).then(m => {
                this.markedModule = m;
                this.markdownRenderer = this.buildMarkdownRenderer(m);
                return m;
            });
        }
        return this.markedModulePromise;
    }
    async ensureMarkdownReady() {
        try {
            await this.loadMarked();
            this.rerenderAssistantMessages();
        }
        catch {
            // ignore
        }
    }
    rerenderAssistantMessages() {
        const nodes = this.messagesNode.querySelectorAll('.deepanalyze-chat-message-assistant .deepanalyze-chat-bubble');
        for (const node of Array.from(nodes)) {
            const el = node;
            const text = el.dataset.assistantText ?? '';
            this.renderAssistantContent(el, text);
        }
    }
    fixUnclosedTags(text) {
        const s = String(text ?? '');
        const tags = ['Analyze', 'Understand', 'Code', 'Answer'];
        let fixed = s;
        for (const tag of tags) {
            const open = new RegExp(`<${tag}>`, 'i');
            const close = new RegExp(`</${tag}>`, 'i');
            if (open.test(fixed) && !close.test(fixed)) {
                fixed = `${fixed}\n</${tag}>`;
            }
        }
        return fixed;
    }
    extractFencedCode(text) {
        const raw = String(text ?? '').trim();
        const match = raw.match(/```(?:python)?\s*([\s\S]*?)```/i);
        if (match) {
            return String(match[1] ?? '').trim();
        }
        return raw;
    }
    parseModules(text) {
        const s = this.fixUnclosedTags(text);
        const pattern = /<(Analyze|Understand|Code|Answer)>([\s\S]*?)<\/\1>/gi;
        const modules = [];
        let match = null;
        while ((match = pattern.exec(s))) {
            const rawTag = String(match[1] ?? '').trim();
            const tag = rawTag
                ? rawTag[0].toUpperCase() + rawTag.slice(1).toLowerCase()
                : rawTag;
            const content = String(match[2] ?? '').trim();
            if (!tag || !content) {
                continue;
            }
            modules.push({ tag, content });
        }
        return modules;
    }
    escapeHtml(raw) {
        const s = String(raw ?? '');
        return s
            .replaceAll('&', '&amp;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;')
            .replaceAll("'", '&#39;');
    }
    buildMarkdownRenderer(markedModule) {
        const renderer = new markedModule.Renderer();
        // 禁用原始 HTML，避免模型输出插入不安全标签。
        renderer.html = (token) => this.escapeHtml(String(token?.text ?? ''));
        renderer.image = (token) => this.escapeHtml(String(token?.text ?? ''));
        renderer.link = (token) => {
            const url = String(token?.href ?? '').trim();
            const label = this.escapeHtml(url || '(link)');
            const safe = url.startsWith('http://') ||
                url.startsWith('https://') ||
                url.startsWith('mailto:') ||
                url.startsWith('#');
            if (!safe) {
                return label;
            }
            const escaped = this.escapeHtml(url);
            return `<a href="${escaped}" target="_blank" rel="noreferrer noopener">${label}</a>`;
        };
        return renderer;
    }
    renderMarkdownInto(host, markdown) {
        const md = String(markdown ?? '').trim();
        if (!md) {
            host.textContent = '';
            return;
        }
        if (!this.markedModule || !this.markdownRenderer) {
            host.textContent = md;
            return;
        }
        try {
            const html = this.markedModule.marked.parse(md, {
                gfm: true,
                breaks: true,
                renderer: this.markdownRenderer
            });
            host.innerHTML = String(html ?? '');
        }
        catch {
            host.textContent = md;
        }
    }
    normalizeStreamTag(raw) {
        const v = String(raw ?? '')
            .trim()
            .toLowerCase();
        if (v === 'analyze') {
            return 'Analyze';
        }
        if (v === 'understand') {
            return 'Understand';
        }
        if (v === 'code') {
            return 'Code';
        }
        if (v === 'answer') {
            return 'Answer';
        }
        return null;
    }
    createStreamUi(turnId) {
        const container = document.createElement('div');
        container.className = 'deepanalyze-chat-stream';
        const rootDetails = document.createElement('details');
        rootDetails.className = 'deepanalyze-chat-stream-root';
        rootDetails.open = true;
        const rootSummary = document.createElement('summary');
        rootSummary.className = 'deepanalyze-chat-stream-root-summary';
        const rootSpinner = document.createElement('span');
        rootSpinner.className = 'deepanalyze-chat-stream-spinner';
        rootSpinner.hidden = true;
        const rootCaret = document.createElement('span');
        rootCaret.className = 'deepanalyze-chat-stream-caret';
        rootCaret.hidden = false;
        const rootLabel = document.createElement('span');
        rootLabel.className = 'deepanalyze-chat-stream-root-label';
        rootLabel.textContent = 'Processing';
        rootSummary.appendChild(rootSpinner);
        rootSummary.appendChild(rootCaret);
        rootSummary.appendChild(rootLabel);
        rootDetails.appendChild(rootSummary);
        const innerNode = document.createElement('div');
        innerNode.className = 'deepanalyze-chat-stream-inner';
        rootDetails.appendChild(innerNode);
        const answerDetails = document.createElement('details');
        answerDetails.className = 'deepanalyze-chat-stream-answer-panel';
        answerDetails.open = true;
        answerDetails.hidden = true;
        const answerSummary = document.createElement('summary');
        answerSummary.className = 'deepanalyze-chat-stream-answer-summary';
        const answerSpinner = document.createElement('span');
        answerSpinner.className = 'deepanalyze-chat-stream-spinner';
        answerSpinner.hidden = true;
        const answerCaret = document.createElement('span');
        answerCaret.className = 'deepanalyze-chat-stream-caret';
        answerCaret.hidden = false;
        const answerLabel = document.createElement('span');
        answerLabel.className = 'deepanalyze-chat-stream-answer-label';
        answerLabel.textContent = 'Answer';
        answerSummary.appendChild(answerSpinner);
        answerSummary.appendChild(answerCaret);
        answerSummary.appendChild(answerLabel);
        answerDetails.appendChild(answerSummary);
        const answerContent = document.createElement('div');
        answerContent.className = 'deepanalyze-chat-stream-answer-content jp-RenderedMarkdown';
        answerDetails.appendChild(answerContent);
        container.appendChild(rootDetails);
        container.appendChild(answerDetails);
        return {
            turnId,
            container,
            rootDetails,
            rootSpinner,
            rootCaret,
            rootLabel,
            answerDetails,
            answerSpinner,
            answerCaret,
            answerLabel,
            answerContent,
            innerNode,
            blocks: [],
            activeBlock: null,
            inAnswer: false,
            answerText: '',
            buffer: '',
            countsByTag: new Map(),
            hasAnswer: false
        };
    }
    ensureStreamUi(turnId, bubble) {
        const existing = this.streamUiByTurnId.get(turnId);
        if (existing) {
            if (existing.container.parentElement !== bubble) {
                bubble.appendChild(existing.container);
            }
            return existing;
        }
        const created = this.createStreamUi(turnId);
        this.streamUiByTurnId.set(turnId, created);
        bubble.appendChild(created.container);
        return created;
    }
    setStreamRootRunning(ui, running) {
        ui.rootSpinner.hidden = !running;
        ui.rootCaret.hidden = running;
        if (running) {
            ui.rootLabel.textContent = 'Processing';
        }
        else if (ui.hasAnswer) {
            ui.rootLabel.textContent = 'Finished work';
        }
        else {
            ui.rootLabel.textContent = 'Processing';
        }
    }
    ensureAnswerPanelVisible(ui) {
        if (ui.answerDetails.hidden) {
            ui.answerDetails.hidden = false;
        }
        if (!ui.answerDetails.open) {
            ui.answerDetails.open = true;
        }
    }
    setAnswerRunning(ui, running) {
        this.ensureAnswerPanelVisible(ui);
        ui.answerSpinner.hidden = !running;
        ui.answerCaret.hidden = running;
    }
    ensureStreamBlock(ui, tag) {
        const prev = ui.countsByTag.get(tag) ?? 0;
        const next = prev + 1;
        ui.countsByTag.set(tag, next);
        const label = next <= 1 ? tag : `${tag}(${next})`;
        const details = document.createElement('details');
        details.className = 'deepanalyze-chat-stream-block';
        details.open = true;
        const summary = document.createElement('summary');
        summary.className = 'deepanalyze-chat-stream-block-summary';
        const spinner = document.createElement('span');
        spinner.className = 'deepanalyze-chat-stream-spinner';
        spinner.hidden = false;
        const caret = document.createElement('span');
        caret.className = 'deepanalyze-chat-stream-caret';
        caret.hidden = true;
        const name = document.createElement('span');
        name.className = 'deepanalyze-chat-stream-block-label';
        name.textContent = label;
        summary.appendChild(spinner);
        summary.appendChild(caret);
        summary.appendChild(name);
        details.appendChild(summary);
        let content;
        if (tag === 'Code') {
            const pre = document.createElement('pre');
            pre.className =
                'deepanalyze-chat-stream-block-content deepanalyze-chat-stream-block-content-code';
            const code = document.createElement('code');
            code.className = 'deepanalyze-chat-stream-code';
            pre.appendChild(code);
            details.appendChild(pre);
            content = code;
        }
        else {
            const host = document.createElement('div');
            host.className =
                'deepanalyze-chat-stream-block-content deepanalyze-chat-stream-block-content-markdown jp-RenderedMarkdown';
            details.appendChild(host);
            content = host;
        }
        ui.innerNode.appendChild(details);
        const block = {
            tag,
            label,
            details,
            spinner,
            caret,
            content,
            text: '',
            closed: false
        };
        ui.blocks.push(block);
        return block;
    }
    closeStreamBlock(block) {
        if (block.closed) {
            return;
        }
        block.closed = true;
        block.spinner.hidden = true;
        block.caret.hidden = false;
        block.details.open = false;
        block.details.classList.add('is-done');
    }
    renderStreamMarkdown(host, markdown) {
        this.renderMarkdownInto(host, markdown);
    }
    highlightPythonCodeHtml(code) {
        const lines = String(code ?? '').replace(/\r\n/g, '\n').split('\n');
        const keywords = [
            'False',
            'None',
            'True',
            'and',
            'as',
            'assert',
            'async',
            'await',
            'break',
            'class',
            'continue',
            'def',
            'del',
            'elif',
            'else',
            'except',
            'finally',
            'for',
            'from',
            'global',
            'if',
            'import',
            'in',
            'is',
            'lambda',
            'nonlocal',
            'not',
            'or',
            'pass',
            'raise',
            'return',
            'try',
            'while',
            'with',
            'yield'
        ];
        const kw = new RegExp(`\\\\b(${keywords.join('|')})\\\\b`, 'g');
        const out = [];
        for (const rawLine of lines) {
            const idx = rawLine.indexOf('#');
            const head = idx >= 0 ? rawLine.slice(0, idx) : rawLine;
            const comment = idx >= 0 ? rawLine.slice(idx) : '';
            const escape = (s) => this.escapeHtml(s);
            const stringRe = /(\"([^\"\\\\]|\\\\.)*\"|'([^'\\\\]|\\\\.)*')/g;
            const bodyParts = [];
            let last = 0;
            for (const m of head.matchAll(stringRe)) {
                const i = typeof m.index === 'number' ? m.index : -1;
                if (i < 0) {
                    continue;
                }
                const before = head.slice(last, i);
                if (before) {
                    bodyParts.push(escape(before).replace(kw, '<span class=\"deepanalyze-code-keyword\">$1</span>'));
                }
                bodyParts.push(`<span class=\"deepanalyze-code-string\">${escape(m[0])}</span>`);
                last = i + m[0].length;
            }
            const tail = head.slice(last);
            if (tail) {
                bodyParts.push(escape(tail).replace(kw, '<span class=\"deepanalyze-code-keyword\">$1</span>'));
            }
            const body = bodyParts.join('');
            const commentHtml = comment
                ? `<span class=\"deepanalyze-code-comment\">${escape(comment)}</span>`
                : '';
            out.push(`${body}${commentHtml}`);
        }
        return out.join('\n');
    }
    renderStreamCode(host, code) {
        host.innerHTML = this.highlightPythonCodeHtml(code);
    }
    renderStreamBlockContent(block) {
        if (block.tag === 'Code') {
            this.renderStreamCode(block.content, block.text);
            return;
        }
        this.renderStreamMarkdown(block.content, block.text);
    }
    renderStreamAnswer(ui) {
        this.ensureAnswerPanelVisible(ui);
        this.renderStreamMarkdown(ui.answerContent, ui.answerText);
    }
    buildTranscriptFromStreamUi(ui) {
        const parts = [];
        for (const block of ui.blocks) {
            const content = String(block.text ?? '').trimEnd();
            parts.push(`<${block.tag}>\n${content}\n</${block.tag}>`);
        }
        if (ui.hasAnswer || ui.answerText.trim()) {
            const content = String(ui.answerText ?? '').trimEnd();
            parts.push(`<Answer>\n${content}\n</Answer>`);
        }
        return parts.join('\n\n').trim();
    }
    persistAssistantTranscriptFromUi(ui) {
        const transcript = this.buildTranscriptFromStreamUi(ui);
        if (!transcript.trim()) {
            return;
        }
        for (let i = this.history.length - 1; i >= 0; i--) {
            const record = this.history[i];
            if (record.role !== 'assistant' || record.hidden) {
                continue;
            }
            if (record.turnId !== ui.turnId) {
                continue;
            }
            record.text = transcript;
            record.trace = this.buildTraceSnapshot(ui.turnId);
            this.persistHistory();
            return;
        }
    }
    applyStreamDeltaToUi(ui, delta) {
        ui.buffer += String(delta ?? '');
        const openTagRe = /<(Analyze|Understand|Code|Answer)>/i;
        const maxOpenTagLen = '<Understand>'.length;
        const appendToActive = (piece) => {
            if (!piece) {
                return;
            }
            if (ui.inAnswer) {
                ui.answerText += piece;
                this.renderStreamAnswer(ui);
                return;
            }
            if (ui.activeBlock) {
                ui.activeBlock.text += piece;
                this.renderStreamBlockContent(ui.activeBlock);
            }
        };
        const tryOpenFromBuffer = () => {
            const m = ui.buffer.match(openTagRe);
            if (!m || typeof m.index !== 'number') {
                return false;
            }
            const before = ui.buffer.slice(0, m.index);
            ui.buffer = ui.buffer.slice(m.index + String(m[0] ?? '').length);
            const tag = this.normalizeStreamTag(m[1]);
            if (!tag) {
                return false;
            }
            // 先把开标签前的内容归入“当前活跃区域”（如果没有活跃区域则丢弃空白）。
            if ((ui.inAnswer || ui.activeBlock) && before) {
                appendToActive(before);
            }
            // 开始新的块
            if (tag === 'Answer') {
                if (ui.activeBlock) {
                    this.closeStreamBlock(ui.activeBlock);
                    ui.activeBlock = null;
                }
                ui.inAnswer = true;
                ui.hasAnswer = true;
                this.ensureAnswerPanelVisible(ui);
                // 不创建内层下拉：Answer 直接渲染到外层区域
                return true;
            }
            if (ui.inAnswer) {
                ui.inAnswer = false;
            }
            if (ui.activeBlock) {
                this.closeStreamBlock(ui.activeBlock);
            }
            ui.activeBlock = this.ensureStreamBlock(ui, tag);
            return true;
        };
        while (true) {
            if (!ui.inAnswer && !ui.activeBlock) {
                if (!tryOpenFromBuffer()) {
                    const keep = Math.max(0, maxOpenTagLen - 1);
                    if (ui.buffer.length > keep) {
                        ui.buffer = ui.buffer.slice(ui.buffer.length - keep);
                    }
                    break;
                }
                continue;
            }
            const closing = ui.inAnswer ? '</Answer>' : `</${ui.activeBlock?.tag}>`;
            const lower = ui.buffer.toLowerCase();
            const idxClose = closing ? lower.indexOf(closing.toLowerCase()) : -1;
            const openMatch = ui.buffer.match(openTagRe);
            const idxOpen = openMatch && typeof openMatch.index === 'number' ? openMatch.index : -1;
            // 容错：若下一个开标签先出现，按“隐式闭合当前区域”处理
            if (idxOpen >= 0 && (idxClose < 0 || idxOpen < idxClose)) {
                const piece = ui.buffer.slice(0, idxOpen);
                appendToActive(piece);
                ui.buffer = ui.buffer.slice(idxOpen);
                if (ui.inAnswer) {
                    ui.inAnswer = false;
                }
                else if (ui.activeBlock) {
                    const finished = ui.activeBlock;
                    this.closeStreamBlock(finished);
                    ui.activeBlock = null;
                }
                continue;
            }
            if (idxClose >= 0) {
                const piece = ui.buffer.slice(0, idxClose);
                appendToActive(piece);
                ui.buffer = ui.buffer.slice(idxClose + closing.length);
                if (ui.inAnswer) {
                    ui.inAnswer = false;
                }
                else if (ui.activeBlock) {
                    const finished = ui.activeBlock;
                    this.closeStreamBlock(finished);
                    ui.activeBlock = null;
                }
                continue;
            }
            // 无任何边界：流式追加，并保留可能构成边界的尾部
            const keep = Math.max(0, Math.max(closing.length - 1, maxOpenTagLen - 1));
            const safeLen = Math.max(0, ui.buffer.length - keep);
            const emit = ui.buffer.slice(0, safeLen);
            appendToActive(emit);
            ui.buffer = ui.buffer.slice(safeLen);
            break;
        }
    }
    resolveActiveStreamUi() {
        const turnId = this.currentTurnId ?? this.activeTraceTurnId;
        if (!turnId) {
            return null;
        }
        const bubble = this.assistantBubbleByTurnId.get(turnId);
        if (!bubble) {
            return null;
        }
        return this.ensureStreamUi(turnId, bubble);
    }
    startAssistantStreaming() {
        const ui = this.resolveActiveStreamUi();
        if (!ui) {
            return;
        }
        ui.rootDetails.open = true;
        this.setStreamRootRunning(ui, true);
    }
    appendAssistantStreaming(delta) {
        const ui = this.resolveActiveStreamUi();
        if (!ui) {
            return;
        }
        const shouldScroll = this.isNearBottom();
        this.applyStreamDeltaToUi(ui, delta);
        if (ui.inAnswer) {
            this.setAnswerRunning(ui, true);
            this.setStreamRootRunning(ui, false);
        }
        else {
            if (!ui.answerDetails.hidden) {
                ui.answerSpinner.hidden = true;
                ui.answerCaret.hidden = false;
                ui.answerDetails.open = true;
            }
            const processingRunning = Boolean(ui.activeBlock && !ui.activeBlock.closed);
            this.setStreamRootRunning(ui, processingRunning);
        }
        this.scrollToBottomIfNeeded(shouldScroll);
    }
    finalizeAssistantStreaming(options) {
        const ui = this.resolveActiveStreamUi();
        if (!ui) {
            return;
        }
        const shouldScroll = this.isNearBottom();
        const raw = String(options?.raw ?? '');
        const hasAnswer = options?.hasAnswer === true || (/<Answer\b/i.test(raw) && /<\/Answer>/i.test(raw));
        if (ui.activeBlock) {
            this.closeStreamBlock(ui.activeBlock);
            ui.activeBlock = null;
        }
        ui.inAnswer = false;
        if (raw && ui.blocks.length === 0 && !ui.answerText.trim()) {
            ui.buffer = '';
            const modules = this.parseModules(raw);
            if (modules.length > 0) {
                for (const module of modules) {
                    const tag = this.normalizeStreamTag(module.tag);
                    if (!tag) {
                        continue;
                    }
                    if (tag === 'Answer') {
                        ui.hasAnswer = true;
                        ui.answerText = String(module.content ?? '');
                        this.renderStreamAnswer(ui);
                        continue;
                    }
                    const block = this.ensureStreamBlock(ui, tag);
                    block.text = String(module.content ?? '');
                    this.renderStreamBlockContent(block);
                    this.closeStreamBlock(block);
                }
            }
            else {
                ui.hasAnswer = true;
                ui.answerText = raw;
                this.renderStreamAnswer(ui);
            }
        }
        ui.hasAnswer = ui.hasAnswer || hasAnswer;
        this.setStreamRootRunning(ui, false);
        if (!ui.answerDetails.hidden) {
            ui.answerSpinner.hidden = true;
            ui.answerCaret.hidden = false;
            ui.answerDetails.open = true;
        }
        this.persistAssistantTranscriptFromUi(ui);
        this.scrollToBottomIfNeeded(shouldScroll);
    }
    renderStaticAssistantBlocks(bubble, text) {
        const modules = this.parseModules(text);
        if (modules.length === 0) {
            return;
        }
        const ui = this.createStreamUi('static');
        const hasAnswer = modules.some(m => this.normalizeStreamTag(m.tag) === 'Answer');
        ui.hasAnswer = hasAnswer;
        ui.rootLabel.textContent = hasAnswer ? 'Finished work' : 'Processing';
        for (const module of modules) {
            const tag = this.normalizeStreamTag(module.tag);
            if (!tag) {
                continue;
            }
            if (tag === 'Answer') {
                ui.answerText = String(module.content ?? '');
                this.renderStreamAnswer(ui);
                continue;
            }
            const block = this.ensureStreamBlock(ui, tag);
            block.text = String(module.content ?? '');
            this.renderStreamBlockContent(block);
            this.closeStreamBlock(block);
        }
        bubble.appendChild(ui.container);
    }
    renderAssistantContent(bubble, text) {
        while (bubble.firstChild) {
            bubble.removeChild(bubble.firstChild);
        }
        // 聊天区展示“链式标签 + 本轮生成过程（可折叠）”：
        // - 链式标签由前端执行 op 时的 trace_update 增量更新，以确保“继续”后的多轮也会接在一起。
        // - 生成过程来自模型输出的 <Analyze>/<Understand>/<Code>/<Answer> 块（支持流式增量展示）。
        const turnId = bubble.dataset.deepanalyzeTurnId ?? '';
        if (turnId) {
            this.renderTraceBarFromTurn(bubble, turnId);
            const stream = this.streamUiByTurnId.get(turnId);
            if (stream) {
                bubble.appendChild(stream.container);
                return;
            }
        }
        this.renderStaticAssistantBlocks(bubble, text);
    }
    ensureTraceState(turnId) {
        const existing = this.traceStateByTurnId.get(turnId);
        if (existing) {
            return existing;
        }
        const created = { items: [], activeId: undefined, counts: new Map() };
        this.traceStateByTurnId.set(turnId, created);
        return created;
    }
    buildTraceSnapshot(turnId) {
        const state = this.traceStateByTurnId.get(turnId);
        if (!state || state.items.length === 0) {
            return undefined;
        }
        return {
            items: state.items.map(it => ({
                id: it.id,
                tag: it.tag,
                label: it.label,
                path: it.path,
                index: it.index
            })),
            activeId: state.activeId
        };
    }
    restoreTraceState(turnId, trace) {
        const counts = new Map();
        for (const item of trace.items) {
            counts.set(item.tag, (counts.get(item.tag) ?? 0) + 1);
        }
        this.traceStateByTurnId.set(turnId, {
            items: trace.items.map(it => ({ ...it })),
            activeId: trace.activeId ?? trace.items[trace.items.length - 1]?.id,
            counts
        });
    }
    persistTraceSnapshotForTurn(turnId) {
        const snapshot = this.buildTraceSnapshot(turnId);
        if (!snapshot) {
            return;
        }
        for (let i = this.history.length - 1; i >= 0; i--) {
            const record = this.history[i];
            if (record.role !== 'assistant' || record.hidden) {
                continue;
            }
            if (record.turnId === turnId) {
                record.trace = snapshot;
                this.persistHistory();
                return;
            }
        }
    }
    applyTraceUpdateToTurn(update) {
        const turnId = this.activeTraceTurnId ?? this.currentTurnId;
        if (!turnId) {
            return;
        }
        const state = this.ensureTraceState(turnId);
        const prev = state.counts.get(update.tag) ?? 0;
        const next = prev + 1;
        state.counts.set(update.tag, next);
        const label = next <= 1 ? update.tag : `${update.tag}(${next})`;
        const id = `${update.tag}:${next}`;
        state.items.push({ id, tag: update.tag, label, path: update.path, index: update.index });
        state.activeId = id;
        this.persistTraceSnapshotForTurn(turnId);
        const bubbles = this.traceBubblesByTurnId.get(turnId);
        if (!bubbles || bubbles.size === 0) {
            return;
        }
        for (const bubble of bubbles) {
            this.renderTraceBarFromTurn(bubble, turnId);
        }
    }
    renderTraceBarFromTurn(bubble, turnId) {
        const state = this.traceStateByTurnId.get(turnId);
        const existing = bubble.querySelector('.deepanalyze-chat-trace');
        existing?.parentElement?.removeChild(existing);
        if (!state || state.items.length === 0) {
            return;
        }
        const bar = document.createElement('div');
        bar.className = 'deepanalyze-chat-trace';
        state.items.forEach((item, i) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'deepanalyze-chat-trace-tag';
            btn.dataset.id = item.id;
            btn.textContent = item.label;
            btn.addEventListener('click', () => void this.handleTraceTagClick(turnId, item.id));
            bar.appendChild(btn);
            if (i < state.items.length - 1) {
                const sep = document.createElement('span');
                sep.className = 'deepanalyze-chat-trace-sep';
                sep.textContent = '→';
                bar.appendChild(sep);
            }
        });
        const stream = bubble.querySelector('.deepanalyze-chat-stream');
        if (stream && stream.parentElement === bubble) {
            bubble.insertBefore(bar, stream);
        }
        else {
            bubble.appendChild(bar);
        }
        this.applyTraceActiveToBubble(bubble, turnId);
    }
    applyTraceActiveToBubble(bubble, turnId) {
        const state = this.traceStateByTurnId.get(turnId);
        const activeId = state?.activeId;
        if (!activeId) {
            return;
        }
        const buttons = bubble.querySelectorAll('.deepanalyze-chat-trace-tag');
        buttons.forEach(btn => {
            const id = String(btn.dataset.id ?? '');
            btn.classList.toggle('deepanalyze-chat-trace-tag-active', id === activeId);
        });
    }
    async handleTraceTagClick(turnId, id) {
        const state = this.traceStateByTurnId.get(turnId);
        const item = state?.items.find(it => it.id === id);
        if (!item) {
            return;
        }
        try {
            await this.onNavigateToCell?.(item.path, item.index);
        }
        catch {
            // ignore
        }
    }
    isNearBottom(thresholdPx = 24) {
        const el = this.messagesNode;
        const distance = el.scrollHeight - (el.scrollTop + el.clientHeight);
        return distance <= thresholdPx;
    }
    scrollToBottomIfNeeded(shouldScroll) {
        if (!shouldScroll) {
            return;
        }
        this.messagesNode.scrollTop = this.messagesNode.scrollHeight;
    }
    setBusy(isBusy) {
        this.isBusy = isBusy;
        this.syncControlState();
    }
    setModelGenerating(isGenerating) {
        this.isModelGenerating = isGenerating;
        this.syncControlState();
    }
    setAwaitingFeedback(isAwaiting) {
        this.isAwaitingFeedback = isAwaiting;
        this.updateWorkingStateClasses();
        this.syncControlState();
        this.updateWorkingIndicatorLabel();
    }
    getAwaitingFeedback() {
        return this.isAwaitingFeedback;
    }
    getAutoContinueEnabled() {
        try {
            const raw = window.localStorage.getItem(this.autoContinueKey);
            if (raw == null) {
                return false;
            }
            return raw === '1' || raw.toLowerCase() === 'true';
        }
        catch {
            return false;
        }
    }
    setAutoContinueEnabled(enabled) {
        try {
            window.localStorage.setItem(this.autoContinueKey, enabled ? '1' : '0');
        }
        catch {
            // ignore
        }
        if (this.autoToggleNode.checked !== enabled) {
            this.autoToggleNode.checked = enabled;
        }
        if (enabled && this.isAwaitingFeedback) {
            this.resolveAwaitDecision('continue');
        }
    }
    waitForContinueOrAbort() {
        if (this.awaitingDecisionPromise) {
            return this.awaitingDecisionPromise;
        }
        this.setAwaitingFeedback(true);
        this.awaitingDecisionPromise = new Promise(resolve => {
            this.awaitingDecisionResolve = resolve;
        });
        if (this.getAutoContinueEnabled()) {
            queueMicrotask(() => this.resolveAwaitDecision('continue'));
        }
        return this.awaitingDecisionPromise;
    }
    resolveAwaitDecision(value) {
        const resolve = this.awaitingDecisionResolve;
        if (!resolve) {
            return;
        }
        this.awaitingDecisionResolve = null;
        const promise = this.awaitingDecisionPromise;
        this.awaitingDecisionPromise = null;
        this.setAwaitingFeedback(false);
        try {
            resolve(value);
        }
        finally {
            void promise;
        }
    }
    updateWorkingIndicatorLabel() {
        if (!this.workingMessageLabelNode) {
            return;
        }
        this.workingMessageLabelNode.textContent = this.isAwaitingFeedback
            ? 'waiting for user choice'
            : 'working';
    }
    updateWorkingStateClasses() {
        const node = this.workingMessageNode;
        if (!node) {
            return;
        }
        node.classList.toggle('deepanalyze-chat-message-working-waiting', this.isAwaitingFeedback);
    }
    syncControlState() {
        const sendingLocked = this.isBusy;
        this.sendButtonNode.disabled = sendingLocked;
        this.inputNode.disabled = sendingLocked;
        this.sendButtonNode.textContent = this.isModelGenerating ? '发送中…' : '发送';
        const canControl = this.isAwaitingFeedback && !this.isModelGenerating;
        this.continueButtonNode.disabled = !canControl;
        this.abortButtonNode.disabled = !canControl;
    }
    clearHistory() {
        this.history.length = 0;
        this.messagesNode.textContent = '';
        this.traceStateByTurnId.clear();
        this.traceBubblesByTurnId.clear();
        this.assistantBubbleByTurnId.clear();
        this.streamUiByTurnId.clear();
        try {
            window.localStorage.removeItem(this.historyKey);
        }
        catch {
            // ignore
        }
    }
    async handleReset() {
        if (this.isBusy) {
            return;
        }
        const bodyNode = document.createElement('div');
        bodyNode.className = 'deepanalyze-chat-reset-dialog';
        const text = document.createElement('div');
        text.textContent = '确认重置当前会话与对话历史吗？';
        bodyNode.appendChild(text);
        const label = document.createElement('label');
        label.style.display = 'flex';
        label.style.alignItems = 'center';
        label.style.gap = '8px';
        label.style.marginTop = '12px';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        label.appendChild(checkbox);
        const labelText = document.createElement('span');
        labelText.textContent = '同时清除 Notebook 结果（model_output / scratch）';
        label.appendChild(labelText);
        bodyNode.appendChild(label);
        const body = new widgets_1.Widget({ node: bodyNode });
        const result = await (0, apputils_1.showDialog)({
            title: '重置确认',
            body,
            buttons: [apputils_1.Dialog.cancelButton(), apputils_1.Dialog.warnButton({ label: '重置' })]
        });
        if (!result.button.accept) {
            return;
        }
        this.setBusy(true);
        try {
            this.setModelGenerating(true);
            const response = await (0, api_1.sendChatMessage)('/reset', this.activeModelId || undefined, this.getPromptLang());
            try {
                await this.onReset?.({ clearNotebooks: checkbox.checked });
            }
            catch {
                // ignore notebook clear failures
            }
            this.clearHistory();
            this.addMessage('assistant', response.reply || '已重置当前会话。');
        }
        catch (error) {
            this.addMessage('system', '重置失败（后端可能未启用）。');
            this.addMessage('system', String(error));
        }
        finally {
            this.setModelGenerating(false);
            this.setBusy(false);
            this.inputNode.focus();
        }
    }
    async handleSend() {
        if (this.isBusy) {
            return;
        }
        const raw = this.inputNode.value ?? '';
        const message = raw.trim();
        if (!message) {
            return;
        }
        this.inputNode.value = '';
        this.addMessage('user', message);
        this.showWorkingIndicator();
        this.setBusy(true);
        const turnId = String(Date.now());
        this.currentTurnId = turnId;
        try {
            const placeholderBubble = this.addMessage('assistant', '', {
                persist: false,
                before: this.workingMessageNode
            });
            this.assistantBubbleByTurnId.set(turnId, placeholderBubble);
            this.ensureStreamUi(turnId, placeholderBubble);
            this.startAssistantStreaming();
            await this.loadMarked();
            this.setModelGenerating(true);
            let response = null;
            const tryStream = async () => {
                // 优先走流式：一方面更好的用户体验，另一方面可以驱动 `open.ts` 写 scratch 流式占位 cell。
                await this.onModelStream?.({ type: 'start', turnId });
                for await (const event of (0, api_1.streamChatMessage)(message, this.activeModelId || undefined, this.getPromptLang())) {
                    if (event.type === 'delta') {
                        this.appendAssistantStreaming(event.delta);
                        await this.onModelStream?.({ type: 'delta', turnId, delta: event.delta });
                        continue;
                    }
                    if (event.type === 'final') {
                        response = event.response;
                        break;
                    }
                }
                if (!response) {
                    throw new Error('流式响应缺少 final');
                }
                try {
                    const data = response.data;
                    const raw = typeof data?.raw === 'string'
                        ? String(data.raw)
                        : String(response.reply ?? '');
                    const awaitFeedback = Boolean(data?.await_feedback);
                    const hasAnswer = /<Answer\b/i.test(raw) && /<\/Answer>/i.test(raw);
                    this.finalizeAssistantStreaming({ raw, hasAnswer });
                    await this.onModelStream?.({
                        type: 'final',
                        turnId,
                        awaitFeedback,
                        hasAnswer,
                        raw
                    });
                }
                catch {
                    // ignore
                }
                await this.onModelStream?.({ type: 'end', turnId });
                return response;
            };
            try {
                response = await tryStream();
            }
            catch (error) {
                // 流式失败时回退到非流式，并把失败信息上报给后端日志接口，便于定位 SSE/vLLM 兼容问题。
                await this.onModelStream?.({ type: 'error', turnId, error: String(error) });
                try {
                    void (0, api_1.sendFrontendLog)({
                        session_id: (0, storage_1.getDeepAnalyzeItem)('sessionId').trim() || undefined,
                        message: 'stream_chat_failed',
                        logs: JSON.stringify({
                            turnId,
                            error: String(error),
                            errorType: error?.name,
                            status: error?.response?.status,
                            statusText: error?.response?.statusText
                        }, null, 2)
                    });
                }
                catch {
                    // ignore
                }
                response = await (0, api_1.sendChatMessage)(message, this.activeModelId || undefined, this.getPromptLang());
            }
            this.setModelGenerating(false);
            const data = response.data;
            const raw = typeof data?.raw === 'string' ? String(data.raw) : '';
            const assistantText = this.fixUnclosedTags(this.ensureTaggedText(raw.trim() ? raw : String(response.reply ?? '')));
            placeholderBubble.dataset.assistantText = assistantText.trim()
                ? assistantText
                : '<Answer>\n\n</Answer>';
            this.appendHistoryOnly('assistant', placeholderBubble.dataset.assistantText, {
                turnId,
                trace: this.buildTraceSnapshot(turnId)
            });
            this.finalizeAssistantStreaming({ raw: placeholderBubble.dataset.assistantText });
            if (response.data) {
                try {
                    const result = await this.onToolResult?.(response.data);
                    if (this.isAsyncIterable(result)) {
                        for await (const chunk of result) {
                            this.applyToolResultChunk(chunk);
                        }
                    }
                    else {
                        this.applyToolResultChunk(result);
                    }
                }
                catch {
                    // Ignore UI-side sync errors.
                }
            }
        }
        catch (error) {
            const bubble = this.assistantBubbleByTurnId.get(turnId);
            if (bubble) {
                bubble.dataset.assistantText = this.ensureTaggedText('请求失败（后端可能未启用）。');
                this.appendHistoryOnly('assistant', bubble.dataset.assistantText, { turnId });
                this.finalizeAssistantStreaming({ raw: bubble.dataset.assistantText, hasAnswer: true });
            }
            else {
                this.addMessage('assistant', this.ensureTaggedText('请求失败（后端可能未启用）。'), {
                    before: this.workingMessageNode
                });
            }
            this.addMessage('system', String(error), { before: this.workingMessageNode });
        }
        finally {
            this.setAwaitingFeedback(false);
            this.finalizeWorkingIndicator();
            this.setModelGenerating(false);
            this.setBusy(false);
            this.assistantBubbleByTurnId.delete(turnId);
            this.currentTurnId = null;
            this.inputNode.focus();
        }
    }
}
exports.DeepAnalyzeChatPanel = DeepAnalyzeChatPanel;


/***/ }),

/***/ "./lib/deepanalyze/open.js":
/*!*********************************!*\
  !*** ./lib/deepanalyze/open.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.restoreDeepAnalyzeIfNeeded = exports.openDeepAnalyze = void 0;
const apputils_1 = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
const coreutils_1 = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
const notebook_1 = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
const disposable_1 = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
const widgets_1 = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
const chatPanel_1 = __webpack_require__(/*! ./chatPanel */ "./lib/deepanalyze/chatPanel.js");
const api_1 = __webpack_require__(/*! ./api */ "./lib/deepanalyze/api.js");
const settings_1 = __webpack_require__(/*! ./settings */ "./lib/deepanalyze/settings.js");
const storage_1 = __webpack_require__(/*! ./storage */ "./lib/deepanalyze/storage.js");
const workspace_1 = __webpack_require__(/*! ./workspace */ "./lib/deepanalyze/workspace.js");
let activeSession = null;
// 工作区根目录的约定：
// - Contents API 使用“server root 相对路径”，不是 OS 绝对路径
// - 历史版本可能落在 legacy 前缀下，这里做兼容映射
const PREFERRED_WORKSPACES_ROOT = 'DeepAnalyze/workspaces';
const LEGACY_WORKSPACES_ROOT = 'jupyter/deepanalyze/DeepAnalyze/workspaces';
const CONFIGURED_WORKSPACES_ROOT_DEFAULT = PREFERRED_WORKSPACES_ROOT;
function configuredWorkspacesRootRaw() {
    const settings = (0, settings_1.getDeepAnalyzeSettings)();
    const raw = String(settings.workspacesRoot ?? CONFIGURED_WORKSPACES_ROOT_DEFAULT).trim();
    // 这里主要做“尽量把用户输入的路径规范化为 Contents 可用的 server-root 相对路径”。
    // The JupyterLab Contents API uses paths relative to the server root, not OS absolute paths.
    // If user provides an absolute filesystem-looking path, try to recover a relative suffix.
    const normalized = raw.replace(/\\/g, '/').replace(/^\/+/, '').replace(/\/+$/, '');
    const firstSlash = normalized.indexOf('/');
    const prefix = firstSlash >= 0 ? normalized.slice(0, firstSlash) : normalized;
    if (prefix.includes(':')) {
        return normalized;
    }
    if (!normalized) {
        return '';
    }
    if (normalized === LEGACY_WORKSPACES_ROOT) {
        return PREFERRED_WORKSPACES_ROOT;
    }
    // If it is already a server-root relative path, keep it as-is (except legacy mapping above).
    if (normalized.startsWith('jupyter/deepanalyze/') || normalized.startsWith('DeepAnalyze/')) {
        return normalized;
    }
    // For OS absolute paths, fall back to the preferred contents-relative suffix.
    if (normalized.endsWith(`/${PREFERRED_WORKSPACES_ROOT}`) ||
        normalized.endsWith(PREFERRED_WORKSPACES_ROOT)) {
        return PREFERRED_WORKSPACES_ROOT;
    }
    if (normalized.endsWith(`/${LEGACY_WORKSPACES_ROOT}`) ||
        normalized.endsWith(LEGACY_WORKSPACES_ROOT)) {
        return PREFERRED_WORKSPACES_ROOT;
    }
    return normalized;
}
function resolveWorkspacesRoot(_contents, _browser, configured) {
    const trimmed = String(configured ?? '').trim();
    if (!trimmed) {
        return CONFIGURED_WORKSPACES_ROOT_DEFAULT;
    }
    const normalized = trimmed.replace(/\\/g, '/').replace(/^\/+/, '');
    // If it looks like a contents "absolute" path with a drive prefix (e.g. "home:..."),
    // do not re-resolve it.
    const firstSlash = normalized.indexOf('/');
    const prefix = firstSlash >= 0 ? normalized.slice(0, firstSlash) : normalized;
    if (prefix.includes(':')) {
        return normalized;
    }
    // Prefer server-root relative paths for workspaces (do not force the file browser drive).
    // If caller provides a drive-prefixed path, keep it as-is.
    return normalized;
}
function toBrowserCdPath(contents, path) {
    const local = contents.localPath(path);
    const normalized = String(local ?? '').replace(/^\/+/, '');
    return normalized ? `/${normalized}` : '/';
}
function toContentsPath(contents, browserPath) {
    const local = contents.localPath(browserPath);
    return String(local ?? '').replace(/^\/+/, '');
}
function getOrCreateDeepAnalyzeSessionId() {
    const existing = (0, storage_1.getDeepAnalyzeItem)('sessionId');
    if (existing && String(existing).trim()) {
        return String(existing).trim();
    }
    let created = '';
    try {
        created = window.crypto?.randomUUID?.() ?? '';
    }
    catch {
        created = '';
    }
    if (!created) {
        created = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    }
    (0, storage_1.setDeepAnalyzeItem)('sessionId', created);
    return created;
}
async function safeFileBrowserCd(contents, browser, candidates) {
    for (const candidate of candidates) {
        const value = String(candidate ?? '').trim();
        if (!value) {
            continue;
        }
        try {
            const contentPath = toContentsPath(contents, value);
            if (contentPath) {
                const model = await contents.get(contentPath, { content: false });
                if (model.type !== 'directory') {
                    continue;
                }
            }
            const cdValue = value.startsWith('/') || value.includes(':') ? value : `/${value}`;
            await browser.model.cd(cdValue);
            return;
        }
        catch {
            // Try next.
        }
    }
}
async function cdFileBrowserToDirectory(contents, browser, targetDir) {
    const cdPath = toBrowserCdPath(contents, targetDir);
    const resolved = contents.resolvePath(browser.model.path || '/', cdPath);
    try {
        const model = await contents.get(resolved, { content: false });
        if (model.type !== 'directory') {
            return false;
        }
    }
    catch {
        return false;
    }
    await browser.model.cd(cdPath);
    return true;
}
function installFileBrowserRootRestriction(contents, defaultBrowser, rootPath) {
    const model = defaultBrowser.model;
    let isRedirecting = false;
    const rootLocal = String(contents.localPath(rootPath) ?? '').replace(/^\/+/, '');
    const isAllowed = (path) => {
        const currentLocal = String(contents.localPath(path) ?? '').replace(/^\/+/, '');
        if (!currentLocal) {
            return false;
        }
        return currentLocal === rootLocal || currentLocal.startsWith(`${rootLocal}/`);
    };
    const handler = () => {
        if (isRedirecting) {
            return;
        }
        if (isAllowed(model.path)) {
            return;
        }
        isRedirecting = true;
        void model.cd(toBrowserCdPath(contents, rootPath)).finally(() => {
            isRedirecting = false;
        });
    };
    model.pathChanged.connect(handler);
    return new disposable_1.DisposableDelegate(() => {
        model.pathChanged.disconnect(handler);
    });
}
async function createNewNotebook(docManager, workspaceDir, refWidgetId) {
    try {
        const model = await docManager.newUntitled({ path: workspaceDir, type: 'notebook' });
        const openOptions = refWidgetId
            ? { mode: 'tab-after', ref: refWidgetId }
            : undefined;
        return docManager.openOrReveal(model.path, undefined, undefined, openOptions) ?? null;
    }
    catch (error) {
        void (0, apputils_1.showErrorMessage)('DeepAnalyze', `新建 Notebook 失败：${error}`);
        return null;
    }
}
function installMainAreaAddButtonClickInterceptor(app, docManager, workspaceDir) {
    const labShell = app.shell;
    const getRefIdFromAddButton = (button) => {
        const dockTabBar = button.closest('.lm-DockPanel-tabBar') ?? button.closest('.jp-DockPanel-tabBar');
        if (!dockTabBar) {
            return labShell.currentWidget?.id ?? undefined;
        }
        const currentTab = dockTabBar.querySelector('.lm-TabBar-tab.lm-mod-current');
        const refId = currentTab?.dataset?.id;
        return refId || (labShell.currentWidget?.id ?? undefined);
    };
    const shouldHandle = (target) => {
        if (!target) {
            return null;
        }
        const button = target.closest('.lm-TabBar-addButton');
        if (!button) {
            return null;
        }
        if (!button.closest('.lm-DockPanel-tabBar') &&
            !button.closest('.jp-DockPanel-tabBar')) {
            return null;
        }
        return button;
    };
    const pointerHandler = (event) => {
        const button = shouldHandle(event.target);
        if (!button) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        event.stopImmediatePropagation?.();
        const refId = getRefIdFromAddButton(button);
        void createNewNotebook(docManager, workspaceDir, refId);
    };
    const keyHandler = (event) => {
        const target = event.target;
        if (!target) {
            return;
        }
        const button = shouldHandle(target);
        if (!button) {
            return;
        }
        if (event.key !== 'Enter' && event.key !== ' ') {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        event.stopImmediatePropagation?.();
        const refId = getRefIdFromAddButton(button);
        void createNewNotebook(docManager, workspaceDir, refId);
    };
    // TabBar emits `addRequested` on document `pointerup` (capture). Intercept it early.
    document.addEventListener('pointerup', pointerHandler, true);
    document.addEventListener('keydown', keyHandler, true);
    return new disposable_1.DisposableDelegate(() => {
        document.removeEventListener('pointerup', pointerHandler, true);
        document.removeEventListener('keydown', keyHandler, true);
    });
}
async function promptWorkspaceDir(contents, workspacesRoot) {
    const workspaces = await (0, workspace_1.listWorkspaces)(contents, workspacesRoot);
    const body = document.createElement('div');
    body.className = 'deepanalyze-workspace-dialog';
    const intro = document.createElement('div');
    intro.textContent = `请选择一个工作区，或新建工作区（目录会创建在 ${workspacesRoot} 下）。`;
    body.appendChild(intro);
    const modeLabel = document.createElement('label');
    modeLabel.textContent = '模式';
    modeLabel.style.display = 'block';
    modeLabel.style.marginTop = '10px';
    body.appendChild(modeLabel);
    const modeSelect = document.createElement('select');
    modeSelect.style.width = '100%';
    modeSelect.style.marginTop = '6px';
    const modeExistingOption = document.createElement('option');
    modeExistingOption.value = 'existing';
    modeExistingOption.textContent = '使用已有工作区';
    const modeNewOption = document.createElement('option');
    modeNewOption.value = 'new';
    modeNewOption.textContent = '新建工作区';
    modeSelect.appendChild(modeExistingOption);
    modeSelect.appendChild(modeNewOption);
    body.appendChild(modeSelect);
    const existingSelect = document.createElement('select');
    existingSelect.style.width = '100%';
    existingSelect.style.marginTop = '6px';
    const placeholder = document.createElement('option');
    placeholder.value = '';
    placeholder.textContent = workspaces.length ? '请选择…' : '暂无可用工作区';
    existingSelect.appendChild(placeholder);
    for (const name of workspaces) {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = name;
        existingSelect.appendChild(option);
    }
    body.appendChild(existingSelect);
    const newInput = document.createElement('input');
    newInput.type = 'text';
    newInput.placeholder = '输入工作区名字（将作为子目录名）';
    newInput.style.width = '100%';
    newInput.style.marginTop = '6px';
    body.appendChild(newInput);
    const update = () => {
        const mode = String(modeSelect.value ?? 'existing');
        existingSelect.disabled = mode !== 'existing';
        newInput.disabled = mode !== 'new';
    };
    if (workspaces.length) {
        modeSelect.value = 'existing';
    }
    else {
        modeSelect.value = 'new';
    }
    update();
    modeSelect.addEventListener('change', update);
    for (;;) {
        const result = await (0, apputils_1.showDialog)({
            title: 'DeepAnalyze 工作区',
            body: new widgets_1.Widget({ node: body }),
            buttons: [apputils_1.Dialog.cancelButton(), apputils_1.Dialog.okButton({ label: '进入' })]
        });
        if (!result.button.accept) {
            return null;
        }
        if (String(modeSelect.value ?? 'existing') === 'existing') {
            const selected = String(existingSelect.value ?? '').trim();
            if (!selected) {
                await (0, apputils_1.showErrorMessage)('DeepAnalyze', '请选择一个已有工作区。');
                continue;
            }
            const target = coreutils_1.PathExt.join(workspacesRoot, selected);
            try {
                const model = await contents.get(target, { content: false });
                if (model.type !== 'directory') {
                    await (0, apputils_1.showErrorMessage)('DeepAnalyze', '所选工作区不是目录。');
                    continue;
                }
            }
            catch {
                await (0, apputils_1.showErrorMessage)('DeepAnalyze', '所选工作区不存在或不可访问。');
                continue;
            }
            return target;
        }
        const rawName = String(newInput.value ?? '');
        const name = (0, workspace_1.sanitizeWorkspaceName)(rawName);
        if (!name) {
            await (0, apputils_1.showErrorMessage)('DeepAnalyze', '请输入工作区名字。');
            continue;
        }
        await (0, workspace_1.ensureNamedWorkspace)(contents, workspacesRoot, name);
        return coreutils_1.PathExt.join(workspacesRoot, name);
    }
}
async function createNotebookFile(contents, docManager, directory, preferredName) {
    const targetPath = coreutils_1.PathExt.join(directory, preferredName);
    try {
        const existing = await contents.get(targetPath, { content: false });
        if (existing.type === 'directory') {
            throw new Error(`目标路径是目录：${targetPath}`);
        }
        return targetPath;
    }
    catch {
        // Not found; proceed to create.
    }
    const model = await docManager.newUntitled({ path: directory, type: 'notebook' });
    try {
        const renamed = await docManager.rename(model.path, targetPath);
        return renamed.path;
    }
    catch {
        try {
            await contents.get(targetPath, { content: false });
            await contents.delete(model.path);
            return targetPath;
        }
        catch {
            // Non-fatal.
        }
        return model.path;
    }
}
async function openDeepAnalyze(app, docManager, defaultBrowser, options) {
    const { contents } = app.serviceManager;
    await defaultBrowser.model.restored;
    activeSession?.disposables.forEach(disposable => disposable.dispose());
    activeSession = null;
    const previousBrowserPath = defaultBrowser.model.path ?? '';
    let workspacesRoot = '';
    let rootPath = '';
    let lastError = null;
    let preselectedWorkspaceDir = String(options?.workspaceDir ?? '').trim();
    if (preselectedWorkspaceDir) {
        workspacesRoot = coreutils_1.PathExt.dirname(preselectedWorkspaceDir);
        rootPath = coreutils_1.PathExt.dirname(workspacesRoot);
        try {
            const rootModel = await contents.get(rootPath, { content: false });
            if (rootModel.type !== 'directory') {
                throw new Error(`"${rootPath}" 不是目录`);
            }
            const wsRootModel = await contents.get(workspacesRoot, { content: false });
            if (wsRootModel.type !== 'directory') {
                throw new Error(`"${workspacesRoot}" 不是目录`);
            }
            const wsModel = await contents.get(preselectedWorkspaceDir, { content: false });
            if (wsModel.type !== 'directory') {
                throw new Error(`"${preselectedWorkspaceDir}" 不是目录`);
            }
            lastError = null;
        }
        catch (error) {
            lastError = error;
            workspacesRoot = '';
            rootPath = '';
            preselectedWorkspaceDir = '';
        }
    }
    else {
        const configuredRaw = configuredWorkspacesRootRaw();
        const primaryRawCandidates = [PREFERRED_WORKSPACES_ROOT, configuredRaw];
        const uniquePrimaryRawCandidates = Array.from(new Set(primaryRawCandidates.map(value => String(value ?? '').trim()).filter(Boolean)));
        const legacyRawCandidates = [LEGACY_WORKSPACES_ROOT];
        const uniqueRawCandidates = Array.from(new Set([...uniquePrimaryRawCandidates, ...legacyRawCandidates]));
        const resolvedPrimaryCandidates = uniquePrimaryRawCandidates.map(raw => {
            return resolveWorkspacesRoot(contents, defaultBrowser, raw);
        });
        for (const resolved of resolvedPrimaryCandidates) {
            const parent = coreutils_1.PathExt.dirname(resolved);
            try {
                const model = await contents.get(resolved, { content: false });
                if (model.type !== 'directory') {
                    throw new Error(`"${resolved}" 不是目录`);
                }
                const parentModel = await contents.get(parent, { content: false });
                if (parentModel.type !== 'directory') {
                    throw new Error(`"${parent}" 不是目录`);
                }
                workspacesRoot = resolved;
                rootPath = parent;
                lastError = null;
                break;
            }
            catch (error) {
                lastError = error;
            }
        }
        if (!workspacesRoot) {
            // None exists yet; create the preferred default root.
            const resolved = resolvedPrimaryCandidates[0] ??
                resolveWorkspacesRoot(contents, defaultBrowser, CONFIGURED_WORKSPACES_ROOT_DEFAULT);
            const parent = coreutils_1.PathExt.dirname(resolved);
            try {
                await (0, workspace_1.ensureDirectoryPath)(contents, resolved);
                const model = await contents.get(resolved, { content: false });
                if (model.type !== 'directory') {
                    throw new Error(`"${resolved}" 不是目录`);
                }
                const parentModel = await contents.get(parent, { content: false });
                if (parentModel.type !== 'directory') {
                    throw new Error(`"${parent}" 不是目录`);
                }
                workspacesRoot = resolved;
                rootPath = parent;
            }
            catch (error) {
                lastError = error;
            }
        }
        if (!workspacesRoot) {
            const resolvedLegacyCandidates = legacyRawCandidates.map(raw => {
                return resolveWorkspacesRoot(contents, defaultBrowser, raw);
            });
            for (const resolved of resolvedLegacyCandidates) {
                const parent = coreutils_1.PathExt.dirname(resolved);
                try {
                    const model = await contents.get(resolved, { content: false });
                    if (model.type !== 'directory') {
                        throw new Error(`"${resolved}" 不是目录`);
                    }
                    const parentModel = await contents.get(parent, { content: false });
                    if (parentModel.type !== 'directory') {
                        throw new Error(`"${parent}" 不是目录`);
                    }
                    workspacesRoot = resolved;
                    rootPath = parent;
                    lastError = null;
                    break;
                }
                catch (error) {
                    lastError = error;
                }
            }
        }
        if (!workspacesRoot) {
            await (0, apputils_1.showErrorMessage)('DeepAnalyze', `无法初始化工作区父目录（候选：${uniqueRawCandidates.join(' , ')}）：${lastError ?? '未知错误'}`);
            return null;
        }
    }
    const rootRestriction = installFileBrowserRootRestriction(contents, defaultBrowser, rootPath);
    if (!(await cdFileBrowserToDirectory(contents, defaultBrowser, rootPath))) {
        rootRestriction.dispose();
        await (0, apputils_1.showErrorMessage)('DeepAnalyze', `无法进入目录: ${rootPath}`);
        return null;
    }
    const workspaceDir = preselectedWorkspaceDir || (await promptWorkspaceDir(contents, workspacesRoot));
    if (!workspaceDir) {
        rootRestriction.dispose();
        await safeFileBrowserCd(contents, defaultBrowser, [
            previousBrowserPath,
            toBrowserCdPath(contents, rootPath),
            '/'
        ]);
        return null;
    }
    const instanceId = Math.random().toString(16).slice(2, 10);
    if (!(await cdFileBrowserToDirectory(contents, defaultBrowser, workspaceDir))) {
        rootRestriction.dispose();
        await (0, apputils_1.showErrorMessage)('DeepAnalyze', `无法进入工作区目录: ${workspaceDir}`);
        return null;
    }
    const outputNotebookPath = await createNotebookFile(contents, docManager, workspaceDir, 'model-output.ipynb');
    const scratchNotebookPath = await createNotebookFile(contents, docManager, workspaceDir, 'scratch.ipynb');
    getOrCreateDeepAnalyzeSessionId();
    (0, storage_1.setDeepAnalyzeItem)('activeWorkspaceDir', workspaceDir);
    (0, storage_1.setDeepAnalyzeItem)('activeOutputPath', outputNotebookPath);
    (0, storage_1.setDeepAnalyzeItem)('activeScratchPath', scratchNotebookPath);
    const outputWidget = docManager.openOrReveal(outputNotebookPath);
    if (!outputWidget) {
        rootRestriction.dispose();
        await (0, apputils_1.showErrorMessage)('DeepAnalyze', '无法打开模型输出 Notebook。');
        return null;
    }
    outputWidget.title.closable = false;
    const ensureInMainArea = (widget) => {
        try {
            app.shell.add(widget, 'main');
        }
        catch {
            // ignore
        }
    };
    ensureInMainArea(outputWidget);
    app.shell.activateById(outputWidget.id);
    const ensureNotebookPanel = async (path) => {
        const existing = docManager.findWidget(path) ?? docManager.openOrReveal(path);
        if (!existing) {
            throw new Error(`无法打开文档：${path}`);
        }
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const context = existing.context;
        if (context?.ready) {
            await context.ready;
        }
        return existing;
    };
    let chatWidget = null;
    let chatPanel = null;
    let restoreAddButtonInterceptor = null;
    try {
        // scratch 的“流式占位 cell”状态：用于把 SSE delta 实时展示在 notebook 中。
        let streamingScratch = null;
        const STREAM_FLUSH_MS = 80;
        const renderStreamingText = (content, status) => {
            const title = status === 'error'
                ? '[Streaming] 发生错误'
                : status === 'done'
                    ? '[Streaming] 完成'
                    : status === 'waiting'
                        ? '[Streaming] 等待执行/回环…'
                        : '[Streaming] 生成中…';
            const body = String(content ?? '');
            return `${title}\n\n${body}`;
        };
        const setCellSource = (notebook, sharedModel, index, source) => {
            const cell = notebook.widgets?.[index];
            if (cell?.model?.sharedModel?.setSource) {
                cell.model.sharedModel.setSource(source);
                return;
            }
            const sharedCell = sharedModel.getCell?.(index);
            sharedCell?.setSource?.(source);
        };
        const setCellLock = (notebook, index, locked) => {
            const cell = notebook?.widgets?.[index];
            const meta = cell?.model?.metadata;
            if (!meta?.set) {
                return;
            }
            const editable = locked ? false : true;
            try {
                meta.set('editable', editable);
            }
            catch {
                // ignore
            }
            try {
                meta.set('deletable', editable);
            }
            catch {
                // ignore
            }
        };
        const finalizeStreamingScratchCell = async (status, options) => {
            const state = streamingScratch;
            if (!state) {
                return;
            }
            if (state.flushHandle != null) {
                window.clearTimeout(state.flushHandle);
            }
            try {
                const panel = state.panel ?? (await ensureNotebookPanel(state.path));
                const notebook = state.notebook ?? panel?.content;
                const sharedModel = state.sharedModel ?? notebook?.model?.sharedModel;
                if (!notebook?.model?.sharedModel || !sharedModel) {
                    return;
                }
                const placeholderIndex = state.sharedCell && Array.isArray(sharedModel.cells)
                    ? sharedModel.cells.indexOf(state.sharedCell)
                    : state.index;
                if (placeholderIndex < 0) {
                    return;
                }
                state.status = status;
                if (state.status === 'done' || state.status === 'waiting') {
                    sharedModel.deleteCell(placeholderIndex);
                }
                else {
                    setCellSource(notebook, sharedModel, placeholderIndex, renderStreamingText(state.content, state.status));
                    if (options.unlock) {
                        setCellLock(notebook, placeholderIndex, false);
                    }
                }
            }
            catch {
                // ignore
            }
            finally {
                streamingScratch = null;
            }
        };
        const startStreamingToScratch = async () => {
            const scratchPath = (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') ?? '';
            if (!scratchPath.trim()) {
                return;
            }
            // 如果上一次还留有流式 cell，先“完成并解锁”，避免残留锁定状态。
            await finalizeStreamingScratchCell('done', { unlock: true });
            const panel = await ensureNotebookPanel(scratchPath);
            const notebook = panel?.content;
            if (!notebook?.model?.sharedModel) {
                return;
            }
            const sharedModel = notebook.model.sharedModel;
            const insertIndex = notebook.widgets?.length ?? 0;
            const sharedCell = sharedModel.insertCell(insertIndex, {
                cell_type: 'raw',
                source: renderStreamingText('', 'streaming'),
                metadata: { editable: false, deletable: false }
            });
            try {
                notebook.activeCellIndex = Math.min(insertIndex, (notebook.widgets?.length ?? 1) - 1);
                notebook.scrollToItem?.(insertIndex);
                // 锁定状态下保持 command 模式，避免误入编辑。
                notebook.mode = 'command';
            }
            catch {
                // ignore
            }
            streamingScratch = {
                path: scratchPath,
                index: insertIndex,
                content: '',
                flushHandle: null,
                lastFlush: 0,
                status: 'streaming',
                panel,
                notebook,
                sharedModel,
                sharedCell,
                cellType: 'raw'
            };
        };
        const flushStreamingToScratch = async () => {
            const state = streamingScratch;
            if (!state) {
                return;
            }
            const scratchPath = (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') ?? '';
            if (!scratchPath.trim() || scratchPath !== state.path) {
                return;
            }
            try {
                const panel = state.panel ?? (await ensureNotebookPanel(state.path));
                const notebook = state.notebook ?? panel?.content;
                const sharedModel = state.sharedModel ?? notebook?.model?.sharedModel;
                if (!notebook?.model?.sharedModel || !sharedModel) {
                    return;
                }
                const placeholderIndex = state.sharedCell && Array.isArray(sharedModel.cells)
                    ? sharedModel.cells.indexOf(state.sharedCell)
                    : state.index;
                if (placeholderIndex < 0) {
                    return;
                }
                setCellSource(notebook, sharedModel, placeholderIndex, renderStreamingText(state.content, state.status));
                state.lastFlush = Date.now();
            }
            catch {
                // ignore
            }
        };
        const scheduleFlushStreamingToScratch = () => {
            const state = streamingScratch;
            if (!state || state.flushHandle != null) {
                return;
            }
            const elapsed = Date.now() - state.lastFlush;
            const delay = Math.max(0, STREAM_FLUSH_MS - elapsed);
            state.flushHandle = window.setTimeout(() => {
                if (!streamingScratch) {
                    return;
                }
                streamingScratch.flushHandle = null;
                void flushStreamingToScratch();
            }, delay);
        };
        const appendStreamingToScratch = (delta) => {
            const state = streamingScratch;
            if (!state) {
                return;
            }
            const d = String(delta ?? '');
            if (!d) {
                return;
            }
            state.content += d;
            scheduleFlushStreamingToScratch();
        };
        const markStreamingToScratch = (status) => {
            const state = streamingScratch;
            if (!state) {
                return;
            }
            state.status = status;
            scheduleFlushStreamingToScratch();
        };
        const clearNotebook = async (path) => {
            const panel = await ensureNotebookPanel(path);
            const notebook = panel?.content;
            if (!notebook?.model?.sharedModel) {
                return;
            }
            const sharedModel = notebook.model.sharedModel;
            const count = notebook.widgets?.length ?? 0;
            for (let i = count - 1; i >= 0; i--) {
                sharedModel.deleteCell(i);
            }
            sharedModel.insertCell(0, { cell_type: 'markdown', source: '' });
            notebook.activeCellIndex = 0;
            try {
                await panel.context?.save?.();
            }
            catch {
                // ignore
            }
        };
        const cleanupSession = async () => {
            const disposables = activeSession?.disposables ?? [];
            activeSession = null;
            for (const disposable of disposables) {
                disposable.dispose();
            }
            (0, storage_1.removeDeepAnalyzeItem)('activeWorkspaceDir');
            (0, storage_1.removeDeepAnalyzeItem)('activeOutputPath');
            (0, storage_1.removeDeepAnalyzeItem)('activeScratchPath');
            (0, storage_1.removeDeepAnalyzeItem)('sessionId');
            await safeFileBrowserCd(contents, defaultBrowser, [
                previousBrowserPath,
                toBrowserCdPath(contents, rootPath),
                '/'
            ]);
        };
        const exit = async () => {
            await cleanupSession();
            try {
                await app.commands.execute('application:close-all');
            }
            catch {
                // Non-fatal.
            }
            try {
                await app.commands.execute('launcher:create');
            }
            catch {
                // Non-fatal.
            }
        };
        // 处理后端返回的 data（包含 frontend_ops / await_feedback 等），并把执行过程以“chunk”形式回流给 Chat UI：
        // - system_text：系统提示（例如执行日志/错误）
        // - assistant_raw_updates：对 assistant raw 的增量覆写（用于回环时同步 notebook 的真实内容）
        // - trace_update：用于在 Chat 中点击定位到对应的 cell
        const handleToolResult = async function* (data) {
            const maybeObject = data;
            const MAX_AUTO_FEEDBACK_TURNS = (0, settings_1.getDeepAnalyzeSettings)().maxAutoFeedbackTurns ?? 50;
            const ops = Array.isArray(maybeObject?.frontend_ops)
                ? maybeObject?.frontend_ops
                : [];
            const changedPaths = Array.isArray(maybeObject?.changed_paths)
                ? maybeObject?.changed_paths
                : [];
            const revertByPath = (path) => {
                const widget = docManager.findWidget(path);
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                const context = widget?.context;
                if (!context) {
                    return;
                }
                if (context.model?.dirty) {
                    return;
                }
                void context.revert?.();
            };
            for (const item of changedPaths) {
                const path = String(item ?? '').trim();
                if (path) {
                    revertByPath(path);
                }
            }
            const truncateText = (value, limit = 2000) => {
                const raw = String(value ?? '');
                if (raw.length <= limit) {
                    return raw;
                }
                return `${raw.slice(0, Math.max(0, limit - 1))}…`;
            };
            const normalizeOutputs = (outputs) => {
                const items = Array.isArray(outputs) ? outputs.slice(0, 20) : [];
                return items.map(out => {
                    const cloned = { ...(out ?? {}) };
                    if (cloned?.output_type === 'stream') {
                        cloned.text = truncateText(cloned.text);
                    }
                    if (cloned?.output_type === 'error') {
                        cloned.ename = truncateText(cloned.ename, 200);
                        cloned.evalue = truncateText(cloned.evalue, 2000);
                        if (Array.isArray(cloned.traceback)) {
                            cloned.traceback = cloned.traceback.map((t) => truncateText(t, 2000));
                        }
                    }
                    const data = cloned?.data;
                    if (data && typeof data === 'object') {
                        const nextData = { ...data };
                        if (typeof nextData['text/plain'] === 'string') {
                            nextData['text/plain'] = truncateText(nextData['text/plain']);
                        }
                        cloned.data = nextData;
                    }
                    return cloned;
                });
            };
            const summarizeOutputs = (outputs) => {
                const lines = [];
                const stdout = outputs
                    .filter(out => out?.output_type === 'stream' && out?.name === 'stdout')
                    .map(out => String(out?.text ?? ''))
                    .join('');
                const stderr = outputs
                    .filter(out => out?.output_type === 'stream' && out?.name === 'stderr')
                    .map(out => String(out?.text ?? ''))
                    .join('');
                if (stdout.trim()) {
                    lines.push(`stdout: ${truncateText(stdout.trim(), 8000)}`);
                }
                if (stderr.trim()) {
                    lines.push(`stderr: ${truncateText(stderr.trim(), 8000)}`);
                }
                const executeResult = outputs.find(out => out?.output_type === 'execute_result');
                const textPlain = executeResult?.data?.['text/plain'];
                if (typeof textPlain === 'string' && textPlain.trim()) {
                    lines.push(`result: ${truncateText(String(textPlain).trim(), 4000)}`);
                }
                const errors = outputs.filter(out => out?.output_type === 'error');
                for (const err of errors) {
                    const ename = String(err?.ename ?? '').trim();
                    const evalue = String(err?.evalue ?? '').trim();
                    const tb = Array.isArray(err?.traceback) ? err.traceback.join('\n') : '';
                    const head = [ename, evalue].filter(Boolean).join(': ');
                    const body = tb.trim() ? tb.trim() : head;
                    if (body.trim()) {
                        lines.push(`error: ${truncateText(body.trim(), 12000)}`);
                    }
                }
                return lines.join('\n');
            };
            // 执行一批 frontend_ops（由后端下发），并在过程中产出 tool_results：
            // - 对 notebook 的写入/执行全部发生在前端（NotebookPanel/sharedModel）
            // - 执行输出会汇总为文本，用于后端下一轮上下文（role=execute）
            const execOpsStream = async function* (opsToRun, awaitFeedback, depth = 0) {
                const logs = [];
                const userVisible = [];
                const toolResults = [];
                let pendingScratchCodeCell = false;
                const pickSyncMeta = (rawOp) => {
                    const meta = {};
                    if (rawOp?.turn_id != null) {
                        meta.turn_id = String(rawOp.turn_id);
                    }
                    if (rawOp?.segment_tag != null) {
                        meta.segment_tag = String(rawOp.segment_tag);
                    }
                    if (rawOp?.segment_kind != null) {
                        meta.segment_kind = String(rawOp.segment_kind);
                    }
                    const ordinal = Number(rawOp?.segment_ordinal);
                    if (Number.isFinite(ordinal)) {
                        meta.segment_ordinal = ordinal;
                    }
                    return meta;
                };
                for (const raw of opsToRun) {
                    const op = raw;
                    const opName = String(op?.op ?? '').trim();
                    const path = String(op?.path ?? '').trim();
                    const opId = op?.id ? String(op.id) : undefined;
                    if (!opName || !path) {
                        continue;
                    }
                    if (opName === 'create_notebook') {
                        const overwrite = Boolean(op?.overwrite);
                        const shouldOpen = op?.open === false ? false : true;
                        const target = String(op?.target ?? '').trim().toLowerCase();
                        const parent = coreutils_1.PathExt.dirname(path);
                        await (0, workspace_1.ensureDirectoryPath)(contents, parent);
                        const resolveRefWidgetId = () => {
                            const outputPath = (0, storage_1.getDeepAnalyzeItem)('activeOutputPath') ?? '';
                            const scratchPath = (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') ?? '';
                            const normalize = (value) => String(value ?? '')
                                .trim()
                                .toLowerCase()
                                .replace(/[\s_]+/g, '-');
                            const targetNormalized = normalize(target);
                            const isOutput = targetNormalized === 'output' ||
                                targetNormalized === 'model-output' ||
                                targetNormalized === 'modeloutput' ||
                                targetNormalized === 'model';
                            const isScratch = targetNormalized === 'scratch';
                            if (isOutput && outputPath) {
                                return docManager.findWidget(outputPath)?.id;
                            }
                            if (isScratch && scratchPath) {
                                return docManager.findWidget(scratchPath)?.id;
                            }
                            return undefined;
                        };
                        const refWidgetId = resolveRefWidgetId();
                        const openOptions = refWidgetId
                            ? { mode: 'tab-after', ref: refWidgetId }
                            : undefined;
                        if (!overwrite) {
                            try {
                                await contents.get(path, { content: false });
                                if (shouldOpen) {
                                    docManager.openOrReveal(path, undefined, undefined, openOptions);
                                    logs.push(`已打开 notebook：${path}`);
                                }
                                else {
                                    logs.push(`已确认 notebook 存在（未打开）：${path}`);
                                }
                                continue;
                            }
                            catch {
                                // create
                            }
                        }
                        const model = await docManager.newUntitled({ path: parent, type: 'notebook' });
                        try {
                            await docManager.rename(model.path, path);
                        }
                        catch {
                            // ignore rename failure
                        }
                        if (shouldOpen) {
                            docManager.openOrReveal(path, undefined, undefined, openOptions);
                            logs.push(`已创建 notebook：${path}`);
                        }
                        else {
                            logs.push(`已创建 notebook（未打开）：${path}`);
                        }
                        continue;
                    }
                    const panel = await ensureNotebookPanel(path);
                    const notebook = panel.content;
                    if (!notebook?.model?.sharedModel) {
                        throw new Error(`不是 NotebookPanel：${path}`);
                    }
                    const sharedModel = notebook.model.sharedModel;
                    const index = Number.isFinite(op?.index) ? Number(op.index) : 0;
                    if (opName === 'list_cells') {
                        const items = (notebook.widgets ?? []).map((cell, i) => {
                            const cellType = cell?.model?.type ?? cell?.model?.sharedModel?.cell_type ?? 'unknown';
                            const source = cell?.model?.sharedModel?.getSource?.() ?? cell?.model?.value?.text ?? '';
                            const firstLine = String(source).split('\n')[0] ?? '';
                            return `${i}. [${cellType}] ${firstLine}`.trim();
                        });
                        logs.push(items.join('\n') || '(empty)');
                        continue;
                    }
                    if (opName === 'get_cell') {
                        const cell = notebook.widgets?.[index];
                        const source = cell?.model?.sharedModel?.getSource?.() ??
                            cell?.model?.value?.text ??
                            '';
                        logs.push(String(source));
                        continue;
                    }
                    if (opName === 'read_cell') {
                        const cell = notebook.widgets?.[index];
                        if (!cell) {
                            throw new Error(`cell index 越界：${index}`);
                        }
                        const cellType = cell?.model?.type ?? cell?.model?.sharedModel?.cell_type ?? 'unknown';
                        const source = cell?.model?.sharedModel?.getSource?.() ??
                            cell?.model?.value?.text ??
                            '';
                        const outputs = cell?.model?.outputs?.toJSON?.() ?? [];
                        const executionCount = 
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        cell?.model?.executionCount ??
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            cell?.model?.execution_count ??
                            cell?.model?.sharedModel?.execution_count ??
                            null;
                        const metadata = cell?.model?.metadata?.toJSON?.() ?? {};
                        const payload = {
                            index,
                            cell_type: cellType,
                            source: String(source),
                            execution_count: executionCount,
                            outputs: normalizeOutputs(outputs),
                            metadata
                        };
                        logs.push(JSON.stringify(payload, null, 2));
                        continue;
                    }
                    if (opName === 'insert_cell') {
                        const cellType = String(op?.cell_type ?? 'code');
                        const source = String(op?.source ?? '');
                        const maybeIndex = Number.isFinite(op?.index) ? Number(op.index) : NaN;
                        const insertIndex = Number.isFinite(maybeIndex) && maybeIndex >= 0
                            ? maybeIndex
                            : notebook.widgets?.length ?? 0;
                        const syncMeta = pickSyncMeta(op);
                        if (opId) {
                            syncMeta.op_id = opId;
                        }
                        sharedModel.insertCell(insertIndex, {
                            cell_type: cellType,
                            source,
                            metadata: {
                                ...(cellType === 'code' ? { trusted: true } : {}),
                                deepanalyze: syncMeta
                            }
                        });
                        notebook.activeCellIndex = Math.min(insertIndex, (notebook.widgets?.length ?? 1) - 1);
                        logs.push(`已插入 cell：index=${insertIndex} type=${cellType}`);
                        toolResults.push({
                            id: opId,
                            op: opName,
                            path,
                            index: insertIndex,
                            cell_type: cellType,
                            ...syncMeta
                        });
                        const scratchPath = (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') ?? '';
                        if (scratchPath && path === scratchPath) {
                            const headerMatch = source.match(/^###\s*(Analyze|Understand|Code|Answer)\b/i);
                            if (cellType === 'markdown' && headerMatch) {
                                const tag = String(headerMatch[1] ?? '').trim();
                                if (tag.toLowerCase() === 'code') {
                                    pendingScratchCodeCell = true;
                                }
                                else {
                                    pendingScratchCodeCell = false;
                                    yield { trace_update: { tag, path, index: insertIndex } };
                                }
                            }
                            else if (cellType === 'code' && pendingScratchCodeCell) {
                                pendingScratchCodeCell = false;
                                yield { trace_update: { tag: 'Code', path, index: insertIndex } };
                            }
                        }
                        continue;
                    }
                    if (opName === 'delete_cell') {
                        sharedModel.deleteCell(index);
                        logs.push(`已删除 cell：index=${index}`);
                        toolResults.push({ id: opId, op: opName, path, index, ...pickSyncMeta(op) });
                        continue;
                    }
                    if (opName === 'update_cell') {
                        const source = String(op?.source ?? '');
                        const cell = notebook.widgets?.[index];
                        const syncMeta = pickSyncMeta(op);
                        if (opId) {
                            syncMeta.op_id = opId;
                        }
                        if (cell?.model?.sharedModel?.setSource) {
                            cell.model.sharedModel.setSource(source);
                        }
                        else {
                            const sharedCell = sharedModel.getCell?.(index);
                            sharedCell?.setSource?.(source);
                        }
                        try {
                            cell?.model?.metadata?.set?.('deepanalyze', syncMeta);
                        }
                        catch {
                            // ignore
                        }
                        logs.push(`已更新 cell：index=${index}`);
                        toolResults.push({ id: opId, op: opName, path, index, ...syncMeta });
                        continue;
                    }
                    if (opName === 'run_last_cell') {
                        const widgets = notebook.widgets ?? [];
                        let targetIndex = -1;
                        for (let i = widgets.length - 1; i >= 0; i--) {
                            const w = widgets[i];
                            const cellType = w?.model?.type ?? w?.model?.sharedModel?.cell_type ?? '';
                            if (String(cellType).toLowerCase() === 'code') {
                                targetIndex = i;
                                break;
                            }
                        }
                        if (targetIndex < 0) {
                            throw new Error('没有可执行的 code cell');
                        }
                        const cellWidget = widgets[targetIndex];
                        try {
                            const syncMeta = pickSyncMeta(op);
                            if (opId) {
                                syncMeta.op_id = opId;
                            }
                            cellWidget?.model?.metadata?.set?.('deepanalyze', syncMeta);
                        }
                        catch {
                            // ignore
                        }
                        const ok = await notebook_1.NotebookActions.runCells(notebook, [cellWidget], panel.sessionContext);
                        const outputs = cellWidget?.model?.outputs?.toJSON?.() ?? [];
                        const text = summarizeOutputs(outputs);
                        logs.push(`执行${ok ? '成功' : '失败'}：index=${targetIndex}\n${text}`);
                        toolResults.push({
                            id: opId,
                            op: opName,
                            path,
                            index: targetIndex,
                            ok,
                            outputs: normalizeOutputs(outputs),
                            text,
                            ...pickSyncMeta(op)
                        });
                        continue;
                    }
                    if (opName === 'run_cell') {
                        const cellWidget = notebook.widgets?.[index];
                        if (!cellWidget) {
                            throw new Error(`cell index 越界：${index}`);
                        }
                        try {
                            const syncMeta = pickSyncMeta(op);
                            if (opId) {
                                syncMeta.op_id = opId;
                            }
                            cellWidget?.model?.metadata?.set?.('deepanalyze', syncMeta);
                        }
                        catch {
                            // ignore
                        }
                        const ok = await notebook_1.NotebookActions.runCells(notebook, [cellWidget], panel.sessionContext);
                        const outputs = cellWidget?.model?.outputs?.toJSON?.() ?? [];
                        const text = summarizeOutputs(outputs);
                        logs.push(`执行${ok ? '成功' : '失败'}：index=${index}\n${text}`);
                        toolResults.push({
                            id: opId,
                            op: opName,
                            path,
                            index,
                            ok,
                            outputs: normalizeOutputs(outputs),
                            text,
                            ...pickSyncMeta(op)
                        });
                        continue;
                    }
                    const message = `未知 op：${opName}`;
                    logs.push(message);
                    userVisible.push(message);
                    toolResults.push({ id: opId, op: opName, path, ok: false, ...pickSyncMeta(op) });
                }
                const sessionId = (0, storage_1.getDeepAnalyzeItem)('sessionId') ?? '';
                const logText = logs.filter(Boolean).join('\n\n');
                const autoContinueEnabled = chatPanel?.getAutoContinueEnabled() ?? true;
                const deferBackendReturn = awaitFeedback && !autoContinueEnabled;
                if (!deferBackendReturn && (logText.trim() || toolResults.length > 0)) {
                    void (0, api_1.sendFrontendLog)({
                        session_id: sessionId || undefined,
                        depth,
                        await_feedback: awaitFeedback,
                        logs: logText,
                        tool_results: toolResults
                    }).catch(() => undefined);
                }
                if (userVisible.length > 0) {
                    yield { system_text: userVisible.join('\n') };
                }
                if (!awaitFeedback) {
                    return;
                }
                if (depth >= MAX_AUTO_FEEDBACK_TURNS) {
                    yield {
                        system_text: `(已达到自动执行轮次上限 ${MAX_AUTO_FEEDBACK_TURNS}，停止继续调用模型)`
                    };
                    return;
                }
                if (!sessionId) {
                    yield { system_text: '(缺少 sessionId，无法回传执行结果)' };
                    return;
                }
                const collectNotebookSnapshots = async () => {
                    const indicesByPath = new Map();
                    const addIndex = (path, index) => {
                        if (!Number.isFinite(index) || index < 0) {
                            return;
                        }
                        const set = indicesByPath.get(path) ?? new Set();
                        set.add(index);
                        indicesByPath.set(path, set);
                    };
                    const MAX_CELLS = 16;
                    const MAX_SOURCE_LEN = 6000;
                    const blocks = [];
                    const refreshedToolResults = toolResults.map(it => ({ ...(it ?? {}) }));
                    const getDeepAnalyzeMeta = (cell) => {
                        try {
                            const meta = cell?.model?.metadata;
                            if (meta?.get) {
                                return meta.get('deepanalyze');
                            }
                            return meta?.toJSON?.()?.deepanalyze ?? null;
                        }
                        catch {
                            return null;
                        }
                    };
                    const normalizeWanted = (it) => {
                        const turnId = String(it?.turn_id ?? '').trim();
                        const segTag = String(it?.segment_tag ?? '').trim();
                        const segKind = String(it?.segment_kind ?? '').trim();
                        const ordinal = Number.isFinite(it?.segment_ordinal) ? Number(it.segment_ordinal) : NaN;
                        return { turnId, segTag, segKind, ordinal };
                    };
                    const resolveIndexByMeta = (notebook, it) => {
                        const wanted = normalizeWanted(it);
                        if (!wanted.turnId || !wanted.segTag || !wanted.segKind || !Number.isFinite(wanted.ordinal)) {
                            return null;
                        }
                        const widgets = notebook?.widgets ?? [];
                        for (let i = 0; i < widgets.length; i++) {
                            const cell = widgets[i];
                            const meta = getDeepAnalyzeMeta(cell);
                            if (!meta) {
                                continue;
                            }
                            const turnId = String(meta?.turn_id ?? '').trim();
                            const segTag = String(meta?.segment_tag ?? '').trim();
                            const segKind = String(meta?.segment_kind ?? '').trim();
                            const ordinal = Number.isFinite(meta?.segment_ordinal) ? Number(meta.segment_ordinal) : NaN;
                            if (turnId === wanted.turnId &&
                                segTag === wanted.segTag &&
                                segKind === wanted.segKind &&
                                Number.isFinite(ordinal) &&
                                ordinal === wanted.ordinal) {
                                return i;
                            }
                        }
                        return null;
                    };
                    // 先按 meta 把 tool_results 的 index 纠正，避免用户增删 cell 后 index 漂移导致快照/覆写错位。
                    const pathGroups = new Map();
                    for (const it of refreshedToolResults) {
                        const path = String(it?.path ?? '').trim();
                        if (!path)
                            continue;
                        const list = pathGroups.get(path) ?? [];
                        list.push(it);
                        pathGroups.set(path, list);
                    }
                    for (const [path, items] of pathGroups) {
                        const panel = await ensureNotebookPanel(path);
                        const notebook = panel?.content;
                        if (!notebook) {
                            continue;
                        }
                        for (const it of items) {
                            const resolved = resolveIndexByMeta(notebook, it);
                            if (resolved != null && Number.isFinite(resolved) && resolved >= 0) {
                                it.index = resolved;
                            }
                            const index = Number.isFinite(it?.index) ? Number(it.index) : NaN;
                            addIndex(path, index);
                        }
                        const indicesSet = indicesByPath.get(path) ?? new Set();
                        const indices = Array.from(indicesSet)
                            .filter(n => Number.isFinite(n))
                            .sort((a, b) => a - b)
                            .slice(0, MAX_CELLS);
                        if (indices.length === 0) {
                            continue;
                        }
                        blocks.push(`# Notebook: ${path}`);
                        for (const index of indices) {
                            const cell = notebook.widgets?.[index];
                            if (!cell) {
                                continue;
                            }
                            const cellType = cell?.model?.type ?? cell?.model?.sharedModel?.cell_type ?? 'unknown';
                            const rawSource = cell?.model?.sharedModel?.getSource?.() ??
                                cell?.model?.value?.text ??
                                '';
                            const source = truncateText(String(rawSource ?? ''), MAX_SOURCE_LEN);
                            const outputs = cell?.model?.outputs?.toJSON?.() ?? [];
                            const outputsText = summarizeOutputs(outputs);
                            blocks.push(`\n## cell[${index}] (${cellType})`);
                            if (String(cellType).toLowerCase() === 'code') {
                                blocks.push(`\n\`\`\`python\n${source}\n\`\`\``);
                                if (outputsText.trim()) {
                                    blocks.push(`\n### outputs\n${outputsText}`);
                                }
                            }
                            else {
                                blocks.push(`\n${source}`);
                            }
                            for (const item of refreshedToolResults) {
                                if (String(item?.path ?? '') !== path) {
                                    continue;
                                }
                                if (!Number.isFinite(item?.index) || Number(item.index) !== index) {
                                    continue;
                                }
                                if (item?.op === 'run_cell' || item?.op === 'run_last_cell') {
                                    item.source = source;
                                    item.outputs = normalizeOutputs(outputs);
                                    item.text = outputsText;
                                }
                                if (item?.op === 'insert_cell' || item?.op === 'update_cell') {
                                    item.source = source;
                                }
                            }
                        }
                    }
                    const executeText = blocks.join('\n').trim();
                    return { execute_text: executeText, tool_results: refreshedToolResults };
                };
                try {
                    if (!autoContinueEnabled) {
                        const decision = chatPanel
                            ? await chatPanel.waitForContinueOrAbort()
                            : 'continue';
                        if (decision === 'abort') {
                            yield { system_text: '已中止：未回传本轮执行结果，停止继续生成。' };
                            return;
                        }
                    }
                    const feedbackPayload = await collectNotebookSnapshots();
                    if (deferBackendReturn && (logText.trim() || toolResults.length > 0)) {
                        void (0, api_1.sendFrontendLog)({
                            session_id: sessionId || undefined,
                            depth,
                            await_feedback: awaitFeedback,
                            logs: logText,
                            tool_results: feedbackPayload.tool_results
                        }).catch(() => undefined);
                    }
                    chatPanel?.setModelGenerating(true);
                    let feedbackResponse = null;
                    try {
                        await startStreamingToScratch();
                        chatPanel?.startAssistantStreaming();
                        for await (const event of (0, api_1.streamAgentFeedback)({
                            session_id: sessionId,
                            execute_text: feedbackPayload.execute_text,
                            tool_results: feedbackPayload.tool_results,
                            model_id: (0, storage_1.getDeepAnalyzeItem)('modelId') || undefined,
                            prompt_lang: (0, storage_1.getDeepAnalyzeItem)('promptLang') || 'zh'
                        })) {
                            if (event.type === 'delta') {
                                appendStreamingToScratch(event.delta);
                                chatPanel?.appendAssistantStreaming(event.delta);
                                continue;
                            }
                            if (event.type === 'final') {
                                feedbackResponse = event.response;
                                break;
                            }
                        }
                        const data = feedbackResponse?.data;
                        const raw = typeof data?.raw === 'string' ? String(data.raw) : String(feedbackResponse?.reply ?? '');
                        if (!raw.trim()) {
                            throw new Error('流式 feedback 返回空内容');
                        }
                        const awaitFeedbackNext = Boolean(data?.await_feedback);
                        const hasAnswer = /<Answer\b/i.test(raw) && /<\/Answer>/i.test(raw);
                        chatPanel?.finalizeAssistantStreaming({ raw, hasAnswer });
                        const nextStatus = awaitFeedbackNext && !hasAnswer ? 'waiting' : 'done';
                        await finalizeStreamingScratchCell(nextStatus, { unlock: true });
                    }
                    catch (error) {
                        await finalizeStreamingScratchCell('error', { unlock: true });
                        chatPanel?.finalizeAssistantStreaming({ hasAnswer: true });
                        try {
                            void (0, api_1.sendFrontendLog)({
                                session_id: sessionId || undefined,
                                depth,
                                await_feedback: awaitFeedback,
                                message: 'stream_feedback_failed',
                                logs: JSON.stringify({ error: String(error) }, null, 2)
                            });
                        }
                        catch {
                            // ignore
                        }
                        feedbackResponse = await (0, api_1.sendAgentFeedback)({
                            session_id: sessionId,
                            execute_text: feedbackPayload.execute_text,
                            tool_results: feedbackPayload.tool_results,
                            model_id: (0, storage_1.getDeepAnalyzeItem)('modelId') || undefined,
                            prompt_lang: (0, storage_1.getDeepAnalyzeItem)('promptLang') || 'zh'
                        });
                    }
                    finally {
                        chatPanel?.setModelGenerating(false);
                    }
                    const followData = feedbackResponse?.data ?? null;
                    const followText = String(feedbackResponse?.reply ?? '').trim();
                    let followRaw = typeof followData?.raw === 'string' ? String(followData.raw) : '';
                    if (!followRaw.trim() && followText) {
                        followRaw = followText.includes('<')
                            ? followText
                            : `<Answer>\n${followText}\n</Answer>`;
                    }
                    if (followRaw.trim()) {
                        yield { assistant_raw_updates: [followRaw.trim()] };
                    }
                    const followOps = Array.isArray(followData?.frontend_ops)
                        ? followData?.frontend_ops
                        : [];
                    if (followOps.length > 0) {
                        for await (const chunk of execOpsStream(followOps, Boolean(followData?.await_feedback), depth + 1)) {
                            yield chunk;
                        }
                    }
                }
                catch (error) {
                    chatPanel?.setModelGenerating(false);
                    yield { system_text: `(回传执行结果失败：${String(error)})` };
                }
            };
            for await (const chunk of execOpsStream(ops, Boolean(maybeObject?.await_feedback))) {
                yield chunk;
            }
        };
        const chat = new chatPanel_1.DeepAnalyzeChatPanel({
            onExit: () => void exit(),
            onReset: async (options) => {
                if (!options?.clearNotebooks) {
                    return;
                }
                const outputPath = (0, storage_1.getDeepAnalyzeItem)('activeOutputPath') ?? '';
                const scratchPath = (0, storage_1.getDeepAnalyzeItem)('activeScratchPath') ?? '';
                if (outputPath.trim()) {
                    await clearNotebook(outputPath);
                }
                if (scratchPath.trim()) {
                    await clearNotebook(scratchPath);
                }
            },
            onModelStream: async (event) => {
                if (event.type === 'start') {
                    try {
                        await startStreamingToScratch();
                    }
                    catch {
                        // ignore
                    }
                    return;
                }
                if (event.type === 'delta') {
                    appendStreamingToScratch(event.delta);
                    return;
                }
                if (event.type === 'final') {
                    const nextStatus = event.awaitFeedback && !event.hasAnswer ? 'waiting' : 'done';
                    try {
                        // 生成结束后解锁（允许复制/修改），但如果需要回环则显示“等待执行”而非 done。
                        await finalizeStreamingScratchCell(nextStatus, { unlock: true });
                    }
                    catch {
                        // ignore
                    }
                    return;
                }
                if (event.type === 'end') {
                    // 兜底：如果没有拿到 final（例如 SSE 被截断），避免一直停留在“生成中…”
                    await finalizeStreamingScratchCell('done', { unlock: true });
                    return;
                }
                if (event.type === 'error') {
                    await finalizeStreamingScratchCell('error', { unlock: true });
                    return;
                }
            },
            onNavigateToCell: async (path, index) => {
                const panel = await ensureNotebookPanel(path);
                const notebook = panel?.content;
                if (!notebook) {
                    return;
                }
                try {
                    app.shell.activateById(panel.id);
                }
                catch {
                    // ignore
                }
                try {
                    notebook.activeCellIndex = index;
                }
                catch {
                    // ignore
                }
                try {
                    notebook.scrollToItem?.(index);
                }
                catch {
                    // ignore
                }
                try {
                    const node = notebook.widgets?.[index]?.node;
                    node?.scrollIntoView?.({ block: 'start' });
                }
                catch {
                    // ignore
                }
            },
            onToolResult: handleToolResult
        });
        chat.id = `deepanalyze-chat-${instanceId}`;
        chat.title.closable = false;
        chatPanel = chat;
        chatWidget = chat;
        restoreAddButtonInterceptor = installMainAreaAddButtonClickInterceptor(app, docManager, workspaceDir);
        activeSession = {
            previousBrowserPath,
            disposables: [rootRestriction, restoreAddButtonInterceptor]
        };
        const originalDispose = chat.dispose.bind(chat);
        chat.dispose = () => {
            void cleanupSession();
            originalDispose();
        };
    }
    catch {
        chatWidget = null;
        rootRestriction.dispose();
        restoreAddButtonInterceptor?.dispose();
        restoreAddButtonInterceptor = null;
    }
    if (chatWidget) {
        // scratch 与 model_output 放在中间栏同一组（tab），右侧仅保留 chat。
        const scratchWidget = docManager.openOrReveal(scratchNotebookPath, undefined, undefined, {
            mode: 'tab-after',
            ref: outputWidget.id
        });
        if (scratchWidget) {
            scratchWidget.title.closable = false;
            try {
                app.shell.add(scratchWidget, 'main', { mode: 'tab-after', ref: outputWidget.id });
            }
            catch {
                ensureInMainArea(scratchWidget);
            }
        }
        // “使用大模型编辑”右键菜单已改为全局注册（见 src/index.ts），这里不再对 scratch 单独安装。
        try {
            app.shell.add(chatWidget, 'main', { mode: 'split-right', ref: outputWidget.id });
        }
        catch {
            ensureInMainArea(chatWidget);
        }
    }
    else {
        const scratchWidget = docManager.openOrReveal(scratchNotebookPath, undefined, undefined, {
            mode: 'split-right',
            ref: outputWidget.id
        });
        scratchWidget && (scratchWidget.title.closable = false);
        await (0, apputils_1.showErrorMessage)('DeepAnalyze', '对话面板不可用，已用 Notebook 分屏代替。');
    }
    return outputWidget;
}
exports.openDeepAnalyze = openDeepAnalyze;
async function restoreDeepAnalyzeIfNeeded(app, docManager, defaultBrowser) {
    // 页面刷新后，若 localStorage 仍保存着上一次的 workspace 信息，则尝试自动恢复布局。
    const workspaceDir = (0, storage_1.getDeepAnalyzeItem)('activeWorkspaceDir') ?? '';
    if (!String(workspaceDir).trim()) {
        return;
    }
    try {
        const { contents } = app.serviceManager;
        try {
            const model = await contents.get(workspaceDir, { content: false });
            if (model.type !== 'directory') {
                (0, storage_1.removeDeepAnalyzeItem)('activeWorkspaceDir');
                (0, storage_1.removeDeepAnalyzeItem)('activeOutputPath');
                (0, storage_1.removeDeepAnalyzeItem)('activeScratchPath');
                (0, storage_1.removeDeepAnalyzeItem)('sessionId');
                return;
            }
        }
        catch (error) {
            const status = Number(error?.response?.status);
            if (status === 404) {
                (0, storage_1.removeDeepAnalyzeItem)('activeWorkspaceDir');
                (0, storage_1.removeDeepAnalyzeItem)('activeOutputPath');
                (0, storage_1.removeDeepAnalyzeItem)('activeScratchPath');
                (0, storage_1.removeDeepAnalyzeItem)('sessionId');
                return;
            }
        }
        await openDeepAnalyze(app, docManager, defaultBrowser, {
            workspaceDir,
            skipPrompt: true
        });
    }
    catch {
        // ignore restore errors
    }
}
exports.restoreDeepAnalyzeIfNeeded = restoreDeepAnalyzeIfNeeded;


/***/ }),

/***/ "./lib/deepanalyze/scratchCellRewrite.js":
/*!***********************************************!*\
  !*** ./lib/deepanalyze/scratchCellRewrite.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.installScratchCellRewriteUI = void 0;
const apputils_1 = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
const disposable_1 = __webpack_require__(/*! @lumino/disposable */ "webpack/sharing/consume/default/@lumino/disposable");
const widgets_1 = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
const api_1 = __webpack_require__(/*! ./api */ "./lib/deepanalyze/api.js");
const storage_1 = __webpack_require__(/*! ./storage */ "./lib/deepanalyze/storage.js");
const cellBars = new WeakMap();
function getCellSource(cell) {
    try {
        const shared = cell?.model?.sharedModel;
        if (shared?.getSource) {
            return String(shared.getSource() ?? '');
        }
    }
    catch {
        // ignore
    }
    try {
        return String(cell?.model?.value?.text ?? '');
    }
    catch {
        return '';
    }
}
function getCellType(cell) {
    try {
        const modelType = String(cell?.model?.type ?? '').trim();
        if (modelType) {
            return modelType;
        }
    }
    catch {
        // ignore
    }
    try {
        const sharedType = String(cell?.model?.sharedModel?.cell_type ?? '').trim();
        if (sharedType) {
            return sharedType;
        }
    }
    catch {
        // ignore
    }
    return '';
}
function _asText(value) {
    if (value == null)
        return '';
    if (Array.isArray(value)) {
        return value.map(v => String(v ?? '')).join('');
    }
    return String(value);
}
function getCodeCellExecutionResult(cell) {
    const cellType = getCellType(cell);
    if (cellType !== 'code') {
        return '';
    }
    let outputs = [];
    try {
        const modelOutputs = cell?.model?.outputs;
        if (modelOutputs?.toJSON) {
            const json = modelOutputs.toJSON();
            if (Array.isArray(json)) {
                outputs = json;
            }
        }
        else if (Array.isArray(modelOutputs)) {
            outputs = modelOutputs;
        }
    }
    catch {
        // ignore
    }
    if (!outputs.length) {
        return '';
    }
    const parts = [];
    for (const output of outputs) {
        const outputType = String(output?.output_type ?? '').trim();
        if (outputType === 'stream') {
            const name = String(output?.name ?? 'stdout');
            const text = _asText(output?.text);
            const content = text.trimEnd();
            if (content) {
                parts.push(`[${name}]\n${content}`);
            }
            continue;
        }
        if (outputType === 'error') {
            const ename = String(output?.ename ?? '').trim();
            const evalue = String(output?.evalue ?? '').trim();
            const header = [ename, evalue].filter(Boolean).join(': ');
            const traceback = output?.traceback;
            const tbText = Array.isArray(traceback)
                ? traceback.map(v => String(v ?? '')).join('\n')
                : String(traceback ?? '');
            const content = tbText.trimEnd();
            if (content || header) {
                parts.push(`[error]${header ? ` ${header}` : ''}\n${content || '(无 traceback)'}`);
            }
            continue;
        }
        if (outputType === 'execute_result' || outputType === 'display_data') {
            const data = output?.data ?? {};
            const plain = _asText(data?.['text/plain']);
            const markdown = _asText(data?.['text/markdown']);
            const content = (plain || markdown).trimEnd();
            if (content) {
                parts.push(`[result]\n${content}`);
            }
            continue;
        }
    }
    const merged = parts.join('\n\n').trim();
    if (!merged) {
        return '';
    }
    const maxChars = 8000;
    if (merged.length <= maxChars) {
        return merged;
    }
    const tail = merged.slice(-maxChars);
    return `（输出过长，已截断，仅保留最后 ${maxChars} 个字符）\n${tail}`;
}
function setCellSource(cell, source) {
    try {
        const shared = cell?.model?.sharedModel;
        if (shared?.setSource) {
            shared.setSource(source);
            return;
        }
    }
    catch {
        // ignore
    }
    try {
        if (cell?.model?.value) {
            cell.model.value.text = source;
        }
    }
    catch {
        // ignore
    }
}
function getCellRoot(cell) {
    return (cell?.node ?? null);
}
function disposeRewriteBars(cell) {
    const bars = cellBars.get(cell);
    const root = bars?.root ?? getCellRoot(cell);
    if (root) {
        try {
            root
                .querySelectorAll('.deepanalyze-cell-rewrite-topbar, .deepanalyze-cell-rewrite-bottombar')
                .forEach(node => node.remove());
        }
        catch {
            // ignore
        }
    }
    if (bars) {
        try {
            bars.topBar.remove();
        }
        catch {
            // ignore
        }
        try {
            bars.bottomBar.remove();
        }
        catch {
            // ignore
        }
        cellBars.delete(cell);
    }
}
function ensureRewriteBars(cell) {
    const existing = cellBars.get(cell);
    if (existing) {
        if (existing.topBar.isConnected && existing.bottomBar.isConnected) {
            return existing;
        }
        cellBars.delete(cell);
    }
    const root = getCellRoot(cell);
    if (!root) {
        return null;
    }
    // 防止 notebook 重新渲染/复用 DOM 时重复插入导致出现多个通知条。
    try {
        const leftovers = root.querySelectorAll('.deepanalyze-cell-rewrite-topbar, .deepanalyze-cell-rewrite-bottombar');
        leftovers.forEach(node => node.remove());
    }
    catch {
        // ignore
    }
    const buildStatus = () => {
        const status = document.createElement('div');
        status.className = 'deepanalyze-cell-rewrite-status';
        const dot = document.createElement('span');
        dot.className = 'deepanalyze-cell-rewrite-dot';
        const text = document.createElement('span');
        text.className = 'deepanalyze-cell-rewrite-text';
        status.appendChild(dot);
        status.appendChild(text);
        return { status, dot, text };
    };
    const topBar = document.createElement('div');
    topBar.className = 'deepanalyze-cell-rewrite-bar deepanalyze-cell-rewrite-topbar';
    topBar.hidden = true;
    const topStatus = buildStatus();
    const topActions = document.createElement('div');
    topActions.className = 'deepanalyze-cell-rewrite-actions';
    const stopButton = document.createElement('button');
    stopButton.type = 'button';
    stopButton.className = 'deepanalyze-cell-rewrite-stop';
    stopButton.textContent = '停止';
    topActions.appendChild(stopButton);
    topBar.appendChild(topStatus.status);
    topBar.appendChild(topActions);
    const bottomBar = document.createElement('div');
    bottomBar.className =
        'deepanalyze-cell-rewrite-bar deepanalyze-cell-rewrite-bottombar';
    bottomBar.hidden = true;
    const bottomStatus = buildStatus();
    const bottomActions = document.createElement('div');
    bottomActions.className = 'deepanalyze-cell-rewrite-actions';
    const acceptButton = document.createElement('button');
    acceptButton.type = 'button';
    acceptButton.className = 'deepanalyze-cell-rewrite-accept';
    acceptButton.textContent = '接受';
    const rollbackButton = document.createElement('button');
    rollbackButton.type = 'button';
    rollbackButton.className = 'deepanalyze-cell-rewrite-rollback';
    rollbackButton.textContent = '回退';
    bottomActions.appendChild(acceptButton);
    bottomActions.appendChild(rollbackButton);
    bottomBar.appendChild(bottomStatus.status);
    bottomBar.appendChild(bottomActions);
    const header = (root.querySelector('.jp-CellHeader') ??
        root.querySelector('.jp-Cell-header'));
    if (header) {
        header.insertAdjacentElement('afterend', topBar);
    }
    else {
        root.insertAdjacentElement('afterbegin', topBar);
    }
    // 底部通知条放在“输出区之前”（输入区之后），保证位于输出结果顶部。
    const outputWrapper = root.querySelector('.jp-Cell-outputWrapper');
    if (outputWrapper) {
        outputWrapper.insertAdjacentElement('beforebegin', bottomBar);
    }
    else {
        root.insertAdjacentElement('beforeend', bottomBar);
    }
    const state = {
        root,
        topBar,
        topStatusText: topStatus.text,
        topDot: topStatus.dot,
        stopButton,
        bottomBar,
        bottomStatusText: bottomStatus.text,
        acceptButton,
        rollbackButton,
        originalSource: null,
        abortController: null,
        phase: 'hidden'
    };
    cellBars.set(cell, state);
    return state;
}
function setBarsPhase(state, phase) {
    state.phase = phase;
    if (phase === 'hidden') {
        state.topBar.hidden = true;
        state.bottomBar.hidden = true;
        return;
    }
    if (phase === 'waiting') {
        state.topBar.hidden = false;
        state.bottomBar.hidden = true;
        state.topDot.classList.add('deepanalyze-cell-rewrite-dot-working');
        state.topStatusText.textContent = 'waiting';
        return;
    }
    if (phase === 'running') {
        state.topBar.hidden = false;
        state.bottomBar.hidden = true;
        state.topDot.classList.add('deepanalyze-cell-rewrite-dot-working');
        state.topStatusText.textContent = '生成中…';
        return;
    }
    // done
    // 为避免偶发残留，结束后直接移除顶部停止条（底部接受/回退条会出现）。
    try {
        state.topBar.hidden = true;
        state.topBar.remove();
    }
    catch {
        // ignore
    }
    try {
        const leftovers = state.root.querySelectorAll('.deepanalyze-cell-rewrite-topbar');
        leftovers.forEach(node => node.remove());
    }
    catch {
        // ignore
    }
    state.bottomBar.hidden = false;
    state.topDot.classList.remove('deepanalyze-cell-rewrite-dot-working');
    state.bottomStatusText.textContent = '已生成改写结果';
}
function buildInstructionDialogBody() {
    const body = document.createElement('div');
    body.style.display = 'flex';
    body.style.flexDirection = 'column';
    body.style.gap = '8px';
    body.style.minWidth = '420px';
    const hint = document.createElement('div');
    hint.textContent = '请输入对该单元格的修改指令：';
    body.appendChild(hint);
    const textarea = document.createElement('textarea');
    textarea.rows = 5;
    textarea.placeholder = '例如：把这段代码改成使用 pandas 读取 CSV，并输出前 5 行…';
    textarea.style.width = '100%';
    textarea.style.boxSizing = 'border-box';
    body.appendChild(textarea);
    return { widget: new widgets_1.Widget({ node: body }), textarea };
}
function stripLeadingLanguageWrappers(state, delta) {
    if (state.done) {
        return delta;
    }
    state.buf += String(delta ?? '');
    // 等待首行完整出现再判断（避免 ```python 被切成多段）
    if (!state.buf.includes('\n') && state.buf.length < 120) {
        return '';
    }
    let s = state.buf.replace(/\r\n/g, '\n');
    for (;;) {
        const trimmed = s.replace(/^\s+/, '');
        const lower = trimmed.toLowerCase();
        if (lower.startsWith('[python]')) {
            s = trimmed.slice('[python]'.length);
            s = s.replace(/^\s*\n?/, '');
            continue;
        }
        if (lower.startsWith('[py]')) {
            s = trimmed.slice('[py]'.length);
            s = s.replace(/^\s*\n?/, '');
            continue;
        }
        if (trimmed.startsWith('```')) {
            const lineEnd = trimmed.indexOf('\n');
            if (lineEnd < 0) {
                // 还没有完整的围栏行，继续等待
                state.buf = trimmed;
                return '';
            }
            const firstLine = trimmed.slice(0, lineEnd).trim().toLowerCase();
            if (firstLine === '```' || firstLine === '```python' || firstLine === '```py') {
                s = trimmed.slice(lineEnd + 1);
                continue;
            }
        }
        break;
    }
    state.done = true;
    state.buf = '';
    return s;
}
function installScratchCellRewriteUI(app) {
    let running = false;
    let lastContextCellNode = null;
    const commandId = 'deepanalyze:cell-llm-edit';
    const has = app.commands.hasCommand?.(commandId) ?? false;
    if (has) {
        return new disposable_1.DisposableDelegate(() => undefined);
    }
    const findNotebook = () => {
        const widget = app.shell.currentWidget;
        const notebook = widget?.content ?? null;
        if (!notebook?.widgets || !notebook?.activeCell) {
            return null;
        }
        return notebook;
    };
    const findCellByNode = (notebook, node) => {
        if (!node) {
            return notebook?.activeCell ?? null;
        }
        const cells = notebook.widgets ?? [];
        for (const cell of cells) {
            const root = getCellRoot(cell);
            if (!root)
                continue;
            if (root === node || root.contains(node)) {
                return cell;
            }
        }
        return notebook?.activeCell ?? null;
    };
    const onContextMenu = (ev) => {
        try {
            const target = ev.target;
            if (!target)
                return;
            const cellNode = target.closest('.jp-Notebook .jp-Cell');
            if (!cellNode)
                return;
            lastContextCellNode = cellNode;
        }
        catch {
            // ignore
        }
    };
    document.addEventListener('contextmenu', onContextMenu, true);
    app.commands.addCommand(commandId, {
        label: '使用大模型编辑',
        caption: '用自然语言指令改写当前单元格内容',
        isVisible: () => Boolean(findNotebook()),
        isEnabled: () => Boolean(findNotebook()) && !running,
        execute: async () => {
            const notebook = findNotebook();
            if (!notebook) {
                return;
            }
            const cell = findCellByNode(notebook, lastContextCellNode);
            if (!cell) {
                void (0, apputils_1.showErrorMessage)('DeepAnalyze', '未找到当前选中的单元格。');
                return;
            }
            const existingBars = cellBars.get(cell) ?? null;
            if (existingBars && existingBars.phase === 'done' && existingBars.originalSource != null) {
                void (0, apputils_1.showErrorMessage)('DeepAnalyze', '该单元格有未确认的改写结果，请先接受或回退。');
                return;
            }
            const { widget, textarea } = buildInstructionDialogBody();
            const result = await (0, apputils_1.showDialog)({
                title: '使用大模型编辑单元格',
                body: widget,
                buttons: [apputils_1.Dialog.cancelButton({ label: '取消' }), apputils_1.Dialog.okButton({ label: '确定' })],
                focusNodeSelector: 'textarea'
            });
            if (!result.button.accept) {
                disposeRewriteBars(cell);
                return;
            }
            const instruction = String(textarea.value ?? '').trim();
            if (!instruction) {
                disposeRewriteBars(cell);
                return;
            }
            const source = getCellSource(cell);
            const cell_type = getCellType(cell) || undefined;
            const execution_result = getCodeCellExecutionResult(cell) || undefined;
            const bars = ensureRewriteBars(cell);
            running = true;
            if (bars) {
                bars.originalSource = source;
                bars.abortController = new AbortController();
                setBarsPhase(bars, 'waiting');
            }
            setCellSource(cell, 'waiting');
            try {
                let rendered = '';
                let pending = '';
                let raf = 0;
                let canceled = false;
                let gotFinal = false;
                const flush = () => {
                    raf = 0;
                    if (!pending)
                        return;
                    rendered += pending;
                    pending = '';
                    setCellSource(cell, rendered);
                };
                const leading = { buf: '', done: false };
                rendered = '';
                let started = false;
                try {
                    if (bars) {
                        bars.stopButton.onclick = ev => {
                            ev?.preventDefault?.();
                            ev?.stopPropagation?.();
                            if (canceled)
                                return;
                            canceled = true;
                            try {
                                bars.abortController?.abort();
                            }
                            catch {
                                // ignore
                            }
                            if (raf) {
                                try {
                                    cancelAnimationFrame(raf);
                                }
                                catch {
                                    // ignore
                                }
                                raf = 0;
                            }
                            pending = '';
                            rendered = '';
                            try {
                                if (bars.originalSource != null) {
                                    setCellSource(cell, bars.originalSource);
                                }
                            }
                            catch {
                                // ignore
                            }
                            bars.abortController = null;
                            bars.originalSource = null;
                            setBarsPhase(bars, 'hidden');
                            disposeRewriteBars(cell);
                            running = false;
                        };
                        bars.acceptButton.onclick = ev => {
                            ev?.preventDefault?.();
                            ev?.stopPropagation?.();
                            bars.abortController = null;
                            bars.originalSource = null;
                            setBarsPhase(bars, 'hidden');
                            disposeRewriteBars(cell);
                        };
                        bars.rollbackButton.onclick = ev => {
                            ev?.preventDefault?.();
                            ev?.stopPropagation?.();
                            try {
                                if (bars.originalSource != null) {
                                    setCellSource(cell, bars.originalSource);
                                }
                            }
                            catch {
                                // ignore
                            }
                            bars.abortController = null;
                            bars.originalSource = null;
                            setBarsPhase(bars, 'hidden');
                            disposeRewriteBars(cell);
                        };
                    }
                    for await (const event of (0, api_1.streamRewriteCellSource)({
                        source,
                        instruction,
                        cell_type,
                        execution_result,
                        model_id: (0, storage_1.getDeepAnalyzeItem)('modelId') || undefined,
                        signal: bars?.abortController?.signal
                    })) {
                        if (event.type === 'start') {
                            started = true;
                            rendered = '';
                            pending = '';
                            setCellSource(cell, '');
                            if (bars) {
                                setBarsPhase(bars, 'running');
                            }
                            continue;
                        }
                        if (event.type === 'delta') {
                            if (!started) {
                                started = true;
                                rendered = '';
                                pending = '';
                                setCellSource(cell, '');
                                if (bars) {
                                    setBarsPhase(bars, 'running');
                                }
                            }
                            const nextDelta = stripLeadingLanguageWrappers(leading, event.delta);
                            if (!nextDelta)
                                continue;
                            pending += nextDelta;
                            if (!raf) {
                                raf = requestAnimationFrame(flush);
                            }
                            continue;
                        }
                        if (event.type === 'final') {
                            gotFinal = true;
                            if (raf) {
                                cancelAnimationFrame(raf);
                                raf = 0;
                            }
                            flush();
                            const finalAnswer = String(event.response?.answer ?? '').replace(/\r\n/g, '\n');
                            if (finalAnswer) {
                                setCellSource(cell, finalAnswer);
                            }
                            if (bars) {
                                bars.abortController = null;
                                setBarsPhase(bars, 'done');
                            }
                            return;
                        }
                    }
                    if (!canceled && !gotFinal) {
                        throw new Error('cell rewrite stream ended without final');
                    }
                }
                catch (error) {
                    const aborted = canceled ||
                        Boolean(bars?.abortController?.signal?.aborted) ||
                        String(error?.name ?? '') === 'AbortError';
                    if (aborted) {
                        return;
                    }
                    if (bars) {
                        setBarsPhase(bars, 'running');
                    }
                    const response = await (0, api_1.rewriteCellSource)({
                        source,
                        instruction,
                        cell_type,
                        execution_result,
                        model_id: (0, storage_1.getDeepAnalyzeItem)('modelId') || undefined,
                        signal: bars?.abortController?.signal
                    });
                    const next = String(response?.answer ?? '').replace(/\r\n/g, '\n');
                    setCellSource(cell, next);
                    if (bars) {
                        bars.abortController = null;
                        setBarsPhase(bars, 'done');
                    }
                    return;
                }
                finally {
                    if (raf) {
                        cancelAnimationFrame(raf);
                    }
                }
            }
            catch (error) {
                try {
                    setCellSource(cell, source);
                }
                catch {
                    // ignore
                }
                if (bars) {
                    bars.abortController = null;
                    bars.originalSource = null;
                    setBarsPhase(bars, 'hidden');
                }
                void (0, apputils_1.showErrorMessage)('DeepAnalyze', `单元格改写失败：${String(error)}`);
            }
            finally {
                running = false;
            }
        }
    });
    const menuDisposable = app.contextMenu.addItem?.({
        command: commandId,
        selector: '.jp-Notebook .jp-Cell',
        rank: 80
    });
    return new disposable_1.DisposableDelegate(() => {
        try {
            document.removeEventListener('contextmenu', onContextMenu, true);
        }
        catch {
            // ignore
        }
        try {
            menuDisposable?.dispose?.();
        }
        catch {
            // ignore
        }
        try {
            app.commands.removeCommand?.(commandId);
        }
        catch {
            // ignore
        }
    });
}
exports.installScratchCellRewriteUI = installScratchCellRewriteUI;


/***/ }),

/***/ "./lib/deepanalyze/settings.js":
/*!*************************************!*\
  !*** ./lib/deepanalyze/settings.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.updateDeepAnalyzeSettings = exports.getDeepAnalyzeSettings = exports.DEFAULT_DEEPANALYZE_SETTINGS = void 0;
// 源码默认值：可在此处直接修改默认配置（localStorage 仍可覆盖）。
exports.DEFAULT_DEEPANALYZE_SETTINGS = {
    // 对应 Jupyter Contents API 的 server-root 相对路径（不是 OS 绝对路径）。
    workspacesRoot: 'DeepAnalyze/workspaces',
    // 自动回环最大轮数（反馈-继续）默认 50。
    maxAutoFeedbackTurns: 50
};
const SETTINGS_KEY = 'deepanalyze.settings';
const LEGACY_WORKSPACES_ROOT_KEY = 'deepanalyze.workspacesRoot';
function safeParseJson(raw) {
    try {
        return JSON.parse(raw);
    }
    catch {
        return null;
    }
}
function readSettingsObject() {
    try {
        const raw = window.localStorage.getItem(SETTINGS_KEY);
        if (!raw) {
            return {};
        }
        const parsed = safeParseJson(raw);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            return {};
        }
        return parsed;
    }
    catch {
        return {};
    }
}
function readLegacyString(key) {
    try {
        const raw = window.localStorage.getItem(key);
        const v = String(raw ?? '').trim();
        return v ? v : undefined;
    }
    catch {
        return undefined;
    }
}
function readLegacyNumber(key) {
    try {
        const raw = window.localStorage.getItem(key);
        if (raw == null) {
            return undefined;
        }
        const num = Number(raw);
        return Number.isFinite(num) ? num : undefined;
    }
    catch {
        return undefined;
    }
}
function getDeepAnalyzeSettings() {
    const obj = readSettingsObject();
    const workspacesRootCandidate = (typeof obj.workspacesRoot === 'string' ? obj.workspacesRoot : undefined) ??
        readLegacyString(LEGACY_WORKSPACES_ROOT_KEY) ??
        exports.DEFAULT_DEEPANALYZE_SETTINGS.workspacesRoot;
    const maxAutoFeedbackTurnsCandidate = (typeof obj.maxAutoFeedbackTurns === 'number' ? obj.maxAutoFeedbackTurns : undefined) ??
        readLegacyNumber('deepanalyze.maxAutoFeedbackTurns') ??
        exports.DEFAULT_DEEPANALYZE_SETTINGS.maxAutoFeedbackTurns;
    const workspacesRoot = String(workspacesRootCandidate ?? '').trim() || undefined;
    const maxAutoFeedbackTurnsRaw = Number(maxAutoFeedbackTurnsCandidate);
    const maxAutoFeedbackTurns = Number.isFinite(maxAutoFeedbackTurnsRaw) && maxAutoFeedbackTurnsRaw > 0
        ? Math.floor(maxAutoFeedbackTurnsRaw)
        : exports.DEFAULT_DEEPANALYZE_SETTINGS.maxAutoFeedbackTurns;
    return {
        workspacesRoot,
        maxAutoFeedbackTurns
    };
}
exports.getDeepAnalyzeSettings = getDeepAnalyzeSettings;
function updateDeepAnalyzeSettings(patch) {
    const current = getDeepAnalyzeSettings();
    const next = { ...current, ...patch };
    try {
        window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
    }
    catch {
        // ignore quota / unavailable
    }
}
exports.updateDeepAnalyzeSettings = updateDeepAnalyzeSettings;


/***/ }),

/***/ "./lib/deepanalyze/storage.js":
/*!************************************!*\
  !*** ./lib/deepanalyze/storage.js ***!
  \************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.removeDeepAnalyzeItem = exports.setDeepAnalyzeItem = exports.getDeepAnalyzeItem = exports.deepAnalyzeStorageKey = exports.deepAnalyzeScopeId = void 0;
const coreutils_1 = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
function normalizeScope(raw) {
    const trimmed = String(raw ?? '').trim();
    if (!trimmed) {
        return '/';
    }
    const withLeadingSlash = trimmed.startsWith('/') ? trimmed : `/${trimmed}`;
    const withoutTrailingSlash = withLeadingSlash.replace(/\/+$/, '');
    return withoutTrailingSlash || '/';
}
function deepAnalyzeScopeId() {
    try {
        return normalizeScope(coreutils_1.PageConfig.getBaseUrl());
    }
    catch {
        return '/';
    }
}
exports.deepAnalyzeScopeId = deepAnalyzeScopeId;
function deepAnalyzeStorageKey(name) {
    const scope = deepAnalyzeScopeId();
    return `deepanalyze.${name}@${scope}`;
}
exports.deepAnalyzeStorageKey = deepAnalyzeStorageKey;
function getDeepAnalyzeItem(name) {
    try {
        return window.localStorage.getItem(deepAnalyzeStorageKey(name)) ?? '';
    }
    catch {
        return '';
    }
}
exports.getDeepAnalyzeItem = getDeepAnalyzeItem;
function setDeepAnalyzeItem(name, value) {
    try {
        window.localStorage.setItem(deepAnalyzeStorageKey(name), String(value ?? ''));
    }
    catch {
        // ignore quota / unavailable
    }
}
exports.setDeepAnalyzeItem = setDeepAnalyzeItem;
function removeDeepAnalyzeItem(name) {
    try {
        window.localStorage.removeItem(deepAnalyzeStorageKey(name));
    }
    catch {
        // ignore
    }
}
exports.removeDeepAnalyzeItem = removeDeepAnalyzeItem;


/***/ }),

/***/ "./lib/deepanalyze/workspace.js":
/*!**************************************!*\
  !*** ./lib/deepanalyze/workspace.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.listWorkspaces = exports.listDeepAnalyzeWorkspaces = exports.ensureNamedWorkspace = exports.ensureNamedDeepAnalyzeWorkspace = exports.sanitizeWorkspaceName = exports.ensureDirectoryPath = exports.createDeepAnalyzeWorkspace = exports.DEFAULT_DEEPANALYZE_WORKSPACES_ROOT = exports.DEFAULT_DEEPANALYZE_ROOT = void 0;
const coreutils_1 = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
exports.DEFAULT_DEEPANALYZE_ROOT = 'DeepAnalyze';
exports.DEFAULT_DEEPANALYZE_WORKSPACES_ROOT = `${exports.DEFAULT_DEEPANALYZE_ROOT}/workspaces`;
function formatTimestampForPath(date) {
    const pad2 = (value) => String(value).padStart(2, '0');
    const year = date.getFullYear();
    const month = pad2(date.getMonth() + 1);
    const day = pad2(date.getDate());
    const hour = pad2(date.getHours());
    const minute = pad2(date.getMinutes());
    const second = pad2(date.getSeconds());
    return `${year}${month}${day}-${hour}${minute}${second}`;
}
async function pathExists(contents, path) {
    try {
        await contents.get(path, { content: false });
        return true;
    }
    catch {
        return false;
    }
}
async function waitForDirectory(contents, path, options) {
    const retries = Math.max(0, Number(options?.retries ?? 10));
    const delayMs = Math.max(0, Number(options?.delayMs ?? 150));
    let lastError = null;
    for (let i = 0; i <= retries; i++) {
        try {
            const model = await contents.get(path, { content: false });
            if (model.type !== 'directory') {
                throw new Error(`目标路径不是目录：${path}`);
            }
            return;
        }
        catch (error) {
            lastError = error;
            const status = Number(error?.response?.status);
            // 仅对“偶发 not found”做重试，其他错误直接抛出。
            if (status !== 404 || i >= retries) {
                throw lastError;
            }
            await new Promise(resolve => setTimeout(resolve, delayMs));
        }
    }
    throw lastError ?? new Error(`等待目录可见超时：${path}`);
}
async function ensureDirectory(contents, fullPath) {
    if (!fullPath || fullPath === '.') {
        return;
    }
    if (await pathExists(contents, fullPath)) {
        return;
    }
    const parentRaw = coreutils_1.PathExt.dirname(fullPath);
    const parent = parentRaw === '.' ? '' : parentRaw;
    const name = coreutils_1.PathExt.basename(fullPath);
    await ensureDirectory(contents, parent);
    const temp = await contents.newUntitled({ path: parent, type: 'directory' });
    const target = parent ? coreutils_1.PathExt.join(parent, name) : name;
    try {
        await contents.rename(temp.path, target);
    }
    catch {
        // 可能是目录已存在但短暂不可见（或并发创建），兜底等待目标目录可见。
        await waitForDirectory(contents, target, { retries: 12, delayMs: 150 });
        return;
    }
    // 目录创建/重命名后偶发短暂不可见，进入工作区前先等待可见。
    await waitForDirectory(contents, target, { retries: 12, delayMs: 150 });
}
function safeWorkspaceRoot() {
    return exports.DEFAULT_DEEPANALYZE_WORKSPACES_ROOT;
}
async function createDeepAnalyzeWorkspace(contents) {
    const root = safeWorkspaceRoot();
    await ensureDirectory(contents, root);
    const timestamp = formatTimestampForPath(new Date());
    const random = Math.random().toString(16).slice(2, 8);
    const workspaceName = `ws-${timestamp}-${random}`;
    const temp = await contents.newUntitled({ path: root, type: 'directory' });
    const workspacePath = coreutils_1.PathExt.join(root, workspaceName);
    try {
        await contents.rename(temp.path, workspacePath);
    }
    catch {
        await waitForDirectory(contents, workspacePath, { retries: 12, delayMs: 150 });
        return workspacePath;
    }
    await waitForDirectory(contents, workspacePath, { retries: 12, delayMs: 150 });
    return workspacePath;
}
exports.createDeepAnalyzeWorkspace = createDeepAnalyzeWorkspace;
async function ensureDirectoryPath(contents, fullPath) {
    await ensureDirectory(contents, fullPath);
}
exports.ensureDirectoryPath = ensureDirectoryPath;
function sanitizeWorkspaceName(raw) {
    const trimmed = String(raw ?? '').trim();
    if (!trimmed) {
        return '';
    }
    const withoutSeparators = trimmed.replace(/[\\/]/g, '-').replace(/\s+/g, ' ');
    const withoutLeadingDots = withoutSeparators.replace(/^\.+/, '');
    const cleaned = withoutLeadingDots.trim();
    if (!cleaned || cleaned === '.' || cleaned === '..') {
        return '';
    }
    return cleaned;
}
exports.sanitizeWorkspaceName = sanitizeWorkspaceName;
async function ensureNamedDeepAnalyzeWorkspace(contents, name) {
    return ensureNamedWorkspace(contents, safeWorkspaceRoot(), name);
}
exports.ensureNamedDeepAnalyzeWorkspace = ensureNamedDeepAnalyzeWorkspace;
async function ensureNamedWorkspace(contents, workspacesRoot, name) {
    const safeName = sanitizeWorkspaceName(name);
    if (!safeName) {
        throw new Error('Invalid workspace name');
    }
    await ensureDirectory(contents, workspacesRoot);
    const target = coreutils_1.PathExt.join(workspacesRoot, safeName);
    if (await pathExists(contents, target)) {
        const model = await contents.get(target, { content: false });
        if (model.type !== 'directory') {
            throw new Error(`Workspace path exists and is not a directory: ${target}`);
        }
        return target;
    }
    await ensureDirectory(contents, target);
    return target;
}
exports.ensureNamedWorkspace = ensureNamedWorkspace;
async function listDeepAnalyzeWorkspaces(contents) {
    return listWorkspaces(contents, safeWorkspaceRoot());
}
exports.listDeepAnalyzeWorkspaces = listDeepAnalyzeWorkspaces;
async function listWorkspaces(contents, workspacesRoot) {
    await ensureDirectory(contents, workspacesRoot);
    try {
        const model = await contents.get(workspacesRoot, { content: true });
        const items = (model.content ?? []);
        return items
            .filter(item => item.type === 'directory')
            .map(item => coreutils_1.PathExt.basename(item.path))
            .sort((a, b) => a.localeCompare(b, 'zh-Hans-CN'));
    }
    catch {
        return [];
    }
}
exports.listWorkspaces = listWorkspaces;


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const launcher_1 = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
const docmanager_1 = __webpack_require__(/*! @jupyterlab/docmanager */ "webpack/sharing/consume/default/@jupyterlab/docmanager");
const filebrowser_1 = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
const open_1 = __webpack_require__(/*! ./deepanalyze/open */ "./lib/deepanalyze/open.js");
const scratchCellRewrite_1 = __webpack_require__(/*! ./deepanalyze/scratchCellRewrite */ "./lib/deepanalyze/scratchCellRewrite.js");
/**
 * deepanalyze 插件入口。
 *
 * 说明：
 * - 在 Launcher 注册 “DeepAnalyze” 按钮，点击后创建/打开工作区与布局。
 * - 在 `app.restored` 后尝试恢复上一次的 DeepAnalyze 会话（基于 localStorage 中记录的 workspace 信息）。
 */
const plugin = {
    id: 'deepanalyze:plugin',
    description: 'DeepAnalyze JupyterLab Extension',
    autoStart: true,
    requires: [launcher_1.ILauncher, docmanager_1.IDocumentManager, filebrowser_1.IDefaultFileBrowser],
    activate: (app, launcher, docManager, defaultBrowser) => {
        const command = 'deepanalyze:open';
        app.commands.addCommand(command, {
            label: 'DeepAnalyze',
            caption: '打开 DeepAnalyze 工作区与布局',
            iconClass: 'deepanalyze-launcher-icon',
            iconLabel: 'DeepAnalyze',
            execute: () => (0, open_1.openDeepAnalyze)(app, docManager, defaultBrowser)
        });
        launcher.add({
            command,
            category: 'Other',
            rank: 50
        });
        // 全局：所有 notebook 单元格右键“使用大模型编辑”
        (0, scratchCellRewrite_1.installScratchCellRewriteUI)(app);
        void app.restored.then(async () => {
            await (0, open_1.restoreDeepAnalyzeIfNeeded)(app, docManager, defaultBrowser);
        });
    }
};
exports["default"] = plugin;


/***/ })

}]);
//# sourceMappingURL=lib_index_js.10b87fbb41f4b2f6fa68.js.map