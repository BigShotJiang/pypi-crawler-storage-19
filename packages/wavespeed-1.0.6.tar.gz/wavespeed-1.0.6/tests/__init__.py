"""WaveSpeed SDK tests package."""
