"""LLMKit - Unified LLM API client. Placeholder package."""
__version__ = "0.0.1"
