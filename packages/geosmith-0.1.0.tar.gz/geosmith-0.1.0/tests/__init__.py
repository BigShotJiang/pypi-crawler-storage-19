"""Tests for GeoSmith."""

