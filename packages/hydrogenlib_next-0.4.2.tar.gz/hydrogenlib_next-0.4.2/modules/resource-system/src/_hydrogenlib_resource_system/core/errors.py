class ResourceNotFound(Exception):
    pass
