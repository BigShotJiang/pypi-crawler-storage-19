from __future__ import annotations

from pathlib import Path

try:
    from defusedxml import ElementTree  # type: ignore[attr-defined]
except ModuleNotFoundError:  # pragma: no cover - dependency missing only in minimal envs
    ElementTree = None  # type: ignore[assignment]
import xml.etree.ElementTree as stdlib_ElementTree

if ElementTree is not None:
    _ElementType = getattr(ElementTree, "Element", stdlib_ElementTree.Element)
else:  # pragma: no cover - defusedxml missing only in constrained envs
    _ElementType = stdlib_ElementTree.Element

from libraries.ontology.bnop.rdf_jena.converters.base_rdf_converter import (
    BaseRdfConverter,
)
from libraries.ontology.bnop.rdf_jena.converters.helpers.conversion_utils import (
    build_uri,
    map_literal,
)
from libraries.ontology.bnop.rdf_jena.object_models.rdf_graphs import (
    RdfGraph,
)
from libraries.ontology.bnop.rdf_jena.object_models.triples import (
    Triple,
)


class XmlToRdfConverter(BaseRdfConverter):
    """Convert XML elements to RDF triples."""

    def __init__(self, namespace: str) -> None:
        super().__init__()
        if not namespace:
            raise ValueError("namespace required")
        self._namespace = namespace
        self._blank_counter = 0

    def convert_file(self, path: str | Path) -> RdfGraph:
        """Convert XML file at *path* to RDF."""
        if ElementTree is None:
            raise RuntimeError(
                "defusedxml is required for secure XML parsing. Install defusedxml to use XmlToRdfConverter.",
            )
        namespaces: dict[str, str] = {}
        iterparse = getattr(ElementTree, "iterparse", stdlib_ElementTree.iterparse)
        parse_fn = getattr(ElementTree, "parse", stdlib_ElementTree.parse)
        for _, elem in iterparse(path, events=("start-ns",)):
            prefix, uri = elem
            namespaces[prefix] = uri
        tree = parse_fn(path)
        root = tree.getroot()
        graph = self.convert([root])
        for prefix, uri in namespaces.items():
            graph.add_namespace(prefix, uri)
        return graph

    def _convert_item(self, item: _ElementType, graph: RdfGraph) -> None:  # type: ignore[override]
        """Add triples for XML *item* to *graph*."""
        subject = self._element_uri(item)
        for attr, value in item.attrib.items():
            if attr == "id":
                continue
            predicate = build_uri(self._namespace, self._local_name(attr))
            obj = map_literal(value)
            graph.add_triple(Triple(subject, predicate, obj))
        text = (item.text or "").strip()
        if text:
            predicate = build_uri(self._namespace, "value")
            obj = map_literal(text)
            graph.add_triple(Triple(subject, predicate, obj))
        for child in list(item):
            child_subject = self._element_uri(child)
            predicate = build_uri(self._namespace, self._local_name(child.tag))
            graph.add_triple(Triple(subject, predicate, child_subject))
            self._convert_item(child, graph)

    def _element_uri(self, element: _ElementType) -> str:
        identifier = element.attrib.get("id")
        if identifier:
            return build_uri(self._namespace, identifier)
        self._blank_counter += 1
        return f"_:b{self._blank_counter}"

    @staticmethod
    def _local_name(tag: str) -> str:
        return tag.split("}")[-1]
