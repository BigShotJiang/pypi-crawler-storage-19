"""Model metadata definitions for BORO boxology."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(slots=True)
class ModelMetadatas:
    """Audit-focused metadata for BORO boxology models.

    The metadata tracks authorship and lifecycle timestamps so that
    services maintaining audit trails can reason about when and by
    whom a model was created or last updated.
    """

    version: str
    created_at: datetime
    updated_at: datetime
    created_by: str
