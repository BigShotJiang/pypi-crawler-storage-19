"""Audit trail entry definitions for BORO boxology."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict

from .objects import ObjectHashes, normalise_object_hash


@dataclass(slots=True)
class AuditEntries:
    """Represents a single audit trail entry."""

    timestamp: datetime
    user: str
    action: str
    object_id: ObjectHashes
    changes: Dict[str, object]

    def __post_init__(self) -> None:
        self.object_id = normalise_object_hash(self.object_id)
