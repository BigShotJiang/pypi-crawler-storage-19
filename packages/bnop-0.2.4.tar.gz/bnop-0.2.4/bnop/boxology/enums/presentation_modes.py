"""Enumerations describing boxology presentation modes."""

from __future__ import annotations

from enum import Enum
from typing import Union

PresentationModeLike = Union["PresentationModes", str]


class PresentationModes(str, Enum):
    """Supported visual presentation modes for boxology objects."""

    BOX = "box"
    EDGE = "edge"
    NESTED = "nested"

    @classmethod
    def normalise(cls, value: PresentationModeLike) -> "PresentationModes":
        """Coerce presentation mode inputs into a canonical enum member."""

        if isinstance(value, cls):
            return value

        try:
            return cls(value)
        except ValueError as error:  # pragma: no cover - defensive formatting only
            allowed = [repr(mode.value) for mode in cls]
            if len(allowed) == 2:
                allowed_display = " or ".join(allowed)
            else:
                allowed_display = ", ".join(allowed)
            msg = (
                "presentation_mode must be either "
                f"{allowed_display}."
            )
            raise ValueError(msg) from error
