"""Enumerations used across the boxology primitives."""

from .presentation_modes import PresentationModeLike, PresentationModes

__all__ = [
    "PresentationModeLike",
    "PresentationModes",
]
