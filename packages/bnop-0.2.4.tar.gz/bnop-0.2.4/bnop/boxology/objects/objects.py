"""Boxology BORO object primitive."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..enums import PresentationModeLike, PresentationModes
from .object_hashes import ObjectHashes, normalise_object_hash
from .stereotypes import Stereotypes, normalise_stereotypes


@dataclass(slots=True)
class Objects:
    """Represents a model element rendered as a box.

    The presentation mode indicates whether the element should
    appear as a standalone canvas box or as a nested attribute
    inside another box. Additional metadata is stored within the
    ``properties`` mapping to support dialect-specific
    configuration.
    """

    id: ObjectHashes
    description: str
    exemplar_name: str
    stereotypes: list[Stereotypes] = field(default_factory=list)
    presentation_mode: PresentationModeLike = PresentationModes.BOX
    properties: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.id = normalise_object_hash(self.id)
        self.stereotypes = normalise_stereotypes(self.stereotypes)
        self.presentation_mode = PresentationModes.normalise(
            self.presentation_mode
        )

    def validate_presentation_mode(self) -> None:
        """Ensure only supported presentation modes are used."""
        PresentationModes.normalise(self.presentation_mode)
