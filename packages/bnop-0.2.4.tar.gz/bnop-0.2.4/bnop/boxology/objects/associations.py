"""Boxology BORO association primitive."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .object_hashes import ObjectHashes, normalise_object_hash
from .places import Places
from .stereotypes import Stereotypes, normalise_stereotypes


@dataclass(slots=True)
class Associations:
    """Represents a binary relationship rendered as a line."""

    id: ObjectHashes
    description: str
    exemplar_name: str
    stereotypes: list[Stereotypes] = field(default_factory=list)
    places: list[Places] = field(default_factory=list)
    properties: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.id = normalise_object_hash(self.id)
        self.stereotypes = normalise_stereotypes(self.stereotypes)

    def validate_binary_places(self) -> None:
        """Ensure exactly two places participate in the association."""

        if len(self.places) != 2:
            msg = (
                "Associations must reference exactly two "
                "Places instances."
            )
            raise ValueError(msg)
