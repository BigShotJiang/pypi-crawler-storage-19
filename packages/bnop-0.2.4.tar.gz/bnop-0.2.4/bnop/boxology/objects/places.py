"""Boxology BORO place primitive."""

from __future__ import annotations

from dataclasses import dataclass, field

from .objects import Objects
from .stereotypes import Stereotypes, normalise_stereotypes


@dataclass(slots=True)
class Places:
    """Captures the placement of an object within an association."""

    placed_object: Objects
    stereotypes: list[Stereotypes] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.stereotypes = normalise_stereotypes(self.stereotypes)
