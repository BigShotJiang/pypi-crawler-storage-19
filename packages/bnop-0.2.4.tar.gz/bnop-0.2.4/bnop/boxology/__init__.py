"""Top-level exports for the BORO-aligned boxology ontology.

This package exposes the canonical dataclasses that model the
"boxes and lines" paradigm used by the universe designer model
builder.  The exports intentionally mirror the conceptual
objects (boxes), their placements, association edges, and the
supporting layout and metadata structures so downstream modules
can construct rich BORO representations without reaching into
module internals.
"""

from .audit_entries import AuditEntries
from .boxology_models import BoxologyModels
from .enums import PresentationModes
from .layouts import Coordinates, Layouts, Sizes
from .model_metadatas import ModelMetadatas
from .objects import (
    Associations,
    ObjectHashLike,
    ObjectHashes,
    Objects,
    Places,
    Stereotypes,
    normalise_object_hash,
)

__all__ = [
    "AuditEntries",
    "BoxologyModels",
    "Layouts",
    "Coordinates",
    "Sizes",
    "ModelMetadatas",
    "Associations",
    "PresentationModes",
    "ObjectHashes",
    "ObjectHashLike",
    "Objects",
    "Places",
    "Stereotypes",
    "normalise_object_hash",
]
