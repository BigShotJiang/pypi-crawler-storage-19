"""Layout metadata for BORO boxology objects."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class Coordinates:
    """Represents a 2D point on the canvas."""

    x: float
    y: float


@dataclass(slots=True)
class Sizes:
    """Represents the dimensions of a layout element."""

    width: float
    height: float


@dataclass(slots=True)
class Layouts:
    """Canvas positioning metadata for an object."""

    coordinates: Coordinates
    sizes: Sizes
    z_index: int = 0
