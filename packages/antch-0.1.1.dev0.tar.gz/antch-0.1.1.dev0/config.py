import pathlib
import os

if os.name == "nt":
    APP_DIR = pathlib.Path(os.getenv("APPDATA", pathlib.Path.home() / "AppData" / "Roaming")) / "antch"
else:
    APP_DIR = pathlib.Path.home() / ".antch"

APP_DIR.mkdir(parents=True, exist_ok=True)
