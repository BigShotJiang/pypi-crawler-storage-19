from __future__ import annotations

from textual.widgets import TextArea as _TextArea

class TextArea(_TextArea):

    try:
        _base = getattr(_TextArea, "COMPONENT_CLASSES", set())
        COMPONENT_CLASSES = set(_base) | {"text-area--gutter"}
    except Exception:
        COMPONENT_CLASSES = {"text-area--gutter"}
