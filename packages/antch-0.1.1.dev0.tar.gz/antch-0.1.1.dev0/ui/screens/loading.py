from textual.screen import Screen
from textual.widgets import Static, LoadingIndicator
from textual.containers import Vertical, Center
from textual.reactive import reactive

class LoadingScreen(Screen):
    status = reactive("Initializing...")

    CSS = """
    LoadingScreen {
        align: center middle;
        background: $surface;
    }
    #loading_container {
        width: 60;
        height: auto;
        border: solid $secondary;
        padding: 2;
        background: $panel;
    }
    #status_label {
        text-align: center;
        margin-top: 1;
        color: $text;
    }
    LoadingIndicator {
        height: 1;
        margin-bottom: 1;
    }
    """

    def compose(self):
        with Center():
            with Vertical(id="loading_container"):
                yield LoadingIndicator()
                yield Static(self.status, id="status_label")

    def watch_status(self, old_val, new_val):
        try:
            self.query_one("#status_label", Static).update(new_val)
        except:
            pass

    def update_status(self, text: str):
        self.status = text
