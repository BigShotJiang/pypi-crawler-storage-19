#!/usr/bin/env python3
"""
Entry point for running Metabase MCP Server as a module.
Usage: python -m metabase_mcp_navi
"""

from .server import main

if __name__ == "__main__":
    main()
