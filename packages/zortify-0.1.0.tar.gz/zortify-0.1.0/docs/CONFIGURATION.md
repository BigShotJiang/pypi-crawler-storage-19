# Configuration Guide

Zortify can be configured using a YAML configuration file. This guide covers all configuration options.

## Configuration File Location

The configuration file is located at:

- **Linux/macOS**: `~/.config/zort/config.yaml`
- **Windows**: `C:\Users\<username>\.config\zort\config.yaml`

## Creating the Configuration File

```bash
# Create default config
zortify config --init

# View current config
zortify config --show

# Edit config
zortify config --edit

# Show config path
zortify config --path
```

## AI Provider Configuration

Zort supports multiple AI providers for smart file classification. AI is optional - the tool works without it using file extensions and patterns.

### Option 1: Ollama (Recommended - Free & Local)

Ollama runs AI models locally on your machine. No API key needed, completely free, and your data stays private.

**Setup:**

1. Install Ollama from [ollama.com](https://ollama.com/download)

2. Pull a model:
   ```bash
   # Recommended - small and fast
   ollama pull phi3

   # Alternative - better quality, needs more RAM
   ollama pull llama3

   # Alternative - good balance
   ollama pull mistral
   ```

3. Configure Zort (this is the default):
   ```yaml
   ai:
     provider: ollama
     ollama:
       host: http://localhost:11434
       model: phi3
   ```

4. Verify it's working:
   ```bash
   zortify ai
   ```

**Troubleshooting:**

- Make sure Ollama is running: `ollama serve`
- Check if model is downloaded: `ollama list`
- Test model directly: `ollama run phi3 "Hello"`

---

### Option 2: Groq (Free Tier - Cloud)

Groq offers a generous free tier with very fast inference.

**Setup:**

1. Create account at [console.groq.com](https://console.groq.com)

2. Go to [API Keys](https://console.groq.com/keys) and create a new key

3. Set the environment variable:

   **Linux/macOS:**
   ```bash
   export GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxx

   # Add to ~/.bashrc or ~/.zshrc to persist
   echo 'export GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxx' >> ~/.bashrc
   ```

   **Windows (PowerShell):**
   ```powershell
   $env:GROQ_API_KEY = "gsk_xxxxxxxxxxxxxxxxxxxx"

   # To persist, add to system environment variables
   [Environment]::SetEnvironmentVariable("GROQ_API_KEY", "gsk_xxxx", "User")
   ```

   **Windows (CMD):**
   ```cmd
   set GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxx

   # To persist
   setx GROQ_API_KEY "gsk_xxxxxxxxxxxxxxxxxxxx"
   ```

4. Update config:
   ```yaml
   ai:
     provider: groq
     groq:
       api_key: ${GROQ_API_KEY}  # Uses environment variable
       model: llama3-70b-8192
   ```

   Or set the key directly (not recommended):
   ```yaml
   ai:
     provider: groq
     groq:
       api_key: gsk_xxxxxxxxxxxxxxxxxxxx
       model: llama3-70b-8192
   ```

5. Verify:
   ```bash
   zortify ai
   ```

**Available Models:**
- `llama3-70b-8192` - Best quality (recommended)
- `llama3-8b-8192` - Faster, less accurate
- `mixtral-8x7b-32768` - Good alternative

---

### Option 3: OpenAI (Paid)

OpenAI provides high-quality models but requires a paid API key.

**Setup:**

1. Create account at [platform.openai.com](https://platform.openai.com)

2. Go to [API Keys](https://platform.openai.com/api-keys) and create a new key

3. Add billing information at [Billing](https://platform.openai.com/account/billing)

4. Set the environment variable:

   **Linux/macOS:**
   ```bash
   export OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxx
   ```

   **Windows:**
   ```powershell
   $env:OPENAI_API_KEY = "sk-xxxxxxxxxxxxxxxxxxxx"
   ```

5. Update config:
   ```yaml
   ai:
     provider: openai
     openai:
       api_key: ${OPENAI_API_KEY}
       model: gpt-3.5-turbo
   ```

6. Verify:
   ```bash
   zortify ai
   ```

**Available Models:**
- `gpt-3.5-turbo` - Fast and cheap (recommended)
- `gpt-4o-mini` - Better quality, still affordable
- `gpt-4o` - Best quality, more expensive

**Cost Estimate:**
- Organizing 100 files ≈ $0.01-0.05 with gpt-3.5-turbo

---

### Option 4: No AI (Rule-based Only)

You can disable AI entirely and use only extension/pattern matching:

```yaml
ai:
  provider: none
```

This still works well for most files using:
- File extension matching (.pdf → Documents)
- Filename pattern matching (*invoice* → Documents/Invoices)
- Custom rules you define

---

## File Categories

Configure how files are categorized:

```yaml
categories:
  documents:
    folder: Documents          # Destination folder name
    extensions:                # File extensions for this category
      - .pdf
      - .doc
      - .docx
      - .txt
    keywords:                  # Keywords in filename trigger this category
      - report
      - invoice
      - resume

  images:
    folder: Images
    extensions:
      - .jpg
      - .jpeg
      - .png
      - .gif
    keywords:
      - photo
      - screenshot

  # Add your own categories...
  work:
    folder: Work
    extensions: []
    keywords:
      - project
      - meeting
      - client
```

---

## Custom Rules

Rules are processed before AI classification. Use them for specific patterns:

```yaml
rules:
  # Move invoices to a subfolder
  - pattern: "*invoice*"
    category: documents
    subfolder: Invoices

  # Move screenshots to a subfolder
  - pattern: "screenshot*"
    category: images
    subfolder: Screenshots

  # Handle camera photos
  - pattern: "IMG_*"
    category: images
    subfolder: Camera

  - pattern: "DSC_*"
    category: images
    subfolder: Camera

  # Skip certain files
  - pattern: "*.partial"
    action: skip

  # Delete temporary files (use with caution!)
  # - pattern: "*.tmp"
  #   action: delete
```

**Pattern Syntax:**
- `*` matches any characters
- `?` matches single character
- Patterns are case-insensitive

---

## Behavior Settings

```yaml
settings:
  # Create date-based subfolders (e.g., Images/2024-01/)
  use_date_folders: false
  date_format: "%Y-%m"

  # Handle duplicate files: rename, skip, or overwrite
  duplicates: rename

  # Only organize files older than N days
  min_age_days: 0

  # Include hidden files (starting with .)
  include_hidden: false

  # Files to always ignore
  ignore:
    - "*.tmp"
    - "*.partial"
    - "*.crdownload"
    - ".DS_Store"
    - "desktop.ini"
    - "Thumbs.db"

  # Enable undo functionality
  enable_history: true
  history_file: ~/.zort_history.json
  max_history: 1000

  # Default category for unclassified files (null = skip)
  default_category: null
```

---

## Full Example Configuration

```yaml
# ~/.config/zort/config.yaml

ai:
  provider: ollama
  confidence_threshold: 0.7

  ollama:
    host: http://localhost:11434
    model: phi3

  groq:
    api_key: ${GROQ_API_KEY}
    model: llama3-70b-8192

  openai:
    api_key: ${OPENAI_API_KEY}
    model: gpt-3.5-turbo

categories:
  documents:
    folder: Documents
    extensions: [.pdf, .doc, .docx, .txt, .xls, .xlsx, .ppt, .pptx]
    keywords: [report, invoice, resume, contract]

  images:
    folder: Images
    extensions: [.jpg, .jpeg, .png, .gif, .webp, .svg]
    keywords: [photo, screenshot, image]

  videos:
    folder: Videos
    extensions: [.mp4, .mkv, .avi, .mov, .webm]
    keywords: [video, movie, clip]

  audio:
    folder: Audio
    extensions: [.mp3, .wav, .flac, .aac, .ogg]
    keywords: [song, music, audio]

  archives:
    folder: Archives
    extensions: [.zip, .rar, .7z, .tar, .gz]
    keywords: [backup, archive]

  code:
    folder: Code
    extensions: [.py, .js, .ts, .java, .cpp, .go, .rs]
    keywords: [script, source]

  installers:
    folder: Installers
    extensions: [.exe, .msi, .dmg, .deb, .rpm]
    keywords: [setup, install]

rules:
  - pattern: "*invoice*"
    category: documents
    subfolder: Invoices

  - pattern: "screenshot*"
    category: images
    subfolder: Screenshots

settings:
  duplicates: rename
  enable_history: true
  ignore:
    - "*.tmp"
    - "*.crdownload"
    - ".DS_Store"
    - "desktop.ini"
```

---

## Environment Variables

| Variable | Description |
|----------|-------------|
| `GROQ_API_KEY` | Groq API key |
| `OPENAI_API_KEY` | OpenAI API key |
| `ANTHROPIC_API_KEY` | Anthropic API key (future) |

---

## Checking Configuration

```bash
# View current configuration
zortify config --show

# Check AI provider status
zortify ai

# Test AI classification
zortify ai --test "invoice_2024.pdf"
```
