# Usage Guide

Complete guide to using Zortify for file organization.

## Basic Usage

### Organize Files

```bash
# Organize current directory
zortify organize .

# Organize specific directory
zortify organize ~/Downloads
zortify organize "C:\Users\John\Downloads"

# Preview without moving (recommended first)
zortify organize ~/Downloads --dry-run

# Skip confirmation prompt
zortify organize ~/Downloads --yes

# Include subdirectories
zortify organize ~/Downloads --recursive

# Verbose output (shows more details)
zortify organize ~/Downloads --verbose
```

### Check Folder Status

See what types of files are in a folder:

```bash
zortify status ~/Downloads
```

Output:
```
┌────────────────────────────── File Statistics ──────────────────────────────┐
│ Analyzing: /home/user/Downloads                                             │
└─────────────────────────────────────────────────────────────────────────────┘
               Files by Category (42 total)
┌───────────┬───────┬─────────────────────────────────────┐
│ Category  │ Count │ Extensions                          │
├───────────┼───────┼─────────────────────────────────────┤
│ documents │    15 │ .pdf, .doc, .docx, .txt             │
│ images    │    12 │ .jpg, .png, .gif                    │
│ archives  │     8 │ .zip, .rar                          │
│ Other     │     7 │ .tmp, .partial                      │
└───────────┴───────┴─────────────────────────────────────┘

Total size: 256.4 MB
Oldest file: 2024-01-15
Newest file: 2024-03-20
```

### Undo Operations

Made a mistake? Undo it:

```bash
# Undo last operation
zortify undo

# Undo last 5 operations
zortify undo --steps 5

# Undo all operations
zortify undo --all

# Skip confirmation
zortify undo --yes
```

### Configuration

```bash
# Create default config file
zortify config --init

# View current configuration
zortify config --show

# Edit configuration
zortify config --edit

# Show config file path
zortify config --path
```

### AI Status

Check AI provider status and test classification:

```bash
# Check which AI providers are available
zortify ai

# Test classification with a filename
zortify ai --test "quarterly_report_2024.pdf"
zortify ai --test "IMG_20240315_143052.jpg"
zortify ai --test "setup_v2.1.0_x64.exe"
```

---

## Command Reference

### `zortify organize`

Organize files in a directory.

```
Usage: zortify organize [OPTIONS] [PATH]

Arguments:
  PATH  Directory to organize [default: .]

Options:
  -n, --dry-run      Preview changes without moving files
  -c, --config PATH  Use custom config file
  -v, --verbose      Show detailed output
  -r, --recursive    Include subdirectories
  -y, --yes          Skip confirmation prompt
  --help             Show help message
```

**Examples:**

```bash
# Basic
zortify organize ~/Downloads

# Safe preview
zortify organize ~/Downloads --dry-run

# Full verbose preview
zortify organize ~/Downloads --dry-run --verbose

# Auto-confirm
zortify organize ~/Downloads --yes

# Custom config
zortify organize ~/Downloads --config ./my-config.yaml

# Recursive with auto-confirm
zortify organize ~/Downloads -r -y
```

### `zortify undo`

Undo previous organization operations.

```
Usage: zortify undo [OPTIONS]

Options:
  -s, --steps INT  Number of operations to undo [default: 1]
  --all            Undo all operations in history
  -y, --yes        Skip confirmation prompt
  --help           Show help message
```

**Examples:**

```bash
zortify undo
zortify undo --steps 3
zortify undo --all
zortify undo --yes
```

### `zortify status`

Show statistics about files in a directory.

```
Usage: zortify status [OPTIONS] [PATH]

Arguments:
  PATH  Directory to analyze [default: .]

Options:
  -r, --recursive  Include subdirectories
  --help           Show help message
```

### `zortify config`

Manage configuration file.

```
Usage: zortify config [OPTIONS]

Options:
  --init   Create default config file
  --show   Display current configuration
  --edit   Open config in default editor
  --path   Show config file path
  --help   Show help message
```

### `zortify ai`

Check AI provider status and test classification.

```
Usage: zortify ai [OPTIONS]

Options:
  --check          Check AI provider availability [default: True]
  -t, --test TEXT  Test classification with a filename
  --help           Show help message
```

### `zortify version`

Show version information.

```bash
zortify version
```

---

## Workflow Examples

### Organizing Downloads Folder

```bash
# Step 1: Check what's in the folder
zortify status ~/Downloads

# Step 2: Preview what will happen
zortify organize ~/Downloads --dry-run

# Step 3: If happy, run it
zortify organize ~/Downloads

# Step 4: If something went wrong
zortify undo
```

### Setting Up AI Classification

```bash
# Check current AI status
zortify ai

# If using Ollama, make sure it's running
ollama serve

# Test AI classification
zortify ai --test "invoice_march_2024.pdf"

# If AI isn't working, the tool still uses extension matching
```

### Organizing with Custom Rules

1. Create config:
   ```bash
   zortify config --init
   ```

2. Edit config:
   ```bash
   zortify config --edit
   ```

3. Add custom rules:
   ```yaml
   rules:
     - pattern: "*client_*"
       category: documents
       subfolder: Clients

     - pattern: "*receipt*"
       category: documents
       subfolder: Receipts
   ```

4. Test:
   ```bash
   zortify organize ~/Downloads --dry-run
   ```

### Batch Processing Multiple Folders

```bash
# Organize multiple folders
for dir in ~/Downloads ~/Desktop ~/Documents/Unsorted; do
    echo "Organizing $dir..."
    zortify organize "$dir" --yes
done
```

### Automated Daily Organization (Linux/macOS)

Add to crontab (`crontab -e`):

```cron
# Organize Downloads every day at 2 AM
0 2 * * * /usr/local/bin/zortify organize ~/Downloads --yes >> ~/zort.log 2>&1
```

### Automated Organization (Windows Task Scheduler)

1. Open Task Scheduler
2. Create Basic Task
3. Set trigger (e.g., Daily at 2 AM)
4. Action: Start a program
5. Program: `zort`
6. Arguments: `organize C:\Users\YourName\Downloads --yes`

---

## Tips and Best Practices

1. **Always use `--dry-run` first** - Preview before moving files

2. **Start with default categories** - Customize later as needed

3. **Use custom rules for repetitive patterns** - If you always get files like `invoice_*.pdf`, create a rule

4. **Keep history enabled** - Makes undo possible

5. **Test AI with `zortify ai --test`** - Make sure classification works as expected

6. **Use verbose mode for debugging** - `zortify organize --dry-run --verbose`

7. **Backup important folders first** - Just in case

---

## Troubleshooting

### "No files to organize"

- Check if files match any category extensions
- Run `zortify status` to see what files are detected
- Check ignore patterns in config

### AI not working

```bash
# Check AI status
zortify ai

# For Ollama, make sure it's running
ollama serve

# Check if model is downloaded
ollama list

# For Groq/OpenAI, check API key
echo $GROQ_API_KEY
echo $OPENAI_API_KEY
```

### Files not being categorized correctly

1. Check your config:
   ```bash
   zortify config --show
   ```

2. Test AI classification:
   ```bash
   zortify ai --test "problematic_file.xyz"
   ```

3. Add a custom rule for specific patterns

### Undo not working

- Make sure `enable_history: true` in config
- Check history file exists: `~/.zort_history.json`
- History is cleared after successful undo

### Permission errors

- Run with appropriate permissions
- Check folder write permissions
- On Windows, try running as Administrator
