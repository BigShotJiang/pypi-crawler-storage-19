"""Tests for organizer module."""

from pathlib import Path

import pytest

from zortify.config import AIConfig, Category, Config, Rule, Settings
from zortify.organizer import OrganizeAction, Organizer, organize_directory


@pytest.fixture
def sample_config() -> Config:
    """Create a sample configuration."""
    return Config(
        ai=AIConfig(),
        categories={
            "documents": Category(
                name="documents",
                folder="Documents",
                extensions=[".pdf", ".doc", ".txt"],
                keywords=[],
            ),
            "images": Category(
                name="images",
                folder="Images",
                extensions=[".jpg", ".png", ".gif"],
                keywords=[],
            ),
            "code": Category(
                name="code",
                folder="Code",
                extensions=[".py", ".js"],
                keywords=[],
            ),
        },
        rules=[
            Rule(pattern="*invoice*", category="documents", subfolder="Invoices"),
        ],
        settings=Settings(
            enable_history=False,
            duplicates="rename",
        ),
    )


class TestOrganizeAction:
    """Tests for OrganizeAction dataclass."""

    def test_destination_display(self):
        """Test destination display string."""
        from datetime import datetime

        from zortify.scanner import FileInfo

        file_info = FileInfo(
            path=Path("/source/test.pdf"),
            name="test.pdf",
            extension=".pdf",
            size=100,
            modified_time=datetime.now(),
            created_time=datetime.now(),
        )

        action = OrganizeAction(
            file=file_info,
            action="move",
            destination=Path("/target/Documents/test.pdf"),
        )

        assert "Documents" in action.destination_display or "test.pdf" in action.destination_display


class TestOrganizer:
    """Tests for Organizer class."""

    def test_plan_empty_directory(self, sample_config, tmp_path: Path):
        """Test planning on empty directory."""
        organizer = Organizer(sample_config)

        actions = organizer.plan(tmp_path)

        assert len(actions) == 0

    def test_plan_with_files(self, sample_config, tmp_path: Path):
        """Test planning with files."""
        # Create test files
        (tmp_path / "document.pdf").write_text("pdf")
        (tmp_path / "image.jpg").write_bytes(b"jpg")
        (tmp_path / "script.py").write_text("python")

        organizer = Organizer(sample_config)
        actions = organizer.plan(tmp_path)

        assert len(actions) == 3

        # Check categories
        categories = {a.category for a in actions}
        assert categories == {"documents", "images", "code"}

    def test_plan_with_rule_match(self, sample_config, tmp_path: Path):
        """Test that rules take precedence."""
        (tmp_path / "invoice_jan_2024.pdf").write_text("invoice")

        organizer = Organizer(sample_config)
        actions = organizer.plan(tmp_path)

        assert len(actions) == 1
        action = actions[0]
        assert action.method == "rule"
        assert "Invoices" in str(action.destination)

    def test_plan_unknown_file(self, sample_config, tmp_path: Path):
        """Test planning for unknown file type."""
        (tmp_path / "unknown.xyz").write_text("unknown")

        organizer = Organizer(sample_config)
        actions = organizer.plan(tmp_path)

        assert len(actions) == 1
        assert actions[0].action == "skip"

    def test_execute_moves_files(self, sample_config, tmp_path: Path):
        """Test that execute actually moves files."""
        # Create source file
        source_file = tmp_path / "test.pdf"
        source_file.write_text("test content")

        organizer = Organizer(sample_config)
        actions = organizer.plan(tmp_path)

        # Execute
        summary = organizer.execute(actions, tmp_path)

        # Check results
        assert summary.moved == 1
        assert summary.errors == 0

        # Check file was moved
        assert not source_file.exists()
        dest_file = tmp_path / "Documents" / "test.pdf"
        assert dest_file.exists()
        assert dest_file.read_text() == "test content"

    def test_execute_creates_directories(self, sample_config, tmp_path: Path):
        """Test that execute creates destination directories."""
        (tmp_path / "test.pdf").write_text("pdf")

        organizer = Organizer(sample_config)
        actions = organizer.plan(tmp_path)
        summary = organizer.execute(actions, tmp_path)

        # Documents folder should be created
        assert (tmp_path / "Documents").is_dir()
        assert summary.moved == 1

    def test_execute_handles_duplicates_rename(self, sample_config, tmp_path: Path):
        """Test duplicate handling with rename strategy."""
        # Create destination with existing file
        docs_dir = tmp_path / "Documents"
        docs_dir.mkdir()
        (docs_dir / "test.pdf").write_text("existing")

        # Create source file
        (tmp_path / "test.pdf").write_text("new")

        organizer = Organizer(sample_config)
        actions = organizer.plan(tmp_path)
        summary = organizer.execute(actions, tmp_path)

        # Should rename to test_1.pdf
        assert summary.moved == 1
        assert (docs_dir / "test.pdf").exists()
        assert (docs_dir / "test_1.pdf").exists()

    def test_organize_dry_run(self, sample_config, tmp_path: Path):
        """Test dry run mode."""
        source_file = tmp_path / "test.pdf"
        source_file.write_text("test")

        organizer = Organizer(sample_config)
        actions, summary = organizer.organize(tmp_path, dry_run=True)

        # File should not be moved
        assert source_file.exists()
        assert summary is None
        assert len(actions) == 1


class TestOrganizeDirectory:
    """Tests for organize_directory convenience function."""

    def test_organize_directory_dry_run(self, tmp_path: Path):
        """Test organize_directory in dry run mode."""
        (tmp_path / "test.pdf").write_text("pdf")

        actions, summary = organize_directory(
            tmp_path,
            dry_run=True,
            enable_history=False,
        )

        assert len(actions) == 1
        assert summary is None
        # File should still exist
        assert (tmp_path / "test.pdf").exists()


class TestDuplicateHandling:
    """Tests for duplicate file handling."""

    def test_skip_strategy(self, tmp_path: Path):
        """Test skip duplicate strategy."""
        config = Config(
            ai=AIConfig(),
            categories={
                "docs": Category(name="docs", folder="Docs", extensions=[".txt"], keywords=[]),
            },
            rules=[],
            settings=Settings(duplicates="skip", enable_history=False),
        )

        # Create existing file at destination
        docs = tmp_path / "Docs"
        docs.mkdir()
        (docs / "test.txt").write_text("existing")

        # Create source
        (tmp_path / "test.txt").write_text("new")

        organizer = Organizer(config)
        actions, summary = organizer.organize(tmp_path)

        # Original file should remain unchanged
        assert (docs / "test.txt").read_text() == "existing"
