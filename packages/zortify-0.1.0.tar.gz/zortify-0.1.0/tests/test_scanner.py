"""Tests for file scanner module."""

from datetime import datetime
from pathlib import Path

import pytest

from zortify.scanner import FileInfo, FileScanner, get_directory_stats, scan_directory


class TestFileInfo:
    """Tests for FileInfo dataclass."""

    def test_age_days(self, tmp_path: Path):
        """Test age calculation."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("test")

        info = FileInfo(
            path=test_file,
            name="test.txt",
            extension=".txt",
            size=4,
            modified_time=datetime.now(),
            created_time=datetime.now(),
        )

        assert info.age_days == 0

    def test_size_human(self):
        """Test human-readable size formatting."""
        info = FileInfo(
            path=Path("test.txt"),
            name="test.txt",
            extension=".txt",
            size=1024,
            modified_time=datetime.now(),
            created_time=datetime.now(),
        )

        assert "KB" in info.size_human

    def test_size_human_bytes(self):
        """Test size formatting for small files."""
        info = FileInfo(
            path=Path("test.txt"),
            name="test.txt",
            extension=".txt",
            size=500,
            modified_time=datetime.now(),
            created_time=datetime.now(),
        )

        assert "B" in info.size_human


class TestFileScanner:
    """Tests for FileScanner class."""

    def test_scan_empty_directory(self, tmp_path: Path):
        """Test scanning an empty directory."""
        scanner = FileScanner()
        files = list(scanner.scan(tmp_path))

        assert len(files) == 0

    def test_scan_with_files(self, tmp_path: Path):
        """Test scanning a directory with files."""
        # Create test files
        (tmp_path / "test1.txt").write_text("content1")
        (tmp_path / "test2.pdf").write_text("content2")
        (tmp_path / "test3.jpg").write_bytes(b"fake image")

        scanner = FileScanner()
        files = list(scanner.scan(tmp_path))

        assert len(files) == 3
        names = {f.name for f in files}
        assert names == {"test1.txt", "test2.pdf", "test3.jpg"}

    def test_scan_ignores_hidden(self, tmp_path: Path):
        """Test that hidden files are ignored by default."""
        (tmp_path / "visible.txt").write_text("visible")
        (tmp_path / ".hidden.txt").write_text("hidden")

        scanner = FileScanner(include_hidden=False)
        files = list(scanner.scan(tmp_path))

        assert len(files) == 1
        assert files[0].name == "visible.txt"

    def test_scan_includes_hidden(self, tmp_path: Path):
        """Test including hidden files."""
        (tmp_path / "visible.txt").write_text("visible")
        (tmp_path / ".hidden.txt").write_text("hidden")

        scanner = FileScanner(include_hidden=True)
        files = list(scanner.scan(tmp_path))

        assert len(files) == 2

    def test_scan_with_ignore_patterns(self, tmp_path: Path):
        """Test ignore patterns."""
        (tmp_path / "keep.txt").write_text("keep")
        (tmp_path / "ignore.tmp").write_text("ignore")
        (tmp_path / "also_ignore.partial").write_text("ignore")

        scanner = FileScanner(ignore_patterns=["*.tmp", "*.partial"])
        files = list(scanner.scan(tmp_path))

        assert len(files) == 1
        assert files[0].name == "keep.txt"

    def test_scan_recursive(self, tmp_path: Path):
        """Test recursive scanning."""
        # Create nested structure
        (tmp_path / "root.txt").write_text("root")
        subdir = tmp_path / "subdir"
        subdir.mkdir()
        (subdir / "nested.txt").write_text("nested")

        scanner = FileScanner()

        # Non-recursive
        files = list(scanner.scan(tmp_path, recursive=False))
        assert len(files) == 1
        assert files[0].name == "root.txt"

        # Recursive
        files = list(scanner.scan(tmp_path, recursive=True))
        assert len(files) == 2

    def test_scan_nonexistent_directory(self):
        """Test scanning a non-existent directory."""
        scanner = FileScanner()

        with pytest.raises(FileNotFoundError):
            list(scanner.scan(Path("/nonexistent/path")))


class TestScanDirectory:
    """Tests for scan_directory convenience function."""

    def test_scan_directory_basic(self, tmp_path: Path):
        """Test basic scan_directory usage."""
        (tmp_path / "file.txt").write_text("content")

        files = scan_directory(tmp_path)

        assert len(files) == 1
        assert files[0].name == "file.txt"


class TestGetDirectoryStats:
    """Tests for get_directory_stats function."""

    def test_empty_directory(self, tmp_path: Path):
        """Test stats for empty directory."""
        stats = get_directory_stats(tmp_path)

        assert stats["total_files"] == 0
        assert stats["total_size"] == 0
        assert stats["extensions"] == {}

    def test_with_files(self, tmp_path: Path):
        """Test stats with files."""
        (tmp_path / "doc1.pdf").write_text("pdf content")
        (tmp_path / "doc2.pdf").write_text("pdf content 2")
        (tmp_path / "image.jpg").write_bytes(b"fake image")

        stats = get_directory_stats(tmp_path)

        assert stats["total_files"] == 3
        assert stats["extensions"][".pdf"] == 2
        assert stats["extensions"][".jpg"] == 1
