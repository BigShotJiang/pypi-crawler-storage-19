"""Tests for classifier module."""

from datetime import datetime
from pathlib import Path

import pytest

from zortify.classifier import ClassificationResult, Classifier, classify_file
from zortify.config import AIConfig, Category, Config, Settings
from zortify.scanner import FileInfo


@pytest.fixture
def sample_config() -> Config:
    """Create a sample configuration for testing."""
    return Config(
        ai=AIConfig(),
        categories={
            "documents": Category(
                name="documents",
                folder="Documents",
                extensions=[".pdf", ".doc", ".docx", ".txt"],
                keywords=["report", "invoice"],
            ),
            "images": Category(
                name="images",
                folder="Images",
                extensions=[".jpg", ".jpeg", ".png", ".gif"],
                keywords=[],
            ),
            "code": Category(
                name="code",
                folder="Code",
                extensions=[".py", ".js", ".ts"],
                keywords=["script", "source"],
            ),
        },
        rules=[],
        settings=Settings(),
    )


@pytest.fixture
def make_file_info():
    """Factory for creating FileInfo objects."""
    def _make(name: str, extension: str = None) -> FileInfo:
        if extension is None:
            extension = Path(name).suffix
        return FileInfo(
            path=Path(f"/fake/{name}"),
            name=name,
            extension=extension,
            size=100,
            modified_time=datetime.now(),
            created_time=datetime.now(),
        )
    return _make


class TestClassificationResult:
    """Tests for ClassificationResult dataclass."""

    def test_target_folder_without_subfolder(self):
        """Test target folder without subfolder."""
        result = ClassificationResult(
            category="documents",
            folder="Documents",
        )
        assert result.target_folder == "Documents"

    def test_target_folder_with_subfolder(self):
        """Test target folder with subfolder."""
        result = ClassificationResult(
            category="documents",
            folder="Documents",
            subfolder="Invoices",
        )
        assert result.target_folder == "Documents/Invoices"


class TestClassifier:
    """Tests for Classifier class."""

    def test_classify_by_extension_pdf(self, sample_config, make_file_info):
        """Test classification of PDF files."""
        classifier = Classifier(sample_config)
        file_info = make_file_info("report.pdf")

        result = classifier.classify(file_info)

        assert result is not None
        assert result.category == "documents"
        assert result.folder == "Documents"
        assert result.method == "extension"
        assert result.confidence == 1.0

    def test_classify_by_extension_image(self, sample_config, make_file_info):
        """Test classification of image files."""
        classifier = Classifier(sample_config)
        file_info = make_file_info("photo.jpg")

        result = classifier.classify(file_info)

        assert result is not None
        assert result.category == "images"
        assert result.folder == "Images"

    def test_classify_by_extension_code(self, sample_config, make_file_info):
        """Test classification of code files."""
        classifier = Classifier(sample_config)
        file_info = make_file_info("script.py")

        result = classifier.classify(file_info)

        assert result is not None
        assert result.category == "code"
        assert result.folder == "Code"

    def test_classify_by_keyword(self, sample_config, make_file_info):
        """Test classification by keyword in filename."""
        classifier = Classifier(sample_config)
        # Unknown extension but has keyword
        file_info = make_file_info("monthly_invoice.xyz", ".xyz")

        result = classifier.classify(file_info)

        assert result is not None
        assert result.category == "documents"
        assert result.method == "keyword"
        assert result.confidence == 0.8

    def test_classify_unknown_extension(self, sample_config, make_file_info):
        """Test classification of unknown file type."""
        classifier = Classifier(sample_config)
        file_info = make_file_info("unknown.xyz", ".xyz")

        result = classifier.classify(file_info)

        # No default category set, should return None
        assert result is None

    def test_classify_with_default_category(self, make_file_info):
        """Test classification with default category."""
        config = Config(
            ai=AIConfig(),
            categories={
                "misc": Category(name="misc", folder="Misc", extensions=[], keywords=[]),
            },
            rules=[],
            settings=Settings(default_category="misc"),
        )
        classifier = Classifier(config)
        file_info = make_file_info("unknown.xyz", ".xyz")

        result = classifier.classify(file_info)

        assert result is not None
        assert result.category == "misc"
        assert result.method == "default"
        assert result.confidence == 0.5

    def test_classify_case_insensitive_extension(self, sample_config, make_file_info):
        """Test that extension matching is case-insensitive."""
        classifier = Classifier(sample_config)
        file_info = make_file_info("DOCUMENT.PDF", ".PDF")

        result = classifier.classify(file_info)

        assert result is not None
        assert result.category == "documents"

    def test_list_categories(self, sample_config):
        """Test listing available categories."""
        classifier = Classifier(sample_config)

        categories = classifier.list_categories()

        assert set(categories) == {"documents", "images", "code"}

    def test_get_category(self, sample_config):
        """Test getting a specific category."""
        classifier = Classifier(sample_config)

        category = classifier.get_category("documents")

        assert category is not None
        assert category.name == "documents"
        assert ".pdf" in category.extensions


class TestClassifyFile:
    """Tests for classify_file convenience function."""

    def test_classify_file_basic(self, sample_config, make_file_info):
        """Test basic classify_file usage."""
        file_info = make_file_info("test.pdf")

        result = classify_file(file_info, sample_config)

        assert result is not None
        assert result.category == "documents"
