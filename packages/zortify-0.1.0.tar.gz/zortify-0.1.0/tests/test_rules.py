"""Tests for rules engine module."""

from datetime import datetime
from pathlib import Path

import pytest

from zortify.config import AIConfig, Category, Config, Rule, Settings
from zortify.rules import Action, RuleMatch, RulesEngine, apply_rules, create_rule
from zortify.scanner import FileInfo


@pytest.fixture
def sample_config() -> Config:
    """Create a sample configuration with rules."""
    return Config(
        ai=AIConfig(),
        categories={
            "documents": Category(
                name="documents",
                folder="Documents",
                extensions=[".pdf"],
                keywords=[],
            ),
            "images": Category(
                name="images",
                folder="Images",
                extensions=[".jpg", ".png"],
                keywords=[],
            ),
        },
        rules=[
            Rule(pattern="*invoice*", category="documents", subfolder="Invoices"),
            Rule(pattern="screenshot*", category="images", subfolder="Screenshots"),
            Rule(pattern="*.tmp", action="delete"),
            Rule(pattern="*.bak", action="skip"),
        ],
        settings=Settings(),
    )


@pytest.fixture
def make_file_info():
    """Factory for creating FileInfo objects."""
    def _make(name: str) -> FileInfo:
        return FileInfo(
            path=Path(f"/fake/{name}"),
            name=name,
            extension=Path(name).suffix,
            size=100,
            modified_time=datetime.now(),
            created_time=datetime.now(),
        )
    return _make


class TestAction:
    """Tests for Action enum."""

    def test_action_values(self):
        """Test action enum values."""
        assert Action.MOVE.value == "move"
        assert Action.DELETE.value == "delete"
        assert Action.SKIP.value == "skip"


class TestRuleMatch:
    """Tests for RuleMatch dataclass."""

    def test_target_folder_with_subfolder(self):
        """Test target folder calculation."""
        rule = Rule(pattern="*", category="docs", subfolder="Sub")
        match = RuleMatch(
            rule=rule,
            action=Action.MOVE,
            category="docs",
            folder="Documents",
            subfolder="Sub",
        )

        assert match.target_folder == "Documents/Sub"

    def test_target_folder_without_subfolder(self):
        """Test target folder without subfolder."""
        rule = Rule(pattern="*", category="docs")
        match = RuleMatch(
            rule=rule,
            action=Action.MOVE,
            category="docs",
            folder="Documents",
        )

        assert match.target_folder == "Documents"

    def test_target_folder_none(self):
        """Test target folder when no folder set."""
        rule = Rule(pattern="*", action="delete")
        match = RuleMatch(
            rule=rule,
            action=Action.DELETE,
        )

        assert match.target_folder is None


class TestRulesEngine:
    """Tests for RulesEngine class."""

    def test_match_invoice_pattern(self, sample_config, make_file_info):
        """Test matching invoice pattern."""
        engine = RulesEngine(sample_config)
        file_info = make_file_info("monthly_invoice_2024.pdf")

        match = engine.match(file_info)

        assert match is not None
        assert match.action == Action.MOVE
        assert match.category == "documents"
        assert match.subfolder == "Invoices"

    def test_match_screenshot_pattern(self, sample_config, make_file_info):
        """Test matching screenshot pattern."""
        engine = RulesEngine(sample_config)
        file_info = make_file_info("screenshot_2024-01-15.png")

        match = engine.match(file_info)

        assert match is not None
        assert match.action == Action.MOVE
        assert match.category == "images"
        assert match.subfolder == "Screenshots"

    def test_match_delete_pattern(self, sample_config, make_file_info):
        """Test matching delete pattern."""
        engine = RulesEngine(sample_config)
        file_info = make_file_info("tempfile.tmp")

        match = engine.match(file_info)

        assert match is not None
        assert match.action == Action.DELETE

    def test_match_skip_pattern(self, sample_config, make_file_info):
        """Test matching skip pattern."""
        engine = RulesEngine(sample_config)
        file_info = make_file_info("backup.bak")

        match = engine.match(file_info)

        assert match is not None
        assert match.action == Action.SKIP

    def test_no_match(self, sample_config, make_file_info):
        """Test when no rule matches."""
        engine = RulesEngine(sample_config)
        file_info = make_file_info("random_file.txt")

        match = engine.match(file_info)

        assert match is None

    def test_case_insensitive_matching(self, sample_config, make_file_info):
        """Test that pattern matching is case-insensitive."""
        engine = RulesEngine(sample_config)
        file_info = make_file_info("INVOICE_2024.PDF")

        match = engine.match(file_info)

        assert match is not None
        assert match.category == "documents"

    def test_get_all_matches(self, make_file_info):
        """Test getting all matching rules."""
        config = Config(
            ai=AIConfig(),
            categories={
                "docs": Category(name="docs", folder="Docs", extensions=[], keywords=[]),
            },
            rules=[
                Rule(pattern="*report*", category="docs"),
                Rule(pattern="*2024*", category="docs"),
            ],
            settings=Settings(),
        )
        engine = RulesEngine(config)
        file_info = make_file_info("annual_report_2024.pdf")

        matches = engine.get_all_matches(file_info)

        # Both rules should match
        assert len(matches) == 2


class TestApplyRules:
    """Tests for apply_rules function."""

    def test_apply_rules_separates_matched_and_unmatched(self, sample_config, make_file_info):
        """Test that apply_rules separates files correctly."""
        files = [
            make_file_info("invoice_jan.pdf"),
            make_file_info("random.txt"),
            make_file_info("screenshot_001.png"),
        ]

        matched, unmatched = apply_rules(files, sample_config)

        assert len(matched) == 2  # invoice and screenshot
        assert len(unmatched) == 1  # random.txt

    def test_apply_rules_empty_list(self, sample_config):
        """Test with empty file list."""
        matched, unmatched = apply_rules([], sample_config)

        assert matched == []
        assert unmatched == []


class TestCreateRule:
    """Tests for create_rule function."""

    def test_create_basic_rule(self):
        """Test creating a basic rule."""
        rule = create_rule("*.pdf", category="documents")

        assert rule.pattern == "*.pdf"
        assert rule.category == "documents"
        assert rule.action == "move"

    def test_create_rule_with_subfolder(self):
        """Test creating a rule with subfolder."""
        rule = create_rule("*invoice*", category="documents", subfolder="Invoices")

        assert rule.subfolder == "Invoices"

    def test_create_delete_rule(self):
        """Test creating a delete rule."""
        rule = create_rule("*.tmp", action="delete")

        assert rule.action == "delete"
