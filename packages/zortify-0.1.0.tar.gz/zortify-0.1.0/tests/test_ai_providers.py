"""Tests for AI providers."""

import pytest

from zortify.ai.base import ClassificationResult
from zortify.ai.factory import (
    create_provider,
    create_provider_with_fallback,
    get_available_providers,
)
from zortify.ai.fallback import FallbackProvider
from zortify.config import AIConfig


class TestClassificationResult:
    """Tests for ClassificationResult dataclass."""

    def test_create_result(self):
        """Test creating a classification result."""
        result = ClassificationResult(
            category="documents",
            confidence=0.95,
            reasoning="Test reasoning",
        )

        assert result.category == "documents"
        assert result.confidence == 0.95
        assert result.reasoning == "Test reasoning"

    def test_confidence_clamping_high(self):
        """Test that confidence is clamped to 1.0."""
        result = ClassificationResult(
            category="test",
            confidence=1.5,
            reasoning="",
        )

        assert result.confidence == 1.0

    def test_confidence_clamping_low(self):
        """Test that confidence is clamped to 0.0."""
        result = ClassificationResult(
            category="test",
            confidence=-0.5,
            reasoning="",
        )

        assert result.confidence == 0.0


class TestFallbackProvider:
    """Tests for FallbackProvider."""

    @pytest.fixture
    def provider(self):
        """Create a fallback provider."""
        return FallbackProvider()

    def test_name(self, provider):
        """Test provider name."""
        assert provider.name == "fallback"

    def test_is_available(self, provider):
        """Test that fallback is always available."""
        assert provider.is_available() is True

    def test_classify_by_extension_pdf(self, provider):
        """Test classification of PDF by extension."""
        result = provider.classify(
            filename="document.pdf",
            extension=".pdf",
        )

        assert result.category == "documents"
        assert result.confidence >= 0.5

    def test_classify_by_extension_jpg(self, provider):
        """Test classification of JPG by extension."""
        result = provider.classify(
            filename="photo.jpg",
            extension=".jpg",
        )

        assert result.category == "images"
        assert result.confidence >= 0.5

    def test_classify_by_extension_py(self, provider):
        """Test classification of Python file by extension."""
        result = provider.classify(
            filename="script.py",
            extension=".py",
        )

        assert result.category == "code"

    def test_classify_by_keyword_invoice(self, provider):
        """Test classification by keyword."""
        result = provider.classify(
            filename="monthly_invoice.xyz",
            extension=".xyz",
        )

        assert result.category == "documents"
        assert "invoice" in result.reasoning.lower()

    def test_classify_by_keyword_screenshot(self, provider):
        """Test classification of screenshot by keyword."""
        result = provider.classify(
            filename="screenshot_2024.xyz",
            extension=".xyz",
        )

        assert result.category == "images"

    def test_classify_by_pattern_img_prefix(self, provider):
        """Test classification by IMG_ pattern."""
        result = provider.classify(
            filename="IMG_20240115.xyz",
            extension=".xyz",
        )

        assert result.category == "images"

    def test_classify_unknown(self, provider):
        """Test classification of unknown file."""
        result = provider.classify(
            filename="random_file.xyz",
            extension=".xyz",
        )

        # Should still return a result, but with low confidence
        assert result is not None
        assert result.confidence < 0.5

    def test_classify_with_categories(self, provider):
        """Test classification with limited categories."""
        result = provider.classify(
            filename="document.pdf",
            extension=".pdf",
            categories=["documents", "other"],
        )

        assert result.category in ["documents", "other"]

    def test_classify_installer(self, provider):
        """Test classification of installer."""
        result = provider.classify(
            filename="setup_v2.3.1_x64.exe",
            extension=".exe",
        )

        assert result.category == "installers"


class TestAIProviderFactory:
    """Tests for AI provider factory functions."""

    @pytest.fixture
    def default_config(self):
        """Create default AI config."""
        return AIConfig()

    def test_create_provider_ollama(self, default_config):
        """Test creating Ollama provider."""
        default_config.provider = "ollama"
        provider = create_provider(default_config)

        assert provider is not None
        assert "ollama" in provider.name

    def test_create_provider_groq(self, default_config):
        """Test creating Groq provider."""
        default_config.provider = "groq"
        provider = create_provider(default_config)

        assert provider is not None
        assert "groq" in provider.name

    def test_create_provider_openai(self, default_config):
        """Test creating OpenAI provider."""
        default_config.provider = "openai"
        provider = create_provider(default_config)

        assert provider is not None
        assert "openai" in provider.name

    def test_create_provider_none(self, default_config):
        """Test creating fallback provider when 'none' is specified."""
        default_config.provider = "none"
        provider = create_provider(default_config)

        assert provider is not None
        assert isinstance(provider, FallbackProvider)

    def test_create_provider_fallback(self, default_config):
        """Test creating fallback provider."""
        default_config.provider = "fallback"
        provider = create_provider(default_config)

        assert isinstance(provider, FallbackProvider)

    def test_create_provider_unknown(self, default_config):
        """Test that unknown provider returns fallback."""
        default_config.provider = "unknown_provider"
        provider = create_provider(default_config)

        assert isinstance(provider, FallbackProvider)

    def test_create_provider_with_fallback_returns_available(self, default_config):
        """Test that create_provider_with_fallback returns an available provider."""
        default_config.provider = "none"
        provider = create_provider_with_fallback(default_config)

        assert provider.is_available()

    def test_get_available_providers(self, default_config):
        """Test listing available providers."""
        providers = get_available_providers(default_config)

        # Should return a list of tuples
        assert isinstance(providers, list)
        assert len(providers) > 0

        # Each item should be (name, bool)
        for name, available in providers:
            assert isinstance(name, str)
            assert isinstance(available, bool)

        # Fallback should always be available
        fallback = next((p for p in providers if p[0] == "fallback"), None)
        assert fallback is not None
        assert fallback[1] is True


class TestOllamaProvider:
    """Tests for Ollama provider (mocked)."""

    def test_provider_name(self):
        """Test Ollama provider name."""
        from zortify.ai.ollama import OllamaProvider

        provider = OllamaProvider(model="phi3")
        assert provider.name == "ollama:phi3"

    def test_unavailable_when_no_server(self):
        """Test that provider reports unavailable when Ollama not running."""
        from zortify.ai.ollama import OllamaProvider

        # Use a port that's unlikely to have Ollama running
        provider = OllamaProvider(host="http://localhost:99999")
        assert provider.is_available() is False


class TestGroqProvider:
    """Tests for Groq provider."""

    def test_provider_name(self):
        """Test Groq provider name."""
        from zortify.ai.groq import GroqProvider

        provider = GroqProvider(model="llama3-70b-8192")
        assert provider.name == "groq:llama3-70b-8192"

    def test_unavailable_without_api_key(self):
        """Test that provider reports unavailable without API key."""
        from zortify.ai.groq import GroqProvider

        provider = GroqProvider(api_key=None)
        assert provider.is_available() is False

    def test_available_with_api_key(self):
        """Test that provider reports available with API key."""
        from zortify.ai.groq import GroqProvider

        provider = GroqProvider(api_key="test_key")
        assert provider.is_available() is True


class TestOpenAIProvider:
    """Tests for OpenAI provider."""

    def test_provider_name(self):
        """Test OpenAI provider name."""
        from zortify.ai.openai import OpenAIProvider

        provider = OpenAIProvider(model="gpt-3.5-turbo")
        assert provider.name == "openai:gpt-3.5-turbo"

    def test_unavailable_without_api_key(self):
        """Test that provider reports unavailable without API key."""
        from zortify.ai.openai import OpenAIProvider

        provider = OpenAIProvider(api_key=None)
        assert provider.is_available() is False

    def test_available_with_api_key(self):
        """Test that provider reports available with API key."""
        from zortify.ai.openai import OpenAIProvider

        provider = OpenAIProvider(api_key="test_key")
        assert provider.is_available() is True
