## Description
Brief description of the changes.

## Type of Change
- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update

## Changes Made
- Change 1
- Change 2

## Testing
- [ ] I have added tests that prove my fix/feature works
- [ ] All new and existing tests pass
- [ ] I have tested manually with real files

## Checklist
- [ ] My code follows the project's code style
- [ ] I have updated documentation as needed
- [ ] I have added appropriate comments to my code
- [ ] My changes generate no new warnings

## Related Issues
Fixes #(issue number)
