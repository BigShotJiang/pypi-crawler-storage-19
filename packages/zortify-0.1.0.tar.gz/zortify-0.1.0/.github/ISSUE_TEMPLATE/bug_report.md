---
name: Bug Report
about: Report a bug or unexpected behavior
title: '[BUG] '
labels: bug
assignees: ''
---

## Description
A clear description of the bug.

## Steps to Reproduce
1. Run command '...'
2. With files like '...'
3. See error

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Environment
- OS: [e.g., Windows 11, Ubuntu 22.04, macOS 14]
- Python version: [e.g., 3.11.5]
- SFO version: [e.g., 0.1.0]
- AI provider: [e.g., ollama, groq, none]

## Error Output
```
Paste any error messages here
```

## Additional Context
Any other relevant information.
