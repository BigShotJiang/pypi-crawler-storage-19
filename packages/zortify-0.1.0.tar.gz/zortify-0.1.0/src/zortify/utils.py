"""Utility functions for Smart File Organizer."""

import sys
from collections.abc import Callable
from functools import wraps
from typing import Any, TypeVar

from rich.console import Console

console = Console(stderr=True)

T = TypeVar("T")


class SFOError(Exception):
    """Base exception for Smart File Organizer."""

    def __init__(self, message: str, hint: str = ""):
        self.message = message
        self.hint = hint
        super().__init__(message)


class ConfigError(SFOError):
    """Configuration-related error."""
    pass


class AIProviderError(SFOError):
    """AI provider-related error."""
    pass


class FileOperationError(SFOError):
    """File operation error."""
    pass


def handle_errors(func: Callable[..., T]) -> Callable[..., T]:
    """Decorator to handle errors gracefully in CLI commands."""

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> T:
        try:
            return func(*args, **kwargs)
        except SFOError as e:
            console.print(f"[red]Error:[/red] {e.message}")
            if e.hint:
                console.print(f"[dim]Hint: {e.hint}[/dim]")
            sys.exit(1)
        except KeyboardInterrupt:
            console.print("\n[yellow]Operation cancelled.[/yellow]")
            sys.exit(130)
        except Exception as e:
            console.print(f"[red]Unexpected error:[/red] {e}")
            console.print("[dim]Please report this issue at https://github.com/zeerakzubair/zort/issues[/dim]")
            sys.exit(1)

    return wrapper


def format_size(size_bytes: int) -> str:
    """Format file size in human-readable format."""
    size: float = size_bytes
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def format_count(count: int, singular: str, plural: str = "") -> str:
    """Format count with proper singular/plural form."""
    if not plural:
        plural = singular + "s"
    return f"{count} {singular if count == 1 else plural}"


def truncate(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """Truncate text to a maximum length."""
    if len(text) <= max_length:
        return text
    return text[: max_length - len(suffix)] + suffix
