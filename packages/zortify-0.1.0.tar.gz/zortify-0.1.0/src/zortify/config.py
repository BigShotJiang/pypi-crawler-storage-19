"""Configuration management for Zort."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class AIConfig:
    """AI provider configuration."""

    provider: str = "ollama"
    confidence_threshold: float = 0.7

    # Ollama settings
    ollama_host: str = "http://localhost:11434"
    ollama_model: str = "phi3"

    # Groq settings
    groq_api_key: str | None = None
    groq_model: str = "llama3-70b-8192"

    # OpenAI settings
    openai_api_key: str | None = None
    openai_model: str = "gpt-3.5-turbo"


@dataclass
class Category:
    """File category definition."""

    name: str
    folder: str
    extensions: list[str] = field(default_factory=list)
    keywords: list[str] = field(default_factory=list)


@dataclass
class Rule:
    """Custom organization rule."""

    pattern: str
    category: str | None = None
    subfolder: str | None = None
    action: str = "move"  # move, delete, skip


@dataclass
class Settings:
    """Behavior settings."""

    use_date_folders: bool = False
    date_format: str = "%Y-%m"
    duplicates: str = "rename"  # rename, skip, overwrite
    min_age_days: int = 0
    include_hidden: bool = False
    ignore: list[str] = field(default_factory=list)
    enable_history: bool = True
    history_file: str = "~/.zort_history.json"
    max_history: int = 1000
    default_category: str | None = None


@dataclass
class Config:
    """Main configuration class."""

    ai: AIConfig = field(default_factory=AIConfig)
    categories: dict[str, Category] = field(default_factory=dict)
    rules: list[Rule] = field(default_factory=list)
    settings: Settings = field(default_factory=Settings)

    @property
    def history_path(self) -> Path:
        """Get resolved history file path."""
        return Path(self.settings.history_file).expanduser()


# Default categories
DEFAULT_CATEGORIES: dict[str, dict[str, Any]] = {
    "documents": {
        "folder": "Documents",
        "extensions": [
            ".pdf", ".doc", ".docx", ".txt", ".odt", ".rtf",
            ".xls", ".xlsx", ".ppt", ".pptx",
        ],
        "keywords": ["report", "invoice", "resume", "letter", "contract"],
    },
    "images": {
        "folder": "Images",
        "extensions": [".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".bmp", ".ico", ".tiff"],
        "keywords": [],
    },
    "videos": {
        "folder": "Videos",
        "extensions": [".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv", ".flv"],
        "keywords": [],
    },
    "audio": {
        "folder": "Audio",
        "extensions": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"],
        "keywords": [],
    },
    "archives": {
        "folder": "Archives",
        "extensions": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2"],
        "keywords": [],
    },
    "code": {
        "folder": "Code",
        "extensions": [
            ".py", ".js", ".ts", ".jsx", ".tsx", ".java",
            ".cpp", ".c", ".h", ".cs", ".go", ".rs", ".rb", ".php",
        ],
        "keywords": [],
    },
    "installers": {
        "folder": "Installers",
        "extensions": [".exe", ".msi", ".dmg", ".deb", ".rpm", ".appimage"],
        "keywords": [],
    },
    "data": {
        "folder": "Data",
        "extensions": [".csv", ".json", ".xml", ".yaml", ".yml", ".sql", ".db", ".sqlite"],
        "keywords": [],
    },
    "ebooks": {
        "folder": "Ebooks",
        "extensions": [".epub", ".mobi", ".azw", ".azw3"],
        "keywords": [],
    },
    "fonts": {
        "folder": "Fonts",
        "extensions": [".ttf", ".otf", ".woff", ".woff2"],
        "keywords": [],
    },
}

DEFAULT_IGNORE = [
    "*.tmp",
    "*.partial",
    "*.crdownload",
    ".DS_Store",
    "desktop.ini",
    "Thumbs.db",
]


def _expand_env_vars(value: Any) -> Any:
    """Expand environment variables in string values."""
    if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
        env_var = value[2:-1]
        return os.environ.get(env_var)
    return value


def _parse_ai_config(data: dict[str, Any]) -> AIConfig:
    """Parse AI configuration from dict."""
    ai_data = data.get("ai", {})

    config = AIConfig(
        provider=ai_data.get("provider", "ollama"),
        confidence_threshold=ai_data.get("confidence_threshold", 0.7),
    )

    # Ollama settings
    ollama = ai_data.get("ollama", {})
    config.ollama_host = ollama.get("host", config.ollama_host)
    config.ollama_model = ollama.get("model", config.ollama_model)

    # Groq settings
    groq = ai_data.get("groq", {})
    config.groq_api_key = _expand_env_vars(groq.get("api_key"))
    config.groq_model = groq.get("model", config.groq_model)

    # OpenAI settings
    openai = ai_data.get("openai", {})
    config.openai_api_key = _expand_env_vars(openai.get("api_key"))
    config.openai_model = openai.get("model", config.openai_model)

    return config


def _parse_categories(data: dict[str, Any]) -> dict[str, Category]:
    """Parse categories from dict."""
    categories_data = data.get("categories", {})
    categories = {}

    for name, cat_data in categories_data.items():
        categories[name] = Category(
            name=name,
            folder=cat_data.get("folder", name.capitalize()),
            extensions=cat_data.get("extensions", []),
            keywords=cat_data.get("keywords", []),
        )

    return categories


def _parse_rules(data: dict[str, Any]) -> list[Rule]:
    """Parse rules from dict."""
    rules_data = data.get("rules", [])
    rules = []

    for rule_data in rules_data:
        rules.append(Rule(
            pattern=rule_data.get("pattern", "*"),
            category=rule_data.get("category"),
            subfolder=rule_data.get("subfolder"),
            action=rule_data.get("action", "move"),
        ))

    return rules


def _parse_settings(data: dict[str, Any]) -> Settings:
    """Parse settings from dict."""
    settings_data = data.get("settings", {})

    return Settings(
        use_date_folders=settings_data.get("use_date_folders", False),
        date_format=settings_data.get("date_format", "%Y-%m"),
        duplicates=settings_data.get("duplicates", "rename"),
        min_age_days=settings_data.get("min_age_days", 0),
        include_hidden=settings_data.get("include_hidden", False),
        ignore=settings_data.get("ignore", DEFAULT_IGNORE.copy()),
        enable_history=settings_data.get("enable_history", True),
        history_file=settings_data.get("history_file", "~/.zort_history.json"),
        max_history=settings_data.get("max_history", 1000),
        default_category=settings_data.get("default_category"),
    )


def load_config(config_path: Path | None = None) -> Config:
    """
    Load configuration from file.

    Args:
        config_path: Path to config file. If None, searches default locations.

    Returns:
        Config object with loaded or default settings.
    """
    # Search paths for config
    search_paths = [
        config_path,
        Path("config.yaml"),
        Path("config.yml"),
        Path.home() / ".config" / "sfo" / "config.yaml",
        Path.home() / ".sfo.yaml",
    ]

    config_file = None
    for path in search_paths:
        if path and path.exists():
            config_file = path
            break

    if config_file is None:
        # Return default config
        return get_default_config()

    # Load and parse config file
    with open(config_file, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    return Config(
        ai=_parse_ai_config(data),
        categories=_parse_categories(data) or get_default_categories(),
        rules=_parse_rules(data),
        settings=_parse_settings(data),
    )


def get_default_config() -> Config:
    """Get default configuration."""
    return Config(
        ai=AIConfig(),
        categories=get_default_categories(),
        rules=[],
        settings=Settings(ignore=DEFAULT_IGNORE.copy()),
    )


def get_default_categories() -> dict[str, Category]:
    """Get default category definitions."""
    categories = {}
    for name, data in DEFAULT_CATEGORIES.items():
        categories[name] = Category(
            name=name,
            folder=data["folder"],
            extensions=data["extensions"],
            keywords=data["keywords"],
        )
    return categories


def get_config_path() -> Path:
    """Get the default config file path."""
    return Path.home() / ".config" / "sfo" / "config.yaml"


def init_config(target_path: Path | None = None) -> Path:
    """
    Initialize a new config file from the example.

    Args:
        target_path: Where to create the config. Defaults to ~/.config/zort/config.yaml

    Returns:
        Path to the created config file.
    """
    if target_path is None:
        target_path = get_config_path()

    # Create parent directories
    target_path.parent.mkdir(parents=True, exist_ok=True)

    # Find example config
    example_path = Path(__file__).parent.parent.parent / "config.example.yaml"

    if example_path.exists():
        content = example_path.read_text(encoding="utf-8")
    else:
        # Generate minimal config
        content = _generate_minimal_config()

    target_path.write_text(content, encoding="utf-8")
    return target_path


def _generate_minimal_config() -> str:
    """Generate a minimal config file content."""
    return """# Zort Configuration

ai:
  provider: ollama  # ollama (free), groq (free tier), openai, none
  ollama:
    host: http://localhost:11434
    model: phi3

settings:
  duplicates: rename
  enable_history: true
  ignore:
    - "*.tmp"
    - "*.partial"
    - ".DS_Store"
    - "desktop.ini"
"""
