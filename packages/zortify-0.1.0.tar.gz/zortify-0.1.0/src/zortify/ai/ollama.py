"""Ollama AI provider for local inference."""

import json
import re

import httpx

from zortify.ai.base import AIProvider, ClassificationResult


class OllamaProvider(AIProvider):
    """
    AI provider using Ollama for local LLM inference.

    Ollama runs locally and is completely free. It supports various models
    like llama3, phi3, mistral, etc.

    Install: https://ollama.com/download
    Usage: ollama pull phi3
    """

    def __init__(
        self,
        host: str = "http://localhost:11434",
        model: str = "phi3",
        timeout: float = 30.0,
    ):
        """
        Initialize Ollama provider.

        Args:
            host: Ollama API host URL
            model: Model to use (phi3, llama3, mistral, etc.)
            timeout: Request timeout in seconds
        """
        self.host = host.rstrip("/")
        self.model = model
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    @property
    def name(self) -> str:
        return f"ollama:{self.model}"

    def is_available(self) -> bool:
        """Check if Ollama is running and model is available."""
        try:
            response = self._client.get(f"{self.host}/api/tags")
            if response.status_code != 200:
                return False

            data = response.json()
            models = [m.get("name", "").split(":")[0] for m in data.get("models", [])]
            full_names = [m.get("name", "") for m in data.get("models", [])]
            return self.model in models or f"{self.model}:latest" in full_names
        except (httpx.RequestError, json.JSONDecodeError):
            return False

    def classify(
        self,
        filename: str,
        extension: str,
        content_preview: str | None = None,
        categories: list[str] | None = None,
    ) -> ClassificationResult:
        """
        Classify a file using Ollama.

        Args:
            filename: Name of the file
            extension: File extension
            content_preview: Optional preview of file contents
            categories: List of available categories

        Returns:
            ClassificationResult with category, confidence, and reasoning
        """
        if categories is None:
            categories = [
                "documents", "images", "videos", "audio",
                "archives", "code", "data", "other",
            ]

        prompt = self._build_prompt(filename, extension, content_preview, categories)

        try:
            response = self._client.post(
                f"{self.host}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,  # Low temperature for consistent results
                        "num_predict": 150,  # Limit response length
                    },
                },
            )
            response.raise_for_status()

            data = response.json()
            result_text = data.get("response", "")

            return self._parse_response(result_text, categories)

        except (httpx.RequestError, json.JSONDecodeError, KeyError) as e:
            # Return low-confidence fallback
            return ClassificationResult(
                category="other",
                confidence=0.0,
                reasoning=f"AI classification failed: {str(e)}",
            )

    def _build_prompt(
        self,
        filename: str,
        extension: str,
        content_preview: str | None,
        categories: list[str],
    ) -> str:
        """Build the classification prompt."""
        categories_str = ", ".join(categories)

        prompt = f"""You are a file classification assistant. \
Classify the given file into exactly one category.

Available categories: {categories_str}

File information:
- Filename: {filename}
- Extension: {extension}
"""

        if content_preview:
            # Truncate and clean content preview
            preview = content_preview[:300].replace("\n", " ").strip()
            prompt += f"- Content preview: {preview}\n"

        prompt += """
Respond with ONLY a JSON object in this exact format (no other text):
{"category": "category_name", "confidence": 0.95, "reasoning": "brief explanation"}

JSON response:"""

        return prompt

    def _parse_response(
        self,
        response_text: str,
        categories: list[str],
    ) -> ClassificationResult:
        """Parse the AI response into a ClassificationResult."""
        # Try to extract JSON from response
        try:
            # Look for JSON object in response
            json_match = re.search(r'\{[^{}]*\}', response_text)
            if json_match:
                data = json.loads(json_match.group())

                category = data.get("category", "other").lower().strip()
                confidence = float(data.get("confidence", 0.5))
                reasoning = data.get("reasoning", "AI classification")

                # Validate category
                if category not in categories:
                    # Try to find closest match
                    for cat in categories:
                        if cat in category or category in cat:
                            category = cat
                            break
                    else:
                        category = "other"
                        confidence = 0.3

                # Clamp confidence
                confidence = max(0.0, min(1.0, confidence))

                return ClassificationResult(
                    category=category,
                    confidence=confidence,
                    reasoning=reasoning,
                )

        except (json.JSONDecodeError, ValueError, TypeError):
            pass

        # Fallback: try to extract category from text
        response_lower = response_text.lower()
        for category in categories:
            if category in response_lower:
                return ClassificationResult(
                    category=category,
                    confidence=0.5,
                    reasoning="Extracted from AI response text",
                )

        return ClassificationResult(
            category="other",
            confidence=0.2,
            reasoning="Could not parse AI response",
        )

    def __del__(self):
        """Cleanup HTTP client."""
        if hasattr(self, '_client'):
            self._client.close()
