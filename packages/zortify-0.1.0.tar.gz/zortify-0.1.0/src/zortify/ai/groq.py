"""Groq AI provider for fast cloud inference with free tier."""

import json
import os
import re

import httpx

from zortify.ai.base import AIProvider, ClassificationResult


class GroqProvider(AIProvider):
    """
    AI provider using Groq's fast inference API.

    Groq offers a generous free tier with fast inference.
    Get your API key at: https://console.groq.com/keys

    Supported models:
    - llama3-70b-8192 (recommended)
    - llama3-8b-8192 (faster, less accurate)
    - mixtral-8x7b-32768
    """

    API_URL = "https://api.groq.com/openai/v1/chat/completions"

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "llama3-70b-8192",
        timeout: float = 30.0,
    ):
        """
        Initialize Groq provider.

        Args:
            api_key: Groq API key (or set GROQ_API_KEY env var)
            model: Model to use
            timeout: Request timeout in seconds
        """
        self.api_key = api_key or os.environ.get("GROQ_API_KEY")
        self.model = model
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    @property
    def name(self) -> str:
        return f"groq:{self.model}"

    def is_available(self) -> bool:
        """Check if API key is configured."""
        return bool(self.api_key)

    def classify(
        self,
        filename: str,
        extension: str,
        content_preview: str | None = None,
        categories: list[str] | None = None,
    ) -> ClassificationResult:
        """
        Classify a file using Groq.

        Args:
            filename: Name of the file
            extension: File extension
            content_preview: Optional preview of file contents
            categories: List of available categories

        Returns:
            ClassificationResult with category, confidence, and reasoning
        """
        if not self.api_key:
            return ClassificationResult(
                category="other",
                confidence=0.0,
                reasoning="Groq API key not configured",
            )

        if categories is None:
            categories = [
                "documents", "images", "videos", "audio",
                "archives", "code", "data", "other",
            ]

        messages = self._build_messages(filename, extension, content_preview, categories)

        try:
            response = self._client.post(
                self.API_URL,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": 0.1,
                    "max_tokens": 150,
                },
            )
            response.raise_for_status()

            data = response.json()
            result_text = data["choices"][0]["message"]["content"]

            return self._parse_response(result_text, categories)

        except httpx.HTTPStatusError as e:
            error_msg = f"Groq API error: {e.response.status_code}"
            try:
                error_data = e.response.json()
                error_msg = error_data.get("error", {}).get("message", error_msg)
            except json.JSONDecodeError:
                pass

            return ClassificationResult(
                category="other",
                confidence=0.0,
                reasoning=error_msg,
            )

        except (httpx.RequestError, json.JSONDecodeError, KeyError) as e:
            return ClassificationResult(
                category="other",
                confidence=0.0,
                reasoning=f"AI classification failed: {str(e)}",
            )

    def _build_messages(
        self,
        filename: str,
        extension: str,
        content_preview: str | None,
        categories: list[str],
    ) -> list[dict]:
        """Build chat messages for the API."""
        categories_str = ", ".join(categories)

        system_prompt = """You are a file classification assistant. Your task is to classify files \
into categories based on their filename, extension, and content preview.

Always respond with ONLY a valid JSON object in this exact format:
{"category": "category_name", "confidence": 0.95, "reasoning": "brief explanation"}

Do not include any other text, markdown formatting, or explanation outside the JSON."""

        user_content = f"""Classify this file into one of these categories: {categories_str}

File information:
- Filename: {filename}
- Extension: {extension}"""

        if content_preview:
            preview = content_preview[:300].replace("\n", " ").strip()
            user_content += f"\n- Content preview: {preview}"

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]

    def _parse_response(
        self,
        response_text: str,
        categories: list[str],
    ) -> ClassificationResult:
        """Parse the AI response into a ClassificationResult."""
        try:
            # Clean up response - remove markdown code blocks if present
            cleaned = response_text.strip()
            if cleaned.startswith("```"):
                # Remove code block markers
                lines = cleaned.split("\n")
                cleaned = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

            # Try to parse JSON
            json_match = re.search(r'\{[^{}]*\}', cleaned)
            if json_match:
                data = json.loads(json_match.group())

                category = data.get("category", "other").lower().strip()
                confidence = float(data.get("confidence", 0.5))
                reasoning = data.get("reasoning", "AI classification")

                # Validate category
                if category not in categories:
                    for cat in categories:
                        if cat in category or category in cat:
                            category = cat
                            break
                    else:
                        category = "other"
                        confidence = 0.3

                confidence = max(0.0, min(1.0, confidence))

                return ClassificationResult(
                    category=category,
                    confidence=confidence,
                    reasoning=reasoning,
                )

        except (json.JSONDecodeError, ValueError, TypeError):
            pass

        # Fallback
        response_lower = response_text.lower()
        for category in categories:
            if category in response_lower:
                return ClassificationResult(
                    category=category,
                    confidence=0.5,
                    reasoning="Extracted from AI response",
                )

        return ClassificationResult(
            category="other",
            confidence=0.2,
            reasoning="Could not parse AI response",
        )

    def __del__(self):
        """Cleanup HTTP client."""
        if hasattr(self, '_client'):
            self._client.close()
