"""Factory for creating AI providers based on configuration."""


from zortify.ai.base import AIProvider
from zortify.ai.fallback import FallbackProvider
from zortify.config import AIConfig


def create_provider(config: AIConfig) -> AIProvider:
    """
    Create an AI provider based on configuration.

    Args:
        config: AI configuration specifying provider and settings

    Returns:
        Configured AIProvider instance

    The factory tries to create the requested provider and falls back
    to alternatives if the requested one is not available.
    """
    provider = config.provider.lower()

    # Try to create the requested provider
    if provider == "ollama":
        return _create_ollama(config)
    elif provider == "groq":
        return _create_groq(config)
    elif provider == "openai":
        return _create_openai(config)
    elif provider == "none" or provider == "fallback":
        return FallbackProvider()

    # Unknown provider, use fallback
    return FallbackProvider()


def create_provider_with_fallback(config: AIConfig) -> AIProvider:
    """
    Create an AI provider with automatic fallback chain.

    Tries providers in order of preference:
    1. Configured provider
    2. Ollama (if available)
    3. Groq (if API key set)
    4. Fallback heuristics

    Args:
        config: AI configuration

    Returns:
        Best available AIProvider instance
    """
    # Try configured provider first
    primary = create_provider(config)
    if primary.is_available():
        return primary

    # If configured provider not available, try alternatives
    if config.provider != "ollama":
        ollama = _create_ollama(config)
        if ollama.is_available():
            return ollama

    if config.provider != "groq" and config.groq_api_key:
        groq = _create_groq(config)
        if groq.is_available():
            return groq

    if config.provider != "openai" and config.openai_api_key:
        openai = _create_openai(config)
        if openai.is_available():
            return openai

    # Fall back to heuristics
    return FallbackProvider()


def _create_ollama(config: AIConfig) -> AIProvider:
    """Create Ollama provider."""
    from zortify.ai.ollama import OllamaProvider

    return OllamaProvider(
        host=config.ollama_host,
        model=config.ollama_model,
    )


def _create_groq(config: AIConfig) -> AIProvider:
    """Create Groq provider."""
    from zortify.ai.groq import GroqProvider

    return GroqProvider(
        api_key=config.groq_api_key,
        model=config.groq_model,
    )


def _create_openai(config: AIConfig) -> AIProvider:
    """Create OpenAI provider."""
    from zortify.ai.openai import OpenAIProvider

    return OpenAIProvider(
        api_key=config.openai_api_key,
        model=config.openai_model,
    )


def get_available_providers(config: AIConfig) -> list[tuple[str, bool]]:
    """
    Check which providers are available.

    Args:
        config: AI configuration

    Returns:
        List of (provider_name, is_available) tuples
    """
    providers = []

    # Check Ollama
    try:
        ollama = _create_ollama(config)
        providers.append(("ollama", ollama.is_available()))
    except Exception:
        providers.append(("ollama", False))

    # Check Groq
    try:
        groq = _create_groq(config)
        providers.append(("groq", groq.is_available()))
    except Exception:
        providers.append(("groq", False))

    # Check OpenAI
    try:
        openai = _create_openai(config)
        providers.append(("openai", openai.is_available()))
    except Exception:
        providers.append(("openai", False))

    # Fallback is always available
    providers.append(("fallback", True))

    return providers
