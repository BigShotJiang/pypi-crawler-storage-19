"""Base class for AI providers."""

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ClassificationResult:
    """Result of AI file classification."""

    category: str
    confidence: float
    reasoning: str

    def __post_init__(self) -> None:
        """Validate confidence is between 0 and 1."""
        self.confidence = max(0.0, min(1.0, self.confidence))


class AIProvider(ABC):
    """Abstract base class for AI classification providers."""

    @abstractmethod
    def classify(
        self,
        filename: str,
        extension: str,
        content_preview: str | None = None,
        categories: list[str] | None = None,
    ) -> ClassificationResult:
        """
        Classify a file into a category.

        Args:
            filename: Name of the file
            extension: File extension (e.g., '.pdf')
            content_preview: Optional preview of file contents
            categories: List of available categories

        Returns:
            ClassificationResult with category, confidence, and reasoning
        """
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """
        Check if the provider is available and configured.

        Returns:
            True if provider can be used, False otherwise
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return the provider name."""
        pass
