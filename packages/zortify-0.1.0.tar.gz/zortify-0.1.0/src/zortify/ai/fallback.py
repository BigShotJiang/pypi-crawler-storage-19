"""Fallback rule-based provider when AI is not available."""

import re

from zortify.ai.base import AIProvider, ClassificationResult


class FallbackProvider(AIProvider):
    """
    Rule-based fallback provider that uses heuristics to classify files.

    This provider works without any AI/API and uses filename patterns
    and keywords to make educated guesses about file categories.
    """

    # Common patterns for each category
    PATTERNS = {
        "documents": {
            "extensions": [
                ".pdf", ".doc", ".docx", ".txt", ".rtf", ".odt",
                ".xls", ".xlsx", ".ppt", ".pptx",
            ],
            "keywords": [
                "report", "invoice", "resume", "cv", "letter", "contract", "agreement",
                "proposal", "presentation", "spreadsheet", "document", "form", "certificate",
            ],
            "patterns": [r"^\d{4}[-_]?\d{2}[-_]?\d{2}", r"v\d+", r"final", r"draft"],
        },
        "images": {
            "extensions": [
                ".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg",
                ".bmp", ".tiff", ".ico", ".raw",
            ],
            "keywords": ["photo", "image", "picture", "screenshot", "screen", "snap", "img", "pic",
                        "wallpaper", "background", "avatar", "logo", "icon", "banner"],
            "patterns": [r"^IMG_", r"^DSC", r"^DCIM", r"^Screenshot", r"^\d{8}_\d{6}"],
        },
        "videos": {
            "extensions": [".mp4", ".mkv", ".avi", ".mov", ".webm", ".wmv", ".flv", ".m4v"],
            "keywords": ["video", "movie", "film", "clip", "recording", "screen_recording",
                        "tutorial", "episode", "trailer"],
            "patterns": [r"^VID_", r"S\d{2}E\d{2}", r"^\d{3,4}p"],
        },
        "audio": {
            "extensions": [".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma", ".opus"],
            "keywords": ["audio", "song", "music", "podcast", "recording", "voice", "sound",
                        "track", "album", "artist"],
            "patterns": [r"^\d{2}[-_.]", r"^Track"],
        },
        "archives": {
            "extensions": [".zip", ".rar", ".7z", ".tar", ".gz", ".bz2", ".xz", ".tar.gz"],
            "keywords": ["archive", "backup", "compressed", "bundle", "package"],
            "patterns": [],
        },
        "code": {
            "extensions": [".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".cpp", ".c", ".h",
                         ".cs", ".go", ".rs", ".rb", ".php", ".swift", ".kt", ".scala"],
            "keywords": ["script", "source", "code", "module", "component", "util", "helper",
                        "test", "spec", "config", "main", "index", "app"],
            "patterns": [r"^test_", r"_test$", r"\.test\.", r"\.spec\."],
        },
        "installers": {
            "extensions": [".exe", ".msi", ".dmg", ".deb", ".rpm", ".appimage", ".pkg"],
            "keywords": ["setup", "install", "installer", "update", "patch"],
            "patterns": [r"v?\d+\.\d+\.\d+", r"x64", r"x86", r"amd64", r"arm64"],
        },
        "data": {
            "extensions": [".csv", ".json", ".xml", ".yaml", ".yml", ".sql", ".db", ".sqlite"],
            "keywords": ["data", "dataset", "export", "import", "backup", "dump", "log"],
            "patterns": [r"^\d{4}[-_]\d{2}[-_]\d{2}"],
        },
        "ebooks": {
            "extensions": [".epub", ".mobi", ".azw", ".azw3", ".fb2"],
            "keywords": ["book", "ebook", "novel", "guide", "manual", "handbook"],
            "patterns": [],
        },
    }

    def __init__(self):
        """Initialize the fallback provider."""
        self._compiled_patterns: dict[str, list[re.Pattern]] = {}
        for category, data in self.PATTERNS.items():
            self._compiled_patterns[category] = [
                re.compile(p, re.IGNORECASE) for p in data.get("patterns", [])
            ]

    @property
    def name(self) -> str:
        return "fallback"

    def is_available(self) -> bool:
        """Always available."""
        return True

    def classify(
        self,
        filename: str,
        extension: str,
        content_preview: str | None = None,
        categories: list[str] | None = None,
    ) -> ClassificationResult:
        """
        Classify a file using heuristics.

        Args:
            filename: Name of the file
            extension: File extension
            content_preview: Optional preview of file contents (not used)
            categories: List of available categories (used to filter results)

        Returns:
            ClassificationResult with category, confidence, and reasoning
        """
        if categories is None:
            categories = list(self.PATTERNS.keys())

        filename_lower = filename.lower()
        ext_lower = extension.lower()

        best_category = None
        best_confidence = 0.0
        best_reasoning = ""

        for category, data in self.PATTERNS.items():
            if category not in categories:
                continue

            confidence = 0.0
            reasoning_parts = []

            # Check extension (highest weight)
            if ext_lower in data.get("extensions", []):
                confidence += 0.6
                reasoning_parts.append(f"extension {ext_lower}")

            # Check keywords
            for keyword in data.get("keywords", []):
                if keyword in filename_lower:
                    confidence += 0.25
                    reasoning_parts.append(f"keyword '{keyword}'")
                    break  # Only count one keyword match

            # Check patterns
            for pattern in self._compiled_patterns.get(category, []):
                if pattern.search(filename):
                    confidence += 0.15
                    reasoning_parts.append("pattern match")
                    break  # Only count one pattern match

            # Cap confidence at 1.0
            confidence = min(confidence, 1.0)

            if confidence > best_confidence:
                best_confidence = confidence
                best_category = category
                if reasoning_parts:
                    best_reasoning = f"Matched: {', '.join(reasoning_parts)}"
                else:
                    best_reasoning = "No specific match"

        if best_category and best_confidence > 0:
            return ClassificationResult(
                category=best_category,
                confidence=best_confidence,
                reasoning=best_reasoning,
            )

        return ClassificationResult(
            category="other",
            confidence=0.1,
            reasoning="No matching patterns found",
        )
