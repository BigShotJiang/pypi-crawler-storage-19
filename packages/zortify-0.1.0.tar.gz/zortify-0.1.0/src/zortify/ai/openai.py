"""OpenAI AI provider for cloud inference (paid)."""

import json
import os
import re

import httpx

from zortify.ai.base import AIProvider, ClassificationResult


class OpenAIProvider(AIProvider):
    """
    AI provider using OpenAI's API.

    This is a paid service. Get your API key at: https://platform.openai.com/api-keys

    Recommended models:
    - gpt-3.5-turbo (fast, cheap)
    - gpt-4o-mini (better quality, still affordable)
    """

    API_URL = "https://api.openai.com/v1/chat/completions"

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gpt-3.5-turbo",
        timeout: float = 30.0,
    ):
        """
        Initialize OpenAI provider.

        Args:
            api_key: OpenAI API key (or set OPENAI_API_KEY env var)
            model: Model to use
            timeout: Request timeout in seconds
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self.model = model
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    @property
    def name(self) -> str:
        return f"openai:{self.model}"

    def is_available(self) -> bool:
        """Check if API key is configured."""
        return bool(self.api_key)

    def classify(
        self,
        filename: str,
        extension: str,
        content_preview: str | None = None,
        categories: list[str] | None = None,
    ) -> ClassificationResult:
        """
        Classify a file using OpenAI.

        Args:
            filename: Name of the file
            extension: File extension
            content_preview: Optional preview of file contents
            categories: List of available categories

        Returns:
            ClassificationResult with category, confidence, and reasoning
        """
        if not self.api_key:
            return ClassificationResult(
                category="other",
                confidence=0.0,
                reasoning="OpenAI API key not configured",
            )

        if categories is None:
            categories = [
                "documents", "images", "videos", "audio",
                "archives", "code", "data", "other",
            ]

        messages = self._build_messages(filename, extension, content_preview, categories)

        try:
            response = self._client.post(
                self.API_URL,
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "messages": messages,
                    "temperature": 0.1,
                    "max_tokens": 150,
                },
            )
            response.raise_for_status()

            data = response.json()
            result_text = data["choices"][0]["message"]["content"]

            return self._parse_response(result_text, categories)

        except httpx.HTTPStatusError as e:
            error_msg = f"OpenAI API error: {e.response.status_code}"
            try:
                error_data = e.response.json()
                error_msg = error_data.get("error", {}).get("message", error_msg)
            except json.JSONDecodeError:
                pass

            return ClassificationResult(
                category="other",
                confidence=0.0,
                reasoning=error_msg,
            )

        except (httpx.RequestError, json.JSONDecodeError, KeyError) as e:
            return ClassificationResult(
                category="other",
                confidence=0.0,
                reasoning=f"AI classification failed: {str(e)}",
            )

    def _build_messages(
        self,
        filename: str,
        extension: str,
        content_preview: str | None,
        categories: list[str],
    ) -> list[dict]:
        """Build chat messages for the API."""
        categories_str = ", ".join(categories)

        system_prompt = """You are a file classification assistant. \
Classify files into categories based on their filename, extension, and content.

Always respond with ONLY a valid JSON object:
{"category": "category_name", "confidence": 0.95, "reasoning": "brief explanation"}

No other text or formatting."""

        user_content = f"""Classify into one of: {categories_str}

Filename: {filename}
Extension: {extension}"""

        if content_preview:
            preview = content_preview[:300].replace("\n", " ").strip()
            user_content += f"\nContent: {preview}"

        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ]

    def _parse_response(
        self,
        response_text: str,
        categories: list[str],
    ) -> ClassificationResult:
        """Parse the AI response into a ClassificationResult."""
        try:
            cleaned = response_text.strip()
            if cleaned.startswith("```"):
                lines = cleaned.split("\n")
                cleaned = "\n".join(lines[1:-1] if lines[-1] == "```" else lines[1:])

            json_match = re.search(r'\{[^{}]*\}', cleaned)
            if json_match:
                data = json.loads(json_match.group())

                category = data.get("category", "other").lower().strip()
                confidence = float(data.get("confidence", 0.5))
                reasoning = data.get("reasoning", "AI classification")

                if category not in categories:
                    for cat in categories:
                        if cat in category or category in cat:
                            category = cat
                            break
                    else:
                        category = "other"
                        confidence = 0.3

                confidence = max(0.0, min(1.0, confidence))

                return ClassificationResult(
                    category=category,
                    confidence=confidence,
                    reasoning=reasoning,
                )

        except (json.JSONDecodeError, ValueError, TypeError):
            pass

        response_lower = response_text.lower()
        for category in categories:
            if category in response_lower:
                return ClassificationResult(
                    category=category,
                    confidence=0.5,
                    reasoning="Extracted from AI response",
                )

        return ClassificationResult(
            category="other",
            confidence=0.2,
            reasoning="Could not parse AI response",
        )

    def __del__(self):
        """Cleanup HTTP client."""
        if hasattr(self, '_client'):
            self._client.close()
