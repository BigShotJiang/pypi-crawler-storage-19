"""File classification engine for Smart File Organizer."""

from dataclasses import dataclass

from zortify.config import Category, Config
from zortify.scanner import FileInfo


@dataclass
class ClassificationResult:
    """Result of file classification."""

    category: str
    folder: str
    subfolder: str | None = None
    confidence: float = 1.0
    method: str = "extension"  # extension, keyword, rule, ai
    reasoning: str = ""

    @property
    def target_folder(self) -> str:
        """Get the full target folder path."""
        if self.subfolder:
            return f"{self.folder}/{self.subfolder}"
        return self.folder


class Classifier:
    """Classifies files into categories based on extension and keywords."""

    def __init__(self, config: Config):
        """
        Initialize the classifier.

        Args:
            config: Configuration with category definitions
        """
        self.config = config
        self._extension_map = self._build_extension_map()

    def _build_extension_map(self) -> dict[str, str]:
        """Build a map of extensions to category names."""
        ext_map: dict[str, str] = {}
        for cat_name, category in self.config.categories.items():
            for ext in category.extensions:
                # Normalize extension (ensure it has a dot and is lowercase)
                ext_normalized = ext.lower() if ext.startswith(".") else f".{ext.lower()}"
                ext_map[ext_normalized] = cat_name
        return ext_map

    def classify(self, file_info: FileInfo) -> ClassificationResult | None:
        """
        Classify a file into a category.

        Args:
            file_info: Information about the file to classify

        Returns:
            ClassificationResult or None if no category matches
        """
        # Try extension-based classification first (fastest)
        result = self._classify_by_extension(file_info)
        if result:
            return result

        # Try keyword-based classification
        result = self._classify_by_keyword(file_info)
        if result:
            return result

        # Return default category if configured
        if self.config.settings.default_category:
            default_cat = self.config.categories.get(self.config.settings.default_category)
            if default_cat:
                return ClassificationResult(
                    category=default_cat.name,
                    folder=default_cat.folder,
                    confidence=0.5,
                    method="default",
                    reasoning="No matching category found, using default",
                )

        return None

    def _classify_by_extension(self, file_info: FileInfo) -> ClassificationResult | None:
        """Classify file by its extension."""
        ext = file_info.extension.lower()

        if ext in self._extension_map:
            cat_name = self._extension_map[ext]
            category = self.config.categories[cat_name]
            return ClassificationResult(
                category=cat_name,
                folder=category.folder,
                confidence=1.0,
                method="extension",
                reasoning=f"Matched extension {ext}",
            )

        return None

    def _classify_by_keyword(self, file_info: FileInfo) -> ClassificationResult | None:
        """Classify file by keywords in filename."""
        filename_lower = file_info.name.lower()

        for cat_name, category in self.config.categories.items():
            for keyword in category.keywords:
                if keyword.lower() in filename_lower:
                    return ClassificationResult(
                        category=cat_name,
                        folder=category.folder,
                        confidence=0.8,
                        method="keyword",
                        reasoning=f"Matched keyword '{keyword}' in filename",
                    )

        return None

    def get_category(self, name: str) -> Category | None:
        """Get a category by name."""
        return self.config.categories.get(name)

    def list_categories(self) -> list[str]:
        """List all available category names."""
        return list(self.config.categories.keys())


class AIClassifier(Classifier):
    """Extended classifier that uses AI for unknown files."""

    def __init__(self, config: Config, ai_provider=None):
        """
        Initialize the AI classifier.

        Args:
            config: Configuration with category definitions
            ai_provider: AI provider instance for classification
        """
        super().__init__(config)
        self.ai_provider = ai_provider

    def classify(self, file_info: FileInfo) -> ClassificationResult | None:
        """
        Classify a file, using AI as fallback for unknown types.

        Args:
            file_info: Information about the file to classify

        Returns:
            ClassificationResult or None if no category matches
        """
        # Try standard classification first
        result = super().classify(file_info)

        # If we have a result with high confidence, use it
        if result and result.confidence >= self.config.ai.confidence_threshold:
            return result

        # Try AI classification if available
        if self.ai_provider and self.ai_provider.is_available():
            ai_result = self._classify_with_ai(file_info)
            if ai_result:
                # If AI is more confident, use its result
                if result is None or ai_result.confidence > result.confidence:
                    return ai_result

        return result

    def _classify_with_ai(self, file_info: FileInfo) -> ClassificationResult | None:
        """Classify file using AI provider."""
        if not self.ai_provider:
            return None

        try:
            # Get content preview for text files
            content_preview = file_info.read_preview(max_bytes=500)

            # Call AI provider
            ai_result = self.ai_provider.classify(
                filename=file_info.name,
                extension=file_info.extension,
                content_preview=content_preview,
                categories=self.list_categories(),
            )

            # Map AI result to our ClassificationResult
            if ai_result.category in self.config.categories:
                category = self.config.categories[ai_result.category]
                return ClassificationResult(
                    category=ai_result.category,
                    folder=category.folder,
                    confidence=ai_result.confidence,
                    method="ai",
                    reasoning=ai_result.reasoning,
                )

        except Exception:
            # AI failed, fall back to other methods
            pass

        return None


def classify_file(file_info: FileInfo, config: Config) -> ClassificationResult | None:
    """
    Convenience function to classify a single file.

    Args:
        file_info: Information about the file
        config: Configuration with categories

    Returns:
        ClassificationResult or None
    """
    classifier = Classifier(config)
    return classifier.classify(file_info)


def classify_files(
    files: list[FileInfo],
    config: Config,
) -> dict[str, list[tuple[FileInfo, ClassificationResult]]]:
    """
    Classify multiple files and group by category.

    Args:
        files: List of files to classify
        config: Configuration with categories

    Returns:
        Dictionary mapping category names to list of (file, result) tuples
    """
    classifier = Classifier(config)
    results: dict[str, list[tuple[FileInfo, ClassificationResult]]] = {}

    for file_info in files:
        result = classifier.classify(file_info)
        if result:
            if result.category not in results:
                results[result.category] = []
            results[result.category].append((file_info, result))

    return results
