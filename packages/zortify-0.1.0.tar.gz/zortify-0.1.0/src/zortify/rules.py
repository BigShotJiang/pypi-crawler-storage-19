"""Custom rules engine for Smart File Organizer."""

import fnmatch
import re
from dataclasses import dataclass
from enum import Enum

from zortify.config import Config, Rule
from zortify.scanner import FileInfo


class Action(Enum):
    """Actions that can be taken on a file."""

    MOVE = "move"
    DELETE = "delete"
    SKIP = "skip"


@dataclass
class RuleMatch:
    """Result of a rule matching a file."""

    rule: Rule
    action: Action
    category: str | None = None
    folder: str | None = None
    subfolder: str | None = None

    @property
    def target_folder(self) -> str | None:
        """Get the full target folder path."""
        if not self.folder:
            return None
        if self.subfolder:
            return f"{self.folder}/{self.subfolder}"
        return self.folder


class RulesEngine:
    """Processes custom rules for file organization."""

    def __init__(self, config: Config):
        """
        Initialize the rules engine.

        Args:
            config: Configuration containing rules and categories
        """
        self.config = config
        self.rules = config.rules

    def match(self, file_info: FileInfo) -> RuleMatch | None:
        """
        Find the first rule that matches a file.

        Args:
            file_info: Information about the file

        Returns:
            RuleMatch if a rule matches, None otherwise
        """
        for rule in self.rules:
            if self._rule_matches(rule, file_info):
                return self._create_match(rule)
        return None

    def _rule_matches(self, rule: Rule, file_info: FileInfo) -> bool:
        """Check if a rule matches a file."""
        pattern = rule.pattern

        # Try glob pattern matching
        if fnmatch.fnmatch(file_info.name.lower(), pattern.lower()):
            return True

        # Try regex matching if pattern looks like a regex
        if pattern.startswith("^") or pattern.endswith("$") or ".*" in pattern:
            try:
                if re.search(pattern, file_info.name, re.IGNORECASE):
                    return True
            except re.error:
                pass

        return False

    def _create_match(self, rule: Rule) -> RuleMatch:
        """Create a RuleMatch from a Rule."""
        action = Action(rule.action) if rule.action else Action.MOVE

        folder = None
        if rule.category and rule.category in self.config.categories:
            folder = self.config.categories[rule.category].folder

        return RuleMatch(
            rule=rule,
            action=action,
            category=rule.category,
            folder=folder,
            subfolder=rule.subfolder,
        )

    def get_all_matches(self, file_info: FileInfo) -> list[RuleMatch]:
        """
        Get all rules that match a file (for debugging).

        Args:
            file_info: Information about the file

        Returns:
            List of all matching RuleMatch objects
        """
        matches = []
        for rule in self.rules:
            if self._rule_matches(rule, file_info):
                matches.append(self._create_match(rule))
        return matches


def apply_rules(
    files: list[FileInfo],
    config: Config,
) -> tuple[list[tuple[FileInfo, RuleMatch]], list[FileInfo]]:
    """
    Apply rules to a list of files.

    Args:
        files: List of files to process
        config: Configuration containing rules

    Returns:
        Tuple of (matched files with rules, unmatched files)
    """
    engine = RulesEngine(config)
    matched: list[tuple[FileInfo, RuleMatch]] = []
    unmatched: list[FileInfo] = []

    for file_info in files:
        match = engine.match(file_info)
        if match:
            matched.append((file_info, match))
        else:
            unmatched.append(file_info)

    return matched, unmatched


def create_rule(
    pattern: str,
    category: str | None = None,
    subfolder: str | None = None,
    action: str = "move",
) -> Rule:
    """
    Convenience function to create a rule.

    Args:
        pattern: Glob or regex pattern to match files
        category: Target category name
        subfolder: Optional subfolder within category
        action: Action to take (move, delete, skip)

    Returns:
        Rule object
    """
    return Rule(
        pattern=pattern,
        category=category,
        subfolder=subfolder,
        action=action,
    )
