"""File scanning utilities for Smart File Organizer."""

import fnmatch
import os
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path


@dataclass
class FileInfo:
    """Information about a scanned file."""

    path: Path
    name: str
    extension: str
    size: int
    modified_time: datetime
    created_time: datetime

    @property
    def age_days(self) -> int:
        """Get file age in days since last modification."""
        delta = datetime.now() - self.modified_time
        return delta.days

    @property
    def size_human(self) -> str:
        """Get human-readable file size."""
        size: float = self.size
        for unit in ["B", "KB", "MB", "GB", "TB"]:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} PB"

    def read_preview(self, max_bytes: int = 1024) -> str | None:
        """
        Read a preview of file contents for text-based files.

        Args:
            max_bytes: Maximum bytes to read

        Returns:
            String preview or None if file is binary/unreadable
        """
        # Text-like extensions
        text_extensions = {
            ".txt", ".md", ".csv", ".json", ".xml", ".yaml", ".yml",
            ".py", ".js", ".ts", ".html", ".css", ".java", ".cpp",
            ".c", ".h", ".cs", ".go", ".rs", ".rb", ".php", ".sh",
            ".bat", ".ps1", ".sql", ".log", ".ini", ".cfg", ".conf",
        }

        if self.extension.lower() not in text_extensions:
            return None

        try:
            with open(self.path, encoding="utf-8", errors="ignore") as f:
                return f.read(max_bytes)
        except OSError:
            return None


class FileScanner:
    """Scans directories for files to organize."""

    def __init__(
        self,
        ignore_patterns: list[str] | None = None,
        include_hidden: bool = False,
        min_age_days: int = 0,
    ):
        """
        Initialize the scanner.

        Args:
            ignore_patterns: Glob patterns for files to ignore
            include_hidden: Whether to include hidden files (starting with .)
            min_age_days: Minimum file age in days to include
        """
        self.ignore_patterns = ignore_patterns or []
        self.include_hidden = include_hidden
        self.min_age_days = min_age_days

    def scan(
        self,
        directory: Path,
        recursive: bool = False,
    ) -> Iterator[FileInfo]:
        """
        Scan a directory for files.

        Args:
            directory: Directory to scan
            recursive: Whether to scan subdirectories

        Yields:
            FileInfo objects for each matching file
        """
        if not directory.exists():
            raise FileNotFoundError(f"Directory not found: {directory}")

        if not directory.is_dir():
            raise NotADirectoryError(f"Not a directory: {directory}")

        if recursive:
            yield from self._scan_recursive(directory)
        else:
            yield from self._scan_directory(directory)

    def _scan_directory(self, directory: Path) -> Iterator[FileInfo]:
        """Scan a single directory (non-recursive)."""
        try:
            entries = list(directory.iterdir())
        except PermissionError:
            return

        for entry in entries:
            if entry.is_file():
                file_info = self._process_file(entry)
                if file_info is not None:
                    yield file_info

    def _scan_recursive(self, directory: Path) -> Iterator[FileInfo]:
        """Scan directory recursively."""
        try:
            for root, dirs, files in os.walk(directory):
                root_path = Path(root)

                # Filter out hidden directories if needed
                if not self.include_hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]

                # Filter out ignored directories
                dirs[:] = [d for d in dirs if not self._should_ignore(d)]

                for filename in files:
                    file_path = root_path / filename
                    file_info = self._process_file(file_path)
                    if file_info is not None:
                        yield file_info
        except PermissionError:
            return

    def _process_file(self, path: Path) -> FileInfo | None:
        """
        Process a single file and return FileInfo if it passes filters.

        Args:
            path: Path to the file

        Returns:
            FileInfo or None if file should be skipped
        """
        name = path.name

        # Skip hidden files if not included
        if not self.include_hidden and name.startswith("."):
            return None

        # Skip ignored patterns
        if self._should_ignore(name):
            return None

        # Get file stats
        try:
            stat = path.stat()
        except OSError:
            return None

        # Get timestamps
        modified_time = datetime.fromtimestamp(stat.st_mtime)
        created_time = datetime.fromtimestamp(stat.st_ctime)

        # Check age filter
        if self.min_age_days > 0:
            age = datetime.now() - modified_time
            if age < timedelta(days=self.min_age_days):
                return None

        return FileInfo(
            path=path,
            name=name,
            extension=path.suffix.lower(),
            size=stat.st_size,
            modified_time=modified_time,
            created_time=created_time,
        )

    def _should_ignore(self, name: str) -> bool:
        """Check if a file/directory name matches any ignore pattern."""
        for pattern in self.ignore_patterns:
            if fnmatch.fnmatch(name.lower(), pattern.lower()):
                return True
        return False


def scan_directory(
    directory: Path,
    recursive: bool = False,
    ignore_patterns: list[str] | None = None,
    include_hidden: bool = False,
    min_age_days: int = 0,
) -> list[FileInfo]:
    """
    Convenience function to scan a directory and return list of files.

    Args:
        directory: Directory to scan
        recursive: Whether to scan subdirectories
        ignore_patterns: Glob patterns for files to ignore
        include_hidden: Whether to include hidden files
        min_age_days: Minimum file age in days

    Returns:
        List of FileInfo objects
    """
    scanner = FileScanner(
        ignore_patterns=ignore_patterns,
        include_hidden=include_hidden,
        min_age_days=min_age_days,
    )
    return list(scanner.scan(directory, recursive=recursive))


def get_directory_stats(directory: Path, recursive: bool = False) -> dict:
    """
    Get statistics about files in a directory.

    Args:
        directory: Directory to analyze
        recursive: Whether to include subdirectories

    Returns:
        Dictionary with file statistics
    """
    scanner = FileScanner()
    files = list(scanner.scan(directory, recursive=recursive))

    total_size = sum(f.size for f in files)
    extensions: dict[str, int] = {}

    for f in files:
        ext = f.extension or "(no extension)"
        extensions[ext] = extensions.get(ext, 0) + 1

    return {
        "total_files": len(files),
        "total_size": total_size,
        "extensions": extensions,
        "oldest": min((f.modified_time for f in files), default=None),
        "newest": max((f.modified_time for f in files), default=None),
    }
