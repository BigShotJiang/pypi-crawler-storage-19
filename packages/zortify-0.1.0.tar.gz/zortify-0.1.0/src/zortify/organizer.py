"""Core organization logic for Smart File Organizer."""

import shutil
from dataclasses import dataclass, field
from pathlib import Path

from zortify.ai import AIProvider, create_provider_with_fallback
from zortify.classifier import AIClassifier, Classifier
from zortify.config import Config
from zortify.history import History
from zortify.rules import Action, RulesEngine
from zortify.scanner import FileInfo, FileScanner


@dataclass
class OrganizeAction:
    """Represents a planned file organization action."""

    file: FileInfo
    action: str  # move, delete, skip
    destination: Path | None = None
    category: str | None = None
    method: str = ""  # rule, extension, keyword, ai
    reasoning: str = ""

    @property
    def destination_display(self) -> str:
        """Get destination path for display (relative)."""
        if self.destination:
            return str(self.destination)
        return "(no destination)"


@dataclass
class OrganizeResult:
    """Result of an organize operation."""

    success: bool
    action: OrganizeAction
    error: str | None = None


@dataclass
class OrganizeSummary:
    """Summary of an organize session."""

    total_files: int = 0
    moved: int = 0
    skipped: int = 0
    deleted: int = 0
    errors: int = 0
    session_id: str | None = None
    actions: list[OrganizeResult] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Calculate success rate as percentage."""
        if self.total_files == 0:
            return 100.0
        return ((self.moved + self.skipped + self.deleted) / self.total_files) * 100


class Organizer:
    """Main organizer class that coordinates file organization."""

    def __init__(
        self,
        config: Config,
        history: History | None = None,
        ai_provider: AIProvider | None = None,
        use_ai: bool = True,
    ):
        """
        Initialize the organizer.

        Args:
            config: Configuration for organization
            history: Optional history tracker for undo support
            ai_provider: Optional AI provider for classification
            use_ai: Whether to use AI classification (default: True)
        """
        self.config = config
        self.history = history
        self.scanner = FileScanner(
            ignore_patterns=config.settings.ignore,
            include_hidden=config.settings.include_hidden,
            min_age_days=config.settings.min_age_days,
        )
        self.rules_engine = RulesEngine(config)

        # Set up classifier with or without AI
        self.ai_provider = ai_provider
        self.classifier: Classifier
        if use_ai and config.ai.provider != "none":
            if ai_provider is None:
                ai_provider = create_provider_with_fallback(config.ai)
            self.ai_provider = ai_provider
            self.classifier = AIClassifier(config, ai_provider)
        else:
            self.classifier = Classifier(config)

    def plan(
        self,
        source_dir: Path,
        target_dir: Path | None = None,
        recursive: bool = False,
    ) -> list[OrganizeAction]:
        """
        Plan organization without moving files.

        Args:
            source_dir: Directory to organize
            target_dir: Where to move files (defaults to source_dir)
            recursive: Whether to scan subdirectories

        Returns:
            List of planned actions
        """
        if target_dir is None:
            target_dir = source_dir

        actions: list[OrganizeAction] = []

        # Scan files
        files = list(self.scanner.scan(source_dir, recursive=recursive))

        for file_info in files:
            action = self._plan_file(file_info, target_dir)
            if action:
                actions.append(action)

        return actions

    def _plan_file(
        self,
        file_info: FileInfo,
        target_dir: Path,
    ) -> OrganizeAction | None:
        """Plan action for a single file."""

        # Check rules first (highest priority)
        rule_match = self.rules_engine.match(file_info)
        if rule_match:
            if rule_match.action == Action.SKIP:
                return OrganizeAction(
                    file=file_info,
                    action="skip",
                    method="rule",
                    reasoning=f"Matched rule: {rule_match.rule.pattern}",
                )
            elif rule_match.action == Action.DELETE:
                return OrganizeAction(
                    file=file_info,
                    action="delete",
                    method="rule",
                    reasoning=f"Matched delete rule: {rule_match.rule.pattern}",
                )
            elif rule_match.folder:
                dest = self._build_destination(
                    file_info,
                    target_dir,
                    rule_match.folder,
                    rule_match.subfolder,
                )
                return OrganizeAction(
                    file=file_info,
                    action="move",
                    destination=dest,
                    category=rule_match.category,
                    method="rule",
                    reasoning=f"Matched rule: {rule_match.rule.pattern}",
                )

        # Try classification
        classification = self.classifier.classify(file_info)
        if classification:
            dest = self._build_destination(
                file_info,
                target_dir,
                classification.folder,
                classification.subfolder,
            )
            return OrganizeAction(
                file=file_info,
                action="move",
                destination=dest,
                category=classification.category,
                method=classification.method,
                reasoning=classification.reasoning,
            )

        # No match - skip
        return OrganizeAction(
            file=file_info,
            action="skip",
            method="none",
            reasoning="No matching category or rule",
        )

    def _build_destination(
        self,
        file_info: FileInfo,
        target_dir: Path,
        folder: str,
        subfolder: str | None = None,
    ) -> Path:
        """Build the destination path for a file."""
        dest_dir = target_dir / folder

        if subfolder:
            dest_dir = dest_dir / subfolder

        # Add date folder if configured
        if self.config.settings.use_date_folders:
            date_str = file_info.modified_time.strftime(self.config.settings.date_format)
            dest_dir = dest_dir / date_str

        # Handle filename conflicts
        dest_path = dest_dir / file_info.name
        dest_path = self._handle_duplicate(dest_path)

        return dest_path

    def _handle_duplicate(self, dest_path: Path) -> Path:
        """Handle duplicate filenames according to config."""
        if not dest_path.exists():
            return dest_path

        strategy = self.config.settings.duplicates

        if strategy == "overwrite":
            return dest_path
        elif strategy == "skip":
            # Return the same path, execute will handle skipping
            return dest_path
        else:  # rename
            return self._get_unique_path(dest_path)

    def _get_unique_path(self, path: Path) -> Path:
        """Get a unique path by adding a number suffix."""
        if not path.exists():
            return path

        stem = path.stem
        suffix = path.suffix
        parent = path.parent
        counter = 1

        while True:
            new_name = f"{stem}_{counter}{suffix}"
            new_path = parent / new_name
            if not new_path.exists():
                return new_path
            counter += 1
            if counter > 1000:  # Safety limit
                raise RuntimeError(f"Too many duplicates for {path}")

    def execute(
        self,
        actions: list[OrganizeAction],
        source_dir: Path,
    ) -> OrganizeSummary:
        """
        Execute planned organization actions.

        Args:
            actions: List of actions to execute
            source_dir: Source directory (for history tracking)

        Returns:
            Summary of the operation
        """
        summary = OrganizeSummary(total_files=len(actions))

        # Start history session if enabled
        session_id = None
        if self.history and self.config.settings.enable_history:
            session_id = self.history.start_session(source_dir)
            summary.session_id = session_id

        for action in actions:
            result = self._execute_action(action, session_id)
            summary.actions.append(result)

            if result.success:
                if action.action == "move":
                    summary.moved += 1
                elif action.action == "skip":
                    summary.skipped += 1
                elif action.action == "delete":
                    summary.deleted += 1
            else:
                summary.errors += 1

        # End history session
        if self.history and session_id:
            self.history.end_session(session_id)

        return summary

    def _execute_action(
        self,
        action: OrganizeAction,
        session_id: str | None,
    ) -> OrganizeResult:
        """Execute a single action."""
        if action.action == "skip":
            return OrganizeResult(success=True, action=action)

        if action.action == "delete":
            return self._execute_delete(action)

        if action.action == "move":
            return self._execute_move(action, session_id)

        return OrganizeResult(
            success=False,
            action=action,
            error=f"Unknown action: {action.action}",
        )

    def _execute_move(
        self,
        action: OrganizeAction,
        session_id: str | None,
    ) -> OrganizeResult:
        """Execute a move action."""
        if not action.destination:
            return OrganizeResult(
                success=False,
                action=action,
                error="No destination specified",
            )

        source = action.file.path
        dest = action.destination

        # Check if file still exists
        if not source.exists():
            return OrganizeResult(
                success=False,
                action=action,
                error="Source file no longer exists",
            )

        # Skip if destination exists and strategy is skip
        if dest.exists() and self.config.settings.duplicates == "skip":
            return OrganizeResult(success=True, action=action)

        try:
            # Create destination directory
            dest.parent.mkdir(parents=True, exist_ok=True)

            # Move the file
            shutil.move(str(source), str(dest))

            # Record in history
            if self.history and session_id:
                self.history.record_move(
                    session_id=session_id,
                    source=source,
                    destination=dest,
                    category=action.category or "unknown",
                    method=action.method,
                )

            return OrganizeResult(success=True, action=action)

        except (OSError, shutil.Error) as e:
            return OrganizeResult(
                success=False,
                action=action,
                error=str(e),
            )

    def _execute_delete(self, action: OrganizeAction) -> OrganizeResult:
        """Execute a delete action."""
        source = action.file.path

        if not source.exists():
            return OrganizeResult(
                success=False,
                action=action,
                error="File no longer exists",
            )

        try:
            source.unlink()
            return OrganizeResult(success=True, action=action)
        except OSError as e:
            return OrganizeResult(
                success=False,
                action=action,
                error=str(e),
            )

    def organize(
        self,
        source_dir: Path,
        target_dir: Path | None = None,
        recursive: bool = False,
        dry_run: bool = False,
    ) -> tuple[list[OrganizeAction], OrganizeSummary | None]:
        """
        Organize files in a directory.

        Args:
            source_dir: Directory to organize
            target_dir: Where to move files (defaults to source_dir)
            recursive: Whether to scan subdirectories
            dry_run: If True, only plan without executing

        Returns:
            Tuple of (planned actions, execution summary or None if dry_run)
        """
        actions = self.plan(source_dir, target_dir, recursive)

        if dry_run:
            return actions, None

        summary = self.execute(actions, source_dir)
        return actions, summary


def organize_directory(
    source_dir: Path,
    config: Config | None = None,
    target_dir: Path | None = None,
    recursive: bool = False,
    dry_run: bool = False,
    enable_history: bool = True,
) -> tuple[list[OrganizeAction], OrganizeSummary | None]:
    """
    Convenience function to organize a directory.

    Args:
        source_dir: Directory to organize
        config: Configuration (uses default if None)
        target_dir: Where to move files (defaults to source_dir)
        recursive: Whether to scan subdirectories
        dry_run: If True, only plan without executing
        enable_history: Whether to track history for undo

    Returns:
        Tuple of (planned actions, execution summary or None if dry_run)
    """
    from zortify.config import load_config

    if config is None:
        config = load_config()

    history = None
    if enable_history and config.settings.enable_history:
        history = History(
            history_file=config.history_path,
            max_entries=config.settings.max_history,
        )

    organizer = Organizer(config, history)
    return organizer.organize(source_dir, target_dir, recursive, dry_run)
