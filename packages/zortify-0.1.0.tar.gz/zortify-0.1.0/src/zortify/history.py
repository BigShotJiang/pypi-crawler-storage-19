"""History tracking for undo functionality."""

import json
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path


@dataclass
class MoveOperation:
    """Record of a single file move operation."""

    source: str
    destination: str
    timestamp: str
    category: str
    method: str  # rule, extension, keyword, ai

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "MoveOperation":
        """Create from dictionary."""
        return cls(**data)


@dataclass
class OrganizeSession:
    """Record of a single organize operation (may contain multiple moves)."""

    session_id: str
    timestamp: str
    source_directory: str
    operations: list[MoveOperation]

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "source_directory": self.source_directory,
            "operations": [op.to_dict() for op in self.operations],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "OrganizeSession":
        """Create from dictionary."""
        return cls(
            session_id=data["session_id"],
            timestamp=data["timestamp"],
            source_directory=data["source_directory"],
            operations=[MoveOperation.from_dict(op) for op in data["operations"]],
        )


class History:
    """Manages history of file operations for undo functionality."""

    def __init__(self, history_file: Path, max_entries: int = 1000):
        """
        Initialize history manager.

        Args:
            history_file: Path to the history JSON file
            max_entries: Maximum number of sessions to keep
        """
        self.history_file = history_file
        self.max_entries = max_entries
        self._sessions: list[OrganizeSession] = []
        self._load()

    def _load(self) -> None:
        """Load history from file."""
        if not self.history_file.exists():
            self._sessions = []
            return

        try:
            with open(self.history_file, encoding="utf-8") as f:
                data = json.load(f)
                self._sessions = [OrganizeSession.from_dict(s) for s in data.get("sessions", [])]
        except (json.JSONDecodeError, KeyError, TypeError):
            self._sessions = []

    def _save(self) -> None:
        """Save history to file."""
        # Ensure parent directory exists
        self.history_file.parent.mkdir(parents=True, exist_ok=True)

        data = {
            "version": 1,
            "sessions": [s.to_dict() for s in self._sessions],
        }

        with open(self.history_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _generate_session_id(self) -> str:
        """Generate a unique session ID."""
        return datetime.now().strftime("%Y%m%d_%H%M%S_%f")

    def start_session(self, source_directory: Path) -> str:
        """
        Start a new organize session.

        Args:
            source_directory: The directory being organized

        Returns:
            Session ID
        """
        session_id = self._generate_session_id()
        session = OrganizeSession(
            session_id=session_id,
            timestamp=datetime.now().isoformat(),
            source_directory=str(source_directory),
            operations=[],
        )
        self._sessions.append(session)

        # Trim old sessions if needed
        while len(self._sessions) > self.max_entries:
            self._sessions.pop(0)

        return session_id

    def record_move(
        self,
        session_id: str,
        source: Path,
        destination: Path,
        category: str,
        method: str,
    ) -> None:
        """
        Record a file move operation.

        Args:
            session_id: The session ID
            source: Original file path
            destination: New file path
            category: Category the file was moved to
            method: Classification method used
        """
        session = self._get_session(session_id)
        if session is None:
            return

        operation = MoveOperation(
            source=str(source),
            destination=str(destination),
            timestamp=datetime.now().isoformat(),
            category=category,
            method=method,
        )
        session.operations.append(operation)

    def end_session(self, session_id: str) -> None:
        """
        End a session and save to disk.

        Args:
            session_id: The session ID to end
        """
        session = self._get_session(session_id)
        if session and len(session.operations) == 0:
            # Remove empty sessions
            self._sessions.remove(session)
        self._save()

    def _get_session(self, session_id: str) -> OrganizeSession | None:
        """Get a session by ID."""
        for session in self._sessions:
            if session.session_id == session_id:
                return session
        return None

    def get_last_session(self) -> OrganizeSession | None:
        """Get the most recent session."""
        if self._sessions:
            return self._sessions[-1]
        return None

    def get_sessions(self, count: int = 10) -> list[OrganizeSession]:
        """
        Get the most recent sessions.

        Args:
            count: Number of sessions to return

        Returns:
            List of sessions (most recent first)
        """
        return list(reversed(self._sessions[-count:]))

    def undo_session(self, session_id: str | None = None) -> list[tuple[Path, Path, bool]]:
        """
        Undo a session by reversing all its operations.

        Args:
            session_id: Session to undo (defaults to most recent)

        Returns:
            List of (source, dest, success) tuples showing what was undone
        """
        if session_id:
            session = self._get_session(session_id)
        else:
            session = self.get_last_session()

        if not session:
            return []

        results: list[tuple[Path, Path, bool]] = []

        # Undo operations in reverse order
        for operation in reversed(session.operations):
            source = Path(operation.destination)  # Current location
            dest = Path(operation.source)  # Original location

            success = False
            if source.exists():
                try:
                    # Ensure destination directory exists
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    source.rename(dest)
                    success = True
                except OSError:
                    pass

            results.append((source, dest, success))

        # Remove the session from history
        if session in self._sessions:
            self._sessions.remove(session)
            self._save()

        return results

    def undo_last_n(self, count: int = 1) -> list[tuple[str, list[tuple[Path, Path, bool]]]]:
        """
        Undo the last N sessions.

        Args:
            count: Number of sessions to undo

        Returns:
            List of (session_id, results) tuples
        """
        all_results: list[tuple[str, list[tuple[Path, Path, bool]]]] = []

        for _ in range(count):
            session = self.get_last_session()
            if not session:
                break

            results = self.undo_session(session.session_id)
            all_results.append((session.session_id, results))

        return all_results

    def clear(self) -> None:
        """Clear all history."""
        self._sessions = []
        self._save()

    @property
    def session_count(self) -> int:
        """Get the number of sessions in history."""
        return len(self._sessions)

    @property
    def total_operations(self) -> int:
        """Get the total number of operations across all sessions."""
        return sum(len(s.operations) for s in self._sessions)
