"""Smart File Organizer - AI-powered file organization CLI tool."""

__version__ = "0.1.0"
