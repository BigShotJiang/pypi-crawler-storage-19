"""CLI interface for Zortify."""

import os
import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

# Fix Windows console encoding issues
if sys.platform == "win32":
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')

from zortify import __version__
from zortify.ai import create_provider_with_fallback, get_available_providers
from zortify.config import get_config_path, init_config, load_config
from zortify.history import History
from zortify.organizer import OrganizeAction, Organizer
from zortify.scanner import get_directory_stats

app = typer.Typer(
    name="zortify",
    help="Zortify - AI-powered file organization",
    add_completion=False,
)
console = Console(force_terminal=True)


def _format_size(size_bytes: int) -> str:
    """Format size in human-readable format."""
    size: float = size_bytes
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def _display_plan(actions: list[OrganizeAction], verbose: bool = False) -> None:
    """Display planned actions in a table."""
    # Group actions by type
    moves = [a for a in actions if a.action == "move"]
    skips = [a for a in actions if a.action == "skip"]
    deletes = [a for a in actions if a.action == "delete"]

    if not actions:
        console.print("[yellow]No files to organize.[/yellow]")
        return

    # Summary panel
    summary = f"[green]{len(moves)}[/green] to move, [yellow]{len(skips)}[/yellow] skipped"
    if deletes:
        summary += f", [red]{len(deletes)}[/red] to delete"
    console.print(Panel(summary, title="Plan Summary", border_style="blue"))

    if moves:
        table = Table(title="Files to Move", show_lines=verbose)
        table.add_column("File", style="white", no_wrap=not verbose)
        table.add_column("Category", style="cyan")
        table.add_column("Destination", style="green")
        if verbose:
            table.add_column("Method", style="dim")
            table.add_column("Reason", style="dim")

        for action in moves[:50]:  # Limit to first 50
            dest_rel = action.destination.name if action.destination else ""
            dest_dir = action.destination.parent.name if action.destination else ""
            dest_display = f"{dest_dir}/{dest_rel}"

            if verbose:
                reasoning = action.reasoning
                if len(reasoning) > 40:
                    reasoning = reasoning[:40] + "..."
                table.add_row(
                    action.file.name,
                    action.category or "-",
                    dest_display,
                    action.method,
                    reasoning,
                )
            else:
                table.add_row(action.file.name, action.category or "-", dest_display)

        console.print(table)

        if len(moves) > 50:
            console.print(f"[dim]... and {len(moves) - 50} more files[/dim]")

    if verbose and skips:
        console.print("\n[yellow]Skipped files:[/yellow]")
        for action in skips[:10]:
            console.print(f"  [dim]{action.file.name}[/dim] - {action.reasoning}")
        if len(skips) > 10:
            console.print(f"  [dim]... and {len(skips) - 10} more[/dim]")


def _display_results(summary, verbose: bool = False) -> None:
    """Display execution results."""
    if summary.errors == 0:
        status = "[green]SUCCESS[/green]"
    else:
        status = "[yellow]COMPLETED WITH ERRORS[/yellow]"

    result_text = (
        f"Status: {status}\n"
        f"Files moved: [green]{summary.moved}[/green]\n"
        f"Files skipped: [yellow]{summary.skipped}[/yellow]\n"
    )
    if summary.deleted:
        result_text += f"Files deleted: [red]{summary.deleted}[/red]\n"
    if summary.errors:
        result_text += f"Errors: [red]{summary.errors}[/red]\n"

    border_style = "green" if summary.errors == 0 else "yellow"
    console.print(Panel(result_text.strip(), title="Results", border_style=border_style))

    if verbose and summary.errors > 0:
        console.print("\n[red]Errors:[/red]")
        for result in summary.actions:
            if not result.success and result.error:
                console.print(f"  [red]{result.action.file.name}[/red]: {result.error}")


@app.command()
def organize(
    path: Path = typer.Argument(
        Path("."),
        help="Directory to organize",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Preview changes without moving files",
    ),
    config_file: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to config file",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show detailed output",
    ),
    recursive: bool = typer.Option(
        False,
        "--recursive",
        "-r",
        help="Include subdirectories",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt",
    ),
) -> None:
    """
    Organize files in a directory using AI-powered classification.

    Examples:
        zort organize ~/Downloads
        zort organize ~/Downloads --dry-run
        zort organize . --config my-config.yaml
    """
    console.print(Panel(
        f"[bold]Target:[/bold] {path}\n"
        f"[bold]Mode:[/bold] {'DRY RUN' if dry_run else 'EXECUTE'}",
        title="Zort",
        border_style="blue",
    ))

    # Load configuration
    try:
        config = load_config(config_file)
    except Exception as e:
        console.print(f"[red]Error loading config:[/red] {e}")
        raise typer.Exit(1)

    # Initialize history
    history = None
    if config.settings.enable_history and not dry_run:
        history = History(
            history_file=config.history_path,
            max_entries=config.settings.max_history,
        )

    # Create organizer
    organizer = Organizer(config, history)

    # Plan organization
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Scanning files...", total=None)
        actions = organizer.plan(path, recursive=recursive)

    # Display plan
    _display_plan(actions, verbose=verbose)

    moves = [a for a in actions if a.action == "move"]
    if not moves:
        console.print("\n[yellow]Nothing to organize.[/yellow]")
        return

    if dry_run:
        console.print("\n[yellow]DRY RUN - No files were moved.[/yellow]")
        console.print("[dim]Remove --dry-run flag to execute.[/dim]")
        return

    # Confirm execution
    if not yes:
        confirm = typer.confirm(f"\nProceed with moving {len(moves)} files?")
        if not confirm:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(0)

    # Execute
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Moving files...", total=None)
        summary = organizer.execute(actions, path)

    # Display results
    _display_results(summary, verbose=verbose)

    if summary.session_id:
        console.print(f"\n[dim]Session ID: {summary.session_id}[/dim]")
        console.print("[dim]Use 'zort undo' to revert this operation.[/dim]")


@app.command()
def undo(
    steps: int = typer.Option(
        1,
        "--steps",
        "-s",
        help="Number of operations to undo",
        min=1,
    ),
    all_ops: bool = typer.Option(
        False,
        "--all",
        help="Undo all operations in history",
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt",
    ),
) -> None:
    """
    Undo previous file organization operations.

    Examples:
        zort undo
        zort undo --steps 5
        zort undo --all
    """
    # Load config for history path
    config = load_config()

    history = History(
        history_file=config.history_path,
        max_entries=config.settings.max_history,
    )

    if history.session_count == 0:
        console.print("[yellow]No operations to undo.[/yellow]")
        return

    # Determine how many to undo
    count = history.session_count if all_ops else min(steps, history.session_count)

    # Show what will be undone
    sessions = history.get_sessions(count)
    console.print("\n[bold]Sessions to undo:[/bold]")
    for session in sessions:
        num_ops = len(session.operations)
        console.print(f"  - {session.session_id}: {num_ops} files from {session.source_directory}")

    total_ops = sum(len(s.operations) for s in sessions)

    if not yes:
        confirm = typer.confirm(f"\nUndo {count} session(s) ({total_ops} files)?")
        if not confirm:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(0)

    # Execute undo
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Undoing operations...", total=None)
        results = history.undo_last_n(count)

    # Display results
    total_success = 0
    total_failed = 0

    for session_id, ops in results:
        successes = sum(1 for _, _, success in ops if success)
        failures = len(ops) - successes
        total_success += successes
        total_failed += failures
        console.print(
            f"  Session {session_id}: [green]{successes}[/green] restored, "
            f"[red]{failures}[/red] failed"
        )

    console.print(f"\n[green]Undo complete![/green] {total_success} files restored.")
    if total_failed > 0:
        console.print(f"[red]{total_failed} files could not be restored.[/red]")


@app.command(name="config")
def config_cmd(
    init: bool = typer.Option(
        False,
        "--init",
        help="Create default config file",
    ),
    edit: bool = typer.Option(
        False,
        "--edit",
        help="Open config in default editor",
    ),
    show: bool = typer.Option(
        False,
        "--show",
        help="Display current configuration",
    ),
    path_only: bool = typer.Option(
        False,
        "--path",
        help="Show config file path",
    ),
) -> None:
    """
    Manage configuration file.

    Examples:
        zort config --init
        zort config --show
        zort config --edit
    """
    config_path = get_config_path()

    if path_only:
        console.print(str(config_path))
        return

    if init:
        if config_path.exists():
            overwrite = typer.confirm(f"Config already exists at {config_path}. Overwrite?")
            if not overwrite:
                console.print("[yellow]Cancelled.[/yellow]")
                return

        created_path = init_config(config_path)
        console.print(f"[green]Config created at:[/green] {created_path}")
        console.print("[dim]Edit this file to customize categories and rules.[/dim]")
        return

    if show:
        if not config_path.exists():
            console.print(f"[yellow]No config file found at {config_path}[/yellow]")
            console.print("[dim]Run 'zort config --init' to create one.[/dim]")
            return

        config = load_config()
        console.print(Panel(f"[bold]Config file:[/bold] {config_path}", border_style="blue"))

        # AI settings
        console.print(f"\n[bold]AI Provider:[/bold] {config.ai.provider}")
        if config.ai.provider == "ollama":
            console.print(f"  Model: {config.ai.ollama_model}")
            console.print(f"  Host: {config.ai.ollama_host}")

        # Categories
        console.print(f"\n[bold]Categories:[/bold] {len(config.categories)}")
        for name, cat in list(config.categories.items())[:5]:
            exts = ", ".join(cat.extensions[:5])
            if len(cat.extensions) > 5:
                exts += f" (+{len(cat.extensions) - 5} more)"
            console.print(f"  {name}: {exts}")
        if len(config.categories) > 5:
            console.print(f"  [dim]... and {len(config.categories) - 5} more categories[/dim]")

        # Rules
        console.print(f"\n[bold]Custom Rules:[/bold] {len(config.rules)}")
        for rule in config.rules[:3]:
            console.print(f"  {rule.pattern} -> {rule.category or rule.action}")
        if len(config.rules) > 3:
            console.print(f"  [dim]... and {len(config.rules) - 3} more rules[/dim]")

        return

    if edit:
        if not config_path.exists():
            create = typer.confirm("No config file found. Create one?")
            if create:
                init_config(config_path)
            else:
                return

        # Open in default editor
        editor = os.environ.get("EDITOR", "notepad" if sys.platform == "win32" else "nano")
        try:
            subprocess.run([editor, str(config_path)])
        except FileNotFoundError:
            console.print(f"[red]Could not open editor '{editor}'[/red]")
            console.print(f"[dim]Edit manually: {config_path}[/dim]")
        return

    # Default: show help
    console.print("Use --init, --show, --edit, or --path")
    console.print(f"\nConfig location: {config_path}")


@app.command()
def status(
    path: Path = typer.Argument(
        Path("."),
        help="Directory to analyze",
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
    ),
    recursive: bool = typer.Option(
        False,
        "--recursive",
        "-r",
        help="Include subdirectories",
    ),
) -> None:
    """
    Show statistics about files in a directory.

    Examples:
        zort status ~/Downloads
    """
    console.print(Panel(
        f"[bold]Analyzing:[/bold] {path}",
        title="File Statistics",
        border_style="blue",
    ))

    # Get statistics
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Scanning...", total=None)
        stats = get_directory_stats(path, recursive=recursive)

    # Load config for category mapping
    config = load_config()

    # Build extension to category map
    ext_to_cat: dict[str, str] = {}
    for cat_name, category in config.categories.items():
        for ext in category.extensions:
            ext_to_cat[ext.lower()] = cat_name

    # Count files by category
    category_stats: dict[str, dict] = {}
    for ext, count in stats["extensions"].items():
        cat = ext_to_cat.get(ext.lower(), "Other")
        if cat not in category_stats:
            category_stats[cat] = {"count": 0}
        category_stats[cat]["count"] += count

    # Display table
    table = Table(title=f"Files by Category ({stats['total_files']} total)")
    table.add_column("Category", style="cyan")
    table.add_column("Count", justify="right", style="green")
    table.add_column("Extensions", style="dim")

    # Sort by count
    sorted_cats = sorted(category_stats.items(), key=lambda x: x[1]["count"], reverse=True)

    for cat_name, data in sorted_cats:
        # Get extensions for this category
        if cat_name == "Other":
            cat_exts = [e for e in stats["extensions"].keys() if e not in ext_to_cat]
            exts_str = ", ".join(cat_exts[:5])
            if len(cat_exts) > 5:
                exts_str += f" (+{len(cat_exts) - 5})"
        else:
            cat_info = config.categories.get(cat_name)
            if cat_info:
                exts_str = ", ".join(cat_info.extensions[:5])
                if len(cat_info.extensions) > 5:
                    exts_str += f" (+{len(cat_info.extensions) - 5})"
            else:
                exts_str = ""

        table.add_row(cat_name, str(data["count"]), exts_str)

    console.print(table)

    # Summary
    console.print(f"\n[bold]Total size:[/bold] {_format_size(stats['total_size'])}")
    if stats["oldest"]:
        console.print(f"[bold]Oldest file:[/bold] {stats['oldest'].strftime('%Y-%m-%d')}")
    if stats["newest"]:
        console.print(f"[bold]Newest file:[/bold] {stats['newest'].strftime('%Y-%m-%d')}")


@app.command()
def version() -> None:
    """Show version information."""
    console.print(f"[bold blue]Zort[/bold blue] v{__version__}")
    console.print("[dim]https://github.com/zeerakzubair/zort[/dim]")


@app.command()
def ai(
    check: bool = typer.Option(
        True,
        "--check",
        help="Check AI provider availability",
    ),
    test: str | None = typer.Option(
        None,
        "--test",
        "-t",
        help="Test classification with a filename",
    ),
) -> None:
    """
    Check AI provider status and test classification.

    Examples:
        zort ai                           # Check available providers
        zort ai --test "invoice_2024.pdf" # Test classification
    """
    config = load_config()

    console.print(Panel(
        f"[bold]Configured provider:[/bold] {config.ai.provider}",
        title="AI Configuration",
        border_style="blue",
    ))

    # Check available providers
    console.print("\n[bold]Provider Status:[/bold]")
    providers = get_available_providers(config.ai)

    table = Table()
    table.add_column("Provider", style="cyan")
    table.add_column("Status", justify="center")
    table.add_column("Notes", style="dim")

    for name, available in providers:
        if name == "ollama":
            notes = f"Model: {config.ai.ollama_model}"
        elif name == "groq":
            notes = "Free tier" if config.ai.groq_api_key else "API key not set"
        elif name == "openai":
            notes = "Paid" if config.ai.openai_api_key else "API key not set"
        else:
            notes = "Heuristic fallback"

        status = "[green]Available[/green]" if available else "[red]Unavailable[/red]"
        table.add_row(name, status, notes)

    console.print(table)

    # Test classification if requested
    if test:
        console.print(f"\n[bold]Testing classification:[/bold] {test}")

        try:
            provider = create_provider_with_fallback(config.ai)
            console.print(f"[dim]Using provider: {provider.name}[/dim]")

            from pathlib import Path
            ext = Path(test).suffix

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                progress.add_task("Classifying...", total=None)
                result = provider.classify(
                    filename=test,
                    extension=ext,
                    categories=list(config.categories.keys()),
                )

            console.print("\n[bold]Result:[/bold]")
            console.print(f"  Category: [cyan]{result.category}[/cyan]")
            console.print(f"  Confidence: [green]{result.confidence:.0%}[/green]")
            console.print(f"  Reasoning: {result.reasoning}")

        except Exception as e:
            console.print(f"[red]Classification failed:[/red] {e}")


if __name__ == "__main__":
    app()
