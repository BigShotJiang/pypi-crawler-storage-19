"""Entry point for running as python -m sfo."""

from zortify.cli import app

if __name__ == "__main__":
    app()
