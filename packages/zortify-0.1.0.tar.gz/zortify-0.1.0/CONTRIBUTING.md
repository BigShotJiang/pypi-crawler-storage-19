# Contributing to Zort

Thank you for your interest in contributing! This document provides guidelines for contributing to the project.

## Getting Started

### Prerequisites

- Python 3.10 or higher
- Git

### Development Setup

1. Fork and clone the repository:
   ```bash
   git clone https://github.com/zeerakzubair/smart-file-organizer.git
   cd smart-file-organizer
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install development dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

4. Run tests to verify setup:
   ```bash
   pytest
   ```

## Development Workflow

### Code Style

We use [Ruff](https://github.com/astral-sh/ruff) for linting and formatting:

```bash
# Check for issues
ruff check src/ tests/

# Auto-fix issues
ruff check --fix src/ tests/

# Format code
ruff format src/ tests/
```

### Type Checking

We use [mypy](https://mypy.readthedocs.io/) for static type checking:

```bash
mypy src/zort
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=zort

# Run specific test file
pytest tests/test_classifier.py

# Run with verbose output
pytest -v
```

### Testing AI Providers

To test AI providers locally:

1. **Ollama** (recommended):
   ```bash
   # Install Ollama
   # Then pull a model
   ollama pull phi3

   # Test it
   zort ai --test "invoice_2024.pdf"
   ```

2. **Groq** (free tier):
   ```bash
   # Set API key
   export GROQ_API_KEY=your_key_here

   # Update config
   zort config --edit  # Change provider to "groq"
   ```

## Making Changes

### Branch Naming

- `feature/description` - New features
- `fix/description` - Bug fixes
- `docs/description` - Documentation changes
- `refactor/description` - Code refactoring

### Commit Messages

Follow conventional commits:

```
type(scope): description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting
- `refactor`: Code restructuring
- `test`: Adding tests
- `chore`: Maintenance

Examples:
```
feat(ai): add Anthropic provider support
fix(scanner): handle permission errors gracefully
docs(readme): add installation instructions
```

### Pull Request Process

1. Create a feature branch from `main`
2. Make your changes
3. Add/update tests as needed
4. Update documentation if needed
5. Run linting and tests
6. Push and create a pull request

## Adding New Features

### Adding a New AI Provider

1. Create a new file in `src/zort/ai/`:
   ```python
   # src/zort/ai/new_provider.py
   from zort.ai.base import AIProvider, ClassificationResult

   class NewProvider(AIProvider):
       @property
       def name(self) -> str:
           return "new_provider"

       def is_available(self) -> bool:
           # Check if provider can be used
           pass

       def classify(self, filename, extension, content_preview=None, categories=None):
           # Implement classification
           pass
   ```

2. Add to factory in `src/zort/ai/factory.py`
3. Add configuration options to `src/zort/config.py`
4. Update `config.example.yaml`
5. Add tests

### Adding New File Categories

1. Update `DEFAULT_CATEGORIES` in `src/zort/config.py`
2. Update `config.example.yaml` with new category
3. Add tests for the new category

## Reporting Issues

### Bug Reports

Please include:
- Python version
- OS and version
- Steps to reproduce
- Expected vs actual behavior
- Error messages (if any)

### Feature Requests

Please include:
- Use case description
- Proposed solution (if any)
- Alternatives considered

## Code of Conduct

- Be respectful and inclusive
- Focus on constructive feedback
- Help others learn and grow

## Questions?

- Open an issue for questions
- Check existing issues before creating new ones

Thank you for contributing!
