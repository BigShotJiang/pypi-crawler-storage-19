from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel

from pantoqa_bridge.service.uiautomator_action import LocalBridgeService

router = APIRouter()


class Action(BaseModel):
  action_type: str
  params: dict | None = None


class ActionRequestModel(BaseModel):
  id: str
  action: Action
  device_serial_no: str | None = None


class ActionResponseModel(BaseModel):
  id: str
  type: str
  data: Any | None = None


@router.post('/perform-action', response_model=ActionResponseModel)
async def perform_action(request: ActionRequestModel):
  action = request.action
  with LocalBridgeService(request.device_serial_no) as srv:
    result = _process_action(srv, action)
  response = ActionResponseModel(id=request.id, type="driver_action_response", data=result)
  return response


def _process_action(srv: LocalBridgeService, action: Action):
  action_type = action.action_type
  if action_type == "screenshot":
    return srv.take_screenshot()
  if action_type == "click":
    params = action.params
    assert params, "params is not present."
    srv.click(params['x'], params['y'])
    return
  if action_type == "long_click":
    params = action.params
    assert params, "params is not present."
    srv.long_click(params['x'], params['y'])
    return
  if action_type == "get_os_version":
    return srv.get_os_version()
  if action_type == "get_device_model":
    return srv.get_device_model()
  if action_type == "get_device_resolution":
    return srv.device_resolution()
  if action_type == "get_ui_dump":
    return srv.get_ui_dump()
  if action_type == "get_current_app_activity":
    return srv.get_current_app_activity()
  if action_type == "get_main_activity":
    params = action.params
    assert params, "params is not present."
    return srv.get_main_activity(params['package_name'])
  if action_type == "get_all_packages":
    return srv.get_all_packages()
  if action_type == "open_app":
    params = action.params
    assert params, "params is not present."
    srv.open_app(params['package_name'], params['activity_name'])
    return
  if action_type == "close_keyboard":
    srv.close_keyboard()
    return
  if action_type == "press_enter":
    srv.press_enter()
    return
  if action_type == "go_back":
    srv.go_back()
    return
  if action_type == "is_keyboard_open":
    return srv.is_keyboard_open()
  if action_type == "goto_home":
    srv.goto_home()
    return
  if action_type == "clear_all_inputs":
    srv.clear_all_inputs()
    return
  if action_type == "backspace":
    srv.backspace()
    return
  if action_type == "input_text":
    params = action.params
    assert params, "params is not present."
    srv.input_text(params['text'])
    return
  if action_type == "swipe":
    params = action.params
    assert params, "params is not present."
    srv.swipe(params['x1'], params['y1'], params['x2'], params['y2'])
    return
  if action_type == "long_press":
    params = action.params
    assert params, "params is not present."
    srv.long_press(params['x'], params['y'])
    return
  if action_type == "get_oem_name":
    return srv.get_oem_name()
  if action_type == "get_device_name":
    return srv.get_device_name()
  if action_type == "get_os_build_version":
    return srv.get_os_build_version()
  if action_type == "stop":
    return srv.stop()

  raise ValueError(f"Unsupported action type: {action_type}")
