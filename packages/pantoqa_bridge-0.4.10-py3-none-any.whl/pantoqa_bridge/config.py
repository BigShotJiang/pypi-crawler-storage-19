import os
import platform
from importlib.resources import files

from dotenv import load_dotenv

load_dotenv(
  dotenv_path=".envrc",
  verbose=True,
)

PKG_NAME = "pantoqa_bridge"


def resource_path(path: str) -> str:
  try:
    return str(files(PKG_NAME).joinpath(path))
  except Exception:
    return path


SCRCPY_SERVER_BIN = resource_path("scrcpy-server-v3.3.1")
SCRCPY_SERVER_VERSION = "3.3.1"
SCRCPY_SOCKET_PORT = 27888

IS_WINDOWS = platform.system() == "Windows"

SERVER_HOST = os.getenv("SERVER_HOST") or ("0.0.0.0" if not IS_WINDOWS else "127.0.0.1")
SERVER_PORT = int(os.getenv("SERVER_PORT") or "6565")

APPIUM_SERVER_HOST = os.getenv("APPIUM_SERVER_HOST") or SERVER_HOST
APPIUM_SERVER_PORT = int(os.getenv("APPIUM_SERVER_PORT") or "6566")
APPIUM_SERVER_URL = f"http://{APPIUM_SERVER_HOST}:{APPIUM_SERVER_PORT}"

MAESTRO_BIN = "maestro"
