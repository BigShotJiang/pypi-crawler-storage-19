import base64
from io import BytesIO

import uiautomator2 as u2  # type: ignore
from adbutils import adb  # type: ignore


class LocalBridgeService():

  def __init__(self, device_serial: str | None = None):
    self.uiautomator = u2.connect(device_serial)
    self.adb = adb.device(device_serial)

  def __enter__(self):
    self.uiautomator.start_uiautomator()
    return self

  def __exit__(self, exc_type, exc, tb):
    self.stop()
    return False

  def stop(self):
    self.uiautomator.stop_uiautomator()

  def take_screenshot(self) -> str:
    image = self.uiautomator.screenshot()
    buf = BytesIO()
    image.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")

  def click(self, x: int, y: int):
    self.uiautomator.click(x, y)

  def long_click(self, x: int, y: int):
    self.uiautomator.long_click(x, y)

  def get_os_version(self) -> str:
    return str(self.uiautomator.device_info["version"])

  def get_device_model(self) -> str:
    return self.uiautomator.device_info["model"]

  def device_resolution(self) -> dict:
    w, h = self.uiautomator.window_size()
    return {"width": w, "height": h}

  def get_ui_dump(self) -> str:
    xml = self.uiautomator.dump_hierarchy()
    return xml

  def get_current_app_activity(self) -> str:
    current_app = self.uiautomator.app_current()
    package = current_app['package']
    activity = current_app['activity']
    return f"{package}/{activity}"

  def get_main_activity(self, package_name: str) -> str | None:
    result = self.adb.shell(f"cmd package resolve-activity --brief {package_name}")

    for line in result.splitlines():
      if line.startswith(package_name + "/"):
        return line.replace(package_name + "/", "", 1)

    return None

  def get_all_packages(self) -> list[str]:
    packages = self.uiautomator.app_list()
    return packages

  def open_app(self, package_name: str, activity_name: str = ".MainActivity"):
    self.uiautomator.app_start(package_name=package_name)

  def close_keyboard(self):
    self.uiautomator.hide_keyboard()

  def press_enter(self):
    self.uiautomator.keyevent("66")

  def go_back(self):
    self.uiautomator.press("back")

  def is_keyboard_open(self) -> bool:
    result = self.adb.shell("dumpsys input_method")
    return "mInputShown=true" in result

  def goto_home(self):
    self.uiautomator.press("home")

  def clear_all_inputs(self):
    self.uiautomator.clear_text()

  def backspace(self):
    self.uiautomator.keyevent("67")

  def input_text(self, text: str):
    self.uiautomator.send_keys(text)

  def swipe(self, x1: int, y1: int, x2: int, y2: int):
    self.uiautomator.swipe(x1, y1, x2, y2)

  def long_press(self, x: int, y: int):
    self.uiautomator.long_click(x, y)

  def get_oem_name(self) -> str:
    info = self.uiautomator.device_info
    return info["brand"]

  def get_device_name(self) -> str:
    info = self.uiautomator.device_info
    return info["model"]

  def get_os_build_version(self) -> str:
    info = self.uiautomator.device_info
    return str(info["sdk"])
