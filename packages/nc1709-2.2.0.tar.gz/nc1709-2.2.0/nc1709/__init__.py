"""
NC1709 CLI - Your AI coding partner that brings your code to life
Version: 2.1.5
Author: Lafzusa Corp
License: Proprietary
"""

__version__ = "2.1.7"
__author__ = "Lafzusa Corp"

from .cli import main

__all__ = ["main"]
