.. _spkg_cddlib:

cddlib: Double description method for polyhedral representation conversion
==========================================================================

Description
-----------

The C-library cddlib is a C implementation of the Double Description
Method of Motzkin et al. for generating all vertices (i.e. extreme
points) and extreme rays of a general convex polyhedron in R^d given by
a system of linear inequalities:

   P = { x=(x1, ..., xd)^T : b - A x >= 0 }

where A is a given m x d real matrix, b is a given m-vector and 0 is the
m-vector of all zeros.

The program can be used for the reverse operation (i.e. convex hull
computation). This means that one can move back and forth between an
inequality representation and a generator (i.e. vertex and ray)
representation of a polyhedron with cdd. Also, cdd can solve a linear
programming problem, i.e. a problem of maximizing and minimizing a
linear function over P.

License
-------

GPL v2


Upstream Contact
----------------

https://github.com/cddlib/cddlib


Type
----

standard


Dependencies
------------

- $(MP_LIBRARY)

Version Information
-------------------

package-version.txt::

    0.94n

See https://repology.org/project/cddlib/versions

Installation commands
---------------------

.. tab:: Sage distribution:

   .. CODE-BLOCK:: bash

       $ sage -i cddlib

.. tab:: Arch Linux:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S cddlib

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install cddlib

.. tab:: Debian/Ubuntu:

   .. CODE-BLOCK:: bash

       $ sudo apt-get install libcdd-dev libcdd-tools

.. tab:: Fedora/Redhat/CentOS:

   .. CODE-BLOCK:: bash

       $ sudo dnf install cddlib cddlib-devel

.. tab:: FreeBSD:

   .. CODE-BLOCK:: bash

       $ sudo pkg install math/cddlib

.. tab:: Gentoo Linux:

   .. CODE-BLOCK:: bash

       $ sudo emerge sci-libs/cddlib\[tools\]

.. tab:: Homebrew:

   .. CODE-BLOCK:: bash

       $ brew install cddlib

.. tab:: MacPorts:

   .. CODE-BLOCK:: bash

       $ sudo port install cddlib

.. tab:: mingw-w64:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S ${MINGW_PACKAGE_PREFIX}-cddlib

.. tab:: Nixpkgs:

   .. CODE-BLOCK:: bash

       $ nix-env -f \'\<nixpkgs\>\' --install --attr cddlib

.. tab:: openSUSE:

   .. CODE-BLOCK:: bash

       $ sudo zypper install cddlib-tools pkgconfig\(cddlib\)

.. tab:: Void Linux:

   .. CODE-BLOCK:: bash

       $ sudo xbps-install cddlib-devel


If the system package is installed, ``./configure`` will check if it can be used.
