"""
Tests for pdfx package.
"""
