"""ModelResult - Typed wrapper for model run results.

Provides intuitive property access to model outputs instead of complex dict navigation.

Example:
    >>> result = Model("fal-ai/hunyuan-video").run({"prompt": "A cat"})
    >>> result.video.url      # Instead of result["outputs"]["video"]["data"][0]["url"]
    >>> result.video.width    # Direct property access
    >>> result.status         # Run metadata
"""

from typing import Any

from .types import Audio, Image, Video


class ModelResult:
    """Wrapper for model run results with typed accessors.

    Provides convenient property access to outputs while maintaining
    backward compatibility with dict access.

    Attributes:
        video: Video output (Video | None)
        image: Image output (Image | None)
        audio: Audio output (Audio | None)
        text: Text output (str | None)
        status: Run status (str)
        run_number: Run number (int | None)
        outputs: Raw outputs dict

    Example:
        >>> result = model.run({"prompt": "A cat"})
        >>> if result.video:
        ...     print(result.video.url)
        >>> # Backward compatible dict access
        >>> result["status"]  # "completed"
    """

    def __init__(self, raw: dict[str, Any]):
        """Initialize ModelResult from raw run dict.

        Args:
            raw: Raw run result dict from API with keys like
                 "run_number", "status", "outputs", etc.
        """
        self._raw = raw
        # Handle outputs being None or missing
        self._outputs = raw.get("outputs") or {}

    @property
    def video(self) -> Video | None:
        """Extract video from outputs.

        Returns:
            Video object with url, width, height, duration_seconds,
            or None if no video output.
        """
        v = self._outputs.get("video")
        if v and isinstance(v, dict) and "url" in v:
            return Video(
                url=v.get("url", ""),
                width=v.get("width"),
                height=v.get("height"),
                duration_seconds=v.get("duration_seconds"),
                format=v.get("format"),
            )
        return None

    @property
    def image(self) -> Image | None:
        """Extract image from outputs.

        Handles both singular "image" key and plural "images" array.

        Returns:
            Image object with url, width, height,
            or None if no image output.
        """
        img = self._outputs.get("image")
        # Handle plural "images" array
        if not img:
            images = self._outputs.get("images")
            if images and isinstance(images, list) and len(images) > 0:
                img = images[0]
        if img and isinstance(img, dict) and "url" in img:
            return Image(
                url=img.get("url", ""),
                width=img.get("width"),
                height=img.get("height"),
                format=img.get("format"),
            )
        return None

    @property
    def audio(self) -> Audio | None:
        """Extract audio from outputs.

        Returns:
            Audio object with url, duration_seconds,
            or None if no audio output.
        """
        a = self._outputs.get("audio")
        if a and isinstance(a, dict) and "url" in a:
            return Audio(
                url=a.get("url", ""),
                duration_seconds=a.get("duration_seconds"),
                format=a.get("format"),
            )
        return None

    @property
    def text(self) -> str | None:
        """Extract text from various possible output keys.

        Checks keys in order: results, output, text, response, content.

        Returns:
            Text string or None if no text output.
        """
        for key in ["results", "output", "text", "response", "content"]:
            if key in self._outputs:
                val = self._outputs[key]
                # Handle primitive wrapper: {"_type": "primitive", "value": "..."}
                if isinstance(val, dict) and val.get("_type") == "primitive":
                    return val.get("value")
                return val if isinstance(val, str) else str(val)
        return None

    # Metadata accessors
    @property
    def status(self) -> str:
        """Run status (pending, running, completed, failed, cancelled)."""
        return self._raw.get("status", "")

    @property
    def run_number(self) -> int | None:
        """Run number within the model."""
        return self._raw.get("run_number")

    @property
    def error(self) -> str | None:
        """Error message if run failed."""
        return self._raw.get("error_message") or self._raw.get("error")

    @property
    def outputs(self) -> dict[str, Any]:
        """Raw outputs dictionary for advanced access."""
        return self._outputs

    # Backward compatibility with dict access
    def __getitem__(self, key: str) -> Any:
        """Allow dict-style access: result['status']."""
        return self._raw[key]

    def __contains__(self, key: str) -> bool:
        """Allow 'in' checks: 'status' in result."""
        return key in self._raw

    def get(self, key: str, default: Any = None) -> Any:
        """Dict-style get with default: result.get('status', 'unknown')."""
        return self._raw.get(key, default)

    def keys(self):
        """Return raw dict keys."""
        return self._raw.keys()

    def values(self):
        """Return raw dict values."""
        return self._raw.values()

    def items(self):
        """Return raw dict items."""
        return self._raw.items()

    def __repr__(self) -> str:
        """String representation."""
        return f"ModelResult(status='{self.status}', run_number={self.run_number})"
