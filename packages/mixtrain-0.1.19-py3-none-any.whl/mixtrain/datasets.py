"""Dataset reference system for convenient dataset access.

This module provides a Dataset proxy class that makes it easy to reference
and interact with datasets in a workspace.

Example:
    >>> from mixtrain import get_dataset
    >>> dataset = get_dataset("my-dataset")
    >>> print(dataset.metadata)
    >>> df = dataset.to_pandas()
"""

from typing import Any, Dict, List, Optional

from .client import MixClient
from .helpers import validate_resource_name


class Dataset:
    """Proxy class for convenient dataset access and operations.

    This class wraps MixClient dataset operations and provides a clean,
    object-oriented interface for working with datasets.

    Usage:
        # Reference an existing dataset (lazy, no API call)
        dataset = Dataset("training-data")
        df = dataset.to_pandas()  # API call happens here

        # Create a new dataset from file
        dataset = Dataset.create_from_file("new-data", "data.csv")

    Args:
        name: Name of the dataset
        client: Optional MixClient instance (creates new one if not provided)
        _response: Optional cached response from creation

    Attributes:
        name: Dataset name
        client: MixClient instance for API operations
    """

    def __init__(
        self,
        name: str,
        client: Optional[MixClient] = None,
        _response: Optional[Dict[str, Any]] = None,
    ):
        """Initialize Dataset proxy.

        Args:
            name: Name of the dataset
            client: Optional MixClient instance (creates new one if not provided)
            _response: Optional cached response from creation

        Raises:
            ValueError: If name is invalid (must be lowercase alphanumeric with hyphens/underscores)
        """
        validate_resource_name(name, "dataset")
        self.name = name
        self.client = client or MixClient()
        self._response = _response
        self._metadata: Optional[Dict[str, Any]] = None

    @classmethod
    def create_from_file(
        cls,
        name: str,
        file_path: str,
        description: Optional[str] = None,
        column_types: Optional[Dict[str, str]] = None,
        provider_type: Optional[str] = None,
        client: Optional[MixClient] = None,
    ) -> "Dataset":
        """Create a new dataset from a file.

        Args:
            name: Name for the dataset
            file_path: Path to the file to upload
            description: Optional description
            column_types: Optional dict mapping column names to display types.
                Valid types: image, video, audio, text, 3d, embedding
            provider_type: Optional provider type (defaults to apache_iceberg)
            client: Optional MixClient instance

        Returns:
            Dataset proxy for the created dataset

        Example:
            >>> dataset = Dataset.create_from_file("my-data", "data.csv")
            >>> # With column types
            >>> dataset = Dataset.create_from_file(
            ...     "my-data",
            ...     "data.csv",
            ...     column_types={"image_url": "image", "audio_path": "audio"}
            ... )
        """
        import json

        if client is None:
            client = MixClient()

        if not provider_type:
            provider_type = "apache_iceberg"

        # Use form data fields instead of headers
        data: Dict[str, str] = {}
        if description:
            data["description"] = description
        if column_types:
            data["column_types"] = json.dumps(column_types)

        with open(file_path, "rb") as f:
            files = {"file": (file_path.split("/")[-1], f, "application/octet-stream")}
            response = client._make_request(
                "POST",
                f"/lakehouse/workspaces/{client._workspace_name}/tables/{name}?provider_type={provider_type}",
                files=files,
                data=data if data else None,
            )
        return cls(name=name, client=client, _response=response.json())

    @property
    def metadata(self) -> Dict[str, Any]:
        """Get dataset metadata (cached after first access).

        Returns:
            Dataset metadata including name, description, row count, etc.

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> print(dataset.metadata["row_count"])
        """
        if self._metadata is None:
            if self._response is not None:
                self._metadata = self._response
            else:
                self._metadata = self.client.get_dataset_metadata(self.name)
        return self._metadata

    @property
    def description(self) -> str:
        """Get dataset description.

        Returns:
            Dataset description string
        """
        return self.metadata.get("description", "")

    @property
    def row_count(self) -> Optional[int]:
        """Get dataset row count.

        Returns:
            Number of rows in the dataset, or None if unknown
        """
        return self.metadata.get("row_count")

    @property
    def detailed_metadata(self) -> Dict[str, Any]:
        """Get detailed metadata including column types.

        Returns:
            Detailed metadata dict including schema, column_types, snapshots, etc.

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> print(dataset.detailed_metadata["column_types"])
        """
        return self.client.get_dataset_detailed_metadata(self.name)

    @property
    def column_types(self) -> Dict[str, str]:
        """Get column types for this dataset.

        Returns:
            Dict mapping column names to display types (image, video, audio, text, 3d)

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> print(dataset.column_types)
            {"image_url": "image", "video_url": "video"}
        """
        metadata = self.detailed_metadata
        return metadata.get("column_types", {})

    def set_column_types(self, column_types: Dict[str, str]) -> Dict[str, Any]:
        """Set column types for this dataset.

        Args:
            column_types: Dict mapping column names to display types.
                         Valid types: image, video, audio, text, 3d

        Returns:
            API response dict with updated metadata

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> dataset.set_column_types({
            ...     "image_url": "image",
            ...     "video_url": "video"
            ... })
        """
        return self.client.update_dataset_metadata(self.name, column_types=column_types)

    def update_metadata(
        self,
        description: Optional[str] = None,
        column_types: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Update dataset metadata.

        Args:
            description: Optional new description
            column_types: Optional dict mapping column names to display types

        Returns:
            API response dict with updated metadata

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> dataset.update_metadata(
            ...     description="My training dataset",
            ...     column_types={"image_url": "image"}
            ... )
        """
        result = self.client.update_dataset_metadata(
            self.name, description=description, column_types=column_types
        )
        # Invalidate cached metadata
        self._metadata = None
        return result

    def to_table(self):
        """Get dataset as a PyArrow Table.

        Returns:
            PyArrow Table containing the dataset data

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> table = dataset.to_table()
        """
        iceberg_table = self.client.get_dataset(self.name)
        return iceberg_table.scan().to_arrow()

    def to_pandas(self):
        """Get dataset as a Pandas DataFrame.

        Returns:
            Pandas DataFrame containing the dataset data

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> df = dataset.to_pandas()
        """
        iceberg_table = self.client.get_dataset(self.name)
        return iceberg_table.scan().to_pandas()

    def delete(self) -> Dict[str, Any]:
        """Delete the dataset.

        Returns:
            Deletion result

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> dataset.delete()
        """
        response = self.client.delete_dataset(self.name)
        return {"status": "deleted"}

    def refresh(self):
        """Clear cached data and force refresh on next access.

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> dataset.refresh()
            >>> print(dataset.metadata)  # Will fetch fresh data
        """
        self._metadata = None
        self._response = None

    def __repr__(self) -> str:
        """String representation of the Dataset."""
        return f"Dataset(name='{self.name}')"

    def __str__(self) -> str:
        """Human-readable string representation."""
        return f"Dataset: {self.name}"


def get_dataset(name: str, client: Optional[MixClient] = None) -> Dataset:
    """Get a dataset reference by name.

    This is the primary way to access datasets in a workspace.

    Args:
        name: Dataset name
        client: Optional MixClient instance

    Returns:
        Dataset proxy instance

    Example:
        >>> from mixtrain import get_dataset
        >>> dataset = get_dataset("training-data")
        >>> df = dataset.to_pandas()
    """
    return Dataset(name, client=client)


def list_datasets(client: Optional[MixClient] = None) -> List[Dataset]:
    """List all datasets in the workspace.

    Args:
        client: Optional MixClient instance

    Returns:
        List of Dataset instances

    Example:
        >>> from mixtrain import list_datasets
        >>> datasets = list_datasets()
        >>> for ds in datasets:
        ...     print(ds.name)
    """
    if client is None:
        client = MixClient()

    response = client.list_datasets()
    datasets_data = response.get("datasets", [])

    return [Dataset(d["name"], client=client) for d in datasets_data]
