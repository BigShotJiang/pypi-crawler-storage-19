"""Mantis CLI tests."""
