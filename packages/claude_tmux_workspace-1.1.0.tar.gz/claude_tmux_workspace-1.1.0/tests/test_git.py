"""Tests for cli.git with mocked GitPython."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from claude_tmux_cli.core.exceptions import (
    GitNotFoundError,
    NotAGitRepoError,
    WorktreeDirtyError,
)
from claude_tmux_cli.git import (
    branch_exists,
    find_repo_root,
    get_current_branch,
    get_head_commit,
    get_worktree_status,
    is_worktree_dirty,
    list_worktrees,
    remove_worktree,
    worktree_exists,
)
from git import InvalidGitRepositoryError
from git.exc import GitCommandNotFound


def _create_mock_repo(
    head_sha: str = "abc123def456",
    branch_name: str = "main",
    is_dirty: bool = False,
    branches: list[str] | None = None,
) -> MagicMock:
    """Create a mock GitPython Repo object."""
    repo = MagicMock()
    repo.head.commit.hexsha = head_sha
    repo.active_branch.name = branch_name
    repo.is_dirty.return_value = is_dirty

    if branches is None:
        branches = ["main"]
    mock_branches = [MagicMock(name=b) for b in branches]
    for mb, name in zip(mock_branches, branches, strict=True):
        mb.name = name
    repo.branches = mock_branches

    return repo


class TestGetHeadCommit:
    """Tests for get_head_commit function."""

    def test_get_head_commit_returns_sha(self) -> None:
        """Test getting HEAD commit SHA."""
        mock_repo = _create_mock_repo(head_sha="abc123def456")

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = get_head_commit(Path("/fake/repo"))
            assert result == "abc123def456"

    def test_git_not_found_raises_exception(self) -> None:
        """Test that GitCommandNotFound is converted to GitNotFoundError."""
        with (
            patch("claude_tmux_cli.git.Repo", side_effect=GitCommandNotFound("git", "not found")),
            pytest.raises((GitNotFoundError, NotAGitRepoError)),
        ):
            get_head_commit(Path("/fake/repo"))


class TestFindRepoRoot:
    """Tests for find_repo_root function."""

    def test_find_repo_root_returns_parent_of_git_dir(self) -> None:
        """Test finding repo root from .git directory."""
        mock_repo = _create_mock_repo()
        mock_repo.git.rev_parse.return_value = "/path/to/repo/.git"

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = find_repo_root(Path("/path/to/repo/subdir"))
            assert result == Path("/path/to/repo")

    def test_find_repo_root_not_a_git_repo(self) -> None:
        """Test NotAGitRepoError when not in a git repo."""
        with patch("claude_tmux_cli.git.Repo", side_effect=InvalidGitRepositoryError("/not/a/repo")):
            with pytest.raises(NotAGitRepoError) as exc_info:
                find_repo_root(Path("/not/a/repo"))
            assert "/not/a/repo" in str(exc_info.value)


class TestGetCurrentBranch:
    """Tests for get_current_branch function."""

    def test_get_current_branch_returns_name(self) -> None:
        """Test getting current branch name."""
        mock_repo = _create_mock_repo(branch_name="main")

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = get_current_branch(Path("/fake/repo"))
            assert result == "main"

    def test_get_current_branch_detached_head(self) -> None:
        """Test getting branch name in detached HEAD state."""
        mock_repo = _create_mock_repo()
        # TypeError is raised when accessing active_branch on detached HEAD
        type(mock_repo).active_branch = property(lambda self: (_ for _ in ()).throw(TypeError()))

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = get_current_branch(Path("/fake/repo"))
            assert result == "HEAD"


class TestBranchExists:
    """Tests for branch_exists function."""

    def test_branch_exists_returns_true(self) -> None:
        """Test branch_exists returns True when branch exists."""
        mock_repo = _create_mock_repo(branches=["main", "feature"])

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = branch_exists(Path("/fake/repo"), "main")
            assert result is True

    def test_branch_exists_returns_false(self) -> None:
        """Test branch_exists returns False when branch doesn't exist."""
        mock_repo = _create_mock_repo(branches=["main"])

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = branch_exists(Path("/fake/repo"), "nonexistent")
            assert result is False


class TestWorktreeExists:
    """Tests for worktree_exists function."""

    def test_worktree_exists_returns_true(self, tmp_path: Path) -> None:
        """Test worktree_exists returns True when worktree exists."""
        worktree_path = tmp_path / "worktree"
        worktree_path.mkdir()
        (worktree_path / ".git").touch()

        assert worktree_exists(worktree_path) is True

    def test_worktree_exists_returns_false_no_dir(self, tmp_path: Path) -> None:
        """Test worktree_exists returns False when directory doesn't exist."""
        worktree_path = tmp_path / "nonexistent"
        assert worktree_exists(worktree_path) is False

    def test_worktree_exists_returns_false_no_git(self, tmp_path: Path) -> None:
        """Test worktree_exists returns False when .git is missing."""
        worktree_path = tmp_path / "worktree"
        worktree_path.mkdir()
        assert worktree_exists(worktree_path) is False


class TestGetWorktreeStatus:
    """Tests for get_worktree_status function."""

    def test_get_worktree_status_returns_changed_files(self) -> None:
        """Test getting list of changed files."""
        mock_repo = _create_mock_repo()
        mock_repo.git.status.return_value = " M file1.py\n?? file2.py"

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = get_worktree_status(Path("/fake/worktree"))
            assert len(result) == 2
            assert any("file1.py" in f for f in result)
            assert any("file2.py" in f for f in result)

    def test_get_worktree_status_empty_on_error(self) -> None:
        """Test returning empty list on error."""
        with patch("claude_tmux_cli.git.Repo", side_effect=InvalidGitRepositoryError("/fake")):
            result = get_worktree_status(Path("/fake/worktree"))
            assert result == []


class TestIsWorktreeDirty:
    """Tests for is_worktree_dirty function."""

    def test_is_worktree_dirty_returns_true(self) -> None:
        """Test worktree is dirty when there are changes."""
        mock_repo = _create_mock_repo(is_dirty=True)

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            assert is_worktree_dirty(Path("/fake/worktree")) is True

    def test_is_worktree_dirty_returns_false(self) -> None:
        """Test worktree is clean when there are no changes."""
        mock_repo = _create_mock_repo(is_dirty=False)

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            assert is_worktree_dirty(Path("/fake/worktree")) is False


class TestRemoveWorktree:
    """Tests for remove_worktree function."""

    def test_remove_worktree_skips_nonexistent(self, tmp_path: Path) -> None:
        """Test removing nonexistent worktree does nothing."""
        worktree_path = tmp_path / "nonexistent"
        # Should not raise
        remove_worktree(worktree_path, tmp_path)

    def test_remove_worktree_raises_on_dirty(self, tmp_path: Path) -> None:
        """Test raising WorktreeDirtyError when dirty."""
        worktree_path = tmp_path / "worktree"
        worktree_path.mkdir()
        (worktree_path / ".git").touch()

        mock_repo = _create_mock_repo()
        mock_repo.git.status.return_value = " M file.py"

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            with pytest.raises(WorktreeDirtyError) as exc_info:
                remove_worktree(worktree_path, tmp_path, force=False)
            assert exc_info.value.changed_count == 1


class TestListWorktrees:
    """Tests for list_worktrees function."""

    def test_list_worktrees_parses_output(self) -> None:
        """Test parsing worktree list output."""
        mock_repo = _create_mock_repo()
        mock_repo.git.worktree.return_value = (
            "worktree /path/to/main\nHEAD abc123\n\nworktree /path/to/wt1\nHEAD def456"
        )

        with patch("claude_tmux_cli.git.Repo", return_value=mock_repo):
            result = list_worktrees(Path("/path/to/main"))
            assert len(result) == 2
            assert Path("/path/to/main") in result
            assert Path("/path/to/wt1") in result

    def test_list_worktrees_empty_on_error(self) -> None:
        """Test returning empty list on error."""
        with patch("claude_tmux_cli.git.Repo", side_effect=InvalidGitRepositoryError("/fake")):
            result = list_worktrees(Path("/fake/repo"))
            assert result == []
