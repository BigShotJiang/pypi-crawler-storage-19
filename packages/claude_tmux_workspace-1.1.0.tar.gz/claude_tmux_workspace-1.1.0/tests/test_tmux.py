"""Tests for shared tmux module with mocked libtmux."""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from claude_tmux_cli.tmux import (
    TmuxNotFoundError,
    TmuxSessionNotFoundError,
    TmuxWindowNotFoundError,
    attach_or_switch,
    capture_pane_content,
    create_session_with_window,
    create_window,
    get_current_session,
    get_pane_info,
    get_user_option,
    get_window_option,
    is_inside_tmux,
    kill_window,
    list_windows,
    pane_exists,
    session_exists,
    set_user_option,
    set_window_name,
    set_window_option,
    window_exists,
)
from libtmux.exc import LibTmuxException


def _create_mock_pane(
    pane_id: str = "%0",
    pane_pid: str = "12345",
    pane_current_command: str = "claude",
    pane_current_path: str = "/tmp/work",
) -> MagicMock:
    """Create a mock pane object."""
    pane = MagicMock()
    pane.pane_id = pane_id
    pane.pane_pid = pane_pid
    pane.pane_current_command = pane_current_command
    pane.pane_current_path = pane_current_path
    return pane


def _create_mock_window(
    window_id: str = "@0",
    window_name: str = "test-window",
    pane: MagicMock | None = None,
) -> MagicMock:
    """Create a mock window object."""
    window = MagicMock()
    window.window_id = window_id
    window.window_name = window_name
    if pane is None:
        pane = _create_mock_pane()
    window.active_pane = pane
    window.panes = [pane]
    pane.window = window
    return window


def _create_mock_session(
    session_name: str = "test-session",
    session_attached: bool = False,
    windows: list[MagicMock] | None = None,
) -> MagicMock:
    """Create a mock session object."""
    session = MagicMock()
    session.session_name = session_name
    session.session_attached = session_attached
    if windows is None:
        windows = [_create_mock_window()]
    session.windows = windows
    for window in windows:
        window.session = session
        for pane in window.panes:
            pane.window = window
    return session


class _MockSessionList(list[MagicMock]):
    """Mock session list that supports both iteration and filter()."""

    def filter(self, **kwargs: str) -> list[MagicMock]:
        """Filter sessions by name."""
        session_name = kwargs.get("session_name")
        if session_name:
            return [s for s in self if s.session_name == session_name]
        return list(self)


def _create_mock_server(sessions: list[MagicMock] | None = None) -> MagicMock:
    """Create a mock server object."""
    server = MagicMock()
    if sessions is None:
        sessions = []
    server.sessions = _MockSessionList(sessions)
    return server


@pytest.fixture
def clear_server_cache() -> None:
    """Clear the cached server before each test."""
    from claude_tmux_cli.tmux.server import get_server

    get_server.cache_clear()


class TestIsInsideTmux:
    """Tests for is_inside_tmux function."""

    def test_inside_tmux_returns_true(self) -> None:
        """Test returns True when TMUX env var is set."""
        with patch.dict(os.environ, {"TMUX": "/tmp/tmux-1000/default,12345,0"}):
            assert is_inside_tmux() is True

    def test_outside_tmux_returns_false(self) -> None:
        """Test returns False when TMUX env var is not set."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("TMUX", None)
            assert is_inside_tmux() is False


class TestGetCurrentSession:
    """Tests for get_current_session function."""

    def test_get_current_session_inside_tmux(self, clear_server_cache: None) -> None:
        """Test getting current session name when inside tmux."""
        session = _create_mock_session(session_name="my-session", session_attached=True)
        server = _create_mock_server([session])
        # Mock the cmd method to return session name from display-message
        mock_result = MagicMock()
        mock_result.stdout = ["my-session"]
        server.cmd = MagicMock(return_value=mock_result)

        with (
            patch.dict(os.environ, {"TMUX": "/tmp/tmux-1000/default,12345,0"}),
            patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server),
        ):
            result = get_current_session()
            assert result == "my-session"
            server.cmd.assert_called_once_with("display-message", "-p", "#{session_name}")

    def test_get_current_session_outside_tmux(self) -> None:
        """Test returns None when outside tmux."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("TMUX", None)
            result = get_current_session()
            assert result is None


class TestSessionExists:
    """Tests for session_exists function."""

    def test_session_exists_returns_true(self, clear_server_cache: None) -> None:
        """Test session_exists returns True when session exists."""
        session = _create_mock_session(session_name="test-session")
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = session_exists("test-session")
            assert result is True

    def test_session_exists_returns_false(self, clear_server_cache: None) -> None:
        """Test session_exists returns False when session doesn't exist."""
        server = _create_mock_server([])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = session_exists("nonexistent")
            assert result is False


class TestCreateSessionWithWindow:
    """Tests for create_session_with_window function."""

    def test_create_session_returns_window_and_pane_id(self, clear_server_cache: None) -> None:
        """Test creating session returns both window and pane IDs."""
        server = _create_mock_server()
        cmd_result = MagicMock()
        cmd_result.stdout = ["@0:::%0"]
        server.cmd = MagicMock(return_value=cmd_result)

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            window_id, pane_id = create_session_with_window(
                "test-session",
                "test-window",
                Path("/tmp"),
            )

            assert window_id == "@0"
            assert pane_id == "%0"


class TestCreateWindow:
    """Tests for create_window function."""

    def test_create_window_returns_window_and_pane_id(self, clear_server_cache: None) -> None:
        """Test creating window returns both window and pane IDs."""
        session = _create_mock_session(session_name="test-session")
        cmd_result = MagicMock()
        cmd_result.stdout = ["@1:::%5"]
        session.cmd = MagicMock(return_value=cmd_result)
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            window_id, pane_id = create_window(
                Path("/tmp"),
                "test-session",
                "test-window",
            )

            assert window_id == "@1"
            assert pane_id == "%5"

    def test_create_window_session_not_found(self, clear_server_cache: None) -> None:
        """Test raising TmuxSessionNotFoundError when session doesn't exist."""
        server = _create_mock_server([])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            with pytest.raises(TmuxSessionNotFoundError) as exc_info:
                create_window(Path("/tmp"), "nonexistent", "test-window")

            assert exc_info.value.session_name == "nonexistent"


class TestListWindows:
    """Tests for list_windows function."""

    def test_list_windows_parses_output(self, clear_server_cache: None) -> None:
        """Test parsing window list output."""
        pane1 = _create_mock_pane("%0", "12345", "bash", "/home/user")
        pane2 = _create_mock_pane("%1", "12346", "claude", "/tmp/work")
        window1 = _create_mock_window("@0", "window-0", pane1)
        window2 = _create_mock_window("@1", "window-1", pane2)
        session = _create_mock_session("test-session", windows=[window1, window2])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = list_windows("test-session")

            assert len(result) == 2
            assert result[0].window_id == "@0"
            assert result[0].window_name == "window-0"
            assert result[0].pane_id == "%0"
            assert result[0].pane_pid == 12345
            assert result[0].pane_current_command == "bash"
            assert result[0].pane_current_path == "/home/user"

            assert result[1].window_id == "@1"
            assert result[1].pane_id == "%1"

    def test_list_windows_empty_for_nonexistent_session(self, clear_server_cache: None) -> None:
        """Test returning empty list for nonexistent session."""
        server = _create_mock_server([])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = list_windows("nonexistent")
            assert result == []


class TestWindowExists:
    """Tests for window_exists function."""

    def test_window_exists_returns_true(self, clear_server_cache: None) -> None:
        """Test window_exists returns True when window exists."""
        window = _create_mock_window("@1")
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = window_exists("@1")
            assert result is True

    def test_window_exists_returns_false(self, clear_server_cache: None) -> None:
        """Test window_exists returns False when window doesn't exist."""
        server = _create_mock_server([])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = window_exists("@999")
            assert result is False


class TestPaneExists:
    """Tests for pane_exists function."""

    def test_pane_exists_returns_true(self, clear_server_cache: None) -> None:
        """Test pane_exists returns True when pane exists."""
        pane = _create_mock_pane("%5")
        window = _create_mock_window(pane=pane)
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = pane_exists("%5")
            assert result is True

    def test_pane_exists_returns_false(self, clear_server_cache: None) -> None:
        """Test pane_exists returns False when pane doesn't exist."""
        server = _create_mock_server([])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = pane_exists("%999")
            assert result is False

    def test_pane_exists_returns_false_for_empty_id(self) -> None:
        """Test pane_exists returns False for empty pane ID."""
        result = pane_exists("")
        assert result is False


class TestKillWindow:
    """Tests for kill_window function."""

    def test_kill_window_success(self, clear_server_cache: None) -> None:
        """Test successfully killing a window."""
        window = _create_mock_window("@1")
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            kill_window("@1")
            window.kill.assert_called_once()

    def test_kill_window_not_found(self, clear_server_cache: None) -> None:
        """Test raising TmuxWindowNotFoundError when window doesn't exist."""
        server = _create_mock_server([])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            with pytest.raises(TmuxWindowNotFoundError) as exc_info:
                kill_window("@999")

            assert exc_info.value.window_id == "@999"


class TestSetWindowName:
    """Tests for set_window_name function."""

    def test_set_window_name_success(self, clear_server_cache: None) -> None:
        """Test successfully renaming a window."""
        window = _create_mock_window("@1")
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            set_window_name("@1", "new-name")
            window.rename_window.assert_called_once_with("new-name")

    def test_set_window_name_not_found(self, clear_server_cache: None) -> None:
        """Test raising TmuxWindowNotFoundError when window doesn't exist."""
        server = _create_mock_server([])

        with (
            patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server),
            pytest.raises(TmuxWindowNotFoundError),
        ):
            set_window_name("@999", "new-name")


class TestAttachOrSwitch:
    """Tests for attach_or_switch function."""

    def test_attach_when_outside_tmux(self, clear_server_cache: None) -> None:
        """Test using attach when outside tmux via os.execvp."""
        session = _create_mock_session("test-session")
        server = _create_mock_server([session])

        with (
            patch.dict(os.environ, {}, clear=True),
            patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server),
            patch("claude_tmux_cli.tmux.client.os.execvp") as mock_execvp,
        ):
            os.environ.pop("TMUX", None)

            attach_or_switch("test-session")

            mock_execvp.assert_called_once_with("tmux", ["tmux", "attach", "-t", "test-session"])

    def test_switch_when_inside_tmux(self, clear_server_cache: None) -> None:
        """Test using switch-client when inside tmux."""
        session = _create_mock_session("test-session")
        server = _create_mock_server([session])

        with (
            patch.dict(os.environ, {"TMUX": "/tmp/tmux-1000/default,12345,0"}),
            patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server),
        ):
            attach_or_switch("test-session")

            session.switch_client.assert_called_once()

    def test_attach_session_not_found(self, clear_server_cache: None) -> None:
        """Test raising TmuxSessionNotFoundError when session doesn't exist."""
        server = _create_mock_server([])

        with (
            patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server),
            pytest.raises(TmuxSessionNotFoundError),
        ):
            attach_or_switch("nonexistent")


class TestCapturePaneContent:
    """Tests for capture_pane_content function."""

    def test_capture_pane_content_returns_content(self, clear_server_cache: None) -> None:
        """Test capturing pane content."""
        pane = _create_mock_pane("%0")
        cmd_result = MagicMock()
        cmd_result.stdout = ["Hello, World!", "This is pane content."]
        pane.cmd = MagicMock(return_value=cmd_result)
        window = _create_mock_window("@1", pane=pane)
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = capture_pane_content("%0")

            assert "Hello, World!" in result
            assert "This is pane content." in result

    def test_capture_pane_content_window_not_found(self, clear_server_cache: None) -> None:
        """Test raising TmuxWindowNotFoundError when window doesn't exist."""
        server = _create_mock_server([])

        with (
            patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server),
            pytest.raises(TmuxWindowNotFoundError),
        ):
            capture_pane_content("@999")


class TestGetPaneInfo:
    """Tests for get_pane_info function."""

    def test_get_pane_info_returns_info(self, clear_server_cache: None) -> None:
        """Test getting pane info."""
        pane = _create_mock_pane("%5", "12345", "claude", "/home/user/project")
        window = _create_mock_window("@1", "my-window", pane)
        session = _create_mock_session("my-session", windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            info = get_pane_info("%5")

            assert info.pane_id == "%5"
            assert info.session_name == "my-session"
            assert info.window_id == "@1"
            assert info.window_name == "my-window"
            assert info.pane_current_path == "/home/user/project"
            assert info.pane_path_basename == "project"

    def test_get_pane_info_not_found(self, clear_server_cache: None) -> None:
        """Test raising TmuxWindowNotFoundError when pane doesn't exist."""
        server = _create_mock_server([])

        with (
            patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server),
            pytest.raises(TmuxWindowNotFoundError),
        ):
            get_pane_info("%999")


class TestWindowOptions:
    """Tests for window option functions."""

    def test_set_window_option(self, clear_server_cache: None) -> None:
        """Test setting a window option."""
        pane = _create_mock_pane("%5")
        window = _create_mock_window("@1", pane=pane)
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            set_window_option("%5", "automatic-rename", "off")
            pane.cmd.assert_called_with("set-option", "-t", "%5", "automatic-rename", "off")

    def test_get_window_option(self, clear_server_cache: None) -> None:
        """Test getting a window option."""
        pane = _create_mock_pane("%5")
        cmd_result = MagicMock()
        cmd_result.stdout = ["on"]
        pane.cmd = MagicMock(return_value=cmd_result)
        window = _create_mock_window("@1", pane=pane)
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = get_window_option("%5", "automatic-rename")
            assert result == "on"


class TestUserOptions:
    """Tests for user option functions."""

    def test_set_user_option_adds_prefix(self, clear_server_cache: None) -> None:
        """Test that set_user_option adds @ prefix."""
        pane = _create_mock_pane("%5")
        window = _create_mock_window("@1", pane=pane)
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            set_user_option("%5", "claude_status", "working")
            pane.cmd.assert_called_with("set-option", "-t", "%5", "@claude_status", "working")

    def test_get_user_option_adds_prefix(self, clear_server_cache: None) -> None:
        """Test that get_user_option adds @ prefix."""
        pane = _create_mock_pane("%5")
        cmd_result = MagicMock()
        cmd_result.stdout = ["waiting"]
        pane.cmd = MagicMock(return_value=cmd_result)
        window = _create_mock_window("@1", pane=pane)
        session = _create_mock_session(windows=[window])
        server = _create_mock_server([session])

        with patch("claude_tmux_cli.tmux.server.libtmux.Server", return_value=server):
            result = get_user_option("%5", "claude_status")
            assert result == "waiting"
            pane.cmd.assert_called_with("show-options", "-t", "%5", "-qv", "@claude_status")


class TestServerCaching:
    """Tests for server caching behavior."""

    def test_server_not_found_returns_false_for_session_exists(self, clear_server_cache: None) -> None:
        """Test that session_exists returns False when server can't be reached."""
        with patch("claude_tmux_cli.tmux.server.libtmux.Server", side_effect=LibTmuxException("no server")):
            # session_exists catches the error and returns False
            assert session_exists("test-session") is False

    def test_server_not_found_raises_for_create_session(self, clear_server_cache: None) -> None:
        """Test that create_session_with_window raises TmuxNotFoundError."""
        with (
            patch(
                "claude_tmux_cli.tmux.server.libtmux.Server",
                side_effect=LibTmuxException("no server"),
            ),
            pytest.raises(TmuxNotFoundError),
        ):
            create_session_with_window("test", "window", Path("/tmp"))
