# Contributing to deltao

First off, thank you for considering contributing to deltao! It's people like you that make deltao such a great tool.

## Table of Contents

- [Getting Started](#getting-started)
- [Development Setup](#development-setup)
- [Making Changes](#making-changes)
- [Commit Convention](#commit-convention)
- [Pull Request Process](#pull-request-process)
- [Reporting Bugs](#reporting-bugs)
- [Suggesting Features](#suggesting-features)

## Getting Started

1. Fork the repository on GitHub
2. Clone your fork locally:
   ```bash
   git clone https://github.com/YOUR_USERNAME/deltao.git
   cd deltao
   ```
3. Add the upstream repository:
   ```bash
   git remote add upstream https://github.com/msulabs/deltao.git
   ```

## Development Setup

This project uses [uv](https://docs.astral.sh/uv/) for dependency management.

1. Install uv (if not already installed):
   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```

2. Install dependencies:
   ```bash
   uv sync --dev
   ```

3. Install pre-commit hooks:
   ```bash
   uv run pre-commit install
   ```

4. Verify setup by running tests:
   ```bash
   uv run pytest
   ```

## Making Changes

1. Create a new branch from `main`:
   ```bash
   git checkout -b feature/your-feature-name
   # or
   git checkout -b fix/your-bug-fix
   ```

2. Make your changes

3. Run the linter and fix any issues:
   ```bash
   uv run ruff check src tests --fix
   uv run ruff format src tests
   ```

4. Run type checking:
   ```bash
   uv run mypy src
   ```

5. Run tests and ensure they pass:
   ```bash
   uv run pytest
   ```

6. Commit your changes (see [Commit Convention](#commit-convention))

7. Push to your fork:
   ```bash
   git push origin feature/your-feature-name
   ```

## Commit Convention

We use [Conventional Commits](https://www.conventionalcommits.org/) specification. This leads to more readable messages and enables automatic changelog generation.

### Commit Message Format

```
<type>(<scope>): <description>

[optional body]

[optional footer(s)]
```

### Types

| Type | Description |
|------|-------------|
| `feat` | A new feature |
| `fix` | A bug fix |
| `docs` | Documentation only changes |
| `style` | Changes that don't affect code meaning (formatting, etc.) |
| `refactor` | Code change that neither fixes a bug nor adds a feature |
| `perf` | Performance improvement |
| `test` | Adding or correcting tests |
| `build` | Changes to build system or dependencies |
| `ci` | Changes to CI configuration |
| `chore` | Other changes that don't modify src or test files |
| `revert` | Reverts a previous commit |

### Examples

```bash
feat(parser): add ability to parse arrays
fix(api): handle null response correctly
docs: update installation instructions
test: add missing unit tests for utils
```

## Pull Request Process

1. Update the README.md with details of changes if applicable
2. Update the CHANGELOG.md following [Keep a Changelog](https://keepachangelog.com/) format
3. Ensure all tests pass and there are no linting errors
4. The PR will be merged once you have the sign-off of at least one maintainer

### PR Title Convention

Use the same format as commit messages:
```
feat(scope): description
```

## Reporting Bugs

### Before Submitting

- Check the [existing issues](https://github.com/msulabs/deltao/issues) to avoid duplicates
- Check if the issue has been fixed in a recent release or the main branch

### How to Submit

Use the [Bug Report template](.github/ISSUE_TEMPLATE/bug_report.md) and include:

- A clear and descriptive title
- Steps to reproduce the behavior
- Expected vs actual behavior
- Environment details (OS, Python version, package version)
- Code samples or error messages if applicable

## Suggesting Features

Use the [Feature Request template](.github/ISSUE_TEMPLATE/feature_request.md) and include:

- A clear and descriptive title
- The problem you're trying to solve
- Your proposed solution
- Alternative solutions you've considered
- Additional context or examples

## Style Guide

### Python Code Style

- Follow [PEP 8](https://pep8.org/)
- Use type hints for all function signatures
- Write docstrings for all public modules, functions, classes, and methods
- Maximum line length is 88 characters (Black default)

### Documentation Style

- Use [Google-style docstrings](https://google.github.io/styleguide/pyguide.html#38-comments-and-docstrings)
- Keep documentation up-to-date with code changes

## Questions?

Feel free to open an issue with the `question` label or reach out to the maintainers.

---

Thank you for contributing! 🎉
