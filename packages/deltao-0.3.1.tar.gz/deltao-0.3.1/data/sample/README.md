# Sample Data

This directory contains sample datasets for backtesting.

## Files

- `dtao|subnet8|1block.csv` — 100 blocks (~20 min) of sample data for Subnet 8
  - Price starts at 1.00 and moves up/down by ~10%
  - Realistic AMM pool values (tao_in, alpha_in, k)

## Usage

```python
from pathlib import Path
from deltao.backtest import BacktestingEngine, BacktestConfig, load_block_data

# Load CSV file
data = load_block_data(netuid=8, data_dir=Path("data/sample"), fmt="csv")
print(data.head())

# Run backtest
config = BacktestConfig(
    netuid=8,
    start_block=1_000_000,
    end_block=1_000_050,
    data_dir=Path("data/sample"),
)
# ... continue with strategy and engine
```

## Adding Your Own Data

Filename format: `dtao|subnet{NETUID}|1block.{csv,parquet}`

Required columns:
- `timestamp` — Unix timestamp (seconds)
- `block_number` — Block number
- `price` — TAO/Alpha price
- `tao_in` — TAO amount in pool
- `alpha_in` — Alpha amount in pool
- `k` — Constant product (tao_in × alpha_in)
