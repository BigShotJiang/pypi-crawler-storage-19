"""Tests for safety utilities."""

import pytest

from deltao.connector.safety import execute_with_retry


class TestExecuteWithRetry:
    """Test execute_with_retry function."""

    async def test_success_on_first_attempt(self):
        """Should return result on first successful attempt."""
        call_count = 0

        async def success_func():
            nonlocal call_count
            call_count += 1
            return "success"

        result = await execute_with_retry(success_func, max_retries=3)

        assert result == "success"
        assert call_count == 1

    async def test_retry_on_failure(self):
        """Should retry on failure."""
        call_count = 0

        async def fail_then_succeed():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError("temporary failure")
            return "success"

        result = await execute_with_retry(
            fail_then_succeed, max_retries=3, base_delay=0.01
        )

        assert result == "success"
        assert call_count == 3

    async def test_raises_after_max_retries(self):
        """Should raise last exception after max retries."""

        async def always_fail():
            raise ValueError("permanent failure")

        with pytest.raises(ValueError, match="permanent failure"):
            await execute_with_retry(always_fail, max_retries=3, base_delay=0.01)

    async def test_on_retry_callback(self):
        """Should call on_retry callback."""
        retry_attempts = []

        def on_retry(attempt, exc):
            retry_attempts.append((attempt, str(exc)))

        async def fail_twice():
            if len(retry_attempts) < 2:
                raise ValueError("fail")
            return "success"

        result = await execute_with_retry(
            fail_twice, max_retries=3, base_delay=0.01, on_retry=on_retry
        )

        assert result == "success"
        assert len(retry_attempts) == 2
        assert retry_attempts[0][0] == 0
        assert retry_attempts[1][0] == 1

    async def test_exponential_backoff(self):
        """Should use exponential backoff delay."""
        import time

        start_times = []

        async def record_time():
            start_times.append(time.time())
            if len(start_times) < 3:
                raise ValueError("fail")
            return "success"

        await execute_with_retry(record_time, max_retries=3, base_delay=0.05)

        # First retry delay: 0.05s, second retry delay: 0.1s
        delay1 = start_times[1] - start_times[0]
        delay2 = start_times[2] - start_times[1]

        assert delay1 >= 0.04  # Allow some timing variance
        assert delay2 >= 0.08  # ~2x first delay
