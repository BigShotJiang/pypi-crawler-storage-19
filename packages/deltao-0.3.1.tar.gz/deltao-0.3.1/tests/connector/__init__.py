"""Connector module tests."""
