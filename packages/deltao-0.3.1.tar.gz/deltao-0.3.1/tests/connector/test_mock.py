"""Tests for MockConnector."""

from datetime import datetime
from decimal import Decimal

import pytest

from deltao.connector.mock import MockConnector
from deltao.core.event import AccountEvent, MarketEvent
from deltao.core.types import OrderRequest, Side


@pytest.mark.asyncio
async def test_mock_connector_initialization():
    """Test MockConnector initialization."""
    connector = MockConnector()

    assert connector.orders == []
    assert connector.market_state is None
    assert connector.account_state is None


@pytest.mark.asyncio
async def test_mock_connector_place_order():
    """Test MockConnector.place_order()."""
    connector = MockConnector()
    order = OrderRequest(side=Side.BUY, amount=Decimal("100"))

    result = await connector.place_order(order)

    assert result.success is True
    assert result.message == "Mock order executed"
    assert result.tx_hash == "0xmock"
    assert result.block_number == 999
    assert len(connector.orders) == 1
    assert connector.orders[0] == order


@pytest.mark.asyncio
async def test_mock_connector_get_market_state_default():
    """Test MockConnector.get_market_state() returns default."""
    connector = MockConnector()

    state = await connector.get_market_state()

    assert state.netuid == 8
    assert state.price == Decimal("1.0")
    assert state.tao_in == Decimal("1000")
    assert state.alpha_in == Decimal("1000")
    assert state.k == Decimal("1000000")


@pytest.mark.asyncio
async def test_mock_connector_get_market_state_custom():
    """Test MockConnector.get_market_state() returns custom state."""
    connector = MockConnector()

    custom_state = MarketEvent(
        netuid=10,
        price=Decimal("2.0"),
        tao_in=Decimal("2000"),
        alpha_in=Decimal("4000"),
        k=Decimal("8000000"),
        block_number=500,
        timestamp=datetime.now(),
    )

    connector.set_market_state(custom_state)
    state = await connector.get_market_state()

    assert state == custom_state
    assert state.price == Decimal("2.0")


@pytest.mark.asyncio
async def test_mock_connector_get_account_state_default():
    """Test MockConnector.get_account_state() returns default."""
    connector = MockConnector()

    state = await connector.get_account_state()

    assert state.tao_balance == Decimal("100")
    assert state.alpha_balance == Decimal("0")
    assert state.positions == []


@pytest.mark.asyncio
async def test_mock_connector_get_account_state_custom():
    """Test MockConnector.get_account_state() returns custom state."""
    connector = MockConnector()

    custom_state = AccountEvent(
        tao_balance=Decimal("500"),
        alpha_balance=Decimal("250"),
        positions=[],
        timestamp=datetime.now(),
    )

    connector.set_account_state(custom_state)
    state = await connector.get_account_state()

    assert state == custom_state
    assert state.tao_balance == Decimal("500")


@pytest.mark.asyncio
async def test_mock_connector_start_stop():
    """Test MockConnector.start() and stop() are no-ops."""
    connector = MockConnector()

    # Should not raise any errors
    await connector.start()
    await connector.stop()
