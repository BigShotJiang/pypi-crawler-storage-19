"""Tests for DTaoConnector with mocked bittensor SDK."""

from decimal import Decimal
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from deltao.connector.dtao import ConnectionState, DTaoConnector
from deltao.core.types import OrderRequest, Side


@pytest.fixture
def mock_wallet():
    """Create mock wallet."""
    wallet = MagicMock()
    wallet.coldkey.ss58_address = "5FHneW46xGXgs5mUiveU4sbTyGBzmstUspZC92UhjJM694ty"
    wallet.hotkey.ss58_address = "5GrwvaEF5zXb26Fz9rcQpDWS57CtERHpNehXCPcNoHGKutQY"
    return wallet


@pytest.fixture
def mock_subtensor():
    """Create mock subtensor."""
    subtensor = AsyncMock()

    # Mock subnet info (async method)
    subnet_info = MagicMock()
    subnet_info.price = 1.5
    subnet_info.tao_in = 1000.0
    subnet_info.alpha_in = 666.67
    subtensor.subnet = AsyncMock(return_value=subnet_info)

    # Mock balance (async method)
    balance = MagicMock()
    balance.tao = 100.0
    subtensor.get_balance = AsyncMock(return_value=balance)

    # Mock stake (async method)
    subtensor.get_stake = AsyncMock(return_value=50.0)

    # Mock block number
    subtensor.substrate.get_block_number = AsyncMock(return_value=12345)

    # Mock add_stake and unstake
    subtensor.add_stake = AsyncMock(return_value=True)
    subtensor.unstake = AsyncMock(return_value=True)

    # Mock close
    subtensor.close = AsyncMock()

    return subtensor


@pytest.fixture
def connector(mock_wallet):
    """Create connector instance."""
    return DTaoConnector(
        wallet=mock_wallet,
        netuid=8,
        network="test",
        max_retries=1,
    )


class TestDTaoConnectorLifecycle:
    """Test connector lifecycle methods."""

    async def test_start_creates_subtensor(self, connector, mock_subtensor):
        """start() should create subtensor connection."""
        with patch("bittensor.Subtensor", new=AsyncMock(return_value=mock_subtensor)):
            await connector.start()
            assert connector._subtensor is not None

    async def test_stop_closes_subtensor(self, connector, mock_subtensor):
        """stop() should close subtensor connection."""
        connector._subtensor = mock_subtensor

        await connector.stop()

        mock_subtensor.close.assert_called_once()
        assert connector._subtensor is None

    async def test_subtensor_property_raises_when_not_started(self, connector):
        """subtensor property should raise if not started."""
        with pytest.raises(RuntimeError, match="not started"):
            _ = connector.subtensor


class TestDTaoConnectorOrders:
    """Test order execution."""

    async def test_place_buy_order_calls_add_stake(
        self,
        connector,
        mock_wallet,  # noqa: ARG002
        mock_subtensor,
    ):
        """BUY order should call add_stake."""
        connector._subtensor = mock_subtensor
        connector._state = ConnectionState.CONNECTED

        order = OrderRequest(side=Side.BUY, amount=Decimal("10.0"))
        result = await connector.place_order(order)

        assert result.success
        mock_subtensor.add_stake.assert_called_once()

    async def test_place_sell_order_calls_unstake(
        self,
        connector,
        mock_wallet,  # noqa: ARG002
        mock_subtensor,
    ):
        """SELL order should call unstake."""
        connector._subtensor = mock_subtensor
        connector._state = ConnectionState.CONNECTED

        order = OrderRequest(side=Side.SELL, amount=Decimal("10.0"))
        result = await connector.place_order(order)

        assert result.success
        mock_subtensor.unstake.assert_called_once()

    async def test_place_order_with_custom_hotkey(
        self,
        connector,
        mock_wallet,  # noqa: ARG002
        mock_subtensor,
    ):
        """Order with custom hotkey should use that hotkey."""
        connector._subtensor = mock_subtensor
        connector._state = ConnectionState.CONNECTED
        custom_hotkey = "5CustomHotkey"

        order = OrderRequest(
            side=Side.BUY,
            amount=Decimal("10.0"),
            hotkey=custom_hotkey,
        )
        await connector.place_order(order)

        call_kwargs = mock_subtensor.add_stake.call_args.kwargs
        assert call_kwargs["hotkey_ss58"] == custom_hotkey

    async def test_place_order_failure_returns_error(self, connector, mock_subtensor):
        """Failed order should return error result."""
        connector._subtensor = mock_subtensor
        connector._state = ConnectionState.CONNECTED
        mock_subtensor.add_stake = AsyncMock(return_value=False)

        order = OrderRequest(side=Side.BUY, amount=Decimal("10.0"))
        result = await connector.place_order(order)

        assert not result.success
        assert "failed" in result.message.lower()


class TestDTaoConnectorState:
    """Test state retrieval methods."""

    async def test_get_market_state(self, connector, mock_subtensor):
        """get_market_state should return MarketEvent."""
        connector._subtensor = mock_subtensor
        connector._state = ConnectionState.CONNECTED

        event = await connector.get_market_state()

        assert event.netuid == 8
        assert event.price == Decimal("1.5")
        assert event.tao_in == Decimal("1000.0")
        assert event.alpha_in == Decimal("666.67")
        assert event.block_number == 12345

    async def test_get_account_state(self, connector, mock_subtensor):
        """get_account_state should return AccountEvent."""
        connector._subtensor = mock_subtensor
        connector._state = ConnectionState.CONNECTED

        event = await connector.get_account_state()

        assert event.tao_balance == Decimal("100.0")
        assert event.alpha_balance == Decimal("50.0")
        assert event.positions == []
