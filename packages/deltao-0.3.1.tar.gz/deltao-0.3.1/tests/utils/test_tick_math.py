"""Tests for Uniswap v3 tick math."""

from decimal import Decimal

import pytest

from deltao.utils.tick_math import (
    MAX_PRICE,
    MAX_TICK,
    MIN_PRICE,
    MIN_TICK,
    PRICE_STEP,
    price_to_tick,
    tick_to_price,
    tick_to_sqrt_price,
)


def test_constants():
    """Test tick math constants."""
    assert MIN_TICK == -443636
    assert MAX_TICK == 443636
    assert Decimal("1.0001") == PRICE_STEP


def test_tick_to_price_at_zero():
    """Test tick_to_price(0) = 1.0."""
    price = tick_to_price(0)
    assert price == Decimal("1.0")


def test_tick_to_price_positive():
    """Test tick_to_price() with positive tick."""
    price = tick_to_price(1)
    assert price == Decimal("1.0001")

    price = tick_to_price(10000)
    # Should be approximately 2.718 (e)
    assert price > Decimal("2.7")
    assert price < Decimal("2.8")


def test_tick_to_price_negative():
    """Test tick_to_price() with negative tick."""
    price = tick_to_price(-1)
    assert price < Decimal("1.0")

    # -10000 should be approximately 1/e
    price = tick_to_price(-10000)
    assert price > Decimal("0.36")
    assert price < Decimal("0.37")


def test_tick_to_price_out_of_range():
    """Test tick_to_price() raises on out of range tick."""
    with pytest.raises(ValueError, match="Tick out of range"):
        tick_to_price(MAX_TICK + 1)

    with pytest.raises(ValueError, match="Tick out of range"):
        tick_to_price(MIN_TICK - 1)


def test_price_to_tick_at_one():
    """Test price_to_tick(1.0) = 0."""
    tick = price_to_tick(Decimal("1.0"))
    assert tick == 0


def test_price_to_tick_roundtrip():
    """Test price_to_tick and tick_to_price roundtrip."""
    original_tick = 5000
    price = tick_to_price(original_tick)
    recovered_tick = price_to_tick(price)

    # Should be close (within 1 tick due to rounding)
    assert abs(recovered_tick - original_tick) <= 1


def test_price_to_tick_invalid_price():
    """Test price_to_tick() raises on invalid price."""
    with pytest.raises(ValueError, match="Price must be positive"):
        price_to_tick(Decimal("0"))

    with pytest.raises(ValueError, match="Price must be positive"):
        price_to_tick(Decimal("-1"))


def test_price_to_tick_out_of_range():
    """Test price_to_tick() raises on out of range price."""
    with pytest.raises(ValueError, match="Price out of range"):
        price_to_tick(MIN_PRICE / 2)

    with pytest.raises(ValueError, match="Price out of range"):
        price_to_tick(MAX_PRICE * 2)


def test_tick_to_sqrt_price():
    """Test tick_to_sqrt_price()."""
    sqrt_price = tick_to_sqrt_price(0)
    assert sqrt_price == Decimal("1.0")

    # sqrt(1.0001) ≈ 1.00005
    sqrt_price = tick_to_sqrt_price(1)
    assert sqrt_price > Decimal("1.00004")
    assert sqrt_price < Decimal("1.00006")


def test_min_max_prices():
    """Test MIN_PRICE and MAX_PRICE are computed correctly."""
    assert MIN_PRICE == PRICE_STEP**MIN_TICK
    assert MAX_PRICE == PRICE_STEP**MAX_TICK

    # Verify they're in expected ranges
    assert Decimal("0.000001") > MIN_PRICE
    assert Decimal("1000000") < MAX_PRICE


def test_price_examples_from_docs():
    """Test examples from IMPLEMENTATION_CORE.md."""
    # price_to_tick(1.0) = 0
    assert price_to_tick(Decimal("1.0")) == 0

    # price_to_tick(1.0001) = 1
    assert price_to_tick(Decimal("1.0001")) == 1

    # price_to_tick(2.0) ≈ 6931
    tick = price_to_tick(Decimal("2.0"))
    assert 6930 <= tick <= 6932

    # tick_to_price(6931) ≈ 2.0
    price = tick_to_price(6931)
    assert abs(price - Decimal("2.0")) < Decimal("0.001")
