"""Test version."""

from deltao import __version__


def test_version() -> None:
    """Test version is defined."""
    assert __version__ is not None
    assert isinstance(__version__, str)
