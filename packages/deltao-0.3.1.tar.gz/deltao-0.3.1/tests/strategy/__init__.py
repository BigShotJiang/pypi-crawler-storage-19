"""Strategy module tests."""
