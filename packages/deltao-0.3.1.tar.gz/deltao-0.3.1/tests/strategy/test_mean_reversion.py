"""Tests for mean reversion strategy."""

from decimal import Decimal

from deltao.core.state import EngineState
from deltao.core.types import Side
from deltao.strategy.directional.mean_reversion import MeanReversionStrategy


def create_state_with_prices(
    prices: list[Decimal],
    tao: Decimal = Decimal("100"),
    alpha: Decimal = Decimal("50"),
) -> EngineState:
    """Create EngineState with given price history."""
    state = EngineState(
        tao_balance=tao,
        alpha_balance=alpha,
        current_price=prices[-1] if prices else Decimal(1),
    )
    for price in prices:
        state.price_history.append(price)
    return state


class TestMeanReversionStrategy:
    """Tests for MeanReversionStrategy."""

    def test_init_defaults(self) -> None:
        """Test default initialization."""
        strategy = MeanReversionStrategy()
        assert strategy.name == "MeanReversionStrategy"
        assert strategy.rsi_period == 14
        assert strategy.oversold_threshold == Decimal("30")
        assert strategy.overbought_threshold == Decimal("70")

    def test_insufficient_data_returns_empty(self) -> None:
        """Test strategy returns no orders with insufficient data."""
        strategy = MeanReversionStrategy()
        prices = [Decimal(i) for i in range(10)]  # Not enough data
        state = create_state_with_prices(prices)

        cancels, opens = strategy.generate_orders(state)

        assert cancels == []
        assert opens == []

    def test_oversold_generates_buy(self) -> None:
        """Test buy signal when oversold (low RSI + price below SMA)."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            oversold_threshold=Decimal("30"),
            min_deviation=Decimal("0.01"),
        )

        # Create prices that drop sharply (oversold)
        # Start high, drop steadily to create low RSI
        prices = [Decimal(100)] * 10 + [Decimal(100 - i * 3) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("100"))

        cancels, opens = strategy.generate_orders(state)

        assert cancels == []
        # Should generate buy if RSI < 30 and price below SMA
        if opens:
            assert opens[0].side == Side.BUY

    def test_overbought_generates_sell(self) -> None:
        """Test sell signal when overbought (high RSI + price above SMA)."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            overbought_threshold=Decimal("70"),
            min_deviation=Decimal("0.01"),
        )

        # Create prices that rise sharply (overbought)
        prices = [Decimal(10)] * 10 + [Decimal(10 + i * 3) for i in range(20)]
        state = create_state_with_prices(prices, alpha=Decimal("50"))

        cancels, opens = strategy.generate_orders(state)

        assert cancels == []
        # Should generate sell if RSI > 70 and price above SMA
        if opens:
            assert opens[0].side == Side.SELL

    def test_no_order_when_rsi_neutral(self) -> None:
        """Test no order when RSI is in neutral range."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
        )

        # Create alternating prices for neutral RSI
        prices = [Decimal(100 + (i % 2) * 2) for i in range(30)]
        state = create_state_with_prices(prices)

        cancels, opens = strategy.generate_orders(state)

        # RSI should be around 50, no signal
        assert cancels == []
        assert opens == []

    def test_no_buy_below_min_deviation(self) -> None:
        """Test no buy when price deviation is too small."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            min_deviation=Decimal("0.10"),  # 10% threshold
            oversold_threshold=Decimal("50"),  # Lower threshold to trigger RSI
        )

        # Prices that are close to SMA (small deviation)
        prices = [Decimal(100)] * 30
        state = create_state_with_prices(prices)

        _, opens = strategy.generate_orders(state)

        assert opens == []

    def test_no_buy_when_no_tao_balance(self) -> None:
        """Test no buy order when TAO balance is insufficient."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
        )

        # Oversold prices but no TAO
        prices = [Decimal(100)] * 10 + [Decimal(100 - i * 3) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("0"))

        _, opens = strategy.generate_orders(state)

        # No buy should be generated
        buy_orders = [o for o in opens if o.side == Side.BUY]
        assert buy_orders == []

    def test_no_sell_when_no_alpha_balance(self) -> None:
        """Test no sell order when Alpha balance is zero."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
        )

        # Overbought prices but no Alpha
        prices = [Decimal(10)] * 10 + [Decimal(10 + i * 3) for i in range(20)]
        state = create_state_with_prices(prices, alpha=Decimal("0"))

        _, opens = strategy.generate_orders(state)

        # No sell should be generated
        sell_orders = [o for o in opens if o.side == Side.SELL]
        assert sell_orders == []

    def test_order_size_clamped_to_max(self) -> None:
        """Test order size is clamped to max_order_size."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            base_order_size=Decimal("1000"),
        )
        strategy.max_order_size = Decimal("10")

        # Create oversold condition
        prices = [Decimal(100)] * 10 + [Decimal(100 - i * 3) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("1000"))

        _, opens = strategy.generate_orders(state)

        if opens:
            assert opens[0].amount <= strategy.max_order_size

    def test_order_size_at_least_min(self) -> None:
        """Test order size is at least min_order_size."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            base_order_size=Decimal("0.001"),
        )

        # Create oversold condition
        prices = [Decimal(100)] * 10 + [Decimal(100 - i * 3) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("100"))

        _, opens = strategy.generate_orders(state)

        if opens:
            assert opens[0].amount >= strategy.min_order_size

    def test_slippage_tolerance_set(self) -> None:
        """Test orders have slippage tolerance set."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
        )

        prices = [Decimal(100)] * 10 + [Decimal(100 - i * 3) for i in range(20)]
        state = create_state_with_prices(prices)

        _, opens = strategy.generate_orders(state)

        if opens:
            assert opens[0].slippage_tolerance == Decimal("0.02")

    def test_buy_size_scales_with_oversold_level(self) -> None:
        """Test buy size increases when more oversold."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            deviation_multiplier=Decimal("2.0"),
        )

        # Mildly oversold
        mild_prices = [Decimal(100)] * 10 + [Decimal(100 - i) for i in range(20)]
        mild_state = create_state_with_prices(mild_prices, tao=Decimal("1000"))

        # Severely oversold
        severe_prices = [Decimal(100)] * 10 + [Decimal(100 - i * 5) for i in range(20)]
        severe_state = create_state_with_prices(severe_prices, tao=Decimal("1000"))

        _, mild_opens = strategy.generate_orders(mild_state)
        _, severe_opens = strategy.generate_orders(severe_state)

        # More oversold should have larger order
        if mild_opens and severe_opens:
            assert severe_opens[0].amount >= mild_opens[0].amount

    def test_custom_thresholds(self) -> None:
        """Test strategy respects custom RSI thresholds."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            oversold_threshold=Decimal("40"),  # Higher threshold
            overbought_threshold=Decimal("60"),  # Lower threshold
        )

        assert strategy.oversold_threshold == Decimal("40")
        assert strategy.overbought_threshold == Decimal("60")

    def test_requires_both_rsi_and_deviation(self) -> None:
        """Test that both RSI and deviation conditions must be met."""
        strategy = MeanReversionStrategy(
            rsi_period=14,
            sma_period=10,
            oversold_threshold=Decimal("30"),
            min_deviation=Decimal("0.05"),
        )

        # Flat prices - RSI neutral, no deviation
        prices = [Decimal(100)] * 30
        state = create_state_with_prices(prices)

        _, opens = strategy.generate_orders(state)

        # Neither condition met
        assert opens == []
