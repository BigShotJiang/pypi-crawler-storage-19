"""Tests for risk management implementations."""

from decimal import Decimal

from deltao.core.state import EngineState
from deltao.core.types import OrderRequest, Side
from deltao.strategy.risk import (
    BasicRiskManager,
    NoOpRiskManager,
    PositionLimitRiskManager,
)


def create_state(
    tao: Decimal = Decimal("100"),
    alpha: Decimal = Decimal("50"),
    price: Decimal = Decimal("10"),
) -> EngineState:
    """Create EngineState with given balances."""
    return EngineState(
        tao_balance=tao,
        alpha_balance=alpha,
        current_price=price,
    )


class TestNoOpRiskManager:
    """Tests for NoOpRiskManager."""

    def test_approves_all_orders(self) -> None:
        """Test NoOp approves all orders."""
        manager = NoOpRiskManager()
        state = create_state()
        orders = [
            OrderRequest(side=Side.BUY, amount=Decimal("10")),
            OrderRequest(side=Side.SELL, amount=Decimal("5")),
        ]

        approved, denied = manager.check(state, orders)

        assert approved == orders
        assert denied == []

    def test_approves_empty_list(self) -> None:
        """Test NoOp handles empty order list."""
        manager = NoOpRiskManager()
        state = create_state()

        approved, denied = manager.check(state, [])

        assert approved == []
        assert denied == []

    def test_approves_large_orders(self) -> None:
        """Test NoOp approves orders larger than balance."""
        manager = NoOpRiskManager()
        state = create_state(tao=Decimal("10"))
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("1000"))]

        approved, denied = manager.check(state, orders)

        assert approved == orders
        assert denied == []


class TestBasicRiskManager:
    """Tests for BasicRiskManager."""

    def test_approves_valid_buy(self) -> None:
        """Test approves buy within limits."""
        manager = BasicRiskManager(
            max_position_size=Decimal("10"),
            max_exposure_pct=Decimal("0.5"),
            min_balance_reserve=Decimal("0.1"),
        )
        state = create_state(tao=Decimal("100"))
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("5"))]

        approved, denied = manager.check(state, orders)

        assert approved == orders
        assert denied == []

    def test_denies_buy_exceeding_position_size(self) -> None:
        """Test denies buy exceeding max_position_size."""
        manager = BasicRiskManager(
            max_position_size=Decimal("10"),
        )
        state = create_state(tao=Decimal("1000"))
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("15"))]

        approved, denied = manager.check(state, orders)

        assert approved == []
        assert denied == orders

    def test_denies_buy_exceeding_exposure(self) -> None:
        """Test denies buy exceeding max_exposure_pct."""
        manager = BasicRiskManager(
            max_position_size=Decimal("100"),
            max_exposure_pct=Decimal("0.2"),  # 20%
            min_balance_reserve=Decimal("0.1"),
        )
        state = create_state(tao=Decimal("100"))
        # Available = 100 * 0.9 = 90, max allowed = 90 * 0.2 = 18
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("20"))]

        approved, denied = manager.check(state, orders)

        assert approved == []
        assert denied == orders

    def test_denies_buy_exceeding_balance(self) -> None:
        """Test denies buy exceeding available balance."""
        manager = BasicRiskManager(
            max_position_size=Decimal("100"),
            max_exposure_pct=Decimal("1.0"),  # 100%
            min_balance_reserve=Decimal("0.1"),
        )
        state = create_state(tao=Decimal("50"))
        # Available = 50 * 0.9 = 45
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("50"))]

        approved, denied = manager.check(state, orders)

        assert approved == []
        assert denied == orders

    def test_approves_valid_sell(self) -> None:
        """Test approves sell within limits."""
        manager = BasicRiskManager(
            max_position_size=Decimal("100"),
        )
        state = create_state(alpha=Decimal("50"))
        orders = [OrderRequest(side=Side.SELL, amount=Decimal("30"))]

        approved, denied = manager.check(state, orders)

        assert approved == orders
        assert denied == []

    def test_denies_sell_exceeding_holdings(self) -> None:
        """Test denies sell exceeding alpha holdings."""
        manager = BasicRiskManager(
            max_position_size=Decimal("100"),
        )
        state = create_state(alpha=Decimal("10"))
        orders = [OrderRequest(side=Side.SELL, amount=Decimal("20"))]

        approved, denied = manager.check(state, orders)

        assert approved == []
        assert denied == orders

    def test_mixed_orders_partial_approval(self) -> None:
        """Test some orders approved, some denied."""
        manager = BasicRiskManager(
            max_position_size=Decimal("10"),
            max_exposure_pct=Decimal("0.5"),
            min_balance_reserve=Decimal("0.1"),
        )
        state = create_state(tao=Decimal("100"), alpha=Decimal("50"))

        orders = [
            OrderRequest(side=Side.BUY, amount=Decimal("5")),  # Valid
            OrderRequest(side=Side.BUY, amount=Decimal("50")),  # Too large
            OrderRequest(side=Side.SELL, amount=Decimal("10")),  # Valid
            OrderRequest(side=Side.SELL, amount=Decimal("100")),  # Exceeds holdings
        ]

        approved, denied = manager.check(state, orders)

        assert len(approved) == 2
        assert len(denied) == 2
        assert orders[0] in approved
        assert orders[2] in approved
        assert orders[1] in denied
        assert orders[3] in denied

    def test_default_values(self) -> None:
        """Test default configuration values."""
        manager = BasicRiskManager()

        assert manager.max_position_size == Decimal("10")
        assert manager.max_exposure_pct == Decimal("0.5")
        assert manager.min_balance_reserve == Decimal("0.1")
        assert manager.max_drawdown is None


class TestPositionLimitRiskManager:
    """Tests for PositionLimitRiskManager."""

    def test_approves_within_limits(self) -> None:
        """Test approves orders within position limits."""
        manager = PositionLimitRiskManager(
            max_total_exposure=Decimal("100"),
            max_single_order=Decimal("20"),
        )
        state = create_state(alpha=Decimal("5"), price=Decimal("10"))
        # Current exposure = 5 * 10 = 50
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("10"))]

        approved, denied = manager.check(state, orders)

        assert approved == orders
        assert denied == []

    def test_denies_exceeding_single_order_limit(self) -> None:
        """Test denies order exceeding max_single_order."""
        manager = PositionLimitRiskManager(
            max_total_exposure=Decimal("1000"),
            max_single_order=Decimal("10"),
        )
        state = create_state()
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("15"))]

        approved, denied = manager.check(state, orders)

        assert approved == []
        assert denied == orders

    def test_denies_buy_exceeding_total_exposure(self) -> None:
        """Test denies buy that would exceed total exposure."""
        manager = PositionLimitRiskManager(
            max_total_exposure=Decimal("100"),
            max_single_order=Decimal("50"),
        )
        state = create_state(alpha=Decimal("8"), price=Decimal("10"))
        # Current exposure = 8 * 10 = 80
        # New exposure would be 80 + 30 = 110 > 100
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("30"))]

        approved, denied = manager.check(state, orders)

        assert approved == []
        assert denied == orders

    def test_allows_sell_reducing_exposure(self) -> None:
        """Test allows sell orders that reduce exposure."""
        manager = PositionLimitRiskManager(
            max_total_exposure=Decimal("100"),
            max_single_order=Decimal("50"),
        )
        state = create_state(alpha=Decimal("10"), price=Decimal("10"))
        # Current exposure = 10 * 10 = 100
        orders = [OrderRequest(side=Side.SELL, amount=Decimal("30"))]

        approved, denied = manager.check(state, orders)

        assert approved == orders
        assert denied == []

    def test_tracks_cumulative_exposure(self) -> None:
        """Test exposure tracking across multiple orders."""
        manager = PositionLimitRiskManager(
            max_total_exposure=Decimal("100"),
            max_single_order=Decimal("30"),
        )
        state = create_state(alpha=Decimal("5"), price=Decimal("10"))
        # Current exposure = 5 * 10 = 50

        orders = [
            OrderRequest(side=Side.BUY, amount=Decimal("20")),  # 50 + 20 = 70
            OrderRequest(side=Side.BUY, amount=Decimal("20")),  # 70 + 20 = 90
            OrderRequest(side=Side.BUY, amount=Decimal("20")),  # 90 + 20 = 110 > 100
        ]

        approved, denied = manager.check(state, orders)

        assert len(approved) == 2
        assert len(denied) == 1
        assert orders[0] in approved
        assert orders[1] in approved
        assert orders[2] in denied

    def test_default_values(self) -> None:
        """Test default configuration values."""
        manager = PositionLimitRiskManager()

        assert manager.max_total_exposure == Decimal("100")
        assert manager.max_single_order == Decimal("10")
        assert manager.current_exposure == Decimal(0)

    def test_exposure_updated_after_check(self) -> None:
        """Test current_exposure is updated after checking orders."""
        manager = PositionLimitRiskManager(
            max_total_exposure=Decimal("100"),
            max_single_order=Decimal("50"),
        )
        state = create_state(alpha=Decimal("5"), price=Decimal("10"))
        orders = [OrderRequest(side=Side.BUY, amount=Decimal("20"))]

        manager.check(state, orders)

        # Exposure should include the approved order
        assert manager.current_exposure == Decimal("70")  # 50 + 20

    def test_sell_decreases_exposure(self) -> None:
        """Test that approved sell orders decrease exposure tracking."""
        manager = PositionLimitRiskManager(
            max_total_exposure=Decimal("100"),
            max_single_order=Decimal("50"),
        )
        state = create_state(alpha=Decimal("10"), price=Decimal("10"))
        orders = [OrderRequest(side=Side.SELL, amount=Decimal("20"))]

        manager.check(state, orders)

        # Exposure = 100 - 20 = 80
        assert manager.current_exposure == Decimal("80")
