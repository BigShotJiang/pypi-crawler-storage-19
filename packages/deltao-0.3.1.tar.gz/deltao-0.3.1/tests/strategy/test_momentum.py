"""Tests for momentum strategy."""

from decimal import Decimal

from deltao.core.state import EngineState
from deltao.core.types import Side
from deltao.strategy.directional.momentum import MomentumStrategy


def create_state_with_prices(
    prices: list[Decimal], tao: Decimal = Decimal("100"), alpha: Decimal = Decimal("50")
) -> EngineState:
    """Create EngineState with given price history."""
    state = EngineState(
        tao_balance=tao,
        alpha_balance=alpha,
        current_price=prices[-1] if prices else Decimal(1),
    )
    for price in prices:
        state.price_history.append(price)
    return state


class TestMomentumStrategy:
    """Tests for MomentumStrategy."""

    def test_init_defaults(self) -> None:
        """Test default initialization."""
        strategy = MomentumStrategy()
        assert strategy.name == "MomentumStrategy"
        assert strategy.fast_period == 10
        assert strategy.slow_period == 30

    def test_insufficient_data_returns_empty(self) -> None:
        """Test strategy returns no orders with insufficient data."""
        strategy = MomentumStrategy()
        prices = [Decimal(i) for i in range(20)]  # Not enough for slow_period + 5
        state = create_state_with_prices(prices)

        cancels, opens = strategy.generate_orders(state)

        assert cancels == []
        assert opens == []

    def test_bullish_momentum_generates_buy(self) -> None:
        """Test buy signal when fast MA > slow MA."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
            min_momentum_pct=Decimal("0.01"),
        )

        # Create upward trending prices
        # Start low, end high so fast MA > slow MA
        prices = [Decimal(10 + i) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("100"))

        cancels, opens = strategy.generate_orders(state)

        assert cancels == []
        assert len(opens) == 1
        assert opens[0].side == Side.BUY

    def test_bearish_momentum_generates_sell(self) -> None:
        """Test sell signal when fast MA < slow MA."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
            min_momentum_pct=Decimal("0.01"),
        )

        # Create downward trending prices
        # Start high, end low so fast MA < slow MA
        prices = [Decimal(30 - i) for i in range(20)]
        state = create_state_with_prices(prices, alpha=Decimal("50"))

        cancels, opens = strategy.generate_orders(state)

        assert cancels == []
        assert len(opens) == 1
        assert opens[0].side == Side.SELL

    def test_no_order_below_min_momentum(self) -> None:
        """Test no order when momentum below threshold."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
            min_momentum_pct=Decimal("0.10"),  # 10% threshold
        )

        # Create flat prices (no momentum)
        prices = [Decimal(100)] * 20
        state = create_state_with_prices(prices)

        cancels, opens = strategy.generate_orders(state)

        assert cancels == []
        assert opens == []

    def test_no_buy_when_no_tao_balance(self) -> None:
        """Test no buy order when TAO balance is insufficient."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
        )

        # Bullish prices but no TAO
        prices = [Decimal(10 + i) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("0"))

        _, opens = strategy.generate_orders(state)

        assert opens == []

    def test_no_sell_when_no_alpha_balance(self) -> None:
        """Test no sell order when Alpha balance is zero."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
        )

        # Bearish prices but no Alpha
        prices = [Decimal(30 - i) for i in range(20)]
        state = create_state_with_prices(prices, alpha=Decimal("0"))

        _, opens = strategy.generate_orders(state)

        assert opens == []

    def test_order_size_clamped_to_max(self) -> None:
        """Test order size is clamped to max_order_size."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
            base_order_size=Decimal("1000"),  # Very large base
        )
        strategy.max_order_size = Decimal("10")

        # Strong bullish momentum
        prices = [Decimal(10 + i * 2) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("1000"))

        _, opens = strategy.generate_orders(state)

        if opens:
            assert opens[0].amount <= strategy.max_order_size

    def test_order_size_at_least_min(self) -> None:
        """Test order size is at least min_order_size."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
            base_order_size=Decimal("0.001"),  # Very small base
        )

        # Bullish momentum
        prices = [Decimal(10 + i) for i in range(20)]
        state = create_state_with_prices(prices, tao=Decimal("100"))

        _, opens = strategy.generate_orders(state)

        if opens:
            assert opens[0].amount >= strategy.min_order_size

    def test_slippage_tolerance_set(self) -> None:
        """Test orders have slippage tolerance set."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
        )

        prices = [Decimal(10 + i) for i in range(20)]
        state = create_state_with_prices(prices)

        _, opens = strategy.generate_orders(state)

        if opens:
            assert opens[0].slippage_tolerance == Decimal("0.02")

    def test_position_size_scales_with_momentum(self) -> None:
        """Test position size increases with momentum strength."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
            momentum_multiplier=Decimal("1.0"),
        )

        # Weak momentum
        weak_prices = [Decimal(100 + i * 0.5) for i in range(20)]
        weak_state = create_state_with_prices(weak_prices, tao=Decimal("1000"))

        # Strong momentum
        strong_prices = [Decimal(100 + i * 5) for i in range(20)]
        strong_state = create_state_with_prices(strong_prices, tao=Decimal("1000"))

        _, weak_opens = strategy.generate_orders(weak_state)
        _, strong_opens = strategy.generate_orders(strong_state)

        # Strong momentum should have larger order size
        if weak_opens and strong_opens:
            assert strong_opens[0].amount >= weak_opens[0].amount

    def test_sell_size_proportional_to_holdings(self) -> None:
        """Test sell size is proportional to alpha holdings."""
        strategy = MomentumStrategy(
            fast_period=5,
            slow_period=10,
        )

        # Bearish prices
        prices = [Decimal(30 - i) for i in range(20)]

        small_holdings = create_state_with_prices(prices, alpha=Decimal("10"))
        large_holdings = create_state_with_prices(prices, alpha=Decimal("100"))

        _, small_opens = strategy.generate_orders(small_holdings)
        _, large_opens = strategy.generate_orders(large_holdings)

        if small_opens and large_opens:
            assert large_opens[0].amount > small_opens[0].amount
