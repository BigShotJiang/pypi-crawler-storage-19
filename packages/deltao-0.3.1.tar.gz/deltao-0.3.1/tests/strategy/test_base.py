"""Tests for base strategy utilities."""

from decimal import Decimal

from deltao.strategy.base import (
    calculate_ema,
    calculate_rsi,
    calculate_sma,
    calculate_volatility,
)


class TestCalculateSMA:
    """Tests for SMA calculation."""

    def test_sma_basic(self) -> None:
        """Test basic SMA calculation."""
        prices = [Decimal(i) for i in [10, 20, 30, 40, 50]]
        result = calculate_sma(prices, 5)
        assert result == Decimal(30)

    def test_sma_insufficient_data(self) -> None:
        """Test SMA with insufficient data returns None."""
        prices = [Decimal(10), Decimal(20)]
        result = calculate_sma(prices, 5)
        assert result is None

    def test_sma_uses_recent_prices(self) -> None:
        """Test SMA uses most recent prices."""
        prices = [Decimal(i) for i in [1, 2, 3, 100, 200, 300]]
        result = calculate_sma(prices, 3)
        # Should use [100, 200, 300]
        assert result == Decimal(200)

    def test_sma_single_period(self) -> None:
        """Test SMA with period of 1."""
        prices = [Decimal(10), Decimal(20), Decimal(30)]
        result = calculate_sma(prices, 1)
        assert result == Decimal(30)


class TestCalculateEMA:
    """Tests for EMA calculation."""

    def test_ema_basic(self) -> None:
        """Test basic EMA calculation."""
        prices = [Decimal(i) for i in range(1, 11)]
        result = calculate_ema(prices, 5)
        assert result is not None
        # EMA should be close to but not equal to SMA
        assert result > Decimal(5)

    def test_ema_insufficient_data(self) -> None:
        """Test EMA with insufficient data returns None."""
        prices = [Decimal(10), Decimal(20)]
        result = calculate_ema(prices, 5)
        assert result is None

    def test_ema_weights_recent_more(self) -> None:
        """Test EMA weights recent prices more heavily."""
        # Prices jump from 10 to 100
        prices = [Decimal(10)] * 10 + [Decimal(100)]
        ema = calculate_ema(prices, 5)
        sma = calculate_sma(prices, 5)

        assert ema is not None
        assert sma is not None
        # EMA should react faster to recent price jump
        assert ema > sma


class TestCalculateRSI:
    """Tests for RSI calculation."""

    def test_rsi_all_gains(self) -> None:
        """Test RSI when all price changes are gains."""
        prices = [Decimal(i) for i in range(1, 20)]
        result = calculate_rsi(prices, 14)
        assert result == Decimal(100)

    def test_rsi_insufficient_data(self) -> None:
        """Test RSI with insufficient data returns None."""
        prices = [Decimal(10), Decimal(20)]
        result = calculate_rsi(prices, 14)
        assert result is None

    def test_rsi_mixed_gains_losses(self) -> None:
        """Test RSI with mixed gains and losses."""
        # Alternating up and down
        prices = [Decimal(10 + (i % 2)) for i in range(20)]
        result = calculate_rsi(prices, 14)
        assert result is not None
        # Should be around 50 for equal gains/losses
        assert Decimal(40) < result < Decimal(60)

    def test_rsi_range(self) -> None:
        """Test RSI is always between 0 and 100."""
        import random

        prices = [Decimal(random.randint(1, 100)) for _ in range(50)]
        result = calculate_rsi(prices, 14)
        assert result is not None
        assert Decimal(0) <= result <= Decimal(100)


class TestCalculateVolatility:
    """Tests for volatility calculation."""

    def test_volatility_constant_prices(self) -> None:
        """Test volatility is zero for constant prices."""
        prices = [Decimal(10)] * 10
        result = calculate_volatility(prices, 5)
        assert result == Decimal(0)

    def test_volatility_insufficient_data(self) -> None:
        """Test volatility with insufficient data returns None."""
        prices = [Decimal(10), Decimal(20)]
        result = calculate_volatility(prices, 5)
        assert result is None

    def test_volatility_positive(self) -> None:
        """Test volatility is positive for varying prices."""
        prices = [Decimal(i) for i in [10, 20, 10, 20, 10]]
        result = calculate_volatility(prices, 5)
        assert result is not None
        assert result > Decimal(0)

    def test_volatility_larger_swings(self) -> None:
        """Test higher volatility for larger price swings."""
        small_swings = [Decimal(i) for i in [10, 11, 10, 11, 10]]
        large_swings = [Decimal(i) for i in [10, 50, 10, 50, 10]]

        vol_small = calculate_volatility(small_swings, 5)
        vol_large = calculate_volatility(large_swings, 5)

        assert vol_small is not None
        assert vol_large is not None
        assert vol_large > vol_small
