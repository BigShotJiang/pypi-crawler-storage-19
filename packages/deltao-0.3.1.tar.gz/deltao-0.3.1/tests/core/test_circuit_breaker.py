"""Tests for circuit breaker implementation."""

from datetime import datetime
from decimal import Decimal

from deltao.core.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    CircuitBreakerState,
    TriggerType,
    TripEvent,
)
from deltao.core.portfolio import PortfolioMetrics


def create_metrics(
    total_capital: Decimal = Decimal("1000"),
    allocated_capital: Decimal = Decimal("500"),
    max_drawdown: Decimal = Decimal("0.05"),
) -> PortfolioMetrics:
    """Create PortfolioMetrics with given values."""
    return PortfolioMetrics(
        total_capital=total_capital,
        allocated_capital=allocated_capital,
        max_drawdown=max_drawdown,
    )


class TestCircuitBreakerConfig:
    """Tests for CircuitBreakerConfig."""

    def test_default_values(self) -> None:
        """Test default configuration values."""
        config = CircuitBreakerConfig()

        assert config.max_drawdown == Decimal("0.15")
        assert config.max_consecutive_losses == 5
        assert config.max_loss_rate == Decimal("0.7")
        assert config.loss_rate_window == 20
        assert config.max_total_exposure == Decimal("0.9")
        assert config.volatility_threshold == Decimal("0.1")
        assert config.volatility_period == 20

    def test_custom_values(self) -> None:
        """Test custom configuration values."""
        config = CircuitBreakerConfig(
            max_drawdown=Decimal("0.2"),
            max_consecutive_losses=3,
            max_loss_rate=Decimal("0.5"),
            loss_rate_window=10,
            max_total_exposure=Decimal("0.8"),
            volatility_threshold=Decimal("0.05"),
            volatility_period=30,
        )

        assert config.max_drawdown == Decimal("0.2")
        assert config.max_consecutive_losses == 3
        assert config.max_loss_rate == Decimal("0.5")
        assert config.loss_rate_window == 10
        assert config.max_total_exposure == Decimal("0.8")
        assert config.volatility_threshold == Decimal("0.05")
        assert config.volatility_period == 30


class TestTripEvent:
    """Tests for TripEvent."""

    def test_to_dict(self) -> None:
        """Test TripEvent serialization."""
        timestamp = datetime(2025, 1, 1, 12, 0, 0)
        event = TripEvent(
            trigger=TriggerType.DRAWDOWN,
            value=Decimal("0.20"),
            threshold=Decimal("0.15"),
            timestamp=timestamp,
            message="Drawdown exceeded",
        )

        result = event.to_dict()

        assert result["trigger"] == "drawdown"
        assert result["value"] == "0.20"
        assert result["threshold"] == "0.15"
        assert result["timestamp"] == "2025-01-01T12:00:00"
        assert result["message"] == "Drawdown exceeded"


class TestCircuitBreakerInitialization:
    """Tests for CircuitBreaker initialization."""

    def test_default_state_is_active(self) -> None:
        """Test circuit breaker starts in ACTIVE state."""
        cb = CircuitBreaker()

        assert cb.state == CircuitBreakerState.ACTIVE
        assert cb.is_active
        assert not cb.is_tripped

    def test_no_initial_trip_event(self) -> None:
        """Test no trip event initially."""
        cb = CircuitBreaker()

        assert cb.trip_event is None
        assert len(cb.trip_history) == 0

    def test_empty_trade_outcomes(self) -> None:
        """Test trade outcomes start empty."""
        cb = CircuitBreaker()

        assert len(cb.trade_outcomes) == 0
        assert cb.consecutive_losses == 0


class TestDrawdownTrigger:
    """Tests for drawdown trigger."""

    def test_passes_below_threshold(self) -> None:
        """Test passes when drawdown below threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_drawdown=Decimal("0.15")))
        metrics = create_metrics(max_drawdown=Decimal("0.10"))

        result = cb.check(metrics)

        assert result is True
        assert cb.is_active

    def test_trips_at_threshold(self) -> None:
        """Test trips when drawdown equals threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_drawdown=Decimal("0.15")))
        metrics = create_metrics(max_drawdown=Decimal("0.16"))

        result = cb.check(metrics)

        assert result is False
        assert cb.is_tripped
        assert cb.trip_event is not None
        assert cb.trip_event.trigger == TriggerType.DRAWDOWN
        assert cb.trip_event.value == Decimal("0.16")

    def test_trips_above_threshold(self) -> None:
        """Test trips when drawdown exceeds threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_drawdown=Decimal("0.15")))
        metrics = create_metrics(max_drawdown=Decimal("0.25"))

        result = cb.check(metrics)

        assert result is False
        assert cb.is_tripped


class TestExposureTrigger:
    """Tests for exposure trigger."""

    def test_passes_below_threshold(self) -> None:
        """Test passes when exposure below threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_total_exposure=Decimal("0.9")))
        metrics = create_metrics(
            total_capital=Decimal("1000"),
            allocated_capital=Decimal("800"),  # 80%
        )

        result = cb.check(metrics)

        assert result is True
        assert cb.is_active

    def test_trips_above_threshold(self) -> None:
        """Test trips when exposure exceeds threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_total_exposure=Decimal("0.9")))
        metrics = create_metrics(
            total_capital=Decimal("1000"),
            allocated_capital=Decimal("950"),  # 95%
        )

        result = cb.check(metrics)

        assert result is False
        assert cb.is_tripped
        assert cb.trip_event is not None
        assert cb.trip_event.trigger == TriggerType.EXPOSURE

    def test_handles_zero_capital(self) -> None:
        """Test handles zero capital gracefully."""
        cb = CircuitBreaker()
        metrics = create_metrics(
            total_capital=Decimal("0"),
            allocated_capital=Decimal("0"),
        )

        result = cb.check(metrics)

        assert result is True  # No trip when capital is zero


class TestLossRateTrigger:
    """Tests for loss rate trigger."""

    def test_passes_with_good_loss_rate(self) -> None:
        """Test passes when loss rate is acceptable."""
        config = CircuitBreakerConfig(
            max_loss_rate=Decimal("0.7"),
            loss_rate_window=10,
            max_consecutive_losses=20,  # High limit to not trigger
        )
        cb = CircuitBreaker(config)
        metrics = create_metrics()

        # Record 6 wins, 4 losses (40% loss rate)
        for _ in range(6):
            cb.record_trade_outcome(is_win=True)
        for _ in range(4):
            cb.record_trade_outcome(is_win=False)

        result = cb.check(metrics)

        assert result is True
        assert cb.is_active

    def test_trips_with_high_loss_rate(self) -> None:
        """Test trips when loss rate exceeds threshold."""
        config = CircuitBreakerConfig(
            max_loss_rate=Decimal("0.7"),
            loss_rate_window=10,
            max_consecutive_losses=20,  # High limit to not trigger
        )
        cb = CircuitBreaker(config)
        metrics = create_metrics()

        # Record pattern that gives 80% loss rate without consecutive losses
        # W L L W L L L L L L = 2 wins, 8 losses (80%)
        cb.record_trade_outcome(is_win=True)
        cb.record_trade_outcome(is_win=False)
        cb.record_trade_outcome(is_win=False)
        cb.record_trade_outcome(is_win=True)
        for _ in range(6):
            cb.record_trade_outcome(is_win=False)

        result = cb.check(metrics)

        assert result is False
        assert cb.is_tripped
        assert cb.trip_event is not None
        assert cb.trip_event.trigger == TriggerType.LOSS_RATE

    def test_ignores_loss_rate_before_window_filled(self) -> None:
        """Test loss rate check only applies when window is filled."""
        config = CircuitBreakerConfig(
            max_loss_rate=Decimal("0.7"),
            loss_rate_window=10,
            max_consecutive_losses=20,  # High limit to not trigger
        )
        cb = CircuitBreaker(config)
        metrics = create_metrics()

        # Record 5 losses (100% loss rate but window not full)
        for _ in range(5):
            cb.record_trade_outcome(is_win=False)

        result = cb.check(metrics)

        assert result is True  # Window not full, so loss rate not checked


class TestConsecutiveLossesTrigger:
    """Tests for consecutive losses trigger."""

    def test_passes_below_threshold(self) -> None:
        """Test passes when consecutive losses below threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_consecutive_losses=5))
        metrics = create_metrics()

        # Record 4 consecutive losses
        for _ in range(4):
            cb.record_trade_outcome(is_win=False)

        result = cb.check(metrics)

        assert result is True
        assert cb.is_active
        assert cb.consecutive_losses == 4

    def test_trips_at_threshold(self) -> None:
        """Test trips when consecutive losses reach threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_consecutive_losses=5))
        metrics = create_metrics()

        # Record 5 consecutive losses
        for _ in range(5):
            cb.record_trade_outcome(is_win=False)

        result = cb.check(metrics)

        assert result is False
        assert cb.is_tripped
        assert cb.trip_event is not None
        assert cb.trip_event.trigger == TriggerType.CONSECUTIVE_LOSSES

    def test_resets_on_win(self) -> None:
        """Test consecutive losses resets on win."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_consecutive_losses=5))

        # Record 3 losses, then a win
        for _ in range(3):
            cb.record_trade_outcome(is_win=False)
        cb.record_trade_outcome(is_win=True)

        assert cb.consecutive_losses == 0

        # Record 4 more losses
        for _ in range(4):
            cb.record_trade_outcome(is_win=False)

        assert cb.consecutive_losses == 4


class TestVolatilityTrigger:
    """Tests for volatility trigger."""

    def test_passes_below_threshold(self) -> None:
        """Test passes when volatility below threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(volatility_threshold=Decimal("0.1")))
        metrics = create_metrics()

        result = cb.check(metrics, volatility=Decimal("0.05"))

        assert result is True
        assert cb.is_active

    def test_trips_above_threshold(self) -> None:
        """Test trips when volatility exceeds threshold."""
        cb = CircuitBreaker(CircuitBreakerConfig(volatility_threshold=Decimal("0.1")))
        metrics = create_metrics()

        result = cb.check(metrics, volatility=Decimal("0.15"))

        assert result is False
        assert cb.is_tripped
        assert cb.trip_event is not None
        assert cb.trip_event.trigger == TriggerType.VOLATILITY

    def test_ignores_none_volatility(self) -> None:
        """Test volatility check skipped when volatility is None."""
        cb = CircuitBreaker(CircuitBreakerConfig(volatility_threshold=Decimal("0.1")))
        metrics = create_metrics()

        result = cb.check(metrics, volatility=None)

        assert result is True


class TestCircuitBreakerReset:
    """Tests for circuit breaker reset."""

    def test_reset_clears_trip_state(self) -> None:
        """Test reset clears trip event and state."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_drawdown=Decimal("0.1")))
        metrics = create_metrics(max_drawdown=Decimal("0.15"))

        # Trip the circuit breaker
        cb.check(metrics)
        assert cb.is_tripped

        # Reset
        cb.reset()

        assert cb.is_active
        assert cb.trip_event is None

    def test_reset_preserves_trade_history(self) -> None:
        """Test reset preserves trade outcomes and consecutive losses."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_consecutive_losses=10))

        # Record some losses
        for _ in range(5):
            cb.record_trade_outcome(is_win=False)

        # Manually set tripped state for test
        cb.state = CircuitBreakerState.TRIPPED

        # Reset
        cb.reset()

        # Trade history should be preserved
        assert cb.consecutive_losses == 5
        assert len(cb.trade_outcomes) == 5

    def test_full_reset_clears_everything(self) -> None:
        """Test full reset clears all state."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_consecutive_losses=10))

        # Record some losses
        for _ in range(5):
            cb.record_trade_outcome(is_win=False)

        # Manually set tripped state
        cb.state = CircuitBreakerState.TRIPPED

        # Full reset
        cb.reset_full()

        assert cb.is_active
        assert cb.trip_event is None
        assert cb.consecutive_losses == 0
        assert len(cb.trade_outcomes) == 0

    def test_trip_history_preserved_after_reset(self) -> None:
        """Test trip history is preserved after reset."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_drawdown=Decimal("0.1")))
        metrics = create_metrics(max_drawdown=Decimal("0.15"))

        # Trip and reset multiple times
        cb.check(metrics)
        cb.reset()
        cb.check(metrics)
        cb.reset()

        assert len(cb.trip_history) == 2


class TestCircuitBreakerTrippedState:
    """Tests for behavior when circuit breaker is tripped."""

    def test_check_returns_false_when_tripped(self) -> None:
        """Test check always returns False when tripped."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_drawdown=Decimal("0.1")))
        metrics_bad = create_metrics(max_drawdown=Decimal("0.15"))
        metrics_good = create_metrics(max_drawdown=Decimal("0.05"))

        # Trip with bad metrics
        cb.check(metrics_bad)
        assert cb.is_tripped

        # Check with good metrics still returns False
        result = cb.check(metrics_good)

        assert result is False
        assert cb.is_tripped  # Still tripped


class TestCircuitBreakerStatus:
    """Tests for circuit breaker status reporting."""

    def test_get_status_active(self) -> None:
        """Test status when active."""
        cb = CircuitBreaker()

        # Record some trades
        cb.record_trade_outcome(is_win=True)
        cb.record_trade_outcome(is_win=False)
        cb.record_trade_outcome(is_win=True)

        status = cb.get_status()

        assert status["state"] == "active"
        assert status["is_tripped"] is False
        assert status["trip_event"] is None
        assert status["metrics"]["consecutive_losses"] == 0
        assert status["metrics"]["total_trades_tracked"] == 3
        assert status["trip_count"] == 0

    def test_get_status_tripped(self) -> None:
        """Test status when tripped."""
        cb = CircuitBreaker(CircuitBreakerConfig(max_drawdown=Decimal("0.1")))
        metrics = create_metrics(max_drawdown=Decimal("0.15"))

        cb.check(metrics)

        status = cb.get_status()

        assert status["state"] == "tripped"
        assert status["is_tripped"] is True
        assert status["trip_event"] is not None
        assert status["trip_event"]["trigger"] == "drawdown"
        assert status["trip_count"] == 1

    def test_get_status_includes_config(self) -> None:
        """Test status includes configuration."""
        config = CircuitBreakerConfig(
            max_drawdown=Decimal("0.2"),
            max_consecutive_losses=3,
        )
        cb = CircuitBreaker(config)

        status = cb.get_status()

        assert status["config"]["max_drawdown"] == "0.2"
        assert status["config"]["max_consecutive_losses"] == 3


class TestMultipleTriggers:
    """Tests for multiple trigger conditions."""

    def test_first_trigger_wins(self) -> None:
        """Test first failing trigger is recorded."""
        config = CircuitBreakerConfig(
            max_drawdown=Decimal("0.1"),
            max_total_exposure=Decimal("0.8"),
        )
        cb = CircuitBreaker(config)

        # Both drawdown and exposure exceed thresholds
        metrics = create_metrics(
            total_capital=Decimal("1000"),
            allocated_capital=Decimal("900"),  # 90% > 80% threshold
            max_drawdown=Decimal("0.15"),  # 15% > 10% threshold
        )

        cb.check(metrics)

        # Drawdown is checked first, so it should be the trigger
        assert cb.trip_event is not None
        assert cb.trip_event.trigger == TriggerType.DRAWDOWN

    def test_all_checks_must_pass(self) -> None:
        """Test all checks must pass for circuit breaker to stay active."""
        config = CircuitBreakerConfig(
            max_drawdown=Decimal("0.2"),
            max_total_exposure=Decimal("0.95"),
            max_consecutive_losses=10,
            volatility_threshold=Decimal("0.2"),
        )
        cb = CircuitBreaker(config)

        # All metrics within limits
        metrics = create_metrics(
            total_capital=Decimal("1000"),
            allocated_capital=Decimal("800"),
            max_drawdown=Decimal("0.1"),
        )

        result = cb.check(metrics, volatility=Decimal("0.05"))

        assert result is True
        assert cb.is_active
