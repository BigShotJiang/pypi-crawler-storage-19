"""Tests for engine state."""

from datetime import datetime
from decimal import Decimal

from deltao.core.event import AccountEvent, MarketEvent, TradingStateUpdate
from deltao.core.state import EngineState


def test_engine_state_defaults():
    """Test EngineState default values."""
    state = EngineState()

    assert state.trading_enabled is True
    assert state.tao_balance == Decimal(0)
    assert state.alpha_balance == Decimal(0)
    assert state.positions == []
    assert state.current_price == Decimal(1)
    assert state.current_block == 0
    assert len(state.price_history) == 0


def test_engine_state_custom_values():
    """Test EngineState with custom values."""
    state = EngineState(
        trading_enabled=False,
        tao_balance=Decimal("100"),
        alpha_balance=Decimal("50"),
    )

    assert state.trading_enabled is False
    assert state.tao_balance == Decimal("100")
    assert state.alpha_balance == Decimal("50")


def test_update_from_market_event():
    """Test state update from MarketEvent."""
    state = EngineState()
    event = MarketEvent(
        netuid=8,
        price=Decimal("1.5"),
        tao_in=Decimal("1000"),
        alpha_in=Decimal("1500"),
        k=Decimal("1500000"),
        block_number=100,
        timestamp=datetime.now(),
    )

    state.update_from_market_event(event)

    assert state.current_price == Decimal("1.5")
    assert state.tao_in == Decimal("1000")
    assert state.alpha_in == Decimal("1500")
    assert state.k == Decimal("1500000")
    assert state.current_block == 100
    assert len(state.price_history) == 1
    assert state.price_history[0] == Decimal("1.5")


def test_price_history_maxlen():
    """Test price history deque maxlen."""
    state = EngineState()

    # Add 1001 prices
    for i in range(1001):
        event = MarketEvent(
            netuid=8,
            price=Decimal(str(i)),
            tao_in=Decimal("1000"),
            alpha_in=Decimal("1000"),
            k=Decimal("1000000"),
            block_number=i,
            timestamp=datetime.now(),
        )
        state.update_from_market_event(event)

    # Should only keep last 1000
    assert len(state.price_history) == 1000
    assert state.price_history[0] == Decimal("1")
    assert state.price_history[-1] == Decimal("1000")


def test_update_from_account_event():
    """Test state update from AccountEvent."""
    state = EngineState()
    event = AccountEvent(
        tao_balance=Decimal("200"),
        alpha_balance=Decimal("100"),
        positions=[],
        timestamp=datetime.now(),
    )

    state.update_from_account_event(event)

    assert state.tao_balance == Decimal("200")
    assert state.alpha_balance == Decimal("100")
    assert state.positions == []


def test_update_from_trading_state():
    """Test state update from TradingStateUpdate."""
    state = EngineState()
    assert state.trading_enabled is True

    event = TradingStateUpdate(
        enabled=False,
        reason="Risk limit",
        timestamp=datetime.now(),
    )

    state.update_from_trading_state(event)

    assert state.trading_enabled is False
