"""Tests for engine processor."""

from datetime import datetime
from decimal import Decimal

import pytest

from deltao.connector.mock import MockConnector
from deltao.core.clock import LiveClock
from deltao.core.engine import Engine
from deltao.core.event import MarketEvent, ShutdownEvent, TradingStateUpdate
from deltao.core.state import EngineState
from deltao.core.types import OrderRequest, Side


# Simple test strategy
class TestStrategy:
    """Test strategy that always generates one order."""

    def generate_orders(self, _state):
        """Generate test orders."""
        order = OrderRequest(side=Side.BUY, amount=Decimal("10"))
        return ([], [order])


# Simple test risk manager
class TestRiskManager:
    """Test risk manager that approves all orders."""

    def check(self, _state, orders):
        """Approve all orders."""
        return (orders, [])


@pytest.mark.asyncio
async def test_engine_initialization():
    """Test Engine initialization."""
    clock = LiveClock()
    state = EngineState()
    strategy = TestStrategy()
    risk = TestRiskManager()
    connector = MockConnector()

    engine = Engine(
        clock=clock,
        state=state,
        strategy=strategy,
        risk=risk,
        connector=connector,
    )

    assert engine.clock == clock
    assert engine.state == state
    assert engine.strategy == strategy
    assert engine.risk == risk
    assert engine.connector == connector
    assert engine.sequence == 0


@pytest.mark.asyncio
async def test_engine_process_market_event():
    """Test engine processes MarketEvent."""
    engine = Engine(
        clock=LiveClock(),
        state=EngineState(),
        strategy=TestStrategy(),
        risk=TestRiskManager(),
        connector=MockConnector(),
    )

    event = MarketEvent(
        netuid=8,
        price=Decimal("1.5"),
        tao_in=Decimal("1000"),
        alpha_in=Decimal("1500"),
        k=Decimal("1500000"),
        block_number=100,
        timestamp=datetime.now(),
    )

    audit = await engine.process(event)

    # State should be updated
    assert engine.state.current_price == Decimal("1.5")
    assert engine.state.current_block == 100

    # Orders should be generated and approved
    assert len(audit.orders_generated) == 1
    assert len(audit.orders_approved) == 1
    assert audit.orders_generated[0].side == Side.BUY

    # Sequence should increment
    assert engine.sequence == 1


@pytest.mark.asyncio
async def test_engine_process_shutdown_event():
    """Test engine processes ShutdownEvent."""
    engine = Engine(
        clock=LiveClock(),
        state=EngineState(),
        strategy=TestStrategy(),
        risk=TestRiskManager(),
        connector=MockConnector(),
    )

    event = ShutdownEvent(reason="Test shutdown", timestamp=datetime.now())

    audit = await engine.process(event)

    # No orders should be generated on shutdown
    assert len(audit.orders_generated) == 0
    assert len(audit.orders_approved) == 0


@pytest.mark.asyncio
async def test_engine_respects_trading_disabled():
    """Test engine doesn't generate orders when trading is disabled."""
    state = EngineState(trading_enabled=False)
    engine = Engine(
        clock=LiveClock(),
        state=state,
        strategy=TestStrategy(),
        risk=TestRiskManager(),
        connector=MockConnector(),
    )

    event = MarketEvent(
        netuid=8,
        price=Decimal("1.0"),
        tao_in=Decimal("1000"),
        alpha_in=Decimal("1000"),
        k=Decimal("1000000"),
        block_number=100,
        timestamp=datetime.now(),
    )

    audit = await engine.process(event)

    # No orders should be generated
    assert len(audit.orders_generated) == 0
    assert len(audit.orders_approved) == 0


@pytest.mark.asyncio
async def test_engine_trading_state_update():
    """Test engine updates trading state."""
    state = EngineState(trading_enabled=True)
    engine = Engine(
        clock=LiveClock(),
        state=state,
        strategy=TestStrategy(),
        risk=TestRiskManager(),
        connector=MockConnector(),
    )

    event = TradingStateUpdate(
        enabled=False,
        reason="Risk limit",
        timestamp=datetime.now(),
    )

    await engine.process(event)

    assert engine.state.trading_enabled is False
