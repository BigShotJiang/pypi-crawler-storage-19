"""Tests for clock abstraction."""

from datetime import datetime, timedelta

import pytest

from deltao.core.clock import HistoricalClock, LiveClock


def test_live_clock_now():
    """Test LiveClock.now() returns current time."""
    clock = LiveClock()
    now1 = clock.now()
    now2 = datetime.now()

    # Should be very close (within 1 second)
    assert abs((now2 - now1).total_seconds()) < 1


def test_live_clock_update_noop():
    """Test LiveClock.update() is a no-op."""
    clock = LiveClock()
    timestamp = datetime.now()

    # Should not raise any errors
    clock.update(timestamp)


def test_historical_clock_initialization():
    """Test HistoricalClock initialization."""
    start_time = datetime(2024, 1, 1, 0, 0, 0)
    clock = HistoricalClock(start_time)

    assert clock.now() == start_time


def test_historical_clock_update():
    """Test HistoricalClock.update() advances time."""
    start_time = datetime(2024, 1, 1, 0, 0, 0)
    clock = HistoricalClock(start_time)

    new_time = start_time + timedelta(hours=1)
    clock.update(new_time)

    assert clock.now() == new_time


def test_historical_clock_cannot_go_back():
    """Test HistoricalClock raises error when going back in time."""
    start_time = datetime(2024, 1, 1, 12, 0, 0)
    clock = HistoricalClock(start_time)

    past_time = start_time - timedelta(hours=1)

    with pytest.raises(ValueError, match="Cannot go back in time"):
        clock.update(past_time)


def test_historical_clock_same_time_allowed():
    """Test HistoricalClock allows updating to same time."""
    start_time = datetime(2024, 1, 1, 0, 0, 0)
    clock = HistoricalClock(start_time)

    # Should not raise error
    clock.update(start_time)

    assert clock.now() == start_time
