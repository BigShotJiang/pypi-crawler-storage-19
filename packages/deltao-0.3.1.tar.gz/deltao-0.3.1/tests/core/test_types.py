"""Tests for trading types."""

from decimal import Decimal

from deltao.core.types import LiquidityPosition, OrderRequest, OrderResult, Side


def test_side_enum():
    """Test Side enum values."""
    assert Side.BUY.value == "buy"
    assert Side.SELL.value == "sell"


def test_order_request():
    """Test OrderRequest creation."""
    order = OrderRequest(
        side=Side.BUY,
        amount=Decimal("100"),
        slippage_tolerance=Decimal("0.02"),
        hotkey="test_hotkey",
    )

    assert order.side == Side.BUY
    assert order.amount == Decimal("100")
    assert order.slippage_tolerance == Decimal("0.02")
    assert order.hotkey == "test_hotkey"


def test_order_request_defaults():
    """Test OrderRequest default values."""
    order = OrderRequest(side=Side.SELL, amount=Decimal("50"))

    assert order.slippage_tolerance == Decimal("0.01")
    assert order.hotkey is None


def test_order_result():
    """Test OrderResult creation."""
    result = OrderResult(
        success=True,
        message="Order executed",
        tx_hash="0x123",
        block_number=1000,
    )

    assert result.success is True
    assert result.message == "Order executed"
    assert result.tx_hash == "0x123"
    assert result.block_number == 1000


def test_liquidity_position():
    """Test LiquidityPosition creation."""
    position = LiquidityPosition(
        position_id=1,
        netuid=8,
        tick_low=-1000,
        tick_high=1000,
        liquidity=10000,
        fees_tao=Decimal("5"),
        fees_alpha=Decimal("3"),
    )

    assert position.position_id == 1
    assert position.netuid == 8
    assert position.tick_low == -1000
    assert position.tick_high == 1000
    assert position.liquidity == 10000
    assert position.fees_tao == Decimal("5")
    assert position.fees_alpha == Decimal("3")


def test_liquidity_position_is_in_range():
    """Test LiquidityPosition.is_in_range()."""
    position = LiquidityPosition(
        position_id=1,
        netuid=8,
        tick_low=-1000,
        tick_high=1000,
        liquidity=10000,
        fees_tao=Decimal("0"),
        fees_alpha=Decimal("0"),
    )

    # Current price at tick 0 = 1.0
    assert position.is_in_range(Decimal("1.0")) is True

    # Test extreme prices
    assert position.is_in_range(Decimal("0.5")) is False
    assert position.is_in_range(Decimal("2.0")) is False
