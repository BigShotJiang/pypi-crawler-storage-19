"""Tests for event types."""

from datetime import datetime
from decimal import Decimal

from deltao.core.event import (
    AccountEvent,
    CommandEvent,
    EventType,
    MarketEvent,
    ShutdownEvent,
    TradingStateUpdate,
)


def test_event_type_enum():
    """Test EventType enum values."""
    assert EventType.SHUTDOWN.value == "shutdown"
    assert EventType.COMMAND.value == "command"
    assert EventType.TRADING_STATE_UPDATE.value == "trading_state_update"
    assert EventType.MARKET.value == "market"
    assert EventType.ACCOUNT.value == "account"


def test_shutdown_event():
    """Test ShutdownEvent creation."""
    timestamp = datetime.now()
    event = ShutdownEvent(reason="Test shutdown", timestamp=timestamp)

    assert event.reason == "Test shutdown"
    assert event.timestamp == timestamp


def test_command_event():
    """Test CommandEvent creation."""
    timestamp = datetime.now()
    params = {"param1": "value1"}
    event = CommandEvent(command="start", params=params, timestamp=timestamp)

    assert event.command == "start"
    assert event.params == params
    assert event.timestamp == timestamp


def test_trading_state_update():
    """Test TradingStateUpdate event."""
    timestamp = datetime.now()
    event = TradingStateUpdate(
        enabled=False, reason="Risk limit exceeded", timestamp=timestamp
    )

    assert event.enabled is False
    assert event.reason == "Risk limit exceeded"
    assert event.timestamp == timestamp


def test_market_event():
    """Test MarketEvent creation."""
    timestamp = datetime.now()
    event = MarketEvent(
        netuid=8,
        price=Decimal("1.5"),
        tao_in=Decimal("1000"),
        alpha_in=Decimal("1500"),
        k=Decimal("1500000"),
        block_number=12345,
        timestamp=timestamp,
    )

    assert event.netuid == 8
    assert event.price == Decimal("1.5")
    assert event.tao_in == Decimal("1000")
    assert event.alpha_in == Decimal("1500")
    assert event.k == Decimal("1500000")
    assert event.block_number == 12345
    assert event.timestamp == timestamp


def test_account_event():
    """Test AccountEvent creation."""
    timestamp = datetime.now()
    event = AccountEvent(
        tao_balance=Decimal("100"),
        alpha_balance=Decimal("50"),
        positions=[],
        timestamp=timestamp,
    )

    assert event.tao_balance == Decimal("100")
    assert event.alpha_balance == Decimal("50")
    assert event.positions == []
    assert event.timestamp == timestamp
