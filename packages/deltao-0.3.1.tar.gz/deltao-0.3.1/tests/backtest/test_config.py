"""Tests for backtest configuration."""

from decimal import Decimal
from pathlib import Path

import pytest

from deltao.backtest.config import BacktestConfig, BacktestingConfig


class TestBacktestConfig:
    """Tests for BacktestConfig."""

    def test_valid_config(self) -> None:
        """Test creating valid config."""
        config = BacktestConfig(
            netuid=8,
            start_block=1_000_000,
            end_block=1_100_000,
        )

        assert config.netuid == 8
        assert config.start_block == 1_000_000
        assert config.end_block == 1_100_000
        assert config.initial_tao == Decimal("1000")
        assert config.initial_alpha == Decimal("0")
        assert config.trade_fee == Decimal("0.001")

    def test_custom_balances(self) -> None:
        """Test config with custom initial balances."""
        config = BacktestConfig(
            netuid=8,
            start_block=100,
            end_block=200,
            initial_tao=Decimal("500"),
            initial_alpha=Decimal("100"),
        )

        assert config.initial_tao == Decimal("500")
        assert config.initial_alpha == Decimal("100")

    def test_custom_data_dir(self) -> None:
        """Test config with custom data directory."""
        config = BacktestConfig(
            netuid=8,
            start_block=100,
            end_block=200,
            data_dir=Path("/custom/path"),
        )

        assert config.data_dir == Path("/custom/path")

    def test_invalid_block_range(self) -> None:
        """Test that invalid block range raises error."""
        with pytest.raises(ValueError, match=r"start_block.*must be < end_block"):
            BacktestConfig(
                netuid=8,
                start_block=200,
                end_block=100,
            )

    def test_equal_block_range(self) -> None:
        """Test that equal start/end blocks raises error."""
        with pytest.raises(ValueError, match=r"start_block.*must be < end_block"):
            BacktestConfig(
                netuid=8,
                start_block=100,
                end_block=100,
            )

    def test_negative_initial_tao(self) -> None:
        """Test that negative initial TAO raises error."""
        with pytest.raises(ValueError, match="initial_tao must be non-negative"):
            BacktestConfig(
                netuid=8,
                start_block=100,
                end_block=200,
                initial_tao=Decimal("-100"),
            )

    def test_negative_initial_alpha(self) -> None:
        """Test that negative initial Alpha raises error."""
        with pytest.raises(ValueError, match="initial_alpha must be non-negative"):
            BacktestConfig(
                netuid=8,
                start_block=100,
                end_block=200,
                initial_alpha=Decimal("-50"),
            )

    def test_invalid_trade_fee(self) -> None:
        """Test that invalid trade fee raises error."""
        with pytest.raises(ValueError, match="trade_fee must be between 0 and 1"):
            BacktestConfig(
                netuid=8,
                start_block=100,
                end_block=200,
                trade_fee=Decimal("1.5"),
            )

        with pytest.raises(ValueError, match="trade_fee must be between 0 and 1"):
            BacktestConfig(
                netuid=8,
                start_block=100,
                end_block=200,
                trade_fee=Decimal("-0.1"),
            )


class TestBacktestingConfig:
    """Tests for BacktestingConfig (combined config)."""

    def test_combined_config(self) -> None:
        """Test creating combined config."""
        backtest_config = BacktestConfig(
            netuid=8,
            start_block=100,
            end_block=200,
        )

        strategy_config: dict[str, Decimal | int | float | str] = {
            "fast_period": 10,
            "slow_period": 30,
            "threshold": Decimal("0.01"),
        }

        config = BacktestingConfig(
            backtest_config=backtest_config,
            strategy_config=strategy_config,
        )

        assert config.backtest_config.netuid == 8
        assert config.strategy_config["fast_period"] == 10
