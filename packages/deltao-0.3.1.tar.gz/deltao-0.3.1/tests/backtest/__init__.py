"""Tests for backtest module."""
