"""Tests for BacktestingEngine."""

import tempfile
from decimal import Decimal
from pathlib import Path

import pytest

# Skip all tests in this module if pandas/numpy not available
pytest.importorskip("pandas")
pytest.importorskip("numpy")

from deltao.backtest.config import BacktestConfig
from deltao.backtest.data import create_sample_data, save_block_data
from deltao.backtest.engine import BacktestingEngine
from deltao.core.state import EngineState
from deltao.core.types import OrderRequest, Side
from deltao.strategy.risk import NoOpRiskManager


class MockStrategy:
    """Simple mock strategy for testing."""

    def __init__(self, buy_every: int = 10, sell_every: int = 20) -> None:
        self.buy_every = buy_every
        self.sell_every = sell_every
        self._call_count = 0

    def generate_orders(
        self, state: EngineState
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Generate orders based on call count."""
        self._call_count += 1
        opens: list[OrderRequest] = []

        if self._call_count % self.buy_every == 0 and state.tao_balance > Decimal("10"):
            opens.append(
                OrderRequest(
                    side=Side.BUY,
                    amount=Decimal("10"),
                    slippage_tolerance=Decimal("0.02"),
                )
            )
        elif self._call_count % self.sell_every == 0 and state.alpha_balance > Decimal(
            "1"
        ):
            opens.append(
                OrderRequest(
                    side=Side.SELL,
                    amount=Decimal("1"),
                    slippage_tolerance=Decimal("0.02"),
                )
            )

        return ([], opens)


class NoTradeStrategy:
    """Strategy that never trades."""

    def generate_orders(
        self, _state: EngineState
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        return ([], [])


@pytest.fixture
def sample_data_dir():
    """Create temporary directory with sample data."""
    with tempfile.TemporaryDirectory() as tmpdir:
        data_dir = Path(tmpdir)
        data = create_sample_data(
            netuid=8,
            num_blocks=500,
            start_block=1_000_000,
            base_price=1.0,
        )
        save_block_data(data, netuid=8, output_dir=data_dir)
        yield data_dir


class TestBacktestingEngine:
    """Tests for BacktestingEngine."""

    @pytest.mark.asyncio
    async def test_run_basic_backtest(self, sample_data_dir: Path) -> None:
        """Test running a basic backtest."""
        config = BacktestConfig(
            netuid=8,
            start_block=1_000_000,
            end_block=1_000_100,
            initial_tao=Decimal("1000"),
            data_dir=sample_data_dir,
        )

        engine = BacktestingEngine(data_dir=sample_data_dir)
        strategy = NoTradeStrategy()
        risk = NoOpRiskManager()

        result = await engine.run(config, strategy, risk)

        # Should have processed 101 blocks
        assert len(result.portfolio_values) == 101
        assert result.total_trades == 0

    @pytest.mark.asyncio
    async def test_run_with_trades(self, sample_data_dir: Path) -> None:
        """Test backtest with actual trades."""
        config = BacktestConfig(
            netuid=8,
            start_block=1_000_000,
            end_block=1_000_100,
            initial_tao=Decimal("1000"),
            data_dir=sample_data_dir,
        )

        engine = BacktestingEngine(data_dir=sample_data_dir)
        strategy = MockStrategy(buy_every=10)  # Buy every 10 blocks
        risk = NoOpRiskManager()

        result = await engine.run(config, strategy, risk)

        # Should have ~10 trades (100 blocks / 10)
        assert result.total_trades >= 9
        assert all(t.side == Side.BUY for t in result.trades)

    @pytest.mark.asyncio
    async def test_initial_balance_preserved(self, sample_data_dir: Path) -> None:
        """Test that initial balance is correctly recorded."""
        config = BacktestConfig(
            netuid=8,
            start_block=1_000_000,
            end_block=1_000_050,
            initial_tao=Decimal("500"),
            initial_alpha=Decimal("100"),
            data_dir=sample_data_dir,
        )

        engine = BacktestingEngine(data_dir=sample_data_dir)
        strategy = NoTradeStrategy()
        risk = NoOpRiskManager()

        result = await engine.run(config, strategy, risk)

        # Initial value should be 500 TAO + 100 Alpha * price
        # Price starts at ~1.0, so initial should be ~600
        assert result.initial_value > Decimal("500")

    @pytest.mark.asyncio
    async def test_trade_fees_applied(self, sample_data_dir: Path) -> None:
        """Test that trade fees are correctly applied."""
        config = BacktestConfig(
            netuid=8,
            start_block=1_000_000,
            end_block=1_000_100,
            initial_tao=Decimal("1000"),
            trade_fee=Decimal("0.01"),  # 1% fee
            data_dir=sample_data_dir,
        )

        engine = BacktestingEngine(data_dir=sample_data_dir)
        strategy = MockStrategy(buy_every=10)
        risk = NoOpRiskManager()

        result = await engine.run(config, strategy, risk)

        # Check fees are non-zero and match expected rate
        if result.total_trades > 0:
            expected_fee_per_trade = Decimal("10") * Decimal("0.01")  # 10 TAO * 1%
            avg_fee = result.total_fees / result.total_trades
            assert abs(avg_fee - expected_fee_per_trade) < Decimal("0.01")

    @pytest.mark.asyncio
    async def test_progress_callback(self, sample_data_dir: Path) -> None:
        """Test progress callback is called."""
        config = BacktestConfig(
            netuid=8,
            start_block=1_000_000,
            end_block=1_000_050,
            data_dir=sample_data_dir,
        )

        progress_calls: list[tuple[int, int]] = []

        def progress_cb(current: int, total: int) -> None:
            progress_calls.append((current, total))

        engine = BacktestingEngine(data_dir=sample_data_dir)
        strategy = NoTradeStrategy()
        risk = NoOpRiskManager()

        await engine.run(config, strategy, risk, progress_callback=progress_cb)

        # Should have 51 progress calls (blocks 0-50)
        assert len(progress_calls) == 51
        assert progress_calls[0] == (1, 51)
        assert progress_calls[-1] == (51, 51)

    @pytest.mark.asyncio
    async def test_empty_block_range(self, sample_data_dir: Path) -> None:
        """Test error on empty block range."""
        config = BacktestConfig(
            netuid=8,
            start_block=9_999_999,  # Outside data range
            end_block=9_999_999 + 100,
            data_dir=sample_data_dir,
        )

        engine = BacktestingEngine(data_dir=sample_data_dir)
        strategy = NoTradeStrategy()
        risk = NoOpRiskManager()

        with pytest.raises(ValueError, match="No data found"):
            await engine.run(config, strategy, risk)

    @pytest.mark.asyncio
    async def test_missing_data_file(self) -> None:
        """Test error when data file doesn't exist."""
        with tempfile.TemporaryDirectory() as tmpdir:
            config = BacktestConfig(
                netuid=999,  # Non-existent netuid
                start_block=100,
                end_block=200,
                data_dir=Path(tmpdir),
            )

            engine = BacktestingEngine(data_dir=Path(tmpdir))
            strategy = NoTradeStrategy()
            risk = NoOpRiskManager()

            with pytest.raises(FileNotFoundError):
                await engine.run(config, strategy, risk)

    @pytest.mark.asyncio
    async def test_run_multiple_backtests(self, sample_data_dir: Path) -> None:
        """Test running multiple backtests."""
        configs: list[
            tuple[BacktestConfig, NoTradeStrategy | MockStrategy, NoOpRiskManager]
        ] = [
            (
                BacktestConfig(
                    netuid=8,
                    start_block=1_000_000,
                    end_block=1_000_050,
                    data_dir=sample_data_dir,
                ),
                NoTradeStrategy(),
                NoOpRiskManager(),
            ),
            (
                BacktestConfig(
                    netuid=8,
                    start_block=1_000_050,
                    end_block=1_000_100,
                    data_dir=sample_data_dir,
                ),
                MockStrategy(buy_every=5),
                NoOpRiskManager(),
            ),
        ]

        engine = BacktestingEngine(data_dir=sample_data_dir)
        results = await engine.run_multiple(configs)

        assert len(results) == 2
        assert results[0].total_trades == 0  # NoTradeStrategy
        assert results[1].total_trades > 0  # MockStrategy


class TestBacktestingEngineCache:
    """Tests for data caching."""

    def test_cache_loads_data(self, sample_data_dir: Path) -> None:
        """Test that cache loads available data."""
        engine = BacktestingEngine(data_dir=sample_data_dir)

        cached = engine.get_cached_data(8)
        assert cached is not None
        assert len(cached) > 0

    def test_cache_returns_none_for_missing(self, sample_data_dir: Path) -> None:
        """Test cache returns None for missing netuid."""
        engine = BacktestingEngine(data_dir=sample_data_dir)

        cached = engine.get_cached_data(999)
        assert cached is None
