"""Tests for backtest data utilities."""

import tempfile
from pathlib import Path

import pytest

# Skip all tests in this module if pandas/numpy not available
pytest.importorskip("pandas")
pytest.importorskip("numpy")

from deltao.backtest.data import (
    create_sample_data,
    get_data_filename,
    load_block_data,
    save_block_data,
)


class TestGetDataFilename:
    """Tests for filename generation."""

    def test_filename_format(self) -> None:
        """Test filename follows convention."""
        filename = get_data_filename(8)
        assert filename == "dtao|subnet8|1block.parquet"

    def test_different_netuids(self) -> None:
        """Test filename with different netuids."""
        assert get_data_filename(1) == "dtao|subnet1|1block.parquet"
        assert get_data_filename(42) == "dtao|subnet42|1block.parquet"


class TestCreateSampleData:
    """Tests for sample data generation."""

    def test_sample_data_columns(self) -> None:
        """Test sample data has correct columns."""
        data = create_sample_data(num_blocks=100)

        assert "timestamp" in data.columns
        assert "block_number" in data.columns
        assert "price" in data.columns
        assert "tao_in" in data.columns
        assert "alpha_in" in data.columns
        assert "k" in data.columns

    def test_sample_data_length(self) -> None:
        """Test sample data has correct length."""
        data = create_sample_data(num_blocks=500)
        assert len(data) == 500

    def test_sample_data_block_numbers(self) -> None:
        """Test block numbers are sequential."""
        data = create_sample_data(num_blocks=100, start_block=1_000_000)

        assert data["block_number"].iloc[0] == 1_000_000
        assert data["block_number"].iloc[-1] == 1_000_099
        assert data["block_number"].is_monotonic_increasing

    def test_sample_data_prices_positive(self) -> None:
        """Test all prices are positive."""
        data = create_sample_data(num_blocks=1000)
        assert (data["price"] > 0).all()

    def test_sample_data_k_calculation(self) -> None:
        """Test k is product of tao_in and alpha_in."""
        data = create_sample_data(num_blocks=100)
        calculated_k = data["tao_in"] * data["alpha_in"]
        assert (data["k"] == calculated_k).all()


class TestSaveAndLoadBlockData:
    """Tests for saving and loading block data."""

    def test_round_trip(self) -> None:
        """Test save then load returns same data."""
        data = create_sample_data(num_blocks=100, netuid=8)

        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)

            # Save
            save_block_data(data, netuid=8, output_dir=output_dir)

            # Load
            loaded = load_block_data(netuid=8, data_dir=output_dir)

            # Check columns match
            for col in [
                "timestamp",
                "block_number",
                "price",
                "tao_in",
                "alpha_in",
                "k",
            ]:
                assert col in loaded.columns

            # Check length matches
            assert len(loaded) == len(data)

    def test_load_with_block_filter(self) -> None:
        """Test loading with block range filter."""
        data = create_sample_data(num_blocks=1000, start_block=1_000_000)

        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir)
            save_block_data(data, netuid=8, output_dir=output_dir)

            # Load subset
            loaded = load_block_data(
                netuid=8,
                data_dir=output_dir,
                start_block=1_000_100,
                end_block=1_000_200,
            )

            assert loaded["block_number"].min() >= 1_000_100
            assert loaded["block_number"].max() <= 1_000_200

    def test_load_nonexistent_file(self) -> None:
        """Test loading nonexistent file raises error."""
        with (
            tempfile.TemporaryDirectory() as tmpdir,
            pytest.raises(FileNotFoundError, match="Data file not found"),
        ):
            load_block_data(netuid=999, data_dir=Path(tmpdir))

    def test_save_creates_directory(self) -> None:
        """Test save creates output directory if needed."""
        data = create_sample_data(num_blocks=10)

        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "nested" / "dir"

            # Directory doesn't exist
            assert not output_dir.exists()

            # Save should create it
            save_block_data(data, netuid=8, output_dir=output_dir)

            assert output_dir.exists()
            assert (output_dir / "dtao|subnet8|1block.parquet").exists()
