"""Tests for backtest recorder."""

from datetime import datetime
from decimal import Decimal

from deltao.backtest.recorder import BacktestResult, Recorder, Trade
from deltao.core.engine import Audit
from deltao.core.event import MarketEvent
from deltao.core.state import EngineState
from deltao.core.types import OrderRequest, Side


def create_audit(
    orders_approved: list[OrderRequest] | None = None,
    timestamp: datetime | None = None,
) -> Audit:
    """Create test audit."""
    event = MarketEvent(
        netuid=8,
        price=Decimal("10"),
        tao_in=Decimal("1000"),
        alpha_in=Decimal("100"),
        k=Decimal("100000"),
        block_number=100,
        timestamp=timestamp or datetime(2024, 1, 1, 12, 0, 0),
    )

    return Audit(
        event=event,
        orders_generated=orders_approved or [],
        orders_approved=orders_approved or [],
        orders_denied=[],
        order_results=[],
        state_changes={},
        timestamp=timestamp or datetime(2024, 1, 1, 12, 0, 0),
        state_before={},
        state_after={},
        errors=[],
        duration_ms=0.0,
    )


def create_state(
    tao: Decimal = Decimal("1000"),
    alpha: Decimal = Decimal("100"),
    price: Decimal = Decimal("10"),
    block: int = 100,
) -> EngineState:
    """Create test state."""
    state = EngineState(
        tao_balance=tao,
        alpha_balance=alpha,
        current_price=price,
        current_block=block,
    )
    return state


class TestTrade:
    """Tests for Trade dataclass."""

    def test_trade_creation(self) -> None:
        """Test creating a trade."""
        trade = Trade(
            timestamp=datetime(2024, 1, 1),
            block_number=100,
            side=Side.BUY,
            amount=Decimal("10"),
            price=Decimal("5"),
            fee=Decimal("0.01"),
        )

        assert trade.side == Side.BUY
        assert trade.amount == Decimal("10")

    def test_trade_value(self) -> None:
        """Test trade value calculation."""
        trade = Trade(
            timestamp=datetime(2024, 1, 1),
            block_number=100,
            side=Side.BUY,
            amount=Decimal("10"),
            price=Decimal("5"),
            fee=Decimal("0.5"),
        )

        assert trade.value == Decimal("50")  # 10 * 5
        assert trade.net_value == Decimal("49.5")  # 50 - 0.5


class TestRecorder:
    """Tests for Recorder."""

    def test_empty_recorder(self) -> None:
        """Test recorder with no data."""
        recorder = Recorder()
        result = recorder.generate_result()

        assert result.total_trades == 0
        assert result.total_pnl == Decimal(0)
        assert result.sharpe_ratio == 0.0

    def test_record_single_event(self) -> None:
        """Test recording a single event."""
        recorder = Recorder()

        state = create_state(
            tao=Decimal("1000"), alpha=Decimal("100"), price=Decimal("10")
        )
        audit = create_audit()

        recorder.record(audit, state)
        result = recorder.generate_result()

        assert len(result.portfolio_values) == 1
        # Portfolio = 1000 TAO + 100 Alpha * 10 price = 2000
        assert result.portfolio_values[0] == Decimal("2000")

    def test_record_with_trade(self) -> None:
        """Test recording event with approved order."""
        recorder = Recorder(trade_fee=Decimal("0.001"))

        state = create_state(
            tao=Decimal("1000"), alpha=Decimal("100"), price=Decimal("10")
        )
        order = OrderRequest(side=Side.BUY, amount=Decimal("50"))
        audit = create_audit(orders_approved=[order])

        recorder.record(audit, state)
        result = recorder.generate_result()

        assert result.total_trades == 1
        assert result.trades[0].side == Side.BUY
        assert result.trades[0].amount == Decimal("50")
        assert result.trades[0].fee == Decimal("0.05")  # 50 * 0.001

    def test_multiple_records_returns(self) -> None:
        """Test returns calculation with multiple records."""
        recorder = Recorder()

        # First state: portfolio = 1000
        state1 = create_state(
            tao=Decimal("1000"), alpha=Decimal("0"), price=Decimal("10")
        )
        audit1 = create_audit(timestamp=datetime(2024, 1, 1, 12, 0, 0))
        recorder.record(audit1, state1)

        # Second state: portfolio = 1100 (10% gain)
        state2 = create_state(
            tao=Decimal("1100"), alpha=Decimal("0"), price=Decimal("10")
        )
        audit2 = create_audit(timestamp=datetime(2024, 1, 1, 12, 0, 12))
        recorder.record(audit2, state2)

        result = recorder.generate_result()

        assert len(result.returns) == 1
        assert result.returns[0] == Decimal("0.1")  # 10% return

    def test_pnl_calculation(self) -> None:
        """Test P&L calculation."""
        recorder = Recorder(trade_fee=Decimal("0.01"))

        # Initial portfolio = 1000
        state1 = create_state(tao=Decimal("1000"), alpha=Decimal("0"))
        audit1 = create_audit()
        recorder.record(audit1, state1)

        # Final portfolio = 1200
        state2 = create_state(tao=Decimal("1200"), alpha=Decimal("0"))
        # Record a trade for fees
        order = OrderRequest(side=Side.BUY, amount=Decimal("100"))
        audit2 = create_audit(orders_approved=[order])
        recorder.record(audit2, state2)

        result = recorder.generate_result()

        assert result.initial_value == Decimal("1000")
        assert result.final_value == Decimal("1200")
        assert result.total_pnl == Decimal("200")
        assert result.total_fees == Decimal("1")  # 100 * 0.01
        assert result.net_pnl == Decimal("199")  # 200 - 1

    def test_reset(self) -> None:
        """Test recorder reset."""
        recorder = Recorder()

        state = create_state()
        audit = create_audit()
        recorder.record(audit, state)

        recorder.reset()
        result = recorder.generate_result()

        assert result.total_trades == 0
        assert len(result.portfolio_values) == 0


class TestBacktestResult:
    """Tests for BacktestResult."""

    def test_summary_format(self) -> None:
        """Test summary string format."""
        result = BacktestResult(
            trades=[],
            total_trades=10,
            initial_value=Decimal("1000"),
            final_value=Decimal("1200"),
            total_pnl=Decimal("200"),
            total_fees=Decimal("10"),
            net_pnl=Decimal("190"),
            returns=[],
            cumulative_returns=[],
            portfolio_values=[],
            timestamps=[],
            sharpe_ratio=1.5,
            sortino_ratio=2.0,
            max_drawdown=-0.1,
            max_drawdown_duration=50,
            win_rate=0.6,
            profit_factor=1.8,
            avg_trade_pnl=Decimal("19"),
            avg_win=Decimal("50"),
            avg_loss=Decimal("30"),
            total_volume=Decimal("5000"),
            avg_trade_size=Decimal("500"),
        )

        summary = result.summary()

        assert "Total Trades: 10" in summary
        assert "Initial Value: 1000" in summary
        assert "Net P&L:" in summary
        assert "Sharpe Ratio:  1.500" in summary
        assert "Max Drawdown:  -10.00%" in summary
        assert "Win Rate:      60.00%" in summary
