"""Tests for deltao."""
