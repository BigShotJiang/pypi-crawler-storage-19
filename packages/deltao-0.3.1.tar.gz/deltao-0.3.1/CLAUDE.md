# Project Rules

- Do not add Co-Authored-By lines to commits
- Update CHANGELOG.md when creating releases (follow Keep a Changelog format)