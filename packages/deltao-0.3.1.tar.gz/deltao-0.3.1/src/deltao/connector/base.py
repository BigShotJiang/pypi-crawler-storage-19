"""Base connector interface.

Based on IMPLEMENTATION_CORE.md lines 496-529.
"""

from abc import ABC, abstractmethod

from deltao.core.event import AccountEvent, MarketEvent
from deltao.core.types import OrderRequest, OrderResult


class Connector(ABC):
    """Base connector interface.

    Implementations:
    - DTaoConnector: Real chain (to be added later with bittensor SDK)
    - MockConnector: Backtesting
    """

    @abstractmethod
    async def place_order(self, order: OrderRequest) -> OrderResult:
        """Place order on chain/exchange.

        Args:
            order: Order request to execute

        Returns:
            OrderResult: Result of order execution
        """
        pass

    @abstractmethod
    async def get_market_state(self) -> MarketEvent:
        """Get current market state.

        Returns:
            MarketEvent: Current market data
        """
        pass

    @abstractmethod
    async def get_account_state(self) -> AccountEvent:
        """Get current account state.

        Returns:
            AccountEvent: Current account balances and positions
        """
        pass

    @abstractmethod
    async def start(self) -> None:
        """Start connector (connect websockets, etc.)."""
        pass

    @abstractmethod
    async def stop(self) -> None:
        """Stop connector gracefully."""
        pass
