"""Generic safety utilities: retry logic with exponential backoff."""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

logger = logging.getLogger(__name__)

T = TypeVar("T")


async def execute_with_retry(
    func: Callable[[], Awaitable[T]],
    max_retries: int = 3,
    base_delay: float = 12.0,
    on_retry: Callable[[int, Exception], None] | None = None,
) -> T:
    """Execute async function with exponential backoff retry.

    Args:
        func: Async function to execute
        max_retries: Maximum number of attempts
        base_delay: Base delay in seconds (doubles each retry)
        on_retry: Optional callback on retry (attempt, exception)

    Returns:
        Result of successful function call

    Raises:
        Exception: Last exception if all retries exhausted
    """
    last_exception: Exception | None = None

    for attempt in range(max_retries):
        try:
            return await func()
        except Exception as e:
            last_exception = e
            logger.warning(f"Attempt {attempt + 1}/{max_retries} failed: {e}")

            if on_retry:
                on_retry(attempt, e)

            if attempt < max_retries - 1:
                delay = base_delay * (2**attempt)
                logger.info(f"Retrying in {delay:.1f}s...")
                await asyncio.sleep(delay)

    assert last_exception is not None
    raise last_exception
