"""Mock connector for backtesting.

Based on IMPLEMENTATION_CORE.md lines 696-758.
"""

from datetime import datetime
from decimal import Decimal

from deltao.connector.base import Connector
from deltao.core.event import AccountEvent, MarketEvent
from deltao.core.types import OrderRequest, OrderResult


class MockConnector(Connector):
    """Mock connector for backtesting.

    Simulates order execution without touching the chain.
    """

    def __init__(self) -> None:
        """Initialize mock connector."""
        self.orders: list[OrderRequest] = []
        self.market_state: MarketEvent | None = None
        self.account_state: AccountEvent | None = None

    async def place_order(self, order: OrderRequest) -> OrderResult:
        """Simulate order execution.

        Args:
            order: Order request to execute

        Returns:
            OrderResult: Simulated success result
        """
        self.orders.append(order)

        # Simulate success
        return OrderResult(
            success=True,
            message="Mock order executed",
            tx_hash="0xmock",
            block_number=999,
        )

    async def get_market_state(self) -> MarketEvent:
        """Return mock market state.

        Returns:
            MarketEvent: Mock or configured market state
        """
        if self.market_state is None:
            # Return default
            return MarketEvent(
                netuid=8,
                price=Decimal("1.0"),
                tao_in=Decimal("1000"),
                alpha_in=Decimal("1000"),
                k=Decimal("1000000"),
                block_number=0,
                timestamp=datetime.now(),
            )
        return self.market_state

    async def get_account_state(self) -> AccountEvent:
        """Return mock account state.

        Returns:
            AccountEvent: Mock or configured account state
        """
        if self.account_state is None:
            return AccountEvent(
                tao_balance=Decimal("100"),
                alpha_balance=Decimal("0"),
                positions=[],
                timestamp=datetime.now(),
            )
        return self.account_state

    async def start(self) -> None:
        """Start connector (no-op for mock)."""
        pass

    async def stop(self) -> None:
        """Stop connector (no-op for mock)."""
        pass

    # Helpers for testing
    def set_market_state(self, state: MarketEvent) -> None:
        """Set market state for testing.

        Args:
            state: Market state to use
        """
        self.market_state = state

    def set_account_state(self, state: AccountEvent) -> None:
        """Set account state for testing.

        Args:
            state: Account state to use
        """
        self.account_state = state
