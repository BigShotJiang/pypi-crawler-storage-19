"""DTaoConnector - thin wrapper around Bittensor SDK.

Uses SDK's native methods directly without unnecessary abstraction.
Includes connection management, error handling, and health monitoring.
"""

from __future__ import annotations

import asyncio
import contextlib
import inspect
import logging
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import TYPE_CHECKING, Any

from deltao.connector.base import Connector
from deltao.connector.safety import execute_with_retry
from deltao.core.detector import EventDetector
from deltao.core.event import AccountEvent, MarketEvent
from deltao.core.types import OrderRequest, OrderResult, Side

if TYPE_CHECKING:
    from collections.abc import Callable

    import bittensor as bt

logger = logging.getLogger(__name__)


class ConnectionState(Enum):
    """Connection state for DTaoConnector."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    RECONNECTING = "reconnecting"
    ERROR = "error"


class DTaoConnectorError(Exception):
    """Base exception for DTaoConnector errors."""

    pass


class ConnectionError(DTaoConnectorError):
    """Connection-related errors."""

    pass


class TransactionError(DTaoConnectorError):
    """Transaction execution errors."""

    pass


async def _maybe_await(value: Any) -> Any:
    """Await value if coroutine/awaitable, otherwise return directly."""
    if inspect.isawaitable(value):
        return await value
    return value


class DTaoConnector(Connector):
    """Bittensor dTao chain connector.

    Thin wrapper around bittensor SDK that adapts to our Connector interface.
    Uses SDK's native methods for all chain operations.

    Features:
    - Automatic reconnection on connection loss
    - Health monitoring with configurable intervals
    - Rate limiting for API calls
    - Comprehensive error handling

    Args:
        wallet: Bittensor wallet with coldkey/hotkey
        netuid: Subnet ID to operate on
        network: Network name ("finney", "test", "local") or endpoint URL
        max_retries: Max retry attempts for chain operations
        reconnect_delay: Delay between reconnection attempts (seconds)
        health_check_interval: Interval for health checks (seconds, 0 to disable)
    """

    def __init__(
        self,
        wallet: bt.Wallet,
        netuid: int,
        network: str = "finney",
        max_retries: int = 3,
        reconnect_delay: float = 5.0,
        health_check_interval: float = 30.0,
        price_change_threshold: Decimal = Decimal("0.02"),
        liquidity_change_threshold: Decimal = Decimal("0.1"),
    ):
        self.wallet = wallet
        self.netuid = netuid
        self.network = network
        self.max_retries = max_retries
        self.reconnect_delay = reconnect_delay
        self.health_check_interval = health_check_interval

        self._subtensor: bt.Subtensor | None = None
        self._state = ConnectionState.DISCONNECTED
        self._health_task: asyncio.Task[None] | None = None
        self._last_successful_call: datetime | None = None
        self._consecutive_failures = 0
        self._on_state_change: Callable[[ConnectionState], None] | None = None

        # Event detection
        self._detector = EventDetector(
            price_change_threshold=price_change_threshold,
            liquidity_change_threshold=liquidity_change_threshold,
        )

    @property
    def state(self) -> ConnectionState:
        """Current connection state."""
        return self._state

    @property
    def is_connected(self) -> bool:
        """Check if connector is connected and healthy."""
        return self._state == ConnectionState.CONNECTED

    def on_state_change(self, callback: Callable[[ConnectionState], None]) -> None:
        """Register callback for connection state changes."""
        self._on_state_change = callback

    def _set_state(self, new_state: ConnectionState) -> None:
        """Update connection state and notify listeners."""
        if self._state != new_state:
            old_state = self._state
            self._state = new_state
            logger.info(f"Connection state: {old_state.value} -> {new_state.value}")
            if self._on_state_change:
                self._on_state_change(new_state)

    async def start(self) -> None:
        """Connect to Bittensor network with automatic retry."""
        if self._state in (ConnectionState.CONNECTED, ConnectionState.CONNECTING):
            logger.warning("Already connected or connecting")
            return

        self._set_state(ConnectionState.CONNECTING)

        try:
            await self._connect()
            self._set_state(ConnectionState.CONNECTED)
            self._consecutive_failures = 0

            # Start health check task
            if self.health_check_interval > 0:
                self._health_task = asyncio.create_task(self._health_check_loop())

        except Exception as e:
            self._set_state(ConnectionState.ERROR)
            logger.exception(f"Failed to connect: {e}")
            raise ConnectionError(f"Failed to connect to {self.network}: {e}") from e

    async def _connect(self) -> None:
        """Internal connection logic."""
        import bittensor as bt

        logger.info(f"Connecting to {self.network}...")
        self._subtensor = await _maybe_await(bt.Subtensor(network=self.network))
        logger.info(f"Connected to {self.network}")

    async def stop(self) -> None:
        """Disconnect from Bittensor network."""
        # Cancel health check task
        if self._health_task:
            self._health_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._health_task
            self._health_task = None

        # Close connection
        if self._subtensor:
            try:
                await _maybe_await(self._subtensor.close())
            except Exception as e:
                logger.warning(f"Error closing connection: {e}")
            self._subtensor = None

        self._set_state(ConnectionState.DISCONNECTED)
        logger.info("Disconnected from network")

    async def reconnect(self) -> None:
        """Attempt to reconnect to the network."""
        if self._state == ConnectionState.RECONNECTING:
            logger.warning("Already reconnecting")
            return

        self._set_state(ConnectionState.RECONNECTING)

        # Close existing connection
        if self._subtensor:
            with contextlib.suppress(Exception):
                await _maybe_await(self._subtensor.close())
            self._subtensor = None

        # Attempt reconnection with exponential backoff
        for attempt in range(self.max_retries):
            try:
                delay = self.reconnect_delay * (2**attempt)
                logger.info(f"Reconnection attempt {attempt + 1}/{self.max_retries}")

                await self._connect()
                self._set_state(ConnectionState.CONNECTED)
                self._consecutive_failures = 0
                logger.info("Reconnected successfully")
                return

            except Exception as e:
                logger.warning(f"Reconnection attempt {attempt + 1} failed: {e}")
                if attempt < self.max_retries - 1:
                    logger.info(f"Waiting {delay:.1f}s before next attempt...")
                    await asyncio.sleep(delay)

        self._set_state(ConnectionState.ERROR)
        raise ConnectionError(f"Failed to reconnect after {self.max_retries} attempts")

    async def _health_check_loop(self) -> None:
        """Background task for health monitoring."""
        while True:
            try:
                await asyncio.sleep(self.health_check_interval)
                await self.health_check()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Health check failed: {e}")
                self._consecutive_failures += 1

                if self._consecutive_failures >= 3:
                    logger.error("Multiple health check failures, attempting reconnect")
                    try:
                        await self.reconnect()
                    except ConnectionError:
                        logger.error("Reconnection failed")

    async def health_check(self) -> bool:
        """Check connection health by querying current block."""
        if self._subtensor is None:
            return False

        try:
            block = await _maybe_await(self.subtensor.substrate.get_block_number())
            self._last_successful_call = datetime.now(timezone.utc)
            self._consecutive_failures = 0
            logger.debug(f"Health check passed, block: {block}")
            return True
        except Exception as e:
            self._consecutive_failures += 1
            logger.warning(f"Health check failed: {e}")
            return False

    @property
    def subtensor(self) -> bt.Subtensor:
        """Get subtensor instance."""
        if self._subtensor is None:
            raise RuntimeError("Connector not started. Call start() first.")
        return self._subtensor

    async def place_order(self, order: OrderRequest) -> OrderResult:
        """Execute stake/unstake order using SDK.

        BUY = stake TAO -> get Alpha
        SELL = unstake Alpha -> get TAO
        """
        if not self.is_connected:
            return OrderResult(
                success=False,
                message="Connector not connected",
            )

        hotkey = order.hotkey or self.wallet.hotkey.ss58_address

        async def execute() -> OrderResult:
            if order.side == Side.BUY:
                return await self._stake(hotkey, order.amount, order.slippage_tolerance)
            else:
                return await self._unstake(
                    hotkey, order.amount, order.slippage_tolerance
                )

        try:
            result = await execute_with_retry(execute, max_retries=self.max_retries)
            if result.success:
                self._last_successful_call = datetime.now(timezone.utc)
                self._consecutive_failures = 0
            return result
        except Exception as e:
            self._consecutive_failures += 1
            return OrderResult(
                success=False,
                message=f"Order failed after {self.max_retries} retries: {e}",
            )

    async def _stake(
        self, hotkey: str, amount: Decimal, _slippage: Decimal
    ) -> OrderResult:
        """Stake TAO to get Alpha using SDK's add_stake."""
        try:
            result = await _maybe_await(
                self.subtensor.add_stake(
                    wallet=self.wallet,
                    hotkey_ss58=hotkey,
                    netuid=self.netuid,
                    amount=float(amount),
                    wait_for_inclusion=True,
                    wait_for_finalization=False,
                )
            )

            if result:
                return OrderResult(
                    success=True,
                    message=f"Staked {amount} TAO to {hotkey}",
                )
            else:
                return OrderResult(
                    success=False,
                    message="Stake transaction failed",
                )
        except Exception as e:
            raise TransactionError(f"Stake failed: {e}") from e

    async def _unstake(
        self, hotkey: str, amount: Decimal, _slippage: Decimal
    ) -> OrderResult:
        """Unstake Alpha to get TAO using SDK's unstake."""
        try:
            result = await _maybe_await(
                self.subtensor.unstake(
                    wallet=self.wallet,
                    hotkey_ss58=hotkey,
                    netuid=self.netuid,
                    amount=float(amount),
                    wait_for_inclusion=True,
                    wait_for_finalization=False,
                )
            )

            if result:
                return OrderResult(
                    success=True,
                    message=f"Unstaked {amount} Alpha from {hotkey}",
                )
            else:
                return OrderResult(
                    success=False,
                    message="Unstake transaction failed",
                )
        except Exception as e:
            raise TransactionError(f"Unstake failed: {e}") from e

    async def get_market_state(self, detect_events: bool = True) -> MarketEvent:
        """Get current market state from chain.

        Args:
            detect_events: Whether to run event detection (default True)

        Returns:
            MarketEvent with optional detected_events populated
        """
        if not self.is_connected:
            raise ConnectionError("Connector not connected")

        try:
            info: Any = await _maybe_await(self.subtensor.subnet(self.netuid))
            block = await _maybe_await(self.subtensor.substrate.get_block_number())

            self._last_successful_call = datetime.now(timezone.utc)
            self._consecutive_failures = 0

            market = MarketEvent(
                netuid=self.netuid,
                price=Decimal(str(info.price)),
                tao_in=Decimal(str(info.tao_in)),
                alpha_in=Decimal(str(info.alpha_in)),
                k=Decimal(str(info.tao_in)) * Decimal(str(info.alpha_in)),
                block_number=block,
                timestamp=datetime.now(timezone.utc),
            )

            # Run event detection if enabled
            if detect_events:
                detected = self._detector.detect(market)
                market.detected_events = detected
                market.is_significant = len(detected) > 0

            return market
        except Exception as e:
            self._consecutive_failures += 1
            raise ConnectionError(f"Failed to get market state: {e}") from e

    @property
    def detector(self) -> EventDetector:
        """Get the event detector instance."""
        return self._detector

    async def get_account_state(self) -> AccountEvent:
        """Get current account balances."""
        if not self.is_connected:
            raise ConnectionError("Connector not connected")

        try:
            coldkey = self.wallet.coldkey.ss58_address
            hotkey = self.wallet.hotkey.ss58_address

            tao_balance = await _maybe_await(self.subtensor.get_balance(coldkey))
            alpha_stake = await _maybe_await(
                self.subtensor.get_stake(
                    hotkey_ss58=hotkey,
                    coldkey_ss58=coldkey,
                    netuid=self.netuid,
                )
            )

            self._last_successful_call = datetime.now(timezone.utc)
            self._consecutive_failures = 0

            return AccountEvent(
                tao_balance=Decimal(str(tao_balance.tao)),
                alpha_balance=Decimal(str(alpha_stake)),
                positions=[],
                timestamp=datetime.now(timezone.utc),
            )
        except Exception as e:
            self._consecutive_failures += 1
            raise ConnectionError(f"Failed to get account state: {e}") from e

    def get_stats(self) -> dict[str, Any]:
        """Get connector statistics for monitoring."""
        return {
            "state": self._state.value,
            "network": self.network,
            "netuid": self.netuid,
            "consecutive_failures": self._consecutive_failures,
            "last_successful_call": (
                self._last_successful_call.isoformat()
                if self._last_successful_call
                else None
            ),
        }
