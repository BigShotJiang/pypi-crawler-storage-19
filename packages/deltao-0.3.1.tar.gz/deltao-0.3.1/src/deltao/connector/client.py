"""Subtensor client wrapper with async context manager.

Provides convenient async context manager for bittensor SDK.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import bittensor as bt


class SubtensorClient:
    """Async context manager wrapper for bt.Subtensor.

    Usage:
        async with SubtensorClient(network="finney") as client:
            info = client.subtensor.subnet(netuid)
    """

    def __init__(self, network: str = "finney"):
        """Initialize client.

        Args:
            network: Bittensor network ("finney", "test", "local", or endpoint URL)
        """
        self.network = network
        self._subtensor: bt.Subtensor | None = None

    async def __aenter__(self) -> SubtensorClient:
        """Async context manager entry."""
        import bittensor as bt

        self._subtensor = await bt.Subtensor(network=self.network)
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Async context manager exit."""
        if self._subtensor:
            await self._subtensor.close()
            self._subtensor = None

    @property
    def subtensor(self) -> bt.Subtensor:
        """Get subtensor instance.

        Raises:
            RuntimeError: If not initialized (use async context manager)
        """
        if self._subtensor is None:
            raise RuntimeError(
                "Subtensor not initialized. Use async context manager: "
                "async with SubtensorClient() as client: ..."
            )
        return self._subtensor
