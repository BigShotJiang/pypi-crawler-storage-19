"""Momentum trading strategy.

Buys when price shows upward momentum (fast MA > slow MA).
Sells when momentum reverses.

Uses dual moving average crossover as primary signal.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING

from deltao.core.types import OrderRequest, Side
from deltao.strategy.base import BaseStrategy

if TYPE_CHECKING:
    from deltao.core.state import EngineState


@dataclass
class MomentumStrategy(BaseStrategy):
    """Momentum strategy using moving average crossover.

    Signal logic:
    - BUY when fast_ma > slow_ma (bullish crossover)
    - SELL when fast_ma < slow_ma (bearish crossover)

    Position sizing based on momentum strength.
    """

    # MA periods
    fast_period: int = 10
    slow_period: int = 30

    # Position sizing
    base_order_size: Decimal = Decimal("1.0")  # Base order in TAO
    momentum_multiplier: Decimal = Decimal("0.5")  # Scale with momentum strength

    # Thresholds
    min_momentum_pct: Decimal = Decimal("0.01")  # 1% min difference to trade

    def __post_init__(self) -> None:
        """Initialize strategy."""
        self.name = "MomentumStrategy"
        self.min_order_size = Decimal("0.01")
        self.max_order_size = Decimal("100")

    def generate_orders(
        self, state: EngineState
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Generate orders based on momentum signals.

        Args:
            state: Current engine state

        Returns:
            tuple: (orders_to_cancel, orders_to_open)
        """
        cancels: list[OrderRequest] = []
        opens: list[OrderRequest] = []

        # Check for sufficient data
        min_data = self.slow_period + 5
        if not self.has_sufficient_data(state, min_data):
            return (cancels, opens)

        # Calculate moving averages
        fast_ma = self.get_sma(state, self.fast_period)
        slow_ma = self.get_sma(state, self.slow_period)

        if fast_ma is None or slow_ma is None:
            return (cancels, opens)

        # Calculate momentum as percentage difference
        momentum_pct = (fast_ma - slow_ma) / slow_ma

        # Check minimum threshold
        if abs(momentum_pct) < self.min_momentum_pct:
            return (cancels, opens)

        # Generate signal
        if momentum_pct > 0 and state.tao_balance > self.min_order_size:
            # Bullish - BUY
            size = self._calculate_position_size(momentum_pct, state)
            if size >= self.min_order_size:
                opens.append(
                    OrderRequest(
                        side=Side.BUY,
                        amount=size,
                        slippage_tolerance=Decimal("0.02"),
                    )
                )

        elif momentum_pct < 0 and state.alpha_balance > 0:
            # Bearish - SELL
            size = self._calculate_sell_size(abs(momentum_pct), state)
            if size >= self.min_order_size:
                opens.append(
                    OrderRequest(
                        side=Side.SELL,
                        amount=size,
                        slippage_tolerance=Decimal("0.02"),
                    )
                )

        return (cancels, opens)

    def _calculate_position_size(
        self, momentum_pct: Decimal, state: EngineState
    ) -> Decimal:
        """Calculate buy position size based on momentum strength.

        Scales base order by momentum strength.
        """
        # Scale by momentum (capped at 3x)
        scale = min(Decimal(3), 1 + abs(momentum_pct) * self.momentum_multiplier * 10)
        size = self.base_order_size * scale

        # Cap at available balance
        size = min(size, state.tao_balance * Decimal("0.5"))

        return self.clamp_order_size(size)

    def _calculate_sell_size(
        self, momentum_pct: Decimal, state: EngineState
    ) -> Decimal:
        """Calculate sell position size.

        Sells proportional to momentum strength and alpha holdings.
        """
        # Sell percentage of alpha holdings based on momentum
        sell_pct = min(Decimal("0.5"), abs(momentum_pct) * 5)
        size = state.alpha_balance * sell_pct

        return self.clamp_order_size(size)
