"""Mean reversion trading strategy.

Buys when price is significantly below its mean.
Sells when price is significantly above its mean.

Uses RSI and deviation from SMA as signals.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING

from deltao.core.types import OrderRequest, Side
from deltao.strategy.base import BaseStrategy

if TYPE_CHECKING:
    from deltao.core.state import EngineState


@dataclass
class MeanReversionStrategy(BaseStrategy):
    """Mean reversion strategy using RSI and price deviation.

    Signal logic:
    - BUY when RSI < oversold_threshold AND price < SMA * (1 - deviation)
    - SELL when RSI > overbought_threshold AND price > SMA * (1 + deviation)

    Assumes price will revert to mean over time.
    """

    # RSI thresholds
    rsi_period: int = 14
    oversold_threshold: Decimal = Decimal("30")
    overbought_threshold: Decimal = Decimal("70")

    # Price deviation from SMA
    sma_period: int = 20
    min_deviation: Decimal = Decimal("0.02")  # 2% minimum deviation

    # Position sizing
    base_order_size: Decimal = Decimal("1.0")
    deviation_multiplier: Decimal = Decimal("2.0")  # Scale with deviation

    def __post_init__(self) -> None:
        """Initialize strategy."""
        self.name = "MeanReversionStrategy"
        self.min_order_size = Decimal("0.01")
        self.max_order_size = Decimal("100")

    def generate_orders(
        self, state: EngineState
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Generate orders based on mean reversion signals.

        Args:
            state: Current engine state

        Returns:
            tuple: (orders_to_cancel, orders_to_open)
        """
        cancels: list[OrderRequest] = []
        opens: list[OrderRequest] = []

        # Check for sufficient data
        min_data = max(self.rsi_period + 1, self.sma_period) + 5
        if not self.has_sufficient_data(state, min_data):
            return (cancels, opens)

        # Calculate indicators
        rsi = self.get_rsi(state, self.rsi_period)
        sma = self.get_sma(state, self.sma_period)

        if rsi is None or sma is None or sma == 0:
            return (cancels, opens)

        # Calculate price deviation from SMA
        current_price = state.current_price
        deviation = (current_price - sma) / sma

        # Check for oversold (buy signal)
        if (
            rsi < self.oversold_threshold
            and deviation < -self.min_deviation
            and state.tao_balance > self.min_order_size
        ):
            size = self._calculate_buy_size(abs(deviation), rsi, state)
            if size >= self.min_order_size:
                opens.append(
                    OrderRequest(
                        side=Side.BUY,
                        amount=size,
                        slippage_tolerance=Decimal("0.02"),
                    )
                )

        # Check for overbought (sell signal)
        elif (
            rsi > self.overbought_threshold
            and deviation > self.min_deviation
            and state.alpha_balance > 0
        ):
            size = self._calculate_sell_size(deviation, rsi, state)
            if size >= self.min_order_size:
                opens.append(
                    OrderRequest(
                        side=Side.SELL,
                        amount=size,
                        slippage_tolerance=Decimal("0.02"),
                    )
                )

        return (cancels, opens)

    def _calculate_buy_size(
        self, deviation: Decimal, rsi: Decimal, state: EngineState
    ) -> Decimal:
        """Calculate buy size based on how oversold the market is.

        More oversold = larger position.
        """
        # RSI factor (0-30 range, lower = more oversold)
        rsi_factor = (self.oversold_threshold - rsi) / self.oversold_threshold

        # Deviation factor (larger deviation = larger position)
        dev_factor = min(Decimal(2), deviation * self.deviation_multiplier * 10)

        # Combined scale
        scale = 1 + (rsi_factor + dev_factor) / 2
        size = self.base_order_size * scale

        # Cap at available balance
        size = min(size, state.tao_balance * Decimal("0.5"))

        return self.clamp_order_size(size)

    def _calculate_sell_size(
        self, deviation: Decimal, rsi: Decimal, state: EngineState
    ) -> Decimal:
        """Calculate sell size based on how overbought the market is.

        More overbought = larger sell.
        """
        # RSI factor (70-100 range, higher = more overbought)
        rsi_factor = (rsi - self.overbought_threshold) / (
            Decimal(100) - self.overbought_threshold
        )

        # Sell percentage based on signals
        sell_pct = min(Decimal("0.5"), (rsi_factor + deviation) / 2)
        size = state.alpha_balance * sell_pct

        return self.clamp_order_size(size)
