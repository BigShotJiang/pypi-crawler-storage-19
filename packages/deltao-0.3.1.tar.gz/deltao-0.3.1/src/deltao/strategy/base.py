"""Base strategy class with common utilities.

Provides:
- Indicator calculations (SMA, EMA, RSI, etc.)
- Common helper methods for strategies
- Event hooks for event-driven strategies
- Abstract base for implementing AlgoStrategy protocol
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

    from deltao.core.detector import DetectedEvent
    from deltao.core.state import EngineState
    from deltao.core.types import OrderRequest


class Indicator(Enum):
    """Available technical indicators."""

    SMA = "sma"  # Simple Moving Average
    EMA = "ema"  # Exponential Moving Average
    RSI = "rsi"  # Relative Strength Index
    VOLATILITY = "volatility"  # Standard deviation


@dataclass
class IndicatorConfig:
    """Configuration for an indicator."""

    indicator: Indicator
    period: int
    params: dict[str, Decimal] = field(default_factory=dict)


def calculate_sma(prices: Sequence[Decimal], period: int) -> Decimal | None:
    """Calculate Simple Moving Average.

    Args:
        prices: Price sequence (most recent last)
        period: Number of periods

    Returns:
        SMA value or None if insufficient data
    """
    if len(prices) < period:
        return None

    recent = list(prices)[-period:]
    return sum(recent) / Decimal(period)


def calculate_ema(
    prices: Sequence[Decimal], period: int, smoothing: Decimal = Decimal(2)
) -> Decimal | None:
    """Calculate Exponential Moving Average.

    Args:
        prices: Price sequence (most recent last)
        period: Number of periods
        smoothing: Smoothing factor (default 2)

    Returns:
        EMA value or None if insufficient data
    """
    if len(prices) < period:
        return None

    prices_list = list(prices)
    multiplier = smoothing / (Decimal(period) + 1)

    # Start with SMA for first EMA value
    ema = sum(prices_list[:period]) / Decimal(period)

    # Calculate EMA for remaining prices
    for price in prices_list[period:]:
        ema = (price * multiplier) + (ema * (1 - multiplier))

    return ema


def calculate_rsi(prices: Sequence[Decimal], period: int = 14) -> Decimal | None:
    """Calculate Relative Strength Index.

    Args:
        prices: Price sequence (most recent last)
        period: RSI period (default 14)

    Returns:
        RSI value (0-100) or None if insufficient data
    """
    if len(prices) < period + 1:
        return None

    prices_list = list(prices)
    changes = [prices_list[i] - prices_list[i - 1] for i in range(1, len(prices_list))]

    recent_changes = changes[-(period):]
    gains = [c for c in recent_changes if c > 0]
    losses = [-c for c in recent_changes if c < 0]

    avg_gain = sum(gains) / Decimal(period) if gains else Decimal(0)
    avg_loss = sum(losses) / Decimal(period) if losses else Decimal(0)

    if avg_loss == 0:
        return Decimal(100)

    rs = avg_gain / avg_loss
    rsi = Decimal(100) - (Decimal(100) / (1 + rs))

    return rsi


def calculate_volatility(prices: Sequence[Decimal], period: int) -> Decimal | None:
    """Calculate price volatility (standard deviation).

    Args:
        prices: Price sequence (most recent last)
        period: Number of periods

    Returns:
        Standard deviation or None if insufficient data
    """
    if len(prices) < period:
        return None

    recent = list(prices)[-period:]
    mean = sum(recent) / Decimal(period)
    variance = sum((p - mean) ** 2 for p in recent) / Decimal(period)

    return variance.sqrt()


class BaseStrategy(ABC):
    """Abstract base class for trading strategies.

    Implements the AlgoStrategy protocol with common utilities.

    Subclasses must implement:
        - generate_orders(state) -> (cancels, opens)
    """

    def __init__(
        self,
        name: str = "BaseStrategy",
        min_order_size: Decimal = Decimal("0.01"),
        max_order_size: Decimal = Decimal("100"),
    ) -> None:
        """Initialize base strategy.

        Args:
            name: Strategy name for logging
            min_order_size: Minimum order size in TAO
            max_order_size: Maximum order size in TAO
        """
        self.name = name
        self.min_order_size = min_order_size
        self.max_order_size = max_order_size

    @abstractmethod
    def generate_orders(
        self, state: EngineState
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Generate orders based on current state.

        Args:
            state: Current engine state

        Returns:
            tuple: (orders_to_cancel, orders_to_open)
        """
        ...

    def get_sma(self, state: EngineState, period: int) -> Decimal | None:
        """Get SMA from state price history."""
        return calculate_sma(state.price_history, period)

    def get_ema(self, state: EngineState, period: int) -> Decimal | None:
        """Get EMA from state price history."""
        return calculate_ema(state.price_history, period)

    def get_rsi(self, state: EngineState, period: int = 14) -> Decimal | None:
        """Get RSI from state price history."""
        return calculate_rsi(state.price_history, period)

    def get_volatility(self, state: EngineState, period: int) -> Decimal | None:
        """Get volatility from state price history."""
        return calculate_volatility(state.price_history, period)

    def clamp_order_size(self, size: Decimal) -> Decimal:
        """Clamp order size to min/max bounds."""
        return max(self.min_order_size, min(self.max_order_size, size))

    def has_sufficient_data(self, state: EngineState, min_periods: int) -> bool:
        """Check if state has enough price history."""
        return len(state.price_history) >= min_periods

    # Event hooks for event-driven strategies
    # Override these methods in subclasses to react to detected events

    def on_price_jump(
        self,
        event: DetectedEvent,  # noqa: ARG002
        state: EngineState,  # noqa: ARG002
    ) -> list[OrderRequest]:
        """Hook called when a price jump is detected.

        Override this method in subclasses to react to sudden price changes.

        Args:
            event: The detected price jump event with details:
                - old_price: Previous price
                - new_price: Current price
                - change_pct: Percentage change (Decimal)
                - direction: "up" or "down"
            state: Current engine state

        Returns:
            List of orders to execute (empty by default)

        Example:
            def on_price_jump(self, event, state):
                if event.severity == EventSeverity.HIGH:
                    if event.details["direction"] == "down":
                        # Buy on large dip
                        return [OrderRequest(side=Side.BUY, amount=...)]
                return []
        """
        return []

    def on_liquidity_change(
        self,
        event: DetectedEvent,  # noqa: ARG002
        state: EngineState,  # noqa: ARG002
    ) -> list[OrderRequest]:
        """Hook called when a liquidity change is detected.

        Override this method in subclasses to react to pool changes.

        Args:
            event: The detected liquidity change event with details:
                - old_tao_in/old_alpha_in: Previous liquidity
                - new_tao_in/new_alpha_in: Current liquidity
                - change_pct: Percentage change (Decimal)
                - direction: "increase" or "decrease"
                - pool: "tao" or "alpha"
            state: Current engine state

        Returns:
            List of orders to execute (empty by default)
        """
        return []

    def process_detected_events(self, state: EngineState) -> list[OrderRequest]:
        """Process all detected events from the current market state.

        This method is called by the engine to collect orders generated
        by event hooks. It iterates through detected_events and calls
        the appropriate hook for each event type.

        Args:
            state: Current engine state (with current_market containing events)

        Returns:
            Combined list of orders from all event hooks
        """
        from deltao.core.detector import DetectedEventType

        orders: list[OrderRequest] = []

        # Check if we have market data with detected events
        if not hasattr(state, "current_market") or state.current_market is None:
            return orders

        market = state.current_market
        if not hasattr(market, "detected_events"):
            return orders

        for event in market.detected_events:
            if event.event_type == DetectedEventType.PRICE_JUMP:
                orders.extend(self.on_price_jump(event, state))
            elif event.event_type == DetectedEventType.LIQUIDITY_CHANGE:
                orders.extend(self.on_liquidity_change(event, state))

        return orders
