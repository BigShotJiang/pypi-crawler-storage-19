"""Risk management implementations.

Provides:
- NoOpRiskManager: Pass-through (no risk checks)
- BasicRiskManager: Common risk checks (position size, balance, drawdown)
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from deltao.core.state import EngineState
    from deltao.core.types import OrderRequest

from deltao.core.types import Side


class NoOpRiskManager:
    """No-op risk manager that approves all orders.

    Useful for backtesting or when risk is managed externally.
    """

    def check(
        self, _state: EngineState, orders: list[OrderRequest]
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Approve all orders without checking.

        Args:
            _state: Current engine state (ignored)
            orders: Orders to check

        Returns:
            tuple: (all orders approved, empty denied list)
        """
        return (orders, [])


@dataclass
class BasicRiskManager:
    """Basic risk manager with common checks.

    Checks:
    - Maximum position size
    - Sufficient balance
    - Maximum exposure percentage
    - Optional drawdown limit
    """

    max_position_size: Decimal = Decimal("10")  # Max TAO per order
    max_exposure_pct: Decimal = Decimal("0.5")  # Max 50% of balance per trade
    min_balance_reserve: Decimal = Decimal("0.1")  # Keep 10% as reserve
    max_drawdown: Decimal | None = None  # Optional drawdown limit

    def check(
        self, state: EngineState, orders: list[OrderRequest]
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Check orders against risk rules.

        Args:
            state: Current engine state
            orders: Orders to check

        Returns:
            tuple: (approved_orders, denied_orders)
        """
        approved: list[OrderRequest] = []
        denied: list[OrderRequest] = []

        for order in orders:
            if self._check_order(state, order):
                approved.append(order)
            else:
                denied.append(order)

        return (approved, denied)

    def _check_order(self, state: EngineState, order: OrderRequest) -> bool:
        """Check single order against risk rules.

        Args:
            state: Current engine state
            order: Order to check

        Returns:
            bool: True if order passes all checks
        """
        # Check position size
        if order.amount > self.max_position_size:
            return False

        # Check balance for buys
        if order.side == Side.BUY:
            available = state.tao_balance * (1 - self.min_balance_reserve)

            # Check max exposure
            max_allowed = available * self.max_exposure_pct
            if order.amount > max_allowed:
                return False

            # Check sufficient balance
            if order.amount > available:
                return False

        # Check balance for sells
        return not (order.side == Side.SELL and order.amount > state.alpha_balance)


@dataclass
class PositionLimitRiskManager:
    """Risk manager with position-based limits.

    Tracks cumulative exposure and enforces limits.
    """

    max_total_exposure: Decimal = Decimal("100")  # Max total TAO exposure
    max_single_order: Decimal = Decimal("10")  # Max per order
    current_exposure: Decimal = Decimal(0)  # Track current exposure

    def check(
        self, state: EngineState, orders: list[OrderRequest]
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Check orders against position limits.

        Args:
            state: Current engine state
            orders: Orders to check

        Returns:
            tuple: (approved_orders, denied_orders)
        """
        approved: list[OrderRequest] = []
        denied: list[OrderRequest] = []

        # Calculate current exposure from state
        self.current_exposure = state.alpha_balance * state.current_price

        for order in orders:
            if self._check_order(order):
                approved.append(order)

                # Update exposure tracking for approved orders
                if order.side == Side.BUY:
                    self.current_exposure += order.amount
                else:
                    self.current_exposure -= order.amount
            else:
                denied.append(order)

        return (approved, denied)

    def _check_order(self, order: OrderRequest) -> bool:
        """Check single order against position limits."""
        # Check single order size
        if order.amount > self.max_single_order:
            return False

        # Check total exposure for buys
        if order.side == Side.BUY:
            new_exposure = self.current_exposure + order.amount
            if new_exposure > self.max_total_exposure:
                return False

        return True
