"""Data loading and saving utilities for backtesting.

Handles parquet and CSV file operations for historical block data.
Filename convention: dtao|subnet{netuid}|1block.{parquet,csv}

Based on IMPLEMENTATION_BACKTEST.md.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from pathlib import Path

    import pandas as pd


DataFormat = Literal["parquet", "csv", "auto"]


def get_data_filename(netuid: int, fmt: Literal["parquet", "csv"] = "parquet") -> str:
    """Get standard filename for subnet data.

    Args:
        netuid: Subnet ID
        fmt: File format ("parquet" or "csv")

    Returns:
        Filename in format: dtao|subnet{netuid}|1block.{ext}
    """
    ext = "parquet" if fmt == "parquet" else "csv"
    return f"dtao|subnet{netuid}|1block.{ext}"


def load_block_data(
    netuid: int,
    data_dir: Path,
    start_block: int | None = None,
    end_block: int | None = None,
    fmt: DataFormat = "auto",
) -> pd.DataFrame:
    """Load block data from parquet or CSV file.

    Args:
        netuid: Subnet ID
        data_dir: Directory containing data files
        start_block: Optional start block filter
        end_block: Optional end block filter
        fmt: File format - "parquet", "csv", or "auto" (tries parquet first)

    Returns:
        DataFrame with columns: timestamp, block_number, price, tao_in, alpha_in, k

    Raises:
        FileNotFoundError: If data file doesn't exist
        ImportError: If pandas not installed
    """
    try:
        import pandas as pd
    except ImportError as e:
        msg = "pandas is required for backtesting: pip install pandas pyarrow"
        raise ImportError(msg) from e

    # Determine file path based on format
    if fmt == "auto":
        # Try parquet first, then csv
        parquet_path = data_dir / get_data_filename(netuid, "parquet")
        csv_path = data_dir / get_data_filename(netuid, "csv")
        if parquet_path.exists():
            filepath = parquet_path
            actual_fmt = "parquet"
        elif csv_path.exists():
            filepath = csv_path
            actual_fmt = "csv"
        else:
            msg = f"Data file not found: tried {parquet_path} and {csv_path}"
            raise FileNotFoundError(msg)
    else:
        filepath = data_dir / get_data_filename(netuid, fmt)
        actual_fmt = fmt
        if not filepath.exists():
            msg = f"Data file not found: {filepath}"
            raise FileNotFoundError(msg)

    # Load data based on format
    if actual_fmt == "parquet":
        data = pd.read_parquet(filepath)
    else:
        data = pd.read_csv(filepath)

    # Set datetime index from timestamp
    data.index = pd.to_datetime(data["timestamp"], unit="s")
    data.index.name = None

    # Filter by block range if specified
    if start_block is not None:
        data = data[data["block_number"] >= start_block]
    if end_block is not None:
        data = data[data["block_number"] <= end_block]

    return data


def save_block_data(
    data: pd.DataFrame,
    netuid: int,
    output_dir: Path,
    fmt: Literal["parquet", "csv"] = "parquet",
) -> Path:
    """Save block data to parquet or CSV format.

    Args:
        data: DataFrame with columns: timestamp, block_number, price, tao_in, alpha_in, k
        netuid: Subnet ID
        output_dir: Output directory
        fmt: File format - "parquet" (default) or "csv"

    Returns:
        Path to saved file
    """
    try:
        import pandas as pd
    except ImportError as e:
        msg = "pandas is required for backtesting: pip install pandas pyarrow"
        raise ImportError(msg) from e

    # Ensure output directory exists
    output_dir.mkdir(parents=True, exist_ok=True)

    filename = get_data_filename(netuid, fmt)
    output_path = output_dir / filename

    # Convert numeric columns
    numeric_cols = ["price", "tao_in", "alpha_in", "k"]
    for col in numeric_cols:
        if col in data.columns:
            data[col] = pd.to_numeric(data[col])

    # Save based on format
    if fmt == "parquet":
        data.to_parquet(output_path, index=False, compression="snappy")
    else:
        data.to_csv(output_path, index=False)

    return output_path


def create_sample_data(
    *,
    netuid: int = 8,  # noqa: ARG001
    num_blocks: int = 1000,
    start_block: int = 1_000_000,
    base_price: float = 1.0,
    volatility: float = 0.02,
) -> pd.DataFrame:
    """Create sample block data for testing.

    Generates synthetic price data with random walk.

    Args:
        netuid: Subnet ID (reserved for future use)
        num_blocks: Number of blocks to generate
        start_block: Starting block number
        base_price: Initial price
        volatility: Price volatility per block

    Returns:
        DataFrame with synthetic block data
    """
    try:
        import numpy as np
        import pandas as pd
    except ImportError as e:
        msg = "pandas and numpy are required: pip install pandas numpy"
        raise ImportError(msg) from e

    np.random.seed(42)

    # Generate price random walk
    returns = np.random.normal(0, volatility, num_blocks)
    prices = base_price * np.exp(np.cumsum(returns))

    # Base liquidity
    base_tao = 10000.0
    base_alpha = base_tao / base_price

    # Generate timestamps (12 second blocks)
    start_timestamp = 1700000000
    timestamps = [start_timestamp + i * 12 for i in range(num_blocks)]

    # Create DataFrame
    data = pd.DataFrame(
        {
            "timestamp": timestamps,
            "block_number": [start_block + i for i in range(num_blocks)],
            "price": prices,
            "tao_in": [
                base_tao * (1 + np.random.uniform(-0.1, 0.1)) for _ in range(num_blocks)
            ],
            "alpha_in": [
                base_alpha * (1 + np.random.uniform(-0.1, 0.1))
                for _ in range(num_blocks)
            ],
        }
    )

    # Calculate k (constant product)
    data["k"] = data["tao_in"] * data["alpha_in"]

    return data
