"""Backtest configuration types.

Based on IMPLEMENTATION_BACKTEST.md.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path


@dataclass
class BacktestConfig:
    """Configuration for a single backtest run.

    Args:
        netuid: Subnet ID to backtest
        start_block: Starting block number
        end_block: Ending block number
        initial_tao: Starting TAO balance
        initial_alpha: Starting Alpha balance
        trade_fee: Trading fee percentage (default 0.1%)
        data_dir: Directory containing parquet data files
    """

    netuid: int
    start_block: int
    end_block: int
    initial_tao: Decimal = Decimal("1000")
    initial_alpha: Decimal = Decimal("0")
    trade_fee: Decimal = Decimal("0.001")  # 0.1% fee
    data_dir: Path = field(default_factory=lambda: Path("data/candles"))

    def __post_init__(self) -> None:
        """Validate configuration."""
        if self.start_block >= self.end_block:
            msg = f"start_block ({self.start_block}) must be < end_block ({self.end_block})"
            raise ValueError(msg)
        if self.initial_tao < 0:
            msg = "initial_tao must be non-negative"
            raise ValueError(msg)
        if self.initial_alpha < 0:
            msg = "initial_alpha must be non-negative"
            raise ValueError(msg)
        if not (Decimal(0) <= self.trade_fee <= Decimal(1)):
            msg = "trade_fee must be between 0 and 1"
            raise ValueError(msg)


@dataclass
class BacktestingConfig:
    """Combined config for backtest + strategy parameters.

    Used by optimizer to couple backtest settings with strategy hyperparameters.
    """

    backtest_config: BacktestConfig
    strategy_config: dict[str, Decimal | int | float | str]
