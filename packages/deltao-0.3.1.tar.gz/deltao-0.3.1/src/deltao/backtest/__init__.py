"""Backtesting module for historical strategy simulation.

This module provides:
- BacktestingEngine: Run strategies against historical data
- Recorder: Track trades and calculate metrics
- Data utilities: Load/save parquet and CSV files

Example:
    from deltao.backtest import BacktestingEngine, BacktestConfig
    from deltao.strategy import MomentumStrategy, BasicRiskManager

    config = BacktestConfig(
        netuid=8,
        start_block=1_000_000,
        end_block=1_100_000,
        initial_tao=Decimal("1000"),
    )

    engine = BacktestingEngine()
    result = await engine.run(config, MomentumStrategy(), BasicRiskManager())
    print(result.summary())
"""

from deltao.backtest.config import BacktestConfig, BacktestingConfig
from deltao.backtest.data import (
    DataFormat,
    create_sample_data,
    get_data_filename,
    load_block_data,
    save_block_data,
)
from deltao.backtest.engine import BacktestingEngine
from deltao.backtest.recorder import BacktestResult, Recorder, Trade

__all__ = [
    "BacktestConfig",
    "BacktestResult",
    "BacktestingConfig",
    "BacktestingEngine",
    "DataFormat",
    "Recorder",
    "Trade",
    "create_sample_data",
    "get_data_filename",
    "load_block_data",
    "save_block_data",
]
