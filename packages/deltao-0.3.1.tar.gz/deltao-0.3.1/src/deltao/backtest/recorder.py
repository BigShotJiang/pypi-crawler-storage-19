"""Backtest recording and metrics calculation.

Records trades, portfolio values, and calculates performance metrics.

Based on IMPLEMENTATION_BACKTEST.md.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import TYPE_CHECKING

from deltao.core.types import Side

if TYPE_CHECKING:
    from datetime import datetime

    from deltao.core.engine import Audit
    from deltao.core.state import EngineState


@dataclass
class Trade:
    """Recorded trade from backtest."""

    timestamp: datetime
    block_number: int
    side: Side
    amount: Decimal
    price: Decimal
    fee: Decimal

    @property
    def value(self) -> Decimal:
        """Trade value in TAO."""
        return self.amount * self.price

    @property
    def net_value(self) -> Decimal:
        """Trade value minus fees."""
        return self.value - self.fee


@dataclass
class BacktestResult:
    """Complete backtest results and metrics."""

    # Trade data
    trades: list[Trade]
    total_trades: int

    # P&L
    initial_value: Decimal
    final_value: Decimal
    total_pnl: Decimal
    total_fees: Decimal
    net_pnl: Decimal

    # Returns series
    returns: list[Decimal]
    cumulative_returns: list[Decimal]
    portfolio_values: list[Decimal]
    timestamps: list[datetime]

    # Risk metrics
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    max_drawdown_duration: int  # In blocks

    # Trade metrics
    win_rate: float
    profit_factor: float
    avg_trade_pnl: Decimal
    avg_win: Decimal
    avg_loss: Decimal

    # Execution stats
    total_volume: Decimal
    avg_trade_size: Decimal

    def summary(self) -> str:
        """Generate human-readable summary."""
        return f"""
Backtest Results
================
Duration: {len(self.timestamps)} blocks
Total Trades: {self.total_trades}

P&L
---
Initial Value: {self.initial_value:.4f} TAO
Final Value:   {self.final_value:.4f} TAO
Net P&L:       {self.net_pnl:.4f} TAO ({float(self.net_pnl / self.initial_value * 100):.2f}%)
Total Fees:    {self.total_fees:.4f} TAO

Risk Metrics
------------
Sharpe Ratio:  {self.sharpe_ratio:.3f}
Sortino Ratio: {self.sortino_ratio:.3f}
Max Drawdown:  {self.max_drawdown:.2%}

Trade Metrics
-------------
Win Rate:      {self.win_rate:.2%}
Profit Factor: {self.profit_factor:.2f}
Avg Trade:     {self.avg_trade_pnl:.4f} TAO
"""


@dataclass
class Recorder:
    """Record backtest activity for analysis.

    Tracks portfolio values, trades, and calculates metrics.
    """

    trade_fee: Decimal = Decimal("0.001")
    _trades: list[Trade] = field(default_factory=list)
    _portfolio_values: list[Decimal] = field(default_factory=list)
    _timestamps: list[datetime] = field(default_factory=list)
    _initial_value: Decimal | None = None

    def record(self, audit: Audit, state: EngineState) -> None:
        """Record state after processing an event.

        Args:
            audit: Audit trail from engine
            state: Current engine state
        """
        # Calculate portfolio value
        portfolio_value = state.tao_balance + (
            state.alpha_balance * state.current_price
        )

        # Store initial value
        if self._initial_value is None:
            self._initial_value = portfolio_value

        self._portfolio_values.append(portfolio_value)
        self._timestamps.append(audit.timestamp)

        # Record trades from approved orders
        for order in audit.orders_approved:
            fee = order.amount * self.trade_fee
            trade = Trade(
                timestamp=audit.timestamp,
                block_number=state.current_block,
                side=order.side,
                amount=order.amount,
                price=state.current_price,
                fee=fee,
            )
            self._trades.append(trade)

    def generate_result(self) -> BacktestResult:
        """Generate backtest result with all metrics.

        Returns:
            BacktestResult with calculated metrics
        """
        if len(self._portfolio_values) == 0:
            return self._empty_result()

        # Calculate returns
        returns = self._calculate_returns()
        cumulative_returns = self._calculate_cumulative_returns(returns)

        # P&L calculations
        initial_value = self._initial_value or self._portfolio_values[0]
        final_value = self._portfolio_values[-1]
        total_pnl = final_value - initial_value
        total_fees = sum(t.fee for t in self._trades)
        net_pnl = total_pnl - total_fees

        # Risk metrics
        returns_float = [float(r) for r in returns]
        sharpe = self._calculate_sharpe(returns_float)
        sortino = self._calculate_sortino(returns_float)
        max_dd, max_dd_duration = self._calculate_max_drawdown()

        # Trade metrics
        trade_metrics = self._calculate_trade_metrics()

        # Volume stats
        total_volume = sum((t.value for t in self._trades), Decimal(0))
        avg_trade_size = (
            total_volume / len(self._trades) if self._trades else Decimal(0)
        )

        return BacktestResult(
            trades=self._trades.copy(),
            total_trades=len(self._trades),
            initial_value=initial_value,
            final_value=final_value,
            total_pnl=total_pnl,
            total_fees=Decimal(total_fees),
            net_pnl=net_pnl,
            returns=returns,
            cumulative_returns=cumulative_returns,
            portfolio_values=self._portfolio_values.copy(),
            timestamps=self._timestamps.copy(),
            sharpe_ratio=sharpe,
            sortino_ratio=sortino,
            max_drawdown=max_dd,
            max_drawdown_duration=max_dd_duration,
            win_rate=float(trade_metrics["win_rate"]),
            profit_factor=float(trade_metrics["profit_factor"]),
            avg_trade_pnl=Decimal(str(trade_metrics["avg_trade_pnl"])),
            avg_win=Decimal(str(trade_metrics["avg_win"])),
            avg_loss=Decimal(str(trade_metrics["avg_loss"])),
            total_volume=total_volume,
            avg_trade_size=avg_trade_size,
        )

    def _empty_result(self) -> BacktestResult:
        """Return empty result when no data recorded."""
        return BacktestResult(
            trades=[],
            total_trades=0,
            initial_value=Decimal(0),
            final_value=Decimal(0),
            total_pnl=Decimal(0),
            total_fees=Decimal(0),
            net_pnl=Decimal(0),
            returns=[],
            cumulative_returns=[],
            portfolio_values=[],
            timestamps=[],
            sharpe_ratio=0.0,
            sortino_ratio=0.0,
            max_drawdown=0.0,
            max_drawdown_duration=0,
            win_rate=0.0,
            profit_factor=0.0,
            avg_trade_pnl=Decimal(0),
            avg_win=Decimal(0),
            avg_loss=Decimal(0),
            total_volume=Decimal(0),
            avg_trade_size=Decimal(0),
        )

    def _calculate_returns(self) -> list[Decimal]:
        """Calculate period-over-period returns."""
        returns = []
        for i in range(1, len(self._portfolio_values)):
            prev = self._portfolio_values[i - 1]
            curr = self._portfolio_values[i]
            ret = (curr - prev) / prev if prev != 0 else Decimal(0)
            returns.append(ret)
        return returns

    def _calculate_cumulative_returns(self, returns: list[Decimal]) -> list[Decimal]:
        """Calculate cumulative returns series."""
        cumulative = []
        cum_ret = Decimal(1)
        for ret in returns:
            cum_ret *= 1 + ret
            cumulative.append(cum_ret - 1)
        return cumulative

    def _calculate_sharpe(
        self,
        returns: list[float],
        risk_free_rate: float = 0.0,
        periods_per_year: int = 2_628_000,  # ~12 sec blocks
    ) -> float:
        """Calculate annualized Sharpe ratio."""
        if len(returns) < 2:
            return 0.0

        try:
            import numpy as np
        except ImportError:
            return 0.0

        returns_array = np.array(returns)
        excess_returns = returns_array - risk_free_rate / periods_per_year

        std = np.std(excess_returns, ddof=1)
        if std == 0:
            return 0.0

        return float(np.mean(excess_returns) / std * np.sqrt(periods_per_year))

    def _calculate_sortino(
        self,
        returns: list[float],
        risk_free_rate: float = 0.0,
        periods_per_year: int = 2_628_000,
    ) -> float:
        """Calculate annualized Sortino ratio (downside deviation only)."""
        if len(returns) < 2:
            return 0.0

        try:
            import numpy as np
        except ImportError:
            return 0.0

        returns_array = np.array(returns)
        excess_returns = returns_array - risk_free_rate / periods_per_year

        # Downside deviation (only negative returns)
        downside_returns = excess_returns[excess_returns < 0]
        if len(downside_returns) == 0:
            return float("inf") if np.mean(excess_returns) > 0 else 0.0

        downside_std = np.std(downside_returns, ddof=1)
        if downside_std == 0:
            return 0.0

        return float(np.mean(excess_returns) / downside_std * np.sqrt(periods_per_year))

    def _calculate_max_drawdown(self) -> tuple[float, int]:
        """Calculate maximum drawdown and duration.

        Returns:
            Tuple of (max_drawdown_pct, duration_in_blocks)
        """
        if len(self._portfolio_values) < 2:
            return 0.0, 0

        try:
            import numpy as np
        except ImportError:
            return 0.0, 0

        values = np.array([float(v) for v in self._portfolio_values])
        running_max = np.maximum.accumulate(values)
        drawdown = (values - running_max) / running_max

        max_dd = float(np.min(drawdown))

        # Calculate drawdown duration
        in_drawdown = drawdown < 0
        max_duration = 0
        current_duration = 0

        for is_dd in in_drawdown:
            if is_dd:
                current_duration += 1
                max_duration = max(max_duration, current_duration)
            else:
                current_duration = 0

        return max_dd, max_duration

    def _calculate_trade_metrics(self) -> dict[str, float | Decimal]:
        """Calculate trade-level metrics."""
        if not self._trades:
            return {
                "win_rate": 0.0,
                "profit_factor": 0.0,
                "avg_trade_pnl": Decimal(0),
                "avg_win": Decimal(0),
                "avg_loss": Decimal(0),
            }

        # Treat SELL value as positive PnL, BUY value as negative (cash outlay).
        pnls = [
            (t.net_value if t.side == Side.SELL else -t.net_value) for t in self._trades
        ]

        total = len(self._trades)
        total_pnl = sum(pnls, Decimal(0))

        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p < 0]

        win_rate = len(wins) / total if total > 0 else 0.0

        gross_profit = sum(wins, Decimal(0))
        gross_loss = sum(losses, Decimal(0))
        profit_factor = (
            float(gross_profit / abs(gross_loss))
            if gross_loss
            else (float("inf") if gross_profit else 0.0)
        )

        avg_trade_pnl = total_pnl / Decimal(total) if total > 0 else Decimal(0)
        avg_win = gross_profit / Decimal(len(wins)) if wins else Decimal(0)
        avg_loss = gross_loss / Decimal(len(losses)) if losses else Decimal(0)

        return {
            "win_rate": win_rate,
            "profit_factor": profit_factor,
            "avg_trade_pnl": avg_trade_pnl,
            "avg_win": avg_win,
            "avg_loss": avg_loss,
        }

    def reset(self) -> None:
        """Reset recorder for new backtest."""
        self._trades.clear()
        self._portfolio_values.clear()
        self._timestamps.clear()
        self._initial_value = None
