"""Backtesting engine for historical simulation.

Runs strategies against historical block data.

Based on IMPLEMENTATION_BACKTEST.md.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from pathlib import Path
from typing import TYPE_CHECKING, cast

from deltao.backtest.data import load_block_data
from deltao.backtest.recorder import BacktestResult, Recorder
from deltao.connector.mock import MockConnector
from deltao.core.clock import HistoricalClock
from deltao.core.engine import AlgoStrategy, Engine, RiskManager
from deltao.core.event import MarketEvent
from deltao.core.state import EngineState

if TYPE_CHECKING:
    from collections.abc import Callable

    import pandas as pd

    from deltao.backtest.config import BacktestConfig
    from deltao.core.types import OrderRequest


@dataclass
class BacktestingEngine:
    """Block-by-block backtest engine for dTao strategies.

    Loads historical data and simulates strategy execution.

    Usage:
        engine = BacktestingEngine()
        result = await engine.run(config, strategy, risk_manager)
        print(result.summary())
    """

    data_dir: Path = field(default_factory=lambda: Path("data/candles"))
    _cache: dict[str, pd.DataFrame] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Initialize with optional data caching."""
        self._load_cache()

    def _load_cache(self) -> None:
        """Load all available parquet files into cache."""
        if not self.data_dir.exists():
            return

        try:
            import pandas as pd
        except ImportError:
            return

        for file in self.data_dir.glob("*.parquet"):
            try:
                df = pd.read_parquet(file)
                df.index = pd.to_datetime(df["timestamp"], unit="s")
                self._cache[file.stem] = df
            except Exception:
                # Skip files that can't be loaded
                continue

    def get_cached_data(self, netuid: int) -> pd.DataFrame | None:
        """Get data from cache if available.

        Args:
            netuid: Subnet ID

        Returns:
            Cached DataFrame or None
        """
        key = f"dtao|subnet{netuid}|1block"
        return self._cache.get(key)

    async def run(
        self,
        config: BacktestConfig,
        strategy: AlgoStrategy,
        risk: RiskManager,
        progress_callback: Callable[[int, int], None] | None = None,
    ) -> BacktestResult:
        """Run backtest with given strategy and risk manager.

        Args:
            config: Backtest configuration
            strategy: Trading strategy to test
            risk: Risk manager for order validation
            progress_callback: Optional callback(current_block, total_blocks)

        Returns:
            BacktestResult with all metrics

        Raises:
            FileNotFoundError: If historical data not found
            ValueError: If no data in specified block range
        """
        # 1. Load historical data
        data = self._load_data(config)

        if len(data) == 0:
            msg = f"No data found for blocks {config.start_block}-{config.end_block}"
            raise ValueError(msg)

        # 2. Create engine components
        first_timestamp = data.index[0].to_pydatetime()
        clock = HistoricalClock(start_time=first_timestamp)

        state = EngineState(
            tao_balance=config.initial_tao,
            alpha_balance=config.initial_alpha,
            trading_enabled=True,
        )

        connector = MockConnector()

        engine = Engine(
            clock=clock,
            state=state,
            strategy=strategy,
            risk=risk,
            connector=connector,
        )

        # 3. Create recorder
        recorder = Recorder(trade_fee=config.trade_fee)

        # 4. Process each block
        total_blocks = len(data)
        for i, (idx, row) in enumerate(data.iterrows()):
            # Create market event from row
            event = MarketEvent(
                netuid=config.netuid,
                price=Decimal(str(row["price"])),
                tao_in=Decimal(str(row["tao_in"])),
                alpha_in=Decimal(str(row["alpha_in"])),
                k=Decimal(str(row["k"])),
                block_number=int(row["block_number"]),
                timestamp=cast("pd.Timestamp", idx).to_pydatetime(),
            )

            # Process event through engine
            audit = await engine.process(event)

            # Simulate trade execution (update balances for approved orders)
            self._simulate_trades(state, audit.orders_approved, config.trade_fee)

            # Record state
            recorder.record(audit, state)

            # Progress callback
            if progress_callback is not None:
                progress_callback(i + 1, total_blocks)

        # 5. Generate result
        return recorder.generate_result()

    def _load_data(self, config: BacktestConfig) -> pd.DataFrame:
        """Load and filter historical data.

        Args:
            config: Backtest configuration

        Returns:
            Filtered DataFrame
        """
        # Try cache first
        cached = self.get_cached_data(config.netuid)
        if cached is not None:
            data = cached
        else:
            data = load_block_data(config.netuid, config.data_dir)

        # Filter by block range
        data = data[
            (data["block_number"] >= config.start_block)
            & (data["block_number"] <= config.end_block)
        ]

        return data

    def _simulate_trades(
        self,
        state: EngineState,
        orders: list[OrderRequest],
        trade_fee: Decimal,
    ) -> None:
        """Simulate trade execution by updating balances.

        Args:
            state: Engine state to update
            orders: List of approved orders
            trade_fee: Fee percentage to deduct
        """
        from deltao.core.types import Side

        for order in orders:
            fee = order.amount * trade_fee

            if order.side == Side.BUY:
                # Buy: spend TAO, receive Alpha
                cost = order.amount + fee
                if state.tao_balance >= cost:
                    state.tao_balance -= cost
                    # Alpha received = TAO spent / price
                    alpha_received = order.amount / state.current_price
                    state.alpha_balance += alpha_received

            elif order.side == Side.SELL:
                # Sell: spend Alpha, receive TAO
                if state.alpha_balance >= order.amount:
                    state.alpha_balance -= order.amount
                    # TAO received = Alpha sold * price - fee
                    tao_received = (order.amount * state.current_price) - fee
                    state.tao_balance += tao_received

    async def run_multiple(
        self,
        configs: list[tuple[BacktestConfig, AlgoStrategy, RiskManager]],
    ) -> list[BacktestResult]:
        """Run multiple backtests sequentially.

        Args:
            configs: List of (config, strategy, risk) tuples

        Returns:
            List of BacktestResult for each configuration
        """
        results = []
        for config, strategy, risk in configs:
            result = await self.run(config, strategy, risk)
            results.append(result)
        return results
