"""deltao - Bittensor dTao Trading Framework."""

from importlib.metadata import version

from deltao.core.agent import (
    AgentConfig,
    AgentPerformance,
    AgentStatus,
    StrategyAgent,
    create_agent,
)
from deltao.core.clock import Clock, HistoricalClock, LiveClock
from deltao.core.engine import AlgoStrategy, Audit, Engine, RiskManager
from deltao.core.event import (
    AccountEvent,
    CommandEvent,
    Event,
    EventType,
    MarketEvent,
    ShutdownEvent,
    TradingStateUpdate,
)
from deltao.core.portfolio import (
    AllocationStrategy,
    PortfolioConfig,
    PortfolioManager,
    PortfolioMetrics,
)
from deltao.core.state import EngineState
from deltao.core.types import LiquidityPosition, OrderRequest, OrderResult, Side

__version__ = version("deltao")

__all__ = [
    "AccountEvent",
    "AgentConfig",
    "AgentPerformance",
    "AgentStatus",
    "AlgoStrategy",
    "AllocationStrategy",
    "Audit",
    "Clock",
    "CommandEvent",
    "Engine",
    "EngineState",
    "Event",
    "EventType",
    "HistoricalClock",
    "LiquidityPosition",
    "LiveClock",
    "MarketEvent",
    "OrderRequest",
    "OrderResult",
    "PortfolioConfig",
    "PortfolioManager",
    "PortfolioMetrics",
    "RiskManager",
    "ShutdownEvent",
    "Side",
    "StrategyAgent",
    "TradingStateUpdate",
    "__version__",
    "create_agent",
]
