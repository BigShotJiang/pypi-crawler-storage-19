"""Event detection for market state changes.

Detects significant market events like:
- Price jumps (sudden price changes)
- Liquidity changes (TAO/Alpha pool changes)
- Volume spikes
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from deltao.core.event import MarketEvent


class EventSeverity(Enum):
    """Severity level for detected events."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class DetectedEventType(Enum):
    """Types of detected market events."""

    PRICE_JUMP = "price_jump"
    LIQUIDITY_CHANGE = "liquidity_change"
    VOLUME_SPIKE = "volume_spike"


@dataclass
class DetectedEvent:
    """A detected market event.

    Attributes:
        event_type: Type of detected event
        severity: Severity level (low, medium, high)
        details: Event-specific details
        timestamp: When the event was detected
    """

    event_type: DetectedEventType
    severity: EventSeverity
    details: dict[str, Any]
    timestamp: datetime

    @property
    def is_high_severity(self) -> bool:
        """Check if event is high severity."""
        return self.severity == EventSeverity.HIGH

    def __str__(self) -> str:
        """Human-readable representation."""
        return f"{self.event_type.value} ({self.severity.value})"


@dataclass
class EventDetector:
    """Detects significant market events from state changes.

    Compares consecutive market states and detects:
    - Price changes above threshold
    - Liquidity (TAO/Alpha) changes above threshold

    Usage:
        detector = EventDetector(price_change_threshold=Decimal("0.02"))
        events = detector.detect(market_event)
        for event in events:
            if event.is_high_severity:
                # Handle significant event
                pass
    """

    # Detection thresholds
    price_change_threshold: Decimal = Decimal("0.02")
    liquidity_change_threshold: Decimal = Decimal("0.1")

    # Severity thresholds
    high_severity_threshold: Decimal = Decimal("0.1")  # 10%+
    medium_severity_threshold: Decimal = Decimal("0.05")  # 5%+

    # State tracking (private)
    _last_price: Decimal | None = field(default=None, repr=False)
    _last_tao_in: Decimal | None = field(default=None, repr=False)
    _last_alpha_in: Decimal | None = field(default=None, repr=False)
    _last_block: int | None = field(default=None, repr=False)

    def detect(self, market: MarketEvent) -> list[DetectedEvent]:
        """Analyze market event and detect significant changes.

        Args:
            market: Current market event to analyze

        Returns:
            List of detected events (empty if no significant changes)
        """
        events: list[DetectedEvent] = []

        # Detect price jump
        if self._last_price is not None and self._last_price > 0:
            price_change = abs(market.price - self._last_price) / self._last_price
            if price_change >= self.price_change_threshold:
                direction = "up" if market.price > self._last_price else "down"
                events.append(
                    DetectedEvent(
                        event_type=DetectedEventType.PRICE_JUMP,
                        severity=self._calculate_severity(price_change),
                        details={
                            "old_price": self._last_price,
                            "new_price": market.price,
                            "change_pct": price_change,
                            "direction": direction,
                        },
                        timestamp=market.timestamp,
                    )
                )

        # Detect liquidity change (TAO)
        if self._last_tao_in is not None and self._last_tao_in > 0:
            tao_change = abs(market.tao_in - self._last_tao_in) / self._last_tao_in
            if tao_change >= self.liquidity_change_threshold:
                direction = (
                    "increase" if market.tao_in > self._last_tao_in else "decrease"
                )
                events.append(
                    DetectedEvent(
                        event_type=DetectedEventType.LIQUIDITY_CHANGE,
                        severity=self._calculate_severity(tao_change),
                        details={
                            "old_tao_in": self._last_tao_in,
                            "new_tao_in": market.tao_in,
                            "change_pct": tao_change,
                            "direction": direction,
                            "pool": "tao",
                        },
                        timestamp=market.timestamp,
                    )
                )

        # Detect liquidity change (Alpha)
        if self._last_alpha_in is not None and self._last_alpha_in > 0:
            alpha_change = (
                abs(market.alpha_in - self._last_alpha_in) / self._last_alpha_in
            )
            if alpha_change >= self.liquidity_change_threshold:
                direction = (
                    "increase" if market.alpha_in > self._last_alpha_in else "decrease"
                )
                events.append(
                    DetectedEvent(
                        event_type=DetectedEventType.LIQUIDITY_CHANGE,
                        severity=self._calculate_severity(alpha_change),
                        details={
                            "old_alpha_in": self._last_alpha_in,
                            "new_alpha_in": market.alpha_in,
                            "change_pct": alpha_change,
                            "direction": direction,
                            "pool": "alpha",
                        },
                        timestamp=market.timestamp,
                    )
                )

        # Update state for next comparison
        self._last_price = market.price
        self._last_tao_in = market.tao_in
        self._last_alpha_in = market.alpha_in
        self._last_block = market.block_number

        return events

    def _calculate_severity(self, change: Decimal) -> EventSeverity:
        """Calculate severity based on change magnitude."""
        if change >= self.high_severity_threshold:
            return EventSeverity.HIGH
        elif change >= self.medium_severity_threshold:
            return EventSeverity.MEDIUM
        return EventSeverity.LOW

    def reset(self) -> None:
        """Reset detector state (clear history)."""
        self._last_price = None
        self._last_tao_in = None
        self._last_alpha_in = None
        self._last_block = None

    def has_state(self) -> bool:
        """Check if detector has previous state for comparison."""
        return self._last_price is not None
