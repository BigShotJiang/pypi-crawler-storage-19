"""Event types for the trading engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from deltao.core.detector import DetectedEvent
    from deltao.core.types import LiquidityPosition


class EventType(Enum):
    """Event type enumeration."""

    SHUTDOWN = "shutdown"
    COMMAND = "command"
    TRADING_STATE_UPDATE = "trading_state_update"
    MARKET = "market"
    ACCOUNT = "account"


@dataclass
class ShutdownEvent:
    """Graceful shutdown signal."""

    reason: str
    timestamp: datetime


@dataclass
class CommandEvent:
    """External command (start/stop trading, etc.)."""

    command: str
    params: dict[str, str]
    timestamp: datetime


@dataclass
class TradingStateUpdate:
    """Enable/disable trading."""

    enabled: bool
    reason: str
    timestamp: datetime


@dataclass
class MarketEvent:
    """Market data update."""

    netuid: int
    price: Decimal
    tao_in: Decimal
    alpha_in: Decimal
    k: Decimal
    block_number: int
    timestamp: datetime
    # Event detection fields (populated by EventDetector)
    detected_events: list[DetectedEvent] = field(default_factory=list)
    is_significant: bool = False


@dataclass
class AccountEvent:
    """Account balance/position update."""

    tao_balance: Decimal
    alpha_balance: Decimal
    positions: list[LiquidityPosition]
    timestamp: datetime


# Union type for all events
Event = ShutdownEvent | CommandEvent | TradingStateUpdate | MarketEvent | AccountEvent
