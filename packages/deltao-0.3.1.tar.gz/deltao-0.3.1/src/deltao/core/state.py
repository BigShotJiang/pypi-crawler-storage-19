"""Engine state management."""

from collections import deque
from dataclasses import dataclass, field
from decimal import Decimal

from deltao.core.event import AccountEvent, MarketEvent, TradingStateUpdate
from deltao.core.types import LiquidityPosition


@dataclass
class EngineState:
    """Full engine state - positions, balances, market data."""

    # Trading control
    trading_enabled: bool = True

    # Account state
    tao_balance: Decimal = Decimal(0)
    alpha_balance: Decimal = Decimal(0)
    positions: list[LiquidityPosition] = field(default_factory=list)

    # Market state
    current_price: Decimal = Decimal(1)
    tao_in: Decimal = Decimal(0)
    alpha_in: Decimal = Decimal(0)
    k: Decimal = Decimal(0)
    current_block: int = 0

    # Price history (for indicators)
    price_history: deque[Decimal] = field(default_factory=lambda: deque(maxlen=1000))

    def update_from_market_event(self, event: MarketEvent) -> None:
        """Update state from market event."""
        self.current_price = event.price
        self.tao_in = event.tao_in
        self.alpha_in = event.alpha_in
        self.k = event.k
        self.current_block = event.block_number
        self.price_history.append(event.price)

    def update_from_account_event(self, event: AccountEvent) -> None:
        """Update state from account event."""
        self.tao_balance = event.tao_balance
        self.alpha_balance = event.alpha_balance
        self.positions = event.positions

    def update_from_trading_state(self, event: TradingStateUpdate) -> None:
        """Update trading enabled/disabled."""
        self.trading_enabled = event.enabled
