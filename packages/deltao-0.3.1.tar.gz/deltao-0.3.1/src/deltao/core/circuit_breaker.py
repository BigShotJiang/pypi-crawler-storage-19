"""Portfolio-wide circuit breaker for risk enforcement.

The CircuitBreaker monitors portfolio health and can trip (pause trading) when:
- Drawdown exceeds threshold
- Loss rate is too high (consecutive losses or % loss rate)
- Total exposure exceeds limits
- Market volatility spikes

Once tripped, manual reset is required to resume trading.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from deltao.core.portfolio import PortfolioMetrics


class CircuitBreakerState(Enum):
    """Circuit breaker operational state."""

    ACTIVE = "active"  # Normal operation, trading allowed
    TRIPPED = "tripped"  # Circuit breaker triggered, trading paused


class TriggerType(Enum):
    """Types of circuit breaker triggers."""

    DRAWDOWN = "drawdown"
    LOSS_RATE = "loss_rate"
    CONSECUTIVE_LOSSES = "consecutive_losses"
    EXPOSURE = "exposure"
    VOLATILITY = "volatility"


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker thresholds.

    Attributes:
        max_drawdown: Maximum portfolio drawdown before trip (default 15%)
        max_consecutive_losses: Trip after N consecutive losing trades
        max_loss_rate: Maximum loss rate (losses/total) over window
        loss_rate_window: Number of trades to track for loss rate
        max_total_exposure: Maximum portfolio exposure as fraction of capital
        volatility_threshold: Volatility level that triggers circuit breaker
        volatility_period: Number of price points for volatility calculation
    """

    # Drawdown trigger
    max_drawdown: Decimal = Decimal("0.15")  # 15%

    # Loss rate triggers
    max_consecutive_losses: int = 5
    max_loss_rate: Decimal = Decimal("0.7")  # 70% loss rate
    loss_rate_window: int = 20  # trades

    # Exposure trigger
    max_total_exposure: Decimal = Decimal("0.9")  # 90% of capital

    # Volatility trigger
    volatility_threshold: Decimal = Decimal("0.1")  # 10% std dev
    volatility_period: int = 20  # blocks/price points


@dataclass
class TripEvent:
    """Record of a circuit breaker trip.

    Attributes:
        trigger: Type of trigger that caused the trip
        value: The actual value that triggered (e.g., drawdown %)
        threshold: The threshold that was exceeded
        timestamp: When the trip occurred
        message: Human-readable description
    """

    trigger: TriggerType
    value: Decimal
    threshold: Decimal
    timestamp: datetime
    message: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "trigger": self.trigger.value,
            "value": str(self.value),
            "threshold": str(self.threshold),
            "timestamp": self.timestamp.isoformat(),
            "message": self.message,
        }


@dataclass
class CircuitBreaker:
    """Portfolio-wide circuit breaker for risk enforcement.

    Monitors portfolio health across multiple dimensions and trips
    (pauses trading) when thresholds are exceeded. Requires manual
    reset to resume trading after a trip.

    Usage:
        cb = CircuitBreaker(CircuitBreakerConfig())

        # Check on each event
        if not cb.check(portfolio_metrics, volatility):
            # Circuit breaker tripped, pause trading
            await pause_all_agents()

        # Record trade outcomes for loss tracking
        cb.record_trade_outcome(is_win=True)

        # Manual reset after resolving issue
        cb.reset()
    """

    config: CircuitBreakerConfig = field(default_factory=CircuitBreakerConfig)

    # State
    state: CircuitBreakerState = CircuitBreakerState.ACTIVE
    trip_event: TripEvent | None = None

    # Loss tracking
    trade_outcomes: deque[bool] = field(
        default_factory=lambda: deque(maxlen=100)
    )  # True=win, False=loss
    consecutive_losses: int = 0

    # Trip history
    trip_history: list[TripEvent] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Initialize with configured window size."""
        # Recreate deque with proper maxlen from config
        self.trade_outcomes = deque(maxlen=self.config.loss_rate_window)

    @property
    def is_tripped(self) -> bool:
        """Check if circuit breaker is currently tripped."""
        return self.state == CircuitBreakerState.TRIPPED

    @property
    def is_active(self) -> bool:
        """Check if circuit breaker is active (trading allowed)."""
        return self.state == CircuitBreakerState.ACTIVE

    def check(
        self,
        metrics: PortfolioMetrics,
        volatility: Decimal | None = None,
    ) -> bool:
        """Check all triggers against current portfolio state.

        Args:
            metrics: Current portfolio metrics (drawdown, exposure, etc.)
            volatility: Current market volatility (optional)

        Returns:
            True if all checks pass (trading can continue)
            False if any trigger trips (trading should pause)
        """
        if self.is_tripped:
            return False

        # Check drawdown
        if not self._check_drawdown(metrics):
            return False

        # Check exposure
        if not self._check_exposure(metrics):
            return False

        # Check loss rate
        if not self._check_loss_rate():
            return False

        # Check volatility (skip if None)
        return volatility is None or self._check_volatility(volatility)

    def _check_drawdown(self, metrics: PortfolioMetrics) -> bool:
        """Check drawdown trigger."""
        if metrics.max_drawdown > self.config.max_drawdown:
            self._trip(
                TriggerType.DRAWDOWN,
                metrics.max_drawdown,
                self.config.max_drawdown,
                f"Portfolio drawdown {metrics.max_drawdown:.1%} exceeds "
                f"limit {self.config.max_drawdown:.1%}",
            )
            return False
        return True

    def _check_exposure(self, metrics: PortfolioMetrics) -> bool:
        """Check exposure trigger."""
        if metrics.total_capital == 0:
            return True

        exposure = metrics.allocated_capital / metrics.total_capital
        if exposure > self.config.max_total_exposure:
            self._trip(
                TriggerType.EXPOSURE,
                exposure,
                self.config.max_total_exposure,
                f"Portfolio exposure {exposure:.1%} exceeds "
                f"limit {self.config.max_total_exposure:.1%}",
            )
            return False
        return True

    def _check_loss_rate(self) -> bool:
        """Check loss rate and consecutive loss triggers."""
        # Check consecutive losses
        if self.consecutive_losses >= self.config.max_consecutive_losses:
            self._trip(
                TriggerType.CONSECUTIVE_LOSSES,
                Decimal(self.consecutive_losses),
                Decimal(self.config.max_consecutive_losses),
                f"{self.consecutive_losses} consecutive losses exceeds "
                f"limit of {self.config.max_consecutive_losses}",
            )
            return False

        # Check loss rate over window
        if len(self.trade_outcomes) >= self.config.loss_rate_window:
            losses = sum(1 for outcome in self.trade_outcomes if not outcome)
            loss_rate = Decimal(losses) / Decimal(len(self.trade_outcomes))

            if loss_rate >= self.config.max_loss_rate:
                self._trip(
                    TriggerType.LOSS_RATE,
                    loss_rate,
                    self.config.max_loss_rate,
                    f"Loss rate {loss_rate:.1%} over {len(self.trade_outcomes)} trades "
                    f"exceeds limit {self.config.max_loss_rate:.1%}",
                )
                return False

        return True

    def _check_volatility(self, volatility: Decimal) -> bool:
        """Check volatility trigger."""
        if volatility > self.config.volatility_threshold:
            self._trip(
                TriggerType.VOLATILITY,
                volatility,
                self.config.volatility_threshold,
                f"Market volatility {volatility:.4f} exceeds "
                f"threshold {self.config.volatility_threshold:.4f}",
            )
            return False
        return True

    def _trip(
        self,
        trigger: TriggerType,
        value: Decimal,
        threshold: Decimal,
        message: str,
    ) -> None:
        """Trip the circuit breaker."""
        self.state = CircuitBreakerState.TRIPPED
        self.trip_event = TripEvent(
            trigger=trigger,
            value=value,
            threshold=threshold,
            timestamp=datetime.now(),
            message=message,
        )
        self.trip_history.append(self.trip_event)

    def record_trade_outcome(self, is_win: bool) -> None:
        """Record a trade outcome for loss rate tracking.

        Args:
            is_win: True if trade was profitable, False otherwise
        """
        self.trade_outcomes.append(is_win)

        if is_win:
            self.consecutive_losses = 0
        else:
            self.consecutive_losses += 1

    def reset(self) -> None:
        """Manual reset after trip.

        Clears the trip event and resets state to ACTIVE.
        Does NOT clear trade history or consecutive loss count.
        """
        self.state = CircuitBreakerState.ACTIVE
        self.trip_event = None

    def reset_full(self) -> None:
        """Full reset including trade history.

        Clears all state including trade outcomes and consecutive losses.
        Use when starting fresh or after significant portfolio changes.
        """
        self.reset()
        self.trade_outcomes.clear()
        self.consecutive_losses = 0

    def get_status(self) -> dict[str, Any]:
        """Get current circuit breaker status for monitoring.

        Returns:
            Dictionary with current state, metrics, and trip info
        """
        total_trades = len(self.trade_outcomes)
        losses = sum(1 for outcome in self.trade_outcomes if not outcome)
        loss_rate = (
            Decimal(losses) / Decimal(total_trades) if total_trades > 0 else Decimal(0)
        )

        return {
            "state": self.state.value,
            "is_tripped": self.is_tripped,
            "trip_event": self.trip_event.to_dict() if self.trip_event else None,
            "metrics": {
                "consecutive_losses": self.consecutive_losses,
                "total_trades_tracked": total_trades,
                "loss_rate": str(loss_rate),
                "losses_in_window": losses,
            },
            "config": {
                "max_drawdown": str(self.config.max_drawdown),
                "max_consecutive_losses": self.config.max_consecutive_losses,
                "max_loss_rate": str(self.config.max_loss_rate),
                "loss_rate_window": self.config.loss_rate_window,
                "max_total_exposure": str(self.config.max_total_exposure),
                "volatility_threshold": str(self.config.volatility_threshold),
            },
            "trip_count": len(self.trip_history),
        }
