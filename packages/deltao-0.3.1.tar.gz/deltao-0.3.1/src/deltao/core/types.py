"""Trading types and data structures.

Based on IMPLEMENTATION_CORE.md lines 95-158, 479-494.
"""

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum


class Side(Enum):
    """Order side."""

    BUY = "buy"
    SELL = "sell"


@dataclass
class OrderRequest:
    """Order request to connector."""

    side: Side
    amount: Decimal
    slippage_tolerance: Decimal = Decimal("0.01")  # 1% default
    hotkey: str | None = None


@dataclass
class OrderResult:
    """Result of order execution."""

    success: bool
    message: str
    tx_hash: str | None = None
    block_number: int | None = None


@dataclass
class LiquidityPosition:
    """Concentrated liquidity position (Uniswap v3 style).

    A position provides liquidity within a price range [tick_low, tick_high].

    Based on IMPLEMENTATION_CORE.md lines 95-158.
    """

    position_id: int
    netuid: int
    tick_low: int  # Lower bound tick
    tick_high: int  # Upper bound tick
    liquidity: int  # Liquidity amount (L)
    fees_tao: Decimal  # Accumulated TAO fees
    fees_alpha: Decimal  # Accumulated Alpha fees

    @property
    def price_low(self) -> Decimal:
        """Lower bound price.

        Requires tick_math module to compute.
        """
        from deltao.utils.tick_math import tick_to_price

        return tick_to_price(self.tick_low)

    @property
    def price_high(self) -> Decimal:
        """Upper bound price.

        Requires tick_math module to compute.
        """
        from deltao.utils.tick_math import tick_to_price

        return tick_to_price(self.tick_high)

    def is_in_range(self, current_price: Decimal) -> bool:
        """Check if position is within active range."""
        return self.price_low <= current_price <= self.price_high

    def to_token_amounts(self, current_price: Decimal) -> tuple[Decimal, Decimal]:
        """Calculate TAO and Alpha amounts for this position.

        Uniswap v3 formulas:
        - If price < price_low: 100% TAO, 0% Alpha
        - If price > price_high: 0% TAO, 100% Alpha
        - If price in range: Mix of both

        Returns:
            tuple[Decimal, Decimal]: (tao_amount, alpha_amount)
        """
        sqrt_price = current_price.sqrt()
        sqrt_price_low = self.price_low.sqrt()
        sqrt_price_high = self.price_high.sqrt()

        liquidity_decimal = Decimal(self.liquidity)

        if current_price < self.price_low:
            # All TAO
            tao_amount = liquidity_decimal * (1 / sqrt_price_low - 1 / sqrt_price_high)
            alpha_amount = Decimal(0)

        elif current_price > self.price_high:
            # All Alpha
            tao_amount = Decimal(0)
            alpha_amount = liquidity_decimal * (sqrt_price_high - sqrt_price_low)

        else:
            # Mixed
            tao_amount = liquidity_decimal * (1 / sqrt_price - 1 / sqrt_price_high)
            alpha_amount = liquidity_decimal * (sqrt_price - sqrt_price_low)

        return (tao_amount, alpha_amount)
