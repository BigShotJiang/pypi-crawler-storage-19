"""Core event processor for trading."""

import logging
from dataclasses import dataclass, field
from datetime import datetime
from time import perf_counter
from typing import Protocol

from deltao.connector.base import Connector
from deltao.core.clock import Clock
from deltao.core.event import (
    AccountEvent,
    Event,
    MarketEvent,
    ShutdownEvent,
    TradingStateUpdate,
)
from deltao.core.state import EngineState
from deltao.core.types import OrderRequest, OrderResult

logger = logging.getLogger(__name__)


class AlgoStrategy(Protocol):
    """Strategy interface for generating orders.

    Strategies will be implemented in deltao.strategy module (Phase 2).
    """

    def generate_orders(
        self, state: EngineState
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Generate orders based on current state.

        Returns:
            tuple: (orders_to_cancel, orders_to_open)
        """
        ...


class RiskManager(Protocol):
    """Risk manager interface for order validation."""

    def check(
        self, state: EngineState, orders: list[OrderRequest]
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Check orders against risk rules.

        Returns:
            tuple: (approved_orders, denied_orders)
        """
        ...


@dataclass
class Audit:
    """Audit trail of what happened during event processing."""

    event: Event
    orders_generated: list[OrderRequest]
    orders_approved: list[OrderRequest]
    orders_denied: list[OrderRequest]
    order_results: list[OrderResult]
    state_changes: dict[str, str]
    timestamp: datetime
    state_before: dict[str, str]
    state_after: dict[str, str]
    errors: list[str]
    duration_ms: float


@dataclass
class Engine:
    """Central event processor for trading.

    Generic over Clock, State, Strategy, Risk, Connector.
    """

    clock: Clock
    state: EngineState
    strategy: AlgoStrategy
    risk: RiskManager
    connector: Connector

    # Metadata
    sequence: int = 0
    start_time: datetime = field(default_factory=lambda: datetime.now())

    async def process(self, event: Event) -> Audit:
        """Process event through the engine.

        Flow:
        1. Update clock
        2. Update state from event
        3. Generate orders (if trading enabled)
        4. Risk check
        5. Send approved orders
        6. Return audit trail

        Args:
            event: Event to process

        Returns:
            Audit: Audit trail of actions taken
        """
        started = perf_counter()

        # 1. Update clock
        self.clock.update(event.timestamp)

        # 2. Update state from event
        state_before = self._snapshot_state()
        self._update_state(event)

        # 3. Generate orders if trading enabled
        orders_generated: list[OrderRequest] = []
        orders_approved: list[OrderRequest] = []
        orders_denied: list[OrderRequest] = []
        order_results: list[OrderResult] = []
        errors: list[str] = []

        if self.state.trading_enabled and not isinstance(event, ShutdownEvent):
            _cancels, opens = self.strategy.generate_orders(self.state)
            orders_generated = list(opens)

            # 4. Risk check
            orders_approved, orders_denied = self.risk.check(
                self.state, orders_generated
            )

            # 5. Send approved orders
            executed_orders: list[OrderRequest] = []
            for order in orders_approved:
                result = await self.connector.place_order(order)
                order_results.append(result)
                if result.success:
                    executed_orders.append(order)
                else:
                    orders_denied.append(order)
                    logger.warning(
                        "Order execution failed: %s (side=%s, amount=%s)",
                        result.message,
                        order.side.value,
                        order.amount,
                    )
                    errors.append(result.message)
            orders_approved = executed_orders

        # 6. Return audit
        self.sequence += 1
        state_after = self._snapshot_state()
        duration_ms = (perf_counter() - started) * 1000
        return Audit(
            event=event,
            orders_generated=orders_generated,
            orders_approved=orders_approved,
            orders_denied=orders_denied,
            order_results=order_results,
            state_changes={},
            timestamp=self.clock.now(),
            state_before=state_before,
            state_after=state_after,
            errors=errors,
            duration_ms=duration_ms,
        )

    def _update_state(self, event: Event) -> None:
        """Update engine state from event.

        Args:
            event: Event to update state from
        """
        if isinstance(event, MarketEvent):
            self.state.update_from_market_event(event)
        elif isinstance(event, AccountEvent):
            self.state.update_from_account_event(event)
        elif isinstance(event, TradingStateUpdate):
            self.state.update_from_trading_state(event)

    def _snapshot_state(self) -> dict[str, str]:
        """Create a lightweight snapshot of current state for auditing."""
        return {
            "trading_enabled": str(self.state.trading_enabled),
            "tao_balance": str(self.state.tao_balance),
            "alpha_balance": str(self.state.alpha_balance),
            "current_price": str(self.state.current_price),
            "current_block": str(self.state.current_block),
            "positions": str(len(self.state.positions)),
            "price_history_len": str(len(self.state.price_history)),
        }
