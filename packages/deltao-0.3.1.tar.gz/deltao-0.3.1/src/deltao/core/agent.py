"""Strategy Agent - wrapper for Engine with lifecycle management.

A StrategyAgent encapsulates an Engine instance with:
- Lifecycle management (start, stop, pause, resume)
- Performance tracking
- Capital allocation
- Isolated state management
"""

import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Any

from deltao.connector.base import Connector
from deltao.core.clock import Clock
from deltao.core.engine import AlgoStrategy, Audit, Engine, RiskManager
from deltao.core.event import Event, ShutdownEvent, TradingStateUpdate
from deltao.core.state import EngineState


class AgentStatus(Enum):
    """Agent lifecycle status."""

    CREATED = "created"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class AgentPerformance:
    """Performance metrics for an agent."""

    # PnL
    realized_pnl: Decimal = Decimal(0)
    unrealized_pnl: Decimal = Decimal(0)
    total_pnl: Decimal = Decimal(0)

    # Risk metrics
    max_drawdown: Decimal = Decimal(0)
    sharpe_ratio: Decimal | None = None
    win_rate: Decimal | None = None

    # Activity
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0

    # Timestamps
    started_at: datetime | None = None
    last_trade_at: datetime | None = None
    last_updated_at: datetime | None = None

    # History for calculations
    pnl_history: list[Decimal] = field(default_factory=list)
    peak_value: Decimal = Decimal(0)


@dataclass
class AgentConfig:
    """Configuration for a strategy agent."""

    # Identity
    agent_id: str
    name: str
    description: str = ""

    # Target
    netuid: int = 0  # 0 = all subnets

    # Capital allocation
    max_capital: Decimal = Decimal(0)  # Max TAO allocation
    capital_fraction: Decimal = Decimal("0.1")  # 10% of portfolio

    # Risk limits (agent-specific)
    max_position_size: Decimal = Decimal(0)
    max_daily_loss: Decimal = Decimal(0)
    max_drawdown: Decimal = Decimal("0.1")  # 10%

    # Execution
    enabled: bool = True
    priority: int = 1  # Higher = executes first


@dataclass
class StrategyAgent:
    """
    Wrapper for Engine with lifecycle and performance management.

    Each agent is an independent trading unit with:
    - Its own Engine instance
    - Isolated state
    - Performance tracking
    - Capital allocation
    """

    config: AgentConfig
    engine: Engine
    clock: Clock
    connector: Connector

    # Lifecycle
    status: AgentStatus = AgentStatus.CREATED
    _task: asyncio.Task[None] | None = None

    # Performance
    performance: AgentPerformance = field(default_factory=AgentPerformance)

    # Audit trail
    audits: list[Audit] = field(default_factory=list)

    # Internal
    _initial_capital: Decimal = Decimal(0)

    def __post_init__(self) -> None:
        """Initialize agent state."""
        self._initial_capital = self.engine.state.tao_balance

    @property
    def agent_id(self) -> str:
        """Get agent ID."""
        return self.config.agent_id

    @property
    def is_active(self) -> bool:
        """Check if agent is actively trading."""
        return self.status == AgentStatus.RUNNING

    @property
    def allocated_capital(self) -> Decimal:
        """Get current allocated capital."""
        return self.engine.state.tao_balance + self.engine.state.alpha_balance

    async def start(self) -> None:
        """Start the agent."""
        if self.status == AgentStatus.RUNNING:
            return

        self.status = AgentStatus.RUNNING
        self.performance.started_at = datetime.now()

        # Enable trading
        await self.engine.process(
            TradingStateUpdate(
                enabled=True,
                reason="Agent started",
                timestamp=datetime.now(),
            )
        )

    async def stop(self) -> None:
        """Stop the agent gracefully."""
        if self.status == AgentStatus.STOPPED:
            return

        # Disable trading first
        await self.engine.process(
            TradingStateUpdate(
                enabled=False,
                reason="Agent stopping",
                timestamp=datetime.now(),
            )
        )

        # Send shutdown event
        await self.engine.process(
            ShutdownEvent(
                reason="Agent stopped",
                timestamp=datetime.now(),
            )
        )

        self.status = AgentStatus.STOPPED

        # Cancel background task if running
        if self._task and not self._task.done():
            self._task.cancel()

    async def pause(self) -> None:
        """Pause trading (keeps state, stops new orders)."""
        if self.status != AgentStatus.RUNNING:
            return

        await self.engine.process(
            TradingStateUpdate(
                enabled=False,
                reason="Agent paused",
                timestamp=datetime.now(),
            )
        )
        self.status = AgentStatus.PAUSED

    async def resume(self) -> None:
        """Resume trading after pause."""
        if self.status != AgentStatus.PAUSED:
            return

        await self.engine.process(
            TradingStateUpdate(
                enabled=True,
                reason="Agent resumed",
                timestamp=datetime.now(),
            )
        )
        self.status = AgentStatus.RUNNING

    async def process_event(self, event: Event) -> Audit:
        """
        Process an event through the agent's engine.

        Also updates performance metrics.
        """
        audit = await self.engine.process(event)
        self.audits.append(audit)

        # Update performance
        self._update_performance(audit)

        return audit

    def _update_performance(self, audit: Audit) -> None:
        """Update performance metrics from audit."""
        self.performance.last_updated_at = datetime.now()

        # Count trades
        if audit.orders_approved:
            self.performance.total_trades += len(audit.orders_approved)
            self.performance.last_trade_at = datetime.now()

        # Calculate PnL
        current_value = self.allocated_capital
        self.performance.unrealized_pnl = current_value - self._initial_capital
        self.performance.total_pnl = (
            self.performance.realized_pnl + self.performance.unrealized_pnl
        )

        # Track for drawdown
        if current_value > self.performance.peak_value:
            self.performance.peak_value = current_value

        if self.performance.peak_value > 0:
            drawdown = (
                self.performance.peak_value - current_value
            ) / self.performance.peak_value
            if drawdown > self.performance.max_drawdown:
                self.performance.max_drawdown = drawdown

    def get_state_snapshot(self) -> dict[str, Any]:
        """Get current state snapshot for monitoring."""
        return {
            "agent_id": self.agent_id,
            "name": self.config.name,
            "status": self.status.value,
            "netuid": self.config.netuid,
            "capital": {
                "tao": str(self.engine.state.tao_balance),
                "alpha": str(self.engine.state.alpha_balance),
                "total": str(self.allocated_capital),
            },
            "performance": {
                "total_pnl": str(self.performance.total_pnl),
                "max_drawdown": str(self.performance.max_drawdown),
                "total_trades": self.performance.total_trades,
            },
            "trading_enabled": self.engine.state.trading_enabled,
            "last_updated": (
                self.performance.last_updated_at.isoformat()
                if self.performance.last_updated_at
                else None
            ),
        }


def create_agent(
    agent_id: str,
    name: str,
    strategy: AlgoStrategy,
    risk: RiskManager,
    connector: Connector,
    clock: Clock,
    initial_capital: Decimal = Decimal(0),
    netuid: int = 0,
    **config_kwargs: Any,
) -> StrategyAgent:
    """
    Factory function to create a StrategyAgent.

    Args:
        agent_id: Unique identifier
        name: Human-readable name
        strategy: Trading strategy
        risk: Risk manager
        connector: Chain connector
        clock: Time source
        initial_capital: Initial TAO allocation
        netuid: Target subnet (0 = all)
        **config_kwargs: Additional AgentConfig parameters

    Returns:
        Configured StrategyAgent
    """
    config = AgentConfig(
        agent_id=agent_id,
        name=name,
        netuid=netuid,
        max_capital=initial_capital,
        **config_kwargs,
    )

    state = EngineState(tao_balance=initial_capital)

    engine = Engine(
        clock=clock,
        state=state,
        strategy=strategy,
        risk=risk,
        connector=connector,
    )

    return StrategyAgent(
        config=config,
        engine=engine,
        clock=clock,
        connector=connector,
    )
