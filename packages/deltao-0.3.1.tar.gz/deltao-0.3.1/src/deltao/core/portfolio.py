"""Portfolio Manager - orchestrates multiple strategy agents.

The PortfolioManager is the top-level coordinator that:
- Manages multiple StrategyAgent instances
- Distributes capital across agents
- Aggregates risk across the portfolio
- Provides unified event distribution
- Handles lifecycle of all agents
"""

import asyncio
import contextlib
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Any

from deltao.connector.base import Connector
from deltao.core.agent import AgentStatus, StrategyAgent, create_agent
from deltao.core.circuit_breaker import (
    CircuitBreaker,
    CircuitBreakerConfig,
    TripEvent,
)
from deltao.core.clock import Clock
from deltao.core.engine import AlgoStrategy, Audit, RiskManager
from deltao.core.event import Event, MarketEvent, ShutdownEvent
from deltao.strategy.base import calculate_volatility


class AllocationStrategy(Enum):
    """Capital allocation strategy."""

    EQUAL = "equal"  # Equal split between all agents
    FIXED = "fixed"  # Use agent.config.capital_fraction
    PERFORMANCE = "performance"  # Allocate more to better performers
    RISK_PARITY = "risk_parity"  # Allocate based on inverse volatility


@dataclass
class PortfolioConfig:
    """Portfolio-level configuration."""

    # Identity
    portfolio_id: str
    name: str = "Default Portfolio"

    # Capital
    total_capital: Decimal = Decimal(0)
    reserve_fraction: Decimal = Decimal("0.1")  # Keep 10% as reserve

    # Allocation
    allocation_strategy: AllocationStrategy = AllocationStrategy.FIXED
    rebalance_interval: int = 3600  # seconds

    # Risk limits (portfolio-wide)
    max_total_exposure: Decimal = Decimal("0.9")  # 90% of capital
    max_correlation: Decimal = Decimal("0.7")  # Max correlation between agents
    max_portfolio_drawdown: Decimal = Decimal("0.15")  # 15%

    # Execution
    max_concurrent_agents: int = 10
    event_timeout: float = 30.0  # seconds

    # Circuit breaker settings
    # Note: Uses max_portfolio_drawdown and max_total_exposure from above
    circuit_breaker_enabled: bool = True
    cb_max_consecutive_losses: int = 5
    cb_max_loss_rate: Decimal = Decimal("0.7")  # 70%
    cb_loss_rate_window: int = 20  # trades
    cb_volatility_threshold: Decimal = Decimal("0.1")  # 10% std dev
    cb_volatility_period: int = 20  # blocks


@dataclass
class PortfolioMetrics:
    """Aggregated portfolio metrics."""

    # Capital
    total_capital: Decimal = Decimal(0)
    allocated_capital: Decimal = Decimal(0)
    reserve_capital: Decimal = Decimal(0)

    # PnL
    total_pnl: Decimal = Decimal(0)
    realized_pnl: Decimal = Decimal(0)
    unrealized_pnl: Decimal = Decimal(0)

    # Risk
    peak_value: Decimal = Decimal(0)  # Highest portfolio value seen
    max_drawdown: Decimal = Decimal(0)  # Max drawdown from peak
    current_drawdown: Decimal = Decimal(0)  # Current drawdown from peak

    # Activity
    total_trades: int = 0
    active_agents: int = 0

    # Per-agent breakdown
    agent_pnl: dict[str, Decimal] = field(default_factory=dict)

    # Timestamps
    last_updated: datetime | None = None


@dataclass
class PortfolioManager:
    """
    Orchestrator for multiple strategy agents.

    Usage:
        portfolio = PortfolioManager(config, clock, connector)
        portfolio.add_agent("momentum", MomentumStrategy(), risk_manager)
        portfolio.add_agent("mean_rev", MeanReversionStrategy(), risk_manager)
        await portfolio.start()
    """

    config: PortfolioConfig
    clock: Clock
    connector: Connector

    # Agents
    agents: dict[str, StrategyAgent] = field(default_factory=dict)
    _agent_order: list[str] = field(default_factory=list)  # Priority order

    # Metrics
    metrics: PortfolioMetrics = field(default_factory=PortfolioMetrics)

    # State
    is_running: bool = False
    _event_queue: asyncio.Queue[Event] = field(default_factory=asyncio.Queue)
    _main_task: asyncio.Task[None] | None = None

    # Callbacks
    on_agent_error: Callable[[str, Exception], None] | None = None
    on_rebalance: Callable[[dict[str, Decimal]], None] | None = None
    on_circuit_breaker_trip: Callable[[TripEvent], None] | None = None

    # Circuit breaker
    circuit_breaker: CircuitBreaker | None = None

    def __post_init__(self) -> None:
        """Initialize portfolio state."""
        self.metrics.total_capital = self.config.total_capital
        self.metrics.reserve_capital = (
            self.config.total_capital * self.config.reserve_fraction
        )
        self.metrics.peak_value = self.config.total_capital  # Start at initial capital

        # Initialize circuit breaker if enabled
        if self.config.circuit_breaker_enabled and self.circuit_breaker is None:
            cb_config = CircuitBreakerConfig(
                max_drawdown=self.config.max_portfolio_drawdown,
                max_consecutive_losses=self.config.cb_max_consecutive_losses,
                max_loss_rate=self.config.cb_max_loss_rate,
                loss_rate_window=self.config.cb_loss_rate_window,
                max_total_exposure=self.config.max_total_exposure,
                volatility_threshold=self.config.cb_volatility_threshold,
                volatility_period=self.config.cb_volatility_period,
            )
            self.circuit_breaker = CircuitBreaker(config=cb_config)

    # =========================================================================
    # Agent Management
    # =========================================================================

    def add_agent(
        self,
        agent_id: str,
        name: str,
        strategy: AlgoStrategy,
        risk: RiskManager,
        netuid: int = 0,
        capital_fraction: Decimal = Decimal("0.1"),
        **kwargs: Any,
    ) -> StrategyAgent:
        """
        Add a new strategy agent to the portfolio.

        Args:
            agent_id: Unique identifier
            name: Human-readable name
            strategy: Trading strategy
            risk: Risk manager
            netuid: Target subnet
            capital_fraction: Fraction of portfolio capital
            **kwargs: Additional AgentConfig params

        Returns:
            The created StrategyAgent
        """
        if agent_id in self.agents:
            raise ValueError(f"Agent {agent_id} already exists")

        # Calculate initial capital
        available = self.config.total_capital * (1 - self.config.reserve_fraction)
        initial_capital = available * capital_fraction

        agent = create_agent(
            agent_id=agent_id,
            name=name,
            strategy=strategy,
            risk=risk,
            connector=self.connector,
            clock=self.clock,
            initial_capital=initial_capital,
            netuid=netuid,
            capital_fraction=capital_fraction,
            **kwargs,
        )

        self.agents[agent_id] = agent
        self._agent_order.append(agent_id)
        self._sort_agents_by_priority()

        return agent

    def remove_agent(self, agent_id: str) -> None:
        """Remove an agent from the portfolio."""
        if agent_id not in self.agents:
            raise ValueError(f"Agent {agent_id} not found")

        agent = self.agents[agent_id]
        if agent.status == AgentStatus.RUNNING:
            raise ValueError(f"Cannot remove running agent {agent_id}. Stop it first.")

        del self.agents[agent_id]
        self._agent_order.remove(agent_id)

    def get_agent(self, agent_id: str) -> StrategyAgent | None:
        """Get an agent by ID."""
        return self.agents.get(agent_id)

    def list_agents(self) -> list[dict[str, Any]]:
        """List all agents with their status."""
        return [agent.get_state_snapshot() for agent in self.agents.values()]

    def _sort_agents_by_priority(self) -> None:
        """Sort agents by priority (higher first)."""
        self._agent_order.sort(
            key=lambda x: self.agents[x].config.priority, reverse=True
        )

    # =========================================================================
    # Lifecycle Management
    # =========================================================================

    async def start(self) -> None:
        """Start the portfolio and all enabled agents."""
        if self.is_running:
            return

        self.is_running = True

        # Start all enabled agents
        for agent_id in self._agent_order:
            agent = self.agents[agent_id]
            if agent.config.enabled:
                await agent.start()

        # Start main event loop
        self._main_task = asyncio.create_task(self._run_loop())

    async def stop(self) -> None:
        """Stop the portfolio and all agents gracefully."""
        if not self.is_running:
            return

        self.is_running = False

        # Stop all agents
        stop_tasks = [agent.stop() for agent in self.agents.values()]
        await asyncio.gather(*stop_tasks, return_exceptions=True)

        # Cancel main task
        if self._main_task and not self._main_task.done():
            self._main_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._main_task

    async def start_agent(self, agent_id: str) -> None:
        """Start a specific agent."""
        agent = self.agents.get(agent_id)
        if agent:
            await agent.start()

    async def stop_agent(self, agent_id: str) -> None:
        """Stop a specific agent."""
        agent = self.agents.get(agent_id)
        if agent:
            await agent.stop()

    async def pause_agent(self, agent_id: str) -> None:
        """Pause a specific agent."""
        agent = self.agents.get(agent_id)
        if agent:
            await agent.pause()

    async def resume_agent(self, agent_id: str) -> None:
        """Resume a specific agent."""
        agent = self.agents.get(agent_id)
        if agent:
            await agent.resume()

    # =========================================================================
    # Event Distribution
    # =========================================================================

    async def broadcast_event(self, event: Event) -> dict[str, Audit]:
        """
        Broadcast an event to all active agents.

        Returns dict of agent_id -> Audit
        """
        # Check if circuit breaker is tripped - no processing when tripped
        if self.circuit_breaker and self.circuit_breaker.is_tripped:
            return {}

        # Capture PnL before processing for win/loss tracking
        pnl_before = self.metrics.total_pnl

        audits: dict[str, Audit] = {}

        for agent_id in self._agent_order:
            agent = self.agents[agent_id]

            if not agent.is_active:
                continue

            # Filter events by netuid if applicable
            if (
                isinstance(event, MarketEvent)
                and agent.config.netuid != 0
                and event.netuid != agent.config.netuid
            ):
                continue

            try:
                audit = await asyncio.wait_for(
                    agent.process_event(event),
                    timeout=self.config.event_timeout,
                )
                audits[agent_id] = audit

            except asyncio.TimeoutError:
                if self.on_agent_error:
                    self.on_agent_error(
                        agent_id, TimeoutError("Event processing timeout")
                    )
                agent.status = AgentStatus.ERROR

            except Exception as e:
                if self.on_agent_error:
                    self.on_agent_error(agent_id, e)
                agent.status = AgentStatus.ERROR

        # Update metrics after processing
        self._update_metrics()

        # Record trade outcomes and check circuit breaker
        if self.circuit_breaker:
            # Record trade outcome based on actual PnL change (not execution success)
            # Only record if there were any executed trades
            total_trades = sum(len(a.orders_approved) for a in audits.values())
            if total_trades > 0:
                pnl_change = self.metrics.total_pnl - pnl_before
                is_win = pnl_change >= 0
                self.circuit_breaker.record_trade_outcome(is_win)

            # Check circuit breaker triggers
            volatility = self._calculate_portfolio_volatility()
            if not self.circuit_breaker.check(self.metrics, volatility):
                # Circuit breaker tripped - pause all agents
                await self._pause_all_agents()

                # Notify via callback
                if self.on_circuit_breaker_trip and self.circuit_breaker.trip_event:
                    self.on_circuit_breaker_trip(self.circuit_breaker.trip_event)

        return audits

    async def submit_event(self, event: Event) -> None:
        """Submit an event to the queue for processing."""
        await self._event_queue.put(event)

    async def _run_loop(self) -> None:
        """Main event processing loop."""
        while self.is_running:
            try:
                # Wait for event with timeout
                event = await asyncio.wait_for(
                    self._event_queue.get(),
                    timeout=1.0,
                )

                # Broadcast to all agents
                await self.broadcast_event(event)

                # Check for shutdown
                if isinstance(event, ShutdownEvent):
                    await self.stop()
                    break

            except asyncio.TimeoutError:
                # No event, continue
                continue

            except asyncio.CancelledError:
                break

            except Exception:
                # Log error but continue
                continue

    # =========================================================================
    # Capital Allocation
    # =========================================================================

    async def rebalance(self) -> dict[str, Decimal]:
        """
        Rebalance capital across agents.

        Returns new allocations per agent.
        """
        allocations: dict[str, Decimal] = {}
        available = self.config.total_capital * (1 - self.config.reserve_fraction)

        if self.config.allocation_strategy == AllocationStrategy.EQUAL:
            allocations = self._allocate_equal(available)

        elif self.config.allocation_strategy == AllocationStrategy.FIXED:
            allocations = self._allocate_fixed(available)

        elif self.config.allocation_strategy == AllocationStrategy.PERFORMANCE:
            allocations = self._allocate_by_performance(available)

        elif self.config.allocation_strategy == AllocationStrategy.RISK_PARITY:
            allocations = self._allocate_risk_parity(available)

        # Apply allocations
        for agent_id, amount in allocations.items():
            agent = self.agents[agent_id]
            agent.engine.state.tao_balance = amount

        if self.on_rebalance:
            self.on_rebalance(allocations)

        return allocations

    def _allocate_equal(self, available: Decimal) -> dict[str, Decimal]:
        """Equal allocation to all agents."""
        active = [a for a in self.agents.values() if a.config.enabled]
        if not active:
            return {}

        per_agent = available / len(active)
        return {a.agent_id: per_agent for a in active}

    def _allocate_fixed(self, available: Decimal) -> dict[str, Decimal]:
        """Fixed allocation based on config.capital_fraction."""
        allocations = {}
        for agent in self.agents.values():
            if agent.config.enabled:
                allocations[agent.agent_id] = available * agent.config.capital_fraction
        return allocations

    def _allocate_by_performance(self, available: Decimal) -> dict[str, Decimal]:
        """Allocate more to better performing agents."""
        active = [a for a in self.agents.values() if a.config.enabled]
        if not active:
            return {}

        # Calculate performance scores (using total PnL)
        scores = {}
        for agent in active:
            # Shift PnL to positive range and add 1 to avoid zero
            pnl = agent.performance.total_pnl
            scores[agent.agent_id] = max(Decimal("0.01"), pnl + Decimal("1"))

        total_score = sum(scores.values())

        allocations = {}
        for agent_id, score in scores.items():
            weight = score / total_score
            allocations[agent_id] = available * weight

        return allocations

    def _allocate_risk_parity(self, available: Decimal) -> dict[str, Decimal]:
        """Allocate based on inverse volatility (risk parity)."""
        active = [a for a in self.agents.values() if a.config.enabled]
        if not active:
            return {}

        # Use inverse of max_drawdown as risk measure
        inv_risks = {}
        for agent in active:
            drawdown = agent.performance.max_drawdown
            # Avoid division by zero
            inv_risk = Decimal(1) / max(drawdown, Decimal("0.01"))
            inv_risks[agent.agent_id] = inv_risk

        total_inv_risk = sum(inv_risks.values())

        allocations = {}
        for agent_id, inv_risk in inv_risks.items():
            weight = inv_risk / total_inv_risk
            allocations[agent_id] = available * weight

        return allocations

    # =========================================================================
    # Metrics & Monitoring
    # =========================================================================

    def _update_metrics(self) -> None:
        """Update aggregated portfolio metrics."""
        self.metrics.total_pnl = Decimal(0)
        self.metrics.realized_pnl = Decimal(0)
        self.metrics.unrealized_pnl = Decimal(0)
        self.metrics.total_trades = 0
        self.metrics.active_agents = 0
        self.metrics.allocated_capital = Decimal(0)
        self.metrics.agent_pnl = {}

        for agent in self.agents.values():
            perf = agent.performance

            self.metrics.total_pnl += perf.total_pnl
            self.metrics.realized_pnl += perf.realized_pnl
            self.metrics.unrealized_pnl += perf.unrealized_pnl
            self.metrics.total_trades += perf.total_trades
            self.metrics.allocated_capital += agent.allocated_capital
            self.metrics.agent_pnl[agent.agent_id] = perf.total_pnl

            if agent.is_active:
                self.metrics.active_agents += 1

        # Calculate portfolio-level drawdown (not per-agent max)
        current_value = self.metrics.total_capital + self.metrics.total_pnl

        # Update peak if we have a new high
        if current_value > self.metrics.peak_value:
            self.metrics.peak_value = current_value

        # Calculate drawdown from peak
        if self.metrics.peak_value > 0:
            self.metrics.current_drawdown = (
                self.metrics.peak_value - current_value
            ) / self.metrics.peak_value

            # Update max drawdown if current is worse
            if self.metrics.current_drawdown > self.metrics.max_drawdown:
                self.metrics.max_drawdown = self.metrics.current_drawdown

        self.metrics.last_updated = datetime.now()

    def get_portfolio_snapshot(self) -> dict[str, Any]:
        """Get full portfolio state snapshot."""
        self._update_metrics()

        return {
            "portfolio_id": self.config.portfolio_id,
            "name": self.config.name,
            "is_running": self.is_running,
            "metrics": {
                "total_capital": str(self.metrics.total_capital),
                "allocated_capital": str(self.metrics.allocated_capital),
                "reserve_capital": str(self.metrics.reserve_capital),
                "total_pnl": str(self.metrics.total_pnl),
                "max_drawdown": str(self.metrics.max_drawdown),
                "total_trades": self.metrics.total_trades,
                "active_agents": self.metrics.active_agents,
            },
            "agents": self.list_agents(),
            "circuit_breaker": self.get_circuit_breaker_status(),
            "last_updated": (
                self.metrics.last_updated.isoformat()
                if self.metrics.last_updated
                else None
            ),
        }

    # =========================================================================
    # Risk Management
    # =========================================================================

    async def check_portfolio_risk(self) -> bool:
        """
        Check portfolio-wide risk limits using circuit breaker.

        Returns True if within limits, False if breached.
        If breached and circuit breaker is enabled, all agents are paused.

        Note: This method delegates to the circuit breaker when enabled.
        For manual checks without circuit breaker, use the metrics directly.
        """
        self._update_metrics()

        if self.metrics.total_capital == 0:
            raise ValueError(
                "Portfolio total_capital must be greater than zero for risk checks"
            )

        # Use circuit breaker if enabled
        if self.circuit_breaker:
            volatility = self._calculate_portfolio_volatility()
            if not self.circuit_breaker.check(self.metrics, volatility):
                await self._pause_all_agents()
                if self.on_circuit_breaker_trip and self.circuit_breaker.trip_event:
                    self.on_circuit_breaker_trip(self.circuit_breaker.trip_event)
                return False
            return True

        # Fallback: manual checks if circuit breaker disabled
        exposure = self.metrics.allocated_capital / self.metrics.total_capital
        if exposure > self.config.max_total_exposure:
            return False

        if self.metrics.max_drawdown > self.config.max_portfolio_drawdown:
            await self._pause_all_agents()
            return False

        return True

    # =========================================================================
    # Circuit Breaker Management
    # =========================================================================

    async def _pause_all_agents(self) -> None:
        """Pause all active agents."""
        for agent in self.agents.values():
            if agent.is_active:
                await agent.pause()

    async def _resume_all_agents(self) -> None:
        """Resume all paused agents."""
        for agent in self.agents.values():
            if agent.status == AgentStatus.PAUSED:
                await agent.resume()

    def _calculate_portfolio_volatility(self) -> Decimal | None:
        """Calculate portfolio-wide volatility from agent price histories.

        Uses the maximum volatility across all active agents. This is a
        conservative approach - if any market shows high volatility, the
        circuit breaker will trigger.

        Returns:
            Maximum volatility across agents, or None if insufficient data
        """
        if not self.circuit_breaker:
            return None

        period = self.circuit_breaker.config.volatility_period
        max_volatility: Decimal | None = None

        for agent in self.agents.values():
            if agent.is_active and len(agent.engine.state.price_history) >= period:
                vol = calculate_volatility(agent.engine.state.price_history, period)
                if vol is not None and (max_volatility is None or vol > max_volatility):
                    max_volatility = vol

        return max_volatility

    async def reset_circuit_breaker(self) -> bool:
        """Manual reset after circuit breaker trip.

        Clears the trip event and resumes all paused agents.

        Returns:
            True if reset successful, False if no circuit breaker configured
        """
        if not self.circuit_breaker:
            return False

        self.circuit_breaker.reset()
        await self._resume_all_agents()
        return True

    def get_circuit_breaker_status(self) -> dict[str, Any] | None:
        """Get current circuit breaker status.

        Returns:
            Status dictionary or None if circuit breaker not configured
        """
        if not self.circuit_breaker:
            return None
        return self.circuit_breaker.get_status()
