"""Time source abstraction for live and historical trading.

Based on IMPLEMENTATION_CORE.md lines 284-331.
"""

from abc import ABC, abstractmethod
from datetime import datetime


class Clock(ABC):
    """Time source abstraction.

    Live = real time
    Historical = backtest time
    """

    @abstractmethod
    def now(self) -> datetime:
        """Get current time."""
        pass

    @abstractmethod
    def update(self, timestamp: datetime) -> None:
        """Update clock (for historical mode)."""
        pass


class LiveClock(Clock):
    """Real-time clock for live trading."""

    def now(self) -> datetime:
        """Get current real time."""
        return datetime.now()

    def update(self, timestamp: datetime) -> None:
        """No-op for live clock."""
        pass


class HistoricalClock(Clock):
    """Historical clock for backtesting."""

    def __init__(self, start_time: datetime):
        """Initialize with starting timestamp.

        Args:
            start_time: Initial timestamp for backtest
        """
        self._current_time = start_time

    def now(self) -> datetime:
        """Get current backtest time."""
        return self._current_time

    def update(self, timestamp: datetime) -> None:
        """Advance to new timestamp.

        Args:
            timestamp: New timestamp to advance to

        Raises:
            ValueError: If timestamp is before current time
        """
        if timestamp < self._current_time:
            raise ValueError("Cannot go back in time")
        self._current_time = timestamp
