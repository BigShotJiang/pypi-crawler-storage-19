"""Uniswap v3 tick math for concentrated liquidity.

Based on IMPLEMENTATION_CORE.md lines 22-87.
dTao uses the same tick math as Uniswap v3.
"""

import math
from decimal import Decimal

# Tick range
MIN_TICK = -443636
MAX_TICK = 443636

# Price step per tick (1.0001 = 0.01% per tick)
PRICE_STEP = Decimal("1.0001")

# Price range
MIN_PRICE = PRICE_STEP**MIN_TICK  # ~0.0000000002
MAX_PRICE = PRICE_STEP**MAX_TICK  # ~4,294,886,577


def price_to_tick(price: Decimal) -> int:
    """Convert price to tick index.

    Formula: tick = floor(log(price) / log(1.0001))

    Examples:
        price_to_tick(1.0) = 0
        price_to_tick(1.0001) = 1
        price_to_tick(2.0) = 6931

    Args:
        price: Price to convert

    Returns:
        int: Tick index

    Raises:
        ValueError: If price is not positive or out of range
    """
    if price <= 0:
        raise ValueError("Price must be positive")

    if price < MIN_PRICE or price > MAX_PRICE:
        raise ValueError(f"Price out of range [{MIN_PRICE}, {MAX_PRICE}]")

    # log_1.0001(price) = ln(price) / ln(1.0001)
    tick = math.floor(math.log(float(price)) / math.log(float(PRICE_STEP)))

    return max(MIN_TICK, min(MAX_TICK, tick))


def tick_to_price(tick: int) -> Decimal:
    """Convert tick index to price.

    Formula: price = 1.0001^tick

    Examples:
        tick_to_price(0) = 1.0
        tick_to_price(1) = 1.0001
        tick_to_price(6931) ≈ 2.0

    Args:
        tick: Tick index to convert

    Returns:
        Decimal: Price at tick

    Raises:
        ValueError: If tick is out of range
    """
    if tick < MIN_TICK or tick > MAX_TICK:
        raise ValueError(f"Tick out of range [{MIN_TICK}, {MAX_TICK}]")

    return PRICE_STEP**tick


def tick_to_sqrt_price(tick: int) -> Decimal:
    """Convert tick to sqrt(price).

    Used for Uniswap v3 liquidity calculations.

    Args:
        tick: Tick index to convert

    Returns:
        Decimal: Square root of price at tick

    Raises:
        ValueError: If tick is out of range
    """
    price = tick_to_price(tick)
    return price.sqrt()
