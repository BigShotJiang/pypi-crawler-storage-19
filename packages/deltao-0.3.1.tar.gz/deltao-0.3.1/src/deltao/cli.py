"""Command-line interface for deltao.

Provides commands for:
- info: Show project information
- backtest: Run backtests with strategies
- live: Start live trading (coming soon)
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from decimal import Decimal
from pathlib import Path
from typing import TYPE_CHECKING

from deltao import __version__

if TYPE_CHECKING:
    from deltao.core.engine import AlgoStrategy, RiskManager

logger = logging.getLogger(__name__)


def _setup_logging(verbose: bool = False) -> None:
    """Configure logging based on verbosity."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )


def _cmd_info(_: argparse.Namespace) -> int:
    """Print project info."""
    print("deltao - Bittensor dTao Trading Framework")
    print(f"Version: {__version__}")
    print("Docs   : https://github.com/msulabs/deltao#readme")
    print("Source : https://github.com/msulabs/deltao")
    return 0


def _get_strategy(name: str, **kwargs: Decimal | int | float) -> AlgoStrategy:
    """Get strategy instance by name."""
    from deltao.strategy.directional import MeanReversionStrategy, MomentumStrategy

    strategies: dict[str, type[AlgoStrategy]] = {
        "momentum": MomentumStrategy,
        "mean_reversion": MeanReversionStrategy,
    }

    if name not in strategies:
        raise ValueError(f"Unknown strategy: {name}. Available: {list(strategies)}")

    return strategies[name](**kwargs)


def _get_risk_manager(name: str, **kwargs: Decimal | int | float) -> RiskManager:
    """Get risk manager instance by name."""
    from deltao.strategy.risk import (
        BasicRiskManager,
        NoOpRiskManager,
        PositionLimitRiskManager,
    )

    managers: dict[str, type[RiskManager]] = {
        "basic": BasicRiskManager,
        "position_limit": PositionLimitRiskManager,
        "none": NoOpRiskManager,
    }

    if name not in managers:
        raise ValueError(f"Unknown risk manager: {name}. Available: {list(managers)}")

    return managers[name](**kwargs)


async def _run_backtest(args: argparse.Namespace) -> int:
    """Run backtest with given configuration."""
    from deltao.backtest import BacktestConfig, BacktestingEngine

    _setup_logging(args.verbose)

    # Build config
    config = BacktestConfig(
        netuid=args.netuid,
        start_block=args.start_block,
        end_block=args.end_block,
        initial_tao=Decimal(str(args.initial_tao)),
        initial_alpha=Decimal(str(args.initial_alpha)),
        trade_fee=Decimal(str(args.fee)),
        data_dir=Path(args.data_dir),
    )

    # Get strategy
    strategy_kwargs: dict[str, Decimal | int | float] = {}
    if args.fast_period:
        strategy_kwargs["fast_period"] = args.fast_period
    if args.slow_period:
        strategy_kwargs["slow_period"] = args.slow_period

    strategy = _get_strategy(args.strategy, **strategy_kwargs)

    # Get risk manager
    risk_kwargs: dict[str, Decimal | int | float] = {}
    if args.max_position:
        risk_kwargs["max_position_size"] = Decimal(str(args.max_position))

    risk = _get_risk_manager(args.risk, **risk_kwargs)

    # Run backtest
    logger.info(f"Starting backtest: {args.strategy} strategy")
    logger.info(f"  Blocks: {args.start_block} -> {args.end_block}")
    logger.info(f"  Initial: {args.initial_tao} TAO, {args.initial_alpha} Alpha")

    engine = BacktestingEngine(data_dir=Path(args.data_dir))

    def progress(current: int, total: int) -> None:
        if current % 100 == 0 or current == total:
            pct = (current / total) * 100
            print(f"\rProgress: {current}/{total} ({pct:.1f}%)", end="", flush=True)

    try:
        result = await engine.run(
            config,
            strategy,
            risk,
            progress_callback=progress if not args.quiet else None,
        )
    except FileNotFoundError as e:
        logger.error(f"Data file not found: {e}")
        return 1

    print()  # Newline after progress
    print("\n" + "=" * 60)
    print(result.summary())
    print("=" * 60)

    # Save results if output specified
    if args.output:
        output_path = Path(args.output)
        output_path.write_text(result.summary())
        logger.info(f"Results saved to {output_path}")

    return 0


def _cmd_backtest(args: argparse.Namespace) -> int:
    """Backtest command handler."""
    return asyncio.run(_run_backtest(args))


async def _run_live(args: argparse.Namespace) -> int:
    """Run live trading bot."""
    _setup_logging(args.verbose)

    # Determine polling interval
    interval = 3.0 if args.fast_poll else args.interval

    logger.info("Live trading mode")
    logger.info(f"  Network: {args.network}")
    logger.info(f"  Netuid: {args.netuid}")
    logger.info(f"  Wallet: {args.wallet}")
    logger.info(f"  Strategy: {args.strategy}")
    logger.info(f"  Polling interval: {interval}s")
    if args.only_significant:
        logger.info("  Mode: Only processing significant events")
    logger.info(f"  Price threshold: {args.price_threshold * 100:.1f}%")
    logger.info(f"  Liquidity threshold: {args.liquidity_threshold * 100:.1f}%")
    logger.info(f"  Account refresh: every {args.account_refresh} polls")

    # Import bittensor for wallet
    try:
        import bittensor as bt
    except ImportError:
        logger.error("bittensor package required for live trading")
        return 1

    from deltao.connector import ConnectionState, DTaoConnector
    from deltao.core.clock import LiveClock
    from deltao.core.engine import Engine
    from deltao.core.state import EngineState

    # Load wallet
    wallet = bt.Wallet(name=args.wallet, hotkey=args.hotkey)
    logger.info(f"Loaded wallet: {wallet.name}")

    # Get strategy and risk manager
    strategy = _get_strategy(args.strategy)
    risk = _get_risk_manager(args.risk)

    # Create connector with event detection thresholds
    connector = DTaoConnector(
        wallet=wallet,
        netuid=args.netuid,
        network=args.network,
        max_retries=3,
        price_change_threshold=Decimal(str(args.price_threshold)),
        liquidity_change_threshold=Decimal(str(args.liquidity_threshold)),
    )

    # State change callback
    def on_state_change(state: ConnectionState) -> None:
        if state == ConnectionState.ERROR:
            logger.error("Connection error - bot may need restart")
        elif state == ConnectionState.CONNECTED:
            logger.info("Connected to network")

    connector.on_state_change(on_state_change)

    # Create engine
    clock = LiveClock()
    state = EngineState(
        tao_balance=Decimal("0"),  # Will be updated from chain
        alpha_balance=Decimal("0"),
        trading_enabled=True,
    )

    engine = Engine(
        clock=clock,
        state=state,
        strategy=strategy,
        risk=risk,
        connector=connector,
    )

    # Connect and run
    try:
        await connector.start()

        # Update state from chain
        account = await connector.get_account_state()
        state.tao_balance = account.tao_balance
        state.alpha_balance = account.alpha_balance
        logger.info(f"Balances: {state.tao_balance} TAO, {state.alpha_balance} Alpha")

        # Main loop with enhanced polling
        logger.info("Starting trading loop (Ctrl+C to stop)")
        poll_count = 0

        while True:
            try:
                # Get market state with event detection
                market = await connector.get_market_state(detect_events=True)
                poll_count += 1

                # Log detected events
                for event in market.detected_events:
                    logger.info(
                        f"Detected {event.event_type.value} ({event.severity.value}): "
                        f"{event.details}"
                    )

                # Skip processing if --only-significant and no significant change
                if args.only_significant and not market.is_significant:
                    logger.debug(
                        f"Block {market.block_number}: No significant change, skipping"
                    )
                else:
                    logger.debug(f"Block {market.block_number}: price={market.price}")

                    # Process market event
                    audit = await engine.process(market)

                    if audit.orders_approved:
                        logger.info(f"Executed {len(audit.orders_approved)} orders")
                        for order in audit.orders_approved:
                            logger.info(f"  {order.side.value}: {order.amount}")

                    if audit.errors:
                        for error in audit.errors:
                            logger.warning(f"Error: {error}")

                # Periodic account refresh
                if poll_count % args.account_refresh == 0:
                    account = await connector.get_account_state()
                    await engine.process(account)
                    logger.debug(
                        f"Account refreshed: {account.tao_balance} TAO, "
                        f"{account.alpha_balance} Alpha"
                    )

                # Wait for next poll
                await asyncio.sleep(interval)

            except KeyboardInterrupt:
                logger.info("Shutdown requested")
                break
            except Exception as e:
                logger.exception(f"Error in trading loop: {e}")
                await asyncio.sleep(5)  # Brief pause before retry

    finally:
        await connector.stop()

    return 0


def _cmd_live(args: argparse.Namespace) -> int:
    """Live trading command handler."""
    return asyncio.run(_run_live(args))


def build_parser() -> argparse.ArgumentParser:
    """Construct the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="deltao",
        description="deltao - Algorithmic trading framework for Bittensor dTao",
    )
    parser.add_argument("--version", action="version", version=__version__)

    subparsers = parser.add_subparsers(dest="command")

    # Info command
    info_parser = subparsers.add_parser("info", help="Show project information")
    info_parser.set_defaults(func=_cmd_info)

    # Backtest command
    bt_parser = subparsers.add_parser("backtest", help="Run a backtest")
    bt_parser.add_argument(
        "--netuid", type=int, default=8, help="Subnet ID (default: 8)"
    )
    bt_parser.add_argument(
        "--start-block", type=int, required=True, help="Starting block number"
    )
    bt_parser.add_argument(
        "--end-block", type=int, required=True, help="Ending block number"
    )
    bt_parser.add_argument(
        "--initial-tao",
        type=float,
        default=1000.0,
        help="Initial TAO balance (default: 1000)",
    )
    bt_parser.add_argument(
        "--initial-alpha",
        type=float,
        default=0.0,
        help="Initial Alpha balance (default: 0)",
    )
    bt_parser.add_argument(
        "--fee", type=float, default=0.001, help="Trading fee (default: 0.001)"
    )
    bt_parser.add_argument(
        "--data-dir",
        type=str,
        default="data/candles",
        help="Data directory (default: data/candles)",
    )
    bt_parser.add_argument(
        "--strategy",
        type=str,
        default="momentum",
        choices=["momentum", "mean_reversion"],
        help="Strategy to use (default: momentum)",
    )
    bt_parser.add_argument(
        "--risk",
        type=str,
        default="basic",
        choices=["basic", "position_limit", "none"],
        help="Risk manager (default: basic)",
    )
    bt_parser.add_argument(
        "--fast-period", type=int, help="Fast MA period (momentum strategy)"
    )
    bt_parser.add_argument(
        "--slow-period", type=int, help="Slow MA period (momentum strategy)"
    )
    bt_parser.add_argument(
        "--max-position", type=float, help="Max position size for risk manager"
    )
    bt_parser.add_argument("--output", "-o", type=str, help="Output file for results")
    bt_parser.add_argument(
        "--quiet", "-q", action="store_true", help="Suppress progress output"
    )
    bt_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Verbose logging"
    )
    bt_parser.set_defaults(func=_cmd_backtest)

    # Live trading command
    live_parser = subparsers.add_parser("live", help="Start live trading")
    live_parser.add_argument(
        "--network",
        type=str,
        default="finney",
        help="Bittensor network (default: finney)",
    )
    live_parser.add_argument(
        "--netuid", type=int, default=8, help="Subnet ID (default: 8)"
    )
    live_parser.add_argument("--wallet", type=str, required=True, help="Wallet name")
    live_parser.add_argument(
        "--hotkey", type=str, default="default", help="Hotkey name (default: default)"
    )
    live_parser.add_argument(
        "--strategy",
        type=str,
        default="momentum",
        choices=["momentum", "mean_reversion"],
        help="Strategy to use (default: momentum)",
    )
    live_parser.add_argument(
        "--risk",
        type=str,
        default="basic",
        choices=["basic", "position_limit", "none"],
        help="Risk manager (default: basic)",
    )
    live_parser.add_argument(
        "--interval",
        type=float,
        default=12.0,
        help="Polling interval in seconds (default: 12)",
    )
    live_parser.add_argument(
        "--fast-poll",
        action="store_true",
        help="Enable fast polling mode (3s interval)",
    )
    live_parser.add_argument(
        "--only-significant",
        action="store_true",
        help="Only process significant market events (skip if no change detected)",
    )
    live_parser.add_argument(
        "--price-threshold",
        type=float,
        default=0.02,
        help="Price change threshold for event detection (default: 0.02 = 2%%)",
    )
    live_parser.add_argument(
        "--liquidity-threshold",
        type=float,
        default=0.1,
        help="Liquidity change threshold for event detection (default: 0.1 = 10%%)",
    )
    live_parser.add_argument(
        "--account-refresh",
        type=int,
        default=5,
        help="Refresh account state every N polls (default: 5)",
    )
    live_parser.add_argument(
        "--verbose", "-v", action="store_true", help="Verbose logging"
    )
    live_parser.set_defaults(func=_cmd_live)

    return parser


def main(argv: list[str] | None = None) -> int:
    """Main entry point for the deltao CLI."""
    parser = build_parser()
    args = parser.parse_args(argv)

    if not hasattr(args, "func"):
        parser.print_help()
        return 0

    result: int = args.func(args)
    return result


if __name__ == "__main__":
    sys.exit(main())
