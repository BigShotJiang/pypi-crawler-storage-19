"""Simple engine example demonstrating core architecture.

This example shows:
- Engine setup with MockConnector
- Simple strategy and risk manager
- Market event processing
- Audit trail inspection

Based on IMPLEMENTATION_CORE.md lines 767-827.
"""

import asyncio
from datetime import datetime
from decimal import Decimal

from deltao import (
    Engine,
    EngineState,
    LiveClock,
    MarketEvent,
    OrderRequest,
    ShutdownEvent,
    Side,
)
from deltao.connector.mock import MockConnector


# Simple implementations for demo purposes
class DummyStrategy:
    """Example strategy that buys when price is low.

    Real strategies will be in deltao.strategy module (Phase 2).
    """

    def generate_orders(
        self, state: EngineState
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Generate orders based on simple price threshold.

        Returns:
            tuple: (orders_to_cancel, orders_to_open)
        """
        orders_to_cancel: list[OrderRequest] = []
        orders_to_open: list[OrderRequest] = []

        # Buy if price is below 1.0
        if state.current_price < Decimal("1.0"):
            orders_to_open.append(
                OrderRequest(
                    side=Side.BUY,
                    amount=Decimal("10"),
                    slippage_tolerance=Decimal("0.01"),
                )
            )

        return (orders_to_cancel, orders_to_open)


class DummyRiskManager:
    """Example risk manager that approves all orders.

    Real risk managers will have position limits, etc.
    """

    def check(
        self, _state: EngineState, orders: list[OrderRequest]
    ) -> tuple[list[OrderRequest], list[OrderRequest]]:
        """Check orders (approve all for demo).

        Returns:
            tuple: (approved_orders, denied_orders)
        """
        # For demo, approve all orders
        return (orders, [])


async def main() -> None:
    """Run simple engine example."""
    print("deltao - Simple Engine Example")
    print("=" * 50)

    # 1. Create components
    clock = LiveClock()
    state = EngineState(
        tao_balance=Decimal("100"),
        alpha_balance=Decimal("0"),
    )
    strategy = DummyStrategy()
    risk = DummyRiskManager()
    connector = MockConnector()

    # 2. Create engine
    engine = Engine(
        clock=clock,
        state=state,
        strategy=strategy,
        risk=risk,
        connector=connector,
    )

    print(f"\nEngine started at {engine.start_time}")
    print(f"Initial TAO balance: {state.tao_balance}")
    print(f"Initial Alpha balance: {state.alpha_balance}\n")

    # 3. Start connector
    await connector.start()

    # 4. Process some market events
    events = [
        MarketEvent(
            netuid=8,
            price=Decimal("0.95"),  # Below 1.0, should trigger buy
            tao_in=Decimal("1000"),
            alpha_in=Decimal("1050"),
            k=Decimal("1050000"),
            block_number=1000,
            timestamp=datetime.now(),
        ),
        MarketEvent(
            netuid=8,
            price=Decimal("1.05"),  # Above 1.0, should not trigger
            tao_in=Decimal("990"),
            alpha_in=Decimal("1060"),
            k=Decimal("1049400"),
            block_number=1001,
            timestamp=datetime.now(),
        ),
        MarketEvent(
            netuid=8,
            price=Decimal("0.98"),  # Below 1.0, should trigger buy
            tao_in=Decimal("1020"),
            alpha_in=Decimal("1040"),
            k=Decimal("1060800"),
            block_number=1002,
            timestamp=datetime.now(),
        ),
    ]

    for event in events:
        audit = await engine.process(event)

        print(f"Block {event.block_number}:")
        print(f"  Price: {event.price}")
        print(f"  Orders generated: {len(audit.orders_generated)}")
        print(f"  Orders approved: {len(audit.orders_approved)}")
        print(f"  Orders denied: {len(audit.orders_denied)}")

        if audit.orders_approved:
            for order in audit.orders_approved:
                print(f"    -> {order.side.value.upper()} {order.amount} TAO")

        print()

    # 5. Shutdown
    shutdown_event = ShutdownEvent(reason="Example complete", timestamp=datetime.now())
    audit = await engine.process(shutdown_event)

    print(f"Shutdown: {shutdown_event.reason}")
    print(f"Total events processed: {engine.sequence}")
    print(f"Total mock orders executed: {len(connector.orders)}")

    # 6. Stop connector
    await connector.stop()

    print("\nExample complete!")


if __name__ == "__main__":
    asyncio.run(main())
