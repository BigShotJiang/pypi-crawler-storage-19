# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.1] - 2026-01-11

Portfolio-wide circuit breaker for risk enforcement.

### Added
- **Circuit Breaker System**: Portfolio-wide risk enforcement with multiple triggers
  - `core/circuit_breaker.py`: CircuitBreaker class with configurable thresholds
  - Drawdown trigger (default 15%)
  - Consecutive losses trigger (default 5)
  - Loss rate trigger (default 70% over 20 trades)
  - Volatility spike trigger (default 10% std dev)
  - Manual reset required after trip
  - Trip history tracking and monitoring callback

### Changed
- `PortfolioManager` now integrates circuit breaker automatically
- `check_portfolio_risk()` delegates to circuit breaker when enabled
- Consolidated config: removed redundant `cb_max_drawdown` and `cb_max_exposure`

### Fixed
- Portfolio drawdown now calculated from total portfolio value, not per-agent max
- Win/loss tracking uses actual PnL change instead of execution success
- Volatility calculation uses maximum across all agents (conservative approach)

## [0.3.0] - 2026-01-10

Event-driven polling with market change detection for reactive trading strategies.

### Added
- **Event Detection System**: Real-time market change detection
  - `core/detector.py`: EventDetector class with configurable thresholds
  - `DetectedEvent` dataclass with severity levels (low, medium, high)
  - Price jump detection (default 2% threshold)
  - Liquidity change detection for TAO/Alpha pools (default 10% threshold)
- **Enhanced CLI Options**: New flags for live trading
  - `--fast-poll`: 3-second polling interval for faster reactions
  - `--only-significant`: Skip processing when no significant changes detected
  - `--price-threshold`: Configurable price change threshold
  - `--liquidity-threshold`: Configurable liquidity change threshold
  - `--account-refresh`: Periodic account state refresh interval
- **Strategy Event Hooks**: Event-driven order generation
  - `BaseStrategy.on_price_jump()`: Hook for price jump events
  - `BaseStrategy.on_liquidity_change()`: Hook for liquidity changes
  - `BaseStrategy.process_detected_events()`: Process all detected events
- **MarketEvent Extensions**: New fields for event data
  - `detected_events`: List of detected market events
  - `is_significant`: Flag indicating significant market changes

### Changed
- `DTaoConnector.get_market_state()` now accepts `detect_events` parameter
- Live trading loop includes periodic account state refresh
- Updated to bittensor 10.0.1

## [0.2.0] - 2026-01-07

Core trading engine implementation and dTao mechanics.

### Added
- **Core Engine**: Event-driven trading engine with async processing
  - `core/engine.py`: Main event processor with Protocol-based DI
  - `core/state.py`: EngineState with balances, positions, market data
  - `core/clock.py`: Time abstraction (LiveClock, HistoricalClock)
  - `core/event.py`: Event types (ShutdownEvent, MarketEvent, AccountEvent, etc.)
  - `core/types.py`: Trading types (Side, OrderRequest, OrderResult, LiquidityPosition)
  - `core/agent.py`: StrategyAgent wrapper with lifecycle management
- **Connector Interface**: Abstraction for chain/exchange connectivity
  - `connector/base.py`: Connector ABC with async methods
  - `connector/mock.py`: MockConnector for testing and backtesting
- **Uniswap v3 Math**: Concentrated liquidity calculations
  - `utils/tick_math.py`: Tick-to-price conversions (MIN_TICK=-443636 to MAX_TICK=443636)
  - Support for LiquidityPosition with price ranges
- **Comprehensive Tests**: 49 tests with 89% coverage
  - Unit tests for all core modules
  - Async test support with pytest-asyncio
- **Example**: `examples/simple_engine.py` demonstrating engine usage

### Technical Details
- Decimal precision for all financial calculations
- Protocol-based dependency injection (AlgoStrategy, RiskManager)
- Event-driven architecture with audit trails
- Clock abstraction for live/backtest compatibility
- No external dependencies beyond Python stdlib (bittensor SDK deferred)

## [0.1.0] - 2026-01-06

Initial release of deltao - Algorithmic Trading Framework

### Added
- CLI entry point (`deltao` command)
- Project scaffolding and core package structure
- Development tools: ruff, mypy, pytest, pre-commit
- Testing framework
- Documentation templates (README, CONTRIBUTING, CHANGELOG)
