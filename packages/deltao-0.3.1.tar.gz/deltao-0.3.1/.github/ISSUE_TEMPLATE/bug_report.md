---
name: Bug Report
about: Report a bug to help us improve
title: "[BUG] "
labels: bug
assignees: ""
---

## Description

A clear and concise description of what the bug is.

## To Reproduce

Steps to reproduce the behavior:

1. Import '...'
2. Call '....'
3. See error

## Expected Behavior

A clear and concise description of what you expected to happen.

## Actual Behavior

What actually happened.

## Code Sample

```python
# Minimal code to reproduce the issue
```

## Error Message

```
Paste the full error message/traceback here
```

## Environment

- OS: [e.g. macOS 14.0, Ubuntu 22.04, Windows 11]
- Python version: [e.g. 3.12.0]
- deltao version: [e.g. 0.1.0]

## Additional Context

Add any other context about the problem here.
