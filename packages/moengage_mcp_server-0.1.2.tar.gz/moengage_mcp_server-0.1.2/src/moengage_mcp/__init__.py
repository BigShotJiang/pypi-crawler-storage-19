"""MoEngage MCP Server - MCP server for MoEngage Campaign APIs.

This package provides an MCP (Model Context Protocol) server that enables
LLMs to interact with MoEngage Campaign APIs for fetching campaign stats,
searching campaigns by channel (Email, Push, SMS), and more.

Usage:
    # As CLI tool (via uvx)
    uvx moengage-mcp-server

    # Programmatic usage
    from moengage_mcp.server import mcp
    mcp.run()
"""

import logging

__version__ = "0.1.0"
__all__ = ["__version__"]

# Best practice: Add NullHandler to prevent "No handler found" warnings
# when the library is used without logging configuration.
# See: https://docs.python.org/3/howto/logging.html#configuring-logging-for-a-library
logging.getLogger(__name__).addHandler(logging.NullHandler())
