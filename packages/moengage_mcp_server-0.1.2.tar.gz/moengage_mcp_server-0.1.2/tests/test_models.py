"""Tests for Pydantic models."""

from datetime import date

import pytest
from pydantic import ValidationError

from moengage_mcp.models import (
    AttributionType,
    MetricType,
    PerformanceStats,
    StatsRequest,
    StatsResponse,
)


class TestStatsRequest:
    """Tests for StatsRequest model."""

    def test_valid_request(self):
        """Test creating a valid stats request."""
        request = StatsRequest(
            campaign_ids=["abc123", "def456"],
            start_date=date(2024, 12, 1),
            end_date=date(2024, 12, 31),
        )
        assert len(request.campaign_ids) == 2
        assert request.attribution_type == AttributionType.VIEW_THROUGH
        assert request.metric_type == MetricType.TOTAL

    def test_empty_campaign_ids_fails(self):
        """Test that empty campaign_ids list fails validation."""
        with pytest.raises(ValidationError):
            StatsRequest(
                campaign_ids=[],
                start_date=date(2024, 12, 1),
                end_date=date(2024, 12, 31),
            )

    def test_end_date_before_start_date_fails(self):
        """Test that end_date before start_date fails validation."""
        with pytest.raises(ValidationError):
            StatsRequest(
                campaign_ids=["abc123"],
                start_date=date(2024, 12, 31),
                end_date=date(2024, 12, 1),
            )

    def test_to_api_request(self):
        """Test conversion to API request format."""
        request = StatsRequest(
            request_id="test-123",
            campaign_ids=["abc123"],
            start_date=date(2024, 12, 1),
            end_date=date(2024, 12, 31),
            attribution_type=AttributionType.CLICK_THROUGH,
            metric_type=MetricType.UNIQUE,
        )
        api_request = request.to_api_request()

        assert api_request["request_id"] == "test-123"
        assert api_request["campaign_ids"] == ["abc123"]
        assert api_request["start_date"] == "2024-12-01"
        assert api_request["end_date"] == "2024-12-31"
        assert api_request["attribution_type"] == "CLICK_THROUGH"
        assert api_request["metric_type"] == "UNIQUE"

    def test_campaign_ids_whitespace_stripped(self):
        """Test that campaign IDs have whitespace stripped."""
        request = StatsRequest(
            campaign_ids=["  abc123  ", "def456"],
            start_date=date(2024, 12, 1),
            end_date=date(2024, 12, 31),
        )
        assert request.campaign_ids == ["abc123", "def456"]


class TestPerformanceStats:
    """Tests for PerformanceStats model."""

    def test_default_values(self):
        """Test default values for performance stats."""
        stats = PerformanceStats()
        assert stats.attempted == 0
        assert stats.sent == 0
        assert stats.ctr == 0.0

    def test_with_values(self):
        """Test creating stats with values."""
        stats = PerformanceStats(
            attempted=1000,
            sent=950,
            failed=50,
            impression=800,
            click=100,
            ctr=12.5,
        )
        assert stats.attempted == 1000
        assert stats.click == 100
        assert stats.ctr == 12.5


class TestStatsResponse:
    """Tests for StatsResponse model."""

    def test_success_response(self):
        """Test creating a successful response."""
        response = StatsResponse(
            request_id="test-123",
            success=True,
            campaigns=[],
        )
        assert response.success is True
        assert response.error_message is None

    def test_error_response(self):
        """Test creating an error response."""
        response = StatsResponse(
            request_id="test-123",
            success=False,
            error_message="Rate limit exceeded",
        )
        assert response.success is False
        assert "Rate limit" in response.error_message
