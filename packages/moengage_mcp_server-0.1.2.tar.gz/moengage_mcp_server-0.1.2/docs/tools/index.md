# Tools Overview

MoEngage MCP Server provides four tools for interacting with MoEngage Campaign APIs.

## Available Tools

| Tool | Description | Use Case |
|------|-------------|----------|
| [`get_campaign_stats`](campaign-stats.md) | Fetch campaign performance metrics | Analytics, reporting |
| [`get_email_campaigns`](email-campaigns.md) | Search email campaigns | Campaign management |
| [`get_push_campaigns`](push-campaigns.md) | Search push campaigns | Campaign management |
| [`get_sms_campaigns`](sms-campaigns.md) | Search SMS campaigns | Campaign management |

## Common Parameters

All campaign search tools share these parameters:

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `campaign_id` | string | No | - | Specific campaign ID to fetch |
| `campaign_name` | string | No | - | Filter by campaign name |
| `status` | string | No | - | Filter by status |
| `limit` | integer | No | 10 | Results per page (1-15) |
| `page` | integer | No | 1 | Page number |
| `include_archived` | boolean | No | false | Include archived campaigns |

## Status Values

Campaigns can have these statuses:

- `DRAFT` - Campaign is in draft state
- `SCHEDULED` - Campaign is scheduled
- `ACTIVE` - Campaign is currently running
- `PAUSED` - Campaign is paused
- `COMPLETED` - Campaign has completed
- `STOPPED` - Campaign was manually stopped

## Response Structure

All tools return structured responses:

```json
{
  "request_id": "mcp-request",
  "success": true,
  "total_campaigns": 10,
  "current_page": 1,
  "total_pages": 1,
  "campaigns": [...],
  "error_message": null
}
```

## Error Handling

If a request fails, the response includes error details:

```json
{
  "request_id": "mcp-request",
  "success": false,
  "error_message": "Invalid credentials"
}
```
