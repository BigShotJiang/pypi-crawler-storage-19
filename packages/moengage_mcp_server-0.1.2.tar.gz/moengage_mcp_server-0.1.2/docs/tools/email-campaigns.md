# Email Campaigns

Search and retrieve email campaign details from MoEngage.

## Usage

```
get_email_campaigns(
    campaign_id: "optional-campaign-id",
    campaign_name: "optional-name-filter",
    status: "ACTIVE",
    limit: 10,
    page: 1
)
```

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `campaign_id` | string | No | - | Specific campaign ID to fetch |
| `campaign_name` | string | No | - | Filter by campaign name |
| `status` | string | No | - | Filter by status |
| `limit` | integer | No | 10 | Results per page (1-15) |
| `page` | integer | No | 1 | Page number |
| `include_archived` | boolean | No | false | Include archived campaigns |

## Response

```json
{
  "request_id": "mcp-request",
  "success": true,
  "total_campaigns": 25,
  "current_page": 1,
  "total_pages": 3,
  "campaigns": [
    {
      "campaign_id": "000000000000000000000003",
      "channel": "EMAIL",
      "status": "ACTIVE",
      "delivery_type": "ONE_TIME",
      "basic_details": {
        "campaign_name": "Welcome Email",
        "team": "Marketing",
        "tags": ["onboarding", "welcome"]
      },
      "variations": [
        {
          "variation_id": "v1",
          "subject": "Welcome to Our Platform!",
          "from_name": "Support Team",
          "from_email": "support@example.com",
          "reply_to": "support@example.com"
        }
      ],
      "utm_params": {
        "source": "moengage",
        "medium": "email",
        "campaign": "welcome"
      }
    }
  ]
}
```

## Campaign Fields

| Field | Description |
|-------|-------------|
| `campaign_id` | Unique campaign identifier |
| `channel` | Always `EMAIL` for this tool |
| `status` | Current campaign status |
| `delivery_type` | `ONE_TIME`, `PERIODIC`, or `EVENT_TRIGGERED` |
| `basic_details` | Campaign name, team, and tags |
| `variations` | Email content variations (A/B testing) |
| `utm_params` | UTM tracking parameters |

## Examples

### Get all email campaigns

```
Show me all email campaigns
```

### Get a specific campaign

```
Get email campaign 000000000000000000000003
```

### Filter by status

```
Find all ACTIVE email campaigns
```

### Search by name

```
Find email campaigns with "welcome" in the name
```

### Paginate results

```
Get email campaigns, page 2, with 15 results per page
```
