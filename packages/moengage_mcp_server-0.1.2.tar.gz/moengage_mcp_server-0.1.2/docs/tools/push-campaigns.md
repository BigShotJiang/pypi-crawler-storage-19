# Push Campaigns

Search and retrieve push notification campaign details from MoEngage.

## Usage

```
get_push_campaigns(
    campaign_id: "optional-campaign-id",
    campaign_name: "optional-name-filter",
    status: "ACTIVE",
    limit: 10,
    page: 1
)
```

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `campaign_id` | string | No | - | Specific campaign ID to fetch |
| `campaign_name` | string | No | - | Filter by campaign name |
| `status` | string | No | - | Filter by status |
| `limit` | integer | No | 10 | Results per page (1-15) |
| `page` | integer | No | 1 | Page number |
| `include_archived` | boolean | No | false | Include archived campaigns |

## Response

```json
{
  "request_id": "mcp-request",
  "success": true,
  "total_campaigns": 15,
  "current_page": 1,
  "total_pages": 2,
  "campaigns": [
    {
      "campaign_id": "000000000000000000000004",
      "channel": "PUSH",
      "platform": "ANDROID",
      "status": "ACTIVE",
      "delivery_type": "EVENT_TRIGGERED",
      "basic_details": {
        "campaign_name": "Cart Abandonment Reminder",
        "team": "Growth",
        "tags": ["cart", "reminder"]
      },
      "variations": [
        {
          "variation_id": "v1",
          "title": "You left something behind!",
          "message": "Complete your purchase and get 10% off"
        }
      ]
    }
  ]
}
```

## Campaign Fields

| Field | Description |
|-------|-------------|
| `campaign_id` | Unique campaign identifier |
| `channel` | Always `PUSH` for this tool |
| `platform` | `ANDROID`, `IOS`, or `WEB` |
| `status` | Current campaign status |
| `delivery_type` | `ONE_TIME`, `PERIODIC`, or `EVENT_TRIGGERED` |
| `basic_details` | Campaign name, team, and tags |
| `variations` | Push content variations |

## Examples

### Get all push campaigns

```
Show me all push notification campaigns
```

### Get a specific campaign

```
Get push campaign 000000000000000000000004
```

### Filter by status

```
Find all SCHEDULED push campaigns
```

### Search by name

```
Find push campaigns containing "reminder"
```

### Get completed campaigns

```
List all COMPLETED push campaigns including archived ones
```
