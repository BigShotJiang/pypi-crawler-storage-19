# Campaign Stats

Fetch performance statistics for one or more campaigns.

## Usage

```
get_campaign_stats(
    campaign_ids: ["campaign-id-1", "campaign-id-2"],
    start_date: "2024-12-01",
    end_date: "2024-12-31"
)
```

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `campaign_ids` | array | Yes | - | List of campaign IDs (max 50) |
| `start_date` | string | Yes | - | Start date (YYYY-MM-DD) |
| `end_date` | string | Yes | - | End date (YYYY-MM-DD) |
| `attribution_type` | string | No | `VIEW_THROUGH` | `VIEW_THROUGH` or `CLICK_THROUGH` |
| `metric_type` | string | No | `TOTAL` | `TOTAL` or `UNIQUE` |
| `request_id` | string | No | `mcp-request` | Request tracking ID |

## Response

```json
{
  "request_id": "mcp-request",
  "success": true,
  "campaigns": [
    {
      "campaign_id": "000000000000000000000001",
      "campaign_name": "Welcome Campaign",
      "campaign_type": "ONE_TIME",
      "channel": "EMAIL",
      "all_variations": {
        "attempted": 10000,
        "sent": 9800,
        "failed": 200,
        "impression": 5000,
        "click": 500,
        "ctr": 10.0,
        "delivery_rate": 98.0,
        "sent_rate": 98.0,
        "failure_rate": 2.0
      },
      "variations": [],
      "global_control_group": null,
      "campaign_control_group": null
    }
  ],
  "rate_limit_remaining": 100
}
```

## Metrics Explained

| Metric | Description |
|--------|-------------|
| `attempted` | Total messages attempted |
| `sent` | Successfully sent messages |
| `failed` | Failed messages |
| `impression` | Total impressions/opens |
| `click` | Total clicks |
| `ctr` | Click-through rate (%) |
| `delivery_rate` | Delivery rate (%) |
| `sent_rate` | Sent rate (%) |
| `failure_rate` | Failure rate (%) |

## Examples

### Get stats for a single campaign

```
Get stats for campaign 000000000000000000000001 for December 2024
```

### Compare multiple campaigns

```
Get stats for these campaigns and compare their performance:
- 000000000000000000000001
- 000000000000000000000002

Date range: December 1-31, 2024
```

### Get unique metrics

```
Get campaign stats for 000000000000000000000001 with unique metrics
(metric_type: UNIQUE) from Dec 1-31, 2024
```
