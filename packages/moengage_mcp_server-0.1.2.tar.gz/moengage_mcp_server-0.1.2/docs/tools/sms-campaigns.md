# SMS Campaigns

Search and retrieve SMS campaign details from MoEngage.

## Usage

```
get_sms_campaigns(
    campaign_id: "optional-campaign-id",
    campaign_name: "optional-name-filter",
    status: "ACTIVE",
    limit: 10,
    page: 1
)
```

## Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `campaign_id` | string | No | - | Specific campaign ID to fetch |
| `campaign_name` | string | No | - | Filter by campaign name |
| `status` | string | No | - | Filter by status |
| `limit` | integer | No | 10 | Results per page (1-15) |
| `page` | integer | No | 1 | Page number |
| `include_archived` | boolean | No | false | Include archived campaigns |

## Response

```json
{
  "request_id": "mcp-request",
  "success": true,
  "total_campaigns": 8,
  "current_page": 1,
  "total_pages": 1,
  "campaigns": [
    {
      "campaign_id": "000000000000000000000001",
      "channel": "SMS",
      "status": "ACTIVE",
      "delivery_type": "ONE_TIME",
      "basic_details": {
        "campaign_name": "Flash Sale Alert",
        "team": "Marketing",
        "tags": ["sale", "promotion"]
      },
      "variations": [
        {
          "variation_id": "v1",
          "message": "Flash Sale! Get 50% off all items. Shop now: example.com/sale"
        }
      ],
      "connector": {
        "name": "Twilio",
        "type": "SMS_PROVIDER"
      }
    }
  ]
}
```

## Campaign Fields

| Field | Description |
|-------|-------------|
| `campaign_id` | Unique campaign identifier |
| `channel` | Always `SMS` for this tool |
| `status` | Current campaign status |
| `delivery_type` | `ONE_TIME`, `PERIODIC`, or `EVENT_TRIGGERED` |
| `basic_details` | Campaign name, team, and tags |
| `variations` | SMS message variations |
| `connector` | SMS provider information |

## Examples

### Get all SMS campaigns

```
Show me all SMS campaigns
```

### Get a specific campaign

```
Get SMS campaign 000000000000000000000001
```

### Filter by status

```
Find all ACTIVE SMS campaigns
```

### Search by name

```
Find SMS campaigns with "sale" in the name
```

### List draft campaigns

```
Show all DRAFT SMS campaigns
```
