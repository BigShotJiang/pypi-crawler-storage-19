# MoEngage MCP Server

**Access MoEngage Campaign APIs through the Model Context Protocol**

[![PyPI version](https://badge.fury.io/py/moengage-mcp-server.svg)](https://badge.fury.io/py/moengage-mcp-server)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

---

## What is MoEngage MCP Server?

MoEngage MCP Server is a **Model Context Protocol (MCP)** server that enables AI assistants like Claude to interact with MoEngage Campaign APIs. It provides tools for:

- **Campaign Statistics** - Fetch performance metrics for campaigns
- **Email Campaigns** - Search and retrieve email campaign details
- **Push Campaigns** - Search and retrieve push notification campaigns
- **SMS Campaigns** - Search and retrieve SMS campaign details

## Quick Start

### Installation

```bash
uvx moengage-mcp-server@latest
```

### Configuration

Add to your Claude Desktop or VS Code configuration:

```json
{
  "mcpServers": {
    "moengage": {
      "command": "uvx",
      "args": ["moengage-mcp-server@latest"],
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```

### Usage

Once configured, you can ask Claude:

> "Get the stats for campaign 000000000000000000000001 for the last 7 days"

> "Show me all active email campaigns"

> "List SMS campaigns created by john@company.com"

## Features

<div class="grid cards" markdown>

-   :material-chart-line:{ .lg .middle } **Campaign Analytics**

    ---

    Fetch detailed performance metrics including delivery rates, CTR, impressions, and more.

    [:octicons-arrow-right-24: Learn more](tools/campaign-stats.md)

-   :material-email:{ .lg .middle } **Email Campaigns**

    ---

    Search and retrieve email campaign configurations, content, and metadata.

    [:octicons-arrow-right-24: Learn more](tools/email-campaigns.md)

-   :material-bell:{ .lg .middle } **Push Notifications**

    ---

    Access push notification campaign details across platforms.

    [:octicons-arrow-right-24: Learn more](tools/push-campaigns.md)

-   :material-message:{ .lg .middle } **SMS Campaigns**

    ---

    Retrieve SMS campaign information and connector details.

    [:octicons-arrow-right-24: Learn more](tools/sms-campaigns.md)

</div>

## Supported Data Centers

| Data Center | Region | API Endpoint |
|-------------|--------|--------------|
| DC01 | Default | `api-01.moengage.com` |
| DC02 | | `api-02.moengage.com` |
| DC03 | | `api-03.moengage.com` |
| DC04 | | `api-04.moengage.com` |
| DC05 | | `api-05.moengage.com` |
| DC06 | | `api-06.moengage.com` |

## Security

- **Environment Variables** - Credentials are never hardcoded
- **Credential Masking** - API keys are masked in logs
- **Secure Transport** - All API calls use HTTPS
- **No Token Passthrough** - Server manages authentication

## Getting Help

- [GitHub Issues](https://github.com/moengage/moengage-mcp-server/issues) - Bug reports and feature requests
- [MoEngage Docs](https://developers.moengage.com) - Official MoEngage documentation
- [MCP Specification](https://modelcontextprotocol.io) - Model Context Protocol docs
