# Environment Variables

Complete reference for all configuration options.

## Required Variables

| Variable | Description |
|----------|-------------|
| `MOENGAGE_WORKSPACE_ID` | Your MoEngage Workspace ID |
| `MOENGAGE_CAMPAIGN_REPORTS_API_KEY` | Campaign Reports API Key |

## Optional Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `MOENGAGE_DATA_CENTER` | `01` | Data center code (01-06) |
| `MOENGAGE_TIMEOUT` | `30` | API timeout in seconds |
| `MOENGAGE_MAX_RETRIES` | `3` | Max retry attempts |

## Setting Variables

### Shell Export

```bash
export MOENGAGE_WORKSPACE_ID="your-workspace-id"
export MOENGAGE_CAMPAIGN_REPORTS_API_KEY="your-api-key"
export MOENGAGE_DATA_CENTER="01"
```

### .env File

Create a `.env` file in your project:

```ini
MOENGAGE_WORKSPACE_ID=your-workspace-id
MOENGAGE_CAMPAIGN_REPORTS_API_KEY=your-api-key
MOENGAGE_DATA_CENTER=01
MOENGAGE_TIMEOUT=30
MOENGAGE_MAX_RETRIES=3
```

### MCP Client Configuration

Pass variables directly in your MCP client config:

```json
{
  "env": {
    "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
    "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
    "MOENGAGE_DATA_CENTER": "01"
  }
}
```

## Security Best Practices

!!! danger "Never Commit Credentials"
    - Add `.env` to `.gitignore`
    - Use environment variables or secrets managers
    - Never hardcode credentials in code

## Variable Precedence

Configuration is loaded in this order (later overrides earlier):

1. Default values
2. `.env` file
3. Environment variables
4. MCP client `env` config
