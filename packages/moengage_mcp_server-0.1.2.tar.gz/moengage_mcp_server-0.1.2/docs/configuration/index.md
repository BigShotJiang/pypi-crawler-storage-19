# Configuration

Configure MoEngage MCP Server for your environment.

## Configuration Options

| Section | Description |
|---------|-------------|
| [Environment Variables](environment.md) | All available settings |
| [Data Centers](data-centers.md) | Regional API endpoints |

## Quick Setup

Set these environment variables to get started:

```bash
export MOENGAGE_WORKSPACE_ID="your-workspace-id"
export MOENGAGE_CAMPAIGN_REPORTS_API_KEY="your-api-key"
export MOENGAGE_DATA_CENTER="01"
```

## Configuration Methods

1. **Environment variables** - Best for local development
2. **.env file** - Best for projects with multiple settings
3. **MCP client config** - Best for per-client configuration

See [Environment Variables](environment.md) for details on each method.
