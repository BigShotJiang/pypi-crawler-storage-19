# Data Centers

MoEngage operates multiple data centers globally. Configure the correct one for your account.

## Available Data Centers

| Code | API Endpoint | Region |
|------|--------------|--------|
| `01` | `api-01.moengage.com` | Default |
| `02` | `api-02.moengage.com` | DC02 |
| `03` | `api-03.moengage.com` | DC03 |
| `04` | `api-04.moengage.com` | DC04 |
| `05` | `api-05.moengage.com` | DC05 |
| `06` | `api-06.moengage.com` | DC06 |

## Finding Your Data Center

Check your MoEngage dashboard URL:

| Dashboard URL | Data Center |
|---------------|-------------|
| `dashboard.moengage.com` | `01` |
| `dashboard-02.moengage.com` | `02` |
| `dashboard-03.moengage.com` | `03` |
| `dashboard-04.moengage.com` | `04` |
| `dashboard-05.moengage.com` | `05` |
| `dashboard-06.moengage.com` | `06` |

## Configuration

Set the `MOENGAGE_DATA_CENTER` environment variable:

```bash
export MOENGAGE_DATA_CENTER="02"
```

Or in your MCP client config:

```json
{
  "env": {
    "MOENGAGE_DATA_CENTER": "02"
  }
}
```

## Wrong Data Center

If you configure the wrong data center, API calls will fail with authentication errors. Symptoms include:

- 401 Unauthorized responses
- "Invalid credentials" errors
- Empty or unexpected results

!!! tip "Verify Your Data Center"
    Log in to your MoEngage dashboard and check the URL to confirm your data center.
