*[MCP]: Model Context Protocol
*[API]: Application Programming Interface
*[CLI]: Command Line Interface
*[CTR]: Click-Through Rate
*[SMS]: Short Message Service
*[JSON]: JavaScript Object Notation
*[URL]: Uniform Resource Locator
*[SDK]: Software Development Kit
*[PyPI]: Python Package Index
