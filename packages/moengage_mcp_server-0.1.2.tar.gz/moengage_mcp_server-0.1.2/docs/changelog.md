# Changelog

All notable changes to MoEngage MCP Server.

## [0.1.0] - 2025-01-11

### Added

- Initial release
- **Tools**:
  - `get_campaign_stats` - Fetch campaign performance metrics
  - `get_email_campaigns` - Search email campaigns
  - `get_push_campaigns` - Search push notification campaigns
  - `get_sms_campaigns` - Search SMS campaigns
- **Features**:
  - Support for all MoEngage data centers (DC01-DC06)
  - Configurable timeouts and retries
  - Credential masking in logs
- **Integrations**:
  - Claude Desktop support
  - Claude Code support
  - VS Code support
  - Any MCP-compatible client

### Security

- Credentials automatically masked in logs
- NullHandler for library logging (no output by default)
- Environment variable configuration (no hardcoded secrets)

## Future Releases

Planned features for upcoming releases:

- Additional campaign types (In-App, Cards, Web Push)
- User analytics tools
- Segment management
- Flow/Journey analytics
