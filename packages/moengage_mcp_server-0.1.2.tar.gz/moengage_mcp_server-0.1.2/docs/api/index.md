# API Reference

Technical reference for MoEngage MCP Server internals.

## Module Structure

```
moengage_mcp/
├── __init__.py      # Package initialization
├── server.py        # MCP server implementation
├── client.py        # MoEngage API client
├── config.py        # Configuration management
└── models.py        # Data models
```

## Configuration (config.py)

### Settings Class

```python
from moengage_mcp.config import Settings

settings = Settings(
    workspace_id="your-workspace-id",
    campaign_reports_api_key="your-api-key",
    data_center=DataCenter.DC01,
    timeout=30,
    max_retries=3
)
```

### DataCenter Enum

```python
from moengage_mcp.config import DataCenter

DataCenter.DC01  # api-01.moengage.com
DataCenter.DC02  # api-02.moengage.com
DataCenter.DC03  # api-03.moengage.com
DataCenter.DC04  # api-04.moengage.com
DataCenter.DC05  # api-05.moengage.com
DataCenter.DC06  # api-06.moengage.com
```

## Client (client.py)

### MoEngageClient Class

```python
from moengage_mcp.client import MoEngageClient
from moengage_mcp.config import Settings

settings = Settings(...)
client = MoEngageClient(settings)

# Get campaign stats
stats = await client.get_campaign_stats(
    campaign_ids=["campaign-id"],
    start_date="2024-12-01",
    end_date="2024-12-31"
)

# Search campaigns
campaigns = await client.get_campaigns(
    channel="EMAIL",
    status="ACTIVE",
    limit=10
)
```

## Server (server.py)

The MCP server is implemented using the `mcp` library:

```python
from mcp.server import Server
from mcp.server.stdio import stdio_server

app = Server("moengage-mcp")

@app.tool()
async def get_campaign_stats(...):
    ...
```

## Running Programmatically

```python
import asyncio
from moengage_mcp.server import create_server, run_stdio

async def main():
    server = create_server()
    await run_stdio(server)

asyncio.run(main())
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `MOENGAGE_WORKSPACE_ID` | MoEngage Workspace ID |
| `MOENGAGE_CAMPAIGN_REPORTS_API_KEY` | Campaign Reports API Key |
| `MOENGAGE_DATA_CENTER` | Data center code (01-06) |
| `MOENGAGE_TIMEOUT` | API timeout in seconds |
| `MOENGAGE_MAX_RETRIES` | Max retry attempts |
