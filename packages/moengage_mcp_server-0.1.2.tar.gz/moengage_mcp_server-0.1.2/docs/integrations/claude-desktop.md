# Claude Desktop

Configure MoEngage MCP Server with Claude Desktop.

## Configuration

Edit your Claude Desktop configuration file:

=== "macOS"

    ```bash
    ~/Library/Application Support/Claude/claude_desktop_config.json
    ```

=== "Windows"

    ```bash
    %APPDATA%\Claude\claude_desktop_config.json
    ```

## Configuration File

```json
{
  "mcpServers": {
    "moengage": {
      "command": "uvx",
      "args": ["moengage-mcp-server@latest"],
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```

## Using pip Installation

If you installed with pip instead of uvx:

```json
{
  "mcpServers": {
    "moengage": {
      "command": "moengage-mcp",
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```

## Apply Changes

1. Save the configuration file
2. Completely quit Claude Desktop (not just close the window)
3. Restart Claude Desktop

## Verify Connection

After restarting, you should see the MoEngage tools available. Try:

> "Show me all email campaigns"

## Troubleshooting

### Server not appearing

- Check that `uvx` is in your PATH
- Verify your credentials are correct
- Check Claude Desktop logs for errors

### Authentication errors

- Verify your Workspace ID and API Key
- Ensure your API key has Campaign Reports permissions
- Check your data center setting matches your account

### Connection timeout

- Check your internet connection
- Verify the MoEngage API is accessible
- Try increasing the timeout with `MOENGAGE_TIMEOUT` environment variable
