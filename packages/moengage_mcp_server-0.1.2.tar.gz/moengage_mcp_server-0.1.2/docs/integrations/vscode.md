# VS Code

Configure MoEngage MCP Server with Visual Studio Code.

## Prerequisites

- VS Code with MCP support (Copilot extension or compatible MCP client)
- `uvx` or pip installed

## Configuration

### Workspace Settings

Add to your `.vscode/settings.json`:

```json
{
  "mcp.servers": {
    "moengage": {
      "command": "uvx",
      "args": ["moengage-mcp-server@latest"],
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```

### User Settings

For global configuration, add to your user settings:

1. Open Command Palette (`Cmd+Shift+P` / `Ctrl+Shift+P`)
2. Search for "Preferences: Open User Settings (JSON)"
3. Add the MCP configuration

## Using pip Installation

```json
{
  "mcp.servers": {
    "moengage": {
      "command": "moengage-mcp",
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```

## Apply Changes

1. Save the settings file
2. Reload VS Code window (`Cmd+Shift+P` → "Developer: Reload Window")

## Security Note

!!! warning "Don't commit credentials"
    If using workspace settings, add `.vscode/settings.json` to your `.gitignore`
    to prevent accidentally committing credentials.

## Alternative: Environment Variables

Set environment variables in your shell profile and use a simpler config:

```bash
# In ~/.zshrc or ~/.bashrc
export MOENGAGE_WORKSPACE_ID="your-workspace-id"
export MOENGAGE_CAMPAIGN_REPORTS_API_KEY="your-api-key"
export MOENGAGE_DATA_CENTER="01"
```

Then in VS Code:

```json
{
  "mcp.servers": {
    "moengage": {
      "command": "uvx",
      "args": ["moengage-mcp-server@latest"]
    }
  }
}
```
