# Integrations

MoEngage MCP Server integrates with any MCP-compatible client.

## Supported Clients

| Client | Documentation |
|--------|---------------|
| [Claude Desktop](claude-desktop.md) | Desktop app for macOS and Windows |
| [Claude Code](claude-code.md) | CLI tool for developers |
| [VS Code](vscode.md) | Visual Studio Code with MCP extensions |

## Quick Comparison

| Feature | Claude Desktop | Claude Code | VS Code |
|---------|---------------|-------------|---------|
| GUI | Yes | No (CLI) | Yes |
| Config location | App config | `~/.claude/settings.json` | `.vscode/settings.json` |
| Best for | General use | Developers | IDE users |

## Configuration Pattern

All clients use the same basic configuration pattern:

```json
{
  "command": "uvx",
  "args": ["moengage-mcp-server@latest"],
  "env": {
    "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
    "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
    "MOENGAGE_DATA_CENTER": "01"
  }
}
```

## Other MCP Clients

The MoEngage MCP Server should work with any MCP-compatible client. Configure it using the standard MCP server configuration pattern shown above.

For custom integrations, see the [API Reference](../api/index.md).
