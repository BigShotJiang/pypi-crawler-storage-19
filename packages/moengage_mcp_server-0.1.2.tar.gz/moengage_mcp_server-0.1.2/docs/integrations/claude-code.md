# Claude Code

Configure MoEngage MCP Server with Claude Code CLI.

## Configuration

Edit your Claude Code settings file:

```bash
~/.claude/settings.json
```

## Configuration File

```json
{
  "mcpServers": {
    "moengage": {
      "type": "stdio",
      "command": "uvx",
      "args": ["moengage-mcp-server@latest"],
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```

## Using pip Installation

If you installed with pip:

```json
{
  "mcpServers": {
    "moengage": {
      "type": "stdio",
      "command": "moengage-mcp",
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```

## Apply Changes

Restart Claude Code or start a new session:

```bash
claude
```

## Verify Connection

Check available MCP servers:

```
/mcp
```

You should see `moengage` listed with its tools.

## Usage Examples

Once configured, you can use natural language:

```
Get stats for campaign 000000000000000000000001 from Dec 1-31, 2024
```

```
Show me all active email campaigns
```

```
Find SMS campaigns with "sale" in the name
```

## Debug Mode

To troubleshoot connection issues, enable debug logging:

```json
{
  "mcpServers": {
    "moengage": {
      "type": "stdio",
      "command": "uvx",
      "args": ["moengage-mcp-server@latest", "--debug"],
      "env": {
        "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
        "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
        "MOENGAGE_DATA_CENTER": "01"
      }
    }
  }
}
```
