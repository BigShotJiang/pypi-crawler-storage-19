# Installation

## Requirements

- Python 3.10 or higher
- [uv](https://docs.astral.sh/uv/) (recommended) or pip

## Quick Install

The easiest way to use MoEngage MCP Server is with `uvx`:

```bash
uvx moengage-mcp-server@latest
```

This downloads and runs the server in an isolated environment - no installation required!

## Install with pip

```bash
pip install moengage-mcp-server
```

## Install from Source

```bash
# Clone the repository
git clone https://github.com/moengage/moengage-mcp-server.git
cd moengage-mcp-server

# Install with uv
uv sync

# Or with pip
pip install -e .
```

## Verify Installation

```bash
# Check the CLI is available
moengage-mcp --help
```

Expected output:

```
usage: moengage-mcp [-h] [--transport {stdio,http,sse}] [--host HOST]
                    [--port PORT] [--debug]

MoEngage MCP Server - Access MoEngage APIs via Model Context Protocol

options:
  -h, --help            show this help message and exit
  --transport {stdio,http,sse}
                        Transport protocol (default: stdio)
  --host HOST           Host to bind to for HTTP/SSE (default: 127.0.0.1)
  --port PORT           Port to bind to for HTTP/SSE (default: 8000)
  --debug               Enable debug logging
```

## Next Steps

- [Configuration](configuration.md) - Set up your MoEngage credentials
- [Quick Start](quickstart.md) - Start using the MCP server
