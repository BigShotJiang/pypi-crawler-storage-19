# Quick Start

Get up and running with MoEngage MCP Server in 5 minutes.

## Prerequisites

- MoEngage account with Campaign Reports API access
- Claude Desktop, Claude Code, or VS Code with MCP support

## Step 1: Get Your Credentials

1. Log in to [MoEngage Dashboard](https://dashboard.moengage.com)
2. Navigate to **Settings** → **Account** → **APIs**
3. Note your:
   - **Workspace ID**
   - **Campaign Reports API Key**
   - **Data Center** (from your dashboard URL)

## Step 2: Configure Your Client

=== "Claude Desktop"

    Edit `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or
    `%APPDATA%\Claude\claude_desktop_config.json` (Windows):

    ```json
    {
      "mcpServers": {
        "moengage": {
          "command": "uvx",
          "args": ["moengage-mcp-server@latest"],
          "env": {
            "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
            "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
            "MOENGAGE_DATA_CENTER": "01"
          }
        }
      }
    }
    ```

=== "Claude Code"

    Edit `~/.claude/settings.json`:

    ```json
    {
      "mcpServers": {
        "moengage": {
          "type": "stdio",
          "command": "uvx",
          "args": ["moengage-mcp-server@latest"],
          "env": {
            "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
            "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
            "MOENGAGE_DATA_CENTER": "01"
          }
        }
      }
    }
    ```

=== "VS Code"

    Add to your `.vscode/settings.json`:

    ```json
    {
      "mcp.servers": {
        "moengage": {
          "command": "uvx",
          "args": ["moengage-mcp-server@latest"],
          "env": {
            "MOENGAGE_WORKSPACE_ID": "your-workspace-id",
            "MOENGAGE_CAMPAIGN_REPORTS_API_KEY": "your-api-key",
            "MOENGAGE_DATA_CENTER": "01"
          }
        }
      }
    }
    ```

## Step 3: Restart Your Client

Restart Claude Desktop, Claude Code, or VS Code to load the MCP server.

## Step 4: Start Using

Try these example prompts:

### Get Campaign Stats

> "Get performance stats for campaign ID `000000000000000000000001` from December 1-31, 2024"

### List Email Campaigns

> "Show me all email campaigns"

### Search SMS Campaigns

> "Find SMS campaigns with status ACTIVE"

### Analyze Performance

> "Get stats for these campaigns and compare their CTR:
> - 000000000000000000000001
> - 000000000000000000000002"

## Available Tools

| Tool | Description |
|------|-------------|
| `get_campaign_stats` | Fetch campaign performance metrics |
| `get_email_campaigns` | Search email campaigns |
| `get_push_campaigns` | Search push notification campaigns |
| `get_sms_campaigns` | Search SMS campaigns |

## Next Steps

- [Tools Reference](../tools/index.md) - Detailed tool documentation
- [Configuration Options](../configuration/environment.md) - All configuration options
