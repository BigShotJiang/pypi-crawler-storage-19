# Configuration

## Environment Variables

MoEngage MCP Server uses environment variables for configuration:

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `MOENGAGE_WORKSPACE_ID` | Yes | - | Your MoEngage Workspace ID |
| `MOENGAGE_CAMPAIGN_REPORTS_API_KEY` | Yes | - | Campaign Reports API Key |
| `MOENGAGE_DATA_CENTER` | No | `01` | Data center (01-06) |
| `MOENGAGE_TIMEOUT` | No | `30` | API timeout in seconds |
| `MOENGAGE_MAX_RETRIES` | No | `3` | Max retry attempts |

## Finding Your Credentials

### Workspace ID

1. Log in to [MoEngage Dashboard](https://dashboard.moengage.com)
2. Go to **Settings** → **Account** → **APIs**
3. Copy your **Workspace ID** (formerly App ID)

### Campaign Reports API Key

1. In MoEngage Dashboard, go to **Settings** → **Account** → **APIs**
2. Find the **Campaign Reports API** section
3. Copy or generate your API Key

!!! warning "API Key Permissions"
    Ensure your API key has permissions for the Campaign Reports API.

## Data Centers

MoEngage operates multiple data centers. Use the correct one for your account:

| Data Center | Code | API Endpoint |
|-------------|------|--------------|
| Default | `01` | `api-01.moengage.com` |
| DC02 | `02` | `api-02.moengage.com` |
| DC03 | `03` | `api-03.moengage.com` |
| DC04 | `04` | `api-04.moengage.com` |
| DC05 | `05` | `api-05.moengage.com` |
| DC06 | `06` | `api-06.moengage.com` |

!!! tip "Finding Your Data Center"
    Check your MoEngage dashboard URL. If it's `dashboard-02.moengage.com`,
    your data center is `02`.

## Configuration Methods

### Method 1: Environment Variables

```bash
export MOENGAGE_WORKSPACE_ID="your-workspace-id"
export MOENGAGE_CAMPAIGN_REPORTS_API_KEY="your-api-key"
export MOENGAGE_DATA_CENTER="01"
```

### Method 2: .env File

Create a `.env` file in your project:

```ini
MOENGAGE_WORKSPACE_ID=your-workspace-id
MOENGAGE_CAMPAIGN_REPORTS_API_KEY=your-api-key
MOENGAGE_DATA_CENTER=01
```

### Method 3: MCP Client Configuration

See [Integrations](../integrations/claude-desktop.md) for client-specific configuration.

## Security Best Practices

!!! danger "Never Commit Credentials"
    - Add `.env` to your `.gitignore`
    - Never hardcode credentials in code
    - Use environment variables or secrets managers

The server automatically masks credentials in logs:

```
Settings(workspace_id='DMQ6...H1CO', data_center=DC01, api_key='[MASKED]')
```
