"""TXT writer (MVP skeleton)."""
