"""JSON writer (MVP skeleton)."""
