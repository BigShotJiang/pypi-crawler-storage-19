"""YAML writer (MVP skeleton)."""
