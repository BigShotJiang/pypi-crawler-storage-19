from setuptools import setup, find_packages

setup(
    name="dockopt",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "docker",
        "rich"
    ],
    entry_points={
        "console_scripts": [
            "dockopt=dockopt.cli:main"
        ]
    },
    author="Jay Parmar",
    description="Language-aware Docker Image Optimizer for DevOps engineers",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    license="MIT",
    python_requires=">=3.9",
)
