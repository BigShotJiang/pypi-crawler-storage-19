from pathlib import Path
from rich.console import Console

console = Console()

# -------------------------------------------------
# Language Detection
# -------------------------------------------------
def detect_language(dockerfile_content: str, context: Path) -> str:
    c = dockerfile_content.lower()

    if "jenkins" in c:
        return "system"

    if "pip install" in c or "python" in c or (context / "requirements.txt").exists():
        return "python"

    if "npm install" in c or "node" in c or (context / "package.json").exists():
        return "node"

    if "cargo build" in c or (context / "Cargo.toml").exists():
        return "rust"

    if "go build" in c or (context / "go.mod").exists():
        return "go"

    if "mvn" in c or "gradle" in c or ".jar" in c:
        return "java"

    if "composer" in c or (context / "composer.json").exists():
        return "php"

    if "dotnet" in c or any(context.glob("*.csproj")):
        return "dotnet"

    if "bundle install" in c or (context / "Gemfile").exists():
        return "ruby"

    if (context / "index.html").exists():
        return "static"

    return "unknown"


# -------------------------------------------------
# Optimized Dockerfile Templates
# -------------------------------------------------
def python():
    return """
FROM python:3.12-slim AS builder
WORKDIR /app

COPY requirements.txt ./ 2>/dev/null || true
RUN if [ -f requirements.txt ]; then \
    pip install --no-cache-dir --prefix=/install -r requirements.txt; \
fi

FROM python:3.12-slim
WORKDIR /app

COPY --from=builder /install /usr/local
COPY . .

CMD ["python", "-c", "print('Docker Optimizer Test')"]
""".strip()


def node():
    return """
FROM node:18-alpine AS builder
WORKDIR /app

COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build

FROM node:18-alpine
WORKDIR /app

COPY --from=builder /app .
CMD ["npm", "start"]
""".strip()


def rust():
    return """
FROM rust:1.81 AS builder
WORKDIR /app

COPY Cargo.toml Cargo.lock ./
RUN mkdir src && echo "fn main() {}" > src/main.rs
RUN cargo build --release
RUN rm -rf src

COPY src ./src
RUN cargo build --release

FROM debian:bookworm-slim
COPY --from=builder /app/target/release /usr/local/bin
CMD ["sh"]
""".strip()


def go():
    return """
FROM golang:1.23 AS builder
WORKDIR /app

COPY go.mod go.sum ./
RUN go mod download

COPY . .
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o app

FROM gcr.io/distroless/base-debian12
WORKDIR /app

COPY --from=builder /app/app .
CMD ["./app"]
""".strip()


def java():
    return """
FROM maven:3.9-eclipse-temurin-21 AS builder
WORKDIR /app

COPY pom.xml .
RUN mvn dependency:go-offline

COPY src ./src
RUN mvn package -DskipTests

FROM eclipse-temurin:21-jre
WORKDIR /app

COPY --from=builder /app/target/*.jar app.jar
CMD ["java", "-jar", "app.jar"]
""".strip()


def php():
    return """
FROM composer:2 AS builder
WORKDIR /app

COPY composer.json composer.lock ./
RUN composer install --no-dev --optimize-autoloader

COPY . .

FROM php:8.3-fpm-alpine
WORKDIR /var/www/html

COPY --from=builder /app .
RUN chown -R www-data:www-data .

CMD ["php-fpm"]
""".strip()


def dotnet():
    return """
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS builder
WORKDIR /app

COPY *.csproj ./
RUN dotnet restore

COPY . .
RUN dotnet publish -c Release -o out

FROM mcr.microsoft.com/dotnet/aspnet:8.0
WORKDIR /app

COPY --from=builder /app/out .
ENTRYPOINT ["dotnet", "app.dll"]
""".strip()


def ruby():
    return """
FROM ruby:3.3-alpine AS builder
WORKDIR /app

COPY Gemfile Gemfile.lock ./
RUN bundle install

COPY . .

FROM ruby:3.3-alpine
WORKDIR /app

COPY --from=builder /app .
CMD ["bundle", "exec", "rails", "server", "-b", "0.0.0.0"]
""".strip()


def static_site():
    return """
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
""".strip()


# -------------------------------------------------
# Main Generator (FIXED SIGNATURE)
# -------------------------------------------------
def generate_multistage(dockerfile_path, lang_override=None):
    dockerfile = Path(dockerfile_path)

    if not dockerfile.exists():
        console.print(f"[red]❌ Dockerfile not found: {dockerfile}[/red]")
        return

    context = dockerfile.parent
    content = dockerfile.read_text()

    detected_lang = detect_language(content, context)
    lang = lang_override.lower() if lang_override else detected_lang

    console.print(f"\n🧠 Detected language: [cyan]{detected_lang.upper()}[/cyan]")
    if lang_override:
        console.print(f"🔧 Language override applied: [green]{lang.upper()}[/green]\n")
    else:
        console.print("")

    templates = {
        "python": python,
        "node": node,
        "rust": rust,
        "go": go,
        "java": java,
        "php": php,
        "dotnet": dotnet,
        "ruby": ruby,
        "static": static_site,
    }

    if lang not in templates:
        console.print("[yellow]⚠ Optimization skipped (system or unknown image)[/yellow]")
        return

    Path("Dockerfile.optimized").write_text(templates[lang]())
    console.print("[green]✔ Dockerfile.optimized generated successfully[/green]\n")
