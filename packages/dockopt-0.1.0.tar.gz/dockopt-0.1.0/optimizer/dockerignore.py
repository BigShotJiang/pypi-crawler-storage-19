from pathlib import Path
from rich.console import Console

console = Console()

COMMON_IGNORES = [
    ".git",
    ".gitignore",
    "node_modules",
    "__pycache__",
    "*.log",
    "*.env",
    "tests",
    "docs",
    ".idea",
    ".vscode",
]

def generate_dockerignore():
    path = Path(".dockerignore")

    if path.exists():
        console.print("[yellow]⚠ .dockerignore already exists[/yellow]")
        return

    path.write_text("\n".join(COMMON_IGNORES))
    console.print("[green]✔ .dockerignore generated[/green]")
