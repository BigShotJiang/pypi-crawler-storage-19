import subprocess
import docker
from pathlib import Path
from rich.console import Console
from reports.html_report import generate_html

console = Console()


def build_image(tag, dockerfile):
    """
    Build Docker image safely and return True/False
    """
    cmd = [
        "docker", "build",
        "-f", dockerfile,
        "-t", tag,
        "."
    ]

    result = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )

    if result.returncode != 0:
        console.print(f"\n[red]❌ Docker build failed for image: {tag}[/red]\n")
        console.print(result.stdout, markup=False)
        return False

    return True


def image_size_mb(client, tag):
    """
    Get Docker image size in MB
    """
    image = client.images.get(tag)
    return image.attrs["Size"] / (1024 * 1024)


def cleanup_images(client):
    """
    Remove temporary images safely
    """
    for tag in ["dockopt:original", "dockopt:optimized"]:
        try:
            client.images.remove(tag, force=True)
        except Exception:
            pass


def compare_images(dockerfile, ci_mode=False):
    dockerfile = Path(dockerfile)

    if not dockerfile.exists():
        console.print(f"[red]❌ Dockerfile not found: {dockerfile}[/red]")
        return

    optimized = Path("Dockerfile.optimized")
    if not optimized.exists():
        console.print("[yellow]⚠ Optimized Dockerfile not found. Run optimize first.[/yellow]")
        return

    client = docker.from_env()

    # -----------------------------
    # Build Original Image
    # -----------------------------
    console.print("\n⚙ Building original image...")
    if not build_image("dockopt:original", str(dockerfile)):
        console.print("[red]❌ Comparison aborted (original build failed)[/red]")
        return

    # -----------------------------
    # Build Optimized Image
    # -----------------------------
    console.print("\n⚙ Building optimized image...")
    if not build_image("dockopt:optimized", "Dockerfile.optimized"):
        console.print("[red]❌ Comparison aborted (optimized build failed)[/red]")
        cleanup_images(client)
        return

    # -----------------------------
    # Size Comparison
    # -----------------------------
    original_size = image_size_mb(client, "dockopt:original")
    optimized_size = image_size_mb(client, "dockopt:optimized")

    reduction = original_size - optimized_size
    percent = (reduction / original_size) * 100 if original_size > 0 else 0

    console.print("\n📊 Image Size Comparison\n")
    console.print(f"📦 Original Image:   {original_size:.2f} MB")
    console.print(f"📦 Optimized Image:  {optimized_size:.2f} MB")
    console.print(f"📉 Reduced By:       {reduction:.2f} MB ({percent:.1f}%)")

    if percent >= 40:
        console.print("[green]✅ Excellent optimization[/green]")
    elif percent >= 20:
        console.print("[yellow]⚠ Moderate optimization[/yellow]")
    else:
        console.print("[red]❌ Low optimization[/red]")

    # -----------------------------
    # Generate HTML Report
    # -----------------------------
    generate_html(original_size, optimized_size, percent)
    console.print("\n📄 HTML report generated: report.html")

    # -----------------------------
    # CI Quality Gate
    # -----------------------------
    if ci_mode:
        console.print("\n🔒 CI Mode Enabled")
        if percent < 20:
            console.print("[red]❌ CI FAIL: Optimization below 20%[/red]")
            cleanup_images(client)
            exit(1)
        else:
            console.print("[green]✅ CI PASS[/green]")

    # -----------------------------
    # Cleanup
    # -----------------------------
    console.print("\n🧹 Cleaning up temporary images...")
    cleanup_images(client)

    console.print("\n✅ Comparison complete\n")
