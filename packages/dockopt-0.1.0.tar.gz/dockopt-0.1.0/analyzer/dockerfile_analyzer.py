from rich import print
from pathlib import Path

BAD_PRACTICES = [
    ("FROM .*:latest", "Avoid using latest tag"),
    ("RUN apt-get update", "Combine apt commands and clean cache"),
    ("COPY . .", "Copy only required files"),
]

def analyze_dockerfile(path):
    dockerfile = Path(path)

    print(f"\n📄 Analyzing Dockerfile: {path}\n")

    if not dockerfile.exists():
        print(f"[red]❌ Dockerfile not found: {path}[/red]")
        print("[yellow]Tip:[/yellow] Use `dockopt image <image_name>` to analyze Docker images")
        return

    if not dockerfile.is_file():
        print(f"[red]❌ Provided path is not a file: {path}[/red]")
        return

    content = dockerfile.read_text()

    for rule, msg in BAD_PRACTICES:
        keyword = rule.replace(".*", "")
        if keyword in content:
            print(f"[yellow]⚠ {msg}[/yellow]")

    if not Path(".dockerignore").exists():
        print("[red]❌ .dockerignore missing[/red]")

    print("\n✅ Dockerfile analysis complete\n")
