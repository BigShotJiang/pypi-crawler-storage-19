import docker
from rich.console import Console

console = Console()

def analyze_image(image_name):
    client = docker.from_env()

    console.print(f"\n🔍 Analyzing Image: {image_name}\n")

    try:
        image = client.images.get(image_name)
    except docker.errors.ImageNotFound:
        console.print(f"[red]❌ Image not found: {image_name}[/red]")
        return

    size_mb = image.attrs["Size"] / (1024 * 1024)
    console.print(f"📦 Image Size: {size_mb:.2f} MB\n")

    history = image.history()

    console.print("🧱 Layer Breakdown:")

    for layer in history:
        layer_size = layer.get("Size", 0) / (1024 * 1024)
        cmd = layer.get("CreatedBy", "").strip()

        # Safely truncate long commands
        if len(cmd) > 80:
            cmd = cmd[:77] + "..."

        # IMPORTANT: markup=False to avoid Rich parsing errors
        console.print(
            f"  - {layer_size:.2f} MB | {cmd}",
            markup=False
        )

    console.print("\n✅ Image analysis complete\n")
