import argparse
from analyzer.dockerfile_analyzer import analyze_dockerfile
from analyzer.image_analyzer import analyze_image
from optimizer.multistage import generate_multistage
from optimizer.compare import compare_images

def main():
    parser = argparse.ArgumentParser(description="🚀 DockOpt – Docker Image Optimizer")
    sub = parser.add_subparsers(dest="command")

    a = sub.add_parser("analyze")
    a.add_argument("dockerfile")

    i = sub.add_parser("image")
    i.add_argument("image")

    o = sub.add_parser("optimize")
    o.add_argument("dockerfile")
    o.add_argument("--lang", help="Override language detection")

    c = sub.add_parser("compare")
    c.add_argument("dockerfile")
    c.add_argument("--ci", action="store_true", help="CI quality gate")

    args = parser.parse_args()

    if args.command == "analyze":
        analyze_dockerfile(args.dockerfile)

    elif args.command == "image":
        analyze_image(args.image)

    elif args.command == "optimize":
        generate_multistage(args.dockerfile, args.lang)

    elif args.command == "compare":
        compare_images(args.dockerfile, ci_mode=args.ci)

    else:
        parser.print_help()

if __name__ == "__main__":
    main()
