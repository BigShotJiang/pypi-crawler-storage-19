# DockOpt 🚀
A language-aware Docker Image Optimizer for DevOps engineers.

## Features
- Multi-language Dockerfile optimization
- Python, Node, Rust, Go, Java, PHP, .NET, Ruby, Static sites
- Image size comparison (before vs after)
- CI quality gates
- HTML optimization report
- Safe handling of system images (Jenkins)

## Installation
```bash
pip install dockopt


dockopt analyze Dockerfile
dockopt optimize Dockerfile
dockopt compare Dockerfile
dockopt compare Dockerfile --ci
