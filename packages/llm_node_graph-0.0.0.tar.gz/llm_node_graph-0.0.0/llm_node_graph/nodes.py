

from abc import ABC, abstractmethod


class Node(ABC):
    
    @abstractmethod
    def process(self, *args, **kwargs):
        pass