from abc import ABC
from .nodes import GraphNode
from .edges import GraphEdge


class Graph(ABC):
    
    nodes: list[GraphNode]
    edges: list[GraphEdge]
    start_node: GraphNode

    def __init__(self, nodes: list[GraphNode], edges: list[GraphEdge]) -> None:
        super().__init__()

        self.nodes = nodes
        self.edges = edges
        self.start_node = nodes[0] if nodes else None