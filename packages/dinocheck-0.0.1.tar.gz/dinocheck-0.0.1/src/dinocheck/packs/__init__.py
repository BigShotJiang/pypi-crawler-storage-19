"""Rule packs for Dinocheck."""
