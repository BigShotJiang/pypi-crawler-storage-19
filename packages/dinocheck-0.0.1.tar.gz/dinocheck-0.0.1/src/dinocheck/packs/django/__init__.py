"""Django framework pack."""
