"""LLM integration for Dinocheck."""
