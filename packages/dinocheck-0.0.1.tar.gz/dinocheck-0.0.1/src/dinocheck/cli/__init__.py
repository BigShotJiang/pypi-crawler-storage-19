"""CLI module for Dinocheck."""
