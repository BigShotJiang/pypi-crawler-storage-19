"""
Test: Get RLE statistics for deltars.summary table
"""

import sys
from pathlib import Path

# Add parent directory to path to import duckrun
sys.path.insert(0, str(Path(__file__).parent.parent))

import duckrun

# Connect to lakehouse
con = duckrun.connect("tmp/data.lakehouse/deltars")

# Get RLE stats for deltars.summary
rle_df = con.get_rle('summary')

print("\n" + "=" * 80)
print("RESULTS")
print("=" * 80)
print(rle_df.to_string(index=False))
