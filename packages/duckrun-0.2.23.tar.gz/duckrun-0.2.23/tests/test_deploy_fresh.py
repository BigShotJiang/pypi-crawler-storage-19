import sys
sys.path.insert(0, 'c:\\Users\\mdjouallah\\duckrun')

import duckrun

# Connect to workspace
con = duckrun.connect('external/external.lakehouse/dbo')

# Deploy PBIX - should use "report" as the name (from report.pbix filename)
pbix_url = "https://github.com/djouallah/Fabric_Notebooks_Demo/raw/refs/heads/main/googleanalytics/report.pbix"
semantic_model_name = "final"

result = con.deploy_pbix(
    pbix_url=pbix_url,
    semantic_model_name=semantic_model_name
)

print(f"\nResult: {'Success' if result == 1 else 'Failed'}")
