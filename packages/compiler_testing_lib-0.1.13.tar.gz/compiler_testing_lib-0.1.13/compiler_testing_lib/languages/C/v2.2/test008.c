// Invalid token @
int g = @;