// Missing CLOSE_PAR
int i = (7;