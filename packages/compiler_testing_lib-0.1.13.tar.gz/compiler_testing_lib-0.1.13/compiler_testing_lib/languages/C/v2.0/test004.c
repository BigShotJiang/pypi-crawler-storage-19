// Unexpected token EOL
v = ;