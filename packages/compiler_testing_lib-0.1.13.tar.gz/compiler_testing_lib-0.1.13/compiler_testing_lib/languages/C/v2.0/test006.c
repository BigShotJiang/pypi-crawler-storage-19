// Unexpected token EOL
r = -;