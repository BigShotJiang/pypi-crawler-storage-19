// Unexpected token DIV
s = /;