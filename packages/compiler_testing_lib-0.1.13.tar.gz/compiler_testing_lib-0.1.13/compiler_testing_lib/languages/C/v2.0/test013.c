// Unexpected token MULT
h = *;