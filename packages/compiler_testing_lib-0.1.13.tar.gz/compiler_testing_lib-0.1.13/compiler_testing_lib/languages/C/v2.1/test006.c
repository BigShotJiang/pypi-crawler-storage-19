// Unexpected token EOL
m = -;