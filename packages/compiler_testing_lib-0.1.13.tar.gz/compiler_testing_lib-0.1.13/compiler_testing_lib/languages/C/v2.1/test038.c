// Missing OPEN_BRA
m = 1;
if (m == 1)
  m = 2;
}