// Unexpected token EOL
y = +;