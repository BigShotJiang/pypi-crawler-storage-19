// Invalid token @
u = @;