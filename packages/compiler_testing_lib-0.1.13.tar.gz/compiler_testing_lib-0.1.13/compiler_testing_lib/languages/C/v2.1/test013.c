// Unexpected token MULT
t = *;