main() {
  // Missing function type
}
