void main() {
  // Unexpected EOF
  str t = "a;
}
