void main() {
  // Missing OPEN_BRA
  int e = 1;
  if (e == 1) {
    e = 2;
  } else
    e = 3;
  }
}
