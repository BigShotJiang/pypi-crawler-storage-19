void main() {
  // Unexpected token EOF (expected CLOSE_BRA)
  int w = 5;
