"""CLI Package Initialization"""

__version__ = "1.0.0"
__author__ = "ArionXiv Team"
