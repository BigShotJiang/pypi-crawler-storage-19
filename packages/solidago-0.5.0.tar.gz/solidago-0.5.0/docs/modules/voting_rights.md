::: solidago.voting_rights

