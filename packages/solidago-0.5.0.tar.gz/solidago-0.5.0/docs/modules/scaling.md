::: solidago.scaling
