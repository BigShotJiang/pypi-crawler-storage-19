from __future__ import annotations

import importlib
import warnings
from typing import TYPE_CHECKING, Any, cast, get_args, overload

import numpy as np
import pandas as pd
import pgtrigger
from django.conf import settings as django_settings
from django.db import connection, models
from django.db.models import CASCADE, PROTECT
from django.db.models.query_utils import DeferredAttribute
from django.db.utils import IntegrityError as DjangoIntegrityError
from lamin_utils import logger
from lamindb_setup._init_instance import get_schema_module_name
from lamindb_setup.core import deprecated
from lamindb_setup.core.hashing import HASH_LENGTH, hash_dict, hash_string
from lamindb_setup.errors import (
    MODULE_WASNT_CONFIGURED_MESSAGE_TEMPLATE,
    ModuleWasntConfigured,
)
from pandas.api.types import CategoricalDtype, is_string_dtype
from pandas.core.dtypes.base import ExtensionDtype

from lamindb.base.fields import (
    BooleanField,
    CharField,
    ForeignKey,
    JSONField,
    TextField,
)
from lamindb.base.types import Dtype, FieldAttr
from lamindb.errors import (
    FieldValidationError,
    IntegrityError,
    InvalidArgument,
    ValidationError,
)

from ..base.uids import base62_12
from ._relations import dict_module_name_to_model_name
from .can_curate import CanCurate
from .has_parents import _query_relatives
from .query_set import QuerySet, SQLRecordList
from .run import (
    TracksRun,
    TracksUpdates,
)
from .sqlrecord import BaseSQLRecord, HasType, Registry, SQLRecord, _get_record_kwargs

if TYPE_CHECKING:
    from collections.abc import Iterable

    from .artifact import Artifact
    from .block import FeatureBlock
    from .projects import Project
    from .run import Run
    from .schema import Schema

FEATURE_DTYPES = set(get_args(Dtype))


def parse_dtype(
    dtype_str: str, check_exists: bool = False, old_format: bool = False
) -> list[dict[str, Any]]:
    """Parses feature data type string into a structured list of components."""
    from .artifact import Artifact

    allowed_dtypes = FEATURE_DTYPES

    # Handle list[...] types
    if dtype_str.startswith("list[") and dtype_str.endswith("]"):
        inner_dtype_str = dtype_str[5:-1]  # Remove "list[" and "]"
        # Recursively parse the inner type
        inner_result = parse_dtype(inner_dtype_str, old_format=old_format)
        # Add "list": True to each component
        for component in inner_result:
            if isinstance(component, dict):
                component["list"] = True  # type: ignore
        return inner_result

    is_composed_cat = dtype_str.startswith("cat[") and dtype_str.endswith("]")
    result: list[dict[str, Any]] = []
    # backward compatibility for bare "cat" dtype (deprecated)
    if dtype_str == "cat":
        return result
    if is_composed_cat:
        related_registries = dict_module_name_to_model_name(Artifact)
        registries_str = dtype_str.replace("cat[", "")[:-1]  # strip last ]
        if registries_str != "":
            registry_str_list = registries_str.split("|")
            for cat_single_dtype_str in registry_str_list:
                single_result = parse_cat_dtype(
                    cat_single_dtype_str,
                    related_registries=related_registries,
                    check_exists=check_exists,
                    old_format=old_format,
                )
                result.append(single_result)
    elif dtype_str not in allowed_dtypes:
        raise ValueError(
            f"dtype is '{dtype_str}' but has to be one of {FEATURE_DTYPES}!"
        )
    return result


def get_record_type_from_uid(
    registry: Registry,
    record_uid: str,
) -> SQLRecord:
    type_record: SQLRecord = registry.get(record_uid)

    if type_record.branch_id == -1:
        warning_msg = f"retrieving {registry.__name__} type '{type_record.name}' (uid='{record_uid}') from trash"
        logger.warning(warning_msg)

    if not type_record.is_type:
        raise InvalidArgument(
            f"The resolved {type_record.__class__.__name__} '{type_record.name}' (uid='{record_uid}') is not a type: is_type is False."
        )
    return type_record


def get_record_type_from_nested_subtypes(
    registry: Registry, subtypes_list: list[str], field_str: str
) -> SQLRecord:
    """Get a record type by querying nested subtypes using raw SQL.

    This function only works with Record or ULabel registries.
    """
    table_name = registry._meta.db_table
    final_name = subtypes_list[-1]

    # Build the SQL query with nested joins
    # For subtypes_list = ["A", "B", "C"], we want:
    # - Record with name="C"
    # - Its type has name="B"
    # - That type's type has name="A"

    params: list[str | bool]
    if len(subtypes_list) > 1:
        # Build nested joins for parent types
        parent_types = list(reversed(subtypes_list[:-1]))
        joins = []
        where_clauses = ["t0.name = %s"]  # Final record name
        params = [final_name]

        for i, parent_type_name in enumerate(parent_types):
            alias = f"t{i + 1}"
            prev_alias = f"t{i}"
            joins.append(
                f"INNER JOIN {table_name} {alias} ON {prev_alias}.type_id = {alias}.id"
            )
            where_clauses.append(f"{alias}.name = %s")
            where_clauses.append(f"{alias}.is_type = %s")
            params.extend([parent_type_name, True])

        join_clause = " ".join(joins)
        where_clause = " AND ".join(where_clauses)

        query = f"""
            SELECT t0.*
            FROM {table_name} t0
            {join_clause}
            WHERE {where_clause}
            LIMIT 1
        """
    else:
        # Single type, no parent - type must be NULL
        query = f"""
            SELECT *
            FROM {table_name}
            WHERE name = %s AND type_id IS NULL
            LIMIT 1
        """
        params = [final_name]

    try:
        with connection.cursor() as cursor:
            cursor.execute(query, params)
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()

            if not rows:
                raise IntegrityError(
                    f"No {registry.__name__} type found matching subtypes {subtypes_list} for field `.{field_str}`"
                )

            if len(rows) > 1:
                raise IntegrityError(
                    f"Multiple {registry.__name__} types found matching subtypes {subtypes_list} for field `.{field_str}`"
                )

            # Create a dictionary from the row data
            row_dict = dict(zip(columns, rows[0]))

            # Create a minimal mock object with only the fields we need
            # This avoids querying the database which may not have all columns during migrations
            # We create a simple object and set its class to the registry for proper error messages
            type_record: SQLRecord = object.__new__(registry)
            type_record.id = row_dict.get("id")
            type_record.uid = row_dict.get("uid")
            type_record.name = row_dict.get("name")
            type_record.is_type = row_dict.get("is_type", False)
            # Initialize _state attribute needed by Django models
            # Create a minimal state object with the required attributes
            state = type("ModelState", (), {"adding": False, "db": "default"})()
            type_record._state = state

    except IntegrityError:
        raise
    except Exception as e:
        raise IntegrityError(
            f"Error retrieving {registry.__name__} type with subtypes {subtypes_list} for field `.{field_str}`: {e}"
        ) from e

    if not type_record.is_type:
        raise InvalidArgument(
            f"The resolved {type_record.__class__.__name__} '{type_record.name}' for field `.{field_str}` is not a type: is_type is False."
        )
    return type_record


def dtype_as_object(dtype_str: str, old_format: bool = False) -> type | None:
    def _dtype_as_object_simple(dtype_str: str) -> type | None:
        if dtype_str == "str":
            return str
        elif dtype_str == "int":
            return int
        elif dtype_str in ("float", "num"):
            return float
        elif dtype_str == "bool":
            return bool
        elif dtype_str == "date":
            from datetime import date

            return date
        elif dtype_str == "datetime":
            from datetime import datetime

            return datetime
        elif dtype_str.startswith("dict"):
            return dict
        return None

    if dtype_str is None:
        return None

    parsed_dtypes = parse_dtype(dtype_str, check_exists=True, old_format=old_format)
    if len(parsed_dtypes) > 0:
        dtype_objects = []
        for parsed_dtype in parsed_dtypes:
            if parsed_dtype.get("record_uid"):
                # return the subtype record for dtypes with record_uid
                dtype_object = get_record_type_from_uid(
                    parsed_dtype["registry"],
                    parsed_dtype["record_uid"],
                )
            elif parsed_dtype.get("subtypes_list"):
                dtype_object = get_record_type_from_nested_subtypes(
                    parsed_dtype["registry"],
                    parsed_dtype["subtypes_list"],
                    parsed_dtype["field"],
                )
            else:
                # return field for dtypes without record_uid, e.g. bt.CellType.ontology_id
                dtype_object = parsed_dtype["field"]
            # for list, returns list[SQLRecord]
            dtype_objects.append(
                list[dtype_object]  # type: ignore
                if "list" in parsed_dtype and parsed_dtype["list"]
                else dtype_object
            )
        return dtype_objects if len(dtype_objects) > 1 else dtype_objects[0]  # type: ignore
    elif dtype_str.startswith("list["):
        # for simple lists, returns list[python_type]
        dtype_simple_object = _dtype_as_object_simple(
            dtype_str.removeprefix("list[").removesuffix("]")
        )
        return (
            list[dtype_simple_object] if dtype_simple_object is not None else list  # type: ignore
        )
    else:
        return _dtype_as_object_simple(dtype_str)


def parse_cat_dtype(
    dtype_str: str,
    related_registries: dict[str, SQLRecord] | None = None,
    is_itype: bool = False,
    check_exists: bool = False,
    old_format: bool = False,
) -> dict[str, Any]:
    """Parses a categorical dtype string into its components (registry, field, subtypes)."""
    from .artifact import Artifact

    assert isinstance(dtype_str, str)  # noqa: S101
    if related_registries is None:
        related_registries = dict_module_name_to_model_name(Artifact)

    # Parse the string considering nested brackets
    parsed = parse_nested_brackets(dtype_str, old_format=old_format)
    registry_str = parsed["registry"]
    filter_str = parsed["filter_str"]
    field_str = parsed["field"]

    if not is_itype:
        if registry_str not in related_registries:
            raise ValidationError(
                f"'{registry_str}' is an invalid dtype, has to be registry, e.g. ULabel or bionty.CellType"
            )
        registry = related_registries[registry_str]
    else:
        if "." in registry_str:
            registry_str_split = registry_str.split(".")
            assert len(registry_str_split) == 2, registry_str  # noqa: S101
            module_name_attempt, class_name = registry_str_split
            module_name = get_schema_module_name(
                module_name_attempt, raise_import_error=False
            )
            if module_name is None:
                raise ModuleWasntConfigured(
                    MODULE_WASNT_CONFIGURED_MESSAGE_TEMPLATE.format(module_name_attempt)
                )
        else:
            module_name, class_name = "lamindb", registry_str
        module = importlib.import_module(module_name)
        registry = getattr(module, class_name)

    if field_str == "":
        field_str = registry._name_field if hasattr(registry, "_name_field") else "name"
    assert hasattr(registry, field_str), f"{registry} has no field {field_str}"

    record_uid = parsed.get("record_uid")
    subtypes_list = parsed.get("subtypes_list")

    # Handle old format (subtypes_list) or new format (record_uid)
    if subtypes_list and check_exists:
        # Old format: validate that the Record exists using nested subtypes
        # subtypes_list is guaranteed to be list[str] when present
        if isinstance(subtypes_list, list):
            get_record_type_from_nested_subtypes(
                registry, cast(list[str], subtypes_list), field_str
            )
    elif record_uid and check_exists:
        get_record_type_from_uid(registry, record_uid)

    if filter_str != "":
        # TODO: validate or process filter string
        pass
    result = {
        "registry": registry,  # should be typed as CanCurate
        "registry_str": registry_str,
        "filter_str": filter_str,
        "field_str": field_str,
        "field": getattr(registry, field_str),
    }

    # Add record_uid if it exists (new format)
    if record_uid:
        result["record_uid"] = record_uid

    # Add subtypes_list if it exists (old format)
    if subtypes_list:
        result["subtypes_list"] = subtypes_list

    return result


def parse_nested_brackets(dtype_str: str, old_format: bool = False) -> dict[str, Any]:
    """Parse dtype string with potentially nested brackets.

    Examples:
        "A" -> {"registry": "A", "filter_str": "", "field": ""}
        "A.field" -> {"registry": "A", "filter_str": "", "field": "field"}
        "Record[abcdefg123456]" -> {"registry": "Record", "filter_str": "", "field": "", "record_uid": "abcdefg123456"}
        "Record[abcdefg123456].name" -> {"registry": "Record", "filter_str": "", "field": "name", "record_uid": "abcdefg123456"}
        "bionty.Gene.ensembl_gene_id[source__id='abcd']" -> {"registry": "bionty.Gene", "filter_str": "source__id='abcd'", "field": "ensembl_gene_id"}

    Args:
        dtype_str: The dtype string to parse

    Returns:
        Dictionary with parsed components
    """
    if "[" not in dtype_str:
        # No brackets - handle simple cases like "A" or "A.field"
        if "." in dtype_str:
            parts = dtype_str.split(".")
            if len(parts) == 2 and parts[1][0].isupper():
                # bionty.CellType
                return {"registry": dtype_str, "filter_str": "", "field": ""}
            elif len(parts) == 3:
                # bionty.CellType.name
                return {
                    "registry": f"{parts[0]}.{parts[1]}",
                    "filter_str": "",
                    "field": parts[2],
                }
            else:
                # ULabel.name
                return {"registry": parts[0], "filter_str": "", "field": parts[1]}
        else:
            # Simple registry name
            return {"registry": dtype_str, "filter_str": "", "field": ""}

    # Find the first opening bracket
    first_bracket = dtype_str.index("[")
    # Handle case where registry_part contains a field (e.g., "bionty.Gene.ensembl_gene_id[filters]")
    registry_and_field = dtype_str[:first_bracket]
    if "." in registry_and_field:
        parts = registry_and_field.split(".")
        if len(parts) == 3:
            registry_part = f"{parts[0]}.{parts[1]}"
            pre_bracket_field = parts[2]
        else:
            registry_part = registry_and_field
            pre_bracket_field = ""
    else:
        registry_part = registry_and_field
        pre_bracket_field = ""

    # Find the matching closing bracket for the first opening bracket
    bracket_count = 0
    closing_bracket_pos = -1

    for i in range(first_bracket, len(dtype_str)):
        if dtype_str[i] == "[":
            bracket_count += 1
        elif dtype_str[i] == "]":
            bracket_count -= 1
            if bracket_count == 0:
                closing_bracket_pos = i
                break

    if closing_bracket_pos == -1:
        raise ValueError(f"Unmatched brackets in dtype string: {dtype_str}")

    # Extract content between brackets
    bracket_content = dtype_str[first_bracket + 1 : closing_bracket_pos]

    # Check for field after the closing bracket
    field_part = ""
    remainder = dtype_str[closing_bracket_pos + 1 :]
    if remainder.startswith("."):
        field_part = remainder[1:]  # Remove the dot

    # Use pre_bracket_field if no post_bracket field
    if not field_part and pre_bracket_field:
        field_part = pre_bracket_field

    # Extract UID, subtypes_list, or filter from bracket content
    # For UID-based format: Record[uid] or ULabel[uid] -> record_uid
    # For old name-based format: Record[Name] or Record[Parent[Child]] -> subtypes_list
    # For filter format: registry.field[filter] -> filter_str
    record_uid = None
    subtypes_list = None
    filter_str = ""

    # If registry is Record or ULabel, bracket content could be UID or name(s)
    if registry_part in ("Record", "ULabel"):
        if bracket_content:
            if old_format:
                # Old format with nested brackets like Record[Parent[Child]]
                extracted = extract_subtypes_and_filter(bracket_content)
                subtypes_list = extracted["subtypes_list"]
                filter_str = extracted["filter_str"]
            else:
                record_uid = bracket_content
    else:
        # For other registries, bracket content is a filter
        filter_str = bracket_content if bracket_content else ""

    result = {
        "registry": registry_part,
        "filter_str": filter_str,
        "field": field_part,
    }

    # Add record_uid if it exists (new format)
    if record_uid:
        result["record_uid"] = record_uid

    # Add subtypes_list if it exists (old format)
    if subtypes_list:
        result["subtypes_list"] = subtypes_list

    return result


def extract_subtypes_and_filter(subtype_str: str) -> dict[str, Any]:
    """Extract nested subtypes and optional filter from a nested subtype string.

    Examples:
        "B" -> {"subtypes_list": ["B"], "filter_str": ""}
        "B[C]" -> {"subtypes_list": ["B", "C"], "filter_str": ""}
        "B[C[filter='<value>']]" -> {"subtypes_list": ["B", "C"], "filter_str": "filter='<value>'"}
        "B[C[D]]" -> {"subtypes_list": ["B", "C", "D"], "filter_str": ""}
        "B[C[D[E]]]" -> {"subtypes_list": ["B", "C", "D", "E"], "filter_str": ""}
        "B[filter='value']" -> {"subtypes_list": ["B"], "filter_str": "filter='value'"}
        "Customer[UScustomer[region='US']]" -> {"subtypes_list": ["Customer", "UScustomer"], "filter_str": "region='US'"}

    Args:
        subtype_str: The subtype string with potential nesting

    Returns:
        Dictionary with subtypes_list and filter_str
    """
    subtypes: list[str] = []
    filter_str = ""
    current = subtype_str

    while current:
        if "[" not in current:
            # No more brackets
            if current and "=" not in current:
                # It's a subtype name
                subtypes.append(current)
            elif current and "=" in current:
                # It's a filter
                filter_str = current
            break

        # Find the first part before the bracket
        bracket_pos = current.index("[")
        part = current[:bracket_pos]

        # Add the part (it's a subtype name)
        if part:
            subtypes.append(part)

        # Find the matching closing bracket
        bracket_count = 0
        closing_pos = -1

        for i in range(bracket_pos, len(current)):
            if current[i] == "[":
                bracket_count += 1
            elif current[i] == "]":
                bracket_count -= 1
                if bracket_count == 0:
                    closing_pos = i
                    break

        if closing_pos == -1:
            break

        # Move to the content inside the brackets
        current = current[bracket_pos + 1 : closing_pos]

    return {"subtypes_list": subtypes, "filter_str": filter_str}


def serialize_dtype(
    dtype: Registry
    | SQLRecord
    | FieldAttr
    | list[SQLRecord]
    | list[Registry]
    | list[str]
    | list[float]
    | str
    | type,
    is_itype: bool = False,
) -> str:
    """Converts a data type object into its string representation."""
    from .record import Record
    from .ulabel import ULabel

    # Handle generic types like list[str], list[Registry], etc.
    if hasattr(dtype, "__origin__") and dtype.__origin__ is list:
        # Get the inner type from list[T]
        inner_type = dtype.__args__[0] if dtype.__args__ else None  # type: ignore
        if inner_type is not None:
            # Recursively serialize the inner type
            inner_dtype_str = serialize_dtype(inner_type, is_itype=is_itype)
            return f"list[{inner_dtype_str}]"

    if (
        not isinstance(dtype, list)
        and hasattr(dtype, "__name__")
        and dtype.__name__ in FEATURE_DTYPES
    ):
        dtype_str = dtype.__name__
    elif dtype is dict:
        dtype_str = "dict"
    elif is_itype and isinstance(dtype, str):
        if dtype not in "Feature":
            parse_cat_dtype(
                dtype_str=dtype, is_itype=True
            )  # throws an error if invalid
        dtype_str = dtype
    elif isinstance(dtype, (ExtensionDtype, np.dtype)):
        dtype_str = serialize_pandas_dtype(dtype)
    else:
        error_message = "dtype has to be a registry, a ulabel subtype, a registry field, or a list of registries or fields, not {}"
        if isinstance(dtype, (Registry, DeferredAttribute, ULabel, Record)):
            dtype = [dtype]
        elif not isinstance(dtype, list):
            raise ValueError(error_message.format(dtype))
        dtype_str = ""
        for one_dtype in dtype:
            if not isinstance(one_dtype, (Registry, DeferredAttribute, ULabel, Record)):
                raise ValueError(error_message.format(one_dtype))
            if isinstance(one_dtype, Registry):
                dtype_str += one_dtype.__get_name_with_module__() + "|"
            elif isinstance(one_dtype, (ULabel, Record)):
                if one_dtype._state.adding:
                    raise InvalidArgument(
                        f"Cannot serialize unsaved objects. Save {one_dtype} via `.save()`."
                    )
                if not one_dtype.is_type:
                    raise InvalidArgument(
                        f"Cannot serialize non-type {one_dtype.__class__.__name__} '{one_dtype.name}'. Only types (is_type=True) are allowed in dtypes."
                    )
                # Use UID-based format: Record[uid] instead of Record[Parent[Child]]
                nested_string = f"[{one_dtype.uid}]"
                if isinstance(one_dtype, ULabel):
                    dtype_str += f"ULabel{nested_string}"
                else:
                    dtype_str += f"Record{nested_string}"
            else:
                name = one_dtype.field.name
                field_ext = f".{name}" if name != "name" else ""
                dtype_str += (
                    one_dtype.field.model.__get_name_with_module__() + field_ext + "|"
                )
        dtype_str = dtype_str.rstrip("|")
        if not is_itype:
            dtype_str = f"cat[{dtype_str}]"
    return dtype_str


def serialize_pandas_dtype(pandas_dtype: ExtensionDtype) -> str:
    """Convert pandas ExtensionDtype to simplified string representation."""
    if is_string_dtype(pandas_dtype):
        if not isinstance(pandas_dtype, CategoricalDtype):
            dtype = "str"
        else:
            dtype = "cat[ULabel]"
    # there are string-like categoricals and "pure" categoricals (pd.Categorical)
    elif isinstance(pandas_dtype, CategoricalDtype):
        dtype = "cat[ULabel]"
    else:
        # strip precision qualifiers
        dtype = "".join(dt for dt in pandas_dtype.name if not dt.isdigit())
        if dtype == "uint":
            dtype = "int"
    if dtype.startswith("datetime"):
        dtype = dtype.split("[")[0]
    if dtype != "cat[ULabel]":
        assert dtype in FEATURE_DTYPES  # noqa: S101
    return dtype


def convert_to_pandas_dtype(lamin_dtype: str) -> str | CategoricalDtype:
    """Convert LaminDB simplified string representation back to pandas dtype."""
    dtype_map = {
        "str": "string",  # nullable string dtype
        "int": "Int64",  # Nullable integer to handle missing values
        "num": "float64",
        "float": "float64",
        "bool": "boolean",  # Nullable boolean
        "datetime": "datetime64[ns]",
        "date": "object",  # preserve Date objects
        "dict": "object",  # dicts are stored as object dtype in pandas
    }
    if lamin_dtype in dtype_map:
        return dtype_map[lamin_dtype]
    elif lamin_dtype.startswith("cat"):
        return CategoricalDtype()
    elif lamin_dtype.startswith("list"):
        return "object"  # lists are stored as object dtype in pandas
    return lamin_dtype


def parse_filter_string(filter_str: str) -> dict[str, tuple[str, str | None, str]]:
    """Parse comma-separated Django filter expressions into structured components.

    Args:
        filter_str: Comma-separated filters like 'name=value, relation__field=value'

    Returns:
        Dict mapping original filter key to (relation_name, field_name, value) tuple.
        For direct fields: field_name is None.
        For relations: field_name contains the lookup field.
    """
    filters = {}

    filter_parts = [part.strip() for part in filter_str.split(",")]
    for part in filter_parts:
        if "=" not in part:
            raise ValueError(f"Invalid filter expression: '{part}' (missing '=' sign)")

        key, value = part.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")

        if not key:
            raise ValueError(f"Invalid filter expression: '{part}' (empty key)")
        if not value:
            raise ValueError(f"Invalid filter expression: '{part}' (empty value)")

        if "__" in key:
            relation_name, field_name = key.split("__", 1)
            filters[key] = (relation_name, field_name, value)
        else:
            filters[key] = (key, None, value)

    return filters


def resolve_relation_filters(
    parsed_filters: dict[str, tuple[str, str | None, str]], registry: SQLRecord
) -> dict[str, str | SQLRecord]:
    """Resolve relation filters actual model objects.

    Args:
        parsed_filters: Django filters like output from :func:`lamindb.models.feature.parse_filter_string`
        registry: Model class to resolve relationships against

    Returns:
        Dict with resolved objects for successful relations, original values for direct fields and failed resolutions.
    """
    resolved = {}
    for filter_key, (relation_name, field_name, value) in parsed_filters.items():
        if field_name is not None:  # relation filter
            if hasattr(registry, relation_name):
                relation_field = getattr(registry, relation_name)
                if (
                    hasattr(relation_field, "field")
                    and relation_field.field.is_relation
                ):
                    related_model = relation_field.field.related_model
                    related_obj = related_model.get(**{field_name: value})
                    resolved[relation_name] = related_obj
        else:
            resolved[filter_key] = value
    return resolved


def migrate_dtype_to_uid_format(connection, input_field: str = "_dtype_str") -> None:
    """Update _dtype_str for nested Record/ULabel types to uid format.

    Converts old format (name-based) dtype strings to new UID-based format.
    This function is used in migrations to update existing feature records.

    Args:
        connection: Database connection (from schema_editor.connection)
        input_field: Field name to read from ("_dtype_str" or "dtype")

    Returns:
        None. Updates are performed directly in the database.
    """
    # Patterns to look for old format (name-based)
    patterns = [
        "cat[Record[",
        "cat[ULabel[",
        "list[cat[Record[",
        "list[cat[ULabel[",
    ]

    # Build SQL query to fetch features matching any pattern
    # Using OR conditions for each pattern
    pattern_conditions = " OR ".join(
        [f"{input_field} LIKE '{pattern}%'" for pattern in patterns]
    )

    query = f"""
        SELECT id, uid, name, {input_field}
        FROM lamindb_feature
        WHERE {pattern_conditions}
    """

    # Fetch matching features
    with connection.cursor() as cursor:
        cursor.execute(query)
        columns = [col[0] for col in cursor.description]
        features = [dict(zip(columns, row)) for row in cursor.fetchall()]

    # Convert each feature
    for feature in features:
        try:
            # Convert old format string to objects, then serialize to UID format
            dtype_objects = dtype_as_object(feature[input_field], old_format=True)
            new_dtype_str = serialize_dtype(dtype_objects)

            if new_dtype_str != feature[input_field]:
                # Update using raw SQL
                update_query = """
                    UPDATE lamindb_feature
                    SET _dtype_str = %s
                    WHERE id = %s
                """
                with connection.cursor() as cursor:
                    cursor.execute(update_query, [new_dtype_str, feature["id"]])

        except Exception as e:
            # If conversion fails, keep the original value
            print(
                f"Warning: Could not convert dtype for feature {feature['name']} ({feature['uid']}) because of error: {e}"
            )
            continue


def process_init_feature_param(args, kwargs):
    # now we proceed with the user-facing constructor
    if len(args) != 0:
        raise ValueError("Only keyword args allowed")
    name: str = kwargs.pop("name", None)
    dtype: type | str | None = kwargs.pop("dtype", None)
    is_type: bool = kwargs.pop("is_type", False)
    type_: Feature | str | None = kwargs.pop("type", None)
    description: str | None = kwargs.pop("description", None)
    branch = kwargs.pop("branch", None)
    branch_id = kwargs.pop("branch_id", 1)
    space = kwargs.pop("space", None)
    space_id = kwargs.pop("space_id", 1)
    _skip_validation = kwargs.pop("_skip_validation", False)
    if kwargs:
        valid_keywords = ", ".join([val[0] for val in _get_record_kwargs(Feature)])
        raise FieldValidationError(f"Only {valid_keywords} are valid keyword arguments")
    kwargs["name"] = name
    kwargs["type"] = type_
    kwargs["is_type"] = is_type
    kwargs["branch"] = branch
    kwargs["branch_id"] = branch_id
    kwargs["space"] = space
    kwargs["space_id"] = space_id
    kwargs["_skip_validation"] = _skip_validation
    kwargs["description"] = description
    # cast dtype
    if dtype is None and not is_type:
        raise ValidationError(
            f"Please pass dtype, one of {FEATURE_DTYPES} or a composed categorical dtype"
        )
    dtype_str = None
    if dtype is not None:
        if not isinstance(dtype, str):
            dtype_str = serialize_dtype(dtype)
        elif dtype in {"num", "path"}:
            dtype_str = dtype
        else:
            logger.warning(
                f"rather than passing a string '{dtype}' to dtype, consider passing a Python object"
            )
            dtype_str = dtype
            parse_dtype(dtype_str, check_exists=True, old_format=True)
            if dtype_str.startswith(
                ("cat[Record[", "cat[ULabel[", "list[cat[Record[", "list[cat[ULabel[")
            ):
                # need to convert from old semantic format to new uid-based format
                dtype_str = serialize_dtype(dtype_as_object(dtype_str, old_format=True))
        kwargs["_dtype_str"] = dtype_str
    return kwargs


UPDATE_FEATURE_ON_NAME_CHANGE = """\
DECLARE
    old_renamed JSONB;
    new_renamed JSONB;
    ts TEXT;
BEGIN
    -- Only proceed if name actually changed
    IF OLD.name IS DISTINCT FROM NEW.name THEN
        -- Update synonyms
        IF NEW.synonyms IS NULL OR NEW.synonyms = '' THEN
            NEW.synonyms := OLD.name;
        ELSIF position(OLD.name in NEW.synonyms) = 0 THEN
            NEW.synonyms := NEW.synonyms || '|' || OLD.name;
        END IF;

        -- Update _aux with rename history
        ts := TO_CHAR(NOW() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"');

        -- Get existing renamed history or initialize empty object
        old_renamed := COALESCE((OLD._aux->>'renamed')::JSONB, '{}'::JSONB);

        -- Add old name with timestamp
        new_renamed := old_renamed || jsonb_build_object(ts, OLD.name);

        -- Update _aux with new renamed history
        IF NEW._aux IS NULL THEN
            NEW._aux := jsonb_build_object('renamed', new_renamed);
        ELSE
            NEW._aux := NEW._aux || jsonb_build_object('renamed', new_renamed);
        END IF;
    END IF;

    RETURN NEW;
END;
"""


class Feature(SQLRecord, HasType, CanCurate, TracksRun, TracksUpdates):
    """Dimensions of measurement such as dataframe columns or dictionary keys.

    Features represent *what* is measured in a dataset—the variables or dimensions along which data is organized.
    They enable you to query datasets based on their structure and corresponding label annotations.

    Args:
        name: `str` Name of the feature, typically a column name.
        dtype: `Dtype | Registry | list[Registry] | FieldAttr` See :class:`~lamindb.base.types.Dtype`.
            For categorical types, you can define to which registry values are
            restricted, e.g., `ln.ULabel` or `ln.ULabel|bt.CellType`.
        type: `Feature | None = None` A feature type, see :attr:`~lamindb.Feature.type`.
        is_type: `bool = False` Whether this feature is a type, see :attr:`~lamindb.Feature.is_type`.
        unit: `str | None = None` Unit of measure, ideally SI (`"m"`, `"s"`, `"kg"`, etc.) or `"normalized"` etc.
        description: `str | None = None` A description.
        synonyms: `str | None = None` Bar-separated synonyms.
        nullable: `bool = True` Whether the feature can have null-like values (`None`, `pd.NA`, `NaN`, etc.), see :attr:`~lamindb.Feature.nullable`.
        default_value: `Any | None = None` Default value for the feature.
        coerce: `bool | None = None` When `True`, attempts to coerce values to the specified dtype
            during validation, see :attr:`~lamindb.Feature.coerce`. Defaults to `False` unless `is_type` is `True`.
        cat_filters: `dict[str, str] | None = None` Subset a registry by additional filters to define valid categories.

    Note:

        For more control, you can use :mod:`bionty` registries to manage simple
        biological entities like genes, proteins & cell markers. Or you define
        custom registries to manage high-level derived features like gene sets.

    See Also:
        :meth:`~lamindb.Feature.from_dataframe`
            Create feature records from DataFrame.
        :attr:`~lamindb.Artifact.features`
            Feature manager of an artifact or collection.
        :class:`~lamindb.ULabel`
            Universal labels.
        :class:`~lamindb.Schema`
            Sets of features.

    Example:

        Features with simple data types::

            ln.Feature(name="sample_note", dtype=str).save()
            ln.Feature(name="temperature_in_celsius", dtype=float).save()
            ln.Feature(name="read_count", dtype=int).save()

        A categorical feature measuring labels managed in the `ULabel` registry::

            ln.Feature(name="sample", dtype=ln.ULabel).save()

        The same for the `bt.CellType` registry::

            ln.Feature(name="cell_type_by_expert", dtype=bt.CellType).save()  # expert annotation
            ln.Feature(name="cell_type_by_model", dtype=bt.CellType).save()   # model annotation

        Scope a feature with a **feature type** to distinguish the same feature name across different contexts::

            abc_feature_type = ln.Feature(name="ABC", is_type=True).save()  # ABC could reference a schema, a project, a team, etc.
            ln.Feature(name="concentration_nM", dtype=float, type=abc_feature_type).save()

            xyz_feature_type = ln.Feature(name="XYZ", is_type=True).save()  # XYZ could reference a schema, a project, a team, etc.
            ln.Feature(name="concentration_nM", dtype=float, type=xyz_feature_type).save()

            # calling .save() again with the same name and type returns the existing feature
            ln.Feature(name="concentration_nM", dtype=float, type=xyz_feature_type).save()

        Annotate an artifact with features (works identically for records and runs)::

            artifact.features.add_values({
                "temperature_in_celsius": 37.5,
                "sample_note": "Control sample",
            })

        Query artifacts/records/runs by features::

            ln.Artifact.filter(features__name="temperature_in_celsius")  # artifacts with this feature
            ln.Artifact.filter(temperature_in_celsius__gt=37)            # artifacts where temperature > 37

        A list dtype::

            ln.Feature(
                name="cell_types",
                dtype=list[bt.CellType],  # or list[str] for a list of strings
            ).save()

        A path feature::

            ln.Feature(
                name="image_path",
                dtype="path",   # will be validated as `str`
            ).save()

    Note:

        *Features* vs. *labels*:

        1. A feature qualifies *what* is measured, i.e., a numerical or categorical random variable
        2. A label *is* a measured value of a categorical feature, i.e., a category

        Example: When annotating a dataset that measures expression of 30k genes,
        the gene identifiers serve as feature identifiers, and the features are expression measurements for these genes.
        When annotating a dataset whose experiment knocked out 3 specific genes, those genes serve as labels of the dataset.

        Re-shaping data can introduce ambiguity among features & labels. If this
        happened, ask yourself what the joint measurement was: a feature
        qualifies variables in a joint measurement. The canonical data matrix
        lists jointly measured variables in the columns.
    """

    class Meta(SQLRecord.Meta, TracksRun.Meta, TracksUpdates.Meta):
        abstract = False
        app_label = "lamindb"
        if (
            django_settings.DATABASES.get("default", {}).get("ENGINE")
            == "django.db.backends.postgresql"
        ):
            triggers = [
                pgtrigger.Trigger(
                    name="update_feature_on_name_change",
                    operation=pgtrigger.Update,
                    when=pgtrigger.Before,
                    condition=pgtrigger.Condition("OLD.name IS DISTINCT FROM NEW.name"),
                    func=UPDATE_FEATURE_ON_NAME_CHANGE,
                ),
            ]
        constraints = [
            models.CheckConstraint(
                condition=models.Q(is_type=True) | models.Q(_dtype_str__isnull=False),
                name="feature_dtype_str_not_null_when_is_type_false",
            ),
            # also see raw SQL constraints for `is_type` and `type` FK validity in migrations
        ]

    _name_field: str = "name"

    id: int = models.AutoField(primary_key=True)
    """Internal id, valid only in one DB instance."""
    uid: str = CharField(
        editable=False, unique=True, db_index=True, max_length=12, default=base62_12
    )
    """Universal id, valid across DB instances."""
    name: str = CharField(max_length=150, db_index=True)
    """Name of feature."""
    _dtype_str: Dtype | str | None = CharField(db_index=True, null=True)
    """The string-serialized data type (:class:`~lamindb.base.types.Dtype`).

    Note that mutating this field currently does not trigger re-validation of existing values.
    """
    type: Feature | None = ForeignKey(
        "self", PROTECT, null=True, related_name="features"
    )
    """Type of feature (e.g., 'Readout', 'Metric', 'Metadata', 'ExpertAnnotation', 'ModelPrediction').

    Allows to group features by type, e.g., all read outs, all metrics, etc.
    """
    features: Feature
    """Features of this type (can only be non-empty if `is_type` is `True`)."""
    unit: str | None = CharField(max_length=30, db_index=True, null=True)
    """Unit of measure, ideally SI (`m`, `s`, `kg`, etc.) or 'normalized' etc. (optional)."""
    description: str | None = TextField(null=True)
    """A description."""
    array_rank: int = models.SmallIntegerField(default=0, db_index=True)
    """Rank of feature.

    Number of indices of the array: 0 for scalar, 1 for vector, 2 for matrix.

    Is called `.ndim` in `numpy` and `pytorch` but shouldn't be confused with
    the dimension of the feature space.
    """
    array_size: int = models.IntegerField(default=0, db_index=True)
    """Number of elements of the feature.

    Total number of elements (product of shape components) of the array.

    - A number or string (a scalar): 1 or `None`
    - A 50-dimensional embedding: 50
    - A 25 x 25 image: 625
    """
    array_shape: list[int] | None = JSONField(default=None, db_default=None, null=True)
    """Shape of the feature.

    - A number or string (a scalar): [1] or `None`
    - A 50-dimensional embedding: [50]
    - A 25 x 25 image: [25, 25]

    Is stored as a list rather than a tuple because it's serialized as JSON.
    """
    synonyms: str | None = TextField(null=True)
    """Bar-separated (|) synonyms (optional)."""
    default_value: Any | None = JSONField(null=True, default=None)
    """A default value that overwrites missing values during standardization."""
    nullable: bool | None = BooleanField(null=True, default=None)
    """Whether the feature can have nullable values. None for type-like features."""
    coerce: bool | None = BooleanField(null=True, default=None)
    """Whether dtypes should be coerced during validation. None for type-like features."""
    # we define the below ManyToMany on the Feature model because it parallels
    # how other registries (like Gene, Protein, etc.) relate to Schema
    schemas: Schema = models.ManyToManyField(
        "Schema", through="SchemaFeature", related_name="features"
    )
    """Schemas linked to this feature."""
    # backward fields
    values: JsonValue
    """Values for this feature."""
    projects: Project
    """Annotating projects."""
    ablocks: FeatureBlock
    """Blocks that annotate this feature."""

    @overload
    def __init__(
        self,
        name: str,
        dtype: Dtype | Registry | list[Registry] | FieldAttr,
        type: Feature | None = None,
        is_type: bool = False,
        unit: str | None = None,
        description: str | None = None,
        synonyms: str | None = None,
        nullable: bool | None = None,
        default_value: Any | None = None,
        coerce: bool | None = None,
        cat_filters: dict[str, str] | None = None,
    ): ...

    @overload
    def __init__(
        self,
        *db_args,
    ): ...

    def __init__(
        self,
        *args,
        **kwargs,
    ):
        if len(args) == len(self._meta.concrete_fields):
            super().__init__(*args, **kwargs)
            return None
        default_value = kwargs.pop("default_value", None)
        nullable = kwargs.pop("nullable", None)
        # Default nullable to True for non-type features
        is_type = kwargs.get("is_type", False)
        if nullable is None and not is_type:
            nullable = True
        cat_filters = kwargs.pop("cat_filters", None)
        if "coerce_dtype" in kwargs:
            warnings.warn(
                "`coerce_dtype` argument was renamed to `coerce` and will be removed in a future release.",
                DeprecationWarning,
                stacklevel=2,
            )
            coerce = kwargs.pop("coerce_dtype")
        else:
            coerce = kwargs.pop("coerce", None)
        kwargs = process_init_feature_param(args, kwargs)
        super().__init__(*args, **kwargs)
        self.default_value = default_value
        self.nullable = nullable
        self.coerce = coerce
        dtype_str = kwargs.pop("_dtype_str", None)
        if dtype_str == "cat":
            warnings.warn(
                "dtype `cat` is deprecated and will be removed in the future - "
                "please use `ln.Record` or `ln.ULabel` instead",
                DeprecationWarning,
                stacklevel=2,
            )
        if cat_filters:
            if "|" in dtype_str:
                raise ValidationError(
                    f"cat_filters are incompatible with union dtypes: '{dtype_str}'"
                )
            if "]]" in dtype_str:
                raise ValidationError(
                    f"cat_filters are incompatible with nested dtypes: '{dtype_str}'"
                )

            # Validate filter values and SQLRecord attributes
            for filter_key, filter_value in cat_filters.items():
                if not filter_value or (
                    isinstance(filter_value, str) and not filter_value.strip()
                ):
                    raise ValidationError(f"Empty value in filter {filter_key}")
                # Check SQLRecord attributes for relation lookups
                if isinstance(filter_value, SQLRecord) and "__" in filter_key:
                    field_name = filter_key.split("__", 1)[1]
                    if not hasattr(filter_value, field_name):
                        raise ValidationError(
                            f"SQLRecord {filter_value.__class__.__name__} has no attribute '{field_name}' in filter {filter_key}"
                        )

            # If a SQLRecord is passed, we access its uid to apply a standard filter
            cat_filters = {
                f"{key}__uid"
                if (
                    is_sqlrecord := isinstance(filter, SQLRecord)
                    and hasattr(filter, "uid")
                )
                else key: filter.uid if is_sqlrecord else filter
                for key, filter in cat_filters.items()
            }

            fill_in = ", ".join(
                f"{key}='{value}'" for (key, value) in cat_filters.items()
            )
            dtype_str = dtype_str.replace("]", f"[{fill_in}]]")
            self._dtype_str = dtype_str
        if not self._state.adding:
            if self._dtype_str != dtype_str:
                raise ValidationError(
                    f"Feature {self.name} already exists with dtype {self._dtype_str}, you passed {dtype_str}"
                )

    # manually sync this docstring across all other children of HasType
    def query_features(self) -> QuerySet:
        """Query features of sub types.

        While `.features` retrieves the features with the current type, this method
        also retrieves sub types and the features with sub types of the current type.
        """
        return _query_relatives([self], "features")  # type: ignore

    @classmethod
    def from_dataframe(
        cls, df: pd.DataFrame, field: FieldAttr | None = None, *, mute: bool = False
    ) -> SQLRecordList:
        """Create Feature records for dataframe columns.

        Args:
            df: Source DataFrame to extract column information from
            field: FieldAttr for Feature model validation, defaults to Feature.name
            mute: Whether to mute Feature creation similar names found warnings
        """
        from lamindb.models import ULabel

        field = Feature.name if field is None else field
        registry = field.field.model  # type: ignore
        if registry != Feature:
            raise ValueError("field must be a Feature FieldAttr!")

        categoricals = categoricals_from_df(df)
        dtypes: dict[str, type | SQLRecord | FieldAttr] = {}
        for name, col in df.items():
            if name in categoricals:
                dtypes[name] = ULabel
            else:
                dtype_str = serialize_pandas_dtype(col.dtype)
                dtypes[name] = dtype_as_object(dtype_str)

        if mute:
            original_verbosity = logger._verbosity
            logger.set_verbosity(0)
        try:
            features = [
                Feature(name=name, dtype=dtype) for name, dtype in dtypes.items()
            ]  # type: ignore
            assert len(features) == len(df.columns)  # noqa: S101
            return SQLRecordList(features)
        finally:
            if mute:
                logger.set_verbosity(original_verbosity)

    @classmethod
    @deprecated("from_dataframe")
    def from_df(
        cls, df: pd.DataFrame, field: FieldAttr | None = None, *, mute: bool = False
    ) -> SQLRecordList:
        return cls.from_dataframe(df, field, mute=mute)

    @classmethod
    def from_dict(
        cls,
        dictionary: dict[str, Any],
        field: FieldAttr | None = None,
        *,
        type: Feature | None = None,
        mute: bool = False,
    ) -> SQLRecordList:
        """Create Feature records for dictionary keys.

        Args:
            dictionary: Source dictionary to extract key information from
            field: FieldAttr for Feature model validation, defaults to `Feature.name`
            type: Feature type of all created features
            mute: Whether to mute dtype inference and feature creation warnings
        """
        from lamindb.models._feature_manager import infer_feature_type_convert_json

        field = Feature.name if field is None else field
        registry = field.field.model  # type: ignore
        if registry != Feature:
            raise ValueError("field must be a Feature FieldAttr!")

        dtypes = {}
        for key, value in dictionary.items():
            dtype, _, message = infer_feature_type_convert_json(key, value, mute=mute)
            if dtype == "cat ? str":
                dtype = "str"
            elif dtype == "list[cat ? str]":
                dtype = "list[str]"
            dtypes[key] = dtype

        if mute:
            original_verbosity = logger._verbosity
            logger.set_verbosity(0)
        try:
            features = [
                Feature(name=key, dtype=dtype, type=type)
                for key, dtype in dtypes.items()
            ]  # type: ignore
            assert len(features) == len(dictionary)  # noqa: S101
            return SQLRecordList(features)
        finally:
            if mute:
                logger.set_verbosity(original_verbosity)

    def save(self, *args, **kwargs) -> Feature:
        """Save the feature to the instance."""
        super().save(*args, **kwargs)
        return self

    def with_config(self, optional: bool | None = None) -> tuple[Feature, dict]:
        """Pass addtional configurations to the schema."""
        if optional is not None:
            return self, {"optional": optional}
        return self, {}

    @property
    @deprecated("coerce")
    def coerce_dtype(self) -> bool | None:
        """Alias for coerce (backward compatibility)."""
        return self.coerce

    @coerce_dtype.setter
    def coerce_dtype(self, value: bool | None) -> None:
        self.coerce = value

    @property
    def dtype(self) -> str | None:
        """The `dtype` as a string."""
        if self._dtype_str is None:
            return None
        if self._dtype_str.startswith(
            ("cat[Record[", "cat[ULabel[", "list[cat[Record[", "list[cat[ULabel[")
        ):
            if self._dtype_str.startswith("list["):
                dtype_str = self._dtype_str.replace("list[", "")[:-1]
            else:
                dtype_str = self._dtype_str
            record_object = dtype_as_object(dtype_str)
            nested_string = f"[{record_object.name}]"  # type: ignore
            for t in record_object.query_types():  # type: ignore
                nested_string = f"[{t.name}{nested_string}]"
            return self._dtype_str.replace(f"[{record_object.uid}]", nested_string)  # type: ignore
        else:
            return self._dtype_str

    @property
    def dtype_as_object(self) -> type | SQLRecord | FieldAttr | None:  # type: ignore
        """The Python object corresponding to :attr:`~lamindb.Feature.dtype`.

        Example:

            For non-categorical features, returns the Python type::

                feature_num = ln.Feature(name="measurement", dtype=float).save()
                assert feature_num.dtype_as_object is float

            For categorical features with subtypes, returns the SQLRecord::

                lab1_type = ln.Feature(name="Lab1", is_type=True).save()
                lab1_sample_type = bt.Record.get(name="Sample", is_type=True, type=lab1_type).save()
                feature_sample = ln.Feature(name="sample", dtype=lab1_sample_type).save()
                assert feature_sample.dtype_as_object == lab1_sample_type

            For categorical features without subtypes, returns the field::

                feature_ontology_id = ln.Feature(name="ontology_id", dtype=bt.CellType.ontology_id).save()
                assert feature_ontology_id.dtype_as_object == bt.CellType.ontology_id

        """
        return dtype_as_object(self._dtype_str)

    # we'll enable this later
    # @property
    # def observational_unit(self) -> Literal["Artifact", "Observation"]:
    #     """Default observational unit on which the feature is measured.

    #     Currently, we only make a distinction between artifact-level and observation-level features.

    #     For example, a feature `"ml_split"` that stores `"test"` & `"train"` labels is typically defined on the artifact level.
    #     When accessing `artifact.features.get_values(["ml_split"])`, you expect a single value, either `"test"` or `"train"`.

    #     However, when accessing an artifact annotation with a feature that's defined on the observation-level, say `"cell_type"`, you expect a set of values. So,
    #     `artifact.features.get_values(["cell_type_from_expert"])` should return a set: `{"T cell", "B cell"}`.

    #     The value of `observational_unit` is currently auto-managed: if using `artifact.features.add_values()`,
    #     it will be set to `Artifact`. In a curator, the value depends on whether it's an artifact- or observation-level slot
    #     (e.g. `.uns` is artifact-level in `AnnData` whereas `.obs` is observation-level).

    #     Note: This attribute might in the future be used to distinguish different types of observational units (e.g. single cells vs. physical samples vs. study subjects etc.).
    #     """
    #     if self._expect_many:
    #         return "Observation"  # this here might be replaced with the specific observational unit
    #     else:
    #         return "Artifact"


class JsonValue(SQLRecord, TracksRun):
    """Non-categorical features values.

    Categorical feature values are stored in their respective registries:
    :class:`~lamindb.ULabel`, :class:`~bionty.CellType`, etc.

    Unlike for ULabel, in `JsonValue`, values are grouped by features and
    not by an ontological hierarchy.
    """

    # we do not have a unique constraint on feature & value because it leads to hashing errors
    # for large dictionaries: https://lamin.ai/laminlabs/lamindata/transform/jgTrkoeuxAfs0000
    # we do not hash values because we have `get_or_create` logic all over the place
    # and also for checking whether the (feature, value) combination exists
    # there does not seem an issue with querying for a dict-like value
    # https://lamin.ai/laminlabs/lamindata/transform/jgTrkoeuxAfs0001

    _name_field: str = "value"

    feature: Feature | None = ForeignKey(
        Feature, CASCADE, null=True, related_name="values", default=None
    )
    """The dimension metadata."""
    value: Any = models.JSONField()
    """The JSON-like value."""
    hash: str = CharField(max_length=HASH_LENGTH, null=True, db_index=True)
    """Value hash."""
    artifacts: Artifact
    """Artifacts annotated with this feature value."""
    runs: Run
    """Runs annotated with this feature value."""

    class Meta(BaseSQLRecord.Meta, TracksRun.Meta):
        app_label = "lamindb"
        unique_together = ("feature", "hash")

    @classmethod
    def get_or_create(cls, feature, value):
        # simple values: (int, float, str, bool, datetime)
        if not isinstance(value, dict):
            hash = hash_string(str(value))
        else:
            hash = hash_dict(value)
        try:
            return (
                cls.objects.create(feature=feature, value=value, hash=hash),
                False,
            )
        except DjangoIntegrityError:
            return cls.objects.get(feature=feature, hash=hash), True


def suggest_categorical_for_str_iterable(
    iterable: Iterable[str], key: str = None
) -> str:
    c = pd.Categorical(iterable)
    message = ""
    if len(c.categories) < len(c):
        if key != "":
            key_note = f" for feature {key}"
        else:
            key_note = ""
        message = f"You have few permissible values{key_note}, consider dtype 'cat' instead of 'str'"
    return message


def categoricals_from_df(df: pd.DataFrame) -> dict:
    """Returns categorical columns."""
    string_cols = [col for col in df.columns if is_string_dtype(df[col])]
    categoricals = {
        col: df[col]
        for col in df.columns
        if isinstance(df[col].dtype, CategoricalDtype)
    }
    for key in string_cols:
        message = suggest_categorical_for_str_iterable(df[key], key)
        if message:
            logger.warning(message)
    return categoricals
