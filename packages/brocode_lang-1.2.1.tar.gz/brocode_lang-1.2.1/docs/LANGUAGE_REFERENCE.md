# Bro Code Language Reference

**Version:** 1.1
**Status:** Production Ready

Bro Code is a high-level, dynamically typed esoteric programming language designed for the ultimate vibe check. It combines the block structure of C-style languages with the simplicity of Python, prioritizing readability and "vibes".

This document serves as the authoritative reference for the Bro Code language, including syntax, keywords, operators, and the standard library.

---

## Table of Contents

1. [Program Structure](#program-structure)
2. [Data Types](#data-types)
3. [Variables and Scope](#variables-and-scope)
4. [Control Flow](#control-flow)
    - [Conditionals](#conditionals)
    - [Loops](#loops)
5. [Functions](#functions)
6. [Operators](#operators)
7. [Error Handling](#error-handling)
8. [Standard Library (Built-ins)](#standard-library-built-ins)
    - [I/O](#io)
    - [Math](#math)
    - [Strings](#strings)
    - [Squads (Arrays)](#squads-arrays)
    - [Utility](#utility)

---

## Program Structure

A Bro Code program is defined within a `sup` block and terminated by a `peace` statement.

**File Extension:** `.homie`

```bro
// my_program.homie
sup {
    // Execution starts here
    spit("Hello, World!");
    
    peace; // Exit program
}
```

- **Comments**: Single-line comments start with `//`.
- **Blocks**: Code blocks are enclosed in curly braces `{}`.

---

## Data Types

Bro Code is dynamically typed. Variables do not hold type information, but values do.

| Type | Description | Literals |
|------|-------------|----------|
| **Integer** | Whole numbers | `42`, `-7`, `0` |
| **Float** | Floating-point numbers | `3.14`, `-0.001`, `4.20` |
| **String** | Text sequences | `"Hello"`, `"Bro Code"` |
| **Boolean** | Logical truth values | `no_cap` (True), `cap` (False) |
| **Null** | Absence of value | `ghost` |
| **Squad** | Ordered, mutable usage list | `[1, 2, "three"]` |

---

## Variables and Scope

### Declaration

Variables are declared using `var` (mutable) or `const` (immutable).

```bro
var currentVibe = "Chilling";
currentVibe = "Coding";     // Allowed

const MAX_LEVEL = 100;
// MAX_LEVEL = 101;         // Runtime Error: Cannot reassign constant
```

### Identifiers
Identifiers must start with a letter or underscore and contain only letters, numbers, and underscores. They are case-sensitive.

---

## Control Flow

### Conditionals

Decision making is handled by `fr` (if), `meh` (else if), and `nah` (else).

```bro
fr (score >= 90) {
    spit("Legendary status");
} 
meh (score >= 50) {
    spit("Not bad, fam");
} 
nah {
    spit("Git gud");
}
```

### Loops

#### While Loop (`hold_up`)
Executes a block while the condition is truthy (`no_cap`).

```bro
var energy = 10;
hold_up (energy > 0) {
    spit("Running...");
    energy--;
}
```

#### For Loop (`cycle`)
Iterates over a sequence (Squad) or a range.

```bro
// Range iteration (inclusive start, exclusive end)
cycle (var i in range(0, 5)) {
    spit(i); // Prints 0, 1, 2, 3, 4
}

// Squad iteration
var friends = ["Alex", "Sam", "Jordan"];
cycle (var friend in friends) {
    spit("Sup " + friend);
}
```

#### Loop Control
- `dip`: Immediately terminates the loop (break).
- `skip`: Skips the rest of the current iteration (continue).

---

## Functions

Functions are first-class citizens, defined with `gig`. Values are returned using `pay`.

```bro
gig calculateSum(a, b) {
    pay a + b;
}

// With default parameters
gig greet(name = "Homie") {
    spit("Sup " + name);
}

sup {
    var result = calculateSum(5, 10);
    greet();        // Prints: Sup Homie
    greet("User");  // Prints: Sup User
    peace;
}
```

---

## Operators

### Arithmetic
| Operator | Description |
|----------|-------------|
| `+` | Addition |
| `-` | Subtraction |
| `*` | Multiplication |
| `/` | Division |
| `//` | Integer Division |
| `%` | Modulus (Remainder) |
| `**` | Exponentiation |

### Comparison
| Operator | Alias | Description |
|----------|-------|-------------|
| `==` | `is_vibe` | Equal to |
| `!=` | | Not equal to |
| `>` | | Greater than |
| `<` | | Less than |
| `>=` | | Greater than or equal |
| `<=` | | Less than or equal |

### Logical
| Operator | Description |
|----------|-------------|
| `&&` | Logical AND |
| `||` | Logical OR |
| `!` | Logical NOT |

### Assignment
- `=`, `+=`, `-=`, `*=`, `/=`, `%=`
- `++` (Increment by 1)
- `--` (Decrement by 1)

---

## Error Handling

Runtime errors can be caught and handled using `shoot` (try) and `fumble` (catch).

```bro
shoot {
    var check = 10 / 0;
} 
fumble (error) {
    spit("Caught the fumble:", error);
}
```

---

## Standard Library (Built-ins)

All standard library functions are available globally.

### I/O

- **`spit(args...)`** -> `ghost`
  - Prints arguments to standard output, separated by spaces.
- **`listen(prompt)`** -> `string`
  - displays the prompt and returns user input as a string.

### Math

- **`abs(x)`** -> `number`
  - Returns the absolute value of x.
- **`max(a, b)`**, **`min(a, b)`** -> `number`
  - Returns the maximum or minimum of two arguments.
- **`pow(base, exp)`** -> `number`
  - Returns base raised to the power of exp.
- **`sqrt(x)`** -> `float`
  - Returns the square root of x.
- **`floor(x)`**, **`ceil(x)`** -> `int`
  - Returns the floor or ceiling of x.
- **`round(x, [digits])`** -> `number`
  - Rounds x to `digits` precision (default 0).

### Strings

- **`len(s)`** -> `int`
  - Returns the length of the string.
- **`upper(s)`**, **`lower(s)`** -> `string`
  - Converts string to upper or lower case.
- **`trim(s)`** -> `string`
  - Removes leading and trailing whitespace.
- **`split(s, delimiter)`** -> `squad`
  - Splits string into a squad based on the delimiter.
- **`join(arr, delimiter)`** -> `string`
  - Joins elements of a squad into a string.
- **`replace(s, old, new)`** -> `string`
  - Replaces all occurrences of `old` with `new`.
- **`contains(s, sub)`** -> `boolean`
  - Returns `no_cap` if `sub` is in `s`.
- **`starts_with(s, prefix)`**, **`ends_with(s, suffix)`** -> `boolean`
  - Checks if string starts or ends with pattern.
- **`substring(s, start, [end])`** -> `string`
  - Extract substring from `start` index to `end` index (exclusive).

### Squads (Arrays)

**Instance Methods:**
These (and only these) are called on the squad variable itself: `squad.method()`.

- **`push(value)`** -> `value`
  - Adds value to the end of the squad (mutating).
- **`pop()`** -> `value`
  - Removes and returns the last element.

**Global Functions:**
These are called with the squad as an argument: `func(squad)`.

- **`len(arr)`** -> `int`
  - Returns number of elements.
- **`sort(arr)`** -> `squad`
  - Returns a new sorted squad.
- **`reverse(arr)`** -> `squad`
  - Returns a new reversed squad.
- **`index_of(arr, value)`** -> `int`
  - Returns index of value, or -1 if not found.
- **`includes(arr, value)`** -> `boolean`
  - Returns `no_cap` if value exists in squad.
- **`slice(arr, start, [end])`** -> `squad`
  - Returns a shallow copy of a portion of the squad.
- **`concat(arr1, arr2)`** -> `squad`
  - Merges two squads into a new one.

### Utility

- **`type(value)`** -> `string`
  - Returns `"integer"`, `"float"`, `"string"`, `"boolean"`, `"squad"`, or `"ghost"`.
- **`int(value)`**, **`float(value)`**, **`str(value)`**
  - Type conversion functions.
- **`range(start, end, [step])`** -> `squad`
  - Generates a sequence of integers from `start` to `end` (exclusive).
- **`random()`** -> `float`
  - Returns a random float between 0.0 and 1.0.
- **`random_int(min, max)`** -> `int`
  - Returns a random integer between min and max (inclusive).
- **`time()`** -> `float`
  - Returns current Unix timestamp.
