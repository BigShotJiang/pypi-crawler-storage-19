# Bro Code Language Specification

**Version:** 1.1  
**Author:** Prashith  
**Event:** CSI Code Wars

---

## 1. Introduction

**Bro Code** is a high-level, dynamically typed esoteric programming language designed for the ultimate vibe check. It combines the block structure of **C++** (using curly braces `{}`) with the simplicity and dynamic typing of **Python**.

### File Extension

All Bro Code source files must end with the extension `.homie`.

---

## 2. Program Structure

Every program must be contained within a main execution block named `sup`. The program ends with the `peace` statement, which acts as the exit command.

**Syntax:**

```cpp
sup {
    // Code logic goes here
    
    peace;
}
```

---

## 3. Variables & Data Types

Bro Code uses **dynamic typing**. Variables are declared using the `var` keyword. Explicit type declaration (e.g., `int`, `string`) is not required.

### 3.1 Declaration

* **Variable:** `var name = value;`
* **Constant:** `const PI = 3.14;`

### 3.2 Supported Types

| Type | Keyword/Example | Description |
| --- | --- | --- |
| **Integer** | `69` | Whole numbers |
| **Float** | `4.20` | Decimal numbers |
| **String** | `"Yo World"` | Text (Must use double quotes) |
| **Boolean** | `no_cap` / `cap` | `True` / `False` |
| **Null** | `ghost` | Represents a null or empty value |

---

## 4. Input & Output (I/O)

### 4.1 Output

To print data to the console, use the `spit()` function.

```cpp
spit("Hello World");
spit(x);
```

### 4.2 Input

To receive input from the user, use the `listen()` function. It always returns a string.

```cpp
var name = listen("Enter your name: ");
```

---

## 5. Control Flow

Bro Code uses C-style curly braces `{}` for scoping.

### 5.1 Conditionals (`fr`, `meh`, `nah`)

* `fr` = `if`
* `meh` = `else if`
* `nah` = `else`

**Example:**

```cpp
var energy = 50;

fr (energy > 80) {
    spit("Hyper mode");
} 
meh (energy > 20) {
    spit("Chilling");
} 
nah {
    spit("Need coffee");
}
```

### 5.2 Loops

**While Loop (`hold_up`)**
Executes the block while the condition is `no_cap` (True).

```cpp
var i = 0;
hold_up (i < 5) {
    spit(i);
    i++;
}
```

**For Loop (`cycle`)**
Iterates over a range or an array.

```cpp
// Prints 0 to 9
cycle (var i in range(0, 10)) {
    spit(i);
}

// With step parameter
cycle (var i in range(0, 10, 2)) {
    spit(i);  // 0, 2, 4, 6, 8
}

// Iterate over array
var squad = [1, 2, 3];
cycle (var item in squad) {
    spit(item);
}
```

### 5.3 Loop Control (`dip`, `skip`)

* `dip` = `break` - Exit the loop immediately
* `skip` = `continue` - Skip to the next iteration

**Example:**

```cpp
cycle (var i in range(0, 10)) {
    fr (i is_vibe 5) {
        dip;  // Exit loop when i equals 5
    }
    fr (i % 2 is_vibe 0) {
        skip;  // Skip even numbers
    }
    spit(i);  // Only prints odd numbers: 1, 3
}
```

---

## 6. Operators

Bro Code supports a comprehensive set of operators.

### 6.1 Arithmetic Operators

| Operator | Description | Example |
| --- | --- | --- |
| `+` | Addition | `5 + 3` → `8` |
| `-` | Subtraction | `5 - 3` → `2` |
| `*` | Multiplication | `5 * 3` → `15` |
| `/` | Division | `7 / 2` → `3.5` |
| `%` | Modulo | `7 % 2` → `1` |
| `**` | Power | `2 ** 10` → `1024` |
| `//` | Integer Division | `7 // 2` → `3` |

### 6.2 Comparison Operators

| Operator | Description |
| --- | --- |
| `>` | Greater than |
| `<` | Less than |
| `>=` | Greater than or equal |
| `<=` | Less than or equal |
| `==` | Equal to |
| `!=` | Not equal to |
| `is_vibe` | Equal to (alias for `==`) |

### 6.3 Logical Operators

| Operator | Description |
| --- | --- |
| `&&` | Logical AND |
| `||` | Logical OR |
| `!` | Logical NOT |

### 6.4 Assignment Operators

| Operator | Description | Equivalent |
| --- | --- | --- |
| `=` | Assignment | `x = 5` |
| `+=` | Add and assign | `x = x + 5` |
| `-=` | Subtract and assign | `x = x - 5` |
| `*=` | Multiply and assign | `x = x * 5` |
| `/=` | Divide and assign | `x = x / 5` |
| `%=` | Modulo and assign | `x = x % 5` |

### 6.5 Increment/Decrement Operators

| Operator | Description | Example |
| --- | --- | --- |
| `++` | Increment by 1 | `i++;` |
| `--` | Decrement by 1 | `i--;` |

---

## 7. Data Structures

### 7.1 Squads (Arrays)

Lists in Bro Code are called "Squads". They are mutable and ordered.

* **Declaration:** `var squad = [1, 2, 3];`
* **Access:** `squad[0]`
* **Methods:**
  * `squad.push(val)`: Adds an item to the end.
  * `squad.pop()`: Removes and returns the last item.

---

## 8. Functions

Functions are defined using the `gig` keyword. Values are returned using `pay`.

### 8.1 Basic Function

```cpp
gig calculateArea(width, height) {
    var area = width * height;
    pay area;
}

sup {
    var a = calculateArea(10, 5);
    spit(a);  // 50
    peace;
}
```

### 8.2 Default Parameters

Functions can have default parameter values. Parameters with defaults must come after required parameters.

```cpp
gig greet(name = "bro", greeting = "Hey") {
    spit(greeting + ", " + name + "!");
}

sup {
    greet();                // "Hey, bro!"
    greet("homie");         // "Hey, homie!"
    greet("fam", "Yo");     // "Yo, fam!"
    peace;
}
```

---

## 9. Error Handling

Handle runtime errors gracefully using `shoot` (try) and `fumble` (catch).

```cpp
shoot {
    var result = 10 / 0;
} 
fumble (error) {
    spit("Error detected: " + error);
}
```

---

## 10. Comments

Bro Code supports both single-line and multi-line comments.

```cpp
// This is a single-line comment

/* This is a
   multi-line comment */
```

---

## Appendix A: Quick Reference Cheat Sheet

| Feature | Bro Code Syntax | Python Equivalent |
| --- | --- | --- |
| **Start Program** | `sup { ... }` | `if __name__ == "__main__":` |
| **End Program** | `peace;` | `exit()` |
| **Print** | `spit(x)` | `print(x)` |
| **Variable** | `var x = 1` | `x = 1` |
| **True / False** | `no_cap` / `cap` | `True` / `False` |
| **If** | `fr (cond) { }` | `if cond:` |
| **Else If** | `meh (cond) { }` | `elif cond:` |
| **Else** | `nah { }` | `else:` |
| **While Loop** | `hold_up (cond) { }` | `while cond:` |
| **For Loop** | `cycle (var i in range(0, n)) { }` | `for i in range(n):` |
| **Break** | `dip;` | `break` |
| **Continue** | `skip;` | `continue` |
| **Function** | `gig name(x = 10) { }` | `def name(x=10):` |
| **Return** | `pay x` | `return x` |
| **Power** | `2 ** 10` | `2 ** 10` |
| **Int Division** | `7 // 2` | `7 // 2` |
| **Increment** | `i++;` | `i += 1` |

---

## Appendix B: Built-in Functions

### I/O Functions

| Function | Description | Return Type |
|----------|-------------|-------------|
| `spit(value)` | Print value to stdout | `ghost` |
| `listen(prompt)` | Read input from user | `string` |

### Type Conversion Functions

| Function | Description | Return Type |
|----------|-------------|-------------|
| `int(value)` | Convert to integer | `integer` |
| `float(value)` | Convert to float | `float` |
| `str(value)` | Convert to string | `string` |
| `type(value)` | Get type name | `string` |

### Math Functions

| Function | Description | Return Type |
|----------|-------------|-------------|
| `abs(x)` | Absolute value | `integer` or `float` |
| `min(a, b)` | Minimum of two values | `integer` or `float` |
| `max(a, b)` | Maximum of two values | `integer` or `float` |
| `pow(base, exp)` | Exponentiation | `integer` or `float` |
| `sqrt(x)` | Square root | `float` |
| `floor(x)` | Round down | `integer` |
| `ceil(x)` | Round up | `integer` |
| `round(x, digits)` | Round to digits | `integer` or `float` |

### String Functions

| Function | Description | Return Type |
|----------|-------------|-------------|
| `upper(s)` | Convert to uppercase | `string` |
| `lower(s)` | Convert to lowercase | `string` |
| `trim(s)` | Remove whitespace from ends | `string` |
| `split(s, delim)` | Split string by delimiter | `squad` |
| `join(arr, delim)` | Join array with delimiter | `string` |
| `replace(s, old, new)` | Replace all occurrences | `string` |
| `contains(s, sub)` | Check if contains substring | `boolean` |
| `starts_with(s, prefix)` | Check if starts with prefix | `boolean` |
| `ends_with(s, suffix)` | Check if ends with suffix | `boolean` |
| `char_at(s, index)` | Get character at index | `string` |
| `substring(s, start, end)` | Get substring | `string` |

### Array Functions

| Function | Description | Return Type |
|----------|-------------|-------------|
| `len(obj)` | Get length of array/string | `integer` |
| `range(start, end, step)` | Generate number sequence | `squad` |
| `sort(arr)` | Return sorted copy | `squad` |
| `reverse(arr)` | Return reversed copy | `squad` |
| `slice(arr, start, end)` | Get sub-array | `squad` |
| `index_of(arr, value)` | Find index (-1 if not found) | `integer` |
| `includes(arr, value)` | Check if value exists | `boolean` |
| `concat(arr1, arr2)` | Concatenate arrays | `squad` |

### Utility Functions

| Function | Description | Return Type |
|----------|-------------|-------------|
| `random()` | Random float 0-1 | `float` |
| `random_int(min, max)` | Random integer (inclusive) | `integer` |
| `time()` | Current timestamp in seconds | `float` |

---

## Appendix C: Reserved Keywords

```
sup, peace, var, const, fr, meh, nah, hold_up, cycle, in,
gig, pay, shoot, fumble, no_cap, cap, ghost, is_vibe, dip, skip
```
