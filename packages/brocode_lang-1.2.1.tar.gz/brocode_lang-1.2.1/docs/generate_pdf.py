#!/usr/bin/env python3
"""
Bro-CODE Documentation PDF Generator
Generates a professional PDF documentation from the language spec, reference, and examples.
Based on official README and documentation files.
"""

from fpdf import FPDF
from datetime import datetime


class BroCodePDF(FPDF):
    """Custom PDF class for Bro-CODE documentation."""
    
    def __init__(self):
        super().__init__()
        self.set_auto_page_break(auto=True, margin=20)
        
    def header(self):
        if self.page_no() > 1:  # Skip header on title page
            self.set_font("Helvetica", "I", 9)
            self.set_text_color(100, 100, 100)
            self.cell(0, 10, "Bro-CODE Language Documentation v1.1", align="L")
            self.cell(0, 10, f"Page {self.page_no()}", align="R")
            self.ln(15)
    
    def footer(self):
        if self.page_no() > 1:
            self.set_y(-15)
            self.set_font("Helvetica", "I", 8)
            self.set_text_color(128, 128, 128)
            self.cell(0, 10, "https://github.com/Prashithshetty/Bro-CODE", align="C")
    
    def title_page(self):
        """Create an attractive title page."""
        self.add_page()
        
        # Background color block
        self.set_fill_color(45, 55, 72)  # Dark blue-gray
        self.rect(0, 0, 210, 297, "F")
        
        # Decorative element
        self.set_fill_color(99, 102, 241)  # Indigo accent
        self.rect(0, 100, 210, 8, "F")
        
        # Title
        self.set_y(120)
        self.set_font("Helvetica", "B", 48)
        self.set_text_color(255, 255, 255)
        self.cell(0, 20, "BRO-CODE", align="C")
        
        self.ln(20)
        self.set_font("Helvetica", "", 20)
        self.set_text_color(200, 200, 200)
        self.cell(0, 10, "Programming Language", align="C")
        
        self.ln(15)
        self.set_font("Helvetica", "I", 14)
        self.set_text_color(150, 150, 150)
        self.cell(0, 10, "The Ultimate Vibe Check Language", align="C")
        
        # Version and date
        self.set_y(200)
        self.set_font("Helvetica", "", 12)
        self.set_text_color(180, 180, 180)
        self.cell(0, 8, "Version 1.1", align="C")
        self.ln()
        self.cell(0, 8, f"Generated: {datetime.now().strftime('%B %d, %Y')}", align="C")
        
        # Author
        self.set_y(250)
        self.set_font("Helvetica", "", 11)
        self.set_text_color(150, 150, 150)
        self.cell(0, 8, "Created by Prashith", align="C")
        self.ln()
        self.cell(0, 8, "For CSI Code Wars", align="C")
    
    def add_section_header(self, title: str, level: int = 1):
        """Add a section header."""
        self.ln(6)
        if level == 1:
            self.set_font("Helvetica", "B", 16)
            self.set_text_color(45, 55, 72)
            self.set_fill_color(240, 240, 245)
            self.cell(0, 10, title, fill=True, new_x="LMARGIN", new_y="NEXT")
            self.ln(3)
        elif level == 2:
            self.set_font("Helvetica", "B", 13)
            self.set_text_color(55, 65, 82)
            self.cell(0, 8, title, new_x="LMARGIN", new_y="NEXT")
            self.ln(2)
        else:
            self.set_font("Helvetica", "B", 11)
            self.set_text_color(65, 75, 92)
            self.cell(0, 7, title, new_x="LMARGIN", new_y="NEXT")
            self.ln(1)
    
    def add_paragraph(self, text: str):
        """Add a paragraph of text."""
        self.set_font("Helvetica", "", 10)
        self.set_text_color(50, 50, 50)
        self.multi_cell(0, 5, text)
        self.ln(2)
    
    def add_code_block(self, code: str):
        """Add a styled code block."""
        self.set_font("Courier", "", 8)
        
        lines = code.strip().split('\n')
        height = len(lines) * 4 + 6
        
        # Check if we need a new page
        if self.get_y() + height > 270:
            self.add_page()
        
        x = self.get_x()
        y = self.get_y()
        
        # Draw background
        self.set_fill_color(45, 55, 72)
        self.rect(x, y, 180, height, "F")
        
        # Draw code
        self.set_xy(x + 4, y + 3)
        self.set_text_color(220, 220, 220)
        for line in lines:
            # Truncate long lines
            if len(line) > 85:
                line = line[:82] + "..."
            self.cell(0, 4, line)
            self.ln(4)
            self.set_x(x + 4)
        
        self.ln(4)
    
    def add_table(self, headers: list, data: list, col_widths: list = None):
        """Add a styled table."""
        if col_widths is None:
            col_widths = [180 // len(headers)] * len(headers)
        
        self.set_font("Helvetica", "B", 9)
        self.set_fill_color(99, 102, 241)
        self.set_text_color(255, 255, 255)
        
        # Headers
        for i, header in enumerate(headers):
            self.cell(col_widths[i], 7, header, border=1, fill=True, align="C")
        self.ln()
        
        # Data rows
        self.set_font("Helvetica", "", 8)
        self.set_text_color(50, 50, 50)
        fill = False
        for row in data:
            if fill:
                self.set_fill_color(245, 245, 250)
            else:
                self.set_fill_color(255, 255, 255)
            for i, cell in enumerate(row):
                self.cell(col_widths[i], 6, str(cell), border=1, fill=True, align="L")
            self.ln()
            fill = not fill
        
        self.ln(4)

    def add_bullet(self, text: str):
        """Add a bullet point."""
        self.set_font("Helvetica", "", 10)
        self.set_text_color(50, 50, 50)
        self.cell(0, 5, f"  - {text}", new_x="LMARGIN", new_y="NEXT")


def create_pdf():
    """Generate the complete Bro-CODE documentation PDF."""
    pdf = BroCodePDF()
    
    # ==================== TITLE PAGE ====================
    pdf.title_page()
    
    # ==================== TABLE OF CONTENTS ====================
    pdf.add_page()
    pdf.set_fill_color(255, 255, 255)
    pdf.add_section_header("Table of Contents")
    
    toc_items = [
        "1. Introduction",
        "2. Installation",
        "3. Quick Start",
        "4. Program Structure",
        "5. Variables and Data Types",
        "6. Input/Output (I/O)",
        "7. Control Flow (Conditionals)",
        "8. Loops",
        "9. Functions",
        "10. Operators",
        "11. Data Structures (Squads/Arrays)",
        "12. Error Handling",
        "13. Built-in Functions",
        "14. Example Programs",
        "Appendix A: Quick Reference Cheat Sheet",
        "Appendix B: Reserved Keywords",
        "Appendix C: CLI Options",
    ]
    
    for item in toc_items:
        pdf.add_bullet(item)
    
    # ==================== 1. INTRODUCTION ====================
    pdf.add_page()
    pdf.add_section_header("1. Introduction")
    pdf.add_paragraph(
        "Bro Code is a high-level, dynamically typed esoteric programming language designed "
        "for the ultimate vibe check. It combines the block structure of C++ (using curly braces {}) "
        "with the simplicity and dynamic typing of Python."
    )
    pdf.add_paragraph(
        "The language prioritizes readability and 'vibes', making it both fun to learn and "
        "a unique challenge for programmers looking to adapt their coding skills."
    )
    
    pdf.add_section_header("Key Features", level=2)
    pdf.add_bullet("File Extension: .homie")
    pdf.add_bullet("Dynamic typing - no explicit type declarations")
    pdf.add_bullet("C-style block structure with curly braces {}")
    pdf.add_bullet("Python-like simplicity")
    pdf.add_bullet("First-class functions with default parameters")
    pdf.add_bullet("Error handling with shoot/fumble (try/catch)")
    pdf.add_bullet("Built-in array type called 'Squad'")
    pdf.add_bullet("No external dependencies - Python 3.8+ only")
    
    # ==================== 2. INSTALLATION ====================
    pdf.add_page()
    pdf.add_section_header("2. Installation")
    
    pdf.add_section_header("Via pip (Recommended)", level=2)
    pdf.add_code_block("pip install brocode-lang")
    
    pdf.add_section_header("Manual Installation", level=2)
    pdf.add_code_block("""# Clone the repository
git clone https://github.com/Prashithshetty/Bro-CODE.git
cd Bro-CODE

# Install in development mode
pip install -e .

# Or run directly without installing
python -m brocode examples/hello.homie""")
    
    pdf.add_section_header("Requirements", level=2)
    pdf.add_paragraph("Python 3.8 or higher. No external dependencies required!")
    
    # ==================== 3. QUICK START ====================
    pdf.add_page()
    pdf.add_section_header("3. Quick Start")
    
    pdf.add_section_header("Running a Program", level=2)
    pdf.add_code_block("""# Run a .homie file
brocode examples/hello.homie

# Or use the Python module directly
python -m brocode examples/hello.homie

# Or use the wrapper script
chmod +x bro
./bro examples/hello.homie""")
    
    pdf.add_section_header("Hello World Example", level=2)
    pdf.add_paragraph("Create a file called hello.homie:")
    pdf.add_code_block("""// Hello World in Bro Code
// Expected output: Hello World! Welcome to Bro Code!

sup {
    spit("Hello World!");
    spit("Welcome to Bro Code!");
    peace;
}""")
    
    pdf.add_paragraph("Run it with: brocode hello.homie")
    
    # ==================== 4. PROGRAM STRUCTURE ====================
    pdf.add_page()
    pdf.add_section_header("4. Program Structure")
    pdf.add_paragraph(
        "Every Bro Code program must be contained within a main execution block named 'sup'. "
        "The program ends with the 'peace' statement, which acts as the exit command."
    )
    
    pdf.add_section_header("Basic Structure", level=2)
    pdf.add_code_block("""sup {
    // Code logic goes here
    
    peace;  // Exit program
}""")
    
    pdf.add_section_header("Comments", level=2)
    pdf.add_paragraph("Bro Code supports both single-line and multi-line comments:")
    pdf.add_code_block("""// This is a single-line comment

/* This is a
   multi-line comment */""")
    
    # ==================== 5. VARIABLES & DATA TYPES ====================
    pdf.add_page()
    pdf.add_section_header("5. Variables and Data Types")
    pdf.add_paragraph(
        "Bro Code uses dynamic typing. Variables are declared using 'var' (mutable) "
        "or 'const' (immutable). Explicit type declaration is not required."
    )
    
    pdf.add_section_header("Declaration", level=2)
    pdf.add_code_block("""var name = "Bro";           // String (mutable)
var age = 21;               // Integer
var price = 4.20;           // Float
var isAwesome = no_cap;     // Boolean (true)
var isBoring = cap;         // Boolean (false)
var nothing = ghost;        // Null
const PI = 3.14;            // Constant (immutable)""")
    
    pdf.add_section_header("Supported Data Types", level=2)
    pdf.add_table(
        ["Type", "Example", "Description"],
        [
            ["Integer", "42, -7, 0", "Whole numbers"],
            ["Float", "3.14, 4.20, -0.5", "Decimal numbers"],
            ["String", '"Hello", "Bro"', "Text (double quotes only)"],
            ["Boolean", "no_cap / cap", "True / False"],
            ["Null", "ghost", "Represents empty/null value"],
            ["Squad", "[1, 2, 3]", "Ordered list (array)"],
        ],
        [40, 50, 90]
    )
    
    pdf.add_section_header("Variables Example (variables.homie)", level=2)
    pdf.add_code_block("""sup {
    // Integer
    var age = 21;
    spit("Age: " + str(age));
    
    // Float
    var price = 4.20;
    spit("Price: $" + str(price));
    
    // String
    var name = "Bro Coder";
    spit("Name: " + name);
    
    // Boolean
    var isAwesome = no_cap;
    spit("Is awesome: " + str(isAwesome));
    
    // Null
    var nothing = ghost;
    spit("Nothing: " + str(nothing));
    
    // Constants
    const PI = 3.14159;
    spit("PI: " + str(PI));
    
    // Arithmetic operations
    var a = 10;
    var b = 3;
    spit("10 + 3 = " + str(a + b));
    spit("10 - 3 = " + str(a - b));
    spit("10 * 3 = " + str(a * b));
    spit("10 / 3 = " + str(a / b));
    spit("10 % 3 = " + str(a % b));
    
    peace;
}""")
    
    # ==================== 6. INPUT/OUTPUT ====================
    pdf.add_page()
    pdf.add_section_header("6. Input/Output (I/O)")
    
    pdf.add_section_header("Output - spit()", level=2)
    pdf.add_paragraph("Use the spit() function to print data to the console:")
    pdf.add_code_block("""spit("Hello!");                         // Print string
spit(x);                                // Print variable
spit("Score: " + str(score));           // Concatenate and print""")
    
    pdf.add_section_header("Input - listen()", level=2)
    pdf.add_paragraph("Use listen() to receive input from the user. It always returns a string:")
    pdf.add_code_block("""var name = listen("Enter your name: ");
var age = int(listen("Enter your age: "));   // Convert to integer""")
    
    pdf.add_section_header("Interactive Input Example (input.homie)", level=2)
    pdf.add_code_block("""gig greetUser() {
    var name = listen("What's your name, bro? ");
    spit("Yo " + name + "! Welcome to Bro Code!");
}

gig guessNumber() {
    var secret = 7;
    var guess = int(listen("Guess a number (1-10): "));
    
    fr (guess is_vibe secret) {
        spit("No cap! You got it!");
    } 
    meh (guess < secret) {
        spit("Too low, bro!");
    } 
    nah {
        spit("Too high, bro!");
    }
}

sup {
    greetUser();
    guessNumber();
    peace;
}""")
    
    # ==================== 7. CONTROL FLOW ====================
    pdf.add_page()
    pdf.add_section_header("7. Control Flow (Conditionals)")
    pdf.add_paragraph("Decision making uses: fr (if), meh (else if), nah (else)")
    
    pdf.add_section_header("Syntax", level=2)
    pdf.add_table(
        ["Bro Code", "Equivalent"],
        [
            ["fr (condition) { }", "if (condition) { }"],
            ["meh (condition) { }", "else if (condition) { }"],
            ["nah { }", "else { }"],
        ],
        [90, 90]
    )
    
    pdf.add_section_header("Conditionals Example (conditionals.homie)", level=2)
    pdf.add_code_block("""sup {
    var energy = 50;
    
    spit("Energy level: " + str(energy));
    
    fr (energy > 80) {
        spit("Hyper mode activated!");
    } 
    meh (energy > 50) {
        spit("Feeling good!");
    } 
    meh (energy > 20) {
        spit("Chilling...");
    } 
    nah {
        spit("Need coffee ASAP!");
    }
    
    // Using is_vibe (equality check)
    var score = 100;
    fr (score is_vibe 100) {
        spit("Perfect score!");
    }
    
    // Boolean conditionals
    var hasPermission = no_cap;
    var isAdmin = cap;
    
    fr (hasPermission && !isAdmin) {
        spit("Regular user with access");
    }
    
    fr (hasPermission || isAdmin) {
        spit("Access granted somehow!");
    }
    
    peace;
}""")
    
    # ==================== 8. LOOPS ====================
    pdf.add_page()
    pdf.add_section_header("8. Loops")
    
    pdf.add_section_header("While Loop (hold_up)", level=2)
    pdf.add_paragraph("Executes the block while the condition is no_cap (True):")
    pdf.add_code_block("""var count = 0;
hold_up (count < 5) {
    spit("Count: " + str(count));
    count = count + 1;
}""")
    
    pdf.add_section_header("For Loop (cycle)", level=2)
    pdf.add_paragraph("Iterates over a range or array (squad):")
    pdf.add_code_block("""// Range iteration (0 to 4)
cycle (var i in range(0, 5)) {
    spit("i = " + str(i));
}

// With step parameter (0, 2, 4, 6, 8)
cycle (var i in range(0, 10, 2)) {
    spit(i);
}

// Iterating over a squad
var squad = ["Alice", "Bob", "Charlie"];
cycle (var name in squad) {
    spit("Hello, " + name + "!");
}""")
    
    pdf.add_section_header("Loop Control (dip, skip)", level=2)
    pdf.add_paragraph("dip = break (exit loop), skip = continue (next iteration)")
    pdf.add_code_block("""// break_continue.homie example
sup {
    spit("=== Testing dip (break) ===");
    
    // Test break in while loop
    var count = 0;
    hold_up (no_cap) {
        count++;
        fr (count is_vibe 5) {
            spit("Breaking at count = " + str(count));
            dip;
        }
    }
    spit("After while loop, count = " + str(count));
    
    spit("=== Testing skip (continue) ===");
    
    // Test continue - skip even numbers
    spit("Odd numbers from 0 to 10:");
    cycle (var i in range(0, 10)) {
        fr (i % 2 is_vibe 0) {
            skip;
        }
        spit(i);
    }
    
    peace;
}""")
    
    pdf.add_section_header("Loops Example (loops.homie)", level=2)
    pdf.add_code_block("""sup {
    // While loop with hold_up
    spit("=== While Loop (hold_up) ===");
    var count = 0;
    hold_up (count < 5) {
        spit("Count: " + str(count));
        count = count + 1;
    }
    
    // For loop with cycle and range
    spit("=== For Loop (cycle) ===");
    cycle (var i in range(0, 5)) {
        spit("i = " + str(i));
    }
    
    // Iterating over an array (squad)
    spit("=== Iterating Squad ===");
    var squad = ["Alice", "Bob", "Charlie"];
    cycle (var name in squad) {
        spit("Hello, " + name + "!");
    }
    
    // Nested loops
    spit("=== Multiplication Table (3x3) ===");
    cycle (var x in range(1, 4)) {
        cycle (var y in range(1, 4)) {
            spit(str(x) + " x " + str(y) + " = " + str(x * y));
        }
    }
    
    peace;
}""")
    
    # ==================== 9. FUNCTIONS ====================
    pdf.add_page()
    pdf.add_section_header("9. Functions")
    pdf.add_paragraph(
        "Functions are first-class citizens in Bro Code, defined with 'gig'. "
        "Values are returned using 'pay'. Functions support default parameters."
    )
    
    pdf.add_section_header("Basic Function Syntax", level=2)
    pdf.add_code_block("""// Simple function
gig greet(name) {
    spit("Hello, " + name + "!");
}

// Function with return value
gig add(a, b) {
    pay a + b;
}

// Function with default parameters
gig greet(name = "bro", greeting = "Hey") {
    spit(greeting + ", " + name + "!");
}""")
    
    pdf.add_section_header("Functions Example (functions.homie)", level=2)
    pdf.add_code_block("""// Simple function
gig greet(name) {
    spit("Hello, " + name + "!");
}

// Function with return value
gig add(a, b) {
    pay a + b;
}

// Function with multiple parameters
gig calculateArea(width, height) {
    var area = width * height;
    pay area;
}

// Recursive function
gig factorial(n) {
    fr (n <= 1) {
        pay 1;
    }
    pay n * factorial(n - 1);
}

// Function using conditionals
gig getGrade(score) {
    fr (score >= 90) {
        pay "A";
    } 
    meh (score >= 80) {
        pay "B";
    } 
    meh (score >= 70) {
        pay "C";
    } 
    meh (score >= 60) {
        pay "D";
    } 
    nah {
        pay "F";
    }
}

sup {
    greet("Bro");
    
    var sum = add(5, 3);
    spit("5 + 3 = " + str(sum));
    
    var area = calculateArea(10, 5);
    spit("Area of 10x5: " + str(area));
    
    spit("5! = " + str(factorial(5)));
    
    var myScore = 85;
    spit("Score " + str(myScore) + " = Grade " + getGrade(myScore));
    
    peace;
}""")
    
    pdf.add_section_header("Default Parameters Example (default_params.homie)", level=2)
    pdf.add_code_block("""gig greet(name = "bro", greeting = "Hey") {
    spit(greeting + ", " + name + "!");
}

gig add(a, b = 10, c = 100) {
    pay a + b + c;
}

gig power_of_two(n = 8) {
    pay 2 ** n;
}

sup {
    spit("=== Testing Default Parameters ===");
    
    greet();                    // "Hey, bro!"
    greet("homie");             // "Hey, homie!"
    greet("fam", "Yo");         // "Yo, fam!"
    
    spit("add(5) = " + str(add(5)));           // 115
    spit("add(5, 20) = " + str(add(5, 20)));   // 125
    spit("add(5, 20, 50) = " + str(add(5, 20, 50))); // 75
    
    spit("power_of_two() = " + str(power_of_two()));   // 256
    spit("power_of_two(4) = " + str(power_of_two(4))); // 16
    
    peace;
}""")
    
    # ==================== 10. OPERATORS ====================
    pdf.add_page()
    pdf.add_section_header("10. Operators")
    
    pdf.add_section_header("Arithmetic Operators", level=2)
    pdf.add_table(
        ["Operator", "Description", "Example"],
        [
            ["+", "Addition", "5 + 3 = 8"],
            ["-", "Subtraction", "5 - 3 = 2"],
            ["*", "Multiplication", "5 * 3 = 15"],
            ["/", "Division", "7 / 2 = 3.5"],
            ["%", "Modulo", "7 % 2 = 1"],
            ["**", "Power (exponentiation)", "2 ** 10 = 1024"],
            ["//", "Integer Division", "7 // 2 = 3"],
        ],
        [30, 80, 70]
    )
    
    pdf.add_section_header("Comparison Operators", level=2)
    pdf.add_table(
        ["Operator", "Description"],
        [
            [">", "Greater than"],
            ["<", "Less than"],
            [">=", "Greater than or equal"],
            ["<=", "Less than or equal"],
            ["==", "Equal to"],
            ["!=", "Not equal to"],
            ["is_vibe", "Equal to (alias for ==)"],
        ],
        [50, 130]
    )
    
    pdf.add_section_header("Logical Operators", level=2)
    pdf.add_table(
        ["Operator", "Description"],
        [
            ["&&", "Logical AND"],
            ["||", "Logical OR"],
            ["!", "Logical NOT"],
        ],
        [50, 130]
    )
    
    pdf.add_section_header("Assignment Operators", level=2)
    pdf.add_table(
        ["Operator", "Description", "Equivalent"],
        [
            ["=", "Assignment", "x = 5"],
            ["+=", "Add and assign", "x = x + 5"],
            ["-=", "Subtract and assign", "x = x - 5"],
            ["*=", "Multiply and assign", "x = x * 5"],
            ["/=", "Divide and assign", "x = x / 5"],
            ["%=", "Modulo and assign", "x = x % 5"],
            ["++", "Increment by 1", "x = x + 1"],
            ["--", "Decrement by 1", "x = x - 1"],
        ],
        [40, 70, 70]
    )
    
    pdf.add_section_header("Power Operations Example (power_ops.homie)", level=2)
    pdf.add_code_block("""sup {
    spit("=== Testing Power Operator (**) ===");
    
    var result = 2 ** 10;
    spit("2 ** 10 = " + str(result));  // 1024
    
    result = 3 ** 4;
    spit("3 ** 4 = " + str(result));   // 81
    
    result = 10 ** 0;
    spit("10 ** 0 = " + str(result));  // 1
    
    // Right-associative: 2 ** 3 ** 2 = 2 ** 9 = 512
    result = 2 ** 3 ** 2;
    spit("2 ** 3 ** 2 = " + str(result));  // 512
    
    spit("=== Testing Integer Division (//) ===");
    
    result = 7 // 2;
    spit("7 // 2 = " + str(result));   // 3
    
    result = 10 // 3;
    spit("10 // 3 = " + str(result));  // 3
    
    peace;
}""")
    
    pdf.add_section_header("Compound Ops Example (compound_ops.homie)", level=2)
    pdf.add_code_block("""sup {
    spit("=== Testing Compound Assignment ===");
    
    var x = 100;
    spit("Initial x = " + str(x));
    
    x += 50;
    spit("After x += 50: " + str(x));  // 150
    
    x -= 30;
    spit("After x -= 30: " + str(x));  // 120
    
    x *= 2;
    spit("After x *= 2: " + str(x));   // 240
    
    x /= 4;
    spit("After x /= 4: " + str(x));   // 60
    
    x %= 7;
    spit("After x %= 7: " + str(x));   // 4
    
    spit("=== Testing Increment/Decrement ===");
    
    var count = 0;
    spit("Initial count = " + str(count));
    
    count++;
    spit("After count++: " + str(count));  // 1
    
    count++;
    count++;
    spit("After two more count++: " + str(count));  // 3
    
    count--;
    spit("After count--: " + str(count));  // 2
    
    peace;
}""")
    
    # ==================== 11. DATA STRUCTURES ====================
    pdf.add_page()
    pdf.add_section_header("11. Data Structures (Squads/Arrays)")
    pdf.add_paragraph(
        "Lists in Bro Code are called 'Squads'. They are mutable, ordered collections "
        "that can hold any type of value including mixed types."
    )
    
    pdf.add_section_header("Squad Basics", level=2)
    pdf.add_code_block("""var squad = [1, 2, 3, 4, 5];    // Create a squad
spit(squad[0]);                  // Access: 1
squad[0] = 100;                  // Modify element
spit(len(squad));                // Length: 5""")
    
    pdf.add_section_header("Instance Methods", level=2)
    pdf.add_paragraph("Called on the squad variable itself:")
    pdf.add_table(
        ["Method", "Description", "Example"],
        [
            ["push(value)", "Add to end", "squad.push(4)"],
            ["pop()", "Remove & return last", "var x = squad.pop()"],
        ],
        [50, 70, 60]
    )
    
    pdf.add_section_header("Global Array Functions", level=2)
    pdf.add_table(
        ["Function", "Description"],
        [
            ["len(arr)", "Returns number of elements"],
            ["sort(arr)", "Returns a new sorted squad"],
            ["reverse(arr)", "Returns a new reversed squad"],
            ["index_of(arr, val)", "Returns index or -1 if not found"],
            ["includes(arr, val)", "Returns boolean if value exists"],
            ["slice(arr, start, end)", "Returns portion of squad"],
            ["concat(arr1, arr2)", "Merges two squads into new one"],
            ["range(start, end, step)", "Generate sequence of integers"],
        ],
        [70, 110]
    )
    
    pdf.add_section_header("Squads Example (squads.homie)", level=2)
    pdf.add_code_block("""sup {
    var squad = [1, 2, 3, 4, 5];
    spit("Original squad: ");
    cycle (var num in squad) {
        spit(num);
    }
    
    // Access by index
    spit("First element: " + str(squad[0]));
    spit("Last element: " + str(squad[4]));
    
    // Get length
    spit("Squad size: " + str(len(squad)));
    
    // Push (add to end)
    squad.push(6);
    spit("After push(6), size: " + str(len(squad)));
    
    // Pop (remove from end)
    var popped = squad.pop();
    spit("Popped: " + str(popped));
    
    // Modify by index
    squad[0] = 100;
    spit("After squad[0] = 100: " + str(squad[0]));
    
    // Mixed type squad
    var mixed = ["hello", 42, no_cap, 3.14];
    spit("Mixed squad types:");
    cycle (var item in mixed) {
        spit("  " + str(item) + " (type: " + type(item) + ")");
    }
    
    peace;
}""")
    
    pdf.add_section_header("Array Functions Example (array_funcs.homie)", level=2)
    pdf.add_code_block("""sup {
    var squad = [3, 1, 4, 1, 5, 9, 2, 6];
    spit("Original squad: [3, 1, 4, 1, 5, 9, 2, 6]");
    
    // sort (returns new array)
    var sorted_squad = sort(squad);
    spit("sort(squad) = " + str(sorted_squad));
    
    // reverse (returns new array)
    var reversed = reverse(squad);
    spit("reverse(squad) = " + str(reversed));
    
    // slice
    var sliced = slice(squad, 2, 5);
    spit("slice(squad, 2, 5) = " + str(sliced));  // [4, 1, 5]
    
    // index_of
    spit("index_of(squad, 5) = " + str(index_of(squad, 5)));   // 4
    spit("index_of(squad, 99) = " + str(index_of(squad, 99))); // -1
    
    // includes
    spit("includes(squad, 9) = " + str(includes(squad, 9)));   // no_cap
    spit("includes(squad, 99) = " + str(includes(squad, 99))); // cap
    
    // concat
    var squad2 = [7, 8];
    var combined = concat(squad, squad2);
    spit("concat(squad, [7, 8]) = " + str(combined));
    
    // range with step
    var evens = range(0, 10, 2);
    spit("range(0, 10, 2) = " + str(evens));  // [0, 2, 4, 6, 8]
    
    peace;
}""")
    
    # ==================== 12. ERROR HANDLING ====================
    pdf.add_page()
    pdf.add_section_header("12. Error Handling")
    pdf.add_paragraph(
        "Handle runtime errors gracefully using 'shoot' (try) and 'fumble' (catch). "
        "The error variable in fumble contains the error message."
    )
    
    pdf.add_section_header("Syntax", level=2)
    pdf.add_code_block("""shoot {
    // Code that might cause an error
    var result = 10 / 0;
} 
fumble (error) {
    spit("Error: " + error);
}""")
    
    pdf.add_section_header("Error Handling Example (error_handling.homie)", level=2)
    pdf.add_code_block("""sup {
    spit("=== Error Handling Demo ===");
    
    // Catching a division error
    shoot {
        var result = 10 / 0;
        spit("Result: " + str(result));
    } 
    fumble (error) {
        spit("Caught error: " + error);
    }
    
    spit("Program continues after error handling!");
    
    // Successful try block
    shoot {
        var x = 10;
        var y = 2;
        spit("10 / 2 = " + str(x / y));
    }
    fumble (error) {
        spit("This won't print");
    }
    
    peace;
}""")
    
    # ==================== 13. BUILT-IN FUNCTIONS ====================
    pdf.add_page()
    pdf.add_section_header("13. Built-in Functions")
    pdf.add_paragraph("All built-in functions are available globally without any imports.")
    
    pdf.add_section_header("I/O Functions", level=2)
    pdf.add_table(
        ["Function", "Description", "Return Type"],
        [
            ["spit(value)", "Print value to stdout", "ghost"],
            ["listen(prompt)", "Read input from user", "string"],
        ],
        [60, 80, 40]
    )
    
    pdf.add_section_header("Type Conversion Functions", level=2)
    pdf.add_table(
        ["Function", "Description", "Return Type"],
        [
            ["int(value)", "Convert to integer", "integer"],
            ["float(value)", "Convert to float", "float"],
            ["str(value)", "Convert to string", "string"],
            ["type(value)", "Get type name", "string"],
        ],
        [60, 80, 40]
    )
    
    pdf.add_section_header("Math Functions", level=2)
    pdf.add_table(
        ["Function", "Description", "Return Type"],
        [
            ["abs(x)", "Absolute value", "number"],
            ["min(a, b)", "Minimum of two values", "number"],
            ["max(a, b)", "Maximum of two values", "number"],
            ["pow(base, exp)", "Exponentiation", "number"],
            ["sqrt(x)", "Square root", "float"],
            ["floor(x)", "Round down", "integer"],
            ["ceil(x)", "Round up", "integer"],
            ["round(x, digits)", "Round to precision", "number"],
        ],
        [60, 80, 40]
    )
    
    pdf.add_section_header("Math Functions Example (math_funcs.homie)", level=2)
    pdf.add_code_block("""sup {
    spit("=== Testing Math Functions ===");
    
    // abs
    spit("abs(-42) = " + str(abs(-42)));      // 42
    spit("abs(42) = " + str(abs(42)));        // 42
    
    // max/min
    spit("max(10, 20) = " + str(max(10, 20)));  // 20
    spit("min(10, 20) = " + str(min(10, 20)));  // 10
    
    // pow
    spit("pow(2, 8) = " + str(pow(2, 8)));     // 256
    
    // sqrt
    spit("sqrt(16) = " + str(sqrt(16)));       // 4.0
    spit("sqrt(2) = " + str(sqrt(2)));         // 1.414...
    
    // floor/ceil
    spit("floor(3.7) = " + str(floor(3.7)));   // 3
    spit("ceil(3.2) = " + str(ceil(3.2)));     // 4
    spit("floor(-3.2) = " + str(floor(-3.2))); // -4
    spit("ceil(-3.7) = " + str(ceil(-3.7)));   // -3
    
    // round
    spit("round(3.5) = " + str(round(3.5)));              // 4
    spit("round(3.14159, 2) = " + str(round(3.14159, 2))); // 3.14
    
    peace;
}""")
    
    pdf.add_page()
    pdf.add_section_header("String Functions", level=2)
    pdf.add_table(
        ["Function", "Description"],
        [
            ["upper(s)", "Convert to uppercase"],
            ["lower(s)", "Convert to lowercase"],
            ["trim(s)", "Remove whitespace from ends"],
            ["split(s, delim)", "Split string by delimiter"],
            ["join(arr, delim)", "Join array with delimiter"],
            ["replace(s, old, new)", "Replace all occurrences"],
            ["contains(s, sub)", "Check if contains substring"],
            ["starts_with(s, prefix)", "Check if starts with prefix"],
            ["ends_with(s, suffix)", "Check if ends with suffix"],
            ["char_at(s, index)", "Get character at index"],
            ["substring(s, start, end)", "Get substring"],
        ],
        [70, 110]
    )
    
    pdf.add_section_header("String Functions Example (string_funcs.homie)", level=2)
    pdf.add_code_block("""sup {
    spit("=== Testing String Functions ===");
    
    // upper/lower
    spit("upper('hello') = " + upper("hello"));     // HELLO
    spit("lower('WORLD') = " + lower("WORLD"));     // world
    
    // trim
    spit("trim('  hello  ') = '" + trim("  hello  ") + "'");  // 'hello'
    
    // split/join
    var words = split("apple,banana,cherry", ",");
    spit("split result:");
    cycle (var word in words) {
        spit("  - " + word);
    }
    
    var joined = join(words, " | ");
    spit("join with ' | ': " + joined);  // apple | banana | cherry
    
    // replace
    var msg = "Hello World";
    spit("replace 'World' with 'Bro': " + replace(msg, "World", "Bro"));
    
    // contains
    spit("contains('Hello', 'ell') = " + str(contains("Hello", "ell")));  // no_cap
    
    // starts_with/ends_with
    spit("starts_with('Hello', 'He') = " + str(starts_with("Hello", "He"))); // no_cap
    spit("ends_with('Hello', 'lo') = " + str(ends_with("Hello", "lo")));     // no_cap
    
    // char_at
    spit("char_at('Hello', 1) = " + char_at("Hello", 1));  // e
    
    // substring
    spit("substring('Hello World', 0, 5) = " + substring("Hello World", 0, 5)); // Hello
    
    peace;
}""")
    
    pdf.add_page()
    pdf.add_section_header("Utility Functions", level=2)
    pdf.add_table(
        ["Function", "Description", "Return Type"],
        [
            ["random()", "Random float 0-1", "float"],
            ["random_int(min, max)", "Random int (inclusive)", "integer"],
            ["time()", "Current Unix timestamp", "float"],
        ],
        [70, 70, 40]
    )
    
    pdf.add_section_header("Utility Functions Example (utility_funcs.homie)", level=2)
    pdf.add_code_block("""sup {
    spit("=== Testing Utility Functions ===");
    
    // random (float 0-1)
    spit("random() = " + str(random()));
    spit("random() = " + str(random()));
    spit("random() = " + str(random()));
    
    spit("=== Testing random_int ===");
    
    // random_int (inclusive)
    spit("random_int(1, 10) = " + str(random_int(1, 10)));
    spit("random_int(1, 10) = " + str(random_int(1, 10)));
    spit("random_int(1, 10) = " + str(random_int(1, 10)));
    
    spit("=== Testing time ===");
    
    // time (current timestamp)
    var start = time();
    spit("Current timestamp: " + str(start));
    
    // Small delay simulation
    var sum = 0;
    cycle (var i in range(0, 10000)) {
        sum += i;
    }
    
    var end = time();
    spit("After loop timestamp: " + str(end));
    spit("Elapsed time: " + str(end - start) + " seconds");
    
    peace;
}""")
    
    # ==================== 14. EXAMPLE PROGRAMS ====================
    pdf.add_page()
    pdf.add_section_header("14. Example Programs")
    pdf.add_paragraph(
        "The following examples demonstrate practical use of Bro Code features. "
        "All examples are available in the examples/ directory of the repository."
    )
    
    pdf.add_section_header("FizzBuzz (fizzbuzz.homie)", level=2)
    pdf.add_code_block("""// FizzBuzz in Bro Code
// Classic programming challenge

gig fizzBuzz(n) {
    cycle (var i in range(1, n + 1)) {
        fr (i % 15 is_vibe 0) {
            spit("FizzBuzz");
        } 
        meh (i % 3 is_vibe 0) {
            spit("Fizz");
        } 
        meh (i % 5 is_vibe 0) {
            spit("Buzz");
        } 
        nah {
            spit(i);
        }
    }
}

sup {
    spit("=== FizzBuzz (1-20) ===");
    fizzBuzz(20);
    peace;
}""")
    
    pdf.add_section_header("Fibonacci Sequence (fibonacci.homie)", level=2)
    pdf.add_code_block("""// Fibonacci Sequence in Bro Code

gig fibonacci(n) {
    fr (n <= 0) {
        pay 0;
    }
    fr (n is_vibe 1) {
        pay 1;
    }
    
    var a = 0;
    var b = 1;
    var result = 0;
    var i = 2;
    
    hold_up (i <= n) {
        result = a + b;
        a = b;
        b = result;
        i = i + 1;
    }
    
    pay result;
}

sup {
    spit("=== Fibonacci Sequence ===");
    
    cycle (var i in range(0, 15)) {
        spit("fib(" + str(i) + ") = " + str(fibonacci(i)));
    }
    
    peace;
}""")
    
    pdf.add_section_header("Negative Numbers (negative_numbers.homie)", level=2)
    pdf.add_code_block("""sup {
    spit("=== Testing Negative Numbers ===");
    
    var n1 = -5;
    spit("n1 = " + str(n1));  // -5
    
    var n2 = 10 + -3;
    spit("10 + -3 = " + str(n2));  // 7
    
    var n3 = -(-5);
    spit("-(-5) = " + str(n3));  // 5
    
    var n4 = 5 * -2;
    spit("5 * -2 = " + str(n4));  // -10
    
    var n5 = -10 / 2;
    spit("-10 / 2 = " + str(n5));  // -5
    
    var n6 = -5.5;
    spit("n6 = " + str(n6));  // -5.5
    
    // Test negative in function args
    spit("abs(-50) = " + str(abs(-50)));
    
    peace;
}""")
    
    # ==================== APPENDIX A: QUICK REFERENCE ====================
    pdf.add_page()
    pdf.add_section_header("Appendix A: Quick Reference Cheat Sheet")
    pdf.add_table(
        ["Feature", "Bro Code", "Python"],
        [
            ["Main block", "sup { ... }", 'if __name__ == "__main__":'],
            ["Exit", "peace;", "exit()"],
            ["Print", "spit(x)", "print(x)"],
            ["Input", "listen(prompt)", "input(prompt)"],
            ["Variable", "var x = 1;", "x = 1"],
            ["Constant", "const X = 1;", "X = 1 (convention)"],
            ["True/False", "no_cap / cap", "True / False"],
            ["Null", "ghost", "None"],
            ["If", "fr (cond) { }", "if cond:"],
            ["Else if", "meh (cond) { }", "elif cond:"],
            ["Else", "nah { }", "else:"],
            ["While", "hold_up (cond) { }", "while cond:"],
            ["For", "cycle (var i in range(0, n)) { }", "for i in range(n):"],
            ["Break", "dip;", "break"],
            ["Continue", "skip;", "continue"],
            ["Function", "gig name(x = 10) { }", "def name(x=10):"],
            ["Return", "pay x;", "return x"],
            ["Equality", "is_vibe or ==", "=="],
            ["Try", "shoot { }", "try:"],
            ["Catch", "fumble (e) { }", "except Exception as e:"],
            ["Power", "2 ** 10", "2 ** 10"],
            ["Int Division", "7 // 2", "7 // 2"],
            ["Increment", "i++;", "i += 1"],
        ],
        [45, 80, 55]
    )
    
    # ==================== APPENDIX B: RESERVED KEYWORDS ====================
    pdf.add_page()
    pdf.add_section_header("Appendix B: Reserved Keywords")
    pdf.add_paragraph(
        "The following keywords are reserved and cannot be used as variable "
        "or function names:"
    )
    pdf.add_code_block("""sup, peace, var, const, fr, meh, nah, hold_up, cycle, in,
gig, pay, shoot, fumble, no_cap, cap, ghost, is_vibe, dip, skip""")
    
    # ==================== APPENDIX C: CLI OPTIONS ====================
    pdf.add_section_header("Appendix C: CLI Options")
    pdf.add_code_block("""brocode <file.homie>           # Run a file
brocode --version              # Show version
brocode --tokens file.homie    # Debug: show tokens
brocode --ast file.homie       # Debug: show AST""")
    
    # ==================== PROJECT STRUCTURE ====================
    pdf.add_section_header("Appendix D: Project Structure")
    pdf.add_code_block("""Bro-CODE/
|-- brocode/
|   |-- __init__.py      # Package info
|   |-- __main__.py      # CLI entry point
|   |-- tokens.py        # Token definitions
|   |-- lexer.py         # Tokenizer
|   |-- parser.py        # AST builder
|   |-- ast_nodes.py     # AST node classes
|   |-- interpreter.py   # Executor
|   |-- builtins.py      # Built-in functions
|   |-- errors.py        # Exception classes
|-- examples/            # Sample programs (19 files)
|-- docs/                # Documentation
|-- bro                  # CLI wrapper script
|-- README.md""")
    
    # ==================== EXAMPLE FILES LIST ====================
    pdf.add_section_header("Appendix E: Example Files")
    pdf.add_paragraph("All example files in the examples/ directory:")
    
    examples = [
        "hello.homie - Hello World",
        "variables.homie - Data types and operations",
        "conditionals.homie - fr/meh/nah (if/else)",
        "loops.homie - hold_up and cycle loops",
        "functions.homie - gig/pay with recursion",
        "squads.homie - Array operations",
        "fibonacci.homie - Fibonacci sequence",
        "fizzbuzz.homie - Classic FizzBuzz",
        "error_handling.homie - shoot/fumble (try/catch)",
        "input.homie - Interactive input",
        "break_continue.homie - dip/skip (break/continue)",
        "compound_ops.homie - +=, -=, ++, -- operators",
        "default_params.homie - Function default parameters",
        "power_ops.homie - ** and // operators",
        "math_funcs.homie - Math built-in functions",
        "string_funcs.homie - String built-in functions",
        "array_funcs.homie - Array built-in functions",
        "utility_funcs.homie - Utility functions",
        "negative_numbers.homie - Negative number handling",
    ]
    
    for example in examples:
        pdf.add_bullet(example)
    
    # Save PDF
    output_path = "/mnt/secondary_ssd/projects/Bro-CODE/docs/BroCode_Documentation.pdf"
    pdf.output(output_path)
    print(f"PDF generated successfully: {output_path}")
    return output_path


if __name__ == "__main__":
    create_pdf()
