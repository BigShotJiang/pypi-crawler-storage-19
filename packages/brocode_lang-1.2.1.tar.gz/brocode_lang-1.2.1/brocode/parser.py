"""
Parser for Bro Code - Builds AST from tokens.
"""

from typing import List, Optional
from .tokens import Token, TokenType
from .ast_nodes import *
from .errors import ParserError, unexpected_token, program_must_start_with_sup, default_params_must_come_last


class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
    
    @property
    def current(self) -> Token:
        if self.pos >= len(self.tokens):
            return self.tokens[-1]  # Return EOF
        return self.tokens[self.pos]
    
    def peek(self, offset: int = 1) -> Token:
        pos = self.pos + offset
        if pos >= len(self.tokens):
            return self.tokens[-1]
        return self.tokens[pos]
    
    def advance(self) -> Token:
        token = self.current
        self.pos += 1
        return token
    
    def check(self, *types: TokenType) -> bool:
        return self.current.type in types
    
    def match(self, *types: TokenType) -> Optional[Token]:
        if self.check(*types):
            return self.advance()
        return None
    
    def expect(self, token_type: TokenType, message: str = None) -> Token:
        if self.current.type == token_type:
            return self.advance()
        msg = message or f"Expected {token_type.name}, got {self.current.type.name}"
        raise ParserError(msg, self.current.line, self.current.column)
    
    def parse(self) -> ProgramNode:
        """Parse the entire program."""
        program = ProgramNode(line=1)
        
        # Parse function definitions first
        while self.check(TokenType.GIG):
            program.functions.append(self.parse_function_def())
        
        # Parse sup block
        if not self.check(TokenType.SUP):
            raise ParserError(program_must_start_with_sup(), self.current.line, self.current.column)
        
        self.expect(TokenType.SUP)
        program.sup_block = self.parse_block()
        
        return program
    
    def parse_block(self) -> BlockNode:
        """Parse a block of statements enclosed in {}."""
        self.expect(TokenType.LBRACE, "Expected '{'")
        block = BlockNode(line=self.current.line)
        
        while not self.check(TokenType.RBRACE, TokenType.EOF):
            stmt = self.parse_statement()
            if stmt:
                block.statements.append(stmt)
        
        self.expect(TokenType.RBRACE, "Expected '}'")
        return block
    
    def parse_statement(self) -> Optional[ASTNode]:
        """Parse a single statement."""
        token = self.current
        
        if self.check(TokenType.VAR):
            return self.parse_var_decl(is_const=False)
        
        if self.check(TokenType.CONST):
            return self.parse_var_decl(is_const=True)
        
        if self.check(TokenType.FR):
            return self.parse_if()
        
        if self.check(TokenType.HOLD_UP):
            return self.parse_while()
        
        if self.check(TokenType.CYCLE):
            return self.parse_for()
        
        if self.check(TokenType.PAY):
            return self.parse_return()
        
        if self.check(TokenType.PEACE):
            self.advance()
            self.expect(TokenType.SEMICOLON, "Expected ';' after 'peace'")
            return PeaceNode(line=token.line)
        
        if self.check(TokenType.DIP):
            self.advance()
            self.expect(TokenType.SEMICOLON, "Expected ';' after 'dip'")
            return BreakNode(line=token.line)
        
        if self.check(TokenType.SKIP):
            self.advance()
            self.expect(TokenType.SEMICOLON, "Expected ';' after 'skip'")
            return ContinueNode(line=token.line)
        
        if self.check(TokenType.SHOOT):
            return self.parse_try()
        
        # Expression statement (assignment or function call)
        expr = self.parse_expression()
        
        # Check for increment/decrement
        if isinstance(expr, IdentifierNode) and self.check(TokenType.PLUS_PLUS):
            self.advance()  # ++
            self.expect(TokenType.SEMICOLON, "Expected ';' after '++'")
            return IncrementNode(name=expr.name, line=expr.line)
        
        if isinstance(expr, IdentifierNode) and self.check(TokenType.MINUS_MINUS):
            self.advance()  # --
            self.expect(TokenType.SEMICOLON, "Expected ';' after '--'")
            return DecrementNode(name=expr.name, line=expr.line)
        
        # Check for compound assignment
        compound_ops = {
            TokenType.PLUS_EQUAL: '+',
            TokenType.MINUS_EQUAL: '-',
            TokenType.STAR_EQUAL: '*',
            TokenType.SLASH_EQUAL: '/',
            TokenType.PERCENT_EQUAL: '%',
        }
        
        if isinstance(expr, IdentifierNode) and self.check(*compound_ops.keys()):
            op_token = self.advance()
            op = compound_ops[op_token.type]
            value = self.parse_expression()
            self.expect(TokenType.SEMICOLON, "Expected ';' after compound assignment")
            return CompoundAssignNode(name=expr.name, operator=op, value=value, line=expr.line)
        
        if isinstance(expr, IndexAccessNode) and self.check(*compound_ops.keys()):
            op_token = self.advance()
            op = compound_ops[op_token.type]
            value = self.parse_expression()
            self.expect(TokenType.SEMICOLON, "Expected ';' after compound assignment")
            return IndexCompoundAssignNode(array=expr.array, index=expr.index, operator=op, value=value, line=expr.line)
        
        # Check for assignment
        if isinstance(expr, IdentifierNode) and self.check(TokenType.EQUAL):
            self.advance()  # =
            value = self.parse_expression()
            self.expect(TokenType.SEMICOLON, "Expected ';' after assignment")
            return AssignNode(name=expr.name, value=value, line=expr.line)
        
        # Check for index assignment
        if isinstance(expr, IndexAccessNode) and self.check(TokenType.EQUAL):
            self.advance()  # =
            value = self.parse_expression()
            self.expect(TokenType.SEMICOLON, "Expected ';'")
            return IndexAssignNode(array=expr.array, index=expr.index, value=value, line=expr.line)
        
        self.expect(TokenType.SEMICOLON, "Expected ';' after expression")
        return expr
    
    def parse_var_decl(self, is_const: bool) -> VarDeclNode:
        """Parse variable/constant declaration."""
        token = self.advance()  # var or const
        name_token = self.expect(TokenType.IDENTIFIER, "Expected variable name")
        
        value = None
        if self.match(TokenType.EQUAL):
            value = self.parse_expression()
        
        self.expect(TokenType.SEMICOLON, "Expected ';' after declaration")
        return VarDeclNode(name=name_token.value, value=value, is_const=is_const, line=token.line)
    
    def parse_if(self) -> IfNode:
        """Parse fr/meh/nah conditional."""
        token = self.advance()  # fr
        self.expect(TokenType.LPAREN, "Expected '(' after 'fr'")
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN, "Expected ')' after condition")
        
        then_block = self.parse_block()
        
        elif_blocks = []
        while self.check(TokenType.MEH):
            self.advance()  # meh
            self.expect(TokenType.LPAREN, "Expected '(' after 'meh'")
            elif_cond = self.parse_expression()
            self.expect(TokenType.RPAREN, "Expected ')' after condition")
            elif_block = self.parse_block()
            elif_blocks.append((elif_cond, elif_block))
        
        else_block = None
        if self.check(TokenType.NAH):
            self.advance()  # nah
            else_block = self.parse_block()
        
        return IfNode(
            condition=condition,
            then_block=then_block,
            elif_blocks=elif_blocks,
            else_block=else_block,
            line=token.line
        )
    
    def parse_while(self) -> WhileNode:
        """Parse hold_up loop."""
        token = self.advance()  # hold_up
        self.expect(TokenType.LPAREN, "Expected '(' after 'hold_up'")
        condition = self.parse_expression()
        self.expect(TokenType.RPAREN, "Expected ')' after condition")
        body = self.parse_block()
        return WhileNode(condition=condition, body=body, line=token.line)
    
    def parse_for(self) -> ForNode:
        """Parse cycle loop."""
        token = self.advance()  # cycle
        self.expect(TokenType.LPAREN, "Expected '(' after 'cycle'")
        
        # Parse: var i in range(...)
        self.expect(TokenType.VAR, "Expected 'var' in cycle")
        var_name = self.expect(TokenType.IDENTIFIER, "Expected variable name").value
        self.expect(TokenType.IN, "Expected 'in' after variable")
        iterable = self.parse_expression()
        
        self.expect(TokenType.RPAREN, "Expected ')' after iterable")
        body = self.parse_block()
        
        return ForNode(var_name=var_name, iterable=iterable, body=body, line=token.line)
    
    def parse_return(self) -> ReturnNode:
        """Parse pay (return) statement."""
        token = self.advance()  # pay
        value = None
        if not self.check(TokenType.SEMICOLON):
            value = self.parse_expression()
        self.expect(TokenType.SEMICOLON, "Expected ';' after return value")
        return ReturnNode(value=value, line=token.line)
    
    def parse_try(self) -> TryNode:
        """Parse shoot/fumble (try/catch)."""
        token = self.advance()  # shoot
        try_block = self.parse_block()
        
        self.expect(TokenType.FUMBLE, "Expected 'fumble' after 'shoot' block")
        self.expect(TokenType.LPAREN, "Expected '(' after 'fumble'")
        error_name = self.expect(TokenType.IDENTIFIER, "Expected error variable name").value
        self.expect(TokenType.RPAREN, "Expected ')' after error variable")
        catch_block = self.parse_block()
        
        return TryNode(
            try_block=try_block,
            error_name=error_name,
            catch_block=catch_block,
            line=token.line
        )
    
    def parse_function_def(self) -> FunctionDefNode:
        """Parse gig (function) definition with optional default parameters."""
        token = self.advance()  # gig
        name = self.expect(TokenType.IDENTIFIER, "Expected function name").value
        
        self.expect(TokenType.LPAREN, "Expected '(' after function name")
        params = []
        param_defaults = []
        seen_default = False
        
        if not self.check(TokenType.RPAREN):
            # Parse first parameter
            param_name = self.expect(TokenType.IDENTIFIER).value
            params.append(param_name)
            
            # Check for default value
            if self.match(TokenType.EQUAL):
                default_value = self.parse_expression()
                param_defaults.append(default_value)
                seen_default = True
            else:
                param_defaults.append(None)
            
            # Parse remaining parameters
            while self.match(TokenType.COMMA):
                param_name = self.expect(TokenType.IDENTIFIER).value
                params.append(param_name)
                
                if self.match(TokenType.EQUAL):
                    default_value = self.parse_expression()
                    param_defaults.append(default_value)
                    seen_default = True
                else:
                    if seen_default:
                        raise ParserError(
                            default_params_must_come_last(),
                            self.current.line, self.current.column
                        )
                    param_defaults.append(None)
        
        self.expect(TokenType.RPAREN, "Expected ')' after parameters")
        body = self.parse_block()
        
        return FunctionDefNode(name=name, params=params, param_defaults=param_defaults, body=body, line=token.line)
    
    def parse_expression(self) -> ASTNode:
        """Parse expression with lowest precedence."""
        return self.parse_or()
    
    def parse_or(self) -> ASTNode:
        """Parse || expressions."""
        left = self.parse_and()
        while self.check(TokenType.OR):
            op = self.advance()
            right = self.parse_and()
            left = BinaryOpNode(left=left, operator='||', right=right, line=op.line)
        return left
    
    def parse_and(self) -> ASTNode:
        """Parse && expressions."""
        left = self.parse_equality()
        while self.check(TokenType.AND):
            op = self.advance()
            right = self.parse_equality()
            left = BinaryOpNode(left=left, operator='&&', right=right, line=op.line)
        return left
    
    def parse_equality(self) -> ASTNode:
        """Parse == and != expressions."""
        left = self.parse_comparison()
        while self.check(TokenType.EQUAL_EQUAL, TokenType.IS_VIBE, TokenType.NOT_EQUAL):
            op = self.advance()
            right = self.parse_comparison()
            operator = '==' if op.type in (TokenType.EQUAL_EQUAL, TokenType.IS_VIBE) else '!='
            left = BinaryOpNode(left=left, operator=operator, right=right, line=op.line)
        return left
    
    def parse_comparison(self) -> ASTNode:
        """Parse comparison expressions."""
        left = self.parse_additive()
        while self.check(TokenType.LESS, TokenType.GREATER, TokenType.LESS_EQUAL, TokenType.GREATER_EQUAL):
            op = self.advance()
            right = self.parse_additive()
            left = BinaryOpNode(left=left, operator=op.value, right=right, line=op.line)
        return left
    
    def parse_additive(self) -> ASTNode:
        """Parse + and - expressions."""
        left = self.parse_multiplicative()
        while self.check(TokenType.PLUS, TokenType.MINUS):
            op = self.advance()
            right = self.parse_multiplicative()
            left = BinaryOpNode(left=left, operator=op.value, right=right, line=op.line)
        return left
    
    def parse_multiplicative(self) -> ASTNode:
        """Parse *, /, %, // expressions."""
        left = self.parse_power()
        while self.check(TokenType.STAR, TokenType.SLASH, TokenType.PERCENT, TokenType.SLASH_SLASH):
            op = self.advance()
            right = self.parse_power()
            # Map // to 'floordiv' operator
            operator = '//' if op.type == TokenType.SLASH_SLASH else op.value
            left = BinaryOpNode(left=left, operator=operator, right=right, line=op.line)
        return left
    
    def parse_power(self) -> ASTNode:
        """Parse ** (power) expressions. Right-associative like Python."""
        left = self.parse_unary()
        if self.check(TokenType.STAR_STAR):
            op = self.advance()
            right = self.parse_power()  # Right-associative
            left = BinaryOpNode(left=left, operator='**', right=right, line=op.line)
        return left
    
    def parse_unary(self) -> ASTNode:
        """Parse unary operators."""
        if self.check(TokenType.NOT, TokenType.MINUS):
            op = self.advance()
            operand = self.parse_unary()
            return UnaryOpNode(operator=op.value, operand=operand, line=op.line)
        return self.parse_postfix()
    
    def parse_postfix(self) -> ASTNode:
        """Parse postfix operations (array access, method calls)."""
        expr = self.parse_primary()
        
        while True:
            if self.check(TokenType.LBRACKET):
                self.advance()  # [
                index = self.parse_expression()
                self.expect(TokenType.RBRACKET, "Expected ']'")
                expr = IndexAccessNode(array=expr, index=index, line=expr.line)
            elif self.check(TokenType.DOT):
                self.advance()  # .
                method = self.expect(TokenType.IDENTIFIER, "Expected method name").value
                self.expect(TokenType.LPAREN, "Expected '(' after method name")
                args = self.parse_arguments()
                self.expect(TokenType.RPAREN, "Expected ')' after arguments")
                expr = MethodCallNode(object=expr, method=method, arguments=args, line=expr.line)
            elif self.check(TokenType.LPAREN) and isinstance(expr, IdentifierNode):
                # Function call
                self.advance()  # (
                args = self.parse_arguments()
                self.expect(TokenType.RPAREN, "Expected ')' after arguments")
                expr = FunctionCallNode(name=expr.name, arguments=args, line=expr.line)
            else:
                break
        
        return expr
    
    def parse_arguments(self) -> List[ASTNode]:
        """Parse function arguments."""
        args = []
        if not self.check(TokenType.RPAREN):
            args.append(self.parse_expression())
            while self.match(TokenType.COMMA):
                args.append(self.parse_expression())
        return args
    
    def parse_primary(self) -> ASTNode:
        """Parse primary expressions."""
        token = self.current
        
        if self.match(TokenType.INTEGER):
            return IntegerNode(value=token.value, line=token.line)
        
        if self.match(TokenType.FLOAT):
            return FloatNode(value=token.value, line=token.line)
        
        if self.match(TokenType.STRING):
            return StringNode(value=token.value, line=token.line)
        
        if self.match(TokenType.NO_CAP):
            return BooleanNode(value=True, line=token.line)
        
        if self.match(TokenType.CAP):
            return BooleanNode(value=False, line=token.line)
        
        if self.match(TokenType.GHOST):
            return NullNode(line=token.line)
        
        if self.match(TokenType.IDENTIFIER):
            return IdentifierNode(name=token.value, line=token.line)
        
        if self.match(TokenType.LBRACKET):
            # Array literal
            elements = []
            if not self.check(TokenType.RBRACKET):
                elements.append(self.parse_expression())
                while self.match(TokenType.COMMA):
                    elements.append(self.parse_expression())
            self.expect(TokenType.RBRACKET, "Expected ']'")
            return ArrayNode(elements=elements, line=token.line)
        
        if self.match(TokenType.LPAREN):
            expr = self.parse_expression()
            self.expect(TokenType.RPAREN, "Expected ')'")
            return expr
        
        raise ParserError(unexpected_token(token.type.name), token.line, token.column)


def parse(tokens: List[Token]) -> ProgramNode:
    """Convenience function to parse tokens into AST."""
    parser = Parser(tokens)
    return parser.parse()
