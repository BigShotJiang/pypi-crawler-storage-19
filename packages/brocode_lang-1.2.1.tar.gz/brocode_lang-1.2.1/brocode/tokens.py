"""
Token definitions for Bro Code lexer.
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Any


class TokenType(Enum):
    # Literals
    INTEGER = auto()
    FLOAT = auto()
    STRING = auto()
    IDENTIFIER = auto()
    
    # Boolean & Null
    NO_CAP = auto()      # True
    CAP = auto()         # False
    GHOST = auto()       # Null
    
    # Keywords
    SUP = auto()         # Main block
    PEACE = auto()       # Exit
    VAR = auto()         # Variable declaration
    CONST = auto()       # Constant declaration
    
    # Conditionals
    FR = auto()          # if
    MEH = auto()         # else if
    NAH = auto()         # else
    
    # Loops
    HOLD_UP = auto()     # while
    CYCLE = auto()       # for
    IN = auto()          # in (for loops)
    
    # Functions
    GIG = auto()         # function def
    PAY = auto()         # return
    
    # Error handling
    SHOOT = auto()       # try
    FUMBLE = auto()      # catch
    
    # Loop control
    DIP = auto()         # break
    SKIP = auto()        # continue
    
    # Operators
    PLUS = auto()        # +
    MINUS = auto()       # -
    STAR = auto()        # *
    SLASH = auto()       # /
    PERCENT = auto()     # %
    STAR_STAR = auto()   # ** (power)
    SLASH_SLASH = auto() # // (integer division)
    
    # Increment/Decrement
    PLUS_PLUS = auto()   # ++
    MINUS_MINUS = auto() # --
    
    # Comparison
    IS_VIBE = auto()     # ==
    EQUAL_EQUAL = auto() # == (alternative)
    NOT_EQUAL = auto()   # !=
    LESS = auto()        # <
    GREATER = auto()     # >
    LESS_EQUAL = auto()  # <=
    GREATER_EQUAL = auto() # >=
    
    # Logical
    AND = auto()         # &&
    OR = auto()          # ||
    NOT = auto()         # !
    
    # Assignment
    EQUAL = auto()       # =
    PLUS_EQUAL = auto()  # +=
    MINUS_EQUAL = auto() # -=
    STAR_EQUAL = auto()  # *=
    SLASH_EQUAL = auto() # /=
    PERCENT_EQUAL = auto() # %=
    
    # Delimiters
    LPAREN = auto()      # (
    RPAREN = auto()      # )
    LBRACE = auto()      # {
    RBRACE = auto()      # }
    LBRACKET = auto()    # [
    RBRACKET = auto()    # ]
    COMMA = auto()       # ,
    SEMICOLON = auto()   # ;
    DOT = auto()         # .
    
    # Special
    EOF = auto()
    NEWLINE = auto()


@dataclass
class Token:
    type: TokenType
    value: Any
    line: int
    column: int
    
    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, line={self.line})"


# Keyword mappings
KEYWORDS = {
    "sup": TokenType.SUP,
    "peace": TokenType.PEACE,
    "var": TokenType.VAR,
    "const": TokenType.CONST,
    "fr": TokenType.FR,
    "meh": TokenType.MEH,
    "nah": TokenType.NAH,
    "hold_up": TokenType.HOLD_UP,
    "cycle": TokenType.CYCLE,
    "in": TokenType.IN,
    "gig": TokenType.GIG,
    "pay": TokenType.PAY,
    "shoot": TokenType.SHOOT,
    "fumble": TokenType.FUMBLE,
    "no_cap": TokenType.NO_CAP,
    "cap": TokenType.CAP,
    "ghost": TokenType.GHOST,
    "is_vibe": TokenType.IS_VIBE,
    "dip": TokenType.DIP,
    "skip": TokenType.SKIP,
}
