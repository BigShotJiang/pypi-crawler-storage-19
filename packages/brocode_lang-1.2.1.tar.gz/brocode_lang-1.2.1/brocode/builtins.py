"""
Built-in functions for Bro Code.
"""

from typing import List, Any, Callable, Dict
import math
import random as random_module
import time as time_module


class BroCodeArray(list):
    """Custom array class with Bro Code methods."""
    
    def push(self, value):
        """Add item to end of array."""
        self.append(value)
        return value
    
    def pop(self):
        """Remove and return last item."""
        if len(self) == 0:
            return None
        return super().pop()


# ============================================
# I/O Functions
# ============================================

def builtin_spit(*args) -> None:
    """Print to stdout."""
    output = ' '.join(str(arg) for arg in args)
    print(output)


def builtin_listen(prompt: str = "") -> str:
    """Read input from user."""
    return input(prompt)


# ============================================
# Type Conversion Functions
# ============================================

def builtin_int(value) -> int:
    """Convert value to integer."""
    return int(value)


def builtin_float(value) -> float:
    """Convert value to float."""
    return float(value)


def builtin_str(value) -> str:
    """Convert value to string."""
    if value is None:
        return "ghost"
    if value is True:
        return "no_cap"
    if value is False:
        return "cap"
    return str(value)


def builtin_type(value) -> str:
    """Get type of value."""
    if value is None:
        return "ghost"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "string"
    if isinstance(value, (list, BroCodeArray)):
        return "squad"
    return "unknown"


# ============================================
# Collection Functions
# ============================================

def builtin_range(start: int, end: int, step: int = 1) -> BroCodeArray:
    """Generate a range of numbers."""
    return BroCodeArray(range(int(start), int(end), int(step)))


def builtin_len(obj) -> int:
    """Get length of array or string."""
    return len(obj)


# ============================================
# Math Functions
# ============================================

def builtin_abs(x) -> Any:
    """Absolute value."""
    return abs(x)


def builtin_max(a, b) -> Any:
    """Maximum of two values."""
    return max(a, b)


def builtin_min(a, b) -> Any:
    """Minimum of two values."""
    return min(a, b)


def builtin_pow(base, exp) -> Any:
    """Power/exponentiation."""
    return base ** exp


def builtin_sqrt(x) -> float:
    """Square root."""
    return math.sqrt(x)


def builtin_floor(x) -> int:
    """Floor - round down to nearest integer."""
    return math.floor(x)


def builtin_ceil(x) -> int:
    """Ceiling - round up to nearest integer."""
    return math.ceil(x)


def builtin_round(x, digits: int = 0) -> Any:
    """Round to specified number of digits."""
    if digits == 0:
        return round(x)
    return round(x, int(digits))


# ============================================
# String Functions
# ============================================

def builtin_upper(s: str) -> str:
    """Convert string to uppercase."""
    return s.upper()


def builtin_lower(s: str) -> str:
    """Convert string to lowercase."""
    return s.lower()


def builtin_trim(s: str) -> str:
    """Strip whitespace from both ends."""
    return s.strip()


def builtin_split(s: str, delimiter: str = " ") -> BroCodeArray:
    """Split string by delimiter."""
    return BroCodeArray(s.split(delimiter))


def builtin_join(arr, delimiter: str = "") -> str:
    """Join array elements into string."""
    return delimiter.join(str(x) for x in arr)


def builtin_replace(s: str, old: str, new: str) -> str:
    """Replace all occurrences of old with new."""
    return s.replace(old, new)


def builtin_contains(s: str, sub: str) -> bool:
    """Check if string contains substring."""
    return sub in s


def builtin_starts_with(s: str, prefix: str) -> bool:
    """Check if string starts with prefix."""
    return s.startswith(prefix)


def builtin_ends_with(s: str, suffix: str) -> bool:
    """Check if string ends with suffix."""
    return s.endswith(suffix)


def builtin_char_at(s: str, index: int) -> str:
    """Get character at index."""
    idx = int(index)
    if idx < 0 or idx >= len(s):
        return ""
    return s[idx]


def builtin_substring(s: str, start: int, end: int = None) -> str:
    """Get substring from start to end."""
    start = int(start)
    if end is None:
        return s[start:]
    return s[start:int(end)]


# ============================================
# Array Functions
# ============================================

def builtin_sort(arr) -> BroCodeArray:
    """Return a new sorted array."""
    return BroCodeArray(sorted(arr))


def builtin_reverse(arr) -> BroCodeArray:
    """Return a new reversed array."""
    return BroCodeArray(reversed(arr))


def builtin_slice(arr, start: int, end: int = None) -> BroCodeArray:
    """Get a slice of the array."""
    start = int(start)
    if end is None:
        return BroCodeArray(arr[start:])
    return BroCodeArray(arr[start:int(end)])


def builtin_index_of(arr, value) -> int:
    """Find index of value in array. Returns -1 if not found."""
    try:
        return arr.index(value)
    except ValueError:
        return -1


def builtin_includes(arr, value) -> bool:
    """Check if array includes value."""
    return value in arr


def builtin_concat(arr1, arr2) -> BroCodeArray:
    """Concatenate two arrays."""
    return BroCodeArray(list(arr1) + list(arr2))


# ============================================
# Utility Functions
# ============================================

def builtin_random() -> float:
    """Random float between 0 and 1."""
    return random_module.random()


def builtin_random_int(min_val: int, max_val: int) -> int:
    """Random integer between min and max (inclusive)."""
    return random_module.randint(int(min_val), int(max_val))


def builtin_time() -> float:
    """Current timestamp in seconds."""
    return time_module.time()


# ============================================
# Registry of all built-in functions
# ============================================

BUILTINS: Dict[str, Callable] = {
    # I/O
    "spit": builtin_spit,
    "listen": builtin_listen,
    
    # Type conversion
    "int": builtin_int,
    "float": builtin_float,
    "str": builtin_str,
    "type": builtin_type,
    
    # Collections
    "range": builtin_range,
    "len": builtin_len,
    
    # Math
    "abs": builtin_abs,
    "max": builtin_max,
    "min": builtin_min,
    "pow": builtin_pow,
    "sqrt": builtin_sqrt,
    "floor": builtin_floor,
    "ceil": builtin_ceil,
    "round": builtin_round,
    
    # String
    "upper": builtin_upper,
    "lower": builtin_lower,
    "trim": builtin_trim,
    "split": builtin_split,
    "join": builtin_join,
    "replace": builtin_replace,
    "contains": builtin_contains,
    "starts_with": builtin_starts_with,
    "ends_with": builtin_ends_with,
    "char_at": builtin_char_at,
    "substring": builtin_substring,
    
    # Array
    "sort": builtin_sort,
    "reverse": builtin_reverse,
    "slice": builtin_slice,
    "index_of": builtin_index_of,
    "includes": builtin_includes,
    "concat": builtin_concat,
    
    # Utility
    "random": builtin_random,
    "random_int": builtin_random_int,
    "time": builtin_time,
}
