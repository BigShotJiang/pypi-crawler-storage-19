"""
Custom exception classes for Bro Code.
Now with extra brain rot flavor 💀
"""

import random


# Slang phrases for extra flavor
SKILL_ISSUES = [
    "skill issue ngl",
    "L + ratio",
    "not very sigma of you",
    "that's lowkey mid",
    "touch grass maybe?",
]

def get_roast():
    """Get a random roast suffix."""
    return random.choice(SKILL_ISSUES)


class BroCodeError(Exception):
    """Base exception for all Bro Code errors."""
    
    def __init__(self, message: str, line: int = None, column: int = None):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(self._format_message())
    
    def _format_message(self) -> str:
        if self.line is not None:
            return f"💀 Line {self.line}: {self.message}"
        return f"💀 {self.message}"


class LexerError(BroCodeError):
    """Error during tokenization - when the code looks like hieroglyphics."""
    pass


class ParserError(BroCodeError):
    """Error during parsing - when the vibes are off."""
    pass


class RuntimeError(BroCodeError):
    """Error during execution - when everything falls apart."""
    pass


class NameError(RuntimeError):
    """When you reference something that doesn't exist (like your social life)."""
    pass


class TypeError(RuntimeError):
    """When types don't vibe together."""
    pass


class ReturnException(Exception):
    """Used to propagate return values from functions."""
    
    def __init__(self, value):
        self.value = value
        super().__init__()


class PeaceException(Exception):
    """Used to exit the program with peace statement. ✌️"""
    pass


class BreakException(Exception):
    """Used to dip out of loops."""
    pass


class ContinueException(Exception):
    """Used to skip to next iteration."""
    pass


# =====================================================
# SLANG ERROR MESSAGE GENERATORS
# =====================================================

def undefined_variable(name: str) -> str:
    """Error for undefined variables."""
    phrases = [
        f"Bro wtf is '{name}'? Never heard of her 💀",
        f"'{name}' is not a thing, you made that up fr fr",
        f"Who is '{name}'?? I don't know this variable 🤷",
        f"'{name}' said 'new phone who dis' - undefined",
        f"'{name}' ghosted us, variable doesn't exist",
    ]
    return random.choice(phrases)


def undefined_function(name: str) -> str:
    """Error for undefined functions."""
    phrases = [
        f"Bro there's no gig called '{name}', touch grass 🌱",
        f"'{name}'? That gig doesn't exist, you're tweaking",
        f"Can't find gig '{name}', it's giving 404 energy",
        f"'{name}' is not a real gig, stop the cap 🧢",
        f"Gig '{name}' left the chat (never existed tbh)",
    ]
    return random.choice(phrases)


def cannot_reassign_constant(name: str) -> str:
    """Error for trying to reassign constants."""
    phrases = [
        f"Bro '{name}' is a CONSTANT, it's not changing like your personality 💅",
        f"'{name}' said it's a constant and meant it, no reassigning",
        f"Can't change '{name}', it's built different (literally const)",
        f"'{name}' is immutable bestie, move on 🚫",
        f"You can't reassign '{name}', that's illegal (const moment)",
    ]
    return random.choice(phrases)


def division_by_zero() -> str:
    """Error for division by zero."""
    phrases = [
        "Bro really tried to divide by zero 😭 ratio + L",
        "Dividing by zero? That's mathematically illegal fr fr",
        "You can't divide by zero, that's not very cash money of you 💸",
        "Zero division? The math isn't mathing rn 🧮",
        "Infinity called, it wants you to stop dividing by zero",
    ]
    return random.choice(phrases)


def type_mismatch(expected: str, got: str) -> str:
    """Error for type mismatches."""
    phrases = [
        f"These types ain't vibing fr fr 🚫 (wanted {expected}, got {got})",
        f"Type conflict! {expected} and {got} are beefing rn",
        f"Expected {expected} but got {got}, that's not it chief",
        f"Can't mix {expected} with {got}, they're incompatible (like you and success)",
        f"{expected} and {got} together? That's mid behavior 💀",
    ]
    return random.choice(phrases)


def unknown_operator(op: str) -> str:
    """Error for unknown operators."""
    phrases = [
        f"What even is '{op}'? Never seen this operator before ngl",
        f"'{op}' is not a valid operator, you're making stuff up",
        f"Operator '{op}' doesn't exist, {get_roast()}",
        f"Unknown operator '{op}', that's not how math works bestie",
    ]
    return random.choice(phrases)


def unknown_method(method: str) -> str:
    """Error for unknown methods."""
    phrases = [
        f"Method '{method}' doesn't exist, stop inventing things 🧪",
        f"'{method}' is not a real method, you're delusional fr",
        f"Can't find method '{method}', {get_roast()}",
        f"Unknown method '{method}', that's giving hallucination vibes",
    ]
    return random.choice(phrases)


def function_args_too_few(name: str, required: int, got: int) -> str:
    """Error for too few function arguments."""
    phrases = [
        f"Gig '{name}' needs at least {required} args but you gave {got} 💀 lazy much?",
        f"'{name}' wants {required}+ arguments, you only brought {got} to the party",
        f"Bro '{name}' is starving for args, needs {required} but got {got}",
        f"Under-argumenting '{name}'? Needs {required}, got {got}. {get_roast()}",
    ]
    return random.choice(phrases)


def function_args_too_many(name: str, max_args: int, got: int) -> str:
    """Error for too many function arguments."""
    phrases = [
        f"Gig '{name}' only takes {max_args} args max, you gave {got} 😭 chill",
        f"Too many args for '{name}'! Max is {max_args}, you sent {got}. Relax.",
        f"'{name}' can't handle {got} args, max is {max_args}. Overwhelmed much?",
        f"Bro '{name}' said {max_args} args max, not {got}. {get_roast()}",
    ]
    return random.choice(phrases)


def missing_argument(param: str) -> str:
    """Error for missing required argument."""
    phrases = [
        f"Missing argument '{param}', did you forget something? 🤔",
        f"Where's '{param}'? You left this argument on read 💔",
        f"'{param}' is required but you ghosted it, not cool",
        f"Bro you forgot to pass '{param}', {get_roast()}",
    ]
    return random.choice(phrases)


def unterminated_string() -> str:
    """Error for unterminated strings."""
    phrases = [
        "Your string never ends, just like my disappointment 😔",
        "Unterminated string! Did you forget the closing quote? Classic.",
        "This string goes on forever... close it with a quote maybe?",
        "String said bye without closing quotes, rude honestly 💔",
    ]
    return random.choice(phrases)


def unterminated_comment() -> str:
    """Error for unterminated multi-line comments."""
    phrases = [
        "Comment never ends, just like this L you're taking 📉",
        "Unterminated comment! Close it with */ bestie",
        "Your comment is going on forever, time to wrap it up",
        "Multi-line comment that never ends? That's deep... close it tho",
    ]
    return random.choice(phrases)


def unexpected_character(char: str) -> str:
    """Error for unexpected characters."""
    phrases = [
        f"What is '{char}' doing here? Uninvited guest fr 🚪",
        f"Unexpected character '{char}', that's sus ngl 🧐",
        f"'{char}' showed up without an invite, kicked out",
        f"Random '{char}' appeared! It's not very effective... (error)",
    ]
    return random.choice(phrases)


def unexpected_token(token_type: str) -> str:
    """Error for unexpected tokens."""
    phrases = [
        f"Didn't expect {token_type} here, that's random af 🎲",
        f"Unexpected {token_type}? Bro what are you doing 😭",
        f"{token_type} showed up uninvited, syntax error bestie",
        f"Why is {token_type} here? This code is giving chaos",
    ]
    return random.choice(phrases)


def program_must_start_with_sup() -> str:
    """Error for programs not starting with sup block."""
    phrases = [
        "Program needs to start with 'sup { }' block, that's the vibe check ✅",
        "Where's your 'sup' block? Can't enter without it fr",
        "No 'sup' block? That's like a party with no host 🎉❌",
        "Your code needs a 'sup' block to say hello, don't be rude",
    ]
    return random.choice(phrases)


def default_params_must_come_last() -> str:
    """Error for default parameters before required ones."""
    phrases = [
        "Default params gotta come after required ones, that's the rule 📜",
        "Put default parameters at the end, not in the middle like a psycho",
        "Required params first, then defaults. It's giving order.",
        "Params with defaults must be last, don't mix it up bestie",
    ]
    return random.choice(phrases)
