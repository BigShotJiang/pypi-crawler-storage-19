#!/usr/bin/env python3
"""
Bro Code CLI - Run .homie files from the command line.

Usage:
    python -m brocode <file.homie>
    python -m brocode --version
    python -m brocode --help
"""

import sys
import argparse
from pathlib import Path

from . import __version__
from .lexer import tokenize
from .parser import parse
from .interpreter import interpret
from .errors import BroCodeError


def run_file(filepath: str) -> int:
    """Run a .homie file and return exit code."""
    path = Path(filepath)
    
    if not path.exists():
        print(f"Error: File not found: {filepath}", file=sys.stderr)
        return 1
    
    if path.suffix != '.homie':
        print(f"Warning: Expected .homie extension, got '{path.suffix}'", file=sys.stderr)
    
    try:
        source = path.read_text()
        tokens = tokenize(source)
        ast = parse(tokens)
        interpret(ast)
        return 0
    
    except BroCodeError as e:
        print(f"Bro Code Error: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nProgram interrupted.", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Internal Error: {e}", file=sys.stderr)
        return 1


def main():
    parser = argparse.ArgumentParser(
        prog='brocode',
        description='Bro Code Interpreter - The Ultimate Vibe Check Language',
        epilog='Example: python -m brocode hello.homie'
    )
    
    parser.add_argument(
        'file',
        nargs='?',
        help='The .homie file to run'
    )
    
    parser.add_argument(
        '--version', '-v',
        action='version',
        version=f'Bro Code v{__version__}'
    )
    
    parser.add_argument(
        '--tokens',
        action='store_true',
        help='Print tokens and exit (for debugging)'
    )
    
    parser.add_argument(
        '--ast',
        action='store_true',
        help='Print AST and exit (for debugging)'
    )
    
    args = parser.parse_args()
    
    if not args.file:
        parser.print_help()
        sys.exit(0)
    
    # Debug modes
    if args.tokens or args.ast:
        path = Path(args.file)
        if not path.exists():
            print(f"Error: File not found: {args.file}", file=sys.stderr)
            sys.exit(1)
        
        source = path.read_text()
        tokens = tokenize(source)
        
        if args.tokens:
            print("=== TOKENS ===")
            for token in tokens:
                print(token)
            sys.exit(0)
        
        if args.ast:
            ast = parse(tokens)
            print("=== AST ===")
            print_ast(ast)
            sys.exit(0)
    
    exit_code = run_file(args.file)
    sys.exit(exit_code)


def print_ast(node, indent=0):
    """Pretty print an AST node."""
    prefix = "  " * indent
    node_name = type(node).__name__
    
    # Print node type
    print(f"{prefix}{node_name}", end="")
    
    # Print simple attributes
    attrs = []
    for key, value in vars(node).items():
        if key == 'line':
            continue
        if isinstance(value, (str, int, float, bool)) and value is not None:
            attrs.append(f"{key}={value!r}")
    
    if attrs:
        print(f" ({', '.join(attrs)})")
    else:
        print()
    
    # Print child nodes
    for key, value in vars(node).items():
        if key == 'line':
            continue
        if hasattr(value, '__dict__') and not isinstance(value, (str, int, float, bool, type(None))):
            print(f"{prefix}  {key}:")
            print_ast(value, indent + 2)
        elif isinstance(value, list) and value:
            print(f"{prefix}  {key}:")
            for item in value:
                if hasattr(item, '__dict__'):
                    print_ast(item, indent + 2)
                elif isinstance(item, tuple):
                    # For elif_blocks which are (condition, block) tuples
                    print(f"{prefix}    tuple:")
                    for sub in item:
                        if hasattr(sub, '__dict__'):
                            print_ast(sub, indent + 3)


if __name__ == '__main__':
    main()
