"""
AST Node definitions for Bro Code parser.
"""

from dataclasses import dataclass, field
from typing import List, Any, Optional


@dataclass
class ASTNode:
    """Base class for all AST nodes."""
    line: int = 0


# Program Structure
@dataclass
class ProgramNode(ASTNode):
    """Root node containing function definitions and sup block."""
    functions: List['FunctionDefNode'] = field(default_factory=list)
    sup_block: 'BlockNode' = None


@dataclass
class BlockNode(ASTNode):
    """A block of statements enclosed in {}."""
    statements: List[ASTNode] = field(default_factory=list)


# Literals
@dataclass
class IntegerNode(ASTNode):
    value: int = 0


@dataclass
class FloatNode(ASTNode):
    value: float = 0.0


@dataclass
class StringNode(ASTNode):
    value: str = ""


@dataclass
class BooleanNode(ASTNode):
    value: bool = False


@dataclass
class NullNode(ASTNode):
    pass


@dataclass
class IdentifierNode(ASTNode):
    name: str = ""


# Arrays (Squads)
@dataclass
class ArrayNode(ASTNode):
    elements: List[ASTNode] = field(default_factory=list)


@dataclass
class IndexAccessNode(ASTNode):
    array: ASTNode = None
    index: ASTNode = None


@dataclass
class MethodCallNode(ASTNode):
    object: ASTNode = None
    method: str = ""
    arguments: List[ASTNode] = field(default_factory=list)


# Variables
@dataclass
class VarDeclNode(ASTNode):
    name: str = ""
    value: ASTNode = None
    is_const: bool = False


@dataclass
class AssignNode(ASTNode):
    name: str = ""
    value: ASTNode = None


@dataclass
class IndexAssignNode(ASTNode):
    array: ASTNode = None
    index: ASTNode = None
    value: ASTNode = None


# Expressions
@dataclass
class BinaryOpNode(ASTNode):
    left: ASTNode = None
    operator: str = ""
    right: ASTNode = None


@dataclass
class UnaryOpNode(ASTNode):
    operator: str = ""
    operand: ASTNode = None


# Control Flow
@dataclass
class IfNode(ASTNode):
    condition: ASTNode = None
    then_block: BlockNode = None
    elif_blocks: List[tuple] = field(default_factory=list)  # List of (condition, block)
    else_block: BlockNode = None


@dataclass
class WhileNode(ASTNode):
    condition: ASTNode = None
    body: BlockNode = None


@dataclass
class ForNode(ASTNode):
    var_name: str = ""
    iterable: ASTNode = None
    body: BlockNode = None


# Functions
@dataclass
class FunctionDefNode(ASTNode):
    name: str = ""
    params: List[str] = field(default_factory=list)
    param_defaults: List[Optional[ASTNode]] = field(default_factory=list)  # Default values (None if no default)
    body: BlockNode = None


@dataclass
class FunctionCallNode(ASTNode):
    name: str = ""
    arguments: List[ASTNode] = field(default_factory=list)


@dataclass
class ReturnNode(ASTNode):
    value: ASTNode = None


# Error Handling
@dataclass
class TryNode(ASTNode):
    try_block: BlockNode = None
    error_name: str = ""
    catch_block: BlockNode = None


# Special
@dataclass
class PeaceNode(ASTNode):
    """Exit statement."""
    pass


@dataclass
class BreakNode(ASTNode):
    """Break (dip) statement - exits loop."""
    pass


@dataclass
class ContinueNode(ASTNode):
    """Continue (skip) statement - skips to next iteration."""
    pass


@dataclass
class CompoundAssignNode(ASTNode):
    """Compound assignment (+=, -=, *=, /=, %=)."""
    name: str = ""
    operator: str = ""  # '+', '-', '*', '/', '%'
    value: ASTNode = None


@dataclass
class IndexCompoundAssignNode(ASTNode):
    """Compound assignment on array index (squad[i] += 1)."""
    array: ASTNode = None
    index: ASTNode = None
    operator: str = ""
    value: ASTNode = None


@dataclass
class IncrementNode(ASTNode):
    """Post-increment (i++)."""
    name: str = ""


@dataclass
class DecrementNode(ASTNode):
    """Post-decrement (i--)."""
    name: str = ""
