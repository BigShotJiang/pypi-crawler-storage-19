"""
Konigle CLI module.
"""
