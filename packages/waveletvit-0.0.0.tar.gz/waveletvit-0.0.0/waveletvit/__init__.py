"""WaveletViT package."""

