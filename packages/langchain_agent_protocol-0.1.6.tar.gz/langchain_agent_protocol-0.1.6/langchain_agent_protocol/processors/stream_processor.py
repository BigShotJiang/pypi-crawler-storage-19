# -*- coding: utf-8 -*-
"""
流式事件处理模块
解析和格式化 LangChain Agent 流式输出事件
"""

import logging
from typing import Dict, Any, List, Generator, Set

logger = logging.getLogger(__name__)


class StreamEventProcessor:
    """
    流式事件处理器 - 解析和格式化 LangChain Agent 流式输出事件
    
    关键改进：追踪已输出内容，只输出增量部分，实现真正的流式输出
    """
    
    def __init__(self, tool_name_map: Dict[str, str]):
        """
        初始化流式事件处理器
        
        Args:
            tool_name_map: 工具名称映射字典
        """
        from ..parsers.tool_call_parser import ToolCallParser
        
        self.tool_name_map = tool_name_map
        self.tool_parser = ToolCallParser()
        
        # 流式状态追踪
        self._last_content_length = 0  # 追踪已输出的内容长度
        self._notified_tool_calls: Set[str] = set()  # 追踪已通知的工具调用
    
    def reset(self):
        """重置流式状态，在新的对话开始时调用"""
        self._last_content_length = 0
        self._notified_tool_calls.clear()
    
    def process_event(self, event: Dict[str, Any]) -> Generator[str, None, None]:
        """
        处理单个流式事件
        
        Args:
            event: LangChain Agent 返回的事件字典
            
        Yields:
            格式化的增量输出文本
        """
        for node_name, node_output in event.items():
            # 情况1: node_output 是包含 messages 的字典
            if isinstance(node_output, dict) and "messages" in node_output:
                yield from self._process_messages(node_output["messages"])
            
            # 情况2: node_name 本身就是 "messages" (全局 values 模式)
            elif node_name == "messages" and isinstance(node_output, list):
                yield from self._process_messages(node_output)
    
    def _process_messages(self, messages: List[Any]) -> Generator[str, None, None]:
        """
        处理消息列表，只输出增量内容
        
        Args:
            messages: 消息列表
            
        Yields:
            格式化的增量输出文本
        """
        from langchain_core.messages import AIMessage, AIMessageChunk
        
        if not messages:
            return
        
        # 只处理最后一条消息 (最新的状态)
        last_msg = messages[-1]
        
        # 支持 AIMessage 和 AIMessageChunk
        if not isinstance(last_msg, (AIMessage, AIMessageChunk)):
            return
        
        # 1. 处理工具调用 (只通知新的工具调用)
        tool_calls = self.tool_parser.extract_tool_calls_from_message(last_msg)
        
        for tc in tool_calls:
            tool_id = tc.get("id") or tc.get("name", "")
            tool_name = tc.get("name")
            
            # 只通知尚未通知过的工具调用
            if tool_id and tool_id not in self._notified_tool_calls and tool_name:
                self._notified_tool_calls.add(tool_id)
                notification = self.tool_parser.format_tool_call_notification(
                    tool_name,
                    self.tool_name_map
                )
                yield notification
        
        # 2. 处理文本内容 - 关键：只输出增量部分！
        content = last_msg.content or ""
        if isinstance(content, str) and len(content) > self._last_content_length:
            # 只输出新增的内容
            delta = content[self._last_content_length:]
            self._last_content_length = len(content)
            if delta:
                yield delta
    
    def process_error(self, error: Exception) -> str:
        """
        处理错误并格式化错误消息
        
        Args:
            error: 异常对象
            
        Returns:
            格式化的错误消息
        """
        logger.error(f"Stream processing error: {error}", exc_info=True)
        return f"❌ 执行过程中出现错误: {str(error)}"
