"""Top-level package for RockSlope.

End users are expected to import the high-level API from this package, e.g.::

    from rockslope import RockMass

Only the public interface defined in :mod:`rockslope.rockslope` is re-exported.

The package can also be executed as a module from the command line::

    python -m rockslope
"""

from .rockslope import RockMass, joints_from_csv

__all__ = ["RockMass", "joints_from_csv"]
