"""
This module offers functions for converting different notations to unit vectors
and vice versa.

If you are happy with the standard behevior and the implemented notations, it's
enough to just use the functions string2uvec, tokens2uvec, uvec2string and
uvec2tokens.

But if you want to tweek the implementations or define your own ones, you can
inherit from the offered classes NotationValidator and NotationConverter and
modify to fit your needs. Then you just have to pass the classes (not
instances!) to the functions mentioned above.

You can also define you validator and converter classes from scratch. If you
do so, make sure, that your classes offer string2uvec, tokens2uvec, uvec2string
and uvec2tokens methods if you pass them to the respective functions.
"""

import re
import math
import numpy as np
from . import sphericmath as smath

PLANAR = "planar"
LINEAR = "linear"
NO_NOTATION_ERROR_MSG = "No suitable notation found for {}. {}"
INVALID_CHARS = r"[^0-9nsewNSEW/,\s\[\]'()*.°+#?-]+"
TOKEN_PATTERN = r"[0-9.]+|[nsewNSEW]+"
NOTATION_PATTERNS = {
    "clar": [
        [0.0, 360.0],
        [0.0, 90.0]
    ],
    "geological": [
        [0.0, 180.0],
        [0.0, 90.0],
        ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
    ],
    "rhr": [
        [0.0, 360.0],
        [0.0, 90.0]
    ],
    "lhr": [
        [0.0, 360.0],
        [0.0, 90.0]
    ]
}
NOTATION2UVEC = {
    "clar": "_clar2uvec",
    "geological": "_geological2uvec",
    "rhr": "_rhr2uvec",
    "lhr": "_lhr2uvec"
}
UVEC2NOTATION = {
    "clar": "_uvec2clar",
    "geological": "_uvec2geological",
    "rhr": "_uvec2rhr",
    "lhr": "_uvec2lhr"
}
NOTATION_TEMPLATES = {
    "clar": "{:06.2f} / {:04.2f}",
    "geological": "{:05.1f} / {:04.1f} {}",
    "rhr": "{:05.1f} / {:04.1f}",
    "lhr": "{:05.1f} / {:04.1f}"
}
CARDINAL_POINTS = {
    "N": "N",
    "NE": "NE",
    "E": "E",
    "SE": "SE",
    "S": "S",
    "SW": "SW",
    "W": "W",
    "NW": "NW"
}


class NotationValidator:

    def __init__(
        self,
        invalid_chars=INVALID_CHARS,
        notation_patterns=NOTATION_PATTERNS,
        cardinal_points=CARDINAL_POINTS
    ):
        self.invalid_chars = invalid_chars
        self.notation_patterns = notation_patterns
        self.cardinal_points = cardinal_points

    def valid_tokens(self, tokens, notation="clar", geometry=PLANAR):
        if notation in ["rhr", "lhr"] and geometry == LINEAR.lower():
            raise ValueError(
                "'{}' is used for planars only.".format(notation)
            )
        self.tokens = [_convert_token(token) for token in tokens]
        valid_notations = self._get_valid_notations(tokens, geometry)
        if notation not in valid_notations:
            raise ValueError(
                "Notation '{}' not in valid notation(s) {}".format(
                    notation,
                    valid_notations
                )
            )
        else:
            return True

    def valid_string(self, notation_string, notation="clar", geometry=PLANAR):
        self.tokens = _tokenize(notation_string)
        valid = self.valid_tokens(self.tokens, notation, geometry)
        return valid

    def _get_valid_notations(self, tokens, geometry=PLANAR):
        # the validation methods below append valid notations to
        # self.valid_notations or raise an error, if there aren't
        # any suitable notations for given tokens
        self._validate_chars()
        self._validate_count()
        self._validate_types()
        self._validate_values()

        # some geological notations exclusive validations must be done:
        if "geological" in self.valid_notations:
            self._validate_geometry_depended_azi(geometry)
            self._validate_cardinal_point(geometry)

        return self.valid_notations

    def _validate_chars(self):
        for token in self.tokens:
            if isinstance(token, float):
                continue
            else:
                invalid_chars = re.findall(self.invalid_chars, token)
                if invalid_chars:
                    raise ValueError(
                        NO_NOTATION_ERROR_MSG.format(
                            self.tokens,
                            "Invalid character(s) {}".format(
                                ", ".join(invalid_chars)
                            )
                        )
                    )
        return self

    def _validate_count(self):
        self.valid_notations = [
            notation for notation in self.notation_patterns
            if len(self.tokens) == len(self.notation_patterns[notation])
        ]
        if not self.valid_notations:
            raise ValueError(
                NO_NOTATION_ERROR_MSG.format(
                    self.tokens,
                    "No match for {} tokens.".format(len(self.tokens))
                )
            )
        return self

    def _validate_types(self):
        self.valid_notations = [
            notation for notation in self.valid_notations
            if all(
                type(token) is type(notation_pattern[0])
                for token, notation_pattern in zip(
                    self.tokens, self.notation_patterns[notation]
                )
            )
        ]
        if not self.valid_notations:
            raise ValueError(
                NO_NOTATION_ERROR_MSG.format(
                    self.tokens,
                    "Unmatching types."
                )
            )
        return self

    def _validate_values(self):
        valid_notations = []
        for notation in self.valid_notations:
            valid_values = True
            for token, notation_pattern in zip(
                self.tokens, self.notation_patterns[notation]
            ):
                if isinstance(token, str):
                    if token not in notation_pattern:
                        valid_values = False
                elif isinstance(token, float):
                    if not notation_pattern[0] <= token <= notation_pattern[1]:
                        valid_values = False
            if valid_values:
                valid_notations.append(notation)
        self.valid_notations = valid_notations
        if not self.valid_notations:
            raise ValueError(
                NO_NOTATION_ERROR_MSG.format(
                    self.tokens,
                    "Contains invalid values."
                )
            )
        return self

    def _validate_cardinal_point(self, geometry):
        # only if "gelogical" in self.valid_notations
        azi = self.tokens[0]
        cardinal_point = self.tokens[2]
        if geometry.lower() == LINEAR:
            valid_cardinal_points = [
                _get_cardinal_point(azi, self.cardinal_points),
                _get_cardinal_point(
                    _rotate_azi(azi, 180.0), self.cardinal_points
                )
            ]
        elif geometry.lower() == PLANAR:
            valid_cardinal_points = [
                _get_cardinal_point(
                    _rotate_azi(azi, 90.0), self.cardinal_points
                ),
                _get_cardinal_point(
                    _rotate_azi(azi, -90.0), self.cardinal_points
                )
            ]
        else:
            raise ValueError(
                NO_NOTATION_ERROR_MSG.format(
                    "geometry '{}'".format(geometry),
                    "Use 'linear' or 'planar'."
                )
            )
        if cardinal_point in valid_cardinal_points:
            return True
        else:
            raise ValueError(
                NO_NOTATION_ERROR_MSG.format(
                    self.tokens,
                    "Wrong cardinal point?"
                )
            )
        return self

    def _validate_geometry_depended_azi(self, geometry):
        # only if "gelogical" in self.valid_notations
        if geometry.lower() == PLANAR:
            strike = self.tokens[0]
            if strike > 180.0:
                raise ValueError(
                    NO_NOTATION_ERROR_MSG.format(
                        self.tokens,
                        "Strike {} > 180.0 degree for planar!".format(strike)
                    )
                )
        return self


class NotationConverter:

    def __init__(
        self,
        notation2uvec=NOTATION2UVEC,
        uvec2notation=UVEC2NOTATION,
        notation_templates=NOTATION_TEMPLATES,
        cardinal_points=CARDINAL_POINTS,
        token_pattern=TOKEN_PATTERN,
        invalid_chars=INVALID_CHARS,
        validator=NotationValidator()
    ):
        self.valid_tokens = validator.valid_tokens
        self.valid_string = validator.valid_string
        self.notation2uvec = notation2uvec
        self.uvec2notation = uvec2notation
        self.cardinal_points = cardinal_points
        self.notation_templates = notation_templates
        self.token_pattern = token_pattern
        self.invalid_chars = invalid_chars

    def string2uvec(
        self,
        notation_string,
        notation="clar",
        geometry=PLANAR,
    ):
        tokens = _tokenize(
            notation_string, self.token_pattern, self.invalid_chars
        )
        return self.tokens2uvec(tokens, notation, geometry)

    def tokens2uvec(
        self,
        tokens,
        notation="clar",
        geometry=PLANAR,
    ):
        if self.valid_tokens(tokens, notation, geometry):
            uvec = getattr(
                self,
                self.notation2uvec[notation]
            )(tokens, geometry)
            return uvec

    def uvec2tokens(self, uvec, notation="clar", geometry=PLANAR):
        tokens = getattr(
            self,
            self.uvec2notation[notation]
        )(uvec, geometry)
        tokens = [0.0 if angle == 360.0 else angle for angle in tokens]
        return tokens

    def uvec2string(
        self,
        uvec,
        notation="clar",
        geometry=PLANAR,
        custom_templates=None
    ):
        tokens = self.uvec2tokens(uvec, notation, geometry)
        if custom_templates:
            notation_string = custom_templates[notation].format(*tokens)
        else:
            notation_string = self.notation_templates[notation].format(*tokens)

        return notation_string

    def _clar2uvec(self, tokens, *args):
        dip_direction, dip = tokens
        spheric = np.array([math.radians(dip_direction), math.radians(dip)])
        uvec = smath.spheric2uvec(spheric)
        return uvec

    def _geological2uvec(self, tokens, geometry):
        strike, dip, cardinal_point = tokens

        if geometry == PLANAR:
            rot_strike = _rotate_azi(strike, 90.0)
            guessed_cardinal_point = _get_cardinal_point(
                rot_strike, self.cardinal_points
            )
            if cardinal_point == guessed_cardinal_point:
                dip_direction = rot_strike
            else:
                dip_direction = _rotate_azi(strike, -90.0)

        elif geometry == LINEAR:
            guessed_cardinal_point = _get_cardinal_point(
                strike, self.cardinal_points
            )
            if cardinal_point == guessed_cardinal_point:
                dip_direction = strike
            else:
                dip_direction = _rotate_azi(strike, 180)
        return self._clar2uvec([dip_direction, dip])

    def _rhr2uvec(self, tokens, *args):
        strike, dip = tokens
        dip_direction = _rotate_azi(strike, 90.0)
        return self._clar2uvec([dip_direction, dip])

    def _lhr2uvec(self, tokens, *args):
        strike, dip = tokens
        dip_direction = _rotate_azi(strike, -90.0)
        return self._clar2uvec([dip_direction, dip])

    def _uvec2clar(self, uvec, *args):
        dip_direction, dip = smath.uvec2spheric(uvec)
        tokens = [math.degrees(dip_direction), math.degrees(dip)]
        return tokens

    def _uvec2geological(self, uvec, geometry):
        azi, incli = smath.uvec2spheric(uvec)
        azi, incli = math.degrees(azi), math.degrees(incli)
        cardinal_point = _get_cardinal_point(azi, self.cardinal_points)
        if geometry == PLANAR:
            azi = _rotate_azi(azi, 90.0)
        if azi > 180.0:
            azi = _rotate_azi(azi, 180.0)
        tokens = [azi, incli, cardinal_point]
        return tokens

    def _uvec2rhr(self, uvec, *args):
        dip_direction, dip = self._uvec2clar(uvec, *args)
        strike = _rotate_azi(dip_direction, -90.0)
        tokens = [strike, dip]
        return tokens

    def _uvec2lhr(self, uvec, *args):
        dip_direction, dip = self._uvec2clar(uvec, *args)
        strike = _rotate_azi(dip_direction, 90.0)
        tokens = [strike, dip]
        return tokens


def string2uvec(
    notation_string,
    notation="clar",
    geometry=PLANAR,
    notation_validator=NotationValidator,
    notation_converter=NotationConverter
):
    """Converts a string containing a notation for a planar or a linear to
    a unit vector representing the direction of the element.

    Using the default validator and the default converter you can convert
    Clar's notation, geological notation, left-hand-rule notation and right-
    hand-rule notation.

    Be aware that "clar" is the default notation and "planar" the default
    geometry. Giving a right-hand- or left-hand-rule notation without changing
    the notation won't fail, but will give you wrong results.

    Args:
        notation_string (str): String containing the notation to be converted
        notation (str, optional): Kind of notation (default is "clar")
        geometry (str, optional): "planar" or "linear" (default is "planar")
        notation_validator (TYPE, optional): Validator class.
        notation_converter (TYPE, optional): Converter class.

    Returns:
       ndarray: Unit vector corresponding to the given notation_string.

    Raises:
        AttributeError: If the validator or converter fails. Giving hints about
            what's the problem with the given notation string.

    """
    nc = notation_converter(validator=notation_validator())
    uvec = nc.string2uvec(notation_string, notation, geometry)
    return uvec


def tokens2uvec(
    tokens,
    notation="clar",
    geometry=PLANAR,
    notation_validator=NotationValidator,
    notation_converter=NotationConverter
):
    """Converts a list containg notation token for a planar or a linear to
    a unit vector representing the direction of the element.

    Using the default validator and the default converter you can convert
    Clar's notation, geological notation, left-hand-rule notation and right-
    hand-rule notation.

    Be aware that "clar" is the default notation and "planar" the default
    geometry. Giving a right-hand- or left-hand-rule notation without changing
    the notation won't fail, but will give you wrong results.

    Args:
        tokens (list): List containing tokens for notations,
            e.g. ["90", "45", "N"]
        notation (str, optional): Kind of notation (default is "clar")
        geometry (str, optional): "planar" or "linear" (default is "planar")
        notation_validator (TYPE, optional): Validator class.
        notation_converter (TYPE, optional): Converter class.
    """
    nc = notation_converter(validator=notation_validator())
    tokens = nc.tokens2uvec(tokens, notation, geometry)
    return tokens


def uvec2string(
    uvec,
    notation="clar",
    geometry=PLANAR,
    custom_templates=None,
    notation_validator=NotationValidator,
    notation_converter=NotationConverter
):
    """Converts an unit vector representing a linear or planar to a
    string formatted like a given notation.

    Numbers are given with one decimal by default. If you want to change the
    appearance of the string you can define custom templates.

    Using the default validator and the default converter you can convert
    Clar's notation, geological notation, left-hand-rule notation and right-
    hand-rule notation.

    Be aware that "clar" is the default notation and "planar" the default
    geometry. Giving a right-hand- or left-hand-rule notation without changing
    the notation won't fail, but will give you wrong results.

    Args:
        uvec (ndarray): Unit vector of shape (3,)
        notation (str, optional): Kind of notation (default is "clar")
        geometry (TYPE, optional): "planar" or "linear" (default is "planar")
        custom_templates (dict, optional): Give custom templates for notations,
            e.g. {"clar": "{:05.1f} :D {:04.1f}"}
        notation_validator (TYPE, optional): Validator class.
        notation_converter (TYPE, optional): Converter class.
    """
    nc = notation_converter(validator=notation_validator())
    notation_string = nc.uvec2string(
        uvec, notation, geometry, custom_templates
    )
    return notation_string


def uvec2tokens(
    uvec,
    notation="clar",
    geometry=PLANAR,
    notation_validator=NotationValidator,
    notation_converter=NotationConverter
):
    """Converts an unit vector representing a linear or planar to a
    a list of tokens representing a given notation.

    Using the default validator and the default converter you can convert
    Clar's notation, geological notation, left-hand-rule notation and right-
    hand-rule notation.

    Be aware that "clar" is the default notation and "planar" the default
    geometry. Giving a right-hand- or left-hand-rule notation without changing
    the notation won't fail, but will give you wrong results.

    Args:
        uvec (ndarray): Unit vector of shape (3,)
        notation (str, optional): Kind of notation (default is "clar")
        geometry (TYPE, optional): "planar" or "linear" (default is "planar")
        notation_validator (TYPE, optional): Validator class.
        notation_converter (TYPE, optional): Converter class.
    """
    nc = notation_converter(validator=notation_validator())
    tokens = nc.uvec2tokens(uvec, notation, geometry)
    return tokens


def _tokenize(
    notation_string,
    token_pattern=TOKEN_PATTERN,
    invalid_chars=INVALID_CHARS
):
    invalid_chars = re.findall(invalid_chars, notation_string)
    if invalid_chars:
        raise ValueError(
            NO_NOTATION_ERROR_MSG.format(
                "'{}'".format(notation_string),
                "Invalid character(s) {}".format(
                    ", ".join(invalid_chars)
                )
            )
        )
    else:
        raw_tokens = re.findall(token_pattern, notation_string)

        # convert raw tokens, so only uppercase chars and floats are returned:
        tokens = [_convert_token(raw_token) for raw_token in raw_tokens]
        return tokens


def _convert_token(token):
    try:
        return float(token)
    except ValueError:
        return token.upper()


def _get_cardinal_point(azi, cardinal_points=CARDINAL_POINTS):
    # main cardinal points are preferred
    if 337.5 <= azi <= 360.0 or 0.0 <= azi <= 22.5:
        return cardinal_points["N"]
    elif 22.5 < azi < 67.5:
        return cardinal_points["NE"]
    elif 67.5 <= azi <= 112.5:
        return cardinal_points["E"]
    elif 112.5 < azi < 157.5:
        return cardinal_points["SE"]
    elif 157.5 <= azi <= 202.5:
        return cardinal_points["S"]
    elif 202.5 < azi < 247.5:
        return cardinal_points["SW"]
    elif 247.5 <= azi <= 292.5:
        return cardinal_points["W"]
    elif 292.5 < azi < 337.5:
        return cardinal_points["NW"]
    else:
        raise ValueError(f"{azi} isn't an accepted azimuth.")


def _rotate_azi(azi, angle):
    # negative ccw, positive cw
    # valid for 0 to 360
    rot_azi = azi + angle
    if rot_azi < 0.0:
        return rot_azi + 360.0
    elif rot_azi > 360.0:
        return rot_azi - 360.0
    elif rot_azi == 360.0:
        return 0.0
    else:
        return rot_azi
