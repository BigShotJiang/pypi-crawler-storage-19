from abc import ABC, abstractmethod


class Component(ABC):

    def __init__(
        self,
        blank_lines_in_front=0,
        blank_lines_after=1,
        bold=False,
        italic=False
    ):
        self.blank_lines_in_front = blank_lines_in_front
        self.blank_lines_after = blank_lines_after
        super().__init__()

    def _unpack(self, component):
        if isinstance(component, (list, tuple)):
            for component in component:
                for component in self._unpack(component):
                    yield component
        elif isinstance(component, (str, int)):
            yield component
        elif isinstance(component, Component):
            yield component.build()

    def _postprocessing(build):
        def __postprocessing(self):
            ""
            built_component = [
                ["\n" for line in range(self.blank_lines_in_front)],
                build(self),
                ["\n" for line in range(self.blank_lines_after)]
            ]
            return "".join(self._unpack(built_component))
        return __postprocessing

    @abstractmethod
    def build(self):
        raise NotImplementedError()


class Document(Component):

    def __init__(self, content):
        self.content = content

    def build(self):
        for component in self._unpack(self.content):
            yield component

    def get(self):
        return "".join(component for component in self.build())

    def save(self, path):
        with open(path, "w") as rst_file:
            rst_file.writelines(self.get())


class Heading(Component):

    def __init__(self, content, level=0, **kwargs):
        super().__init__(**kwargs)
        self.content = content
        self.level = level
        self.levels = ["#", "*", "=", "-", "^", '"']

    @Component._postprocessing
    def build(self):
        heading = f"{self.content}\n"
        lining = f"{len(self.content) * self.levels[self.level]}\n"
        if self.level == 0:
            return f"{lining}{heading}{lining}"
        else:
            return f"{heading}{lining}"


class Paragraph(Component):

    def __init__(self, content, **kwargs):
        self.content = content
        super().__init__(**kwargs)

    @Component._postprocessing
    def build(self):
        return self.content + "\n"


class BulletList(Component):

    def __init__(self, items, bullet_point="*", **kwargs):
        super().__init__(**kwargs)
        self.items = items
        self.bullet_point = bullet_point

    @Component._postprocessing
    def build(self):
        bullet_list = []
        for item in self.items:
            bullet_item = f"{self.bullet_point} {item}\n"
            bullet_list.append(bullet_item)
        return "".join(bullet_list)


class EnumeratedList(Component):
    def __init__(self, items, starting_number=1, **kwargs):
        super().__init__(**kwargs)
        self.items = items
        self.starting_number = starting_number

    @Component._postprocessing
    def build(self):
        enumerated_list = []
        for (n, item) in enumerate(self.items):
            enumerated_item = f"{n + self.starting_number}. {item}\n"
            enumerated_list.append(enumerated_item)
        return "".join(enumerated_list)


class SimpleTable(Component):

    """
    Very limited class for building simple rst-tables.
    Every cell value has to be converted to string before, and you have to
    make sure, that all columns are of same length. Only one line per cell
    is possible.

    Attributes:
        columns (dict): Columns as dict with key (str) as header, value
        (list, containing str) as entries
    """

    def __init__(self, columns, **kwargs):
        super().__init__(**kwargs)
        self.columns = columns

    @Component._postprocessing
    def build(self):
        data_cols = [data for data in self.columns.values()]
        data_rows = [row for row in zip(*data_cols)]

        col_widths = [
            max((len(heading), len(max(data, key=len))))
            for heading, data in self.columns.items()]

        line = ["  ".join(["="*width for width in col_widths])]
        row_fmt = "  ".join(
            ["{{:<{}s}}".format(width) for width in col_widths]
        )

        header = [row_fmt.format(*self.columns.keys())]
        data = [row_fmt.format(*row) for row in data_rows]
        return "\n".join(
            line +
            header +
            line +
            data +
            line +
            [""]
        )


def set_bold(text):
    return f"**{text}**"


def set_italic(text):
    return f"*{text}*"


if __name__ == '__main__':
    table = {
        "Column 1": ["fdgsfdg", "sdfdsf"],
        "Column 2": [set_italic("only one cell"), "a veeeerrrong entry"]
    }

    doc = Document(
        [
            Heading("Überschrift", level=0),
            Heading("Unterüberschrift 1", level=1),
            Paragraph(
                """Hier kann ganz viel Text stehen.
Oder auch sehr wenig.
                """
            ),
            SimpleTable(table)
        ]
    )

    print(doc.get())
