"""The selections module provides options to create a sub-selection from a set
of structure elements. Currently, it is possible to choose between two
different shapes over which a selection can be made: A rectangular selection
and a circular selection.
"""

import math
import numpy as np
from . import sphericmath as smath

SAFETY_MARGIN = 1e-6  # for compensating rounding errors


def select_rectangular(dir_uvec, dec_angle, inc_angle, uvecs):
    """Checks if vectors are inside of a rectangular "selection windows", which
    is defined bei a pointing direction and vertical and horizontal opening
    angles.

    Args:
        dir_uvec (ndarray): Unit vector of shape (3,)
        dec_angle (float): Horizontal opening angle (declination)
        inc_angle (float): Vertical opening angle (inclination)
        uvecs (ndarray): n unit vectors to be checked, shape (n,3)

    Returns:
        ndarray: Array filled with bools (True: inside, False: outside).
            Shape (n,).
    """
    conditions = []
    for dir_uvec in (dir_uvec, np.negative(dir_uvec)):
        dir_uvec_inc_angle = math.acos(dir_uvec[2])

        upper_limit = dir_uvec_inc_angle - inc_angle
        if upper_limit < 0.0:  # equals "north pole"
            upper_limit = 0.0
        cos_upper_limit = math.cos(upper_limit)
        upper_inc_conditions = (uvecs[:, 2] <= cos_upper_limit + SAFETY_MARGIN).T

        lower_limit = dir_uvec_inc_angle + inc_angle
        if lower_limit > math.pi:  # equals "south pole"
            lower_limit = math.pi
        cos_lower_limit = math.cos(lower_limit)
        lower_inc_conditions = (uvecs[:, 2] >= cos_lower_limit - SAFETY_MARGIN).T

        inc_conditions = np.all(
            [upper_inc_conditions, lower_inc_conditions],
            axis=0
        )

        dec_cos_dist = math.cos(dec_angle)
        dec_cos_dists = smath.get_dec_cos_distance(dir_uvec, uvecs)
        dec_condition = np.any(
            np.array([dec_cos_dist - SAFETY_MARGIN <= dec_cos_dists]).T,
            axis=1
        )
        conditions.append(np.all([inc_conditions, dec_condition], axis=0))
    return np.any(conditions, axis=0)


def select_circular(dir_uvec, angle, uvecs):
    """Checks if vectors are inside of a circular "selection windows", which
    is defined bei a pointing direction and an opening angle.

    Args:
        dir_uvec (ndarray): Unit vector of shape (3,)
        angle (float): Semi apical opening angle
        uvecs (ndarray): n unit vectors to be checked, shape (n,3)

    Returns:
        ndarray: Array filled with bools (True: inside, False: outside).
            Shape (n,).
    """
    dist_condition = math.cos(angle)
    cos_dists = smath.get_cos_distance(dir_uvec, uvecs)
    cos_dists_negative = smath.get_cos_distance(dir_uvec, np.negative(uvecs))
    condition_satisfied = np.any(
        np.array(
            [
                dist_condition <= cos_dists,
                dist_condition <= cos_dists_negative
            ]
        ).T,
        axis=1
    )
    return condition_satisfied


if __name__ == '__main__':
    from .notations import string2uvec
    from . import sphericstats as sstats
    from . import plot
    import matplotlib.pyplot as plt

    # CREATE RANDOM TEST DATA

    uvecs = sstats.generate_fisher_dist(
        n_samples=2000,
        kappa=1,
        seed=10
    )

    # DEFINE SELECTIONS

    directions = [
        string2uvec(direction, geometry="linear")
        for direction in ["060/45", "120/10", "200/30"]
    ]

    angles = [
        {"dec_angle": math.radians(10), "inc_angle": math.radians(15)},
        {"dec_angle": math.radians(40), "inc_angle": math.radians(30)},
        {"angle": math.radians(15)}
    ]

    selections = []
    for direction, angle in zip(directions, angles):
        if len(angle) == 1:  # only "angle" -> circular
            selections.append(select_circular(
                direction, angle["angle"], uvecs
                )
            )
        elif len(angle) == 2:  # "dec_angle", "inc_angle" -> rectangular
            selections.append(
                select_rectangular(
                    direction, angle["dec_angle"], angle["inc_angle"], uvecs
                )
            )

    # PLOT RESULTS

    ax = plt.subplot(111, projection="equal_angle")
    ax.stereogrid(kind="polar")
    ax.plot_planars(uvecs)
    ax.plot_planars(uvecs[selections[0]])

    for direction, angle, selection in zip(directions, angles, selections):
        if len(angle) == 1:
            ax.plot_small_circle(direction, angle["angle"])
        elif len(angle) == 2:
            ax.plot_rectangular_selection_window(direction, **angle)
        ax.plot_planars(uvecs[selection])
    plt.show()
