# -*- coding: utf-8 -*-
"""Spherical math

This module is providing necessary functions for basic manipulation or
comparison of spherical data.

It also provides functions for converting spherical coordinates into
cartesian coordinates. For converting the spherical coordinates themselves
to different conventions, eg. dip direction/ dip to strike/ plunge for planars,
have a look at the notations module. Furthermore it is possible to calculate
the trace of elements like great circles, small circles or daylight envelopes.
"""

import math
import numpy as np
# from numpy.core.umath_tests import inner1d  # deprecated: internal NumPy module removed in recent versions

PI2 = np.pi * 2.0

# rotation matrix for axis (0, 0, 1), angle 270 deg ccw:
STRIKE_UVEC_ROTATION_MATRIX = np.array(
    [
        [0.0, 1.0, 0.0],
        [-1.0, 0.0, 0.0],
        [0.0, 0.0, 1.0]
    ]
).T


def vec2uvec(vecs):
    """Function for converting arbitrary vectors to unit vectors.

    Args:
        vecs (array_like): n vectors of length i. Expects shape (n, i) or (i,).

    Returns:
        ndarray: n unit vectors, with same shape as input.
    """
    # Old implementation using numpy.core.umath_tests.inner1d
    # length = np.sqrt(np.atleast_2d(inner1d(vecs, vecs)).T)
    length = np.sqrt(np.atleast_2d(np.sum(np.square(vecs), axis=-1)).T)
    #print("length", length)
    uvec = vecs / length
    #uvec = vecs / np.linalg.norm(vecs)
    if uvec.shape[0] == 1:
        return uvec[0]
    else:
        return uvec


def uvec2spheric(uvecs):
    """Function for converting unit vectors to spherical coordinates
    (geological coordinate system).

    If you don't have unit vectors already you could receive them by using
    vec2uvec. Be aware that there are no checks if you're really passing unit
    vectors into the function!

    Args:
        uvecs (ndarray): n unit vectors of shape (n, 3) or (3,).

    Returns:
        ndarray: same shape as input, angles in radians.
    """
    uvecs = uvecs.T
    arctan2_uvecs = np.arctan2(uvecs[0], uvecs[1])
    spheric = np.array(
        [
            np.where(
                uvecs[0] > 0,
                arctan2_uvecs,
                arctan2_uvecs + PI2
            ),
            -np.arcsin(np.clip(uvecs[2], -1.0, 1.0))
        ]
    )
    return spheric.T


def spheric2uvec(spherics):
    """Function for converting spherical coordinates (geological coordinate
    system) to unit vectors.

    Args:
        spherics (ndarray): n spherical coordinates of shape (n, 2) or (2,).
        Angles have to be in radians.

    Returns:
        ndarray: Same shape as input.
    """
    spherics = spherics.T
    cos_spherics_1 = np.cos(spherics[1])
    uvecs = np.array(
        [
            np.sin(spherics[0]) * cos_spherics_1,
            np.cos(spherics[0]) * cos_spherics_1,
            -np.sin(spherics[1])
        ]
    )
    return uvecs.T


def spheric2pole_uvec(spherics):
    """Similar to spheric2uvec. But here spherical coordinates of a plane,
    given as dip direction and dip, are directly converted to the pole unit
    vector.

    By using formulas for direct conversion you avoid multiple conversions,
    which would be necessary every time as using poles is the standard
    behavior for dealing with planars.

    Args:
        spherics (ndarray): n spherical coordinates of shape (n, 2) or (2,).
        Angles have to be in radians.

    Returns:
        ndarray: Same shape as input.
    """
    spherics = spherics.T
    sin_spherics_1 = np.sin(spherics[1])
    pole_uvecs = np.array(
        [
            -np.sin(spherics[0]) * sin_spherics_1,
            -np.cos(spherics[0]) * sin_spherics_1,
            -np.cos(spherics[1])
        ]
    )
    return pole_uvecs.T


def switch(uvecs):
    """Can be used to easily switch between pole vector representation and
    dip vector representation.

    It's quite efficient compared to rotating them to the right position.

    Args:
        uvecs (ndarray): n unit vectors of shape (n, 3) or (3,).

    Returns:
        ndarray: n unit vectors of shape (n, 3) or (3,).
    """

    uvecs = np.atleast_2d(uvecs).T
    new_z = -np.sqrt(1.0 - uvecs[2] * uvecs[2])
    scaling = uvecs[2] / (new_z + 1e-6)  # prevent zero divide
    new_x = -uvecs[0] * scaling
    new_y = -uvecs[1] * scaling
    return np.array([new_x, new_y, new_z]).T


def pole_uvec2strike_uvec(pole_uvecs):
    """This function can be used to convert unit vectors representing
    poles of planes to their corresponding strike unit vector.

    Resulting vectors are following the right-hand-rule.

    BE CAREFUL: The calculations are performed on the input array,
    which is why it is overwritten. If you need the array afterwards for
    further calculations you have to make a copy.

    Args:
        pole_uvecs (ndarray): n unit vectors of shape (n, 3) or (3,).

    Returns:
        ndarray: n unit vectors of shape (n, 3) or (3,).
    """
    pole_uvecs = np.atleast_2d(pole_uvecs)
    pole_uvecs[:, 2] = 0.0
    pole_uvecs = vec2uvec(pole_uvecs)
    # Instead of calculating the rotation matrix again any single
    # time this function is called, I precomputed it as it is the
    # same all the time.
    #
    # It's based on axis (0, 0, 1) and angle 1.5 * PI, which is
    # 270 degrees. Rotation of poles about 270 degrees in ccw order
    # around a vertical axis results in a strike vector following
    # the right-hand-rule related to dip direction and dip
    strike_uvecs = np.atleast_2d(pole_uvecs.dot(STRIKE_UVEC_ROTATION_MATRIX))

    # if uvec is (0, 0, -1), strike is not defined, resp. (nan, nan, nan)
    # to prevent resulting errors, e.g. with plotting small circles,
    # I define the strike to be (1, 0, 0) in this case
    strike_is_nan = np.isnan(strike_uvecs)
    strike_uvecs = np.where(strike_is_nan, [1.0, 0.0, 0.0], strike_uvecs)
    return strike_uvecs


def trace_great_circle(
    pole_uvecs,
    to_left=np.pi,
    to_right=None,
    nodes_per_pi=100
):
    """Traces full or partial great circles with regard to given poles as
    unit vectors.

    The trace length can be controlled with "to_left" and "to_right" arguments,
    where left and right is defined by the deflection of a imaginary dip
    vector, which is connected to the pole vector and is moving when the pole
    is rotated.

    Metaphorically speaking: The dip vector is a pen, drawing the great circle
    while the pole is being rotated.

    Args:
        pole_uvecs (ndarray): n poles as unit vectors of shape (n, 3) or (3,).
        to_left (float, optional): End point of trace in left direction in
            radians. Defaults to Pi, so full hemisphere length.
        to_right (float, optional): End point of trace in right direction in
            radians. Defaults to None, which results in same end point as
            given with "to_left".
        nodes_per_pi (int, optional): Gives number of nodes per Pi, resp. per
            90 degree arc length. Defaults to 100.

    Returns:
        ndarray: Partial or full hemisphere trace of great circle.
    """

    pole_uvecs = np.where(pole_uvecs == 0.0, 1e-6, pole_uvecs)
    # pole vectors with z = 0 can lead to ugly artefacts
    # above solution may be a hackish, but is working
    # to do: find a solution removing the actual problem

    pole_uvecs = np.atleast_2d(pole_uvecs)
    if to_right is None:
        to_right = to_left
    start = np.pi/2.0 - to_left
    stop = np.pi/2.0 + to_right
    trace_length = stop - start
    n_nodes = int(nodes_per_pi * (trace_length / np.pi))
    angles = np.linspace(start, stop, n_nodes)

    strike_uvecs = np.array(pole_uvecs)  # new array to keep poles
    strike_uvecs = pole_uvec2strike_uvec(strike_uvecs)

    great_circles = np.empty([pole_uvecs.shape[0], n_nodes, 3])

    for i, (pole_uvec, strike_uvec) in enumerate(zip(pole_uvecs, strike_uvecs)):
        pole_uvec = np.atleast_2d(pole_uvec)
        a = np.cos(angles / 2.0)
        b, c, d = -pole_uvec.T * (np.sin(angles / 2.0))

        aa, bb, cc, dd = a*a, b*b, c*c, d*d
        bc, ad, ac, ab, bd, cd = b*c, a*d, a*c, a*b, b*d, c*d

        matrix = np.array(
            [
                [aa + bb - cc - dd, 2 * (bc + ad), 2 * (bd - ac)],
                [2 * (bc - ad), aa + cc - bb - dd, 2 * (cd + ab)],
                [2 * (bd + ac), 2 * (cd - ab), aa + dd - bb - cc]
            ]
        )

        great_circles[i] = np.dot(strike_uvec, matrix).T

    return great_circles


def trace_small_circle(
    cone_axis_uvec,
    semiapical_angle,
    to_left=np.pi,
    to_right=None,
    nodes_per_pi=100
):
    """Traces full or partial small circles with regard to a given direction as
    unit vectors.

    Args:
        cone_axis_uvec (ndarray): unit vector of shape (3,).
        semiapical_angle (TYPE): Description
        to_left (float, optional): End point of trace in left direction in
            radians. Defaults to Pi, so 180 degrees.
        to_right (float, optional): End point of trace in right direction in
            radians. Defaults to None, which results in same end point as
            given with "to_left".
        nodes_per_pi (int, optional): Gives number of nodes per Pi, resp. per
            90 degree arc length. Defaults to 100.
    """

    if to_right is None:
        to_right = to_left
    start = np.pi - to_left
    stop = np.pi + to_right
    trace_length = stop - start
    n_nodes = int(nodes_per_pi * (trace_length / np.pi))
    angles = np.linspace(start, stop, n_nodes)

    # tracing starts "south" of axis direction
    strike_uvec = np.array(cone_axis_uvec)  # new array to keep poles
    strike_uvec = pole_uvec2strike_uvec(strike_uvec)
    starting_uvec = rotate(cone_axis_uvec, strike_uvec[0], -semiapical_angle)

    cone_axis_uvec = np.atleast_2d(cone_axis_uvec)
    a = np.cos(angles / 2.0)
    b, c, d = -cone_axis_uvec.T * (np.sin(angles / 2.0))

    aa, bb, cc, dd = a*a, b*b, c*c, d*d
    bc, ad, ac, ab, bd, cd = b*c, a*d, a*c, a*b, b*d, c*d

    matrix = np.array(
        [
            [aa + bb - cc - dd, 2 * (bc + ad), 2 * (bd - ac)],
            [2 * (bc - ad), aa + cc - bb - dd, 2 * (cd + ab)],
            [2 * (bd + ac), 2 * (cd - ab), aa + dd - bb - cc]
        ]
    )

    small_circle = np.dot(starting_uvec, matrix).T

    return small_circle


def trace_daylight_envelope(
    pole_uvec,
    n_nodes=100
):
    """Traces a daylight envelope for any planar given as a pole unit vector.

    Args:
        pole_uvec (ndarray): Unit vector of shape (3,).
        n_nodes (int, optional): Number of points,
            plotted at the path of the daylight envelope
    """

    strike_uvec = np.array(pole_uvec)  # new array to keep poles
    strike_uvec = pole_uvec2strike_uvec(strike_uvec)

    angles = np.linspace(0.0, np.pi, n_nodes)

    # daylight_envelope = np.empty([n_nodes, 3])

    pole_uvec = np.atleast_2d(pole_uvec)
    a = np.cos(angles / 2.0)
    b, c, d = -pole_uvec.T * (np.sin(angles / 2.0))

    aa, bb, cc, dd = a*a, b*b, c*c, d*d
    bc, ad, ac, ab, bd, cd = b*c, a*d, a*c, a*b, b*d, c*d

    matrix = np.array(
        [
            [aa + bb - cc - dd, 2 * (bc + ad), 2 * (bd - ac)],
            [2 * (bc - ad), aa + cc - bb - dd, 2 * (cd + ab)],
            [2 * (bd + ac), 2 * (cd - ab), aa + dd - bb - cc]
        ]
    )

    great_circle = np.dot(strike_uvec, matrix).T
    great_circle = great_circle.T[0]

    daylight_envelope = np.empty(great_circle.shape)
    daylight_envelope[2] = - np.sqrt(1.0 - great_circle[2] * great_circle[2])

    scaling_factor = great_circle[2] / daylight_envelope[2]
    daylight_envelope[0] = np.negative(great_circle[0]) * scaling_factor
    daylight_envelope[1] = np.negative(great_circle[1]) * scaling_factor

    daylight_envelope = daylight_envelope.T

    return daylight_envelope


def trace_rectangular_selection_window(
    dir_uvec,
    dec_angle,
    inc_angle
):
    """Tracing a rectangular selection window. It needs a pointing direction,
    given as an unit vector. Starting from this direction it opens a rectangle
    by adding an angle to both sides of both declination and inclination
    direction.

    Args:
        dir_uvec (ndarray): Unit vector of shape (3,).
        dec_angle (float): Declination angle given in radians.
        inc_angle (float): Inclination angle given in radians.
    """
    dip_angle = math.acos(dir_uvec[2])
    dir_uvec = vec2uvec(np.array([dir_uvec[0], dir_uvec[1], 0.0]))

    sum_dip_inc = dip_angle + inc_angle
    inner_semiapical_angle = np.pi - (sum_dip_inc)
    #if inner_semiapical_angle > math.pi:
    #    inner_semiapical_angle = math.pi

    outer_semiapical_angle = np.pi - (dip_angle - inc_angle)
    if outer_semiapical_angle < 0.0:
        outer_semiapical_angle = 0.0

    strike_uvec = rotate(dir_uvec, np.array([0.0, 0.0, -1.0]), np.pi/2)

    # np.pi - dip_angle - 1e-6
    cone_axis_uvec = rotate(dir_uvec, strike_uvec, np.pi/2 - 1e-4)
    if sum_dip_inc > math.pi:
        inner_arc = np.atleast_2d(np.array([0.0, 0.0, -1.0]))
    else:
        inner_arc = trace_small_circle(cone_axis_uvec, inner_semiapical_angle, dec_angle)
    outer_arc = trace_small_circle(cone_axis_uvec, outer_semiapical_angle, dec_angle)
    if sum_dip_inc >= math.pi:
        window = np.concatenate(
            [
                #np.atleast_2d((vec2uvec([0, 0, -1]))),
                outer_arc
                #np.atleast_2d((vec2uvec([0, 0, -1])))
            ]
        )
    else:
        window = np.concatenate(
            [
                np.flip(outer_arc, axis=0),
                inner_arc,
                np.atleast_2d(outer_arc[-1, :])
            ]
        )
    return window


def rotation_matrix(axis, angle):
    """Computes the rotation matrix following the Euler-Rodridues formula
    for a given axis of rotation an a rotation angle.

    A vector is rotated by multiplying it with the rotation matrix.

    Args:
        axis (ndarray): Rotation axis given as an unit vector. Shape (3,).
        angle (float): Angle for counterclockwise rotation, in radians.

    Returns:
        ndarray: Rotation matrix of shape (3, 3)
    """
    a = np.cos(angle / 2.0)
    b, c, d = -axis * np.sin(angle / 2.0)
    aa, bb, cc, dd = a*a, b*b, c*c, d*d
    bc, ad, ac, ab, bd, cd = b*c, a*d, a*c, a*b, b*d, c*d
    matrix = np.array(
        [
            [aa + bb - cc - dd, 2 * (bc + ad), 2 * (bd - ac)],
            [2 * (bc - ad), aa + cc - bb - dd, 2 * (cd + ab)],
            [2 * (bd + ac), 2 * (cd - ab), aa + dd - bb - cc]
        ]
    )
    return matrix


def rotate(vecs, axis, angle, hemisphere=None):
    """Rotates n vectors counterclockwise around a given axis.

    It makes use of the Euler-Rodrigues formula as a slightly modified
    implementation from Stack Overflow user Unutbu
    (see: https://stackoverflow.com/a/6802723).

    Only difference is to require an axis as unit vector directly and
    not only calculate the rotation matrix but also do the rotation itself.

    Args:
        vecs (ndarray): n Vectors to be rotated. Shape (n, 3) or (3,).
        axis (ndarray): Rotation axis given as an unit vector. Shape (3,).
        angle (float): Angle for counterclockwise rotation, in radians.
        hemisphere (string): Keeps hemisphere if None, change hemisphere
            if "lower" or "upper" if rotated in opposite hemisphere.

    Returns:
        ndarray: Rotated vectors, same shape as vecs.
    """
    matrix = rotation_matrix(axis, angle)
    rotated_vecs = vecs.dot(matrix.T).T
    if hemisphere == "l" or hemisphere == "lower":
        rotated_vecs = np.where(
            rotated_vecs[2] <= 0.0,
            rotated_vecs,
            np.negative(rotated_vecs)
        )
    elif hemisphere == "u" or hemisphere == "upper":
        rotated_vecs = np.where(
            rotated_vecs[2] <= 0.0,
            np.negative(rotated_vecs),
            rotated_vecs
        )
    return rotated_vecs.T


def intersect(vecs):
    """Intersects planars, given as their pole unit vectors.

    Sometimes you may also want to know, which planes lead to which
    intersection (e.g. for kinematic analysis), so those informations
    are returned as well. There is no performance problem with this
    approach, as the implementation needs the indices anyway. It
    could change, if someone comes up with a better implementation.

    If you only need one or two of the return values, it's recommended
    to use unpacking with underscores for unneeded values. If you only
    need the intersections itself, you could write

        intersections, _, _ = intersect(vecs)

    Args:
        vecs (ndarray): n poles of planars, given as vectors. n > 1.
        Shape (n, 3) or(3,).

    Returns:
        ndarray: Intersections as linears, shape (((n**2-n)/2), 3)
        ndarray: Indices of first planars, shape (((n**2-n)/2), 3)
        ndarray: Indices of second planars, shape (((n**2-n)/2), 3)
    """
    n_vecs = vecs.shape[0]

    # get all indices of intersected planars
    planar_ids_1 = np.fromiter([
        i
        for i in range(n_vecs)
        for j in range(i+1, n_vecs)
    ], dtype="int")

    planar_ids_2 = np.fromiter([
        j
        for i in range(n_vecs)
        for j in range(i+1, n_vecs)
    ], dtype="int")

    planars_1 = vecs[planar_ids_1]
    planars_2 = vecs[planar_ids_2]

    intsecs = np.cross(planars_1, planars_2)

    # bring all intersections to lower hemisphere
    intsecs = np.where(
        intsecs[:, 2].reshape(intsecs.shape[0], 1) >= 0.0,
        np.negative(intsecs),
        intsecs
    )

    # make them uvecs
    intsecs = vec2uvec(intsecs)

    return np.atleast_2d(intsecs), planar_ids_1, planar_ids_2


def get_cos_distance(uvec, uvecs):
    """Returns the cosinus distances of unit vector to an arbitrary
    number of other unit vectors. This function is just a wrapper
    around uvecs.dot(uvec.T) and it's introduced for the sake of
    clarity.

    Args:
        uvec (ndarray): array of shape (3,)
        uvecs (ndarray): n unit vectors of shape (n, 3)

    Returns:
        ndarray: Array of shape (n,)
    """
    return uvecs.dot(uvec.T)


def get_dec_cos_distance(uvec, uvecs):
    """Returns the cosinus distances of unit vector to an arbitrary
    number of other unit vector in horizontal direction (decliantion)

    Args:
        uvec (ndarray): array of shape (3,)
        uvecs (ndarray): n unit vectors of shape (n, 3)

    Returns:
        ndarray: Array of shape (n,)
        TYPE: Description
    """
    uvec = vec2uvec(uvec[0:2])
    uvecs = np.atleast_2d(uvecs)
    uvecs = vec2uvec(uvecs[:, 0:2])
    return uvecs.dot(uvec.T)


def get_inc_cos_distance(uvec, uvecs):
    """Returns the cosinus distances of unit vector to an arbitrary
    number of other unit vector in vertical direction (inclination)

    Args:
        uvec (ndarray): array of shape (3,)
        uvecs (ndarray): n unit vectors of shape (n, 3)

    Returns:
        ndarray: Array of shape (n,)
    """
    uvec = np.array([np.sqrt(1.0 - uvec[2]**2), uvec[2]])
    uvecs = np.atleast_2d(uvecs)
    uvecs = np.array([np.sqrt(1.0 - uvecs[:, 2]**2), uvecs[:, 2]]).T
    return uvecs.dot(uvec.T)


def get_inc_angles_between(uvec, uvecs):
    """Returns the actual angles between an unit vector to an
    arbitrary number of other unit vectors in vertical direction
    (inclination).

    Args:
        uvec (ndarray): array of shape (3,)
        uvecs (ndarray): n unit vectors of shape (n, 3)

    Returns:
        float: Angle given in radians
    """
    uvec_angle = np.arccos(uvec[2])
    uvecs = np.atleast_2d(uvecs)
    uvecs_angles = np.arccos(uvecs[:, 2])
    return np.absolute(uvecs_angles - uvec_angle)


def get_angles_between(uvec, uvecs, rad_out=True):
    """Returns the actual angles between an unit vector to an
    arbitrary number of other unit vectors.

    Args:
        uvec (ndarray): array of shape (3,)
        uvecs (ndarray): n unit vectors of shape (n, 3)
        rad_out (optional, bool): Return radians if True,
            degrees if False

    Returns:
        float: Angle given in radians or degree, depending on rad_out.
    """
    cos_dist = get_cos_distance(uvec, uvecs)
    rad_angles = np.arccos(np.clip(cos_dist, -1.0, 1.0))
    if rad_out:
        return rad_angles
    else:
        return np.degrees(rad_angles)


def get_sum_vec(vecs):
    """Returns the sum of any given vectors. It's just a wrapper
    around NumPy's array method sum() with the argument axis=0.
    This function is just introduced for the sake of clarity.

    Args:
        vecs (ndarray): n unit vectors of shape (n, 3)

    Returns:
        ndarray: Array of shape (3,)
    """
    return vecs.sum(axis=0)


def get_sum_vec(uvecs):
    mean_axis = np.zeros(3)

    # first division is (0, 0, 0) / 0, so ignore runtime warning
    # this is fine
    with np.errstate(divide='ignore', invalid="ignore"):
        for uvec in uvecs:
            temp_mean_axis = mean_axis / math.sqrt(mean_axis.dot(mean_axis))
            if np.dot(temp_mean_axis, uvec) < 0.0:
                mean_axis = mean_axis + np.negative(uvec)
            else:
                mean_axis = mean_axis + uvec

    if mean_axis[2] > 0.0:
        return np.negative(mean_axis)
    else:
        return mean_axis


def get_mean_axis(uvecs):
    """
    Don't use it, use the corresponding function in sphericstats module.
    Will be removed in a later version most likely.
    """
    mean_axis = np.zeros(3)

    # first division is (0, 0, 0) / 0, so ignore runtime warning

    with np.errstate(divide='ignore', invalid="ignore"):
        for uvec in uvecs:
            temp_mean_axis = mean_axis / math.sqrt(mean_axis.dot(mean_axis))
            if np.dot(temp_mean_axis, uvec) < 0.0:
                mean_axis = mean_axis + np.negative(uvec)
            else:
                mean_axis = mean_axis + uvec

    return mean_axis


def get_vec_magnitude(vec):
    """Returns the magintude of any given vector. It's just a
    wrapper around math.sqrt(np.dot(vec, vec)).
    This function is just introduced for the sake of clarity.

    Args:
        vec (ndarray): Array of shape (3,). Other shapes are possible of
        course, just want to make clear, that it's meant for unit vectors,
        not for spherical coordinates.

    Returns:
        float: Magnitude of a vector.
    """
    return math.sqrt(np.dot(vec, vec))
