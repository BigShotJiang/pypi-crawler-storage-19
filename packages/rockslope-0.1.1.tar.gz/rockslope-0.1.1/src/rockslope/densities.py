"""The densities module provides the DensityEstimator class, which is able to
determine the density distribution of structural elements on a regular grid
based on the Schmidt method and the (modified) Kamb method. The density
distribution can then be used to generate a contour plot (see plot module).

The functions refer to Vollmer (1995): "C program for automatic contouring of
spherical orientation data using a modified Kamb method".

If you only want to create contour plots and do not need the numerical values
of the counting stations on the grid directly, you do not need to use this
module.
"""

import math
import numpy as np
from . import sphericmath as smath
from . import projections


class DensityEstimator:

    """
    A class for determining the distribution density of structural elements.

    Based on a method described in:

    Vollmer (1995:) "C program for automatic contouring of spherical
    orientation data using a modified Kamb method"

    There is no need to create the class directly to generate a contour plot.
    Just use the schmidt_density or kamb_density method from the plot module.
    """

    def __init__(
        self,
        uvecs,
        method="kamb",
        smoothing="exponential",
        sigma=3.0,
        schmidt_fractional=0.01,
        grid_size=50,
        projection="equal_area"
    ):
        """
        Args:
            uvecs (ndarray): n unit vectors of shape (n, 3) or (3,).
            method (str, optional): Use "kamb" or "schmidt"
            smoothing (str, optional):
                Use "inverse_area", "inverse_area_squared" or "exponential"
            sigma (float, optional): Standard deviation for Kamb method
            schmidt_fractional (float, optional):
                Fraction of total area used by Schmidt method
            grid_size (int, optional): Number of nodes for calculation grid
            projection (str, optional): Give the projection for the kind of
                plot you want your grid to be equally spaced in projection
                plane. "equal_area" and "equal angle" is supported.
        """
        self.uvecs = uvecs
        self.method = method
        self.smoothing = smoothing
        self.sigma = sigma
        self.schmidt_fractional = schmidt_fractional
        self.grid_size = grid_size
        self.projection = projection

        self._smoothing_funcs = {
            "exponential": self._exponential,
            "inverse_area": self._inverse_area,
            "inverse_area_squared": self._inverse_area_squared,
            "none": self._none
        }

        self._init_counters()
        self._init_estimator()

    def _init_counters(self):
        # create counting grid
        # it's equally spaced on the plane of projection
        steps = np.linspace(-1.0, 1.0, self.grid_size)
        x, y = np.meshgrid(steps, steps)
        xy = np.array([np.ravel(x), np.ravel(y)]).T
        if self.projection == "equal_area":
            xyz = projections.inverted_project(xy, self.projection)
        else:
            xy = xy.T
            r = xy[0] * xy[0] + xy[1] * xy[1]
            z = (1 - r) / (1 + r)
            x = (1 + z) * xy[0]
            y = - (1 + z) * xy[1]
            xyz = np.array([x, y, z]).T
        self.counters_projected = xy
        self.counters = xyz

    def _init_estimator(self):

        # wf: weighting factor
        # nf: normalization factor
        # cs: cosine of semiapical angle
        # see attribute assignment below

        n = self.uvecs.shape[0]
        wf = 1.0

        if self.method == "schmidt":
            fractional_area = self.schmidt_fractional
            nf = 1.0 / (1.0 / (n * self.schmidt_fractional))
            if self.smoothing == "exponential":
                raise ValueError("Exponential smoothing not supported")

        elif self.method == "kamb":
            fractional_area = self.sigma**2 / (n + self.sigma**2)
            if self.smoothing == "exponential":
                wf = 2.0 * (1.0 + n / self.sigma**2)
                nf = 1.0 / math.sqrt(n * (wf * 0.5 - 1.0) / wf**2)
            else:
                nf = 1.0 / math.sqrt(
                    n * fractional_area * (1.0 - fractional_area)
                )

        cs = 1.0 - fractional_area

        if self.smoothing == "inverse_area":
            wf = 2.0 / (1.0 - cs)
        elif self.smoothing == "inverse_area_squared":
            wf = 3.0 / (1.0 - cs)**2

        self.weighting = wf
        self.cos_semiapical = cs
        self.normalization = nf

    def estimate(self):
        """Use this method after initialisation of DenstiyEstimator.
        It actually computes the densities on the counting stations.

        Returns:
            ndarray: Array with calculated densities. Shape is the same
                as the counting grid.
        """
        densities = np.zeros(self.counters.shape[0], dtype=float)
        for i, counter in enumerate(self.counters):
            cos_dists = np.abs(counter.dot(self.uvecs.T))
            smoothed = self._smoothing_funcs[self.smoothing](
                cos_dists=cos_dists,
                weighting=self.weighting,
                cos_semiapical=self.cos_semiapical
            )
            densities[i] = (smoothed.sum() - 0.5) * self.normalization

        densities = np.where(densities < 0.0, 0.0, densities)
        densities = densities.reshape(self.grid_size, self.grid_size).T
        return np.rot90(densities, 3)

    def _exponential(self, **kwargs):

        # exponential weighting function

        weighting = kwargs["weighting"]
        cos_dists = kwargs["cos_dists"]

        return np.exp(weighting * (cos_dists - 1.0))

    def _inverse_area(self, **kwargs):

        # inverse area weighting function

        weighting = kwargs["weighting"]
        cos_dists = kwargs["cos_dists"]
        cos_semiapical = kwargs["cos_semiapical"]

        return (
            (cos_dists - cos_semiapical) * (cos_dists >= cos_semiapical)
            * weighting
        )

    def _inverse_area_squared(self, **kwargs):

        # inverse area squared weighting function

        weighting = kwargs["weighting"]
        cos_dists = kwargs["cos_dists"]
        cos_semiapical = kwargs["cos_semiapical"]

        return (
            (cos_dists - cos_semiapical)**2 * (cos_dists >= cos_semiapical)
            * weighting
        )

    def _none(self, **kwargs):

        # used, if no weighting function is applied

        cos_dists = kwargs["cos_dists"]
        cos_semiapical = kwargs["cos_semiapical"]

        return (cos_dists >= cos_semiapical).astype(float)
