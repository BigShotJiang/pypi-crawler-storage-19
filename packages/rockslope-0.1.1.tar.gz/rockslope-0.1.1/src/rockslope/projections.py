"""The module projections contains only two functions, which allow the equal
angle and equal area projection of unit vectors (3D) onto the plane (2D) and
vice versa.

Both functions refer to Vollmer (1995): "C program for automatic contouring of
spherical orientation data using a modified Kamb method".

The functions are needed to display the projections in Matplotlib, because
Matplotlib is not able to display these projections by default. Especially it
is not possible to project unit vectors there, because Matplotlib only supports
spherical coordinates (longitude, latitude).

By using unit vectors directly, you avoid unnecessary coordinate
transformations like unit vectors to lon/lat to Matplotlib display coordinates.

If you are only interested in plotting stereonets, there is no need to use the
module directly, as its functionality is included in the plot module.
"""

import numpy as np


def project(uvecs, projection="equal_angle"):
    """Projection of unit vectors resp. direction cosines to the plane.
    It's a non-affine transformation.

    For reference see:

    Vollmer (1995): "C program for automatic contouring of spherical
    orientation data using a modified Kamb method"

    The output values are in a rectangle from (-1, -1) to (1, 1).
    For use in matplotlib you have to take care of the affine
    transformation as well, which is easy here. Use:

    Affine2D.scale(0.5, 0.5).translate(0.5, 0.5)

    to receive coordinates in matplotlib's axes space resp. in the
    unit rectangle from (0, 0) to (1, 1).

    Args:
        uvecs (ndarray): n unit vectors to be projected
            Shape (n, 3) or (3,)
        projection (str, optional): Type of projection.
            Either "equal_angle" resp. stereographic projection or
            "equal_area" resp. Lambert azimutal projection is possible

    Returns:
        ndarray: 2D coordinates of projected unit vectors, shape (n, 2)
    """

    # dealing with zero division like here:
    # https://stackoverflow.com/a/37977222
    uvecs = uvecs.T

    if projection == "equal_angle":
        denominator = (1.0 - uvecs[2])
    elif projection == "equal_area":
        denominator = np.sqrt((1.0 - uvecs[2]))
    else:
        raise ValueError(f"Invalid projection: {projection}")
    # no need to catch any mistyped projection names here,
    # because they are already recognized my matplotlib before

    x = np.divide(
        uvecs[0], denominator,
        out=np.zeros_like(uvecs[0]),
        where=(denominator != 0.0)
    )
    y = np.divide(
        uvecs[1], denominator,
        out=np.zeros_like(uvecs[1]),
        where=(denominator != 0.0)
    )
    return np.array([x, y]).T


def inverted_project(xy, projection="equal_angle"):
    """Used for projection of points on the plane back to the sphere.
    It's necessary to give the kind of projection which lead to the projection
    to the plane. It's either equal_angle or equal_area.

    For reference see:

    Vollmer (1995): "C program for automatic contouring of spherical
    orientation data using a modified Kamb method"

    Args:
        xy (ndarray): 2D coordinates of projected unit vectors, shape (n, 2)
        projection (str, optional): Type of projection.
            Either "equal_angle" resp. stereographic projection or
            "equal_area" resp. Lambert azimutal projection is possibl

    Returns:
        TYPE: n unit vectors to be projected. Shape (n, 3) or (3,)
    """

    xy = xy.T
    r = xy[0] * xy[0] + xy[1] * xy[1]
    if projection == "equal_angle":
        z = (1 - r) / (1 + r)
        x = (1 + z) * xy[0]
        y = - (1 + z) * xy[1]
    elif projection == "equal_area":
        z = 1 - r
        x = np.sqrt(np.abs(2 - r)) * xy[0]
        y = - np.sqrt(np.abs(2 - r)) * xy[1]
    return np.array([x, y, z]).T
