"""Public API for the RockSlope package.

This module provides the high-level interface intended for end users.
The primary entry point is :class:`RockMass`, which manages discontinuity
(joint) orientation data, supports defining joint sets via selection windows,
computing set statistics, running kinematic analyses, plotting stereonets,
and generating text reports.

Notes:
    Angles passed into the public API are generally expected in degrees.
    Internally, orientations are stored in radians and often represented as
    unit vectors on the sphere.
"""

import math
import csv
import numpy as np
import matplotlib.pyplot as plt
from . import kinematics
from . import sphericmath as smath
from . import sphericstats as sstats
from . import selections
from . import plot  # necessary for registration of projections
from . import rstbuilder as rst
import uuid

np.seterr(all="ignore")


class RockMass:
    """Container and analysis workflow for joint orientation data.

    The class stores joint orientations (dip direction and dip) and offers:
    - Defining joint sets via circular/rectangular selection windows.
    - Computing set statistics (mean axes, confidence/variability angles, kappa).
    - Performing kinematic analyses against a given slope orientation.
    - Plotting stereonet visualizations for data, selections, and failure modes.
    - Generating a reStructuredText-based report.

    Args:
        joints (array-like): Joint orientations as dip direction and dip
            in degrees. Expected shape is (n, 2), e.g. ``[[230, 23], [145, 45]]``.

    Attributes:
        joints (numpy.ndarray): Joint orientations in radians as a NumPy array
            of shape (n, 2): ``[[dip_direction_rad, dip_rad], ...]``.

    Notes:
        - Internally, ``_uvecs`` are unit vectors representing planes, and
          ``_pole_uvecs`` represent pole vectors.
        - Many computations require that one or more selections were defined
          via ``add_circular_selection`` / ``add_rectangular_selection``.
        - Kinematic computations require a slope to be set via ``add_slope``.
    """

    def __init__(self, joints):
        """Initialize a RockMass instance.

        Converts input joint orientations from degrees to radians and computes
        cached unit-vector representations used throughout the analysis.

        Args:
            joints (array-like): Joint orientations as dip direction and dip
                in degrees; shape (n, 2).

        Raises:
            ValueError: If `joints` cannot be converted to a float array of
                shape (n, 2).
        """
        self.joints = np.deg2rad(np.array(joints, dtype=float))  # [[230, 23], [145, 45]]
        self._uvecs = smath.spheric2uvec(self.joints)
        self._pole_uvecs = smath.spheric2pole_uvec(self.joints)
        self._selections = []
        self._selection_params = []
        self._slope = None
        self._mean_axes = None
        self._statistics_computed = False
        self._kinematics_computed = False

    def add_circular_selection(self, dip_direction, dip, apical_angle):
        """Add a circular selection window and store the selected joints.

        The selection is defined by a center orientation (dip direction/dip)
        and an apical angle. Internally, the given apical angle is converted
        to a semi-apical angle (half angle) in radians.

        Args:
            dip_direction (float): Dip direction of the window center in degrees.
            dip (float): Dip of the window center in degrees.
            apical_angle (float): Full apical angle of the selection window
                in degrees.

        Side Effects:
            Appends a boolean mask (selection) into ``self._selections`` and
            stores the corresponding parameters in ``self._selection_params``.
        """
        dir_uvec = smath.spheric2uvec(
            np.array([math.radians(dip_direction), math.radians(dip)], dtype=float)
        )
        angle = math.radians(apical_angle / 2.0)  # semi-apical angle
        selected = selections.select_circular(dir_uvec, angle, self._pole_uvecs)
        self._selections.append(selected)
        self._selection_params.append({"dir_uvec": dir_uvec, "angle": angle})

    def add_rectangular_selection(self, dip_direction, dip, dec_angle, inc_angle):
        """Add a rectangular selection window and store the selected joints.

        A rectangular selection window is defined around a central orientation
        with separate angular bounds in "declination" and "inclination" directions.

        Args:
            dip_direction (float): Dip direction of the window center in degrees.
            dip (float): Dip of the window center in degrees.
            dec_angle (float): declination angle bound in degrees.
            inc_angle (float): inclination angle bound in degrees.

        Side Effects:
            Appends a boolean mask (selection) into ``self._selections`` and
            stores the corresponding parameters in ``self._selection_params``.
        """
        dir_uvec = smath.spheric2uvec(
            np.array([math.radians(dip_direction), math.radians(dip)], dtype=float)
        )
        dec_angle = math.radians(dec_angle)
        inc_angle = math.radians(inc_angle)
        selected = selections.select_rectangular(dir_uvec, dec_angle, inc_angle, self._pole_uvecs)
        self._selections.append(selected)
        self._selection_params.append(
            {"dir_uvec": dir_uvec, "dec_angle": dec_angle, "inc_angle": inc_angle}
        )

    def add_slope(self, dip_direction, dip):
        """Define the slope orientation used for kinematic analyses and plotting.

        Args:
            dip_direction (float): Slope dip direction in degrees.
            dip (float): Slope dip in degrees.

        Side Effects:
            Stores slope parameters in ``self._add_slope_params`` and caches
            the slope pole unit vector in ``self._slope``.
        """
        self._add_slope_params = {"dip_direction": dip_direction, "dip": dip}
        slope = np.array([math.radians(dip_direction), math.radians(dip)], dtype=float)
        self._slope = smath.spheric2pole_uvec(slope)

    def compute_kinematics(
        self,
        joint_friction=30.0,
        lateral_limit=30.0,
        planar_sliding=True,
        planar_sliding_no_limit=True,
        wedge_sliding=True,
        flexural_toppling=True,
        direct_toppling=True,
    ):
        """Compute kinematic failure modes for the rock slope.

        The method computes failure conditions (planar sliding, wedge sliding,
        flexural toppling, direct toppling) using the internal
        :class:`kinematics.RockSlopeKinematics` engine. Results are stored on
        the instance for later use in plotting and reporting.

        Args:
            joint_friction (float, optional): Friction angle (degrees) used by
                the kinematic checks. Defaults to 30.0.
            lateral_limit (float | None, optional): Lateral limit angle in
                degrees. If ``None``, lateral constraints are disabled for
                relevant checks. Defaults to 30.0.
            planar_sliding (bool, optional): Whether to compute planar sliding
                with the provided lateral limit. Defaults to True.
            planar_sliding_no_limit (bool, optional): Whether to compute planar
                sliding with lateral limit disabled. Stored separately in
                ``self._rsk_no_limit``. Defaults to True.
            wedge_sliding (bool, optional): Whether to compute wedge sliding.
                Defaults to True.
            flexural_toppling (bool, optional): Whether to compute flexural
                toppling. Defaults to True.
            direct_toppling (bool, optional): Whether to compute direct
                toppling. Defaults to True.

        Raises:
            ValueError: If no slope was defined via :meth:`add_slope`.

        Side Effects:
            Sets ``self._kinematics_computed`` and stores results in:
            - ``self._rsk`` (computed on all poles),
            - ``self._rsk_mean`` (computed on mean axes, if available),
            - ``self._rsk_no_limit`` (optional planar sliding without limit).

        Notes:
            This function expects ``self._pole_uvecs`` to represent joint poles.
            If ``self._mean_axes`` has been computed (via :meth:`compute_statistics`
            with ``mean_axes=True``), kinematics are computed for both the full
            dataset and the mean axes.
        """
        self._kinematics_computed = True

        if self._slope is None:
            raise ValueError("You have to add a slope using RockMass.add_slope first")

        self._kinematics_params = {
            "joint_friction": joint_friction,
            "lateral_limit": lateral_limit,
        }

        if lateral_limit is not None:
            lateral_limit = math.radians(lateral_limit)

        def _compute_kinematics(
            joints,
            slope,
            joint_friction,
            lateral_limit,
            planar_sliding,
            wedge_sliding,
            flexural_toppling,
            direct_toppling,
        ):
            """Run the selected kinematic checks and return a kinematics object.

            Args:
                joints (numpy.ndarray): Joint pole unit vectors.
                slope (numpy.ndarray): Slope pole unit vector.
                joint_friction (float): Friction angle in radians.
                lateral_limit (float | None): Lateral limit in radians or None.
                planar_sliding (bool): Compute planar sliding.
                wedge_sliding (bool): Compute wedge sliding.
                flexural_toppling (bool): Compute flexural toppling.
                direct_toppling (bool): Compute direct toppling.

            Returns:
                kinematics.RockSlopeKinematics: The populated kinematics object.
            """
            # joints as poles!
            rsk = kinematics.RockSlopeKinematics(joints, slope, friction)
            if planar_sliding:
                rsk.check_planar_sliding(lateral_limit)

            if wedge_sliding:
                rsk.check_wedge_sliding()

            if flexural_toppling:
                rsk.check_flexural_toppling(lateral_limit)

            if direct_toppling:
                rsk.check_direct_toppling(lateral_limit)

            return rsk

        friction = math.radians(joint_friction)

        if self._mean_axes:
            self._rsk_mean = _compute_kinematics(
                self._mean_axes,
                self._slope,
                friction,
                lateral_limit,
                planar_sliding,
                wedge_sliding,
                flexural_toppling,
                direct_toppling,
            )
        else:
            self._rsk_mean = None

        self._rsk = _compute_kinematics(
            self._pole_uvecs,
            self._slope,
            friction,
            lateral_limit,
            planar_sliding,
            wedge_sliding,
            flexural_toppling,
            direct_toppling,
        )

        if planar_sliding_no_limit:
            self._rsk_no_limit = _compute_kinematics(
                self._pole_uvecs,
                self._slope,
                friction,
                None,
                planar_sliding,
                False,
                False,
                False,
            )

    def compute_statistics(
        self,
        mean_axes=True,
        fisher_confidence_angles=True,
        dips_confidence_angles=True,
        variability_angles=True,
        kappa_fisher=True,
        kappa_davis=True,
        confidence=0.95,
    ):
        """Compute orientation statistics for each defined selection (joint set).

        Statistics are computed per selection in ``self._selections`` and stored
        on the instance. Common outputs include mean axes and measures of spread
        (confidence/variability angles) and concentration parameters (kappa).

        Args:
            mean_axes (bool, optional): Compute and store mean axes for each
                selection in ``self._mean_axes``. Defaults to True.
            fisher_confidence_angles (bool, optional): Compute Fisher confidence
                angles with the provided `confidence` level and store them in
                ``self._fisher_confidence_angles``. Defaults to True.
            dips_confidence_angles (bool, optional): Compute Priest confidence
                angles for a fixed set of confidence levels (68.26%, 95.44%,
                99.74%, 50.00%) and store them in ``self._dips_confidence_angles``.
                Defaults to True.
            variability_angles (bool, optional): Compute variability angles for
                the same fixed confidence levels and store them in
                ``self._variability_angles``. Defaults to True.
            kappa_fisher (bool, optional): Estimate Fisher kappa for each
                selection and store in ``self._kappa_fisher``. Defaults to True.
            kappa_davis (bool, optional): Estimate Davis kappa for each
                selection and store in ``self._kappa_davis``. Defaults to True.
            confidence (float, optional): Confidence level used for Fisher
                confidence angles (if enabled). Defaults to 0.95.

        Side Effects:
            Sets ``self._statistics_computed`` and stores computed results on
            the instance.

        Notes:
            This method expects at least one selection in ``self._selections``.
            If no selections are defined, lists created by this method will be
            empty (and reporting will indicate that no sets were defined).
        """
        self._statistics_computed = True

        if any(
            [
                fisher_confidence_angles,
                dips_confidence_angles,
                variability_angles,
                kappa_fisher,
                kappa_davis,
            ]
        ):
            sum_vec_magnitudes = [
                smath.get_vec_magnitude(smath.get_sum_vec(self._pole_uvecs[selection]))
                for selection in self._selections
            ]

        if mean_axes:
            self._mean_axes = [
                sstats.get_mean_axis(self._pole_uvecs[selection]) for selection in self._selections
            ]

        if fisher_confidence_angles:
            self._fisher_confidence_angles = [
                sstats.get_confidence_angle(
                    sum_vec_magnitude, np.sum(selection), confidence, "fisher"
                )
                for sum_vec_magnitude, selection in zip(sum_vec_magnitudes, self._selections)
            ]

        confidences = [0.6826, 0.9544, 0.9974, 0.50]
        if dips_confidence_angles:
            self._dips_confidence_angles = [
                {
                    confidence: sstats.get_confidence_angle(
                        sum_vec_magnitude, np.sum(selection), confidence, "priest"
                    )
                    for confidence in confidences
                }
                for sum_vec_magnitude, selection in zip(sum_vec_magnitudes, self._selections)
            ]

        if variability_angles:
            self._variability_angles = [
                {
                    confidence: sstats.get_variability_angle(
                        sum_vec_magnitude, np.sum(selection), confidence
                    )
                    for confidence in confidences
                }
                for sum_vec_magnitude, selection in zip(sum_vec_magnitudes, self._selections)
            ]

        if kappa_fisher:
            self._kappa_fisher = [
                sstats.estimate_fisher_kappa(sum_vec_magnitude, np.sum(selection), "fisher")
                for sum_vec_magnitude, selection in zip(sum_vec_magnitudes, self._selections)
            ]

        if kappa_davis:
            self._kappa_davis = [
                sstats.estimate_fisher_kappa(sum_vec_magnitude, np.sum(selection), "davis")
                for sum_vec_magnitude, selection in zip(sum_vec_magnitudes, self._selections)
            ]

    def plot(
        self,
        poles=True,
        great_circles=False,
        intersections=False,
        selection_windows=True,
        confidence_angles=None,
        kinematics=None,
        densities=None,
        projection="equal_angle",
        grid_kind="none",
        save_as=False,
        show=False,
    ):
        """Plot stereonet visualizations for joints, selections, and analyses.

        This method uses a custom Matplotlib stereonet projection registered by
        the RockSlope package. It can plot poles, great circles, intersections,
        selection windows, density overlays, mean axes with confidence circles,
        and kinematic failure zones.

        Args:
            poles (bool, optional): Plot poles of all joints. Defaults to True.
            great_circles (bool, optional): Plot great circles for all joints.
                Defaults to False.
            intersections (bool, optional): Plot intersections of joint planes.
                Defaults to False.
            selection_windows (bool, optional): Plot selection windows associated
                with defined sets. Defaults to True.
            confidence_angles (str | None, optional): If set to ``"fisher"``,
                plots Fisher confidence circles around mean axes (requires
                :meth:`compute_statistics`). Defaults to None.
            kinematics (str | None, optional): If provided, plots the requested
                kinematic mode overlay. Recognized values include:
                ``"planar_sliding"``, ``"planar_sliding_no_limit"``,
                ``"wedge_sliding"``, ``"flexural_toppling"``,
                ``"direct_toppling"``, ``"direct_toppling_base"``.
                Requires :meth:`add_slope` and :meth:`compute_kinematics`.
                Defaults to None.
            densities (str | None, optional): Density visualization mode.
                Currently supports ``"kamb"``. Defaults to None.
            projection (str, optional): Matplotlib projection name registered by
                the package, e.g. ``"equal_angle"``. Defaults to "equal_angle".
            grid_kind (str, optional): Grid type passed to ``ax.stereogrid``.
                Defaults to "none".
            save_as (str | bool, optional): If truthy and a string, path to save
                the figure via ``plt.savefig``. Defaults to False.
            show (bool, optional): Whether to display the figure via ``plt.show``.
                Defaults to False.

        Side Effects:
            Creates a Matplotlib figure/axes. Optionally writes an image file
            and/or shows the plot window.

        Notes:
            A unique axis label is used to avoid Matplotlib reusing axes when
            calling this method multiple times in a script.
        """
        labels = {
            "planar_sliding": "Planar Sliding",
            "planar_sliding_no_limit": "Planar Sliding (No Limit)",
            "wedge_sliding": "Wedge Sliding",
            "flexural_toppling": "Flexural Toppling",
            "direct_toppling": "Direct Toppling (Intersections)",
            "direct_toppling_base": "Direct Toppling (Base Planes)",
        }
        construction_line_params = {"color": "#2a343b", "linewidth": 0.9}
        selection_window_params = {"linewidth": 0.9}
        selection_colors = ["#f4a261", "#5e9ad1", "#a1c181", "#eb9bc7"]

        fig = plt.figure(dpi=300)
        fig.set_size_inches(2.54 * 21 * 0.1, 2.54 * 29.7 * 0.1)
        ax = fig.add_subplot(111, projection=projection, label=uuid.uuid4().hex)
        # creating a unique label is necessary to avoid reusing axes
        # by Matplotlib, when plot() is executed more then once in a script

        ax.stereogrid(which="major", kind=grid_kind, longitude_cap=80, major_grid_distance=10)

        if great_circles:
            ax.plot_planars(
                self._pole_uvecs, kind="great_circles", color="#66727a", linewidth=0.3
            )
        if poles:
            ax.plot_planars(self._pole_uvecs, color="#66727a", markersize=2)
        if intersections:
            ax.plot_axes(smath.intersect(self._pole_uvecs)[0], color="#66727a", marker=",")

        if densities == "kamb":
            ax._plot_density(self._pole_uvecs, cmap="bone_r")

        for selection, color in zip(self._selections, selection_colors[: len(self._selections)]):
            ax.plot_planars(self._pole_uvecs[selection], color=color, markersize=2)

        for selection, params, color in zip(
            self._selections,
            self._selection_params,
            selection_colors[: len(self._selections)],
        ):
            if len(params) == 2:  # circurlar selection
                ax.plot_small_circle(
                    params["dir_uvec"], params["angle"], color=color, **selection_window_params
                )
            else:  # rectangular selection
                ax.plot_rectangular_selection_window(
                    params["dir_uvec"],
                    params["dec_angle"],
                    params["inc_angle"],
                    color=color,
                    **selection_window_params,
                )

        if self._mean_axes:
            for mean_axis, color in zip(self._mean_axes, selection_colors[: len(self._mean_axes)]):
                ax.plot_planars(
                    mean_axis,
                    markeredgewidth=1,
                    color=color,
                    markeredgecolor=color,
                    markerfacecolor="#ffffff",
                    kind="both",
                    marker="D",
                    markersize=5,
                    linewidth=0.9,
                )
            if confidence_angles == "fisher":
                for mean_axis, angle, color in zip(
                    self._mean_axes,
                    self._fisher_confidence_angles,
                    selection_colors[: len(self._mean_axes)],
                ):
                    ax.plot_small_circle(mean_axis, angle, color=color)

        if kinematics is not None:
            dip_direction = self._add_slope_params["dip_direction"]
            dip = self._add_slope_params["dip"]
            friction = self._kinematics_params["joint_friction"]
            lateral_limit = None

            ax.plot_planars(self._slope, kind="great_circles", color="#2a343b", linewidth=1.5)

            if kinematics == "planar_sliding_no_limit":
                failure = self._rsk_no_limit.planar_sliding
                failing_elements = "pole_uvecs"
                ax.plot_small_circle(
                    np.array([0.0, 0.0, -1.0]),
                    np.radians(friction),
                    **construction_line_params,
                )
                ax.plot_daylight_envelope(self._slope, **construction_line_params, n_nodes=500)
                lateral_limit = False

            if self._rsk_mean is not None:
                rsks = [rsk for rsk in [[self._rsk, "regular"], [self._rsk_mean, "mean"]]]
            else:
                rsks = [[self._rsk, "regular"]]

            for rsk in rsks:
                kind = rsk[1]
                rsk = rsk[0]

                if kinematics == "planar_sliding":
                    failure = rsk.planar_sliding
                    failing_elements = "pole_uvecs"
                    lateral_limit = self._kinematics_params["lateral_limit"]
                    ax.plot_small_circle(
                        np.array([0.0, 0.0, -1.0]),
                        np.radians(friction),
                        **construction_line_params,
                    )
                    ax.plot_daylight_envelope(self._slope, **construction_line_params, n_nodes=500)

                elif kinematics == "wedge_sliding":
                    failure = np.any(
                        [rsk.wedge_sliding_primary, rsk.wedge_sliding_secondary], axis=0
                    )
                    failing_elements = "intsecs"
                    ax.plot_small_circle(
                        np.array([0.0, 0.0, -1.0]),
                        np.radians(90.0 - friction),
                        **construction_line_params,
                    )
                    ax.plot_planars(
                        smath.switch(
                            smath.spheric2uvec(
                                np.array([np.radians(dip_direction), np.radians(friction)])
                            )
                        ),
                        kind="great_circles",
                        **construction_line_params,
                    )

                elif kinematics == "flexural_toppling":
                    failure = rsk.flexural_toppling
                    failing_elements = "pole_uvecs"
                    lateral_limit = self._kinematics_params["lateral_limit"]

                    slip_limit_plane = smath.switch(
                        smath.spheric2uvec(np.array([np.radians(dip_direction), rsk._slip_limit]))
                    )
                    ax.plot_planars(
                        slip_limit_plane, kind="great_circles", **construction_line_params
                    )

                elif kinematics == "direct_toppling":
                    failure = np.any(
                        [
                            rsk.direct_toppling_zone_1,
                            # rsk.direct_toppling_zone_2,
                            rsk.direct_toppling_zone_3,
                        ],
                        axis=0,
                    )
                    failing_elements = "intsecs"
                    lateral_limit = self._kinematics_params["lateral_limit"]

                    ax.plot_small_circle(
                        np.array([0.0, 0.0, -1.0]),
                        np.radians(friction),
                        **construction_line_params,
                    )
                    ax.plot_small_circle(
                        np.array([0.0, 0.0, -1.0]),
                        np.radians(dip),
                        **construction_line_params,
                    )
                    ax._plot_line(dip_direction + 90.0, **construction_line_params)

                elif kinematics == "direct_toppling_base":
                    lateral_limit = self._kinematics_params["lateral_limit"]

                    ax.plot_small_circle(
                        np.array([0.0, 0.0, -1.0]),
                        np.radians(friction),
                        **construction_line_params,
                    )
                    ax.plot_small_circle(
                        np.array([0.0, 0.0, -1.0]),
                        np.radians(dip),
                        **construction_line_params,
                    )
                    ax._plot_line(dip_direction + 90.0, **construction_line_params)

                    failing_elements = "pole_uvecs"
                    failure = np.any(
                        [rsk.direct_toppling_base_23, rsk.direct_toppling_base_1], axis=0
                    )

                if lateral_limit:
                    lateral_limit_orientations = [dip_direction - lateral_limit, dip_direction + lateral_limit]
                    for orientation in lateral_limit_orientations:
                        ax._plot_line(orientation, **construction_line_params)

                if failing_elements == "intsecs":
                    if kind == "regular":
                        params = {"color": "#e32746", "marker": ".", "markersize": 1.5}
                    elif kind == "mean":
                        params = {
                            "marker": "D",
                            "markersize": 5,
                            "markeredgecolor": "#e32746",
                            "markerfacecolor": "#ffffff",
                        }
                elif failing_elements == "pole_uvecs":
                    if kind == "regular":
                        params = {"color": "#e32746", "marker": ".", "markersize": 4}
                    elif kind == "mean":
                        params = {"color": "#e32746", "marker": "D", "markersize": 2}

                ax.plot_planars(getattr(rsk, failing_elements)[failure], **params)
                ax.text(-1.0, 1.4, labels[kinematics], fontsize=7, horizontalalignment="left", weight="bold")
                slope_dipdir = self._add_slope_params["dip_direction"]
                slope_dip = self._add_slope_params["dip"]
                ax.text(
                    -1.0,
                    1.3,
                    f"Slope (Dip Direction / Dip): {slope_dipdir:03d} / {slope_dip:02d}",
                    fontsize=7,
                    horizontalalignment="left",
                )

        if save_as:
            plt.savefig(save_as)
        if show:
            plt.show()

    def get_report(self, projectname=None, author=None, date=None, description=None, save_as=False):
        """Generate a reStructuredText report for statistics and kinematics.

        The report contains:
        - Basic project metadata (optional).
        - Number of planes and intersections.
        - Set statistics, if computed via :meth:`compute_statistics`.
        - Kinematic analysis summary, if computed via :meth:`compute_kinematics`.

        Args:
            projectname (str | None, optional): Project title. Defaults to None.
            author (str | None, optional): Author name. Defaults to None.
            date (str | None, optional): Date string (free format). Defaults to None.
            description (str | None, optional): Project description. Defaults to None.
            save_as (str | bool, optional): If truthy and a string, path to write
                the report text file. Defaults to False.

        Returns:
            None: The method prints the report to stdout. If `save_as` is set,
            the report is additionally written to the given file.

        Side Effects:
            Prints the generated report and optionally writes it to disk.

        Notes:
            This method assumes that set-related attributes (e.g.
            ``self._dips_confidence_angles``) exist if and only if statistics
            were computed with the corresponding options enabled.
        """
        set_statistics_tables = []
        set_statistics = []
        if self._statistics_computed:
            set_statistics = []
            for confidence_angles, variability_angles in zip(
                self._dips_confidence_angles, self._variability_angles
            ):
                set_statistics_tables.append(
                    rst.SimpleTable(
                        {
                            "Levels": ["Variability Limit", "Confidence Limit"],
                            "68,26 %": [
                                f"{(np.rad2deg(variability_angles[0.6826])):.4f}",
                                f"{(np.rad2deg(confidence_angles[0.6826])):.5f}",
                            ],
                            "95,44 %": [
                                f"{(np.rad2deg(variability_angles[0.9544])):.4f}",
                                f"{(np.rad2deg(confidence_angles[0.9544])):.5f}",
                            ],
                            "99,74 %": [
                                f"{(np.rad2deg(variability_angles[0.9974])):.4f}",
                                f"{(np.rad2deg(confidence_angles[0.9974])):.5f}",
                            ],
                            "50,00 %": [
                                f"{(np.rad2deg(variability_angles[0.50])):.4f}",
                                f"{(np.rad2deg(confidence_angles[0.50])):.5f}",
                            ],
                        }
                    )
                )
            for n, (selection, kappa_fisher, table, mean) in enumerate(
                zip(self._selections, self._kappa_fisher, set_statistics_tables, self._mean_axes)
            ):
                mean = smath.uvec2spheric(smath.switch(mean))
                dipdir, dip = mean[0]
                dipdir, dip = np.rad2deg(dipdir), np.rad2deg(dip)
                set_statistics.append(
                    [
                        rst.Heading(f"Set {n+1}", level=3),
                        rst.Paragraph(f"Poles: {np.sum(selection)}"),
                        rst.Paragraph(f"Fisher's K: {kappa_fisher:.4f}"),
                        rst.Paragraph(f"Mean: {dipdir:.2f} / {dip:.2f}"),
                        table,
                    ]
                )
        if set_statistics == []:
            set_statistics = rst.Paragraph("No sets were defined or statistics calculated.")

        n_poles = len(self._pole_uvecs)
        n_intsecs = len(smath.intersect(self._pole_uvecs)[0])

        kinematics_report = rst.Paragraph("No kinematic analysis was calculated.")
        if self._kinematics_computed:
            n_planar_sliding = sum(self._rsk.planar_sliding)
            p_planar_sliding = n_planar_sliding / n_poles * 100

            n_planar_sliding_no_limits = sum(self._rsk_no_limit.planar_sliding)
            p_planar_sliding_no_limits = n_planar_sliding_no_limits / n_poles * 100

            n_wedge_sliding_primary = sum(self._rsk.wedge_sliding_primary)
            p_wedge_sliding_primary = n_wedge_sliding_primary / n_intsecs * 100
            n_wedge_sliding_secondary = sum(self._rsk.wedge_sliding_secondary)
            p_wedge_sliding_secondary = n_wedge_sliding_secondary / n_intsecs * 100
            n_wedge_sliding_total = n_wedge_sliding_primary + n_wedge_sliding_secondary
            p_wedge_sliding_total = n_wedge_sliding_total / n_intsecs * 100

            n_flexural_toppling = sum(self._rsk.flexural_toppling)
            p_flexural_toppling = n_flexural_toppling / n_poles * 100

            n_direct_toppling_1_2 = sum(self._rsk.direct_toppling_zone_1) + sum(
                self._rsk.direct_toppling_zone_2
            )
            p_direct_toppling_1_2 = n_direct_toppling_1_2 / n_intsecs * 100
            n_direct_toppling_3 = sum(self._rsk.direct_toppling_zone_3)
            p_direct_toppling_3 = n_direct_toppling_3 / n_intsecs * 100
            n_direct_toppling_base_1 = sum(self._rsk.direct_toppling_base_1)
            p_direct_toppling_base_1 = n_direct_toppling_base_1 / n_poles * 100
            n_direct_toppling_base_23 = sum(self._rsk.direct_toppling_base_23)
            p_direct_toppling_base_23 = n_direct_toppling_base_23 / n_poles * 100
            n_direct_toppling_base_total = n_direct_toppling_base_1 + n_direct_toppling_base_23
            p_direct_toppling_base_total = n_direct_toppling_base_total / n_poles * 100

            slope_dipdir = self._add_slope_params["dip_direction"]
            slope_dip = self._add_slope_params["dip"]

            kinematics_report = [
                rst.Paragraph(f"Slope (Dip Direction / Dip): {slope_dipdir:03d} / {slope_dip:02d}"),
                rst.Paragraph(f"Friction Angle: {self._kinematics_params['joint_friction']:.1f}"),
                rst.Paragraph(f"Lateral Limit Angle: {self._kinematics_params['lateral_limit']:.1f}"),
                rst.Heading("Planar Sliding", level=3),
                rst.Paragraph(
                    f"Critical: {n_planar_sliding} of {n_poles} planes."
                    f" ({p_planar_sliding:.2f} %)"
                ),
                rst.Heading("Planar Sliding (No Limits)", level=3),
                rst.Paragraph(
                    f"Critical: {n_planar_sliding_no_limits} of {n_poles} planes."
                    f" ({p_planar_sliding_no_limits:.2f} %)"
                ),
                rst.Heading("Wedge Sliding", level=3),
                rst.Paragraph(
                    f"Critical in primary zone: {n_wedge_sliding_primary} of {n_intsecs} Intersections"
                    f" ({p_wedge_sliding_primary:.2f} %)"
                ),
                rst.Paragraph(
                    f"Critical in secondary zone: {n_wedge_sliding_secondary} of {n_intsecs} Intersections"
                    f" ({p_wedge_sliding_secondary:.2f} %)"
                ),
                rst.Paragraph(
                    f"Critical in total: {n_wedge_sliding_total}"
                    f" ({p_wedge_sliding_total:.2f} %)"
                ),
                rst.Heading("Flexural Toppling", level=3),
                rst.Paragraph(
                    f"Critical: {n_flexural_toppling} of {n_poles} planes."
                    f" ({p_flexural_toppling:.2f} %)"
                ),
                rst.Heading("Direct Toppling", level=3),
                rst.Heading("Intersections", level=4),
                rst.Paragraph(
                    f"Critical for direct toppling (zone 1 + 2): {n_direct_toppling_1_2} of {n_intsecs} Intersections"
                    f" ({p_direct_toppling_1_2:.2f} %)"
                ),
                rst.Paragraph(
                    f"Critical for oblique toppling (zone 3): {n_direct_toppling_3} of {n_intsecs} Intersections"
                    f" ({p_direct_toppling_3:.2f} %)"
                ),
                rst.Heading("Base Plane", level=4),
                rst.Paragraph(
                    f"Critical in zone 1: {n_direct_toppling_base_1} of {n_poles} planes."
                    f" ({p_direct_toppling_base_1:.2f} %)"
                ),
                rst.Paragraph(
                    f"Critical in zone 2 + 3: {n_direct_toppling_base_23} of {n_poles} planes."
                    f" ({p_direct_toppling_base_23:.2f} %)"
                ),
                rst.Paragraph(
                    f"Critical in total: {n_direct_toppling_base_total} of {n_poles} planes."
                    f" ({p_direct_toppling_base_total:.2f} %)"
                ),
            ]

        doc = rst.Document(
            [
                rst.Heading(projectname) if projectname else projectname,
                rst.Paragraph(f"Author:\n    {author}") if author else author,
                rst.Paragraph(f"Date:\n    {date}") if date else date,
                rst.Paragraph(f"Description:\n    {description}") if description else description,
                rst.Heading("Number of Elements", level=2),
                rst.Paragraph(f"Planes: {n_poles}"),
                rst.Paragraph(f"Intersections: {n_intsecs}"),
                rst.Heading("Set Statistics", level=2),
                set_statistics,
                rst.Heading("Kinematic Analysis", level=2),
                kinematics_report,
            ]
        )
        report = doc.get()
        print(report)
        if save_as:
            with open(save_as, "w") as file:
                file.writelines(report)


def joints_from_csv(path, col_dip_direction=0, col_dip=1, skip=0, delimiter=";"):
    """Load joint orientations (dip direction, dip) from a CSV file.

    The CSV is expected to contain at least two numeric columns representing
    dip direction and dip (in degrees). Optionally, a number of header rows
    can be skipped.

    Args:
        path (str): Path to the CSV file.
        col_dip_direction (int, optional): Zero-based column index for dip
            direction values. Defaults to 0.
        col_dip (int, optional): Zero-based column index for dip values.
            Defaults to 1.
        skip (int, optional): Number of initial rows to skip (e.g. header).
            Defaults to 0.
        delimiter (str, optional): CSV delimiter character. Defaults to ";".

    Returns:
        numpy.ndarray: Array of joint orientations in degrees with shape (n, 2),
        where each row is ``[dip_direction, dip]``.

    Raises:
        FileNotFoundError: If `path` does not exist.
        ValueError: If rows cannot be parsed into floats at the given columns.
    """
    with open(path, newline="") as csvfile:
        reader = csv.reader(csvfile, delimiter=delimiter)
        for _ in range(skip):
            next(reader)
        joints = np.array(
            [[float(line[col_dip_direction]), float(line[col_dip])] for line in reader]
        )
    return joints
