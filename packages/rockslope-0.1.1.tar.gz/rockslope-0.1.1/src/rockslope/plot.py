"""The plot module provides possibilities of graphical representation of
equal angle and equal area projections. In addition to projections, common
elements such as great circles, small circles or linear can be plotted.
Contour plots according to Schmidt or Kamb are also possible.

This is realized via the StereoNet class, which inherits from Matplotlib's
Axes class.

How to use it?

The class is not initialized directly. Instead a Matplotlib plot is created as
usual. The plot module must be imported into the script. Here the projections
are registered and can be accessed via the projection attribute of the plot.
"""

import math
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.patches import Circle
from matplotlib.projections import register_projection
from . import projections
from . import notations
from . import densities as dens
from . import sphericmath as smath


class Stereonet(plt.Axes):
    name = "stereonet"

    default_axes_attributes = {
        "anchor": "C",
        "aspect": "equal",
        "xlim": (-1.0, 1.0),
        "ylim": (-1.0, 1.0),
        "frame_on": False
    }

    def __init__(self, *args, **kwargs):

        self.default_axes_attributes.update(kwargs)
        super().__init__(
            *args,
            **self.default_axes_attributes)

        self.set_axis_off()

        # text in data space
        self.text(
            0.0,
            1.05,
            "N",
            fontsize=rcParams["xtick.labelsize"],
            color=rcParams["axes.labelcolor"],
            horizontalalignment="center"
        )

        self.circle = Circle(
            xy=(0.0, 0.0),
            radius=1,
            fill=False,
            linestyle="-",
            ec=rcParams["axes.edgecolor"],
            fc=rcParams["axes.facecolor"],
            linewidth=rcParams["axes.linewidth"],
            clip_on=False
        )

        self.add_patch(self.circle)

    def format_coord(self, x, y):
        uvec = projections.inverted_project(
            np.array([x, y]),
            projection=self.name
        )
        notation_string = notations.uvec2string(uvec, notation="clar")
        if self.name == "equal_angle":
            projection = "Equal Angle Projection"
        else:
            projection = "Equal Area Projection"
        return f"{notation_string} (Dip Direction / Dip), {projection}"

    def plot_axes(self, uvecs, *args, **kwargs):
        default_kwargs = {
            "marker": "o",
            "linestyle": "None"
        }
        default_kwargs.update(kwargs)
        xy = projections.project(uvecs, projection=self.name).T
        xy_opposite = projections.project(-uvecs, projection=self.name).T
        for x, y in (xy, xy_opposite):
            super().plot(
                x, y,
                *args,
                clip_on=True,
                clip_path=self.circle,
                **default_kwargs
            )
            default_kwargs["color"] = plt.gca().lines[-1].get_color()

    def plot_planars(self, uvecs, kind="poles", *args, **kwargs):
        default_kwargs = {}
        if kind == "poles" or kind == "both":
            default_kwargs["marker"] = "."
            default_kwargs.update(kwargs)
            self.plot_axes(uvecs, *args, **default_kwargs)
            default_kwargs["color"] = plt.gca().lines[-1].get_color()
        if kind == "great_circles" or kind == "both":
            great_circles = smath.trace_great_circle(uvecs, nodes_per_pi=50)
            default_kwargs.update(kwargs)
            default_kwargs["marker"] = None
            for gc in great_circles:
                xy = projections.project(gc, projection=self.name).T
                super().plot(
                    xy[0], xy[1],
                    *args,
                    clip_on=True,
                    clip_path=self.circle,
                    **default_kwargs
                )
                default_kwargs["color"] = plt.gca().lines[-1].get_color()

    def plot_small_circle(
        self,
        cone_axis_uvec,
        semiapical_angle,
        to_left=np.pi,
        to_right=None,
        nodes_per_pi=100,
        *args,
        **kwargs
    ):
        small_circle = smath.trace_small_circle(
            cone_axis_uvec, semiapical_angle, to_left, to_right, nodes_per_pi
        )
        xy = projections.project(small_circle, projection=self.name).T
        xy_opposite = projections.project(-small_circle, projection=self.name).T

        default_kwargs = {}
        default_kwargs.update(kwargs)
        for xy in (xy, xy_opposite):
            super().plot(
                xy[0], xy[1],
                *args,
                clip_on=True,
                clip_path=self.circle,
                **default_kwargs
            )

            default_kwargs["color"] = plt.gca().lines[-1].get_color()

    def plot_great_circle(
        self,
        pole_uvec,
        to_left=np.pi,
        to_right=None,
        nodes_per_pi=100,
        *args,
        **kwargs
    ):
        great_circle = smath.trace_great_circle(
            pole_uvec, to_left, to_right, nodes_per_pi
        )
        xy = projections.project(great_circle, projection=self.name).T

        super().plot(
            xy[0], xy[1],
            *args,
            clip_on=True,
            clip_path=self.circle,
            **kwargs
        )

    def plot_rectangular_selection_window(
        self,
        dir_uvec,
        dec_angle,
        inc_angle,
        to_left=np.pi,
        to_right=None,
        nodes_per_pi=100,
        *args,
        **kwargs
    ):
        small_circle = smath.trace_rectangular_selection_window(
            dir_uvec, dec_angle, inc_angle
        )
        xy = projections.project(small_circle, projection=self.name).T
        xy_opposite = projections.project(-small_circle, projection=self.name).T

        default_kwargs = {}
        default_kwargs.update(kwargs)
        for xy in (xy, xy_opposite):
            super().plot(
                xy[0], xy[1],
                *args,
                clip_on=True,
                clip_path=self.circle,
                **default_kwargs
            )

            default_kwargs["color"] = plt.gca().lines[-1].get_color()

    def plot_daylight_envelope(
        self,
        pole_uvec,
        n_nodes=100,
        *args,
        **kwargs
    ):
        """
        great_circle = smath.trace_great_circle(
            dir_uvec, to_left, to_right, nodes_per_pi
        )[0].T
        daylight_envelope = np.empty(great_circle.shape)
        daylight_envelope[2] = - np.sqrt(1.0 - great_circle[2] * great_circle[2])

        scaling_factor = great_circle[2] / daylight_envelope[2]
        daylight_envelope[0] = np.negative(great_circle[1]) * scaling_factor
        daylight_envelope[1] = np.negative(great_circle[0]) * scaling_factor

        daylight_envelope = daylight_envelope.T
        """

        daylight_envelope = smath.trace_daylight_envelope(pole_uvec, n_nodes)

        xy = projections.project(daylight_envelope, projection=self.name).T

        dists = []
        for i in range(n_nodes-1):
            dist = np.linalg.norm(xy[0][i:i+2] - xy[1][i:i+2])
            dists.append(dist)

        super().plot(
            xy[0], xy[1],
            *args,
            clip_on=True,
            clip_path=self.circle,
            **kwargs
        )
        return dists

    def schmidt_density(
        self,
        uvecs,
        schmidt_fractional=0.01,
        smoothing="none",
        grid_size=100,
        *args,
        **kwargs
    ):
        self._plot_density(
            uvecs,
            method="schmidt",
            smoothing=smoothing,
            schmidt_fractional=schmidt_fractional,
            grid_size=grid_size,
            *args,
            **kwargs
        )

    def kamb_density(
        self,
        uvecs,
        sigma=3,
        smoothing="exponential",
        grid_size=100,
        *args,
        **kwargs
    ):
        self._plot_density(
            uvecs,
            sigma=sigma,
            smoothing=smoothing,
            grid_size=grid_size,
            *args,
            **kwargs
        )

    def _plot_density(
        self,
        uvecs,
        method="kamb",
        smoothing="exponential",
        sigma=3,
        schmidt_fractional=0.01,
        grid_size=100,
        *args,
        **kwargs
    ):
        projection = self.name

        de = dens.DensityEstimator(
            uvecs=uvecs,
            method=method,
            smoothing=smoothing,
            sigma=sigma,
            schmidt_fractional=schmidt_fractional,
            grid_size=grid_size,
            projection=projection
        )

        densities = de.estimate()
        steps = np.linspace(-1.0, 1.0, grid_size)

        contour = super().contourf(steps, steps, densities, *args, **kwargs)
        for c in contour.collections:
            c.set_clip_path(self.circle)

    def stereogrid(
        self,
        b=None,
        which="major",
        axis="both",
        kind="equatorial",
        longitude_cap=80.0,
        major_grid_distance=10,
        minor_grid_distance=2,
        **kwargs
    ):
        grid_params = {
            "alpha": rcParams["grid.alpha"],
            "color": rcParams["grid.color"],
            "linestyle": rcParams["grid.linestyle"],
            "linewidth": rcParams["grid.linewidth"],
            "zorder": 0
        }
        grid_params.update(kwargs)

        if kind == "equatorial":
            print("da")
            if which in ["major", "both"]:
                print("hier")
                self._plot_equatorial_grid(
                    major_grid_distance,
                    longitude_cap,
                    **grid_params
                )
            """
            uvec_1 = notations.tokens2uvec([90.0, 0.0])
            uvec_2 = notations.tokens2uvec([90.0, longitude_cap])

            xy = projections.project(np.array([uvec_1, uvec_2]), projection=self.name).T
            super().plot(
                xy[0], xy[1],
                clip_on=True,
                clip_path=self.circle,
            )
            """

            if which in ["minor", "both"]:
                print("in")
                self._plot_equatorial_grid(
                    minor_grid_distance,
                    longitude_cap,
                    **grid_params
                )
        elif kind == "polar":
            self._plot_polar_grid(major_grid_distance, longitude_cap, **grid_params)

    def _plot_line(self, direction, *args, **kwargs):
        # direction between 0 and 180
        y = math.cos(math.radians(direction))
        x = math.tan(math.radians(direction)) * y

        super().plot(
            [x, -x], [y, -y],
            *args,
            clip_on=True,
            clip_path=self.circle,
            **kwargs
        )

    def _plot_equatorial_grid(self, grid_distance, longitude_cap, **grid_params):
        rad_longitude_cap = math.radians(longitude_cap)
        # longitudes
        for dip_direction in [270.0, 90.0]:
            for dip in range(0, 90, grid_distance):
                uvec = notations.tokens2uvec([dip_direction, dip])
                self.plot_great_circle(
                    uvec,
                    to_left=rad_longitude_cap,
                    **grid_params
                )
        self.plot_great_circle(
            notations.tokens2uvec([90.0, 0.0]),
            to_left=rad_longitude_cap,
            **grid_params
        )
        # latitudes
        for dip_direction in [0.0, 180.0]:
            for dip in range(10, 90, grid_distance):
                if dip >= (90.0 - longitude_cap):
                    dir_uvec = notations.tokens2uvec([dip_direction, 0.0])
                    self.plot_small_circle(
                        dir_uvec,
                        np.radians(dip),
                        **grid_params
                    )
        self.plot_small_circle(
            notations.tokens2uvec([0.0, 0.0]),
            np.radians(90),
            **grid_params
        )

    def _plot_polar_grid(self, grid_distance, longitude_cap, **grid_params):

        for dip_direction in range(0, 180, grid_distance):
            self._plot_line(dip_direction, **grid_params)

        for dip in range(0, 90, grid_distance):
            self.plot_small_circle(
                np.array([0.0, 0.0, -1.0]),
                np.radians(dip),
                **grid_params
            )

    def can_pan(self):
        return False

    def contourf(self, x, y, z, *args, **kwargs):
        contourf = super().contourf(x, y, z, *args, **kwargs)
        for c in contourf.collections:
            c.set_clip_path(self.circle)

    def contour(self, x, y, z, *args, **kwargs):
        contour = super().contour(x, y, z, *args, **kwargs)
        for c in contour.collections:
            c.set_clip_path(self.circle)


class EqualAngle(Stereonet):
    name = "equal_angle"


class EqualArea(Stereonet):
    name = "equal_area"


# functions below are executed when the plot module is imported
# to a script. They are outside the if __name__ == '__main__'
# branch on purpose.

register_projection(EqualAngle)
register_projection(EqualArea)

if __name__ == '__main__':
    import numpy as np
    from . import sphericmath as smath
    from . import sphericstats as stats

    n_nodes = 100

    planar = smath.spheric2uvec(np.array([np.deg2rad(20), np.deg2rad(50)]))
    ax = plt.subplot(111, projection="equal_area")

    ax.stereogrid(which="major", kind="polar", longitude_cap=50, major_grid_distance=10, linewidth=0.2)
    #ax.stereogrid(which="minor", kind="polar", linewidth=0.1)

    fisher_uvecs = stats.generate_fisher_dist(200, 10, 5)

    ax.plot_planars(fisher_uvecs, kind="both", linewidth=0.2, color="#123456", marker="o", markersize=1)
    """
    ax._plot_density(
        fisher_uvecs,
        method="kamb",
        smoothing="exponential",
        sigma=1.5,
        schmidt_fractional=0.01,
        grid_size=100,
        alpha=0.6,
        #levels=[0,0.1,0.2,0.3,0.4,2,4,6,8,10,12,14,16]
    )
    """
    plt.show()
    print(rcParams)

    '''
    import numpy as np
    from . import sphericmath as smath
    from . import sphericstats as sstats



    np.random.seed(10)

    axes = [
        smath.vec2uvec([-1, -1, 0]),
        smath.vec2uvec([-2, -1, -1]),
        smath.vec2uvec([1, -2, -1])
    ]

    samples = [152, 150, 140]
    kappas = [20, 10, 25]
    angles = [2, 1.0, 1]

    fisher_uvecs = [
        smath.spheric2uvec(decinc)
        for decinc in [
            sstats.generate_fisher_dist(samples, kappa)
            for samples, kappa in zip(samples, kappas)
        ]
    ]

    rotated_uvecs = [
        smath.rotate(uvecs, axis, angle)
        for uvecs, axis, angle
        in zip(fisher_uvecs, axes, angles)
    ]

    magnitudes = [
        smath.get_vec_magnitude(smath.get_sum_vec(uvecs))
        for uvecs in rotated_uvecs
    ]

    fisher_confidence_angles = [
        sstats.get_fisher_confidence_angle(mag, uvecs.shape[0], 0.95)
        for mag, uvecs in zip(magnitudes, rotated_uvecs)
    ]

    mean_axes = [
        sstats.get_mean_axis(uvecs) for uvecs in rotated_uvecs
    ]

    ax = plt.subplot(111, projection="equal_angle")

    ax.kamb_density(
        uvecs=np.concatenate(rotated_uvecs, axis=0),
        sigma=3,
        cmap=plt.get_cmap("bone_r"),
        levels=[0,2,4,6,8,10,12,14,16,18,20,22,24]
    )

    for uvecs in rotated_uvecs:
        ax.plot_planars(uvecs, "poles", color="darkkhaki")

    uvec = smath.vec2uvec([0, 2, -0.5])
    ax.plot_small_circle(
        uvec,
        np.deg2rad(30),
        to_left=np.deg2rad(40),
        to_right=np.deg2rad(40)
    )
    ax.plot_great_circle(
        uvec,
        to_left=np.deg2rad(30),
    )


    #for conf, mean in zip(fisher_confidence_angles, mean_axes):
    #    ax.plot_small_circle(mean, conf)


    #print(plt.gca().__dict__["collections"][-1].get_facecolors())
    plt.show()
    """

    n = 1400
    np.random.seed(10)
    trend = [0, 45, 90, 220, 50, 16]
    plunge = [90, 45, 45, 45, 60, 66]
    spherics = np.deg2rad(np.array([trend, plunge]))

    uvecs = smath.spheric2uvec(spherics.T)
    ax = plt.subplot(111, projection="equal_area")

    dens = ax.kamb_density(
        uvecs=uvecs,
        method="kamb",
        smoothing="exponential",
        sigma=3,
        grid_size=100,
        levels=[0,2,4,6,8,10],
        cmap=plt.get_cmap("bone_r")
    )

    ax.plot_planars(uvecs, "poles", markersize=8)

    #magnitudes = smath.get_vec_magnitude(smath.get_sum_vec(uvecs))

    #conf = sstats.get_fisher_confidence_angle(magnitudes, uvecs.shape[0], 0.95)
    #mean_axis = sstats.get_mean_axis(uvecs)

    #print("confidence", np.rad2deg(conf))
    #print("mean", np.rad2deg(smath.uvec2spheric(mean_axis)))
    #ax.plot_small_circle(mean_axis, conf)

    plt.show()
    """
    '''