"""The kinematics module provides the RockSlopeKinematics class, which is able
to check different failure modes.
"""

import math
import numpy as np
from . import sphericmath as smath

SAFETY_MARGIN = 1e-6  # for compensating rounding errors


class RockSlopeKinematics:

    """A class for dealing with failure of rock slopes based on their joints.

    It's possible to investigate 4 different failure modes:

    - Planar sliding (method check_planar_sliding())
    - Wedge sliding (method check_wedge_sliding())
    - Flexural toppling (method check_flexural_toppling())
    - Direct toppling (method check_direct_toppling())

    The class is taking following attributes:

    Attributes:
        friction (float): Angle of friction for joints, given in radians.
        pole_uvecs (ndarray):
            Poles of joints given as unit vectors of shape (n, 3)
        slope (ndarray):
            Slope given as pole unit vector of shape (n, 3) or (3,)
    """

    def __init__(self, pole_uvecs, slope, friction):
        self.pole_uvecs = np.array(pole_uvecs)
        self.slope = np.atleast_2d(slope)
        self.friction = friction
        self.intsecs = np.array([])

        self._tan_friction = math.tan(friction)
        self._z_slope = self.slope[:, 2]
        self._z_poles = self.pole_uvecs[:, 2]
        self._slope_dip = np.arccos(-self.slope[:, 2])

        # _z_slope is direction cosine of slope's pole
        # to get slope dip, use arcsin
        self._tan_slope_dip_sliding = np.tan(self._slope_dip)
        self._tan_slope_dip_wedge = np.tan(self._slope_dip)

        self._planar_sliding_lateral = None
        self._planar_sliding_friction = None
        self._planar_sliding_daylighting = None

    def check_planar_sliding(self, lateral_limit=None):
        """Checks for planar sliding by checking 3 conditions:

        - lateral limit (optional)
        - friction
        - daylighting

        Args:
            lateral_limit (float, optional):
                Elements outside of the lateral limits can't fail.
        """

        if lateral_limit:
            self._cos_lateral_limit = math.cos(lateral_limit)
        else:
            self._cos_lateral_limit = math.cos(math.pi/2)
        cos_lateral_dists = smath.get_dec_cos_distance(
            self.slope[0], self.pole_uvecs
        )

        tan_apparent_slope_dip = np.nan_to_num(
            self._tan_slope_dip_sliding * cos_lateral_dists
        )
        z_planes = np.sqrt(1.0 - self._z_poles * self._z_poles)
        tan_planes_dip = np.nan_to_num(
            z_planes / np.sqrt(1.0 - z_planes * z_planes)
        )

        self._planar_sliding_lateral = (
            self._cos_lateral_limit <= cos_lateral_dists + SAFETY_MARGIN
        )
        self._planar_sliding_friction = (
            self._tan_friction - SAFETY_MARGIN <= tan_planes_dip
        )
        self._planar_sliding_daylighting = (
            tan_planes_dip <= tan_apparent_slope_dip + SAFETY_MARGIN
        )
        print(np.arctan(tan_planes_dip) - np.arctan(tan_apparent_slope_dip))

        self.planar_sliding = np.all(
            [
                self._planar_sliding_friction,
                self._planar_sliding_daylighting,
                self._planar_sliding_lateral
            ],
            axis=0
        )

    def check_wedge_sliding(self):
        """Checks for wedge sliding by checking 2 conditions:
        - friction
        - daylighting

        Each for intersections and planars.
        """

        if self.intsecs.size == 0:  # check if intsecs are calculated already
            self.intsecs, self.planar_ids_1, self.planar_ids_2 = (
                smath.intersect(self.pole_uvecs)
            )

        # check primary zone failure
        # aka sliding intersections

        cos_lateral_dists = smath.get_dec_cos_distance(
            self.slope[0], self.intsecs
        )
        tan_apparent_slope_dip = -self._tan_slope_dip_wedge * cos_lateral_dists

        z_intsecs = self.intsecs[:, 2]
        tan_intsecs_dip = -z_intsecs / np.sqrt(1.0 - z_intsecs * z_intsecs)
        self._primary_wedge_sliding_daylighting = (
            tan_intsecs_dip - SAFETY_MARGIN < tan_apparent_slope_dip
        )

        self._primary_wedge_sliding_friction = (
            self._tan_friction - SAFETY_MARGIN < tan_intsecs_dip
        )

        self.wedge_sliding_primary = np.all(
            [
                self._primary_wedge_sliding_daylighting,
                self._primary_wedge_sliding_friction,
            ],
            axis=0
        )

        # check secondary zone failure
        # sliding planes

        planar_1_condition = np.all(
            [
                self._planar_sliding_friction,
                self._planar_sliding_daylighting
            ],
            axis=0
        )[self.planar_ids_1]

        planar_2_condition = np.all(
            [
                self._planar_sliding_friction,
                self._planar_sliding_daylighting
            ],
            axis=0
        )[self.planar_ids_2]

        planar_condition = np.any(
            [
                planar_1_condition,
                planar_2_condition
            ],
            axis=0
        )

        tan_apparent_friction_dip = -np.tan(self.friction) * cos_lateral_dists
        friction_condition = (
            tan_intsecs_dip + SAFETY_MARGIN > tan_apparent_friction_dip
        )

        self.wedge_sliding_secondary = np.all(
            [
                planar_condition,
                friction_condition,
                self._primary_wedge_sliding_daylighting,
                np.invert(self.wedge_sliding_primary)
            ],
            axis=0
        )

        self.two_planes_condition = np.all(
            [
                planar_1_condition,
                planar_2_condition,
                self.wedge_sliding_primary
            ],
            axis=0
        )

    def check_flexural_toppling(self, lateral_limit=None):
        """Checks for flexural toppling by checking 2 conditions:
        - lateral condition
        - slip limit condition

        Args:
            lateral_limit (float, optional):
                Elements outside of the lateral limits can't fail.
        """
        if lateral_limit:
            self._cos_lateral_limit = math.cos(lateral_limit)
        else:
            self._cos_lateral_limit = math.cos(math.pi/2)
        cos_lateral_dists_face = smath.get_dec_cos_distance(
            self.slope[0], self.pole_uvecs
        )
        cos_lateral_dists_back = smath.get_dec_cos_distance(
            np.negative(self.slope[0]), self.pole_uvecs
        )
        # Negative means opposite direction.
        # Switching hemispheres isn't a problem here.

        self._slip_limit = self._slope_dip - self.friction
        tan_apparent_dip = -np.tan(self._slip_limit * cos_lateral_dists_face)

        z_poles = self.pole_uvecs[:, 2]
        tan_poles_dip = -z_poles / np.sqrt(1.0 - z_poles * z_poles)

        self._slip_limit_condition = (
            tan_apparent_dip + SAFETY_MARGIN >= tan_poles_dip
        )
        self._flexural_toppling_lateral = (
            self._cos_lateral_limit <= cos_lateral_dists_back + SAFETY_MARGIN
        )
        self.flexural_toppling = np.all(
            [
                self._flexural_toppling_lateral,
                self._slip_limit_condition
            ],
            axis=0
        )

    def check_direct_toppling(self, lateral_limit=None):
        """Checks for direct toppling by checking following conditions:
        - lateral limit / oblique lateral limit
        - friction limit

        Both for intersections and possible release planes.

        Args:
            lateral_limit (float, optional):
                Elements outside of the lateral limits can't fail.
        """
        if lateral_limit:
            self._cos_lateral_limit = math.cos(lateral_limit)
        else:
            self._cos_lateral_limit = math.cos(math.pi/2.0)

        # INTERSECTION CONDITIONS

        if self.intsecs.size == 0:  # check if intsecs are calculated already
            self.intsecs, self.planar_ids_1, self.planar_ids_2 = (
                smath.intersect(self.pole_uvecs)
            )

        z_intsecs = self.intsecs[:, 2]
        tan_intsecs_dip = -z_intsecs / np.sqrt(1.0 - z_intsecs * z_intsecs)

        cos_lateral_dists = smath.get_dec_cos_distance(
            np.negative(self.slope[0]), self.intsecs
        )

        self._direct_toppling_lateral_limit_condition = (
            cos_lateral_dists <= math.cos(math.pi - lateral_limit)
        )

        self._direct_toppling_friction_limit = (
            tan_intsecs_dip + SAFETY_MARGIN > math.tan(math.pi/2 - self.friction)
        )

        self._direct_toppling_oblique_lateral_limit_condition = (
            cos_lateral_dists <= math.cos(math.pi/2) + SAFETY_MARGIN
        )

        tan_zone_1_limit = math.tan(math.pi/2 - self._slope_dip)

        self._zone_1_limit_condition = (
            tan_intsecs_dip + SAFETY_MARGIN > tan_zone_1_limit
        )

        self.direct_toppling_zone_1 = np.all(
            [
                self._zone_1_limit_condition,
                self._direct_toppling_lateral_limit_condition,
                #np.invert(self._direct_toppling_friction_limit)
            ],
            axis=0
        )

        self.direct_toppling_zone_2 = np.all(
            [
                self._direct_toppling_lateral_limit_condition,
                self._direct_toppling_friction_limit
            ],
            axis=0
        )

        self.direct_toppling_zone_3 = np.all(
            [
                self._direct_toppling_oblique_lateral_limit_condition,
                self._direct_toppling_friction_limit,
                np.invert(self.direct_toppling_zone_2)
            ],
            axis=0
        )

        # PLANAR CONDITIONS

        cos_lateral_dists = np.nan_to_num(
            smath.get_dec_cos_distance(self.slope[0], self.pole_uvecs)
        )

        self._direct_toppling_base_no_lateral = (
            math.cos(math.pi/2) <= cos_lateral_dists + SAFETY_MARGIN  # means not behind slope
        )

        z_planes = np.sqrt(1.0 - self._z_poles * self._z_poles)
        tan_planes_dip = np.nan_to_num(z_planes / np.sqrt(1.0 - z_planes * z_planes))
        self._inside_friction_cone = (
            self._tan_friction + SAFETY_MARGIN > tan_planes_dip
        )

        self.direct_toppling_base_23 = np.all(
            [
                self._direct_toppling_base_no_lateral,
                self._inside_friction_cone
            ],
            axis=0
        )

        self._direct_toppling_base_lateral = (
            self._cos_lateral_limit <= cos_lateral_dists + SAFETY_MARGIN  # means not behind slope
        )

        self._zone_1_limit_base_condition = (
            tan_planes_dip - SAFETY_MARGIN < self._tan_slope_dip_sliding
        )

        self._outside_friction_cone = (
            self._tan_friction + SAFETY_MARGIN < tan_planes_dip
        )

        self.direct_toppling_base_1 = np.all(
            [
                self._direct_toppling_base_lateral,
                self._zone_1_limit_base_condition,
                self._outside_friction_cone
            ],
            axis=0
        )
