"""Command-line entry point for the :mod:`rockslope` package.

This module delegates to :func:`rockslope.rockslope.main` so that the
library can be started via::

    python -m rockslope
"""

from . import rockslope


def main() -> None:
    """Run the RockSlope command-line entry point."""
    rockslope.main()


if __name__ == "__main__":
    main()
