"""The sphericstats module provides basic functions for the statistical
evaluation of microstructure data.

In addition, it is possible to generate random values that correspond to a
radially symmetrical normal distribution (Fisher distribution).
"""

import math
import numpy as np
from . import sphericmath as smath


def get_mean_uvec(vecs):
    """Calculates a mean direction for given vectors. Input doesn't have to be
    unit vectors, return value is.

    Be aware, that it can give wrong results if you are actually dealing with
    axial data. Use get_mean_axis then.

    Args:
        vecs (ndarray): n unit vectors of shape (n, 3) or (3,).

    Returns:
        TYPE: Mean vector of shape (3,) as a unit vector.
    """
    sum_vec = vecs.sum(axis=0)
    return sum_vec / math.sqrt(np.dot(sum_vec, sum_vec))


def get_mean_axis(uvecs):
    """Calculates the mean axis for arbitrary axial data. When dealing with
    axial data, this is most likely what you want to have instead of the
    mean direction.

    It relies on the algorithm given in ADAM (1989), "Methoden und Algorithmen
    zur Verwaltung und Analyse axialer 3-D-Richtungsdaten und ihrer
    Belegungsdichten", p. 85.

    Args:
        uvecs (ndarray): n unit vectors of shape (n, 3) or (3,).

    Returns:
        ndarray: Mean axis of shape (3,) as a unit vector.
    """
    mean_axis = np.zeros(3)

    # first division is (0, 0, 0) / 0, so ignore runtime warning
    # this is fine
    with np.errstate(divide='ignore', invalid="ignore"):
        for uvec in uvecs:
            temp_mean_axis = mean_axis / math.sqrt(mean_axis.dot(mean_axis))
            if np.dot(temp_mean_axis, uvec) < 0.0:
                mean_axis = mean_axis + np.negative(uvec)
            else:
                mean_axis = mean_axis + uvec

    if mean_axis[2] > 0.0:
        return smath.vec2uvec(np.negative(mean_axis))
    else:
        return smath.vec2uvec(mean_axis)


def estimate_fisher_kappa(sum_vec_magnitude, n_samples, method="fisher"):
    """Can estimate Fisher's kappa value by using different methods.
    For reference see:
    Fisher, N. I.: Statistical analysis of spherical data, 1993
    Davis, J. C.: Statistics and data analysis in geology, 2002

    Args:
        sum_vec_magnitude (float): Magnitude of sum vector
        n_samples (float): Number of data samples.
        Both int and float is accepted as input.
        method (str, optional): Choose desired estimation method.
            "fisher" and "davis" is available.

    Returns:
        float: Fisher's kappa value
    """
    if method == "fisher":
        if n_samples < 16:
            k_mle = n_samples / (n_samples - sum_vec_magnitude)
            return (1.0 - (1.0 / n_samples))**2 * k_mle
        else:
            return (n_samples - 1.0) / (n_samples - sum_vec_magnitude)

    elif method == "davis":
        return (n_samples - 2) / (n_samples - sum_vec_magnitude)


def _get_fisher_confidence_angle(
    sum_vec_magnitude, n_samples, confidence=0.95
):
    """See get_confidence_angle."""
    r, n, p = sum_vec_magnitude, n_samples, (1.0 - confidence)
    confidence_angle = math.acos(1 - (n-r) / r * ((1/p)**(1/(n-1)) - 1))
    return confidence_angle


def _get_priest_confidence_angle(
    sum_vec_magnitude, n_samples, confidence=0.95
):
    """See get_confidence angle."""
    r, n, p = sum_vec_magnitude, n_samples, confidence
    k = estimate_fisher_kappa(r, n)
    confidence_angle = math.acos(1.0 + math.log(1.0 - p) / (r * k))
    return confidence_angle


def get_confidence_angle(
    sum_vec_magnitude, n_samples, confidence=0.95, method="priest"
):
    """Calculates the angle of confidence to determine the area of true
    mean direction. A Fisher-distribution is assumed.

    Currently two methods are supported.
    For Fisher see:
    Fisher, N. I.: Statistical analysis of spherical data, 1993
    For Priest see:
    Priest, S. D.: Hemispherical projection methods in rock mechanics, 1985

    Args:
        sum_vec_magnitude (float): Magnitude of sum of vector of
            directional data.
        n_samples (int): Number of samples.
        confidence (float, optional): Confidence level, can have values
            between 0.0 and 1.0. Standard is 0.95.
        method (str, optional): Method, which is used for calculations.
            Currently "fisher" and "priest" is supported.

    Returns:
        float: Angle of confidence in radians.
    """
    if method == "priest":
        return _get_priest_confidence_angle(
            sum_vec_magnitude, n_samples, confidence
        )
    elif method == "fisher":
        return _get_fisher_confidence_angle(
            sum_vec_magnitude, n_samples, confidence
        )
    else:
        raise ValueError("Invalid method. Use 'priest' or 'fisher'.")


def get_variability_angle(sum_vec_magnitude, n_samples, confidence=0.95):
    """Calculates the angle of variability to determine the distribution
    of a set of directional data. A Fisher-distribution is assumed.

    It's calculated with a method by Priest. For reference see:
    Priest, S. D.: Hemispherical projection methods in rock mechanics, 1985

    Args:
        sum_vec_magnitude (float): Magnitude of sum of vector of
            directional data.
        n_samples (int): Number of samples.
        confidence (float, optional): Confidence level, can have values
            between 0.0 and 1.0. Standard is 0.95.

    Returns:
        float: Angle of variability in radians.
    """
    r, n, p = sum_vec_magnitude, n_samples, confidence
    k = estimate_fisher_kappa(r, n)
    variability_angle = math.acos(1.0 + math.log(1.0 - p) / k)
    return variability_angle


def generate_fisher_dist(n_samples, kappa, seed=None, lower_hemisphere=True):
    """This function generates a fisher distribution with n samples.
    Be aware that the function doesn't provide rotational abilities,
    it's generating points around a dip angle of 90 degrees.

    For formula see:
    Fisher, N. I.: Statistical analysis of spherical data, 1993

    Formula is changed to return dip instead of colatitude.

    Args:
        n_samples (int): Number of samples drawn from fisher pdf
        kappa (float): Concentration factor, dispersion factor,
            fisher constant
        seed (int, optional): Seed for Numpy's RandomState
        lower_hemisphere (bool, optional): All vectors pointing downwards

    Returns:
        ndarray: Unit vector of shape (3, n)
    """
    np.random.seed(seed)

    _lambda = np.exp(-2.0 * kappa)
    term = np.random.rand(n_samples) * (1.0 - _lambda) + _lambda

    # np.pi/2 to return dip instead of colatiude
    inc = np.pi/2.0 - (2.0 * np.arcsin(np.sqrt(-np.log(term) / (2.0 * kappa))))
    dec = 2.0 * np.pi * np.random.rand(n_samples)

    fisher_uvecs = smath.spheric2uvec(np.array([dec, inc]).T)
    return fisher_uvecs


if __name__ == '__main__':
    from . import notations
    from . import plot  # for registration of projections
    import matplotlib.pyplot as plt

    uvecs = generate_fisher_dist(
        n_samples=40,
        kappa=20,
        seed=10
    )

    mean_axis = get_mean_axis(uvecs)

    n_samples = len(uvecs)

    sum_vec_magnitude = smath.get_vec_magnitude(smath.get_sum_vec(uvecs))

    confidence_angle = get_confidence_angle(sum_vec_magnitude, n_samples)
    variability_angle = get_variability_angle(sum_vec_magnitude, n_samples)
    kappa = estimate_fisher_kappa(sum_vec_magnitude, n_samples)

    print("Mean Axis:\t", notations.uvec2string(mean_axis))
    print("Confidence:\t", math.degrees(confidence_angle))
    print("Variability:\t", math.degrees(variability_angle))
    print("Kappa:\t", kappa)

    ax = plt.subplot(111, projection="equal_angle")
    ax.plot_planars(uvecs)
    ax.plot_axes(mean_axis)
    ax.plot_small_circle(mean_axis, confidence_angle)
    ax.plot_small_circle(mean_axis, variability_angle)
    plt.show()
