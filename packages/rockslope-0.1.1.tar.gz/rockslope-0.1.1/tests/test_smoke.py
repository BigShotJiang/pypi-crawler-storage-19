import numpy as np
import rockslope


def test_import_and_basic_usage():
    joints = np.array([[123.0, 23.0], [23.0, 33.0], [124.0, 30.0]])
    rm = rockslope.RockMass(joints, friction=30.0)
    assert rm.joints.shape == joints.shape
    assert isinstance(rm.friction, (int, float))
