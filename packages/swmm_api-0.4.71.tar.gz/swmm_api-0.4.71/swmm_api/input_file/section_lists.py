from .section_labels import *

GEO_SECTIONS = [COORDINATES, VERTICES, POLYGONS]
GUI_SECTIONS = [MAP, SYMBOLS, LABELS, BACKDROP, PROFILES]

LINK_SECTIONS = [CONDUITS, ORIFICES, OUTLETS, PUMPS, WEIRS]  # only link objects
LINK_SECTIONS_ADD = [XSECTIONS, LOSSES, VERTICES]  # where the link-label is the only identifier.
# only conduits: as part-identifier: INLET_USAGE

NODE_SECTIONS = [JUNCTIONS, OUTFALLS, DIVIDERS, STORAGE]  # only node objects
NODE_SECTIONS_ADD = [COORDINATES, RDII]  # where the node-label is the only identifier.
# as part-identifier: INFLOWS(constituent), DWF(constituent), GROUNDWATER(AQUIFERS, SUBCATCHMENT), INLET_USAGE(CONDUIT, INLETS)
NODE_SECTIONS_PLUS = [INFLOWS, DWF, GROUNDWATER, INLET_USAGE]
# as parameter: SUBCATCHMENTS

SUBCATCHMENT_SECTIONS = [SUBCATCHMENTS, SUBAREAS, INFILTRATION, POLYGONS, LOADINGS, COVERAGES]  # where the subcatchment-label is the only identifier.
# as parameter:
# as part-identifier: LID_USAGE(LID_CONTROLS), GWF(kind), GROUNDWATER(AQUIFERS, NODE)
SUBCATCHMENT_SECTIONS_PLUS = [LID_USAGE, GWF, GROUNDWATER]

POLLUTANT_SECTIONS = [TREATMENT, WASHOFF, BUILDUP, POLLUTANTS, LOADINGS, COVERAGES, LANDUSES]  # where pollutants are defined and used
# as parameter: LID_CONTROLS

GENERIC_SECTIONS = [TITLE, OPTIONS, REPORT, FILES, EVAPORATION, TEMPERATURE, ADJUSTMENTS, MAP, BACKDROP]

LID_SECTIONS = [LID_CONTROLS, LID_USAGE]

# %%
SECTIONS_ORDER_MP = ([
                         TITLE,
                         OPTIONS,
                         REPORT,
                         EVAPORATION,
                         TEMPERATURE

                     ] + NODE_SECTIONS +
                     [
                         DWF,
                         INFLOWS

                     ] + LINK_SECTIONS +
                     [

                         LOSSES,
                         XSECTIONS,
                         STREETS,
                         INLETS,
                         INLET_USAGE,
                         TRANSECTS,

                         CURVES,
                         TIMESERIES,
                         RAINGAGES,
                         PATTERNS,

                         SUBCATCHMENTS,
                         SUBAREAS,
                         INFILTRATION,

                         POLLUTANTS,
                         LOADINGS,
                     ])

SECTIONS_ORDER_DEFAULT = [TITLE,
                          OPTIONS,
                          FILES,
                          EVAPORATION,
                          TEMPERATURE,
                          RAINGAGES,
                          SUBCATCHMENTS,
                          SUBAREAS,
                          INFILTRATION,
                          LID_CONTROLS,
                          LID_USAGE,
                          AQUIFERS,
                          GROUNDWATER,
                          GWF,
                          SNOWPACKS,
                          JUNCTIONS,
                          OUTFALLS,
                          DIVIDERS,
                          STORAGE,
                          CONDUITS,
                          PUMPS,
                          ORIFICES,
                          WEIRS,
                          OUTLETS,
                          XSECTIONS,
                          STREETS,
                          INLETS,
                          INLET_USAGE,
                          TRANSECTS,
                          LOSSES,
                          CONTROLS,
                          POLLUTANTS,
                          LANDUSES,
                          COVERAGES,
                          LOADINGS,
                          BUILDUP,
                          WASHOFF,
                          TREATMENT,
                          INFLOWS,
                          DWF,
                          HYDROGRAPHS,
                          RDII,
                          CURVES,
                          TIMESERIES,
                          PATTERNS,
                          REPORT,
                          ADJUSTMENTS,
                          TAGS,
                          MAP,
                          COORDINATES,
                          VERTICES,
                          POLYGONS,
                          SYMBOLS,
                          LABELS,
                          BACKDROP,
                          PROFILES]
