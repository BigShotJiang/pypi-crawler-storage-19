"""EmDash Core - FastAPI server for code intelligence."""

__version__ = "0.1.0"
