"""Spec planning tools for feature specifications."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .base import BaseTool, ToolResult, ToolCategory
from ..spec_schema import Spec
from ...utils.logger import log


@dataclass
class SpecState:
    """Singleton state for spec management."""

    current_spec: Optional[Spec] = None
    save_path: Optional[Path] = None
    history: list[Spec] = field(default_factory=list)

    _instance: Optional["SpecState"] = None

    @classmethod
    def get_instance(cls) -> "SpecState":
        """Get the singleton instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton instance."""
        cls._instance = None

    def configure(self, save_path: Optional[Path] = None) -> None:
        """Configure the spec state.

        Args:
            save_path: Path to save specs to
        """
        self.save_path = save_path


class SubmitSpecTool(BaseTool):
    """Tool for submitting a new specification."""

    name = "submit_spec"
    description = """Submit a feature specification for review.
Creates a structured spec document with requirements and acceptance criteria."""
    category = ToolCategory.PLANNING

    def __init__(self, connection=None):
        """Initialize without requiring connection."""
        self.connection = connection

    def execute(
        self,
        title: str,
        summary: str,
        requirements: list[str],
        acceptance_criteria: list[str],
        technical_notes: Optional[list[str]] = None,
        dependencies: Optional[list[str]] = None,
        open_questions: Optional[list[str]] = None,
    ) -> ToolResult:
        """Submit a specification.

        Args:
            title: Spec title
            summary: Brief summary
            requirements: List of requirements
            acceptance_criteria: Acceptance criteria
            technical_notes: Optional technical notes
            dependencies: Optional dependencies
            open_questions: Optional open questions

        Returns:
            ToolResult with spec info
        """
        try:
            spec = Spec(
                title=title,
                summary=summary,
                requirements=requirements,
                acceptance_criteria=acceptance_criteria,
                technical_notes=technical_notes or [],
                dependencies=dependencies or [],
                open_questions=open_questions or [],
            )

            # Validate
            errors = spec.validate()
            if errors:
                return ToolResult.error_result(
                    f"Spec validation failed: {', '.join(errors)}",
                    suggestions=["Ensure all required fields are provided"],
                )

            # Store in state
            state = SpecState.get_instance()
            if state.current_spec:
                state.history.append(state.current_spec)
            state.current_spec = spec

            # Save to file if configured
            if state.save_path:
                try:
                    state.save_path.write_text(spec.to_markdown())
                    log.info(f"Saved spec to {state.save_path}")
                except Exception as e:
                    log.warning(f"Failed to save spec: {e}")

            return ToolResult.success_result(
                data={
                    "title": title,
                    "requirements_count": len(requirements),
                    "acceptance_criteria_count": len(acceptance_criteria),
                    "markdown": spec.to_markdown(),
                },
            )

        except Exception as e:
            log.exception("Submit spec failed")
            return ToolResult.error_result(f"Failed to submit spec: {str(e)}")

    def get_schema(self) -> dict:
        """Get OpenAI function schema."""
        return self._make_schema(
            properties={
                "title": {
                    "type": "string",
                    "description": "Spec title",
                },
                "summary": {
                    "type": "string",
                    "description": "Brief summary of the feature",
                },
                "requirements": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of requirements",
                },
                "acceptance_criteria": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Acceptance criteria for completion",
                },
                "technical_notes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Technical implementation notes",
                },
                "dependencies": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Dependencies on other features/specs",
                },
                "open_questions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Open questions to resolve",
                },
            },
            required=["title", "summary", "requirements", "acceptance_criteria"],
        )


class GetSpecTool(BaseTool):
    """Tool for getting the current specification."""

    name = "get_spec"
    description = """Get the current feature specification.
Returns the spec in markdown format."""
    category = ToolCategory.PLANNING

    def __init__(self, connection=None):
        """Initialize without requiring connection."""
        self.connection = connection

    def execute(self) -> ToolResult:
        """Get the current spec.

        Returns:
            ToolResult with spec content
        """
        state = SpecState.get_instance()

        if not state.current_spec:
            return ToolResult.error_result(
                "No spec has been submitted yet",
                suggestions=["Use submit_spec to create a specification"],
            )

        spec = state.current_spec

        return ToolResult.success_result(
            data={
                "title": spec.title,
                "summary": spec.summary,
                "requirements": spec.requirements,
                "acceptance_criteria": spec.acceptance_criteria,
                "technical_notes": spec.technical_notes,
                "dependencies": spec.dependencies,
                "open_questions": spec.open_questions,
                "markdown": spec.to_markdown(),
                "is_complete": spec.is_complete(),
            },
        )

    def get_schema(self) -> dict:
        """Get OpenAI function schema."""
        return self._make_schema(properties={}, required=[])


class UpdateSpecTool(BaseTool):
    """Tool for updating the current specification."""

    name = "update_spec"
    description = """Update the current feature specification.
Add or modify requirements, criteria, or other fields."""
    category = ToolCategory.PLANNING

    def __init__(self, connection=None):
        """Initialize without requiring connection."""
        self.connection = connection

    def execute(
        self,
        add_requirements: Optional[list[str]] = None,
        add_acceptance_criteria: Optional[list[str]] = None,
        add_technical_notes: Optional[list[str]] = None,
        add_dependencies: Optional[list[str]] = None,
        add_open_questions: Optional[list[str]] = None,
        resolve_questions: Optional[list[str]] = None,
        update_summary: Optional[str] = None,
    ) -> ToolResult:
        """Update the current spec.

        Args:
            add_requirements: Requirements to add
            add_acceptance_criteria: Criteria to add
            add_technical_notes: Notes to add
            add_dependencies: Dependencies to add
            add_open_questions: Questions to add
            resolve_questions: Questions to mark as resolved
            update_summary: New summary text

        Returns:
            ToolResult with updated spec
        """
        state = SpecState.get_instance()

        if not state.current_spec:
            return ToolResult.error_result(
                "No spec to update",
                suggestions=["Use submit_spec first"],
            )

        spec = state.current_spec

        # Add new items
        if add_requirements:
            spec.requirements.extend(add_requirements)
        if add_acceptance_criteria:
            spec.acceptance_criteria.extend(add_acceptance_criteria)
        if add_technical_notes:
            spec.technical_notes.extend(add_technical_notes)
        if add_dependencies:
            spec.dependencies.extend(add_dependencies)
        if add_open_questions:
            spec.open_questions.extend(add_open_questions)

        # Resolve questions
        if resolve_questions:
            spec.open_questions = [
                q for q in spec.open_questions
                if q not in resolve_questions
            ]

        # Update summary
        if update_summary:
            spec.summary = update_summary

        # Save if configured
        if state.save_path:
            try:
                state.save_path.write_text(spec.to_markdown())
            except Exception as e:
                log.warning(f"Failed to save spec: {e}")

        return ToolResult.success_result(
            data={
                "title": spec.title,
                "requirements_count": len(spec.requirements),
                "acceptance_criteria_count": len(spec.acceptance_criteria),
                "open_questions_count": len(spec.open_questions),
                "is_complete": spec.is_complete(),
                "markdown": spec.to_markdown(),
            },
        )

    def get_schema(self) -> dict:
        """Get OpenAI function schema."""
        return self._make_schema(
            properties={
                "add_requirements": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Requirements to add",
                },
                "add_acceptance_criteria": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Acceptance criteria to add",
                },
                "add_technical_notes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Technical notes to add",
                },
                "add_dependencies": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Dependencies to add",
                },
                "add_open_questions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Open questions to add",
                },
                "resolve_questions": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Questions to mark as resolved",
                },
                "update_summary": {
                    "type": "string",
                    "description": "New summary text",
                },
            },
            required=[],
        )
