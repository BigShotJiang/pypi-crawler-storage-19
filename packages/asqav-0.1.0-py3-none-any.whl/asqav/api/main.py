"""FastAPI application for Asqav Cloud API."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan handler."""
    # Startup
    yield
    # Shutdown


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    application = FastAPI(
        title="Asqav API",
        description="Quantum-safe identity and runtime monitoring for AI agents",
        version="0.1.0",
        lifespan=lifespan,
    )

    # CORS middleware
    application.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    from .routes import agents, health, qml, sessions

    application.include_router(health.router, prefix=settings.api_prefix)
    application.include_router(agents.router, prefix=settings.api_prefix)
    application.include_router(sessions.router, prefix=settings.api_prefix)
    application.include_router(qml.router, prefix=settings.api_prefix)

    return application


app = create_app()
