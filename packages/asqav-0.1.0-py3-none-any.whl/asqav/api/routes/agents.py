"""Agent management endpoints."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix="/agents", tags=["agents"])


# In-memory storage for now (will be replaced with database)
_agents: dict[str, dict[str, Any]] = {}


class AgentRegister(BaseModel):
    """Request schema for registering an agent."""

    agent_id: str = Field(..., pattern=r"^agt_[A-Za-z0-9_-]+$")
    name: str = Field(..., min_length=1, max_length=255)
    algorithm: str = Field(..., pattern=r"^ML-DSA-(44|65|87)$")
    public_key: str  # Base64 encoded
    key_id: str
    capabilities: list[str] = Field(default_factory=list)
    issuer: str = Field(default="asqav")
    created_at: datetime
    metadata: dict[str, Any] | None = None


class AgentResponse(BaseModel):
    """Response schema for agent."""

    agent_id: str
    name: str
    algorithm: str
    public_key: str
    key_id: str
    capabilities: list[str]
    issuer: str
    created_at: datetime
    revoked_at: datetime | None = None
    is_revoked: bool = False
    metadata: dict[str, Any] | None = None


class RevocationRequest(BaseModel):
    """Request schema for revoking an agent."""

    reason: str = Field(
        default="manual",
        pattern=r"^(compromised|expired|policy_violation|manual|anomaly_detected)$",
    )
    propagate: bool = True


@router.post("/", response_model=AgentResponse, status_code=201)
async def register_agent(agent: AgentRegister) -> AgentResponse:
    """Register an agent created by the local library."""
    if agent.agent_id in _agents:
        raise HTTPException(status_code=409, detail="Agent already registered")

    agent_data = agent.model_dump()
    agent_data["revoked_at"] = None
    agent_data["is_revoked"] = False
    _agents[agent.agent_id] = agent_data

    return AgentResponse(**agent_data)


@router.get("/", response_model=list[AgentResponse])
async def list_agents(
    revoked: bool | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[AgentResponse]:
    """List all registered agents."""
    agents = list(_agents.values())

    if revoked is not None:
        agents = [a for a in agents if a["is_revoked"] == revoked]

    return [AgentResponse(**a) for a in agents[offset : offset + limit]]


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(agent_id: str) -> AgentResponse:
    """Get an agent by ID."""
    if agent_id not in _agents:
        raise HTTPException(status_code=404, detail="Agent not found")
    return AgentResponse(**_agents[agent_id])


@router.post("/{agent_id}/revoke", response_model=AgentResponse)
async def revoke_agent(agent_id: str, request: RevocationRequest) -> AgentResponse:
    """Revoke an agent."""
    if agent_id not in _agents:
        raise HTTPException(status_code=404, detail="Agent not found")

    _agents[agent_id]["revoked_at"] = datetime.now()
    _agents[agent_id]["is_revoked"] = True

    return AgentResponse(**_agents[agent_id])


@router.delete("/{agent_id}", status_code=204)
async def delete_agent(agent_id: str) -> None:
    """Delete an agent (soft delete via revocation)."""
    if agent_id not in _agents:
        raise HTTPException(status_code=404, detail="Agent not found")

    _agents[agent_id]["revoked_at"] = datetime.now()
    _agents[agent_id]["is_revoked"] = True
