"""API configuration settings."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class Settings:
    """API configuration."""

    # Database
    database_url: str = field(
        default_factory=lambda: os.getenv(
            "ASQAV_DATABASE_URL",
            "sqlite+aiosqlite:///asqav.db"
        )
    )

    # API
    api_prefix: str = "/api/v1"
    debug: bool = field(
        default_factory=lambda: os.getenv("ASQAV_DEBUG", "false").lower() == "true"
    )
    cors_origins: list[str] = field(default_factory=lambda: ["*"])

    # Server
    host: str = field(default_factory=lambda: os.getenv("ASQAV_HOST", "0.0.0.0"))
    port: int = field(
        default_factory=lambda: int(os.getenv("ASQAV_PORT", "8000"))
    )


settings = Settings()
