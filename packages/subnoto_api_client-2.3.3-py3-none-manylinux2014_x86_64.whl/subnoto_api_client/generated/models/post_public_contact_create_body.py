from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_contact_create_body_contacts_item import PostPublicContactCreateBodyContactsItem





T = TypeVar("T", bound="PostPublicContactCreateBody")



@_attrs_define
class PostPublicContactCreateBody:
    """ 
        Attributes:
            workspace_uuid (str): The UUID of the workspace to create the envelope in.
            contacts (list[PostPublicContactCreateBodyContactsItem]): The contacts to create.
     """

    workspace_uuid: str
    contacts: list[PostPublicContactCreateBodyContactsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_contact_create_body_contacts_item import PostPublicContactCreateBodyContactsItem
        workspace_uuid = self.workspace_uuid

        contacts = []
        for contacts_item_data in self.contacts:
            contacts_item = contacts_item_data.to_dict()
            contacts.append(contacts_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "workspaceUuid": workspace_uuid,
            "contacts": contacts,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_contact_create_body_contacts_item import PostPublicContactCreateBodyContactsItem
        d = dict(src_dict)
        workspace_uuid = d.pop("workspaceUuid")

        contacts = []
        _contacts = d.pop("contacts")
        for contacts_item_data in (_contacts):
            contacts_item = PostPublicContactCreateBodyContactsItem.from_dict(contacts_item_data)



            contacts.append(contacts_item)


        post_public_contact_create_body = cls(
            workspace_uuid=workspace_uuid,
            contacts=contacts,
        )


        post_public_contact_create_body.additional_properties = d
        return post_public_contact_create_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
