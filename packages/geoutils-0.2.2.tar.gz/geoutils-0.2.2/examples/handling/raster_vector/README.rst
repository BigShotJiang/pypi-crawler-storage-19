Raster–vector interfacing
-------------------------
