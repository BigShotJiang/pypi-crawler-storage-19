Raster–point interfacing
------------------------
