# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AgencyPolicyResource:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'uri': 'list[str]'
    }

    attribute_map = {
        'uri': 'uri'
    }

    def __init__(self, uri=None):
        r"""AgencyPolicyResource

        The model defined in huaweicloud sdk

        :param uri: 委托资源的URI。格式为：/iam/agencies/委托ID。例： &#x60;&#x60;&#x60; \&quot;uri\&quot;: [\&quot;/iam/agencies/07805acaba800fdd4fbdc00b8f888c7c\&quot;] &#x60;&#x60;&#x60;
        :type uri: list[str]
        """
        
        

        self._uri = None
        self.discriminator = None

        self.uri = uri

    @property
    def uri(self):
        r"""Gets the uri of this AgencyPolicyResource.

        委托资源的URI。格式为：/iam/agencies/委托ID。例： ``` \"uri\": [\"/iam/agencies/07805acaba800fdd4fbdc00b8f888c7c\"] ```

        :return: The uri of this AgencyPolicyResource.
        :rtype: list[str]
        """
        return self._uri

    @uri.setter
    def uri(self, uri):
        r"""Sets the uri of this AgencyPolicyResource.

        委托资源的URI。格式为：/iam/agencies/委托ID。例： ``` \"uri\": [\"/iam/agencies/07805acaba800fdd4fbdc00b8f888c7c\"] ```

        :param uri: The uri of this AgencyPolicyResource.
        :type uri: list[str]
        """
        self._uri = uri

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AgencyPolicyResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
