# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowOpenIdConnectConfigResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'openid_connect_config': 'OpenIdConnectConfig'
    }

    attribute_map = {
        'openid_connect_config': 'openid_connect_config'
    }

    def __init__(self, openid_connect_config=None):
        r"""ShowOpenIdConnectConfigResponse

        The model defined in huaweicloud sdk

        :param openid_connect_config: 
        :type openid_connect_config: :class:`huaweicloudsdkiam.v3.OpenIdConnectConfig`
        """
        
        super().__init__()

        self._openid_connect_config = None
        self.discriminator = None

        if openid_connect_config is not None:
            self.openid_connect_config = openid_connect_config

    @property
    def openid_connect_config(self):
        r"""Gets the openid_connect_config of this ShowOpenIdConnectConfigResponse.

        :return: The openid_connect_config of this ShowOpenIdConnectConfigResponse.
        :rtype: :class:`huaweicloudsdkiam.v3.OpenIdConnectConfig`
        """
        return self._openid_connect_config

    @openid_connect_config.setter
    def openid_connect_config(self, openid_connect_config):
        r"""Sets the openid_connect_config of this ShowOpenIdConnectConfigResponse.

        :param openid_connect_config: The openid_connect_config of this ShowOpenIdConnectConfigResponse.
        :type openid_connect_config: :class:`huaweicloudsdkiam.v3.OpenIdConnectConfig`
        """
        self._openid_connect_config = openid_connect_config

    def to_dict(self):
        import warnings
        warnings.warn("ShowOpenIdConnectConfigResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowOpenIdConnectConfigResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
