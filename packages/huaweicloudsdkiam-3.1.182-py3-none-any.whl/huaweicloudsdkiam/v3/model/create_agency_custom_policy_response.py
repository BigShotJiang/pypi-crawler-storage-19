# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateAgencyCustomPolicyResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'role': 'AgencyPolicyRoleResult'
    }

    attribute_map = {
        'role': 'role'
    }

    def __init__(self, role=None):
        r"""CreateAgencyCustomPolicyResponse

        The model defined in huaweicloud sdk

        :param role: 
        :type role: :class:`huaweicloudsdkiam.v3.AgencyPolicyRoleResult`
        """
        
        super().__init__()

        self._role = None
        self.discriminator = None

        if role is not None:
            self.role = role

    @property
    def role(self):
        r"""Gets the role of this CreateAgencyCustomPolicyResponse.

        :return: The role of this CreateAgencyCustomPolicyResponse.
        :rtype: :class:`huaweicloudsdkiam.v3.AgencyPolicyRoleResult`
        """
        return self._role

    @role.setter
    def role(self, role):
        r"""Sets the role of this CreateAgencyCustomPolicyResponse.

        :param role: The role of this CreateAgencyCustomPolicyResponse.
        :type role: :class:`huaweicloudsdkiam.v3.AgencyPolicyRoleResult`
        """
        self._role = role

    def to_dict(self):
        import warnings
        warnings.warn("CreateAgencyCustomPolicyResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateAgencyCustomPolicyResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
