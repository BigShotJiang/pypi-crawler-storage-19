# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class KeystoneShowCatalogResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'catalog': 'list[Catalog]',
        'links': 'LinksSelf'
    }

    attribute_map = {
        'catalog': 'catalog',
        'links': 'links'
    }

    def __init__(self, catalog=None, links=None):
        r"""KeystoneShowCatalogResponse

        The model defined in huaweicloud sdk

        :param catalog: 服务目录信息列表。
        :type catalog: list[:class:`huaweicloudsdkiam.v3.Catalog`]
        :param links: 
        :type links: :class:`huaweicloudsdkiam.v3.LinksSelf`
        """
        
        super().__init__()

        self._catalog = None
        self._links = None
        self.discriminator = None

        if catalog is not None:
            self.catalog = catalog
        if links is not None:
            self.links = links

    @property
    def catalog(self):
        r"""Gets the catalog of this KeystoneShowCatalogResponse.

        服务目录信息列表。

        :return: The catalog of this KeystoneShowCatalogResponse.
        :rtype: list[:class:`huaweicloudsdkiam.v3.Catalog`]
        """
        return self._catalog

    @catalog.setter
    def catalog(self, catalog):
        r"""Sets the catalog of this KeystoneShowCatalogResponse.

        服务目录信息列表。

        :param catalog: The catalog of this KeystoneShowCatalogResponse.
        :type catalog: list[:class:`huaweicloudsdkiam.v3.Catalog`]
        """
        self._catalog = catalog

    @property
    def links(self):
        r"""Gets the links of this KeystoneShowCatalogResponse.

        :return: The links of this KeystoneShowCatalogResponse.
        :rtype: :class:`huaweicloudsdkiam.v3.LinksSelf`
        """
        return self._links

    @links.setter
    def links(self, links):
        r"""Sets the links of this KeystoneShowCatalogResponse.

        :param links: The links of this KeystoneShowCatalogResponse.
        :type links: :class:`huaweicloudsdkiam.v3.LinksSelf`
        """
        self._links = links

    def to_dict(self):
        import warnings
        warnings.warn("KeystoneShowCatalogResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, KeystoneShowCatalogResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
