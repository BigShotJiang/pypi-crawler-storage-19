# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class KeystoneUpdateUserByAdminResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'user': 'KeystoneUpdateUserByAdminResult'
    }

    attribute_map = {
        'user': 'user'
    }

    def __init__(self, user=None):
        r"""KeystoneUpdateUserByAdminResponse

        The model defined in huaweicloud sdk

        :param user: 
        :type user: :class:`huaweicloudsdkiam.v3.KeystoneUpdateUserByAdminResult`
        """
        
        super().__init__()

        self._user = None
        self.discriminator = None

        if user is not None:
            self.user = user

    @property
    def user(self):
        r"""Gets the user of this KeystoneUpdateUserByAdminResponse.

        :return: The user of this KeystoneUpdateUserByAdminResponse.
        :rtype: :class:`huaweicloudsdkiam.v3.KeystoneUpdateUserByAdminResult`
        """
        return self._user

    @user.setter
    def user(self, user):
        r"""Sets the user of this KeystoneUpdateUserByAdminResponse.

        :param user: The user of this KeystoneUpdateUserByAdminResponse.
        :type user: :class:`huaweicloudsdkiam.v3.KeystoneUpdateUserByAdminResult`
        """
        self._user = user

    def to_dict(self):
        import warnings
        warnings.warn("KeystoneUpdateUserByAdminResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, KeystoneUpdateUserByAdminResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
