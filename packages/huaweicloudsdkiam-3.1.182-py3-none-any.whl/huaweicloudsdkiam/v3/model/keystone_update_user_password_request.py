# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class KeystoneUpdateUserPasswordRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'user_id': 'str',
        'body': 'KeystoneUpdateUserPasswordRequestBody'
    }

    attribute_map = {
        'user_id': 'user_id',
        'body': 'body'
    }

    def __init__(self, user_id=None, body=None):
        r"""KeystoneUpdateUserPasswordRequest

        The model defined in huaweicloud sdk

        :param user_id: 待修改密码的IAM用户ID，获取方式请参见：[获取用户ID](https://support.huaweicloud.com/api-iam/iam_17_0002.html)。
        :type user_id: str
        :param body: Body of the KeystoneUpdateUserPasswordRequest
        :type body: :class:`huaweicloudsdkiam.v3.KeystoneUpdateUserPasswordRequestBody`
        """
        
        

        self._user_id = None
        self._body = None
        self.discriminator = None

        self.user_id = user_id
        if body is not None:
            self.body = body

    @property
    def user_id(self):
        r"""Gets the user_id of this KeystoneUpdateUserPasswordRequest.

        待修改密码的IAM用户ID，获取方式请参见：[获取用户ID](https://support.huaweicloud.com/api-iam/iam_17_0002.html)。

        :return: The user_id of this KeystoneUpdateUserPasswordRequest.
        :rtype: str
        """
        return self._user_id

    @user_id.setter
    def user_id(self, user_id):
        r"""Sets the user_id of this KeystoneUpdateUserPasswordRequest.

        待修改密码的IAM用户ID，获取方式请参见：[获取用户ID](https://support.huaweicloud.com/api-iam/iam_17_0002.html)。

        :param user_id: The user_id of this KeystoneUpdateUserPasswordRequest.
        :type user_id: str
        """
        self._user_id = user_id

    @property
    def body(self):
        r"""Gets the body of this KeystoneUpdateUserPasswordRequest.

        :return: The body of this KeystoneUpdateUserPasswordRequest.
        :rtype: :class:`huaweicloudsdkiam.v3.KeystoneUpdateUserPasswordRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this KeystoneUpdateUserPasswordRequest.

        :param body: The body of this KeystoneUpdateUserPasswordRequest.
        :type body: :class:`huaweicloudsdkiam.v3.KeystoneUpdateUserPasswordRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, KeystoneUpdateUserPasswordRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
