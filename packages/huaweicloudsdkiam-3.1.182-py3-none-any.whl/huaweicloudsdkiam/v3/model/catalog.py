# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class Catalog:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'endpoints': 'list[CatalogEndpoints]',
        'id': 'str',
        'name': 'str',
        'type': 'str'
    }

    attribute_map = {
        'endpoints': 'endpoints',
        'id': 'id',
        'name': 'name',
        'type': 'type'
    }

    def __init__(self, endpoints=None, id=None, name=None, type=None):
        r"""Catalog

        The model defined in huaweicloud sdk

        :param endpoints: 终端节点信息。
        :type endpoints: list[:class:`huaweicloudsdkiam.v3.CatalogEndpoints`]
        :param id: 服务ID。
        :type id: str
        :param name: 服务名。
        :type name: str
        :param type: 服务类型。
        :type type: str
        """
        
        

        self._endpoints = None
        self._id = None
        self._name = None
        self._type = None
        self.discriminator = None

        self.endpoints = endpoints
        self.id = id
        self.name = name
        self.type = type

    @property
    def endpoints(self):
        r"""Gets the endpoints of this Catalog.

        终端节点信息。

        :return: The endpoints of this Catalog.
        :rtype: list[:class:`huaweicloudsdkiam.v3.CatalogEndpoints`]
        """
        return self._endpoints

    @endpoints.setter
    def endpoints(self, endpoints):
        r"""Sets the endpoints of this Catalog.

        终端节点信息。

        :param endpoints: The endpoints of this Catalog.
        :type endpoints: list[:class:`huaweicloudsdkiam.v3.CatalogEndpoints`]
        """
        self._endpoints = endpoints

    @property
    def id(self):
        r"""Gets the id of this Catalog.

        服务ID。

        :return: The id of this Catalog.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this Catalog.

        服务ID。

        :param id: The id of this Catalog.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this Catalog.

        服务名。

        :return: The name of this Catalog.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this Catalog.

        服务名。

        :param name: The name of this Catalog.
        :type name: str
        """
        self._name = name

    @property
    def type(self):
        r"""Gets the type of this Catalog.

        服务类型。

        :return: The type of this Catalog.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this Catalog.

        服务类型。

        :param type: The type of this Catalog.
        :type type: str
        """
        self._type = type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Catalog):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
