# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AllowAddressNetmasksOptionIPv6:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'address_netmask': 'str',
        'description': 'str'
    }

    attribute_map = {
        'address_netmask': 'address_netmask',
        'description': 'description'
    }

    def __init__(self, address_netmask=None, description=None):
        r"""AllowAddressNetmasksOptionIPv6

        The model defined in huaweicloud sdk

        :param address_netmask: IPv6地址或网段，例如： 0000:0000:0000:0000:0000:0000:0000:0000/126。
        :type address_netmask: str
        :param description: 描述信息。
        :type description: str
        """
        
        

        self._address_netmask = None
        self._description = None
        self.discriminator = None

        self.address_netmask = address_netmask
        if description is not None:
            self.description = description

    @property
    def address_netmask(self):
        r"""Gets the address_netmask of this AllowAddressNetmasksOptionIPv6.

        IPv6地址或网段，例如： 0000:0000:0000:0000:0000:0000:0000:0000/126。

        :return: The address_netmask of this AllowAddressNetmasksOptionIPv6.
        :rtype: str
        """
        return self._address_netmask

    @address_netmask.setter
    def address_netmask(self, address_netmask):
        r"""Sets the address_netmask of this AllowAddressNetmasksOptionIPv6.

        IPv6地址或网段，例如： 0000:0000:0000:0000:0000:0000:0000:0000/126。

        :param address_netmask: The address_netmask of this AllowAddressNetmasksOptionIPv6.
        :type address_netmask: str
        """
        self._address_netmask = address_netmask

    @property
    def description(self):
        r"""Gets the description of this AllowAddressNetmasksOptionIPv6.

        描述信息。

        :return: The description of this AllowAddressNetmasksOptionIPv6.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        r"""Sets the description of this AllowAddressNetmasksOptionIPv6.

        描述信息。

        :param description: The description of this AllowAddressNetmasksOptionIPv6.
        :type description: str
        """
        self._description = description

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AllowAddressNetmasksOptionIPv6):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
