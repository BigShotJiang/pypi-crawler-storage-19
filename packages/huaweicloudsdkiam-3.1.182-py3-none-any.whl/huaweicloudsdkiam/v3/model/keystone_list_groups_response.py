# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class KeystoneListGroupsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'groups': 'list[KeystoneGroupResult]',
        'links': 'Links'
    }

    attribute_map = {
        'groups': 'groups',
        'links': 'links'
    }

    def __init__(self, groups=None, links=None):
        r"""KeystoneListGroupsResponse

        The model defined in huaweicloud sdk

        :param groups: 用户组信息列表。
        :type groups: list[:class:`huaweicloudsdkiam.v3.KeystoneGroupResult`]
        :param links: 
        :type links: :class:`huaweicloudsdkiam.v3.Links`
        """
        
        super().__init__()

        self._groups = None
        self._links = None
        self.discriminator = None

        if groups is not None:
            self.groups = groups
        if links is not None:
            self.links = links

    @property
    def groups(self):
        r"""Gets the groups of this KeystoneListGroupsResponse.

        用户组信息列表。

        :return: The groups of this KeystoneListGroupsResponse.
        :rtype: list[:class:`huaweicloudsdkiam.v3.KeystoneGroupResult`]
        """
        return self._groups

    @groups.setter
    def groups(self, groups):
        r"""Sets the groups of this KeystoneListGroupsResponse.

        用户组信息列表。

        :param groups: The groups of this KeystoneListGroupsResponse.
        :type groups: list[:class:`huaweicloudsdkiam.v3.KeystoneGroupResult`]
        """
        self._groups = groups

    @property
    def links(self):
        r"""Gets the links of this KeystoneListGroupsResponse.

        :return: The links of this KeystoneListGroupsResponse.
        :rtype: :class:`huaweicloudsdkiam.v3.Links`
        """
        return self._links

    @links.setter
    def links(self, links):
        r"""Sets the links of this KeystoneListGroupsResponse.

        :param links: The links of this KeystoneListGroupsResponse.
        :type links: :class:`huaweicloudsdkiam.v3.Links`
        """
        self._links = links

    def to_dict(self):
        import warnings
        warnings.warn("KeystoneListGroupsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, KeystoneListGroupsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
