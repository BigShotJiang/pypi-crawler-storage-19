import os
import requests
import pyotp
from datetime import datetime

class TFAuth:
    def __init__(self):
        self.TAPI = None
        self.version = "1.2.5"
        self.logo = ""
        self.footer_text = "TFAuth Ironclad System 2026"
        self.color1 = "#ff416c"
        self.color2 = "#4b6cb7"
        self.GAPI = "not_set"
        self.FAPI = "not_set"
        self.success_login = "successl.html"
        self.GITHUB_RAW_URL = "https://raw.githubusercontent.com/TLETIFORMAT/apifs/ad181080e15c98116d839ab15f0c54214d1259bf/main/APIKEYS.json"
        self.otp_secret = pyotp.random_base32()

    def _get_styles(self):
        return f"""
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Roboto:wght@300;400&display=swap');
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ background: #05050a; height: 100vh; overflow: hidden; font-family: 'Roboto', sans-serif; display: flex; justify-content: center; align-items: center; }}
            #preloader {{ position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: #000; display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 9999; }}
            .spinner {{ width: 50px; height: 50px; border: 3px solid transparent; border-top: 3px solid {self.color1}; border-radius: 50%; animation: spin 1s linear infinite; }}
            @keyframes spin {{ to {{ transform: rotate(360deg); }} }}
            #particles-js {{ position: absolute; width: 100%; height: 100%; z-index: 1; }}
            .main-frame {{ position: relative; z-index: 10; width: 420px; padding: 40px; background: rgba(255,255,255,0.05); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.1); border-radius: 35px; text-align: center; color: white; }}
            h2 {{ font-family: 'Orbitron'; margin-bottom: 25px; letter-spacing: 3px; font-size: 20px; }}
            .input-box {{ position: relative; margin-bottom: 15px; }}
            .input-box input {{ width: 100%; padding: 12px 15px 12px 45px; background: rgba(0,0,0,0.3); border: 1px solid #333; border-radius: 12px; color: white; outline: none; }}
            .input-box i {{ position: absolute; left: 15px; top: 14px; color: {self.color1}; }}
            .master-btn {{ width: 100%; padding: 15px; border: none; border-radius: 12px; background: linear-gradient(45deg, {self.color1}, {self.color2}); color: white; font-family: 'Orbitron'; font-weight: bold; cursor: pointer; }}
            .hidden {{ display: none !important; }}
            #toast-box {{ position: fixed; top: 20px; right: 20px; z-index: 10000; }}
            .toast {{ background: #111; color: #fff; padding: 15px 20px; border-left: 4px solid {self.color1}; margin-bottom: 10px; border-radius: 5px; }}
        </style>
        """

    def generate_html(self):
        totp = pyotp.TOTP(self.otp_secret)
        otp_link = totp.provisioning_uri(name="SecureUser", issuer_name="TFAuth")

        return f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://unpkg.com/@otplib/preset-browser@12.0.1/buffer.js"></script>
    <script src="https://unpkg.com/@otplib/preset-browser@12.0.1/index.js"></script>
    {self._get_styles()}
</head>
<body>
    <div id="preloader"><div class="spinner"></div></div>
    <div id="toast-box"></div>
    <div id="particles-js"></div>

    <div class="main-frame">
        <h2 id="title">TERMINAL LOGIN</h2>
        <div id="step-1">
            <div class="input-box"><i class="fa fa-user"></i><input type="text" id="u" placeholder="USERNAME"></div>
            <div class="input-box"><i class="fa fa-lock"></i><input type="password" id="p" placeholder="PASSWORD"></div>
            <button class="master-btn" onclick="handleStep1()">CONTINUE</button>
            <p id="switch-text" style="margin-top:15px; font-size:11px; color:#777;">
                No account? <b style="color:{self.color1}; cursor:pointer;" onclick="switchMode(false)">Register with 2FA</b>
            </p>
        </div>
        <div id="step-register-2fa" class="hidden">
            <p style="font-size:11px; color:#aaa; margin-bottom:10px;">SCAN QR WITH AUTH APP</p>
            <div style="background:white; padding:10px; display:inline-block; border-radius:10px;">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data={otp_link}">
            </div>
            <button class="master-btn" onclick="completeRegistration()">I SCANNED IT</button>
        </div>
        <div id="step-login-otp" class="hidden">
            <p style="font-size:11px; color:#aaa; margin-bottom:15px;">ENTER 6-DIGIT CODE</p>
            <div class="input-box"><i class="fa fa-shield-alt"></i><input type="text" id="otp" placeholder="000000" maxlength="6" style="text-align:center; letter-spacing:5px;"></div>
            <button class="master-btn" onclick="verifyFinal()">VERIFY</button>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <script>
        window.onload = function() {{
            setTimeout(function() {{
                document.getElementById('preloader').style.display = 'none';
                console.log("System Ready. OTPLIB Loaded:", typeof otplib !== 'undefined');
            }}, 1000);
        }};

        particlesJS('particles-js', {{
            "particles": {{
                "number": {{ "value": 50 }},
                "color": {{ "value": "#ffffff" }},
                "line_linked": {{ "enable": true, "opacity": 0.1 }},
                "move": {{ "speed": 1 }}
            }}
        }});
        
        let isLoginMode = true;
        let currentSecret = "{self.otp_secret}";

        function showT(m) {{ 
            const b = document.getElementById('toast-box'); 
            const t = document.createElement('div');
            t.className='toast';
            t.innerText=m; 
            b.appendChild(t);
            setTimeout(function() {{ t.remove(); }}, 3000); 
        }}

        function switchMode(mode) {{
            isLoginMode = mode;
            document.getElementById('title').innerText = mode ? "TERMINAL LOGIN" : "CREATE ACCOUNT";
        }}

        function handleStep1() {{
            const u = document.getElementById('u').value;
            const p = document.getElementById('p').value;
            if(!u || !p) return showT("⚠️ Fill all fields");

            if(!isLoginMode) {{
                document.getElementById('step-1').classList.add('hidden');
                document.getElementById('step-register-2fa').classList.remove('hidden');
            }} else {{
                const savedPass = localStorage.getItem('up_'+u);
                if(savedPass === p) {{
                    document.getElementById('step-1').classList.add('hidden');
                    document.getElementById('step-login-otp').classList.remove('hidden');
                }} else {{
                    showT("❌ Invalid credentials");
                }}
            }}
        }}

        function completeRegistration() {{
            const u = document.getElementById('u').value;
            const p = document.getElementById('p').value;
            localStorage.setItem('up_'+u, p);
            localStorage.setItem('us_'+u, currentSecret);
            showT("✅ Registered! Now Login.");
            setTimeout(function() {{ location.reload(); }}, 1500);
        }}

        function verifyFinal() {{
            const code = document.getElementById('otp').value;
            const u = document.getElementById('u').value;
            const userSecret = localStorage.getItem('us_' + u);
            
            if(!userSecret) return showT("⚠️ No 2FA data");

            try {{
                // ВАЖНО: правильный вызов из otplib-preset-browser
                const authenticator = otplib.authenticator;
                authenticator.options = {{ window: 1 }};
                
                const isValid = authenticator.check(code, userSecret);
                
                if(isValid) {{
                    showT("✅ Success!");
                    setTimeout(function() {{ location.href='{self.success_login}'; }}, 1000);
                }} else {{
                    showT("❌ Wrong Code. Check phone time!");
                }}
            }} catch(e) {{
                console.error(e);
                showT("⚠️ Critical 2FA Error. Check Console.");
            }}
        }}
    </script>
</body>
</html>
        """

    def save_as_html(self, filename="index.html"):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(self.generate_html())
        print(f"[TFAuth v{self.version}] Final Hotfix applied.")