"""Engine and backend management for Pie.

This module handles the lifecycle of the Pie engine and backend services.
"""

import sys
import time
import os
import signal
import subprocess
import random
import asyncio
import warnings
from pathlib import Path
from typing import Optional, Any

import torch
import torch.multiprocessing as mp
import torch.distributed as dist


import blake3


from rich.console import Console

from . import path as pie_path
from . import _pie

from pie_worker import utils as pie_utils
from pie_worker.control_channel import ControlChannel, create_control_channels
from pie_worker.server import start_ffi_worker
from pie_worker.config import RuntimeConfig
from pie_worker.runtime import Runtime


from pie_client import PieClient, Event


class EngineError(Exception):
    """Exception raised for engine/backend errors."""

    pass


class FfiWorkerHandle:
    """Wrapper for FFI worker thread to look like a process for cleanup."""

    def __init__(self, thread, stop_event):
        self.thread = thread
        self.stop_event = stop_event
        self.pid = -1  # Pseudo-PID

    def terminate(self):
        self.stop_event.set()

    def kill(self):
        """Simulate kill by ensuring stop event is set (threads cannot be SIGKILLed)."""
        self.stop_event.set()

    def join(self, timeout=None):
        self.thread.join(timeout=timeout)

    def is_alive(self):
        return self.thread.is_alive()


def start_engine_and_backend(
    engine_config: dict,
    model_configs: list[dict],
    timeout: float = 300.0,
    console: Optional[Any] = None,
    on_status: Optional[callable] = None,
    on_message: Optional[callable] = None,
) -> tuple["_pie.ServerHandle", list]:
    """Start the Pie engine and all configured backend services.

    Args:
        engine_config: Engine configuration dict
        model_configs: List of model configurations
        timeout: Maximum time to wait for backends to connect (seconds)
        console: Optional rich.console.Console for output
        on_status: Optional callback for status updates: (status_message: str) -> None
        on_message: Optional callback for log messages: (level: str, message: str) -> None

    Returns:
        Tuple of (ServerHandle, list of backend processes - empty for FFI mode)

    Raises:
        EngineError: If engine or backend fails to start
    """
    """Start the Pie engine and all configured backend services.

    Args:
        engine_config: Engine configuration dict
        model_configs: List of model configurations
        timeout: Maximum time to wait for backends to connect (seconds)
        console: Optional rich.console.Console for output
        on_status: Optional callback for status updates: (status_message: str) -> None
        on_message: Optional callback for log messages: (level: str, message: str) -> None

    Returns:
        Tuple of (ServerHandle, list of backend processes - empty for FFI mode)

    Raises:
        EngineError: If engine or backend fails to start
    """

    def status_update(msg: str):
        if on_status:
            on_status(msg)

    def log_message(level: str, msg: str):
        if on_message:
            on_message(level, msg)

    # Load authorized users if auth is enabled
    authorized_users_path = None
    if engine_config.get("enable_auth", True):
        auth_path = pie_path.get_authorized_users_path()
        if auth_path.exists():
            authorized_users_path = str(auth_path)

    # Create server config
    # Get telemetry config from engine_config (loaded from [telemetry] section)
    telemetry_config = engine_config.get("telemetry", {})
    server_config = _pie.ServerConfig(
        host=engine_config.get("host", "127.0.0.1"),
        port=engine_config.get("port", 8080),
        enable_auth=engine_config.get("enable_auth", True),
        cache_dir=engine_config.get("cache_dir"),
        verbose=engine_config.get("verbose", False),
        log_dir=engine_config.get("log_dir"),
        registry=engine_config.get("registry", "https://registry.pie-project.org/"),
        telemetry_enabled=telemetry_config.get("enabled", False),
        telemetry_endpoint=telemetry_config.get("endpoint", "http://localhost:4317"),
        telemetry_service_name=telemetry_config.get("service_name", "pie-runtime"),
    )

    # FFI MODE: Queue-based communication for high throughput
    if console is not None:
        console.print("[dim]Starting engine...[/dim]")

    try:
        # Currently supports single-model configurations
        if len(model_configs) > 1:
            raise EngineError(
                "Currently only single-model configurations are supported"
            )

        model_config = model_configs[0]

        # Detect multi-GPU configuration
        device_value = model_config.get("device")
        world_size = len(device_value) if isinstance(device_value, list) else 1

        if world_size > 1:
            # Multi-GPU FFI mode: spawn worker processes
            backend_processes = _start_multi_gpu_ffi_backend(
                engine_config,
                model_config,
                server_config,
                authorized_users_path,
                device_value,
                world_size,
                console,
                status_update,
            )
            server_handle = backend_processes.pop(0)  # First element is server_handle
        else:
            # Single-GPU FFI mode: existing in-process path
            status_update("Initializing backend in-process...")

            # Build the full config for pie_backend
            full_config = _build_backend_config(
                engine_config, model_config, authorized_users_path
            )

            # Initialize Python backend - returns Runtime
            runtime = _pie.initialize_backend(full_config)

            # Create the FfiQueue FIRST via Python
            ffi_queue = _pie.FfiQueue()

            # Start the Python worker thread BEFORE starting server
            # This allows the worker to respond to handshake during Model::new
            _ffi_worker, stop_event = start_ffi_worker(ffi_queue, runtime)

            # Now start server with FFI mode - the worker is ready to handle requests
            server_handle = _pie.start_server_with_ffi(
                server_config,
                authorized_users_path,
                ffi_queue,
            )

            # Wrap worker thread for cleanup
            backend_processes = [FfiWorkerHandle(_ffi_worker, stop_event)]

    except Exception as e:
        raise EngineError(f"Failed to initialize backend: {e}") from e

    # Final success message
    if console is not None:
        console.print(
            "[green]✓[/green] Engine running. [dim]Press Ctrl+C to stop[/dim]"
        )

    return server_handle, backend_processes


def _build_backend_config(
    engine_config: dict, model_config: dict, internal_token: str
) -> dict:
    """Build the configuration dict for RuntimeConfig.from_args().

    Args:
        engine_config: Engine configuration dict (host, port) - not used for RuntimeConfig
        model_config: Model configuration dict
        internal_token: Internal authentication token - not used for RuntimeConfig

    Returns:
        Configuration dict suitable for RuntimeConfig.from_args(**kwargs)
    """
    # Note: host, port, internal_auth_token are for pycrust server registration,
    # not RuntimeConfig. They're excluded here because in FFI mode we don't
    # need to register with the engine - we call Python directly.

    # Handle device field - can be string or list
    # RuntimeConfig.from_args expects: device (str) OR devices (list[str])
    device_value = model_config.get("device")
    device_key = None
    if device_value is not None:
        if isinstance(device_value, list):
            device_key = "devices"
        else:
            device_key = "device"

    config = {
        "hf_repo": model_config.get("hf_repo"),
        "cache_dir": model_config.get("cache_dir"),
        "kv_page_size": model_config.get("kv_page_size", 16),
        "max_dist_size": model_config.get("max_dist_size", 64),
        "max_num_embeds": model_config.get("max_num_embeds", 128),
        "max_batch_tokens": model_config.get("max_batch_tokens", 10240),
        "max_num_adapters": model_config.get("max_num_adapters", 48),
        "max_adapter_rank": model_config.get("max_adapter_rank", 8),
        "gpu_mem_utilization": model_config.get("gpu_mem_utilization", 0.9),
        "max_batch_size": model_config.get("max_batch_size", 128),
        "activation_dtype": model_config.get("activation_dtype", "bfloat16"),
        "weight_dtype": model_config.get("weight_dtype"),
        "telemetry_enabled": engine_config.get("telemetry", {}).get("enabled", False),
        "telemetry_endpoint": engine_config.get("telemetry", {}).get(
            "endpoint", "http://localhost:4317"
        ),
        "telemetry_service_name": engine_config.get("telemetry", {}).get(
            "service_name", "pie"
        ),
        "random_seed": model_config.get("random_seed", 42),
        "use_cuda_graphs": model_config.get("use_cuda_graphs", True),
    }

    # Add device with correct key
    if device_key is not None:
        config[device_key] = device_value

    # Remove None values to use from_args() defaults
    return {k: v for k, v in config.items() if v is not None}


# =============================================================================
# Multi-GPU FFI Mode Helpers
# =============================================================================


def _init_distributed(rank: int, world_size: int, master_port: int, device: str):
    """Initialize torch.distributed for a given rank.

    Sets up environment variables, CUDA device, and process group.
    """
    # Environment setup
    os.environ["MASTER_ADDR"] = "localhost"
    os.environ["MASTER_PORT"] = str(master_port)
    os.environ["NCCL_TIMEOUT"] = "300"
    os.environ["TORCH_NCCL_ASYNC_ERROR_HANDLING"] = "1"

    # Set CUDA device
    torch.cuda.set_device(device)

    # Suppress harmless warnings
    warnings.filterwarnings(
        "ignore", message=".*barrier.*device under current context.*"
    )

    # Initialize process group with NCCL options if available
    backend = "nccl" if torch.cuda.is_available() else "gloo"
    pg_options = None

    if backend == "nccl":
        try:
            from torch.distributed import ProcessGroupNCCL

            pg_options = ProcessGroupNCCL.Options()
            pg_options.config.capture_safe = True
        except (ImportError, AttributeError):
            pass

    if pg_options:
        dist.init_process_group(
            backend, rank=rank, world_size=world_size, pg_options=pg_options
        )
    else:
        dist.init_process_group(backend, rank=rank, world_size=world_size)


def _setup_control_channel(rank: int, world_size: int, control_queues: list):
    """Set up the IPC control channel for this rank."""


def _setup_control_channel(rank: int, world_size: int, control_queues: list):
    """Set up the IPC control channel for this rank."""
    pie_utils._control_channel = ControlChannel(rank, world_size, control_queues)


def _create_runtime(config_dict: dict, devices: list[str], rank: int, world_size: int):
    """Create a Runtime instance for the given rank."""


def _create_runtime(config_dict: dict, devices: list[str], rank: int, world_size: int):
    """Create a Runtime instance for the given rank."""

    # Remove device/devices from config to avoid duplicate argument
    filtered_config = {
        k: v for k, v in config_dict.items() if k not in ("device", "devices")
    }

    config = RuntimeConfig.from_args(
        **filtered_config,
        devices=devices,
        rank=rank,
        world_size=world_size,
    )

    return Runtime(config, log_queue=None)


# =============================================================================
# Multi-GPU FFI Mode Entry Points
# =============================================================================


def _start_multi_gpu_ffi_backend(
    engine_config: dict,
    model_config: dict,
    server_config,
    authorized_users_path: str | None,
    devices: list[str],
    world_size: int,
    console,
    status_update: callable,
) -> list:
    """Start multi-GPU FFI backend with worker processes.

    Spawns worker processes for ranks 1..world_size-1, then initializes rank 0
    in-process with torch.distributed and the FFI queue.

    Returns:
        List where first element is ServerHandle, rest are worker processes
    """
    """Start multi-GPU FFI backend with worker processes.

    Spawns worker processes for ranks 1..world_size-1, then initializes rank 0
    in-process with torch.distributed and the FFI queue.

    Returns:
        List where first element is ServerHandle, rest are worker processes
    """

    status_update(f"Initializing multi-GPU backend ({world_size} devices)...")

    # Use 'spawn' context for CUDA compatibility
    mp.set_start_method("spawn", force=True)

    # Generate master port and create control channels
    master_port = 29500 + random.randint(0, 1000)
    control_queues = create_control_channels(world_size)

    # Build config dict for all ranks
    full_config = _build_backend_config(
        engine_config, model_config, authorized_users_path
    )

    # Spawn worker processes for ranks 1..world_size-1
    ctx = mp.spawn(
        _ffi_worker_process,
        args=(world_size, devices, master_port, control_queues, full_config),
        nprocs=world_size - 1,
        join=False,
        start_method="spawn",
    )
    worker_processes = list(ctx.processes)

    # Initialize rank 0 in this process
    _init_distributed(0, world_size, master_port, devices[0])
    _setup_control_channel(0, world_size, control_queues)
    runtime = _create_runtime(full_config, devices, 0, world_size)

    # Sync with workers then start server
    # Sync with workers then start server
    dist.barrier()

    ffi_queue = _pie.FfiQueue()
    _ffi_worker, stop_event = start_ffi_worker(ffi_queue, runtime)

    server_handle = _pie.start_server_with_ffi(
        server_config, authorized_users_path, ffi_queue
    )

    # Return the context objects (ctx) instead of raw processes so we can join gracefully
    return [server_handle, ctx, FfiWorkerHandle(_ffi_worker, stop_event)]


def _ffi_worker_process(
    local_rank: int,  # mp.spawn passes 0-indexed local rank
    world_size: int,
    devices: list[str],
    master_port: int,
    control_queues: list,
    config_dict: dict,
):
    """Worker process for multi-GPU FFI mode.

    Note: mp.spawn passes local_rank starting at 0, so actual rank = local_rank + 1.
    """
    """Worker process for multi-GPU FFI mode.

    Note: mp.spawn passes local_rank starting at 0, so actual rank = local_rank + 1.
    """
    rank = local_rank + 1

    # Ignore SIGTERM initially (parent handles shutdown)
    signal.signal(signal.SIGTERM, signal.SIG_IGN)

    # Initialize distributed, control channel, and runtime
    _init_distributed(rank, world_size, master_port, devices[rank])
    _setup_control_channel(rank, world_size, control_queues)
    runtime = _create_runtime(config_dict, devices, rank, world_size)

    # Sync with rank 0 then run worker loop
    dist.barrier()
    runtime.worker_loop()

    # Clean exit without running Python finalizers that might hang
    # dist.destroy_process_group() # Can hang in multi-process if not coordinated

    # Cleanup control channel resources
    if pie_utils._control_channel is not None:
        pie_utils._control_channel.cleanup()
        pie_utils._control_channel = None

    # Clear local references
    control_queues = None

    # Force GC to cleanup Queues and other resources
    # time imported globally

    # Give background threads a moment to exit
    time.sleep(0.1)

    gc.collect()

    return


def wait_for_backends(
    server_handle: "_pie.ServerHandle",
    expected_count: int,
    timeout: float,
    backend_processes: list,
) -> bool:
    """Wait for the expected number of backends to register with the engine.

    Args:
        server_handle: The server handle to query
        expected_count: Number of backends we expect to connect
        timeout: Maximum time to wait in seconds
        backend_processes: List of backend processes to check for early exit

    Returns:
        True if all backends connected, False if timeout
    """
    start_time = time.time()
    poll_interval = 0.5  # seconds

    while time.time() - start_time < timeout:
        # Check if the engine is still running
        if not server_handle.is_running():
            print("❌ Engine stopped unexpectedly", file=sys.stderr)
            return False

        # Check if any backend process has died
        if not check_backend_processes(backend_processes):
            return False

        # Check registered models
        models = server_handle.registered_models()
        if len(models) >= expected_count:
            return True

        time.sleep(poll_interval)

    return False


def check_backend_processes(
    backend_processes: list, on_error: Optional[callable] = None
) -> bool:
    """Check if all backend processes are still alive.

    Args:
        backend_processes: List of backend processes to check
        on_error: Optional callback for error messages: (message: str) -> None

    Returns:
        True if all processes are alive, False if any have died
    """

    all_alive = True
    for process in backend_processes:
        # In FFI mode, backend_processes may contain dispatcher functions (not processes)
        # Skip anything that's not a process
        if not hasattr(process, "pid") or not hasattr(process, "is_alive"):
            continue

        is_dead = False
        return_code = None
        stderr = ""

        if isinstance(process, subprocess.Popen):
            if process.poll() is not None:
                is_dead = True
                return_code = process.returncode
                stderr = process.stderr.read().decode() if process.stderr else ""
        else:
            # Assume multiprocessing.Process
            if not process.is_alive():
                is_dead = True
                return_code = process.exitcode
                # Check for SpawnContext
                if hasattr(process, "processes"):
                    # For SpawnContext, is_alive checks if any process is alive
                    # Context is "dead" if all processes are dead
                    pass

        if is_dead:
            all_alive = False
            error_msg = f"Backend process exited unexpectedly (exit code {return_code})"
            if stderr:
                error_msg += f" stderr: {stderr[:500]}"
            if on_error:
                on_error(error_msg)
            else:
                print(f"❌ {error_msg}", file=sys.stderr)

    return all_alive


def terminate_engine_and_backend(
    server_handle: "_pie.ServerHandle | None",
    backend_processes: list,
    on_message: Optional[callable] = None,
) -> None:
    """Terminate the engine and backend processes.

    Args:
        server_handle: The server handle (or None if already shut down)
        backend_processes: List of backend subprocess.Popen objects
        on_message: Optional callback for status messages: (message: str) -> None
    """

    def log(msg: str):
        if on_message:
            on_message(msg)
        else:
            # sys imported globally
            pass
            # print(f"[Manager] {msg}", file=sys.stderr)

    # 1. Broadcast STOP signal to workers
    try:
        if pie_utils._control_channel is not None:
            # log("Debug: Sending STOP signal to workers")
            pie_utils._control_channel.send("STOP")
            # Give workers time to receive the signal and exit voluntarily
            time.sleep(0.5)
    except ImportError:
        pass
    except Exception as e:
        log(f"Error sending STOP signal: {e}")

    for process in backend_processes:
        # Check for SpawnContext (multiprocessing spawn context)
        # It doesn't have a pid attribute directly, but has .processes and .join
        if hasattr(process, "join") and hasattr(process, "processes"):
            try:
                # log("Debug: Joining SpawnContext")
                process.join(timeout=5)
                # log("Debug: SpawnContext joined successfully")
            except Exception as e:
                log(f"Error joining SpawnContext: {e}")
            continue

        # In FFI mode, backend_processes may contain dispatcher functions (not processes)
        # Skip anything that's not a process or context
        if not hasattr(process, "pid"):
            continue

        is_running = False
        pid = process.pid

        if isinstance(process, subprocess.Popen):
            is_running = process.poll() is None
        else:
            is_running = process.is_alive()

        if is_running:
            try:
                if isinstance(process, subprocess.Popen):
                    process.send_signal(signal.SIGTERM)
                    process.wait(timeout=5)
                else:
                    process.terminate()
                    process.join(timeout=5)
                    if process.is_alive():
                        raise subprocess.TimeoutExpired(cmd=str(pid), timeout=5)
            except subprocess.TimeoutExpired:
                log(f"Force killing process {pid}")
                process.kill()
            except Exception as e:
                log(f"Error terminating process {pid}: {e}")

    # Gracefully shut down the engine
    if server_handle is not None:
        try:
            if server_handle.is_running():
                server_handle.shutdown()
        except Exception as e:
            log(f"Error shutting down engine: {e}")

    # Finalize control channel queues if they exist
    # This prevents "leaked semaphore" warnings from multiprocessing.resource_tracker
    try:
        if pie_utils._control_channel is not None:
            pie_utils._control_channel.cleanup()
            pie_utils._control_channel = None

    except ImportError:
        pass  # pie_worker might not be installed or importable
    except Exception as e:
        log(f"Error cleaning up control channel: {e}")


def run_interactive_shell(engine_config: dict, internal_token: str) -> None:
    """Run the interactive shell session.

    Args:
        engine_config: Engine configuration dict
        internal_token: Internal authentication token
    """
    # Simple readline-based shell
    try:
        import readline
    except ImportError:
        pass  # readline not available on all platforms

    # Load history
    history_path = pie_path.get_shell_history_path()
    try:
        if history_path.exists():
            readline.read_history_file(str(history_path))
    except (OSError, NameError):
        pass

    client_config = {
        "host": engine_config.get("host", "127.0.0.1"),
        "port": engine_config.get("port", 8080),
        "internal_auth_token": internal_token,
    }

    print("Available commands:")
    print("  run <path> [ARGS]... - Run a .wasm inferlet with optional arguments")
    print("  stat                 - Query the backend statistics")
    print("  exit                 - Exit the Pie session")
    print("  help                 - Show this help message")

    while True:
        try:
            line = input("pie> ")
        except EOFError:
            print("Exiting...")
            break
        except KeyboardInterrupt:
            print("\n(To exit, type 'exit' or press Ctrl-D)")
            continue

        line = line.strip()
        if not line:
            continue

        parts = line.split()
        command = parts[0]
        args = parts[1:]

        if command == "exit":
            print("Exiting...")
            break
        elif command == "help":
            print("Available commands:")
            print("  run <path> [ARGS]... - Run a .wasm inferlet")
            print("  stat                 - Query backend statistics")
            print("  exit                 - Exit the session")
            print("  help                 - Show this help message")
        elif command == "run":
            if not args:
                print("Usage: run <inferlet_path> [ARGS]...")
                continue
            inferlet_path = Path(args[0]).expanduser()
            inferlet_args = args[1:]
            try:
                submit_inferlet_and_wait(client_config, inferlet_path, inferlet_args)
            except Exception as e:
                print(f"Error running inferlet: {e}")
        elif command == "stat":
            print("(stat command not yet implemented)")
        else:
            print(f"Unknown command: '{command}'. Type 'help' for a list of commands.")

    # Save history
    try:
        history_path.parent.mkdir(parents=True, exist_ok=True)
        readline.write_history_file(str(history_path))
    except (OSError, NameError):
        pass


def submit_inferlet_and_wait(
    client_config: dict,
    inferlet_path: Path,
    arguments: list[str],
    server_handle: "_pie.ServerHandle | None" = None,
    backend_processes: list | None = None,
    on_event: Optional[callable] = None,
) -> None:
    """Submit an inferlet to the engine and wait for it to finish.

    Args:
        client_config: Client configuration with host, port, internal_auth_token
        inferlet_path: Path to the .wasm inferlet file
        arguments: Arguments to pass to the inferlet
        server_handle: Optional server handle for process monitoring
        backend_processes: Optional list of backend processes to monitor
    """
    asyncio.run(
        _submit_inferlet_async(
            client_config,
            inferlet_path,
            arguments,
            server_handle,
            backend_processes,
            on_event,
        )
    )


async def _submit_inferlet_async(
    client_config: dict,
    inferlet_path: Path,
    arguments: list[str],
    server_handle: "_pie.ServerHandle | None" = None,
    backend_processes: list | None = None,
    on_event: Optional[callable] = None,
) -> None:
    """Async implementation of submit_inferlet_and_wait."""

    def emit(event_type: str, msg: str):
        if on_event:
            on_event(event_type, msg)
        else:
            print(msg)

    # Check inferlet exists
    if not inferlet_path.exists():
        raise FileNotFoundError(f"Inferlet not found: {inferlet_path}")

    # Read and hash the inferlet
    inferlet_blob = inferlet_path.read_bytes()
    program_hash = blake3.blake3(inferlet_blob).hexdigest()
    emit("info", f"Inferlet hash: {program_hash}")

    # Build the WebSocket URI
    host = client_config.get("host", "127.0.0.1")
    port = client_config.get("port", 8080)
    internal_token = client_config.get("internal_auth_token")
    server_uri = f"ws://{host}:{port}"

    # Start monitoring task if processes provided
    monitor_task = None
    if backend_processes:
        monitor_task = asyncio.create_task(
            _monitor_processes_task(server_handle, backend_processes)
        )

    try:
        async with PieClient(server_uri) as client:
            # Authenticate with internal token
            await client.internal_authenticate(internal_token)

            # Check if program already exists, upload if not
            if not await client.program_exists(program_hash):
                emit("info", "Uploading inferlet...")
                await client.upload_program(inferlet_blob)
            else:
                emit("info", "Inferlet already cached on server.")

            # Launch the instance
            emit("info", f"Launching {inferlet_path.name}...")
            instance = await client.launch_instance(
                program_hash=program_hash,
                arguments=arguments,
                detached=False,
            )
            emit("info", f"Instance launched: {instance.instance_id}")

            # Stream events until completion
            while True:
                recv_task = asyncio.create_task(instance.recv())
                tasks = [recv_task]
                if monitor_task:
                    tasks.append(monitor_task)

                done, pending = await asyncio.wait(
                    tasks, return_when=asyncio.FIRST_COMPLETED
                )

                if monitor_task in done:
                    monitor_task.result()

                event, message = recv_task.result()

                if event == Event.Stdout:
                    print(message, end="", flush=True)
                elif event == Event.Stderr:
                    print(message, end="", file=sys.stderr, flush=True)
                elif event == Event.Message:
                    emit("message", f"[Message] {message}")
                elif event == Event.Completed:
                    emit("completed", f"{message}")
                    break
                elif event == Event.Aborted:
                    emit("aborted", f"⚠️ Instance aborted: {message}")
                    break
                elif event == Event.Exception:
                    emit("exception", f"❌ Instance exception: {message}")
                    break
                elif event == Event.ServerError:
                    emit("error", f"❌ Server error: {message}")
                    break
                elif event == Event.OutOfResources:
                    emit("error", f"❌ Out of resources: {message}")
                    break
                elif event == Event.Blob:
                    emit("blob", f"[Received blob: {len(message)} bytes]")
                else:
                    emit("unknown", f"[Unknown event {event}]: {message}")

    finally:
        if monitor_task:
            monitor_task.cancel()
            try:
                await monitor_task
            except asyncio.CancelledError:
                pass


async def _monitor_processes_task(
    server_handle: "_pie.ServerHandle | None",
    backend_processes: list | None,
):
    """Async task to monitor backend processes."""
    import asyncio

    if not backend_processes:
        return

    while True:
        if not check_backend_processes(backend_processes):
            raise RuntimeError("Backend process died")

        if server_handle and hasattr(server_handle, "is_running"):
            if not server_handle.is_running():
                raise RuntimeError("Engine process died")

        await asyncio.sleep(1.0)


def submit_inferlet_from_registry_and_wait(
    client_config: dict,
    inferlet_name: str,
    arguments: list[str],
    server_handle: "_pie.ServerHandle | None" = None,
    backend_processes: list | None = None,
    on_event: Optional[callable] = None,
) -> None:
    """Submit an inferlet from the registry and wait for it to finish.

    Args:
        client_config: Client configuration with host, port, internal_auth_token
        inferlet_name: Inferlet name (e.g., "std/text-completion@0.1.0")
        arguments: Arguments to pass to the inferlet
        server_handle: Optional server handle for process monitoring
        backend_processes: Optional list of backend processes to monitor
        on_event: Optional callback for events: (event_type: str, message: str) -> None
    """
    import asyncio

    asyncio.run(
        _submit_inferlet_from_registry_async(
            client_config,
            inferlet_name,
            arguments,
            server_handle,
            backend_processes,
            on_event,
        )
    )


async def _submit_inferlet_from_registry_async(
    client_config: dict,
    inferlet_name: str,
    arguments: list[str],
    server_handle: "_pie.ServerHandle | None" = None,
    backend_processes: list | None = None,
    on_event: Optional[callable] = None,
) -> None:
    """Async implementation of submit_inferlet_from_registry_and_wait."""
    import asyncio
    from pie_client import PieClient, Event

    def emit(event_type: str, msg: str):
        if on_event:
            on_event(event_type, msg)
        else:
            print(msg)

    # Build the WebSocket URI
    host = client_config.get("host", "127.0.0.1")
    port = client_config.get("port", 8080)
    internal_token = client_config.get("internal_auth_token")
    server_uri = f"ws://{host}:{port}"

    # Start monitoring task if processes provided
    monitor_task = None
    if backend_processes:
        monitor_task = asyncio.create_task(
            _monitor_processes_task(server_handle, backend_processes)
        )

    try:
        async with PieClient(server_uri) as client:
            # Authenticate with internal token
            await client.internal_authenticate(internal_token)

            # Launch the instance from registry
            instance = await client.launch_instance_from_registry(
                inferlet=inferlet_name,
                arguments=arguments,
                detached=False,
            )

            # Stream events until completion
            while True:
                recv_task = asyncio.create_task(instance.recv())
                tasks = [recv_task]
                if monitor_task:
                    tasks.append(monitor_task)

                done, pending = await asyncio.wait(
                    tasks, return_when=asyncio.FIRST_COMPLETED
                )

                if monitor_task in done:
                    monitor_task.result()

                event, message = recv_task.result()

                if event == Event.Stdout:
                    print(message, end="", flush=True)
                elif event == Event.Stderr:
                    print(message, end="", file=sys.stderr, flush=True)
                elif event == Event.Message:
                    emit("message", f"[Message] {message}")
                elif event == Event.Completed:
                    emit("completed", f"{message}")
                    break
                elif event == Event.Aborted:
                    emit("aborted", f"⚠️ Instance aborted: {message}")
                    break
                elif event == Event.Exception:
                    emit("exception", f"❌ Instance exception: {message}")
                    break
                elif event == Event.ServerError:
                    emit("error", f"❌ Server error: {message}")
                    break
                elif event == Event.OutOfResources:
                    emit("error", f"❌ Out of resources: {message}")
                    break
                elif event == Event.Blob:
                    emit("blob", f"[Received blob: {len(message)} bytes]")
                else:
                    emit("unknown", f"[Unknown event {event}]: {message}")
    except Exception:
        if monitor_task and not monitor_task.done():
            monitor_task.cancel()
        raise
