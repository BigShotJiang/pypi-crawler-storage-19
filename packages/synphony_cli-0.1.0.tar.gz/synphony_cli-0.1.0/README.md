# Synphony CLI

Command line interface for the Synphony robotics data platform.

## Installation

```bash
pip install synphony-cli
```

Or with pipx (recommended):

```bash
pipx install synphony-cli
```

## Quick Start

1. Get your API token from [synphony.co/settings](https://synphony.co/settings)

2. Authenticate:
```bash
synphony auth <your-token>
```

3. Initialize a project:
```bash
# Link to existing dataset
synphony init "My Dataset"

# Or create a new dataset
synphony init --new
synphony init --new "My New Dataset"
```

4. Process videos (uploads and generates augmented data):
```bash
synphony multiply *.mp4 -p "change lighting" -p "add motion blur"
```

5. Check status:
```bash
synphony status
```

6. Download results:
```bash
synphony pull
```

## Commands

| Command | Description |
|---------|-------------|
| `synphony auth <token>` | Authenticate with your API token |
| `synphony login` | Login via browser (alternative to auth) |
| `synphony whoami` | Show current authentication status |
| `synphony init <name>` | Link to existing dataset |
| `synphony init --new [name]` | Create a new dataset |
| `synphony list` | List all your datasets |
| `synphony multiply` | Upload videos and generate augmented data |
| `synphony status` | Check processing status |
| `synphony pull` | Download generated files |
| `synphony --version` | Show CLI version |

## Links

- [Website](https://synphony.co)
- [Documentation](https://docs.synphony.co)
