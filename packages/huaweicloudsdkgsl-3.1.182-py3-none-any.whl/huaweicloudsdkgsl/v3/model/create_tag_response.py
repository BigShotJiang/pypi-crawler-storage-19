# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateTagResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'int',
        'tag_name': 'str',
        'status': 'int'
    }

    attribute_map = {
        'id': 'id',
        'tag_name': 'tag_name',
        'status': 'status'
    }

    def __init__(self, id=None, tag_name=None, status=None):
        r"""CreateTagResponse

        The model defined in huaweicloud sdk

        :param id: 标签标识
        :type id: int
        :param tag_name: 标签名称
        :type tag_name: str
        :param status: 标签状态，0未使用，1使用中。
        :type status: int
        """
        
        super().__init__()

        self._id = None
        self._tag_name = None
        self._status = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if tag_name is not None:
            self.tag_name = tag_name
        if status is not None:
            self.status = status

    @property
    def id(self):
        r"""Gets the id of this CreateTagResponse.

        标签标识

        :return: The id of this CreateTagResponse.
        :rtype: int
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CreateTagResponse.

        标签标识

        :param id: The id of this CreateTagResponse.
        :type id: int
        """
        self._id = id

    @property
    def tag_name(self):
        r"""Gets the tag_name of this CreateTagResponse.

        标签名称

        :return: The tag_name of this CreateTagResponse.
        :rtype: str
        """
        return self._tag_name

    @tag_name.setter
    def tag_name(self, tag_name):
        r"""Sets the tag_name of this CreateTagResponse.

        标签名称

        :param tag_name: The tag_name of this CreateTagResponse.
        :type tag_name: str
        """
        self._tag_name = tag_name

    @property
    def status(self):
        r"""Gets the status of this CreateTagResponse.

        标签状态，0未使用，1使用中。

        :return: The status of this CreateTagResponse.
        :rtype: int
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this CreateTagResponse.

        标签状态，0未使用，1使用中。

        :param status: The status of this CreateTagResponse.
        :type status: int
        """
        self._status = status

    def to_dict(self):
        import warnings
        warnings.warn("CreateTagResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateTagResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
