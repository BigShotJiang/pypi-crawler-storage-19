# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowMonthUsageReq:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'sim_card_ids': 'list[int]',
        'iccids': 'list[str]',
        'billing_cycles': 'list[str]'
    }

    attribute_map = {
        'sim_card_ids': 'sim_card_ids',
        'iccids': 'iccids',
        'billing_cycles': 'billing_cycles'
    }

    def __init__(self, sim_card_ids=None, iccids=None, billing_cycles=None):
        r"""ShowMonthUsageReq

        The model defined in huaweicloud sdk

        :param sim_card_ids: sim卡id列表，最多支持传入500个SIM卡id。sim_card_ids与iccids不能同时为空，sim_card_ids参数为空则根据iccids参数处理
        :type sim_card_ids: list[int]
        :param iccids: iccid列表，最多支持传入500个iccid。sim_card_ids与iccids不能同时为空，sim_card_ids参数为空则根据iccids参数处理
        :type iccids: list[str]
        :param billing_cycles: 账期，最多支持传入本月在内的6个月账期，例如[2022-07, 2022-06]，不支持传入未来账期。
        :type billing_cycles: list[str]
        """
        
        

        self._sim_card_ids = None
        self._iccids = None
        self._billing_cycles = None
        self.discriminator = None

        if sim_card_ids is not None:
            self.sim_card_ids = sim_card_ids
        if iccids is not None:
            self.iccids = iccids
        self.billing_cycles = billing_cycles

    @property
    def sim_card_ids(self):
        r"""Gets the sim_card_ids of this ShowMonthUsageReq.

        sim卡id列表，最多支持传入500个SIM卡id。sim_card_ids与iccids不能同时为空，sim_card_ids参数为空则根据iccids参数处理

        :return: The sim_card_ids of this ShowMonthUsageReq.
        :rtype: list[int]
        """
        return self._sim_card_ids

    @sim_card_ids.setter
    def sim_card_ids(self, sim_card_ids):
        r"""Sets the sim_card_ids of this ShowMonthUsageReq.

        sim卡id列表，最多支持传入500个SIM卡id。sim_card_ids与iccids不能同时为空，sim_card_ids参数为空则根据iccids参数处理

        :param sim_card_ids: The sim_card_ids of this ShowMonthUsageReq.
        :type sim_card_ids: list[int]
        """
        self._sim_card_ids = sim_card_ids

    @property
    def iccids(self):
        r"""Gets the iccids of this ShowMonthUsageReq.

        iccid列表，最多支持传入500个iccid。sim_card_ids与iccids不能同时为空，sim_card_ids参数为空则根据iccids参数处理

        :return: The iccids of this ShowMonthUsageReq.
        :rtype: list[str]
        """
        return self._iccids

    @iccids.setter
    def iccids(self, iccids):
        r"""Sets the iccids of this ShowMonthUsageReq.

        iccid列表，最多支持传入500个iccid。sim_card_ids与iccids不能同时为空，sim_card_ids参数为空则根据iccids参数处理

        :param iccids: The iccids of this ShowMonthUsageReq.
        :type iccids: list[str]
        """
        self._iccids = iccids

    @property
    def billing_cycles(self):
        r"""Gets the billing_cycles of this ShowMonthUsageReq.

        账期，最多支持传入本月在内的6个月账期，例如[2022-07, 2022-06]，不支持传入未来账期。

        :return: The billing_cycles of this ShowMonthUsageReq.
        :rtype: list[str]
        """
        return self._billing_cycles

    @billing_cycles.setter
    def billing_cycles(self, billing_cycles):
        r"""Sets the billing_cycles of this ShowMonthUsageReq.

        账期，最多支持传入本月在内的6个月账期，例如[2022-07, 2022-06]，不支持传入未来账期。

        :param billing_cycles: The billing_cycles of this ShowMonthUsageReq.
        :type billing_cycles: list[str]
        """
        self._billing_cycles = billing_cycles

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowMonthUsageReq):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
