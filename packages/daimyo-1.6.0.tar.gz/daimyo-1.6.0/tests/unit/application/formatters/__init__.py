"""Tests for formatter modules."""
