"""Tests for reminix.client"""
