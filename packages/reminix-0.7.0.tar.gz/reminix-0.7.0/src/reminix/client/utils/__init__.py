"""
Client utilities
"""
