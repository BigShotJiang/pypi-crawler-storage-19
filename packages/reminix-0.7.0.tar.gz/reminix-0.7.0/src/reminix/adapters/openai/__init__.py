"""
OpenAI SDK Adapter

Wrap OpenAI SDK clients for use with the Reminix runtime.

Example::

    from openai import AsyncOpenAI
    from reminix.adapters.openai import from_openai
    from reminix.runtime import serve

    client = AsyncOpenAI()
    agent = from_openai(client, name="gpt4-agent", model="gpt-4o")

    serve(agent)
"""

from .client import from_openai

__all__ = ["from_openai"]
