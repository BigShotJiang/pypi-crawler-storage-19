"""
Anthropic SDK Adapter

Wrap Anthropic SDK clients for use with the Reminix runtime.

Example::

    from anthropic import AsyncAnthropic
    from reminix.adapters.anthropic import from_anthropic
    from reminix.runtime import serve

    client = AsyncAnthropic()
    agent = from_anthropic(client, name="claude-agent", model="claude-sonnet-4-20250514")

    serve(agent)
"""

from .client import from_anthropic

__all__ = ["from_anthropic"]
