"""
LangGraph Adapter

Wrap LangGraph stateful workflows for use with the Reminix runtime.

Example::

    from langgraph.graph import StateGraph, START, END
    from reminix.adapters.langgraph import from_compiled_graph
    from reminix.runtime import serve

    # Build and compile your graph
    graph = (
        StateGraph(State)
        .add_node("process", process_node)
        .add_edge(START, "process")
        .add_edge("process", END)
        .compile()
    )

    # Wrap and serve
    reminix_agent = from_compiled_graph(graph, name="my-workflow")
    serve(reminix_agent)
"""

from .compiled_graph import from_compiled_graph

__all__ = [
    "from_compiled_graph",
]
