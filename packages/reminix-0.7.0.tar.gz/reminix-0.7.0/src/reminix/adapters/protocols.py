"""
Protocol types for adapter compatibility.

These protocols define the minimal interface required by each adapter.
Any client that satisfies the protocol will work, enabling duck-typed
type safety without hard dependencies on the underlying frameworks.

Usage::

    from reminix.adapters.protocols import OpenAIClientProtocol

    def my_function(client: OpenAIClientProtocol) -> None:
        # Type checker knows client.chat.completions.create exists
        ...
"""

from typing import Any, AsyncContextManager, AsyncIterator, Protocol, runtime_checkable


# =============================================================================
# OpenAI Protocols
# =============================================================================


class OpenAIMessage(Protocol):
    """Protocol for OpenAI message response."""

    content: str | None


class OpenAIChoice(Protocol):
    """Protocol for OpenAI completion choice."""

    message: OpenAIMessage


class OpenAIDelta(Protocol):
    """Protocol for OpenAI streaming delta."""

    content: str | None


class OpenAIStreamChoice(Protocol):
    """Protocol for OpenAI streaming choice."""

    delta: OpenAIDelta


class OpenAIStreamChunk(Protocol):
    """Protocol for OpenAI streaming chunk."""

    choices: list[OpenAIStreamChoice]


class OpenAICompletionResponse(Protocol):
    """Protocol for OpenAI completion response."""

    choices: list[OpenAIChoice]


class OpenAIChatCompletions(Protocol):
    """Protocol for OpenAI chat.completions interface."""

    async def create(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        stream: bool = False,
    ) -> OpenAICompletionResponse | AsyncIterator[OpenAIStreamChunk]: ...


class OpenAIChat(Protocol):
    """Protocol for OpenAI chat interface."""

    completions: OpenAIChatCompletions


@runtime_checkable
class OpenAIClientProtocol(Protocol):
    """
    Protocol for OpenAI-compatible async clients.

    Compatible with:
        - openai.AsyncOpenAI (openai >= 2.0.0)

    Example::

        from openai import AsyncOpenAI
        from reminix.adapters.openai import from_openai

        client = AsyncOpenAI()  # Satisfies OpenAIClientProtocol
        agent = from_openai(client, name="my-agent")
    """

    chat: OpenAIChat


# =============================================================================
# Anthropic Protocols
# =============================================================================


class AnthropicContentBlock(Protocol):
    """Protocol for Anthropic content block."""

    type: str
    text: str


class AnthropicMessageResponse(Protocol):
    """Protocol for Anthropic message response."""

    content: list[AnthropicContentBlock]


class AnthropicStreamManager(Protocol):
    """Protocol for Anthropic streaming context manager."""

    text_stream: AsyncIterator[str]

    async def __aenter__(self) -> "AnthropicStreamManager": ...

    async def __aexit__(self, *args: Any) -> None: ...


class AnthropicMessages(Protocol):
    """Protocol for Anthropic messages interface."""

    async def create(
        self,
        *,
        model: str,
        max_tokens: int,
        system: str,
        messages: list[dict[str, Any]],
    ) -> AnthropicMessageResponse: ...

    def stream(
        self,
        *,
        model: str,
        max_tokens: int,
        system: str,
        messages: list[dict[str, Any]],
    ) -> AsyncContextManager[AnthropicStreamManager]: ...


@runtime_checkable
class AnthropicClientProtocol(Protocol):
    """
    Protocol for Anthropic-compatible async clients.

    Compatible with:
        - anthropic.AsyncAnthropic (anthropic >= 0.75.0)

    Example::

        from anthropic import AsyncAnthropic
        from reminix.adapters.anthropic import from_anthropic

        client = AsyncAnthropic()  # Satisfies AnthropicClientProtocol
        agent = from_anthropic(client, name="my-agent")
    """

    messages: AnthropicMessages


# =============================================================================
# LangChain Protocols
# =============================================================================


class LangChainMessageContent(Protocol):
    """Protocol for LangChain message with content."""

    content: str


@runtime_checkable
class LangChainChatModelProtocol(Protocol):
    """
    Protocol for LangChain chat model.

    Compatible with:
        - langchain_openai.ChatOpenAI
        - langchain_anthropic.ChatAnthropic
        - Any BaseChatModel subclass

    Example::

        from langchain_openai import ChatOpenAI
        from reminix.adapters.langchain import from_chat_model

        llm = ChatOpenAI(model="gpt-4o")  # Satisfies LangChainChatModelProtocol
        agent = from_chat_model(llm, name="my-agent")
    """

    async def ainvoke(self, input: Any) -> LangChainMessageContent: ...

    def astream(self, input: Any) -> AsyncIterator[LangChainMessageContent]: ...


# =============================================================================
# LangGraph Protocols
# =============================================================================


@runtime_checkable
class LangGraphCompiledGraphProtocol(Protocol):
    """
    Protocol for LangGraph CompiledGraph.

    Compatible with:
        - langgraph.graph.CompiledGraph (result of StateGraph.compile())

    Example::

        from langgraph.graph import StateGraph, START, END
        from reminix.adapters.langgraph import from_compiled_graph

        graph = StateGraph(...).compile()  # Satisfies LangGraphCompiledGraphProtocol
        agent = from_compiled_graph(graph, name="my-agent")
    """

    async def ainvoke(self, input: dict[str, Any]) -> dict[str, Any]: ...

    def astream(
        self, input: dict[str, Any], *, stream_mode: str = "updates"
    ) -> AsyncIterator[dict[str, Any]]: ...


# =============================================================================
# LlamaIndex Protocols
# =============================================================================


@runtime_checkable
class LlamaIndexQueryEngineProtocol(Protocol):
    """
    Protocol for LlamaIndex QueryEngine.

    Compatible with:
        - llama_index.core.query_engine.BaseQueryEngine

    Example::

        from llama_index.core import VectorStoreIndex
        from reminix.adapters.llamaindex import from_query_engine

        index = VectorStoreIndex.from_documents(docs)
        query_engine = index.as_query_engine()  # Satisfies LlamaIndexQueryEngineProtocol
        agent = from_query_engine(query_engine, name="my-agent")
    """

    async def aquery(self, query: str) -> Any: ...


@runtime_checkable
class LlamaIndexChatEngineProtocol(Protocol):
    """
    Protocol for LlamaIndex ChatEngine.

    Compatible with:
        - llama_index.core.chat_engine.BaseChatEngine

    Example::

        from llama_index.core import VectorStoreIndex
        from reminix.adapters.llamaindex import from_chat_engine

        index = VectorStoreIndex.from_documents(docs)
        chat_engine = index.as_chat_engine()  # Satisfies LlamaIndexChatEngineProtocol
        agent = from_chat_engine(chat_engine, name="my-agent")
    """

    async def achat(self, message: str) -> Any: ...

    def reset(self) -> None: ...


@runtime_checkable
class LlamaIndexAgentProtocol(Protocol):
    """
    Protocol for LlamaIndex Agent (ReAct agent, etc.).

    Compatible with:
        - llama_index.core.agent.ReActAgent
        - llama_index.core.agent.OpenAIAgent
    """

    async def achat(self, message: str) -> Any: ...


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # OpenAI
    "OpenAIClientProtocol",
    "OpenAIChat",
    "OpenAIChatCompletions",
    "OpenAICompletionResponse",
    "OpenAIChoice",
    "OpenAIMessage",
    "OpenAIStreamChunk",
    "OpenAIStreamChoice",
    "OpenAIDelta",
    # Anthropic
    "AnthropicClientProtocol",
    "AnthropicMessages",
    "AnthropicMessageResponse",
    "AnthropicContentBlock",
    "AnthropicStreamManager",
    # LangChain
    "LangChainChatModelProtocol",
    "LangChainMessageContent",
    # LangGraph
    "LangGraphCompiledGraphProtocol",
    # LlamaIndex
    "LlamaIndexQueryEngineProtocol",
    "LlamaIndexChatEngineProtocol",
    "LlamaIndexAgentProtocol",
]
