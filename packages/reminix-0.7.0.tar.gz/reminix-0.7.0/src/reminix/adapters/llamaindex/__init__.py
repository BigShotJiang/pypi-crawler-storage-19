"""
LlamaIndex Adapter

Wrap LlamaIndex query engines, chat engines, and agents for use with the Reminix runtime.

Example::

    from llama_index.core import VectorStoreIndex, SimpleDirectoryReader
    from reminix.adapters.llamaindex import from_query_engine, from_chat_engine
    from reminix.runtime import serve

    # Load documents and create an index
    documents = SimpleDirectoryReader("data").load_data()
    index = VectorStoreIndex.from_documents(documents)

    # Wrap a QueryEngine for simple Q&A
    query_engine = index.as_query_engine()
    agent = from_query_engine(query_engine, name="docs-qa")

    # Or wrap a ChatEngine for conversational RAG
    chat_engine = index.as_chat_engine()
    agent = from_chat_engine(chat_engine, name="docs-chat")

    serve(agent)
"""

from .agent import from_agent
from .chat_engine import from_chat_engine
from .query_engine import from_query_engine

__all__ = [
    "from_agent",
    "from_chat_engine",
    "from_query_engine",
]
