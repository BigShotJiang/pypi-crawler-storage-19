"""
LangChain Chat Model Adapter

Wraps a LangChain chat model for use with the Reminix runtime.

Compatibility:
    langchain-core >= 1.0.0
"""

from __future__ import annotations

from typing import Any

from ..protocols import LangChainChatModelProtocol
from reminix.runtime import Agent


def from_chat_model(
    model: LangChainChatModelProtocol,
    *,
    name: str,
    metadata: dict[str, Any] | None = None,
) -> Agent:
    """
    Create a Reminix Agent from a LangChain chat model.

    This is the simplest adapter - wraps a chat model directly without
    any chain or agent logic.

    Args:
        model: A LangChain chat model instance (ChatOpenAI, ChatAnthropic, etc.).
        name: Name for the Reminix agent.
        metadata: Optional metadata for the agent.

    Returns:
        A Reminix Agent that wraps the chat model.

    Example::

        from langchain_openai import ChatOpenAI
        from reminix.adapters.langchain import from_chat_model
        from reminix.runtime import serve

        # Create chat model
        llm = ChatOpenAI(model="gpt-4o")

        # Wrap and serve
        reminix_agent = from_chat_model(llm, name="gpt4-chat")
        serve(reminix_agent)
    """
    agent = Agent(
        name,
        metadata={
            "framework": "langchain",
            "adapter": "chat_model",
            **(metadata or {}),
        },
    )

    @agent.invoke  # type: ignore[arg-type]
    async def handle_invoke(input_data: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
        """Non-streaming invoke via LangChain chat model."""
        # Extract prompt from input
        prompt = input_data.get("prompt") or input_data.get("input") or str(input_data)
        result = await model.ainvoke(prompt)
        return {"output": _extract_content(result)}

    @agent.invoke_stream  # type: ignore[arg-type]
    async def handle_invoke_stream(input_data: dict[str, Any], ctx: dict[str, Any]):
        """Streaming invoke via LangChain chat model."""
        prompt = input_data.get("prompt") or input_data.get("input") or str(input_data)
        async for chunk in model.astream(prompt):
            content = _extract_content(chunk)
            if content:
                yield {"chunk": content}

    @agent.chat  # type: ignore[arg-type]
    async def handle_chat(messages: list[dict[str, Any]], ctx: dict[str, Any]) -> dict[str, Any]:
        """Non-streaming chat via LangChain chat model."""
        lc_messages = _convert_messages(messages)
        result = await model.ainvoke(lc_messages)
        return {"message": {"role": "assistant", "content": _extract_content(result)}}

    @agent.chat_stream  # type: ignore[arg-type]
    async def handle_chat_stream(messages: list[dict[str, Any]], ctx: dict[str, Any]):
        """Streaming chat via LangChain chat model."""
        lc_messages = _convert_messages(messages)
        async for chunk in model.astream(lc_messages):
            content = _extract_content(chunk)
            if content:
                yield {"chunk": content}

    return agent


def _extract_content(result: Any) -> str:
    """Extract string content from a LangChain message or chunk."""
    if isinstance(result, str):
        return result
    if hasattr(result, "content"):
        return str(result.content) if result.content else ""
    return str(result)


def _convert_messages(messages: list[dict[str, Any]]) -> list[Any]:
    """Convert Reminix messages to LangChain message format."""
    try:
        from langchain_core.messages import (  # type: ignore[import-not-found]
            AIMessage,
            HumanMessage,
            SystemMessage,
        )
    except ImportError as e:
        raise ImportError(
            "langchain-core is required for the LangChain adapter. "
            "Install it with: pip install langchain-core"
        ) from e

    lc_messages: list[Any] = []
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")

        if role == "system":
            lc_messages.append(SystemMessage(content=content))
        elif role == "user":
            lc_messages.append(HumanMessage(content=content))
        elif role == "assistant":
            lc_messages.append(AIMessage(content=content))

    return lc_messages
