"""
LangChain Adapter

Wrap LangChain agents and chat models for use with the Reminix runtime.

Example::

    from langchain.agents import create_agent
    from langchain_openai import ChatOpenAI
    from reminix.adapters.langchain import (
        from_langchain_agent,
        from_agent_executor,
        from_chat_model,
    )
    from reminix.runtime import serve

    # Wrap a modern LangChain agent (recommended)
    agent = create_agent(model="openai:gpt-4o", tools=[...])
    reminix_agent = from_langchain_agent(agent, name="smart-agent")

    # Or wrap a legacy AgentExecutor
    executor = AgentExecutor(agent=agent, tools=tools)
    reminix_agent = from_agent_executor(executor, name="my-agent")

    # Or wrap a simple chat model
    llm = ChatOpenAI(model="gpt-4o")
    reminix_agent = from_chat_model(llm, name="gpt4-chat")

    serve(reminix_agent)
"""

from .agent import from_langchain_agent
from .agent_executor import from_agent_executor
from .chat_model import from_chat_model

__all__ = [
    "from_langchain_agent",
    "from_agent_executor",
    "from_chat_model",
]
