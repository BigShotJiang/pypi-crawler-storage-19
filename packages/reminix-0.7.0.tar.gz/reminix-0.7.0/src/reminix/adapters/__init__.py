"""
Reminix Adapters

Adapters for integrating popular AI agent frameworks with the Reminix runtime.

Available adapters:
- anthropic: Anthropic SDK clients
- langchain: LangChain agents and runnables
- langgraph: LangGraph stateful workflows
- llamaindex: LlamaIndex query engines, chat engines, and agents
- openai: OpenAI SDK clients

Protocol types are available for type-safe duck typing without hard dependencies::

    from reminix.adapters.protocols import OpenAIClientProtocol

Install adapter dependencies with extras::

    pip install reminix[openai]          # Just OpenAI
    pip install reminix[langchain]       # Just LangChain
    pip install reminix[adapters]        # All adapters
    pip install reminix[all]             # Everything including runtime
"""

from . import anthropic, langchain, langgraph, llamaindex, openai, protocols

__all__ = [
    "anthropic",
    "langchain",
    "langgraph",
    "llamaindex",
    "openai",
    "protocols",
]
