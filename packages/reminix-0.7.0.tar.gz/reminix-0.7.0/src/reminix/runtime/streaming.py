"""
Reminix Streaming Utilities

SSE (Server-Sent Events) streaming utilities for the Reminix runtime.
"""

import json
from collections.abc import AsyncGenerator, Mapping
from typing import Any

from .types import StreamChunk


def format_sse_event(data: Mapping[str, Any]) -> str:
    """
    Format a single SSE event.

    Args:
        data: The data to send.

    Returns:
        SSE-formatted string.
    """
    return f"data: {json.dumps(data)}\n\n"


def format_sse_done() -> str:
    """
    Format the SSE done marker.

    Returns:
        SSE done marker string.
    """
    return "data: [DONE]\n\n"


async def stream_to_sse(
    generator: AsyncGenerator[StreamChunk, None],
) -> AsyncGenerator[str, None]:
    """
    Convert an async generator of StreamChunks to SSE format.

    Args:
        generator: Async generator yielding StreamChunk dicts.

    Yields:
        SSE-formatted strings (e.g., "data: {...}\\n\\n").
    """
    try:
        async for chunk in generator:
            # Validate chunk structure
            if not isinstance(chunk, dict) or "chunk" not in chunk:
                error_msg = {"error": "Invalid chunk: missing 'chunk' field"}
                yield format_sse_event(error_msg)
                yield format_sse_done()
                return

            if not isinstance(chunk["chunk"], str):
                error_msg = {"error": "Invalid chunk: 'chunk' must be a string"}
                yield format_sse_event(error_msg)
                yield format_sse_done()
                return

            # Valid chunk - send it
            yield format_sse_event(chunk)

        # End of stream
        yield format_sse_done()

    except Exception as e:
        # Handle errors during streaming
        error_msg = {"error": f"Stream error: {e!s}"}
        yield format_sse_event(error_msg)
        yield format_sse_done()
