# -*- coding: utf-8 -*-
# test\test_electroacoustics.py

# License: GNU GPL v3.0
# Copyright (c) 2026 Christos Sevastiadis
# Author: Christos Sevastiadis <csevast@auth.gr>
"""Test script for Electroacoustics-AUTH package."""
from electroacoustics.init_ipynb import *
ea.oct_frq(x=np.arange(-5, 5), b=1, ret_type="pandas")
