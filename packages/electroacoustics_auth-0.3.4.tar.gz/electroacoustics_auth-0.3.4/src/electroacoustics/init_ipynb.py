# -*- coding: utf-8 -*-
# src\electroacoustics\init_ipynb.py

# License: GNU GPL v3.0
# Copyright (c) 2026 Christos Sevastiadis
# Author: Christos Sevastiadis <csevast@auth.gr>
"""
    Electroacoustics-AUTH package Jupyter Notebooks support module.

    Provides the essential imports and settings for running the Jupyter Notbooks for
    the Electroacoustics courses of Aristotle University of Thessaloniki. I imports the
    electroacoustics module of the the Electroacoustics-AUTH package, NumPy, Pandas,
    Matplotlib, etc.

    Usage:
    Insert at the first Python cell of the Jupyter Notebook the following code:
    from electroacoustics.init_ipynb import *

"""
import warnings
import electroacoustics as ea
import numpy as np
import pandas as pd
from IPython.display import Latex as lt
from IPython.display import HTML, Markdown, Math, display
from matplotlib import pyplot as plt
from matplotlib import rc
from pandas.io.formats.style import Styler

rc("text", usetex=True)
