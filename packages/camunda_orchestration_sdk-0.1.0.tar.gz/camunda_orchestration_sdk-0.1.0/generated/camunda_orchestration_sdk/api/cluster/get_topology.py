from http import HTTPStatus
from typing import Any
import httpx
from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_topology_response_200 import GetTopologyResponse200
from ...models.get_topology_response_401 import GetTopologyResponse401
from ...models.get_topology_response_500 import GetTopologyResponse500
from ...types import Response

def _get_kwargs() -> dict[str, Any]:
    _kwargs: dict[str, Any] = {'method': 'get', 'url': '/topology'}
    return _kwargs

def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500 | None:
    if response.status_code == 200:
        response_200 = GetTopologyResponse200.from_dict(response.json())
        return response_200
    if response.status_code == 401:
        response_401 = GetTopologyResponse401.from_dict(response.json())
        return response_401
    if response.status_code == 500:
        response_500 = GetTopologyResponse500.from_dict(response.json())
        return response_500
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None

def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))

def sync_detailed(*, client: AuthenticatedClient | Client) -> Response[GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500]:
    """Get cluster topology

     Obtains the current topology of the cluster the gateway is part of.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500]
    """
    kwargs = _get_kwargs()
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)

def sync(*, client: AuthenticatedClient | Client, **kwargs) -> GetTopologyResponse200:
    """Get cluster topology

 Obtains the current topology of the cluster the gateway is part of.

Raises:
    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
    httpx.TimeoutException: If the request takes longer than Client.timeout.

Returns:
    Response[GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500]"""
    response = sync_detailed(client=client)
    if response.status_code < 200 or response.status_code >= 300:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return response.parsed

async def asyncio_detailed(*, client: AuthenticatedClient | Client) -> Response[GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500]:
    """Get cluster topology

     Obtains the current topology of the cluster the gateway is part of.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500]
    """
    kwargs = _get_kwargs()
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)

async def asyncio(*, client: AuthenticatedClient | Client, **kwargs) -> GetTopologyResponse200:
    """Get cluster topology

 Obtains the current topology of the cluster the gateway is part of.

Raises:
    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
    httpx.TimeoutException: If the request takes longer than Client.timeout.

Returns:
    Response[GetTopologyResponse200 | GetTopologyResponse401 | GetTopologyResponse500]"""
    response = await asyncio_detailed(client=client)
    if response.status_code < 200 or response.status_code >= 300:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return response.parsed