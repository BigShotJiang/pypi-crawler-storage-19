"""Data loader for beamline 5-2 at SSRL."""

__all__ = ["SSRL52Loader"]

import datetime
import os
import re
import typing
from collections.abc import Callable, Hashable

import numpy as np
import xarray as xr

import erlab
from erlab.io.dataloader import LoaderBase


def _format_polarization(val) -> str:
    val = float(np.round(val, 3))
    return {0.0: "LH", 0.5: "LV", 0.25: "RC", -0.25: "LC"}.get(val, str(val))


def _parse_value(value):
    if isinstance(value, np.generic):
        return value.item()
    return value


def _find_group_for_key(dt: xr.DataTree, name: str) -> xr.DataTree | None:
    target = name.casefold()
    for k, v in dt.items():
        if str(k).casefold() == target and isinstance(v, xr.DataTree):
            return v
    return None


class SSRL52Loader(LoaderBase):
    name = "ssrl52"
    description = "SSRL Beamline 5-2"
    extensions: typing.ClassVar[set[str]] = {".h5"}

    aliases = ("ssrl", "bl5-2")

    name_map: typing.ClassVar[dict] = {
        "eV": ["Kinetic Energy", "Binding Energy"],
        "alpha": "ThetaX",
        "beta": ["ThetaY", "YDeflection", "DeflectionY"],
        "delta": ["A", "a"],  # azi
        "chi": ["T", "t"],  # polar
        "xi": ["F", "f"],  # tilt
        "x": "X",
        "y": "Y",
        "z": "Z",
        "hv": ["energy", "photon_energy"],
        "sample_temp": ["TB", "sample_stage_temperature"],
        "sample_workfunction": "WorkFunction",
    }

    coordinate_attrs = (
        "beta",
        "delta",
        "chi",
        "xi",
        "hv",
        "x",
        "y",
        "z",
        "polarization",
        "sample_temp",
    )

    additional_attrs: typing.ClassVar[dict] = {
        "configuration": 3,
    }

    formatters: typing.ClassVar[dict[str, Callable]] = {
        "CreationTimeStamp": datetime.datetime.fromtimestamp,
        "PassEnergy": round,
        "polarization": _format_polarization,
    }

    summary_attrs: typing.ClassVar[
        dict[str, str | Callable[[xr.DataArray], typing.Any]]
    ] = {
        "time": "CreationTimeStamp",
        "type": "Description",
        "lens mode": "LensModeName",
        "region": "RegionName",
        "temperature": "sample_temp",
        "pass energy": "PassEnergy",
        "pol": "polarization",
        "hv": "hv",
        "polar": "chi",
        "tilt": "xi",
        "azi": "delta",
        "deflector": "beta",
        "x": "x",
        "y": "y",
        "z": "z",
    }

    summary_sort = "time"

    always_single: bool = True
    skip_validate: bool = True

    @property
    def file_dialog_methods(self):
        return {"SSRL BL5-2 Raw Data (*.h5)": (self.load, {})}

    def load_single(
        self,
        file_path: str | os.PathLike,
        *,
        without_values: bool = False,
        chunks: int | dict | typing.Literal["auto"] | tuple[int, ...] | None = None,
    ) -> xr.DataArray:
        is_hvdep: bool = False

        dt = xr.open_datatree(
            file_path, engine="h5netcdf", phony_dims="sort", chunks=chunks
        )

        compat_mode: bool = "/data" in dt.groups

        # Combine top-level attributes
        attrs: dict[Hashable, typing.Any] = dt.attrs.copy()
        for ds in dt.values():
            attrs |= {k: _parse_value(v) for k, v in ds.attrs.items()}

        data = _find_group_for_key(dt, "Data")
        if data is None:
            data = _find_group_for_key(dt, "Camera")
        if data is None:
            raise KeyError("Data group not found in SSRL 5-2 file")

        mapinfo: xr.DataTree | None = _find_group_for_key(dt, "MapInfo")

        # Normalize variable names
        time_var_name: str = "time"
        if compat_mode:
            count_var_name: str = "counts"
            if "exposure" in data.variables:
                time_var_name = "exposure"
        else:
            count_var_name = "Count"
            if "Time" in data.variables:
                time_var_name = "Time"

        # List of dicts containing scale and label info for each axis
        # Unify case for compatibility with old data
        axes: list[dict[str, float | int | str]] = [
            {str(name).lower(): val for name, val in v.attrs.items()}
            for v in data.children.values()
        ]

        # Apply dim labels
        dim_mapping = {f"phony_dim_{i}": str(ax["label"]) for i, ax in enumerate(axes)}

        ds = data.dataset.rename_dims(dim_mapping)

        for ax in axes:
            cnt = ds.sizes[ax["label"]]
            if "centerpixel" in ax:
                offset = float(ax["centerpixel"])
                delta = 1.0
                count_var_name = "Image"
            elif isinstance(ax["offset"], str):
                if mapinfo is None:
                    raise RuntimeError
                if ax["label"] == "energy":
                    ds = ds.assign_coords(
                        {ax["label"]: mapinfo["Beamline:energy"].data}
                    )
                    # Axes2 may have some values... not sure what they are
                    # For now, just ignore them and use beamline attributes
                    continue
                if ax["label"] != "Kinetic Energy":
                    erlab.utils.misc.emit_user_level_warning(
                        "Undefined offset for non-energy axis. This was "
                        "not taken into account while writing the loader "
                        "code. Please report this issue. Resulting data "
                        "may be incorrect"
                    )
                    continue
                is_hvdep = True

                # For hv dep scans, EKin is given for each scan
                ds = ds.rename({ax["label"]: "Binding Energy"})
                ax["label"] = "Binding Energy"

                # ax['offset'] will be something like:
                # "MapInfo:Data:Axes0:Offset"
                offset_key: str = ax["offset"][8:]

                # Take first kinetic energy
                offset = np.array(mapinfo[offset_key])[0]

                if isinstance(ax["delta"], str):
                    deltas = np.array(mapinfo[ax["delta"][8:]])
                    # may be ~1e-8 difference between values
                    if not np.allclose(deltas, deltas[0], atol=1e-7):
                        erlab.utils.misc.emit_user_level_warning(
                            "Non-uniform delta for hv-dependent scan. This "
                            "was not taken into account while writing the "
                            "loader code. Please report this issue. "
                            "Resulting data may be incorrect"
                        )
                    delta = deltas[0]
                else:
                    delta = float(ax["delta"])

            else:
                offset = float(ax["offset"])
                delta = float(ax["delta"])

            mn, mx = (offset, offset + (cnt - 1) * delta)
            coord = xr.DataArray(np.linspace(mn, mx, cnt), dims=[ax["label"]], attrs=ax)

            ds = ds.assign_coords({ax["label"]: coord})

        coord_attrs: dict[Hashable, typing.Any] = {}
        map_dims = tuple(
            v
            for v in dim_mapping.values()
            # Attributes should not be dependent on these dims
            if v not in ("ThetaX", "Kinetic Energy", "Binding Energy")
        )
        for k, v in dict(attrs).items():
            if isinstance(v, str) and v.startswith("MapInfo:"):
                if mapinfo is None:
                    raise RuntimeError
                del attrs[k]
                if k not in map_dims:
                    coord_da = mapinfo[v[8:]]
                    coord_attrs[k] = coord_da.rename(
                        {d: map_dims[i] for i, d in enumerate(coord_da.dims)}
                    )

        if is_hvdep:
            ds = ds.assign_coords(
                {
                    "Binding Energy": ds["Binding Energy"]
                    - ds["energy"].values[0]
                    + attrs.get("WorkFunction", 4.465)
                }
            )

            # ds = ds.rename(energy="hv")

        darr = ds[count_var_name].rename(
            dt.attrs.get("FileName", "").removesuffix(".h5")
        )

        if without_values:
            darr = xr.DataArray(
                np.zeros(darr.shape, darr.dtype),
                coords=darr.coords,
                dims=darr.dims,
                attrs=darr.attrs,
                name=darr.name,
            )
        elif time_var_name in data.variables:
            # Normalize by dwell time
            dwell_time = ds[time_var_name]
            darr = darr.where(dwell_time > 0) / dwell_time.clip(min=1e-15)

        darr = darr.assign_attrs(attrs)

        return darr.assign_coords(coord_attrs)

    def post_process(self, data: xr.DataArray) -> xr.DataArray:
        data = super().post_process(data)

        # Convert to binding energy
        if (
            "sample_workfunction" in data.attrs
            and "eV" in data.dims
            and data["eV"].min() > 0
        ):
            data = data.assign_coords(
                eV=data["eV"] - float(data["hv"]) + data.attrs["sample_workfunction"]
            )

        return data

    def identify(self, num: int, data_dir: str | os.PathLike, zap: bool = False):
        if zap:
            target_files = erlab.io.utils.get_files(data_dir, ".h5", contains="zap")
        else:
            target_files = erlab.io.utils.get_files(data_dir, ".h5", notcontains="zap")

        pattern = re.compile(r"(.*?)_" + str(num).zfill(4) + r".h5")
        matches = [path for path in target_files if pattern.match(path.name)]

        return matches, {}

    def load_zap(self, identifier, data_dir):
        return self.load(identifier, data_dir, zap=True)

    def files_for_summary(self, data_dir):
        return sorted(erlab.io.utils.get_files(data_dir, extensions=(".h5",)))
