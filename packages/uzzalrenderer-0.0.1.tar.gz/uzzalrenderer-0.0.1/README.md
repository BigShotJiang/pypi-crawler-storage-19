# Uzzal_Renderer_Pypi_package

## How to run 
## Crate Conda Envirnment

```bash
conda create -n pypy python=3.8 -y

conda activate pypy

pip install -r requirements_dev.txt

```