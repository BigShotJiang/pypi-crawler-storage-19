from pprint import pformat
import os
import sys
from difflib import SequenceMatcher
from .. import logs, types, const
from ..conf import settings
from ..corrector import get_corrected_commands
from ..exceptions import EmptyCommand
from ..ui import select_command
from ..utils import get_alias, get_all_executables


def _get_raw_command(known_args):
    if known_args.force_command:
        return [known_args.force_command]
    elif known_args.command:
        return known_args.command
    elif os.environ.get('TMD_HISTORY'):
        # 如果通过别名调用，使用环境变量中的历史
        history = os.environ['TMD_HISTORY'].split('\n')[::-1]
        alias = get_alias()
        executables = get_all_executables()
        for command in history:
            diff = SequenceMatcher(a=alias, b=command).ratio()
            if diff < const.DIFF_WITH_ALIAS or command in executables:
                return [command]
    else:
        # 不使用别名：直接从 shell 历史文件读取上一个命令
        from ..shells import shell
        try:
            history = shell.get_history()
            if history:
                # 获取最后一个命令（排除 tmd 本身）
                alias = get_alias()
                executables = get_all_executables()
                for command in reversed(history[-10:]):  # 检查最近10条
                    if command and command.strip():
                        cmd_parts = command.strip().split()
                        if cmd_parts and cmd_parts[0] != alias:
                            if cmd_parts[0] in executables or any(cmd_parts[0] == exe for exe in executables):
                                return [command.strip()]
                # 如果没找到，返回最后一个非空命令
                for command in reversed(history[-10:]):
                    if command and command.strip() and command.strip() != alias:
                        return [command.strip()]
        except Exception as e:
            from .. import logs
            logs.debug(f'无法读取历史: {e}')
    return []


def fix_command(known_args):
    """Fixes previous command. Used when `thefuck` called without arguments."""
    settings.init(known_args)
    with logs.debug_time('Total'):
        logs.debug(u'Run with settings: {}'.format(pformat(settings)))
        raw_command = _get_raw_command(known_args)

        try:
            command = types.Command.from_raw_script(raw_command)
        except EmptyCommand:
            logs.debug('Empty command, nothing to do')
            return

        corrected_commands = get_corrected_commands(command)
        selected_command = select_command(corrected_commands)

        if selected_command:
            selected_command.run(command)
        else:
            sys.exit(1)
