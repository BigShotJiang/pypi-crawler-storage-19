.. automodapi:: fiasco
    :inherited-members:
