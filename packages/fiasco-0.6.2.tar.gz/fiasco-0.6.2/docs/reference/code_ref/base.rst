.. automodapi:: fiasco.base
