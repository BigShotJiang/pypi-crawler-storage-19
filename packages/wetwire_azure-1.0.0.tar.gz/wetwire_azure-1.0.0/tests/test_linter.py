"""Tests for linter functionality."""

import tempfile
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity, run_linter
from wetwire_azure.linter.rules.waz001_api_version import WAZ001ApiVersion


class TestLintResult:
    """Test LintResult dataclass."""

    def test_lint_result_creation(self):
        """Test LintResult can be created."""
        result = LintResult(
            rule_id="WAZ001",
            severity=LintSeverity.ERROR,
            message="Test message",
            file="test.py",
            line=10,
            column=5,
        )
        assert result.rule_id == "WAZ001"
        assert result.severity == LintSeverity.ERROR
        assert result.message == "Test message"
        assert result.file == "test.py"
        assert result.line == 10
        assert result.column == 5

    def test_lint_result_optional_column(self):
        """Test LintResult with no column specified."""
        result = LintResult(
            rule_id="WAZ001",
            severity=LintSeverity.WARNING,
            message="Test message",
            file="test.py",
            line=10,
        )
        assert result.column is None


class TestLintSeverity:
    """Test LintSeverity enum."""

    def test_severity_values(self):
        """Test severity enum values."""
        assert LintSeverity.ERROR.value == "error"
        assert LintSeverity.WARNING.value == "warning"
        assert LintSeverity.INFO.value == "info"


class TestLintRuleBase:
    """Test base LintRule class."""

    def test_base_rule_has_required_attributes(self):
        """Test base rule defines required interface."""
        # Test with a concrete implementation
        rule = WAZ001ApiVersion()
        assert hasattr(rule, "rule_id")
        assert hasattr(rule, "description")
        assert hasattr(rule, "severity")
        assert hasattr(rule, "check")
        assert callable(rule.check)


class TestWAZ001ApiVersion:
    """Test WAZ001 - Use typed API version constants."""

    def test_waz001_detects_string_api_version(self):
        """Test WAZ001 detects hardcoded string API versions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                '''from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    api_version="2023-03-01"
)
'''
            )

            results = run_linter(Path(tmpdir), rules=["WAZ001"])
            assert len(results) > 0
            assert any(r.rule_id == "WAZ001" for r in results)

    def test_waz001_allows_constant_api_version(self):
        """Test WAZ001 allows API version constants."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine
from azure.mgmt.compute.constants import API_VERSION

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    api_version=API_VERSION
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ001"])
            waz001_results = [r for r in results if r.rule_id == "WAZ001"]
            assert len(waz001_results) == 0


class TestWAZ002ExtractInline:
    """Test WAZ002 - Extract inline properties."""

    def test_waz002_detects_inline_dict_properties(self):
        """Test WAZ002 detects inline dictionary properties."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    network_profile={"network_interfaces": [{"id": "nic-id"}]}
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ002"])
            assert len(results) > 0
            assert any(r.rule_id == "WAZ002" for r in results)

    def test_waz002_allows_extracted_resources(self):
        """Test WAZ002 allows extracted resource references."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import NetworkInterface
from azure.mgmt.compute import VirtualMachine

nic: NetworkInterface = NetworkInterface(id="nic-id")
vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    network_profile=nic
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ002"])
            waz002_results = [r for r in results if r.rule_id == "WAZ002"]
            assert len(waz002_results) == 0


class TestWAZ003DuplicateNames:
    """Test WAZ003 - Flag duplicate resource names."""

    def test_waz003_detects_duplicate_names(self):
        """Test WAZ003 detects duplicate resource names."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm1: VirtualMachine = VirtualMachine(name="my-vm")
vm2: VirtualMachine = VirtualMachine(name="my-vm")
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ003"])
            assert len(results) > 0
            assert any(r.rule_id == "WAZ003" for r in results)

    def test_waz003_allows_unique_names(self):
        """Test WAZ003 allows unique resource names."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm1: VirtualMachine = VirtualMachine(name="vm-1")
vm2: VirtualMachine = VirtualMachine(name="vm-2")
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ003"])
            waz003_results = [r for r in results if r.rule_id == "WAZ003"]
            assert len(waz003_results) == 0


class TestWAZ004CircularDeps:
    """Test WAZ004 - Flag circular dependencies."""

    def test_waz004_detects_circular_dependency(self):
        """Test WAZ004 detects circular dependencies."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork, Subnet

# Simulate circular reference
vnet: VirtualNetwork = VirtualNetwork(name="vnet", subnet=None)
subnet: Subnet = Subnet(name="subnet", vnet=vnet)
# This would create a cycle if vnet.subnet = subnet
"""
            )

            # This test will need actual circular dependency detection
            # For now, just test the structure
            results = run_linter(Path(tmpdir), rules=["WAZ004"])
            # Circular deps may or may not be present in this simple case
            assert isinstance(results, list)

    def test_waz004_allows_acyclic_dependencies(self):
        """Test WAZ004 allows acyclic dependencies."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork, Subnet

vnet: VirtualNetwork = VirtualNetwork(name="vnet")
subnet: Subnet = Subnet(name="subnet", vnet=vnet)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ004"])
            waz004_results = [r for r in results if r.rule_id == "WAZ004"]
            assert len(waz004_results) == 0


class TestWAZ005Secrets:
    """Test WAZ005 - Flag hardcoded secrets."""

    def test_waz005_detects_hardcoded_password(self):
        """Test WAZ005 detects hardcoded passwords."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    admin_password="SuperSecret123!"
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ005"])
            assert len(results) > 0
            assert any(r.rule_id == "WAZ005" for r in results)

    def test_waz005_detects_api_key(self):
        """Test WAZ005 detects API keys."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.web import WebApp

app: WebApp = WebApp(
    name="my-app",
    api_key="ak_1234567890abcdef"
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ005"])
            assert len(results) > 0
            assert any(r.rule_id == "WAZ005" for r in results)

    def test_waz005_allows_environment_variables(self):
        """Test WAZ005 allows environment variable references."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """import os
from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    admin_password=os.environ["ADMIN_PASSWORD"]
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ005"])
            waz005_results = [r for r in results if r.rule_id == "WAZ005"]
            assert len(waz005_results) == 0


class TestWAZ006DeprecatedApi:
    """Test WAZ006 - Flag deprecated API versions."""

    def test_waz006_detects_deprecated_api_version(self):
        """Test WAZ006 detects deprecated API versions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    api_version="2020-01-01"
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ006"])
            assert len(results) > 0
            assert any(r.rule_id == "WAZ006" for r in results)

    def test_waz006_allows_current_api_version(self):
        """Test WAZ006 allows current API versions."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    api_version="2024-03-01"
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ006"])
            waz006_results = [r for r in results if r.rule_id == "WAZ006"]
            assert len(waz006_results) == 0


class TestRunLinter:
    """Test run_linter function."""

    def test_run_linter_empty_directory(self):
        """Test run_linter on empty directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            results = run_linter(Path(tmpdir))
            assert results == []

    def test_run_linter_all_rules(self):
        """Test run_linter runs all rules by default."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    api_version="2020-01-01",
    admin_password="password123"
)
"""
            )

            results = run_linter(Path(tmpdir))
            # Should have multiple rule violations
            assert len(results) > 0
            rule_ids = {r.rule_id for r in results}
            # Should have WAZ006 (deprecated API) and WAZ005 (secrets)
            assert "WAZ006" in rule_ids or "WAZ005" in rule_ids

    def test_run_linter_specific_rules(self):
        """Test run_linter with specific rules."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    api_version="2020-01-01",
    admin_password="password123"
)
"""
            )

            results = run_linter(Path(tmpdir), rules=["WAZ005"])
            # Should only have WAZ005 results
            rule_ids = {r.rule_id for r in results}
            assert "WAZ005" in rule_ids
            assert "WAZ006" not in rule_ids

    def test_run_linter_ignore_rules(self):
        """Test run_linter with ignored rules."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    api_version="2020-01-01",
    admin_password="password123"
)
"""
            )

            results = run_linter(Path(tmpdir), ignore_rules=["WAZ005"])
            # Should not have WAZ005 results
            rule_ids = {r.rule_id for r in results}
            assert "WAZ005" not in rule_ids

    def test_run_linter_on_single_file(self):
        """Test run_linter on single file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine(
    name="my-vm",
    admin_password="password123"
)
"""
            )

            results = run_linter(test_file, rules=["WAZ005"])
            assert len(results) > 0
            assert all(r.file == str(test_file) for r in results)


class TestLinterCLI:
    """Test linter CLI integration."""

    def test_lint_command_exists(self):
        """Test that lint command is available."""
        # This will be tested via CLI module
        from wetwire_azure.cli import main

        # The CLI should be callable
        assert callable(main)

    def test_lint_command_help(self):
        """Test lint command shows help."""
        # This will be implemented when CLI is updated
        pass
