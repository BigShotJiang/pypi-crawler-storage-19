"""Tests for resource discovery and loading."""

import tempfile
from pathlib import Path

from wetwire_azure.loader import Resource, build_dependency_graph, discover_resources


class TestResourceDataclass:
    """Test Resource dataclass."""

    def test_resource_creation(self):
        """Test Resource dataclass can be created."""
        resource = Resource(
            name="my_vm",
            type="VirtualMachine",
            file="/path/to/file.py",
            line=10,
            dependencies=["my_network"],
        )
        assert resource.name == "my_vm"
        assert resource.type == "VirtualMachine"
        assert resource.file == "/path/to/file.py"
        assert resource.line == 10
        assert resource.dependencies == ["my_network"]

    def test_resource_empty_dependencies(self):
        """Test Resource with no dependencies."""
        resource = Resource(
            name="standalone",
            type="ResourceGroup",
            file="/path/to/file.py",
            line=5,
            dependencies=[],
        )
        assert resource.dependencies == []


class TestDiscoverResources:
    """Test discover_resources function."""

    def test_discover_single_resource(self):
        """Test discovering a single resource."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            resources = discover_resources(Path(tmpdir))
            assert len(resources) == 1
            assert resources[0].name == "vm"
            assert resources[0].type == "VirtualMachine"
            assert resources[0].file == str(test_file)
            assert resources[0].line == 3

    def test_discover_multiple_resources(self):
        """Test discovering multiple resources in a file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork()
vm: VirtualMachine = VirtualMachine()
"""
            )

            resources = discover_resources(Path(tmpdir))
            assert len(resources) == 2
            names = [r.name for r in resources]
            assert "vnet" in names
            assert "vm" in names

    def test_discover_with_dependencies(self):
        """Test discovering resources with dependencies."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork(name="my-vnet")
vm: VirtualMachine = VirtualMachine(network=vnet)
"""
            )

            resources = discover_resources(Path(tmpdir))
            assert len(resources) == 2

            vm_resource = next(r for r in resources if r.name == "vm")
            assert "vnet" in vm_resource.dependencies

    def test_discover_nested_dependencies(self):
        """Test discovering nested dependency references."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork, Subnet
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork()
subnet: Subnet = Subnet(vnet=vnet)
vm: VirtualMachine = VirtualMachine(subnet=subnet)
"""
            )

            resources = discover_resources(Path(tmpdir))
            assert len(resources) == 3

            vm_resource = next(r for r in resources if r.name == "vm")
            assert "subnet" in vm_resource.dependencies

            subnet_resource = next(r for r in resources if r.name == "subnet")
            assert "vnet" in subnet_resource.dependencies

    def test_discover_multiple_files(self):
        """Test discovering resources across multiple files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file1 = Path(tmpdir) / "network.py"
            file1.write_text(
                """from azure.mgmt.network import VirtualNetwork

vnet: VirtualNetwork = VirtualNetwork()
"""
            )

            file2 = Path(tmpdir) / "compute.py"
            file2.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            resources = discover_resources(Path(tmpdir))
            assert len(resources) == 2
            files = [r.file for r in resources]
            assert str(file1) in files
            assert str(file2) in files

    def test_discover_ignores_non_azure_types(self):
        """Test that non-Azure types are ignored."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
some_var: str = "hello"
another_var = 42
"""
            )

            resources = discover_resources(Path(tmpdir))
            assert len(resources) == 1
            assert resources[0].name == "vm"

    def test_discover_empty_directory(self):
        """Test discovering resources in empty directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            resources = discover_resources(Path(tmpdir))
            assert resources == []

    def test_discover_no_python_files(self):
        """Test discovering resources with no Python files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            (Path(tmpdir) / "readme.txt").write_text("Not Python")
            resources = discover_resources(Path(tmpdir))
            assert resources == []

    def test_discover_attribute_access_dependency(self):
        """Test discovering dependencies via attribute access."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork()
vm: VirtualMachine = VirtualMachine(network_id=vnet.id)
"""
            )

            resources = discover_resources(Path(tmpdir))
            vm_resource = next(r for r in resources if r.name == "vm")
            assert "vnet" in vm_resource.dependencies

    def test_discover_handles_syntax_errors_gracefully(self):
        """Test that files with syntax errors are skipped."""
        with tempfile.TemporaryDirectory() as tmpdir:
            bad_file = Path(tmpdir) / "bad.py"
            bad_file.write_text("def bad syntax here")

            good_file = Path(tmpdir) / "good.py"
            good_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            resources = discover_resources(Path(tmpdir))
            assert len(resources) == 1
            assert resources[0].name == "vm"


class TestBuildDependencyGraph:
    """Test build_dependency_graph function."""

    def test_empty_resources(self):
        """Test building graph with no resources."""
        graph = build_dependency_graph([])
        assert graph == {}

    def test_single_resource_no_deps(self):
        """Test building graph with single resource and no dependencies."""
        resources = [
            Resource(
                name="vm",
                type="VirtualMachine",
                file="test.py",
                line=1,
                dependencies=[],
            )
        ]
        graph = build_dependency_graph(resources)
        assert graph == {"vm": []}

    def test_linear_dependency_chain(self):
        """Test building graph with linear dependency chain."""
        resources = [
            Resource(
                name="vnet",
                type="VirtualNetwork",
                file="test.py",
                line=1,
                dependencies=[],
            ),
            Resource(
                name="subnet",
                type="Subnet",
                file="test.py",
                line=2,
                dependencies=["vnet"],
            ),
            Resource(
                name="vm",
                type="VirtualMachine",
                file="test.py",
                line=3,
                dependencies=["subnet"],
            ),
        ]
        graph = build_dependency_graph(resources)
        assert graph == {"vnet": [], "subnet": ["vnet"], "vm": ["subnet"]}

    def test_multiple_dependencies(self):
        """Test building graph with multiple dependencies."""
        resources = [
            Resource(
                name="vnet",
                type="VirtualNetwork",
                file="test.py",
                line=1,
                dependencies=[],
            ),
            Resource(
                name="subnet",
                type="Subnet",
                file="test.py",
                line=2,
                dependencies=[],
            ),
            Resource(
                name="vm",
                type="VirtualMachine",
                file="test.py",
                line=3,
                dependencies=["vnet", "subnet"],
            ),
        ]
        graph = build_dependency_graph(resources)
        assert graph == {"vnet": [], "subnet": [], "vm": ["vnet", "subnet"]}

    def test_diamond_dependency_pattern(self):
        """Test building graph with diamond dependency pattern."""
        resources = [
            Resource(name="base", type="Base", file="test.py", line=1, dependencies=[]),
            Resource(
                name="left",
                type="Left",
                file="test.py",
                line=2,
                dependencies=["base"],
            ),
            Resource(
                name="right",
                type="Right",
                file="test.py",
                line=3,
                dependencies=["base"],
            ),
            Resource(
                name="top",
                type="Top",
                file="test.py",
                line=4,
                dependencies=["left", "right"],
            ),
        ]
        graph = build_dependency_graph(resources)
        assert graph == {
            "base": [],
            "left": ["base"],
            "right": ["base"],
            "top": ["left", "right"],
        }
