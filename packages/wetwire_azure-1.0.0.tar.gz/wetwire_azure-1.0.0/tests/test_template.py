"""Tests for template builder and build pipeline."""

import json
import tempfile
from pathlib import Path

import pytest

from wetwire_azure.loader import Resource
from wetwire_azure.template import (
    BuildPipeline,
    CircularDependencyError,
    TemplateBuilder,
    topological_sort,
)


class TestTopologicalSort:
    """Test Kahn's algorithm for topological sorting."""

    def test_empty_graph(self):
        """Test sorting empty graph."""
        result = topological_sort({})
        assert result == []

    def test_single_node_no_dependencies(self):
        """Test sorting single node with no dependencies."""
        graph = {"a": []}
        result = topological_sort(graph)
        assert result == ["a"]

    def test_linear_dependency_chain(self):
        """Test sorting linear dependency chain: a -> b -> c."""
        graph = {"a": [], "b": ["a"], "c": ["b"]}
        result = topological_sort(graph)
        assert result == ["a", "b", "c"]

    def test_multiple_roots(self):
        """Test sorting with multiple independent roots."""
        graph = {"a": [], "b": [], "c": ["a", "b"]}
        result = topological_sort(graph)
        # a and b can be in any order, but both must come before c
        assert result[2] == "c"
        assert set(result[:2]) == {"a", "b"}

    def test_diamond_pattern(self):
        """Test sorting diamond dependency pattern."""
        graph = {"base": [], "left": ["base"], "right": ["base"], "top": ["left", "right"]}
        result = topological_sort(graph)
        # base must be first, top must be last
        assert result[0] == "base"
        assert result[3] == "top"
        assert set(result[1:3]) == {"left", "right"}

    def test_complex_graph(self):
        """Test sorting complex dependency graph."""
        graph = {
            "a": [],
            "b": ["a"],
            "c": ["a"],
            "d": ["b", "c"],
            "e": ["c"],
            "f": ["d", "e"],
        }
        result = topological_sort(graph)
        # Verify all dependencies are satisfied
        positions = {node: i for i, node in enumerate(result)}
        for node, deps in graph.items():
            for dep in deps:
                assert positions[dep] < positions[node], f"{dep} must come before {node}"

    def test_circular_dependency_simple(self):
        """Test detecting simple circular dependency: a -> b -> a."""
        graph = {"a": ["b"], "b": ["a"]}
        with pytest.raises(CircularDependencyError) as exc:
            topological_sort(graph)
        assert "circular dependency" in str(exc.value).lower()

    def test_circular_dependency_complex(self):
        """Test detecting circular dependency in complex graph: a -> b -> c -> a."""
        graph = {"a": ["c"], "b": ["a"], "c": ["b"]}
        with pytest.raises(CircularDependencyError) as exc:
            topological_sort(graph)
        assert "circular dependency" in str(exc.value).lower()

    def test_self_reference(self):
        """Test detecting self-reference as circular dependency."""
        graph = {"a": ["a"]}
        with pytest.raises(CircularDependencyError) as exc:
            topological_sort(graph)
        assert "circular dependency" in str(exc.value).lower()


class TestTemplateBuilder:
    """Test TemplateBuilder class."""

    def test_builder_initialization(self):
        """Test TemplateBuilder can be initialized."""
        builder = TemplateBuilder()
        assert builder is not None

    def test_add_resource(self):
        """Test adding a resource to the builder."""
        builder = TemplateBuilder()
        resource = Resource(
            name="vm", type="VirtualMachine", file="test.py", line=1, dependencies=[]
        )
        builder.add_resource(resource)
        assert len(builder.resources) == 1

    def test_add_multiple_resources(self):
        """Test adding multiple resources."""
        builder = TemplateBuilder()
        resources = [
            Resource(name="vnet", type="VirtualNetwork", file="test.py", line=1, dependencies=[]),
            Resource(name="subnet", type="Subnet", file="test.py", line=2, dependencies=["vnet"]),
        ]
        for resource in resources:
            builder.add_resource(resource)
        assert len(builder.resources) == 2

    def test_validate_circular_dependency(self):
        """Test validation detects circular dependencies."""
        builder = TemplateBuilder()
        resources = [
            Resource(name="a", type="TypeA", file="test.py", line=1, dependencies=["b"]),
            Resource(name="b", type="TypeB", file="test.py", line=2, dependencies=["a"]),
        ]
        for resource in resources:
            builder.add_resource(resource)

        with pytest.raises(CircularDependencyError):
            builder.validate()

    def test_validate_success(self):
        """Test validation succeeds with valid dependencies."""
        builder = TemplateBuilder()
        resources = [
            Resource(name="vnet", type="VirtualNetwork", file="test.py", line=1, dependencies=[]),
            Resource(name="subnet", type="Subnet", file="test.py", line=2, dependencies=["vnet"]),
        ]
        for resource in resources:
            builder.add_resource(resource)

        # Should not raise
        builder.validate()

    def test_order_resources(self):
        """Test ordering resources by dependencies."""
        builder = TemplateBuilder()
        resources = [
            Resource(name="vm", type="VirtualMachine", file="test.py", line=3, dependencies=["subnet"]),
            Resource(name="vnet", type="VirtualNetwork", file="test.py", line=1, dependencies=[]),
            Resource(name="subnet", type="Subnet", file="test.py", line=2, dependencies=["vnet"]),
        ]
        for resource in resources:
            builder.add_resource(resource)

        ordered = builder.order_resources()
        names = [r.name for r in ordered]
        assert names == ["vnet", "subnet", "vm"]

    def test_serialize_to_arm_basic(self):
        """Test basic ARM template serialization."""
        builder = TemplateBuilder()
        resource = Resource(
            name="rg", type="ResourceGroup", file="test.py", line=1, dependencies=[]
        )
        builder.add_resource(resource)

        arm_template = builder.serialize_to_arm()
        assert "$schema" in arm_template
        assert "contentVersion" in arm_template
        assert "resources" in arm_template
        assert len(arm_template["resources"]) == 1

    def test_serialize_with_depends_on(self):
        """Test ARM template includes dependsOn arrays."""
        builder = TemplateBuilder()
        resources = [
            Resource(name="vnet", type="VirtualNetwork", file="test.py", line=1, dependencies=[]),
            Resource(name="subnet", type="Subnet", file="test.py", line=2, dependencies=["vnet"]),
        ]
        for resource in resources:
            builder.add_resource(resource)

        arm_template = builder.serialize_to_arm()
        resources_array = arm_template["resources"]

        # Find subnet resource
        subnet = next(r for r in resources_array if r["name"] == "subnet")
        assert "dependsOn" in subnet
        assert "vnet" in subnet["dependsOn"]

    def test_serialize_filters_non_resource_dependencies(self):
        """Test that non-resource dependencies are filtered out in ARM template."""
        builder = TemplateBuilder()
        # Resource has 'SomeType' in dependencies but it's not a resource
        resource = Resource(
            name="vm",
            type="VirtualMachine",
            file="test.py",
            line=1,
            dependencies=["SomeType", "vnet"],  # SomeType should be filtered out
        )
        vnet = Resource(
            name="vnet",
            type="VirtualNetwork",
            file="test.py",
            line=2,
            dependencies=[],
        )
        builder.add_resource(vnet)
        builder.add_resource(resource)

        arm_template = builder.serialize_to_arm()
        vm_resource = next(r for r in arm_template["resources"] if r["name"] == "vm")

        # Should only have 'vnet' as dependency, not 'SomeType'
        assert vm_resource["dependsOn"] == ["vnet"]


class TestBuildPipeline:
    """Test BuildPipeline orchestration."""

    def test_pipeline_initialization(self):
        """Test BuildPipeline can be initialized."""
        pipeline = BuildPipeline()
        assert pipeline is not None

    def test_discover_stage(self):
        """Test DISCOVER stage finds resources."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            pipeline = BuildPipeline()
            pipeline.discover(Path(tmpdir))
            assert len(pipeline.builder.resources) == 1

    def test_validate_stage(self):
        """Test VALIDATE stage checks dependencies."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork()
vm: VirtualMachine = VirtualMachine(network=vnet)
"""
            )

            pipeline = BuildPipeline()
            pipeline.discover(Path(tmpdir))
            # Should not raise
            pipeline.validate()

    def test_extract_stage_placeholder(self):
        """Test EXTRACT stage (placeholder for now)."""
        pipeline = BuildPipeline()
        # For now, just verify it doesn't crash
        pipeline.extract()

    def test_order_stage(self):
        """Test ORDER stage sorts resources."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import VirtualNetwork, Subnet

vnet: VirtualNetwork = VirtualNetwork()
subnet: Subnet = Subnet(vnet=vnet)
"""
            )

            pipeline = BuildPipeline()
            pipeline.discover(Path(tmpdir))
            ordered = pipeline.order()
            names = [r.name for r in ordered]
            assert names == ["vnet", "subnet"]

    def test_serialize_stage(self):
        """Test SERIALIZE stage produces ARM template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            pipeline = BuildPipeline()
            pipeline.discover(Path(tmpdir))
            arm_template = pipeline.serialize()
            assert "$schema" in arm_template
            assert "resources" in arm_template

    def test_emit_stage(self):
        """Test EMIT stage writes output file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "source.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "output.json"

            pipeline = BuildPipeline()
            pipeline.discover(Path(tmpdir))
            arm_template = pipeline.serialize()
            pipeline.emit(arm_template, output_file)

            assert output_file.exists()
            content = json.loads(output_file.read_text())
            assert "$schema" in content

    def test_full_pipeline_execution(self):
        """Test complete pipeline from discovery to emission."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "source.py"
            source_file.write_text(
                """from azure.mgmt.network import VirtualNetwork, Subnet
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork()
subnet: Subnet = Subnet(vnet=vnet)
vm: VirtualMachine = VirtualMachine(subnet=subnet)
"""
            )

            output_file = Path(tmpdir) / "template.json"

            pipeline = BuildPipeline()
            pipeline.discover(Path(tmpdir))
            pipeline.validate()
            pipeline.extract()  # Placeholder for now
            ordered = pipeline.order()
            assert len(ordered) == 3
            arm_template = pipeline.serialize()
            pipeline.emit(arm_template, output_file)

            assert output_file.exists()
            content = json.loads(output_file.read_text())
            assert len(content["resources"]) == 3

    def test_pipeline_with_circular_dependency_fails(self):
        """Test pipeline fails gracefully with circular dependencies."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test.py"
            test_file.write_text(
                """from azure.mgmt.network import TypeA, TypeB

a: TypeA = TypeA(ref=b)
b: TypeB = TypeB(ref=a)
"""
            )

            pipeline = BuildPipeline()
            pipeline.discover(Path(tmpdir))

            with pytest.raises(CircularDependencyError):
                pipeline.validate()
