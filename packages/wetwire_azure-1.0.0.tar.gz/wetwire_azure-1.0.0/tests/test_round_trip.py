"""Tests for round-trip ARM template conversion.

This module tests the full pipeline:
1. Import ARM JSON template → Python code (ArmTemplateImporter)
2. Execute Python code → Resource objects
3. Serialize resources → ARM JSON (to_arm_template)
4. Compare semantically with original
"""

import json
from pathlib import Path
from typing import Any

from wetwire_azure.importer import ArmTemplateImporter
from wetwire_azure.serialize import to_arm_template


def normalize_arm_resource(resource: dict[str, Any]) -> dict[str, Any]:
    """Normalize an ARM resource for semantic comparison.

    This removes or standardizes fields that can vary between implementations
    while maintaining semantic equivalence:
    - Sorts nested dictionaries for consistent comparison
    - Removes leading/trailing whitespace from strings
    - Normalizes resource type format (with/without Microsoft. prefix)

    Args:
        resource: ARM resource dictionary to normalize

    Returns:
        Normalized resource dictionary
    """
    normalized = {}

    for key, value in resource.items():
        # Normalize string values
        if isinstance(value, str):
            normalized[key] = value.strip()
        # Recursively normalize nested dicts
        elif isinstance(value, dict):
            normalized[key] = normalize_arm_resource(value)
        # Recursively normalize lists
        elif isinstance(value, list):
            normalized[key] = [
                normalize_arm_resource(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            normalized[key] = value

    return normalized


def semantic_compare(original: dict[str, Any], generated: dict[str, Any]) -> tuple[bool, str]:
    """Compare two ARM templates semantically.

    Compares the essential structure and content while ignoring:
    - Key ordering differences
    - Whitespace variations
    - Empty parameters/variables/outputs sections
    - Exact schema URL format (as long as both are valid ARM schemas)

    Args:
        original: Original ARM template dictionary
        generated: Generated ARM template dictionary

    Returns:
        Tuple of (success: bool, message: str)
        - If success is True, message is empty
        - If success is False, message contains the diff details
    """
    # Normalize both templates
    orig_normalized = normalize_arm_resource(original)
    gen_normalized = normalize_arm_resource(generated)

    # Check schema (both should have valid ARM schema)
    orig_schema = orig_normalized.get("$schema", "")
    gen_schema = gen_normalized.get("$schema", "")

    if not orig_schema or not gen_schema:
        return False, "Missing $schema field"

    # Both should be ARM deployment template schemas
    if "deploymentTemplate.json" not in orig_schema or "deploymentTemplate.json" not in gen_schema:
        return False, f"Invalid schema: original={orig_schema}, generated={gen_schema}"

    # Check contentVersion
    if orig_normalized.get("contentVersion") != gen_normalized.get("contentVersion"):
        return False, f"contentVersion mismatch: {orig_normalized.get('contentVersion')} vs {gen_normalized.get('contentVersion')}"

    # Compare resources (main focus)
    orig_resources = orig_normalized.get("resources", [])
    gen_resources = gen_normalized.get("resources", [])

    if len(orig_resources) != len(gen_resources):
        return False, f"Resource count mismatch: {len(orig_resources)} vs {len(gen_resources)}"

    # Sort resources by name for consistent comparison
    orig_resources_sorted = sorted(orig_resources, key=lambda r: r.get("name", ""))
    gen_resources_sorted = sorted(gen_resources, key=lambda r: r.get("name", ""))

    # Compare each resource
    for i, (orig_res, gen_res) in enumerate(
        zip(orig_resources_sorted, gen_resources_sorted, strict=True)
    ):
        # Compare essential fields
        for field in ["name", "type", "location", "sku", "kind", "properties", "tags"]:
            orig_val = orig_res.get(field)
            gen_val = gen_res.get(field)

            # Skip if both are None/missing
            if orig_val is None and gen_val is None:
                continue

            # Compare values
            if orig_val != gen_val:
                return False, f"Resource {i} field '{field}' mismatch:\n  Original: {orig_val}\n  Generated: {gen_val}"

    # Note: We ignore parameters, variables, and outputs for now as they're not part of the basic round-trip

    return True, ""


class TestSemanticCompare:
    """Test the semantic comparison utility function."""

    def test_identical_templates(self):
        """Test that identical templates compare as equal."""
        template = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "storage1",
                    "type": "Microsoft.Storage/storageAccounts",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                }
            ],
        }

        success, message = semantic_compare(template, template)
        assert success, f"Identical templates should compare equal: {message}"

    def test_different_key_order(self):
        """Test that different key ordering is treated as equal."""
        template1 = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "storage1",
                    "type": "Microsoft.Storage/storageAccounts",
                    "location": "eastus",
                }
            ],
        }

        template2 = {
            "contentVersion": "1.0.0.0",
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "resources": [
                {
                    "location": "eastus",
                    "type": "Microsoft.Storage/storageAccounts",
                    "name": "storage1",
                }
            ],
        }

        success, message = semantic_compare(template1, template2)
        assert success, f"Different key order should be treated as equal: {message}"

    def test_missing_resource(self):
        """Test that missing resources are detected."""
        template1 = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [{"name": "resource1", "type": "Microsoft.Storage/storageAccounts"}],
        }

        template2 = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [],
        }

        success, message = semantic_compare(template1, template2)
        assert not success
        assert "Resource count mismatch" in message

    def test_different_resource_values(self):
        """Test that different resource values are detected."""
        template1 = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "storage1",
                    "type": "Microsoft.Storage/storageAccounts",
                    "location": "eastus",
                }
            ],
        }

        template2 = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "storage1",
                    "type": "Microsoft.Storage/storageAccounts",
                    "location": "westus",  # Different location
                }
            ],
        }

        success, message = semantic_compare(template1, template2)
        assert not success
        assert "location" in message


class TestRoundTripSimpleStorage:
    """Test round-trip conversion for simple storage account templates."""

    def test_minimal_storage_round_trip(self):
        """Test round-trip for minimal storage account with only required fields."""
        # Load the original ARM template
        fixture_path = Path(__file__).parent / "fixtures" / "minimal_storage.json"
        with open(fixture_path) as f:
            original_template = json.load(f)

        # Step 1: Import ARM JSON → Python code
        importer = ArmTemplateImporter()
        python_code = importer.import_template(original_template)

        # Step 2: Execute Python code → Resource objects
        # We need to capture the created resource objects
        namespace = {}
        exec(python_code, namespace)

        # Extract resource objects (they're named resource_1, resource_2, etc.)
        resources = []
        for name, obj in namespace.items():
            if name.startswith("resource_"):
                resources.append(obj)

        # Step 3: Serialize resources → ARM JSON
        generated_template = to_arm_template(resources)

        # Step 4: Compare semantically with original
        success, message = semantic_compare(original_template, generated_template)

        assert success, f"Round-trip failed for minimal storage:\n{message}\n\nOriginal:\n{json.dumps(original_template, indent=2)}\n\nGenerated:\n{json.dumps(generated_template, indent=2)}"

    def test_full_storage_round_trip(self):
        """Test round-trip for storage account with all optional fields."""
        # Load the original ARM template
        fixture_path = Path(__file__).parent / "fixtures" / "simple_storage.json"
        with open(fixture_path) as f:
            original_template = json.load(f)

        # Step 1: Import ARM JSON → Python code
        importer = ArmTemplateImporter()
        python_code = importer.import_template(original_template)

        # Step 2: Execute Python code → Resource objects
        namespace = {}
        exec(python_code, namespace)

        # Extract resource objects
        resources = []
        for name, obj in namespace.items():
            if name.startswith("resource_"):
                resources.append(obj)

        # Step 3: Serialize resources → ARM JSON
        generated_template = to_arm_template(resources)

        # Step 4: Compare semantically with original
        success, message = semantic_compare(original_template, generated_template)

        assert success, f"Round-trip failed for full storage:\n{message}\n\nOriginal:\n{json.dumps(original_template, indent=2)}\n\nGenerated:\n{json.dumps(generated_template, indent=2)}"

    def test_multiple_resources_round_trip(self):
        """Test round-trip for template with multiple storage accounts."""
        original_template = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "name": "storage1",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                },
                {
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "name": "storage2",
                    "location": "westus",
                    "sku": {"name": "Premium_LRS"},
                    "kind": "BlobStorage",
                },
            ],
        }

        # Step 1: Import ARM JSON → Python code
        importer = ArmTemplateImporter()
        python_code = importer.import_template(original_template)

        # Step 2: Execute Python code → Resource objects
        namespace = {}
        exec(python_code, namespace)

        # Extract resource objects
        resources = []
        for name, obj in namespace.items():
            if name.startswith("resource_"):
                resources.append(obj)

        # Verify we got 2 resources
        assert len(resources) == 2, f"Expected 2 resources, got {len(resources)}"

        # Step 3: Serialize resources → ARM JSON
        generated_template = to_arm_template(resources)

        # Step 4: Compare semantically with original
        success, message = semantic_compare(original_template, generated_template)

        assert success, f"Round-trip failed for multiple resources:\n{message}\n\nOriginal:\n{json.dumps(original_template, indent=2)}\n\nGenerated:\n{json.dumps(generated_template, indent=2)}"


class TestRoundTripEdgeCases:
    """Test round-trip conversion edge cases."""

    def test_empty_template_round_trip(self):
        """Test round-trip for template with no resources."""
        original_template = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [],
        }

        # For empty templates, just validate they serialize correctly
        generated_template = to_arm_template([])

        success, message = semantic_compare(original_template, generated_template)
        assert success, f"Empty template round-trip failed: {message}"

    def test_resource_with_nested_properties(self):
        """Test round-trip for resource with deeply nested properties."""
        original_template = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "name": "complexstorage",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                    "properties": {
                        "supportsHttpsTrafficOnly": True,
                        "encryption": {
                            "services": {
                                "blob": {
                                    "enabled": True
                                }
                            }
                        },
                        "accessTier": "Hot"
                    },
                }
            ],
        }

        # Import, execute, serialize
        importer = ArmTemplateImporter()
        python_code = importer.import_template(original_template)

        namespace = {}
        exec(python_code, namespace)

        resources = [obj for name, obj in namespace.items() if name.startswith("resource_")]
        generated_template = to_arm_template(resources)

        success, message = semantic_compare(original_template, generated_template)
        assert success, f"Nested properties round-trip failed: {message}"
