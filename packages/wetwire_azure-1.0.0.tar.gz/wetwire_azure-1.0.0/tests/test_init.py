"""Basic tests for wetwire-azure."""

from wetwire_azure import __version__


def test_version():
    """Test version is set."""
    assert __version__ == "0.1.0"
