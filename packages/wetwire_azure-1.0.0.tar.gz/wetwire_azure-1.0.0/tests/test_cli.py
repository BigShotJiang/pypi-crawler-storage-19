"""Tests for CLI commands."""

import json
import sys
import tempfile
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from wetwire_azure.cli import main


class TestBuildCommand:
    """Test build command."""

    def test_build_command_basic(self):
        """Test basic build command execution."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            # Run build command
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "build", str(source_file), "--output", str(output_file)],
            ):
                result = main()

            assert result == 0
            assert output_file.exists()

            # Verify output is valid JSON ARM template
            content = json.loads(output_file.read_text())
            assert "$schema" in content
            assert "contentVersion" in content
            assert "resources" in content

    def test_build_command_directory(self):
        """Test build command on directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_dir = Path(tmpdir) / "src"
            source_dir.mkdir()
            source_file = source_dir / "infra.py"
            source_file.write_text(
                """from azure.mgmt.network import VirtualNetwork

vnet: VirtualNetwork = VirtualNetwork()
"""
            )

            output_file = Path(tmpdir) / "output.json"

            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "build", str(source_dir), "--output", str(output_file)],
            ):
                result = main()

            assert result == 0
            assert output_file.exists()

    def test_build_command_without_output_flag(self):
        """Test build command defaults to template.json."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            # Change to tmpdir so template.json is created there
            import os

            original_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                with patch.object(sys, "argv", ["wetwire-azure", "build", str(source_file)]):
                    result = main()

                assert result == 0
                default_output = Path(tmpdir) / "template.json"
                assert default_output.exists()
            finally:
                os.chdir(original_cwd)

    def test_build_command_format_arm(self):
        """Test build command with explicit ARM format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "build",
                    str(source_file),
                    "--output",
                    str(output_file),
                    "--format",
                    "arm",
                ],
            ):
                result = main()

            assert result == 0
            assert output_file.exists()

            # Verify ARM format
            content = json.loads(output_file.read_text())
            assert "$schema" in content
            assert "deploymentTemplate.json" in content["$schema"]

    def test_build_command_format_bicep(self):
        """Test build command with Bicep format (placeholder)."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.bicep"

            with patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "build",
                    str(source_file),
                    "--output",
                    str(output_file),
                    "--format",
                    "bicep",
                ],
            ):
                result = main()

            # For now, bicep format is not implemented, should return error or success with note
            # We'll implement ARM first, so this should fail or warn
            assert result in [0, 1]  # Allow both for now

    def test_build_command_invalid_path(self):
        """Test build command with non-existent path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            non_existent = Path(tmpdir) / "nonexistent.py"
            output_file = Path(tmpdir) / "template.json"

            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "build", str(non_existent), "--output", str(output_file)],
            ):
                result = main()

            assert result == 1
            assert not output_file.exists()

    def test_build_command_circular_dependency_error(self):
        """Test build command fails gracefully with circular dependencies."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.network import TypeA, TypeB

a: TypeA = TypeA(ref=b)
b: TypeB = TypeB(ref=a)
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "build", str(source_file), "--output", str(output_file)],
            ):
                result = main()

            assert result == 1
            # Output file may or may not be created depending on when error occurs

    def test_build_command_with_dependencies(self):
        """Test build command orders resources correctly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.network import VirtualNetwork, Subnet
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork()
subnet: Subnet = Subnet(vnet=vnet)
vm: VirtualMachine = VirtualMachine(subnet=subnet)
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "build", str(source_file), "--output", str(output_file)],
            ):
                result = main()

            assert result == 0
            assert output_file.exists()

            content = json.loads(output_file.read_text())
            resources = content["resources"]
            assert len(resources) == 3

            # Verify resources are in correct order
            names = [r["name"] for r in resources]
            assert names.index("vnet") < names.index("subnet")
            assert names.index("subnet") < names.index("vm")

    def test_build_command_shows_progress(self):
        """Test build command prints progress messages."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            # Capture stdout
            captured_output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "build", str(source_file), "--output", str(output_file)],
            ), patch("sys.stdout", captured_output):
                result = main()

            output = captured_output.getvalue()
            # Should show some progress indication
            assert result == 0
            # Progress messages might include stages like "Discovering", "Validating", etc.
            # We'll check that some output was produced
            assert len(output) > 0 or result == 0  # Either shows progress or succeeds silently

    def test_build_command_help(self):
        """Test build command help message."""
        with patch.object(sys, "argv", ["wetwire-azure", "build", "--help"]):
            result = main()

        assert result == 0

    def test_build_command_missing_required_args(self):
        """Test build command without path argument."""
        # Build without path should use current directory or show error
        with patch.object(sys, "argv", ["wetwire-azure", "build"]):
            result = main()

        # Should either succeed (using cwd) or fail with helpful message
        assert result in [0, 1]


class TestMainFunction:
    """Test main CLI function."""

    def test_main_no_args_shows_help(self):
        """Test main with no arguments shows help."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "wetwire-azure" in output.lower()

    def test_main_help_flag(self):
        """Test main with --help flag."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "--help"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "usage" in output.lower() or "wetwire-azure" in output.lower()

    def test_main_unknown_command(self):
        """Test main with unknown command."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "unknown"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 1
        output = captured_output.getvalue()
        assert "unknown" in output.lower()

    def test_main_build_command_exists(self):
        """Test that build command is recognized."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            with patch.object(sys, "argv", ["wetwire-azure", "build", str(source_file)]):
                result = main()

            # Should not return "unknown command" error
            assert result in [0, 1]  # Either success or validation error, not unknown command


class TestOutputFormats:
    """Test different output format options."""

    def test_output_format_default_is_arm(self):
        """Test default output format is ARM JSON."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "build", str(source_file), "--output", str(output_file)],
            ):
                result = main()

            assert result == 0
            content = json.loads(output_file.read_text())
            assert "$schema" in content
            assert "deploymentTemplate.json" in content["$schema"]

    def test_output_format_invalid(self):
        """Test invalid output format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "build",
                    str(source_file),
                    "--output",
                    str(output_file),
                    "--format",
                    "invalid",
                ],
            ):
                result = main()

            assert result == 1


class TestDiffCommand:
    """Test diff command."""

    def test_diff_command_basic(self):
        """Test basic diff command execution."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            # Create existing template
            existing_template = Path(tmpdir) / "existing.json"
            existing_template.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "resources": []
            }))

            captured_output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "diff", str(source_file), "--against", str(existing_template)],
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0

    def test_diff_command_identical_templates(self):
        """Test diff with identical templates."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """# Empty file
"""
            )

            # Create existing template matching empty resources
            existing_template = Path(tmpdir) / "existing.json"
            existing_template.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "resources": []
            }))

            captured_output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "diff", str(tmpdir), "--against", str(existing_template)],
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "no differences" in output.lower()

    def test_diff_command_semantic_mode(self):
        """Test diff with semantic comparison."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            # Create existing template with different resource
            existing_template = Path(tmpdir) / "existing.json"
            existing_template.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "resources": [{"name": "old_vm", "type": "Microsoft.Compute/virtualMachines"}]
            }))

            captured_output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "diff", str(source_file), "--against", str(existing_template), "--semantic"],
            ):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0
            output = captured_output.getvalue()
            # Semantic diff should mention added/removed resources
            assert "added" in output.lower() or "removed" in output.lower() or "vm" in output.lower()

    def test_diff_command_with_color(self):
        """Test diff with color output."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            existing_template = Path(tmpdir) / "existing.json"
            existing_template.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "resources": []
            }))

            captured_output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "diff", str(source_file), "--against", str(existing_template), "--color"],
            ):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0

    def test_diff_command_missing_against_flag(self):
        """Test diff without --against flag."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "diff", str(source_file)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 1
            output = captured_output.getvalue()
            assert "against" in output.lower() or "required" in output.lower()

    def test_diff_command_invalid_against_path(self):
        """Test diff with non-existent --against path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "diff", str(source_file), "--against", "/nonexistent/template.json"],
            ):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 1

    def test_diff_command_shows_additions(self):
        """Test diff shows additions correctly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            existing_template = Path(tmpdir) / "existing.json"
            existing_template.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "resources": []
            }))

            captured_output = StringIO()
            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "diff", str(source_file), "--against", str(existing_template)],
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            # Should show some diff output for adding a resource
            assert len(output) > 0

    def test_diff_command_help(self):
        """Test diff command help message."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "diff", "--help"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "--against" in output or "against" in output.lower()


class TestWatchCommand:
    """Test watch command."""

    def test_watch_command_basic(self):
        """Test basic watch command starts watching."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            # Mock time.sleep to raise KeyboardInterrupt after first call
            with patch("time.sleep", side_effect=KeyboardInterrupt):
                captured_output = StringIO()
                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "watch",
                        str(source_file),
                        "--output",
                        str(output_file),
                    ],
                ), patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0

    def test_watch_command_with_interval(self):
        """Test watch command with custom interval."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch("time.sleep", side_effect=KeyboardInterrupt), patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "watch",
                    str(source_file),
                    "--output",
                    str(output_file),
                    "--interval",
                    "2",
                ],
            ):
                result = main()

            assert result == 0

    def test_watch_command_rebuilds_on_change(self):
        """Test watch rebuilds when files change."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            call_count = [0]

            def mock_sleep(seconds):
                call_count[0] += 1
                if call_count[0] == 1:
                    # Modify file on first sleep
                    source_file.write_text(
                        """from azure.mgmt.compute import VirtualMachine

vm2: VirtualMachine = VirtualMachine()
"""
                    )
                elif call_count[0] >= 3:
                    raise KeyboardInterrupt

            with patch("time.sleep", side_effect=mock_sleep), patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "watch",
                    str(source_file),
                    "--output",
                    str(output_file),
                ],
            ):
                result = main()

            assert result == 0

    def test_watch_command_reports_build_errors(self):
        """Test watch reports build errors gracefully."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            call_count = [0]

            def mock_sleep(seconds):
                call_count[0] += 1
                if call_count[0] == 1:
                    # Write invalid Python
                    source_file.write_text("syntax error ::::")
                elif call_count[0] >= 3:
                    raise KeyboardInterrupt

            with patch("time.sleep", side_effect=mock_sleep):
                captured_output = StringIO()
                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "watch",
                        str(source_file),
                        "--output",
                        str(output_file),
                    ],
                ), patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0

    def test_watch_command_directory(self):
        """Test watch command on a directory."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch("time.sleep", side_effect=KeyboardInterrupt), patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "watch",
                    str(tmpdir),
                    "--output",
                    str(output_file),
                ],
            ):
                result = main()

            assert result == 0

    def test_watch_command_debounce(self):
        """Test watch command debounces rapid changes."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            with patch("time.sleep", side_effect=KeyboardInterrupt), patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "watch",
                    str(source_file),
                    "--output",
                    str(output_file),
                ],
            ):
                result = main()

            assert result == 0

    def test_watch_command_help(self):
        """Test watch command help message."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "watch", "--help"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "--output" in output or "output" in output.lower()

    def test_watch_command_invalid_path(self):
        """Test watch command with non-existent path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_file = Path(tmpdir) / "template.json"

            with patch.object(
                sys,
                "argv",
                [
                    "wetwire-azure",
                    "watch",
                    "/nonexistent/path",
                    "--output",
                    str(output_file),
                ],
            ):
                result = main()

            assert result == 1


class TestListCommand:
    """Test list command."""

    def test_list_command_basic(self):
        """Test basic list command execution."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "list", str(tmpdir)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "vm" in output
            assert "VirtualMachine" in output

    def test_list_command_table_format(self):
        """Test list command with table (text) format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine
from azure.mgmt.network import VirtualNetwork

vm: VirtualMachine = VirtualMachine()
vnet: VirtualNetwork = VirtualNetwork()
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "list", str(tmpdir), "--format", "text"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "vm" in output
            assert "vnet" in output
            assert "VirtualMachine" in output
            assert "VirtualNetwork" in output

    def test_list_command_json_format(self):
        """Test list command with JSON format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "list", str(tmpdir), "--format", "json"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            data = json.loads(output)
            assert isinstance(data, list)
            assert len(data) == 1
            assert data[0]["name"] == "vm"
            assert data[0]["type"] == "VirtualMachine"

    def test_list_command_no_resources(self):
        """Test list command with no resources found."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """# No Azure resources here
x = 1
"""
            )

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "list", str(tmpdir)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "no resources" in output.lower() or output.strip() == ""

    def test_list_command_invalid_path(self):
        """Test list command with non-existent path."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "list", "/nonexistent/path"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 1


class TestInitCommand:
    """Test init command."""

    def test_init_command_creates_project_structure(self):
        """Test init command creates basic project structure."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "myproject"

            with patch.object(sys, "argv", ["wetwire-azure", "init", str(project_dir)]):
                result = main()

            assert result == 0
            assert project_dir.exists()
            assert project_dir.is_dir()

    def test_init_command_creates_pyproject_toml(self):
        """Test init command creates pyproject.toml."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "myproject"

            with patch.object(sys, "argv", ["wetwire-azure", "init", str(project_dir)]):
                result = main()

            assert result == 0
            pyproject = project_dir / "pyproject.toml"
            assert pyproject.exists()
            content = pyproject.read_text()
            assert "wetwire-azure" in content

    def test_init_command_creates_example_resource(self):
        """Test init command creates example infrastructure file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "myproject"

            with patch.object(sys, "argv", ["wetwire-azure", "init", str(project_dir)]):
                result = main()

            assert result == 0
            infra_file = project_dir / "infra.py"
            assert infra_file.exists()
            content = infra_file.read_text()
            assert "azure.mgmt" in content

    def test_init_command_creates_gitignore(self):
        """Test init command creates .gitignore."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "myproject"

            with patch.object(sys, "argv", ["wetwire-azure", "init", str(project_dir)]):
                result = main()

            assert result == 0
            gitignore = project_dir / ".gitignore"
            assert gitignore.exists()

    def test_init_command_creates_parameters_template(self):
        """Test init command creates parameters.json template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "myproject"

            with patch.object(sys, "argv", ["wetwire-azure", "init", str(project_dir)]):
                result = main()

            assert result == 0
            params_file = project_dir / "parameters.json"
            assert params_file.exists()
            content = json.loads(params_file.read_text())
            assert "$schema" in content

    def test_init_command_existing_directory(self):
        """Test init command with existing non-empty directory warns."""
        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "myproject"
            project_dir.mkdir()
            (project_dir / "existing.txt").write_text("test")

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "init", str(project_dir)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            # Should either succeed (overwrite/merge) or fail with warning
            assert result in [0, 1]

    def test_init_command_current_directory(self):
        """Test init command without path uses current directory."""
        import os

        with tempfile.TemporaryDirectory() as tmpdir:
            original_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                with patch.object(sys, "argv", ["wetwire-azure", "init"]):
                    result = main()

                assert result == 0
                # Should create files in current directory
                assert (Path(tmpdir) / "infra.py").exists()
            finally:
                os.chdir(original_cwd)


class TestGraphCommand:
    """Test graph command."""

    def test_graph_command_basic(self):
        """Test basic graph command execution."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "graph", str(tmpdir)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "vm" in output

    def test_graph_command_dot_format(self):
        """Test graph command with DOT format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine
from azure.mgmt.network import VirtualNetwork

vnet: VirtualNetwork = VirtualNetwork()
vm: VirtualMachine = VirtualMachine(network=vnet)
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "graph", str(tmpdir), "--format", "dot"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "digraph" in output
            assert "vm" in output
            assert "vnet" in output

    def test_graph_command_mermaid_format(self):
        """Test graph command with Mermaid format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine
from azure.mgmt.network import VirtualNetwork

vnet: VirtualNetwork = VirtualNetwork()
vm: VirtualMachine = VirtualMachine(network=vnet)
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "graph", str(tmpdir), "--format", "mermaid"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "graph" in output.lower() or "flowchart" in output.lower()
            assert "vm" in output
            assert "vnet" in output

    def test_graph_command_output_file(self):
        """Test graph command with output file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "graph.dot"

            with patch.object(
                sys,
                "argv",
                ["wetwire-azure", "graph", str(tmpdir), "--output", str(output_file)],
            ):
                result = main()

            assert result == 0
            assert output_file.exists()
            content = output_file.read_text()
            assert "vm" in content

    def test_graph_command_no_resources(self):
        """Test graph command with no resources found."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """# No Azure resources here
x = 1
"""
            )

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "graph", str(tmpdir)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0

    def test_graph_command_invalid_path(self):
        """Test graph command with non-existent path."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "graph", "/nonexistent/path"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 1

    def test_graph_command_shows_dependencies(self):
        """Test graph command shows dependency edges."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.network import VirtualNetwork, Subnet
from azure.mgmt.compute import VirtualMachine

vnet: VirtualNetwork = VirtualNetwork()
subnet: Subnet = Subnet(vnet=vnet)
vm: VirtualMachine = VirtualMachine(subnet=subnet)
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "graph", str(tmpdir), "--format", "dot"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            # Should show edges for dependencies
            assert "->" in output  # DOT format uses -> for edges


class TestValidateCommand:
    """Test validate command."""

    def test_validate_command_basic(self):
        """Test basic validate command execution."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "validate", str(tmpdir)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "passed" in output.lower() or "no errors" in output.lower()

    def test_validate_command_text_format(self):
        """Test validate command with text format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "validate", str(tmpdir), "--format", "text"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            assert "passed" in output.lower() or "no errors" in output.lower()

    def test_validate_command_json_format(self):
        """Test validate command with JSON format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "validate", str(tmpdir), "--format", "json"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 0
            output = captured_output.getvalue()
            data = json.loads(output)
            assert isinstance(data, list)
            assert len(data) == 0  # No errors

    def test_validate_command_circular_dependency(self):
        """Test validate command detects circular dependencies."""
        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.network import TypeA, TypeB

a: TypeA = TypeA(ref=b)
b: TypeB = TypeB(ref=a)
"""
            )

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "validate", str(tmpdir)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 1
            output = captured_output.getvalue()
            assert "circular" in output.lower() or "error" in output.lower()

    def test_validate_command_arm_missing_schema(self):
        """Test validate command detects missing ARM schema."""
        with tempfile.TemporaryDirectory() as tmpdir:
            arm_file = Path(tmpdir) / "template.json"
            arm_file.write_text(json.dumps({
                "contentVersion": "1.0.0.0",
                "resources": []
            }))

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "validate", str(arm_file)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 1
            output = captured_output.getvalue()
            assert "schema" in output.lower() or "warning" in output.lower()

    def test_validate_command_arm_missing_resources(self):
        """Test validate command detects missing resources array."""
        with tempfile.TemporaryDirectory() as tmpdir:
            arm_file = Path(tmpdir) / "template.json"
            arm_file.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0"
            }))

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "validate", str(arm_file)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 1
            output = captured_output.getvalue()
            assert "resources" in output.lower() or "error" in output.lower()

    def test_validate_command_arm_valid_template(self):
        """Test validate command passes for valid ARM template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            arm_file = Path(tmpdir) / "template.json"
            arm_file.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "resources": []
            }))

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "validate", str(arm_file)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 0

    def test_validate_command_arm_missing_dependency(self):
        """Test validate command detects missing dependency in ARM template."""
        with tempfile.TemporaryDirectory() as tmpdir:
            arm_file = Path(tmpdir) / "template.json"
            arm_file.write_text(json.dumps({
                "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                "contentVersion": "1.0.0.0",
                "resources": [
                    {
                        "name": "myvm",
                        "type": "Microsoft.Compute/virtualMachines",
                        "dependsOn": ["nonexistent"]
                    }
                ]
            }))

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "validate", str(arm_file)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 1
            output = captured_output.getvalue()
            assert "dependency" in output.lower() or "nonexistent" in output.lower()

    def test_validate_command_arm_invalid_json(self):
        """Test validate command handles invalid JSON."""
        with tempfile.TemporaryDirectory() as tmpdir:
            arm_file = Path(tmpdir) / "template.json"
            arm_file.write_text("not valid json {")

            captured_output = StringIO()
            with patch.object(sys, "argv", ["wetwire-azure", "validate", str(arm_file)]):
                with patch("sys.stdout", captured_output):
                    result = main()

            assert result == 1
            output = captured_output.getvalue()
            assert "json" in output.lower() or "error" in output.lower()

    def test_validate_command_json_output_with_errors(self):
        """Test validate command JSON output with errors."""
        with tempfile.TemporaryDirectory() as tmpdir:
            arm_file = Path(tmpdir) / "template.json"
            arm_file.write_text(json.dumps({
                "contentVersion": "1.0.0.0",
                "resources": []
            }))

            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "validate", str(arm_file), "--format", "json"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 1
            output = captured_output.getvalue()
            data = json.loads(output)
            assert isinstance(data, list)
            assert len(data) > 0
            assert "type" in data[0]
            assert "severity" in data[0]

    def test_validate_command_invalid_path(self):
        """Test validate command with non-existent path."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "validate", "/nonexistent/path"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 1

    def test_validate_command_help(self):
        """Test validate command help message."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "validate", "--help"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "validate" in output.lower() or "help" in output.lower()

    def test_validate_command_invalid_format(self):
        """Test validate command with invalid format."""
        with tempfile.TemporaryDirectory() as tmpdir:
            captured_output = StringIO()
            with patch.object(
                sys, "argv", ["wetwire-azure", "validate", str(tmpdir), "--format", "invalid"]
            ), patch("sys.stdout", captured_output):
                result = main()

            assert result == 1
