"""Tests for required documentation files."""

import re
from pathlib import Path


class TestRequiredDocumentation:
    """Tests for required documentation files per wetwire standards."""

    def test_changelog_exists(self):
        """CHANGELOG.md must exist at repository root."""
        changelog = Path("CHANGELOG.md")
        assert changelog.exists(), "CHANGELOG.md is required per wetwire standards"

    def test_changelog_has_unreleased_section(self):
        """CHANGELOG.md must have an Unreleased section."""
        changelog = Path("CHANGELOG.md")
        content = changelog.read_text()
        assert "## [Unreleased]" in content, "CHANGELOG must have [Unreleased] section"

    def test_changelog_has_version_entry(self):
        """CHANGELOG.md must have at least one version entry."""
        changelog = Path("CHANGELOG.md")
        content = changelog.read_text()
        # Look for version pattern like [0.1.0] - YYYY-MM-DD
        version_pattern = r"\[(\d+\.\d+\.\d+)\]\s*-\s*\d{4}-\d{2}-\d{2}"
        assert re.search(version_pattern, content), "CHANGELOG must have dated version entries"

    def test_changelog_follows_keepachangelog(self):
        """CHANGELOG.md must reference Keep a Changelog format."""
        changelog = Path("CHANGELOG.md")
        content = changelog.read_text()
        assert "keepachangelog" in content.lower(), "CHANGELOG should follow Keep a Changelog"

    def test_readme_exists(self):
        """README.md must exist at repository root."""
        readme = Path("README.md")
        assert readme.exists(), "README.md is required"

    def test_claude_md_exists(self):
        """CLAUDE.md must exist at repository root."""
        claude_md = Path("CLAUDE.md")
        assert claude_md.exists(), "CLAUDE.md is required per wetwire standards"

    def test_cli_md_exists(self):
        """CLI.md must exist in docs directory."""
        cli_md = Path("docs/CLI.md")
        assert cli_md.exists(), "docs/CLI.md is required per wetwire standards"

    def test_faq_md_exists(self):
        """FAQ.md must exist in docs directory."""
        faq_md = Path("docs/FAQ.md")
        assert faq_md.exists(), "docs/FAQ.md is required per wetwire standards"

    def test_lint_rules_md_exists(self):
        """LINT_RULES.md must exist in docs directory."""
        lint_rules_md = Path("docs/LINT_RULES.md")
        assert lint_rules_md.exists(), "docs/LINT_RULES.md is required per wetwire standards"

    def test_quick_start_md_exists(self):
        """QUICK_START.md must exist in docs directory."""
        quick_start_md = Path("docs/QUICK_START.md")
        assert quick_start_md.exists(), "docs/QUICK_START.md is required per wetwire standards"
