"""Tests for ARM template serialization."""

from dataclasses import dataclass
from typing import Any

import pytest

from wetwire_azure.resources.storage import StorageAccount
from wetwire_azure.serialize import (
    AttributeReference,
    ParameterReference,
    ResourceReference,
    VariableReference,
    to_arm_dict,
    to_arm_template,
)


class TestBasicSerialization:
    """Test basic dataclass to dict conversion."""

    def test_simple_dataclass(self):
        """Test serialization of simple dataclass with primitive types."""
        @dataclass
        class Simple:
            name: str
            count: int
            enabled: bool

        obj = Simple(name="test", count=5, enabled=True)
        result = to_arm_dict(obj)

        assert result == {
            "name": "test",
            "count": 5,
            "enabled": True,
        }

    def test_snake_case_to_camel_case(self):
        """Test field name conversion from snake_case to camelCase."""
        @dataclass
        class SnakeCase:
            simple_field: str
            multi_word_field: str
            already_camel_case: str
            field_with_many_words: int

        obj = SnakeCase(
            simple_field="value1",
            multi_word_field="value2",
            already_camel_case="value3",
            field_with_many_words=42,
        )
        result = to_arm_dict(obj)

        assert result == {
            "simpleField": "value1",
            "multiWordField": "value2",
            "alreadyCamelCase": "value3",
            "fieldWithManyWords": 42,
        }

    def test_omit_none_values(self):
        """Test that None values are omitted from output."""
        @dataclass
        class WithOptional:
            required: str
            optional: str | None = None
            another_optional: int | None = None

        obj = WithOptional(required="value")
        result = to_arm_dict(obj)

        assert result == {"required": "value"}
        assert "optional" not in result
        assert "anotherOptional" not in result

    def test_include_non_none_optional_values(self):
        """Test that optional values with actual values are included."""
        @dataclass
        class WithOptional:
            required: str
            optional: str | None = None

        obj = WithOptional(required="value", optional="present")
        result = to_arm_dict(obj)

        assert result == {
            "required": "value",
            "optional": "present",
        }


class TestNestedSerialization:
    """Test serialization of nested dataclasses."""

    def test_nested_dataclass(self):
        """Test serialization of nested dataclass."""
        @dataclass
        class Inner:
            inner_field: str
            inner_count: int

        @dataclass
        class Outer:
            outer_field: str
            nested: Inner

        obj = Outer(
            outer_field="outer",
            nested=Inner(inner_field="inner", inner_count=10),
        )
        result = to_arm_dict(obj)

        assert result == {
            "outerField": "outer",
            "nested": {
                "innerField": "inner",
                "innerCount": 10,
            },
        }

    def test_list_of_dataclasses(self):
        """Test serialization of list containing dataclasses."""
        @dataclass
        class Item:
            item_name: str
            item_value: int

        @dataclass
        class Container:
            items: list[Item]

        obj = Container(items=[
            Item(item_name="first", item_value=1),
            Item(item_name="second", item_value=2),
        ])
        result = to_arm_dict(obj)

        assert result == {
            "items": [
                {"itemName": "first", "itemValue": 1},
                {"itemName": "second", "itemValue": 2},
            ],
        }

    def test_dict_with_dataclass_values(self):
        """Test serialization of dict with dataclass values."""
        @dataclass
        class Value:
            data: str

        @dataclass
        class Container:
            mapping: dict[str, Value]

        obj = Container(mapping={
            "key1": Value(data="value1"),
            "key2": Value(data="value2"),
        })
        result = to_arm_dict(obj)

        assert result == {
            "mapping": {
                "key1": {"data": "value1"},
                "key2": {"data": "value2"},
            },
        }


class TestArmReferences:
    """Test ARM template reference conversions."""

    def test_resource_reference(self):
        """Test ResourceReference converts to [resourceId(...)]."""
        @dataclass
        class WithResourceRef:
            name: str
            subnet_id: ResourceReference

        ref = ResourceReference(
            resource_type="Microsoft.Network/virtualNetworks/subnets",
            resource_name=["myVnet", "mySubnet"],
        )
        obj = WithResourceRef(name="test", subnet_id=ref)
        result = to_arm_dict(obj)

        assert result == {
            "name": "test",
            "subnetId": "[resourceId('Microsoft.Network/virtualNetworks/subnets', 'myVnet', 'mySubnet')]",
        }

    def test_attribute_reference(self):
        """Test AttributeReference converts to [reference(...).attribute]."""
        @dataclass
        class WithAttrRef:
            name: str
            storage_key: AttributeReference

        ref = AttributeReference(
            resource_type="Microsoft.Storage/storageAccounts",
            resource_name="myStorage",
            attribute_path="keys[0].value",
        )
        obj = WithAttrRef(name="test", storage_key=ref)
        result = to_arm_dict(obj)

        assert result == {
            "name": "test",
            "storageKey": "[reference(resourceId('Microsoft.Storage/storageAccounts', 'myStorage')).keys[0].value]",
        }

    def test_parameter_reference(self):
        """Test ParameterReference converts to [parameters('...')]."""
        @dataclass
        class WithParamRef:
            name: str
            admin_password: ParameterReference

        ref = ParameterReference(parameter_name="adminPassword")
        obj = WithParamRef(name="test", admin_password=ref)
        result = to_arm_dict(obj)

        assert result == {
            "name": "test",
            "adminPassword": "[parameters('adminPassword')]",
        }

    def test_variable_reference(self):
        """Test VariableReference converts to [variables('...')]."""
        @dataclass
        class WithVarRef:
            name: str
            subnet_name: VariableReference

        ref = VariableReference(variable_name="subnetName")
        obj = WithVarRef(name="test", subnet_name=ref)
        result = to_arm_dict(obj)

        assert result == {
            "name": "test",
            "subnetName": "[variables('subnetName')]",
        }


class TestResourceSerialization:
    """Test serialization of actual resource classes."""

    def test_storage_account(self):
        """Test serialization of StorageAccount resource."""
        storage = StorageAccount(
            name="mystorageaccount",
            location="eastus",
            sku={"name": "Standard_LRS"},
            kind="StorageV2",
            tags={"environment": "dev", "project": "test"},
            properties={"supportsHttpsTrafficOnly": True},
        )
        result = to_arm_dict(storage)

        assert result == {
            "name": "mystorageaccount",
            "location": "eastus",
            "sku": {"name": "Standard_LRS"},
            "kind": "StorageV2",
            "tags": {"environment": "dev", "project": "test"},
            "properties": {"supportsHttpsTrafficOnly": True},
            "type": "Microsoft.Storage/storageAccounts",
            "apiVersion": "2023-05-01",
        }

    def test_resource_with_none_fields(self):
        """Test resource serialization with None fields omitted."""
        storage = StorageAccount(
            name="mystorageaccount",
            location="eastus",
            sku={"name": "Standard_LRS"},
            kind="StorageV2",
        )
        result = to_arm_dict(storage)

        assert "tags" not in result
        assert "properties" not in result
        assert result["name"] == "mystorageaccount"


class TestArmTemplateSerialization:
    """Test full ARM template generation."""

    def test_minimal_template(self):
        """Test generation of minimal ARM template with no resources."""
        template = to_arm_template(resources=[])

        assert template["$schema"] == "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"
        assert template["contentVersion"] == "1.0.0.0"
        assert template["parameters"] == {}
        assert template["variables"] == {}
        assert template["resources"] == []
        assert template["outputs"] == {}

    def test_template_with_single_resource(self):
        """Test ARM template with a single resource."""
        storage = StorageAccount(
            name="mystorageaccount",
            location="eastus",
            sku={"name": "Standard_LRS"},
            kind="StorageV2",
        )
        template = to_arm_template(resources=[storage])

        assert len(template["resources"]) == 1
        assert template["resources"][0]["name"] == "mystorageaccount"
        assert template["resources"][0]["type"] == "Microsoft.Storage/storageAccounts"

    def test_template_with_multiple_resources(self):
        """Test ARM template with multiple resources."""
        storage1 = StorageAccount(
            name="storage1",
            location="eastus",
            sku={"name": "Standard_LRS"},
            kind="StorageV2",
        )
        storage2 = StorageAccount(
            name="storage2",
            location="westus",
            sku={"name": "Premium_LRS"},
            kind="StorageV2",
        )
        template = to_arm_template(resources=[storage1, storage2])

        assert len(template["resources"]) == 2
        assert template["resources"][0]["name"] == "storage1"
        assert template["resources"][1]["name"] == "storage2"

    def test_template_with_parameters(self):
        """Test ARM template with parameters."""
        template = to_arm_template(
            resources=[],
            parameters={
                "location": {
                    "type": "string",
                    "defaultValue": "eastus",
                },
                "adminPassword": {
                    "type": "securestring",
                },
            },
        )

        assert "location" in template["parameters"]
        assert "adminPassword" in template["parameters"]
        assert template["parameters"]["location"]["type"] == "string"

    def test_template_with_variables(self):
        """Test ARM template with variables."""
        template = to_arm_template(
            resources=[],
            variables={
                "subnetName": "default",
                "storageAccountType": "Standard_LRS",
            },
        )

        assert template["variables"]["subnetName"] == "default"
        assert template["variables"]["storageAccountType"] == "Standard_LRS"

    def test_template_with_outputs(self):
        """Test ARM template with outputs."""
        template = to_arm_template(
            resources=[],
            outputs={
                "storageAccountId": {
                    "type": "string",
                    "value": "[resourceId('Microsoft.Storage/storageAccounts', 'myStorage')]",
                },
            },
        )

        assert "storageAccountId" in template["outputs"]
        assert template["outputs"]["storageAccountId"]["type"] == "string"


class TestComplexScenarios:
    """Test complex serialization scenarios."""

    def test_deeply_nested_structure(self):
        """Test serialization of deeply nested structures."""
        @dataclass
        class Level3:
            deep_value: str

        @dataclass
        class Level2:
            level2_field: str
            level3: Level3

        @dataclass
        class Level1:
            level1_field: str
            level2: Level2

        obj = Level1(
            level1_field="l1",
            level2=Level2(
                level2_field="l2",
                level3=Level3(deep_value="l3"),
            ),
        )
        result = to_arm_dict(obj)

        assert result == {
            "level1Field": "l1",
            "level2": {
                "level2Field": "l2",
                "level3": {
                    "deepValue": "l3",
                },
            },
        }

    def test_mixed_types_in_list(self):
        """Test list with mixed primitive and dataclass types."""
        @dataclass
        class Item:
            name: str

        @dataclass
        class Container:
            mixed_list: list[Any]

        obj = Container(mixed_list=[
            "string",
            42,
            Item(name="item"),
            {"key": "value"},
        ])
        result = to_arm_dict(obj)

        assert result == {
            "mixedList": [
                "string",
                42,
                {"name": "item"},
                {"key": "value"},
            ],
        }

    def test_reference_in_nested_structure(self):
        """Test ARM reference inside nested dataclass."""
        @dataclass
        class NetworkConfig:
            vnet_id: ResourceReference

        @dataclass
        class VmConfig:
            name: str
            network: NetworkConfig

        ref = ResourceReference(
            resource_type="Microsoft.Network/virtualNetworks",
            resource_name="myVnet",
        )
        obj = VmConfig(
            name="myVm",
            network=NetworkConfig(vnet_id=ref),
        )
        result = to_arm_dict(obj)

        assert result == {
            "name": "myVm",
            "network": {
                "vnetId": "[resourceId('Microsoft.Network/virtualNetworks', 'myVnet')]",
            },
        }

    def test_empty_collections(self):
        """Test serialization of empty lists and dicts."""
        @dataclass
        class WithCollections:
            name: str
            tags: dict[str, str]
            items: list[str]

        obj = WithCollections(name="test", tags={}, items=[])
        result = to_arm_dict(obj)

        # Empty collections should be included (not None)
        assert result == {
            "name": "test",
            "tags": {},
            "items": [],
        }


class TestErrorHandling:
    """Test error handling and edge cases."""

    def test_to_arm_dict_with_non_dataclass(self):
        """Test that to_arm_dict raises ValueError for non-dataclass."""
        with pytest.raises(ValueError, match="Expected dataclass instance"):
            to_arm_dict("not a dataclass")

    def test_to_arm_dict_with_dataclass_type(self):
        """Test that to_arm_dict raises ValueError for dataclass type (not instance)."""
        @dataclass
        class MyClass:
            field: str

        with pytest.raises(ValueError, match="Expected dataclass instance"):
            to_arm_dict(MyClass)

    def test_resource_reference_with_list_of_names(self):
        """Test ResourceReference with multiple resource names."""
        ref = ResourceReference(
            resource_type="Microsoft.Network/virtualNetworks/subnets",
            resource_name=["vnet1", "subnet1"],
        )
        result = ref.to_arm_expression()
        assert result == "[resourceId('Microsoft.Network/virtualNetworks/subnets', 'vnet1', 'subnet1')]"

    def test_attribute_reference_with_list_of_names(self):
        """Test AttributeReference with multiple resource names."""
        ref = AttributeReference(
            resource_type="Microsoft.Network/virtualNetworks/subnets",
            resource_name=["vnet1", "subnet1"],
            attribute_path="properties.addressPrefix",
        )
        result = ref.to_arm_expression()
        assert result == "[reference(resourceId('Microsoft.Network/virtualNetworks/subnets', 'vnet1', 'subnet1')).properties.addressPrefix]"
