"""Tests for lint auto-fix functionality."""

import tempfile
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity
from wetwire_azure.linter.rules.base import LintRule
from wetwire_azure.linter.rules.waz001_api_version import WAZ001ApiVersion


class TestLintRuleAutoFixBase:
    """Test that LintRule base class has auto-fix support."""

    def test_lint_rule_has_can_auto_fix_property(self):
        """Test that LintRule has can_auto_fix property."""
        rule = WAZ001ApiVersion()
        assert hasattr(rule, "can_auto_fix")

    def test_lint_rule_has_fix_method(self):
        """Test that LintRule has fix method."""
        rule = WAZ001ApiVersion()
        assert hasattr(rule, "fix")
        assert callable(rule.fix)

    def test_default_can_auto_fix_is_false(self):
        """Test that default can_auto_fix is False for rules that don't override."""
        # Create a minimal rule that doesn't override can_auto_fix
        class MinimalRule(LintRule):
            rule_id = "TEST001"
            description = "Test rule"
            severity = LintSeverity.WARNING

            def check(self, files):
                return []

        rule = MinimalRule()
        assert rule.can_auto_fix is False


class TestLintResultAutoFix:
    """Test that LintResult has auto-fix fields."""

    def test_lint_result_has_fixable_field(self):
        """Test that LintResult has fixable field."""
        result = LintResult(
            rule_id="WAZ001",
            severity=LintSeverity.ERROR,
            message="Test message",
            file="test.py",
            line=1,
            fixable=True,
        )
        assert result.fixable is True

    def test_lint_result_fixable_defaults_to_false(self):
        """Test that LintResult fixable defaults to False."""
        result = LintResult(
            rule_id="WAZ001",
            severity=LintSeverity.ERROR,
            message="Test message",
            file="test.py",
            line=1,
        )
        assert result.fixable is False


class TestWAZ001AutoFix:
    """Test WAZ001 auto-fix functionality."""

    def test_waz001_can_auto_fix_is_true(self):
        """Test that WAZ001 rule reports it can auto-fix."""
        rule = WAZ001ApiVersion()
        assert rule.can_auto_fix is True

    def test_waz001_results_are_fixable(self):
        """Test that WAZ001 violations are marked as fixable."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_resource.py"
            test_file.write_text('''
from wetwire_azure.resources.storage import StorageAccount

storage = StorageAccount(
    name="test",
    location="eastus",
    sku={"name": "Standard_LRS"},
    kind="StorageV2",
    api_version="2023-05-01",
)
''')

            rule = WAZ001ApiVersion()
            results = rule.check([test_file])

            assert len(results) == 1
            assert results[0].fixable is True

    def test_waz001_fix_removes_api_version_argument(self):
        """Test that WAZ001 fix removes the api_version string argument."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_resource.py"
            original_content = '''from wetwire_azure.resources.storage import StorageAccount

storage = StorageAccount(
    name="test",
    location="eastus",
    sku={"name": "Standard_LRS"},
    kind="StorageV2",
    api_version="2023-05-01",
)
'''
            test_file.write_text(original_content)

            rule = WAZ001ApiVersion()
            results = rule.check([test_file])

            assert len(results) == 1

            # Apply the fix
            fixed = rule.fix(test_file, results[0])
            assert fixed is True

            # Read the fixed content
            fixed_content = test_file.read_text()

            # The api_version argument should be removed
            assert 'api_version="2023-05-01"' not in fixed_content
            # Other content should remain
            assert 'name="test"' in fixed_content
            assert 'location="eastus"' in fixed_content

    def test_waz001_fix_handles_multiple_violations(self):
        """Test that WAZ001 fix handles multiple violations in one file."""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_resources.py"
            test_file.write_text('''from wetwire_azure.resources.storage import StorageAccount

storage1 = StorageAccount(
    name="test1",
    location="eastus",
    sku={"name": "Standard_LRS"},
    kind="StorageV2",
    api_version="2023-05-01",
)

storage2 = StorageAccount(
    name="test2",
    location="westus",
    sku={"name": "Standard_LRS"},
    kind="StorageV2",
    api_version="2023-01-01",
)
''')

            rule = WAZ001ApiVersion()
            results = rule.check([test_file])

            assert len(results) == 2

            # Apply fixes in reverse line order to prevent line shifts
            results.sort(key=lambda r: r.line, reverse=True)
            for result in results:
                rule.fix(test_file, result)

            # Read the fixed content
            fixed_content = test_file.read_text()

            # Both api_version arguments should be removed
            assert "api_version=" not in fixed_content


class TestAutoFixIntegration:
    """Test auto-fix integration with linter."""

    def test_run_linter_with_fix_flag(self):
        """Test running linter with --fix applies fixes."""
        from wetwire_azure.linter import run_linter_with_fix

        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "test_resource.py"
            test_file.write_text('''from wetwire_azure.resources.storage import StorageAccount

storage = StorageAccount(
    name="test",
    location="eastus",
    sku={"name": "Standard_LRS"},
    kind="StorageV2",
    api_version="2023-05-01",
)
''')

            # Run linter with fix
            results, fixed_count = run_linter_with_fix(test_file)

            # Should have fixed at least one issue
            assert fixed_count >= 1

            # Verify the file was modified
            fixed_content = test_file.read_text()
            assert 'api_version="2023-05-01"' not in fixed_content
