"""Tests for the design command (AI-assisted infrastructure generation)."""

import sys
import tempfile
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch


class TestDesignToolImplementations:
    """Test tool implementations for the Runner agent."""

    def test_init_package_creates_directory(self):
        """Test init_package creates a new project directory."""
        from wetwire_azure.cli import init_package

        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "my-infra"
            result = init_package(str(project_dir))

            assert result["success"] is True
            assert project_dir.exists()
            assert project_dir.is_dir()

    def test_init_package_returns_error_for_existing_dir(self):
        """Test init_package returns error for existing directory."""
        from wetwire_azure.cli import init_package

        with tempfile.TemporaryDirectory() as tmpdir:
            project_dir = Path(tmpdir) / "my-infra"
            project_dir.mkdir()
            (project_dir / "existing.py").write_text("x = 1")

            result = init_package(str(project_dir))

            # Should fail or warn for non-empty directory
            assert (
                result["success"] is False
                or "warning" in result.get("message", "").lower()
            )

    def test_write_file_creates_file(self):
        """Test write_file creates a source file."""
        from wetwire_azure.cli import write_file

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "infra.py"
            content = "from azure.mgmt.compute import VirtualMachine\n\nvm: VirtualMachine = VirtualMachine()"

            result = write_file(str(file_path), content)

            assert result["success"] is True
            assert file_path.exists()
            assert file_path.read_text() == content

    def test_write_file_creates_nested_directories(self):
        """Test write_file creates parent directories."""
        from wetwire_azure.cli import write_file

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "src" / "infra" / "main.py"
            content = "# infrastructure code"

            result = write_file(str(file_path), content)

            assert result["success"] is True
            assert file_path.exists()

    def test_read_file_returns_contents(self):
        """Test read_file returns file contents."""
        from wetwire_azure.cli import read_file

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "test.py"
            content = "# test content\nx = 1"
            file_path.write_text(content)

            result = read_file(str(file_path))

            assert result["success"] is True
            assert result["content"] == content

    def test_read_file_returns_error_for_missing_file(self):
        """Test read_file returns error for non-existent file."""
        from wetwire_azure.cli import read_file

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "nonexistent.py"

            result = read_file(str(file_path))

            assert result["success"] is False
            assert "error" in result or "message" in result

    def test_run_lint_executes_linter(self):
        """Test run_lint executes the linter on files."""
        from wetwire_azure.cli import run_lint_tool

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "test.py"
            file_path.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            result = run_lint_tool(str(tmpdir))

            assert "success" in result
            assert "issues" in result

    def test_run_lint_returns_issues(self):
        """Test run_lint returns lint issues."""
        from wetwire_azure.cli import run_lint_tool

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "test.py"
            # Write code that might have lint issues
            file_path.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            result = run_lint_tool(str(tmpdir))

            assert "issues" in result
            assert isinstance(result["issues"], list)

    def test_run_build_executes_build(self):
        """Test run_build builds the template."""
        from wetwire_azure.cli import run_build_tool

        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = Path(tmpdir) / "test.py"
            file_path.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )
            output_path = Path(tmpdir) / "template.json"

            result = run_build_tool(str(tmpdir), str(output_path))

            assert "success" in result
            if result["success"]:
                assert output_path.exists()

    def test_run_build_returns_error_on_failure(self):
        """Test run_build returns error on build failure."""
        from wetwire_azure.cli import run_build_tool

        with tempfile.TemporaryDirectory() as tmpdir:
            # Non-existent source path should fail
            non_existent = Path(tmpdir) / "nonexistent"
            output_path = Path(tmpdir) / "template.json"

            result = run_build_tool(str(non_existent), str(output_path))

            assert result["success"] is False
            assert "error" in result or "message" in result

    def test_ask_developer_returns_question_format(self):
        """Test ask_developer returns properly formatted question."""
        from wetwire_azure.cli import ask_developer

        result = ask_developer("What size should the VM be?")

        assert "question" in result
        assert result["question"] == "What size should the VM be?"


class TestDesignCommandParsing:
    """Test design command argument parsing."""

    def test_design_command_requires_prompt(self):
        """Test design command requires --prompt flag."""
        from wetwire_azure.cli import main

        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "design"]):
            with patch("sys.stdout", captured_output):
                with patch("sys.stderr", captured_output):
                    result = main()

        assert result == 1
        output = captured_output.getvalue()
        assert "prompt" in output.lower() or "required" in output.lower()

    def test_design_command_accepts_prompt(self):
        """Test design command accepts --prompt flag."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            # Mock the orchestrator to avoid actual API calls
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {"success": True, "output_path": None}

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create a storage account",
                        "--output-dir",
                        tmpdir,
                    ],
                ):
                    result = main()

                # Should not fail on argument parsing
                assert result == 0 or mock_run.called

    def test_design_command_accepts_provider(self):
        """Test design command accepts --provider flag."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {"success": True}

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create a VM",
                        "--provider",
                        "anthropic",
                        "--output-dir",
                        tmpdir,
                    ],
                ):
                    result = main()

                if mock_run.called:
                    call_kwargs = mock_run.call_args
                    # Provider should be passed correctly
                    assert "anthropic" in str(call_kwargs) or result == 0

    def test_design_command_accepts_output_dir(self):
        """Test design command accepts --output-dir flag."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "output"

            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {"success": True}

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create infra",
                        "--output-dir",
                        str(output_dir),
                    ],
                ):
                    result = main()

                # Command should parse successfully
                assert result == 0 or mock_run.called

    def test_design_command_accepts_max_lint_cycles(self):
        """Test design command accepts --max-lint-cycles flag."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {"success": True}

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create infra",
                        "--max-lint-cycles",
                        "5",
                        "--output-dir",
                        tmpdir,
                    ],
                ):
                    result = main()

                assert result == 0 or mock_run.called

    def test_design_command_default_provider_is_anthropic(self):
        """Test design command defaults to anthropic provider."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {"success": True}

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create infra",
                        "--output-dir",
                        tmpdir,
                    ],
                ):
                    main()

                if mock_run.called:
                    call_args = mock_run.call_args
                    # Default should be anthropic
                    args_str = str(call_args)
                    assert "anthropic" in args_str or "provider" not in args_str

    def test_design_command_default_max_lint_cycles_is_3(self):
        """Test design command defaults to 3 max lint cycles."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {"success": True}

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create infra",
                        "--output-dir",
                        tmpdir,
                    ],
                ):
                    main()

                if mock_run.called:
                    call_args = mock_run.call_args
                    # Check max_lint_cycles is 3 (default)
                    if call_args.kwargs:
                        assert call_args.kwargs.get("max_lint_cycles", 3) == 3

    def test_design_command_help(self):
        """Test design command shows help."""
        from wetwire_azure.cli import main

        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "design", "--help"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "--prompt" in output or "prompt" in output.lower()


class TestDesignOrchestratorIntegration:
    """Test integration with the Orchestrator from wetwire-core."""

    def test_design_creates_session_with_correct_config(self):
        """Test design creates session with correct configuration."""
        from wetwire_azure.cli import create_design_session

        with tempfile.TemporaryDirectory() as tmpdir:
            session = create_design_session(
                prompt="Create a VM",
                provider="anthropic",
                output_dir=tmpdir,
                max_lint_cycles=5,
            )

            assert session is not None
            assert session.config.max_lint_cycles == 5
            assert session.config.domain == "azure"

    def test_design_session_has_tools(self):
        """Test design session runner has required tools."""
        from wetwire_azure.cli import get_design_tools

        tools = get_design_tools("/tmp/output")

        tool_names = [t["name"] for t in tools]
        assert "init_package" in tool_names
        assert "write_file" in tool_names
        assert "read_file" in tool_names
        assert "run_lint" in tool_names
        assert "run_build" in tool_names
        assert "ask_developer" in tool_names

    def test_design_tools_have_descriptions(self):
        """Test design tools have proper descriptions."""
        from wetwire_azure.cli import get_design_tools

        tools = get_design_tools("/tmp/output")

        for tool in tools:
            assert "name" in tool
            assert "description" in tool
            assert len(tool["description"]) > 0

    def test_design_enforces_lint_after_write_warning(self):
        """Test design warns if lint not run after write."""
        from wetwire_azure.cli import DesignEnforcer

        enforcer = DesignEnforcer()

        # Simulate write without lint (success=True means write succeeded)
        enforcer.record_action("write_file", {"success": True, "path": "/tmp/test.py"})

        warnings = enforcer.get_warnings()
        # After write, should warn about needing lint
        assert len(warnings) == 1
        assert "lint" in warnings[0].lower()

        # Try to complete without lint
        can_complete, reason = enforcer.can_complete()
        assert can_complete is False
        assert "lint" in reason.lower()

    def test_design_enforces_pass_before_done(self):
        """Test design cannot complete until lint passes."""
        from wetwire_azure.cli import DesignEnforcer

        enforcer = DesignEnforcer()

        # Write and lint with errors
        enforcer.record_action("write_file", {"success": True, "path": "/tmp/test.py"})
        enforcer.record_action(
            "run_lint", {"success": True, "issues": [{"severity": "error"}]}
        )

        can_complete, reason = enforcer.can_complete()
        assert can_complete is False
        assert "pass" in reason.lower() or "error" in reason.lower()

    def test_design_allows_complete_after_lint_passes(self):
        """Test design can complete after lint passes."""
        from wetwire_azure.cli import DesignEnforcer

        enforcer = DesignEnforcer()

        # Write and lint with no errors
        enforcer.record_action("write_file", {"success": True, "path": "/tmp/test.py"})
        enforcer.record_action("run_lint", {"success": True, "issues": []})

        can_complete, reason = enforcer.can_complete()
        assert can_complete is True


class TestDesignRunnerAgent:
    """Test the Runner agent implementation."""

    def test_runner_processes_tool_calls(self):
        """Test Runner processes tool calls correctly."""
        from wetwire_azure.cli import DesignRunner

        with tempfile.TemporaryDirectory() as tmpdir:
            runner = DesignRunner(output_dir=tmpdir, provider=MagicMock())

            # Simulate processing a tool call
            result = runner.execute_tool("init_package", {"path": f"{tmpdir}/project"})

            assert "success" in result

    def test_runner_tracks_completion_state(self):
        """Test Runner tracks completion state."""
        from wetwire_azure.cli import DesignRunner

        with tempfile.TemporaryDirectory() as tmpdir:
            runner = DesignRunner(output_dir=tmpdir, provider=MagicMock())

            assert runner.is_complete() is False

            # Simulate successful completion
            runner.execute_tool(
                "write_file", {"path": f"{tmpdir}/test.py", "content": "x=1"}
            )
            runner.execute_tool("run_lint", {"path": tmpdir})
            runner.mark_complete()

            assert runner.is_complete() is True


class TestDesignDeveloperAgent:
    """Test the Developer agent implementation."""

    def test_developer_responds_to_questions(self):
        """Test Developer responds to Runner questions."""
        from wetwire_azure.cli import AIDeveloper

        # Create mock provider
        mock_provider = MagicMock()
        mock_provider.create_message.return_value = {
            "content": [{"type": "text", "text": "Use Standard_DS1_v2"}],
            "stop_reason": "end_turn",
        }

        developer = AIDeveloper(provider=mock_provider, initial_prompt="Create a VM")

        response = developer.respond("What VM size should I use?")

        assert response is not None
        assert len(response) > 0


class TestDesignEndToEnd:
    """End-to-end tests for design command (mocked API)."""

    def test_design_full_workflow_mocked(self):
        """Test full design workflow with mocked API."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            # Mock the entire design session
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {
                    "success": True,
                    "output_path": f"{tmpdir}/template.json",
                    "lint_cycles": 1,
                    "turns": 5,
                }

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create a storage account with blob container",
                        "--output-dir",
                        tmpdir,
                    ],
                ):
                    result = main()

                assert result == 0
                mock_run.assert_called_once()

    def test_design_reports_lint_cycles(self):
        """Test design reports number of lint cycles used."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            captured_output = StringIO()
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                mock_run.return_value = {
                    "success": True,
                    "output_path": f"{tmpdir}/template.json",
                    "lint_cycles": 2,
                    "turns": 8,
                }

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create infra",
                        "--output-dir",
                        tmpdir,
                    ],
                ), patch("sys.stdout", captured_output):
                    main()

                output = captured_output.getvalue()
                # Should report lint cycles somewhere
                assert "2" in output or "lint" in output.lower()

    def test_design_fails_on_max_lint_cycles_exceeded(self):
        """Test design fails when max lint cycles exceeded."""
        from wetwire_azure.cli import main

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("wetwire_azure.cli.run_design_session") as mock_run:
                # Try to import from wetwire_core, fall back to mock exception
                try:
                    from wetwire_core.agent import MaxLintCyclesExceeded
                except ImportError:
                    # wetwire-core version doesn't have this exception yet
                    class MaxLintCyclesExceeded(Exception):  # noqa: N818
                        pass

                mock_run.side_effect = MaxLintCyclesExceeded(
                    "Exceeded maximum lint cycles (3)"
                )

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "design",
                        "--prompt",
                        "Create infra",
                        "--output-dir",
                        tmpdir,
                    ],
                ):
                    result = main()

                assert result == 1
