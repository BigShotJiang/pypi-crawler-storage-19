"""Tests for persona-based testing CLI command."""

import sys
import tempfile
from io import StringIO
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from wetwire_azure.cli import main


class TestPersonaLoading:
    """Test loading personas from wetwire-core."""

    def test_get_persona_intermediate(self):
        """Test loading intermediate persona."""
        from wetwire_core.agent import get_persona

        persona = get_persona("intermediate")
        assert persona.name == "intermediate"
        assert len(persona.system_prompt) > 0

    def test_get_persona_beginner(self):
        """Test loading beginner persona."""
        from wetwire_core.agent import get_persona

        persona = get_persona("beginner")
        assert persona.name == "beginner"
        assert "beginner" in persona.system_prompt.lower()

    def test_get_persona_expert(self):
        """Test loading expert persona."""
        from wetwire_core.agent import get_persona

        persona = get_persona("expert")
        assert persona.name == "expert"
        assert "expert" in persona.system_prompt.lower()

    def test_get_persona_terse(self):
        """Test loading terse persona."""
        from wetwire_core.agent import get_persona

        persona = get_persona("terse")
        assert persona.name == "terse"

    def test_get_persona_verbose(self):
        """Test loading verbose persona."""
        from wetwire_core.agent import get_persona

        persona = get_persona("verbose")
        assert persona.name == "verbose"

    def test_get_persona_invalid(self):
        """Test loading invalid persona raises error."""
        from wetwire_core.agent import get_persona

        with pytest.raises(ValueError, match="Unknown persona"):
            get_persona("nonexistent")

    def test_all_personas(self):
        """Test getting all personas."""
        from wetwire_core.agent import all_personas

        personas = all_personas()
        assert len(personas) == 5
        names = [p.name for p in personas]
        assert "beginner" in names
        assert "intermediate" in names
        assert "expert" in names
        assert "terse" in names
        assert "verbose" in names

    def test_persona_names(self):
        """Test getting persona names."""
        from wetwire_core.agent import persona_names

        names = persona_names()
        assert len(names) == 5
        assert "beginner" in names
        assert "intermediate" in names
        assert "expert" in names
        assert "terse" in names
        assert "verbose" in names


class TestScoringCalculation:
    """Test scoring calculation from wetwire-core."""

    def test_calculate_score_perfect(self):
        """Test perfect score calculation."""
        from wetwire_core.agent import Score, calculate_score

        score = calculate_score(
            produced_package=True,
            missing_resources=0,
            total_resources=5,
            lint_cycles=0,
            lint_passed=True,
            syntax_valid=True,
            pattern_issues=0,
            output_valid=True,
            validation_errors=0,
            validation_warnings=0,
            questions_asked=0,
            appropriate_questions=0,
        )

        assert isinstance(score, Score)
        assert score.total == 15
        assert score.grade == "Excellent"
        assert score.passed is True

    def test_calculate_score_failure(self):
        """Test failing score calculation."""
        from wetwire_core.agent import calculate_score

        score = calculate_score(
            produced_package=False,
            missing_resources=5,
            total_resources=5,
            lint_cycles=10,
            lint_passed=False,
            syntax_valid=False,
            pattern_issues=10,
            output_valid=False,
            validation_errors=10,
            validation_warnings=10,
            questions_asked=10,
            appropriate_questions=0,
        )

        assert score.total == 0
        assert score.grade == "Failure"
        assert score.passed is False

    def test_calculate_score_partial(self):
        """Test partial score calculation."""
        from wetwire_core.agent import calculate_score

        score = calculate_score(
            produced_package=True,
            missing_resources=2,
            total_resources=5,
            lint_cycles=2,
            lint_passed=True,
            syntax_valid=True,
            pattern_issues=2,
            output_valid=True,
            validation_errors=0,
            validation_warnings=2,
            questions_asked=2,
            appropriate_questions=1,
        )

        assert 6 <= score.total <= 12
        assert score.passed is True

    def test_score_dimensions(self):
        """Test individual score dimensions."""
        from wetwire_core.agent import calculate_score

        score = calculate_score(
            produced_package=True,
            missing_resources=0,
            total_resources=5,
            lint_cycles=1,
            lint_passed=True,
            syntax_valid=True,
            pattern_issues=1,
            output_valid=True,
            validation_errors=0,
            validation_warnings=1,
            questions_asked=1,
            appropriate_questions=1,
        )

        assert score.completeness == 3  # All resources
        assert score.lint_quality == 2  # 1 cycle
        assert score.code_quality == 2  # 1 pattern issue
        assert score.output_validity == 2  # 1 warning
        assert score.question_efficiency == 2  # 1 question


class TestResultsWriting:
    """Test results writing from wetwire-core."""

    def test_results_writer_format(self):
        """Test formatting session results."""
        from wetwire_core.agent import ResultsWriter
        from wetwire_core.agent.results import SessionResults
        from wetwire_core.agent.scoring import Rating, Score

        results = SessionResults(
            prompt="Create a virtual machine",
            package_name="my_vm",
            domain="azure",
            persona="intermediate",
            summary="Created a VM with networking",
        )
        results.score = Score(
            completeness=Rating.EXCELLENT,
            lint_quality=Rating.GOOD,
            code_quality=Rating.EXCELLENT,
            output_validity=Rating.GOOD,
            question_efficiency=Rating.GOOD,
        )

        writer = ResultsWriter()
        content = writer.format(results)

        assert "# Package Generation Results" in content
        assert "Create a virtual machine" in content
        assert "my_vm" in content
        assert "azure" in content
        assert "intermediate" in content
        assert "Completeness" in content

    def test_results_writer_write(self):
        """Test writing results to file."""
        from wetwire_core.agent import ResultsWriter
        from wetwire_core.agent.results import SessionResults

        results = SessionResults(
            prompt="Test prompt",
            package_name="test_pkg",
            domain="azure",
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = Path(tmpdir) / "RESULTS.md"
            writer = ResultsWriter()
            writer.write(results, output_path)

            assert output_path.exists()
            content = output_path.read_text()
            assert "Test prompt" in content


class TestTestCommand:
    """Test the test CLI command."""

    def test_test_command_help(self):
        """Test test command help message."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "test", "--help"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "--persona" in output or "persona" in output.lower()

    def test_test_command_unknown_persona(self):
        """Test test command with unknown persona."""
        captured_output = StringIO()
        with patch.object(
            sys, "argv", ["wetwire-azure", "test", "--persona", "nonexistent"]
        ), patch("sys.stdout", captured_output):
            result = main()

        assert result == 1
        output = captured_output.getvalue()
        assert "unknown" in output.lower() or "invalid" in output.lower()

    def test_test_command_list_personas(self):
        """Test test command lists available personas."""
        captured_output = StringIO()
        with patch.object(sys, "argv", ["wetwire-azure", "test", "--list-personas"]):
            with patch("sys.stdout", captured_output):
                result = main()

        assert result == 0
        output = captured_output.getvalue()
        assert "beginner" in output.lower()
        assert "intermediate" in output.lower()
        assert "expert" in output.lower()

    def test_test_command_default_persona(self):
        """Test test command uses intermediate persona by default."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "output"

            # Mock the DeveloperAgent to avoid actual API calls
            with patch("wetwire_azure.cli.DeveloperAgent") as mock_agent:
                mock_instance = MagicMock()
                mock_instance.run.return_value = {
                    "success": True,
                    "messages": [],
                    "lint_cycles": 0,
                    "turns": 1,
                }
                mock_agent.return_value = mock_instance

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "test",
                        "--output-dir",
                        str(output_dir),
                        "--scenario",
                        "default",
                    ],
                ):
                    main()  # Result not needed - just checking mock calls

                # Check that intermediate persona was used
                if mock_agent.called:
                    call_kwargs = mock_agent.call_args.kwargs
                    if "persona" in call_kwargs:
                        assert call_kwargs["persona"].name == "intermediate"

    def test_test_command_specific_persona(self):
        """Test test command with specific persona."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "output"

            with patch("wetwire_azure.cli.DeveloperAgent") as mock_agent:
                mock_instance = MagicMock()
                mock_instance.run.return_value = {
                    "success": True,
                    "messages": [],
                    "lint_cycles": 0,
                    "turns": 1,
                }
                mock_agent.return_value = mock_instance

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "test",
                        "--persona",
                        "expert",
                        "--output-dir",
                        str(output_dir),
                    ],
                ):
                    main()  # Result not needed - just checking mock calls

                if mock_agent.called:
                    call_kwargs = mock_agent.call_args.kwargs
                    if "persona" in call_kwargs:
                        assert call_kwargs["persona"].name == "expert"

    def test_test_command_all_personas(self):
        """Test test command with --all-personas flag."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "output"

            with patch("wetwire_azure.cli.DeveloperAgent") as mock_agent:
                mock_instance = MagicMock()
                mock_instance.run.return_value = {
                    "success": True,
                    "messages": [],
                    "lint_cycles": 0,
                    "turns": 1,
                }
                mock_agent.return_value = mock_instance

                captured_output = StringIO()
                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "test",
                        "--all-personas",
                        "--output-dir",
                        str(output_dir),
                    ],
                ), patch("sys.stdout", captured_output):
                    result = main()

                # Should run for all 5 personas
                assert mock_agent.call_count >= 5 or result == 0

    def test_test_command_output_files(self):
        """Test test command creates output files."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "output"

            with patch("wetwire_azure.cli.DeveloperAgent") as mock_agent:
                mock_instance = MagicMock()
                mock_instance.run.return_value = {
                    "success": True,
                    "messages": [{"role": "user", "content": "test"}],
                    "lint_cycles": 0,
                    "turns": 1,
                }
                mock_agent.return_value = mock_instance

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "test",
                        "--persona",
                        "intermediate",
                        "--output-dir",
                        str(output_dir),
                    ],
                ):
                    result = main()

                # Check output files exist
                if result == 0 and output_dir.exists():
                    # Files should be created
                    files = list(output_dir.rglob("*"))
                    # At minimum should have some output
                    assert len(files) >= 0

    def test_test_command_provider_flag(self):
        """Test test command with --provider flag."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "output"

            with patch("wetwire_azure.cli.DeveloperAgent") as mock_agent:
                mock_instance = MagicMock()
                mock_instance.run.return_value = {
                    "success": True,
                    "messages": [],
                    "lint_cycles": 0,
                    "turns": 1,
                }
                mock_agent.return_value = mock_instance

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "test",
                        "--provider",
                        "anthropic",
                        "--output-dir",
                        str(output_dir),
                    ],
                ):
                    main()  # Result not needed - just checking mock calls

                if mock_agent.called:
                    call_kwargs = mock_agent.call_args.kwargs
                    if "provider" in call_kwargs:
                        assert call_kwargs["provider"] == "anthropic"

    def test_test_command_scenario_flag(self):
        """Test test command with --scenario flag."""
        with tempfile.TemporaryDirectory() as tmpdir:
            output_dir = Path(tmpdir) / "output"

            with patch("wetwire_azure.cli.DeveloperAgent") as mock_agent:
                mock_instance = MagicMock()
                mock_instance.run.return_value = {
                    "success": True,
                    "messages": [],
                    "lint_cycles": 0,
                    "turns": 1,
                }
                mock_agent.return_value = mock_instance

                with patch.object(
                    sys,
                    "argv",
                    [
                        "wetwire-azure",
                        "test",
                        "--scenario",
                        "create_vm",
                        "--output-dir",
                        str(output_dir),
                    ],
                ):
                    result = main()

                # Should handle custom scenario
                assert result in [0, 1]


class TestDeveloperAgent:
    """Test the DeveloperAgent class."""

    def test_developer_agent_init(self):
        """Test DeveloperAgent initialization."""
        from wetwire_core.agent import get_persona

        try:
            from wetwire_azure.cli import DeveloperAgent

            persona = get_persona("intermediate")
            agent = DeveloperAgent(persona=persona, provider="anthropic")
            assert agent.persona == persona
        except ImportError:
            # DeveloperAgent not yet implemented
            pytest.skip("DeveloperAgent not yet implemented")

    def test_developer_agent_respond(self):
        """Test DeveloperAgent respond method."""
        from wetwire_core.agent import get_persona

        try:
            from wetwire_azure.cli import DeveloperAgent

            persona = get_persona("terse")

            with patch("anthropic.Anthropic") as mock_anthropic:
                mock_client = MagicMock()
                mock_response = MagicMock()
                mock_response.content = [MagicMock(text="yes")]
                mock_client.messages.create.return_value = mock_response
                mock_anthropic.return_value = mock_client

                agent = DeveloperAgent(persona=persona, provider="anthropic")
                response = agent.respond("Do you want a VM?")

                assert isinstance(response, str)
        except ImportError:
            pytest.skip("DeveloperAgent not yet implemented")


class TestScoreJsonOutput:
    """Test score.json output file."""

    def test_score_json_structure(self):
        """Test score.json has correct structure."""
        from wetwire_core.agent.scoring import Rating, Score

        score = Score(
            completeness=Rating.EXCELLENT,
            lint_quality=Rating.GOOD,
            code_quality=Rating.EXCELLENT,
            output_validity=Rating.GOOD,
            question_efficiency=Rating.POOR,
        )

        # Create expected JSON structure
        score_dict = {
            "completeness": int(score.completeness),
            "lint_quality": int(score.lint_quality),
            "code_quality": int(score.code_quality),
            "output_validity": int(score.output_validity),
            "question_efficiency": int(score.question_efficiency),
            "total": score.total,
            "grade": score.grade,
            "passed": score.passed,
        }

        assert score_dict["completeness"] == 3
        assert score_dict["lint_quality"] == 2
        assert score_dict["total"] == 11
        assert score_dict["grade"] == "Success"
        assert score_dict["passed"] is True


class TestSessionJsonOutput:
    """Test session.json output file."""

    def test_session_json_structure(self):
        """Test session.json has correct structure."""
        session_data = {
            "persona": "intermediate",
            "scenario": "default",
            "provider": "anthropic",
            "messages": [
                {"role": "developer", "content": "Create a VM", "turn": 0},
                {"role": "runner", "content": "I'll create a VM...", "turn": 1},
            ],
            "lint_cycles": 1,
            "turns": 2,
            "success": True,
        }

        # Verify structure
        assert "persona" in session_data
        assert "messages" in session_data
        assert isinstance(session_data["messages"], list)
        assert "lint_cycles" in session_data
        assert "turns" in session_data
        assert "success" in session_data
