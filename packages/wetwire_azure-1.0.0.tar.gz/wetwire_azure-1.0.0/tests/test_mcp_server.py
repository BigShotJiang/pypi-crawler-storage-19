"""Tests for MCP server."""

import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestMCPServerWithoutMCP:
    """Test MCP server behavior when MCP is not available."""

    def test_main_without_mcp(self):
        """Test that main() works gracefully when MCP is unavailable."""
        # Mock MCP_AVAILABLE to False
        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", False):
            from wetwire_azure.mcp_server import main

            # Should exit with code 1 when MCP is not available
            result = main()
            assert result == 1

    def test_help_flag_without_mcp(self, capsys):
        """Test --help flag prints install instructions."""
        with patch.object(sys, "argv", ["wetwire-azure-mcp", "--help"]):
            from wetwire_azure.mcp_server import main

            result = main()
            captured = capsys.readouterr()

            # Should print install instructions
            assert result == 0
            assert "wetwire-azure" in captured.out
            # When wetwire-core is not available, we get a simple stub message
            # When it is available, we get full instructions with mcpServers and uvx


class TestMCPServerWithMCP:
    """Test MCP server behavior when MCP is available."""

    @pytest.fixture
    def mock_mcp(self):
        """Mock MCP availability and components."""
        # Create mock server
        mock_server = MagicMock()
        mock_server.list_tools = MagicMock(return_value=lambda: lambda: None)
        mock_server.call_tool = MagicMock(return_value=lambda: lambda x, y: None)

        # Mock the wetwire_core.mcp module
        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", True), patch(
            "wetwire_azure.mcp_server.create_server", return_value=mock_server
        ), patch("wetwire_azure.mcp_server.register_tool"), patch(
            "wetwire_azure.mcp_server.run_server", new_callable=AsyncMock
        ):
            yield mock_server

    def test_create_server(self, mock_mcp):
        """Test server is created with correct name."""
        from wetwire_azure.mcp_server import create_server

        server = create_server("wetwire-azure")
        assert server is not None

    def test_register_build_tool(self, mock_mcp):
        """Test build tool registration."""
        from wetwire_azure.mcp_server import setup_tools

        tools = setup_tools(mock_mcp)

        # Should have registered build tool
        assert any(t["name"] == "build" for t in tools)

        # Check build tool schema
        build_tool = next(t for t in tools if t["name"] == "build")
        assert "description" in build_tool
        assert "inputSchema" in build_tool
        assert "path" in build_tool["inputSchema"]["properties"]
        assert "output" in build_tool["inputSchema"]["properties"]
        assert "format" in build_tool["inputSchema"]["properties"]

    def test_register_lint_tool(self, mock_mcp):
        """Test lint tool registration."""
        from wetwire_azure.mcp_server import setup_tools

        tools = setup_tools(mock_mcp)

        # Should have registered lint tool
        assert any(t["name"] == "lint" for t in tools)

        # Check lint tool schema
        lint_tool = next(t for t in tools if t["name"] == "lint")
        assert "description" in lint_tool
        assert "inputSchema" in lint_tool
        assert "path" in lint_tool["inputSchema"]["properties"]
        assert "format" in lint_tool["inputSchema"]["properties"]

    def test_register_import_tool(self, mock_mcp):
        """Test import tool registration."""
        from wetwire_azure.mcp_server import setup_tools

        tools = setup_tools(mock_mcp)

        # Should have registered import tool
        assert any(t["name"] == "import" for t in tools)

        # Check import tool schema
        import_tool = next(t for t in tools if t["name"] == "import")
        assert "description" in import_tool
        assert "inputSchema" in import_tool
        assert "path" in import_tool["inputSchema"]["properties"]
        assert "output" in import_tool["inputSchema"]["properties"]


class TestMCPToolHandlers:
    """Test MCP tool handler functions."""

    def test_build_handler_success(self):
        """Test build handler with successful build."""
        from wetwire_azure.mcp_server import handle_build

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            output_file = Path(tmpdir) / "template.json"

            result = handle_build(
                path=str(source_file), output=str(output_file), format="arm"
            )

            # Should return success message
            assert "success" in result.lower() or "built" in result.lower()
            assert output_file.exists()

            # Verify output is valid JSON ARM template
            content = json.loads(output_file.read_text())
            assert "$schema" in content
            assert "resources" in content

    def test_build_handler_with_default_output(self):
        """Test build handler with default output path."""
        from wetwire_azure.mcp_server import handle_build

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            # Change to tmpdir and build
            import os

            old_cwd = os.getcwd()
            try:
                os.chdir(tmpdir)
                result = handle_build(path=str(source_file))

                # Should use default template.json
                assert Path("template.json").exists()
                assert "success" in result.lower() or "built" in result.lower()
            finally:
                os.chdir(old_cwd)

    def test_build_handler_error(self):
        """Test build handler with invalid path."""
        from wetwire_azure.mcp_server import handle_build

        result = handle_build(path="/nonexistent/path.py")

        # Should return error message
        assert "error" in result.lower()

    def test_lint_handler_success(self):
        """Test lint handler with clean file."""
        from wetwire_azure.mcp_server import handle_lint

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            result = handle_lint(path=str(source_file))

            # Should return success or issues count
            assert isinstance(result, str)

    def test_lint_handler_json_format(self):
        """Test lint handler with JSON format."""
        from wetwire_azure.mcp_server import handle_lint

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                """from azure.mgmt.compute import VirtualMachine

vm: VirtualMachine = VirtualMachine()
"""
            )

            result = handle_lint(path=str(source_file), format="json")

            # Should return valid JSON
            # Result may be empty array or have lint issues
            assert isinstance(result, str)

    def test_import_handler_success(self):
        """Test import handler with valid ARM template."""
        from wetwire_azure.mcp_server import handle_import

        with tempfile.TemporaryDirectory() as tmpdir:
            template_file = Path(tmpdir) / "template.json"
            template_file.write_text(
                json.dumps(
                    {
                        "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                        "contentVersion": "1.0.0.0",
                        "resources": [
                            {
                                "type": "Microsoft.Storage/storageAccounts",
                                "apiVersion": "2023-05-01",
                                "name": "mystorage123",
                                "location": "eastus",
                                "sku": {"name": "Standard_LRS"},
                                "kind": "StorageV2",
                            }
                        ],
                    }
                )
            )

            result = handle_import(path=str(template_file))

            # Should return Python code with the storage account
            assert 'Generated from ARM template' in result
            assert "StorageAccount" in result
            assert "mystorage123" in result

    def test_import_handler_with_output(self):
        """Test import handler with output file."""
        from wetwire_azure.mcp_server import handle_import

        with tempfile.TemporaryDirectory() as tmpdir:
            template_file = Path(tmpdir) / "template.json"
            template_file.write_text(
                json.dumps(
                    {
                        "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
                        "contentVersion": "1.0.0.0",
                        "resources": [
                            {
                                "type": "Microsoft.Compute/virtualMachines",
                                "apiVersion": "2021-03-01",
                                "name": "myVM",
                                "location": "eastus",
                                "properties": {},
                            }
                        ],
                    }
                )
            )

            output_file = Path(tmpdir) / "output.py"
            result = handle_import(path=str(template_file), output=str(output_file))

            # Should write to file and return success message
            assert output_file.exists()
            assert "success" in result.lower() or "written" in result.lower()

    def test_import_handler_error(self):
        """Test import handler with invalid file."""
        from wetwire_azure.mcp_server import handle_import

        result = handle_import(path="/nonexistent/template.json")

        # Should return error message
        assert "error" in result.lower()

    def test_import_handler_invalid_json(self):
        """Test import handler with invalid JSON file."""
        from wetwire_azure.mcp_server import handle_import

        with tempfile.TemporaryDirectory() as tmpdir:
            template_file = Path(tmpdir) / "template.json"
            template_file.write_text("not valid json {{{")

            result = handle_import(path=str(template_file))

            # Should return error message
            assert "error" in result.lower()


class TestMCPBuildHandlerEdgeCases:
    """Test edge cases for build handler."""

    def test_build_handler_invalid_format(self):
        """Test build handler with invalid format."""
        from wetwire_azure.mcp_server import handle_build

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text("# empty file\n")

            result = handle_build(path=str(source_file), format="invalid")

            assert "error" in result.lower()
            assert "invalid format" in result.lower()

    def test_build_handler_bicep_format_unsupported(self):
        """Test build handler with bicep format (not yet supported)."""
        from wetwire_azure.mcp_server import handle_build

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text("# empty file\n")

            result = handle_build(path=str(source_file), format="bicep")

            assert "error" in result.lower()
            assert "bicep" in result.lower() or "not yet supported" in result.lower()

    def test_build_handler_exception_in_pipeline(self):
        """Test build handler when pipeline raises exception."""
        from wetwire_azure.mcp_server import handle_build

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text("# valid Python\n")

            # Mock the BuildPipeline to raise an exception (patch at source)
            with patch("wetwire_azure.template.BuildPipeline") as mock_pipeline:
                mock_pipeline.return_value.discover.side_effect = RuntimeError(
                    "Pipeline error"
                )

                result = handle_build(path=str(source_file))

                # Should return error message (caught exception)
                assert "error" in result.lower()


class TestMCPLintHandlerEdgeCases:
    """Test edge cases for lint handler."""

    def test_lint_handler_path_not_found(self):
        """Test lint handler with non-existent path."""
        from wetwire_azure.mcp_server import handle_lint

        result = handle_lint(path="/nonexistent/path")

        assert "error" in result.lower()
        assert "not found" in result.lower()

    def test_lint_handler_invalid_format(self):
        """Test lint handler with invalid format."""
        from wetwire_azure.mcp_server import handle_lint

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text("# empty\n")

            result = handle_lint(path=str(source_file), format="xml")

            assert "error" in result.lower()
            assert "invalid format" in result.lower()

    def test_lint_handler_text_format_with_issues(self):
        """Test lint handler text format output with lint issues."""
        from wetwire_azure.mcp_server import handle_lint

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            # Write code that triggers WAZ001 (hardcoded api_version)
            source_file.write_text(
                '''from azure.mgmt.compute import VirtualMachine

vm = VirtualMachine(api_version="2021-03-01")
'''
            )

            result = handle_lint(path=str(source_file), format="text")

            # Should show text formatted results
            assert "WAZ001" in result
            assert "issue" in result.lower()
            assert "error" in result.lower()

    def test_lint_handler_text_format_with_column_info(self):
        """Test lint handler text format with column information."""
        from wetwire_azure.mcp_server import handle_lint

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                '''from azure.mgmt.storage import StorageAccount

account = StorageAccount(api_version="2023-05-01")
'''
            )

            result = handle_lint(path=str(source_file), format="text")

            # Should contain file path and line number
            assert str(source_file) in result or "test.py" in result

    def test_lint_handler_json_format_with_issues(self):
        """Test lint handler JSON format with lint issues."""
        from wetwire_azure.mcp_server import handle_lint

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text(
                '''from azure.mgmt.compute import VirtualMachine

vm = VirtualMachine(api_version="2021-03-01")
'''
            )

            result = handle_lint(path=str(source_file), format="json")

            # Should be valid JSON with lint issues
            data = json.loads(result)
            assert isinstance(data, list)
            assert len(data) > 0
            assert data[0]["rule_id"] == "WAZ001"
            assert "severity" in data[0]
            assert "message" in data[0]

    def test_lint_handler_exception_in_linter(self):
        """Test lint handler when linter raises exception."""
        from wetwire_azure.mcp_server import handle_lint

        with tempfile.TemporaryDirectory() as tmpdir:
            source_file = Path(tmpdir) / "test.py"
            source_file.write_text("# valid Python\n")

            # Mock the run_linter to raise an exception (patching where it's imported)
            with patch("wetwire_azure.linter.runner.run_linter") as mock_linter:
                mock_linter.side_effect = RuntimeError("Linter crash")

                result = handle_lint(path=str(source_file))

                assert "error" in result.lower()


class TestMCPFallbackStubs:
    """Test fallback stub functions when wetwire-core is not available."""

    def test_fallback_stubs_behavior_when_mcp_unavailable(self):
        """Test that fallback stubs work correctly when MCP unavailable."""
        # Test with MCP_AVAILABLE=False which simulates unavailable state
        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", False):
            from wetwire_azure.mcp_server import main

            # When MCP unavailable, main returns 1
            result = main()
            assert result == 1

    def test_register_tool_accepts_all_parameters(self):
        """Test register_tool function accepts all parameters."""
        from wetwire_azure.mcp_server import register_tool

        # Should not raise any exception with all parameters
        register_tool(
            server=MagicMock(),
            name="test_tool",
            handler=lambda: None,
            schema={"type": "object"},
            description="Test tool description",
        )

    def test_get_install_instructions_returns_string(self):
        """Test get_install_instructions returns useful string."""
        from wetwire_azure.mcp_server import get_install_instructions

        result = get_install_instructions("wetwire-azure")

        # Should return install instructions string
        assert isinstance(result, str)
        assert len(result) > 0

    def test_run_server_is_async(self):
        """Test run_server is an async function."""
        import asyncio

        from wetwire_azure.mcp_server import run_server

        # run_server should be a coroutine function
        assert asyncio.iscoroutinefunction(run_server)


class TestMCPMainFunction:
    """Test main() function edge cases."""

    def test_main_server_creation_failure(self, capsys):
        """Test main() when server creation fails."""
        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", True), patch(
            "wetwire_azure.mcp_server.create_server", return_value=None
        ):
            from wetwire_azure.mcp_server import main

            result = main()

            assert result == 1
            captured = capsys.readouterr()
            assert "failed" in captured.err.lower() or "error" in captured.err.lower()

    def test_main_run_server_exception(self, capsys):
        """Test main() when run_server raises exception."""
        mock_server = MagicMock()

        async def raise_exception(server):
            raise RuntimeError("Connection failed")

        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", True), patch(
            "wetwire_azure.mcp_server.create_server", return_value=mock_server
        ), patch("wetwire_azure.mcp_server.register_tool"), patch(
            "wetwire_azure.mcp_server.run_server", side_effect=raise_exception
        ):
            from wetwire_azure.mcp_server import main

            result = main()

            assert result == 1
            captured = capsys.readouterr()
            assert "error" in captured.err.lower()

    def test_main_keyboard_interrupt(self):
        """Test main() handles KeyboardInterrupt gracefully."""
        mock_server = MagicMock()

        async def raise_keyboard_interrupt(server):
            raise KeyboardInterrupt()

        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", True), patch(
            "wetwire_azure.mcp_server.create_server", return_value=mock_server
        ), patch("wetwire_azure.mcp_server.register_tool"), patch(
            "wetwire_azure.mcp_server.run_server", side_effect=raise_keyboard_interrupt
        ):
            from wetwire_azure.mcp_server import main

            result = main()

            # Should exit cleanly with 0
            assert result == 0

    def test_main_mcp_unavailable_stderr_message(self, capsys):
        """Test main() outputs correct stderr message when MCP unavailable."""
        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", False), patch.object(
            sys, "argv", ["wetwire-azure-mcp"]
        ):
            from wetwire_azure.mcp_server import main

            result = main()

            assert result == 1
            captured = capsys.readouterr()
            assert "mcp" in captured.err.lower()
            assert "install" in captured.err.lower()

    def test_main_successful_run(self):
        """Test main() successful server run."""
        mock_server = MagicMock()

        with patch("wetwire_azure.mcp_server.MCP_AVAILABLE", True), patch(
            "wetwire_azure.mcp_server.create_server", return_value=mock_server
        ), patch("wetwire_azure.mcp_server.register_tool"), patch(
            "wetwire_azure.mcp_server.run_server", new_callable=AsyncMock
        ) as mock_run:
            from wetwire_azure.mcp_server import main

            result = main()

            assert result == 0
            mock_run.assert_called_once_with(mock_server)
