"""Tests for expanded Azure resource types."""


from wetwire_azure.importer import RESOURCE_TYPE_MAPPING, convert_arm_to_python


class TestResourceTypeMapping:
    """Test that all resource types are properly mapped."""

    def test_storage_account_mapped(self):
        """Test StorageAccount is in mapping."""
        assert "Microsoft.Storage/storageAccounts" in RESOURCE_TYPE_MAPPING

    def test_virtual_machine_mapped(self):
        """Test VirtualMachine is in mapping."""
        assert "Microsoft.Compute/virtualMachines" in RESOURCE_TYPE_MAPPING

    def test_availability_set_mapped(self):
        """Test AvailabilitySet is in mapping."""
        assert "Microsoft.Compute/availabilitySets" in RESOURCE_TYPE_MAPPING

    def test_virtual_network_mapped(self):
        """Test VirtualNetwork is in mapping."""
        assert "Microsoft.Network/virtualNetworks" in RESOURCE_TYPE_MAPPING

    def test_network_interface_mapped(self):
        """Test NetworkInterface is in mapping."""
        assert "Microsoft.Network/networkInterfaces" in RESOURCE_TYPE_MAPPING

    def test_nsg_mapped(self):
        """Test NetworkSecurityGroup is in mapping."""
        assert "Microsoft.Network/networkSecurityGroups" in RESOURCE_TYPE_MAPPING

    def test_public_ip_mapped(self):
        """Test PublicIPAddress is in mapping."""
        assert "Microsoft.Network/publicIPAddresses" in RESOURCE_TYPE_MAPPING

    def test_load_balancer_mapped(self):
        """Test LoadBalancer is in mapping."""
        assert "Microsoft.Network/loadBalancers" in RESOURCE_TYPE_MAPPING

    def test_keyvault_mapped(self):
        """Test KeyVault is in mapping."""
        assert "Microsoft.KeyVault/vaults" in RESOURCE_TYPE_MAPPING

    def test_app_service_plan_mapped(self):
        """Test AppServicePlan is in mapping."""
        assert "Microsoft.Web/serverfarms" in RESOURCE_TYPE_MAPPING

    def test_web_app_mapped(self):
        """Test WebApp is in mapping."""
        assert "Microsoft.Web/sites" in RESOURCE_TYPE_MAPPING

    def test_sql_server_mapped(self):
        """Test SqlServer is in mapping."""
        assert "Microsoft.Sql/servers" in RESOURCE_TYPE_MAPPING

    def test_sql_database_mapped(self):
        """Test SqlDatabase is in mapping."""
        assert "Microsoft.Sql/servers/databases" in RESOURCE_TYPE_MAPPING

    def test_app_insights_mapped(self):
        """Test ApplicationInsights is in mapping."""
        assert "Microsoft.Insights/components" in RESOURCE_TYPE_MAPPING

    def test_cosmosdb_mapped(self):
        """Test CosmosDBAccount is in mapping."""
        assert "Microsoft.DocumentDB/databaseAccounts" in RESOURCE_TYPE_MAPPING

    def test_redis_mapped(self):
        """Test RedisCache is in mapping."""
        assert "Microsoft.Cache/redis" in RESOURCE_TYPE_MAPPING

    def test_aks_mapped(self):
        """Test ManagedCluster (AKS) is in mapping."""
        assert "Microsoft.ContainerService/managedClusters" in RESOURCE_TYPE_MAPPING

    def test_at_least_15_resource_types(self):
        """Test that we have at least 15 resource types (acceptance criteria)."""
        assert len(RESOURCE_TYPE_MAPPING) >= 15


class TestNetworkResources:
    """Test network resource types."""

    def test_import_nsg(self):
        """Test importing NetworkSecurityGroup."""
        from wetwire_azure.resources.network import NetworkSecurityGroup

        nsg = NetworkSecurityGroup(
            name="test-nsg",
            location="eastus",
            security_rules=[
                {
                    "name": "allow-http",
                    "properties": {
                        "priority": 100,
                        "direction": "Inbound",
                        "access": "Allow",
                        "protocol": "Tcp",
                        "destinationPortRange": "80",
                    },
                }
            ],
        )

        assert nsg.name == "test-nsg"
        assert nsg.type == "Microsoft.Network/networkSecurityGroups"

    def test_import_public_ip(self):
        """Test importing PublicIPAddress."""
        from wetwire_azure.resources.network import PublicIPAddress

        pip = PublicIPAddress(
            name="test-pip",
            location="eastus",
            sku={"name": "Standard"},
            public_ip_allocation_method="Static",
        )

        assert pip.name == "test-pip"
        assert pip.type == "Microsoft.Network/publicIPAddresses"

    def test_import_load_balancer(self):
        """Test importing LoadBalancer."""
        from wetwire_azure.resources.network import LoadBalancer

        lb = LoadBalancer(
            name="test-lb",
            location="eastus",
            sku={"name": "Standard"},
        )

        assert lb.name == "test-lb"
        assert lb.type == "Microsoft.Network/loadBalancers"


class TestKeyVaultResources:
    """Test Key Vault resource types."""

    def test_import_keyvault(self):
        """Test importing KeyVault."""
        from wetwire_azure.resources.keyvault import KeyVault

        kv = KeyVault(
            name="test-kv",
            location="eastus",
            properties={
                "tenantId": "00000000-0000-0000-0000-000000000000",
                "sku": {"family": "A", "name": "standard"},
                "accessPolicies": [],
            },
        )

        assert kv.name == "test-kv"
        assert kv.type == "Microsoft.KeyVault/vaults"


class TestWebResources:
    """Test Web (App Service) resource types."""

    def test_import_app_service_plan(self):
        """Test importing AppServicePlan."""
        from wetwire_azure.resources.web import AppServicePlan

        plan = AppServicePlan(
            name="test-plan",
            location="eastus",
            sku={"name": "S1", "tier": "Standard"},
            kind="linux",
        )

        assert plan.name == "test-plan"
        assert plan.type == "Microsoft.Web/serverfarms"

    def test_import_web_app(self):
        """Test importing WebApp."""
        from wetwire_azure.resources.web import WebApp

        app = WebApp(
            name="test-app",
            location="eastus",
            kind="app,linux",
            properties={
                "serverFarmId": "/subscriptions/.../test-plan",
                "siteConfig": {"linuxFxVersion": "PYTHON|3.11"},
            },
        )

        assert app.name == "test-app"
        assert app.type == "Microsoft.Web/sites"


class TestSqlResources:
    """Test SQL resource types."""

    def test_import_sql_server(self):
        """Test importing SqlServer."""
        from wetwire_azure.resources.sql import SqlServer

        server = SqlServer(
            name="test-sql-server",
            location="eastus",
            properties={
                "administratorLogin": "sqladmin",
                "version": "12.0",
            },
        )

        assert server.name == "test-sql-server"
        assert server.type == "Microsoft.Sql/servers"

    def test_import_sql_database(self):
        """Test importing SqlDatabase."""
        from wetwire_azure.resources.sql import SqlDatabase

        db = SqlDatabase(
            name="test-db",
            location="eastus",
            sku={"name": "S0", "tier": "Standard"},
        )

        assert db.name == "test-db"
        assert db.type == "Microsoft.Sql/servers/databases"


class TestInsightsResources:
    """Test Insights (Application Insights) resource types."""

    def test_import_app_insights(self):
        """Test importing ApplicationInsights."""
        from wetwire_azure.resources.insights import ApplicationInsights

        ai = ApplicationInsights(
            name="test-ai",
            location="eastus",
            kind="web",
            properties={
                "Application_Type": "web",
            },
        )

        assert ai.name == "test-ai"
        assert ai.type == "Microsoft.Insights/components"


class TestCosmosDBResources:
    """Test Cosmos DB resource types."""

    def test_import_cosmosdb(self):
        """Test importing CosmosDBAccount."""
        from wetwire_azure.resources.documentdb import CosmosDBAccount

        cosmos = CosmosDBAccount(
            name="test-cosmos",
            location="eastus",
            kind="GlobalDocumentDB",
            properties={
                "databaseAccountOfferType": "Standard",
                "locations": [{"locationName": "eastus", "failoverPriority": 0}],
            },
        )

        assert cosmos.name == "test-cosmos"
        assert cosmos.type == "Microsoft.DocumentDB/databaseAccounts"


class TestCacheResources:
    """Test Cache (Redis) resource types."""

    def test_import_redis(self):
        """Test importing RedisCache."""
        from wetwire_azure.resources.cache import RedisCache

        redis = RedisCache(
            name="test-redis",
            location="eastus",
            sku={"name": "Standard", "family": "C", "capacity": 1},
        )

        assert redis.name == "test-redis"
        assert redis.type == "Microsoft.Cache/redis"


class TestContainerServiceResources:
    """Test Container Service (AKS) resource types."""

    def test_import_aks(self):
        """Test importing ManagedCluster (AKS)."""
        from wetwire_azure.resources.containerservice import ManagedCluster

        aks = ManagedCluster(
            name="test-aks",
            location="eastus",
            properties={
                "kubernetesVersion": "1.28",
                "dnsPrefix": "test-aks",
                "agentPoolProfiles": [
                    {"name": "nodepool1", "count": 3, "vmSize": "Standard_DS2_v2"}
                ],
            },
        )

        assert aks.name == "test-aks"
        assert aks.type == "Microsoft.ContainerService/managedClusters"


class TestArmConversion:
    """Test ARM to Python conversion for new types."""

    def test_convert_nsg_arm_to_python(self):
        """Test converting NSG ARM resource to Python."""
        resource = {
            "type": "Microsoft.Network/networkSecurityGroups",
            "apiVersion": "2024-01-01",
            "name": "my-nsg",
            "location": "eastus",
            "properties": {
                "securityRules": [
                    {
                        "name": "allow-ssh",
                        "properties": {"priority": 100, "access": "Allow"},
                    }
                ]
            },
        }

        python_code = convert_arm_to_python(resource)

        assert python_code is not None
        assert "NetworkSecurityGroup(" in python_code
        assert 'name="my-nsg"' in python_code

    def test_convert_keyvault_arm_to_python(self):
        """Test converting KeyVault ARM resource to Python."""
        resource = {
            "type": "Microsoft.KeyVault/vaults",
            "apiVersion": "2023-07-01",
            "name": "my-vault",
            "location": "eastus",
            "properties": {
                "tenantId": "00000000-0000-0000-0000-000000000000",
                "sku": {"family": "A", "name": "standard"},
            },
        }

        python_code = convert_arm_to_python(resource)

        assert python_code is not None
        assert "KeyVault(" in python_code
        assert 'name="my-vault"' in python_code

    def test_convert_web_app_arm_to_python(self):
        """Test converting WebApp ARM resource to Python."""
        resource = {
            "type": "Microsoft.Web/sites",
            "apiVersion": "2023-12-01",
            "name": "my-web-app",
            "location": "eastus",
            "kind": "app",
            "properties": {
                "serverFarmId": "/subscriptions/.../my-plan",
            },
        }

        python_code = convert_arm_to_python(resource)

        assert python_code is not None
        assert "WebApp(" in python_code
        assert 'name="my-web-app"' in python_code
