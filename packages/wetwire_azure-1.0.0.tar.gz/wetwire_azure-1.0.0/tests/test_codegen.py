"""Tests for Azure schema codegen pipeline."""


class TestSchemaFetching:
    """Tests for schema fetching from azure-resource-manager-schemas."""

    def test_fetch_schema_function_exists(self):
        """Test that fetch_schema function exists and is callable."""
        from wetwire_azure.codegen.fetch import fetch_schema

        assert callable(fetch_schema)

    def test_fetch_schema_returns_dict(self):
        """Test that fetch_schema returns a dictionary."""
        from wetwire_azure.codegen.fetch import fetch_schema

        # Fetch a known schema (e.g., Compute VirtualMachine)
        schema = fetch_schema("Microsoft.Compute", "virtualMachines", "2024-03-01")
        assert isinstance(schema, dict)
        assert "properties" in schema or "definitions" in schema

    def test_get_latest_api_version_function_exists(self):
        """Test that get_latest_api_version function exists."""
        from wetwire_azure.codegen.fetch import get_latest_api_version

        assert callable(get_latest_api_version)


class TestSchemaParsing:
    """Tests for parsing ARM JSON schemas."""

    def test_parse_schema_function_exists(self):
        """Test that parse_schema function exists."""
        from wetwire_azure.codegen.parse import parse_schema

        assert callable(parse_schema)

    def test_parse_simple_schema(self):
        """Test parsing a simple ARM schema into intermediate format."""
        from wetwire_azure.codegen.parse import parse_schema

        simple_schema = {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Resource name"},
                "location": {"type": "string", "description": "Resource location"},
                "tags": {
                    "type": "object",
                    "additionalProperties": {"type": "string"},
                },
            },
            "required": ["name", "location"],
        }

        parsed = parse_schema(simple_schema, "TestResource")
        assert parsed["class_name"] == "TestResource"
        assert "name" in parsed["fields"]
        assert "location" in parsed["fields"]
        assert "tags" in parsed["fields"]
        assert parsed["fields"]["name"]["type"] == "str"
        assert parsed["fields"]["name"]["required"] is True
        assert parsed["fields"]["location"]["required"] is True
        assert parsed["fields"]["tags"]["required"] is False


class TestCodeGeneration:
    """Tests for generating Python dataclasses from parsed schemas."""

    def test_generate_dataclass_function_exists(self):
        """Test that generate_dataclass function exists."""
        from wetwire_azure.codegen.generate import generate_dataclass

        assert callable(generate_dataclass)

    def test_generate_valid_python_code(self):
        """Test that generated code is valid Python."""
        from wetwire_azure.codegen.generate import generate_dataclass

        parsed_schema = {
            "class_name": "TestResource",
            "fields": {
                "name": {
                    "type": "str",
                    "required": True,
                    "description": "Resource name",
                },
                "location": {
                    "type": "str",
                    "required": True,
                    "description": "Resource location",
                },
                "tags": {
                    "type": "dict[str, str] | None",
                    "required": False,
                    "description": "Resource tags",
                },
            },
        }

        code = generate_dataclass(parsed_schema)
        assert isinstance(code, str)
        assert "class TestResource" in code
        assert "name: str" in code
        assert "location: str" in code
        assert "tags: dict[str, str] | None = None" in code

        # Verify it's valid Python by compiling
        compile(code, "<string>", "exec")

    def test_generated_code_uses_dataclass_dsl(self):
        """Test that generated code uses dataclass-dsl patterns."""
        from wetwire_azure.codegen.generate import generate_dataclass

        parsed_schema = {
            "class_name": "VirtualMachine",
            "fields": {
                "name": {"type": "str", "required": True, "description": "VM name"},
                "vm_size": {
                    "type": "str",
                    "required": True,
                    "description": "VM size",
                },
            },
        }

        code = generate_dataclass(parsed_schema)
        # Should import dataclass from dataclasses
        assert "from dataclasses import dataclass" in code or "@dataclass" in code


class TestResourceGeneration:
    """Tests for generated resource types."""

    def test_base_resource_class_exists(self):
        """Test that base Resource class exists with common Azure fields."""
        from wetwire_azure.resources.base import Resource

        assert hasattr(Resource, "__dataclass_fields__")

    def test_base_resource_has_common_fields(self):
        """Test that Resource has common Azure ARM fields."""
        from wetwire_azure.resources.base import Resource

        fields = Resource.__dataclass_fields__
        # Common ARM fields
        assert "name" in fields
        assert "location" in fields
        assert "tags" in fields

    def test_virtual_machine_class_exists(self):
        """Test that VirtualMachine resource class exists."""
        from wetwire_azure.resources.compute import VirtualMachine

        assert hasattr(VirtualMachine, "__dataclass_fields__")

    def test_virtual_machine_instantiation(self):
        """Test that VirtualMachine can be instantiated."""
        from wetwire_azure.resources.compute import VirtualMachine

        vm = VirtualMachine(
            name="myvm",
            location="eastus",
            vm_size="Standard_DS1_v2",
        )
        assert vm.name == "myvm"
        assert vm.location == "eastus"
        assert vm.vm_size == "Standard_DS1_v2"

    def test_storage_account_class_exists(self):
        """Test that StorageAccount resource class exists."""
        from wetwire_azure.resources.storage import StorageAccount

        assert hasattr(StorageAccount, "__dataclass_fields__")

    def test_virtual_network_class_exists(self):
        """Test that VirtualNetwork resource class exists."""
        from wetwire_azure.resources.network import VirtualNetwork

        assert hasattr(VirtualNetwork, "__dataclass_fields__")


class TestEndToEndCodegen:
    """End-to-end tests for the codegen pipeline."""

    def test_full_pipeline_compute_vm(self):
        """Test full pipeline: fetch -> parse -> generate for Compute VM."""
        from wetwire_azure.codegen.fetch import fetch_schema, get_latest_api_version
        from wetwire_azure.codegen.generate import generate_dataclass
        from wetwire_azure.codegen.parse import parse_schema

        # Get latest API version for VirtualMachines
        api_version = get_latest_api_version(
            "Microsoft.Compute", "virtualMachines"
        )
        assert api_version is not None

        # Fetch schema
        schema = fetch_schema("Microsoft.Compute", "virtualMachines", api_version)
        assert isinstance(schema, dict)

        # Parse schema
        parsed = parse_schema(schema, "VirtualMachine")
        assert parsed["class_name"] == "VirtualMachine"
        assert "fields" in parsed

        # Generate code
        code = generate_dataclass(parsed)
        assert "class VirtualMachine" in code

        # Verify it's valid Python
        compile(code, "<string>", "exec")
