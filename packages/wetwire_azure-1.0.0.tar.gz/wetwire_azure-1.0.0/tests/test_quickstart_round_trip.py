"""Tests for round-trip conversion of Azure Quickstart Templates.

These tests use templates from the Azure Quickstart Templates repository:
https://github.com/Azure/azure-quickstart-templates

The templates are fetched using scripts/fetch_quickstart_templates.py and
stored in tests/fixtures/quickstart/.
"""

import json
from pathlib import Path

import pytest

from wetwire_azure.importer import ArmTemplateImporter
from wetwire_azure.serialize import to_arm_template

# Path to quickstart fixtures
QUICKSTART_DIR = Path(__file__).parent / "fixtures" / "quickstart"


def get_quickstart_templates() -> list[tuple[str, Path]]:
    """Get all quickstart template files for parameterized testing.

    Returns:
        List of (name, path) tuples for each template.
    """
    if not QUICKSTART_DIR.exists():
        return []

    templates = []
    for path in sorted(QUICKSTART_DIR.glob("*.json")):
        templates.append((path.stem, path))

    return templates


def normalize_arm_resource(resource: dict) -> dict:
    """Normalize an ARM resource for semantic comparison.

    This handles differences that don't affect semantic equivalence:
    - Removes empty properties
    - Strips whitespace from strings
    - Normalizes nested structures
    """
    normalized = {}

    for key, value in resource.items():
        if isinstance(value, str):
            normalized[key] = value.strip()
        elif isinstance(value, dict):
            if value:  # Skip empty dicts
                normalized[key] = normalize_arm_resource(value)
        elif isinstance(value, list):
            normalized[key] = [
                normalize_arm_resource(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            normalized[key] = value

    return normalized


def compare_resources(original: dict, generated: dict) -> tuple[bool, str]:
    """Compare two ARM resources for semantic equivalence.

    Args:
        original: Original resource from template.
        generated: Generated resource from round-trip.

    Returns:
        Tuple of (success, message).
    """
    orig_norm = normalize_arm_resource(original)
    gen_norm = normalize_arm_resource(generated)

    # Essential fields to compare
    fields = ["name", "type", "location", "sku", "kind", "properties", "tags"]

    for field in fields:
        orig_val = orig_norm.get(field)
        gen_val = gen_norm.get(field)

        # Skip if both are None/missing
        if orig_val is None and gen_val is None:
            continue

        # Handle empty dicts/properties
        if orig_val == {} and gen_val is None:
            continue
        if orig_val is None and gen_val == {}:
            continue

        if orig_val != gen_val:
            return False, f"Field '{field}' mismatch:\n  Original: {orig_val}\n  Generated: {gen_val}"

    return True, ""


class TestQuickstartRoundTrip:
    """Tests for round-trip conversion of Azure Quickstart Templates."""

    @pytest.mark.parametrize(
        "template_name,template_path",
        get_quickstart_templates(),
        ids=[t[0] for t in get_quickstart_templates()],
    )
    def test_quickstart_template_round_trip(self, template_name: str, template_path: Path):
        """Test round-trip conversion of a quickstart template.

        This test:
        1. Loads the original ARM template
        2. Imports it to Python code
        3. Executes the Python code to create resources
        4. Serializes resources back to ARM JSON
        5. Compares the generated ARM with the original

        Args:
            template_name: Name of the template for test identification.
            template_path: Path to the ARM template JSON file.
        """
        # Load original template
        with open(template_path) as f:
            original_template = json.load(f)

        original_resources = original_template.get("resources", [])
        if not original_resources:
            pytest.skip(f"Template {template_name} has no resources")

        # Step 1: Import ARM JSON -> Python code
        importer = ArmTemplateImporter()
        python_code = importer.import_template(original_template)

        # Verify we got code (not just comments for unsupported types)
        if "Unsupported resource type" in python_code and "StorageAccount(" not in python_code:
            pytest.skip(f"Template {template_name} contains only unsupported resource types")

        # Step 2: Execute Python code -> Resource objects
        namespace = {}
        try:
            exec(python_code, namespace)
        except Exception as e:
            pytest.fail(f"Failed to execute generated code for {template_name}: {e}\n\nCode:\n{python_code}")

        # Extract resource objects
        resources = [obj for name, obj in namespace.items() if name.startswith("resource_")]

        if not resources:
            pytest.skip(f"No resources extracted from {template_name}")

        # Step 3: Serialize resources -> ARM JSON
        generated_template = to_arm_template(resources)
        generated_resources = generated_template.get("resources", [])

        # Step 4: Compare resources
        # Supported types we can compare (exact match only)
        supported_types = {"Microsoft.Storage/storageAccounts"}

        # Sort by name for consistent comparison
        orig_sorted = sorted(
            [r for r in original_resources if r.get("type", "") in supported_types],
            key=lambda r: r.get("name", ""),
        )
        gen_sorted = sorted(generated_resources, key=lambda r: r.get("name", ""))

        if len(orig_sorted) != len(gen_sorted):
            # Only compare storage account resources (our currently supported type)
            if len(gen_sorted) == 0 or len(orig_sorted) == 0:
                pytest.skip(f"No supported resources in {template_name}")

        for i, (orig_res, gen_res) in enumerate(zip(orig_sorted, gen_sorted, strict=False)):
            success, message = compare_resources(orig_res, gen_res)
            if not success:
                pytest.fail(
                    f"Round-trip failed for {template_name} resource {i}:\n{message}\n\n"
                    f"Original:\n{json.dumps(orig_res, indent=2)}\n\n"
                    f"Generated:\n{json.dumps(gen_res, indent=2)}"
                )


class TestQuickstartImport:
    """Tests for importing Azure Quickstart Templates."""

    @pytest.mark.parametrize(
        "template_name,template_path",
        get_quickstart_templates(),
        ids=[t[0] for t in get_quickstart_templates()],
    )
    def test_quickstart_template_imports(self, template_name: str, template_path: Path):
        """Test that quickstart templates can be imported without errors.

        This is a simpler test that just verifies the import doesn't crash.

        Args:
            template_name: Name of the template for test identification.
            template_path: Path to the ARM template JSON file.
        """
        with open(template_path) as f:
            template = json.load(f)

        importer = ArmTemplateImporter()
        python_code = importer.import_template(template)

        # Verify we got some code
        assert python_code, f"No code generated for {template_name}"
        assert '"""Generated from ARM template."""' in python_code

    @pytest.mark.parametrize(
        "template_name,template_path",
        get_quickstart_templates(),
        ids=[t[0] for t in get_quickstart_templates()],
    )
    def test_quickstart_code_executes(self, template_name: str, template_path: Path):
        """Test that generated code can be executed without errors.

        Args:
            template_name: Name of the template for test identification.
            template_path: Path to the ARM template JSON file.
        """
        with open(template_path) as f:
            template = json.load(f)

        importer = ArmTemplateImporter()
        python_code = importer.import_template(template)

        # Execute the code (should not raise)
        namespace = {}
        exec(python_code, namespace)


class TestQuickstartFixtures:
    """Tests for the quickstart fixtures themselves."""

    def test_quickstart_directory_exists(self):
        """Test that the quickstart fixtures directory exists."""
        assert QUICKSTART_DIR.exists(), (
            f"Quickstart fixtures directory does not exist: {QUICKSTART_DIR}\n"
            "Run: python scripts/fetch_quickstart_templates.py"
        )

    def test_quickstart_has_templates(self):
        """Test that at least some quickstart templates are present."""
        templates = get_quickstart_templates()
        assert len(templates) > 0, (
            "No quickstart templates found.\n"
            "Run: python scripts/fetch_quickstart_templates.py"
        )

    def test_all_templates_are_valid_json(self):
        """Test that all quickstart templates are valid JSON."""
        for name, path in get_quickstart_templates():
            with open(path) as f:
                try:
                    template = json.load(f)
                except json.JSONDecodeError as e:
                    pytest.fail(f"Invalid JSON in {name}: {e}")

            # Basic ARM template structure checks
            assert "$schema" in template, f"Missing $schema in {name}"
            assert "resources" in template, f"Missing resources in {name}"
