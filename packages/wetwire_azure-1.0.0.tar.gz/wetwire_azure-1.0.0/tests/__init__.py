"""Tests for wetwire-azure."""
