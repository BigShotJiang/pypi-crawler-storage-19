"""Tests for ARM JSON template importer."""

import json
import tempfile
from pathlib import Path

import pytest

from wetwire_azure.importer import (
    ArmTemplateImporter,
    convert_arm_to_python,
    parse_arm_template,
)


class TestParseArmTemplate:
    """Test parsing ARM JSON templates."""

    def test_parse_minimal_template(self):
        """Test parsing minimal ARM template structure."""
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [],
        }

        result = parse_arm_template(arm_json)

        assert result["schema"] == "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#"
        assert result["contentVersion"] == "1.0.0.0"
        assert result["resources"] == []
        assert result["parameters"] == {}
        assert result["variables"] == {}

    def test_parse_template_with_resources(self):
        """Test parsing template with resources."""
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "mystorageaccount",
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                }
            ],
        }

        result = parse_arm_template(arm_json)

        assert len(result["resources"]) == 1
        assert result["resources"][0]["name"] == "mystorageaccount"
        assert result["resources"][0]["type"] == "Microsoft.Storage/storageAccounts"

    def test_parse_template_with_parameters(self):
        """Test parsing template with parameters."""
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "parameters": {
                "storageAccountName": {
                    "type": "string",
                    "defaultValue": "mystorageaccount",
                }
            },
            "resources": [],
        }

        result = parse_arm_template(arm_json)

        assert "storageAccountName" in result["parameters"]
        assert result["parameters"]["storageAccountName"]["type"] == "string"

    def test_parse_template_with_variables(self):
        """Test parsing template with variables."""
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "variables": {
                "location": "eastus",
                "storageAccountType": "Standard_LRS",
            },
            "resources": [],
        }

        result = parse_arm_template(arm_json)

        assert result["variables"]["location"] == "eastus"
        assert result["variables"]["storageAccountType"] == "Standard_LRS"


class TestConvertArmToPython:
    """Test converting ARM resources to Python code."""

    def test_convert_storage_account(self):
        """Test converting StorageAccount resource to Python code."""
        resource = {
            "name": "mystorageaccount",
            "type": "Microsoft.Storage/storageAccounts",
            "apiVersion": "2023-05-01",
            "location": "eastus",
            "sku": {"name": "Standard_LRS"},
            "kind": "StorageV2",
        }

        python_code = convert_arm_to_python(resource)

        assert "StorageAccount(" in python_code
        assert 'name="mystorageaccount"' in python_code
        assert 'location="eastus"' in python_code
        assert "sku={'name': 'Standard_LRS'}" in python_code or 'sku={"name": "Standard_LRS"}' in python_code
        assert 'kind="StorageV2"' in python_code

    def test_convert_resource_with_tags(self):
        """Test converting resource with tags to Python code."""
        resource = {
            "name": "mystorageaccount",
            "type": "Microsoft.Storage/storageAccounts",
            "apiVersion": "2023-05-01",
            "location": "eastus",
            "sku": {"name": "Standard_LRS"},
            "kind": "StorageV2",
            "tags": {
                "environment": "dev",
                "project": "test",
            },
        }

        python_code = convert_arm_to_python(resource)

        assert "tags=" in python_code
        assert "'environment': 'dev'" in python_code or '"environment": "dev"' in python_code
        assert "'project': 'test'" in python_code or '"project": "test"' in python_code

    def test_convert_resource_with_properties(self):
        """Test converting resource with properties to Python code."""
        resource = {
            "name": "mystorageaccount",
            "type": "Microsoft.Storage/storageAccounts",
            "apiVersion": "2023-05-01",
            "location": "eastus",
            "sku": {"name": "Standard_LRS"},
            "kind": "StorageV2",
            "properties": {
                "supportsHttpsTrafficOnly": True,
            },
        }

        python_code = convert_arm_to_python(resource)

        assert "properties=" in python_code
        assert "'supportsHttpsTrafficOnly': True" in python_code or '"supportsHttpsTrafficOnly": True' in python_code

    def test_convert_unsupported_resource_type(self):
        """Test converting unsupported resource type returns None."""
        resource = {
            "name": "myresource",
            "type": "Microsoft.SomeUnsupported/resourceType",
            "apiVersion": "2023-01-01",
            "location": "eastus",
        }

        python_code = convert_arm_to_python(resource)

        # Unsupported types should return None
        assert python_code is None


class TestArmTemplateImporter:
    """Test the ArmTemplateImporter class."""

    def test_import_minimal_template(self):
        """Test importing minimal template."""
        importer = ArmTemplateImporter()
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [],
        }

        python_code = importer.import_template(arm_json)

        assert "from wetwire_azure.resources.storage import StorageAccount" in python_code or "# No resources" in python_code
        assert isinstance(python_code, str)

    def test_import_template_with_storage_account(self):
        """Test importing template with StorageAccount."""
        importer = ArmTemplateImporter()
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "mystorageaccount",
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                }
            ],
        }

        python_code = importer.import_template(arm_json)

        assert "from wetwire_azure.resources.storage import StorageAccount" in python_code
        assert "StorageAccount(" in python_code
        assert 'name="mystorageaccount"' in python_code

    def test_import_template_with_multiple_resources(self):
        """Test importing template with multiple resources."""
        importer = ArmTemplateImporter()
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "storage1",
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                },
                {
                    "name": "storage2",
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "location": "westus",
                    "sku": {"name": "Premium_LRS"},
                    "kind": "StorageV2",
                },
            ],
        }

        python_code = importer.import_template(arm_json)

        assert python_code.count("StorageAccount(") == 2
        assert 'name="storage1"' in python_code
        assert 'name="storage2"' in python_code

    def test_import_from_file(self):
        """Test importing from a JSON file."""
        importer = ArmTemplateImporter()
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "mystorageaccount",
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                }
            ],
        }

        # Create temporary file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            json.dump(arm_json, f)
            temp_path = Path(f.name)

        try:
            python_code = importer.import_from_file(temp_path)

            assert "from wetwire_azure.resources.storage import StorageAccount" in python_code
            assert "StorageAccount(" in python_code
        finally:
            temp_path.unlink()

    def test_import_from_nonexistent_file(self):
        """Test importing from non-existent file raises error."""
        importer = ArmTemplateImporter()

        with pytest.raises(FileNotFoundError):
            importer.import_from_file(Path("/nonexistent/file.json"))

    def test_import_from_invalid_json(self):
        """Test importing invalid JSON raises error."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("invalid json {]")
            temp_path = Path(f.name)

        try:
            importer = ArmTemplateImporter()
            with pytest.raises(json.JSONDecodeError):
                importer.import_from_file(temp_path)
        finally:
            temp_path.unlink()


class TestGeneratedPythonCode:
    """Test that generated Python code is valid and can be executed."""

    def test_generated_code_is_valid_python(self):
        """Test that generated code is syntactically valid Python."""
        importer = ArmTemplateImporter()
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "mystorageaccount",
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                }
            ],
        }

        python_code = importer.import_template(arm_json)

        # Should compile without errors
        compile(python_code, "<string>", "exec")

    def test_generated_code_uses_camel_case_conversion(self):
        """Test that generated code converts camelCase to snake_case for Python."""
        # This test verifies that ARM properties like "apiVersion" are properly
        # handled (either kept or converted based on the implementation)
        importer = ArmTemplateImporter()
        arm_json = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [
                {
                    "name": "mystorageaccount",
                    "type": "Microsoft.Storage/storageAccounts",
                    "apiVersion": "2023-05-01",
                    "location": "eastus",
                    "sku": {"name": "Standard_LRS"},
                    "kind": "StorageV2",
                }
            ],
        }

        python_code = importer.import_template(arm_json)

        # The generated code should be valid
        compile(python_code, "<string>", "exec")
