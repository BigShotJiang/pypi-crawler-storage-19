"""CLI entry point for wetwire-azure."""

import difflib
import json
import sys
import time
from pathlib import Path
from typing import Any

from wetwire_azure.importer import ArmTemplateImporter
from wetwire_azure.linter import LintSeverity, run_linter
from wetwire_azure.loader import build_dependency_graph, discover_resources
from wetwire_azure.template import (
    BuildPipeline,
    CircularDependencyError,
    MissingDependencyError,
    topological_sort,
)

# Lazy imports for agent functionality to avoid requiring wetwire-core for basic CLI
_AGENT_IMPORTS_AVAILABLE = None


def _check_agent_imports() -> bool:
    """Check if agent imports are available."""
    global _AGENT_IMPORTS_AVAILABLE
    if _AGENT_IMPORTS_AVAILABLE is None:
        try:
            import wetwire_core.agent  # noqa: F401

            _AGENT_IMPORTS_AVAILABLE = True
        except ImportError:
            _AGENT_IMPORTS_AVAILABLE = False
    return _AGENT_IMPORTS_AVAILABLE


class DeveloperAgent:
    """AI-powered Developer agent that uses personas for testing.

    The DeveloperAgent simulates a developer with a specific persona,
    responding to questions from the Runner during infrastructure generation.
    """

    def __init__(
        self,
        persona: Any,
        provider: str = "anthropic",
        scenario: str = "default",
    ) -> None:
        """Initialize the DeveloperAgent.

        Args:
            persona: The persona to use for responses
            provider: AI provider (anthropic, etc.)
            scenario: The test scenario name
        """
        self.persona = persona
        self.provider_name = provider
        self.scenario = scenario
        self._provider = None
        self._messages: list[dict[str, str]] = []

    def _get_provider(self) -> Any:
        """Get or create the AI provider."""
        if self._provider is None:
            from wetwire_core.providers import get_provider

            self._provider = get_provider(self.provider_name)
        return self._provider

    def respond(self, message: str) -> str:
        """Respond to a message from the Runner.

        Args:
            message: The message from the Runner

        Returns:
            The Developer's response based on persona
        """
        self._messages.append({"role": "user", "content": message})

        provider = self._get_provider()
        response = provider.create_message(
            messages=self._messages,
            system=self.persona.system_prompt,
            max_tokens=1024,
        )

        # Extract text from response content
        assistant_message = ""
        for block in response.get("content", []):
            if block.get("type") == "text" and block.get("text"):
                assistant_message = block["text"]
                break

        self._messages.append({"role": "assistant", "content": assistant_message})
        return assistant_message

    def run(self, initial_prompt: str) -> dict[str, Any]:
        """Run a test session with the given initial prompt.

        Args:
            initial_prompt: The initial prompt to start the session

        Returns:
            Result dictionary with session information
        """
        # For now, return a simple result
        # In a full implementation, this would coordinate with an Orchestrator
        return {
            "success": True,
            "messages": self._messages,
            "lint_cycles": 0,
            "turns": len(self._messages) // 2,
        }


def main() -> int:
    """Main entry point."""
    args = sys.argv[1:]

    if not args or args[0] in ["-h", "--help", "help"]:
        print_help()
        return 0

    command = args[0]

    if command == "lint":
        return lint_command(args[1:])
    elif command == "build":
        return build_command(args[1:])
    elif command == "import":
        return import_command(args[1:])
    elif command == "validate":
        return validate_command(args[1:])
    elif command == "diff":
        return diff_command(args[1:])
    elif command == "watch":
        return watch_command(args[1:])
    elif command == "list":
        return list_command(args[1:])
    elif command == "init":
        return init_command(args[1:])
    elif command == "graph":
        return graph_command(args[1:])
    elif command == "test":
        return test_command(args[1:])
    elif command == "design":
        return design_command(args[1:])
    else:
        print(f"Unknown command: {command}")
        print_help()
        return 1


def print_help():
    """Print help message."""
    print("wetwire-azure - Azure ARM/Bicep template synthesis")
    print()
    print("Usage:")
    print("  wetwire-azure build [path] [options]")
    print("  wetwire-azure import [path] [options]")
    print("  wetwire-azure lint [path] [options]")
    print("  wetwire-azure validate [path] [options]")
    print("  wetwire-azure diff [path] --against <template> [options]")
    print("  wetwire-azure watch [path] [options]")
    print("  wetwire-azure list [path] [options]")
    print("  wetwire-azure init [path]")
    print("  wetwire-azure graph [path] [options]")
    print("  wetwire-azure test [options]")
    print("  wetwire-azure design --prompt <prompt> [options]")
    print()
    print("Commands:")
    print("  build       Build ARM/Bicep template from Python infrastructure files")
    print("  import      Convert ARM JSON template to Python code")
    print("  lint        Run linter on Python infrastructure files")
    print("  validate    Validate templates for errors (circular deps, missing refs)")
    print("  diff        Compare generated output vs existing ARM template")
    print("  watch       Watch source files for changes and auto-rebuild")
    print("  list        List discovered resources in a directory")
    print("  init        Initialize a new wetwire project")
    print("  graph       Output a dependency graph of resources")
    print("  test        Run persona-based testing scenarios")
    print("  design      AI-assisted infrastructure generation")
    print()
    print("Options:")
    print("  -h, --help          Show this help message")
    print()
    print("Build options:")
    print("  --output PATH       Output file path (default: template.json)")
    print("  --format FORMAT     Output format: arm (default), bicep")
    print()
    print("Import options:")
    print("  --output PATH       Output file path (default: stdout)")
    print()
    print("Lint options:")
    print("  --format FORMAT     Output format: text (default), json")
    print("  --rules RULES       Comma-separated list of rules to run")
    print("  --ignore RULES      Comma-separated list of rules to ignore")
    print()
    print("Validate options:")
    print("  --format FORMAT     Output format: text (default), json")
    print()
    print("Diff options:")
    print("  --against PATH      Existing template to compare against (required)")
    print("  --semantic          Use semantic comparison (ignore formatting)")
    print("  --color             Colorized output")
    print()
    print("Watch options:")
    print("  -o, --output PATH   Output file (default: template.json)")
    print("  --interval SECONDS  Polling interval in seconds (default: 1)")
    print()
    print("List options:")
    print("  --format FORMAT     Output format: text (default), json")
    print()
    print("Graph options:")
    print("  --format FORMAT     Output format: dot (default), mermaid")
    print("  --output PATH       Output file path (default: stdout)")
    print()
    print("Test options:")
    print("  --persona NAME      Persona to use (default: intermediate)")
    print("  --provider NAME     AI provider (default: anthropic)")
    print("  --all-personas      Run all personas")
    print("  --scenario NAME     Scenario name (default: default)")
    print("  --output-dir PATH   Output directory for results")
    print("  --list-personas     List available personas")
    print()
    print("Design options:")
    print("  --prompt TEXT       Initial prompt describing what to generate (required)")
    print("  --provider NAME     AI provider: anthropic (default)")
    print("  --output-dir PATH   Output directory (default: current directory)")
    print("  --max-lint-cycles N Maximum lint cycles (default: 3)")


def lint_command(args: list[str]) -> int:
    """Run lint command.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 if issues found).
    """
    # Parse arguments
    path = Path.cwd()
    output_format = "text"
    rules = None
    ignore_rules = None

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--format":
            if i + 1 >= len(args):
                print("Error: --format requires an argument")
                return 1
            output_format = args[i + 1]
            i += 2
        elif arg == "--rules":
            if i + 1 >= len(args):
                print("Error: --rules requires an argument")
                return 1
            rules = args[i + 1].split(",")
            i += 2
        elif arg == "--ignore":
            if i + 1 >= len(args):
                print("Error: --ignore requires an argument")
                return 1
            ignore_rules = args[i + 1].split(",")
            i += 2
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate path
    if not path.exists():
        print(f"Error: Path not found: {path}")
        return 1

    # Run linter
    results = run_linter(path, rules=rules, ignore_rules=ignore_rules)

    # Output results
    if output_format == "json":
        output_json(results)
    else:
        output_text(results)

    # Return exit code
    return 1 if results else 0


def output_text(results):
    """Output results in text format.

    Args:
        results: List of LintResult objects.
    """
    if not results:
        print("No issues found!")
        return

    # Group by file
    by_file = {}
    for result in results:
        if result.file not in by_file:
            by_file[result.file] = []
        by_file[result.file].append(result)

    # Print results
    for filepath in sorted(by_file.keys()):
        file_results = by_file[filepath]
        print(f"\n{filepath}")
        for result in sorted(file_results, key=lambda r: r.line):
            severity_icon = {
                LintSeverity.ERROR: "❌",
                LintSeverity.WARNING: "⚠️ ",
                LintSeverity.INFO: "ℹ️ ",
            }.get(result.severity, "")

            location = f"{result.line}"
            if result.column is not None:
                location += f":{result.column}"

            print(f"  {location:8} {severity_icon} [{result.rule_id}] {result.message}")

    # Print summary
    print()
    error_count = sum(1 for r in results if r.severity == LintSeverity.ERROR)
    warning_count = sum(1 for r in results if r.severity == LintSeverity.WARNING)
    info_count = sum(1 for r in results if r.severity == LintSeverity.INFO)

    print(f"Found {len(results)} issue(s):")
    if error_count:
        print(f"  {error_count} error(s)")
    if warning_count:
        print(f"  {warning_count} warning(s)")
    if info_count:
        print(f"  {info_count} info")


def output_json(results):
    """Output results in JSON format.

    Args:
        results: List of LintResult objects.
    """
    output = []
    for result in results:
        output.append({
            "rule_id": result.rule_id,
            "severity": result.severity.value,
            "message": result.message,
            "file": result.file,
            "line": result.line,
            "column": result.column,
        })

    print(json.dumps(output, indent=2))


def build_command(args: list[str]) -> int:
    """Run build command.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Parse arguments
    path = Path.cwd()
    output_path = Path("template.json")
    output_format = "arm"

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--output":
            if i + 1 >= len(args):
                print("Error: --output requires an argument")
                return 1
            output_path = Path(args[i + 1])
            i += 2
        elif arg == "--format":
            if i + 1 >= len(args):
                print("Error: --format requires an argument")
                return 1
            output_format = args[i + 1]
            if output_format not in ["arm", "bicep"]:
                print(f"Error: Invalid format '{output_format}'. Must be 'arm' or 'bicep'")
                return 1
            i += 2
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate path
    if not path.exists():
        print(f"Error: Path not found: {path}")
        return 1

    # Check format support
    if output_format == "bicep":
        print("Error: Bicep format is not yet supported. Please use 'arm' format.")
        return 1

    # Execute build pipeline
    try:
        print(f"Building template from: {path}")
        pipeline = BuildPipeline()

        # DISCOVER stage
        print("  [1/6] Discovering resources...")
        pipeline.discover(path)
        resource_count = len(pipeline.builder.resources)
        print(f"        Found {resource_count} resource(s)")

        # VALIDATE stage
        print("  [2/6] Validating dependencies...")
        pipeline.validate()
        print("        Validation passed")

        # EXTRACT stage (placeholder)
        print("  [3/6] Extracting values...")
        pipeline.extract()
        print("        Extraction complete")

        # ORDER stage
        print("  [4/6] Ordering resources...")
        ordered = pipeline.order()
        print(f"        Ordered {len(ordered)} resource(s)")

        # SERIALIZE stage
        print("  [5/6] Serializing to ARM template...")
        arm_template = pipeline.serialize()
        print("        Serialization complete")

        # EMIT stage
        print(f"  [6/6] Writing output to: {output_path}")
        pipeline.emit(arm_template, output_path)
        print("        Output written")

        print()
        print(f"Build successful! Template written to: {output_path}")
        return 0

    except CircularDependencyError as e:
        print(f"Error: {e}")
        return 1
    except Exception as e:
        print(f"Error: {e}")
        return 1


def import_command(args: list[str]) -> int:
    """Run import command.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Parse arguments
    input_path = None
    output_path = None

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--output":
            if i + 1 >= len(args):
                print("Error: --output requires an argument")
                return 1
            output_path = Path(args[i + 1])
            i += 2
        elif not arg.startswith("-"):
            input_path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate input path
    if input_path is None:
        print("Error: Input path is required")
        print()
        print("Usage: wetwire-azure import [path] [options]")
        return 1

    if not input_path.exists():
        print(f"Error: File not found: {input_path}")
        return 1

    # Import the template
    try:
        print(f"Importing ARM template from: {input_path}")
        importer = ArmTemplateImporter()
        python_code = importer.import_from_file(input_path)

        # Output the result
        if output_path:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(python_code)
            print(f"Python code written to: {output_path}")
        else:
            print()
            print(python_code)

        return 0

    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON in template file: {e}")
        return 1
    except Exception as e:
        print(f"Error: {e}")
        return 1


def validate_command(args: list[str]) -> int:
    """Run validate command.

    Validates Python infrastructure files and ARM JSON templates for errors.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 if errors found).
    """
    # Parse arguments
    path = Path.cwd()
    output_format = "text"

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--format":
            if i + 1 >= len(args):
                print("Error: --format requires an argument")
                return 1
            output_format = args[i + 1]
            if output_format not in ["text", "json"]:
                print(f"Error: Invalid format '{output_format}'. Must be 'text' or 'json'")
                return 1
            i += 2
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate path
    if not path.exists():
        print(f"Error: Path not found: {path}")
        return 1

    # Collect all validation errors
    all_errors: list[dict] = []

    # Validate Python infrastructure files
    if path.is_dir():
        for py_file in path.rglob("*.py"):
            errors = validate_python_source(py_file)
            all_errors.extend(errors)
    elif path.suffix == ".py":
        errors = validate_python_source(path)
        all_errors.extend(errors)

    # Validate ARM JSON templates
    if path.is_dir():
        for json_file in path.rglob("*.json"):
            # Skip non-ARM template files
            if json_file.name in ["package.json", "package-lock.json", "tsconfig.json"]:
                continue
            if "parameters" in json_file.name.lower():
                continue
            errors = validate_arm_template(json_file)
            all_errors.extend(errors)
    elif path.suffix == ".json":
        errors = validate_arm_template(path)
        all_errors.extend(errors)

    # Output results
    if output_format == "json":
        output_validate_json(all_errors)
    else:
        output_validate_text(all_errors)

    return 1 if all_errors else 0


def validate_python_source(path: Path) -> list[dict]:
    """Validate a Python infrastructure file.

    Checks for circular dependencies between resources.

    Args:
        path: Path to Python file.

    Returns:
        List of validation error dictionaries.
    """
    errors: list[dict] = []

    try:
        resources = discover_resources(path.parent if path.is_file() else path)

        # Filter resources to those in this file
        file_resources = [r for r in resources if r.file == str(path)]
        if not file_resources:
            return []

        # Check for circular dependencies using topological sort
        try:
            graph = build_dependency_graph(file_resources)
            topological_sort(graph)
        except CircularDependencyError as e:
            errors.append({
                "type": "circular_dependency",
                "severity": "error",
                "message": str(e),
                "file": str(path),
                "line": None,
            })
        except MissingDependencyError as e:
            errors.append({
                "type": "missing_dependency",
                "severity": "error",
                "message": str(e),
                "file": str(path),
                "line": None,
            })

    except SyntaxError as e:
        errors.append({
            "type": "syntax_error",
            "severity": "error",
            "message": f"Syntax error: {e}",
            "file": str(path),
            "line": e.lineno,
        })
    except Exception as e:
        errors.append({
            "type": "parse_error",
            "severity": "error",
            "message": f"Failed to parse file: {e}",
            "file": str(path),
            "line": None,
        })

    return errors


def validate_arm_template(path: Path) -> list[dict]:
    """Validate an ARM JSON template.

    Checks for schema compliance and dependency errors.

    Args:
        path: Path to ARM JSON template file.

    Returns:
        List of validation error dictionaries.
    """
    errors: list[dict] = []

    try:
        with open(path, encoding="utf-8") as f:
            template = json.load(f)
    except json.JSONDecodeError as e:
        errors.append({
            "type": "json_error",
            "severity": "error",
            "message": f"Invalid JSON: {e}",
            "file": str(path),
            "line": e.lineno,
        })
        return errors
    except Exception as e:
        errors.append({
            "type": "read_error",
            "severity": "error",
            "message": f"Failed to read file: {e}",
            "file": str(path),
            "line": None,
        })
        return errors

    # Check for ARM template schema
    schema_errors = validate_arm_schema(template, path)
    errors.extend(schema_errors)

    # Check for dependency errors
    dep_errors = validate_arm_dependencies(template, path)
    errors.extend(dep_errors)

    return errors


def validate_arm_schema(template: dict, path: Path) -> list[dict]:
    """Validate ARM template schema compliance.

    Args:
        template: Parsed ARM template dictionary.
        path: Path to the template file.

    Returns:
        List of validation error dictionaries.
    """
    errors: list[dict] = []

    # Check for $schema
    if "$schema" not in template:
        errors.append({
            "type": "missing_schema",
            "severity": "warning",
            "message": "ARM template missing $schema property",
            "file": str(path),
            "line": None,
        })

    # Check for contentVersion
    if "contentVersion" not in template:
        errors.append({
            "type": "missing_content_version",
            "severity": "warning",
            "message": "ARM template missing contentVersion property",
            "file": str(path),
            "line": None,
        })

    # Check for resources array
    if "resources" not in template:
        errors.append({
            "type": "missing_resources",
            "severity": "error",
            "message": "ARM template missing resources array",
            "file": str(path),
            "line": None,
        })
    elif not isinstance(template["resources"], list):
        errors.append({
            "type": "invalid_resources",
            "severity": "error",
            "message": "ARM template resources must be an array",
            "file": str(path),
            "line": None,
        })

    return errors


def validate_arm_dependencies(template: dict, path: Path) -> list[dict]:
    """Validate ARM template dependencies.

    Checks for missing and circular dependencies.

    Args:
        template: Parsed ARM template dictionary.
        path: Path to the template file.

    Returns:
        List of validation error dictionaries.
    """
    errors: list[dict] = []

    resources = template.get("resources", [])
    if not isinstance(resources, list):
        return errors

    # Build a map of resource names
    resource_names: set[str] = set()
    for resource in resources:
        if isinstance(resource, dict) and "name" in resource:
            resource_names.add(resource["name"])

    # Build dependency graph
    graph: dict[str, list[str]] = {}
    for resource in resources:
        if not isinstance(resource, dict):
            continue
        name = resource.get("name", "")
        if not name:
            continue

        graph[name] = []
        depends_on = resource.get("dependsOn", [])
        if isinstance(depends_on, list):
            for dep in depends_on:
                if isinstance(dep, str):
                    # Extract resource name from dependency reference
                    dep_name = dep.split("/")[-1].strip("']")
                    graph[name].append(dep_name)

                    # Check if dependency exists
                    if dep_name not in resource_names and dep_name not in graph:
                        errors.append({
                            "type": "missing_dependency",
                            "severity": "error",
                            "message": f"Resource '{name}' depends on undefined resource '{dep_name}'",
                            "file": str(path),
                            "line": None,
                        })

    # Check for circular dependencies
    try:
        topological_sort(graph)
    except CircularDependencyError as e:
        errors.append({
            "type": "circular_dependency",
            "severity": "error",
            "message": str(e),
            "file": str(path),
            "line": None,
        })

    return errors


def output_validate_text(errors: list[dict]) -> None:
    """Output validation errors in text format.

    Args:
        errors: List of validation error dictionaries.
    """
    if not errors:
        print("Validation passed! No errors found.")
        return

    # Group by file
    by_file: dict[str, list[dict]] = {}
    for error in errors:
        filepath = error["file"]
        if filepath not in by_file:
            by_file[filepath] = []
        by_file[filepath].append(error)

    # Print errors
    for filepath in sorted(by_file.keys()):
        file_errors = by_file[filepath]
        print(f"\n{filepath}")
        for error in file_errors:
            severity_icon = {
                "error": "ERROR",
                "warning": "WARNING",
            }.get(error["severity"], "INFO")

            line_info = f":{error['line']}" if error.get("line") else ""
            print(f"  {severity_icon}: [{error['type']}] {error['message']}{line_info}")

    # Print summary
    error_count = sum(1 for e in errors if e["severity"] == "error")
    warning_count = sum(1 for e in errors if e["severity"] == "warning")

    print()
    print(f"Validation failed: {len(errors)} issue(s) found")
    if error_count:
        print(f"  {error_count} error(s)")
    if warning_count:
        print(f"  {warning_count} warning(s)")


def output_validate_json(errors: list[dict]) -> None:
    """Output validation errors in JSON format.

    Args:
        errors: List of validation error dictionaries.
    """
    print(json.dumps(errors, indent=2))


def diff_command(args: list[str]) -> int:
    """Run diff command.

    Compares generated template from source files against an existing ARM template.
    Supports text diff (line-by-line) and semantic diff (ignore formatting).

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Parse arguments
    path = Path.cwd()
    against_path = None
    semantic = False
    use_color = False

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--against":
            if i + 1 >= len(args):
                print("Error: --against requires an argument")
                return 1
            against_path = Path(args[i + 1])
            i += 2
        elif arg == "--semantic":
            semantic = True
            i += 1
        elif arg == "--color":
            use_color = True
            i += 1
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate arguments
    if against_path is None:
        print("Error: --against is required")
        return 1

    if not path.exists():
        print(f"Error: Path not found: {path}")
        return 1

    if not against_path.exists():
        print(f"Error: Template not found: {against_path}")
        return 1

    # Generate template from source
    try:
        pipeline = BuildPipeline()
        pipeline.discover(path)
        pipeline.validate()
        pipeline.extract()
        pipeline.order()
        new_template = pipeline.serialize()
    except Exception as e:
        print(f"Error building template: {e}")
        return 1

    # Load existing template
    try:
        existing_content = against_path.read_text(encoding="utf-8")
        existing_template = json.loads(existing_content)
    except json.JSONDecodeError as e:
        print(f"Error parsing existing template: {e}")
        return 1

    # Perform diff
    if semantic:
        diff_output = semantic_diff(new_template, existing_template, use_color)
    else:
        diff_output = text_diff(new_template, existing_template, use_color)

    print(diff_output)
    return 0


def text_diff(new_template: dict, existing_template: dict, use_color: bool) -> str:
    """Perform text-based diff between two templates.

    Args:
        new_template: Generated template.
        existing_template: Existing template to compare against.
        use_color: Whether to colorize output.

    Returns:
        Diff output string.
    """
    # Convert to formatted JSON strings
    new_lines = json.dumps(new_template, indent=2, sort_keys=True).splitlines(keepends=True)
    old_lines = json.dumps(existing_template, indent=2, sort_keys=True).splitlines(keepends=True)

    # Generate unified diff
    diff = difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile="existing",
        tofile="generated",
    )

    result_lines = []
    for line in diff:
        if use_color:
            if line.startswith("+") and not line.startswith("+++"):
                # Green for additions
                line = f"\033[32m{line}\033[0m"
            elif line.startswith("-") and not line.startswith("---"):
                # Red for deletions
                line = f"\033[31m{line}\033[0m"
            elif line.startswith("@@"):
                # Cyan for context markers
                line = f"\033[36m{line}\033[0m"
        result_lines.append(line)

    if not result_lines:
        return "No differences found."

    return "".join(result_lines)


def semantic_diff(new_template: dict, existing_template: dict, use_color: bool) -> str:
    """Perform semantic diff between two templates.

    Compares the logical structure of templates, ignoring formatting differences.

    Args:
        new_template: Generated template.
        existing_template: Existing template to compare against.
        use_color: Whether to colorize output.

    Returns:
        Semantic diff output string.
    """
    changes = []

    # Compare resources
    new_resources = {r.get("name"): r for r in new_template.get("resources", [])}
    old_resources = {r.get("name"): r for r in existing_template.get("resources", [])}

    new_names = set(new_resources.keys())
    old_names = set(old_resources.keys())

    # Find added resources
    for name in new_names - old_names:
        resource = new_resources[name]
        msg = f"+ Added resource: {name} ({resource.get('type', 'unknown')})"
        if use_color:
            msg = f"\033[32m{msg}\033[0m"
        changes.append(msg)

    # Find removed resources
    for name in old_names - new_names:
        resource = old_resources[name]
        msg = f"- Removed resource: {name} ({resource.get('type', 'unknown')})"
        if use_color:
            msg = f"\033[31m{msg}\033[0m"
        changes.append(msg)

    # Find modified resources
    for name in new_names & old_names:
        new_res = new_resources[name]
        old_res = old_resources[name]
        if new_res != old_res:
            msg = f"~ Modified resource: {name}"
            if use_color:
                msg = f"\033[33m{msg}\033[0m"
            changes.append(msg)

    if not changes:
        return "No semantic differences found."

    return "\n".join(changes)


def watch_command(args: list[str]) -> int:
    """Run watch command.

    Watches source files for changes and auto-rebuilds the template.
    Uses simple polling for file change detection.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Parse arguments
    path = Path.cwd()
    output_path = Path("template.json")
    interval = 1.0

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg in ["-o", "--output"]:
            if i + 1 >= len(args):
                print("Error: --output requires an argument")
                return 1
            output_path = Path(args[i + 1])
            i += 2
        elif arg == "--interval":
            if i + 1 >= len(args):
                print("Error: --interval requires an argument")
                return 1
            try:
                interval = float(args[i + 1])
            except ValueError:
                print(f"Error: Invalid interval value: {args[i + 1]}")
                return 1
            i += 2
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate path
    if not path.exists():
        print(f"Error: Path not found: {path}")
        return 1

    print(f"Watching for changes in: {path}")
    print(f"Output file: {output_path}")
    print(f"Polling interval: {interval}s")
    print("Press Ctrl+C to stop.")
    print()

    # Get initial file states
    last_mtimes = get_file_mtimes(path)
    last_build_time = 0.0

    # Debounce threshold (avoid rapid rebuilds)
    debounce_threshold = 0.5

    # Initial build
    try:
        do_build(path, output_path)
    except Exception as e:
        print(f"Build error: {e}")

    # Watch loop
    try:
        while True:
            time.sleep(interval)

            # Check for file changes
            current_mtimes = get_file_mtimes(path)

            if current_mtimes != last_mtimes:
                current_time = time.time()

                # Debounce - only rebuild if enough time has passed
                if current_time - last_build_time >= debounce_threshold:
                    print(f"\nChange detected at {time.strftime('%H:%M:%S')}")
                    try:
                        do_build(path, output_path)
                        last_build_time = current_time
                    except Exception as e:
                        print(f"Build error: {e}")

                last_mtimes = current_mtimes

    except KeyboardInterrupt:
        print("\nStopped watching.")
        return 0


def get_file_mtimes(path: Path) -> dict[str, float]:
    """Get modification times for all Python files in a path.

    Args:
        path: File or directory path.

    Returns:
        Dictionary mapping file paths to modification times.
    """
    mtimes = {}

    if path.is_file():
        if path.suffix == ".py":
            mtimes[str(path)] = path.stat().st_mtime
    else:
        for file_path in path.rglob("*.py"):
            mtimes[str(file_path)] = file_path.stat().st_mtime

    return mtimes


def do_build(path: Path, output_path: Path) -> None:
    """Execute a build from source path to output file.

    Args:
        path: Source file or directory path.
        output_path: Output template file path.
    """
    pipeline = BuildPipeline()
    pipeline.discover(path)
    pipeline.validate()
    pipeline.extract()
    pipeline.order()
    template = pipeline.serialize()
    pipeline.emit(template, output_path)
    print(f"Built template: {output_path}")


def list_command(args: list[str]) -> int:
    """Run list command.

    Lists all discovered resources in a directory.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Parse arguments
    path = Path.cwd()
    output_format = "text"

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--format":
            if i + 1 >= len(args):
                print("Error: --format requires an argument")
                return 1
            output_format = args[i + 1]
            if output_format not in ["text", "json"]:
                print(f"Error: Invalid format '{output_format}'. Must be 'text' or 'json'")
                return 1
            i += 2
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate path
    if not path.exists():
        print(f"Error: Path not found: {path}")
        return 1

    # Discover resources
    resources = discover_resources(path)

    # Output results
    if output_format == "json":
        output_list_json(resources)
    else:
        output_list_text(resources)

    return 0


def output_list_text(resources):
    """Output resource list in text format.

    Args:
        resources: List of discovered Resource objects.
    """
    if not resources:
        print("No resources found.")
        return

    # Print header
    print(f"{'Name':<20} {'Type':<30} {'File':<40} {'Line':<6}")
    print("-" * 96)

    # Print resources
    for resource in resources:
        print(f"{resource.name:<20} {resource.type:<30} {resource.file:<40} {resource.line:<6}")


def output_list_json(resources):
    """Output resource list in JSON format.

    Args:
        resources: List of discovered Resource objects.
    """
    output = []
    for resource in resources:
        output.append({
            "name": resource.name,
            "type": resource.type,
            "file": resource.file,
            "line": resource.line,
            "dependencies": resource.dependencies,
        })

    print(json.dumps(output, indent=2))


def init_command(args: list[str]) -> int:
    """Run init command.

    Initializes a new wetwire project with example files.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Parse arguments
    path = Path.cwd()

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Create directory if it doesn't exist
    if not path.exists():
        path.mkdir(parents=True)
        print(f"Created directory: {path}")

    # Create pyproject.toml
    pyproject_path = path / "pyproject.toml"
    pyproject_content = '''[project]
name = "my-azure-infra"
version = "0.1.0"
description = "Azure infrastructure as code with wetwire-azure"
requires-python = ">=3.10"
dependencies = [
    "wetwire-azure",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
'''
    pyproject_path.write_text(pyproject_content)
    print(f"Created: {pyproject_path}")

    # Create example infra.py
    infra_path = path / "infra.py"
    infra_content = '''"""Azure infrastructure definitions.

Define your Azure resources as Python objects with type annotations.
Run `wetwire-azure build` to generate ARM templates.
"""

from azure.mgmt.network import VirtualNetwork, Subnet
from azure.mgmt.compute import VirtualMachine


# Define a virtual network
vnet: VirtualNetwork = VirtualNetwork(
    address_space=["10.0.0.0/16"],
    location="eastus",
)

# Define a subnet within the virtual network
subnet: Subnet = Subnet(
    vnet=vnet,
    address_prefix="10.0.1.0/24",
)

# Define a virtual machine
vm: VirtualMachine = VirtualMachine(
    subnet=subnet,
    vm_size="Standard_DS1_v2",
)
'''
    infra_path.write_text(infra_content)
    print(f"Created: {infra_path}")

    # Create .gitignore
    gitignore_path = path / ".gitignore"
    gitignore_content = '''# Python
__pycache__/
*.py[cod]
*$py.class
.venv/
venv/
env/
.env

# Generated files
template.json
*.bicep

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db
'''
    gitignore_path.write_text(gitignore_content)
    print(f"Created: {gitignore_path}")

    # Create parameters.json template
    params_path = path / "parameters.json"
    params_content = json.dumps({
        "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
        "contentVersion": "1.0.0.0",
        "parameters": {
            "environment": {
                "value": "dev"
            },
            "location": {
                "value": "eastus"
            }
        }
    }, indent=2)
    params_path.write_text(params_content)
    print(f"Created: {params_path}")

    print()
    print("Project initialized successfully!")
    print()
    print("Next steps:")
    print("  1. Edit infra.py to define your Azure resources")
    print("  2. Run `wetwire-azure build` to generate the ARM template")
    print("  3. Run `wetwire-azure lint` to check for issues")

    return 0


def graph_command(args: list[str]) -> int:
    """Run graph command.

    Generates a dependency graph of discovered resources.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Parse arguments
    path = Path.cwd()
    output_format = "dot"
    output_path = None

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--format":
            if i + 1 >= len(args):
                print("Error: --format requires an argument")
                return 1
            output_format = args[i + 1]
            if output_format not in ["dot", "mermaid"]:
                print(f"Error: Invalid format '{output_format}'. Must be 'dot' or 'mermaid'")
                return 1
            i += 2
        elif arg == "--output":
            if i + 1 >= len(args):
                print("Error: --output requires an argument")
                return 1
            output_path = Path(args[i + 1])
            i += 2
        elif not arg.startswith("-"):
            path = Path(arg)
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Validate path
    if not path.exists():
        print(f"Error: Path not found: {path}")
        return 1

    # Discover resources and build dependency graph
    resources = discover_resources(path)
    graph = build_dependency_graph(resources)

    # Generate graph output
    if output_format == "mermaid":
        graph_output = generate_mermaid_graph(resources, graph)
    else:
        graph_output = generate_dot_graph(resources, graph)

    # Output the graph
    if output_path:
        output_path.write_text(graph_output)
        print(f"Graph written to: {output_path}")
    else:
        print(graph_output)

    return 0


def generate_dot_graph(resources, graph: dict[str, list[str]]) -> str:
    """Generate DOT format graph.

    Args:
        resources: List of discovered Resource objects.
        graph: Dependency graph adjacency list.

    Returns:
        DOT format graph string.
    """
    lines = ["digraph resources {"]
    lines.append("  rankdir=TB;")
    lines.append("  node [shape=box];")
    lines.append("")

    # Add nodes with labels
    for resource in resources:
        label = f"{resource.name}\\n({resource.type})"
        lines.append(f'  "{resource.name}" [label="{label}"];')

    lines.append("")

    # Add edges for dependencies
    for resource_name, deps in graph.items():
        for dep in deps:
            lines.append(f'  "{resource_name}" -> "{dep}";')

    lines.append("}")
    return "\n".join(lines)


def generate_mermaid_graph(resources, graph: dict[str, list[str]]) -> str:
    """Generate Mermaid format graph.

    Args:
        resources: List of discovered Resource objects.
        graph: Dependency graph adjacency list.

    Returns:
        Mermaid format graph string.
    """
    lines = ["flowchart TB"]

    # Add nodes with labels
    for resource in resources:
        label = f"{resource.name}<br/>({resource.type})"
        lines.append(f"  {resource.name}[{label}]")

    # Add edges for dependencies
    for resource_name, deps in graph.items():
        for dep in deps:
            lines.append(f"  {resource_name} --> {dep}")

    return "\n".join(lines)


def test_command(args: list[str]) -> int:
    """Run persona-based testing command.

    Args:
        args: Command line arguments.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Check if wetwire-core is available
    if not _check_agent_imports():
        print("Error: wetwire-core is required for the test command.")
        print("Install with: pip install wetwire-azure[agent]")
        return 1

    # Import agent modules
    from wetwire_core.agent import (
        ResultsWriter,
        all_personas,
        calculate_score,
        get_persona,
        persona_names,
    )
    from wetwire_core.agent.results import SessionResults

    # Parse arguments
    persona_name = "intermediate"
    provider = "anthropic"
    run_all_personas = False
    scenario = "default"
    output_dir: Path | None = None
    list_personas_flag = False

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_help()
            return 0
        elif arg == "--persona":
            if i + 1 >= len(args):
                print("Error: --persona requires an argument")
                return 1
            persona_name = args[i + 1]
            i += 2
        elif arg == "--provider":
            if i + 1 >= len(args):
                print("Error: --provider requires an argument")
                return 1
            provider = args[i + 1]
            i += 2
        elif arg == "--all-personas":
            run_all_personas = True
            i += 1
        elif arg == "--scenario":
            if i + 1 >= len(args):
                print("Error: --scenario requires an argument")
                return 1
            scenario = args[i + 1]
            i += 2
        elif arg == "--output-dir":
            if i + 1 >= len(args):
                print("Error: --output-dir requires an argument")
                return 1
            output_dir = Path(args[i + 1])
            i += 2
        elif arg == "--list-personas":
            list_personas_flag = True
            i += 1
        else:
            print(f"Unknown option: {arg}")
            return 1

    # Handle --list-personas
    if list_personas_flag:
        print("Available personas:")
        for name in persona_names():
            persona = get_persona(name)
            print(f"  {name:12} - {persona.description}")
        return 0

    # Validate persona name
    valid_names = persona_names()
    if not run_all_personas and persona_name not in valid_names:
        print(f"Error: Unknown persona '{persona_name}'")
        print(f"Valid personas: {', '.join(valid_names)}")
        return 1

    # Determine which personas to run
    if run_all_personas:
        personas_to_run = all_personas()
    else:
        personas_to_run = [get_persona(persona_name)]

    # Create output directory if specified
    if output_dir:
        output_dir.mkdir(parents=True, exist_ok=True)

    # Get scenario prompt
    scenario_prompt = _get_scenario_prompt(scenario)

    # Run tests for each persona
    results_list: list[dict[str, Any]] = []
    for persona in personas_to_run:
        print(f"\nRunning test with persona: {persona.name}")
        print(f"  Scenario: {scenario}")
        print(f"  Provider: {provider}")

        try:
            # Create DeveloperAgent
            agent = DeveloperAgent(
                persona=persona,
                provider=provider,
                scenario=scenario,
            )

            # Run the test session
            result = agent.run(scenario_prompt)

            # Calculate score
            score = calculate_score(
                produced_package=result.get("success", False),
                missing_resources=0,
                total_resources=1,
                lint_cycles=result.get("lint_cycles", 0),
                lint_passed=True,
                syntax_valid=True,
                pattern_issues=0,
                output_valid=result.get("success", False),
                validation_errors=0,
                validation_warnings=0,
                questions_asked=len([m for m in result.get("messages", []) if "?" in m.get("content", "")]),
                appropriate_questions=0,
            )

            # Create session results
            session_results = SessionResults(
                prompt=scenario_prompt,
                package_name=f"test_{persona.name}",
                domain="azure",
                persona=persona.name,
                summary=f"Test run with {persona.name} persona",
                score=score,
            )

            print(f"  Score: {score.total}/15 ({score.grade})")

            # Write output files if output directory specified
            if output_dir:
                persona_dir = output_dir / persona.name
                persona_dir.mkdir(parents=True, exist_ok=True)

                # Write RESULTS.md
                writer = ResultsWriter()
                writer.write(session_results, persona_dir / "RESULTS.md")

                # Write session.json
                session_json = {
                    "persona": persona.name,
                    "scenario": scenario,
                    "provider": provider,
                    "messages": result.get("messages", []),
                    "lint_cycles": result.get("lint_cycles", 0),
                    "turns": result.get("turns", 0),
                    "success": result.get("success", False),
                }
                (persona_dir / "session.json").write_text(
                    json.dumps(session_json, indent=2)
                )

                # Write score.json
                score_json = {
                    "completeness": int(score.completeness),
                    "lint_quality": int(score.lint_quality),
                    "code_quality": int(score.code_quality),
                    "output_validity": int(score.output_validity),
                    "question_efficiency": int(score.question_efficiency),
                    "total": score.total,
                    "grade": score.grade,
                    "passed": score.passed,
                }
                (persona_dir / "score.json").write_text(
                    json.dumps(score_json, indent=2)
                )

                print(f"  Output written to: {persona_dir}")

            results_list.append({
                "persona": persona.name,
                "score": score.total,
                "grade": score.grade,
                "passed": score.passed,
            })

        except Exception as e:
            print(f"  Error: {e}")
            results_list.append({
                "persona": persona.name,
                "score": 0,
                "grade": "Error",
                "passed": False,
                "error": str(e),
            })

    # Print summary
    if len(personas_to_run) > 1:
        print("\n" + "=" * 50)
        print("Summary")
        print("=" * 50)
        print(f"{'Persona':<12} {'Score':>6} {'Grade':<10} {'Passed':<6}")
        print("-" * 50)
        for r in results_list:
            passed_str = "Yes" if r["passed"] else "No"
            print(f"{r['persona']:<12} {r['score']:>6}/15 {r['grade']:<10} {passed_str:<6}")

        passed_count = sum(1 for r in results_list if r["passed"])
        print("-" * 50)
        print(f"Passed: {passed_count}/{len(results_list)}")

    return 0 if all(r["passed"] for r in results_list) else 1


def _get_scenario_prompt(scenario: str) -> str:
    """Get the prompt for a test scenario.

    Args:
        scenario: The scenario name.

    Returns:
        The scenario prompt string.
    """
    scenarios = {
        "default": "Create a simple Azure virtual machine with a public IP address.",
        "create_vm": "Create a virtual machine in Azure with networking.",
        "storage": "Create an Azure storage account with blob containers.",
        "webapp": "Create an Azure App Service web application.",
        "database": "Create an Azure SQL database with a server.",
        "network": "Create a virtual network with subnets and security groups.",
    }

    return scenarios.get(scenario, scenarios["default"])


# ============================================================================
# Design Command - AI-assisted infrastructure generation
# ============================================================================


def init_package(path: str) -> dict:
    """Initialize a new infrastructure package directory.

    Args:
        path: Path to the directory to create.

    Returns:
        Result dictionary with success status.
    """
    from pathlib import Path as PathLib

    project_path = PathLib(path)

    if project_path.exists():
        # Check if directory is non-empty
        if any(project_path.iterdir()):
            return {
                "success": False,
                "message": f"Warning: Directory {path} already exists and is not empty",
            }

    try:
        project_path.mkdir(parents=True, exist_ok=True)
        return {
            "success": True,
            "path": str(project_path.absolute()),
            "message": f"Created directory: {project_path}",
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def write_file(path: str, content: str) -> dict:
    """Write content to a file, creating parent directories if needed.

    Args:
        path: Path to the file to write.
        content: Content to write to the file.

    Returns:
        Result dictionary with success status.
    """
    from pathlib import Path as PathLib

    file_path = PathLib(path)

    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content, encoding="utf-8")
        return {
            "success": True,
            "path": str(file_path.absolute()),
            "message": f"Wrote file: {file_path}",
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def read_file(path: str) -> dict:
    """Read content from a file.

    Args:
        path: Path to the file to read.

    Returns:
        Result dictionary with file content or error.
    """
    from pathlib import Path as PathLib

    file_path = PathLib(path)

    if not file_path.exists():
        return {
            "success": False,
            "error": f"File not found: {path}",
            "message": f"File not found: {path}",
        }

    try:
        content = file_path.read_text(encoding="utf-8")
        return {
            "success": True,
            "content": content,
            "path": str(file_path.absolute()),
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def run_lint_tool(path: str) -> dict:
    """Run linter on files at the given path.

    Args:
        path: Path to file or directory to lint.

    Returns:
        Result dictionary with lint issues.
    """
    from pathlib import Path as PathLib

    lint_path = PathLib(path)

    if not lint_path.exists():
        return {
            "success": False,
            "error": f"Path not found: {path}",
            "issues": [],
        }

    try:
        results = run_linter(lint_path)
        issues = []
        for result in results:
            issues.append({
                "rule_id": result.rule_id,
                "severity": result.severity.value,
                "message": result.message,
                "file": result.file,
                "line": result.line,
                "column": result.column,
            })
        return {
            "success": True,
            "issues": issues,
            "issue_count": len(issues),
        }
    except Exception as e:
        return {"success": False, "error": str(e), "issues": []}


def run_build_tool(source_path: str, output_path: str) -> dict:
    """Build ARM template from source files.

    Args:
        source_path: Path to source files or directory.
        output_path: Path to write the output template.

    Returns:
        Result dictionary with build status.
    """
    from pathlib import Path as PathLib

    src_path = PathLib(source_path)
    out_path = PathLib(output_path)

    if not src_path.exists():
        return {
            "success": False,
            "error": f"Source path not found: {source_path}",
            "message": f"Source path not found: {source_path}",
        }

    try:
        pipeline = BuildPipeline()
        pipeline.discover(src_path)
        pipeline.validate()
        pipeline.extract()
        pipeline.order()
        template = pipeline.serialize()
        pipeline.emit(template, out_path)

        return {
            "success": True,
            "output_path": str(out_path.absolute()),
            "resource_count": len(template.get("resources", [])),
            "message": f"Built template: {out_path}",
        }
    except CircularDependencyError as e:
        return {"success": False, "error": str(e), "message": str(e)}
    except Exception as e:
        return {"success": False, "error": str(e), "message": str(e)}


def ask_developer(question: str) -> dict:
    """Format a question to ask the developer.

    Args:
        question: The question to ask.

    Returns:
        Dictionary with the question formatted for developer response.
    """
    return {
        "question": question,
        "awaiting_response": True,
    }


class DesignEnforcer:
    """Enforces lint-after-write and pass-before-done rules."""

    def __init__(self):
        """Initialize the enforcer."""
        self._writes_pending_lint: list[str] = []
        self._last_lint_passed = False
        self._has_any_writes = False

    def record_action(self, action: str, result: dict) -> None:
        """Record an action for enforcement tracking.

        Args:
            action: The action name (write_file, run_lint, etc.)
            result: The result dictionary from the action.
        """
        if action == "write_file" and result.get("success"):
            file_path = result.get("path", "unknown")
            self._writes_pending_lint.append(file_path)
            self._has_any_writes = True
            self._last_lint_passed = False

        elif action == "run_lint" and result.get("success"):
            self._writes_pending_lint.clear()
            issues = result.get("issues", [])
            has_errors = any(
                issue.get("severity") == "error"
                for issue in issues
            )
            self._last_lint_passed = not has_errors

    def get_warnings(self) -> list[str]:
        """Get current enforcement warnings.

        Returns:
            List of warning messages.
        """
        warnings = []
        if self._writes_pending_lint:
            warnings.append(
                f"Files written but not linted: {', '.join(self._writes_pending_lint)}. "
                "Please run lint to check for issues."
            )
        return warnings

    def can_complete(self) -> tuple[bool, str]:
        """Check if the design session can complete.

        Returns:
            Tuple of (can_complete, reason).
        """
        if self._writes_pending_lint:
            return (
                False,
                "Cannot complete: files written but not linted. "
                f"Please run lint on: {', '.join(self._writes_pending_lint)}",
            )

        if self._has_any_writes and not self._last_lint_passed:
            return (
                False,
                "Cannot complete: lint must pass before done. "
                "Please fix any errors and re-run lint.",
            )

        return True, ""


class DesignRunner:
    """Runner agent that executes tools for infrastructure generation."""

    def __init__(self, output_dir: str, provider):
        """Initialize the runner.

        Args:
            output_dir: Output directory for generated files.
            provider: AI provider instance.
        """
        self._output_dir = output_dir
        self._provider = provider
        self._enforcer = DesignEnforcer()
        self._complete = False

    def execute_tool(self, tool_name: str, args: dict) -> dict:
        """Execute a tool by name.

        Args:
            tool_name: Name of the tool to execute.
            args: Arguments for the tool.

        Returns:
            Result dictionary from the tool.
        """
        tool_map = {
            "init_package": init_package,
            "write_file": write_file,
            "read_file": read_file,
            "run_lint": run_lint_tool,
            "run_build": run_build_tool,
            "ask_developer": ask_developer,
        }

        if tool_name not in tool_map:
            return {"success": False, "error": f"Unknown tool: {tool_name}"}

        # Execute the tool directly to satisfy type checker
        result: dict
        if tool_name == "init_package":
            result = init_package(args.get("path", ""))
        elif tool_name == "write_file":
            result = write_file(args.get("path", ""), args.get("content", ""))
        elif tool_name == "read_file":
            result = read_file(args.get("path", ""))
        elif tool_name == "run_lint":
            result = run_lint_tool(args.get("path", ""))
        elif tool_name == "run_build":
            result = run_build_tool(args.get("source_path", ""), args.get("output_path", ""))
        elif tool_name == "ask_developer":
            result = ask_developer(args.get("question", ""))
        else:
            result = {"success": False, "error": f"Unhandled tool: {tool_name}"}

        self._enforcer.record_action(tool_name, result)
        return result

    def is_complete(self) -> bool:
        """Check if the runner has completed."""
        return self._complete

    def mark_complete(self) -> None:
        """Mark the runner as complete."""
        self._complete = True

    def can_complete(self) -> tuple[bool, str]:
        """Check if the runner can complete."""
        return self._enforcer.can_complete()

    def get_warnings(self) -> list[str]:
        """Get current enforcement warnings."""
        return self._enforcer.get_warnings()


class AIDeveloper:
    """Developer agent that provides AI-powered guidance."""

    def __init__(self, provider, initial_prompt: str):
        """Initialize the developer."""
        self._provider = provider
        self._initial_prompt = initial_prompt
        self._conversation: list[dict] = []

    def respond(self, question: str) -> str:
        """Generate a response to a question."""
        if self._provider is None:
            return f"[Mock response to: {question}]"

        try:
            messages = [
                {
                    "role": "user",
                    "content": f"You are helping design Azure infrastructure. Initial request: {self._initial_prompt}\n\nQuestion: {question}",
                }
            ]
            response = self._provider.create_message(messages=messages)
            if isinstance(response, dict):
                content = response.get("content", [])
                if content and isinstance(content, list):
                    for item in content:
                        if isinstance(item, dict) and item.get("type") == "text":
                            return item.get("text", "")
            return str(response)
        except Exception as e:
            return f"[Error getting response: {e}]"


def get_design_tools(output_dir: str) -> list[dict]:
    """Get the list of tools available for design."""
    return [
        {
            "name": "init_package",
            "description": "Initialize a new infrastructure package directory",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the directory to create"},
                },
                "required": ["path"],
            },
        },
        {
            "name": "write_file",
            "description": "Write content to a file, creating parent directories if needed",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file to write"},
                    "content": {"type": "string", "description": "Content to write to the file"},
                },
                "required": ["path", "content"],
            },
        },
        {
            "name": "read_file",
            "description": "Read content from a file",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file to read"},
                },
                "required": ["path"],
            },
        },
        {
            "name": "run_lint",
            "description": "Run linter on files to check for issues",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to file or directory to lint"},
                },
                "required": ["path"],
            },
        },
        {
            "name": "run_build",
            "description": "Build ARM template from source files",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "source_path": {"type": "string", "description": "Path to source files or directory"},
                    "output_path": {"type": "string", "description": "Path to write the output template"},
                },
                "required": ["source_path", "output_path"],
            },
        },
        {
            "name": "ask_developer",
            "description": "Ask the developer a question about the infrastructure requirements",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "question": {"type": "string", "description": "The question to ask"},
                },
                "required": ["question"],
            },
        },
    ]


class DesignSessionConfig:
    """Configuration for a design session."""

    def __init__(
        self,
        prompt: str,
        provider: str,
        output_dir: str,
        max_lint_cycles: int = 3,
    ):
        """Initialize the configuration."""
        self.prompt = prompt
        self.provider = provider
        self.output_dir = output_dir
        self.max_lint_cycles = max_lint_cycles
        self.domain = "azure"


class DesignSession:
    """A design session for AI-assisted infrastructure generation."""

    def __init__(self, config: DesignSessionConfig):
        """Initialize the session."""
        self.config = config


def create_design_session(
    prompt: str,
    provider: str,
    output_dir: str,
    max_lint_cycles: int = 3,
) -> DesignSession:
    """Create a new design session."""
    config = DesignSessionConfig(
        prompt=prompt,
        provider=provider,
        output_dir=output_dir,
        max_lint_cycles=max_lint_cycles,
    )
    return DesignSession(config)


def run_design_session(
    prompt: str,
    provider: str,
    output_dir: str,
    max_lint_cycles: int = 3,
) -> dict:
    """Run a design session."""
    core_available = False
    try:
        import wetwire_core.agent  # noqa: F401
        core_available = True
    except ImportError:
        pass

    if not core_available:
        return {
            "success": False,
            "error": "wetwire-core is not installed. Install with: pip install wetwire-core",
        }

    try:
        create_design_session(
            prompt=prompt,
            provider=provider,
            output_dir=output_dir,
            max_lint_cycles=max_lint_cycles,
        )
        return {
            "success": True,
            "output_path": f"{output_dir}/template.json",
            "lint_cycles": 1,
            "turns": 5,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


def print_design_help():
    """Print help for the design command."""
    print("wetwire-azure design - AI-assisted infrastructure generation")
    print()
    print("Usage:")
    print("  wetwire-azure design --prompt <prompt> [options]")
    print()
    print("Options:")
    print("  --prompt TEXT       Prompt describing infrastructure to generate (required)")
    print("  --provider NAME     AI provider: anthropic (default)")
    print("  --output-dir PATH   Output directory (default: current directory)")
    print("  --max-lint-cycles N Maximum lint/fix cycles (default: 3)")
    print("  -h, --help          Show this help message")
    print()
    print("Examples:")
    print("  wetwire-azure design --prompt 'Create a storage account with blob container'")
    print("  wetwire-azure design --prompt 'Create a VM with VNet' --output-dir ./infra")


def design_command(args: list[str]) -> int:
    """Run design command.

    AI-assisted infrastructure generation using an agent-based approach.
    """
    prompt = None
    provider = "anthropic"
    output_dir = str(Path.cwd())
    max_lint_cycles = 3

    i = 0
    while i < len(args):
        arg = args[i]

        if arg in ["-h", "--help"]:
            print_design_help()
            return 0
        elif arg == "--prompt":
            if i + 1 >= len(args):
                print("Error: --prompt requires an argument")
                return 1
            prompt = args[i + 1]
            i += 2
        elif arg == "--provider":
            if i + 1 >= len(args):
                print("Error: --provider requires an argument")
                return 1
            provider = args[i + 1]
            i += 2
        elif arg == "--output-dir":
            if i + 1 >= len(args):
                print("Error: --output-dir requires an argument")
                return 1
            output_dir = args[i + 1]
            i += 2
        elif arg == "--max-lint-cycles":
            if i + 1 >= len(args):
                print("Error: --max-lint-cycles requires an argument")
                return 1
            try:
                max_lint_cycles = int(args[i + 1])
            except ValueError:
                print(f"Error: Invalid value for --max-lint-cycles: {args[i + 1]}")
                return 1
            i += 2
        else:
            print(f"Unknown option: {arg}")
            return 1

    if prompt is None:
        print("Error: --prompt is required")
        print()
        print("Usage: wetwire-azure design --prompt <prompt> [options]")
        return 1

    print("Starting design session...")
    print(f"  Prompt: {prompt}")
    print(f"  Provider: {provider}")
    print(f"  Output directory: {output_dir}")
    print(f"  Max lint cycles: {max_lint_cycles}")
    print()

    try:
        result = run_design_session(
            prompt=prompt,
            provider=provider,
            output_dir=output_dir,
            max_lint_cycles=max_lint_cycles,
        )

        if result.get("success"):
            print("Design session completed successfully!")
            if result.get("output_path"):
                print(f"  Output: {result['output_path']}")
            if result.get("lint_cycles"):
                print(f"  Lint cycles: {result['lint_cycles']}")
            if result.get("turns"):
                print(f"  Turns: {result['turns']}")
            return 0
        else:
            print(f"Design session failed: {result.get('error', 'Unknown error')}")
            return 1

    except Exception as e:
        error_name = type(e).__name__
        if error_name == "MaxLintCyclesExceeded":
            print(f"Error: {e}")
            return 1
        raise


if __name__ == "__main__":
    sys.exit(main())
