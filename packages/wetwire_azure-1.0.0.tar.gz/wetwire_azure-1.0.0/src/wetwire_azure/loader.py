"""Resource discovery via AST parsing.

This module discovers Azure resources from Python source files without
executing any code. It uses AST parsing to find resource definitions
and their dependencies.
"""

import ast
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Resource:
    """Discovered resource from source file."""

    name: str  # Variable name
    type: str  # Resource type (e.g., "VirtualMachine")
    file: str  # Source file path
    line: int  # Line number
    dependencies: list[str] = field(default_factory=list)  # Referenced resource names


class ResourceVisitor(ast.NodeVisitor):
    """AST visitor to discover resources and their dependencies."""

    def __init__(self, filepath: str):
        """Initialize visitor.

        Args:
            filepath: Path to the file being parsed.
        """
        self.filepath = filepath
        self.resources: list[Resource] = []
        self.imported_types: set[str] = set()

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        """Track imports from azure.mgmt and wetwire_azure.resources modules.

        Args:
            node: ImportFrom AST node.
        """
        if node.module and (
            node.module.startswith("azure.mgmt.")
            or node.module.startswith("wetwire_azure.resources.")
        ):
            for alias in node.names:
                self.imported_types.add(alias.name)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        """Visit annotated assignment to discover resources.

        Args:
            node: AnnAssign AST node.
        """
        # Check if this is a top-level assignment
        if isinstance(node.target, ast.Name):
            var_name = node.target.id

            # Check if the annotation is an Azure resource type
            resource_type = self._extract_type_name(node.annotation)
            if resource_type and resource_type in self.imported_types:
                # Extract dependencies from the initializer
                dependencies = []
                if node.value:
                    dependencies = self._extract_dependencies(node.value)

                resource = Resource(
                    name=var_name,
                    type=resource_type,
                    file=self.filepath,
                    line=node.lineno,
                    dependencies=dependencies,
                )
                self.resources.append(resource)

        self.generic_visit(node)

    def _extract_type_name(self, annotation: ast.expr) -> str | None:
        """Extract type name from annotation.

        Args:
            annotation: AST expression representing the type annotation.

        Returns:
            Type name as string, or None if not a simple name.
        """
        if isinstance(annotation, ast.Name):
            return annotation.id
        return None

    def _extract_dependencies(self, node: ast.expr) -> list[str]:
        """Extract resource dependencies from an expression.

        This finds all Name nodes in the expression that could be
        references to other resources.

        Args:
            node: AST expression to analyze.

        Returns:
            List of variable names that are potential dependencies.
        """
        dependencies = set()

        class DependencyExtractor(ast.NodeVisitor):
            def visit_Name(self, node: ast.Name) -> None:
                # Add variable references as potential dependencies
                if isinstance(node.ctx, ast.Load):
                    dependencies.add(node.id)
                self.generic_visit(node)

        extractor = DependencyExtractor()
        extractor.visit(node)

        return sorted(dependencies)


def discover_resources(path: Path) -> list[Resource]:
    """Discover all Azure resources in Python source files.

    Uses AST parsing - no code execution.

    Args:
        path: Directory or file path to scan for resources.

    Returns:
        List of discovered resources.
    """
    resources = []

    # Get all Python files to scan
    if path.is_file():
        python_files = [path]
    elif path.is_dir():
        python_files = list(path.rglob("*.py"))
    else:
        return []

    # Parse each file and extract resources
    for py_file in python_files:
        try:
            source = py_file.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(py_file))

            visitor = ResourceVisitor(str(py_file))
            visitor.visit(tree)

            resources.extend(visitor.resources)
        except SyntaxError:
            # Skip files with syntax errors
            continue
        except Exception:
            # Skip files that can't be read or parsed
            continue

    return resources


def build_dependency_graph(resources: list[Resource]) -> dict[str, list[str]]:
    """Build adjacency list of resource dependencies.

    Args:
        resources: List of discovered resources.

    Returns:
        Dictionary mapping resource names to their dependencies.
    """
    graph = {}

    # Get all resource names
    resource_names = {r.name for r in resources}

    # Build adjacency list, filtering to only actual resources
    for resource in resources:
        # Only include dependencies that are actual resources
        valid_deps = [dep for dep in resource.dependencies if dep in resource_names]
        graph[resource.name] = valid_deps

    return graph
