"""Template builder and build pipeline.

This module implements the build pipeline for converting Python resource
definitions into ARM templates. It follows these stages:

1. DISCOVER - Parse source files, find resource declarations
2. VALIDATE - Check references exist, detect cycles
3. EXTRACT - Execute source to get runtime values (placeholder)
4. ORDER - Topological sort by dependencies (Kahn's algorithm)
5. SERIALIZE - Convert to ARM JSON
6. EMIT - Write output file
"""

import json
from pathlib import Path

from wetwire_azure.loader import Resource, build_dependency_graph, discover_resources


class CircularDependencyError(Exception):
    """Raised when a circular dependency is detected."""

    pass


class MissingDependencyError(Exception):
    """Raised when a resource references a non-existent dependency."""

    pass


def topological_sort(graph: dict[str, list[str]]) -> list[str]:
    """Sort resources topologically using Kahn's algorithm.

    Implements Kahn's algorithm for topological sorting as specified in
    section 8.2. Detects and reports circular dependencies.

    The graph maps each node to its dependencies (what it depends on).
    The algorithm returns nodes in order such that all dependencies
    come before the nodes that depend on them.

    Args:
        graph: Adjacency list mapping node names to their dependencies.

    Returns:
        List of node names in topologically sorted order.

    Raises:
        CircularDependencyError: If a circular dependency is detected.
    """
    if not graph:
        return []

    # Calculate in-degree for each node (number of dependencies)
    in_degree = {node: len(deps) for node, deps in graph.items()}

    # Find all nodes with in-degree 0 (no dependencies)
    queue = [node for node in in_degree if in_degree[node] == 0]
    result = []

    while queue:
        # Remove a node from the queue
        node = queue.pop(0)
        result.append(node)

        # For each node that depends on this node
        for other_node, deps in graph.items():
            if node in deps:
                # Decrement in-degree (one dependency satisfied)
                in_degree[other_node] -= 1
                if in_degree[other_node] == 0:
                    queue.append(other_node)

    # If we haven't processed all nodes, there's a cycle
    if len(result) != len(graph):
        unprocessed = set(graph.keys()) - set(result)
        raise CircularDependencyError(
            f"Circular dependency detected involving nodes: {unprocessed}"
        )

    return result


class TemplateBuilder:
    """Builder for ARM templates from discovered resources.

    Coordinates the validation, ordering, and serialization of resources
    into ARM template format.
    """

    def __init__(self):
        """Initialize the template builder."""
        self.resources: list[Resource] = []

    def add_resource(self, resource: Resource) -> None:
        """Add a resource to the builder.

        Args:
            resource: Resource to add.
        """
        self.resources.append(resource)

    def validate(self) -> None:
        """Validate all resources and their dependencies.

        Checks that:
        1. All referenced dependencies exist (after filtering to actual resources)
        2. There are no circular dependencies

        Raises:
            MissingDependencyError: If a dependency doesn't exist.
            CircularDependencyError: If circular dependencies are detected.
        """
        # Build dependency graph (this filters to only actual resources)
        graph = build_dependency_graph(self.resources)

        # The graph already filters out non-resource dependencies,
        # so we just need to check for cycles
        try:
            topological_sort(graph)
        except CircularDependencyError:
            raise

    def order_resources(self) -> list[Resource]:
        """Order resources by dependencies using topological sort.

        Returns:
            List of resources in dependency order (dependencies first).
        """
        graph = build_dependency_graph(self.resources)
        sorted_names = topological_sort(graph)

        # Create a map for quick lookup
        resource_map = {r.name: r for r in self.resources}

        # Return resources in sorted order
        return [resource_map[name] for name in sorted_names]

    def serialize_to_arm(self) -> dict:
        """Serialize resources to ARM template format.

        Converts the resources into a valid ARM template JSON structure,
        including proper dependsOn arrays.

        Returns:
            Dictionary representing the ARM template.
        """
        # Order resources first
        ordered_resources = self.order_resources()

        # Build filtered dependency graph
        graph = build_dependency_graph(self.resources)

        # Build the ARM template structure
        arm_template = {
            "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
            "contentVersion": "1.0.0.0",
            "resources": [],
        }

        # Convert each resource to ARM format
        for resource in ordered_resources:
            arm_resource = {
                "name": resource.name,
                "type": f"Microsoft.{resource.type}",  # Simplified type mapping
                "apiVersion": "2023-01-01",  # Placeholder version
                "location": "[resourceGroup().location]",  # Default location
                "properties": {},
            }

            # Add dependsOn if there are dependencies (use filtered graph)
            filtered_deps = graph.get(resource.name, [])
            if filtered_deps:
                arm_resource["dependsOn"] = filtered_deps

            arm_template["resources"].append(arm_resource)

        return arm_template


class BuildPipeline:
    """Orchestrates the complete build pipeline.

    Coordinates all stages from discovery through emission:
    DISCOVER -> VALIDATE -> EXTRACT -> ORDER -> SERIALIZE -> EMIT
    """

    def __init__(self):
        """Initialize the build pipeline."""
        self.builder = TemplateBuilder()

    def discover(self, path: Path) -> None:
        """DISCOVER stage: Parse source files and find resource declarations.

        Args:
            path: Path to source files or directory.
        """
        resources = discover_resources(path)
        for resource in resources:
            self.builder.add_resource(resource)

    def validate(self) -> None:
        """VALIDATE stage: Check references exist and detect cycles.

        Raises:
            MissingDependencyError: If a dependency doesn't exist.
            CircularDependencyError: If circular dependencies are detected.
        """
        self.builder.validate()

    def extract(self) -> None:
        """EXTRACT stage: Execute source to get runtime values.

        This is a placeholder for future implementation. Will eventually
        execute the Python source files to extract actual runtime values
        from resource definitions.
        """
        # TODO: Implement runtime extraction
        pass

    def order(self) -> list[Resource]:
        """ORDER stage: Topologically sort resources by dependencies.

        Returns:
            List of resources in dependency order.
        """
        return self.builder.order_resources()

    def serialize(self) -> dict:
        """SERIALIZE stage: Convert to ARM JSON format.

        Returns:
            Dictionary representing the ARM template.
        """
        return self.builder.serialize_to_arm()

    def emit(self, arm_template: dict, output_path: Path) -> None:
        """EMIT stage: Write output file.

        Args:
            arm_template: ARM template dictionary to write.
            output_path: Path where the template should be written.
        """
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(arm_template, f, indent=2)
