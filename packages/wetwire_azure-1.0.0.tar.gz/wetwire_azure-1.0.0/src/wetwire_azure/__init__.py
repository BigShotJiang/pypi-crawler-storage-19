"""wetwire-azure - Azure ARM/Bicep template synthesis for wetwire."""

__version__ = "0.1.0"
