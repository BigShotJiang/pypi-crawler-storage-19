"""Serialization utilities for converting dataclasses to ARM JSON templates."""

from dataclasses import dataclass, fields, is_dataclass
from typing import Any


@dataclass
class ResourceReference:
    """Reference to an Azure resource ID."""

    resource_type: str
    resource_name: str | list[str]

    def to_arm_expression(self) -> str:
        """Convert to ARM resourceId() expression."""
        if isinstance(self.resource_name, str):
            names = f"'{self.resource_name}'"
        else:
            names = ", ".join(f"'{name}'" for name in self.resource_name)
        return f"[resourceId('{self.resource_type}', {names})]"


@dataclass
class AttributeReference:
    """Reference to an attribute of an Azure resource."""

    resource_type: str
    resource_name: str | list[str]
    attribute_path: str

    def to_arm_expression(self) -> str:
        """Convert to ARM reference() expression with attribute access."""
        if isinstance(self.resource_name, str):
            names = f"'{self.resource_name}'"
        else:
            names = ", ".join(f"'{name}'" for name in self.resource_name)
        return f"[reference(resourceId('{self.resource_type}', {names})).{self.attribute_path}]"


@dataclass
class ParameterReference:
    """Reference to an ARM template parameter."""

    parameter_name: str

    def to_arm_expression(self) -> str:
        """Convert to ARM parameters() expression."""
        return f"[parameters('{self.parameter_name}')]"


@dataclass
class VariableReference:
    """Reference to an ARM template variable."""

    variable_name: str

    def to_arm_expression(self) -> str:
        """Convert to ARM variables() expression."""
        return f"[variables('{self.variable_name}')]"


def _snake_to_camel(snake_str: str) -> str:
    """Convert snake_case to camelCase.

    Args:
        snake_str: String in snake_case format

    Returns:
        String in camelCase format
    """
    components = snake_str.split('_')
    # Keep first component as-is, capitalize the rest
    return components[0] + ''.join(x.title() for x in components[1:])


def _serialize_value(value: Any) -> Any:
    """Serialize a value, handling special types.

    Args:
        value: Value to serialize

    Returns:
        Serialized value suitable for JSON
    """
    # Handle None
    if value is None:
        return None

    # Handle ARM reference types
    if isinstance(value, (ResourceReference, AttributeReference, ParameterReference, VariableReference)):
        return value.to_arm_expression()

    # Handle dataclasses
    if is_dataclass(value) and not isinstance(value, type):
        return to_arm_dict(value)

    # Handle lists
    if isinstance(value, list):
        return [_serialize_value(item) for item in value]

    # Handle dicts
    if isinstance(value, dict):
        return {key: _serialize_value(val) for key, val in value.items()}

    # Handle primitives (str, int, bool, float, etc.)
    return value


def to_arm_dict(obj: Any) -> dict[str, Any]:
    """Convert a dataclass instance to a dictionary suitable for ARM JSON.

    This function:
    - Converts snake_case field names to camelCase
    - Omits fields with None values
    - Recursively processes nested dataclasses
    - Handles lists and dicts containing dataclasses
    - Converts ARM reference types to their string expressions

    Args:
        obj: Dataclass instance to convert

    Returns:
        Dictionary representation suitable for ARM template JSON

    Raises:
        ValueError: If obj is not a dataclass instance
    """
    if not is_dataclass(obj) or isinstance(obj, type):
        raise ValueError(f"Expected dataclass instance, got {type(obj)}")

    result = {}

    for field in fields(obj):
        value = getattr(obj, field.name)

        # Skip None values
        if value is None:
            continue

        # Convert field name to camelCase
        camel_name = _snake_to_camel(field.name)

        # Serialize the value
        result[camel_name] = _serialize_value(value)

    return result


def to_arm_template(
    resources: list[Any],
    parameters: dict[str, Any] | None = None,
    variables: dict[str, Any] | None = None,
    outputs: dict[str, Any] | None = None,
    schema: str = "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
    content_version: str = "1.0.0.0",
) -> dict[str, Any]:
    """Generate a complete ARM template from resources and optional sections.

    Args:
        resources: List of resource dataclass instances
        parameters: Optional ARM template parameters
        variables: Optional ARM template variables
        outputs: Optional ARM template outputs
        schema: ARM template schema URL
        content_version: Template content version

    Returns:
        Complete ARM template as a dictionary
    """
    template = {
        "$schema": schema,
        "contentVersion": content_version,
        "parameters": parameters or {},
        "variables": variables or {},
        "resources": [to_arm_dict(resource) for resource in resources],
        "outputs": outputs or {},
    }

    return template


__all__ = [
    "to_arm_dict",
    "to_arm_template",
    "ResourceReference",
    "AttributeReference",
    "ParameterReference",
    "VariableReference",
]
