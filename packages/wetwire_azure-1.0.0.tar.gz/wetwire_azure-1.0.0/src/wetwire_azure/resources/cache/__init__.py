"""Azure Cache for Redis resource types."""

from dataclasses import dataclass
from typing import Any


@dataclass
class RedisCache:
    """Generated Redis Cache resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # SKU for the Redis Cache
    sku: dict[str, Any] | None = None

    # Resource tags
    tags: dict[str, str] | None = None

    # Redis properties (enableNonSslPort, minimumTlsVersion, etc.)
    properties: dict[str, Any] | None = None

    # Zones
    zones: list[str] | None = None

    # Identity
    identity: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Cache/redis"

    # API version
    api_version: str = "2024-03-01"


__all__ = ["RedisCache"]
