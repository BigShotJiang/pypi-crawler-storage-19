"""Azure Network resource types."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class VirtualNetwork:
    """Generated VirtualNetwork resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Address space prefixes
    address_space: dict[str, Any] | None = None

    # Subnets
    subnets: list[dict[str, Any]] | None = None

    # Resource type
    type: str = "Microsoft.Network/virtualNetworks"

    # API version
    api_version: str = "2024-01-01"


@dataclass
class NetworkInterface:
    """Generated NetworkInterface resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # IP configurations
    ip_configurations: list[dict[str, Any]] | None = None

    # Network security group reference
    network_security_group: dict[str, Any] | None = None

    # Enable IP forwarding
    enable_ip_forwarding: bool | None = None

    # Resource type
    type: str = "Microsoft.Network/networkInterfaces"

    # API version
    api_version: str = "2024-01-01"


@dataclass
class NetworkSecurityGroup:
    """Generated NetworkSecurityGroup resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Security rules
    security_rules: list[dict[str, Any]] | None = None

    # Resource properties
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Network/networkSecurityGroups"

    # API version
    api_version: str = "2024-01-01"


@dataclass
class PublicIPAddress:
    """Generated PublicIPAddress resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # SKU for the public IP
    sku: dict[str, Any] | None = None

    # Resource tags
    tags: dict[str, str] | None = None

    # Public IP allocation method
    public_ip_allocation_method: str | None = None

    # Public IP address version
    public_ip_address_version: str | None = None

    # DNS settings
    dns_settings: dict[str, Any] | None = None

    # Resource properties
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Network/publicIPAddresses"

    # API version
    api_version: str = "2024-01-01"


@dataclass
class LoadBalancer:
    """Generated LoadBalancer resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # SKU for the load balancer
    sku: dict[str, Any] | None = None

    # Resource tags
    tags: dict[str, str] | None = None

    # Frontend IP configurations
    frontend_ip_configurations: list[dict[str, Any]] | None = None

    # Backend address pools
    backend_address_pools: list[dict[str, Any]] | None = None

    # Load balancing rules
    load_balancing_rules: list[dict[str, Any]] | None = None

    # Probes
    probes: list[dict[str, Any]] | None = None

    # Resource properties
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Network/loadBalancers"

    # API version
    api_version: str = "2024-01-01"


__all__ = [
    "VirtualNetwork",
    "NetworkInterface",
    "NetworkSecurityGroup",
    "PublicIPAddress",
    "LoadBalancer",
]
