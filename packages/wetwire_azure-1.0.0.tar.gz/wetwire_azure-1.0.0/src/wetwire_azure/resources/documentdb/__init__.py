"""Azure Cosmos DB resource types."""

from dataclasses import dataclass
from typing import Any


@dataclass
class CosmosDBAccount:
    """Generated CosmosDB Account resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Kind (GlobalDocumentDB, MongoDB, Parse)
    kind: str | None = None

    # Cosmos DB properties (databaseAccountOfferType, locations, etc.)
    properties: dict[str, Any] | None = None

    # Identity
    identity: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.DocumentDB/databaseAccounts"

    # API version
    api_version: str = "2024-05-15"


__all__ = ["CosmosDBAccount"]
