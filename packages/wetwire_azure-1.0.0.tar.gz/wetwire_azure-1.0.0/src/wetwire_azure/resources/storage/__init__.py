"""Azure Storage resource types."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class StorageAccount:
    """Generated StorageAccount resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # SKU for the storage account
    sku: dict[str, Any]

    # Account kind (Storage, StorageV2, BlobStorage, etc.)
    kind: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Storage account properties
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Storage/storageAccounts"

    # API version
    api_version: str = "2023-05-01"


__all__ = ["StorageAccount"]
