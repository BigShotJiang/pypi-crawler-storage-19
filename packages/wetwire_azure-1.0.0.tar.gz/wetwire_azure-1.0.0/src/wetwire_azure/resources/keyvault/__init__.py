"""Azure Key Vault resource types."""

from dataclasses import dataclass
from typing import Any


@dataclass
class KeyVault:
    """Generated KeyVault resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Key Vault properties (tenantId, sku, accessPolicies, etc.)
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.KeyVault/vaults"

    # API version
    api_version: str = "2023-07-01"


__all__ = ["KeyVault"]
