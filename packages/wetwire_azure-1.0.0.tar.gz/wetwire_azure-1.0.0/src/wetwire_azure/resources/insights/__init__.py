"""Azure Monitor/Insights resource types."""

from dataclasses import dataclass
from typing import Any


@dataclass
class ApplicationInsights:
    """Generated ApplicationInsights resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Kind (web, ios, phone, store, java, other)
    kind: str | None = None

    # Application Insights properties (Application_Type, Flow_Type, etc.)
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Insights/components"

    # API version
    api_version: str = "2020-02-02"


__all__ = ["ApplicationInsights"]
