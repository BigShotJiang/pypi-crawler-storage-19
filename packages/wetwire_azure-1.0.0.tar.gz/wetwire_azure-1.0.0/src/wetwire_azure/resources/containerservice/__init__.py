"""Azure Container Service (AKS) resource types."""

from dataclasses import dataclass
from typing import Any


@dataclass
class ManagedCluster:
    """Generated Managed Cluster (AKS) resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # AKS properties (kubernetesVersion, dnsPrefix, agentPoolProfiles, etc.)
    properties: dict[str, Any] | None = None

    # Identity
    identity: dict[str, Any] | None = None

    # SKU
    sku: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.ContainerService/managedClusters"

    # API version
    api_version: str = "2024-05-01"


__all__ = ["ManagedCluster"]
