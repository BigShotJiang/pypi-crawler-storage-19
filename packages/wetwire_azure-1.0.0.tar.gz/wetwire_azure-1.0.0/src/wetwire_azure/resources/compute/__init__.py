"""Azure Compute resource types."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class VirtualMachine:
    """Generated VirtualMachine resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # The size of the virtual machine
    vm_size: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Virtual machine properties
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Compute/virtualMachines"

    # API version
    api_version: str = "2024-03-01"


@dataclass
class AvailabilitySet:
    """Generated AvailabilitySet resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Platform fault domain count
    platform_fault_domain_count: int | None = None

    # Platform update domain count
    platform_update_domain_count: int | None = None

    # Resource type
    type: str = "Microsoft.Compute/availabilitySets"

    # API version
    api_version: str = "2024-03-01"


__all__ = ["VirtualMachine", "AvailabilitySet"]
