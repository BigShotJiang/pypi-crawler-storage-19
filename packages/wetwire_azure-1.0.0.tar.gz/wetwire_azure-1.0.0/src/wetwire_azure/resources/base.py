"""Base Azure resource class with common ARM fields."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Resource:
    """Base class for all Azure resources with common ARM fields."""

    # Resource name
    name: str

    # Resource location (e.g., "eastus", "westus2")
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Resource type (e.g., "Microsoft.Compute/virtualMachines")
    type: str | None = None

    # API version
    api_version: str | None = None

    # Resource properties (provider-specific)
    properties: dict[str, Any] | None = None
