"""Azure resource type definitions."""

from wetwire_azure.resources.base import Resource

__all__ = ["Resource"]
