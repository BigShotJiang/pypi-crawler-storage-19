"""Azure Web (App Service) resource types."""

from dataclasses import dataclass
from typing import Any


@dataclass
class AppServicePlan:
    """Generated AppServicePlan (ServerFarm) resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # SKU for the App Service Plan
    sku: dict[str, Any] | None = None

    # Resource tags
    tags: dict[str, str] | None = None

    # Kind (linux, app, etc.)
    kind: str | None = None

    # App Service Plan properties
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Web/serverfarms"

    # API version
    api_version: str = "2023-12-01"


@dataclass
class WebApp:
    """Generated WebApp (App Service) resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # Kind (app, functionapp, linux, etc.)
    kind: str | None = None

    # Web App properties (serverFarmId, siteConfig, etc.)
    properties: dict[str, Any] | None = None

    # Identity
    identity: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Web/sites"

    # API version
    api_version: str = "2023-12-01"


__all__ = ["AppServicePlan", "WebApp"]
