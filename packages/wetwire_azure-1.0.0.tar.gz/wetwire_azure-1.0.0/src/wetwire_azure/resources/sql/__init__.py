"""Azure SQL resource types."""

from dataclasses import dataclass
from typing import Any


@dataclass
class SqlServer:
    """Generated SqlServer resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # Resource tags
    tags: dict[str, str] | None = None

    # SQL Server properties (administratorLogin, version, etc.)
    properties: dict[str, Any] | None = None

    # Identity
    identity: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Sql/servers"

    # API version
    api_version: str = "2023-08-01-preview"


@dataclass
class SqlDatabase:
    """Generated SqlDatabase resource type."""

    # Resource name
    name: str

    # Resource location
    location: str

    # SKU for the database
    sku: dict[str, Any] | None = None

    # Resource tags
    tags: dict[str, str] | None = None

    # SQL Database properties (collation, maxSizeBytes, etc.)
    properties: dict[str, Any] | None = None

    # Resource type
    type: str = "Microsoft.Sql/servers/databases"

    # API version
    api_version: str = "2023-08-01-preview"


__all__ = ["SqlServer", "SqlDatabase"]
