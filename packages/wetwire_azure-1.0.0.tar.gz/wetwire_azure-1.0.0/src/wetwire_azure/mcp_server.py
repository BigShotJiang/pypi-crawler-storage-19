"""MCP server for wetwire-azure.

Provides Model Context Protocol (MCP) server integration for Azure ARM/Bicep
template synthesis, making wetwire-azure tools available to AI assistants.
"""

import asyncio
import sys
from pathlib import Path
from typing import Any

try:
    from wetwire_core.mcp import (
        MCP_AVAILABLE,
        create_server,
        get_install_instructions,
        register_tool,
        run_server,
    )
except ImportError:
    # Graceful fallback if wetwire-core is not installed
    MCP_AVAILABLE = False

    def create_server(name: str) -> None:
        """Stub for create_server when wetwire-core not available."""
        return None

    def register_tool(
        server: Any,
        name: str,
        handler: Any,
        schema: dict[str, Any],
        description: str | None = None,
    ) -> None:
        """Stub for register_tool when wetwire-core not available."""
        pass

    async def run_server(server: Any) -> None:
        """Stub for run_server when wetwire-core not available."""
        pass

    def get_install_instructions(package_name: str) -> str:
        """Stub for get_install_instructions when wetwire-core not available."""
        return f"Install wetwire-core to use {package_name} as an MCP server."


def handle_build(
    path: str = ".", output: str = "template.json", format: str = "arm"
) -> str:
    """Handle build tool call.

    Args:
        path: Source file or directory path.
        output: Output file path.
        format: Output format (arm or bicep).

    Returns:
        Result message.
    """
    from wetwire_azure.template import BuildPipeline

    source_path = Path(path)
    output_path = Path(output)

    # Validate path
    if not source_path.exists():
        return f"Error: Path not found: {path}"

    # Validate format
    if format not in ["arm", "bicep"]:
        return f"Error: Invalid format '{format}'. Must be 'arm' or 'bicep'"

    if format == "bicep":
        return "Error: Bicep format is not yet supported. Please use 'arm' format."

    try:
        # Execute build pipeline
        pipeline = BuildPipeline()
        pipeline.discover(source_path)
        pipeline.validate()
        pipeline.extract()
        pipeline.order()
        arm_template = pipeline.serialize()
        pipeline.emit(arm_template, output_path)

        return f"Build successful! Template written to: {output_path}"

    except Exception as e:
        return f"Error: {e}"


def handle_lint(path: str = ".", format: str = "text") -> str:
    """Handle lint tool call.

    Args:
        path: Source file or directory path.
        format: Output format (text or json).

    Returns:
        Lint results.
    """
    import json

    from wetwire_azure.linter import run_linter

    source_path = Path(path)

    # Validate path
    if not source_path.exists():
        return f"Error: Path not found: {path}"

    # Validate format
    if format not in ["text", "json"]:
        return f"Error: Invalid format '{format}'. Must be 'text' or 'json'"

    try:
        # Run linter
        results = run_linter(source_path)

        if format == "json":
            # Return JSON format
            output = []
            for result in results:
                output.append(
                    {
                        "rule_id": result.rule_id,
                        "severity": result.severity.value,
                        "message": result.message,
                        "file": result.file,
                        "line": result.line,
                        "column": result.column,
                    }
                )
            return json.dumps(output, indent=2)
        else:
            # Return text format
            if not results:
                return "No issues found!"

            output_lines = []
            # Group by file
            by_file = {}
            for result in results:
                if result.file not in by_file:
                    by_file[result.file] = []
                by_file[result.file].append(result)

            # Format results
            for filepath in sorted(by_file.keys()):
                file_results = by_file[filepath]
                output_lines.append(f"\n{filepath}")
                for result in sorted(file_results, key=lambda r: r.line):
                    location = f"{result.line}"
                    if result.column is not None:
                        location += f":{result.column}"
                    output_lines.append(
                        f"  {location:8} [{result.rule_id}] {result.message}"
                    )

            # Add summary
            from wetwire_azure.linter import LintSeverity

            error_count = sum(1 for r in results if r.severity == LintSeverity.ERROR)
            warning_count = sum(
                1 for r in results if r.severity == LintSeverity.WARNING
            )
            info_count = sum(1 for r in results if r.severity == LintSeverity.INFO)

            output_lines.append("")
            output_lines.append(f"Found {len(results)} issue(s):")
            if error_count:
                output_lines.append(f"  {error_count} error(s)")
            if warning_count:
                output_lines.append(f"  {warning_count} warning(s)")
            if info_count:
                output_lines.append(f"  {info_count} info")

            return "\n".join(output_lines)

    except Exception as e:
        return f"Error: {e}"


def handle_import(path: str, output: str | None = None) -> str:
    """Handle import tool call.

    Args:
        path: ARM template file path.
        output: Optional output file path.

    Returns:
        Python code or result message.
    """
    from wetwire_azure.importer import ArmTemplateImporter

    input_path = Path(path)

    # Validate path
    if not input_path.exists():
        return f"Error: File not found: {path}"

    try:
        # Import the template
        importer = ArmTemplateImporter()
        python_code = importer.import_from_file(input_path)

        # Write to file if output specified
        if output:
            output_path = Path(output)
            output_path.write_text(python_code, encoding="utf-8")
            return f"Python code written to: {output_path}"
        else:
            # Return the Python code directly
            return python_code

    except Exception as e:
        return f"Error: {e}"


def setup_tools(server: Any) -> list[dict[str, Any]]:
    """Setup and register all MCP tools.

    Args:
        server: MCP server instance.

    Returns:
        List of tool definitions.
    """
    tools = []

    # Build tool
    build_tool = {
        "name": "build",
        "description": "Build ARM/Bicep template from Python infrastructure files. Synthesizes Python code into Azure Resource Manager templates.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Source file or directory path (default: current directory)",
                    "default": ".",
                },
                "output": {
                    "type": "string",
                    "description": "Output file path (default: template.json)",
                    "default": "template.json",
                },
                "format": {
                    "type": "string",
                    "description": "Output format: arm or bicep (default: arm)",
                    "enum": ["arm", "bicep"],
                    "default": "arm",
                },
            },
        },
    }
    tools.append(build_tool)
    register_tool(
        server,
        "build",
        handle_build,
        build_tool["inputSchema"],  # type: ignore[arg-type]
        str(build_tool["description"]),
    )

    # Lint tool
    lint_tool = {
        "name": "lint",
        "description": "Run lint checks on Python infrastructure files. Detects issues, code smells, and best practice violations.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Source file or directory path (default: current directory)",
                    "default": ".",
                },
                "format": {
                    "type": "string",
                    "description": "Output format: text or json (default: text)",
                    "enum": ["text", "json"],
                    "default": "text",
                },
            },
        },
    }
    tools.append(lint_tool)
    register_tool(
        server,
        "lint",
        handle_lint,
        lint_tool["inputSchema"],  # type: ignore[arg-type]
        str(lint_tool["description"]),
    )

    # Import tool
    import_tool = {
        "name": "import",
        "description": "Import ARM JSON template and convert to Python code. Reverse-engineers existing ARM templates into Python infrastructure code.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "ARM template file path (required)",
                },
                "output": {
                    "type": "string",
                    "description": "Output Python file path (optional, prints to stdout if not specified)",
                },
            },
            "required": ["path"],
        },
    }
    tools.append(import_tool)
    register_tool(
        server,
        "import",
        handle_import,
        import_tool["inputSchema"],  # type: ignore[arg-type]
        str(import_tool["description"]),
    )

    return tools


def main() -> int:
    """Main entry point for MCP server.

    Returns:
        Exit code (0 for success, 1 for error).
    """
    # Check for --help flag
    if "--help" in sys.argv or "-h" in sys.argv:
        print(get_install_instructions("wetwire-azure"))
        return 0

    # Check if MCP is available
    if not MCP_AVAILABLE:
        print("Error: MCP is not installed.", file=sys.stderr)
        print("", file=sys.stderr)
        print(
            "Install with: pip install 'wetwire-azure[mcp]' or pip install mcp",
            file=sys.stderr,
        )
        print("", file=sys.stderr)
        print("For Claude Code integration:", file=sys.stderr)
        print(get_install_instructions("wetwire-azure"), file=sys.stderr)
        return 1

    # Create and configure server
    server = create_server("wetwire-azure")
    if server is None:
        print("Error: Failed to create MCP server", file=sys.stderr)
        return 1

    # Register tools
    setup_tools(server)

    # Run server
    try:
        asyncio.run(run_server(server))
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
