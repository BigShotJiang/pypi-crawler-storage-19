"""Linter for wetwire-azure Python packages."""

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

__all__ = ["LintResult", "LintSeverity", "run_linter", "run_linter_with_fix"]


class LintSeverity(Enum):
    """Severity level for lint results."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class LintResult:
    """Result from a lint rule check."""

    rule_id: str
    severity: LintSeverity
    message: str
    file: str
    line: int
    column: int | None = None
    fixable: bool = False


# Import run_linter after defining types to avoid circular import
def run_linter(
    path: Path,
    rules: list[str] | None = None,
    ignore_rules: list[str] | None = None,
) -> list[LintResult]:
    """Run linter on a path.

    Args:
        path: File or directory path to lint.
        rules: List of rule IDs to run. If None, runs all rules.
        ignore_rules: List of rule IDs to ignore.

    Returns:
        List of lint results.
    """
    from wetwire_azure.linter.runner import run_linter as _run_linter

    return _run_linter(path, rules=rules, ignore_rules=ignore_rules)


def run_linter_with_fix(
    path: Path,
    rules: list[str] | None = None,
    ignore_rules: list[str] | None = None,
) -> tuple[list[LintResult], int]:
    """Run linter on a path and apply auto-fixes for fixable violations.

    Args:
        path: File or directory path to lint.
        rules: List of rule IDs to run. If None, runs all rules.
        ignore_rules: List of rule IDs to ignore.

    Returns:
        Tuple of (remaining violations after fixing, number of fixes applied).
    """
    from wetwire_azure.linter.runner import run_linter_with_fix as _run_linter_with_fix

    return _run_linter_with_fix(path, rules=rules, ignore_rules=ignore_rules)
