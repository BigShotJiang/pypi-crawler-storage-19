"""WAZ003 - Flag duplicate resource names."""

import ast
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity
from wetwire_azure.linter.rules.base import LintRule


class WAZ003DuplicateNames(LintRule):
    """Check for duplicate resource names."""

    rule_id = "WAZ003"
    description = "Resource names must be unique within a package"
    severity = LintSeverity.ERROR

    def check(self, files: list[Path]) -> list[LintResult]:
        """Check files for duplicate resource names.

        Args:
            files: List of Python files to check.

        Returns:
            List of lint violations found.
        """
        results = []
        name_locations: dict[str, list[tuple[str, int]]] = {}

        for filepath in files:
            tree = self.parse_file(filepath)
            if not tree:
                continue

            visitor = ResourceNameVisitor(str(filepath))
            visitor.visit(tree)

            # Track name locations
            for name, line in visitor.resource_names:
                if name not in name_locations:
                    name_locations[name] = []
                name_locations[name].append((str(filepath), line))

        # Find duplicates
        for name, locations in name_locations.items():
            if len(locations) > 1:
                for filepath, line in locations[1:]:
                    first_file, first_line = locations[0]
                    results.append(
                        LintResult(
                            rule_id="WAZ003",
                            severity=LintSeverity.ERROR,
                            message=f"Duplicate resource name '{name}' (first defined at {first_file}:{first_line})",
                            file=filepath,
                            line=line,
                        )
                    )

        return results


class ResourceNameVisitor(ast.NodeVisitor):
    """AST visitor to extract resource names."""

    def __init__(self, filepath: str):
        """Initialize visitor.

        Args:
            filepath: Path to file being checked.
        """
        self.filepath = filepath
        self.resource_names: list[tuple[str, int]] = []

    def visit_Call(self, node: ast.Call) -> None:
        """Visit function calls to extract name parameter.

        Args:
            node: Call AST node.
        """
        # Look for name parameter in resource constructors
        if isinstance(node.func, ast.Name) and node.func.id[0].isupper():
            for keyword in node.keywords:
                if keyword.arg == "name":
                    if isinstance(keyword.value, ast.Constant) and isinstance(
                        keyword.value.value, str
                    ):
                        self.resource_names.append(
                            (keyword.value.value, node.lineno)
                        )

        self.generic_visit(node)
