"""WAZ005 - Flag hardcoded secrets."""

import ast
import re
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity
from wetwire_azure.linter.rules.base import LintRule


class WAZ005Secrets(LintRule):
    """Check for hardcoded secrets."""

    rule_id = "WAZ005"
    description = "Secrets must not be hardcoded in source files"
    severity = LintSeverity.ERROR

    # Keywords that suggest secrets
    SECRET_KEYWORDS = [
        "password",
        "passwd",
        "pwd",
        "secret",
        "api_key",
        "apikey",
        "access_key",
        "private_key",
        "token",
        "auth",
        "credential",
    ]

    # Patterns that look like secrets
    SECRET_PATTERNS = [
        r"[a-zA-Z0-9]{32,}",  # Long alphanumeric strings
        r"[a-z]{2,}_[a-zA-Z0-9]{20,}",  # Prefixed keys like ak_xxxxx
    ]

    def check(self, files: list[Path]) -> list[LintResult]:
        """Check files for hardcoded secrets.

        Args:
            files: List of Python files to check.

        Returns:
            List of lint violations found.
        """
        results = []

        for filepath in files:
            tree = self.parse_file(filepath)
            if not tree:
                continue

            visitor = SecretVisitor(str(filepath), self.SECRET_KEYWORDS, self.SECRET_PATTERNS)
            visitor.visit(tree)
            results.extend(visitor.results)

        return results


class SecretVisitor(ast.NodeVisitor):
    """AST visitor to find hardcoded secrets."""

    def __init__(self, filepath: str, keywords: list[str], patterns: list[str]):
        """Initialize visitor.

        Args:
            filepath: Path to file being checked.
            keywords: List of secret-related keywords.
            patterns: List of regex patterns for secrets.
        """
        self.filepath = filepath
        self.keywords = keywords
        self.patterns = [re.compile(p) for p in patterns]
        self.results: list[LintResult] = []

    def visit_Call(self, node: ast.Call) -> None:
        """Visit function calls to check for secret parameters.

        Args:
            node: Call AST node.
        """
        # Check keyword arguments
        for keyword in node.keywords:
            if keyword.arg and any(kw in keyword.arg.lower() for kw in self.keywords):
                # Check if value is a string literal
                if isinstance(keyword.value, ast.Constant) and isinstance(
                    keyword.value.value, str
                ):
                    value = keyword.value.value
                    # If it's a secret parameter with a non-empty string, flag it
                    # (unless it looks like a placeholder or variable reference)
                    if value and not self._looks_like_placeholder(value):
                        self.results.append(
                            LintResult(
                                rule_id="WAZ005",
                                severity=LintSeverity.ERROR,
                                message=f"Hardcoded secret in parameter '{keyword.arg}'. Use environment variables or Azure Key Vault instead",
                                file=self.filepath,
                                line=keyword.value.lineno,
                                column=keyword.value.col_offset,
                            )
                        )

        self.generic_visit(node)

    def _looks_like_placeholder(self, value: str) -> bool:
        """Check if a string looks like a placeholder.

        Args:
            value: String value to check.

        Returns:
            True if value looks like a placeholder.
        """
        # Common placeholder patterns
        placeholders = [
            "xxx",
            "placeholder",
            "changeme",
            "todo",
            "fixme",
            "example",
            "test",
            "dummy",
        ]

        value_lower = value.lower()

        # Check if it contains placeholder keywords
        if any(p in value_lower for p in placeholders):
            return True

        # Check if it's surrounded by angle brackets or similar
        return (
            (value.startswith("<") and value.endswith(">"))
            or (value.startswith("{") and value.endswith("}"))
            or (value.startswith("[") and value.endswith("]"))
        )
