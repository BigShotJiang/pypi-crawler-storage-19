"""WAZ001 - Use typed API version constants."""

import ast
import re
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity
from wetwire_azure.linter.rules.base import LintRule


class WAZ001ApiVersion(LintRule):
    """Check that API versions use constants instead of strings."""

    rule_id = "WAZ001"
    description = "Use typed API version constants instead of string literals"
    severity = LintSeverity.ERROR
    can_auto_fix = True

    def check(self, files: list[Path]) -> list[LintResult]:
        """Check files for hardcoded API version strings.

        Args:
            files: List of Python files to check.

        Returns:
            List of lint violations found.
        """
        results = []

        for filepath in files:
            tree = self.parse_file(filepath)
            if not tree:
                continue

            visitor = ApiVersionVisitor(str(filepath))
            visitor.visit(tree)
            results.extend(visitor.results)

        return results

    def fix(self, filepath: Path, violation: LintResult) -> bool:
        """Remove the api_version string argument from the file.

        Args:
            filepath: Path to file containing the violation.
            violation: The lint violation to fix.

        Returns:
            True if fix was applied successfully, False otherwise.
        """
        try:
            content = filepath.read_text(encoding="utf-8")
            lines = content.splitlines(keepends=True)

            if violation.line < 1 or violation.line > len(lines):
                return False

            line_idx = violation.line - 1
            line = lines[line_idx]

            # Pattern to match api_version="..." with optional trailing comma and whitespace
            # This handles: api_version="2023-05-01", or api_version="2023-05-01"
            pattern = r'\s*api_version\s*=\s*["\'][^"\']*["\']\s*,?\s*'

            new_line = re.sub(pattern, "", line)

            # If the line becomes empty or only whitespace, remove it
            if new_line.strip() == "" or new_line.strip() == ",":
                lines[line_idx] = ""
            else:
                lines[line_idx] = new_line

            # Write back
            filepath.write_text("".join(lines), encoding="utf-8")
            return True
        except Exception:
            return False


class ApiVersionVisitor(ast.NodeVisitor):
    """AST visitor to find hardcoded API version strings."""

    def __init__(self, filepath: str):
        """Initialize visitor.

        Args:
            filepath: Path to file being checked.
        """
        self.filepath = filepath
        self.results: list[LintResult] = []

    def visit_Call(self, node: ast.Call) -> None:
        """Visit function calls to check for api_version parameter.

        Args:
            node: Call AST node.
        """
        # Check keyword arguments
        for keyword in node.keywords:
            if keyword.arg == "api_version":
                # Check if value is a string literal
                if isinstance(keyword.value, ast.Constant) and isinstance(
                    keyword.value.value, str
                ):
                    self.results.append(
                        LintResult(
                            rule_id="WAZ001",
                            severity=LintSeverity.ERROR,
                            message=f"Use API version constant instead of string literal '{keyword.value.value}'",
                            file=self.filepath,
                            line=keyword.value.lineno,
                            column=keyword.value.col_offset,
                            fixable=True,
                        )
                    )

        self.generic_visit(node)
