"""WAZ002 - Extract inline properties."""

import ast
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity
from wetwire_azure.linter.rules.base import LintRule


class WAZ002ExtractInline(LintRule):
    """Check that complex inline properties are extracted."""

    rule_id = "WAZ002"
    description = "Extract inline properties into separate resource declarations"
    severity = LintSeverity.ERROR

    def check(self, files: list[Path]) -> list[LintResult]:
        """Check files for inline dict/list literals in resource properties.

        Args:
            files: List of Python files to check.

        Returns:
            List of lint violations found.
        """
        results = []

        for filepath in files:
            tree = self.parse_file(filepath)
            if not tree:
                continue

            visitor = InlinePropertyVisitor(str(filepath))
            visitor.visit(tree)
            results.extend(visitor.results)

        return results


class InlinePropertyVisitor(ast.NodeVisitor):
    """AST visitor to find inline dict/list properties."""

    def __init__(self, filepath: str):
        """Initialize visitor.

        Args:
            filepath: Path to file being checked.
        """
        self.filepath = filepath
        self.results: list[LintResult] = []
        self.in_resource_call = False

    def visit_Call(self, node: ast.Call) -> None:
        """Visit function calls to check for inline properties.

        Args:
            node: Call AST node.
        """
        # Check if this might be a resource constructor
        # (simple heuristic: capitalized function name)
        is_resource_call = False
        if isinstance(node.func, ast.Name) and node.func.id[0].isupper():
            is_resource_call = True

        old_in_resource = self.in_resource_call
        if is_resource_call:
            self.in_resource_call = True

            # Check keyword arguments for dict/list literals
            for keyword in node.keywords:
                if isinstance(keyword.value, (ast.Dict, ast.List)):
                    # Check if it's a non-empty dict/list
                    if (isinstance(keyword.value, ast.Dict) and keyword.value.keys) or (
                        isinstance(keyword.value, ast.List) and keyword.value.elts
                    ):
                        self.results.append(
                            LintResult(
                                rule_id="WAZ002",
                                severity=LintSeverity.ERROR,
                                message=f"Extract inline property '{keyword.arg}' into a separate resource declaration",
                                file=self.filepath,
                                line=keyword.value.lineno,
                                column=keyword.value.col_offset,
                            )
                        )

        self.generic_visit(node)
        self.in_resource_call = old_in_resource
