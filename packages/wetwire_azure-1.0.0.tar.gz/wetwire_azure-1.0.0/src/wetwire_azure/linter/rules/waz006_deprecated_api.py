"""WAZ006 - Flag deprecated API versions."""

import ast
from datetime import datetime
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity
from wetwire_azure.linter.rules.base import LintRule


class WAZ006DeprecatedApi(LintRule):
    """Check for deprecated API versions."""

    rule_id = "WAZ006"
    description = "Avoid using deprecated API versions"
    severity = LintSeverity.WARNING

    # API versions older than this date are considered deprecated
    DEPRECATION_CUTOFF = datetime(2023, 1, 1)

    def check(self, files: list[Path]) -> list[LintResult]:
        """Check files for deprecated API versions.

        Args:
            files: List of Python files to check.

        Returns:
            List of lint violations found.
        """
        results = []

        for filepath in files:
            tree = self.parse_file(filepath)
            if not tree:
                continue

            visitor = DeprecatedApiVisitor(str(filepath), self.DEPRECATION_CUTOFF)
            visitor.visit(tree)
            results.extend(visitor.results)

        return results


class DeprecatedApiVisitor(ast.NodeVisitor):
    """AST visitor to find deprecated API versions."""

    def __init__(self, filepath: str, cutoff_date: datetime):
        """Initialize visitor.

        Args:
            filepath: Path to file being checked.
            cutoff_date: Date before which API versions are deprecated.
        """
        self.filepath = filepath
        self.cutoff_date = cutoff_date
        self.results: list[LintResult] = []

    def visit_Call(self, node: ast.Call) -> None:
        """Visit function calls to check for deprecated api_version.

        Args:
            node: Call AST node.
        """
        # Check keyword arguments
        for keyword in node.keywords:
            if keyword.arg == "api_version":
                # Check if value is a string literal
                if isinstance(keyword.value, ast.Constant) and isinstance(
                    keyword.value.value, str
                ):
                    api_version = keyword.value.value
                    if self._is_deprecated(api_version):
                        self.results.append(
                            LintResult(
                                rule_id="WAZ006",
                                severity=LintSeverity.WARNING,
                                message=f"API version '{api_version}' is deprecated. Use a newer version",
                                file=self.filepath,
                                line=keyword.value.lineno,
                                column=keyword.value.col_offset,
                            )
                        )

        self.generic_visit(node)

    def _is_deprecated(self, api_version: str) -> bool:
        """Check if an API version is deprecated.

        Args:
            api_version: API version string (e.g., "2020-01-01").

        Returns:
            True if the API version is deprecated.
        """
        # Try to parse the date from the API version
        try:
            # Most Azure API versions are in YYYY-MM-DD format
            parts = api_version.split("-")
            if len(parts) >= 3:
                year = int(parts[0])
                month = int(parts[1])
                day = int(parts[2])
                version_date = datetime(year, month, day)
                return version_date < self.cutoff_date
        except (ValueError, IndexError):
            # If we can't parse it, don't flag it
            pass

        return False
