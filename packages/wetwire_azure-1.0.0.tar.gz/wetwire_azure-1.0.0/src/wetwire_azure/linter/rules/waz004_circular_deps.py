"""WAZ004 - Flag circular dependencies."""

from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity
from wetwire_azure.linter.rules.base import LintRule
from wetwire_azure.loader import build_dependency_graph, discover_resources


class WAZ004CircularDeps(LintRule):
    """Check for circular dependencies between resources."""

    rule_id = "WAZ004"
    description = "Resources must not have circular dependencies"
    severity = LintSeverity.ERROR

    def check(self, files: list[Path]) -> list[LintResult]:
        """Check files for circular dependencies.

        Args:
            files: List of Python files to check.

        Returns:
            List of lint violations found.
        """
        results = []

        # Discover resources from all files
        all_resources = []
        for filepath in files:
            resources = discover_resources(filepath)
            all_resources.extend(resources)

        if not all_resources:
            return results

        # Build dependency graph
        graph = build_dependency_graph(all_resources)

        # Detect cycles using DFS
        visited = set()
        rec_stack = set()

        def has_cycle(node: str, path: list[str]) -> list[str] | None:
            """DFS to detect cycles.

            Args:
                node: Current node being visited.
                path: Current path from root.

            Returns:
                Cycle path if found, None otherwise.
            """
            visited.add(node)
            rec_stack.add(node)
            current_path = path + [node]

            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    cycle = has_cycle(neighbor, current_path)
                    if cycle:
                        return cycle
                elif neighbor in rec_stack:
                    # Found a cycle
                    cycle_start = current_path.index(neighbor)
                    return current_path[cycle_start:] + [neighbor]

            rec_stack.remove(node)
            return None

        # Check each connected component
        for node in graph:
            if node not in visited:
                cycle = has_cycle(node, [])
                if cycle:
                    # Find the resource for error reporting
                    for resource in all_resources:
                        if resource.name == cycle[0]:
                            cycle_str = " -> ".join(cycle)
                            results.append(
                                LintResult(
                                    rule_id="WAZ004",
                                    severity=LintSeverity.ERROR,
                                    message=f"Circular dependency detected: {cycle_str}",
                                    file=resource.file,
                                    line=resource.line,
                                )
                            )
                            break
                    break  # Report only one cycle

        return results
