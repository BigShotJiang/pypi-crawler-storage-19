"""Lint rules for wetwire-azure."""

from wetwire_azure.linter.rules.base import LintRule
from wetwire_azure.linter.rules.waz001_api_version import WAZ001ApiVersion
from wetwire_azure.linter.rules.waz002_extract_inline import WAZ002ExtractInline
from wetwire_azure.linter.rules.waz003_duplicate_names import WAZ003DuplicateNames
from wetwire_azure.linter.rules.waz004_circular_deps import WAZ004CircularDeps
from wetwire_azure.linter.rules.waz005_secrets import WAZ005Secrets
from wetwire_azure.linter.rules.waz006_deprecated_api import WAZ006DeprecatedApi

__all__ = [
    "LintRule",
    "WAZ001ApiVersion",
    "WAZ002ExtractInline",
    "WAZ003DuplicateNames",
    "WAZ004CircularDeps",
    "WAZ005Secrets",
    "WAZ006DeprecatedApi",
    "ALL_RULES",
]

ALL_RULES = [
    WAZ001ApiVersion,
    WAZ002ExtractInline,
    WAZ003DuplicateNames,
    WAZ004CircularDeps,
    WAZ005Secrets,
    WAZ006DeprecatedApi,
]
