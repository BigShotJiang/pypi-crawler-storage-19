"""Base class for lint rules."""

import ast
from abc import ABC, abstractmethod
from pathlib import Path

from wetwire_azure.linter import LintResult, LintSeverity


class LintRule(ABC):
    """Base class for all lint rules."""

    rule_id: str
    description: str
    severity: LintSeverity
    can_auto_fix: bool = False

    @abstractmethod
    def check(self, files: list[Path]) -> list[LintResult]:
        """Check files for lint violations.

        Args:
            files: List of Python files to check.

        Returns:
            List of lint violations found.
        """
        pass

    def fix(self, filepath: Path, violation: LintResult) -> bool:
        """Apply auto-fix for a violation.

        Args:
            filepath: Path to file containing the violation.
            violation: The lint violation to fix.

        Returns:
            True if fix was applied successfully, False otherwise.
        """
        if not self.can_auto_fix:
            return False
        return False

    def parse_file(self, filepath: Path) -> ast.AST | None:
        """Parse a Python file into an AST.

        Args:
            filepath: Path to Python file.

        Returns:
            Parsed AST or None if parsing fails.
        """
        try:
            source = filepath.read_text(encoding="utf-8")
            return ast.parse(source, filename=str(filepath))
        except (SyntaxError, UnicodeDecodeError):
            return None
