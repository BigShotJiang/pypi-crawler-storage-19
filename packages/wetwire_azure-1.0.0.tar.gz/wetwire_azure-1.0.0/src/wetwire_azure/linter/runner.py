"""Linter runner that executes all rules."""

from pathlib import Path

from wetwire_azure.linter import LintResult
from wetwire_azure.linter.rules import ALL_RULES


def run_linter(
    path: Path,
    rules: list[str] | None = None,
    ignore_rules: list[str] | None = None,
) -> list[LintResult]:
    """Run linter on a path.

    Args:
        path: File or directory path to lint.
        rules: List of rule IDs to run. If None, runs all rules.
        ignore_rules: List of rule IDs to ignore.

    Returns:
        List of lint results.
    """
    # Get Python files to check
    if path.is_file():
        files = [path]
    elif path.is_dir():
        files = list(path.rglob("*.py"))
    else:
        return []

    # Filter out virtual environments and __pycache__
    # BUT keep test files during testing
    files = [
        f
        for f in files
        if not any(
            part in ("__pycache__", ".venv", "venv")
            for part in f.parts
        )
    ]

    if not files:
        return []

    # Determine which rules to run
    rules_to_run = []
    for rule_class in ALL_RULES:
        rule_id = rule_class.rule_id

        # Check if we should run this rule
        if rules is not None and rule_id not in rules:
            continue
        if ignore_rules is not None and rule_id in ignore_rules:
            continue

        rules_to_run.append(rule_class())

    # Run all rules
    all_results = []
    for rule in rules_to_run:
        results = rule.check(files)
        all_results.extend(results)

    return all_results


def run_linter_with_fix(
    path: Path,
    rules: list[str] | None = None,
    ignore_rules: list[str] | None = None,
) -> tuple[list[LintResult], int]:
    """Run linter on a path and apply auto-fixes for fixable violations.

    Args:
        path: File or directory path to lint.
        rules: List of rule IDs to run. If None, runs all rules.
        ignore_rules: List of rule IDs to ignore.

    Returns:
        Tuple of (remaining violations after fixing, number of fixes applied).
    """
    # Get Python files to check
    if path.is_file():
        files = [path]
    elif path.is_dir():
        files = list(path.rglob("*.py"))
    else:
        return [], 0

    # Filter out virtual environments and __pycache__
    files = [
        f
        for f in files
        if not any(part in ("__pycache__", ".venv", "venv") for part in f.parts)
    ]

    if not files:
        return [], 0

    # Build rule instances
    rule_instances = {}
    for rule_class in ALL_RULES:
        rule_id = rule_class.rule_id

        if rules is not None and rule_id not in rules:
            continue
        if ignore_rules is not None and rule_id in ignore_rules:
            continue

        rule_instances[rule_id] = rule_class()

    # Run all rules and collect results
    all_results = []
    for rule in rule_instances.values():
        results = rule.check(files)
        all_results.extend(results)

    # Apply fixes for fixable violations
    fixed_count = 0
    remaining_results = []

    # Group results by file for efficient fixing
    results_by_file: dict[str, list[LintResult]] = {}
    for result in all_results:
        if result.file not in results_by_file:
            results_by_file[result.file] = []
        results_by_file[result.file].append(result)

    for filepath_str, file_results in results_by_file.items():
        filepath = Path(filepath_str)

        # Sort by line number in reverse to fix from bottom up
        # This prevents line number shifts from affecting other fixes
        file_results.sort(key=lambda r: r.line, reverse=True)

        for result in file_results:
            if result.fixable and result.rule_id in rule_instances:
                rule = rule_instances[result.rule_id]
                if rule.can_auto_fix:
                    if rule.fix(filepath, result):
                        fixed_count += 1
                    else:
                        remaining_results.append(result)
                else:
                    remaining_results.append(result)
            else:
                remaining_results.append(result)

    return remaining_results, fixed_count
