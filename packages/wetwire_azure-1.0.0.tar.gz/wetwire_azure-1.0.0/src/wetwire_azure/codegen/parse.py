"""Parse ARM JSON schemas into intermediate format for code generation."""

from typing import Any


def _json_type_to_python_type(
    json_type: str | list[str], is_required: bool = True
) -> str:
    """Convert JSON schema type to Python type annotation.

    Args:
        json_type: JSON schema type (e.g., "string", "object", ["string", "null"])
        is_required: Whether the field is required

    Returns:
        Python type annotation string
    """
    # Handle array of types (e.g., ["string", "null"])
    if isinstance(json_type, list):
        # Filter out "null" and take the first non-null type
        non_null_types = [t for t in json_type if t != "null"]
        if non_null_types:
            json_type = non_null_types[0]
        else:
            json_type = "string"  # default fallback

    type_mapping = {
        "string": "str",
        "integer": "int",
        "number": "float",
        "boolean": "bool",
        "object": "dict[str, Any]",
        "array": "list[Any]",
    }

    python_type = type_mapping.get(json_type, "Any")

    # Add | None for optional fields
    if not is_required:
        python_type = f"{python_type} | None"

    return python_type


def _parse_property(
    prop_name: str, prop_schema: dict[str, Any], required: list[str]
) -> dict[str, Any]:
    """Parse a single property from JSON schema.

    Args:
        prop_name: Property name
        prop_schema: Property schema definition
        required: List of required property names

    Returns:
        Parsed field information
    """
    is_required = prop_name in required
    json_type = prop_schema.get("type", "string")

    # Special handling for objects with additionalProperties (maps/dicts)
    if json_type == "object" and "additionalProperties" in prop_schema:
        additional_type = prop_schema["additionalProperties"].get("type", "string")
        python_type = f"dict[str, {_json_type_to_python_type(additional_type, True)}]"
        if not is_required:
            python_type = f"{python_type} | None"
    else:
        python_type = _json_type_to_python_type(json_type, is_required)

    return {
        "type": python_type,
        "required": is_required,
        "description": prop_schema.get("description", ""),
    }


def parse_schema(schema: dict[str, Any], class_name: str) -> dict[str, Any]:
    """Parse ARM JSON schema into intermediate format for code generation.

    Args:
        schema: The JSON schema dictionary
        class_name: Name for the generated class

    Returns:
        Parsed schema in intermediate format with structure:
        {
            "class_name": str,
            "fields": {
                "field_name": {
                    "type": str,
                    "required": bool,
                    "description": str
                }
            }
        }
    """
    properties = schema.get("properties", {})
    required = schema.get("required", [])

    fields = {}
    for prop_name, prop_schema in properties.items():
        # Convert kebab-case or camelCase to snake_case for Python conventions
        python_field_name = prop_name.replace("-", "_")

        # Skip complex nested objects for now, focusing on simple properties
        fields[python_field_name] = _parse_property(prop_name, prop_schema, required)

    return {
        "class_name": class_name,
        "fields": fields,
    }
