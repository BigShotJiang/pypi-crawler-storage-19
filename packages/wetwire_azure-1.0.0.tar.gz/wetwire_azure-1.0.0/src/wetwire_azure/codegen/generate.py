"""Generate Python dataclasses from parsed ARM schemas."""

from typing import Any


def generate_dataclass(parsed_schema: dict[str, Any]) -> str:
    """Generate Python dataclass code from parsed schema.

    Args:
        parsed_schema: Parsed schema in intermediate format

    Returns:
        Python source code string
    """
    class_name = parsed_schema["class_name"]
    fields = parsed_schema["fields"]

    # Build imports
    imports = [
        "from dataclasses import dataclass, field",
        "from typing import Any",
    ]

    # Build class definition
    lines = [
        "",
        "",
        "@dataclass",
        f"class {class_name}:",
        f'    """Generated {class_name} resource type."""',
        "",
    ]

    # Generate fields
    if not fields:
        lines.append("    pass")
    else:
        for field_name, field_info in fields.items():
            field_type = field_info["type"]
            description = field_info["description"]

            if description:
                lines.append(f'    # {description}')

            if field_info["required"]:
                lines.append(f"    {field_name}: {field_type}")
            else:
                lines.append(f"    {field_name}: {field_type} = None")

            lines.append("")

    # Combine everything
    code = "\n".join(imports) + "\n" + "\n".join(lines)
    return code


def generate_module(
    resource_classes: list[dict[str, Any]], module_docstring: str = ""
) -> str:
    """Generate a complete Python module with multiple resource classes.

    Args:
        resource_classes: List of parsed schema dictionaries
        module_docstring: Docstring for the module

    Returns:
        Complete Python module source code
    """
    # Build imports
    imports = [
        "from dataclasses import dataclass, field",
        "from typing import Any",
        "",
    ]

    if module_docstring:
        imports.insert(0, f'"""{module_docstring}"""')
        imports.insert(1, "")

    # Generate each class
    class_codes = []
    for parsed_schema in resource_classes:
        class_name = parsed_schema["class_name"]
        fields = parsed_schema["fields"]

        lines = [
            "",
            "@dataclass",
            f"class {class_name}:",
            f'    """Generated {class_name} resource type."""',
            "",
        ]

        if not fields:
            lines.append("    pass")
        else:
            for field_name, field_info in fields.items():
                field_type = field_info["type"]
                description = field_info["description"]

                if description:
                    lines.append(f'    # {description}')

                if field_info["required"]:
                    lines.append(f"    {field_name}: {field_type}")
                else:
                    lines.append(f"    {field_name}: {field_type} = None")

                lines.append("")

        class_codes.append("\n".join(lines))

    # Combine everything
    code = "\n".join(imports) + "\n" + "\n".join(class_codes)
    return code
