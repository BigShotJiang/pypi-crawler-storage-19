"""Code generation package for Azure ARM schema types."""

__all__ = ["fetch", "parse", "generate"]
