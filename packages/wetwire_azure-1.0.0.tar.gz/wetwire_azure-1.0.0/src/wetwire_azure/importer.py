"""ARM template importer for converting ARM JSON to Python code."""

import json
from pathlib import Path
from typing import Any

# Mapping of ARM resource types to Python resource classes
RESOURCE_TYPE_MAPPING = {
    # Storage
    "Microsoft.Storage/storageAccounts": {
        "class_name": "StorageAccount",
        "module": "wetwire_azure.resources.storage",
    },
    # Compute
    "Microsoft.Compute/virtualMachines": {
        "class_name": "VirtualMachine",
        "module": "wetwire_azure.resources.compute",
    },
    "Microsoft.Compute/availabilitySets": {
        "class_name": "AvailabilitySet",
        "module": "wetwire_azure.resources.compute",
    },
    # Network
    "Microsoft.Network/virtualNetworks": {
        "class_name": "VirtualNetwork",
        "module": "wetwire_azure.resources.network",
    },
    "Microsoft.Network/networkInterfaces": {
        "class_name": "NetworkInterface",
        "module": "wetwire_azure.resources.network",
    },
    "Microsoft.Network/networkSecurityGroups": {
        "class_name": "NetworkSecurityGroup",
        "module": "wetwire_azure.resources.network",
    },
    "Microsoft.Network/publicIPAddresses": {
        "class_name": "PublicIPAddress",
        "module": "wetwire_azure.resources.network",
    },
    "Microsoft.Network/loadBalancers": {
        "class_name": "LoadBalancer",
        "module": "wetwire_azure.resources.network",
    },
    # Key Vault
    "Microsoft.KeyVault/vaults": {
        "class_name": "KeyVault",
        "module": "wetwire_azure.resources.keyvault",
    },
    # Web (App Service)
    "Microsoft.Web/serverfarms": {
        "class_name": "AppServicePlan",
        "module": "wetwire_azure.resources.web",
    },
    "Microsoft.Web/sites": {
        "class_name": "WebApp",
        "module": "wetwire_azure.resources.web",
    },
    # SQL
    "Microsoft.Sql/servers": {
        "class_name": "SqlServer",
        "module": "wetwire_azure.resources.sql",
    },
    "Microsoft.Sql/servers/databases": {
        "class_name": "SqlDatabase",
        "module": "wetwire_azure.resources.sql",
    },
    # Insights (Application Insights)
    "Microsoft.Insights/components": {
        "class_name": "ApplicationInsights",
        "module": "wetwire_azure.resources.insights",
    },
    # Cosmos DB
    "Microsoft.DocumentDB/databaseAccounts": {
        "class_name": "CosmosDBAccount",
        "module": "wetwire_azure.resources.documentdb",
    },
    # Redis Cache
    "Microsoft.Cache/redis": {
        "class_name": "RedisCache",
        "module": "wetwire_azure.resources.cache",
    },
    # Container Service (AKS)
    "Microsoft.ContainerService/managedClusters": {
        "class_name": "ManagedCluster",
        "module": "wetwire_azure.resources.containerservice",
    },
}


def parse_arm_template(arm_json: dict[str, Any]) -> dict[str, Any]:
    """Parse an ARM template JSON and extract relevant sections.

    Args:
        arm_json: Dictionary containing ARM template JSON.

    Returns:
        Dictionary with parsed template sections.
    """
    return {
        "schema": arm_json.get("$schema", ""),
        "contentVersion": arm_json.get("contentVersion", "1.0.0.0"),
        "parameters": arm_json.get("parameters", {}),
        "variables": arm_json.get("variables", {}),
        "resources": arm_json.get("resources", []),
    }


def _format_value(value: Any, indent: int = 0) -> str:
    """Format a Python value as a string.

    Args:
        value: Value to format.
        indent: Indentation level for nested structures.

    Returns:
        Formatted string representation.
    """
    if isinstance(value, str):
        return f'"{value}"'
    elif isinstance(value, (bool, int, float)):
        return str(value)
    elif isinstance(value, dict):
        if not value:
            return "{}"
        items = []
        for k, v in value.items():
            formatted_value = _format_value(v, indent + 1)
            items.append(f'"{k}": {formatted_value}')
        return "{" + ", ".join(items) + "}"
    elif isinstance(value, list):
        if not value:
            return "[]"
        items = [_format_value(item, indent + 1) for item in value]
        return "[" + ", ".join(items) + "]"
    elif value is None:
        return "None"
    else:
        return str(value)


def convert_arm_to_python(resource: dict[str, Any]) -> str | None:
    """Convert an ARM resource to Python code.

    Args:
        resource: ARM resource dictionary.

    Returns:
        Python code string for the resource, or None if unsupported.
    """
    resource_type = resource.get("type", "")

    # Check if we support this resource type
    if resource_type not in RESOURCE_TYPE_MAPPING:
        # Return None as a placeholder - caller will handle commenting
        return None

    mapping = RESOURCE_TYPE_MAPPING[resource_type]
    class_name = mapping["class_name"]

    # Build the constructor arguments
    args = []

    # Required fields
    if "name" in resource:
        args.append(f'name={_format_value(resource["name"])}')

    if "location" in resource:
        args.append(f'location={_format_value(resource["location"])}')

    # Common optional fields that many resource types have
    if "sku" in resource:
        args.append(f'sku={_format_value(resource["sku"])}')

    if "kind" in resource:
        args.append(f'kind={_format_value(resource["kind"])}')

    if "tags" in resource:
        args.append(f'tags={_format_value(resource["tags"])}')

    if "identity" in resource:
        args.append(f'identity={_format_value(resource["identity"])}')

    if "properties" in resource:
        args.append(f'properties={_format_value(resource["properties"])}')

    # Build the Python code
    args_str = ",\n    ".join(args)
    return f"{class_name}(\n    {args_str},\n)"


class ArmTemplateImporter:
    """Importer for converting ARM templates to Python code."""

    def __init__(self):
        """Initialize the importer."""
        self.imported_modules = set()
        self.resources_code = []

    def import_template(self, arm_json: dict[str, Any]) -> str:
        """Import an ARM template and generate Python code.

        Args:
            arm_json: Dictionary containing ARM template JSON.

        Returns:
            Generated Python code as a string.
        """
        self.imported_modules.clear()
        self.resources_code.clear()

        parsed = parse_arm_template(arm_json)

        # Process resources
        for resource in parsed["resources"]:
            resource_type = resource.get("type", "")

            # Track which modules we need to import
            if resource_type in RESOURCE_TYPE_MAPPING:
                mapping = RESOURCE_TYPE_MAPPING[resource_type]
                self.imported_modules.add(
                    (mapping["module"], mapping["class_name"])
                )

                # Generate Python code for the resource
                resource_code = convert_arm_to_python(resource)
                if resource_code:
                    self.resources_code.append(resource_code)
            # Skip unsupported resource types (don't add invalid Python code)

        # Build the complete Python file
        return self._generate_python_file()

    def import_from_file(self, path: Path) -> str:
        """Import an ARM template from a JSON file.

        Args:
            path: Path to the ARM template JSON file.

        Returns:
            Generated Python code as a string.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            json.JSONDecodeError: If the file contains invalid JSON.
        """
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        with open(path, encoding="utf-8") as f:
            arm_json = json.load(f)

        return self.import_template(arm_json)

    def _generate_python_file(self) -> str:
        """Generate the complete Python file with imports and resources.

        Returns:
            Complete Python source code.
        """
        lines = []

        # Add file header
        lines.append('"""Generated from ARM template."""')
        lines.append("")

        # Add imports
        if self.imported_modules:
            for module, class_name in sorted(self.imported_modules):
                lines.append(f"from {module} import {class_name}")
            lines.append("")
            lines.append("")

        # Add resources
        if self.resources_code:
            for i, resource_code in enumerate(self.resources_code):
                var_name = f"resource_{i + 1}"
                lines.append(f"{var_name} = {resource_code}")
                lines.append("")
        else:
            lines.append("# No resources to import")
            lines.append("")

        return "\n".join(lines)


__all__ = [
    "ArmTemplateImporter",
    "parse_arm_template",
    "convert_arm_to_python",
]
