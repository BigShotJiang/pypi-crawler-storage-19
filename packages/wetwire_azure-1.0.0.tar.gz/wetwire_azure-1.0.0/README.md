# wetwire-azure-python

[![Python Version](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)
[![CI Status](https://github.com/lex00/wetwire-azure-python/workflows/CI/badge.svg)](https://github.com/lex00/wetwire-azure-python/actions)
[![PyPI](https://img.shields.io/pypi/v/wetwire-azure)](https://pypi.org/project/wetwire-azure/)
[![codecov](https://codecov.io/gh/lex00/wetwire-azure-python/branch/main/graph/badge.svg)](https://codecov.io/gh/lex00/wetwire-azure-python)

Python implementation of wetwire for Azure ARM/Bicep templates.

## Overview

wetwire-azure enables defining Azure resources using Python dataclasses, with full type safety and IDE support. Write infrastructure as code using Python, get ARM templates as output.

## Installation

```bash
pip install wetwire-azure
```

## Quick Start

```python
from wetwire_azure.resources.compute import VirtualMachine
from wetwire_azure.resources.network import VirtualNetwork, Subnet

my_vnet = VirtualNetwork(
    name="my-vnet",
    location="eastus",
    properties={
        "addressSpace": {
            "addressPrefixes": ["10.0.0.0/16"]
        }
    }
)

my_vm = VirtualMachine(
    name="my-vm",
    location="eastus",
    properties={
        "hardwareProfile": {"vmSize": "Standard_DS1_v2"},
        # ...
    }
)
```

## Commands

- `wetwire-azure build` - Generate ARM templates from Python code
- `wetwire-azure lint` - Lint Azure resource definitions
- `wetwire-azure import` - Import existing ARM templates
- `wetwire-azure validate` - Validate against Azure schemas
- `wetwire-azure test` - Run synthesis tests with AI personas

See [docs/CLI.md](docs/CLI.md) for detailed command reference.

## Documentation

- [Quick Start](docs/QUICK_START.md) - Get started in 5 minutes
- [CLI Reference](docs/CLI.md) - Complete command documentation
- [Lint Rules](docs/LINT_RULES.md) - Available lint rules and best practices
- [Import Workflow](docs/IMPORT_WORKFLOW.md) - Convert ARM templates to Python
- [MCP Server](docs/MCP_SERVER.md) - Claude Code integration
- [FAQ](docs/FAQ.md) - Frequently asked questions
- [CLAUDE.md](CLAUDE.md) - AI assistant context

## Development

```bash
# Install dependencies
uv sync --all-extras

# Run tests
uv run pytest

# Lint code
uv run ruff check src/

# Type check
uv run ty check src/wetwire_azure/
```

## Contributing

Contributions are welcome! Please open an issue or pull request on GitHub.

## License

MIT
