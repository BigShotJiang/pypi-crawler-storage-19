from __future__ import annotations
import yaml


def load_secrets(path: str = "secrets.yaml") -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)
