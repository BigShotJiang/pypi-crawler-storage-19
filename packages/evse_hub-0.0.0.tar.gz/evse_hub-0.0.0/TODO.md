# Various ToDos

## Watchdog

### Algodue watchdog

```bash
curl -sS -c /tmp/algodue.cookie \
  -X POST http://ALGODUE_IP/index.htm \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data 'user=admin&password=admin'
```

This stores the auth cookie. Then 
```bash
curl -sS -b /tmp/algodue.cookie \
  -X POST http://ALGODUE_IP/parameters_change.htm \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  --data 'addressingType=Static' \
  --data 'host_name=ETHBOARD' \
  --data 'IP=192.168.1.249' \
  --data 'gateway=192.168.1.1' \
  --data 'mask=255.255.255.0' \
  --data 'primary_dns=8.8.8.8' \
  --data 'secondary_dns=8.8.4.4' \
  --data 'logical_addr=01' \
  --data 'chbSyncWithNTP=on' \
  --data 'ntp_server=europe.pool.ntp.org' \
  --data 'utc_correction=%2B01'
```

