#!/usr/bin/python

import setuptools

with open("README.md", "r") as fh:
    LONG_DESCRIPTION = fh.read()
    
KEYWORDS = ('blocklist aggregator domains dns blacklist whitelist')

setuptools.setup(
    name="blocklist_aggregator",
    version="1.4.2",
    author="Denis MACHARD",
    author_email="d.machard@gmail.com",
    description="Domains blocklist aggregator",
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    url="https://github.com/dmachard/blocklist-aggregator",
    packages=['blocklist_aggregator'],
    include_package_data=True,
    platforms='any',
    keywords=KEYWORDS,
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
    ],
    install_requires=[
        "pyyaml",
        "requests",
        "pure-cdb",
        "httpx[http2]",
    ]
)