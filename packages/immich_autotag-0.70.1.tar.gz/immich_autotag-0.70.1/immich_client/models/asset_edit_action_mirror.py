from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.asset_edit_action import AssetEditAction

if TYPE_CHECKING:
    from ..models.mirror_parameters import MirrorParameters


T = TypeVar("T", bound="AssetEditActionMirror")


@_attrs_define
class AssetEditActionMirror:
    """
    Attributes:
        action (AssetEditAction):
        parameters (MirrorParameters):
    """

    action: AssetEditAction
    parameters: MirrorParameters
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        action = self.action.value

        parameters = self.parameters.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "action": action,
                "parameters": parameters,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.mirror_parameters import MirrorParameters

        d = dict(src_dict)
        action = AssetEditAction(d.pop("action"))

        parameters = MirrorParameters.from_dict(d.pop("parameters"))

        asset_edit_action_mirror = cls(
            action=action,
            parameters=parameters,
        )

        asset_edit_action_mirror.additional_properties = d
        return asset_edit_action_mirror

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
