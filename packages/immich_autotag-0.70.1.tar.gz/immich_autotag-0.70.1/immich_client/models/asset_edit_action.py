from enum import Enum


class AssetEditAction(str, Enum):
    CROP = "crop"
    MIRROR = "mirror"
    ROTATE = "rotate"

    def __str__(self) -> str:
        return str(self.value)
