from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.asset_edit_action_crop import AssetEditActionCrop
    from ..models.asset_edit_action_mirror import AssetEditActionMirror
    from ..models.asset_edit_action_rotate import AssetEditActionRotate


T = TypeVar("T", bound="AssetEditActionListDto")


@_attrs_define
class AssetEditActionListDto:
    """
    Attributes:
        edits (list[AssetEditActionCrop | AssetEditActionMirror | AssetEditActionRotate]): list of edits
    """

    edits: list[AssetEditActionCrop | AssetEditActionMirror | AssetEditActionRotate]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.asset_edit_action_crop import AssetEditActionCrop
        from ..models.asset_edit_action_rotate import AssetEditActionRotate

        edits = []
        for edits_item_data in self.edits:
            edits_item: dict[str, Any]
            if isinstance(edits_item_data, AssetEditActionCrop):
                edits_item = edits_item_data.to_dict()
            elif isinstance(edits_item_data, AssetEditActionRotate):
                edits_item = edits_item_data.to_dict()
            else:
                edits_item = edits_item_data.to_dict()

            edits.append(edits_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "edits": edits,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.asset_edit_action_crop import AssetEditActionCrop
        from ..models.asset_edit_action_mirror import AssetEditActionMirror
        from ..models.asset_edit_action_rotate import AssetEditActionRotate

        d = dict(src_dict)
        edits = []
        _edits = d.pop("edits")
        for edits_item_data in _edits:

            def _parse_edits_item(data: object) -> AssetEditActionCrop | AssetEditActionMirror | AssetEditActionRotate:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    edits_item_type_0 = AssetEditActionCrop.from_dict(data)

                    return edits_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    edits_item_type_1 = AssetEditActionRotate.from_dict(data)

                    return edits_item_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                edits_item_type_2 = AssetEditActionMirror.from_dict(data)

                return edits_item_type_2

            edits_item = _parse_edits_item(edits_item_data)

            edits.append(edits_item)

        asset_edit_action_list_dto = cls(
            edits=edits,
        )

        asset_edit_action_list_dto.additional_properties = d
        return asset_edit_action_list_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
