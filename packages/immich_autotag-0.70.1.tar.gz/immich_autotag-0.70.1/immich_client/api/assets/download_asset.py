from http import HTTPStatus
from io import BytesIO
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, File, Response, Unset


def _get_kwargs(
    id: UUID,
    *,
    edited: bool | Unset = False,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["edited"] = edited

    params["key"] = key

    params["slug"] = slug

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/assets/{id}/original".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> File | None:
    if response.status_code == 200:
        response_200 = File(payload=BytesIO(response.content))

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[File]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient,
    edited: bool | Unset = False,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> Response[File]:
    """Download original asset

     Downloads the original file of the specified asset.

    Args:
        id (UUID):
        edited (bool | Unset):  Default: False.
        key (str | Unset):
        slug (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[File]
    """

    kwargs = _get_kwargs(
        id=id,
        edited=edited,
        key=key,
        slug=slug,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: UUID,
    *,
    client: AuthenticatedClient,
    edited: bool | Unset = False,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> File | None:
    """Download original asset

     Downloads the original file of the specified asset.

    Args:
        id (UUID):
        edited (bool | Unset):  Default: False.
        key (str | Unset):
        slug (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        File
    """

    return sync_detailed(
        id=id,
        client=client,
        edited=edited,
        key=key,
        slug=slug,
    ).parsed


async def asyncio_detailed(
    id: UUID,
    *,
    client: AuthenticatedClient,
    edited: bool | Unset = False,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> Response[File]:
    """Download original asset

     Downloads the original file of the specified asset.

    Args:
        id (UUID):
        edited (bool | Unset):  Default: False.
        key (str | Unset):
        slug (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[File]
    """

    kwargs = _get_kwargs(
        id=id,
        edited=edited,
        key=key,
        slug=slug,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: UUID,
    *,
    client: AuthenticatedClient,
    edited: bool | Unset = False,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> File | None:
    """Download original asset

     Downloads the original file of the specified asset.

    Args:
        id (UUID):
        edited (bool | Unset):  Default: False.
        key (str | Unset):
        slug (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        File
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            edited=edited,
            key=key,
            slug=slug,
        )
    ).parsed
