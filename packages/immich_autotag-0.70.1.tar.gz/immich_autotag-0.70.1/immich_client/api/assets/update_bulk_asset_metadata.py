from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.asset_metadata_bulk_response_dto import AssetMetadataBulkResponseDto
from ...models.asset_metadata_bulk_upsert_dto import AssetMetadataBulkUpsertDto
from ...types import Response


def _get_kwargs(
    *,
    body: AssetMetadataBulkUpsertDto,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/assets/metadata",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> list[AssetMetadataBulkResponseDto] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = AssetMetadataBulkResponseDto.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[list[AssetMetadataBulkResponseDto]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: AssetMetadataBulkUpsertDto,
) -> Response[list[AssetMetadataBulkResponseDto]]:
    """Upsert asset metadata

     Upsert metadata key-value pairs for multiple assets.

    Args:
        body (AssetMetadataBulkUpsertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[AssetMetadataBulkResponseDto]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: AssetMetadataBulkUpsertDto,
) -> list[AssetMetadataBulkResponseDto] | None:
    """Upsert asset metadata

     Upsert metadata key-value pairs for multiple assets.

    Args:
        body (AssetMetadataBulkUpsertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[AssetMetadataBulkResponseDto]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: AssetMetadataBulkUpsertDto,
) -> Response[list[AssetMetadataBulkResponseDto]]:
    """Upsert asset metadata

     Upsert metadata key-value pairs for multiple assets.

    Args:
        body (AssetMetadataBulkUpsertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[list[AssetMetadataBulkResponseDto]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: AssetMetadataBulkUpsertDto,
) -> list[AssetMetadataBulkResponseDto] | None:
    """Upsert asset metadata

     Upsert metadata key-value pairs for multiple assets.

    Args:
        body (AssetMetadataBulkUpsertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        list[AssetMetadataBulkResponseDto]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
