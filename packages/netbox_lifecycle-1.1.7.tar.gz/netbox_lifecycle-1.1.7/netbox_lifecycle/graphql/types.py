from typing import Annotated, Union

import strawberry
import strawberry_django

from dcim.graphql.types import (
    ManufacturerType,
    DeviceType,
    DeviceTypeType,
    ModuleTypeType,
    ModuleType,
)
from virtualization.graphql.types import VirtualMachineType
from netbox.graphql.types import PrimaryObjectType
from .filters import *

from netbox_lifecycle import models

__all__ = (
    'VendorType',
    'SupportSKUType',
    'SupportContractType',
    'SupportContractAssignmentType',
    'LicenseType',
    'LicenseAssignmentType',
    'HardwareLifecycleType',
)


@strawberry_django.type(models.Vendor, fields='__all__', filters=VendorFilter)
class VendorType(PrimaryObjectType):
    name: str


@strawberry_django.type(models.SupportSKU, fields='__all__', filters=SupportSKUFilter)
class SupportSKUType(PrimaryObjectType):

    sku: str
    manufacturer: ManufacturerType


@strawberry_django.type(
    models.SupportContract, fields='__all__', filters=SupportContractFilter
)
class SupportContractType(PrimaryObjectType):

    vendor: VendorType
    contract_id: str
    start: str | None
    renewal: str | None
    end: str | None


@strawberry_django.type(models.License, fields='__all__', filters=LicenseFilter)
class LicenseType(PrimaryObjectType):

    manufacturer: ManufacturerType
    name: str


@strawberry_django.type(
    models.SupportContractAssignment,
    fields='__all__',
    filters=SupportContractAssignmentFilter,
)
class SupportContractAssignmentType(PrimaryObjectType):
    contract: SupportContractType
    sku: SupportSKUType | None
    device: DeviceType | None
    module: ModuleType | None
    virtual_machine: VirtualMachineType | None
    license: LicenseType | None
    end: str | None


@strawberry_django.type(
    models.LicenseAssignment, fields='__all__', filters=LicenseAssignmentFilter
)
class LicenseAssignmentType(PrimaryObjectType):
    license: LicenseType
    vendor: VendorType
    device: DeviceType | None
    virtual_machine: VirtualMachineType | None
    quantity: int | None


@strawberry_django.type(
    models.HardwareLifecycle, fields='__all__', filters=HardwareLifecycleFilter
)
class HardwareLifecycleType(PrimaryObjectType):
    assigned_object_type: (
        Annotated["ContentTypeType", strawberry.lazy('netbox.graphql.types')] | None
    )
    assigned_object_id: int
    assigned_object: (
        Annotated[
            Union[
                Annotated["DeviceType", strawberry.lazy('dcim.graphql.types')],
                Annotated["ModuleType", strawberry.lazy('dcim.graphql.types')],
            ],
            strawberry.union("HardwareLifecycleObjectTypes"),
        ]
        | None
    )
    end_of_sale: str
    end_of_maintenance: str | None
    end_of_security: str | None
    last_contract_attach: str | None
    last_contract_renewal: str | None
    end_of_support: str
    notice: str | None
    documentation: str | None


class HardwareLifecycleObjectTypes:
    class Meta:
        types = (
            DeviceTypeType,
            ModuleTypeType,
        )

    @classmethod
    def resolve_type(cls, instance, info):
        if type(instance) is DeviceType:
            return DeviceTypeType
        if type(instance) is ModuleType:
            return ModuleTypeType
