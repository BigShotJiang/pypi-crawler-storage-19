# Hello Ensai

## Démarrer le projet

```sh
uv sync
uv run python -m helloensai
```

- `uv sync` permet de récupérer la version de python qui matche le pyproject et installer les dépendances, uv va stocker tout ça dans un `.venv`.
- `uv run` permet d'utiliser l'environnement virtuel ainsi crée pour lancer le programme.

## Publication
Pour publier avec UV, il faut bien configurer son projet et notamment le fichier pyproject.toml.

- Par défaut uv publie le fichier qui est dans `src`

Vous pouvez y contrevenir
