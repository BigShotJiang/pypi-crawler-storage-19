import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

from sc2_datasets.replay_parser.details.details import Details
from sc2_datasets.replay_parser.game_events.game_event import GameEvent
from sc2_datasets.replay_parser.game_events.game_events_parser import GameEventsParser
from sc2_datasets.replay_parser.header.header import Header
from sc2_datasets.replay_parser.init_data.init_data import InitData
from sc2_datasets.replay_parser.message_events.message_event import MessageEvent
from sc2_datasets.replay_parser.message_events.message_events_parser import (
    MessageEventsParser,
)
from sc2_datasets.replay_parser.metadata.metadata import Metadata
from sc2_datasets.replay_parser.toon_player_desc_map.toon_player_desc import (
    ToonPlayerDesc,
)
from sc2_datasets.replay_parser.tracker_events.tracker_event import TrackerEvent
from sc2_datasets.replay_parser.tracker_events.tracker_events_parser import (
    TrackerEventsParser,
)


@dataclass
class AdditionalInformation:
    replaypack_name: str | None
    replaypack_url: str | None
    filename: str | None
    original_filepath: str | None

    @staticmethod
    def from_dict(d: dict) -> "AdditionalInformation":
        return AdditionalInformation(
            replaypack_name=d.get("replaypack_name", None),
            replaypack_url=d.get("replaypack_url", None),
            filename=d.get("filename", None),
            original_filepath=d.get("original_filepath", None),
        )


@dataclass
class SC2ReplayData:
    filepath: Path
    header: Header
    initData: InitData
    details: Details
    metadata: Metadata
    messageEvents: list[MessageEvent] = field(default_factory=list)
    gameEvents: list[GameEvent] = field(default_factory=list)
    trackerEvents: list[TrackerEvent] = field(default_factory=list)
    toonPlayerDescMap: list = field(default_factory=list)
    gameEventsErr: bool = False
    messageEventsErr: bool = False
    trackerEventsErr: bool = False
    additionalInformation: AdditionalInformation | None = None

    # TODO: Add tests!!!!!
    @staticmethod
    def from_dict(loaded_data: dict, replay_filepath: str) -> "SC2ReplayData":
        SC2ReplayData.sanitize_events(loaded_data=loaded_data)

        additional_information_obj = loaded_data.get("additional_information", None)
        additiona_information = (
            AdditionalInformation.from_dict(d=additional_information_obj)
            if additional_information_obj
            else None
        )

        return SC2ReplayData(
            filepath=replay_filepath,
            header=Header.from_dict(d=loaded_data["header"]),
            initData=InitData.from_dict(d=loaded_data["initData"]),
            details=Details.from_dict(d=loaded_data["details"]),
            metadata=Metadata.from_dict(d=loaded_data["metadata"]),
            messageEvents=[
                MessageEventsParser.from_dict(d=event_dict)
                for event_dict in loaded_data.get("messageEvents", [])
            ],
            gameEvents=[
                GameEventsParser.from_dict(d=event_dict)
                for event_dict in loaded_data.get("gameEvents", [])
            ],
            trackerEvents=[
                TrackerEventsParser.from_dict(d=event_dict)
                for event_dict in loaded_data.get("trackerEvents", [])
            ],
            toonPlayerDescMap=[
                ToonPlayerDesc.from_dict(toon=toon, d=player_dict)
                for toon, player_dict in loaded_data.get(
                    "ToonPlayerDescMap", {}
                ).items()
            ],
            gameEventsErr=loaded_data.get("gameEventsErr", False),
            messageEventsErr=loaded_data.get("messageEventsErr", False),
            trackerEventsErr=loaded_data.get("trackerEvtsErr", False),
            additionalInformation=additiona_information,
        )

    @staticmethod
    def from_file(replay_filepath: Path | str) -> "SC2ReplayData":
        """
        Static method returning initialized SC2ReplayData class from a dictionary.
        This helps with the original JSON parsing.

        Parameters
        ----------
        replay_filepath : Path | str
            Specifies a filepath to a JSON file containing data\
            from parsed .SC2Replay file.

        Returns
        -------
        SC2ReplayData
            Returns an initialized SC2ReplayData object.

        Examples
        -------
        The factory method ``from_file`` assists with initializing a ``SC2ReplayData`` class.
        All that is required is a known path to the file that should be parsed.

        >>> replay_data = SC2ReplayData.from_file("test/test_files/single_replay/test_replay.json")
        >>> assert isinstance(replay_data, SC2ReplayData)
        """

        replay_path = (
            replay_filepath
            if isinstance(replay_filepath, Path)
            else Path(replay_filepath).resolve()
        )

        logging.info(f"Attempting to parse: {str(replay_filepath)}")
        with replay_path.open(mode="r", encoding="utf-8") as replay_file:
            loaded_data = json.load(replay_file)
            return SC2ReplayData.from_dict(
                loaded_data=loaded_data,
                replay_filepath=str(replay_filepath),
            )

    @staticmethod
    def sanitize_events(loaded_data: dict):
        message_events = loaded_data.get("messageEvents", [])
        if message_events is None:
            loaded_data["messageEvents"] = []

        game_events = loaded_data.get("gameEvents", [])
        if game_events is None:
            loaded_data["gameEvents"] = []

        tracker_events = loaded_data.get("trackerEvents", [])
        if tracker_events is None:
            loaded_data["trackerEvents"] = []

    def __hash__(self) -> int:
        """
        Custom hashing function based on the fields that were read from replay.
        This hashing function returns a result of hash() call
        on a tuple constructed as follows:
        (game_duration_loops, game_time_utc, game_map, game_version,
        player_toon_map_len, player_tuple_toon,)

        Returns
        -------
        int
            Returns an int (hash) representation of the SC2ReplayData class.
        """

        game_duration_loops = self.header.elapsedGameLoops
        game_time_utc = self.details.timeUTC
        game_map = self.metadata.mapName
        game_version = self.metadata.gameVersion
        player_toon_map_len = len(self.toonPlayerDescMap)
        player_tuple_toon = tuple(toon.toon for toon in self.toonPlayerDescMap)

        return hash(
            (
                game_duration_loops,
                game_time_utc,
                game_map,
                game_version,
                player_toon_map_len,
                player_tuple_toon,
            )
        )
