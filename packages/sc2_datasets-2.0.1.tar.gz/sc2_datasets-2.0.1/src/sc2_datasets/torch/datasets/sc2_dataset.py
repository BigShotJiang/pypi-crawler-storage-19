from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Callable

from torch.utils.data import Dataset
from tqdm import tqdm

from sc2_datasets.available_replaypacks import DatasetProperties
from sc2_datasets.replay_data.sc2_replay_data import SC2ReplayData
from sc2_datasets.torch.datasets.sc2_replaypack_dataset import SC2ReplaypackDataset


class SC2Dataset(Dataset):
    """
    Inherits from PyTorch Dataset and ensures that the dataset for SC2EGSet is downloaded.

    Parameters
    ----------
    names_urls : list[DatasetProperties]
        Specifies the URL of the dataset which will be used to download the files.
    unpack_dir : Path | str
        Specifies the path of a directory where the dataset files will be unpacked.
    download_dir : Path | str
        Specifies the path of a directory where the dataset files will be downloaded.
    unpack_n_workers : int, optional
        Specifies the number of workers that will be used for unpacking the archive, defaults to 16.
    transform : Func[SC2ReplayData, T]
        PyTorch transform function that takes SC2ReplayData and returns something.
    validator : Callable | None, optional
        Specifies the validation option for fetched data, defaults to None.
    """

    def __init__(
        self,
        names_urls: list[DatasetProperties],
        unpack_dir: Path | str = Path("./data/unpack").resolve(),
        download_dir: Path | str = Path("./data/download").resolve(),
        download: bool = True,
        unpack_n_workers: int = 16,
        transform: Callable | None = None,
        validator: Callable | None = None,
    ):
        # PyTorch fields:
        self.transform = transform

        # Custom fields:
        self.download_dir = (
            download_dir
            if isinstance(download_dir, Path)
            else Path(download_dir).resolve()
        )
        self.unpack_dir = (
            unpack_dir if isinstance(unpack_dir, Path) else Path(unpack_dir).resolve()
        )
        self.names_urls = names_urls
        self.download = download
        self.unpack_n_workers = unpack_n_workers
        self.validator = validator

        self.skip_files: dict[str, set[str]] = {}

        # We have received an URL for the dataset
        # and it migth not have been downloaded:
        self.len = 0
        self.ensure_downloaded()

    def ensure_downloaded(self):
        """
        Ensures that the dataset was downloaded before accessing the __len__ or __getitem__ methods.
        """

        list_of_arguments = []
        for dataset_properties in self.names_urls:
            list_of_arguments.append(
                {
                    "replaypack_name": dataset_properties.name,
                    "unpack_dir": self.unpack_dir,
                    "download_dir": self.download_dir,
                    "url": dataset_properties.url,
                    "download": self.download,
                    "unpack_n_workers": self.unpack_n_workers,
                    "validator": self.validator,
                }
            )

        # NOTE: The parameter of max_workers may be customizable,
        # Be wary that this operation is downloading the dataset,
        # don't DDOS people with this:
        with ThreadPoolExecutor(
            max_workers=3,
            initializer=tqdm.set_lock,
            initargs=(tqdm.get_lock(),),
        ) as executor:
            self.replaypacks = list(
                executor.map(
                    SC2ReplaypackDataset.from_args,
                    list_of_arguments,
                )
            )

        for replaypack in self.replaypacks:
            self.len += len(replaypack)

    def __len__(self) -> int:
        """
        Returns the number of items that are within the dataset
        """
        return self.len

    def __getitem__(self, index: Any) -> tuple[Any, Any] | SC2ReplayData:
        """
        Exposes logic of getting a single parsed item by using dataset[index].

        Parameters
        ----------
        index : Any
            Specifies the index of an item that should be retrieved.

        Raises
        ------
        IndexError
            To support negative indexing, if the index is less than zero twice,\
            IndexError is raised.
        IndexError
            If the index is greater than length of the dataset, IndexError is raised.

        Returns
        -------
        tuple[Any, Any] | SC2ReplayData
            Returns a parsed SC2ReplayData from an underlying SC2ReplaypackDataset,
            or a result of a transform that was passed to the dataset.
        """

        # If the index is negative, treat it as if expressed from the back of the sequence.
        # For example, if index is -1 and lenght is 10,
        # it means we are looking for the last element, which is at index 10 + (-1) = 9
        if index < 0:
            index = self.len + index

        if index < 0:
            raise IndexError(f"Computed index {index} is still less than zero!")

        if index > self.len:
            raise IndexError(f"Computed index {index} is greater than {self.len}!")

        for replaypack in self.replaypacks:
            if index < len(replaypack):
                if self.transform:
                    return self.transform(replaypack[index])
                return replaypack[index]
            else:
                index -= len(replaypack)
