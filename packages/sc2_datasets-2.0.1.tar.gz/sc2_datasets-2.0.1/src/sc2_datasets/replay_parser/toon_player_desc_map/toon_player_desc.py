from dataclasses import dataclass
from typing import Any

# pylama:ignore=E501
from sc2_datasets.replay_parser.toon_player_desc_map.toon_player_info import (
    ToonPlayerInfo,
)


@dataclass
class ToonPlayerDesc:
    """
    Specifies ToonPlayerDesc class representation.

    Parameters
    ----------
    toon : Toon
        Specifies a player's unique account identifier, example: 3-S2-1-6904171.
    toon_player_info : ToonPlayerInfo
        Specific a ToonPlayerInfo class object, which includes a list of parameters.
    """

    toon: str
    toon_player_info: ToonPlayerInfo

    @staticmethod
    def from_dict(toon: str, d: dict[str, Any]) -> "ToonPlayerDesc":
        """
        Specifies ToonPlayerDesc class representation.

        Parameters
        ----------
        toon : Toon
            Specifies a player's unique account identifier, example: 3-S2-1-6904171.
        toon_player_info : ToonPlayerInfo
            Specific a ToonPlayerInfo class object, which includes a list of parameters.
        """
        return ToonPlayerDesc(
            toon=toon,
            toon_player_info=ToonPlayerInfo.from_dict(d=d),
        )
