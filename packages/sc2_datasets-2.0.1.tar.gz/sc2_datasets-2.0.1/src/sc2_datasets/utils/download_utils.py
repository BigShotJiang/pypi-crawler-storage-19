import logging
import time
from pathlib import Path

import requests
from tqdm import tqdm


# TODO: There are two servers hosting the dataset files,
# TODO: this function could have a failover mechanism implemented where
# TODO: if the first server is not responsive or causes errors,
# TODO: the function would switch to the second server URL automatically.
def download_replaypack(
    destination_dir: Path,
    replaypack_name: str,
    replaypack_url: str,
) -> Path | None:
    """
    Exposes logic for downloading a single StarCraft II replaypack from an url.

    Parameters
    ----------
    destination_dir : Path
        Specifies the destination directory where the replaypack will be saved.
    replaypack_name : str
        Specifies the name of a replaypack that will\
        be used for the downloaded .zip archive.
    replaypack_url : str
        Specifies the url that is a direct link\
        to the .zip which will be downloaded.

    Returns
    -------
    Path | None
        Returns the filepath to the downloaded .zip archive. If the download
        failed, None is returned.

    Examples
    --------
    The use of this method is intended
    to download a .zip replaypack containing StarCraft II games.

    Replaypack download directory should be empty before running
    this function.

    Replaypack name will be used as the name for the downloaded .zip archive.

    Replaypack url should be valid and poiting directly to a .zip archive hosted
    on some server.

    The parameters should be set as in the example below.

    >>> from pathlib import Path
    >>> replaypack_download_dir = Path("datasets/download_directory").resolve()
    >>> replaypack_name = "TournamentName"
    >>> replaypack_url = "some_url"
    >>> download_replaypack_object = download_replaypack(
    ...    destination_dir=replaypack_download_dir,
    ...    replaypack_name=replaypack_name,
    ...    replaypack_url=replaypack_url)

    >>> assert isinstance(replaypack_download_dir, Path)
    >>> assert isinstance(replaypack_name, str)
    >>> assert isinstance(replaypack_url, str)
    >>> assert len(os.listdir(replaypack_download_dir)) == 0
    >>> assert existing_files[0].endswith(".zip")
    """

    # Check if there is something in the destination directory:
    existing_files = []
    if destination_dir.exists():
        existing_files = list(destination_dir.iterdir())

    filename_with_ext = replaypack_name + ".zip"
    download_filepath = Path(destination_dir, filename_with_ext).resolve()

    # The file was previously downloaded so return it immediately:
    if existing_files:
        if download_filepath in existing_files:
            return download_filepath

    # Send a request and save the response content into a .zip file.
    # The .zip file should be a replaypack:
    downloaded = False
    n_retries = 5
    initial_delay = 2
    connect_timeout = 5
    read_timeout = 10

    while not downloaded or n_retries > 0:
        try:
            with requests.get(
                url=replaypack_url,
                stream=True,
                timeout=(connect_timeout, read_timeout),
            ) as response:
                total_size = int(response.headers.get("content-length", 0))
                chunk_size = 1 * 10**6  # 1 MB

                # Read the response content. To ensure that the request was successful,
                # we need 200 OK response code, any other code triggers an exception
                # and results in an exponential backoff retry.
                response_code = response.status_code
                reason = response.reason
                if response_code != requests.codes.ok:
                    raise requests.RequestException(
                        f"Response code: {response_code}, Reason: {reason}"
                    )

                # Saving the content into a .zip file:
                with (
                    download_filepath.open("wb") as output_zip_file,
                    tqdm(
                        total=total_size,
                        unit="B",
                        unit_scale=True,
                        desc=f"Downloading: {replaypack_name}",
                    ) as progress_bar,
                ):
                    for data_chunk in response.iter_content(chunk_size=chunk_size):
                        size = output_zip_file.write(data_chunk)
                        progress_bar.update(size)

                return download_filepath
        except requests.RequestException as e:
            n_retries -= 1
            if n_retries <= 0:
                logging.error(
                    f"Download failed for {replaypack_name} from {replaypack_url} with error: {e}. "
                    f"No retries left."
                )
                return None
            logging.warning(
                f"Download failed for {replaypack_name} from {replaypack_url} with error: {e}. "
                f"Retries left: {n_retries}"
            )

            # Exponential backoff before retrying:
            time.sleep(initial_delay)
            initial_delay *= 2

    return None
