import json
import logging
from pathlib import Path


# TODO: consider splitting file creation out from this method
def read_validation_file(
    path: Path,
) -> tuple[set[Path], set[Path]]:
    """
    Attempts to read the validation file from a specified path.

    Parameters
    ----------
    path : Path
        Specifies the path that will be used to read the validation file.

    Returns
    -------
    tuple[set[Path], set[Path]]
        Returns a tuple of sets containing files that were validated.

    Examples
    --------
    This function is a helper that is required to have persistent validators which are
    able to skip the files that were previously processed.
    It is tasked with reading the validation file.
    Return of this function shoud contain information on which files were validated
    (all of the validated files), and which files ought to be skipped.

    >>> from pathlib import Path
    >>> validator_file_content = read_validation_file(path=Path("validator_file.json"))
    >>> assert len(validator_file_content[0]) == 2
    >>> assert len(validator_file_content[1]) == 1
    """

    if not path.is_file():
        with path.open(mode="w", encoding="utf-8") as input_file:
            # If there is no content in the file, initlialize empty lists and write them to file:
            initialize_content = {"validated_files": [], "skip_files": []}
            json.dump(initialize_content, input_file)

    validated_file_set = {}
    skip_file_set = {}
    # Reading the file:
    with path.open(mode="r", encoding="utf-8") as input_file:
        try:
            # Try reading the data from JSON:
            json_data = json.load(input_file)
            # Immediately converting the lists of strings denoting paths to sets:
            validated_file_set = set(
                Path(filepath).resolve() for filepath in json_data["validated_files"]
            )
            skip_file_set = set(
                Path(filepath).resolve() for filepath in json_data["skip_files"]
            )
        except Exception as e:
            logging.error("Error while parsing json!", exc_info=e)

    return (validated_file_set, skip_file_set)


def save_validation_file(
    validated_files: set[Path],
    skip_files: set[Path],
    path: Path = Path("validator_file.json"),
) -> None:
    """
    Attempts to save the validation file to a specified path.

    Parameters
    ----------
    validated_files : set[Path]
        Specifies the list of paths to replays that were verified\
        as ones that can be used in further processing.
    skip_files : set[Path]
        Specifies the list of paths to replays that were verified\
        as ones that should be skipped in further processing.
    path : Path, optional
        Specifies the path to the file that will be saved,\
        by default Path("validator_file.json")

    Examples
    --------
    This function is a helper that is required to have persistent validators which are
    able to skip the files that were previously processed.
    It is tasked with saving the information that was processed
    by the validators so that future runs of the program can use this information.

    >>> from pathlib import Path
    >>> validated_files = {Path("validated_file_0.json"), Path("validated_file_1.json")}
    >>> skip_files = {Path("validated_file_0.json")}
    >>> validator_file_content = save_validation_file(
    ...                                         validated_files=validated_files,
    ...                                         skip_files=skip_files,
    ...                                         )
    """

    # Gettings paths as posix to be able to serialize them:
    validated_file_list = [str(Path(file).resolve()) for file in validated_files]
    skip_file_list = [str(Path(file).resolve()) for file in skip_files]

    # Initializing the dict that will be serialized to a file:
    file_dict = {
        "validated_files": validated_file_list,
        "skip_files": skip_file_list,
    }
    with path.open(mode="w", encoding="utf-8") as output_file:
        json.dump(file_dict, output_file)
