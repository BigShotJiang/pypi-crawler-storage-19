from pathlib import Path

from sc2_datasets.validators.validate_chunk import validate_chunk
from sc2_datasets.validators.validator_utils import (
    read_validation_file,
    save_validation_file,
)


# REVIEW: This function:
# TODO: Add temporary files to be used as a validator file:
def validate_integrity_persist_sp(
    list_of_replays: list[Path],
    validation_file_path: Path,
) -> set[Path]:
    """
    Exposes the logic for validating replays using a single process.
    This function uses a validation file that persists the files which were previously checked.

    Parameters
    ----------
    list_of_replays : list[Path]
        Specifies the list of replays that are supposed to be validated.
    validation_file_path : Path
        Specifies the path to the validation file\
        which will be read to obtain the

    Returns
    -------
    set[Path]
        Returns a set of files that should be skipped in further processing.

    Examples
    --------
    Persistent validators save the validation information to a specified filepath.
    Only the files that ought to be skipped are returned as a set from this function.

    >>> from pathlib import Path
    >>> replays_to_skip = validate_integrity_persist_sp(
    ...                         list_of_replays=[
    ...                               Path("test/test_files/single_replay/test_replay.json"),
    ...                               Path("test/test_files/single_replay/test_bit_flip_example.json"),
    ...                         ],
    ...                         validation_file_path=Path("validator_file.json"),
    ...                   )
    >>> assert len(replays_to_skip) == 1
    """

    # Reading from a file:
    read_validated_files, read_skip_files = read_validation_file(
        path=validation_file_path
    )

    # Validate only the files we haven't already validated:
    files_to_validate = set(list_of_replays) - read_validated_files - read_skip_files
    # TODO: Consider changing the input param to set
    # Perform the validation:
    validated_files, skip_files = validate_integrity_sp(
        list_of_replays=list(files_to_validate)
    )

    # Updating the sets of validated and skip_files:
    read_validated_files.update(validated_files)
    read_skip_files.update(skip_files)

    # Save to a file:
    save_validation_file(
        validated_files=read_validated_files,
        skip_files=read_skip_files,
        path=validation_file_path,
    )

    return read_skip_files


def validate_integrity_sp(
    list_of_replays: list[Path],
) -> tuple[set[Path], set[Path]]:
    """
    Exposes logic for single process integrity validation of a replay.

    Parameters
    ----------
    list_of_replays : list[Path]
        Specifies the SC2ReplayInfo information\
        of the files that will be validated.

    Returns
    -------
    tuple[set[Path], set[Path]]
        Returns a tuple that contains (validated replays, files to be skipped).

    Examples
    --------
    Validators can be used to check if a file is correct before loading it for some modeling task.
    Below you will find a sample execution which
    should contain one correct file and one incorrect file.
    This results in the final tuple containing two sets.
    The first tuple denotes correctly validated files,
    whereas the second tuple denotes the files that should be skipped in modeling tasks.

    >>> validated_replays = validate_integrity_sp(
    ...                         list_of_replays=[
    ...                               Path("./test/test_files/single_replay/test_replay.json"),
    ...                               Path("./test/test_files/single_replay/test_bit_flip_example.json"),
    ...                         ],
    ...                   )
    >>> assert len(validated_replays[0]) == 2
    >>> assert len(validated_replays[1]) == 1
    """

    # TODO: Convert this!
    validated_files = validate_chunk(list_of_replays=list_of_replays)

    # REVIEW: revisit
    # Convert result to two sets:
    validated = set()
    skip_files = set()
    for sc2_file_info, is_correct in validated_files:
        if not is_correct:
            skip_files.add(sc2_file_info)

        validated.add(sc2_file_info)

    return (validated, skip_files)
