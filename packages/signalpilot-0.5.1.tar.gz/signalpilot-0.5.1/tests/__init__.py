"""SignalPilot CLI tests."""
