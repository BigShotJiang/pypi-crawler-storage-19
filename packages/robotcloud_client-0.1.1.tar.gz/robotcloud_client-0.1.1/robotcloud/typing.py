from typing import TypedDict, Dict, List, Any, Literal


RobotCloudProjectAccessLevel = Literal[
    "BLOCKED",
    "RESTRICTED",
    "BASIC",
    "ADVANCED"
]

RobotCloudProjectAppAccessLevel = Literal[
    "BLOCKED",
    "STANDARD",
    "ADVANCED",
    "ADMIN"
]

class RobotCloudNamedItemData(TypedDict):
    id: str
    name: str


class RobotCloudDescribedItemData(RobotCloudNamedItemData):
    description: str


class RobotCloudServiceInstance(RobotCloudNamedItemData):
    service: str


class RobotCloudDeviceDetails(RobotCloudDescribedItemData):
    location: str
    address: Dict[str, int]
    type: int
    configuration_type: str
    tags: List[str]


class RobotCloudProjectDetails(RobotCloudDescribedItemData):
    version: int
    organization: str
    access_level: RobotCloudProjectAccessLevel
    app_access_level: RobotCloudProjectAppAccessLevel
    country: str
    timezone: str
    longitude: float
    latitude: float
    image_url: str
    application_enabled: bool


class RobotCloudServiceInstanceMeasurement(TypedDict):
    instance: str
    time_mark: str
    status: str
    value: Dict[str, Any]


class RobotCloudServiceInstanceDetails(RobotCloudDescribedItemData):
    tags: List[str]
    classifier: str
    location: str
    service: str
    subsystems: List[str]


HistoricAggregateFunction = Literal["count", "increase", "mean", "first", "last", "max", "min",
                                    "amax", "amin", "pmax", "pmin", "nmax", "nmin"]
