# duecalc

CPython extension for calculating due dates excluding weekends and holidays.

## Build
```bash
python -m build


----------------
1. pip install build
2. python -m build     or    python -m build --wheel