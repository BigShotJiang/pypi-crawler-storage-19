#include <Python.h>
#include <time.h>

static int is_weekday(struct tm *tm_date) {
    // tm_wday: Sunday = 0, Saturday = 6
    return (tm_date->tm_wday >= 1 && tm_date->tm_wday <= 5);
}

static int is_holiday(PyObject *holidays, struct tm *tm_date) {
    char buffer[11];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d", tm_date);

    Py_ssize_t len = PyList_Size(holidays);
    for (Py_ssize_t i = 0; i < len; i++) {
        PyObject *item = PyList_GetItem(holidays, i);  // borrowed ref
        if (PyUnicode_Check(item)) {
            if (strcmp(PyUnicode_AsUTF8(item), buffer) == 0) {
                return 1;
            }
        }
    }
    return 0;
}

static PyObject* calculate_due_date(PyObject* self, PyObject* args) {
    const char* start_date_str;
    int time_limit;
    PyObject* holidays;

    if (!PyArg_ParseTuple(args, "siO!", &start_date_str, &time_limit,
                          &PyList_Type, &holidays)) {
        return NULL;
    }

    struct tm tm_date = {0};
    if (!strptime(start_date_str, "%Y-%m-%d", &tm_date)) {
        PyErr_SetString(PyExc_ValueError, "Invalid date format, expected YYYY-MM-DD");
        return NULL;
    }

    time_t current = mktime(&tm_date);
    int added_days = 0;

    while (added_days < time_limit) {
        current += 86400;  // add 1 day
        struct tm *next_day = localtime(&current);

        if (is_weekday(next_day) && !is_holiday(holidays, next_day)) {
            added_days++;
        }
    }

    char result[11];
    strftime(result, sizeof(result), "%Y-%m-%d", localtime(&current));
    return PyUnicode_FromString(result);
}

static PyMethodDef DueCalcMethods[] = {
    {"calculate_due_date", calculate_due_date, METH_VARARGS,
     "Calculate ETC date excluding weekends and holidays"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef duecalcmodule = {
    PyModuleDef_HEAD_INIT,
    "duecalc",
    NULL,
    -1,
    DueCalcMethods
};

PyMODINIT_FUNC PyInit_duecalc(void) {
    return PyModule_Create(&duecalcmodule);
}
