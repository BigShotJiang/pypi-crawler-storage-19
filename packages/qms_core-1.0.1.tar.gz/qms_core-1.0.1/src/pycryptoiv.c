#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <openssl/evp.h>
#include <string.h>
#include <stdlib.h>

/* -------------------------------------------------- */
/* encrypt (simple placeholder, Python-compatible)   */
/* -------------------------------------------------- */

static PyObject* encrypt(PyObject* self, PyObject* args) {
    const char* text;

    if (!PyArg_ParseTuple(args, "s", &text))
        return NULL;

    return PyUnicode_FromFormat("encrypted(%s)", text);
}

/* -------------------------------------------------- */
/* decrypt_payload                                   */
/* -------------------------------------------------- */

static PyObject* decrypt_payload(PyObject *self, PyObject *args) {
    const char *crypted_token;
    const char *key_str;

    if (!PyArg_ParseTuple(args, "ss", &crypted_token, &key_str))
        return NULL;

    /* Split ct::iv */
    const char *sep = strstr(crypted_token, "::");
    if (!sep) {
        PyErr_SetString(PyExc_ValueError, "Invalid token format");
        return NULL;
    }

    PyObject *ct_b64 = PyUnicode_FromStringAndSize(
        crypted_token, sep - crypted_token
    );
    PyObject *iv_hex = PyUnicode_FromString(sep + 2);

    /* base64 decode ct */
    PyObject *base64 = PyImport_ImportModule("base64");
    PyObject *b64decode = PyObject_GetAttrString(base64, "b64decode");
    PyObject *ct_bytes = PyObject_CallFunctionObjArgs(b64decode, ct_b64, NULL);

    Py_DECREF(base64);
    Py_DECREF(b64decode);
    Py_DECREF(ct_b64);

    if (!ct_bytes) {
        Py_DECREF(iv_hex);
        return NULL;
    }

    /* hex decode iv */
    PyObject *binascii = PyImport_ImportModule("binascii");
    PyObject *unhexlify = PyObject_GetAttrString(binascii, "unhexlify");
    PyObject *iv_bytes = PyObject_CallFunctionObjArgs(unhexlify, iv_hex, NULL);

    Py_DECREF(binascii);
    Py_DECREF(unhexlify);
    Py_DECREF(iv_hex);

    if (!iv_bytes) {
        Py_DECREF(ct_bytes);
        return NULL;
    }

    unsigned char *ciphertext = (unsigned char*)PyBytes_AsString(ct_bytes);
    Py_ssize_t ct_len = PyBytes_Size(ct_bytes);

    unsigned char *iv = (unsigned char*)PyBytes_AsString(iv_bytes);
    unsigned char *key = (unsigned char*)key_str;

    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        PyErr_SetString(PyExc_RuntimeError, "EVP_CIPHER_CTX_new failed");
        goto cleanup;
    }

    EVP_DecryptInit_ex(ctx, EVP_aes_128_ctr(), NULL, key, iv);

    unsigned char *plaintext = malloc(ct_len + 1);
    if (!plaintext) {
        EVP_CIPHER_CTX_free(ctx);
        PyErr_NoMemory();
        goto cleanup;
    }

    int outlen = 0, total = 0;

    EVP_DecryptUpdate(ctx, plaintext, &outlen, ciphertext, ct_len);
    total += outlen;

    EVP_DecryptFinal_ex(ctx, plaintext + total, &outlen);
    total += outlen;

    EVP_CIPHER_CTX_free(ctx);

    plaintext[total] = '\0';

    PyObject *decoded = PyUnicode_DecodeUTF8(
        (char*)plaintext, total, "ignore"
    );

    free(plaintext);

    if (!decoded)
        goto cleanup;

    PyObject *json = PyImport_ImportModule("json");
    PyObject *loads = PyObject_GetAttrString(json, "loads");
    PyObject *result = PyObject_CallFunctionObjArgs(loads, decoded, NULL);

    Py_DECREF(json);
    Py_DECREF(loads);
    Py_DECREF(decoded);

cleanup:
    Py_DECREF(ct_bytes);
    Py_DECREF(iv_bytes);

    return result;
}

/* -------------------------------------------------- */
/* Method table                                      */
/* -------------------------------------------------- */

static PyMethodDef PyCryptoIVMethods[] = {
    {"encrypt", encrypt, METH_VARARGS, "Encrypt data"},
    {"decrypt_payload", decrypt_payload, METH_VARARGS,
     "AES-CTR decrypt payload and return dict"},
    {NULL, NULL, 0, NULL}
};

/* -------------------------------------------------- */
/* Module definition                                 */
/* -------------------------------------------------- */

static struct PyModuleDef pycryptoivmodule = {
    PyModuleDef_HEAD_INIT,
    "pycryptoiv",
    NULL,
    -1,
    PyCryptoIVMethods
};

/* -------------------------------------------------- */
/* Entry point                                       */
/* -------------------------------------------------- */

PyMODINIT_FUNC PyInit_pycryptoiv(void) {
    return PyModule_Create(&pycryptoivmodule);
}
