"""Binsmith agent plugin package."""
