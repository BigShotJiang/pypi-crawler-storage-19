"""Constants for cmdop-llm package."""

# Default base URL for CMDOP LLM service (with /v1 for OpenAI compatibility)
DEFAULT_BASE_URL = "https://llm.cmdop.com/v1"

# Environment variable names
ENV_API_KEY = "CMDOP_API_KEY"
ENV_BASE_URL = "CMDOP_BASE_URL"

# Default timeout settings (seconds)
DEFAULT_TIMEOUT = 60.0
DEFAULT_MAX_RETRIES = 2
