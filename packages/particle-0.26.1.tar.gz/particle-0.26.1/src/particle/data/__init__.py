# Copyright (c) 2018-2026, Eduardo Rodrigues and Henry Schreiner.
#
# Distributed under the 3-clause BSD license, see accompanying file LICENSE
# or https://github.com/scikit-hep/particle for details.

from __future__ import annotations

from importlib import resources

__all__ = ("basepath",)


basepath = resources.files(__name__)


def __dir__() -> tuple[str, ...]:
    return __all__
