"""Utils for graph generation."""
