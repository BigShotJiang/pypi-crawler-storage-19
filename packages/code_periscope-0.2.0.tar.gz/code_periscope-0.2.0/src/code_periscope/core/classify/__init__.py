"""Commit/type classification utilities."""
