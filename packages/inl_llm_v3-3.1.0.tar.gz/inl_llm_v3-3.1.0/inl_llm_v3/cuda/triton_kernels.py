"""
Triton Kernels for INL Dynamics

Fused CUDA kernels that compute INL dynamics in a single pass:
- error = x - mu
- v_next = alpha * v - beta * error
- x_next = x + dt * gate * v_next

Instead of 5 separate kernel launches, we do 1.

Author: Boris Peyriguere
"""

import torch
import torch.nn.functional as F
from typing import Tuple, Optional

# Try to import Triton
try:
    import triton
    import triton.language as tl
    HAS_TRITON = True
except ImportError:
    HAS_TRITON = False
    print("Triton not installed. Using PyTorch fallback.")


if HAS_TRITON:
    # =========================================================================
    # FUSED INL DYNAMICS KERNEL
    # =========================================================================

    @triton.jit
    def _fused_inl_dynamics_kernel(
        # Inputs
        x_ptr, v_ptr, mu_ptr,
        alpha_ptr, beta_ptr, gate_ptr,
        # Outputs
        x_out_ptr, v_out_ptr,
        # Scalars
        dt,
        n_elements,
        # Block size
        BLOCK_SIZE: tl.constexpr
    ):
        """
        Fused INL dynamics kernel.

        Computes in one pass:
            error = x - mu
            v_next = alpha * v - beta * error
            x_next = x + dt * gate * v_next

        Much faster than separate PyTorch ops (5 kernels -> 1 kernel).
        """
        # Program ID
        pid = tl.program_id(0)

        # Block start offset
        block_start = pid * BLOCK_SIZE
        offsets = block_start + tl.arange(0, BLOCK_SIZE)

        # Mask for bounds checking
        mask = offsets < n_elements

        # Load inputs (coalesced memory access)
        x = tl.load(x_ptr + offsets, mask=mask, other=0.0)
        v = tl.load(v_ptr + offsets, mask=mask, other=0.0)
        mu = tl.load(mu_ptr + offsets, mask=mask, other=0.0)
        alpha = tl.load(alpha_ptr + offsets, mask=mask, other=0.0)
        beta = tl.load(beta_ptr + offsets, mask=mask, other=0.0)
        gate = tl.load(gate_ptr + offsets, mask=mask, other=0.0)

        # Fused INL computation
        error = x - mu
        v_next = alpha * v - beta * error
        x_next = x + dt * gate * v_next

        # Store outputs
        tl.store(x_out_ptr + offsets, x_next, mask=mask)
        tl.store(v_out_ptr + offsets, v_next, mask=mask)


    @triton.jit
    def _fused_inl_dynamics_backward_kernel(
        # Forward pass values
        x_ptr, v_ptr, mu_ptr,
        alpha_ptr, beta_ptr, gate_ptr,
        # Gradients from upstream
        dx_out_ptr, dv_out_ptr,
        # Gradient outputs
        dx_ptr, dv_ptr, dmu_ptr,
        dalpha_ptr, dbeta_ptr, dgate_ptr,
        # Scalars
        dt,
        n_elements,
        BLOCK_SIZE: tl.constexpr
    ):
        """
        Backward pass for fused INL dynamics.

        Computes gradients w.r.t. x, v, mu, alpha, beta, gate.
        """
        pid = tl.program_id(0)
        block_start = pid * BLOCK_SIZE
        offsets = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offsets < n_elements

        # Load forward values
        x = tl.load(x_ptr + offsets, mask=mask, other=0.0)
        v = tl.load(v_ptr + offsets, mask=mask, other=0.0)
        mu = tl.load(mu_ptr + offsets, mask=mask, other=0.0)
        alpha = tl.load(alpha_ptr + offsets, mask=mask, other=0.0)
        beta = tl.load(beta_ptr + offsets, mask=mask, other=0.0)
        gate = tl.load(gate_ptr + offsets, mask=mask, other=0.0)

        # Load upstream gradients
        dx_out = tl.load(dx_out_ptr + offsets, mask=mask, other=0.0)
        dv_out = tl.load(dv_out_ptr + offsets, mask=mask, other=0.0)

        # Recompute forward values needed for backward
        error = x - mu
        v_next = alpha * v - beta * error

        # Backward through x_next = x + dt * gate * v_next
        # dx_next/dx = 1 + dt * gate * dv_next/dx
        # dx_next/dgate = dt * v_next
        # dx_next/dv_next = dt * gate

        dv_next = dx_out * dt * gate + dv_out
        dgate = dx_out * dt * v_next

        # Backward through v_next = alpha * v - beta * error
        dalpha = dv_next * v
        dv = dv_next * alpha
        dbeta = -dv_next * error
        derror = -dv_next * beta

        # Backward through error = x - mu
        dx = dx_out + derror
        dmu = -derror

        # Store gradients
        tl.store(dx_ptr + offsets, dx, mask=mask)
        tl.store(dv_ptr + offsets, dv, mask=mask)
        tl.store(dmu_ptr + offsets, dmu, mask=mask)
        tl.store(dalpha_ptr + offsets, dalpha, mask=mask)
        tl.store(dbeta_ptr + offsets, dbeta, mask=mask)
        tl.store(dgate_ptr + offsets, dgate, mask=mask)


    # =========================================================================
    # FUSED ACTIVATIONS KERNEL
    # =========================================================================

    @triton.jit
    def _fused_controller_activations_kernel(
        # Input: raw controller output [alpha_raw, beta_raw, gate_raw]
        ctrl_ptr,
        # Outputs
        alpha_ptr, beta_ptr, gate_ptr,
        # Dimensions
        output_dim,
        n_batch,
        BLOCK_SIZE: tl.constexpr
    ):
        """
        Fused activation functions for controller output.

        alpha = sigmoid(alpha_raw)
        beta = softplus(beta_raw)
        gate = sigmoid(gate_raw)

        Processes all 3 in one kernel instead of 3 separate ops.
        """
        pid = tl.program_id(0)
        batch_idx = pid // 3
        param_idx = pid % 3  # 0=alpha, 1=beta, 2=gate

        if batch_idx >= n_batch:
            return

        # Calculate offset into ctrl tensor [batch, 3*output_dim]
        base_offset = batch_idx * 3 * output_dim + param_idx * output_dim

        for i in range(0, output_dim, BLOCK_SIZE):
            offsets = i + tl.arange(0, BLOCK_SIZE)
            mask = offsets < output_dim

            # Load raw value
            raw = tl.load(ctrl_ptr + base_offset + offsets, mask=mask, other=0.0)

            # Apply activation based on param_idx
            if param_idx == 0:
                # sigmoid for alpha
                activated = tl.sigmoid(raw)
                tl.store(alpha_ptr + batch_idx * output_dim + offsets, activated, mask=mask)
            elif param_idx == 1:
                # softplus for beta: log(1 + exp(x))
                # Numerically stable: max(0, x) + log(1 + exp(-|x|))
                abs_raw = tl.abs(raw)
                activated = tl.maximum(raw, 0.0) + tl.log(1.0 + tl.exp(-abs_raw))
                tl.store(beta_ptr + batch_idx * output_dim + offsets, activated, mask=mask)
            else:
                # sigmoid for gate
                activated = tl.sigmoid(raw)
                tl.store(gate_ptr + batch_idx * output_dim + offsets, activated, mask=mask)


# =============================================================================
# PYTHON WRAPPERS
# =============================================================================

def fused_inl_dynamics(
    x: torch.Tensor,
    v: torch.Tensor,
    mu: torch.Tensor,
    alpha: torch.Tensor,
    beta: torch.Tensor,
    gate: torch.Tensor,
    dt: float = 0.1
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Fused INL dynamics computation.

    Args:
        x: State tensor [batch, dim] or [batch, seq, dim]
        v: Velocity tensor (same shape as x)
        mu: Equilibrium point [dim] (will be broadcast)
        alpha: Damping coefficient (same shape as x)
        beta: Spring constant (same shape as x)
        gate: Output gate (same shape as x)
        dt: Time step

    Returns:
        x_next, v_next
    """
    if not HAS_TRITON:
        # PyTorch fallback
        error = x - mu
        v_next = alpha * v - beta * error
        x_next = x + dt * gate * v_next
        return x_next, v_next

    # Flatten for kernel
    original_shape = x.shape
    x_flat = x.view(-1)
    v_flat = v.view(-1)

    # Broadcast mu if needed
    if mu.dim() == 1:
        # Expand mu to match x shape
        mu_expanded = mu.unsqueeze(0).expand(original_shape).contiguous().view(-1)
    else:
        mu_expanded = mu.view(-1)

    alpha_flat = alpha.view(-1)
    beta_flat = beta.view(-1)
    gate_flat = gate.view(-1)

    n_elements = x_flat.numel()

    # Allocate outputs
    x_out = torch.empty_like(x_flat)
    v_out = torch.empty_like(v_flat)

    # Launch kernel
    BLOCK_SIZE = 1024
    grid = (triton.cdiv(n_elements, BLOCK_SIZE),)

    _fused_inl_dynamics_kernel[grid](
        x_flat, v_flat, mu_expanded,
        alpha_flat, beta_flat, gate_flat,
        x_out, v_out,
        dt,
        n_elements,
        BLOCK_SIZE=BLOCK_SIZE
    )

    # Reshape outputs
    return x_out.view(original_shape), v_out.view(original_shape)


def fused_inl_dynamics_backward(
    x: torch.Tensor,
    v: torch.Tensor,
    mu: torch.Tensor,
    alpha: torch.Tensor,
    beta: torch.Tensor,
    gate: torch.Tensor,
    dx_out: torch.Tensor,
    dv_out: torch.Tensor,
    dt: float = 0.1
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Backward pass for fused INL dynamics.

    Returns:
        dx, dv, dmu, dalpha, dbeta, dgate
    """
    if not HAS_TRITON:
        # PyTorch autograd fallback
        x.requires_grad_(True)
        v.requires_grad_(True)
        mu.requires_grad_(True)
        alpha.requires_grad_(True)
        beta.requires_grad_(True)
        gate.requires_grad_(True)

        error = x - mu
        v_next = alpha * v - beta * error
        x_next = x + dt * gate * v_next

        x_next.backward(dx_out, retain_graph=True)
        v_next.backward(dv_out)

        return x.grad, v.grad, mu.grad, alpha.grad, beta.grad, gate.grad

    # Flatten
    original_shape = x.shape
    x_flat = x.view(-1)
    v_flat = v.view(-1)

    if mu.dim() == 1:
        mu_expanded = mu.unsqueeze(0).expand(original_shape).contiguous().view(-1)
    else:
        mu_expanded = mu.view(-1)

    alpha_flat = alpha.view(-1)
    beta_flat = beta.view(-1)
    gate_flat = gate.view(-1)
    dx_out_flat = dx_out.view(-1)
    dv_out_flat = dv_out.view(-1)

    n_elements = x_flat.numel()

    # Allocate gradient outputs
    dx = torch.empty_like(x_flat)
    dv = torch.empty_like(v_flat)
    dmu = torch.empty_like(mu_expanded)
    dalpha = torch.empty_like(alpha_flat)
    dbeta = torch.empty_like(beta_flat)
    dgate = torch.empty_like(gate_flat)

    # Launch kernel
    BLOCK_SIZE = 1024
    grid = (triton.cdiv(n_elements, BLOCK_SIZE),)

    _fused_inl_dynamics_backward_kernel[grid](
        x_flat, v_flat, mu_expanded,
        alpha_flat, beta_flat, gate_flat,
        dx_out_flat, dv_out_flat,
        dx, dv, dmu, dalpha, dbeta, dgate,
        dt,
        n_elements,
        BLOCK_SIZE=BLOCK_SIZE
    )

    return (
        dx.view(original_shape),
        dv.view(original_shape),
        dmu.view(original_shape) if mu.dim() > 1 else dmu.view(original_shape).sum(dim=0),
        dalpha.view(original_shape),
        dbeta.view(original_shape),
        dgate.view(original_shape)
    )


# =============================================================================
# AUTOGRAD FUNCTION FOR TRAINING
# =============================================================================

class FusedINLDynamicsFunction(torch.autograd.Function):
    """
    Autograd-compatible fused INL dynamics.

    Use this in training to get both forward and backward fused.
    """

    @staticmethod
    def forward(ctx, x, v, mu, alpha, beta, gate, dt):
        x_next, v_next = fused_inl_dynamics(x, v, mu, alpha, beta, gate, dt)
        ctx.save_for_backward(x, v, mu, alpha, beta, gate)
        ctx.dt = dt
        return x_next, v_next

    @staticmethod
    def backward(ctx, dx_out, dv_out):
        x, v, mu, alpha, beta, gate = ctx.saved_tensors
        dt = ctx.dt

        dx, dv, dmu, dalpha, dbeta, dgate = fused_inl_dynamics_backward(
            x, v, mu, alpha, beta, gate, dx_out, dv_out, dt
        )

        return dx, dv, dmu, dalpha, dbeta, dgate, None


# Convenient function that uses autograd
def fused_inl_dynamics_autograd(
    x: torch.Tensor,
    v: torch.Tensor,
    mu: torch.Tensor,
    alpha: torch.Tensor,
    beta: torch.Tensor,
    gate: torch.Tensor,
    dt: float = 0.1
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Fused INL dynamics with autograd support.

    Use this in training - it will use Triton for both forward and backward.
    """
    return FusedINLDynamicsFunction.apply(x, v, mu, alpha, beta, gate, dt)


# =============================================================================
# BENCHMARK
# =============================================================================

def benchmark_inl_dynamics(batch_size: int = 1024, dim: int = 2048, n_iter: int = 100):
    """
    Benchmark fused vs unfused INL dynamics.
    """
    import time

    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # Create test tensors
    x = torch.randn(batch_size, dim, device=device)
    v = torch.randn(batch_size, dim, device=device)
    mu = torch.randn(dim, device=device)
    alpha = torch.sigmoid(torch.randn(batch_size, dim, device=device))
    beta = F.softplus(torch.randn(batch_size, dim, device=device))
    gate = torch.sigmoid(torch.randn(batch_size, dim, device=device))
    dt = 0.1

    # Warmup
    for _ in range(10):
        _ = fused_inl_dynamics(x, v, mu, alpha, beta, gate, dt)
    torch.cuda.synchronize()

    # Benchmark fused
    start = time.perf_counter()
    for _ in range(n_iter):
        x_next, v_next = fused_inl_dynamics(x, v, mu, alpha, beta, gate, dt)
    torch.cuda.synchronize()
    fused_time = (time.perf_counter() - start) / n_iter * 1000

    # Benchmark unfused (PyTorch)
    start = time.perf_counter()
    for _ in range(n_iter):
        error = x - mu
        v_next = alpha * v - beta * error
        x_next = x + dt * gate * v_next
    torch.cuda.synchronize()
    unfused_time = (time.perf_counter() - start) / n_iter * 1000

    print(f"INL Dynamics Benchmark (batch={batch_size}, dim={dim})")
    print(f"  Fused (Triton):   {fused_time:.3f} ms")
    print(f"  Unfused (PyTorch): {unfused_time:.3f} ms")
    print(f"  Speedup: {unfused_time / fused_time:.2f}x")

    return fused_time, unfused_time


if __name__ == "__main__":
    if torch.cuda.is_available():
        benchmark_inl_dynamics()
    else:
        print("CUDA not available, skipping benchmark")
