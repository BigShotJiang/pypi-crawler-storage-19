"""
INL-LLM CUDA/Triton Kernels

Optimized GPU kernels for INL dynamics using Triton.
Provides 2-5x speedup on forward pass by fusing operations.

Usage:
    from inl_llm_v3.cuda import fused_inl_dynamics, FusedMoELayer

Requirements:
    pip install triton
"""

from .triton_kernels import (
    fused_inl_dynamics,
    fused_inl_dynamics_backward,
    HAS_TRITON
)

from .fused_moe import (
    FusedMoEINL,
    fused_expert_forward
)

__all__ = [
    'fused_inl_dynamics',
    'fused_inl_dynamics_backward',
    'FusedMoEINL',
    'fused_expert_forward',
    'HAS_TRITON'
]
