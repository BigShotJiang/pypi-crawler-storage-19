"""
KV Cache support for INL-LLM inference.

Contains:
- INLCacheLayer: Cache for a single layer
- INLCache: Complete cache for all layers
"""

import torch
from typing import Optional, Tuple, List


class INLCacheLayer:
    """
    Cache for a single layer, storing:
    - Attention K, V (standard transformer cache)

    NOTE: We do NOT cache integrator x, v states because integrator dynamics
    run WITHIN each layer for each token, not across tokens. Only attention
    needs to look back at previous tokens' K, V.
    """

    def __init__(self):
        self.keys: Optional[torch.Tensor] = None          # [B, num_heads, seq_len, head_dim]
        self.values: Optional[torch.Tensor] = None        # [B, num_heads, seq_len, head_dim]

    def update_attention(
        self,
        new_keys: torch.Tensor,
        new_values: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Update attention cache with new K, V.

        Args:
            new_keys: [B, num_heads, new_seq_len, head_dim]
            new_values: [B, num_heads, new_seq_len, head_dim]

        Returns:
            Full keys, values (concatenated with past)
        """
        if self.keys is None:
            # First time: initialize cache
            self.keys = new_keys
            self.values = new_values
        else:
            # Concatenate along sequence dimension
            self.keys = torch.cat([self.keys, new_keys], dim=2)
            self.values = torch.cat([self.values, new_values], dim=2)

        return self.keys, self.values

    def get_seq_length(self) -> int:
        """Get current sequence length in cache."""
        if self.keys is not None:
            return self.keys.shape[2]
        return 0

    def reorder_batch(self, beam_idx: torch.LongTensor):
        """Reorder cache for beam search."""
        if self.keys is not None:
            device = self.keys.device
            self.keys = self.keys.index_select(0, beam_idx.to(device))
            self.values = self.values.index_select(0, beam_idx.to(device))


class INLCache:
    """
    Complete cache for INL-LLM model.

    Stores attention K, V for all layers.
    Compatible with HuggingFace's past_key_values interface.

    NOTE: Simpler than typical transformers - we only cache attention K, V,
    not integrator states since those are computed fresh for each token.
    """

    def __init__(self, num_layers: int):
        self.num_layers = num_layers
        self.layers: List[INLCacheLayer] = [INLCacheLayer() for _ in range(num_layers)]

    def __getitem__(self, layer_idx: int) -> INLCacheLayer:
        """Access cache for specific layer."""
        return self.layers[layer_idx]

    def __len__(self) -> int:
        """Number of layers."""
        return self.num_layers

    def get_seq_length(self, layer_idx: int = 0) -> int:
        """Get current sequence length (all layers should be same)."""
        return self.layers[layer_idx].get_seq_length()

    def reorder_cache(self, beam_idx: torch.LongTensor):
        """Reorder all layers for beam search."""
        for layer in self.layers:
            layer.reorder_batch(beam_idx)

    def to_legacy_cache(self) -> Tuple[Tuple[torch.Tensor, torch.Tensor], ...]:
        """
        Convert to tuple format for compatibility.

        Returns:
            Tuple of (K, V) for each layer
        """
        return tuple(
            (layer.keys, layer.values)
            for layer in self.layers
        )

    @staticmethod
    def from_legacy_cache(
        past_key_values: Tuple[Tuple[torch.Tensor, torch.Tensor], ...]
    ) -> 'INLCache':
        """
        Create INLCache from legacy tuple format.

        Args:
            past_key_values: Tuple of (K, V) for each layer
        """
        num_layers = len(past_key_values)
        cache = INLCache(num_layers)

        for layer_idx, (keys, values) in enumerate(past_key_values):
            cache.layers[layer_idx].keys = keys
            cache.layers[layer_idx].values = values

        return cache
