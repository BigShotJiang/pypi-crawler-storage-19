"""
Complete INL-LLM model with all optimizations (Level 1 + 2).

Single production-ready model with maximum efficiency.

Refactored into modular files:
- normalization.py: RMSNorm, SwiGLU
- positional.py: RotaryPositionalEmbedding, PositionalEncoding
- cache.py: INLCacheLayer, INLCache
- attention.py: GroupedQueryAttention, INLCachedAttention
- layers.py: UltraOptimizedINLBlock
- model.py: UltraOptimizedIntegratorLanguageModel, create_ultra_optimized_model
"""

# Import from refactored modules
from .normalization import RMSNorm, SwiGLU
from .positional import RotaryPositionalEmbedding, PositionalEncoding
from .cache import INLCacheLayer, INLCache
from .attention import GroupedQueryAttention, INLCachedAttention
from .layers import UltraOptimizedINLBlock
from .model import (
    UltraOptimizedIntegratorLanguageModel,
    create_ultra_optimized_model,
    HAS_FUSED_MOE
)

# HuggingFace-compatible wrappers (for vLLM support)
from .modeling_inl_llm import (
    INLLLMConfig,
    INLLLMForCausalLM
)

# Aliases for simpler API
IntegratorLanguageModel = UltraOptimizedIntegratorLanguageModel
create_model = create_ultra_optimized_model

__all__ = [
    # Normalization
    'RMSNorm',
    'SwiGLU',
    # Positional
    'RotaryPositionalEmbedding',
    'PositionalEncoding',
    # Cache
    'INLCacheLayer',
    'INLCache',
    # Attention
    'GroupedQueryAttention',
    'INLCachedAttention',
    # Layers
    'UltraOptimizedINLBlock',
    # Model
    'IntegratorLanguageModel',
    'create_model',
    # Legacy aliases
    'UltraOptimizedIntegratorLanguageModel',
    'create_ultra_optimized_model',
    # HuggingFace compatibility
    'INLLLMConfig',
    'INLLLMForCausalLM',
    # Feature flags
    'HAS_FUSED_MOE'
]
