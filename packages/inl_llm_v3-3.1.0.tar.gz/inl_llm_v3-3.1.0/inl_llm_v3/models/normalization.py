"""
Normalization layers for INL-LLM.

Contains:
- RMSNorm: Root Mean Square Layer Normalization
- SwiGLU: SwiGLU activation with gating
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization (RMSNorm)

    Faster than LayerNorm: no mean computation, no bias.
    Used in LLaMA, Mistral, etc.

    RMSNorm(x) = x * rsqrt(mean(x²) + eps) * weight
    """
    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [batch, seq_len, dim]
        rms = torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return x * rms * self.weight


class SwiGLU(nn.Module):
    """
    SwiGLU activation function.

    SwiGLU(x) = Swish(xW) * (xV)

    Better than GELU for LLMs. Used in LLaMA, PaLM, etc.
    """
    def __init__(
        self,
        in_features: int,
        hidden_features: int,
        out_features: int,
        dropout: float = 0.0
    ):
        super().__init__()
        self.w1 = nn.Linear(in_features, hidden_features, bias=False)
        self.w2 = nn.Linear(hidden_features, out_features, bias=False)
        self.w3 = nn.Linear(in_features, hidden_features, bias=False)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # SwiGLU: swish(W1(x)) * W3(x), then W2
        swish = F.silu(self.w1(x))  # Swish = x * sigmoid(x) = SiLU
        gate = self.w3(x)
        x = swish * gate
        x = self.dropout(x)
        x = self.w2(x)
        return x
