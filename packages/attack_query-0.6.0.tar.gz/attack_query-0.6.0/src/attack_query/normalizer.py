"""Query normalizer with LLM support for smart mode."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from attack_query.completion.protocol import CompletionModel
    from attack_query.store import ATTACKDataStore

# Prompt template for query normalization
# Note: Double braces {{}} are used to escape them from Python's .format()
NORMALIZE_PROMPT = """You are a query normalizer for MITRE ATT&CK. Convert the user's natural language query into the canonical form. Return ONLY the normalized query, nothing else.

Canonical forms:
- techniques used by GROUP
- techniques used by GROUP1 or GROUP2
- techniques used by GROUP1 and GROUP2
- techniques used by GROUP1 but not GROUP2
- techniques NOT used by GROUP
- groups using TECHNIQUE_ID
- compare GROUP1 and GROUP2
- groups similar to GROUP
- similarity GROUP1 GROUP2
- software used by GROUP
- groups using SOFTWARE
- techniques for SOFTWARE
- mitigations for TECHNIQUE_ID
- techniques mitigated by MITIGATION
- campaigns by GROUP
- techniques in CAMPAIGN
- campaigns in YEAR
- sub-techniques of TECHNIQUE_ID
- parent of TECHNIQUE_ID
- who is GROUP
- aliases of GROUP

Known groups include: APT28, APT29, APT33, Lazarus Group, Fancy Bear (alias for APT28), Cozy Bear (alias for APT29)
Technique IDs look like: T1566, T1059, T1078, T1566.001

User query: {query}
Normalized:"""


class QueryNormalizer:
    """
    Normalizes natural language queries using LLM assistance.

    This is used in "smart mode" to help parse ambiguous or
    non-standard query phrasings.
    """

    def __init__(
        self,
        model: CompletionModel,
        store: ATTACKDataStore | None = None,
    ) -> None:
        """
        Initialize the normalizer.

        Args:
            model: CompletionModel instance for LLM completions
            store: Optional ATTACKDataStore for group name validation
        """
        self.model = model
        self.store = store

    def normalize(self, query: str) -> str:
        """
        Normalize a natural language query.

        Args:
            query: User's natural language query

        Returns:
            Normalized query in canonical form
        """
        prompt = NORMALIZE_PROMPT.format(query=query)
        result = self.model.complete(prompt)

        # Clean up the result
        result = result.strip()

        # Remove any surrounding quotes
        if result.startswith('"') and result.endswith('"'):
            result = result[1:-1]
        if result.startswith("'") and result.endswith("'"):
            result = result[1:-1]

        return result
