"""
attack-query: Programmatic queries on MITRE ATT&CK threat actor techniques.

Example usage:

    from attack_query import ATTACKDataStore, ATTACKQueryEngine, Matrix

    # Load ATT&CK data (latest version, Enterprise matrix)
    store = ATTACKDataStore()
    store.load()

    # Or load a specific version
    store = ATTACKDataStore(version="12.0")
    store.load()

    # Or load a different matrix (Mobile, ICS)
    store = ATTACKDataStore(matrix=Matrix.MOBILE)
    store.load()

    # Create query engine
    engine = ATTACKQueryEngine(store)

    # Query techniques
    apt28_techniques = engine.get_group_techniques("APT28")

    # Set operations
    shared = engine.techniques_intersection(["APT28", "APT29"])
    unique = engine.techniques_difference(["APT28", "APT29"], ["APT33"])

    # Export to Navigator
    layer = engine.export_navigator_layer(unique, name="Unique to APT28/29")

For natural language queries:

    from attack_query import ATTACKDataStore, ATTACKQueryEngine, NLQueryParser

    store = ATTACKDataStore()
    store.load()
    engine = ATTACKQueryEngine(store)
    parser = NLQueryParser(engine)

    results = parser.parse_and_execute("techniques used by APT28 and APT29 but not APT33")
"""

from attack_query.engine import ATTACKQueryEngine
from attack_query.models import Group, Matrix, Software, Tactic, Technique
from attack_query.parser import NLQueryParser
from attack_query.store import ATTACKDataStore

__version__ = "0.6.0"
__all__ = [
    "ATTACKDataStore",
    "ATTACKQueryEngine",
    "Matrix",
    "NLQueryParser",
    "Technique",
    "Group",
    "Tactic",
    "Software",
]
