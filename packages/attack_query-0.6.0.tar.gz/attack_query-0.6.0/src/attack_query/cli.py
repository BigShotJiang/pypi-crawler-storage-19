"""Command-line interface for attack-query."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from attack_query.engine import ATTACKQueryEngine
from attack_query.parser import NLQueryParser
from attack_query.store import ATTACKDataStore


def print_results(results: dict[str, Any], *, verbose: bool = False) -> None:
    """Pretty-print query results."""
    if "error" in results:
        print(f"\n❌ Error: {results['error']}")
        if "suggestions" in results:
            print("   Did you mean:")
            for suggestion in results["suggestions"]:
                print(f"      • {suggestion}")
        if "suggested_pattern" in results:
            print(f"   Try pattern: {results['suggested_pattern']}")
        elif "hint" in results:
            print(f"   Hint: {results['hint']}")
        return

    query_type = results.get("query_type", "unknown")

    if query_type in (
        "techniques_by_groups",
        "techniques_not_used_by",
        "techniques_by_mixed_entities",
    ):
        operation = results.get("operation", "union")

        if query_type == "techniques_not_used_by":
            exclude = results.get("exclude_groups", [])
            print(f"\n📊 Techniques NOT used by: {', '.join(exclude)} (complement)")
        elif query_type == "techniques_by_mixed_entities":
            # Format mixed entities (software + groups)
            include_entities = results.get("include_entities", [])
            exclude_entities = results.get("exclude_entities", [])
            include_strs = [
                f"{e['name']} ({e['type']})" for e in include_entities
            ]
            exclude_strs = [
                f"{e['name']} ({e['type']})" for e in exclude_entities
            ]
            op_symbol = "∩" if operation == "intersection" else "∪"

            print(f"\n📊 Techniques used by: {', '.join(include_strs)} ({op_symbol} {operation})")
            if exclude_strs:
                print(f"   But not by: {', '.join(exclude_strs)}")
        else:
            include = ", ".join(results.get("include_groups", []))
            exclude = results.get("exclude_groups", [])
            op_symbol = "∩" if operation == "intersection" else "∪"

            print(f"\n📊 Techniques used by: {include} ({op_symbol} {operation})")
            if exclude:
                print(f"   But not by: {', '.join(exclude)}")

        if results.get("tactic_filter"):
            print(f"   Filtered by tactic: {results['tactic_filter']}")

        print(f"\n   Found {results['count']} techniques:\n")

        # Group techniques hierarchically for display
        techniques = results.get("techniques", [])
        hierarchy: dict[str, list[dict[str, Any]]] = {}
        standalone: list[dict[str, Any]] = []

        for tech in techniques:
            if tech.get("is_subtechnique") and tech.get("parent_id"):
                parent_id = tech["parent_id"]
                if parent_id not in hierarchy:
                    hierarchy[parent_id] = []
                hierarchy[parent_id].append(tech)
            else:
                standalone.append(tech)
                if tech["id"] not in hierarchy:
                    hierarchy[tech["id"]] = []

        # Display hierarchically
        for tech in standalone:
            tactics_str = ", ".join(tech.get("tactics", []))
            print(f"   {tech['id']:12} {tech['name']}")
            if verbose:
                print(f"                Tactics: {tactics_str}")
            # Show sub-techniques under this parent
            for subtech in hierarchy.get(tech["id"], []):
                sub_suffix = subtech["id"].split(".")[-1]
                print(f"     .{sub_suffix:9} {subtech['name']}")
                if verbose:
                    sub_tactics = ", ".join(subtech.get("tactics", []))
                    print(f"                Tactics: {sub_tactics}")

        # Show orphan sub-techniques (parent not in result set)
        shown_parents = {t["id"] for t in standalone}
        for parent_id, subtechs in hierarchy.items():
            if parent_id not in shown_parents and subtechs:
                print(f"   ({parent_id})        (parent not in results)")
                for subtech in subtechs:
                    sub_suffix = subtech["id"].split(".")[-1]
                    print(f"     .{sub_suffix:9} {subtech['name']}")

        # Show by-tactic summary
        by_tactic = results.get("by_tactic", {})
        if by_tactic:
            print("\n   By Tactic:")
            for tactic_name, techs in sorted(by_tactic.items()):
                print(f"      {tactic_name}: {len(techs)} techniques")

    elif query_type == "groups_using_technique":
        tech = results.get("technique", {})
        print(f"\n📊 Groups using {tech.get('id', '?')}: {tech.get('name', '?')}")
        print(f"\n   Found {results['count']} groups:\n")
        for group in results.get("groups", []):
            print(f"   • {group}")

    elif query_type == "compare_groups":
        g1 = results.get("group1", "?")
        g2 = results.get("group2", "?")
        print(f"\n📊 Comparison: {g1} vs {g2}")
        print(f"\n   {g1}: {results.get('group1_total', 0)} techniques")
        print(f"   {g2}: {results.get('group2_total', 0)} techniques")
        print(f"   Shared: {results.get('shared_count', 0)} techniques")
        print(f"   Jaccard Similarity: {results.get('jaccard_similarity', 0):.1%}")

        if verbose:
            print("\n   Shared techniques:")
            for tech in results.get("shared", [])[:10]:
                print(f"      {tech['id']:12} {tech['name']}")
            if results.get("shared_count", 0) > 10:
                print(f"      ... and {results['shared_count'] - 10} more")

            print(f"\n   Unique to {g1}:")
            for tech in results.get("unique_to_first", [])[:5]:
                print(f"      {tech['id']:12} {tech['name']}")
            if results.get("unique_to_first_count", 0) > 5:
                print(f"      ... and {results['unique_to_first_count'] - 5} more")

            print(f"\n   Unique to {g2}:")
            for tech in results.get("unique_to_second", [])[:5]:
                print(f"      {tech['id']:12} {tech['name']}")
            if results.get("unique_to_second_count", 0) > 5:
                print(f"      ... and {results['unique_to_second_count'] - 5} more")

    elif query_type == "group_similarity":
        g1 = results.get("group1", "?")
        g2 = results.get("group2", "?")
        print(f"\n📊 Similarity: {g1} vs {g2}")
        print(f"\n   {g1}: {results.get('group1_technique_count', 0)} techniques")
        print(f"   {g2}: {results.get('group2_technique_count', 0)} techniques")
        print(f"   Shared: {results.get('shared_count', 0)} techniques")
        print("\n   Similarity Metrics:")
        print(f"      Jaccard:  {results.get('jaccard', 0):.1%}  (|A∩B|/|A∪B|)")
        print(f"      Overlap:  {results.get('overlap', 0):.1%}  (|A∩B|/min(|A|,|B|))")
        print(f"      Cosine:   {results.get('cosine', 0):.1%}  (dot/magnitudes)")

        if verbose:
            shared = results.get("shared_techniques", [])
            if shared:
                print("\n   Shared techniques:")
                for tid in shared[:10]:
                    print(f"      {tid}")
                if len(shared) > 10:
                    print(f"      ... and {len(shared) - 10} more")

    elif query_type == "similar_groups":
        group = results.get("group", "?")
        metric = results.get("metric", "jaccard")
        threshold = results.get("threshold", 0.0)
        print(f"\n📊 Groups similar to {group}")
        print(f"   ({results.get('technique_count', 0)} techniques)")
        print(f"   Metric: {metric}, Threshold: {threshold:.0%}")
        print(f"\n   Found {results['count']} similar groups:\n")

        for sg in results.get("similar_groups", []):
            sim = sg.get("similarity", 0)
            shared = sg.get("shared_count", 0)
            total = sg.get("technique_count", 0)
            print(f"   {sim:.1%}  {sg['group']:30} ({shared}/{total} shared)")

    elif query_type == "tactics_by_groups":
        groups = results.get("groups", [])
        operation = results.get("operation", "union")
        op_symbol = "∩" if operation == "intersection" else "∪"

        print(f"\n📊 Tactics used by: {', '.join(groups)} ({op_symbol} {operation})")
        print(f"\n   Found {results['count']} tactics:\n")

        for tactic in results.get("tactics", []):
            print(f"   {tactic['id']:8} {tactic['name']}")

    elif query_type == "tactics_not_used_by":
        groups = results.get("groups", [])

        print(f"\n📊 Tactics NOT used by: {', '.join(groups)} (complement)")
        print(f"\n   Found {results['count']} tactics:\n")

        for tactic in results.get("tactics", []):
            print(f"   {tactic['id']:8} {tactic['name']}")

    elif query_type == "subtechniques_of":
        parent = results.get("parent", {})
        print(f"\n📊 Sub-techniques of {parent.get('id', '?')}: {parent.get('name', '?')}")
        print(f"\n   Found {results['count']} sub-techniques:\n")
        for tech in results.get("subtechniques", []):
            print(f"   {tech['id']:12} {tech['name']}")

    elif query_type == "parent_of":
        subtech = results.get("subtechnique", {})
        parent = results.get("parent", {})
        print(f"\n📊 Parent of {subtech.get('id', '?')}: {subtech.get('name', '?')}")
        if parent:
            print(f"\n   Parent: {parent['id']:12} {parent['name']}")
        else:
            print("\n   No parent found")

    elif query_type == "group_info":
        name = results.get("name", "?")
        group_id = results.get("id", "?")
        resolved_from = results.get("resolved_from")

        if resolved_from:
            print(f'\n📊 "{resolved_from}" is an alias for: {name} ({group_id})')
        else:
            print(f"\n📊 Group: {name} ({group_id})")

        aliases = results.get("aliases", [])
        if aliases:
            print(f"\n   Aliases: {', '.join(aliases)}")

        print(f"   Techniques: {results.get('technique_count', 0)}")

        if verbose:
            description = results.get("description", "")
            if description:
                # Truncate long descriptions
                if len(description) > 300:
                    description = description[:300] + "..."
                print(f"\n   Description:\n   {description}")

    elif query_type == "software_by_group":
        group = results.get("group", "?")
        print(f"\n📊 Software used by {group}")
        print(f"\n   Found {results['count']} software:\n")
        for sw in results.get("software", []):
            sw_type = sw.get("type", "?")
            tech_count = sw.get("technique_count", 0)
            print(f"   {sw['id']:8} {sw['name']:30} ({sw_type}, {tech_count} techniques)")

    elif query_type == "groups_using_software":
        sw_name = results.get("software", "?")
        sw_type = results.get("software_type", "?")
        print(f"\n📊 Groups using {sw_name} ({sw_type})")
        print(f"\n   Found {results['count']} groups:\n")
        for group in results.get("groups", []):
            print(f"   • {group}")

    elif query_type == "techniques_by_software":
        sw_name = results.get("software", "?")
        sw_type = results.get("software_type", "?")
        print(f"\n📊 Techniques used by {sw_name} ({sw_type})")
        print(f"\n   Found {results['count']} techniques:\n")
        for tech in results.get("techniques", []):
            print(f"   {tech['id']:12} {tech['name']}")
            if verbose:
                tactics_str = ", ".join(tech.get("tactics", []))
                print(f"                Tactics: {tactics_str}")

        # Show by-tactic summary
        by_tactic = results.get("by_tactic", {})
        if by_tactic:
            print("\n   By Tactic:")
            for tactic_name, techs in sorted(by_tactic.items()):
                print(f"      {tactic_name}: {len(techs)} techniques")

    elif query_type == "software_info":
        name = results.get("name", "?")
        sw_id = results.get("id", "?")
        sw_type = results.get("type", "?")
        resolved_from = results.get("resolved_from")

        if resolved_from:
            print(f'\n📊 "{resolved_from}" is an alias for: {name} ({sw_id})')
        else:
            print(f"\n📊 Software: {name} ({sw_id})")

        print(f"   Type: {sw_type}")

        aliases = results.get("aliases", [])
        if aliases:
            print(f"   Aliases: {', '.join(aliases)}")

        platforms = results.get("platforms", [])
        if platforms:
            print(f"   Platforms: {', '.join(platforms)}")

        print(f"   Techniques: {results.get('technique_count', 0)}")

        groups = results.get("groups", [])
        if groups:
            print(f"   Used by: {', '.join(groups[:10])}")
            if len(groups) > 10:
                print(f"            ... and {len(groups) - 10} more groups")

        if verbose:
            description = results.get("description", "")
            if description:
                if len(description) > 300:
                    description = description[:300] + "..."
                print(f"\n   Description:\n   {description}")

    elif query_type == "software_using_technique":
        tech = results.get("technique", {})
        print(f"\n📊 Software using {tech.get('id', '?')}: {tech.get('name', '?')}")
        print(f"\n   Found {results['count']} software:\n")
        for sw in results.get("software", []):
            sw_type = sw.get("type", "?")
            print(f"   {sw['id']:8} {sw['name']:30} ({sw_type})")

    elif query_type == "mitigations_for_technique":
        tech = results.get("technique", {})
        print(f"\n📊 Mitigations for {tech.get('id', '?')}: {tech.get('name', '?')}")
        print(f"\n   Found {results['count']} mitigations:\n")
        for mit in results.get("mitigations", []):
            print(f"   {mit['id']:8} {mit['name']}")

    elif query_type == "techniques_mitigated_by":
        mit = results.get("mitigation", {})
        print(f"\n📊 Techniques mitigated by {mit.get('id', '?')}: {mit.get('name', '?')}")
        print(f"\n   Found {results['count']} techniques:\n")
        for tech in results.get("techniques", []):
            print(f"   {tech['id']:12} {tech['name']}")
            if verbose:
                tactics_str = ", ".join(tech.get("tactics", []))
                print(f"                Tactics: {tactics_str}")

        # Show by-tactic summary
        by_tactic = results.get("by_tactic", {})
        if by_tactic:
            print("\n   By Tactic:")
            for tactic_name, techs in sorted(by_tactic.items()):
                print(f"      {tactic_name}: {len(techs)} techniques")

    elif query_type == "mitigation_info":
        name = results.get("name", "?")
        mit_id = results.get("id", "?")
        print(f"\n📊 Mitigation: {name} ({mit_id})")
        print(f"   Techniques: {results.get('technique_count', 0)}")

        if verbose:
            description = results.get("description", "")
            if description:
                if len(description) > 300:
                    description = description[:300] + "..."
                print(f"\n   Description:\n   {description}")

    elif query_type == "list_data_sources":
        print(f"\n📊 ATT&CK Data Sources ({results['count']} total):\n")
        for ds in results.get("data_sources", []):
            platforms = ", ".join(ds.get("platforms", []))
            print(f"   {ds['id']:8} {ds['name']:30} ({platforms or 'all platforms'})")

    elif query_type == "data_source_info":
        name = results.get("name", "?")
        ds_id = results.get("id", "?")
        print(f"\n📊 Data Source: {name} ({ds_id})")

        platforms = results.get("platforms", [])
        if platforms:
            print(f"   Platforms: {', '.join(platforms)}")

        layers = results.get("collection_layers", [])
        if layers:
            print(f"   Collection Layers: {', '.join(layers)}")

        if verbose:
            description = results.get("description", "")
            if description:
                if len(description) > 300:
                    description = description[:300] + "..."
                print(f"\n   Description:\n   {description}")

    elif query_type == "list_data_components":
        print(f"\n📊 ATT&CK Data Components ({results['count']} total):\n")
        for dc in results.get("data_components", []):
            tech_count = dc.get("technique_count", 0)
            print(f"   {dc['id']:8} {dc['name']:40} ({tech_count} techniques)")

    elif query_type == "data_component_info":
        name = results.get("name", "?")
        dc_id = results.get("id", "?")
        print(f"\n📊 Data Component: {name} ({dc_id})")
        print(f"   Techniques: {results.get('technique_count', 0)}")

        log_sources = results.get("log_sources", [])
        if log_sources:
            print(f"   Log Sources: {len(log_sources)}")
            if verbose:
                print("\n   Log Source Examples:")
                for ls in log_sources[:10]:
                    print(f"      {ls.get('name', '?')}: {ls.get('channel', '')}")
                if len(log_sources) > 10:
                    print(f"      ... and {len(log_sources) - 10} more")

        if verbose:
            description = results.get("description", "")
            if description:
                if len(description) > 300:
                    description = description[:300] + "..."
                print(f"\n   Description:\n   {description}")

    elif query_type == "techniques_detectable_by":
        dc = results.get("data_component", {})
        print(f"\n📊 Techniques detectable by {dc.get('id', '?')}: {dc.get('name', '?')}")
        print(f"\n   Found {results['count']} techniques:\n")
        for tech in results.get("techniques", []):
            print(f"   {tech['id']:12} {tech['name']}")
            if verbose:
                tactics_str = ", ".join(tech.get("tactics", []))
                print(f"                Tactics: {tactics_str}")

        # Show by-tactic summary
        by_tactic = results.get("by_tactic", {})
        if by_tactic:
            print("\n   By Tactic:")
            for tactic_name, techs in sorted(by_tactic.items()):
                print(f"      {tactic_name}: {len(techs)} techniques")

    elif query_type == "list_campaigns":
        print(f"\n📊 ATT&CK Campaigns ({results['count']} total):\n")
        for camp in results.get("campaigns", []):
            first = camp.get("first_seen", "?")[:10] if camp.get("first_seen") else "?"
            last = camp.get("last_seen", "?")[:10] if camp.get("last_seen") else "?"
            tech_count = camp.get("technique_count", 0)
            print(
                f"   {camp['id']:8} {camp['name']:30} ({first} - {last}, {tech_count} techniques)"
            )

    elif query_type == "campaigns_by_group":
        group = results.get("group", "?")
        print(f"\n📊 Campaigns attributed to {group}")
        print(f"\n   Found {results['count']} campaigns:\n")
        for camp in results.get("campaigns", []):
            first = camp.get("first_seen", "?")[:10] if camp.get("first_seen") else "?"
            last = camp.get("last_seen", "?")[:10] if camp.get("last_seen") else "?"
            tech_count = camp.get("technique_count", 0)
            print(
                f"   {camp['id']:8} {camp['name']:30} ({first} - {last}, {tech_count} techniques)"
            )

    elif query_type == "techniques_in_campaign":
        campaign = results.get("campaign", {})
        first = campaign.get("first_seen", "?")[:10] if campaign.get("first_seen") else "?"
        last = campaign.get("last_seen", "?")[:10] if campaign.get("last_seen") else "?"
        print(f"\n📊 Techniques in {campaign.get('id', '?')}: {campaign.get('name', '?')}")
        print(f"   Timeline: {first} - {last}")
        print(f"\n   Found {results['count']} techniques:\n")
        for tech in results.get("techniques", []):
            print(f"   {tech['id']:12} {tech['name']}")
            if verbose:
                tactics_str = ", ".join(tech.get("tactics", []))
                print(f"                Tactics: {tactics_str}")

        # Show by-tactic summary
        by_tactic = results.get("by_tactic", {})
        if by_tactic:
            print("\n   By Tactic:")
            for tactic_name, techs in sorted(by_tactic.items()):
                print(f"      {tactic_name}: {len(techs)} techniques")

    elif query_type == "campaign_info":
        name = results.get("name", "?")
        camp_id = results.get("id", "?")
        print(f"\n📊 Campaign: {name} ({camp_id})")

        first = results.get("first_seen", "?")[:10] if results.get("first_seen") else "?"
        last = results.get("last_seen", "?")[:10] if results.get("last_seen") else "?"
        print(f"   Timeline: {first} - {last}")

        aliases = results.get("aliases", [])
        if aliases:
            print(f"   Aliases: {', '.join(aliases)}")

        print(f"   Techniques: {results.get('technique_count', 0)}")
        print(f"   Software: {results.get('software_count', 0)}")

        groups = results.get("groups", [])
        if groups:
            print(f"   Attributed to: {', '.join(groups)}")

        if verbose:
            description = results.get("description", "")
            if description:
                if len(description) > 300:
                    description = description[:300] + "..."
                print(f"\n   Description:\n   {description}")

    elif query_type == "campaigns_in_year":
        year = results.get("year", "?")
        print(f"\n📊 Campaigns active in {year}")
        print(f"\n   Found {results['count']} campaigns:\n")
        for camp in results.get("campaigns", []):
            first = camp.get("first_seen", "?")[:10] if camp.get("first_seen") else "?"
            last = camp.get("last_seen", "?")[:10] if camp.get("last_seen") else "?"
            tech_count = camp.get("technique_count", 0)
            print(
                f"   {camp['id']:8} {camp['name']:30} ({first} - {last}, {tech_count} techniques)"
            )

    elif query_type == "campaigns_in_range":
        start_year = results.get("start_year", "?")
        end_year = results.get("end_year", "?")
        print(f"\n📊 Campaigns active between {start_year} and {end_year}")
        print(f"\n   Found {results['count']} campaigns:\n")
        for camp in results.get("campaigns", []):
            first = camp.get("first_seen", "?")[:10] if camp.get("first_seen") else "?"
            last = camp.get("last_seen", "?")[:10] if camp.get("last_seen") else "?"
            tech_count = camp.get("technique_count", 0)
            print(
                f"   {camp['id']:8} {camp['name']:30} ({first} - {last}, {tech_count} techniques)"
            )

    elif query_type == "techniques_in_year":
        year = results.get("year", "?")
        campaign_count = results.get("campaign_count", 0)
        print(f"\n📊 Techniques used in campaigns during {year}")
        print(f"   ({campaign_count} campaigns)")
        print(f"\n   Found {results['count']} techniques:\n")
        for tech in results.get("techniques", []):
            print(f"   {tech['id']:12} {tech['name']}")
            if verbose:
                tactics_str = ", ".join(tech.get("tactics", []))
                print(f"                Tactics: {tactics_str}")

        # Show by-tactic summary
        by_tactic = results.get("by_tactic", {})
        if by_tactic:
            print("\n   By Tactic:")
            for tactic_name, techs in sorted(by_tactic.items()):
                print(f"      {tactic_name}: {len(techs)} techniques")

    elif query_type == "techniques_in_range":
        start_year = results.get("start_year", "?")
        end_year = results.get("end_year", "?")
        campaign_count = results.get("campaign_count", 0)
        print(f"\n📊 Techniques used in campaigns between {start_year} and {end_year}")
        print(f"   ({campaign_count} campaigns)")
        print(f"\n   Found {results['count']} techniques:\n")
        for tech in results.get("techniques", []):
            print(f"   {tech['id']:12} {tech['name']}")
            if verbose:
                tactics_str = ", ".join(tech.get("tactics", []))
                print(f"                Tactics: {tactics_str}")

        # Show by-tactic summary
        by_tactic = results.get("by_tactic", {})
        if by_tactic:
            print("\n   By Tactic:")
            for tactic_name, techs in sorted(by_tactic.items()):
                print(f"      {tactic_name}: {len(techs)} techniques")

    print()


def interactive_mode(parser: NLQueryParser) -> None:
    """Run interactive query mode."""
    version_str = parser.engine.store.version or "latest"
    matrix_str = parser.engine.store.matrix.display_name
    print("\n" + "=" * 60)
    print("MITRE ATT&CK Query Tool - Interactive Mode")
    print(f"Matrix: {matrix_str} | Version: {version_str}")
    print("=" * 60)
    print("\nExample queries:")
    print("  • techniques used by APT28 or APT29      (union)")
    print("  • techniques used by APT28 and APT29    (intersection)")
    print("  • techniques used by APT28 or APT29 but not APT33")
    print("  • techniques used by APT28 for initial access")
    print("  • groups using T1566")
    print("  • compare APT28 and APT29")
    print("  • techniques NOT used by APT28")
    print("  • sub-techniques of T1566")
    print("  • parent of T1566.001")
    print("  • who is Fancy Bear")
    print("  • aliases of APT28")
    print("  • software used by APT28")
    print("  • groups using Mimikatz")
    print("  • techniques for Cobalt Strike")
    print("  • mitigations for T1566")
    print("  • techniques detectable by Process Creation")
    print("  • campaigns by APT28")
    print("  • techniques in C0027")
    print("  • campaigns in 2023")
    print("  • techniques used in 2023")
    print("  • groups similar to APT28")
    print("  • similarity APT28 APT29")
    print(
        "\nCommands: 'help', 'groups', 'tactics', 'software', 'mitigations', 'campaigns', 'data sources', 'data components', 'export', 'version', 'quit'\n"
    )

    last_results: dict[str, Any] | None = None

    while True:
        try:
            query = input("query> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not query:
            continue

        if query.lower() in ("quit", "exit", "q"):
            print("Goodbye!")
            break

        if query.lower() == "help":
            _print_help()
            continue

        if query.lower() == "version":
            _print_version(parser)
            continue

        if query.lower() == "versions":
            _print_versions()
            continue

        if query.lower() == "groups":
            _print_groups(parser)
            continue

        if query.lower() == "tactics":
            _print_tactics(parser)
            continue

        if query.lower() == "software":
            _print_software(parser)
            continue

        if query.lower() == "mitigations":
            _print_mitigations(parser)
            continue

        if query.lower() in ("data sources", "datasources"):
            _print_data_sources(parser)
            continue

        if query.lower() in ("data components", "datacomponents"):
            _print_data_components(parser)
            continue

        if query.lower() == "campaigns":
            _print_campaigns(parser)
            continue

        if query.lower().startswith("export"):
            last_results = _handle_export(query, parser, last_results)
            continue

        if query.lower().startswith("heatmap"):
            _handle_heatmap(query, parser)
            continue

        # Check for verbose flag
        verbose = False
        if query.endswith(" -v"):
            verbose = True
            query = query[:-3].strip()

        results = parser.parse_and_execute(query)
        last_results = results
        print_results(results, verbose=verbose)


def _print_help() -> None:
    """Print help information."""
    print("\nSupported query patterns:")
    print("  • techniques used by [GROUP]")
    print("  • techniques used by [GROUP1] or [GROUP2]       (union - ANY group)")
    print("  • techniques used by [GROUP1] and [GROUP2]      (intersection - ALL groups)")
    print("  • techniques used by [GROUP1] or [GROUP2] but not [GROUP3]")
    print("  • techniques used by [GROUP1] and [GROUP2] but not [GROUP3]")
    print("  • techniques used by [GROUP] for [TACTIC]")
    print("  • groups using [TECHNIQUE_ID]")
    print("  • compare [GROUP1] and [GROUP2]")
    print("  • techniques NOT used by [GROUP]")
    print("  • sub-techniques of [TECHNIQUE_ID]")
    print("  • parent of [SUBTECHNIQUE_ID]")
    print("  • who is [GROUP]  /  info [GROUP]")
    print("  • aliases of [GROUP]")
    print("\nSoftware queries:")
    print("  • software used by [GROUP]")
    print("  • groups using [SOFTWARE]")
    print("  • techniques for [SOFTWARE]")
    print("  • software using [TECHNIQUE_ID]")
    print("  • software [NAME]  /  software info [NAME]")
    print("\nMitigation queries:")
    print("  • mitigations for [TECHNIQUE_ID]")
    print("  • how to mitigate [TECHNIQUE_ID]")
    print("  • techniques mitigated by [MITIGATION]")
    print("  • mitigation [NAME]  /  mitigation info [NAME]")
    print("\nData source queries:")
    print("  • data sources               (list all data sources)")
    print("  • data source [NAME]         (data source details)")
    print("  • data components            (list all data components)")
    print("  • data component [NAME]      (data component details)")
    print("  • techniques detectable by [DATA_COMPONENT]")
    print("\nCampaign queries:")
    print("  • campaigns                  (list all campaigns)")
    print("  • campaigns by [GROUP]       (campaigns attributed to group)")
    print("  • techniques in [CAMPAIGN]   (techniques used in campaign)")
    print("  • campaign [ID]              (campaign details)")
    print("\nTimeline queries:")
    print("  • campaigns in [YEAR]        (campaigns active in year)")
    print("  • campaigns between [YEAR1] and [YEAR2]")
    print("  • techniques used in [YEAR]  (techniques from campaigns)")
    print("  • techniques between [YEAR1] and [YEAR2]")
    print("\nSimilarity queries:")
    print("  • similarity [GROUP1] [GROUP2]            (detailed metrics)")
    print("  • groups similar to [GROUP]               (find similar groups)")
    print("  • groups like [GROUP] threshold 0.5       (with minimum score)")
    print("  • groups like [GROUP] limit 5 using cosine")
    print("\nTactics queries:")
    print("  • tactics used by [GROUP]")
    print("  • tactics used by [GROUP1] or [GROUP2]    (union - ANY group)")
    print("  • tactics used by [GROUP1] and [GROUP2]   (intersection - ALL groups)")
    print("  • which tactics does [GROUP] use")
    print("\nSet operations:")
    print("  • 'or'      → Union (techniques used by ANY of the groups)")
    print("  • 'and'     → Intersection (techniques used by ALL groups)")
    print("  • 'but not' → Difference (exclude techniques)")
    print("\nAdd '-v' to any query for verbose output.")
    print("\nCommands:")
    print("  • groups           - List all threat groups")
    print("  • tactics          - List all tactics")
    print("  • software         - List all software/tools")
    print("  • mitigations      - List all mitigations")
    print("  • campaigns        - List all campaigns")
    print("  • data sources     - List all data sources")
    print("  • data components  - List all data components")
    print("  • export [file]    - Export last query to Navigator layer (JSON)")
    print("  • export csv [file] - Export last query to CSV")
    print("  • export md [file]  - Export last query to Markdown")
    print("  • heatmap [file] [group1] [group2] ... - Create overlap heatmap")
    print("  • version          - Show loaded ATT&CK version")
    print("  • versions         - List available ATT&CK versions")
    print()


def _print_version(parser: NLQueryParser) -> None:
    """Print version information."""
    v = parser.engine.store.version or "latest"
    m = parser.engine.store.matrix.display_name
    print(f"\nLoaded ATT&CK Matrix: {m}")
    print(f"Version: {v}")
    print(f"Techniques: {len(parser.engine.store.techniques)}")
    print(f"Groups: {len(parser.engine.store.groups)}")
    print(f"Software: {len(parser.engine.store.software)}")
    print(f"Mitigations: {len(parser.engine.store.mitigations)}")
    print(f"Campaigns: {len(parser.engine.store.campaigns)}")
    print(f"Data Sources: {len(parser.engine.store.data_sources)}")
    print(f"Data Components: {len(parser.engine.store.data_components)}")
    print(f"Tactics: {len(parser.engine.store.tactics)}")
    print("\nTo use a different version: --version X.X")
    print("To use a different matrix: --matrix [enterprise|mobile|ics]")
    print()


def _print_versions() -> None:
    """Print available versions."""
    print("\nAvailable ATT&CK versions:")
    versions = ATTACKDataStore.list_versions()
    for i in range(0, len(versions), 8):
        row = versions[i : i + 8]
        print("  " + "  ".join(f"{v:6}" for v in row))
    print("\nTo use a specific version, restart with: --version X.X")
    print()


def _print_groups(parser: NLQueryParser) -> None:
    """Print all threat groups."""
    print("\nKnown threat groups:")
    for group in sorted(parser.engine.store.groups.values(), key=lambda g: g.name):
        print(f"  {group.id:8} {group.name}")
    print()


def _print_tactics(parser: NLQueryParser) -> None:
    """Print all tactics."""
    print("\nATT&CK Tactics:")
    for tactic in sorted(parser.engine.store.tactics.values(), key=lambda t: t.id):
        print(f"  {tactic.id:8} {tactic.name} ({tactic.shortname})")
    print()


def _print_software(parser: NLQueryParser) -> None:
    """Print all software/tools."""
    software_list = sorted(parser.engine.store.software.values(), key=lambda s: s.name)
    malware = [s for s in software_list if s.software_type == "malware"]
    tools = [s for s in software_list if s.software_type == "tool"]

    print(f"\nATT&CK Software ({len(software_list)} total):")
    print(f"\n  Malware ({len(malware)}):")
    for sw in malware[:20]:
        print(f"    {sw.id:8} {sw.name}")
    if len(malware) > 20:
        print(f"    ... and {len(malware) - 20} more")

    print(f"\n  Tools ({len(tools)}):")
    for sw in tools[:20]:
        print(f"    {sw.id:8} {sw.name}")
    if len(tools) > 20:
        print(f"    ... and {len(tools) - 20} more")
    print()


def _print_mitigations(parser: NLQueryParser) -> None:
    """Print all mitigations."""
    mitigations = sorted(parser.engine.store.mitigations.values(), key=lambda m: m.id)
    print(f"\nATT&CK Mitigations ({len(mitigations)} total):\n")
    for mit in mitigations:
        print(f"  {mit.id:8} {mit.name}")
    print()


def _print_data_sources(parser: NLQueryParser) -> None:
    """Print all data sources."""
    data_sources = sorted(parser.engine.store.data_sources.values(), key=lambda d: d.id)
    print(f"\nATT&CK Data Sources ({len(data_sources)} total):\n")
    for ds in data_sources:
        platforms = ", ".join(ds.platforms) if ds.platforms else "all platforms"
        print(f"  {ds.id:8} {ds.name:30} ({platforms})")
    print()


def _print_data_components(parser: NLQueryParser) -> None:
    """Print all data components."""
    data_components = sorted(parser.engine.store.data_components.values(), key=lambda d: d.id)
    print(f"\nATT&CK Data Components ({len(data_components)} total):\n")
    for dc in data_components[:30]:
        tech_count = len(dc.techniques)
        print(f"  {dc.id:8} {dc.name:40} ({tech_count} techniques)")
    if len(data_components) > 30:
        print(f"  ... and {len(data_components) - 30} more")
    print()


def _print_campaigns(parser: NLQueryParser) -> None:
    """Print all campaigns."""
    campaigns = sorted(parser.engine.store.campaigns.values(), key=lambda c: c.id)
    print(f"\nATT&CK Campaigns ({len(campaigns)} total):\n")
    for camp in campaigns[:30]:
        first = camp.first_seen[:10] if camp.first_seen else "?"
        last = camp.last_seen[:10] if camp.last_seen else "?"
        tech_count = len(camp.techniques)
        print(f"  {camp.id:8} {camp.name:30} ({first} - {last}, {tech_count} techniques)")
    if len(campaigns) > 30:
        print(f"  ... and {len(campaigns) - 30} more")
    print()


def _handle_export(
    query: str,
    parser: NLQueryParser,
    last_results: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Handle export command.

    Supports:
    - export [filename]           - Export to Navigator layer (JSON)
    - export csv [filename]       - Export to CSV
    - export md [filename]        - Export to Markdown
    """
    parts = query.split()
    # Determine format and filename
    export_format = "json"  # default is Navigator layer
    filename = None

    if len(parts) >= 2:
        if parts[1].lower() == "csv":
            export_format = "csv"
            filename = parts[2] if len(parts) > 2 else None
        elif parts[1].lower() == "md":
            export_format = "md"
            filename = parts[2] if len(parts) > 2 else None
        else:
            filename = parts[1]

    # Set default filenames
    if not filename:
        if export_format == "csv":
            filename = "attack_results.csv"
        elif export_format == "md":
            filename = "attack_results.md"
        else:
            filename = "attack_layer.json"

    # Ensure correct extension
    if export_format == "csv" and not filename.endswith(".csv"):
        filename += ".csv"
    elif export_format == "md" and not filename.endswith(".md"):
        filename += ".md"
    elif export_format == "json" and not filename.endswith(".json"):
        filename += ".json"

    if not last_results or "techniques" not in last_results:
        print("\n⚠️  No technique query results to export. Run a techniques query first.\n")
        return last_results

    technique_ids = {t["id"] for t in last_results["techniques"]}

    if export_format == "csv":
        content = parser.engine.export_csv(technique_ids)
        with open(filename, "w") as f:
            f.write(content)
        print(f"\n✅ Exported CSV to: {filename}")
        print(f"   {len(technique_ids)} techniques exported.\n")
    elif export_format == "md":
        content = parser.engine.export_markdown(technique_ids)
        with open(filename, "w") as f:
            f.write(content)
        print(f"\n✅ Exported Markdown to: {filename}")
        print(f"   {len(technique_ids)} techniques exported.\n")
    else:
        layer = parser.engine.export_navigator_layer(
            technique_ids,
            name=f"Query Results ({len(technique_ids)} techniques)",
            description=(
                f"Include: {last_results.get('include_groups', [])} "
                f"Exclude: {last_results.get('exclude_groups', [])}"
            ),
        )
        with open(filename, "w") as f:
            json.dump(layer, f, indent=2)
        print(f"\n✅ Exported Navigator layer to: {filename}")
        print("   Open https://mitre-attack.github.io/attack-navigator/ and import this file.\n")

    return last_results


def _handle_heatmap(query: str, parser: NLQueryParser) -> None:
    """Handle heatmap command."""
    parts = query.split()
    if len(parts) < 3:
        print("\nUsage: heatmap [filename] [group1] [group2] ...")
        print("Example: heatmap overlap.json APT28 APT29 APT33\n")
        return

    # Determine filename vs group names
    filename = parts[1] if not parts[1].upper().startswith(("APT", "G0", "FIN")) else "heatmap.json"
    start_idx = 1 if filename == "heatmap.json" else 2
    group_names = parts[start_idx:]

    if not filename.endswith(".json"):
        filename += ".json"

    layer = parser.engine.export_heatmap_layer(
        group_names,
        name=f"Overlap Heatmap: {', '.join(group_names)}",
    )
    with open(filename, "w") as f:
        json.dump(layer, f, indent=2)
    print(f"\n✅ Exported heatmap layer to: {filename}")
    print("   Open https://mitre-attack.github.io/attack-navigator/ and import this file.\n")


def main() -> None:
    """Main entry point."""
    arg_parser = argparse.ArgumentParser(
        description="MITRE ATT&CK Query Tool - Programmatic queries on threat actor techniques",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s "techniques used by APT28 or APT29"              # union
  %(prog)s "techniques used by APT28 and APT29"             # intersection
  %(prog)s "techniques used by APT28 or APT29 but not APT33"
  %(prog)s "techniques NOT used by APT28"                   # complement
  %(prog)s "groups using T1566" -v
  %(prog)s "compare APT28 and APT29" --json
  %(prog)s "who is Fancy Bear"                              # alias resolution
  %(prog)s --version 12.0 "techniques used by APT28"
  %(prog)s --matrix mobile "techniques used by APT28"       # Mobile ATT&CK
  %(prog)s --matrix ics "techniques used by ALLANITE"       # ICS ATT&CK
  %(prog)s --format csv "techniques used by APT28"          # CSV output
  %(prog)s --format md "techniques used by APT28"           # Markdown output
  %(prog)s --format layer "techniques used by APT28"        # Navigator layer JSON
  %(prog)s --list-versions
  %(prog)s --smart "what attacks does fancy bear do"        # LLM-assisted parsing
  %(prog)s --smart --model ollama:mistral "show APT28 tools"

Set operations: 'or' = union (ANY), 'and' = intersection (ALL), 'but not' = difference
Matrices: enterprise (default), mobile, ics
        """,
    )
    arg_parser.add_argument(
        "query",
        nargs="*",
        help="Query to execute (interactive mode if omitted)",
    )
    arg_parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Verbose output",
    )
    arg_parser.add_argument(
        "--json",
        action="store_true",
        help="Output results as JSON (shorthand for --format json)",
    )
    arg_parser.add_argument(
        "--format",
        dest="output_format",
        choices=["json", "csv", "md", "layer"],
        help="Output format: json, csv, md (markdown), or layer (Navigator)",
    )
    arg_parser.add_argument(
        "--refresh",
        action="store_true",
        help="Force refresh of cached data",
    )
    arg_parser.add_argument(
        "--data-file",
        type=Path,
        help="Path to local ATT&CK STIX JSON file",
    )
    arg_parser.add_argument(
        "--version",
        dest="attack_version",
        metavar="VERSION",
        help="ATT&CK version to use (e.g., 12.0, 15.1, 18.0)",
    )
    arg_parser.add_argument(
        "--list-versions",
        action="store_true",
        help="List known ATT&CK versions and exit",
    )
    arg_parser.add_argument(
        "--matrix",
        dest="matrix",
        choices=["enterprise", "mobile", "ics"],
        default="enterprise",
        help="ATT&CK matrix to use (default: enterprise)",
    )
    arg_parser.add_argument(
        "--smart",
        action="store_true",
        help="Enable LLM-assisted query parsing for ambiguous queries",
    )
    arg_parser.add_argument(
        "--model",
        dest="model",
        metavar="PROVIDER:MODEL",
        help="Completion model (e.g., ollama:llama3.2, openai:gpt-4o-mini)",
    )

    args = arg_parser.parse_args()

    # Handle --list-versions
    if args.list_versions:
        print("\nKnown ATT&CK versions:")
        print("-" * 40)
        versions = ATTACKDataStore.list_versions()
        for i in range(0, len(versions), 8):
            row = versions[i : i + 8]
            print("  " + "  ".join(f"{v:6}" for v in row))
        print('\nUsage: attack-query --version 12.0 "your query"')
        print("See: https://github.com/mitre-attack/attack-stix-data/releases")
        return

    # Initialize data store
    # Enable quiet mode when using any structured output format
    quiet = args.json or args.output_format is not None
    store = ATTACKDataStore(
        data_file=args.data_file,
        version=args.attack_version,
        matrix=args.matrix,
        quiet=quiet,
    )
    store.load(force_refresh=args.refresh)

    # Initialize query engine and NL parser
    engine = ATTACKQueryEngine(store)
    nl_parser = NLQueryParser(engine)

    # Determine output format
    output_format = args.output_format or ("json" if args.json else None)

    # Execute query or enter interactive mode
    if args.query:
        query = " ".join(args.query)

        # Smart mode: use LLM to normalize ambiguous queries
        if args.smart:
            try:
                from attack_query.completion import get_completion_model
                from attack_query.normalizer import QueryNormalizer

                model = get_completion_model(args.model)
                normalizer = QueryNormalizer(model, store)

                if not quiet:
                    print(f"🤖 Smart mode ({model.model_name})")
                    print(f"   Original: {query}")

                normalized = normalizer.normalize(query)

                if not quiet:
                    print(f"   Normalized: {normalized}\n")

                query = normalized
            except Exception as e:
                if not quiet:
                    print(f"⚠️  Smart mode failed: {e}")
                    print("   Falling back to standard parsing.\n")

        results = nl_parser.parse_and_execute(query)

        if output_format == "json":
            print(json.dumps(results, indent=2, default=list))
        elif output_format in ("csv", "md", "layer"):
            # Extract technique IDs from results
            techniques = results.get("techniques", [])
            if not techniques and "error" in results:
                print(f"Error: {results['error']}", file=sys.stderr)
            elif not techniques:
                print("No techniques in results to export.", file=sys.stderr)
            else:
                technique_ids = {t["id"] for t in techniques}
                if output_format == "csv":
                    print(engine.export_csv(technique_ids, include_description=args.verbose))
                elif output_format == "md":
                    print(engine.export_markdown(technique_ids))
                else:  # layer
                    # Generate layer name from query
                    layer_name = f"ATT&CK Query: {query[:50]}" if len(query) > 50 else f"ATT&CK Query: {query}"
                    layer = engine.export_navigator_layer(
                        technique_ids,
                        name=layer_name,
                        description=f"Query: {query}",
                    )
                    print(json.dumps(layer, indent=2))
        else:
            print_results(results, verbose=args.verbose)
    else:
        interactive_mode(nl_parser)


if __name__ == "__main__":
    main()
