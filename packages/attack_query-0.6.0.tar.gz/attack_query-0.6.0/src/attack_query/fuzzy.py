"""Fuzzy matching utilities for query suggestions."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from attack_query.store import ATTACKDataStore

# Lazy import thefuzz
_fuzz: Any = None
_process: Any = None


def _get_fuzz() -> tuple[Any, Any]:
    """Lazy import thefuzz modules."""
    global _fuzz, _process
    if _fuzz is None:
        try:
            from thefuzz import fuzz, process

            _fuzz = fuzz
            _process = process
        except ImportError:
            # Graceful degradation - return None modules
            return None, None
    return _fuzz, _process


def fuzzy_available() -> bool:
    """Check if fuzzy matching is available."""
    fuzz, _ = _get_fuzz()
    return fuzz is not None


def suggest_group(query: str, store: ATTACKDataStore, threshold: int = 70) -> str | None:
    """
    Suggest a group name based on fuzzy matching.

    Args:
        query: User's input that didn't match a group
        store: ATTACKDataStore with loaded groups
        threshold: Minimum similarity score (0-100)

    Returns:
        Suggested group name or None if no good match
    """
    fuzz, process = _get_fuzz()
    if process is None:
        return None

    # Build list of all group names and aliases
    candidates: list[str] = []
    for group in store.groups.values():
        candidates.append(group.name)
        candidates.extend(group.aliases)

    if not candidates:
        return None

    # Find best match
    result = process.extractOne(query, candidates, scorer=fuzz.ratio)
    if result and result[1] >= threshold:
        return str(result[0])

    return None


def suggest_technique(query: str, store: ATTACKDataStore, threshold: int = 70) -> str | None:
    """
    Suggest a technique ID or name based on fuzzy matching.

    Args:
        query: User's input that didn't match a technique
        store: ATTACKDataStore with loaded techniques
        threshold: Minimum similarity score (0-100)

    Returns:
        Suggested technique ID or None if no good match
    """
    fuzz, process = _get_fuzz()
    if process is None:
        return None

    # Build mapping of technique names/IDs to IDs
    candidates: dict[str, str] = {}
    for tech in store.techniques.values():
        candidates[tech.id] = tech.id
        candidates[tech.name.lower()] = tech.id

    if not candidates:
        return None

    # Find best match
    result = process.extractOne(query.lower(), list(candidates.keys()), scorer=fuzz.ratio)
    if result and result[1] >= threshold:
        return candidates[result[0]]

    return None


def suggest_software(query: str, store: ATTACKDataStore, threshold: int = 70) -> str | None:
    """
    Suggest a software name based on fuzzy matching.

    Args:
        query: User's input that didn't match software
        store: ATTACKDataStore with loaded software
        threshold: Minimum similarity score (0-100)

    Returns:
        Suggested software name or None if no good match
    """
    fuzz, process = _get_fuzz()
    if process is None:
        return None

    # Build list of all software names and aliases
    candidates: list[str] = []
    for sw in store.software.values():
        candidates.append(sw.name)
        candidates.extend(sw.aliases)

    if not candidates:
        return None

    # Find best match
    result = process.extractOne(query, candidates, scorer=fuzz.ratio)
    if result and result[1] >= threshold:
        return str(result[0])

    return None


def suggest_query_pattern(query: str, threshold: int = 60) -> str | None:
    """
    Suggest a canonical query pattern based on fuzzy matching.

    Args:
        query: User's query that didn't match any pattern
        threshold: Minimum similarity score (0-100)

    Returns:
        Suggested query pattern or None if no good match
    """
    fuzz, process = _get_fuzz()
    if process is None:
        return None

    # Canonical query patterns
    patterns = [
        "techniques used by {GROUP}",
        "techniques used by {GROUP1} or {GROUP2}",
        "techniques used by {GROUP1} and {GROUP2}",
        "techniques NOT used by {GROUP}",
        "groups using {TECHNIQUE}",
        "compare {GROUP1} and {GROUP2}",
        "groups similar to {GROUP}",
        "similarity {GROUP1} {GROUP2}",
        "software used by {GROUP}",
        "groups using {SOFTWARE}",
        "techniques for {SOFTWARE}",
        "mitigations for {TECHNIQUE}",
        "techniques mitigated by {MITIGATION}",
        "campaigns by {GROUP}",
        "techniques in {CAMPAIGN}",
        "sub-techniques of {TECHNIQUE}",
        "parent of {TECHNIQUE}",
        "who is {GROUP}",
        "aliases of {GROUP}",
    ]

    # Find best match
    result = process.extractOne(
        query.lower(), [p.lower() for p in patterns], scorer=fuzz.partial_ratio
    )
    if result and result[1] >= threshold:
        idx = [p.lower() for p in patterns].index(result[0])
        return patterns[idx]

    return None
