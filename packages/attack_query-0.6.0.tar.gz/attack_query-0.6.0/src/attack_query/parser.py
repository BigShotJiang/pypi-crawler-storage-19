"""Natural language query parser for ATT&CK queries."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from attack_query.engine import ATTACKQueryEngine


class NLQueryParser:
    """
    Parses natural language queries into ATT&CK operations.

    Supported patterns:
    - "techniques used by APT28"
    - "techniques used by APT28 or APT29" (union)
    - "techniques used by APT28 and APT29" (intersection)
    - "techniques used by APT28 or APT29 but not APT33"
    - "techniques used by APT28 and APT29 but not APT33"
    - "techniques used by APT28 for initial access"
    - "techniques NOT used by APT28" (complement)
    - "techniques NOT used by APT28 or APT29" (complement of union)
    - "groups using T1566"
    - "compare APT28 and APT29"
    - "sub-techniques of T1566"
    - "parent of T1566.001"
    - "who is Fancy Bear" / "info APT28" / "group APT28"
    - "aliases of APT28"
    - "software used by APT28" / "tools used by APT28"
    - "groups using Mimikatz"
    - "techniques for Cobalt Strike" / "techniques used by Cobalt Strike"
    - "software info Mimikatz"
    - "software using T1566"
    - "mitigations for T1566"
    - "techniques mitigated by M1031"
    - "mitigation info M1031"
    - "data sources" / "list data sources"
    - "data source info Process"
    - "data components" / "list data components"
    - "data component info Process Creation"
    - "techniques detectable by Process Creation"
    - "campaigns" / "list campaigns"
    - "campaigns by APT28" / "campaigns for APT28"
    - "techniques in C0027"
    - "campaign info C0027"
    - "campaigns in 2023" / "campaigns from 2023"
    - "campaigns between 2022 and 2024"
    - "techniques used in 2023" / "techniques from 2023"
    - "similarity APT28 APT29" / "similarity between APT28 and APT29"
    - "groups similar to APT28" / "groups like APT28"
    - "groups similar to APT28 threshold 0.5 limit 5 using cosine"
    - "tactics used by APT28"
    - "tactics used by APT28 or APT29" (union)
    - "tactics used by APT28 and APT29" (intersection)
    - "which tactics does APT28 use"

    Mixed entity queries (combining software and groups):
    - "techniques used by software Mimikatz but not by group APT29"
    - "techniques used by both software Cobalt Strike and group APT28"
    - "techniques used by software Mimikatz or group APT28"

    Set operation semantics:
    - "or" → Union (techniques used by ANY of the groups)
    - "and" → Intersection (techniques used by ALL of the groups)
    - "but not" → Difference (exclude techniques from specified groups)
    - "both...and" → Intersection for mixed entity queries
    """

    def __init__(self, engine: ATTACKQueryEngine) -> None:
        """
        Initialize the parser.

        Args:
            engine: ATTACKQueryEngine instance for executing queries
        """
        self.engine = engine

    def parse_and_execute(self, query: str) -> dict[str, Any]:
        """
        Parse a natural language query and execute it.

        Args:
            query: Natural language query string

        Returns:
            Dictionary with query results
        """
        query = query.strip()

        # Pattern: "sub-techniques of T1566" or "subtechniques of T1566"
        match = re.match(r"sub-?techniques?\s+of\s+([T\d\.]+)", query, re.IGNORECASE)
        if match:
            parent_id = match.group(1).upper()
            return self._query_subtechniques_of(parent_id)

        # Pattern: "parent of T1566.001"
        match = re.match(r"parent\s+of\s+([T\d\.]+)", query, re.IGNORECASE)
        if match:
            subtechnique_id = match.group(1).upper()
            return self._query_parent_of(subtechnique_id)

        # Pattern: "software/tools used by APT28"
        match = re.match(
            r"(?:software|tools?|malware)\s+used\s+by\s+(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            group_name = match.group(1).strip()
            return self._query_software_by_group(group_name)

        # Pattern: "software using T1566"
        match = re.match(
            r"(?:software|tools?|malware)\s+using\s+([T\d\.]+)",
            query,
            re.IGNORECASE,
        )
        if match:
            technique_id = match.group(1).upper()
            return self._query_software_using_technique(technique_id)

        # Pattern: "groups using SOFTWARE" (check if not a technique ID)
        match = re.match(r"groups?\s+using\s+(.+)", query, re.IGNORECASE)
        if match:
            identifier = match.group(1).strip()
            # Check if it looks like a technique ID
            if re.match(r"^T\d+", identifier, re.IGNORECASE):
                return self._query_groups_using_technique(identifier.upper())
            # Otherwise treat as software
            return self._query_groups_using_software(identifier)

        # Pattern: "techniques for SOFTWARE" (software-specific, not "techniques used by")
        # Use "techniques for X" specifically for software queries
        match = re.match(
            r"techniques?\s+for\s+(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            identifier = match.group(1).strip()
            # Check if it's a software ID (starts with S)
            if re.match(r"^S\d+$", identifier, re.IGNORECASE):
                return self._query_techniques_by_software(identifier)
            # Check if it's known software (but not a group - avoid ambiguity)
            sw = self.engine.store.get_software(identifier)
            group = self.engine.store.get_group(identifier)
            if sw and not group:
                return self._query_techniques_by_software(identifier)
            # Fall through to group query if it's a group or unknown

        # Pattern: "software info NAME" / "software NAME"
        match = re.match(
            r"(?:software|tool|malware)\s+(?:info\s+)?(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            sw_name = match.group(1).strip()
            # Don't match "software used by" or "software using"
            if not sw_name.lower().startswith(("used", "using")):
                return self._query_software_info(sw_name)

        # Pattern: "mitigations for T1566" / "how to mitigate T1566"
        match = re.match(
            r"(?:mitigations?\s+for|how\s+to\s+mitigate)\s+([T\d\.]+)",
            query,
            re.IGNORECASE,
        )
        if match:
            technique_id = match.group(1).upper()
            return self._query_mitigations_for_technique(technique_id)

        # Pattern: "techniques mitigated by M1031"
        match = re.match(
            r"techniques?\s+mitigated\s+by\s+(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            mitigation_identifier = match.group(1).strip()
            return self._query_techniques_mitigated_by(mitigation_identifier)

        # Pattern: "mitigation info M1031" / "mitigation M1031"
        match = re.match(
            r"mitigation\s+(?:info\s+)?(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            mit_name = match.group(1).strip()
            # Don't match "mitigations for" pattern
            if not mit_name.lower().startswith("for"):
                return self._query_mitigation_info(mit_name)

        # Pattern: "data sources" / "list data sources"
        if re.match(r"(?:list\s+)?data\s+sources?$", query, re.IGNORECASE):
            return self._query_list_data_sources()

        # Pattern: "data source info NAME" / "data source NAME"
        match = re.match(
            r"data\s+source\s+(?:info\s+)?(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            ds_name = match.group(1).strip()
            # Don't match "data sources" (plural)
            if ds_name.lower() != "s" and not ds_name.lower().startswith("s "):
                return self._query_data_source_info(ds_name)

        # Pattern: "data components" / "list data components"
        if re.match(r"(?:list\s+)?data\s+components?$", query, re.IGNORECASE):
            return self._query_list_data_components()

        # Pattern: "data component info NAME" / "data component NAME"
        match = re.match(
            r"data\s+component\s+(?:info\s+)?(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            dc_name = match.group(1).strip()
            # Don't match "data components" (plural)
            if dc_name.lower() != "s" and not dc_name.lower().startswith("s "):
                return self._query_data_component_info(dc_name)

        # Pattern: "techniques detectable by DATA_COMPONENT"
        match = re.match(
            r"techniques?\s+detectable\s+by\s+(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            dc_identifier = match.group(1).strip()
            return self._query_techniques_detectable_by(dc_identifier)

        # Pattern: "campaigns" / "list campaigns"
        if re.match(r"(?:list\s+)?campaigns?$", query, re.IGNORECASE):
            return self._query_list_campaigns()

        # Pattern: "campaigns in 2023" / "campaigns from 2023"
        match = re.match(
            r"campaigns?\s+(?:in|from|during)\s+(\d{4})$",
            query,
            re.IGNORECASE,
        )
        if match:
            year = int(match.group(1))
            return self._query_campaigns_in_year(year)

        # Pattern: "campaigns between 2022 and 2024"
        match = re.match(
            r"campaigns?\s+between\s+(\d{4})\s+and\s+(\d{4})",
            query,
            re.IGNORECASE,
        )
        if match:
            start_year = int(match.group(1))
            end_year = int(match.group(2))
            return self._query_campaigns_in_range(start_year, end_year)

        # Pattern: "techniques used in 2023" / "techniques from 2023" / "techniques in 2023"
        match = re.match(
            r"techniques?\s+(?:used\s+)?(?:in|from|during)\s+(\d{4})$",
            query,
            re.IGNORECASE,
        )
        if match:
            year = int(match.group(1))
            return self._query_techniques_in_year(year)

        # Pattern: "techniques between 2022 and 2024"
        match = re.match(
            r"techniques?\s+(?:used\s+)?between\s+(\d{4})\s+and\s+(\d{4})",
            query,
            re.IGNORECASE,
        )
        if match:
            start_year = int(match.group(1))
            end_year = int(match.group(2))
            return self._query_techniques_in_range(start_year, end_year)

        # Pattern: "campaigns by APT28" / "campaigns for APT28" / "campaigns attributed to APT28"
        match = re.match(
            r"campaigns?\s+(?:by|for|attributed\s+to)\s+(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            group_name = match.group(1).strip()
            return self._query_campaigns_by_group(group_name)

        # Pattern: "techniques in C0027" / "techniques used in C0027"
        match = re.match(
            r"techniques?\s+(?:in|used\s+in)\s+(C\d+)",
            query,
            re.IGNORECASE,
        )
        if match:
            campaign_id = match.group(1).upper()
            return self._query_techniques_in_campaign(campaign_id)

        # Pattern: "campaign info C0027" / "campaign C0027"
        match = re.match(
            r"campaign\s+(?:info\s+)?(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            campaign_identifier = match.group(1).strip()
            # Don't match "campaigns by" or "campaigns for" patterns
            if not campaign_identifier.lower().startswith(("by", "for", "attributed")):
                return self._query_campaign_info(campaign_identifier)

        # Pattern: "who is Fancy Bear" / "info APT28" / "group info APT28"
        # Note: "what is" is too generic, so we use more specific patterns
        match = re.match(
            r"(?:who\s+is|info|group\s+info)\s+(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            group_name = match.group(1).strip()
            return self._query_group_info(group_name)

        # Pattern: "aliases of APT28" / "alias for APT28"
        match = re.match(r"alias(?:es)?\s+(?:of|for)\s+(.+)", query, re.IGNORECASE)
        if match:
            group_name = match.group(1).strip()
            return self._query_group_info(group_name)

        # Pattern: "group APT28" (single word "group" prefix) - must be after "groups using"
        match = re.match(r"group\s+(.+)", query, re.IGNORECASE)
        if match:
            group_name = match.group(1).strip()
            # Don't match if it looks like "group using", "group info", or "group similar to"
            if not group_name.lower().startswith(("using", "info", "similar", "like")):
                return self._query_group_info(group_name)

        # Pattern: "compare GROUP1 and GROUP2"
        match = re.match(r"compare\s+(.+?)\s+and\s+(.+)", query, re.IGNORECASE)
        if match:
            group1 = match.group(1).strip()
            group2 = match.group(2).strip()
            return self._query_compare_groups(group1, group2)

        # Pattern: "similarity GROUP1 GROUP2" / "similarity between GROUP1 and GROUP2"
        match = re.match(
            r"similarity\s+(?:between\s+)?(.+?)\s+(?:and\s+)?(.+)",
            query,
            re.IGNORECASE,
        )
        if match:
            group1 = match.group(1).strip()
            group2 = match.group(2).strip()
            return self._query_group_similarity(group1, group2)

        # Pattern: "groups similar to APT28" / "groups like APT28"
        # Optional: "threshold 0.5", "limit 5", "using cosine"
        match = re.match(
            r"groups?\s+(?:similar\s+to|like)\s+(.+?)(?:\s+threshold\s+([\d.]+))?(?:\s+limit\s+(\d+))?(?:\s+using\s+(\w+))?$",
            query,
            re.IGNORECASE,
        )
        if match:
            group_name = match.group(1).strip()
            threshold = float(match.group(2)) if match.group(2) else 0.0
            limit = int(match.group(3)) if match.group(3) else 10
            metric = match.group(4).lower() if match.group(4) else "jaccard"
            return self._query_similar_groups(group_name, threshold, limit, metric)

        # Pattern: "techniques NOT used by GROUP1 [or/and GROUP2...] [for TACTIC]"
        match = re.match(
            r"techniques?\s+not\s+used\s+by\s+(.+?)(?:\s+for\s+(.+))?$",
            query,
            re.IGNORECASE,
        )
        if match:
            groups_part = match.group(1)
            tactic_part = match.group(2)
            return self._query_techniques_not_used_by(groups_part, tactic_part)

        # Pattern: "tactics NOT used by GROUP1 [and/or GROUP2...]"
        match = re.match(
            r"tactics?\s+not\s+used\s+by\s+(.+)$",
            query,
            re.IGNORECASE,
        )
        if match:
            groups_part = match.group(1)
            return self._query_tactics_not_used_by(groups_part.strip())

        # Pattern: "tactics used by GROUP1 [and/or GROUP2...]"
        # Also: "which tactics does GROUP use" / "what tactics are used by GROUP"
        match = re.match(
            r"(?:tactics?\s+used\s+by|which\s+tactics?\s+(?:does|do)\s+(.+?)\s+use|what\s+tactics?\s+(?:are|is)\s+used\s+by)\s+(.+)$",
            query,
            re.IGNORECASE,
        )
        if match:
            # Handle "which tactics does X use" vs "tactics used by X"
            groups_part = match.group(1) or match.group(2)
            return self._query_tactics_by_groups(groups_part.strip())

        # Simpler pattern for "tactics used by X"
        match = re.match(
            r"tactics?\s+used\s+by\s+(.+)$",
            query,
            re.IGNORECASE,
        )
        if match:
            groups_part = match.group(1)
            return self._query_tactics_by_groups(groups_part.strip())

        # Pattern: "techniques used/employed by GROUP1 [and/or GROUP2...] [but not GROUP3...] [for TACTIC]"
        match = re.match(
            r"techniques?\s+(?:used|employed)\s+by\s+(.+?)(?:\s+for\s+(.+))?$",
            query,
            re.IGNORECASE,
        )
        if match:
            groups_part = match.group(1)
            tactic_part = match.group(2)
            return self._query_techniques_by_groups(groups_part, tactic_part)

        return self._build_error_response(query)

    def _query_groups_using_technique(self, technique_id: str) -> dict[str, Any]:
        """Execute a 'groups using technique' query."""
        technique = self.engine.store.get_technique(technique_id)
        if not technique:
            return {"error": f"Technique not found: {technique_id}"}

        groups = self.engine.groups_using_technique(technique_id)
        return {
            "query_type": "groups_using_technique",
            "technique": technique.to_dict(),
            "groups": sorted(groups),
            "count": len(groups),
        }

    def _query_compare_groups(self, group1: str, group2: str) -> dict[str, Any]:
        """Execute a group comparison query."""
        try:
            comparison = self.engine.compare_groups(group1, group2)

            # Convert sets to technique info
            def expand_techniques(tech_ids: set[str]) -> list[dict[str, Any]]:
                return [
                    self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                    for tid in sorted(tech_ids)
                    if self.engine.store.get_technique(tid)
                ]

            return {
                "query_type": "compare_groups",
                "group1": comparison["group1"],
                "group2": comparison["group2"],
                "group1_total": comparison["group1_total"],
                "group2_total": comparison["group2_total"],
                "shared_count": len(comparison["shared"]),
                "shared": expand_techniques(comparison["shared"]),
                "unique_to_first_count": len(comparison["unique_to_first"]),
                "unique_to_first": expand_techniques(comparison["unique_to_first"]),
                "unique_to_second_count": len(comparison["unique_to_second"]),
                "unique_to_second": expand_techniques(comparison["unique_to_second"]),
                "jaccard_similarity": round(comparison["jaccard_similarity"], 3),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_subtechniques_of(self, parent_id: str) -> dict[str, Any]:
        """Execute a 'sub-techniques of' query."""
        parent = self.engine.store.get_technique(parent_id)
        if not parent:
            return {"error": f"Technique not found: {parent_id}"}
        if parent.is_subtechnique:
            return {"error": f"{parent_id} is a sub-technique, not a parent technique"}

        try:
            subtechnique_ids = self.engine.get_subtechniques_of(parent_id)
            subtechniques = [
                self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                for tid in sorted(subtechnique_ids)
                if self.engine.store.get_technique(tid)
            ]

            return {
                "query_type": "subtechniques_of",
                "parent": parent.to_dict(),
                "subtechniques": subtechniques,
                "count": len(subtechniques),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_parent_of(self, subtechnique_id: str) -> dict[str, Any]:
        """Execute a 'parent of' query."""
        technique = self.engine.store.get_technique(subtechnique_id)
        if not technique:
            return {"error": f"Technique not found: {subtechnique_id}"}
        if not technique.is_subtechnique:
            return {"error": f"{subtechnique_id} is a parent technique, not a sub-technique"}

        try:
            parent_id = self.engine.get_parent_of(subtechnique_id)
            parent = self.engine.store.get_technique(parent_id)

            return {
                "query_type": "parent_of",
                "subtechnique": technique.to_dict(),
                "parent": parent.to_dict() if parent else None,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_group_info(self, group_name: str) -> dict[str, Any]:
        """Execute a group info/alias query."""
        try:
            info = self.engine.get_group_info(group_name)
            return {
                "query_type": "group_info",
                **info,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_techniques_not_used_by(
        self,
        groups_part: str,
        tactic_part: str | None,
    ) -> dict[str, Any]:
        """
        Execute a 'techniques NOT used by groups' query (complement operation).

        Returns all techniques from the ATT&CK database that are NOT used
        by any of the specified groups.
        """
        # Parse groups (supports "or", "and", comma - all treated as union for complement)
        groups, _ = self._parse_group_expression(groups_part)

        # Validate groups
        for group_name in groups:
            if not self.engine.store.get_group(group_name):
                return {"error": f"Group not found: {group_name}"}

        try:
            techniques = self.engine.techniques_complement(groups)

            # Filter by tactic if specified
            if tactic_part:
                tactic = self.engine.store.get_tactic(tactic_part.strip())
                if not tactic:
                    # Try matching by partial name
                    for t in self.engine.store.tactics.values():
                        if tactic_part.lower() in t.name.lower():
                            tactic = t
                            break

                if tactic:
                    techniques = self.engine.get_techniques_by_tactic(tactic.shortname, techniques)
                else:
                    return {"error": f"Tactic not found: {tactic_part}"}

            # Build result
            technique_list = [
                self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                for tid in sorted(techniques)
                if self.engine.store.get_technique(tid)
            ]

            result: dict[str, Any] = {
                "query_type": "techniques_not_used_by",
                "exclude_groups": groups,
                "operation": "complement",
                "techniques": technique_list,
                "count": len(technique_list),
            }

            if tactic_part:
                result["tactic_filter"] = tactic_part.strip()

            # Add tactic coverage summary
            result["by_tactic"] = self.engine.get_technique_coverage_by_tactic(techniques)

            return result

        except ValueError as e:
            return {"error": str(e)}

    def _query_tactics_by_groups(self, groups_part: str) -> dict[str, Any]:
        """
        Execute a 'tactics used by groups' query.

        Supports:
        - "A" → single group
        - "A or B" → union (tactics used by ANY)
        - "A and B" → intersection (tactics used by ALL)
        """
        # Detect operation type and parse groups
        groups, operation = self._parse_group_expression(groups_part)

        # Validate groups
        for group_name in groups:
            if not self.engine.store.get_group(group_name):
                return {"error": f"Group not found: {group_name}"}

        # Execute query based on operation type
        try:
            if operation == "intersection":
                tactic_shortnames = self.engine.tactics_intersection(groups)
            else:  # union (default)
                tactic_shortnames = self.engine.tactics_union(groups)

            # Convert shortnames to full tactic info
            tactics_list = []
            for shortname in sorted(tactic_shortnames):
                for tactic in self.engine.store.tactics.values():
                    if tactic.shortname == shortname:
                        tactics_list.append(
                            {
                                "id": tactic.id,
                                "name": tactic.name,
                                "shortname": tactic.shortname,
                            }
                        )
                        break

            # Sort by kill chain order (TA0001 -> TA0043)
            tactics_list.sort(key=lambda t: t["id"])

            return {
                "query_type": "tactics_by_groups",
                "groups": groups,
                "operation": operation,
                "tactics": tactics_list,
                "count": len(tactics_list),
            }

        except ValueError as e:
            return {"error": str(e)}

    def _query_tactics_not_used_by(self, groups_part: str) -> dict[str, Any]:
        """
        Execute a 'tactics NOT used by groups' query.

        Args:
            groups_part: Group expression like "APT28" or "APT28 or APT29"

        Returns:
            Query result with tactics not used by any of the groups
        """
        # Parse groups (always union for complement - tactics not used by any)
        groups, _ = self._parse_group_expression(groups_part)

        # Validate groups
        for group_name in groups:
            if not self.engine.store.get_group(group_name):
                return {"error": f"Group not found: {group_name}"}

        try:
            # Get tactics NOT used by the groups
            tactic_shortnames = self.engine.tactics_complement(groups)

            # Convert shortnames to full tactic info
            tactics_list = []
            for shortname in sorted(tactic_shortnames):
                for tactic in self.engine.store.tactics.values():
                    if tactic.shortname == shortname:
                        tactics_list.append(
                            {
                                "id": tactic.id,
                                "name": tactic.name,
                                "shortname": tactic.shortname,
                            }
                        )
                        break

            # Sort by kill chain order (TA0001 -> TA0043)
            tactics_list.sort(key=lambda t: t["id"])

            return {
                "query_type": "tactics_not_used_by",
                "groups": groups,
                "tactics": tactics_list,
                "count": len(tactics_list),
            }

        except ValueError as e:
            return {"error": str(e)}

    def _query_techniques_by_groups(
        self,
        groups_part: str,
        tactic_part: str | None,
    ) -> dict[str, Any]:
        """
        Execute a 'techniques used by groups' query.

        Supports:
        - "A" → single group
        - "A or B" → union (techniques used by ANY)
        - "A and B" → intersection (techniques used by ALL)
        - "A or B but not C" → union minus exclusions
        - "A and B but not C" → intersection minus exclusions
        - "software X but not by group Y" → mixed entity query
        - "both software X and group Y" → mixed entity intersection
        """
        # Check for mixed entity queries with explicit qualifiers
        if self._has_mixed_entity_qualifiers(groups_part):
            include_entities, operation, exclude_entities = (
                self._parse_mixed_entity_expression(groups_part)
            )
            return self._execute_mixed_entity_query(
                include_entities, operation, exclude_entities, tactic_part
            )

        include_groups: list[str] = []
        exclude_groups: list[str] = []

        # Split on "but not" or "but not by" first
        if " but not " in groups_part.lower():
            # Match "but not" optionally followed by "by"
            parts = re.split(r"\s+but\s+not\s+(?:by\s+)?", groups_part, flags=re.IGNORECASE)
            include_part = parts[0]
            exclude_part = parts[1] if len(parts) > 1 else ""
        else:
            include_part = groups_part
            exclude_part = ""

        # Detect operation type and parse included groups
        include_groups, include_operation = self._parse_group_expression(include_part)

        # Parse excluded groups (always union for exclusions)
        if exclude_part:
            exclude_groups, _ = self._parse_group_expression(exclude_part)

        # Resolve entity types and check for mixed software/group queries
        resolved_include: list[tuple[str, str]] = []
        resolved_exclude: list[tuple[str, str]] = []
        has_software = False
        has_group = False

        for name in include_groups:
            if self.engine.store.get_group(name):
                resolved_include.append((name, "group"))
                has_group = True
            elif self.engine.store.get_software(name):
                resolved_include.append((name, "software"))
                has_software = True
            else:
                return {"error": f"Group not found: {name}"}

        for name in exclude_groups:
            if self.engine.store.get_group(name):
                resolved_exclude.append((name, "group"))
                has_group = True
            elif self.engine.store.get_software(name):
                resolved_exclude.append((name, "software"))
                has_software = True
            else:
                return {"error": f"Group not found: {name}"}

        # If we have a mix of software and groups, use mixed entity query
        if has_software and has_group:
            return self._execute_mixed_entity_query(
                resolved_include, include_operation, resolved_exclude, tactic_part
            )

        # If all are software (single identifier case)
        if has_software and not has_group:
            if len(resolved_include) == 1 and not resolved_exclude:
                return self._query_techniques_by_software(resolved_include[0][0])
            # Multiple software or software with exclusions - use mixed entity query
            return self._execute_mixed_entity_query(
                resolved_include, include_operation, resolved_exclude, tactic_part
            )

        # Execute query based on operation type
        try:
            if include_operation == "intersection":
                if exclude_groups:
                    # Intersection of include, minus union of exclude
                    techniques = self.engine.techniques_exclusive_intersection(
                        include_groups, exclude_groups
                    )
                else:
                    techniques = self.engine.techniques_intersection(include_groups)
            else:  # union (default)
                if exclude_groups:
                    techniques = self.engine.techniques_difference(include_groups, exclude_groups)
                else:
                    techniques = self.engine.techniques_union(include_groups)

            # Filter by tactic if specified
            if tactic_part:
                tactic = self.engine.store.get_tactic(tactic_part.strip())
                if not tactic:
                    # Try matching by partial name
                    for t in self.engine.store.tactics.values():
                        if tactic_part.lower() in t.name.lower():
                            tactic = t
                            break

                if tactic:
                    techniques = self.engine.get_techniques_by_tactic(tactic.shortname, techniques)
                else:
                    return {"error": f"Tactic not found: {tactic_part}"}

            # Build result
            technique_list = [
                self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                for tid in sorted(techniques)
                if self.engine.store.get_technique(tid)
            ]

            result: dict[str, Any] = {
                "query_type": "techniques_by_groups",
                "include_groups": include_groups,
                "exclude_groups": exclude_groups,
                "operation": include_operation,
                "techniques": technique_list,
                "count": len(technique_list),
            }

            if tactic_part:
                result["tactic_filter"] = tactic_part.strip()

            # Add tactic coverage summary
            result["by_tactic"] = self.engine.get_technique_coverage_by_tactic(techniques)

            return result

        except ValueError as e:
            return {"error": str(e)}

    def _parse_group_expression(self, text: str) -> tuple[list[str], str]:
        """
        Parse a group expression and determine the operation type.

        Args:
            text: Group expression like "APT28 and APT29" or "APT28 or APT29"
                  or "APT28, APT29, and APT33" (comma list with trailing "and")

        Returns:
            Tuple of (list of group names, operation type: "union" or "intersection")
        """
        text = text.strip()

        # Check for "or" (union) - must check before "and" since "and" appears in some group names
        if re.search(r"\s+or\s+", text, re.IGNORECASE):
            # Split on ", or", " or ", or just ","
            groups = re.split(r",?\s+or\s+|,\s*", text, flags=re.IGNORECASE)
            return [g.strip() for g in groups if g.strip()], "union"

        # Check for "and" (intersection)
        if re.search(r"\s+and\s+", text, re.IGNORECASE):
            # Split on ", and", " and ", or just ","
            groups = re.split(r",?\s+and\s+|,\s*", text, flags=re.IGNORECASE)
            return [g.strip() for g in groups if g.strip()], "intersection"

        # Check for comma-separated (defaults to union for backward compatibility)
        if "," in text:
            groups = re.split(r",\s*", text)
            return [g.strip() for g in groups if g.strip()], "union"

        # Single group
        return [text], "union"

    def _has_mixed_entity_qualifiers(self, text: str) -> bool:
        """Check if text contains explicit 'software X' or 'group X' qualifiers."""
        return bool(
            re.search(r"(?:the\s+)?(?:software|tool|malware)\s+\S", text, re.IGNORECASE)
            or re.search(r"(?:the\s+)?group\s+\S", text, re.IGNORECASE)
        )

    def _parse_mixed_entity_expression(
        self, text: str
    ) -> tuple[list[tuple[str, str]], str, list[tuple[str, str]]]:
        """
        Parse a mixed entity expression with explicit software/group qualifiers.

        Args:
            text: Expression like "software bankshot but not by the group APT1"
                  or "both software drovorub and the group APT41"

        Returns:
            Tuple of (include_entities, operation, exclude_entities)
            Each entity is a tuple of (name, type) where type is "software" or "group"
        """
        text = text.strip()

        # Determine if this is an intersection ("both...and") operation
        is_intersection = text.lower().startswith("both ")
        if is_intersection:
            text = text[5:].strip()  # Remove "both "

        include_entities: list[tuple[str, str]] = []
        exclude_entities: list[tuple[str, str]] = []

        # Split on "but not" or "but not by" for exclusions
        if " but not " in text.lower():
            parts = re.split(r"\s+but\s+not\s+(?:by\s+)?", text, flags=re.IGNORECASE)
            include_part = parts[0]
            exclude_part = parts[1] if len(parts) > 1 else ""
        else:
            include_part = text
            exclude_part = ""

        # Parse entities from the include part
        include_entities = self._extract_entities_from_expression(include_part)

        # Parse entities from the exclude part
        if exclude_part:
            exclude_entities = self._extract_entities_from_expression(exclude_part)

        # Determine operation based on "both" keyword or "and" between entities
        if is_intersection or " and " in include_part.lower():
            operation = "intersection"
        else:
            operation = "union"

        return include_entities, operation, exclude_entities

    def _extract_entities_from_expression(self, text: str) -> list[tuple[str, str]]:
        """
        Extract entity (name, type) tuples from an expression.

        Handles patterns like:
        - "software bankshot"
        - "the software bankshot"
        - "group APT1"
        - "the group APT1"
        - Combinations with "and" or "or"
        """
        entities: list[tuple[str, str]] = []

        # Split on "and" or "or" to handle multiple entities
        # Need to be careful not to split within entity names
        parts = re.split(r"\s+(?:and|or)\s+", text, flags=re.IGNORECASE)

        for part in parts:
            part = part.strip()
            if not part:
                continue

            # Try to match "software NAME" or "the software NAME"
            match = re.match(
                r"(?:the\s+)?(?:software|tool|malware)\s+(.+)",
                part,
                re.IGNORECASE,
            )
            if match:
                name = match.group(1).strip()
                entities.append((name, "software"))
                continue

            # Try to match "group NAME" or "the group NAME"
            match = re.match(
                r"(?:the\s+)?group\s+(.+)",
                part,
                re.IGNORECASE,
            )
            if match:
                name = match.group(1).strip()
                entities.append((name, "group"))
                continue

            # If no qualifier, treat as unknown (caller will need to resolve)
            entities.append((part, "unknown"))

        return entities

    def _execute_mixed_entity_query(
        self,
        include_entities: list[tuple[str, str]],
        operation: str,
        exclude_entities: list[tuple[str, str]],
        tactic_part: str | None,
    ) -> dict[str, Any]:
        """
        Execute a mixed entity query combining software and group techniques.

        Args:
            include_entities: List of (name, type) tuples to include
            operation: "union" or "intersection"
            exclude_entities: List of (name, type) tuples to exclude
            tactic_part: Optional tactic filter

        Returns:
            Query result dictionary
        """
        include_technique_sets: list[set[str]] = []
        exclude_technique_sets: list[set[str]] = []
        resolved_includes: list[dict[str, str]] = []
        resolved_excludes: list[dict[str, str]] = []

        # Resolve and get techniques for include entities
        for name, entity_type in include_entities:
            techniques: set[str] = set()

            if entity_type == "software":
                sw = self.engine.store.get_software(name)
                if not sw:
                    return {"error": f"Software not found: {name}"}
                techniques = self.engine.get_software_techniques(name)
                resolved_includes.append(
                    {"name": sw.name, "id": sw.id, "type": "software"}
                )
            elif entity_type == "group":
                group = self.engine.store.get_group(name)
                if not group:
                    return {"error": f"Group not found: {name}"}
                techniques = group.techniques.copy()
                resolved_includes.append(
                    {"name": group.name, "id": group.id, "type": "group"}
                )
            else:
                # Unknown type - try to resolve
                sw = self.engine.store.get_software(name)
                group = self.engine.store.get_group(name)
                if sw:
                    techniques = self.engine.get_software_techniques(name)
                    resolved_includes.append(
                        {"name": sw.name, "id": sw.id, "type": "software"}
                    )
                elif group:
                    techniques = group.techniques.copy()
                    resolved_includes.append(
                        {"name": group.name, "id": group.id, "type": "group"}
                    )
                else:
                    return {"error": f"Entity not found: {name}"}

            include_technique_sets.append(techniques)

        # Resolve and get techniques for exclude entities
        for name, entity_type in exclude_entities:
            techniques = set()

            if entity_type == "software":
                sw = self.engine.store.get_software(name)
                if not sw:
                    return {"error": f"Software not found: {name}"}
                techniques = self.engine.get_software_techniques(name)
                resolved_excludes.append(
                    {"name": sw.name, "id": sw.id, "type": "software"}
                )
            elif entity_type == "group":
                group = self.engine.store.get_group(name)
                if not group:
                    return {"error": f"Group not found: {name}"}
                techniques = group.techniques.copy()
                resolved_excludes.append(
                    {"name": group.name, "id": group.id, "type": "group"}
                )
            else:
                # Unknown type - try to resolve
                sw = self.engine.store.get_software(name)
                group = self.engine.store.get_group(name)
                if sw:
                    techniques = self.engine.get_software_techniques(name)
                    resolved_excludes.append(
                        {"name": sw.name, "id": sw.id, "type": "software"}
                    )
                elif group:
                    techniques = group.techniques.copy()
                    resolved_excludes.append(
                        {"name": group.name, "id": group.id, "type": "group"}
                    )
                else:
                    return {"error": f"Entity not found: {name}"}

            exclude_technique_sets.append(techniques)

        # Apply set operation to include techniques
        if not include_technique_sets:
            return {"error": "No entities to include"}

        result_techniques: set[str]
        if operation == "intersection":
            result_techniques = include_technique_sets[0]
            for tech_set in include_technique_sets[1:]:
                result_techniques = result_techniques & tech_set
        else:  # union
            result_techniques = set()
            for tech_set in include_technique_sets:
                result_techniques = result_techniques | tech_set

        # Remove excluded techniques (union of all exclude sets)
        for tech_set in exclude_technique_sets:
            result_techniques = result_techniques - tech_set

        # Filter by tactic if specified
        if tactic_part:
            tactic = self.engine.store.get_tactic(tactic_part.strip())
            if not tactic:
                # Try matching by partial name
                for t in self.engine.store.tactics.values():
                    if tactic_part.lower() in t.name.lower():
                        tactic = t
                        break

            if tactic:
                result_techniques = self.engine.get_techniques_by_tactic(
                    tactic.shortname, result_techniques
                )
            else:
                return {"error": f"Tactic not found: {tactic_part}"}

        # Build result
        technique_list = [
            self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
            for tid in sorted(result_techniques)
            if self.engine.store.get_technique(tid)
        ]

        result: dict[str, Any] = {
            "query_type": "techniques_by_mixed_entities",
            "include_entities": resolved_includes,
            "exclude_entities": resolved_excludes,
            "operation": operation,
            "techniques": technique_list,
            "count": len(technique_list),
        }

        if tactic_part:
            result["tactic_filter"] = tactic_part.strip()

        # Add tactic coverage summary
        result["by_tactic"] = self.engine.get_technique_coverage_by_tactic(
            result_techniques
        )

        return result

    def _split_group_list(self, text: str) -> list[str]:
        """
        Split a group list on 'or', 'and', or ','.

        Deprecated: Use _parse_group_expression() instead for proper operation detection.
        Kept for backward compatibility.
        """
        groups, _ = self._parse_group_expression(text)
        return groups

    def _query_software_by_group(self, group_name: str) -> dict[str, Any]:
        """Execute a 'software used by group' query."""
        try:
            group = self.engine.store.get_group(group_name)
            if not group:
                return {"error": f"Group not found: {group_name}"}

            software_list = self.engine.get_group_software(group_name)
            return {
                "query_type": "software_by_group",
                "group": group.name,
                "group_id": group.id,
                "software": software_list,
                "count": len(software_list),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_groups_using_software(self, software_name: str) -> dict[str, Any]:
        """Execute a 'groups using software' query."""
        try:
            sw = self.engine.store.get_software(software_name)
            if not sw:
                return {"error": f"Software not found: {software_name}"}

            groups = self.engine.groups_using_software(software_name)
            return {
                "query_type": "groups_using_software",
                "software": sw.name,
                "software_id": sw.id,
                "software_type": sw.software_type,
                "groups": groups,
                "count": len(groups),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_techniques_by_software(self, software_name: str) -> dict[str, Any]:
        """Execute a 'techniques for software' query."""
        try:
            sw = self.engine.store.get_software(software_name)
            if not sw:
                return {"error": f"Software not found: {software_name}"}

            technique_ids = self.engine.get_software_techniques(software_name)
            technique_list = [
                self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                for tid in sorted(technique_ids)
                if self.engine.store.get_technique(tid)
            ]

            return {
                "query_type": "techniques_by_software",
                "software": sw.name,
                "software_id": sw.id,
                "software_type": sw.software_type,
                "techniques": technique_list,
                "count": len(technique_list),
                "by_tactic": self.engine.get_technique_coverage_by_tactic(technique_ids),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_software_info(self, software_name: str) -> dict[str, Any]:
        """Execute a software info query."""
        try:
            info = self.engine.get_software_info(software_name)
            return {
                "query_type": "software_info",
                **info,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_software_using_technique(self, technique_id: str) -> dict[str, Any]:
        """Execute a 'software using technique' query."""
        technique = self.engine.store.get_technique(technique_id)
        if not technique:
            return {"error": f"Technique not found: {technique_id}"}

        software_list = self.engine.software_using_technique(technique_id)
        return {
            "query_type": "software_using_technique",
            "technique": technique.to_dict(),
            "software": software_list,
            "count": len(software_list),
        }

    def _query_mitigations_for_technique(self, technique_id: str) -> dict[str, Any]:
        """Execute a 'mitigations for technique' query."""
        technique = self.engine.store.get_technique(technique_id)
        if not technique:
            return {"error": f"Technique not found: {technique_id}"}

        mitigations = self.engine.get_mitigations_for_technique(technique_id)
        return {
            "query_type": "mitigations_for_technique",
            "technique": technique.to_dict(),
            "mitigations": mitigations,
            "count": len(mitigations),
        }

    def _query_techniques_mitigated_by(self, mitigation_identifier: str) -> dict[str, Any]:
        """Execute a 'techniques mitigated by' query."""
        try:
            mitigation = self.engine.store.get_mitigation(mitigation_identifier)
            if not mitigation:
                return {"error": f"Mitigation not found: {mitigation_identifier}"}

            technique_ids = self.engine.get_techniques_mitigated_by(mitigation_identifier)
            technique_list = [
                self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                for tid in sorted(technique_ids)
                if self.engine.store.get_technique(tid)
            ]

            return {
                "query_type": "techniques_mitigated_by",
                "mitigation": {
                    "id": mitigation.id,
                    "name": mitigation.name,
                },
                "techniques": technique_list,
                "count": len(technique_list),
                "by_tactic": self.engine.get_technique_coverage_by_tactic(technique_ids),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_mitigation_info(self, mitigation_identifier: str) -> dict[str, Any]:
        """Execute a mitigation info query."""
        try:
            info = self.engine.get_mitigation_info(mitigation_identifier)
            return {
                "query_type": "mitigation_info",
                **info,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_list_data_sources(self) -> dict[str, Any]:
        """List all data sources."""
        data_sources = [
            {"id": ds.id, "name": ds.name, "platforms": ds.platforms}
            for ds in sorted(self.engine.store.data_sources.values(), key=lambda x: x.id)
        ]
        return {
            "query_type": "list_data_sources",
            "data_sources": data_sources,
            "count": len(data_sources),
        }

    def _query_data_source_info(self, ds_identifier: str) -> dict[str, Any]:
        """Execute a data source info query."""
        try:
            info = self.engine.get_data_source_info(ds_identifier)
            return {
                "query_type": "data_source_info",
                **info,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_list_data_components(self) -> dict[str, Any]:
        """List all data components."""
        data_components = [
            {
                "id": dc.id,
                "name": dc.name,
                "technique_count": len(dc.techniques),
            }
            for dc in sorted(self.engine.store.data_components.values(), key=lambda x: x.id)
        ]
        return {
            "query_type": "list_data_components",
            "data_components": data_components,
            "count": len(data_components),
        }

    def _query_data_component_info(self, dc_identifier: str) -> dict[str, Any]:
        """Execute a data component info query."""
        try:
            info = self.engine.get_data_component_info(dc_identifier)
            return {
                "query_type": "data_component_info",
                **info,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_techniques_detectable_by(self, dc_identifier: str) -> dict[str, Any]:
        """Execute a 'techniques detectable by data component' query."""
        try:
            dc = self.engine.store.get_data_component(dc_identifier)
            if not dc:
                return {"error": f"Data component not found: {dc_identifier}"}

            technique_ids = self.engine.get_techniques_detectable_by(dc_identifier)
            technique_list = [
                self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                for tid in sorted(technique_ids)
                if self.engine.store.get_technique(tid)
            ]

            return {
                "query_type": "techniques_detectable_by",
                "data_component": {
                    "id": dc.id,
                    "name": dc.name,
                },
                "techniques": technique_list,
                "count": len(technique_list),
                "by_tactic": self.engine.get_technique_coverage_by_tactic(technique_ids),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_list_campaigns(self) -> dict[str, Any]:
        """List all campaigns."""
        campaigns = [
            {
                "id": c.id,
                "name": c.name,
                "first_seen": c.first_seen,
                "last_seen": c.last_seen,
                "technique_count": len(c.techniques),
            }
            for c in sorted(self.engine.store.campaigns.values(), key=lambda x: x.id)
        ]
        return {
            "query_type": "list_campaigns",
            "campaigns": campaigns,
            "count": len(campaigns),
        }

    def _query_campaigns_by_group(self, group_name: str) -> dict[str, Any]:
        """Execute a 'campaigns by group' query."""
        try:
            group = self.engine.store.get_group(group_name)
            if not group:
                return {"error": f"Group not found: {group_name}"}

            campaigns = self.engine.get_group_campaigns(group_name)
            return {
                "query_type": "campaigns_by_group",
                "group": group.name,
                "group_id": group.id,
                "campaigns": campaigns,
                "count": len(campaigns),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_techniques_in_campaign(self, campaign_id: str) -> dict[str, Any]:
        """Execute a 'techniques in campaign' query."""
        try:
            campaign = self.engine.store.get_campaign(campaign_id)
            if not campaign:
                return {"error": f"Campaign not found: {campaign_id}"}

            technique_ids = self.engine.get_campaign_techniques(campaign_id)
            technique_list = [
                self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
                for tid in sorted(technique_ids)
                if self.engine.store.get_technique(tid)
            ]

            return {
                "query_type": "techniques_in_campaign",
                "campaign": {
                    "id": campaign.id,
                    "name": campaign.name,
                    "first_seen": campaign.first_seen,
                    "last_seen": campaign.last_seen,
                },
                "techniques": technique_list,
                "count": len(technique_list),
                "by_tactic": self.engine.get_technique_coverage_by_tactic(technique_ids),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_campaign_info(self, campaign_identifier: str) -> dict[str, Any]:
        """Execute a campaign info query."""
        try:
            info = self.engine.get_campaign_info(campaign_identifier)
            return {
                "query_type": "campaign_info",
                **info,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_campaigns_in_year(self, year: int) -> dict[str, Any]:
        """Execute a 'campaigns in year' query."""
        campaigns = self.engine.get_campaigns_in_year(year)
        return {
            "query_type": "campaigns_in_year",
            "year": year,
            "campaigns": campaigns,
            "count": len(campaigns),
        }

    def _query_campaigns_in_range(self, start_year: int, end_year: int) -> dict[str, Any]:
        """Execute a 'campaigns between years' query."""
        campaigns = self.engine.get_campaigns_in_range(start_year, end_year)
        return {
            "query_type": "campaigns_in_range",
            "start_year": start_year,
            "end_year": end_year,
            "campaigns": campaigns,
            "count": len(campaigns),
        }

    def _query_techniques_in_year(self, year: int) -> dict[str, Any]:
        """Execute a 'techniques in year' query."""
        technique_ids = self.engine.get_techniques_in_year(year)
        technique_list = [
            self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
            for tid in sorted(technique_ids)
            if self.engine.store.get_technique(tid)
        ]

        # Get campaigns that contributed these techniques
        campaigns = self.engine.get_campaigns_in_year(year)

        return {
            "query_type": "techniques_in_year",
            "year": year,
            "techniques": technique_list,
            "count": len(technique_list),
            "campaign_count": len(campaigns),
            "by_tactic": self.engine.get_technique_coverage_by_tactic(technique_ids),
        }

    def _query_techniques_in_range(self, start_year: int, end_year: int) -> dict[str, Any]:
        """Execute a 'techniques between years' query."""
        technique_ids = self.engine.get_techniques_in_range(start_year, end_year)
        technique_list = [
            self.engine.store.get_technique(tid).to_dict()  # type: ignore[union-attr]
            for tid in sorted(technique_ids)
            if self.engine.store.get_technique(tid)
        ]

        # Get campaigns that contributed these techniques
        campaigns = self.engine.get_campaigns_in_range(start_year, end_year)

        return {
            "query_type": "techniques_in_range",
            "start_year": start_year,
            "end_year": end_year,
            "techniques": technique_list,
            "count": len(technique_list),
            "campaign_count": len(campaigns),
            "by_tactic": self.engine.get_technique_coverage_by_tactic(technique_ids),
        }

    def _query_group_similarity(self, group1: str, group2: str) -> dict[str, Any]:
        """Execute a 'similarity between two groups' query."""
        try:
            result = self.engine.calculate_group_similarity(group1, group2)
            return {
                "query_type": "group_similarity",
                **result,
            }
        except ValueError as e:
            return {"error": str(e)}

    def _query_similar_groups(
        self,
        group_name: str,
        threshold: float,
        limit: int,
        metric: str,
    ) -> dict[str, Any]:
        """Execute a 'groups similar to' query."""
        try:
            group = self.engine.store.get_group(group_name)
            if not group:
                return {"error": f"Group not found: {group_name}"}

            similar_groups = self.engine.find_similar_groups(
                group_name,
                threshold=threshold,
                limit=limit,
                metric=metric,
            )

            return {
                "query_type": "similar_groups",
                "group": group.name,
                "group_id": group.id,
                "technique_count": len(group.techniques),
                "metric": metric,
                "threshold": threshold,
                "similar_groups": similar_groups,
                "count": len(similar_groups),
            }
        except ValueError as e:
            return {"error": str(e)}

    def _build_error_response(self, query: str) -> dict[str, Any]:
        """Build error response with fuzzy matching suggestions."""
        from attack_query.fuzzy import (
            fuzzy_available,
            suggest_group,
            suggest_query_pattern,
        )

        result: dict[str, Any] = {
            "error": "Could not parse query",
            "query": query,
            "hint": "Try: 'techniques used by APT28 or APT29 but not APT33'",
        }

        if not fuzzy_available():
            return result

        # Try to suggest a query pattern
        suggested_pattern = suggest_query_pattern(query)
        if suggested_pattern:
            result["suggested_pattern"] = suggested_pattern

        # Extract potential group names from query and suggest corrections
        words = query.split()
        suggestions: list[str] = []

        for word in words:
            # Skip common words
            if word.lower() in {
                "techniques",
                "used",
                "by",
                "or",
                "and",
                "but",
                "not",
                "for",
                "groups",
                "using",
                "software",
                "mitigations",
                "campaigns",
                "similar",
                "to",
                "like",
            }:
                continue

            # Try to find a matching group
            suggested = suggest_group(word, self.engine.store)
            if suggested and suggested.lower() != word.lower():
                suggestions.append(f"'{word}' → '{suggested}'")

        if suggestions:
            result["suggestions"] = suggestions

        return result
