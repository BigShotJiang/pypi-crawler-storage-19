"""Data models for MITRE ATT&CK entities."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Matrix(Enum):
    """ATT&CK matrix types."""

    ENTERPRISE = "enterprise"
    MOBILE = "mobile"
    ICS = "ics"

    @property
    def stix_name(self) -> str:
        """Get the STIX bundle name prefix (e.g., 'enterprise-attack')."""
        return f"{self.value}-attack"

    @property
    def display_name(self) -> str:
        """Get human-readable name."""
        names = {
            "enterprise": "Enterprise",
            "mobile": "Mobile",
            "ics": "ICS",
        }
        return names[self.value]

    @classmethod
    def from_string(cls, value: str) -> Matrix:
        """Parse matrix from string, case-insensitive."""
        value_lower = value.lower()
        for matrix in cls:
            if matrix.value == value_lower:
                return matrix
        valid = ", ".join(m.value for m in cls)
        raise ValueError(f"Unknown matrix: {value}. Valid options: {valid}")


@dataclass
class Technique:
    """Represents an ATT&CK technique or sub-technique."""

    id: str  # e.g., "T1566" or "T1566.001"
    stix_id: str  # e.g., "attack-pattern--..."
    name: str
    description: str
    tactics: list[str] = field(default_factory=list)  # e.g., ["initial-access"]
    platforms: list[str] = field(default_factory=list)
    is_subtechnique: bool = False
    parent_id: str | None = None  # For sub-techniques

    def to_dict(self) -> dict[str, str | list[str] | bool | None]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description[:200] + "..."
            if len(self.description) > 200
            else self.description,
            "tactics": self.tactics,
            "platforms": self.platforms,
            "is_subtechnique": self.is_subtechnique,
            "parent_id": self.parent_id,
        }


@dataclass
class Group:
    """Represents a threat actor group."""

    id: str  # e.g., "G0007"
    stix_id: str
    name: str  # e.g., "APT28"
    description: str
    aliases: list[str] = field(default_factory=list)
    techniques: set[str] = field(default_factory=set)  # Set of technique IDs

    def to_dict(self) -> dict[str, str | list[str] | int]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "aliases": self.aliases,
            "technique_count": len(self.techniques),
        }


@dataclass
class Tactic:
    """Represents an ATT&CK tactic (kill chain phase)."""

    id: str  # e.g., "TA0001"
    stix_id: str
    name: str  # e.g., "Initial Access"
    shortname: str  # e.g., "initial-access"
    description: str

    def to_dict(self) -> dict[str, str]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "shortname": self.shortname,
        }


@dataclass
class Software:
    """Represents ATT&CK software (malware or tool)."""

    id: str  # e.g., "S0002"
    stix_id: str
    name: str  # e.g., "Mimikatz"
    description: str
    software_type: str  # "malware" or "tool"
    aliases: list[str] = field(default_factory=list)
    platforms: list[str] = field(default_factory=list)
    techniques: set[str] = field(default_factory=set)  # Technique IDs this software uses

    def to_dict(self) -> dict[str, str | list[str] | int]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "type": self.software_type,
            "aliases": self.aliases,
            "platforms": self.platforms,
            "technique_count": len(self.techniques),
        }


@dataclass
class Mitigation:
    """Represents an ATT&CK mitigation (course of action)."""

    id: str  # e.g., "M1031"
    stix_id: str
    name: str  # e.g., "Network Intrusion Prevention"
    description: str
    techniques: set[str] = field(default_factory=set)  # Technique IDs this mitigation addresses

    def to_dict(self) -> dict[str, str | int]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description[:200] + "..."
            if len(self.description) > 200
            else self.description,
            "technique_count": len(self.techniques),
        }


@dataclass
class DataSource:
    """Represents an ATT&CK data source."""

    id: str  # e.g., "DS0014"
    stix_id: str
    name: str  # e.g., "Pod"
    description: str
    platforms: list[str] = field(default_factory=list)
    collection_layers: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, str | list[str]]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description[:200] + "..."
            if len(self.description) > 200
            else self.description,
            "platforms": self.platforms,
            "collection_layers": self.collection_layers,
        }


@dataclass
class DataComponent:
    """Represents an ATT&CK data component."""

    id: str  # e.g., "DC0084"
    stix_id: str
    name: str  # e.g., "Active Directory Credential Request"
    description: str
    log_sources: list[dict[str, str]] = field(
        default_factory=list
    )  # e.g., [{"name": "WinEventLog:Security", "channel": "EventCode=4768"}]
    techniques: set[str] = field(default_factory=set)  # Technique IDs detectable via this component

    def to_dict(self) -> dict[str, str | list[dict[str, str]] | int]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description[:200] + "..."
            if len(self.description) > 200
            else self.description,
            "log_sources": self.log_sources,
            "technique_count": len(self.techniques),
        }


@dataclass
class Campaign:
    """Represents an ATT&CK campaign."""

    id: str  # e.g., "C0027"
    stix_id: str
    name: str  # e.g., "C0027" (often same as id)
    description: str
    aliases: list[str] = field(default_factory=list)
    first_seen: str | None = None  # ISO date string, e.g., "2022-06-01T04:00:00.000Z"
    last_seen: str | None = None  # ISO date string
    techniques: set[str] = field(default_factory=set)  # Technique IDs used in campaign
    software: set[str] = field(default_factory=set)  # Software IDs used in campaign
    groups: set[str] = field(default_factory=set)  # Group IDs attributed to campaign

    def to_dict(self) -> dict[str, str | list[str] | int | None]:
        """Convert to dictionary representation."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description[:200] + "..."
            if len(self.description) > 200
            else self.description,
            "aliases": self.aliases,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "technique_count": len(self.techniques),
            "software_count": len(self.software),
            "group_count": len(self.groups),
        }
