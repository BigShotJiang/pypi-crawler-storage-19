"""Query engine for ATT&CK data with set operations."""

from __future__ import annotations

import csv
import io
import math
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from attack_query.store import ATTACKDataStore


class ATTACKQueryEngine:
    """
    Query engine providing set operations on ATT&CK techniques.

    Enables queries like:
    - Techniques used by multiple groups (intersection)
    - Techniques used by any of several groups (union)
    - Techniques used by some groups but not others (difference)
    - Techniques NOT used by specified groups (complement)
    """

    def __init__(self, store: ATTACKDataStore) -> None:
        """
        Initialize the query engine.

        Args:
            store: Loaded ATTACKDataStore instance
        """
        self.store = store

    def get_group_info(self, identifier: str) -> dict[str, Any]:
        """
        Get detailed information about a group, including alias resolution.

        Args:
            identifier: Group name, ID, or alias

        Returns:
            Dictionary with group info and resolution details

        Raises:
            ValueError: If group not found
        """
        group = self.store.get_group(identifier)
        if not group:
            raise ValueError(f"Group not found: {identifier}")

        # Determine if lookup was via alias
        resolved_from: str | None = None
        lower_id = identifier.lower()
        if lower_id in self.store.groups_by_alias and lower_id != group.name.lower():
            resolved_from = identifier

        return {
            "id": group.id,
            "name": group.name,
            "description": group.description,
            "aliases": group.aliases,
            "technique_count": len(group.techniques),
            "resolved_from": resolved_from,
        }

    def get_software_info(self, identifier: str) -> dict[str, Any]:
        """
        Get detailed information about software, including alias resolution.

        Args:
            identifier: Software name, ID, or alias

        Returns:
            Dictionary with software info and resolution details

        Raises:
            ValueError: If software not found
        """
        sw = self.store.get_software(identifier)
        if not sw:
            raise ValueError(f"Software not found: {identifier}")

        # Determine if lookup was via alias
        resolved_from: str | None = None
        lower_id = identifier.lower()
        if lower_id in self.store.software_by_alias and lower_id != sw.name.lower():
            resolved_from = identifier

        # Get groups that use this software
        group_ids = self.store.software_to_groups.get(sw.id, set())
        groups = [self.store.groups[gid].name for gid in group_ids if gid in self.store.groups]

        return {
            "id": sw.id,
            "name": sw.name,
            "type": sw.software_type,
            "description": sw.description,
            "aliases": sw.aliases,
            "platforms": sw.platforms,
            "technique_count": len(sw.techniques),
            "groups": sorted(groups),
            "resolved_from": resolved_from,
        }

    def get_software_techniques(self, software_identifier: str) -> set[str]:
        """
        Get all technique IDs used by a software.

        Args:
            software_identifier: Software name, ID, or alias

        Returns:
            Set of technique IDs

        Raises:
            ValueError: If software not found
        """
        sw = self.store.get_software(software_identifier)
        if not sw:
            raise ValueError(f"Software not found: {software_identifier}")
        return sw.techniques.copy()

    def get_group_software(self, group_identifier: str) -> list[dict[str, Any]]:
        """
        Get all software used by a group.

        Args:
            group_identifier: Group name, ID, or alias

        Returns:
            List of software info dictionaries

        Raises:
            ValueError: If group not found
        """
        group = self.store.get_group(group_identifier)
        if not group:
            raise ValueError(f"Group not found: {group_identifier}")

        software_ids = self.store.group_to_software.get(group.id, set())
        result = []
        for sw_id in sorted(software_ids):
            sw = self.store.software.get(sw_id)
            if sw:
                result.append(
                    {
                        "id": sw.id,
                        "name": sw.name,
                        "type": sw.software_type,
                        "technique_count": len(sw.techniques),
                    }
                )
        return result

    def groups_using_software(self, software_identifier: str) -> list[str]:
        """
        Get all groups that use a specific software.

        Args:
            software_identifier: Software name, ID, or alias

        Returns:
            List of group names

        Raises:
            ValueError: If software not found
        """
        sw = self.store.get_software(software_identifier)
        if not sw:
            raise ValueError(f"Software not found: {software_identifier}")

        group_ids = self.store.software_to_groups.get(sw.id, set())
        return sorted(self.store.groups[gid].name for gid in group_ids if gid in self.store.groups)

    def software_using_technique(self, technique_id: str) -> list[dict[str, Any]]:
        """
        Get all software that uses a specific technique.

        Args:
            technique_id: Technique ID (e.g., "T1566")

        Returns:
            List of software info dictionaries
        """
        technique_id = technique_id.upper()
        software_ids = self.store.technique_to_software.get(technique_id, set())
        result = []
        for sw_id in sorted(software_ids):
            sw = self.store.software.get(sw_id)
            if sw:
                result.append(
                    {
                        "id": sw.id,
                        "name": sw.name,
                        "type": sw.software_type,
                    }
                )
        return result

    def get_mitigation_info(self, identifier: str) -> dict[str, Any]:
        """
        Get detailed information about a mitigation.

        Args:
            identifier: Mitigation ID (e.g., "M1031") or name

        Returns:
            Dictionary with mitigation info

        Raises:
            ValueError: If mitigation not found
        """
        mitigation = self.store.get_mitigation(identifier)
        if not mitigation:
            raise ValueError(f"Mitigation not found: {identifier}")

        return {
            "id": mitigation.id,
            "name": mitigation.name,
            "description": mitigation.description,
            "technique_count": len(mitigation.techniques),
        }

    def get_mitigations_for_technique(self, technique_id: str) -> list[dict[str, Any]]:
        """
        Get all mitigations that address a specific technique.

        Args:
            technique_id: Technique ID (e.g., "T1566")

        Returns:
            List of mitigation info dictionaries
        """
        technique_id = technique_id.upper()
        mitigation_ids = self.store.technique_to_mitigations.get(technique_id, set())
        result = []
        for mid in sorted(mitigation_ids):
            mitigation = self.store.mitigations.get(mid)
            if mitigation:
                result.append(
                    {
                        "id": mitigation.id,
                        "name": mitigation.name,
                    }
                )
        return result

    def get_techniques_mitigated_by(self, mitigation_identifier: str) -> set[str]:
        """
        Get all technique IDs that a mitigation addresses.

        Args:
            mitigation_identifier: Mitigation ID (e.g., "M1031") or name

        Returns:
            Set of technique IDs

        Raises:
            ValueError: If mitigation not found
        """
        mitigation = self.store.get_mitigation(mitigation_identifier)
        if not mitigation:
            raise ValueError(f"Mitigation not found: {mitigation_identifier}")
        return mitigation.techniques.copy()

    def get_group_techniques(self, group_identifier: str) -> set[str]:
        """
        Get all technique IDs used by a group.

        Args:
            group_identifier: Group name, ID, or alias

        Returns:
            Set of technique IDs (e.g., {"T1566", "T1059.001", ...})

        Raises:
            ValueError: If group not found
        """
        group = self.store.get_group(group_identifier)
        if not group:
            raise ValueError(f"Group not found: {group_identifier}")
        return group.techniques.copy()

    def get_group_tactics(self, group_identifier: str) -> set[str]:
        """
        Get all tactics used by a group (derived from their techniques).

        Args:
            group_identifier: Group name, ID, or alias

        Returns:
            Set of tactic shortnames (e.g., {"initial-access", "execution", ...})

        Raises:
            ValueError: If group not found
        """
        techniques = self.get_group_techniques(group_identifier)
        tactics: set[str] = set()
        for tech_id in techniques:
            technique = self.store.get_technique(tech_id)
            if technique:
                tactics.update(technique.tactics)
        return tactics

    def tactics_union(self, group_identifiers: list[str]) -> set[str]:
        """
        Get tactics used by ANY of the specified groups.

        Args:
            group_identifiers: List of group names, IDs, or aliases

        Returns:
            Union of tactic shortnames
        """
        result: set[str] = set()
        for identifier in group_identifiers:
            result |= self.get_group_tactics(identifier)
        return result

    def tactics_intersection(self, group_identifiers: list[str]) -> set[str]:
        """
        Get tactics used by ALL of the specified groups.

        Args:
            group_identifiers: List of group names, IDs, or aliases

        Returns:
            Intersection of tactic shortnames
        """
        if not group_identifiers:
            return set()

        result = self.get_group_tactics(group_identifiers[0])
        for identifier in group_identifiers[1:]:
            result &= self.get_group_tactics(identifier)
        return result

    def tactics_complement(self, group_identifiers: list[str]) -> set[str]:
        """
        Get tactics NOT used by any of the specified groups.

        Args:
            group_identifiers: List of group names, IDs, or aliases

        Returns:
            Set of tactic shortnames not used by any of the groups
        """
        # Get all tactics
        all_tactics = {t.shortname for t in self.store.tactics.values()}

        # Get tactics used by the groups (union)
        used_tactics = self.tactics_union(group_identifiers)

        # Return complement
        return all_tactics - used_tactics

    def techniques_union(self, group_identifiers: list[str]) -> set[str]:
        """
        Get techniques used by ANY of the specified groups.

        Args:
            group_identifiers: List of group names, IDs, or aliases

        Returns:
            Union of technique IDs
        """
        result: set[str] = set()
        for identifier in group_identifiers:
            result |= self.get_group_techniques(identifier)
        return result

    def techniques_intersection(self, group_identifiers: list[str]) -> set[str]:
        """
        Get techniques used by ALL of the specified groups.

        Args:
            group_identifiers: List of group names, IDs, or aliases

        Returns:
            Intersection of technique IDs
        """
        if not group_identifiers:
            return set()

        result = self.get_group_techniques(group_identifiers[0])
        for identifier in group_identifiers[1:]:
            result &= self.get_group_techniques(identifier)
        return result

    def techniques_difference(
        self,
        include_groups: list[str],
        exclude_groups: list[str],
    ) -> set[str]:
        """
        Get techniques used by include_groups but NOT by exclude_groups.

        This is the core operation for queries like:
        "techniques used by APT28 and APT29 but not APT33"

        Args:
            include_groups: Groups whose techniques to include (union)
            exclude_groups: Groups whose techniques to exclude

        Returns:
            Set difference of technique IDs
        """
        include_techniques = self.techniques_union(include_groups)
        exclude_techniques = self.techniques_union(exclude_groups)
        return include_techniques - exclude_techniques

    def techniques_exclusive_intersection(
        self,
        include_groups: list[str],
        exclude_groups: list[str],
    ) -> set[str]:
        """
        Get techniques used by ALL include_groups but NONE of exclude_groups.

        More restrictive than techniques_difference - requires ALL include groups
        to use the technique.

        Args:
            include_groups: All must use the technique
            exclude_groups: None may use the technique

        Returns:
            Filtered intersection of technique IDs
        """
        include_techniques = self.techniques_intersection(include_groups)
        exclude_techniques = self.techniques_union(exclude_groups)
        return include_techniques - exclude_techniques

    def techniques_complement(self, group_identifiers: list[str]) -> set[str]:
        """
        Get all techniques NOT used by any of the specified groups.

        This is the complement operation: returns techniques from the entire
        ATT&CK database that none of the specified groups use.

        Args:
            group_identifiers: List of group names, IDs, or aliases

        Returns:
            Set of technique IDs not used by any of the groups
        """
        all_techniques = set(self.store.techniques.keys())
        used_techniques = self.techniques_union(group_identifiers)
        return all_techniques - used_techniques

    def groups_using_technique(self, technique_id: str) -> list[str]:
        """
        Get all groups that use a specific technique.

        Args:
            technique_id: Technique ID (e.g., "T1566")

        Returns:
            List of group names
        """
        technique_id = technique_id.upper()
        group_ids = self.store.technique_to_groups.get(technique_id, set())
        return [self.store.groups[gid].name for gid in group_ids if gid in self.store.groups]

    def get_subtechniques_of(self, parent_id: str) -> set[str]:
        """
        Get all sub-technique IDs for a parent technique.

        Args:
            parent_id: Parent technique ID (e.g., "T1566")

        Returns:
            Set of sub-technique IDs (e.g., {"T1566.001", "T1566.002", ...})

        Raises:
            ValueError: If parent technique not found or is itself a sub-technique
        """
        parent_id = parent_id.upper()
        parent = self.store.get_technique(parent_id)
        if not parent:
            raise ValueError(f"Technique not found: {parent_id}")
        if parent.is_subtechnique:
            raise ValueError(f"{parent_id} is a sub-technique, not a parent")

        return set(self.store.subtechniques_by_parent.get(parent_id, set()))

    def get_parent_of(self, subtechnique_id: str) -> str:
        """
        Get the parent technique ID for a sub-technique.

        Args:
            subtechnique_id: Sub-technique ID (e.g., "T1566.001")

        Returns:
            Parent technique ID (e.g., "T1566")

        Raises:
            ValueError: If sub-technique not found or has no parent
        """
        subtechnique_id = subtechnique_id.upper()
        technique = self.store.get_technique(subtechnique_id)
        if not technique:
            raise ValueError(f"Technique not found: {subtechnique_id}")
        if not technique.is_subtechnique or not technique.parent_id:
            raise ValueError(f"{subtechnique_id} is not a sub-technique")

        return technique.parent_id

    def group_techniques_hierarchically(
        self,
        technique_ids: set[str],
    ) -> dict[str, list[str]]:
        """
        Group technique IDs hierarchically: parent -> [subtechniques].

        Techniques without sub-techniques appear with empty lists.
        Sub-techniques are grouped under their parent key.

        Args:
            technique_ids: Set of technique IDs (mix of parents and sub-techniques)

        Returns:
            Dict mapping parent_id -> list of matching subtechnique_ids
            Standalone techniques map to empty list
        """
        hierarchy: dict[str, list[str]] = {}

        for tid in sorted(technique_ids):
            technique = self.store.get_technique(tid)
            if not technique:
                continue

            if technique.is_subtechnique and technique.parent_id:
                # It's a sub-technique - add under parent
                if technique.parent_id not in hierarchy:
                    hierarchy[technique.parent_id] = []
                hierarchy[technique.parent_id].append(tid)
            else:
                # It's a parent technique
                if tid not in hierarchy:
                    hierarchy[tid] = []

        return hierarchy

    def compare_groups(
        self,
        group1: str,
        group2: str,
    ) -> dict[str, Any]:
        """
        Compare techniques between two groups.

        Args:
            group1: First group identifier
            group2: Second group identifier

        Returns:
            Dictionary with shared, unique_to_first, unique_to_second technique sets
        """
        techs1 = self.get_group_techniques(group1)
        techs2 = self.get_group_techniques(group2)

        g1 = self.store.get_group(group1)
        g2 = self.store.get_group(group2)

        return {
            "group1": g1.name if g1 else group1,
            "group2": g2.name if g2 else group2,
            "group1_total": len(techs1),
            "group2_total": len(techs2),
            "shared": techs1 & techs2,
            "unique_to_first": techs1 - techs2,
            "unique_to_second": techs2 - techs1,
            "jaccard_similarity": (
                len(techs1 & techs2) / len(techs1 | techs2) if techs1 | techs2 else 0
            ),
        }

    def calculate_group_similarity(
        self,
        group1: str,
        group2: str,
    ) -> dict[str, Any]:
        """
        Calculate multiple similarity metrics between two groups.

        Metrics:
        - Jaccard: |A ∩ B| / |A ∪ B| (symmetric, good for overall similarity)
        - Overlap: |A ∩ B| / min(|A|, |B|) (good when one group is subset)
        - Cosine: dot(A,B) / (||A|| * ||B||) (treats techniques as binary vectors)

        Args:
            group1: First group identifier
            group2: Second group identifier

        Returns:
            Dictionary with similarity metrics and shared techniques

        Raises:
            ValueError: If either group not found
        """
        g1 = self.store.get_group(group1)
        g2 = self.store.get_group(group2)

        if not g1:
            raise ValueError(f"Group not found: {group1}")
        if not g2:
            raise ValueError(f"Group not found: {group2}")

        techs1 = g1.techniques
        techs2 = g2.techniques

        intersection = len(techs1 & techs2)
        union = len(techs1 | techs2)
        min_size = min(len(techs1), len(techs2))

        # Calculate metrics
        jaccard = intersection / union if union > 0 else 0.0
        overlap = intersection / min_size if min_size > 0 else 0.0

        # Cosine similarity (binary vectors)
        # For binary vectors: cos = |A ∩ B| / sqrt(|A| * |B|)
        cosine = (
            intersection / math.sqrt(len(techs1) * len(techs2))
            if len(techs1) > 0 and len(techs2) > 0
            else 0.0
        )

        return {
            "group1": g1.name,
            "group1_id": g1.id,
            "group2": g2.name,
            "group2_id": g2.id,
            "group1_technique_count": len(techs1),
            "group2_technique_count": len(techs2),
            "shared_count": intersection,
            "shared_techniques": sorted(techs1 & techs2),
            "jaccard": round(jaccard, 4),
            "overlap": round(overlap, 4),
            "cosine": round(cosine, 4),
        }

    def find_similar_groups(
        self,
        group_identifier: str,
        threshold: float = 0.0,
        limit: int = 10,
        metric: str = "jaccard",
    ) -> list[dict[str, Any]]:
        """
        Find groups with similar technique profiles.

        Args:
            group_identifier: Group to find similar groups for
            threshold: Minimum similarity score (0.0 to 1.0)
            limit: Maximum number of results to return
            metric: Similarity metric to use ("jaccard", "overlap", "cosine")

        Returns:
            List of similar groups with similarity scores, sorted by score descending

        Raises:
            ValueError: If group not found or invalid metric
        """
        target_group = self.store.get_group(group_identifier)
        if not target_group:
            raise ValueError(f"Group not found: {group_identifier}")

        valid_metrics = ("jaccard", "overlap", "cosine")
        if metric not in valid_metrics:
            raise ValueError(f"Invalid metric: {metric}. Use one of: {valid_metrics}")

        target_techniques = target_group.techniques
        if not target_techniques:
            return []

        results = []

        for group in self.store.groups.values():
            # Skip comparing to self
            if group.id == target_group.id:
                continue

            other_techniques = group.techniques
            if not other_techniques:
                continue

            intersection = len(target_techniques & other_techniques)
            if intersection == 0:
                continue  # No overlap

            # Calculate the requested metric
            if metric == "jaccard":
                union = len(target_techniques | other_techniques)
                score = intersection / union if union > 0 else 0.0
            elif metric == "overlap":
                min_size = min(len(target_techniques), len(other_techniques))
                score = intersection / min_size if min_size > 0 else 0.0
            else:  # cosine
                score = (
                    intersection / math.sqrt(len(target_techniques) * len(other_techniques))
                    if len(target_techniques) > 0 and len(other_techniques) > 0
                    else 0.0
                )

            if score >= threshold:
                results.append(
                    {
                        "group": group.name,
                        "group_id": group.id,
                        "similarity": round(score, 4),
                        "shared_count": intersection,
                        "technique_count": len(other_techniques),
                    }
                )

        # Sort by similarity descending, then by name
        def sort_key(x: dict[str, Any]) -> tuple[float, str]:
            return (-x["similarity"], x["group"])

        results.sort(key=sort_key)

        return results[:limit]

    def get_techniques_by_tactic(
        self,
        tactic_identifier: str,
        technique_ids: set[str] | None = None,
    ) -> set[str]:
        """
        Filter techniques by tactic.

        Args:
            tactic_identifier: Tactic ID or shortname
            technique_ids: Optional set to filter; if None, searches all techniques

        Returns:
            Set of technique IDs that belong to the tactic
        """
        tactic = self.store.get_tactic(tactic_identifier)
        if not tactic:
            raise ValueError(f"Tactic not found: {tactic_identifier}")

        source = technique_ids if technique_ids else set(self.store.techniques.keys())
        return {
            tid
            for tid in source
            if tid in self.store.techniques
            and tactic.shortname in self.store.techniques[tid].tactics
        }

    def get_technique_coverage_by_tactic(
        self,
        technique_ids: set[str],
    ) -> dict[str, list[str]]:
        """
        Group techniques by their tactics.

        Args:
            technique_ids: Set of technique IDs to categorize

        Returns:
            Dictionary mapping tactic names to lists of technique IDs
        """
        coverage: dict[str, list[str]] = {}

        for tactic in self.store.tactics.values():
            matching = [
                tid
                for tid in technique_ids
                if tid in self.store.techniques
                and tactic.shortname in self.store.techniques[tid].tactics
            ]
            if matching:
                coverage[tactic.name] = sorted(matching)

        return coverage

    def export_navigator_layer(
        self,
        technique_ids: set[str],
        name: str = "ATT&CK Query Results",
        description: str = "",
        color: str = "#ff6666",
    ) -> dict[str, Any]:
        """
        Export techniques as an ATT&CK Navigator layer.

        Args:
            technique_ids: Set of technique IDs to highlight
            name: Layer name
            description: Layer description
            color: Highlight color (hex)

        Returns:
            Navigator layer JSON structure
        """
        techniques_list = []

        for tid in technique_ids:
            technique = self.store.get_technique(tid)
            if technique:
                tech_entry: dict[str, Any] = {
                    "techniqueID": tid,
                    "color": color,
                    "comment": technique.name,
                    "enabled": True,
                    "showSubtechniques": False,
                }

                # Handle sub-techniques
                if technique.is_subtechnique and technique.parent_id:
                    tech_entry["tactic"] = technique.tactics[0] if technique.tactics else ""

                techniques_list.append(tech_entry)

        layer: dict[str, Any] = {
            "name": name,
            "versions": {
                "attack": self.store.version or "latest",
                "navigator": "4.5",
                "layer": "4.5",
            },
            "domain": "enterprise-attack",
            "description": description,
            "filters": {"platforms": ["Windows", "Linux", "macOS", "Cloud", "Network"]},
            "sorting": 0,
            "layout": {
                "layout": "side",
                "showID": True,
                "showName": True,
            },
            "hideDisabled": False,
            "techniques": techniques_list,
            "gradient": {
                "colors": ["#ffffff", color],
                "minValue": 0,
                "maxValue": 1,
            },
            "legendItems": [{"label": "Matching Techniques", "color": color}],
            "showTacticRowBackground": True,
            "tacticRowBackground": "#dddddd",
        }

        return layer

    def export_heatmap_layer(
        self,
        group_identifiers: list[str],
        name: str = "Technique Overlap Heatmap",
    ) -> dict[str, Any]:
        """
        Export a heatmap layer showing technique overlap across groups.

        Args:
            group_identifiers: List of group names/IDs to include
            name: Layer name

        Returns:
            Navigator layer with gradient coloring based on group overlap
        """
        # Count how many groups use each technique
        technique_counts: dict[str, int] = {}

        for identifier in group_identifiers:
            try:
                techniques = self.get_group_techniques(identifier)
                for tid in techniques:
                    technique_counts[tid] = technique_counts.get(tid, 0) + 1
            except ValueError:
                continue

        max_count = max(technique_counts.values()) if technique_counts else 1
        techniques_list = []

        for tid, count in technique_counts.items():
            technique = self.store.get_technique(tid)
            if technique:
                # Calculate color intensity based on overlap
                intensity = count / max_count
                r = int(255 * (1 - intensity * 0.6))
                g = int(255 * (1 - intensity * 0.8))
                b = int(255 * (1 - intensity * 0.2))
                color = f"#{r:02x}{g:02x}{b:02x}"

                techniques_list.append(
                    {
                        "techniqueID": tid,
                        "color": color,
                        "score": count,
                        "comment": f"Used by {count}/{len(group_identifiers)} groups",
                        "enabled": True,
                    }
                )

        return {
            "name": name,
            "versions": {
                "attack": self.store.version or "latest",
                "navigator": "4.5",
                "layer": "4.5",
            },
            "domain": "enterprise-attack",
            "description": f"Overlap heatmap for: {', '.join(group_identifiers)}",
            "filters": {"platforms": ["Windows", "Linux", "macOS", "Cloud", "Network"]},
            "sorting": 3,  # Sort by score descending
            "layout": {
                "layout": "side",
                "showID": True,
                "showName": True,
            },
            "hideDisabled": False,
            "techniques": techniques_list,
            "gradient": {
                "colors": ["#ffffff", "#ff0000"],
                "minValue": 0,
                "maxValue": max_count,
            },
            "legendItems": [
                {"label": "1 group", "color": "#ffcccc"},
                {"label": f"{max_count} groups", "color": "#ff0000"},
            ],
            "showTacticRowBackground": True,
            "tacticRowBackground": "#dddddd",
        }

    def get_data_source_info(self, identifier: str) -> dict[str, Any]:
        """
        Get detailed information about a data source.

        Args:
            identifier: Data source ID (e.g., "DS0014") or name (e.g., "Pod")

        Returns:
            Dictionary with data source info

        Raises:
            ValueError: If data source not found
        """
        ds = self.store.get_data_source(identifier)
        if not ds:
            raise ValueError(f"Data source not found: {identifier}")

        return {
            "id": ds.id,
            "name": ds.name,
            "description": ds.description,
            "platforms": ds.platforms,
            "collection_layers": ds.collection_layers,
        }

    def get_data_component_info(self, identifier: str) -> dict[str, Any]:
        """
        Get detailed information about a data component.

        Args:
            identifier: Data component ID (e.g., "DC0084") or
                       name (e.g., "Active Directory Credential Request")

        Returns:
            Dictionary with data component info including log sources and technique count

        Raises:
            ValueError: If data component not found
        """
        dc = self.store.get_data_component(identifier)
        if not dc:
            raise ValueError(f"Data component not found: {identifier}")

        return {
            "id": dc.id,
            "name": dc.name,
            "description": dc.description,
            "log_sources": dc.log_sources,
            "technique_count": len(dc.techniques),
        }

    def get_techniques_detectable_by(self, data_component_identifier: str) -> set[str]:
        """
        Get all technique IDs detectable via a data component.

        Args:
            data_component_identifier: Data component ID or name

        Returns:
            Set of technique IDs

        Raises:
            ValueError: If data component not found
        """
        dc = self.store.get_data_component(data_component_identifier)
        if not dc:
            raise ValueError(f"Data component not found: {data_component_identifier}")
        return dc.techniques.copy()

    def get_campaign_info(self, identifier: str) -> dict[str, Any]:
        """
        Get detailed information about a campaign.

        Args:
            identifier: Campaign ID (e.g., "C0027") or name

        Returns:
            Dictionary with campaign info

        Raises:
            ValueError: If campaign not found
        """
        campaign = self.store.get_campaign(identifier)
        if not campaign:
            raise ValueError(f"Campaign not found: {identifier}")

        # Get group names
        group_names = [
            self.store.groups[gid].name for gid in campaign.groups if gid in self.store.groups
        ]

        return {
            "id": campaign.id,
            "name": campaign.name,
            "description": campaign.description,
            "aliases": campaign.aliases,
            "first_seen": campaign.first_seen,
            "last_seen": campaign.last_seen,
            "technique_count": len(campaign.techniques),
            "software_count": len(campaign.software),
            "groups": sorted(group_names),
        }

    def get_group_campaigns(self, group_identifier: str) -> list[dict[str, Any]]:
        """
        Get all campaigns attributed to a group.

        Args:
            group_identifier: Group name, ID, or alias

        Returns:
            List of campaign info dictionaries

        Raises:
            ValueError: If group not found
        """
        group = self.store.get_group(group_identifier)
        if not group:
            raise ValueError(f"Group not found: {group_identifier}")

        campaign_ids = self.store.group_to_campaigns.get(group.id, set())
        result = []
        for cid in sorted(campaign_ids):
            campaign = self.store.campaigns.get(cid)
            if campaign:
                result.append(
                    {
                        "id": campaign.id,
                        "name": campaign.name,
                        "first_seen": campaign.first_seen,
                        "last_seen": campaign.last_seen,
                        "technique_count": len(campaign.techniques),
                    }
                )
        return result

    def get_campaign_techniques(self, campaign_identifier: str) -> set[str]:
        """
        Get all technique IDs used in a campaign.

        Args:
            campaign_identifier: Campaign ID or name

        Returns:
            Set of technique IDs

        Raises:
            ValueError: If campaign not found
        """
        campaign = self.store.get_campaign(campaign_identifier)
        if not campaign:
            raise ValueError(f"Campaign not found: {campaign_identifier}")
        return campaign.techniques.copy()

    def _campaign_active_in_year(self, campaign: Any, year: int) -> bool:
        """
        Check if a campaign was active during a specific year.

        A campaign is considered active if its timeframe overlaps with the year.

        Args:
            campaign: Campaign object with first_seen/last_seen fields
            year: Year to check (e.g., 2023)

        Returns:
            True if campaign was active during the year
        """
        year_start = f"{year}-01-01"
        year_end = f"{year}-12-31"

        # Extract just the date portion (YYYY-MM-DD) from ISO strings
        first_seen = campaign.first_seen[:10] if campaign.first_seen else None
        last_seen = campaign.last_seen[:10] if campaign.last_seen else None

        # Campaign must have started before year end
        if first_seen and first_seen > year_end:
            return False

        # Campaign must have ended after year start (or still ongoing)
        return not (last_seen and last_seen < year_start)

    def _campaign_active_in_range(self, campaign: Any, start_year: int, end_year: int) -> bool:
        """
        Check if a campaign was active during a year range.

        Args:
            campaign: Campaign object with first_seen/last_seen fields
            start_year: Start year (inclusive)
            end_year: End year (inclusive)

        Returns:
            True if campaign was active during any part of the range
        """
        range_start = f"{start_year}-01-01"
        range_end = f"{end_year}-12-31"

        first_seen = campaign.first_seen[:10] if campaign.first_seen else None
        last_seen = campaign.last_seen[:10] if campaign.last_seen else None

        # Campaign must have started before range end
        if first_seen and first_seen > range_end:
            return False

        # Campaign must have ended after range start (or still ongoing)
        return not (last_seen and last_seen < range_start)

    def get_campaigns_in_year(self, year: int) -> list[dict[str, Any]]:
        """
        Get all campaigns active during a specific year.

        Args:
            year: Year to filter by (e.g., 2023)

        Returns:
            List of campaign info dictionaries sorted by first_seen date
        """
        result = []
        for campaign in self.store.campaigns.values():
            if self._campaign_active_in_year(campaign, year):
                result.append(
                    {
                        "id": campaign.id,
                        "name": campaign.name,
                        "first_seen": campaign.first_seen,
                        "last_seen": campaign.last_seen,
                        "technique_count": len(campaign.techniques),
                    }
                )

        # Sort by first_seen date
        return sorted(result, key=lambda c: c.get("first_seen") or "")

    def get_campaigns_in_range(self, start_year: int, end_year: int) -> list[dict[str, Any]]:
        """
        Get all campaigns active during a year range.

        Args:
            start_year: Start year (inclusive)
            end_year: End year (inclusive)

        Returns:
            List of campaign info dictionaries sorted by first_seen date
        """
        result = []
        for campaign in self.store.campaigns.values():
            if self._campaign_active_in_range(campaign, start_year, end_year):
                result.append(
                    {
                        "id": campaign.id,
                        "name": campaign.name,
                        "first_seen": campaign.first_seen,
                        "last_seen": campaign.last_seen,
                        "technique_count": len(campaign.techniques),
                    }
                )

        return sorted(result, key=lambda c: c.get("first_seen") or "")

    def get_techniques_in_year(self, year: int) -> set[str]:
        """
        Get all techniques used in campaigns active during a specific year.

        Args:
            year: Year to filter by (e.g., 2023)

        Returns:
            Set of technique IDs
        """
        techniques: set[str] = set()
        for campaign in self.store.campaigns.values():
            if self._campaign_active_in_year(campaign, year):
                techniques |= campaign.techniques
        return techniques

    def get_techniques_in_range(self, start_year: int, end_year: int) -> set[str]:
        """
        Get all techniques used in campaigns active during a year range.

        Args:
            start_year: Start year (inclusive)
            end_year: End year (inclusive)

        Returns:
            Set of technique IDs
        """
        techniques: set[str] = set()
        for campaign in self.store.campaigns.values():
            if self._campaign_active_in_range(campaign, start_year, end_year):
                techniques |= campaign.techniques
        return techniques

    def export_csv(
        self,
        technique_ids: set[str],
        include_description: bool = False,
    ) -> str:
        """
        Export techniques as CSV format.

        Args:
            technique_ids: Set of technique IDs to export
            include_description: Whether to include technique descriptions

        Returns:
            CSV string with headers: id,name,tactics[,description]
        """
        output = io.StringIO()
        fieldnames = ["id", "name", "tactics"]
        if include_description:
            fieldnames.append("description")

        writer = csv.DictWriter(output, fieldnames=fieldnames, quoting=csv.QUOTE_MINIMAL)
        writer.writeheader()

        for tid in sorted(technique_ids):
            technique = self.store.get_technique(tid)
            if technique:
                row: dict[str, str] = {
                    "id": technique.id,
                    "name": technique.name,
                    "tactics": ",".join(technique.tactics),
                }
                if include_description:
                    row["description"] = technique.description
                writer.writerow(row)

        return output.getvalue()

    def export_markdown(
        self,
        technique_ids: set[str],
        title: str = "Query Results",
    ) -> str:
        """
        Export techniques as Markdown table format.

        Args:
            technique_ids: Set of technique IDs to export
            title: Title for the markdown section

        Returns:
            Markdown string with table
        """
        lines = [f"## {title}", "", "| ID | Name | Tactics |", "|-------|------|---------|"]

        for tid in sorted(technique_ids):
            technique = self.store.get_technique(tid)
            if technique:
                tactics = ", ".join(technique.tactics)
                # Escape pipe characters in name
                name = technique.name.replace("|", "\\|")
                lines.append(f"| {technique.id} | {name} | {tactics} |")

        lines.append("")  # Trailing newline
        return "\n".join(lines)
