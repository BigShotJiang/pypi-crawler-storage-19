"""ATT&CK data store for loading and indexing STIX data."""

from __future__ import annotations

import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import requests

from attack_query.models import (
    Campaign,
    DataComponent,
    DataSource,
    Group,
    Matrix,
    Mitigation,
    Software,
    Tactic,
    Technique,
)

if TYPE_CHECKING:
    pass


class ATTACKDataStore:
    """
    Stores and indexes MITRE ATT&CK data for efficient querying.

    Supports specific ATT&CK versions (e.g., "12.0", "15.1", "18.0") and
    different matrices (enterprise, mobile, ics).

    See https://github.com/mitre-attack/attack-stix-data/releases for available versions.
    """

    BASE_URL = "https://raw.githubusercontent.com/mitre-attack/attack-stix-data/master"
    CACHE_DIR = Path.home() / ".cache" / "attack"
    CACHE_MAX_AGE_DAYS = 7

    # Known ATT&CK versions (subset - more exist)
    KNOWN_VERSIONS: list[str] = [
        "18.1",
        "18.0",
        "17.1",
        "17.0",
        "16.1",
        "16.0",
        "15.1",
        "15.0",
        "14.1",
        "14.0",
        "13.1",
        "13.0",
        "12.1",
        "12.0",
        "11.3",
        "11.2",
        "11.1",
        "11.0",
        "10.1",
        "10.0",
        "9.0",
        "8.2",
        "8.1",
        "8.0",
        "7.2",
        "7.1",
        "7.0",
        "6.3",
        "6.2",
        "6.1",
        "6.0",
        "5.2",
        "5.1",
        "5.0",
        "4.0",
        "3.0",
        "2.0",
        "1.0",
    ]

    def __init__(
        self,
        data_file: Path | None = None,
        version: str | None = None,
        matrix: Matrix | str = Matrix.ENTERPRISE,
        quiet: bool = False,
    ) -> None:
        """
        Initialize the ATT&CK data store.

        Args:
            data_file: Path to a local STIX JSON file (overrides version/matrix)
            version: ATT&CK version to use (e.g., "12.0", "15.1", "18.0")
                     If None, uses the latest version.
            matrix: ATT&CK matrix to use (enterprise, mobile, ics).
                    Default is enterprise.
            quiet: Suppress progress messages
        """
        # Parse matrix if string
        if isinstance(matrix, str):
            matrix = Matrix.from_string(matrix)
        self._matrix = matrix
        self.techniques: dict[str, Technique] = {}  # technique_id -> Technique
        self.techniques_by_stix: dict[str, Technique] = {}  # stix_id -> Technique
        self.groups: dict[str, Group] = {}  # group_id -> Group
        self.groups_by_name: dict[str, Group] = {}  # name (lowercase) -> Group
        self.groups_by_alias: dict[str, Group] = {}  # alias (lowercase) -> Group
        self.tactics: dict[str, Tactic] = {}  # tactic_id -> Tactic
        self.tactics_by_shortname: dict[str, Tactic] = {}  # shortname -> Tactic
        self.software: dict[str, Software] = {}  # software_id -> Software
        self.software_by_name: dict[str, Software] = {}  # name (lowercase) -> Software
        self.software_by_alias: dict[str, Software] = {}  # alias (lowercase) -> Software
        self.software_by_stix: dict[str, Software] = {}  # stix_id -> Software
        self.mitigations: dict[str, Mitigation] = {}  # mitigation_id -> Mitigation
        self.mitigations_by_name: dict[str, Mitigation] = {}  # name (lowercase) -> Mitigation
        self.mitigations_by_stix: dict[str, Mitigation] = {}  # stix_id -> Mitigation
        self.data_sources: dict[str, DataSource] = {}  # data_source_id -> DataSource
        self.data_sources_by_name: dict[str, DataSource] = {}  # name (lowercase) -> DataSource
        self.data_components: dict[str, DataComponent] = {}  # data_component_id -> DataComponent
        self.data_components_by_name: dict[
            str, DataComponent
        ] = {}  # name (lowercase) -> DataComponent
        self.data_components_by_stix: dict[str, DataComponent] = {}  # stix_id -> DataComponent
        self.campaigns: dict[str, Campaign] = {}  # campaign_id -> Campaign
        self.campaigns_by_name: dict[str, Campaign] = {}  # name (lowercase) -> Campaign
        self.campaigns_by_stix: dict[str, Campaign] = {}  # stix_id -> Campaign
        self.technique_to_groups: dict[str, set[str]] = defaultdict(set)
        self.technique_to_software: dict[str, set[str]] = defaultdict(set)
        self.technique_to_mitigations: dict[str, set[str]] = defaultdict(set)
        self.technique_to_campaigns: dict[str, set[str]] = defaultdict(set)
        self.group_to_software: dict[str, set[str]] = defaultdict(set)
        self.group_to_campaigns: dict[str, set[str]] = defaultdict(set)
        self.software_to_groups: dict[str, set[str]] = defaultdict(set)
        self.subtechniques_by_parent: dict[str, set[str]] = defaultdict(set)

        self._loaded = False
        self._data_file = data_file
        self._version = version
        self._loaded_version: str | None = None
        self._quiet = quiet

    @property
    def version(self) -> str | None:
        """Return the loaded ATT&CK version."""
        return self._loaded_version

    @property
    def matrix(self) -> Matrix:
        """Return the ATT&CK matrix being used."""
        return self._matrix

    def _log(self, message: str) -> None:
        """Print message unless quiet mode is enabled."""
        if not self._quiet:
            print(message)

    def _get_url_for_version(self, version: str | None = None) -> str:
        """Get the download URL for a specific version and matrix."""
        stix_name = self._matrix.stix_name  # e.g., "enterprise-attack"
        if version:
            return f"{self.BASE_URL}/{stix_name}/{stix_name}-{version}.json"
        return f"{self.BASE_URL}/{stix_name}/{stix_name}.json"

    def _get_cache_file(self, version: str | None = None) -> Path:
        """Get the cache file path for a specific version and matrix."""
        stix_name = self._matrix.stix_name  # e.g., "enterprise-attack"
        if version:
            return self.CACHE_DIR / f"{stix_name}-{version}.json"
        return self.CACHE_DIR / f"{stix_name}-latest.json"

    @classmethod
    def list_versions(cls) -> list[str]:
        """Return list of known ATT&CK versions."""
        return cls.KNOWN_VERSIONS.copy()

    def load(self, force_refresh: bool = False) -> None:
        """Load ATT&CK data from cache or download fresh."""
        if self._loaded and not force_refresh:
            return

        try:
            data = self._get_data(force_refresh)
            self._parse_data(data)
            self._loaded = True

            version_str = f"v{self._loaded_version}" if self._loaded_version else "latest"
            matrix_str = self._matrix.display_name
            self._log(
                f"Loaded ATT&CK {matrix_str} ({version_str}): {len(self.techniques)} techniques, "
                f"{len(self.groups)} groups, {len(self.campaigns)} campaigns, "
                f"{len(self.software)} software, {len(self.mitigations)} mitigations, "
                f"{len(self.data_sources)} data sources, {len(self.data_components)} data components, "
                f"{len(self.tactics)} tactics"
            )
        except Exception as e:
            stix_name = self._matrix.stix_name
            print(f"\n❌ Failed to load ATT&CK data: {e}")
            print("\nTo use offline, download the data file manually:")
            print(f"  curl -o {stix_name}.json {self._get_url_for_version(self._version)}")
            print(f"  attack-query --data-file {stix_name}.json")
            print("\nAvailable versions: " + ", ".join(self.KNOWN_VERSIONS[:10]) + "...")
            raise SystemExit(1) from e

    def _get_data(self, force_refresh: bool = False) -> dict[str, Any]:
        """Get ATT&CK data from cache, custom file, or download."""
        # Option 1: Use custom data file if provided
        if self._data_file and self._data_file.exists():
            self._log(f"Loading from file: {self._data_file}")
            with open(self._data_file) as f:
                data: dict[str, Any] = json.load(f)
            self._loaded_version = self._extract_version(data)
            return data

        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache_file = self._get_cache_file(self._version)

        # Option 2: Check cache
        if not force_refresh and cache_file.exists():
            cache_age = datetime.now().timestamp() - cache_file.stat().st_mtime
            # Versioned files never expire (immutable), latest expires after CACHE_MAX_AGE_DAYS
            if self._version or cache_age < self.CACHE_MAX_AGE_DAYS * 86400:
                self._log(f"Loading from cache: {cache_file}")
                with open(cache_file) as f:
                    data = json.load(f)
                self._loaded_version = self._version or self._extract_version(data)
                return data
            self._log(f"Cache is {int(cache_age / 86400)} days old, refreshing...")

        # Option 3: Download
        url = self._get_url_for_version(self._version)
        version_str = f"v{self._version}" if self._version else "latest"
        matrix_str = self._matrix.display_name
        self._log(f"Downloading ATT&CK {matrix_str} ({version_str}) from {url}...")

        response = requests.get(url, timeout=60)
        response.raise_for_status()
        data = response.json()

        # Cache it
        with open(cache_file, "w") as f:
            json.dump(data, f)
        self._log(f"Cached to: {cache_file}")

        self._loaded_version = self._version or self._extract_version(data)
        return data

    def _extract_version(self, data: dict[str, Any]) -> str | None:
        """Extract ATT&CK version from STIX bundle metadata."""
        for obj in data.get("objects", []):
            if obj.get("type") == "x-mitre-collection":
                version: str | None = obj.get("x_mitre_version")
                return version
        return None

    def _parse_data(self, data: dict[str, Any]) -> None:
        """Parse STIX bundle and build indexes."""
        objects = data.get("objects", [])

        # First pass: extract techniques, groups, tactics, software, mitigations
        for obj in objects:
            obj_type = obj.get("type")

            if obj_type == "attack-pattern" and not obj.get("revoked", False):
                self._parse_technique(obj)
            elif obj_type == "intrusion-set" and not obj.get("revoked", False):
                self._parse_group(obj)
            elif obj_type == "x-mitre-tactic" and not obj.get("revoked", False):
                self._parse_tactic(obj)
            elif obj_type in ("malware", "tool") and not obj.get("revoked", False):
                self._parse_software(obj)
            elif obj_type == "course-of-action" and not obj.get("revoked", False):
                self._parse_mitigation(obj)
            elif obj_type == "x-mitre-data-source":
                # Data sources may be deprecated but still parse them for queries
                self._parse_data_source(obj)
            elif obj_type == "x-mitre-data-component" and not obj.get("revoked", False):
                self._parse_data_component(obj)
            elif obj_type == "campaign" and not obj.get("revoked", False):
                self._parse_campaign(obj)

        # Second pass: extract relationships
        for obj in objects:
            if obj.get("type") == "relationship":
                rel_type = obj.get("relationship_type")
                if rel_type == "uses":
                    self._parse_relationship(obj)
                elif rel_type == "mitigates":
                    self._parse_mitigation_relationship(obj)
                elif rel_type == "attributed-to":
                    self._parse_campaign_attribution(obj)

        # Third pass: build data component -> technique index via detection strategies
        self._build_detection_mappings(objects)

    def _parse_technique(self, obj: dict[str, Any]) -> None:
        """Parse a technique object from STIX."""
        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        kill_chain_phases = obj.get("kill_chain_phases", [])
        tactics = [
            phase.get("phase_name")
            for phase in kill_chain_phases
            if phase.get("kill_chain_name") == "mitre-attack"
        ]

        is_subtechnique = obj.get("x_mitre_is_subtechnique", False)
        parent_id = None
        if is_subtechnique and "." in attack_id:
            parent_id = attack_id.split(".")[0]

        technique = Technique(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=obj.get("name", ""),
            description=obj.get("description", ""),
            tactics=tactics,
            platforms=obj.get("x_mitre_platforms", []),
            is_subtechnique=is_subtechnique,
            parent_id=parent_id,
        )

        self.techniques[attack_id] = technique
        self.techniques_by_stix[obj.get("id", "")] = technique

        # Build subtechnique index
        if technique.is_subtechnique and technique.parent_id:
            self.subtechniques_by_parent[technique.parent_id].add(technique.id)

    def _parse_group(self, obj: dict[str, Any]) -> None:
        """Parse a group (intrusion-set) object from STIX."""
        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        aliases = obj.get("aliases", [])
        name = obj.get("name", "")

        group = Group(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=name,
            description=obj.get("description", ""),
            aliases=aliases,
        )

        self.groups[attack_id] = group
        self.groups_by_name[name.lower()] = group

        # Index by all aliases
        for alias in aliases:
            self.groups_by_alias[alias.lower()] = group

    def _parse_tactic(self, obj: dict[str, Any]) -> None:
        """Parse a tactic object from STIX."""
        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        shortname = obj.get("x_mitre_shortname", "")

        tactic = Tactic(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=obj.get("name", ""),
            shortname=shortname,
            description=obj.get("description", ""),
        )

        self.tactics[attack_id] = tactic
        self.tactics_by_shortname[shortname] = tactic

    def _parse_software(self, obj: dict[str, Any]) -> None:
        """Parse a software (malware or tool) object from STIX."""
        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        aliases = obj.get("x_mitre_aliases", [])
        name = obj.get("name", "")
        software_type = obj.get("type", "malware")  # "malware" or "tool"

        sw = Software(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=name,
            description=obj.get("description", ""),
            software_type=software_type,
            aliases=aliases,
            platforms=obj.get("x_mitre_platforms", []),
        )

        self.software[attack_id] = sw
        self.software_by_name[name.lower()] = sw
        self.software_by_stix[obj.get("id", "")] = sw

        # Index by all aliases
        for alias in aliases:
            self.software_by_alias[alias.lower()] = sw

    def _parse_mitigation(self, obj: dict[str, Any]) -> None:
        """Parse a mitigation (course-of-action) object from STIX."""
        # Skip deprecated mitigations
        if obj.get("x_mitre_deprecated", False):
            return

        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        name = obj.get("name", "")

        mitigation = Mitigation(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=name,
            description=obj.get("description", ""),
        )

        self.mitigations[attack_id] = mitigation
        self.mitigations_by_name[name.lower()] = mitigation
        self.mitigations_by_stix[obj.get("id", "")] = mitigation

    def _parse_relationship(self, obj: dict[str, Any]) -> None:
        """Parse a 'uses' relationship between entities."""
        source_ref = obj.get("source_ref", "")
        target_ref = obj.get("target_ref", "")

        # Group uses Technique
        if source_ref.startswith("intrusion-set--") and target_ref.startswith("attack-pattern--"):
            # Find the group
            group = None
            for g in self.groups.values():
                if g.stix_id == source_ref:
                    group = g
                    break

            # Find the technique
            technique = self.techniques_by_stix.get(target_ref)

            if group and technique:
                group.techniques.add(technique.id)
                self.technique_to_groups[technique.id].add(group.id)

        # Software uses Technique
        elif source_ref.startswith(("malware--", "tool--")) and target_ref.startswith(
            "attack-pattern--"
        ):
            software = self.software_by_stix.get(source_ref)
            technique = self.techniques_by_stix.get(target_ref)

            if software and technique:
                software.techniques.add(technique.id)
                self.technique_to_software[technique.id].add(software.id)

        # Group uses Software
        elif source_ref.startswith("intrusion-set--") and target_ref.startswith(
            ("malware--", "tool--")
        ):
            # Find the group
            group = None
            for g in self.groups.values():
                if g.stix_id == source_ref:
                    group = g
                    break

            software = self.software_by_stix.get(target_ref)

            if group and software:
                self.group_to_software[group.id].add(software.id)
                self.software_to_groups[software.id].add(group.id)

        # Campaign uses Technique
        elif source_ref.startswith("campaign--") and target_ref.startswith("attack-pattern--"):
            campaign = self.campaigns_by_stix.get(source_ref)
            technique = self.techniques_by_stix.get(target_ref)

            if campaign and technique:
                campaign.techniques.add(technique.id)
                self.technique_to_campaigns[technique.id].add(campaign.id)

        # Campaign uses Software
        elif source_ref.startswith("campaign--") and target_ref.startswith(("malware--", "tool--")):
            campaign = self.campaigns_by_stix.get(source_ref)
            software = self.software_by_stix.get(target_ref)

            if campaign and software:
                campaign.software.add(software.id)

    def _parse_mitigation_relationship(self, obj: dict[str, Any]) -> None:
        """Parse a 'mitigates' relationship between mitigation and technique."""
        source_ref = obj.get("source_ref", "")
        target_ref = obj.get("target_ref", "")

        # Mitigation (course-of-action) mitigates Technique (attack-pattern)
        if source_ref.startswith("course-of-action--") and target_ref.startswith(
            "attack-pattern--"
        ):
            mitigation = self.mitigations_by_stix.get(source_ref)
            technique = self.techniques_by_stix.get(target_ref)

            if mitigation and technique:
                mitigation.techniques.add(technique.id)
                self.technique_to_mitigations[technique.id].add(mitigation.id)

    def _parse_data_source(self, obj: dict[str, Any]) -> None:
        """Parse a data source object from STIX.

        Note: In ATT&CK v18.1+, data sources are deprecated in favor of detection
        strategies, but we still parse them as they provide useful categorization.
        """
        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        name = obj.get("name", "")

        data_source = DataSource(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=name,
            description=obj.get("description", ""),
            platforms=obj.get("x_mitre_platforms", []),
            collection_layers=obj.get("x_mitre_collection_layers", []),
        )

        self.data_sources[attack_id] = data_source
        self.data_sources_by_name[name.lower()] = data_source

    def _parse_data_component(self, obj: dict[str, Any]) -> None:
        """Parse a data component object from STIX."""
        # Skip deprecated data components
        if obj.get("x_mitre_deprecated", False):
            return

        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        name = obj.get("name", "")

        # Extract log sources
        log_sources = []
        for ls in obj.get("x_mitre_log_sources", []):
            log_sources.append({"name": ls.get("name", ""), "channel": ls.get("channel", "")})

        data_component = DataComponent(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=name,
            description=obj.get("description", ""),
            log_sources=log_sources,
        )

        self.data_components[attack_id] = data_component
        self.data_components_by_name[name.lower()] = data_component
        self.data_components_by_stix[obj.get("id", "")] = data_component

    def _parse_campaign(self, obj: dict[str, Any]) -> None:
        """Parse a campaign object from STIX."""
        # Skip deprecated campaigns
        if obj.get("x_mitre_deprecated", False):
            return

        external_refs = obj.get("external_references", [])
        attack_id = None
        for ref in external_refs:
            if ref.get("source_name") == "mitre-attack":
                attack_id = ref.get("external_id")
                break

        if not attack_id:
            return

        name = obj.get("name", "")
        aliases = obj.get("aliases", [])

        campaign = Campaign(
            id=attack_id,
            stix_id=obj.get("id", ""),
            name=name,
            description=obj.get("description", ""),
            aliases=aliases,
            first_seen=obj.get("first_seen"),
            last_seen=obj.get("last_seen"),
        )

        self.campaigns[attack_id] = campaign
        self.campaigns_by_name[name.lower()] = campaign
        self.campaigns_by_stix[obj.get("id", "")] = campaign

        # Also index by aliases
        for alias in aliases:
            if alias.lower() != name.lower():
                self.campaigns_by_name[alias.lower()] = campaign

    def _parse_campaign_attribution(self, obj: dict[str, Any]) -> None:
        """Parse a 'attributed-to' relationship between campaign and group."""
        source_ref = obj.get("source_ref", "")
        target_ref = obj.get("target_ref", "")

        # Campaign attributed-to Group (intrusion-set)
        if source_ref.startswith("campaign--") and target_ref.startswith("intrusion-set--"):
            campaign = self.campaigns_by_stix.get(source_ref)

            # Find the group
            group = None
            for g in self.groups.values():
                if g.stix_id == target_ref:
                    group = g
                    break

            if campaign and group:
                campaign.groups.add(group.id)
                self.group_to_campaigns[group.id].add(campaign.id)

    def _build_detection_mappings(self, objects: list[dict[str, Any]]) -> None:
        """Build data component -> technique index via detection strategies and analytics."""
        # Build analytics index first
        analytics_by_stix: dict[str, dict[str, Any]] = {}
        for obj in objects:
            if obj.get("type") == "x-mitre-analytic" and not obj.get("x_mitre_deprecated", False):
                analytics_by_stix[obj.get("id", "")] = obj

        # Build detection strategy -> technique index
        detection_to_techniques: dict[str, set[str]] = defaultdict(set)
        for obj in objects:
            if obj.get("type") == "relationship" and obj.get("relationship_type") == "detects":
                source_ref = obj.get("source_ref", "")
                target_ref = obj.get("target_ref", "")
                technique = self.techniques_by_stix.get(target_ref)
                if technique and source_ref.startswith("x-mitre-detection-strategy--"):
                    detection_to_techniques[source_ref].add(technique.id)

        # Trace: detection strategy -> analytics -> data components -> techniques
        for obj in objects:
            if obj.get("type") == "x-mitre-detection-strategy" and not obj.get(
                "x_mitre_deprecated", False
            ):
                det_id = obj.get("id", "")
                techniques = detection_to_techniques.get(det_id, set())

                # Get analytics for this detection strategy
                for analytic_ref in obj.get("x_mitre_analytic_refs", []):
                    analytic = analytics_by_stix.get(analytic_ref)
                    if not analytic:
                        continue

                    # Get data components referenced by this analytic
                    for log_ref in analytic.get("x_mitre_log_source_references", []):
                        dc_stix_id = log_ref.get("x_mitre_data_component_ref", "")
                        dc = self.data_components_by_stix.get(dc_stix_id)
                        if dc:
                            dc.techniques.update(techniques)

    def get_group(self, identifier: str) -> Group | None:
        """
        Get a group by ID, name, or alias.

        Args:
            identifier: Group ID (e.g., "G0007"), name (e.g., "APT28"),
                       or alias (e.g., "Fancy Bear")

        Returns:
            Group object or None if not found
        """
        # Try by ID first
        if identifier.upper() in self.groups:
            return self.groups[identifier.upper()]

        # Try by name (case-insensitive)
        lower_id = identifier.lower()
        if lower_id in self.groups_by_name:
            return self.groups_by_name[lower_id]

        # Try by alias (case-insensitive)
        if lower_id in self.groups_by_alias:
            return self.groups_by_alias[lower_id]

        return None

    def get_technique(self, identifier: str) -> Technique | None:
        """
        Get a technique by ID.

        Args:
            identifier: Technique ID (e.g., "T1566" or "T1566.001")

        Returns:
            Technique object or None if not found
        """
        return self.techniques.get(identifier.upper())

    def get_tactic(self, identifier: str) -> Tactic | None:
        """
        Get a tactic by ID or shortname.

        Args:
            identifier: Tactic ID (e.g., "TA0001") or shortname (e.g., "initial-access")

        Returns:
            Tactic object or None if not found
        """
        # Try by ID
        if identifier.upper() in self.tactics:
            return self.tactics[identifier.upper()]

        # Try by shortname
        return self.tactics_by_shortname.get(identifier.lower())

    def get_subtechniques(self, parent_id: str) -> list[Technique]:
        """
        Get all sub-techniques of a parent technique.

        Args:
            parent_id: Parent technique ID (e.g., "T1566")

        Returns:
            List of Technique objects that are sub-techniques of the parent
        """
        parent_id = parent_id.upper()
        child_ids = self.subtechniques_by_parent.get(parent_id, set())
        return [self.techniques[cid] for cid in sorted(child_ids) if cid in self.techniques]

    def get_parent_technique(self, subtechnique_id: str) -> Technique | None:
        """
        Get the parent technique of a sub-technique.

        Args:
            subtechnique_id: Sub-technique ID (e.g., "T1566.001")

        Returns:
            Parent Technique object or None if not a sub-technique
        """
        technique = self.get_technique(subtechnique_id)
        if technique and technique.parent_id:
            return self.get_technique(technique.parent_id)
        return None

    def get_software(self, identifier: str) -> Software | None:
        """
        Get software by ID, name, or alias.

        Args:
            identifier: Software ID (e.g., "S0002"), name (e.g., "Mimikatz"),
                       or alias

        Returns:
            Software object or None if not found
        """
        # Try by ID first
        if identifier.upper() in self.software:
            return self.software[identifier.upper()]

        # Try by name (case-insensitive)
        lower_id = identifier.lower()
        if lower_id in self.software_by_name:
            return self.software_by_name[lower_id]

        # Try by alias (case-insensitive)
        if lower_id in self.software_by_alias:
            return self.software_by_alias[lower_id]

        return None

    def get_mitigation(self, identifier: str) -> Mitigation | None:
        """
        Get a mitigation by ID or name.

        Args:
            identifier: Mitigation ID (e.g., "M1031") or name (e.g., "Network Intrusion Prevention")

        Returns:
            Mitigation object or None if not found
        """
        # Try by ID first
        if identifier.upper() in self.mitigations:
            return self.mitigations[identifier.upper()]

        # Try by name (case-insensitive)
        lower_id = identifier.lower()
        if lower_id in self.mitigations_by_name:
            return self.mitigations_by_name[lower_id]

        return None

    def get_data_source(self, identifier: str) -> DataSource | None:
        """
        Get a data source by ID or name.

        Args:
            identifier: Data source ID (e.g., "DS0014") or name (e.g., "Pod")

        Returns:
            DataSource object or None if not found
        """
        # Try by ID first
        if identifier.upper() in self.data_sources:
            return self.data_sources[identifier.upper()]

        # Try by name (case-insensitive)
        lower_id = identifier.lower()
        if lower_id in self.data_sources_by_name:
            return self.data_sources_by_name[lower_id]

        return None

    def get_data_component(self, identifier: str) -> DataComponent | None:
        """
        Get a data component by ID or name.

        Args:
            identifier: Data component ID (e.g., "DC0084") or
                       name (e.g., "Active Directory Credential Request")

        Returns:
            DataComponent object or None if not found
        """
        # Try by ID first
        if identifier.upper() in self.data_components:
            return self.data_components[identifier.upper()]

        # Try by name (case-insensitive)
        lower_id = identifier.lower()
        if lower_id in self.data_components_by_name:
            return self.data_components_by_name[lower_id]

        return None

    def get_campaign(self, identifier: str) -> Campaign | None:
        """
        Get a campaign by ID or name.

        Args:
            identifier: Campaign ID (e.g., "C0027") or name

        Returns:
            Campaign object or None if not found
        """
        # Try by ID first
        if identifier.upper() in self.campaigns:
            return self.campaigns[identifier.upper()]

        # Try by name (case-insensitive)
        lower_id = identifier.lower()
        if lower_id in self.campaigns_by_name:
            return self.campaigns_by_name[lower_id]

        return None
