"""Protocol definition for completion models."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class CompletionModel(Protocol):
    """
    Protocol for completion model adapters.

    Implementations should provide a way to complete text prompts
    using an LLM backend (Ollama, OpenAI, etc.).
    """

    @property
    def model_name(self) -> str:
        """Return the model identifier (e.g., 'ollama:llama3.2')."""
        ...

    def complete(self, prompt: str) -> str:
        """
        Complete a text prompt.

        Args:
            prompt: The prompt to complete

        Returns:
            The completion text

        Raises:
            CompletionError: If the completion fails
        """
        ...


class CompletionError(Exception):
    """Raised when a completion request fails."""

    pass
