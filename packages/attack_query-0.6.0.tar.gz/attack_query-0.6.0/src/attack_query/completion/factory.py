"""Factory for creating completion model instances."""

from __future__ import annotations

import os

from attack_query.completion.protocol import CompletionError, CompletionModel


def get_completion_model(provider_string: str | None = None) -> CompletionModel:
    """
    Create a completion model from a provider string.

    Provider string format: "provider:model"
    Examples:
        - "ollama:llama3.2"
        - "ollama:mistral"
        - "openai:gpt-4o-mini"
        - "openai:gpt-4o"

    Args:
        provider_string: Provider and model specification.
            If None, uses ATTACK_QUERY_COMPLETION_MODEL env var,
            defaulting to "ollama:llama3.2"

    Returns:
        CompletionModel instance

    Raises:
        CompletionError: If provider is unknown or configuration is invalid
    """
    if provider_string is None:
        provider_string = os.environ.get("ATTACK_QUERY_COMPLETION_MODEL", "ollama:llama3.2")

    if ":" not in provider_string:
        raise CompletionError(
            f"Invalid provider string: {provider_string}. "
            "Expected format: provider:model (e.g., 'ollama:llama3.2')"
        )

    provider, model = provider_string.split(":", 1)
    provider = provider.lower()

    if provider == "ollama":
        from attack_query.completion.ollama import OllamaModel

        return OllamaModel(model=model)

    elif provider == "openai":
        from attack_query.completion.openai import OpenAIModel

        return OpenAIModel(model=model)

    else:
        raise CompletionError(f"Unknown provider: {provider}. Supported: ollama, openai")
