"""OpenAI completion model adapter."""

from __future__ import annotations

import os
from typing import Any

from attack_query.completion.protocol import CompletionError

# Lazy import httpx to make it optional
_httpx: Any = None


def _get_httpx() -> Any:
    """Lazy import httpx."""
    global _httpx
    if _httpx is None:
        try:
            import httpx

            _httpx = httpx
        except ImportError as e:
            raise ImportError(
                "httpx is required for OpenAI support. "
                "Install with: pip install attack-query[smart]"
            ) from e
    return _httpx


class OpenAIModel:
    """
    OpenAI completion model adapter.

    Uses the OpenAI API for completions.
    """

    def __init__(
        self,
        model: str = "gpt-4o-mini",
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """
        Initialize the OpenAI adapter.

        Args:
            model: Model name (e.g., "gpt-4o-mini", "gpt-4o")
            api_key: OpenAI API key (default: from OPENAI_API_KEY env var)
            base_url: API base URL (for OpenAI-compatible APIs)
            timeout: Request timeout in seconds
        """
        self._model = model
        self._api_key = api_key or os.environ.get("OPENAI_API_KEY")
        self._base_url = base_url or "https://api.openai.com/v1"
        self._timeout = timeout

        if not self._api_key:
            raise CompletionError(
                "OpenAI API key required. Set OPENAI_API_KEY environment variable."
            )

    @property
    def model_name(self) -> str:
        """Return the model identifier."""
        return f"openai:{self._model}"

    def complete(self, prompt: str) -> str:
        """
        Complete a prompt using OpenAI.

        Args:
            prompt: The prompt to complete

        Returns:
            The completion text

        Raises:
            CompletionError: If the request fails
        """
        httpx = _get_httpx()

        try:
            response = httpx.post(
                f"{self._base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self._model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 256,
                    "temperature": 0,
                },
                timeout=self._timeout,
            )
            response.raise_for_status()
            data = response.json()
            return str(data["choices"][0]["message"]["content"]).strip()
        except httpx.HTTPStatusError as e:
            raise CompletionError(f"OpenAI API error: {e.response.status_code}") from e
        except httpx.RequestError as e:
            raise CompletionError(f"OpenAI connection error: {e}") from e
        except (KeyError, IndexError) as e:
            raise CompletionError(f"OpenAI response parsing error: {e}") from e
        except Exception as e:
            raise CompletionError(f"OpenAI error: {e}") from e
