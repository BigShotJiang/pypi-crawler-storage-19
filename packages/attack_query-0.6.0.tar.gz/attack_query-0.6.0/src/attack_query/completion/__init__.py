"""Completion module for LLM-assisted query normalization."""

from attack_query.completion.factory import get_completion_model
from attack_query.completion.protocol import CompletionModel

__all__ = ["CompletionModel", "get_completion_model"]
