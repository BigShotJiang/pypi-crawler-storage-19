"""Ollama completion model adapter."""

from __future__ import annotations

import os
from typing import Any

from attack_query.completion.protocol import CompletionError

# Lazy import httpx to make it optional
_httpx: Any = None


def _get_httpx() -> Any:
    """Lazy import httpx."""
    global _httpx
    if _httpx is None:
        try:
            import httpx

            _httpx = httpx
        except ImportError as e:
            raise ImportError(
                "httpx is required for Ollama support. "
                "Install with: pip install attack-query[smart]"
            ) from e
    return _httpx


class OllamaModel:
    """
    Ollama completion model adapter.

    Uses the Ollama API to complete prompts locally.
    """

    def __init__(
        self,
        model: str = "llama3.2",
        base_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """
        Initialize the Ollama adapter.

        Args:
            model: Model name (e.g., "llama3.2", "mistral")
            base_url: Ollama API URL (default: http://localhost:11434)
            timeout: Request timeout in seconds
        """
        self._model = model
        self._base_url = base_url or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
        self._timeout = timeout

    @property
    def model_name(self) -> str:
        """Return the model identifier."""
        return f"ollama:{self._model}"

    def complete(self, prompt: str) -> str:
        """
        Complete a prompt using Ollama.

        Args:
            prompt: The prompt to complete

        Returns:
            The completion text

        Raises:
            CompletionError: If the request fails
        """
        httpx = _get_httpx()

        try:
            response = httpx.post(
                f"{self._base_url}/api/generate",
                json={
                    "model": self._model,
                    "prompt": prompt,
                    "stream": False,
                },
                timeout=self._timeout,
            )
            response.raise_for_status()
            data = response.json()
            return str(data.get("response", "")).strip()
        except httpx.HTTPStatusError as e:
            raise CompletionError(f"Ollama API error: {e.response.status_code}") from e
        except httpx.RequestError as e:
            raise CompletionError(f"Ollama connection error: {e}") from e
        except Exception as e:
            raise CompletionError(f"Ollama error: {e}") from e
