"""Tests for attack_query.parser."""

from __future__ import annotations

from collections import defaultdict
from unittest.mock import MagicMock

import pytest

from attack_query.engine import ATTACKQueryEngine
from attack_query.models import (
    Campaign,
    DataComponent,
    DataSource,
    Group,
    Mitigation,
    Software,
    Tactic,
    Technique,
)
from attack_query.parser import NLQueryParser


@pytest.fixture
def mock_store() -> MagicMock:
    """Create a mock store with test data."""
    store = MagicMock()

    # Create test techniques
    techniques = {
        "T1566": Technique(
            id="T1566",
            stix_id="attack-pattern--1",
            name="Phishing",
            description="Phishing description",
            tactics=["initial-access"],
        ),
        "T1566.001": Technique(
            id="T1566.001",
            stix_id="attack-pattern--1a",
            name="Spearphishing Attachment",
            description="Spearphishing description",
            tactics=["initial-access"],
            is_subtechnique=True,
            parent_id="T1566",
        ),
        "T1566.002": Technique(
            id="T1566.002",
            stix_id="attack-pattern--1b",
            name="Spearphishing Link",
            description="Spearphishing link description",
            tactics=["initial-access"],
            is_subtechnique=True,
            parent_id="T1566",
        ),
        "T1059": Technique(
            id="T1059",
            stix_id="attack-pattern--2",
            name="Command and Scripting Interpreter",
            description="Command interpreter description",
            tactics=["execution"],
        ),
        "T1078": Technique(
            id="T1078",
            stix_id="attack-pattern--3",
            name="Valid Accounts",
            description="Valid accounts description",
            tactics=["defense-evasion", "persistence", "initial-access"],
        ),
        "T1071": Technique(
            id="T1071",
            stix_id="attack-pattern--4",
            name="Application Layer Protocol",
            description="C2 protocol description",
            tactics=["command-and-control"],
        ),
    }
    store.techniques = techniques
    store.get_technique = lambda tid: techniques.get(tid.upper())

    # Create test groups
    # APT28: T1566, T1059, T1078
    # APT29: T1566, T1078, T1071
    # APT33: T1566, T1059
    # Union APT28|APT29: T1566, T1059, T1078, T1071 (4)
    # Intersection APT28&APT29: T1566, T1078 (2)
    apt28 = Group(
        id="G0007",
        stix_id="intrusion-set--1",
        name="APT28",
        description="Russian threat actor",
        aliases=["Fancy Bear", "Sofacy"],
        techniques={"T1566", "T1059", "T1078"},
    )
    apt29 = Group(
        id="G0016",
        stix_id="intrusion-set--2",
        name="APT29",
        description="Russian threat actor",
        aliases=["Cozy Bear"],
        techniques={"T1566", "T1078", "T1071"},
    )
    apt33 = Group(
        id="G0064",
        stix_id="intrusion-set--3",
        name="APT33",
        description="Iranian threat actor",
        techniques={"T1566", "T1059"},
    )

    groups = {"G0007": apt28, "G0016": apt29, "G0064": apt33}
    groups_by_name = {"apt28": apt28, "apt29": apt29, "apt33": apt33}
    groups_by_alias = {"fancy bear": apt28, "cozy bear": apt29, "sofacy": apt28}

    store.groups = groups
    store.groups_by_name = groups_by_name
    store.groups_by_alias = groups_by_alias

    def get_group(identifier: str) -> Group | None:
        if identifier.upper() in groups:
            return groups[identifier.upper()]
        lower = identifier.lower()
        if lower in groups_by_name:
            return groups_by_name[lower]
        if lower in groups_by_alias:
            return groups_by_alias[lower]
        return None

    store.get_group = get_group

    # Create test tactics
    tactics = {
        "TA0001": Tactic(
            id="TA0001",
            stix_id="x-mitre-tactic--1",
            name="Initial Access",
            shortname="initial-access",
            description="Initial access description",
        ),
        "TA0002": Tactic(
            id="TA0002",
            stix_id="x-mitre-tactic--2",
            name="Execution",
            shortname="execution",
            description="Execution description",
        ),
        "TA0003": Tactic(
            id="TA0003",
            stix_id="x-mitre-tactic--3",
            name="Persistence",
            shortname="persistence",
            description="Persistence description",
        ),
        "TA0005": Tactic(
            id="TA0005",
            stix_id="x-mitre-tactic--5",
            name="Defense Evasion",
            shortname="defense-evasion",
            description="Defense evasion description",
        ),
        "TA0011": Tactic(
            id="TA0011",
            stix_id="x-mitre-tactic--11",
            name="Command and Control",
            shortname="command-and-control",
            description="C2 description",
        ),
    }
    tactics_by_shortname = {t.shortname: t for t in tactics.values()}
    store.tactics = tactics
    store.tactics_by_shortname = tactics_by_shortname

    def get_tactic(identifier: str) -> Tactic | None:
        if identifier.upper() in tactics:
            return tactics[identifier.upper()]
        return tactics_by_shortname.get(identifier.lower())

    store.get_tactic = get_tactic

    # Build technique_to_groups index
    technique_to_groups: dict[str, set[str]] = defaultdict(set)
    for group in groups.values():
        for tech_id in group.techniques:
            technique_to_groups[tech_id].add(group.id)
    store.technique_to_groups = technique_to_groups

    # Build subtechniques_by_parent index
    store.subtechniques_by_parent = {
        "T1566": {"T1566.001", "T1566.002"},
    }

    # Create test software
    mimikatz = Software(
        id="S0002",
        stix_id="malware--1",
        name="Mimikatz",
        description="Credential dumping tool",
        software_type="malware",
        aliases=["sekurlsa"],
        platforms=["Windows"],
        techniques={"T1566", "T1059"},
    )
    cobalt_strike = Software(
        id="S0154",
        stix_id="tool--1",
        name="Cobalt Strike",
        description="Commercial adversary simulation tool",
        software_type="tool",
        platforms=["Windows", "Linux"],
        techniques={"T1566", "T1078", "T1071"},
    )

    software = {"S0002": mimikatz, "S0154": cobalt_strike}
    software_by_name = {"mimikatz": mimikatz, "cobalt strike": cobalt_strike}
    software_by_alias = {"sekurlsa": mimikatz}
    store.software = software
    store.software_by_name = software_by_name
    store.software_by_alias = software_by_alias

    def get_software(identifier: str) -> Software | None:
        if identifier.upper() in software:
            return software[identifier.upper()]
        lower = identifier.lower()
        if lower in software_by_name:
            return software_by_name[lower]
        if lower in software_by_alias:
            return software_by_alias[lower]
        return None

    store.get_software = get_software

    # Build technique_to_software index
    technique_to_software: dict[str, set[str]] = defaultdict(set)
    for sw in software.values():
        for tech_id in sw.techniques:
            technique_to_software[tech_id].add(sw.id)
    store.technique_to_software = technique_to_software

    # Build group_to_software index (APT28 uses Mimikatz, APT29 uses Cobalt Strike)
    store.group_to_software = {"G0007": {"S0002"}, "G0016": {"S0154"}}

    # Build software_to_groups index
    store.software_to_groups = {"S0002": {"G0007"}, "S0154": {"G0016"}}

    # Create test mitigations
    user_training = Mitigation(
        id="M1017",
        stix_id="course-of-action--1",
        name="User Training",
        description="Train users to identify social engineering...",
        techniques={"T1566", "T1566.001", "T1566.002"},
    )
    network_intrusion = Mitigation(
        id="M1031",
        stix_id="course-of-action--2",
        name="Network Intrusion Prevention",
        description="Use network-based prevention systems...",
        techniques={"T1566", "T1071"},
    )

    mitigations = {"M1017": user_training, "M1031": network_intrusion}
    mitigations_by_name = {
        "user training": user_training,
        "network intrusion prevention": network_intrusion,
    }
    store.mitigations = mitigations
    store.mitigations_by_name = mitigations_by_name

    def get_mitigation(identifier: str) -> Mitigation | None:
        if identifier.upper() in mitigations:
            return mitigations[identifier.upper()]
        lower = identifier.lower()
        if lower in mitigations_by_name:
            return mitigations_by_name[lower]
        return None

    store.get_mitigation = get_mitigation

    # Build technique_to_mitigations index
    technique_to_mitigations: dict[str, set[str]] = defaultdict(set)
    for mit in mitigations.values():
        for tech_id in mit.techniques:
            technique_to_mitigations[tech_id].add(mit.id)
    store.technique_to_mitigations = technique_to_mitigations

    # Create test data sources
    process_ds = DataSource(
        id="DS0009",
        stix_id="x-mitre-data-source--1",
        name="Process",
        description="Process execution events...",
        platforms=["Windows", "Linux", "macOS"],
        collection_layers=["Host"],
    )
    network_ds = DataSource(
        id="DS0029",
        stix_id="x-mitre-data-source--2",
        name="Network Traffic",
        description="Network traffic data...",
        platforms=["Windows", "Linux"],
        collection_layers=["Network"],
    )

    data_sources = {"DS0009": process_ds, "DS0029": network_ds}
    data_sources_by_name = {"process": process_ds, "network traffic": network_ds}

    store.data_sources = data_sources
    store.data_sources_by_name = data_sources_by_name

    def get_data_source(identifier: str) -> DataSource | None:
        if identifier.upper() in data_sources:
            return data_sources[identifier.upper()]
        lower = identifier.lower()
        if lower in data_sources_by_name:
            return data_sources_by_name[lower]
        return None

    store.get_data_source = get_data_source

    # Create test data components
    process_creation = DataComponent(
        id="DC0032",
        stix_id="x-mitre-data-component--1",
        name="Process Creation",
        description="Process creation events...",
        log_sources=[
            {"name": "WinEventLog:Security", "channel": "EventCode=4688"},
            {"name": "Sysmon", "channel": "EventID=1"},
        ],
        techniques={"T1059", "T1566"},
    )
    network_connection = DataComponent(
        id="DC0007",
        stix_id="x-mitre-data-component--2",
        name="Network Connection Creation",
        description="Network connection events...",
        log_sources=[{"name": "Sysmon", "channel": "EventID=3"}],
        techniques={"T1071"},
    )

    data_components = {"DC0032": process_creation, "DC0007": network_connection}
    data_components_by_name = {
        "process creation": process_creation,
        "network connection creation": network_connection,
    }

    store.data_components = data_components
    store.data_components_by_name = data_components_by_name

    def get_data_component(identifier: str) -> DataComponent | None:
        if identifier.upper() in data_components:
            return data_components[identifier.upper()]
        lower = identifier.lower()
        if lower in data_components_by_name:
            return data_components_by_name[lower]
        return None

    store.get_data_component = get_data_component

    # Create test campaigns
    campaign1 = Campaign(
        id="C0027",
        stix_id="campaign--1",
        name="Test Campaign",
        description="A test campaign",
        aliases=["Operation Test"],
        first_seen="2022-06-01T04:00:00.000Z",
        last_seen="2023-01-01T04:00:00.000Z",
        techniques={"T1566", "T1059"},
        software={"S0002"},
        groups={"G0007"},
    )
    campaign2 = Campaign(
        id="C0028",
        stix_id="campaign--2",
        name="Second Campaign",
        description="Another test campaign",
        first_seen="2023-01-01T04:00:00.000Z",
        last_seen="2023-06-01T04:00:00.000Z",
        techniques={"T1078", "T1071"},
        software={"S0154"},
        groups={"G0007", "G0016"},
    )

    campaigns = {"C0027": campaign1, "C0028": campaign2}
    campaigns_by_name = {"test campaign": campaign1, "second campaign": campaign2}
    campaigns_by_stix = {"campaign--1": campaign1, "campaign--2": campaign2}

    store.campaigns = campaigns
    store.campaigns_by_name = campaigns_by_name
    store.campaigns_by_stix = campaigns_by_stix

    def get_campaign(identifier: str) -> Campaign | None:
        if identifier.upper() in campaigns:
            return campaigns[identifier.upper()]
        lower = identifier.lower()
        if lower in campaigns_by_name:
            return campaigns_by_name[lower]
        return None

    store.get_campaign = get_campaign

    # Build campaign relationship indexes
    technique_to_campaigns: dict[str, set[str]] = defaultdict(set)
    for camp in campaigns.values():
        for tech_id in camp.techniques:
            technique_to_campaigns[tech_id].add(camp.id)
    store.technique_to_campaigns = technique_to_campaigns

    group_to_campaigns: dict[str, set[str]] = defaultdict(set)
    for camp in campaigns.values():
        for group_id in camp.groups:
            group_to_campaigns[group_id].add(camp.id)
    store.group_to_campaigns = group_to_campaigns

    store.version = "test"

    return store


@pytest.fixture
def parser(mock_store: MagicMock) -> NLQueryParser:
    """Create a parser with mock store."""
    engine = ATTACKQueryEngine(mock_store)
    return NLQueryParser(engine)


class TestNLQueryParserGroupsUsingTechnique:
    """Tests for 'groups using technique' queries."""

    def test_groups_using_technique(self, parser: NLQueryParser):
        """Test basic groups using technique query."""
        result = parser.parse_and_execute("groups using T1566")

        assert result["query_type"] == "groups_using_technique"
        assert result["technique"]["id"] == "T1566"
        assert result["count"] == 3
        assert set(result["groups"]) == {"APT28", "APT29", "APT33"}

    def test_groups_using_technique_lowercase(self, parser: NLQueryParser):
        """Test case-insensitive technique ID."""
        result = parser.parse_and_execute("groups using t1566")

        assert result["query_type"] == "groups_using_technique"
        assert result["technique"]["id"] == "T1566"

    def test_groups_using_technique_singular(self, parser: NLQueryParser):
        """Test 'group using' (singular) pattern."""
        result = parser.parse_and_execute("group using T1071")

        assert result["query_type"] == "groups_using_technique"
        assert result["count"] == 1
        assert "APT29" in result["groups"]

    def test_groups_using_technique_not_found(self, parser: NLQueryParser):
        """Test error when technique not found."""
        result = parser.parse_and_execute("groups using T9999")

        assert "error" in result
        assert "T9999" in result["error"]


class TestNLQueryParserCompareGroups:
    """Tests for 'compare groups' queries."""

    def test_compare_groups(self, parser: NLQueryParser):
        """Test basic group comparison."""
        result = parser.parse_and_execute("compare APT28 and APT29")

        assert result["query_type"] == "compare_groups"
        assert result["group1"] == "APT28"
        assert result["group2"] == "APT29"
        assert result["group1_total"] == 3
        assert result["group2_total"] == 3
        assert result["shared_count"] == 2
        assert result["jaccard_similarity"] == 0.5

    def test_compare_groups_case_insensitive(self, parser: NLQueryParser):
        """Test case-insensitive group names."""
        result = parser.parse_and_execute("Compare apt28 And apt29")

        assert result["query_type"] == "compare_groups"
        assert result["group1"] == "APT28"

    def test_compare_groups_with_aliases(self, parser: NLQueryParser):
        """Test comparing using group aliases."""
        result = parser.parse_and_execute("compare Fancy Bear and Cozy Bear")

        assert result["query_type"] == "compare_groups"
        assert result["group1"] == "APT28"
        assert result["group2"] == "APT29"

    def test_compare_groups_not_found(self, parser: NLQueryParser):
        """Test error when group not found."""
        result = parser.parse_and_execute("compare APT28 and NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()


class TestNLQueryParserTechniquesByGroups:
    """Tests for 'techniques used by groups' queries."""

    def test_single_group(self, parser: NLQueryParser):
        """Test techniques for single group."""
        result = parser.parse_and_execute("techniques used by APT28")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28"]
        assert result["exclude_groups"] == []
        assert result["operation"] == "union"
        assert result["count"] == 3
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1059", "T1078"}

    def test_multiple_groups_union_with_or(self, parser: NLQueryParser):
        """Test 'or' produces union (techniques used by ANY group)."""
        result = parser.parse_and_execute("techniques used by APT28 or APT29")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28", "APT29"]
        assert result["operation"] == "union"
        # APT28: {T1566, T1059, T1078}
        # APT29: {T1566, T1078, T1071}
        # Union: {T1566, T1059, T1078, T1071}
        assert result["count"] == 4
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1059", "T1078", "T1071"}

    def test_multiple_groups_intersection_with_and(self, parser: NLQueryParser):
        """Test 'and' produces intersection (techniques used by ALL groups)."""
        result = parser.parse_and_execute("techniques used by APT28 and APT29")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28", "APT29"]
        assert result["operation"] == "intersection"
        # APT28: {T1566, T1059, T1078}
        # APT29: {T1566, T1078, T1071}
        # Intersection: {T1566, T1078}
        assert result["count"] == 2
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1078"}

    def test_union_with_exclusion(self, parser: NLQueryParser):
        """Test union with 'but not' exclusion."""
        result = parser.parse_and_execute("techniques used by APT28 or APT29 but not APT33")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28", "APT29"]
        assert result["exclude_groups"] == ["APT33"]
        assert result["operation"] == "union"
        # Union APT28|APT29: {T1566, T1059, T1078, T1071}
        # APT33: {T1566, T1059}
        # Difference: {T1078, T1071}
        assert result["count"] == 2
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1078", "T1071"}

    def test_intersection_with_exclusion(self, parser: NLQueryParser):
        """Test intersection with 'but not' exclusion."""
        result = parser.parse_and_execute("techniques used by APT28 and APT29 but not APT33")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28", "APT29"]
        assert result["exclude_groups"] == ["APT33"]
        assert result["operation"] == "intersection"
        # Intersection APT28&APT29: {T1566, T1078}
        # APT33: {T1566, T1059}
        # Difference: {T1078}
        assert result["count"] == 1
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1078"}

    def test_union_with_exclusion_but_not_by(self, parser: NLQueryParser):
        """Test union with 'but not by' exclusion (alternative phrasing)."""
        result = parser.parse_and_execute("techniques used by APT28 or APT29 but not by APT33")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28", "APT29"]
        assert result["exclude_groups"] == ["APT33"]
        assert result["operation"] == "union"

    def test_exclusion_with_multiple_groups_or(self, parser: NLQueryParser):
        """Test exclusion with multiple groups using 'or'."""
        result = parser.parse_and_execute(
            "techniques used by APT28 but not by APT29 or APT33"
        )

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28"]
        assert result["exclude_groups"] == ["APT29", "APT33"]
        assert result["operation"] == "union"

    def test_groups_comma_separated_defaults_to_union(self, parser: NLQueryParser):
        """Test comma-separated group list defaults to union."""
        result = parser.parse_and_execute("techniques used by APT28, APT29")

        assert result["include_groups"] == ["APT28", "APT29"]
        assert result["operation"] == "union"
        assert result["count"] == 4

    def test_groups_with_alias(self, parser: NLQueryParser):
        """Test using group alias."""
        result = parser.parse_and_execute("techniques used by Fancy Bear")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["Fancy Bear"]
        assert result["count"] == 3

    def test_group_not_found(self, parser: NLQueryParser):
        """Test error when group not found."""
        result = parser.parse_and_execute("techniques used by NonExistent")

        assert "error" in result
        assert "NonExistent" in result["error"]

    def test_with_tactic_filter_shortname(self, parser: NLQueryParser):
        """Test filtering by tactic shortname."""
        result = parser.parse_and_execute("techniques used by APT28 for initial-access")

        assert result["query_type"] == "techniques_by_groups"
        assert result["tactic_filter"] == "initial-access"
        # APT28 has T1566, T1059, T1078
        # initial-access: T1566, T1078
        assert result["count"] == 2
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1078"}

    def test_with_tactic_filter_partial_name(self, parser: NLQueryParser):
        """Test filtering by partial tactic name."""
        result = parser.parse_and_execute("techniques used by APT28 for initial access")

        assert result["query_type"] == "techniques_by_groups"
        assert result["count"] == 2

    def test_with_tactic_filter_execution(self, parser: NLQueryParser):
        """Test filtering by execution tactic."""
        result = parser.parse_and_execute("techniques used by APT28 for execution")

        assert result["count"] == 1
        assert result["techniques"][0]["id"] == "T1059"

    def test_tactic_not_found(self, parser: NLQueryParser):
        """Test error when tactic not found."""
        result = parser.parse_and_execute("techniques used by APT28 for nonexistent-tactic")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_by_tactic_coverage(self, parser: NLQueryParser):
        """Test that results include tactic coverage summary."""
        result = parser.parse_and_execute("techniques used by APT28")

        assert "by_tactic" in result
        assert "Initial Access" in result["by_tactic"]
        assert "Execution" in result["by_tactic"]

    def test_technique_singular(self, parser: NLQueryParser):
        """Test 'technique used by' (singular) pattern."""
        result = parser.parse_and_execute("technique used by APT28")

        assert result["query_type"] == "techniques_by_groups"
        assert result["count"] == 3

    def test_three_groups_union(self, parser: NLQueryParser):
        """Test union with three groups."""
        result = parser.parse_and_execute("techniques used by APT28 or APT29 or APT33")

        assert result["operation"] == "union"
        assert result["include_groups"] == ["APT28", "APT29", "APT33"]
        # All techniques across all three groups
        assert result["count"] == 4

    def test_three_groups_intersection(self, parser: NLQueryParser):
        """Test intersection with three groups."""
        result = parser.parse_and_execute("techniques used by APT28 and APT29 and APT33")

        assert result["operation"] == "intersection"
        assert result["include_groups"] == ["APT28", "APT29", "APT33"]
        # Only T1566 is in all three groups
        assert result["count"] == 1
        assert result["techniques"][0]["id"] == "T1566"

    def test_comma_list_with_and_intersection(self, parser: NLQueryParser):
        """Test 'A, B, and C' pattern is treated as intersection."""
        result = parser.parse_and_execute("techniques employed by APT28, APT29, and APT33")

        assert result["operation"] == "intersection"
        assert result["include_groups"] == ["APT28", "APT29", "APT33"]
        # Only T1566 is in all three groups
        assert result["count"] == 1
        assert result["techniques"][0]["id"] == "T1566"

    def test_employed_by_single_group(self, parser: NLQueryParser):
        """Test 'techniques employed by' with single group."""
        result = parser.parse_and_execute("techniques employed by APT28")

        assert result["query_type"] == "techniques_by_groups"
        assert result["include_groups"] == ["APT28"]
        assert result["count"] == 3


class TestNLQueryParserTacticsByGroups:
    """Tests for 'tactics used by groups' queries."""

    def test_single_group(self, parser: NLQueryParser):
        """Test tactics for single group."""
        result = parser.parse_and_execute("tactics used by APT28")

        assert result["query_type"] == "tactics_by_groups"
        assert result["groups"] == ["APT28"]
        assert result["operation"] == "union"
        # APT28 uses T1566 (initial-access), T1059 (execution), T1078 (multiple)
        tactic_names = {t["shortname"] for t in result["tactics"]}
        assert "initial-access" in tactic_names
        assert "execution" in tactic_names
        assert "defense-evasion" in tactic_names
        assert "persistence" in tactic_names

    def test_multiple_groups_union(self, parser: NLQueryParser):
        """Test union of tactics with 'or'."""
        result = parser.parse_and_execute("tactics used by APT28 or APT29")

        assert result["query_type"] == "tactics_by_groups"
        assert result["groups"] == ["APT28", "APT29"]
        assert result["operation"] == "union"
        tactic_names = {t["shortname"] for t in result["tactics"]}
        # Should have all tactics from both groups
        assert "initial-access" in tactic_names
        assert "execution" in tactic_names
        assert "command-and-control" in tactic_names

    def test_multiple_groups_intersection(self, parser: NLQueryParser):
        """Test intersection of tactics with 'and'."""
        result = parser.parse_and_execute("tactics used by APT28 and APT29")

        assert result["query_type"] == "tactics_by_groups"
        assert result["groups"] == ["APT28", "APT29"]
        assert result["operation"] == "intersection"
        tactic_names = {t["shortname"] for t in result["tactics"]}
        # Should only have shared tactics
        assert "initial-access" in tactic_names
        assert "defense-evasion" in tactic_names
        assert "persistence" in tactic_names
        # execution and command-and-control should NOT be in intersection
        assert "execution" not in tactic_names
        assert "command-and-control" not in tactic_names

    def test_tactic_singular(self, parser: NLQueryParser):
        """Test 'tactic used by' (singular) pattern."""
        result = parser.parse_and_execute("tactic used by APT28")

        assert result["query_type"] == "tactics_by_groups"
        assert result["groups"] == ["APT28"]

    def test_tactics_sorted_by_kill_chain(self, parser: NLQueryParser):
        """Test that tactics are sorted by kill chain order (TA ID)."""
        result = parser.parse_and_execute("tactics used by APT28")

        # Tactics should be sorted by ID (TA0001 before TA0002, etc.)
        ids = [t["id"] for t in result["tactics"]]
        assert ids == sorted(ids)

    def test_group_not_found(self, parser: NLQueryParser):
        """Test error when group not found."""
        result = parser.parse_and_execute("tactics used by NonExistent")

        assert "error" in result
        assert "NonExistent" in result["error"]


class TestNLQueryParserTacticsNotUsedBy:
    """Tests for 'tactics NOT used by groups' queries."""

    def test_tactics_not_used_by_single_group(self, parser: NLQueryParser):
        """Test 'tactics NOT used by' with single group."""
        result = parser.parse_and_execute("tactics not used by APT28")

        assert result["query_type"] == "tactics_not_used_by"
        assert result["groups"] == ["APT28"]
        # APT28 uses initial-access, execution, defense-evasion
        # So complement should NOT include those
        tactic_shortnames = {t["shortname"] for t in result["tactics"]}
        assert "initial-access" not in tactic_shortnames
        assert "execution" not in tactic_shortnames
        assert "defense-evasion" not in tactic_shortnames

    def test_tactics_not_used_by_multiple_groups(self, parser: NLQueryParser):
        """Test 'tactics NOT used by' with multiple groups (union complement)."""
        result = parser.parse_and_execute(
            "tactics not used by APT28, APT29, or APT33"
        )

        assert result["query_type"] == "tactics_not_used_by"
        assert len(result["groups"]) == 3

    def test_tactic_singular_not_used_by(self, parser: NLQueryParser):
        """Test 'tactic not used by' (singular form)."""
        result = parser.parse_and_execute("tactic not used by APT28")

        assert result["query_type"] == "tactics_not_used_by"
        assert result["groups"] == ["APT28"]

    def test_tactics_not_used_by_sorted(self, parser: NLQueryParser):
        """Test that tactics are sorted by kill chain order."""
        result = parser.parse_and_execute("tactics not used by APT28")

        ids = [t["id"] for t in result["tactics"]]
        assert ids == sorted(ids)

    def test_tactics_not_used_by_group_not_found(self, parser: NLQueryParser):
        """Test error when group not found."""
        result = parser.parse_and_execute("tactics not used by NonExistent")

        assert "error" in result
        assert "NonExistent" in result["error"]


class TestNLQueryParserEdgeCases:
    """Tests for edge cases and error handling."""

    def test_unparseable_query(self, parser: NLQueryParser):
        """Test handling of unparseable query."""
        result = parser.parse_and_execute("what is the meaning of life")

        assert "error" in result
        assert "Could not parse" in result["error"]
        assert "hint" in result

    def test_empty_query(self, parser: NLQueryParser):
        """Test handling of empty query."""
        result = parser.parse_and_execute("")

        assert "error" in result

    def test_whitespace_query(self, parser: NLQueryParser):
        """Test handling of whitespace-only query."""
        result = parser.parse_and_execute("   ")

        assert "error" in result

    def test_query_with_extra_whitespace(self, parser: NLQueryParser):
        """Test query with extra whitespace is handled."""
        result = parser.parse_and_execute("  techniques used by APT28  ")

        assert result["query_type"] == "techniques_by_groups"
        assert result["count"] == 3


class TestNLQueryParserComplement:
    """Tests for complement operation (techniques NOT used by)."""

    def test_techniques_not_used_by_single_group(self, parser: NLQueryParser):
        """Test 'techniques NOT used by' with single group."""
        result = parser.parse_and_execute("techniques NOT used by APT28")

        assert result["query_type"] == "techniques_not_used_by"
        assert result["operation"] == "complement"
        assert result["exclude_groups"] == ["APT28"]
        # APT28 uses T1566, T1059, T1078, so T1071 should be in result
        assert result["count"] > 0
        technique_ids = {t["id"] for t in result["techniques"]}
        assert "T1071" in technique_ids  # APT29-only technique
        assert "T1566" not in technique_ids  # Used by APT28

    def test_techniques_not_used_by_multiple_groups(self, parser: NLQueryParser):
        """Test 'techniques NOT used by' with multiple groups."""
        result = parser.parse_and_execute("techniques NOT used by APT28 or APT29")

        assert result["query_type"] == "techniques_not_used_by"
        assert result["exclude_groups"] == ["APT28", "APT29"]
        # Combined they use T1566, T1059, T1078, T1071
        # Only sub-techniques should remain
        technique_ids = {t["id"] for t in result["techniques"]}
        assert "T1566.001" in technique_ids
        assert "T1566" not in technique_ids

    def test_techniques_not_used_by_lowercase(self, parser: NLQueryParser):
        """Test case-insensitive 'not used by'."""
        result = parser.parse_and_execute("techniques not used by APT28")

        assert result["query_type"] == "techniques_not_used_by"
        assert result["exclude_groups"] == ["APT28"]

    def test_techniques_not_used_by_with_tactic(self, parser: NLQueryParser):
        """Test 'techniques NOT used by' with tactic filter."""
        result = parser.parse_and_execute("techniques NOT used by APT28 for initial access")

        assert result["query_type"] == "techniques_not_used_by"
        assert result["tactic_filter"] == "initial access"
        # All techniques in result should be initial-access tactics
        for tech in result["techniques"]:
            assert "initial-access" in tech["tactics"]

    def test_techniques_not_used_by_singular(self, parser: NLQueryParser):
        """Test 'technique NOT used by' (singular)."""
        result = parser.parse_and_execute("technique NOT used by APT29")

        assert result["query_type"] == "techniques_not_used_by"
        assert result["exclude_groups"] == ["APT29"]

    def test_techniques_not_used_by_group_not_found(self, parser: NLQueryParser):
        """Test 'techniques NOT used by' with non-existent group."""
        result = parser.parse_and_execute("techniques NOT used by NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()


class TestNLQueryParserGroupInfo:
    """Tests for group info and alias queries."""

    def test_who_is_alias(self, parser: NLQueryParser):
        """Test 'who is' query with alias."""
        result = parser.parse_and_execute("who is Fancy Bear")

        assert result["query_type"] == "group_info"
        assert result["name"] == "APT28"
        assert result["id"] == "G0007"
        assert result["resolved_from"] == "Fancy Bear"

    def test_info_by_name(self, parser: NLQueryParser):
        """Test 'info' query with group name."""
        result = parser.parse_and_execute("info APT28")

        assert result["query_type"] == "group_info"
        assert result["name"] == "APT28"
        assert result["resolved_from"] is None

    def test_info_group(self, parser: NLQueryParser):
        """Test 'info' query."""
        result = parser.parse_and_execute("info APT29")

        assert result["query_type"] == "group_info"
        assert result["name"] == "APT29"
        assert "Cozy Bear" in result["aliases"]

    def test_group_info(self, parser: NLQueryParser):
        """Test 'group info' query."""
        result = parser.parse_and_execute("group info APT28")

        assert result["query_type"] == "group_info"
        assert result["name"] == "APT28"

    def test_group_query(self, parser: NLQueryParser):
        """Test 'group' query (single word)."""
        result = parser.parse_and_execute("group Cozy Bear")

        assert result["query_type"] == "group_info"
        assert result["name"] == "APT29"
        assert result["resolved_from"] == "Cozy Bear"

    def test_aliases_of(self, parser: NLQueryParser):
        """Test 'aliases of' query."""
        result = parser.parse_and_execute("aliases of APT28")

        assert result["query_type"] == "group_info"
        assert result["name"] == "APT28"
        assert "Fancy Bear" in result["aliases"]
        assert "Sofacy" in result["aliases"]

    def test_alias_for(self, parser: NLQueryParser):
        """Test 'alias for' query."""
        result = parser.parse_and_execute("alias for APT29")

        assert result["query_type"] == "group_info"
        assert "Cozy Bear" in result["aliases"]

    def test_group_info_not_found(self, parser: NLQueryParser):
        """Test group info with non-existent group."""
        result = parser.parse_and_execute("who is NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_case_insensitive_alias(self, parser: NLQueryParser):
        """Test case-insensitive alias lookup."""
        result = parser.parse_and_execute("who is fancy bear")

        assert result["query_type"] == "group_info"
        assert result["name"] == "APT28"


class TestNLQueryParserSubtechniques:
    """Tests for sub-technique related queries."""

    def test_subtechniques_of(self, parser: NLQueryParser):
        """Test 'sub-techniques of' query."""
        result = parser.parse_and_execute("sub-techniques of T1566")

        assert result["query_type"] == "subtechniques_of"
        assert result["parent"]["id"] == "T1566"
        assert result["count"] == 2
        ids = {t["id"] for t in result["subtechniques"]}
        assert ids == {"T1566.001", "T1566.002"}

    def test_subtechniques_of_lowercase(self, parser: NLQueryParser):
        """Test 'sub-techniques of' with lowercase technique ID."""
        result = parser.parse_and_execute("sub-techniques of t1566")

        assert result["query_type"] == "subtechniques_of"
        assert result["parent"]["id"] == "T1566"

    def test_subtechniques_of_no_hyphen(self, parser: NLQueryParser):
        """Test 'subtechniques of' without hyphen."""
        result = parser.parse_and_execute("subtechniques of T1566")

        assert result["query_type"] == "subtechniques_of"
        assert result["count"] == 2

    def test_subtechniques_of_singular(self, parser: NLQueryParser):
        """Test 'sub-technique of' (singular) pattern."""
        result = parser.parse_and_execute("sub-technique of T1566")

        assert result["query_type"] == "subtechniques_of"
        assert result["count"] == 2

    def test_subtechniques_of_not_found(self, parser: NLQueryParser):
        """Test 'sub-techniques of' with non-existent technique."""
        result = parser.parse_and_execute("sub-techniques of T9999")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_subtechniques_of_is_subtechnique(self, parser: NLQueryParser):
        """Test 'sub-techniques of' when given a sub-technique ID."""
        result = parser.parse_and_execute("sub-techniques of T1566.001")

        assert "error" in result
        assert "sub-technique" in result["error"].lower()

    def test_parent_of(self, parser: NLQueryParser):
        """Test 'parent of' query."""
        result = parser.parse_and_execute("parent of T1566.001")

        assert result["query_type"] == "parent_of"
        assert result["subtechnique"]["id"] == "T1566.001"
        assert result["parent"]["id"] == "T1566"
        assert result["parent"]["name"] == "Phishing"

    def test_parent_of_lowercase(self, parser: NLQueryParser):
        """Test 'parent of' with lowercase technique ID."""
        result = parser.parse_and_execute("parent of t1566.001")

        assert result["query_type"] == "parent_of"
        assert result["parent"]["id"] == "T1566"

    def test_parent_of_not_found(self, parser: NLQueryParser):
        """Test 'parent of' with non-existent technique."""
        result = parser.parse_and_execute("parent of T9999.001")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_parent_of_not_subtechnique(self, parser: NLQueryParser):
        """Test 'parent of' when given a parent technique ID."""
        result = parser.parse_and_execute("parent of T1566")

        assert "error" in result
        assert "not a sub-technique" in result["error"].lower()


class TestNLQueryParserParseGroupExpression:
    """Tests for _parse_group_expression method."""

    def test_single_group(self, parser: NLQueryParser):
        """Test single group returns union operation."""
        groups, operation = parser._parse_group_expression("APT28")

        assert groups == ["APT28"]
        assert operation == "union"

    def test_or_produces_union(self, parser: NLQueryParser):
        """Test 'or' produces union operation."""
        groups, operation = parser._parse_group_expression("APT28 or APT29")

        assert groups == ["APT28", "APT29"]
        assert operation == "union"

    def test_and_produces_intersection(self, parser: NLQueryParser):
        """Test 'and' produces intersection operation."""
        groups, operation = parser._parse_group_expression("APT28 and APT29")

        assert groups == ["APT28", "APT29"]
        assert operation == "intersection"

    def test_comma_produces_union(self, parser: NLQueryParser):
        """Test comma-separated produces union operation."""
        groups, operation = parser._parse_group_expression("APT28, APT29")

        assert groups == ["APT28", "APT29"]
        assert operation == "union"

    def test_or_case_insensitive(self, parser: NLQueryParser):
        """Test 'OR' is case-insensitive."""
        groups, operation = parser._parse_group_expression("APT28 OR APT29")

        assert groups == ["APT28", "APT29"]
        assert operation == "union"

    def test_and_case_insensitive(self, parser: NLQueryParser):
        """Test 'AND' is case-insensitive."""
        groups, operation = parser._parse_group_expression("APT28 AND APT29")

        assert groups == ["APT28", "APT29"]
        assert operation == "intersection"

    def test_three_groups_with_or(self, parser: NLQueryParser):
        """Test three groups with 'or'."""
        groups, operation = parser._parse_group_expression("APT28 or APT29 or APT33")

        assert groups == ["APT28", "APT29", "APT33"]
        assert operation == "union"

    def test_three_groups_with_and(self, parser: NLQueryParser):
        """Test three groups with 'and'."""
        groups, operation = parser._parse_group_expression("APT28 and APT29 and APT33")

        assert groups == ["APT28", "APT29", "APT33"]
        assert operation == "intersection"

    def test_handles_extra_whitespace(self, parser: NLQueryParser):
        """Test handles extra whitespace."""
        groups, operation = parser._parse_group_expression("  APT28   or   APT29  ")

        assert groups == ["APT28", "APT29"]
        assert operation == "union"


class TestNLQueryParserSplitGroupList:
    """Tests for _split_group_list helper method (backward compatibility)."""

    def test_split_on_or(self, parser: NLQueryParser):
        """Test splitting on 'or'."""
        result = parser._split_group_list("APT28 or APT29")
        assert result == ["APT28", "APT29"]

    def test_split_on_and(self, parser: NLQueryParser):
        """Test splitting on 'and'."""
        result = parser._split_group_list("APT28 and APT29")
        assert result == ["APT28", "APT29"]

    def test_split_on_comma(self, parser: NLQueryParser):
        """Test splitting on comma."""
        result = parser._split_group_list("APT28, APT29")
        assert result == ["APT28", "APT29"]

    def test_split_single(self, parser: NLQueryParser):
        """Test single group (no split)."""
        result = parser._split_group_list("APT28")
        assert result == ["APT28"]

    def test_split_with_spaces(self, parser: NLQueryParser):
        """Test splitting handles extra spaces."""
        result = parser._split_group_list("APT28  or  APT29")
        assert result == ["APT28", "APT29"]

    def test_split_case_insensitive(self, parser: NLQueryParser):
        """Test 'OR' and 'AND' are case-insensitive."""
        result = parser._split_group_list("APT28 OR APT29")
        assert result == ["APT28", "APT29"]


class TestNLQueryParserSoftware:
    """Tests for software-related queries."""

    def test_software_used_by_group(self, parser: NLQueryParser):
        """Test 'software used by GROUP' query."""
        result = parser.parse_and_execute("software used by APT28")

        assert result["query_type"] == "software_by_group"
        assert result["group"] == "APT28"
        assert result["count"] == 1
        assert any(sw["name"] == "Mimikatz" for sw in result["software"])

    def test_tools_used_by_group(self, parser: NLQueryParser):
        """Test 'tools used by GROUP' query."""
        result = parser.parse_and_execute("tools used by APT29")

        assert result["query_type"] == "software_by_group"
        assert result["group"] == "APT29"
        assert result["count"] == 1

    def test_malware_used_by_group(self, parser: NLQueryParser):
        """Test 'malware used by GROUP' query."""
        result = parser.parse_and_execute("malware used by APT28")

        assert result["query_type"] == "software_by_group"
        assert result["group"] == "APT28"

    def test_software_used_by_group_not_found(self, parser: NLQueryParser):
        """Test 'software used by' with non-existent group."""
        result = parser.parse_and_execute("software used by NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_groups_using_software(self, parser: NLQueryParser):
        """Test 'groups using SOFTWARE' query."""
        result = parser.parse_and_execute("groups using Mimikatz")

        assert result["query_type"] == "groups_using_software"
        assert result["software"] == "Mimikatz"
        assert result["software_type"] == "malware"
        assert result["count"] == 1
        assert "APT28" in result["groups"]

    def test_groups_using_software_by_alias(self, parser: NLQueryParser):
        """Test 'groups using SOFTWARE' with software alias."""
        result = parser.parse_and_execute("groups using sekurlsa")

        assert result["query_type"] == "groups_using_software"
        assert result["software"] == "Mimikatz"

    def test_groups_using_software_not_found(self, parser: NLQueryParser):
        """Test 'groups using SOFTWARE' with non-existent software."""
        result = parser.parse_and_execute("groups using NonExistentTool")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_groups_using_technique_vs_software(self, parser: NLQueryParser):
        """Test that 'groups using T1566' is treated as technique, not software."""
        result = parser.parse_and_execute("groups using T1566")

        assert result["query_type"] == "groups_using_technique"
        assert result["technique"]["id"] == "T1566"

    def test_techniques_for_software(self, parser: NLQueryParser):
        """Test 'techniques for SOFTWARE' query."""
        result = parser.parse_and_execute("techniques for Cobalt Strike")

        assert result["query_type"] == "techniques_by_software"
        assert result["software"] == "Cobalt Strike"
        assert result["software_type"] == "tool"
        assert result["count"] == 3
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1078", "T1071"}

    def test_techniques_for_software_by_id(self, parser: NLQueryParser):
        """Test 'techniques for S0002' query."""
        result = parser.parse_and_execute("techniques for S0002")

        assert result["query_type"] == "techniques_by_software"
        assert result["software"] == "Mimikatz"
        assert result["count"] == 2

    def test_techniques_for_software_not_found(self, parser: NLQueryParser):
        """Test 'techniques for SOFTWARE' with non-existent software.

        When software is not found and not a group, falls through to error.
        """
        result = parser.parse_and_execute("techniques for NonExistentTool")

        # Falls through to "Could not parse" when identifier is unknown
        assert "error" in result

    def test_techniques_used_by_software(self, parser: NLQueryParser):
        """Test 'techniques used by SOFTWARE' query (alternative phrasing).

        When the identifier is not a group but is software, falls back to software query.
        """
        result = parser.parse_and_execute("techniques used by Cobalt Strike")

        assert result["query_type"] == "techniques_by_software"
        assert result["software"] == "Cobalt Strike"
        assert result["software_type"] == "tool"
        assert result["count"] == 3

    def test_software_info(self, parser: NLQueryParser):
        """Test 'software info NAME' query."""
        result = parser.parse_and_execute("software info Mimikatz")

        assert result["query_type"] == "software_info"
        assert result["name"] == "Mimikatz"
        assert result["id"] == "S0002"
        assert result["type"] == "malware"

    def test_software_name_only(self, parser: NLQueryParser):
        """Test 'software NAME' query (without 'info')."""
        result = parser.parse_and_execute("software Cobalt Strike")

        assert result["query_type"] == "software_info"
        assert result["name"] == "Cobalt Strike"
        assert result["type"] == "tool"

    def test_tool_info(self, parser: NLQueryParser):
        """Test 'tool info NAME' query."""
        result = parser.parse_and_execute("tool info Cobalt Strike")

        assert result["query_type"] == "software_info"
        assert result["name"] == "Cobalt Strike"

    def test_malware_info(self, parser: NLQueryParser):
        """Test 'malware NAME' query."""
        result = parser.parse_and_execute("malware Mimikatz")

        assert result["query_type"] == "software_info"
        assert result["name"] == "Mimikatz"

    def test_software_info_not_found(self, parser: NLQueryParser):
        """Test 'software info NAME' with non-existent software."""
        result = parser.parse_and_execute("software info NonExistentTool")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_software_using_technique(self, parser: NLQueryParser):
        """Test 'software using TECHNIQUE' query."""
        result = parser.parse_and_execute("software using T1566")

        assert result["query_type"] == "software_using_technique"
        assert result["technique"]["id"] == "T1566"
        assert result["count"] == 2
        sw_names = {sw["name"] for sw in result["software"]}
        assert sw_names == {"Mimikatz", "Cobalt Strike"}

    def test_tools_using_technique(self, parser: NLQueryParser):
        """Test 'tools using TECHNIQUE' query."""
        result = parser.parse_and_execute("tools using T1071")

        assert result["query_type"] == "software_using_technique"
        assert result["count"] == 1

    def test_software_using_technique_not_found(self, parser: NLQueryParser):
        """Test 'software using TECHNIQUE' with non-existent technique."""
        result = parser.parse_and_execute("software using T9999")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_software_using_technique_lowercase(self, parser: NLQueryParser):
        """Test 'software using t1566' with lowercase technique ID."""
        result = parser.parse_and_execute("software using t1566")

        assert result["query_type"] == "software_using_technique"
        assert result["technique"]["id"] == "T1566"


class TestNLQueryParserMitigation:
    """Tests for mitigation-related queries."""

    def test_mitigations_for_technique(self, parser: NLQueryParser):
        """Test 'mitigations for TECHNIQUE' query."""
        result = parser.parse_and_execute("mitigations for T1566")

        assert result["query_type"] == "mitigations_for_technique"
        assert result["technique"]["id"] == "T1566"
        assert result["count"] == 2
        mit_ids = {m["id"] for m in result["mitigations"]}
        assert mit_ids == {"M1017", "M1031"}

    def test_mitigations_for_technique_single(self, parser: NLQueryParser):
        """Test 'mitigations for TECHNIQUE' with single mitigation."""
        result = parser.parse_and_execute("mitigations for T1071")

        assert result["query_type"] == "mitigations_for_technique"
        assert result["count"] == 1
        assert result["mitigations"][0]["id"] == "M1031"

    def test_mitigations_for_technique_lowercase(self, parser: NLQueryParser):
        """Test 'mitigations for t1566' with lowercase ID."""
        result = parser.parse_and_execute("mitigations for t1566")

        assert result["query_type"] == "mitigations_for_technique"
        assert result["technique"]["id"] == "T1566"

    def test_mitigation_for_technique(self, parser: NLQueryParser):
        """Test 'mitigation for TECHNIQUE' (singular)."""
        result = parser.parse_and_execute("mitigation for T1566")

        assert result["query_type"] == "mitigations_for_technique"

    def test_how_to_mitigate_technique(self, parser: NLQueryParser):
        """Test 'how to mitigate TECHNIQUE' query."""
        result = parser.parse_and_execute("how to mitigate T1566")

        assert result["query_type"] == "mitigations_for_technique"
        assert result["technique"]["id"] == "T1566"

    def test_mitigations_for_technique_not_found(self, parser: NLQueryParser):
        """Test 'mitigations for TECHNIQUE' with non-existent technique."""
        result = parser.parse_and_execute("mitigations for T9999")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_techniques_mitigated_by_id(self, parser: NLQueryParser):
        """Test 'techniques mitigated by MITIGATION' query by ID."""
        result = parser.parse_and_execute("techniques mitigated by M1017")

        assert result["query_type"] == "techniques_mitigated_by"
        assert result["mitigation"]["id"] == "M1017"
        assert result["mitigation"]["name"] == "User Training"
        assert result["count"] == 3
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1566.001", "T1566.002"}

    def test_techniques_mitigated_by_name(self, parser: NLQueryParser):
        """Test 'techniques mitigated by MITIGATION' query by name."""
        result = parser.parse_and_execute("techniques mitigated by User Training")

        assert result["query_type"] == "techniques_mitigated_by"
        assert result["mitigation"]["id"] == "M1017"

    def test_techniques_mitigated_by_not_found(self, parser: NLQueryParser):
        """Test 'techniques mitigated by' with non-existent mitigation."""
        result = parser.parse_and_execute("techniques mitigated by M9999")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_mitigation_info_by_id(self, parser: NLQueryParser):
        """Test 'mitigation info MITIGATION' query by ID."""
        result = parser.parse_and_execute("mitigation info M1017")

        assert result["query_type"] == "mitigation_info"
        assert result["id"] == "M1017"
        assert result["name"] == "User Training"
        assert result["technique_count"] == 3

    def test_mitigation_info_by_name(self, parser: NLQueryParser):
        """Test 'mitigation info MITIGATION' query by name."""
        result = parser.parse_and_execute("mitigation info User Training")

        assert result["query_type"] == "mitigation_info"
        assert result["name"] == "User Training"

    def test_mitigation_name_only(self, parser: NLQueryParser):
        """Test 'mitigation NAME' query (without 'info')."""
        result = parser.parse_and_execute("mitigation M1031")

        assert result["query_type"] == "mitigation_info"
        assert result["id"] == "M1031"

    def test_mitigation_info_not_found(self, parser: NLQueryParser):
        """Test 'mitigation info' with non-existent mitigation."""
        result = parser.parse_and_execute("mitigation info M9999")

        assert "error" in result
        assert "not found" in result["error"].lower()


class TestNLQueryParserDataSource:
    """Tests for data source query parsing."""

    def test_list_data_sources(self, parser: NLQueryParser):
        """Test 'data sources' query."""
        result = parser.parse_and_execute("data sources")

        assert result["query_type"] == "list_data_sources"
        assert "data_sources" in result
        assert "count" in result
        assert result["count"] >= 0

    def test_list_data_sources_with_list_prefix(self, parser: NLQueryParser):
        """Test 'list data sources' query."""
        result = parser.parse_and_execute("list data sources")

        assert result["query_type"] == "list_data_sources"

    def test_data_source_info_by_name(self, parser: NLQueryParser):
        """Test 'data source info NAME' query."""
        result = parser.parse_and_execute("data source info Process")

        assert result["query_type"] == "data_source_info"
        assert result["name"] == "Process"
        assert "platforms" in result

    def test_data_source_info_by_id(self, parser: NLQueryParser):
        """Test 'data source info ID' query."""
        result = parser.parse_and_execute("data source info DS0009")

        assert result["query_type"] == "data_source_info"
        assert result["id"] == "DS0009"

    def test_data_source_name_only(self, parser: NLQueryParser):
        """Test 'data source NAME' query (without 'info')."""
        result = parser.parse_and_execute("data source Process")

        assert result["query_type"] == "data_source_info"
        assert result["name"] == "Process"

    def test_data_source_not_found(self, parser: NLQueryParser):
        """Test 'data source info' with non-existent data source."""
        result = parser.parse_and_execute("data source info NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_list_data_components(self, parser: NLQueryParser):
        """Test 'data components' query."""
        result = parser.parse_and_execute("data components")

        assert result["query_type"] == "list_data_components"
        assert "data_components" in result
        assert "count" in result

    def test_list_data_components_with_list_prefix(self, parser: NLQueryParser):
        """Test 'list data components' query."""
        result = parser.parse_and_execute("list data components")

        assert result["query_type"] == "list_data_components"

    def test_data_component_info_by_name(self, parser: NLQueryParser):
        """Test 'data component info NAME' query."""
        result = parser.parse_and_execute("data component info Process Creation")

        assert result["query_type"] == "data_component_info"
        assert result["name"] == "Process Creation"
        assert "technique_count" in result

    def test_data_component_info_by_id(self, parser: NLQueryParser):
        """Test 'data component info ID' query."""
        result = parser.parse_and_execute("data component info DC0032")

        assert result["query_type"] == "data_component_info"
        assert result["id"] == "DC0032"

    def test_data_component_name_only(self, parser: NLQueryParser):
        """Test 'data component NAME' query (without 'info')."""
        result = parser.parse_and_execute("data component Process Creation")

        assert result["query_type"] == "data_component_info"

    def test_data_component_not_found(self, parser: NLQueryParser):
        """Test 'data component info' with non-existent data component."""
        result = parser.parse_and_execute("data component info NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_techniques_detectable_by(self, parser: NLQueryParser):
        """Test 'techniques detectable by DATA_COMPONENT' query."""
        result = parser.parse_and_execute("techniques detectable by Process Creation")

        assert result["query_type"] == "techniques_detectable_by"
        assert result["data_component"]["name"] == "Process Creation"
        assert "techniques" in result
        assert result["count"] >= 0

    def test_techniques_detectable_by_id(self, parser: NLQueryParser):
        """Test 'techniques detectable by' with data component ID."""
        result = parser.parse_and_execute("techniques detectable by DC0032")

        assert result["query_type"] == "techniques_detectable_by"
        assert result["data_component"]["id"] == "DC0032"

    def test_techniques_detectable_by_not_found(self, parser: NLQueryParser):
        """Test 'techniques detectable by' with non-existent data component."""
        result = parser.parse_and_execute("techniques detectable by NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()


class TestNLQueryParserCampaign:
    """Tests for campaign queries."""

    def test_list_campaigns(self, parser: NLQueryParser):
        """Test 'campaigns' query to list all campaigns."""
        result = parser.parse_and_execute("campaigns")

        assert result["query_type"] == "list_campaigns"
        assert result["count"] == 2
        campaign_ids = {c["id"] for c in result["campaigns"]}
        assert campaign_ids == {"C0027", "C0028"}

    def test_list_campaigns_with_list(self, parser: NLQueryParser):
        """Test 'list campaigns' query."""
        result = parser.parse_and_execute("list campaigns")

        assert result["query_type"] == "list_campaigns"
        assert result["count"] == 2

    def test_campaigns_by_group(self, parser: NLQueryParser):
        """Test 'campaigns by GROUP' query."""
        result = parser.parse_and_execute("campaigns by APT28")

        assert result["query_type"] == "campaigns_by_group"
        assert result["group"] == "APT28"
        assert result["count"] == 2
        campaign_ids = {c["id"] for c in result["campaigns"]}
        assert campaign_ids == {"C0027", "C0028"}

    def test_campaigns_for_group(self, parser: NLQueryParser):
        """Test 'campaigns for GROUP' query."""
        result = parser.parse_and_execute("campaigns for APT29")

        assert result["query_type"] == "campaigns_by_group"
        assert result["group"] == "APT29"
        assert result["count"] == 1
        assert result["campaigns"][0]["id"] == "C0028"

    def test_campaigns_attributed_to(self, parser: NLQueryParser):
        """Test 'campaigns attributed to GROUP' query."""
        result = parser.parse_and_execute("campaigns attributed to APT28")

        assert result["query_type"] == "campaigns_by_group"
        assert result["group"] == "APT28"
        assert result["count"] == 2

    def test_campaigns_by_group_not_found(self, parser: NLQueryParser):
        """Test 'campaigns by' with non-existent group."""
        result = parser.parse_and_execute("campaigns by NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_techniques_in_campaign(self, parser: NLQueryParser):
        """Test 'techniques in CAMPAIGN' query."""
        result = parser.parse_and_execute("techniques in C0027")

        assert result["query_type"] == "techniques_in_campaign"
        assert result["campaign"]["id"] == "C0027"
        assert result["count"] == 2
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1059"}

    def test_techniques_used_in_campaign(self, parser: NLQueryParser):
        """Test 'techniques used in CAMPAIGN' query."""
        result = parser.parse_and_execute("techniques used in C0028")

        assert result["query_type"] == "techniques_in_campaign"
        assert result["campaign"]["id"] == "C0028"
        assert result["count"] == 2
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1078", "T1071"}

    def test_techniques_in_campaign_not_found(self, parser: NLQueryParser):
        """Test 'techniques in' with non-existent campaign."""
        result = parser.parse_and_execute("techniques in C9999")

        assert "error" in result
        assert "not found" in result["error"].lower()

    def test_campaign_info(self, parser: NLQueryParser):
        """Test 'campaign info CAMPAIGN' query."""
        result = parser.parse_and_execute("campaign info C0027")

        assert result["query_type"] == "campaign_info"
        assert result["id"] == "C0027"
        assert result["name"] == "Test Campaign"
        assert result["first_seen"] == "2022-06-01T04:00:00.000Z"
        assert result["technique_count"] == 2

    def test_campaign_name_only(self, parser: NLQueryParser):
        """Test 'campaign CAMPAIGN' query (without 'info')."""
        result = parser.parse_and_execute("campaign C0027")

        assert result["query_type"] == "campaign_info"
        assert result["id"] == "C0027"

    def test_campaign_by_name(self, parser: NLQueryParser):
        """Test campaign info by name."""
        result = parser.parse_and_execute("campaign Test Campaign")

        assert result["query_type"] == "campaign_info"
        assert result["id"] == "C0027"

    def test_campaign_info_not_found(self, parser: NLQueryParser):
        """Test campaign info with non-existent campaign."""
        result = parser.parse_and_execute("campaign info NonExistent")

        assert "error" in result
        assert "not found" in result["error"].lower()


class TestNLQueryParserCampaignTimeline:
    """Tests for campaign timeline queries."""

    def test_campaigns_in_year(self, parser: NLQueryParser):
        """Test 'campaigns in YEAR' query."""
        result = parser.parse_and_execute("campaigns in 2023")

        assert result["query_type"] == "campaigns_in_year"
        assert result["year"] == 2023
        assert result["count"] == 2

    def test_campaigns_from_year(self, parser: NLQueryParser):
        """Test 'campaigns from YEAR' query."""
        result = parser.parse_and_execute("campaigns from 2022")

        assert result["query_type"] == "campaigns_in_year"
        assert result["year"] == 2022
        assert result["count"] == 1

    def test_campaigns_during_year(self, parser: NLQueryParser):
        """Test 'campaigns during YEAR' query."""
        result = parser.parse_and_execute("campaigns during 2023")

        assert result["query_type"] == "campaigns_in_year"
        assert result["year"] == 2023

    def test_campaigns_between_years(self, parser: NLQueryParser):
        """Test 'campaigns between YEAR1 and YEAR2' query."""
        result = parser.parse_and_execute("campaigns between 2022 and 2023")

        assert result["query_type"] == "campaigns_in_range"
        assert result["start_year"] == 2022
        assert result["end_year"] == 2023
        assert result["count"] == 2

    def test_techniques_in_year(self, parser: NLQueryParser):
        """Test 'techniques in YEAR' query."""
        result = parser.parse_and_execute("techniques in 2023")

        assert result["query_type"] == "techniques_in_year"
        assert result["year"] == 2023
        assert result["count"] == 4  # T1566, T1059, T1078, T1071
        assert result["campaign_count"] == 2

    def test_techniques_used_in_year(self, parser: NLQueryParser):
        """Test 'techniques used in YEAR' query."""
        result = parser.parse_and_execute("techniques used in 2022")

        assert result["query_type"] == "techniques_in_year"
        assert result["year"] == 2022
        assert result["count"] == 2  # T1566, T1059 from C0027

    def test_techniques_from_year(self, parser: NLQueryParser):
        """Test 'techniques from YEAR' query."""
        result = parser.parse_and_execute("techniques from 2023")

        assert result["query_type"] == "techniques_in_year"
        assert result["year"] == 2023

    def test_techniques_between_years(self, parser: NLQueryParser):
        """Test 'techniques between YEAR1 and YEAR2' query."""
        result = parser.parse_and_execute("techniques between 2022 and 2023")

        assert result["query_type"] == "techniques_in_range"
        assert result["start_year"] == 2022
        assert result["end_year"] == 2023
        assert result["count"] == 4
        assert result["campaign_count"] == 2

    def test_techniques_used_between_years(self, parser: NLQueryParser):
        """Test 'techniques used between YEAR1 and YEAR2' query."""
        result = parser.parse_and_execute("techniques used between 2022 and 2024")

        assert result["query_type"] == "techniques_in_range"
        assert result["start_year"] == 2022
        assert result["end_year"] == 2024

    def test_campaigns_in_year_none(self, parser: NLQueryParser):
        """Test campaigns in a year with no activity."""
        result = parser.parse_and_execute("campaigns in 2010")

        assert result["query_type"] == "campaigns_in_year"
        assert result["count"] == 0

    def test_techniques_in_year_none(self, parser: NLQueryParser):
        """Test techniques in a year with no campaigns."""
        result = parser.parse_and_execute("techniques in 2010")

        assert result["query_type"] == "techniques_in_year"
        assert result["count"] == 0


class TestSimilarityPatterns:
    """Tests for similarity query parsing."""

    def test_similarity_two_groups(self, parser: NLQueryParser):
        """Test 'similarity GROUP1 GROUP2' query."""
        result = parser.parse_and_execute("similarity APT28 APT29")

        assert result["query_type"] == "group_similarity"
        assert result["group1"] == "APT28"
        assert result["group2"] == "APT29"
        assert "jaccard" in result
        assert "overlap" in result
        assert "cosine" in result

    def test_similarity_between_groups(self, parser: NLQueryParser):
        """Test 'similarity between GROUP1 and GROUP2' query."""
        result = parser.parse_and_execute("similarity between APT28 and APT29")

        assert result["query_type"] == "group_similarity"
        assert result["group1"] == "APT28"
        assert result["group2"] == "APT29"

    def test_groups_similar_to(self, parser: NLQueryParser):
        """Test 'groups similar to GROUP' query."""
        result = parser.parse_and_execute("groups similar to APT28")

        assert result["query_type"] == "similar_groups"
        assert result["group"] == "APT28"
        assert result["metric"] == "jaccard"
        assert result["threshold"] == 0.0
        assert "similar_groups" in result

    def test_groups_like(self, parser: NLQueryParser):
        """Test 'groups like GROUP' query."""
        result = parser.parse_and_execute("groups like APT28")

        assert result["query_type"] == "similar_groups"
        assert result["group"] == "APT28"

    def test_groups_similar_with_threshold(self, parser: NLQueryParser):
        """Test 'groups similar to GROUP threshold 0.5' query."""
        result = parser.parse_and_execute("groups similar to APT28 threshold 0.5")

        assert result["query_type"] == "similar_groups"
        assert result["group"] == "APT28"
        assert result["threshold"] == 0.5

    def test_groups_similar_with_limit(self, parser: NLQueryParser):
        """Test 'groups similar to GROUP limit 5' query."""
        result = parser.parse_and_execute("groups similar to APT28 limit 5")

        assert result["query_type"] == "similar_groups"
        assert result["group"] == "APT28"
        # Limit should limit results

    def test_groups_similar_with_metric(self, parser: NLQueryParser):
        """Test 'groups similar to GROUP using cosine' query."""
        result = parser.parse_and_execute("groups similar to APT28 using cosine")

        assert result["query_type"] == "similar_groups"
        assert result["group"] == "APT28"
        assert result["metric"] == "cosine"

    def test_groups_similar_with_all_options(self, parser: NLQueryParser):
        """Test 'groups similar to GROUP threshold X limit Y using Z' query."""
        result = parser.parse_and_execute(
            "groups similar to APT28 threshold 0.3 limit 5 using overlap"
        )

        assert result["query_type"] == "similar_groups"
        assert result["group"] == "APT28"
        assert result["threshold"] == 0.3
        assert result["metric"] == "overlap"

    def test_similarity_group_not_found(self, parser: NLQueryParser):
        """Test similarity with non-existent group."""
        result = parser.parse_and_execute("similarity NonExistent APT28")

        assert "error" in result

    def test_groups_similar_not_found(self, parser: NLQueryParser):
        """Test groups similar to non-existent group."""
        result = parser.parse_and_execute("groups similar to NonExistent")

        assert "error" in result

    def test_group_singular_similar(self, parser: NLQueryParser):
        """Test 'group similar to' (singular form) query."""
        result = parser.parse_and_execute("group similar to APT28")

        assert result["query_type"] == "similar_groups"
        assert result["group"] == "APT28"


class TestNLQueryParserMixedEntities:
    """Tests for mixed software+group queries."""

    def test_software_but_not_group(self, parser: NLQueryParser):
        """Test 'techniques used by software X but not by group Y' query."""
        result = parser.parse_and_execute(
            "techniques used by software Mimikatz but not by group APT29"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert len(result["include_entities"]) == 1
        assert result["include_entities"][0]["name"] == "Mimikatz"
        assert result["include_entities"][0]["type"] == "software"
        assert len(result["exclude_entities"]) == 1
        assert result["exclude_entities"][0]["name"] == "APT29"
        assert result["exclude_entities"][0]["type"] == "group"
        # Mimikatz: {T1566, T1059}, APT29: {T1566, T1078, T1071}
        # Result: {T1059} (T1566 is excluded because APT29 uses it)
        assert result["count"] == 1
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1059"}

    def test_both_software_and_group_intersection(self, parser: NLQueryParser):
        """Test 'techniques used by both software X and group Y' query."""
        result = parser.parse_and_execute(
            "techniques used by both software Cobalt Strike and group APT29"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["operation"] == "intersection"
        assert len(result["include_entities"]) == 2
        # Cobalt Strike: {T1566, T1078, T1071}, APT29: {T1566, T1078, T1071}
        # Intersection: {T1566, T1078, T1071}
        assert result["count"] == 3
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1078", "T1071"}

    def test_software_and_group_intersection(self, parser: NLQueryParser):
        """Test 'techniques used by software X and group Y' (implicit intersection)."""
        result = parser.parse_and_execute(
            "techniques used by software Mimikatz and group APT28"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["operation"] == "intersection"
        # Mimikatz: {T1566, T1059}, APT28: {T1566, T1059, T1078}
        # Intersection: {T1566, T1059}
        assert result["count"] == 2
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1059"}

    def test_software_or_group_union(self, parser: NLQueryParser):
        """Test 'techniques used by software X or group Y' query."""
        result = parser.parse_and_execute(
            "techniques used by software Mimikatz or group APT29"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["operation"] == "union"
        # Mimikatz: {T1566, T1059}, APT29: {T1566, T1078, T1071}
        # Union: {T1566, T1059, T1078, T1071}
        assert result["count"] == 4
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1566", "T1059", "T1078", "T1071"}

    def test_the_software_the_group(self, parser: NLQueryParser):
        """Test 'the software X' and 'the group Y' qualifiers."""
        result = parser.parse_and_execute(
            "techniques used by the software Mimikatz but not by the group APT29"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["include_entities"][0]["name"] == "Mimikatz"
        assert result["exclude_entities"][0]["name"] == "APT29"

    def test_tool_and_group(self, parser: NLQueryParser):
        """Test 'tool X' qualifier (synonym for software)."""
        result = parser.parse_and_execute(
            "techniques used by tool Cobalt Strike and group APT28"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["include_entities"][0]["type"] == "software"

    def test_malware_and_group(self, parser: NLQueryParser):
        """Test 'malware X' qualifier (synonym for software)."""
        result = parser.parse_and_execute(
            "techniques used by malware Mimikatz or group APT28"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["include_entities"][0]["type"] == "software"

    def test_software_not_found(self, parser: NLQueryParser):
        """Test error when software not found in mixed query."""
        result = parser.parse_and_execute(
            "techniques used by software NonExistent but not by group APT28"
        )

        assert "error" in result
        assert "Software not found" in result["error"]

    def test_group_not_found_in_mixed(self, parser: NLQueryParser):
        """Test error when group not found in mixed query."""
        result = parser.parse_and_execute(
            "techniques used by software Mimikatz but not by group NonExistent"
        )

        assert "error" in result
        assert "Group not found" in result["error"]

    def test_mixed_with_tactic_filter(self, parser: NLQueryParser):
        """Test mixed query with tactic filter."""
        result = parser.parse_and_execute(
            "techniques used by software Cobalt Strike or group APT28 for initial access"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["tactic_filter"] == "initial access"
        # Filter to only initial-access techniques
        for tech in result["techniques"]:
            assert "initial-access" in tech["tactics"]

    def test_group_but_not_software(self, parser: NLQueryParser):
        """Test 'techniques used by group X but not by software Y' query."""
        result = parser.parse_and_execute(
            "techniques used by group APT28 but not by software Mimikatz"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["include_entities"][0]["name"] == "APT28"
        assert result["include_entities"][0]["type"] == "group"
        assert result["exclude_entities"][0]["name"] == "Mimikatz"
        assert result["exclude_entities"][0]["type"] == "software"
        # APT28: {T1566, T1059, T1078}, Mimikatz: {T1566, T1059}
        # Result: {T1078}
        assert result["count"] == 1
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1078"}

    def test_both_with_exclusion(self, parser: NLQueryParser):
        """Test 'techniques used by both software X and group Y but not by group Z'."""
        result = parser.parse_and_execute(
            "techniques used by both software Cobalt Strike and group APT28 but not by group APT33"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["operation"] == "intersection"
        assert len(result["include_entities"]) == 2
        assert len(result["exclude_entities"]) == 1
        # Cobalt Strike: {T1566, T1078, T1071}
        # APT28: {T1566, T1059, T1078}
        # Intersection: {T1566, T1078}
        # APT33: {T1566, T1059}
        # Result: {T1078}
        assert result["count"] == 1
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1078"}

    def test_implicit_software_but_not_group(self, parser: NLQueryParser):
        """Test implicit entity resolution: software but not group without qualifiers."""
        result = parser.parse_and_execute(
            "techniques used by Mimikatz but not APT29"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        # Mimikatz: {T1566, T1059}, APT29: {T1566, T1078, T1071}
        # Result: {T1059}
        assert result["count"] == 1
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1059"}

    def test_implicit_group_but_not_software(self, parser: NLQueryParser):
        """Test implicit entity resolution: group but not software without qualifiers."""
        result = parser.parse_and_execute(
            "techniques used by APT28 but not Mimikatz"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        # APT28: {T1566, T1059, T1078}, Mimikatz: {T1566, T1059}
        # Result: {T1078}
        assert result["count"] == 1
        tech_ids = {t["id"] for t in result["techniques"]}
        assert tech_ids == {"T1078"}

    def test_implicit_software_and_group_intersection(self, parser: NLQueryParser):
        """Test implicit intersection of software and group without qualifiers."""
        result = parser.parse_and_execute(
            "techniques used by Mimikatz and APT28"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["operation"] == "intersection"
        # Mimikatz: {T1566, T1059}, APT28: {T1566, T1059, T1078}
        # Intersection: {T1566, T1059}
        assert result["count"] == 2

    def test_implicit_software_or_group_union(self, parser: NLQueryParser):
        """Test implicit union of software and group without qualifiers."""
        result = parser.parse_and_execute(
            "techniques used by Mimikatz or APT29"
        )

        assert result["query_type"] == "techniques_by_mixed_entities"
        assert result["operation"] == "union"
        # Mimikatz: {T1566, T1059}, APT29: {T1566, T1078, T1071}
        # Union: {T1566, T1059, T1078, T1071}
        assert result["count"] == 4
