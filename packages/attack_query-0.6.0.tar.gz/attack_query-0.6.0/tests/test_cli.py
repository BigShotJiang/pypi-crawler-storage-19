"""Tests for attack_query.cli."""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from attack_query.cli import (
    _handle_export,
    _handle_heatmap,
    _print_groups,
    _print_help,
    _print_tactics,
    _print_version,
    _print_versions,
    interactive_mode,
    main,
    print_results,
)
from attack_query.engine import ATTACKQueryEngine
from attack_query.models import Group, Matrix, Tactic, Technique
from attack_query.parser import NLQueryParser


@pytest.fixture
def mock_store() -> MagicMock:
    """Create a mock store with test data."""
    store = MagicMock()

    techniques = {
        "T1566": Technique(
            id="T1566",
            stix_id="attack-pattern--1",
            name="Phishing",
            description="Phishing description",
            tactics=["initial-access"],
        ),
        "T1059": Technique(
            id="T1059",
            stix_id="attack-pattern--2",
            name="Command and Scripting Interpreter",
            description="Command interpreter description",
            tactics=["execution"],
        ),
    }
    store.techniques = techniques
    store.get_technique = lambda tid: techniques.get(tid.upper())

    groups = {
        "G0007": Group(
            id="G0007",
            stix_id="intrusion-set--1",
            name="APT28",
            description="Russian threat actor",
            aliases=["Fancy Bear"],
            techniques={"T1566", "T1059"},
        ),
        "G0016": Group(
            id="G0016",
            stix_id="intrusion-set--2",
            name="APT29",
            description="Russian threat actor",
            aliases=["Cozy Bear"],
            techniques={"T1566"},
        ),
    }
    store.groups = groups
    store.groups_by_name = {"apt28": groups["G0007"], "apt29": groups["G0016"]}

    tactics = {
        "TA0001": Tactic(
            id="TA0001",
            stix_id="x-mitre-tactic--1",
            name="Initial Access",
            shortname="initial-access",
            description="Initial access tactic",
        ),
        "TA0002": Tactic(
            id="TA0002",
            stix_id="x-mitre-tactic--2",
            name="Execution",
            shortname="execution",
            description="Execution tactic",
        ),
    }
    store.tactics = tactics

    technique_to_groups: dict[str, set[str]] = defaultdict(set)
    for group in groups.values():
        for tech_id in group.techniques:
            technique_to_groups[tech_id].add(group.id)
    store.technique_to_groups = technique_to_groups

    store.version = "15.1"
    store.matrix = Matrix.ENTERPRISE

    return store


@pytest.fixture
def mock_parser(mock_store: MagicMock) -> NLQueryParser:
    """Create a parser with mock store."""
    engine = ATTACKQueryEngine(mock_store)
    return NLQueryParser(engine)


class TestPrintResultsTechniquesByGroups:
    """Tests for print_results with techniques_by_groups query type."""

    def test_print_techniques_by_groups(self, capsys):
        """Test printing techniques by groups results."""
        results = {
            "query_type": "techniques_by_groups",
            "include_groups": ["APT28"],
            "exclude_groups": [],
            "count": 2,
            "techniques": [
                {"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]},
                {"id": "T1059", "name": "Command Interpreter", "tactics": ["execution"]},
            ],
            "by_tactic": {
                "Initial Access": ["T1566"],
                "Execution": ["T1059"],
            },
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques used by: APT28" in captured.out
        assert "Found 2 techniques" in captured.out
        assert "T1566" in captured.out
        assert "Phishing" in captured.out
        assert "By Tactic:" in captured.out

    def test_print_techniques_with_exclusion(self, capsys):
        """Test printing with exclude groups."""
        results = {
            "query_type": "techniques_by_groups",
            "include_groups": ["APT28"],
            "exclude_groups": ["APT33"],
            "count": 1,
            "techniques": [{"id": "T1566", "name": "Phishing", "tactics": []}],
            "by_tactic": {},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "But not by: APT33" in captured.out

    def test_print_techniques_with_tactic_filter(self, capsys):
        """Test printing with tactic filter."""
        results = {
            "query_type": "techniques_by_groups",
            "include_groups": ["APT28"],
            "exclude_groups": [],
            "tactic_filter": "initial-access",
            "count": 1,
            "techniques": [{"id": "T1566", "name": "Phishing", "tactics": []}],
            "by_tactic": {},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Filtered by tactic: initial-access" in captured.out

    def test_print_techniques_verbose(self, capsys):
        """Test verbose output includes tactics."""
        results = {
            "query_type": "techniques_by_groups",
            "include_groups": ["APT28"],
            "exclude_groups": [],
            "count": 1,
            "techniques": [{"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]}],
            "by_tactic": {},
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Tactics: initial-access" in captured.out

    def test_print_techniques_with_subtechniques(self, capsys):
        """Test hierarchical display with sub-techniques."""
        results = {
            "query_type": "techniques_by_groups",
            "include_groups": ["APT28"],
            "exclude_groups": [],
            "count": 2,
            "techniques": [
                {"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]},
                {
                    "id": "T1566.001",
                    "name": "Spearphishing Attachment",
                    "tactics": ["initial-access"],
                    "is_subtechnique": True,
                    "parent_id": "T1566",
                },
            ],
            "by_tactic": {},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "T1566" in captured.out
        assert "Phishing" in captured.out
        assert ".001" in captured.out
        assert "Spearphishing Attachment" in captured.out

    def test_print_techniques_with_subtechniques_verbose(self, capsys):
        """Test verbose output for sub-techniques includes tactics."""
        results = {
            "query_type": "techniques_by_groups",
            "include_groups": ["APT28"],
            "exclude_groups": [],
            "count": 2,
            "techniques": [
                {"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]},
                {
                    "id": "T1566.001",
                    "name": "Spearphishing Attachment",
                    "tactics": ["initial-access"],
                    "is_subtechnique": True,
                    "parent_id": "T1566",
                },
            ],
            "by_tactic": {},
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        # Both parent and sub-technique should show tactics in verbose mode
        assert captured.out.count("Tactics: initial-access") == 2

    def test_print_techniques_orphan_subtechniques(self, capsys):
        """Test display of orphan sub-techniques (parent not in results)."""
        results = {
            "query_type": "techniques_by_groups",
            "include_groups": ["APT28"],
            "exclude_groups": [],
            "count": 1,
            "techniques": [
                {
                    "id": "T1566.001",
                    "name": "Spearphishing Attachment",
                    "tactics": ["initial-access"],
                    "is_subtechnique": True,
                    "parent_id": "T1566",
                },
            ],
            "by_tactic": {},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "(T1566)" in captured.out
        assert "parent not in results" in captured.out
        assert ".001" in captured.out


class TestPrintResultsTechniquesNotUsedBy:
    """Tests for print_results with techniques_not_used_by query type."""

    def test_print_techniques_not_used_by(self, capsys):
        """Test printing complement query results."""
        results = {
            "query_type": "techniques_not_used_by",
            "exclude_groups": ["APT28", "APT29"],
            "operation": "complement",
            "count": 3,
            "techniques": [
                {"id": "T1071", "name": "Application Layer Protocol", "tactics": ["c2"]},
                {"id": "T1078", "name": "Valid Accounts", "tactics": ["persistence"]},
                {"id": "T1566.002", "name": "Spearphishing Link", "tactics": ["initial-access"]},
            ],
            "by_tactic": {},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques NOT used by: APT28, APT29" in captured.out
        assert "complement" in captured.out
        assert "Found 3 techniques" in captured.out
        assert "T1071" in captured.out


class TestPrintResultsGroupsUsingTechnique:
    """Tests for print_results with groups_using_technique query type."""

    def test_print_groups_using_technique(self, capsys):
        """Test printing groups using technique results."""
        results = {
            "query_type": "groups_using_technique",
            "technique": {"id": "T1566", "name": "Phishing"},
            "groups": ["APT28", "APT29"],
            "count": 2,
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Groups using T1566: Phishing" in captured.out
        assert "Found 2 groups" in captured.out
        assert "APT28" in captured.out
        assert "APT29" in captured.out


class TestPrintResultsCompareGroups:
    """Tests for print_results with compare_groups query type."""

    def test_print_compare_groups(self, capsys):
        """Test printing group comparison results."""
        results = {
            "query_type": "compare_groups",
            "group1": "APT28",
            "group2": "APT29",
            "group1_total": 10,
            "group2_total": 8,
            "shared_count": 5,
            "jaccard_similarity": 0.5,
            "shared": [],
            "unique_to_first": [],
            "unique_to_second": [],
            "unique_to_first_count": 5,
            "unique_to_second_count": 3,
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Comparison: APT28 vs APT29" in captured.out
        assert "APT28: 10 techniques" in captured.out
        assert "APT29: 8 techniques" in captured.out
        assert "Shared: 5 techniques" in captured.out
        assert "50.0%" in captured.out

    def test_print_compare_groups_verbose(self, capsys):
        """Test verbose comparison shows technique details."""
        results = {
            "query_type": "compare_groups",
            "group1": "APT28",
            "group2": "APT29",
            "group1_total": 3,
            "group2_total": 2,
            "shared_count": 1,
            "jaccard_similarity": 0.25,
            "shared": [{"id": "T1566", "name": "Phishing"}],
            "unique_to_first": [{"id": "T1059", "name": "Command Interpreter"}],
            "unique_to_first_count": 1,
            "unique_to_second": [{"id": "T1071", "name": "App Protocol"}],
            "unique_to_second_count": 1,
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Shared techniques:" in captured.out
        assert "T1566" in captured.out
        assert "Unique to APT28:" in captured.out
        assert "Unique to APT29:" in captured.out

    def test_print_compare_groups_verbose_truncates(self, capsys):
        """Test verbose output truncates long lists."""
        results = {
            "query_type": "compare_groups",
            "group1": "APT28",
            "group2": "APT29",
            "group1_total": 20,
            "group2_total": 20,
            "shared_count": 15,
            "jaccard_similarity": 0.5,
            "shared": [{"id": f"T{i}", "name": f"Tech {i}"} for i in range(15)],
            "unique_to_first": [{"id": f"T{i}", "name": f"Tech {i}"} for i in range(10)],
            "unique_to_first_count": 10,
            "unique_to_second": [{"id": f"T{i}", "name": f"Tech {i}"} for i in range(8)],
            "unique_to_second_count": 8,
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "... and 5 more" in captured.out  # 15 - 10 shared
        assert "... and 5 more" in captured.out  # 10 - 5 unique_to_first
        assert "... and 3 more" in captured.out  # 8 - 5 unique_to_second


class TestPrintResultsGroupInfo:
    """Tests for print_results with group_info query type."""

    def test_print_group_info(self, capsys):
        """Test printing group info results."""
        results = {
            "query_type": "group_info",
            "id": "G0007",
            "name": "APT28",
            "aliases": ["Fancy Bear", "Sofacy"],
            "technique_count": 45,
            "resolved_from": None,
            "description": "APT28 is a threat group.",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Group: APT28 (G0007)" in captured.out
        assert "Aliases: Fancy Bear, Sofacy" in captured.out
        assert "Techniques: 45" in captured.out

    def test_print_group_info_resolved_alias(self, capsys):
        """Test printing group info when resolved from alias."""
        results = {
            "query_type": "group_info",
            "id": "G0007",
            "name": "APT28",
            "aliases": ["Fancy Bear", "Sofacy"],
            "technique_count": 45,
            "resolved_from": "Fancy Bear",
            "description": "APT28 is a threat group.",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert '"Fancy Bear" is an alias for: APT28 (G0007)' in captured.out

    def test_print_group_info_verbose(self, capsys):
        """Test verbose output includes description."""
        results = {
            "query_type": "group_info",
            "id": "G0007",
            "name": "APT28",
            "aliases": ["Fancy Bear"],
            "technique_count": 45,
            "resolved_from": None,
            "description": "APT28 is a Russian threat group attributed to military intelligence.",
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Description:" in captured.out
        assert "Russian threat group" in captured.out

    def test_print_group_info_verbose_truncates_long_description(self, capsys):
        """Test verbose output truncates long descriptions."""
        long_description = "A" * 400  # Longer than 300 char limit
        results = {
            "query_type": "group_info",
            "id": "G0007",
            "name": "APT28",
            "aliases": [],
            "technique_count": 45,
            "resolved_from": None,
            "description": long_description,
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Description:" in captured.out
        assert "..." in captured.out
        # Should be truncated to ~300 chars + "..."
        assert "A" * 300 in captured.out
        assert "A" * 350 not in captured.out

    def test_print_group_info_no_aliases(self, capsys):
        """Test printing group info with no aliases."""
        results = {
            "query_type": "group_info",
            "id": "G0007",
            "name": "APT28",
            "aliases": [],
            "technique_count": 45,
            "resolved_from": None,
            "description": "",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Group: APT28 (G0007)" in captured.out
        assert "Aliases:" not in captured.out  # No aliases section when empty


class TestPrintResultsError:
    """Tests for print_results with error responses."""

    def test_print_error(self, capsys):
        """Test printing error results."""
        results = {"error": "Group not found: NonExistent"}

        print_results(results)
        captured = capsys.readouterr()

        assert "Error: Group not found" in captured.out

    def test_print_error_with_hint(self, capsys):
        """Test printing error with hint."""
        results = {
            "error": "Could not parse query",
            "hint": "Try: techniques used by APT28",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Error:" in captured.out
        assert "Hint:" in captured.out


class TestHelperFunctions:
    """Tests for helper print functions."""

    def test_print_help(self, capsys):
        """Test printing help information."""
        _print_help()
        captured = capsys.readouterr()

        assert "Supported query patterns:" in captured.out
        assert "techniques used by" in captured.out
        assert "groups using" in captured.out
        assert "compare" in captured.out
        assert "Commands:" in captured.out

    def test_print_version(self, capsys, mock_parser: NLQueryParser):
        """Test printing version information."""
        _print_version(mock_parser)
        captured = capsys.readouterr()

        assert "Loaded ATT&CK Matrix: Enterprise" in captured.out
        assert "Version: 15.1" in captured.out
        assert "Techniques:" in captured.out
        assert "Groups:" in captured.out

    def test_print_versions(self, capsys):
        """Test printing available versions."""
        _print_versions()
        captured = capsys.readouterr()

        assert "Available ATT&CK versions:" in captured.out
        assert "18.0" in captured.out or "18.1" in captured.out

    def test_print_groups(self, capsys, mock_parser: NLQueryParser):
        """Test printing groups list."""
        _print_groups(mock_parser)
        captured = capsys.readouterr()

        assert "Known threat groups:" in captured.out
        assert "APT28" in captured.out
        assert "G0007" in captured.out

    def test_print_tactics(self, capsys, mock_parser: NLQueryParser):
        """Test printing tactics list."""
        _print_tactics(mock_parser)
        captured = capsys.readouterr()

        assert "ATT&CK Tactics:" in captured.out
        assert "Initial Access" in captured.out
        assert "TA0001" in captured.out


class TestHandleExport:
    """Tests for _handle_export function."""

    def test_export_with_results(self, tmp_path: Path, capsys, mock_parser: NLQueryParser):
        """Test exporting results to file."""
        last_results = {
            "techniques": [
                {"id": "T1566", "name": "Phishing"},
                {"id": "T1059", "name": "Command Interpreter"},
            ],
            "include_groups": ["APT28"],
            "exclude_groups": [],
        }

        # Change to temp directory for file creation
        export_file = tmp_path / "test_layer.json"

        with patch("attack_query.cli.open", create=True) as mock_open:
            mock_file = MagicMock()
            mock_open.return_value.__enter__.return_value = mock_file

            result = _handle_export(f"export {export_file}", mock_parser, last_results)

        assert result == last_results
        captured = capsys.readouterr()
        assert "Exported Navigator layer" in captured.out

    def test_export_default_filename(self, capsys, mock_parser: NLQueryParser):
        """Test export with default filename."""
        last_results = {
            "techniques": [{"id": "T1566", "name": "Phishing"}],
            "include_groups": ["APT28"],
        }

        with patch("attack_query.cli.open", create=True):
            _handle_export("export", mock_parser, last_results)

        captured = capsys.readouterr()
        assert "attack_layer.json" in captured.out

    def test_export_adds_json_extension(self, capsys, mock_parser: NLQueryParser):
        """Test export adds .json extension if missing."""
        last_results = {
            "techniques": [{"id": "T1566", "name": "Phishing"}],
        }

        with patch("attack_query.cli.open", create=True):
            _handle_export("export myfile", mock_parser, last_results)

        captured = capsys.readouterr()
        assert "myfile.json" in captured.out

    def test_export_no_results(self, capsys, mock_parser: NLQueryParser):
        """Test export with no previous results."""
        result = _handle_export("export", mock_parser, None)

        assert result is None
        captured = capsys.readouterr()
        assert "No technique query results" in captured.out

    def test_export_no_techniques(self, capsys, mock_parser: NLQueryParser):
        """Test export when results don't have techniques."""
        last_results = {"query_type": "compare_groups"}

        _handle_export("export", mock_parser, last_results)

        captured = capsys.readouterr()
        assert "No technique query results" in captured.out


class TestHandleHeatmap:
    """Tests for _handle_heatmap function."""

    def test_heatmap_with_filename(self, capsys, mock_parser: NLQueryParser):
        """Test heatmap with explicit filename."""
        with patch("attack_query.cli.open", create=True):
            _handle_heatmap("heatmap overlap.json APT28 APT29", mock_parser)

        captured = capsys.readouterr()
        assert "Exported heatmap layer" in captured.out
        assert "overlap.json" in captured.out

    def test_heatmap_infers_default_filename(self, capsys, mock_parser: NLQueryParser):
        """Test heatmap infers default filename when first arg is group."""
        with patch("attack_query.cli.open", create=True):
            _handle_heatmap("heatmap APT28 APT29", mock_parser)

        captured = capsys.readouterr()
        assert "heatmap.json" in captured.out

    def test_heatmap_adds_json_extension(self, capsys, mock_parser: NLQueryParser):
        """Test heatmap adds .json extension."""
        with patch("attack_query.cli.open", create=True):
            _handle_heatmap("heatmap mymap APT28 APT29", mock_parser)

        captured = capsys.readouterr()
        assert "mymap.json" in captured.out

    def test_heatmap_insufficient_args(self, capsys, mock_parser: NLQueryParser):
        """Test heatmap with insufficient arguments."""
        _handle_heatmap("heatmap APT28", mock_parser)

        captured = capsys.readouterr()
        assert "Usage: heatmap" in captured.out


class TestInteractiveMode:
    """Tests for interactive_mode function."""

    def test_interactive_quit(self, capsys, mock_parser: NLQueryParser):
        """Test quitting interactive mode."""
        with patch("builtins.input", side_effect=["quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "MITRE ATT&CK Query Tool" in captured.out
        assert "Goodbye!" in captured.out

    def test_interactive_exit(self, capsys, mock_parser: NLQueryParser):
        """Test exit command."""
        with patch("builtins.input", side_effect=["exit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Goodbye!" in captured.out

    def test_interactive_q(self, capsys, mock_parser: NLQueryParser):
        """Test q shortcut."""
        with patch("builtins.input", side_effect=["q"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Goodbye!" in captured.out

    def test_interactive_eof(self, capsys, mock_parser: NLQueryParser):
        """Test EOF handling."""
        with patch("builtins.input", side_effect=EOFError):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Goodbye!" in captured.out

    def test_interactive_keyboard_interrupt(self, capsys, mock_parser: NLQueryParser):
        """Test Ctrl+C handling."""
        with patch("builtins.input", side_effect=KeyboardInterrupt):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Goodbye!" in captured.out

    def test_interactive_empty_input(self, capsys, mock_parser: NLQueryParser):
        """Test empty input is ignored."""
        with patch("builtins.input", side_effect=["", "   ", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Goodbye!" in captured.out

    def test_interactive_help(self, capsys, mock_parser: NLQueryParser):
        """Test help command."""
        with patch("builtins.input", side_effect=["help", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Supported query patterns:" in captured.out

    def test_interactive_version(self, capsys, mock_parser: NLQueryParser):
        """Test version command."""
        with patch("builtins.input", side_effect=["version", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Loaded ATT&CK Matrix:" in captured.out
        assert "Version:" in captured.out

    def test_interactive_versions(self, capsys, mock_parser: NLQueryParser):
        """Test versions command."""
        with patch("builtins.input", side_effect=["versions", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Available ATT&CK versions:" in captured.out

    def test_interactive_groups(self, capsys, mock_parser: NLQueryParser):
        """Test groups command."""
        with patch("builtins.input", side_effect=["groups", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Known threat groups:" in captured.out

    def test_interactive_tactics(self, capsys, mock_parser: NLQueryParser):
        """Test tactics command."""
        with patch("builtins.input", side_effect=["tactics", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "ATT&CK Tactics:" in captured.out

    def test_interactive_query(self, capsys, mock_parser: NLQueryParser):
        """Test executing a query."""
        with patch("builtins.input", side_effect=["techniques used by APT28", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Techniques used by: APT28" in captured.out

    def test_interactive_query_verbose(self, capsys, mock_parser: NLQueryParser):
        """Test query with -v flag strips the flag from query."""
        with patch("builtins.input", side_effect=["techniques used by APT28 -v", "quit"]):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        # The -v flag should be stripped and query should execute
        assert "Techniques used by: APT28" in captured.out
        # -v should not appear as part of the group name
        assert "APT28 -v" not in captured.out

    def test_interactive_export(self, capsys, mock_parser: NLQueryParser):
        """Test export command in interactive mode."""
        with (
            patch("builtins.input", side_effect=["export", "quit"]),
            patch("attack_query.cli.open", create=True),
        ):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        # No previous query, so should warn
        assert "No technique query results" in captured.out

    def test_interactive_heatmap(self, capsys, mock_parser: NLQueryParser):
        """Test heatmap command in interactive mode."""
        with (
            patch("builtins.input", side_effect=["heatmap APT28 APT29", "quit"]),
            patch("attack_query.cli.open", create=True),
        ):
            interactive_mode(mock_parser)

        captured = capsys.readouterr()
        assert "Exported heatmap layer" in captured.out


class TestMain:
    """Tests for main() entry point."""

    def test_main_list_versions(self, capsys):
        """Test --list-versions flag."""
        with patch("sys.argv", ["attack-query", "--list-versions"]):
            main()

        captured = capsys.readouterr()
        assert "Known ATT&CK versions:" in captured.out

    def test_main_with_query(self, capsys, tmp_path: Path):
        """Test running with a query argument."""
        # Create test data file
        data_file = tmp_path / "test-data.json"
        data_file.write_text(
            json.dumps(
                {
                    "objects": [
                        {
                            "type": "attack-pattern",
                            "id": "attack-pattern--1",
                            "name": "Test Technique",
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "T1234"}
                            ],
                        },
                        {
                            "type": "intrusion-set",
                            "id": "intrusion-set--1",
                            "name": "TestGroup",
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "G0001"}
                            ],
                        },
                        {
                            "type": "relationship",
                            "relationship_type": "uses",
                            "source_ref": "intrusion-set--1",
                            "target_ref": "attack-pattern--1",
                        },
                    ]
                }
            )
        )

        with patch(
            "sys.argv",
            [
                "attack-query",
                "--data-file",
                str(data_file),
                "techniques used by TestGroup",
            ],
        ):
            main()

        captured = capsys.readouterr()
        assert "Techniques used by: TestGroup" in captured.out

    def test_main_json_output(self, capsys, tmp_path: Path):
        """Test --json output flag."""
        data_file = tmp_path / "test-data.json"
        data_file.write_text(
            json.dumps(
                {
                    "objects": [
                        {
                            "type": "attack-pattern",
                            "id": "attack-pattern--1",
                            "name": "Test",
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "T1234"}
                            ],
                        },
                        {
                            "type": "intrusion-set",
                            "id": "intrusion-set--1",
                            "name": "TestGroup",
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "G0001"}
                            ],
                        },
                        {
                            "type": "relationship",
                            "relationship_type": "uses",
                            "source_ref": "intrusion-set--1",
                            "target_ref": "attack-pattern--1",
                        },
                    ]
                }
            )
        )

        with patch(
            "sys.argv",
            [
                "attack-query",
                "--data-file",
                str(data_file),
                "--json",
                "techniques used by TestGroup",
            ],
        ):
            main()

        captured = capsys.readouterr()
        # Should be valid JSON
        result = json.loads(captured.out)
        assert "query_type" in result

    def test_main_verbose_output(self, capsys, tmp_path: Path):
        """Test -v verbose flag."""
        data_file = tmp_path / "test-data.json"
        data_file.write_text(
            json.dumps(
                {
                    "objects": [
                        {
                            "type": "attack-pattern",
                            "id": "attack-pattern--1",
                            "name": "Test",
                            "kill_chain_phases": [
                                {
                                    "kill_chain_name": "mitre-attack",
                                    "phase_name": "initial-access",
                                }
                            ],
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "T1234"}
                            ],
                        },
                        {
                            "type": "intrusion-set",
                            "id": "intrusion-set--1",
                            "name": "TestGroup",
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "G0001"}
                            ],
                        },
                        {
                            "type": "relationship",
                            "relationship_type": "uses",
                            "source_ref": "intrusion-set--1",
                            "target_ref": "attack-pattern--1",
                        },
                    ]
                }
            )
        )

        with patch(
            "sys.argv",
            [
                "attack-query",
                "--data-file",
                str(data_file),
                "-v",
                "techniques used by TestGroup",
            ],
        ):
            main()

        captured = capsys.readouterr()
        assert "Tactics:" in captured.out

    def test_main_format_layer_output(self, capsys, tmp_path: Path):
        """Test --format layer output flag produces Navigator layer JSON."""
        data_file = tmp_path / "test-data.json"
        data_file.write_text(
            json.dumps(
                {
                    "objects": [
                        {
                            "type": "attack-pattern",
                            "id": "attack-pattern--1",
                            "name": "Phishing",
                            "kill_chain_phases": [
                                {
                                    "kill_chain_name": "mitre-attack",
                                    "phase_name": "initial-access",
                                }
                            ],
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "T1566"}
                            ],
                        },
                        {
                            "type": "intrusion-set",
                            "id": "intrusion-set--1",
                            "name": "TestGroup",
                            "external_references": [
                                {"source_name": "mitre-attack", "external_id": "G0001"}
                            ],
                        },
                        {
                            "type": "relationship",
                            "relationship_type": "uses",
                            "source_ref": "intrusion-set--1",
                            "target_ref": "attack-pattern--1",
                        },
                    ]
                }
            )
        )

        with patch(
            "sys.argv",
            [
                "attack-query",
                "--data-file",
                str(data_file),
                "--format",
                "layer",
                "techniques used by TestGroup",
            ],
        ):
            main()

        captured = capsys.readouterr()
        # Should be valid Navigator layer JSON
        layer = json.loads(captured.out)
        assert layer["name"] == "ATT&CK Query: techniques used by TestGroup"
        assert layer["domain"] == "enterprise-attack"
        assert "techniques" in layer
        # Should have the technique highlighted
        assert any(t["techniqueID"] == "T1566" for t in layer["techniques"])

    def test_main_interactive_mode(self, capsys, tmp_path: Path):
        """Test entering interactive mode when no query provided."""
        data_file = tmp_path / "test-data.json"
        data_file.write_text(json.dumps({"objects": []}))

        with (
            patch("sys.argv", ["attack-query", "--data-file", str(data_file)]),
            patch("builtins.input", side_effect=["quit"]),
        ):
            main()

        captured = capsys.readouterr()
        assert "Interactive Mode" in captured.out


class TestPrintResultsGroupSimilarity:
    """Tests for print_results with group_similarity query type."""

    def test_print_group_similarity(self, capsys):
        """Test printing group similarity results."""
        results = {
            "query_type": "group_similarity",
            "group1": "APT28",
            "group2": "APT29",
            "group1_technique_count": 45,
            "group2_technique_count": 38,
            "shared_count": 20,
            "jaccard": 0.317,
            "overlap": 0.526,
            "cosine": 0.484,
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Similarity: APT28 vs APT29" in captured.out
        assert "APT28: 45 techniques" in captured.out
        assert "APT29: 38 techniques" in captured.out
        assert "Shared: 20 techniques" in captured.out
        assert "Jaccard:" in captured.out
        assert "Overlap:" in captured.out
        assert "Cosine:" in captured.out

    def test_print_group_similarity_verbose(self, capsys):
        """Test verbose output shows shared techniques."""
        results = {
            "query_type": "group_similarity",
            "group1": "APT28",
            "group2": "APT29",
            "group1_technique_count": 10,
            "group2_technique_count": 8,
            "shared_count": 5,
            "jaccard": 0.5,
            "overlap": 0.625,
            "cosine": 0.559,
            "shared_techniques": ["T1566", "T1059", "T1078"],
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Shared techniques:" in captured.out
        assert "T1566" in captured.out

    def test_print_group_similarity_verbose_truncates(self, capsys):
        """Test verbose output truncates long shared technique lists."""
        results = {
            "query_type": "group_similarity",
            "group1": "APT28",
            "group2": "APT29",
            "group1_technique_count": 50,
            "group2_technique_count": 40,
            "shared_count": 15,
            "jaccard": 0.3,
            "overlap": 0.375,
            "cosine": 0.335,
            "shared_techniques": [f"T{i}" for i in range(15)],
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "... and 5 more" in captured.out


class TestPrintResultsSimilarGroups:
    """Tests for print_results with similar_groups query type."""

    def test_print_similar_groups(self, capsys):
        """Test printing similar groups results."""
        results = {
            "query_type": "similar_groups",
            "group": "APT28",
            "technique_count": 45,
            "metric": "jaccard",
            "threshold": 0.3,
            "count": 2,
            "similar_groups": [
                {
                    "group": "APT29",
                    "group_id": "G0016",
                    "similarity": 0.45,
                    "shared_count": 20,
                    "technique_count": 38,
                },
                {
                    "group": "APT33",
                    "group_id": "G0064",
                    "similarity": 0.32,
                    "shared_count": 15,
                    "technique_count": 30,
                },
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Groups similar to APT28" in captured.out
        assert "45 techniques" in captured.out
        assert "Metric: jaccard" in captured.out
        assert "Threshold: 30%" in captured.out
        assert "Found 2 similar groups" in captured.out
        assert "APT29" in captured.out
        assert "45.0%" in captured.out


class TestPrintResultsTacticsByGroups:
    """Tests for print_results with tactics_by_groups query type."""

    def test_print_tactics_by_groups_union(self, capsys):
        """Test printing tactics by groups (union)."""
        results = {
            "query_type": "tactics_by_groups",
            "groups": ["APT28", "APT29"],
            "operation": "union",
            "count": 3,
            "tactics": [
                {"id": "TA0001", "name": "Initial Access", "shortname": "initial-access"},
                {"id": "TA0002", "name": "Execution", "shortname": "execution"},
                {"id": "TA0011", "name": "Command and Control", "shortname": "command-and-control"},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Tactics used by: APT28, APT29" in captured.out
        assert "∪ union" in captured.out
        assert "Found 3 tactics" in captured.out
        assert "TA0001" in captured.out
        assert "Initial Access" in captured.out

    def test_print_tactics_by_groups_intersection(self, capsys):
        """Test printing tactics by groups (intersection)."""
        results = {
            "query_type": "tactics_by_groups",
            "groups": ["APT28", "APT29"],
            "operation": "intersection",
            "count": 2,
            "tactics": [
                {"id": "TA0001", "name": "Initial Access", "shortname": "initial-access"},
                {"id": "TA0002", "name": "Execution", "shortname": "execution"},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "∩ intersection" in captured.out


class TestPrintResultsSubtechniques:
    """Tests for print_results with subtechniques_of and parent_of query types."""

    def test_print_subtechniques_of(self, capsys):
        """Test printing sub-techniques of a parent."""
        results = {
            "query_type": "subtechniques_of",
            "parent": {"id": "T1566", "name": "Phishing"},
            "count": 3,
            "subtechniques": [
                {"id": "T1566.001", "name": "Spearphishing Attachment"},
                {"id": "T1566.002", "name": "Spearphishing Link"},
                {"id": "T1566.003", "name": "Spearphishing via Service"},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Sub-techniques of T1566: Phishing" in captured.out
        assert "Found 3 sub-techniques" in captured.out
        assert "T1566.001" in captured.out
        assert "Spearphishing Attachment" in captured.out

    def test_print_parent_of(self, capsys):
        """Test printing parent of a sub-technique."""
        results = {
            "query_type": "parent_of",
            "subtechnique": {"id": "T1566.001", "name": "Spearphishing Attachment"},
            "parent": {"id": "T1566", "name": "Phishing"},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Parent of T1566.001: Spearphishing Attachment" in captured.out
        assert "Parent: T1566" in captured.out
        assert "Phishing" in captured.out

    def test_print_parent_of_no_parent(self, capsys):
        """Test printing when no parent found."""
        results = {
            "query_type": "parent_of",
            "subtechnique": {"id": "T1566", "name": "Phishing"},
            "parent": None,
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "No parent found" in captured.out


class TestPrintResultsSoftware:
    """Tests for print_results with software query types."""

    def test_print_software_by_group(self, capsys):
        """Test printing software by group."""
        results = {
            "query_type": "software_by_group",
            "group": "APT28",
            "count": 2,
            "software": [
                {"id": "S0002", "name": "Mimikatz", "type": "malware", "technique_count": 15},
                {"id": "S0154", "name": "Cobalt Strike", "type": "tool", "technique_count": 25},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Software used by APT28" in captured.out
        assert "Found 2 software" in captured.out
        assert "S0002" in captured.out
        assert "Mimikatz" in captured.out
        assert "malware" in captured.out

    def test_print_groups_using_software(self, capsys):
        """Test printing groups using software."""
        results = {
            "query_type": "groups_using_software",
            "software": "Mimikatz",
            "software_type": "malware",
            "count": 3,
            "groups": ["APT28", "APT29", "APT33"],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Groups using Mimikatz (malware)" in captured.out
        assert "Found 3 groups" in captured.out
        assert "APT28" in captured.out

    def test_print_techniques_by_software(self, capsys):
        """Test printing techniques by software."""
        results = {
            "query_type": "techniques_by_software",
            "software": "Mimikatz",
            "software_type": "malware",
            "count": 2,
            "techniques": [
                {"id": "T1003", "name": "OS Credential Dumping", "tactics": ["credential-access"]},
                {"id": "T1078", "name": "Valid Accounts", "tactics": ["defense-evasion"]},
            ],
            "by_tactic": {"Credential Access": ["T1003"], "Defense Evasion": ["T1078"]},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques used by Mimikatz (malware)" in captured.out
        assert "Found 2 techniques" in captured.out
        assert "T1003" in captured.out
        assert "By Tactic:" in captured.out

    def test_print_techniques_by_software_verbose(self, capsys):
        """Test verbose output shows tactics."""
        results = {
            "query_type": "techniques_by_software",
            "software": "Mimikatz",
            "software_type": "malware",
            "count": 1,
            "techniques": [
                {"id": "T1003", "name": "OS Credential Dumping", "tactics": ["credential-access"]},
            ],
            "by_tactic": {},
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Tactics: credential-access" in captured.out

    def test_print_software_info(self, capsys):
        """Test printing software info."""
        results = {
            "query_type": "software_info",
            "id": "S0002",
            "name": "Mimikatz",
            "type": "malware",
            "aliases": ["sekurlsa"],
            "platforms": ["Windows"],
            "technique_count": 15,
            "groups": ["APT28", "APT29"],
            "resolved_from": None,
            "description": "Credential dumping tool",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Software: Mimikatz (S0002)" in captured.out
        assert "Type: malware" in captured.out
        assert "Aliases: sekurlsa" in captured.out
        assert "Platforms: Windows" in captured.out
        assert "Techniques: 15" in captured.out
        assert "Used by: APT28, APT29" in captured.out

    def test_print_software_info_resolved_alias(self, capsys):
        """Test software info when resolved from alias."""
        results = {
            "query_type": "software_info",
            "id": "S0002",
            "name": "Mimikatz",
            "type": "malware",
            "resolved_from": "sekurlsa",
            "aliases": ["sekurlsa"],
            "platforms": [],
            "technique_count": 15,
            "groups": [],
            "description": "",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert '"sekurlsa" is an alias for: Mimikatz' in captured.out

    def test_print_software_info_many_groups(self, capsys):
        """Test software info truncates long group list."""
        results = {
            "query_type": "software_info",
            "id": "S0002",
            "name": "Mimikatz",
            "type": "malware",
            "aliases": [],
            "platforms": [],
            "technique_count": 15,
            "groups": [f"APT{i}" for i in range(15)],
            "resolved_from": None,
            "description": "",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "... and 5 more groups" in captured.out

    def test_print_software_using_technique(self, capsys):
        """Test printing software using technique."""
        results = {
            "query_type": "software_using_technique",
            "technique": {"id": "T1566", "name": "Phishing"},
            "count": 2,
            "software": [
                {"id": "S0002", "name": "Mimikatz", "type": "malware"},
                {"id": "S0154", "name": "Cobalt Strike", "type": "tool"},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Software using T1566: Phishing" in captured.out
        assert "Found 2 software" in captured.out


class TestPrintResultsMitigations:
    """Tests for print_results with mitigation query types."""

    def test_print_mitigations_for_technique(self, capsys):
        """Test printing mitigations for technique."""
        results = {
            "query_type": "mitigations_for_technique",
            "technique": {"id": "T1566", "name": "Phishing"},
            "count": 2,
            "mitigations": [
                {"id": "M1017", "name": "User Training"},
                {"id": "M1031", "name": "Network Intrusion Prevention"},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Mitigations for T1566: Phishing" in captured.out
        assert "Found 2 mitigations" in captured.out
        assert "M1017" in captured.out
        assert "User Training" in captured.out

    def test_print_techniques_mitigated_by(self, capsys):
        """Test printing techniques mitigated by."""
        results = {
            "query_type": "techniques_mitigated_by",
            "mitigation": {"id": "M1017", "name": "User Training"},
            "count": 2,
            "techniques": [
                {"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]},
                {"id": "T1204", "name": "User Execution", "tactics": ["execution"]},
            ],
            "by_tactic": {"Initial Access": ["T1566"], "Execution": ["T1204"]},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques mitigated by M1017: User Training" in captured.out
        assert "Found 2 techniques" in captured.out
        assert "By Tactic:" in captured.out

    def test_print_mitigation_info(self, capsys):
        """Test printing mitigation info."""
        results = {
            "query_type": "mitigation_info",
            "id": "M1017",
            "name": "User Training",
            "technique_count": 25,
            "description": "Train users to be aware of access or manipulation attempts.",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Mitigation: User Training (M1017)" in captured.out
        assert "Techniques: 25" in captured.out

    def test_print_mitigation_info_verbose(self, capsys):
        """Test verbose mitigation info shows description."""
        results = {
            "query_type": "mitigation_info",
            "id": "M1017",
            "name": "User Training",
            "technique_count": 25,
            "description": "Train users to be aware of access or manipulation attempts.",
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Description:" in captured.out
        assert "Train users" in captured.out


class TestPrintResultsDataSources:
    """Tests for print_results with data source query types."""

    def test_print_list_data_sources(self, capsys):
        """Test printing list of data sources."""
        results = {
            "query_type": "list_data_sources",
            "count": 2,
            "data_sources": [
                {"id": "DS0009", "name": "Process", "platforms": ["Windows", "Linux"]},
                {"id": "DS0015", "name": "Application Log", "platforms": []},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "ATT&CK Data Sources (2 total)" in captured.out
        assert "DS0009" in captured.out
        assert "Process" in captured.out
        assert "Windows, Linux" in captured.out
        assert "all platforms" in captured.out  # For empty platforms

    def test_print_data_source_info(self, capsys):
        """Test printing data source info."""
        results = {
            "query_type": "data_source_info",
            "id": "DS0009",
            "name": "Process",
            "platforms": ["Windows", "Linux", "macOS"],
            "collection_layers": ["Host"],
            "description": "Information about running processes.",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Data Source: Process (DS0009)" in captured.out
        assert "Platforms: Windows, Linux, macOS" in captured.out
        assert "Collection Layers: Host" in captured.out

    def test_print_list_data_components(self, capsys):
        """Test printing list of data components."""
        results = {
            "query_type": "list_data_components",
            "count": 2,
            "data_components": [
                {"id": "DC0001", "name": "Process Creation", "technique_count": 150},
                {"id": "DC0002", "name": "File Creation", "technique_count": 80},
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "ATT&CK Data Components (2 total)" in captured.out
        assert "DC0001" in captured.out
        assert "Process Creation" in captured.out
        assert "150 techniques" in captured.out

    def test_print_data_component_info(self, capsys):
        """Test printing data component info."""
        results = {
            "query_type": "data_component_info",
            "id": "DC0001",
            "name": "Process Creation",
            "technique_count": 150,
            "log_sources": [
                {"name": "Sysmon", "channel": "Event ID 1"},
                {"name": "Windows Security", "channel": "4688"},
            ],
            "description": "Initial construction of a process.",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Data Component: Process Creation (DC0001)" in captured.out
        assert "Techniques: 150" in captured.out
        assert "Log Sources: 2" in captured.out

    def test_print_data_component_info_verbose(self, capsys):
        """Test verbose data component info shows log sources."""
        results = {
            "query_type": "data_component_info",
            "id": "DC0001",
            "name": "Process Creation",
            "technique_count": 150,
            "log_sources": [
                {"name": "Sysmon", "channel": "Event ID 1"},
                {"name": "Windows Security", "channel": "4688"},
            ],
            "description": "Initial construction of a process.",
        }

        print_results(results, verbose=True)
        captured = capsys.readouterr()

        assert "Log Source Examples:" in captured.out
        assert "Sysmon: Event ID 1" in captured.out
        assert "Description:" in captured.out

    def test_print_techniques_detectable_by(self, capsys):
        """Test printing techniques detectable by data component."""
        results = {
            "query_type": "techniques_detectable_by",
            "data_component": {"id": "DC0001", "name": "Process Creation"},
            "count": 2,
            "techniques": [
                {
                    "id": "T1059",
                    "name": "Command and Scripting Interpreter",
                    "tactics": ["execution"],
                },
                {"id": "T1106", "name": "Native API", "tactics": ["execution"]},
            ],
            "by_tactic": {"Execution": ["T1059", "T1106"]},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques detectable by DC0001: Process Creation" in captured.out
        assert "Found 2 techniques" in captured.out
        assert "By Tactic:" in captured.out


class TestPrintResultsCampaigns:
    """Tests for print_results with campaign query types."""

    def test_print_list_campaigns(self, capsys):
        """Test printing list of campaigns."""
        results = {
            "query_type": "list_campaigns",
            "count": 2,
            "campaigns": [
                {
                    "id": "C0027",
                    "name": "Operation Dream Job",
                    "first_seen": "2019-09-01",
                    "last_seen": "2020-08-01",
                    "technique_count": 25,
                },
                {
                    "id": "C0028",
                    "name": "Operation Sharpshooter",
                    "first_seen": "2018-10-01",
                    "last_seen": "2019-04-01",
                    "technique_count": 15,
                },
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "ATT&CK Campaigns (2 total)" in captured.out
        assert "C0027" in captured.out
        assert "Operation Dream Job" in captured.out
        assert "2019-09-01" in captured.out

    def test_print_campaigns_by_group(self, capsys):
        """Test printing campaigns by group."""
        results = {
            "query_type": "campaigns_by_group",
            "group": "Lazarus Group",
            "count": 1,
            "campaigns": [
                {
                    "id": "C0027",
                    "name": "Operation Dream Job",
                    "first_seen": "2019-09-01",
                    "last_seen": "2020-08-01",
                    "technique_count": 25,
                },
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Campaigns attributed to Lazarus Group" in captured.out
        assert "Found 1 campaigns" in captured.out

    def test_print_techniques_in_campaign(self, capsys):
        """Test printing techniques in campaign."""
        results = {
            "query_type": "techniques_in_campaign",
            "campaign": {
                "id": "C0027",
                "name": "Operation Dream Job",
                "first_seen": "2019-09-01",
                "last_seen": "2020-08-01",
            },
            "count": 2,
            "techniques": [
                {"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]},
                {
                    "id": "T1059",
                    "name": "Command and Scripting Interpreter",
                    "tactics": ["execution"],
                },
            ],
            "by_tactic": {"Initial Access": ["T1566"], "Execution": ["T1059"]},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques in C0027: Operation Dream Job" in captured.out
        assert "Timeline: 2019-09-01 - 2020-08-01" in captured.out
        assert "Found 2 techniques" in captured.out

    def test_print_campaign_info(self, capsys):
        """Test printing campaign info."""
        results = {
            "query_type": "campaign_info",
            "id": "C0027",
            "name": "Operation Dream Job",
            "first_seen": "2019-09-01",
            "last_seen": "2020-08-01",
            "aliases": ["Dream Job"],
            "technique_count": 25,
            "software_count": 5,
            "groups": ["Lazarus Group"],
            "description": "A campaign targeting defense and aerospace sectors.",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Campaign: Operation Dream Job (C0027)" in captured.out
        assert "Timeline: 2019-09-01 - 2020-08-01" in captured.out
        assert "Aliases: Dream Job" in captured.out
        assert "Techniques: 25" in captured.out
        assert "Software: 5" in captured.out
        assert "Attributed to: Lazarus Group" in captured.out

    def test_print_campaigns_in_year(self, capsys):
        """Test printing campaigns in year."""
        results = {
            "query_type": "campaigns_in_year",
            "year": 2023,
            "count": 1,
            "campaigns": [
                {
                    "id": "C0030",
                    "name": "SolarWinds Breach",
                    "first_seen": "2023-01-01",
                    "last_seen": "2023-12-01",
                    "technique_count": 30,
                },
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Campaigns active in 2023" in captured.out
        assert "Found 1 campaigns" in captured.out

    def test_print_campaigns_in_range(self, capsys):
        """Test printing campaigns in date range."""
        results = {
            "query_type": "campaigns_in_range",
            "start_year": 2020,
            "end_year": 2022,
            "count": 2,
            "campaigns": [
                {
                    "id": "C0027",
                    "name": "Operation Dream Job",
                    "first_seen": "2020-01-01",
                    "last_seen": "2021-01-01",
                    "technique_count": 25,
                },
                {
                    "id": "C0028",
                    "name": "Operation Sharpshooter",
                    "first_seen": "2021-06-01",
                    "last_seen": "2022-03-01",
                    "technique_count": 15,
                },
            ],
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Campaigns active between 2020 and 2022" in captured.out
        assert "Found 2 campaigns" in captured.out

    def test_print_techniques_in_year(self, capsys):
        """Test printing techniques in year."""
        results = {
            "query_type": "techniques_in_year",
            "year": 2023,
            "count": 2,
            "techniques": [
                {"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]},
                {
                    "id": "T1059",
                    "name": "Command and Scripting Interpreter",
                    "tactics": ["execution"],
                },
            ],
            "by_tactic": {},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques used in campaigns during 2023" in captured.out
        assert "Found 2 techniques" in captured.out

    def test_print_techniques_in_range(self, capsys):
        """Test printing techniques in date range."""
        results = {
            "query_type": "techniques_in_range",
            "start_year": 2020,
            "end_year": 2022,
            "count": 3,
            "techniques": [
                {"id": "T1566", "name": "Phishing", "tactics": ["initial-access"]},
                {"id": "T1059", "name": "Command Interpreter", "tactics": ["execution"]},
                {"id": "T1078", "name": "Valid Accounts", "tactics": ["defense-evasion"]},
            ],
            "by_tactic": {},
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Techniques used in campaigns between 2020 and 2022" in captured.out
        assert "Found 3 techniques" in captured.out


class TestPrintResultsErrorSuggestions:
    """Tests for print_results with error suggestions."""

    def test_print_error_with_suggestions(self, capsys):
        """Test printing error with fuzzy match suggestions."""
        results = {
            "error": "Group not found: APT27",
            "suggestions": ["'APT27' → 'APT28'", "'APT27' → 'APT29'"],
            "suggested_pattern": "techniques used by {GROUP}",
        }

        print_results(results)
        captured = capsys.readouterr()

        assert "Error: Group not found" in captured.out
        assert "Did you mean:" in captured.out
        assert "'APT27' → 'APT28'" in captured.out
        assert "Try pattern:" in captured.out
