"""Tests for attack_query.store."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from attack_query.models import Matrix
from attack_query.store import ATTACKDataStore

# Sample STIX data for testing
SAMPLE_STIX_DATA = {
    "type": "bundle",
    "id": "bundle--test",
    "objects": [
        # Version metadata
        {
            "type": "x-mitre-collection",
            "id": "x-mitre-collection--test",
            "x_mitre_version": "15.1",
        },
        # Tactic
        {
            "type": "x-mitre-tactic",
            "id": "x-mitre-tactic--test1",
            "name": "Initial Access",
            "x_mitre_shortname": "initial-access",
            "description": "Initial access tactic",
            "external_references": [{"source_name": "mitre-attack", "external_id": "TA0001"}],
        },
        # Technique
        {
            "type": "attack-pattern",
            "id": "attack-pattern--test1",
            "name": "Phishing",
            "description": "Phishing technique",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}
            ],
            "external_references": [{"source_name": "mitre-attack", "external_id": "T1566"}],
        },
        # Sub-technique
        {
            "type": "attack-pattern",
            "id": "attack-pattern--test2",
            "name": "Spearphishing Attachment",
            "description": "Spearphishing sub-technique",
            "x_mitre_is_subtechnique": True,
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}
            ],
            "external_references": [{"source_name": "mitre-attack", "external_id": "T1566.001"}],
        },
        # Group
        {
            "type": "intrusion-set",
            "id": "intrusion-set--test1",
            "name": "APT28",
            "description": "Russian threat actor",
            "aliases": ["Fancy Bear", "Sofacy"],
            "external_references": [{"source_name": "mitre-attack", "external_id": "G0007"}],
        },
        # Relationship (group uses technique)
        {
            "type": "relationship",
            "id": "relationship--test1",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--test1",
            "target_ref": "attack-pattern--test1",
        },
        # Revoked technique (should be skipped)
        {
            "type": "attack-pattern",
            "id": "attack-pattern--revoked",
            "name": "Revoked Technique",
            "description": "This is revoked",
            "revoked": True,
            "external_references": [{"source_name": "mitre-attack", "external_id": "T9999"}],
        },
        # Campaign
        {
            "type": "campaign",
            "id": "campaign--test1",
            "name": "Test Campaign",
            "description": "A test campaign",
            "aliases": ["Operation Test"],
            "first_seen": "2022-06-01T04:00:00.000Z",
            "last_seen": "2023-01-01T04:00:00.000Z",
            "external_references": [{"source_name": "mitre-attack", "external_id": "C0027"}],
        },
        # Campaign uses technique relationship
        {
            "type": "relationship",
            "id": "relationship--camp1",
            "relationship_type": "uses",
            "source_ref": "campaign--test1",
            "target_ref": "attack-pattern--test1",
        },
        # Campaign attributed-to group relationship
        {
            "type": "relationship",
            "id": "relationship--camp2",
            "relationship_type": "attributed-to",
            "source_ref": "campaign--test1",
            "target_ref": "intrusion-set--test1",
        },
    ],
}


class TestATTACKDataStoreInit:
    """Tests for ATTACKDataStore initialization."""

    def test_default_initialization(self):
        """Test default initialization."""
        store = ATTACKDataStore()

        assert store.techniques == {}
        assert store.groups == {}
        assert store.tactics == {}
        assert store._loaded is False
        assert store._version is None
        assert store._data_file is None
        assert store._quiet is False

    def test_initialization_with_version(self):
        """Test initialization with specific version."""
        store = ATTACKDataStore(version="12.0")

        assert store._version == "12.0"

    def test_initialization_with_data_file(self):
        """Test initialization with custom data file."""
        data_file = Path("/path/to/data.json")
        store = ATTACKDataStore(data_file=data_file)

        assert store._data_file == data_file

    def test_initialization_quiet_mode(self):
        """Test initialization with quiet mode."""
        store = ATTACKDataStore(quiet=True)

        assert store._quiet is True

    def test_version_property_before_load(self):
        """Test version property returns None before loading."""
        store = ATTACKDataStore()

        assert store.version is None


class TestATTACKDataStoreVersionHandling:
    """Tests for version-related functionality."""

    def test_list_versions(self):
        """Test listing known versions."""
        versions = ATTACKDataStore.list_versions()

        assert isinstance(versions, list)
        assert "18.0" in versions
        assert "12.0" in versions
        assert "1.0" in versions

    def test_list_versions_returns_copy(self):
        """Test that list_versions returns a copy."""
        versions1 = ATTACKDataStore.list_versions()
        versions2 = ATTACKDataStore.list_versions()

        assert versions1 is not versions2
        assert versions1 == versions2

    def test_get_url_for_version_specific(self):
        """Test URL generation for specific version."""
        store = ATTACKDataStore()
        url = store._get_url_for_version("12.0")

        assert "enterprise-attack-12.0.json" in url
        assert url.startswith(store.BASE_URL)

    def test_get_url_for_version_latest(self):
        """Test URL generation for latest version."""
        store = ATTACKDataStore()
        url = store._get_url_for_version(None)

        assert "enterprise-attack.json" in url
        assert "enterprise-attack-" not in url

    def test_get_cache_file_specific_version(self):
        """Test cache file path for specific version."""
        store = ATTACKDataStore()
        cache_file = store._get_cache_file("12.0")

        assert cache_file.name == "enterprise-attack-12.0.json"
        assert cache_file.parent == store.CACHE_DIR

    def test_get_cache_file_latest(self):
        """Test cache file path for latest version."""
        store = ATTACKDataStore()
        cache_file = store._get_cache_file(None)

        assert cache_file.name == "enterprise-attack-latest.json"


class TestATTACKDataStoreMatrix:
    """Tests for matrix support."""

    def test_default_matrix_is_enterprise(self):
        """Test default matrix is enterprise."""
        store = ATTACKDataStore()
        assert store.matrix == Matrix.ENTERPRISE

    def test_matrix_property(self):
        """Test matrix property."""
        store = ATTACKDataStore(matrix=Matrix.MOBILE)
        assert store.matrix == Matrix.MOBILE

    def test_matrix_from_string(self):
        """Test matrix can be set from string."""
        store = ATTACKDataStore(matrix="mobile")
        assert store.matrix == Matrix.MOBILE

        store2 = ATTACKDataStore(matrix="ics")
        assert store2.matrix == Matrix.ICS

    def test_matrix_url_enterprise(self):
        """Test URL generation for enterprise matrix."""
        store = ATTACKDataStore(matrix=Matrix.ENTERPRISE)
        url = store._get_url_for_version("12.0")
        assert "enterprise-attack/enterprise-attack-12.0.json" in url

        url_latest = store._get_url_for_version(None)
        assert "enterprise-attack/enterprise-attack.json" in url_latest

    def test_matrix_url_mobile(self):
        """Test URL generation for mobile matrix."""
        store = ATTACKDataStore(matrix=Matrix.MOBILE)
        url = store._get_url_for_version("12.0")
        assert "mobile-attack/mobile-attack-12.0.json" in url

        url_latest = store._get_url_for_version(None)
        assert "mobile-attack/mobile-attack.json" in url_latest

    def test_matrix_url_ics(self):
        """Test URL generation for ICS matrix."""
        store = ATTACKDataStore(matrix=Matrix.ICS)
        url = store._get_url_for_version("12.0")
        assert "ics-attack/ics-attack-12.0.json" in url

        url_latest = store._get_url_for_version(None)
        assert "ics-attack/ics-attack.json" in url_latest

    def test_matrix_cache_file_enterprise(self):
        """Test cache file path for enterprise matrix."""
        store = ATTACKDataStore(matrix=Matrix.ENTERPRISE)
        cache_file = store._get_cache_file("12.0")
        assert cache_file.name == "enterprise-attack-12.0.json"

        cache_latest = store._get_cache_file(None)
        assert cache_latest.name == "enterprise-attack-latest.json"

    def test_matrix_cache_file_mobile(self):
        """Test cache file path for mobile matrix."""
        store = ATTACKDataStore(matrix=Matrix.MOBILE)
        cache_file = store._get_cache_file("12.0")
        assert cache_file.name == "mobile-attack-12.0.json"

        cache_latest = store._get_cache_file(None)
        assert cache_latest.name == "mobile-attack-latest.json"

    def test_matrix_cache_file_ics(self):
        """Test cache file path for ICS matrix."""
        store = ATTACKDataStore(matrix=Matrix.ICS)
        cache_file = store._get_cache_file("12.0")
        assert cache_file.name == "ics-attack-12.0.json"

        cache_latest = store._get_cache_file(None)
        assert cache_latest.name == "ics-attack-latest.json"


class TestATTACKDataStoreParsingTechniques:
    """Tests for technique parsing."""

    def test_parse_technique(self):
        """Test parsing a technique from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "T1566" in store.techniques
        tech = store.techniques["T1566"]
        assert tech.name == "Phishing"
        assert tech.tactics == ["initial-access"]
        assert "Windows" in tech.platforms
        assert tech.is_subtechnique is False

    def test_parse_subtechnique(self):
        """Test parsing a sub-technique."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "T1566.001" in store.techniques
        tech = store.techniques["T1566.001"]
        assert tech.name == "Spearphishing Attachment"
        assert tech.is_subtechnique is True
        assert tech.parent_id == "T1566"

    def test_technique_indexed_by_stix_id(self):
        """Test technique is indexed by STIX ID."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "attack-pattern--test1" in store.techniques_by_stix
        assert store.techniques_by_stix["attack-pattern--test1"].id == "T1566"

    def test_revoked_technique_skipped(self):
        """Test that revoked techniques are not parsed."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "T9999" not in store.techniques

    def test_technique_without_attack_id_skipped(self):
        """Test technique without ATT&CK ID is skipped."""
        data = {
            "objects": [
                {
                    "type": "attack-pattern",
                    "id": "attack-pattern--no-id",
                    "name": "No ID Technique",
                    "external_references": [
                        {"source_name": "other-source", "external_id": "OTHER123"}
                    ],
                }
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        assert len(store.techniques) == 0


class TestATTACKDataStoreParsingGroups:
    """Tests for group parsing."""

    def test_parse_group(self):
        """Test parsing a group from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "G0007" in store.groups
        group = store.groups["G0007"]
        assert group.name == "APT28"
        assert "Fancy Bear" in group.aliases

    def test_group_indexed_by_name(self):
        """Test group is indexed by lowercase name."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "apt28" in store.groups_by_name
        assert store.groups_by_name["apt28"].id == "G0007"

    def test_group_indexed_by_alias(self):
        """Test group is indexed by aliases."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "fancy bear" in store.groups_by_alias
        assert "sofacy" in store.groups_by_alias
        assert store.groups_by_alias["fancy bear"].id == "G0007"


class TestATTACKDataStoreParsingTactics:
    """Tests for tactic parsing."""

    def test_parse_tactic(self):
        """Test parsing a tactic from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "TA0001" in store.tactics
        tactic = store.tactics["TA0001"]
        assert tactic.name == "Initial Access"
        assert tactic.shortname == "initial-access"

    def test_tactic_indexed_by_shortname(self):
        """Test tactic is indexed by shortname."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "initial-access" in store.tactics_by_shortname
        assert store.tactics_by_shortname["initial-access"].id == "TA0001"


class TestATTACKDataStoreParsingRelationships:
    """Tests for relationship parsing."""

    def test_parse_group_uses_technique(self):
        """Test parsing group-uses-technique relationship."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        group = store.groups["G0007"]
        assert "T1566" in group.techniques

    def test_technique_to_groups_index(self):
        """Test technique_to_groups index is built."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "T1566" in store.technique_to_groups
        assert "G0007" in store.technique_to_groups["T1566"]

    def test_relationship_with_missing_group_ignored(self):
        """Test relationship with unknown group is ignored."""
        data = {
            "objects": [
                {
                    "type": "attack-pattern",
                    "id": "attack-pattern--exists",
                    "name": "Exists",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "T1234"}
                    ],
                },
                {
                    "type": "relationship",
                    "relationship_type": "uses",
                    "source_ref": "intrusion-set--unknown",
                    "target_ref": "attack-pattern--exists",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        # Should not raise, relationship just ignored
        assert len(store.technique_to_groups) == 0

    def test_relationship_with_missing_technique_ignored(self):
        """Test relationship with unknown technique is ignored."""
        data = {
            "objects": [
                {
                    "type": "intrusion-set",
                    "id": "intrusion-set--exists",
                    "name": "Exists",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "G1234"}
                    ],
                },
                {
                    "type": "relationship",
                    "relationship_type": "uses",
                    "source_ref": "intrusion-set--exists",
                    "target_ref": "attack-pattern--unknown",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        group = store.groups["G1234"]
        assert len(group.techniques) == 0


class TestATTACKDataStoreLookups:
    """Tests for lookup methods."""

    @pytest.fixture
    def loaded_store(self) -> ATTACKDataStore:
        """Create a store with sample data loaded."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)
        return store

    def test_get_group_by_id(self, loaded_store: ATTACKDataStore):
        """Test getting group by ID."""
        group = loaded_store.get_group("G0007")
        assert group is not None
        assert group.name == "APT28"

    def test_get_group_by_id_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting group by ID is case-insensitive."""
        group = loaded_store.get_group("g0007")
        assert group is not None
        assert group.name == "APT28"

    def test_get_group_by_name(self, loaded_store: ATTACKDataStore):
        """Test getting group by name."""
        group = loaded_store.get_group("APT28")
        assert group is not None
        assert group.id == "G0007"

    def test_get_group_by_name_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting group by name is case-insensitive."""
        group = loaded_store.get_group("apt28")
        assert group is not None

    def test_get_group_by_alias(self, loaded_store: ATTACKDataStore):
        """Test getting group by alias."""
        group = loaded_store.get_group("Fancy Bear")
        assert group is not None
        assert group.id == "G0007"

    def test_get_group_not_found(self, loaded_store: ATTACKDataStore):
        """Test getting non-existent group."""
        group = loaded_store.get_group("NonExistent")
        assert group is None

    def test_get_technique_by_id(self, loaded_store: ATTACKDataStore):
        """Test getting technique by ID."""
        tech = loaded_store.get_technique("T1566")
        assert tech is not None
        assert tech.name == "Phishing"

    def test_get_technique_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting technique by ID is case-insensitive."""
        tech = loaded_store.get_technique("t1566")
        assert tech is not None

    def test_get_technique_not_found(self, loaded_store: ATTACKDataStore):
        """Test getting non-existent technique."""
        tech = loaded_store.get_technique("T9999")
        assert tech is None

    def test_get_tactic_by_id(self, loaded_store: ATTACKDataStore):
        """Test getting tactic by ID."""
        tactic = loaded_store.get_tactic("TA0001")
        assert tactic is not None
        assert tactic.name == "Initial Access"

    def test_get_tactic_by_shortname(self, loaded_store: ATTACKDataStore):
        """Test getting tactic by shortname."""
        tactic = loaded_store.get_tactic("initial-access")
        assert tactic is not None
        assert tactic.id == "TA0001"

    def test_get_tactic_not_found(self, loaded_store: ATTACKDataStore):
        """Test getting non-existent tactic."""
        tactic = loaded_store.get_tactic("nonexistent")
        assert tactic is None


class TestATTACKDataStoreVersionExtraction:
    """Tests for version extraction from STIX data."""

    def test_extract_version(self):
        """Test extracting version from STIX bundle."""
        store = ATTACKDataStore(quiet=True)
        version = store._extract_version(SAMPLE_STIX_DATA)

        assert version == "15.1"

    def test_extract_version_missing(self):
        """Test version extraction when not present."""
        store = ATTACKDataStore(quiet=True)
        data = {"objects": [{"type": "other-type"}]}
        version = store._extract_version(data)

        assert version is None


class TestATTACKDataStoreLoading:
    """Tests for data loading functionality."""

    def test_load_from_custom_file(self, tmp_path: Path):
        """Test loading from custom data file."""
        # Create a test data file
        data_file = tmp_path / "test-data.json"
        data_file.write_text(json.dumps(SAMPLE_STIX_DATA))

        store = ATTACKDataStore(data_file=data_file, quiet=True)
        store.load()

        assert store._loaded is True
        assert "T1566" in store.techniques
        assert "G0007" in store.groups
        assert store.version == "15.1"

    def test_load_skips_if_already_loaded(self, tmp_path: Path):
        """Test that load() skips if already loaded."""
        data_file = tmp_path / "test-data.json"
        data_file.write_text(json.dumps(SAMPLE_STIX_DATA))

        store = ATTACKDataStore(data_file=data_file, quiet=True)
        store.load()

        # Modify the store to verify it doesn't reload
        store.techniques["TEST"] = None  # type: ignore

        store.load()  # Should not reload

        assert "TEST" in store.techniques

    def test_load_force_refresh(self, tmp_path: Path):
        """Test force refresh reloads data even if already loaded."""
        data_file = tmp_path / "test-data.json"
        data_file.write_text(json.dumps(SAMPLE_STIX_DATA))

        store = ATTACKDataStore(data_file=data_file, quiet=True)
        store.load()

        # Verify initial load
        assert "T1566" in store.techniques

        # Clear techniques to verify reload happens
        store.techniques.clear()
        assert "T1566" not in store.techniques

        store.load(force_refresh=True)  # Should reload

        # Data should be back after force refresh
        assert "T1566" in store.techniques

    @patch("attack_query.store.requests.get")
    def test_load_downloads_and_caches(self, mock_get: MagicMock, tmp_path: Path):
        """Test downloading and caching data."""
        # Setup mock response
        mock_response = MagicMock()
        mock_response.json.return_value = SAMPLE_STIX_DATA
        mock_get.return_value = mock_response

        store = ATTACKDataStore(quiet=True)
        store.CACHE_DIR = tmp_path  # Use temp dir for cache

        store.load()

        assert store._loaded is True
        assert "T1566" in store.techniques
        mock_get.assert_called_once()

        # Verify cache file was created
        cache_file = tmp_path / "enterprise-attack-latest.json"
        assert cache_file.exists()

    @patch("attack_query.store.requests.get")
    def test_load_from_cache(self, mock_get: MagicMock, tmp_path: Path):
        """Test loading from cache instead of downloading."""
        # Create cache file
        cache_file = tmp_path / "enterprise-attack-latest.json"
        cache_file.write_text(json.dumps(SAMPLE_STIX_DATA))

        store = ATTACKDataStore(quiet=True)
        store.CACHE_DIR = tmp_path

        store.load()

        assert store._loaded is True
        mock_get.assert_not_called()  # Should not download

    @patch("attack_query.store.requests.get")
    def test_load_versioned_cache_never_expires(self, mock_get: MagicMock, tmp_path: Path):
        """Test that versioned cache files never expire."""
        # Create old cache file for version 12.0
        cache_file = tmp_path / "enterprise-attack-12.0.json"
        cache_file.write_text(json.dumps(SAMPLE_STIX_DATA))

        # Make the file appear old (30 days)
        import os
        import time

        old_time = time.time() - (30 * 86400)
        os.utime(cache_file, (old_time, old_time))

        store = ATTACKDataStore(version="12.0", quiet=True)
        store.CACHE_DIR = tmp_path

        store.load()

        assert store._loaded is True
        mock_get.assert_not_called()  # Should use cache despite age

    @patch("attack_query.store.requests.get")
    def test_load_latest_cache_expires(self, mock_get: MagicMock, tmp_path: Path):
        """Test that latest cache expires after max age."""
        # Create old cache file
        cache_file = tmp_path / "enterprise-attack-latest.json"
        cache_file.write_text(json.dumps(SAMPLE_STIX_DATA))

        # Make the file appear old (10 days, more than CACHE_MAX_AGE_DAYS)
        import os
        import time

        old_time = time.time() - (10 * 86400)
        os.utime(cache_file, (old_time, old_time))

        # Setup mock response
        mock_response = MagicMock()
        mock_response.json.return_value = SAMPLE_STIX_DATA
        mock_get.return_value = mock_response

        store = ATTACKDataStore(quiet=True)
        store.CACHE_DIR = tmp_path

        store.load()

        mock_get.assert_called_once()  # Should download fresh

    def test_load_failure_exits(self, tmp_path: Path):
        """Test that load failure raises SystemExit."""
        # Point to non-existent file and unreachable network
        store = ATTACKDataStore(quiet=True)
        store.CACHE_DIR = tmp_path / "nonexistent"

        with patch("attack_query.store.requests.get") as mock_get:
            mock_get.side_effect = Exception("Network error")

            with pytest.raises(SystemExit) as exc_info:
                store.load()

            assert exc_info.value.code == 1


class TestATTACKDataStoreSubtechniques:
    """Tests for sub-technique indexing and lookup."""

    @pytest.fixture
    def store_with_subtechniques(self) -> ATTACKDataStore:
        """Create a store with parent and sub-techniques."""
        store = ATTACKDataStore(quiet=True)
        # Add a second sub-technique for testing
        data = dict(SAMPLE_STIX_DATA)
        data["objects"] = list(SAMPLE_STIX_DATA["objects"]) + [
            {
                "type": "attack-pattern",
                "id": "attack-pattern--test3",
                "name": "Spearphishing Link",
                "description": "Spearphishing link sub-technique",
                "x_mitre_is_subtechnique": True,
                "kill_chain_phases": [
                    {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}
                ],
                "external_references": [
                    {"source_name": "mitre-attack", "external_id": "T1566.002"}
                ],
            }
        ]
        store._parse_data(data)
        return store

    def test_subtechniques_by_parent_index_built(self, store_with_subtechniques):
        """Test that subtechniques_by_parent index is built during parsing."""
        assert "T1566" in store_with_subtechniques.subtechniques_by_parent
        assert store_with_subtechniques.subtechniques_by_parent["T1566"] == {
            "T1566.001",
            "T1566.002",
        }

    def test_get_subtechniques(self, store_with_subtechniques):
        """Test get_subtechniques returns sub-techniques of a parent."""
        subtechniques = store_with_subtechniques.get_subtechniques("T1566")

        assert len(subtechniques) == 2
        ids = {t.id for t in subtechniques}
        assert ids == {"T1566.001", "T1566.002"}

    def test_get_subtechniques_case_insensitive(self, store_with_subtechniques):
        """Test get_subtechniques is case-insensitive."""
        subtechniques = store_with_subtechniques.get_subtechniques("t1566")

        assert len(subtechniques) == 2

    def test_get_subtechniques_no_children(self, store_with_subtechniques):
        """Test get_subtechniques returns empty for technique with no sub-techniques."""
        # T1566.001 is a sub-technique, has no children
        subtechniques = store_with_subtechniques.get_subtechniques("T1566.001")

        assert subtechniques == []

    def test_get_parent_technique(self, store_with_subtechniques):
        """Test get_parent_technique returns parent of a sub-technique."""
        parent = store_with_subtechniques.get_parent_technique("T1566.001")

        assert parent is not None
        assert parent.id == "T1566"
        assert parent.name == "Phishing"

    def test_get_parent_technique_case_insensitive(self, store_with_subtechniques):
        """Test get_parent_technique is case-insensitive."""
        parent = store_with_subtechniques.get_parent_technique("t1566.001")

        assert parent is not None
        assert parent.id == "T1566"

    def test_get_parent_technique_not_subtechnique(self, store_with_subtechniques):
        """Test get_parent_technique returns None for parent technique."""
        parent = store_with_subtechniques.get_parent_technique("T1566")

        assert parent is None

    def test_get_parent_technique_not_found(self, store_with_subtechniques):
        """Test get_parent_technique returns None for non-existent technique."""
        parent = store_with_subtechniques.get_parent_technique("T9999.001")

        assert parent is None


class TestATTACKDataStoreLogging:
    """Tests for logging functionality."""

    def test_log_prints_when_not_quiet(self, capsys):
        """Test that _log prints when not in quiet mode."""
        store = ATTACKDataStore(quiet=False)
        store._log("Test message")

        captured = capsys.readouterr()
        assert "Test message" in captured.out

    def test_log_silent_when_quiet(self, capsys):
        """Test that _log is silent in quiet mode."""
        store = ATTACKDataStore(quiet=True)
        store._log("Test message")

        captured = capsys.readouterr()
        assert captured.out == ""


class TestATTACKDataStoreParsingCampaigns:
    """Tests for campaign parsing."""

    def test_parse_campaign(self):
        """Test parsing a campaign from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "C0027" in store.campaigns
        camp = store.campaigns["C0027"]
        assert camp.name == "Test Campaign"
        assert camp.first_seen == "2022-06-01T04:00:00.000Z"
        assert camp.last_seen == "2023-01-01T04:00:00.000Z"
        assert "Operation Test" in camp.aliases

    def test_campaign_indexed_by_stix_id(self):
        """Test campaign is indexed by STIX ID."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "campaign--test1" in store.campaigns_by_stix
        assert store.campaigns_by_stix["campaign--test1"].id == "C0027"

    def test_campaign_indexed_by_name(self):
        """Test campaign is indexed by lowercase name."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "test campaign" in store.campaigns_by_name
        assert store.campaigns_by_name["test campaign"].id == "C0027"

    def test_parse_campaign_uses_technique(self):
        """Test parsing campaign-uses-technique relationship."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        camp = store.campaigns["C0027"]
        assert "T1566" in camp.techniques

    def test_technique_to_campaigns_index(self):
        """Test technique_to_campaigns index is built."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "T1566" in store.technique_to_campaigns
        assert "C0027" in store.technique_to_campaigns["T1566"]

    def test_parse_campaign_attributed_to(self):
        """Test parsing campaign-attributed-to-group relationship."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        camp = store.campaigns["C0027"]
        assert "G0007" in camp.groups

    def test_group_to_campaigns_index(self):
        """Test group_to_campaigns index is built."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        assert "G0007" in store.group_to_campaigns
        assert "C0027" in store.group_to_campaigns["G0007"]

    def test_get_campaign_by_id(self):
        """Test getting campaign by ID."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        camp = store.get_campaign("C0027")
        assert camp is not None
        assert camp.name == "Test Campaign"

    def test_get_campaign_by_id_case_insensitive(self):
        """Test getting campaign by ID is case-insensitive."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        camp = store.get_campaign("c0027")
        assert camp is not None
        assert camp.name == "Test Campaign"

    def test_get_campaign_by_name(self):
        """Test getting campaign by name."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        camp = store.get_campaign("Test Campaign")
        assert camp is not None
        assert camp.id == "C0027"

    def test_get_campaign_not_found(self):
        """Test getting non-existent campaign."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(SAMPLE_STIX_DATA)

        camp = store.get_campaign("NonExistent")
        assert camp is None


# Extended STIX data with software, mitigations, data sources, and data components
EXTENDED_STIX_DATA = {
    "type": "bundle",
    "id": "bundle--extended",
    "objects": [
        # Version metadata
        {
            "type": "x-mitre-collection",
            "id": "x-mitre-collection--test",
            "x_mitre_version": "18.0",
        },
        # Tactic
        {
            "type": "x-mitre-tactic",
            "id": "x-mitre-tactic--test1",
            "name": "Execution",
            "x_mitre_shortname": "execution",
            "description": "Execution tactic",
            "external_references": [{"source_name": "mitre-attack", "external_id": "TA0002"}],
        },
        # Technique
        {
            "type": "attack-pattern",
            "id": "attack-pattern--tech1",
            "name": "Command and Scripting Interpreter",
            "description": "Command execution technique",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [{"kill_chain_name": "mitre-attack", "phase_name": "execution"}],
            "external_references": [{"source_name": "mitre-attack", "external_id": "T1059"}],
        },
        # Another technique for mitigation testing
        {
            "type": "attack-pattern",
            "id": "attack-pattern--tech2",
            "name": "Phishing",
            "description": "Phishing technique",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}
            ],
            "external_references": [{"source_name": "mitre-attack", "external_id": "T1566"}],
        },
        # Group
        {
            "type": "intrusion-set",
            "id": "intrusion-set--grp1",
            "name": "APT28",
            "description": "Russian threat actor",
            "aliases": ["Fancy Bear", "Sofacy"],
            "external_references": [{"source_name": "mitre-attack", "external_id": "G0007"}],
        },
        # Software (malware)
        {
            "type": "malware",
            "id": "malware--sw1",
            "name": "Mimikatz",
            "description": "Credential dumping tool",
            "x_mitre_aliases": ["Mimikatz", "sekurlsa"],
            "x_mitre_platforms": ["Windows"],
            "external_references": [{"source_name": "mitre-attack", "external_id": "S0002"}],
        },
        # Software (tool)
        {
            "type": "tool",
            "id": "tool--sw2",
            "name": "Cobalt Strike",
            "description": "Commercial adversary simulation tool",
            "x_mitre_aliases": ["Cobalt Strike", "CS"],
            "x_mitre_platforms": ["Windows", "Linux"],
            "external_references": [{"source_name": "mitre-attack", "external_id": "S0154"}],
        },
        # Revoked software (should be skipped)
        {
            "type": "malware",
            "id": "malware--revoked",
            "name": "Revoked Malware",
            "description": "This is revoked",
            "revoked": True,
            "external_references": [{"source_name": "mitre-attack", "external_id": "S9999"}],
        },
        # Mitigation
        {
            "type": "course-of-action",
            "id": "course-of-action--mit1",
            "name": "User Training",
            "description": "Train users to identify threats",
            "external_references": [{"source_name": "mitre-attack", "external_id": "M1017"}],
        },
        # Another mitigation
        {
            "type": "course-of-action",
            "id": "course-of-action--mit2",
            "name": "Network Intrusion Prevention",
            "description": "Use intrusion prevention systems",
            "external_references": [{"source_name": "mitre-attack", "external_id": "M1031"}],
        },
        # Deprecated mitigation (should be skipped)
        {
            "type": "course-of-action",
            "id": "course-of-action--deprecated",
            "name": "Deprecated Mitigation",
            "description": "This is deprecated",
            "x_mitre_deprecated": True,
            "external_references": [{"source_name": "mitre-attack", "external_id": "M9999"}],
        },
        # Data source
        {
            "type": "x-mitre-data-source",
            "id": "x-mitre-data-source--ds1",
            "name": "Process",
            "description": "Information about running processes",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "x_mitre_collection_layers": ["Host"],
            "external_references": [{"source_name": "mitre-attack", "external_id": "DS0009"}],
        },
        # Data component
        {
            "type": "x-mitre-data-component",
            "id": "x-mitre-data-component--dc1",
            "name": "Process Creation",
            "description": "A new process was created",
            "x_mitre_log_sources": [
                {"name": "Sysmon", "channel": "Microsoft-Windows-Sysmon/Operational"}
            ],
            "external_references": [{"source_name": "mitre-attack", "external_id": "DC0001"}],
        },
        # Deprecated data component (should be skipped)
        {
            "type": "x-mitre-data-component",
            "id": "x-mitre-data-component--deprecated",
            "name": "Deprecated Component",
            "description": "This is deprecated",
            "x_mitre_deprecated": True,
            "external_references": [{"source_name": "mitre-attack", "external_id": "DC9999"}],
        },
        # Campaign
        {
            "type": "campaign",
            "id": "campaign--camp1",
            "name": "Operation Test",
            "description": "A test campaign",
            "aliases": ["OpTest"],
            "first_seen": "2023-01-01T00:00:00.000Z",
            "last_seen": "2023-12-31T00:00:00.000Z",
            "external_references": [{"source_name": "mitre-attack", "external_id": "C0030"}],
        },
        # Deprecated campaign (should be skipped)
        {
            "type": "campaign",
            "id": "campaign--deprecated",
            "name": "Deprecated Campaign",
            "description": "This is deprecated",
            "x_mitre_deprecated": True,
            "external_references": [{"source_name": "mitre-attack", "external_id": "C9999"}],
        },
        # Relationships
        # Group uses technique
        {
            "type": "relationship",
            "id": "relationship--g-t",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--grp1",
            "target_ref": "attack-pattern--tech1",
        },
        # Software (malware) uses technique
        {
            "type": "relationship",
            "id": "relationship--sw-t",
            "relationship_type": "uses",
            "source_ref": "malware--sw1",
            "target_ref": "attack-pattern--tech1",
        },
        # Software (tool) uses technique
        {
            "type": "relationship",
            "id": "relationship--tool-t",
            "relationship_type": "uses",
            "source_ref": "tool--sw2",
            "target_ref": "attack-pattern--tech1",
        },
        # Group uses software
        {
            "type": "relationship",
            "id": "relationship--g-sw",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--grp1",
            "target_ref": "malware--sw1",
        },
        # Mitigation mitigates technique
        {
            "type": "relationship",
            "id": "relationship--mit-t",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--mit1",
            "target_ref": "attack-pattern--tech2",
        },
        # Campaign uses technique
        {
            "type": "relationship",
            "id": "relationship--camp-t",
            "relationship_type": "uses",
            "source_ref": "campaign--camp1",
            "target_ref": "attack-pattern--tech1",
        },
        # Campaign uses software
        {
            "type": "relationship",
            "id": "relationship--camp-sw",
            "relationship_type": "uses",
            "source_ref": "campaign--camp1",
            "target_ref": "malware--sw1",
        },
        # Campaign attributed to group
        {
            "type": "relationship",
            "id": "relationship--camp-grp",
            "relationship_type": "attributed-to",
            "source_ref": "campaign--camp1",
            "target_ref": "intrusion-set--grp1",
        },
    ],
}


class TestATTACKDataStoreParsingSoftware:
    """Tests for software parsing."""

    def test_parse_malware(self):
        """Test parsing malware from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "S0002" in store.software
        sw = store.software["S0002"]
        assert sw.name == "Mimikatz"
        assert sw.software_type == "malware"
        assert "Windows" in sw.platforms
        assert "sekurlsa" in sw.aliases

    def test_parse_tool(self):
        """Test parsing tool from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "S0154" in store.software
        sw = store.software["S0154"]
        assert sw.name == "Cobalt Strike"
        assert sw.software_type == "tool"
        assert "Linux" in sw.platforms

    def test_software_indexed_by_name(self):
        """Test software is indexed by lowercase name."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "mimikatz" in store.software_by_name
        assert store.software_by_name["mimikatz"].id == "S0002"

    def test_software_indexed_by_alias(self):
        """Test software is indexed by aliases."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "sekurlsa" in store.software_by_alias
        assert "cs" in store.software_by_alias
        assert store.software_by_alias["sekurlsa"].id == "S0002"

    def test_software_indexed_by_stix_id(self):
        """Test software is indexed by STIX ID."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "malware--sw1" in store.software_by_stix
        assert store.software_by_stix["malware--sw1"].id == "S0002"

    def test_revoked_software_skipped(self):
        """Test that revoked software is not parsed."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "S9999" not in store.software

    def test_software_without_attack_id_skipped(self):
        """Test software without ATT&CK ID is skipped."""
        data = {
            "objects": [
                {
                    "type": "malware",
                    "id": "malware--no-id",
                    "name": "No ID Malware",
                    "external_references": [
                        {"source_name": "other-source", "external_id": "OTHER123"}
                    ],
                }
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        assert len(store.software) == 0


class TestATTACKDataStoreParsingMitigations:
    """Tests for mitigation parsing."""

    def test_parse_mitigation(self):
        """Test parsing mitigation from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "M1017" in store.mitigations
        mit = store.mitigations["M1017"]
        assert mit.name == "User Training"
        assert "Train users" in mit.description

    def test_mitigation_indexed_by_name(self):
        """Test mitigation is indexed by lowercase name."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "user training" in store.mitigations_by_name
        assert store.mitigations_by_name["user training"].id == "M1017"

    def test_mitigation_indexed_by_stix_id(self):
        """Test mitigation is indexed by STIX ID."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "course-of-action--mit1" in store.mitigations_by_stix
        assert store.mitigations_by_stix["course-of-action--mit1"].id == "M1017"

    def test_deprecated_mitigation_skipped(self):
        """Test that deprecated mitigations are not parsed."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "M9999" not in store.mitigations

    def test_mitigation_without_attack_id_skipped(self):
        """Test mitigation without ATT&CK ID is skipped."""
        data = {
            "objects": [
                {
                    "type": "course-of-action",
                    "id": "course-of-action--no-id",
                    "name": "No ID Mitigation",
                    "external_references": [
                        {"source_name": "other-source", "external_id": "OTHER123"}
                    ],
                }
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        assert len(store.mitigations) == 0


class TestATTACKDataStoreParsingDataSources:
    """Tests for data source parsing."""

    def test_parse_data_source(self):
        """Test parsing data source from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "DS0009" in store.data_sources
        ds = store.data_sources["DS0009"]
        assert ds.name == "Process"
        assert "Windows" in ds.platforms
        assert "Host" in ds.collection_layers

    def test_data_source_indexed_by_name(self):
        """Test data source is indexed by lowercase name."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "process" in store.data_sources_by_name
        assert store.data_sources_by_name["process"].id == "DS0009"

    def test_data_source_without_attack_id_skipped(self):
        """Test data source without ATT&CK ID is skipped."""
        data = {
            "objects": [
                {
                    "type": "x-mitre-data-source",
                    "id": "x-mitre-data-source--no-id",
                    "name": "No ID Data Source",
                    "external_references": [
                        {"source_name": "other-source", "external_id": "OTHER123"}
                    ],
                }
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        assert len(store.data_sources) == 0


class TestATTACKDataStoreParsingDataComponents:
    """Tests for data component parsing."""

    def test_parse_data_component(self):
        """Test parsing data component from STIX data."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "DC0001" in store.data_components
        dc = store.data_components["DC0001"]
        assert dc.name == "Process Creation"
        assert len(dc.log_sources) == 1
        assert dc.log_sources[0]["name"] == "Sysmon"

    def test_data_component_indexed_by_name(self):
        """Test data component is indexed by lowercase name."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "process creation" in store.data_components_by_name
        assert store.data_components_by_name["process creation"].id == "DC0001"

    def test_data_component_indexed_by_stix_id(self):
        """Test data component is indexed by STIX ID."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "x-mitre-data-component--dc1" in store.data_components_by_stix

    def test_deprecated_data_component_skipped(self):
        """Test that deprecated data components are not parsed."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "DC9999" not in store.data_components

    def test_data_component_without_attack_id_skipped(self):
        """Test data component without ATT&CK ID is skipped."""
        data = {
            "objects": [
                {
                    "type": "x-mitre-data-component",
                    "id": "x-mitre-data-component--no-id",
                    "name": "No ID Component",
                    "external_references": [
                        {"source_name": "other-source", "external_id": "OTHER123"}
                    ],
                }
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        assert len(store.data_components) == 0


class TestATTACKDataStoreParsingSoftwareRelationships:
    """Tests for software relationship parsing."""

    def test_parse_software_uses_technique(self):
        """Test parsing software-uses-technique relationship."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        sw = store.software["S0002"]
        assert "T1059" in sw.techniques

    def test_technique_to_software_index(self):
        """Test technique_to_software index is built."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "T1059" in store.technique_to_software
        assert "S0002" in store.technique_to_software["T1059"]
        assert "S0154" in store.technique_to_software["T1059"]

    def test_parse_group_uses_software(self):
        """Test parsing group-uses-software relationship."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "G0007" in store.group_to_software
        assert "S0002" in store.group_to_software["G0007"]

    def test_software_to_groups_index(self):
        """Test software_to_groups index is built."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "S0002" in store.software_to_groups
        assert "G0007" in store.software_to_groups["S0002"]

    def test_software_relationship_missing_software_ignored(self):
        """Test relationship with unknown software is ignored."""
        data = {
            "objects": [
                {
                    "type": "attack-pattern",
                    "id": "attack-pattern--exists",
                    "name": "Exists",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "T1234"}
                    ],
                },
                {
                    "type": "relationship",
                    "relationship_type": "uses",
                    "source_ref": "malware--unknown",
                    "target_ref": "attack-pattern--exists",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        assert len(store.technique_to_software) == 0


class TestATTACKDataStoreParsingMitigationRelationships:
    """Tests for mitigation relationship parsing."""

    def test_parse_mitigation_mitigates_technique(self):
        """Test parsing mitigation-mitigates-technique relationship."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        mit = store.mitigations["M1017"]
        assert "T1566" in mit.techniques

    def test_technique_to_mitigations_index(self):
        """Test technique_to_mitigations index is built."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "T1566" in store.technique_to_mitigations
        assert "M1017" in store.technique_to_mitigations["T1566"]

    def test_mitigation_relationship_missing_mitigation_ignored(self):
        """Test relationship with unknown mitigation is ignored."""
        data = {
            "objects": [
                {
                    "type": "attack-pattern",
                    "id": "attack-pattern--exists",
                    "name": "Exists",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "T1234"}
                    ],
                },
                {
                    "type": "relationship",
                    "relationship_type": "mitigates",
                    "source_ref": "course-of-action--unknown",
                    "target_ref": "attack-pattern--exists",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        assert len(store.technique_to_mitigations) == 0


class TestATTACKDataStoreParsingCampaignRelationships:
    """Tests for campaign relationship parsing."""

    def test_parse_campaign_uses_software(self):
        """Test parsing campaign-uses-software relationship."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        camp = store.campaigns["C0030"]
        assert "S0002" in camp.software

    def test_deprecated_campaign_skipped(self):
        """Test that deprecated campaigns are not parsed."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        assert "C9999" not in store.campaigns

    def test_campaign_indexed_by_alias(self):
        """Test campaign is indexed by aliases."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)

        # Alias "OpTest" should map to campaign
        assert "optest" in store.campaigns_by_name
        assert store.campaigns_by_name["optest"].id == "C0030"

    def test_campaign_uses_software_missing_software_ignored(self):
        """Test relationship with unknown software is ignored."""
        data = {
            "objects": [
                {
                    "type": "campaign",
                    "id": "campaign--exists",
                    "name": "Exists",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "C1234"}
                    ],
                },
                {
                    "type": "relationship",
                    "relationship_type": "uses",
                    "source_ref": "campaign--exists",
                    "target_ref": "malware--unknown",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        camp = store.campaigns["C1234"]
        assert len(camp.software) == 0

    def test_campaign_attribution_missing_group_ignored(self):
        """Test attribution with unknown group is ignored."""
        data = {
            "objects": [
                {
                    "type": "campaign",
                    "id": "campaign--exists",
                    "name": "Exists",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "C1234"}
                    ],
                },
                {
                    "type": "relationship",
                    "relationship_type": "attributed-to",
                    "source_ref": "campaign--exists",
                    "target_ref": "intrusion-set--unknown",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        camp = store.campaigns["C1234"]
        assert len(camp.groups) == 0


class TestATTACKDataStoreDetectionMappings:
    """Tests for detection mapping building."""

    def test_build_detection_mappings(self):
        """Test detection mappings are built from STIX data."""
        # Create STIX data with detection strategy, analytic, and data component
        data = {
            "objects": [
                # Technique
                {
                    "type": "attack-pattern",
                    "id": "attack-pattern--tech1",
                    "name": "Test Technique",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "T1059"}
                    ],
                },
                # Data component
                {
                    "type": "x-mitre-data-component",
                    "id": "x-mitre-data-component--dc1",
                    "name": "Process Creation",
                    "description": "Process creation events",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "DC0001"}
                    ],
                },
                # Analytic
                {
                    "type": "x-mitre-analytic",
                    "id": "x-mitre-analytic--ana1",
                    "name": "Test Analytic",
                    "x_mitre_log_source_references": [
                        {"x_mitre_data_component_ref": "x-mitre-data-component--dc1"}
                    ],
                },
                # Detection strategy
                {
                    "type": "x-mitre-detection-strategy",
                    "id": "x-mitre-detection-strategy--det1",
                    "name": "Detect Command Execution",
                    "x_mitre_analytic_refs": ["x-mitre-analytic--ana1"],
                },
                # Detection strategy detects technique
                {
                    "type": "relationship",
                    "relationship_type": "detects",
                    "source_ref": "x-mitre-detection-strategy--det1",
                    "target_ref": "attack-pattern--tech1",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        # Data component should have the technique in its techniques set
        dc = store.data_components["DC0001"]
        assert "T1059" in dc.techniques

    def test_build_detection_mappings_deprecated_analytic_skipped(self):
        """Test deprecated analytics are skipped."""
        data = {
            "objects": [
                {
                    "type": "attack-pattern",
                    "id": "attack-pattern--tech1",
                    "name": "Test Technique",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "T1059"}
                    ],
                },
                {
                    "type": "x-mitre-data-component",
                    "id": "x-mitre-data-component--dc1",
                    "name": "Process Creation",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "DC0001"}
                    ],
                },
                {
                    "type": "x-mitre-analytic",
                    "id": "x-mitre-analytic--deprecated",
                    "name": "Deprecated Analytic",
                    "x_mitre_deprecated": True,
                    "x_mitre_log_source_references": [
                        {"x_mitre_data_component_ref": "x-mitre-data-component--dc1"}
                    ],
                },
                {
                    "type": "x-mitre-detection-strategy",
                    "id": "x-mitre-detection-strategy--det1",
                    "name": "Detection",
                    "x_mitre_analytic_refs": ["x-mitre-analytic--deprecated"],
                },
                {
                    "type": "relationship",
                    "relationship_type": "detects",
                    "source_ref": "x-mitre-detection-strategy--det1",
                    "target_ref": "attack-pattern--tech1",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        # Data component should NOT have the technique due to deprecated analytic
        dc = store.data_components["DC0001"]
        assert len(dc.techniques) == 0

    def test_build_detection_mappings_deprecated_strategy_skipped(self):
        """Test deprecated detection strategies are skipped."""
        data = {
            "objects": [
                {
                    "type": "attack-pattern",
                    "id": "attack-pattern--tech1",
                    "name": "Test Technique",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "T1059"}
                    ],
                },
                {
                    "type": "x-mitre-data-component",
                    "id": "x-mitre-data-component--dc1",
                    "name": "Process Creation",
                    "external_references": [
                        {"source_name": "mitre-attack", "external_id": "DC0001"}
                    ],
                },
                {
                    "type": "x-mitre-analytic",
                    "id": "x-mitre-analytic--ana1",
                    "name": "Analytic",
                    "x_mitre_log_source_references": [
                        {"x_mitre_data_component_ref": "x-mitre-data-component--dc1"}
                    ],
                },
                {
                    "type": "x-mitre-detection-strategy",
                    "id": "x-mitre-detection-strategy--deprecated",
                    "name": "Deprecated Strategy",
                    "x_mitre_deprecated": True,
                    "x_mitre_analytic_refs": ["x-mitre-analytic--ana1"],
                },
                {
                    "type": "relationship",
                    "relationship_type": "detects",
                    "source_ref": "x-mitre-detection-strategy--deprecated",
                    "target_ref": "attack-pattern--tech1",
                },
            ]
        }
        store = ATTACKDataStore(quiet=True)
        store._parse_data(data)

        # Data component should NOT have the technique due to deprecated strategy
        dc = store.data_components["DC0001"]
        assert len(dc.techniques) == 0


class TestATTACKDataStoreSoftwareLookups:
    """Tests for software lookup methods."""

    @pytest.fixture
    def loaded_store(self) -> ATTACKDataStore:
        """Create a store with extended data loaded."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)
        return store

    def test_get_software_by_id(self, loaded_store: ATTACKDataStore):
        """Test getting software by ID."""
        sw = loaded_store.get_software("S0002")
        assert sw is not None
        assert sw.name == "Mimikatz"

    def test_get_software_by_id_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting software by ID is case-insensitive."""
        sw = loaded_store.get_software("s0002")
        assert sw is not None

    def test_get_software_by_name(self, loaded_store: ATTACKDataStore):
        """Test getting software by name."""
        sw = loaded_store.get_software("Mimikatz")
        assert sw is not None
        assert sw.id == "S0002"

    def test_get_software_by_name_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting software by name is case-insensitive."""
        sw = loaded_store.get_software("mimikatz")
        assert sw is not None

    def test_get_software_by_alias(self, loaded_store: ATTACKDataStore):
        """Test getting software by alias."""
        sw = loaded_store.get_software("sekurlsa")
        assert sw is not None
        assert sw.id == "S0002"

    def test_get_software_not_found(self, loaded_store: ATTACKDataStore):
        """Test getting non-existent software."""
        sw = loaded_store.get_software("NonExistent")
        assert sw is None


class TestATTACKDataStoreMitigationLookups:
    """Tests for mitigation lookup methods."""

    @pytest.fixture
    def loaded_store(self) -> ATTACKDataStore:
        """Create a store with extended data loaded."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)
        return store

    def test_get_mitigation_by_id(self, loaded_store: ATTACKDataStore):
        """Test getting mitigation by ID."""
        mit = loaded_store.get_mitigation("M1017")
        assert mit is not None
        assert mit.name == "User Training"

    def test_get_mitigation_by_id_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting mitigation by ID is case-insensitive."""
        mit = loaded_store.get_mitigation("m1017")
        assert mit is not None

    def test_get_mitigation_by_name(self, loaded_store: ATTACKDataStore):
        """Test getting mitigation by name."""
        mit = loaded_store.get_mitigation("User Training")
        assert mit is not None
        assert mit.id == "M1017"

    def test_get_mitigation_by_name_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting mitigation by name is case-insensitive."""
        mit = loaded_store.get_mitigation("user training")
        assert mit is not None

    def test_get_mitigation_not_found(self, loaded_store: ATTACKDataStore):
        """Test getting non-existent mitigation."""
        mit = loaded_store.get_mitigation("NonExistent")
        assert mit is None


class TestATTACKDataStoreDataSourceLookups:
    """Tests for data source lookup methods."""

    @pytest.fixture
    def loaded_store(self) -> ATTACKDataStore:
        """Create a store with extended data loaded."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)
        return store

    def test_get_data_source_by_id(self, loaded_store: ATTACKDataStore):
        """Test getting data source by ID."""
        ds = loaded_store.get_data_source("DS0009")
        assert ds is not None
        assert ds.name == "Process"

    def test_get_data_source_by_id_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting data source by ID is case-insensitive."""
        ds = loaded_store.get_data_source("ds0009")
        assert ds is not None

    def test_get_data_source_by_name(self, loaded_store: ATTACKDataStore):
        """Test getting data source by name."""
        ds = loaded_store.get_data_source("Process")
        assert ds is not None
        assert ds.id == "DS0009"

    def test_get_data_source_by_name_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting data source by name is case-insensitive."""
        ds = loaded_store.get_data_source("process")
        assert ds is not None

    def test_get_data_source_not_found(self, loaded_store: ATTACKDataStore):
        """Test getting non-existent data source."""
        ds = loaded_store.get_data_source("NonExistent")
        assert ds is None


class TestATTACKDataStoreDataComponentLookups:
    """Tests for data component lookup methods."""

    @pytest.fixture
    def loaded_store(self) -> ATTACKDataStore:
        """Create a store with extended data loaded."""
        store = ATTACKDataStore(quiet=True)
        store._parse_data(EXTENDED_STIX_DATA)
        return store

    def test_get_data_component_by_id(self, loaded_store: ATTACKDataStore):
        """Test getting data component by ID."""
        dc = loaded_store.get_data_component("DC0001")
        assert dc is not None
        assert dc.name == "Process Creation"

    def test_get_data_component_by_id_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting data component by ID is case-insensitive."""
        dc = loaded_store.get_data_component("dc0001")
        assert dc is not None

    def test_get_data_component_by_name(self, loaded_store: ATTACKDataStore):
        """Test getting data component by name."""
        dc = loaded_store.get_data_component("Process Creation")
        assert dc is not None
        assert dc.id == "DC0001"

    def test_get_data_component_by_name_case_insensitive(self, loaded_store: ATTACKDataStore):
        """Test getting data component by name is case-insensitive."""
        dc = loaded_store.get_data_component("process creation")
        assert dc is not None

    def test_get_data_component_not_found(self, loaded_store: ATTACKDataStore):
        """Test getting non-existent data component."""
        dc = loaded_store.get_data_component("NonExistent")
        assert dc is None
