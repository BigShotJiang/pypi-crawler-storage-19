"""Tests for attack_query.completion."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from attack_query.completion.factory import get_completion_model
from attack_query.completion.protocol import CompletionError, CompletionModel


class TestCompletionProtocol:
    """Tests for CompletionModel protocol."""

    def test_protocol_implementation(self):
        """Test that a class implementing the protocol is recognized."""

        class MockModel:
            @property
            def model_name(self) -> str:
                return "mock:test"

            def complete(self, prompt: str) -> str:
                return f"response to: {prompt}"

        model = MockModel()
        assert isinstance(model, CompletionModel)

    def test_protocol_missing_method(self):
        """Test that incomplete implementations are not recognized."""

        class IncompleteModel:
            @property
            def model_name(self) -> str:
                return "incomplete"

            # Missing complete() method

        model = IncompleteModel()
        assert not isinstance(model, CompletionModel)


class TestCompletionFactory:
    """Tests for get_completion_model factory."""

    def test_invalid_provider_string(self):
        """Test error for invalid provider string format."""
        with pytest.raises(CompletionError, match="Invalid provider string"):
            get_completion_model("no-colon-here")

    def test_unknown_provider(self):
        """Test error for unknown provider."""
        with pytest.raises(CompletionError, match="Unknown provider"):
            get_completion_model("unknown:model")

    def test_ollama_provider(self):
        """Test Ollama provider creation."""
        model = get_completion_model("ollama:llama3.2")
        assert model.model_name == "ollama:llama3.2"

    def test_openai_provider_no_key(self):
        """Test OpenAI provider without API key."""
        with patch.dict("os.environ", {}, clear=True):
            # Remove OPENAI_API_KEY if set
            import os

            if "OPENAI_API_KEY" in os.environ:
                del os.environ["OPENAI_API_KEY"]

            with pytest.raises(CompletionError, match="API key required"):
                get_completion_model("openai:gpt-4o-mini")

    def test_openai_provider_with_key(self):
        """Test OpenAI provider with API key."""
        with patch.dict("os.environ", {"OPENAI_API_KEY": "sk-test-key"}):
            model = get_completion_model("openai:gpt-4o-mini")
            assert model.model_name == "openai:gpt-4o-mini"

    def test_default_model_from_env(self):
        """Test default model from environment variable."""
        with patch.dict("os.environ", {"ATTACK_QUERY_COMPLETION_MODEL": "ollama:mistral"}):
            model = get_completion_model()
            assert model.model_name == "ollama:mistral"


class TestOllamaModel:
    """Tests for OllamaModel."""

    def test_model_name(self):
        """Test model name property."""
        from attack_query.completion.ollama import OllamaModel

        model = OllamaModel(model="llama3.2")
        assert model.model_name == "ollama:llama3.2"

    def test_custom_base_url(self):
        """Test custom base URL."""
        from attack_query.completion.ollama import OllamaModel

        model = OllamaModel(model="test", base_url="http://custom:1234")
        assert model._base_url == "http://custom:1234"

    @patch("attack_query.completion.ollama._get_httpx")
    def test_complete_success(self, mock_get_httpx: MagicMock):
        """Test successful completion."""
        from attack_query.completion.ollama import OllamaModel

        # Mock httpx response
        mock_httpx = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {"response": "techniques used by APT28"}
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OllamaModel(model="test")
        result = model.complete("normalize this query")

        assert result == "techniques used by APT28"
        mock_httpx.post.assert_called_once()

    @patch("attack_query.completion.ollama._get_httpx")
    def test_complete_connection_error(self, mock_get_httpx: MagicMock):
        """Test connection error handling."""
        from attack_query.completion.ollama import OllamaModel

        # Create a proper mock that simulates httpx behavior
        mock_httpx = MagicMock()

        # Create custom exception classes
        class MockRequestError(Exception):
            pass

        class MockHTTPStatusError(Exception):
            pass

        mock_httpx.RequestError = MockRequestError
        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.post.side_effect = MockRequestError("Connection refused")
        mock_get_httpx.return_value = mock_httpx

        model = OllamaModel(model="test")
        with pytest.raises(CompletionError, match="Ollama connection error"):
            model.complete("test")

    @patch("attack_query.completion.ollama._get_httpx")
    def test_complete_http_status_error(self, mock_get_httpx: MagicMock):
        """Test HTTP status error handling."""
        from attack_query.completion.ollama import OllamaModel

        mock_httpx = MagicMock()

        class MockHTTPStatusError(Exception):
            def __init__(self, msg: str, status_code: int):
                super().__init__(msg)
                self.response = MagicMock()
                self.response.status_code = status_code

        class MockRequestError(Exception):
            pass

        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.RequestError = MockRequestError

        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = MockHTTPStatusError("Not Found", 404)
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OllamaModel(model="test")
        with pytest.raises(CompletionError, match="Ollama API error: 404"):
            model.complete("test")

    @patch("attack_query.completion.ollama._get_httpx")
    def test_complete_generic_error(self, mock_get_httpx: MagicMock):
        """Test generic exception handling."""
        from attack_query.completion.ollama import OllamaModel

        mock_httpx = MagicMock()

        class MockHTTPStatusError(Exception):
            pass

        class MockRequestError(Exception):
            pass

        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.RequestError = MockRequestError
        mock_httpx.post.side_effect = ValueError("Unexpected error")
        mock_get_httpx.return_value = mock_httpx

        model = OllamaModel(model="test")
        with pytest.raises(CompletionError, match="Ollama error"):
            model.complete("test")

    @patch("attack_query.completion.ollama._get_httpx")
    def test_complete_empty_response(self, mock_get_httpx: MagicMock):
        """Test handling of empty response."""
        from attack_query.completion.ollama import OllamaModel

        mock_httpx = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {}  # Missing "response" key
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OllamaModel(model="test")
        result = model.complete("test")

        assert result == ""  # Should return empty string gracefully

    def test_base_url_from_env(self):
        """Test base URL from environment variable."""
        from attack_query.completion.ollama import OllamaModel

        with patch.dict("os.environ", {"OLLAMA_BASE_URL": "http://remote:11434"}):
            model = OllamaModel(model="test")
            assert model._base_url == "http://remote:11434"

    def test_timeout_parameter(self):
        """Test custom timeout parameter."""
        from attack_query.completion.ollama import OllamaModel

        model = OllamaModel(model="test", timeout=60.0)
        assert model._timeout == 60.0


class TestOpenAIModel:
    """Tests for OpenAIModel."""

    def test_model_name(self):
        """Test model name property."""
        from attack_query.completion.openai import OpenAIModel

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        assert model.model_name == "openai:gpt-4o-mini"

    def test_missing_api_key(self):
        """Test error when API key is missing."""
        from attack_query.completion.openai import OpenAIModel

        with patch.dict("os.environ", {}, clear=True):
            import os

            if "OPENAI_API_KEY" in os.environ:
                del os.environ["OPENAI_API_KEY"]

            with pytest.raises(CompletionError, match="API key required"):
                OpenAIModel(model="gpt-4o-mini")

    @patch("attack_query.completion.openai._get_httpx")
    def test_complete_success(self, mock_get_httpx: MagicMock):
        """Test successful completion."""
        from attack_query.completion.openai import OpenAIModel

        # Mock httpx response
        mock_httpx = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "techniques used by APT28"}}]
        }
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        result = model.complete("normalize this query")

        assert result == "techniques used by APT28"
        mock_httpx.post.assert_called_once()

    @patch("attack_query.completion.openai._get_httpx")
    def test_complete_http_status_error(self, mock_get_httpx: MagicMock):
        """Test HTTP status error handling."""
        from attack_query.completion.openai import OpenAIModel

        mock_httpx = MagicMock()

        class MockHTTPStatusError(Exception):
            def __init__(self, msg: str, status_code: int):
                super().__init__(msg)
                self.response = MagicMock()
                self.response.status_code = status_code

        class MockRequestError(Exception):
            pass

        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.RequestError = MockRequestError

        mock_response = MagicMock()
        mock_response.raise_for_status.side_effect = MockHTTPStatusError("Unauthorized", 401)
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        with pytest.raises(CompletionError, match="OpenAI API error: 401"):
            model.complete("test")

    @patch("attack_query.completion.openai._get_httpx")
    def test_complete_connection_error(self, mock_get_httpx: MagicMock):
        """Test connection error handling."""
        from attack_query.completion.openai import OpenAIModel

        mock_httpx = MagicMock()

        class MockHTTPStatusError(Exception):
            pass

        class MockRequestError(Exception):
            pass

        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.RequestError = MockRequestError
        mock_httpx.post.side_effect = MockRequestError("Connection refused")
        mock_get_httpx.return_value = mock_httpx

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        with pytest.raises(CompletionError, match="OpenAI connection error"):
            model.complete("test")

    @patch("attack_query.completion.openai._get_httpx")
    def test_complete_parsing_error_missing_choices(self, mock_get_httpx: MagicMock):
        """Test response parsing error with missing choices."""
        from attack_query.completion.openai import OpenAIModel

        mock_httpx = MagicMock()

        # Need mock exception classes for the except clause
        class MockHTTPStatusError(Exception):
            pass

        class MockRequestError(Exception):
            pass

        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.RequestError = MockRequestError

        mock_response = MagicMock()
        mock_response.json.return_value = {}  # Missing "choices" key
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        with pytest.raises(CompletionError, match="OpenAI response parsing error"):
            model.complete("test")

    @patch("attack_query.completion.openai._get_httpx")
    def test_complete_parsing_error_empty_choices(self, mock_get_httpx: MagicMock):
        """Test response parsing error with empty choices."""
        from attack_query.completion.openai import OpenAIModel

        mock_httpx = MagicMock()

        # Need mock exception classes for the except clause
        class MockHTTPStatusError(Exception):
            pass

        class MockRequestError(Exception):
            pass

        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.RequestError = MockRequestError

        mock_response = MagicMock()
        mock_response.json.return_value = {"choices": []}  # Empty choices
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        with pytest.raises(CompletionError, match="OpenAI response parsing error"):
            model.complete("test")

    @patch("attack_query.completion.openai._get_httpx")
    def test_complete_generic_error(self, mock_get_httpx: MagicMock):
        """Test generic exception handling."""
        from attack_query.completion.openai import OpenAIModel

        mock_httpx = MagicMock()

        class MockHTTPStatusError(Exception):
            pass

        class MockRequestError(Exception):
            pass

        mock_httpx.HTTPStatusError = MockHTTPStatusError
        mock_httpx.RequestError = MockRequestError
        mock_httpx.post.side_effect = ValueError("Unexpected error")
        mock_get_httpx.return_value = mock_httpx

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        with pytest.raises(CompletionError, match="OpenAI error"):
            model.complete("test")

    def test_api_key_from_env(self):
        """Test API key from environment variable."""
        from attack_query.completion.openai import OpenAIModel

        with patch.dict("os.environ", {"OPENAI_API_KEY": "sk-env-key"}):
            model = OpenAIModel(model="gpt-4o-mini")
            assert model._api_key == "sk-env-key"

    def test_custom_base_url(self):
        """Test custom base URL for OpenAI-compatible APIs."""
        from attack_query.completion.openai import OpenAIModel

        model = OpenAIModel(
            model="gpt-4o-mini",
            api_key="sk-test",
            base_url="https://api.custom.com/v1",
        )
        assert model._base_url == "https://api.custom.com/v1"

    def test_timeout_parameter(self):
        """Test custom timeout parameter."""
        from attack_query.completion.openai import OpenAIModel

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test", timeout=60.0)
        assert model._timeout == 60.0

    @patch("attack_query.completion.openai._get_httpx")
    def test_complete_strips_whitespace(self, mock_get_httpx: MagicMock):
        """Test that response content is stripped of whitespace."""
        from attack_query.completion.openai import OpenAIModel

        mock_httpx = MagicMock()
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "  techniques used by APT28  \n"}}]
        }
        mock_httpx.post.return_value = mock_response
        mock_get_httpx.return_value = mock_httpx

        model = OpenAIModel(model="gpt-4o-mini", api_key="sk-test")
        result = model.complete("test")

        assert result == "techniques used by APT28"
