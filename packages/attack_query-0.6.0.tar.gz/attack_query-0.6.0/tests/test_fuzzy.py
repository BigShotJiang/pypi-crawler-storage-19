"""Tests for attack_query.fuzzy."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from attack_query.fuzzy import (
    fuzzy_available,
    suggest_group,
    suggest_query_pattern,
    suggest_software,
    suggest_technique,
)
from attack_query.models import Group, Software, Technique


@pytest.fixture
def mock_store() -> MagicMock:
    """Create a mock store with test data."""
    store = MagicMock()

    # Create test groups
    apt28 = Group(
        id="G0007",
        stix_id="intrusion-set--1",
        name="APT28",
        description="...",
        aliases=["Fancy Bear", "Sofacy"],
        techniques=set(),
    )
    apt29 = Group(
        id="G0016",
        stix_id="intrusion-set--2",
        name="APT29",
        description="...",
        aliases=["Cozy Bear"],
        techniques=set(),
    )

    store.groups = {"G0007": apt28, "G0016": apt29}

    # Create test techniques
    store.techniques = {
        "T1566": Technique(
            id="T1566",
            stix_id="attack-pattern--1",
            name="Phishing",
            description="...",
            tactics=["initial-access"],
        ),
        "T1059": Technique(
            id="T1059",
            stix_id="attack-pattern--2",
            name="Command and Scripting Interpreter",
            description="...",
            tactics=["execution"],
        ),
    }

    # Create test software
    mimikatz = Software(
        id="S0002",
        stix_id="malware--1",
        name="Mimikatz",
        description="...",
        software_type="malware",
        aliases=["sekurlsa"],
        platforms=["Windows"],
        techniques=set(),
    )
    store.software = {"S0002": mimikatz}

    return store


class TestFuzzyAvailable:
    """Tests for fuzzy_available()."""

    def test_fuzzy_available(self):
        """Test that fuzzy matching is available when thefuzz is installed."""
        # thefuzz should be installed in dev mode
        assert fuzzy_available() is True


class TestSuggestGroup:
    """Tests for suggest_group()."""

    def test_suggest_group_exact_match(self, mock_store: MagicMock):
        """Test that exact matches don't return suggestions."""
        result = suggest_group("APT28", mock_store)
        # Exact match returns the match
        assert result == "APT28"

    def test_suggest_group_typo(self, mock_store: MagicMock):
        """Test suggestion for a typo."""
        result = suggest_group("APT27", mock_store)
        # Should suggest APT28 or APT29
        assert result in ("APT28", "APT29")

    def test_suggest_group_alias(self, mock_store: MagicMock):
        """Test suggestion for an alias with typo."""
        result = suggest_group("Fancy Bare", mock_store)
        # Should suggest "Fancy Bear"
        assert result == "Fancy Bear"

    def test_suggest_group_no_match(self, mock_store: MagicMock):
        """Test no suggestion for completely unrelated input."""
        result = suggest_group("XYZ123", mock_store, threshold=90)
        assert result is None

    def test_suggest_group_empty_store(self):
        """Test with empty store."""
        empty_store = MagicMock()
        empty_store.groups = {}
        result = suggest_group("APT28", empty_store)
        assert result is None


class TestSuggestTechnique:
    """Tests for suggest_technique()."""

    def test_suggest_technique_typo(self, mock_store: MagicMock):
        """Test suggestion for a technique ID typo."""
        result = suggest_technique("T1565", mock_store)
        # Should suggest T1566
        assert result == "T1566"

    def test_suggest_technique_by_name(self, mock_store: MagicMock):
        """Test suggestion by technique name."""
        result = suggest_technique("phising", mock_store)
        # Should suggest Phishing -> T1566
        assert result == "T1566"

    def test_suggest_technique_no_match(self, mock_store: MagicMock):
        """Test no suggestion for unrelated input."""
        result = suggest_technique("XYZ", mock_store, threshold=90)
        assert result is None


class TestSuggestSoftware:
    """Tests for suggest_software()."""

    def test_suggest_software_typo(self, mock_store: MagicMock):
        """Test suggestion for a software name typo."""
        result = suggest_software("Mimicatz", mock_store)
        # Should suggest Mimikatz
        assert result == "Mimikatz"

    def test_suggest_software_alias(self, mock_store: MagicMock):
        """Test suggestion for an alias."""
        result = suggest_software("sekurlza", mock_store)
        # Should suggest sekurlsa
        assert result == "sekurlsa"


class TestSuggestQueryPattern:
    """Tests for suggest_query_pattern()."""

    def test_suggest_pattern_techniques_by(self):
        """Test suggestion for 'techniques by' typo."""
        result = suggest_query_pattern("techniques by APT28")
        # Should suggest "techniques used by {GROUP}"
        assert result is not None
        assert "techniques used by" in result

    def test_suggest_pattern_similar_groups(self):
        """Test suggestion for similarity query."""
        result = suggest_query_pattern("similar groups APT28")
        # Should suggest a similarity pattern
        assert result is not None
        assert "similar" in result.lower()

    def test_suggest_pattern_no_match(self):
        """Test no suggestion for unrelated input."""
        result = suggest_query_pattern("xyz abc 123", threshold=90)
        assert result is None
