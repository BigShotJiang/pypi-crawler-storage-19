"""Tests for attack_query.models."""

import pytest

from attack_query.models import (
    Campaign,
    DataComponent,
    DataSource,
    Group,
    Matrix,
    Mitigation,
    Software,
    Tactic,
    Technique,
)


class TestMatrix:
    """Tests for Matrix enum."""

    def test_matrix_values(self):
        """Test matrix enum values."""
        assert Matrix.ENTERPRISE.value == "enterprise"
        assert Matrix.MOBILE.value == "mobile"
        assert Matrix.ICS.value == "ics"

    def test_matrix_stix_name(self):
        """Test stix_name property."""
        assert Matrix.ENTERPRISE.stix_name == "enterprise-attack"
        assert Matrix.MOBILE.stix_name == "mobile-attack"
        assert Matrix.ICS.stix_name == "ics-attack"

    def test_matrix_display_name(self):
        """Test display_name property."""
        assert Matrix.ENTERPRISE.display_name == "Enterprise"
        assert Matrix.MOBILE.display_name == "Mobile"
        assert Matrix.ICS.display_name == "ICS"

    def test_matrix_from_string(self):
        """Test parsing matrix from string."""
        assert Matrix.from_string("enterprise") == Matrix.ENTERPRISE
        assert Matrix.from_string("mobile") == Matrix.MOBILE
        assert Matrix.from_string("ics") == Matrix.ICS

    def test_matrix_from_string_case_insensitive(self):
        """Test parsing matrix is case-insensitive."""
        assert Matrix.from_string("ENTERPRISE") == Matrix.ENTERPRISE
        assert Matrix.from_string("Mobile") == Matrix.MOBILE
        assert Matrix.from_string("ICS") == Matrix.ICS

    def test_matrix_from_string_invalid(self):
        """Test error on invalid matrix string."""
        with pytest.raises(ValueError, match="Unknown matrix"):
            Matrix.from_string("invalid")

        with pytest.raises(ValueError, match="enterprise, mobile, ics"):
            Matrix.from_string("foo")


class TestTechnique:
    """Tests for Technique dataclass."""

    def test_technique_creation(self):
        """Test creating a technique."""
        tech = Technique(
            id="T1566",
            stix_id="attack-pattern--123",
            name="Phishing",
            description="Adversaries may send phishing messages...",
            tactics=["initial-access"],
            platforms=["Windows", "Linux", "macOS"],
        )

        assert tech.id == "T1566"
        assert tech.name == "Phishing"
        assert "initial-access" in tech.tactics
        assert not tech.is_subtechnique
        assert tech.parent_id is None

    def test_subtechnique_creation(self):
        """Test creating a sub-technique."""
        tech = Technique(
            id="T1566.001",
            stix_id="attack-pattern--456",
            name="Spearphishing Attachment",
            description="A more specific phishing technique...",
            tactics=["initial-access"],
            is_subtechnique=True,
            parent_id="T1566",
        )

        assert tech.is_subtechnique
        assert tech.parent_id == "T1566"

    def test_technique_to_dict(self):
        """Test technique serialization."""
        tech = Technique(
            id="T1566",
            stix_id="attack-pattern--123",
            name="Phishing",
            description="Short description",
            tactics=["initial-access"],
        )

        result = tech.to_dict()
        assert result["id"] == "T1566"
        assert result["name"] == "Phishing"
        assert result["tactics"] == ["initial-access"]
        assert result["is_subtechnique"] is False

    def test_technique_description_truncation(self):
        """Test that long descriptions are truncated."""
        long_description = "A" * 300
        tech = Technique(
            id="T1566",
            stix_id="attack-pattern--123",
            name="Phishing",
            description=long_description,
        )

        result = tech.to_dict()
        assert len(result["description"]) < len(long_description)
        assert result["description"].endswith("...")


class TestGroup:
    """Tests for Group dataclass."""

    def test_group_creation(self):
        """Test creating a group."""
        group = Group(
            id="G0007",
            stix_id="intrusion-set--123",
            name="APT28",
            description="Russian threat actor...",
            aliases=["Fancy Bear", "Sofacy"],
        )

        assert group.id == "G0007"
        assert group.name == "APT28"
        assert "Fancy Bear" in group.aliases
        assert len(group.techniques) == 0

    def test_group_with_techniques(self):
        """Test group with techniques."""
        group = Group(
            id="G0007",
            stix_id="intrusion-set--123",
            name="APT28",
            description="Russian threat actor...",
            techniques={"T1566", "T1059", "T1078"},
        )

        assert len(group.techniques) == 3
        assert "T1566" in group.techniques

    def test_group_to_dict(self):
        """Test group serialization."""
        group = Group(
            id="G0007",
            stix_id="intrusion-set--123",
            name="APT28",
            description="...",
            aliases=["Fancy Bear"],
            techniques={"T1566", "T1059"},
        )

        result = group.to_dict()
        assert result["id"] == "G0007"
        assert result["name"] == "APT28"
        assert result["technique_count"] == 2


class TestTactic:
    """Tests for Tactic dataclass."""

    def test_tactic_creation(self):
        """Test creating a tactic."""
        tactic = Tactic(
            id="TA0001",
            stix_id="x-mitre-tactic--123",
            name="Initial Access",
            shortname="initial-access",
            description="The adversary is trying to get into your network.",
        )

        assert tactic.id == "TA0001"
        assert tactic.name == "Initial Access"
        assert tactic.shortname == "initial-access"

    def test_tactic_to_dict(self):
        """Test tactic serialization."""
        tactic = Tactic(
            id="TA0001",
            stix_id="x-mitre-tactic--123",
            name="Initial Access",
            shortname="initial-access",
            description="...",
        )

        result = tactic.to_dict()
        assert result["id"] == "TA0001"
        assert result["name"] == "Initial Access"
        assert result["shortname"] == "initial-access"
        assert "description" not in result  # Not included in to_dict


class TestSoftware:
    """Tests for Software dataclass."""

    def test_software_creation_malware(self):
        """Test creating malware software."""
        sw = Software(
            id="S0002",
            stix_id="malware--123",
            name="Mimikatz",
            description="Mimikatz is a credential dumper...",
            software_type="malware",
            aliases=["sekurlsa"],
            platforms=["Windows"],
        )

        assert sw.id == "S0002"
        assert sw.name == "Mimikatz"
        assert sw.software_type == "malware"
        assert "sekurlsa" in sw.aliases
        assert "Windows" in sw.platforms
        assert len(sw.techniques) == 0

    def test_software_creation_tool(self):
        """Test creating a tool."""
        sw = Software(
            id="S0154",
            stix_id="tool--123",
            name="Cobalt Strike",
            description="Cobalt Strike is a commercial...",
            software_type="tool",
            platforms=["Windows", "Linux"],
        )

        assert sw.software_type == "tool"
        assert len(sw.platforms) == 2

    def test_software_with_techniques(self):
        """Test software with techniques."""
        sw = Software(
            id="S0002",
            stix_id="malware--123",
            name="Mimikatz",
            description="...",
            software_type="malware",
            techniques={"T1003", "T1558", "T1134"},
        )

        assert len(sw.techniques) == 3
        assert "T1003" in sw.techniques

    def test_software_to_dict(self):
        """Test software serialization."""
        sw = Software(
            id="S0002",
            stix_id="malware--123",
            name="Mimikatz",
            description="...",
            software_type="malware",
            aliases=["sekurlsa"],
            platforms=["Windows"],
            techniques={"T1003", "T1558"},
        )

        result = sw.to_dict()
        assert result["id"] == "S0002"
        assert result["name"] == "Mimikatz"
        assert result["type"] == "malware"
        assert result["aliases"] == ["sekurlsa"]
        assert result["platforms"] == ["Windows"]
        assert result["technique_count"] == 2


class TestMitigation:
    """Tests for Mitigation dataclass."""

    def test_mitigation_creation(self):
        """Test creating a mitigation."""
        mit = Mitigation(
            id="M1031",
            stix_id="course-of-action--123",
            name="Network Intrusion Prevention",
            description="Use network intrusion prevention systems...",
        )

        assert mit.id == "M1031"
        assert mit.name == "Network Intrusion Prevention"
        assert len(mit.techniques) == 0

    def test_mitigation_with_techniques(self):
        """Test mitigation with techniques."""
        mit = Mitigation(
            id="M1031",
            stix_id="course-of-action--123",
            name="Network Intrusion Prevention",
            description="...",
            techniques={"T1566", "T1059", "T1071"},
        )

        assert len(mit.techniques) == 3
        assert "T1566" in mit.techniques

    def test_mitigation_to_dict(self):
        """Test mitigation serialization."""
        mit = Mitigation(
            id="M1031",
            stix_id="course-of-action--123",
            name="Network Intrusion Prevention",
            description="Short description",
            techniques={"T1566", "T1059"},
        )

        result = mit.to_dict()
        assert result["id"] == "M1031"
        assert result["name"] == "Network Intrusion Prevention"
        assert result["technique_count"] == 2

    def test_mitigation_description_truncation(self):
        """Test that long descriptions are truncated."""
        long_description = "A" * 300
        mit = Mitigation(
            id="M1031",
            stix_id="course-of-action--123",
            name="Network Intrusion Prevention",
            description=long_description,
        )

        result = mit.to_dict()
        assert len(result["description"]) < len(long_description)
        assert result["description"].endswith("...")


class TestDataSource:
    """Tests for DataSource dataclass."""

    def test_data_source_creation(self):
        """Test creating a data source."""
        ds = DataSource(
            id="DS0009",
            stix_id="x-mitre-data-source--123",
            name="Process",
            description="Events related to process execution...",
            platforms=["Windows", "Linux", "macOS"],
            collection_layers=["Host"],
        )

        assert ds.id == "DS0009"
        assert ds.name == "Process"
        assert "Windows" in ds.platforms
        assert "Host" in ds.collection_layers

    def test_data_source_to_dict(self):
        """Test data source serialization."""
        ds = DataSource(
            id="DS0009",
            stix_id="x-mitre-data-source--123",
            name="Process",
            description="Short description",
            platforms=["Windows", "Linux"],
            collection_layers=["Host"],
        )

        result = ds.to_dict()
        assert result["id"] == "DS0009"
        assert result["name"] == "Process"
        assert result["platforms"] == ["Windows", "Linux"]
        assert result["collection_layers"] == ["Host"]

    def test_data_source_description_truncation(self):
        """Test that long descriptions are truncated."""
        long_description = "A" * 300
        ds = DataSource(
            id="DS0009",
            stix_id="x-mitre-data-source--123",
            name="Process",
            description=long_description,
        )

        result = ds.to_dict()
        assert len(result["description"]) < len(long_description)
        assert result["description"].endswith("...")


class TestDataComponent:
    """Tests for DataComponent dataclass."""

    def test_data_component_creation(self):
        """Test creating a data component."""
        dc = DataComponent(
            id="DC0032",
            stix_id="x-mitre-data-component--123",
            name="Process Creation",
            description="Process creation events...",
            log_sources=[
                {"name": "WinEventLog:Security", "channel": "EventCode=4688"},
                {"name": "Sysmon", "channel": "EventID=1"},
            ],
        )

        assert dc.id == "DC0032"
        assert dc.name == "Process Creation"
        assert len(dc.log_sources) == 2
        assert len(dc.techniques) == 0

    def test_data_component_with_techniques(self):
        """Test data component with techniques."""
        dc = DataComponent(
            id="DC0032",
            stix_id="x-mitre-data-component--123",
            name="Process Creation",
            description="...",
            techniques={"T1059", "T1106", "T1569"},
        )

        assert len(dc.techniques) == 3
        assert "T1059" in dc.techniques

    def test_data_component_to_dict(self):
        """Test data component serialization."""
        dc = DataComponent(
            id="DC0032",
            stix_id="x-mitre-data-component--123",
            name="Process Creation",
            description="Short description",
            log_sources=[{"name": "Sysmon", "channel": "EventID=1"}],
            techniques={"T1059", "T1106"},
        )

        result = dc.to_dict()
        assert result["id"] == "DC0032"
        assert result["name"] == "Process Creation"
        assert result["technique_count"] == 2
        assert len(result["log_sources"]) == 1

    def test_data_component_description_truncation(self):
        """Test that long descriptions are truncated."""
        long_description = "A" * 300
        dc = DataComponent(
            id="DC0032",
            stix_id="x-mitre-data-component--123",
            name="Process Creation",
            description=long_description,
        )

        result = dc.to_dict()
        assert len(result["description"]) < len(long_description)
        assert result["description"].endswith("...")


class TestCampaign:
    """Tests for Campaign dataclass."""

    def test_campaign_creation(self):
        """Test creating a campaign."""
        campaign = Campaign(
            id="C0027",
            stix_id="campaign--123",
            name="SolarWinds Attack",
            description="Supply chain attack...",
            first_seen="2020-03-01T00:00:00.000Z",
            last_seen="2021-01-01T00:00:00.000Z",
        )

        assert campaign.id == "C0027"
        assert campaign.name == "SolarWinds Attack"
        assert campaign.first_seen == "2020-03-01T00:00:00.000Z"
        assert campaign.last_seen == "2021-01-01T00:00:00.000Z"
        assert len(campaign.techniques) == 0
        assert len(campaign.software) == 0
        assert len(campaign.groups) == 0

    def test_campaign_with_relations(self):
        """Test campaign with techniques, software, and groups."""
        campaign = Campaign(
            id="C0027",
            stix_id="campaign--123",
            name="SolarWinds Attack",
            description="...",
            techniques={"T1566", "T1059", "T1078"},
            software={"S0002", "S0154"},
            groups={"G0007", "G0016"},
        )

        assert len(campaign.techniques) == 3
        assert "T1566" in campaign.techniques
        assert len(campaign.software) == 2
        assert "S0002" in campaign.software
        assert len(campaign.groups) == 2
        assert "G0007" in campaign.groups

    def test_campaign_with_aliases(self):
        """Test campaign with aliases."""
        campaign = Campaign(
            id="C0027",
            stix_id="campaign--123",
            name="SolarWinds Attack",
            description="...",
            aliases=["SUNBURST", "Solorigate"],
        )

        assert len(campaign.aliases) == 2
        assert "SUNBURST" in campaign.aliases

    def test_campaign_to_dict(self):
        """Test campaign serialization."""
        campaign = Campaign(
            id="C0027",
            stix_id="campaign--123",
            name="SolarWinds Attack",
            description="Short description",
            aliases=["SUNBURST"],
            first_seen="2020-03-01T00:00:00.000Z",
            last_seen="2021-01-01T00:00:00.000Z",
            techniques={"T1566", "T1059"},
            software={"S0002"},
            groups={"G0007"},
        )

        result = campaign.to_dict()
        assert result["id"] == "C0027"
        assert result["name"] == "SolarWinds Attack"
        assert result["aliases"] == ["SUNBURST"]
        assert result["first_seen"] == "2020-03-01T00:00:00.000Z"
        assert result["last_seen"] == "2021-01-01T00:00:00.000Z"
        assert result["technique_count"] == 2
        assert result["software_count"] == 1
        assert result["group_count"] == 1

    def test_campaign_description_truncation(self):
        """Test that long descriptions are truncated."""
        long_description = "A" * 300
        campaign = Campaign(
            id="C0027",
            stix_id="campaign--123",
            name="SolarWinds Attack",
            description=long_description,
        )

        result = campaign.to_dict()
        assert len(result["description"]) < len(long_description)
        assert result["description"].endswith("...")
