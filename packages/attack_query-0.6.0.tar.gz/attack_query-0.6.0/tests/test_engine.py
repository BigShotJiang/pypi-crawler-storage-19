"""Tests for attack_query.engine."""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING
from unittest.mock import MagicMock

import pytest

from attack_query.engine import ATTACKQueryEngine
from attack_query.models import (
    Campaign,
    DataComponent,
    DataSource,
    Group,
    Mitigation,
    Software,
    Tactic,
    Technique,
)

if TYPE_CHECKING:
    pass


@pytest.fixture
def mock_store() -> MagicMock:
    """Create a mock store with test data."""
    store = MagicMock()

    # Create test techniques
    techniques = {
        "T1566": Technique(
            id="T1566",
            stix_id="attack-pattern--1",
            name="Phishing",
            description="...",
            tactics=["initial-access"],
        ),
        "T1566.001": Technique(
            id="T1566.001",
            stix_id="attack-pattern--1a",
            name="Spearphishing Attachment",
            description="...",
            tactics=["initial-access"],
            is_subtechnique=True,
            parent_id="T1566",
        ),
        "T1566.002": Technique(
            id="T1566.002",
            stix_id="attack-pattern--1b",
            name="Spearphishing Link",
            description="...",
            tactics=["initial-access"],
            is_subtechnique=True,
            parent_id="T1566",
        ),
        "T1059": Technique(
            id="T1059",
            stix_id="attack-pattern--2",
            name="Command and Scripting Interpreter",
            description="...",
            tactics=["execution"],
        ),
        "T1078": Technique(
            id="T1078",
            stix_id="attack-pattern--3",
            name="Valid Accounts",
            description="...",
            tactics=["defense-evasion", "persistence", "initial-access"],
        ),
        "T1071": Technique(
            id="T1071",
            stix_id="attack-pattern--4",
            name="Application Layer Protocol",
            description="...",
            tactics=["command-and-control"],
        ),
    }
    store.techniques = techniques
    store.get_technique = lambda tid: techniques.get(tid.upper())

    # Build subtechniques_by_parent index
    store.subtechniques_by_parent = {
        "T1566": {"T1566.001", "T1566.002"},
    }

    # Create test groups
    apt28 = Group(
        id="G0007",
        stix_id="intrusion-set--1",
        name="APT28",
        description="...",
        aliases=["Fancy Bear"],
        techniques={"T1566", "T1059", "T1078"},
    )
    apt29 = Group(
        id="G0016",
        stix_id="intrusion-set--2",
        name="APT29",
        description="...",
        aliases=["Cozy Bear"],
        techniques={"T1566", "T1078", "T1071"},
    )
    apt33 = Group(
        id="G0064",
        stix_id="intrusion-set--3",
        name="APT33",
        description="...",
        techniques={"T1566", "T1059"},
    )

    groups = {"G0007": apt28, "G0016": apt29, "G0064": apt33}
    groups_by_name = {"apt28": apt28, "apt29": apt29, "apt33": apt33}
    groups_by_alias = {"fancy bear": apt28, "cozy bear": apt29}

    store.groups = groups
    store.groups_by_name = groups_by_name
    store.groups_by_alias = groups_by_alias

    def get_group(identifier: str) -> Group | None:
        if identifier.upper() in groups:
            return groups[identifier.upper()]
        lower = identifier.lower()
        if lower in groups_by_name:
            return groups_by_name[lower]
        if lower in groups_by_alias:
            return groups_by_alias[lower]
        return None

    store.get_group = get_group

    # Create test tactics
    tactics = {
        "TA0001": Tactic(
            id="TA0001",
            stix_id="x-mitre-tactic--1",
            name="Initial Access",
            shortname="initial-access",
            description="...",
        ),
        "TA0002": Tactic(
            id="TA0002",
            stix_id="x-mitre-tactic--2",
            name="Execution",
            shortname="execution",
            description="...",
        ),
    }
    tactics_by_shortname = {
        "initial-access": tactics["TA0001"],
        "execution": tactics["TA0002"],
    }
    store.tactics = tactics
    store.tactics_by_shortname = tactics_by_shortname

    def get_tactic(identifier: str) -> Tactic | None:
        if identifier.upper() in tactics:
            return tactics[identifier.upper()]
        return tactics_by_shortname.get(identifier.lower())

    store.get_tactic = get_tactic

    # Build technique_to_groups index
    technique_to_groups: dict[str, set[str]] = defaultdict(set)
    for group in groups.values():
        for tech_id in group.techniques:
            technique_to_groups[tech_id].add(group.id)
    store.technique_to_groups = technique_to_groups

    # Create test software
    mimikatz = Software(
        id="S0002",
        stix_id="malware--1",
        name="Mimikatz",
        description="Credential dumper...",
        software_type="malware",
        aliases=["sekurlsa"],
        platforms=["Windows"],
        techniques={"T1566", "T1078"},
    )
    cobalt_strike = Software(
        id="S0154",
        stix_id="tool--1",
        name="Cobalt Strike",
        description="Commercial adversary simulation...",
        software_type="tool",
        platforms=["Windows", "Linux"],
        techniques={"T1059", "T1071"},
    )

    software = {"S0002": mimikatz, "S0154": cobalt_strike}
    software_by_name = {"mimikatz": mimikatz, "cobalt strike": cobalt_strike}
    software_by_alias = {"sekurlsa": mimikatz}
    software_by_stix = {"malware--1": mimikatz, "tool--1": cobalt_strike}

    store.software = software
    store.software_by_name = software_by_name
    store.software_by_alias = software_by_alias
    store.software_by_stix = software_by_stix

    def get_software(identifier: str) -> Software | None:
        if identifier.upper() in software:
            return software[identifier.upper()]
        lower = identifier.lower()
        if lower in software_by_name:
            return software_by_name[lower]
        if lower in software_by_alias:
            return software_by_alias[lower]
        return None

    store.get_software = get_software

    # Build software relationship indexes
    technique_to_software: dict[str, set[str]] = defaultdict(set)
    for sw in software.values():
        for tech_id in sw.techniques:
            technique_to_software[tech_id].add(sw.id)
    store.technique_to_software = technique_to_software

    # Groups use software (APT28 uses Mimikatz, APT29 uses Cobalt Strike)
    group_to_software: dict[str, set[str]] = defaultdict(set)
    group_to_software["G0007"] = {"S0002"}  # APT28 uses Mimikatz
    group_to_software["G0016"] = {"S0154"}  # APT29 uses Cobalt Strike
    store.group_to_software = group_to_software

    software_to_groups: dict[str, set[str]] = defaultdict(set)
    software_to_groups["S0002"] = {"G0007"}  # Mimikatz used by APT28
    software_to_groups["S0154"] = {"G0016"}  # Cobalt Strike used by APT29
    store.software_to_groups = software_to_groups

    # Create test mitigations
    user_training = Mitigation(
        id="M1017",
        stix_id="course-of-action--1",
        name="User Training",
        description="Train users to identify social engineering...",
        techniques={"T1566", "T1566.001", "T1566.002"},  # Mitigates phishing
    )
    network_intrusion = Mitigation(
        id="M1031",
        stix_id="course-of-action--2",
        name="Network Intrusion Prevention",
        description="Use network-based prevention systems...",
        techniques={"T1566", "T1071"},  # Mitigates phishing and C2
    )

    mitigations = {"M1017": user_training, "M1031": network_intrusion}
    mitigations_by_name = {
        "user training": user_training,
        "network intrusion prevention": network_intrusion,
    }
    mitigations_by_stix = {
        "course-of-action--1": user_training,
        "course-of-action--2": network_intrusion,
    }

    store.mitigations = mitigations
    store.mitigations_by_name = mitigations_by_name
    store.mitigations_by_stix = mitigations_by_stix

    def get_mitigation(identifier: str) -> Mitigation | None:
        if identifier.upper() in mitigations:
            return mitigations[identifier.upper()]
        lower = identifier.lower()
        if lower in mitigations_by_name:
            return mitigations_by_name[lower]
        return None

    store.get_mitigation = get_mitigation

    # Build technique_to_mitigations index
    technique_to_mitigations: dict[str, set[str]] = defaultdict(set)
    for mit in mitigations.values():
        for tech_id in mit.techniques:
            technique_to_mitigations[tech_id].add(mit.id)
    store.technique_to_mitigations = technique_to_mitigations

    # Create test data sources
    process_ds = DataSource(
        id="DS0009",
        stix_id="x-mitre-data-source--1",
        name="Process",
        description="Process execution events...",
        platforms=["Windows", "Linux", "macOS"],
        collection_layers=["Host"],
    )
    network_ds = DataSource(
        id="DS0029",
        stix_id="x-mitre-data-source--2",
        name="Network Traffic",
        description="Network traffic data...",
        platforms=["Windows", "Linux"],
        collection_layers=["Network"],
    )

    data_sources = {"DS0009": process_ds, "DS0029": network_ds}
    data_sources_by_name = {"process": process_ds, "network traffic": network_ds}

    store.data_sources = data_sources
    store.data_sources_by_name = data_sources_by_name

    def get_data_source(identifier: str) -> DataSource | None:
        if identifier.upper() in data_sources:
            return data_sources[identifier.upper()]
        lower = identifier.lower()
        if lower in data_sources_by_name:
            return data_sources_by_name[lower]
        return None

    store.get_data_source = get_data_source

    # Create test data components
    process_creation = DataComponent(
        id="DC0032",
        stix_id="x-mitre-data-component--1",
        name="Process Creation",
        description="Process creation events...",
        log_sources=[
            {"name": "WinEventLog:Security", "channel": "EventCode=4688"},
            {"name": "Sysmon", "channel": "EventID=1"},
        ],
        techniques={"T1059", "T1566"},
    )
    network_connection = DataComponent(
        id="DC0007",
        stix_id="x-mitre-data-component--2",
        name="Network Connection Creation",
        description="Network connection events...",
        log_sources=[{"name": "Sysmon", "channel": "EventID=3"}],
        techniques={"T1071"},
    )

    data_components = {"DC0032": process_creation, "DC0007": network_connection}
    data_components_by_name = {
        "process creation": process_creation,
        "network connection creation": network_connection,
    }
    data_components_by_stix = {
        "x-mitre-data-component--1": process_creation,
        "x-mitre-data-component--2": network_connection,
    }

    store.data_components = data_components
    store.data_components_by_name = data_components_by_name
    store.data_components_by_stix = data_components_by_stix

    def get_data_component(identifier: str) -> DataComponent | None:
        if identifier.upper() in data_components:
            return data_components[identifier.upper()]
        lower = identifier.lower()
        if lower in data_components_by_name:
            return data_components_by_name[lower]
        return None

    store.get_data_component = get_data_component

    # Create test campaigns
    campaign1 = Campaign(
        id="C0027",
        stix_id="campaign--1",
        name="Test Campaign",
        description="A test campaign",
        aliases=["Operation Test"],
        first_seen="2022-06-01T04:00:00.000Z",
        last_seen="2023-01-01T04:00:00.000Z",
        techniques={"T1566", "T1059"},
        software={"S0002"},
        groups={"G0007"},
    )
    campaign2 = Campaign(
        id="C0028",
        stix_id="campaign--2",
        name="Second Campaign",
        description="Another test campaign",
        first_seen="2023-01-01T04:00:00.000Z",
        last_seen="2023-06-01T04:00:00.000Z",
        techniques={"T1078", "T1071"},
        software={"S0154"},
        groups={"G0007", "G0016"},
    )

    campaigns = {"C0027": campaign1, "C0028": campaign2}
    campaigns_by_name = {"test campaign": campaign1, "second campaign": campaign2}
    campaigns_by_stix = {"campaign--1": campaign1, "campaign--2": campaign2}

    store.campaigns = campaigns
    store.campaigns_by_name = campaigns_by_name
    store.campaigns_by_stix = campaigns_by_stix

    def get_campaign(identifier: str) -> Campaign | None:
        if identifier.upper() in campaigns:
            return campaigns[identifier.upper()]
        lower = identifier.lower()
        if lower in campaigns_by_name:
            return campaigns_by_name[lower]
        return None

    store.get_campaign = get_campaign

    # Build campaign relationship indexes
    technique_to_campaigns: dict[str, set[str]] = defaultdict(set)
    for camp in campaigns.values():
        for tech_id in camp.techniques:
            technique_to_campaigns[tech_id].add(camp.id)
    store.technique_to_campaigns = technique_to_campaigns

    group_to_campaigns: dict[str, set[str]] = defaultdict(set)
    for camp in campaigns.values():
        for group_id in camp.groups:
            group_to_campaigns[group_id].add(camp.id)
    store.group_to_campaigns = group_to_campaigns

    store.version = "test"

    return store


class TestATTACKQueryEngineGroupInfo:
    """Tests for group info and alias resolution."""

    def test_get_group_info_by_name(self, mock_store: MagicMock):
        """Test getting group info by name."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_group_info("APT28")
        assert info["id"] == "G0007"
        assert info["name"] == "APT28"
        assert "Fancy Bear" in info["aliases"]
        assert info["technique_count"] == 3
        assert info["resolved_from"] is None  # Direct name lookup

    def test_get_group_info_by_alias(self, mock_store: MagicMock):
        """Test getting group info by alias with resolution."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_group_info("Fancy Bear")
        assert info["id"] == "G0007"
        assert info["name"] == "APT28"
        assert info["resolved_from"] == "Fancy Bear"  # Alias resolution

    def test_get_group_info_by_id(self, mock_store: MagicMock):
        """Test getting group info by ID."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_group_info("G0007")
        assert info["name"] == "APT28"
        assert info["resolved_from"] is None  # Direct ID lookup

    def test_get_group_info_not_found(self, mock_store: MagicMock):
        """Test error when group not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Group not found"):
            engine.get_group_info("NonExistent")


class TestATTACKQueryEngine:
    """Tests for ATTACKQueryEngine."""

    def test_get_group_techniques(self, mock_store: MagicMock):
        """Test getting techniques for a group."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_group_techniques("APT28")
        assert techniques == {"T1566", "T1059", "T1078"}

    def test_get_group_techniques_by_alias(self, mock_store: MagicMock):
        """Test getting techniques using group alias."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_group_techniques("Fancy Bear")
        assert techniques == {"T1566", "T1059", "T1078"}

    def test_get_group_techniques_not_found(self, mock_store: MagicMock):
        """Test error when group not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Group not found"):
            engine.get_group_techniques("NonExistent")

    def test_techniques_union(self, mock_store: MagicMock):
        """Test union of techniques across groups."""
        engine = ATTACKQueryEngine(mock_store)

        union = engine.techniques_union(["APT28", "APT29"])
        assert union == {"T1566", "T1059", "T1078", "T1071"}

    def test_techniques_intersection(self, mock_store: MagicMock):
        """Test intersection of techniques across groups."""
        engine = ATTACKQueryEngine(mock_store)

        intersection = engine.techniques_intersection(["APT28", "APT29"])
        assert intersection == {"T1566", "T1078"}

    def test_techniques_difference(self, mock_store: MagicMock):
        """Test difference: techniques in include_groups but not exclude_groups."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28 and APT29 have {T1566, T1059, T1078, T1071}
        # APT33 has {T1566, T1059}
        # Difference should be {T1078, T1071}
        diff = engine.techniques_difference(
            include_groups=["APT28", "APT29"],
            exclude_groups=["APT33"],
        )
        assert diff == {"T1078", "T1071"}

    def test_techniques_exclusive_intersection(self, mock_store: MagicMock):
        """Test exclusive intersection: ALL include, NONE exclude."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28 ∩ APT29 = {T1566, T1078}
        # APT33 = {T1566, T1059}
        # Result: {T1078} (T1566 is excluded because APT33 uses it)
        result = engine.techniques_exclusive_intersection(
            include_groups=["APT28", "APT29"],
            exclude_groups=["APT33"],
        )
        assert result == {"T1078"}

    def test_groups_using_technique(self, mock_store: MagicMock):
        """Test finding groups that use a technique."""
        engine = ATTACKQueryEngine(mock_store)

        groups = engine.groups_using_technique("T1566")
        assert set(groups) == {"APT28", "APT29", "APT33"}

    def test_compare_groups(self, mock_store: MagicMock):
        """Test comparing two groups."""
        engine = ATTACKQueryEngine(mock_store)

        comparison = engine.compare_groups("APT28", "APT29")

        assert comparison["group1"] == "APT28"
        assert comparison["group2"] == "APT29"
        assert comparison["group1_total"] == 3
        assert comparison["group2_total"] == 3
        assert comparison["shared"] == {"T1566", "T1078"}
        assert comparison["unique_to_first"] == {"T1059"}
        assert comparison["unique_to_second"] == {"T1071"}
        # Jaccard: |intersection| / |union| = 2 / 4 = 0.5
        assert comparison["jaccard_similarity"] == 0.5

    def test_get_techniques_by_tactic(self, mock_store: MagicMock):
        """Test filtering techniques by tactic."""
        engine = ATTACKQueryEngine(mock_store)

        initial_access = engine.get_techniques_by_tactic(
            "initial-access",
            {"T1566", "T1059", "T1078"},
        )
        assert initial_access == {"T1566", "T1078"}

    def test_get_technique_coverage_by_tactic(self, mock_store: MagicMock):
        """Test grouping techniques by tactic."""
        engine = ATTACKQueryEngine(mock_store)

        coverage = engine.get_technique_coverage_by_tactic({"T1566", "T1059"})

        assert "Initial Access" in coverage
        assert "T1566" in coverage["Initial Access"]
        assert "Execution" in coverage
        assert "T1059" in coverage["Execution"]

    def test_export_navigator_layer(self, mock_store: MagicMock):
        """Test exporting Navigator layer."""
        engine = ATTACKQueryEngine(mock_store)

        layer = engine.export_navigator_layer(
            {"T1566", "T1059"},
            name="Test Layer",
            description="Test description",
            color="#ff0000",
        )

        assert layer["name"] == "Test Layer"
        assert layer["description"] == "Test description"
        assert layer["domain"] == "enterprise-attack"
        assert len(layer["techniques"]) == 2

        # Check technique entries
        tech_ids = {t["techniqueID"] for t in layer["techniques"]}
        assert tech_ids == {"T1566", "T1059"}

    def test_export_heatmap_layer(self, mock_store: MagicMock):
        """Test exporting heatmap layer."""
        engine = ATTACKQueryEngine(mock_store)

        layer = engine.export_heatmap_layer(
            ["APT28", "APT29"],
            name="Test Heatmap",
        )

        assert layer["name"] == "Test Heatmap"
        assert layer["domain"] == "enterprise-attack"

        # Check that scores reflect overlap
        techniques = {t["techniqueID"]: t for t in layer["techniques"]}

        # T1566 and T1078 are used by both groups
        assert techniques["T1566"]["score"] == 2
        assert techniques["T1078"]["score"] == 2

        # T1059 only by APT28, T1071 only by APT29
        assert techniques["T1059"]["score"] == 1
        assert techniques["T1071"]["score"] == 1


class TestATTACKQueryEngineTactics:
    """Tests for tactics queries."""

    def test_get_group_tactics_single(self, mock_store: MagicMock):
        """Test getting tactics for a single group."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28 uses T1566 (initial-access), T1059 (execution), T1078 (multiple tactics)
        tactics = engine.get_group_tactics("APT28")

        assert "initial-access" in tactics
        assert "execution" in tactics
        assert "defense-evasion" in tactics  # From T1078
        assert "persistence" in tactics  # From T1078

    def test_get_group_tactics_not_found(self, mock_store: MagicMock):
        """Test error when group not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Group not found"):
            engine.get_group_tactics("NonExistent")

    def test_tactics_union(self, mock_store: MagicMock):
        """Test union of tactics from multiple groups."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28: initial-access, execution, defense-evasion, persistence
        # APT29: initial-access, defense-evasion, persistence, command-and-control
        tactics = engine.tactics_union(["APT28", "APT29"])

        # Union should include all tactics from both groups
        assert "initial-access" in tactics
        assert "execution" in tactics  # APT28 only
        assert "command-and-control" in tactics  # APT29 only
        assert "defense-evasion" in tactics
        assert "persistence" in tactics

    def test_tactics_intersection(self, mock_store: MagicMock):
        """Test intersection of tactics from multiple groups."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28: initial-access, execution, defense-evasion, persistence
        # APT29: initial-access, defense-evasion, persistence, command-and-control
        tactics = engine.tactics_intersection(["APT28", "APT29"])

        # Intersection should only include shared tactics
        assert "initial-access" in tactics
        assert "defense-evasion" in tactics
        assert "persistence" in tactics
        # These should NOT be in intersection
        assert "execution" not in tactics  # APT28 only
        assert "command-and-control" not in tactics  # APT29 only

    def test_tactics_intersection_empty_list(self, mock_store: MagicMock):
        """Test intersection with empty group list."""
        engine = ATTACKQueryEngine(mock_store)

        tactics = engine.tactics_intersection([])
        assert len(tactics) == 0


class TestATTACKQueryEngineComplement:
    """Tests for complement operation."""

    def test_techniques_complement_single_group(self, mock_store: MagicMock):
        """Test complement operation with single group."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28 uses T1566, T1059, T1078
        # All techniques: T1566, T1566.001, T1566.002, T1059, T1078, T1071
        complement = engine.techniques_complement(["APT28"])

        # Should return techniques NOT used by APT28
        assert "T1071" in complement  # Only used by APT29
        assert "T1566.001" in complement  # Sub-technique not directly used
        assert "T1566.002" in complement  # Sub-technique not directly used
        # Should NOT include techniques used by APT28
        assert "T1566" not in complement
        assert "T1059" not in complement
        assert "T1078" not in complement

    def test_techniques_complement_multiple_groups(self, mock_store: MagicMock):
        """Test complement operation with multiple groups."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28 uses: T1566, T1059, T1078
        # APT29 uses: T1566, T1078, T1071
        # Combined: T1566, T1059, T1078, T1071
        complement = engine.techniques_complement(["APT28", "APT29"])

        # Only sub-techniques should remain (not used by either group)
        assert "T1566.001" in complement
        assert "T1566.002" in complement
        # All parent techniques are used by at least one group
        assert "T1566" not in complement
        assert "T1059" not in complement
        assert "T1078" not in complement
        assert "T1071" not in complement

    def test_techniques_complement_empty_groups(self, mock_store: MagicMock):
        """Test complement with empty group list returns all techniques."""
        engine = ATTACKQueryEngine(mock_store)

        complement = engine.techniques_complement([])
        all_techniques = set(mock_store.techniques.keys())

        assert complement == all_techniques


class TestATTACKQueryEngineSubtechniques:
    """Tests for sub-technique related engine methods."""

    def test_get_subtechniques_of(self, mock_store: MagicMock):
        """Test getting sub-techniques of a parent technique."""
        engine = ATTACKQueryEngine(mock_store)

        subtechniques = engine.get_subtechniques_of("T1566")
        assert subtechniques == {"T1566.001", "T1566.002"}

    def test_get_subtechniques_of_case_insensitive(self, mock_store: MagicMock):
        """Test get_subtechniques_of is case-insensitive."""
        engine = ATTACKQueryEngine(mock_store)

        subtechniques = engine.get_subtechniques_of("t1566")
        assert subtechniques == {"T1566.001", "T1566.002"}

    def test_get_subtechniques_of_not_found(self, mock_store: MagicMock):
        """Test error when parent technique not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Technique not found"):
            engine.get_subtechniques_of("T9999")

    def test_get_subtechniques_of_is_subtechnique(self, mock_store: MagicMock):
        """Test error when querying sub-techniques of a sub-technique."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="is a sub-technique"):
            engine.get_subtechniques_of("T1566.001")

    def test_get_parent_of(self, mock_store: MagicMock):
        """Test getting parent of a sub-technique."""
        engine = ATTACKQueryEngine(mock_store)

        parent = engine.get_parent_of("T1566.001")
        assert parent == "T1566"

    def test_get_parent_of_case_insensitive(self, mock_store: MagicMock):
        """Test get_parent_of is case-insensitive."""
        engine = ATTACKQueryEngine(mock_store)

        parent = engine.get_parent_of("t1566.001")
        assert parent == "T1566"

    def test_get_parent_of_not_found(self, mock_store: MagicMock):
        """Test error when sub-technique not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Technique not found"):
            engine.get_parent_of("T9999.001")

    def test_get_parent_of_not_subtechnique(self, mock_store: MagicMock):
        """Test error when querying parent of a parent technique."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="not a sub-technique"):
            engine.get_parent_of("T1566")

    def test_group_techniques_hierarchically(self, mock_store: MagicMock):
        """Test grouping techniques by parent/child relationship."""
        engine = ATTACKQueryEngine(mock_store)

        # Mix of parents and sub-techniques
        technique_ids = {"T1566", "T1566.001", "T1059"}
        hierarchy = engine.group_techniques_hierarchically(technique_ids)

        # T1566 should have T1566.001 as child
        assert "T1566" in hierarchy
        assert "T1566.001" in hierarchy["T1566"]

        # T1059 is standalone (no children in result set)
        assert "T1059" in hierarchy
        assert hierarchy["T1059"] == []

    def test_group_techniques_hierarchically_only_subtechniques(self, mock_store: MagicMock):
        """Test hierarchy with only sub-techniques (orphaned)."""
        engine = ATTACKQueryEngine(mock_store)

        # Only sub-techniques, parent not in set
        technique_ids = {"T1566.001", "T1566.002"}
        hierarchy = engine.group_techniques_hierarchically(technique_ids)

        # Sub-techniques grouped under their parent key (even though parent not in input)
        assert "T1566" in hierarchy
        assert set(hierarchy["T1566"]) == {"T1566.001", "T1566.002"}

    def test_group_techniques_hierarchically_empty(self, mock_store: MagicMock):
        """Test hierarchy with empty input."""
        engine = ATTACKQueryEngine(mock_store)

        hierarchy = engine.group_techniques_hierarchically(set())
        assert hierarchy == {}


class TestATTACKQueryEngineSoftware:
    """Tests for software query methods."""

    def test_get_software_info_by_name(self, mock_store: MagicMock):
        """Test getting software info by name."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_software_info("Mimikatz")
        assert info["id"] == "S0002"
        assert info["name"] == "Mimikatz"
        assert info["type"] == "malware"
        assert "sekurlsa" in info["aliases"]
        assert info["technique_count"] == 2
        assert "APT28" in info["groups"]
        assert info["resolved_from"] is None

    def test_get_software_info_by_id(self, mock_store: MagicMock):
        """Test getting software info by ID."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_software_info("S0154")
        assert info["name"] == "Cobalt Strike"
        assert info["type"] == "tool"

    def test_get_software_info_by_alias(self, mock_store: MagicMock):
        """Test getting software info by alias."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_software_info("sekurlsa")
        assert info["name"] == "Mimikatz"
        assert info["resolved_from"] == "sekurlsa"

    def test_get_software_info_not_found(self, mock_store: MagicMock):
        """Test getting software info for unknown software."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Software not found"):
            engine.get_software_info("UnknownSoftware")

    def test_get_software_techniques(self, mock_store: MagicMock):
        """Test getting techniques for software."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_software_techniques("Mimikatz")
        assert techniques == {"T1566", "T1078"}

    def test_get_software_techniques_not_found(self, mock_store: MagicMock):
        """Test getting techniques for unknown software."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Software not found"):
            engine.get_software_techniques("UnknownSoftware")

    def test_get_group_software(self, mock_store: MagicMock):
        """Test getting software used by a group."""
        engine = ATTACKQueryEngine(mock_store)

        software = engine.get_group_software("APT28")
        assert len(software) == 1
        assert software[0]["id"] == "S0002"
        assert software[0]["name"] == "Mimikatz"
        assert software[0]["type"] == "malware"

    def test_get_group_software_not_found(self, mock_store: MagicMock):
        """Test getting software for unknown group."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Group not found"):
            engine.get_group_software("UnknownGroup")

    def test_groups_using_software(self, mock_store: MagicMock):
        """Test getting groups that use software."""
        engine = ATTACKQueryEngine(mock_store)

        groups = engine.groups_using_software("Mimikatz")
        assert groups == ["APT28"]

    def test_groups_using_software_not_found(self, mock_store: MagicMock):
        """Test getting groups for unknown software."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Software not found"):
            engine.groups_using_software("UnknownSoftware")

    def test_software_using_technique(self, mock_store: MagicMock):
        """Test getting software that uses a technique."""
        engine = ATTACKQueryEngine(mock_store)

        software = engine.software_using_technique("T1566")
        assert len(software) == 1
        assert software[0]["id"] == "S0002"
        assert software[0]["name"] == "Mimikatz"

    def test_software_using_technique_multiple(self, mock_store: MagicMock):
        """Test getting multiple software using same technique."""
        engine = ATTACKQueryEngine(mock_store)

        # T1078 is used by Mimikatz
        software = engine.software_using_technique("T1078")
        assert len(software) == 1
        names = [s["name"] for s in software]
        assert "Mimikatz" in names

    def test_software_using_technique_none(self, mock_store: MagicMock):
        """Test technique used by no software."""
        engine = ATTACKQueryEngine(mock_store)

        # T1566.001 is a sub-technique not used by any software in mock
        software = engine.software_using_technique("T1566.001")
        assert software == []


class TestATTACKQueryEngineMitigation:
    """Tests for mitigation queries."""

    def test_get_mitigation_info_by_id(self, mock_store: MagicMock):
        """Test getting mitigation info by ID."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_mitigation_info("M1017")
        assert info["id"] == "M1017"
        assert info["name"] == "User Training"
        assert info["technique_count"] == 3

    def test_get_mitigation_info_by_name(self, mock_store: MagicMock):
        """Test getting mitigation info by name."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_mitigation_info("User Training")
        assert info["id"] == "M1017"
        assert info["name"] == "User Training"

    def test_get_mitigation_info_not_found(self, mock_store: MagicMock):
        """Test getting non-existent mitigation."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Mitigation not found"):
            engine.get_mitigation_info("M9999")

    def test_get_mitigations_for_technique(self, mock_store: MagicMock):
        """Test getting mitigations for a technique."""
        engine = ATTACKQueryEngine(mock_store)

        mitigations = engine.get_mitigations_for_technique("T1566")
        assert len(mitigations) == 2
        mit_ids = {m["id"] for m in mitigations}
        assert mit_ids == {"M1017", "M1031"}

    def test_get_mitigations_for_technique_single(self, mock_store: MagicMock):
        """Test getting mitigations when only one exists."""
        engine = ATTACKQueryEngine(mock_store)

        mitigations = engine.get_mitigations_for_technique("T1071")
        assert len(mitigations) == 1
        assert mitigations[0]["id"] == "M1031"

    def test_get_mitigations_for_technique_none(self, mock_store: MagicMock):
        """Test technique with no mitigations."""
        engine = ATTACKQueryEngine(mock_store)

        mitigations = engine.get_mitigations_for_technique("T1059")
        assert mitigations == []

    def test_get_techniques_mitigated_by(self, mock_store: MagicMock):
        """Test getting techniques mitigated by a mitigation."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_techniques_mitigated_by("M1017")
        assert len(techniques) == 3
        assert techniques == {"T1566", "T1566.001", "T1566.002"}

    def test_get_techniques_mitigated_by_name(self, mock_store: MagicMock):
        """Test getting techniques by mitigation name."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_techniques_mitigated_by("Network Intrusion Prevention")
        assert len(techniques) == 2
        assert "T1566" in techniques
        assert "T1071" in techniques

    def test_get_techniques_mitigated_by_not_found(self, mock_store: MagicMock):
        """Test getting techniques for non-existent mitigation."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Mitigation not found"):
            engine.get_techniques_mitigated_by("M9999")


class TestATTACKQueryEngineDataSource:
    """Tests for data source queries."""

    def test_get_data_source_info_by_id(self, mock_store: MagicMock):
        """Test getting data source info by ID."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_data_source_info("DS0009")
        assert info["id"] == "DS0009"
        assert info["name"] == "Process"
        assert "Windows" in info["platforms"]
        assert "Host" in info["collection_layers"]

    def test_get_data_source_info_by_name(self, mock_store: MagicMock):
        """Test getting data source info by name."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_data_source_info("Process")
        assert info["id"] == "DS0009"
        assert info["name"] == "Process"

    def test_get_data_source_info_not_found(self, mock_store: MagicMock):
        """Test error when data source not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Data source not found"):
            engine.get_data_source_info("NonExistent")

    def test_get_data_component_info_by_id(self, mock_store: MagicMock):
        """Test getting data component info by ID."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_data_component_info("DC0032")
        assert info["id"] == "DC0032"
        assert info["name"] == "Process Creation"
        assert info["technique_count"] == 2
        assert len(info["log_sources"]) == 2

    def test_get_data_component_info_by_name(self, mock_store: MagicMock):
        """Test getting data component info by name."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_data_component_info("Process Creation")
        assert info["id"] == "DC0032"
        assert info["name"] == "Process Creation"

    def test_get_data_component_info_not_found(self, mock_store: MagicMock):
        """Test error when data component not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Data component not found"):
            engine.get_data_component_info("NonExistent")

    def test_get_techniques_detectable_by_id(self, mock_store: MagicMock):
        """Test getting techniques detectable by a data component."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_techniques_detectable_by("DC0032")
        assert techniques == {"T1059", "T1566"}

    def test_get_techniques_detectable_by_name(self, mock_store: MagicMock):
        """Test getting techniques by data component name."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_techniques_detectable_by("Network Connection Creation")
        assert techniques == {"T1071"}

    def test_get_techniques_detectable_by_not_found(self, mock_store: MagicMock):
        """Test error when data component not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Data component not found"):
            engine.get_techniques_detectable_by("NonExistent")


class TestATTACKQueryEngineExport:
    """Tests for export functionality."""

    def test_export_csv_basic(self, mock_store: MagicMock):
        """Test basic CSV export."""
        engine = ATTACKQueryEngine(mock_store)

        csv_output = engine.export_csv({"T1566", "T1059"})
        lines = csv_output.strip().splitlines()

        assert lines[0].strip() == "id,name,tactics"
        assert len(lines) == 3  # header + 2 techniques
        assert "T1059" in lines[1]
        assert "T1566" in lines[2]

    def test_export_csv_with_description(self, mock_store: MagicMock):
        """Test CSV export with descriptions."""
        engine = ATTACKQueryEngine(mock_store)

        csv_output = engine.export_csv({"T1566"}, include_description=True)
        lines = csv_output.strip().splitlines()

        assert "description" in lines[0]
        assert len(lines) == 2

    def test_export_csv_empty(self, mock_store: MagicMock):
        """Test CSV export with no techniques."""
        engine = ATTACKQueryEngine(mock_store)

        csv_output = engine.export_csv(set())
        lines = csv_output.strip().splitlines()

        assert lines[0].strip() == "id,name,tactics"
        assert len(lines) == 1  # header only

    def test_export_csv_unknown_technique(self, mock_store: MagicMock):
        """Test CSV export skips unknown techniques."""
        engine = ATTACKQueryEngine(mock_store)

        csv_output = engine.export_csv({"T1566", "T9999"})
        lines = csv_output.strip().splitlines()

        assert len(lines) == 2  # header + T1566 only

    def test_export_markdown_basic(self, mock_store: MagicMock):
        """Test basic Markdown export."""
        engine = ATTACKQueryEngine(mock_store)

        md_output = engine.export_markdown({"T1566", "T1059"})
        lines = md_output.strip().split("\n")

        assert lines[0] == "## Query Results"
        assert "| ID | Name | Tactics |" in md_output
        assert "| T1566 | Phishing |" in md_output
        assert "| T1059 | Command and Scripting Interpreter |" in md_output

    def test_export_markdown_custom_title(self, mock_store: MagicMock):
        """Test Markdown export with custom title."""
        engine = ATTACKQueryEngine(mock_store)

        md_output = engine.export_markdown({"T1566"}, title="APT28 Techniques")

        assert "## APT28 Techniques" in md_output

    def test_export_markdown_empty(self, mock_store: MagicMock):
        """Test Markdown export with no techniques."""
        engine = ATTACKQueryEngine(mock_store)

        md_output = engine.export_markdown(set())
        lines = md_output.strip().split("\n")

        assert lines[0] == "## Query Results"
        assert "| ID | Name | Tactics |" in md_output
        assert len(lines) == 4  # title, blank, header, separator

    def test_export_csv_sorted(self, mock_store: MagicMock):
        """Test that CSV export is sorted by technique ID."""
        engine = ATTACKQueryEngine(mock_store)

        csv_output = engine.export_csv({"T1078", "T1059", "T1566"})
        lines = csv_output.strip().splitlines()

        # Techniques should be sorted: T1059, T1078, T1566
        assert "T1059" in lines[1]
        assert "T1078" in lines[2]
        assert "T1566" in lines[3]

    def test_export_markdown_sorted(self, mock_store: MagicMock):
        """Test that Markdown export is sorted by technique ID."""
        engine = ATTACKQueryEngine(mock_store)

        md_output = engine.export_markdown({"T1078", "T1059", "T1566"})

        # Find the lines with technique IDs
        t1059_pos = md_output.find("T1059")
        t1078_pos = md_output.find("T1078")
        t1566_pos = md_output.find("T1566")

        assert t1059_pos < t1078_pos < t1566_pos


class TestATTACKQueryEngineCampaign:
    """Tests for campaign queries."""

    def test_get_campaign_info_by_id(self, mock_store: MagicMock):
        """Test getting campaign info by ID."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_campaign_info("C0027")
        assert info["id"] == "C0027"
        assert info["name"] == "Test Campaign"
        assert info["first_seen"] == "2022-06-01T04:00:00.000Z"
        assert info["last_seen"] == "2023-01-01T04:00:00.000Z"
        assert "Operation Test" in info["aliases"]
        assert info["technique_count"] == 2
        assert info["software_count"] == 1
        assert "APT28" in info["groups"]

    def test_get_campaign_info_by_name(self, mock_store: MagicMock):
        """Test getting campaign info by name."""
        engine = ATTACKQueryEngine(mock_store)

        info = engine.get_campaign_info("Test Campaign")
        assert info["id"] == "C0027"
        assert info["name"] == "Test Campaign"

    def test_get_campaign_info_not_found(self, mock_store: MagicMock):
        """Test error when campaign not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Campaign not found"):
            engine.get_campaign_info("NonExistent")

    def test_get_group_campaigns(self, mock_store: MagicMock):
        """Test getting campaigns attributed to a group."""
        engine = ATTACKQueryEngine(mock_store)

        campaigns = engine.get_group_campaigns("APT28")
        assert len(campaigns) == 2
        campaign_ids = {c["id"] for c in campaigns}
        assert campaign_ids == {"C0027", "C0028"}

    def test_get_group_campaigns_single(self, mock_store: MagicMock):
        """Test getting campaigns for group with one campaign."""
        engine = ATTACKQueryEngine(mock_store)

        campaigns = engine.get_group_campaigns("APT29")
        assert len(campaigns) == 1
        assert campaigns[0]["id"] == "C0028"

    def test_get_group_campaigns_not_found(self, mock_store: MagicMock):
        """Test error when group not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Group not found"):
            engine.get_group_campaigns("NonExistent")

    def test_get_group_campaigns_no_campaigns(self, mock_store: MagicMock):
        """Test group with no attributed campaigns."""
        engine = ATTACKQueryEngine(mock_store)

        campaigns = engine.get_group_campaigns("APT33")
        assert campaigns == []

    def test_get_campaign_techniques(self, mock_store: MagicMock):
        """Test getting techniques used in a campaign."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_campaign_techniques("C0027")
        assert techniques == {"T1566", "T1059"}

    def test_get_campaign_techniques_by_name(self, mock_store: MagicMock):
        """Test getting techniques by campaign name."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_campaign_techniques("Test Campaign")
        assert techniques == {"T1566", "T1059"}

    def test_get_campaign_techniques_not_found(self, mock_store: MagicMock):
        """Test error when campaign not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Campaign not found"):
            engine.get_campaign_techniques("NonExistent")


class TestATTACKQueryEngineCampaignTimeline:
    """Tests for campaign timeline queries."""

    def test_get_campaigns_in_year(self, mock_store: MagicMock):
        """Test getting campaigns active in a specific year."""
        engine = ATTACKQueryEngine(mock_store)

        # 2022: C0027 was active (2022-06 to 2023-01)
        campaigns = engine.get_campaigns_in_year(2022)
        assert len(campaigns) == 1
        assert campaigns[0]["id"] == "C0027"

    def test_get_campaigns_in_year_multiple(self, mock_store: MagicMock):
        """Test getting multiple campaigns in overlapping year."""
        engine = ATTACKQueryEngine(mock_store)

        # 2023: Both campaigns were active
        # C0027: 2022-06 to 2023-01
        # C0028: 2023-01 to 2023-06
        campaigns = engine.get_campaigns_in_year(2023)
        assert len(campaigns) == 2
        campaign_ids = {c["id"] for c in campaigns}
        assert campaign_ids == {"C0027", "C0028"}

    def test_get_campaigns_in_year_none(self, mock_store: MagicMock):
        """Test getting campaigns in a year with no activity."""
        engine = ATTACKQueryEngine(mock_store)

        # 2020: No campaigns active
        campaigns = engine.get_campaigns_in_year(2020)
        assert len(campaigns) == 0

    def test_get_campaigns_in_range(self, mock_store: MagicMock):
        """Test getting campaigns in a year range."""
        engine = ATTACKQueryEngine(mock_store)

        campaigns = engine.get_campaigns_in_range(2022, 2023)
        assert len(campaigns) == 2
        campaign_ids = {c["id"] for c in campaigns}
        assert campaign_ids == {"C0027", "C0028"}

    def test_get_campaigns_in_range_partial(self, mock_store: MagicMock):
        """Test campaigns partially overlapping with range."""
        engine = ATTACKQueryEngine(mock_store)

        # Only C0027 started in 2022
        campaigns = engine.get_campaigns_in_range(2022, 2022)
        assert len(campaigns) == 1
        assert campaigns[0]["id"] == "C0027"

    def test_get_techniques_in_year(self, mock_store: MagicMock):
        """Test getting techniques from campaigns in a year."""
        engine = ATTACKQueryEngine(mock_store)

        # 2023 has both campaigns active
        techniques = engine.get_techniques_in_year(2023)
        # C0027: T1566, T1059
        # C0028: T1078, T1071
        assert techniques == {"T1566", "T1059", "T1078", "T1071"}

    def test_get_techniques_in_year_single_campaign(self, mock_store: MagicMock):
        """Test techniques from a single campaign in a year."""
        engine = ATTACKQueryEngine(mock_store)

        # 2022 only has C0027 active
        techniques = engine.get_techniques_in_year(2022)
        assert techniques == {"T1566", "T1059"}

    def test_get_techniques_in_range(self, mock_store: MagicMock):
        """Test getting techniques from campaigns in a range."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_techniques_in_range(2022, 2023)
        assert techniques == {"T1566", "T1059", "T1078", "T1071"}

    def test_get_techniques_in_range_none(self, mock_store: MagicMock):
        """Test getting techniques from a range with no campaigns."""
        engine = ATTACKQueryEngine(mock_store)

        techniques = engine.get_techniques_in_range(2010, 2015)
        assert techniques == set()


class TestSimilarityScoring:
    """Tests for similarity scoring functionality."""

    def test_calculate_group_similarity_basic(self, mock_store: MagicMock):
        """Test basic similarity calculation between two groups."""
        engine = ATTACKQueryEngine(mock_store)

        result = engine.calculate_group_similarity("APT28", "APT29")

        assert result["group1"] == "APT28"
        assert result["group2"] == "APT29"
        assert result["group1_technique_count"] == 3  # T1566, T1059, T1078
        assert result["group2_technique_count"] == 3  # T1566, T1078, T1071
        assert result["shared_count"] == 2  # T1566, T1078
        assert "T1566" in result["shared_techniques"]
        assert "T1078" in result["shared_techniques"]
        # Jaccard: 2 shared / 4 union = 0.5
        assert result["jaccard"] == 0.5

    def test_calculate_group_similarity_same_group(self, mock_store: MagicMock):
        """Test similarity when comparing a group to itself."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28 vs APT28 should give perfect similarity
        result = engine.calculate_group_similarity("APT28", "APT28")

        assert result["jaccard"] == 1.0
        assert result["overlap"] == 1.0
        assert result["cosine"] == 1.0
        assert result["shared_count"] == 3

    def test_calculate_group_similarity_no_overlap(self, mock_store: MagicMock):
        """Test similarity when groups have no shared techniques."""
        # Create a group with no overlap
        no_overlap = Group(
            id="G9999",
            stix_id="intrusion-set--99",
            name="NoOverlap",
            description="...",
            techniques={"T1071"},  # Only T1071, not shared with APT33
        )
        mock_store.groups["G9999"] = no_overlap
        mock_store.groups_by_name["nooverlap"] = no_overlap

        engine = ATTACKQueryEngine(mock_store)

        # APT33 has T1566, T1059 - NoOverlap has T1071
        result = engine.calculate_group_similarity("APT33", "NoOverlap")

        assert result["shared_count"] == 0
        assert result["jaccard"] == 0.0
        assert result["overlap"] == 0.0
        assert result["cosine"] == 0.0

    def test_calculate_group_similarity_overlap_metric(self, mock_store: MagicMock):
        """Test the overlap coefficient metric."""
        engine = ATTACKQueryEngine(mock_store)

        # APT28 has 3 techniques, APT33 has 2 techniques
        # Shared: T1566, T1059 (2)
        result = engine.calculate_group_similarity("APT28", "APT33")

        # Overlap: 2 / min(3, 2) = 2/2 = 1.0
        assert result["overlap"] == 1.0

    def test_calculate_group_similarity_group_not_found(self, mock_store: MagicMock):
        """Test error when group not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Group not found"):
            engine.calculate_group_similarity("NonExistent", "APT28")

        with pytest.raises(ValueError, match="Group not found"):
            engine.calculate_group_similarity("APT28", "NonExistent")

    def test_find_similar_groups_basic(self, mock_store: MagicMock):
        """Test finding similar groups."""
        engine = ATTACKQueryEngine(mock_store)

        results = engine.find_similar_groups("APT28")

        # Should find APT29 and APT33 as similar groups
        assert len(results) == 2
        # Results should be sorted by similarity descending
        assert results[0]["similarity"] >= results[1]["similarity"]

    def test_find_similar_groups_with_threshold(self, mock_store: MagicMock):
        """Test finding similar groups with threshold filter."""
        engine = ATTACKQueryEngine(mock_store)

        # With high threshold, should find fewer groups
        results = engine.find_similar_groups("APT28", threshold=0.6)

        # APT33 has 2/3 overlap = 0.666 Jaccard with APT28
        # APT29 has 2/4 = 0.5 Jaccard with APT28
        # Only APT33 should pass the 0.6 threshold
        assert len(results) == 1
        assert results[0]["group"] == "APT33"

    def test_find_similar_groups_with_limit(self, mock_store: MagicMock):
        """Test limiting number of similar groups returned."""
        engine = ATTACKQueryEngine(mock_store)

        results = engine.find_similar_groups("APT28", limit=1)

        assert len(results) == 1

    def test_find_similar_groups_different_metrics(self, mock_store: MagicMock):
        """Test finding similar groups with different metrics."""
        engine = ATTACKQueryEngine(mock_store)

        jaccard_results = engine.find_similar_groups("APT28", metric="jaccard")
        overlap_results = engine.find_similar_groups("APT28", metric="overlap")
        cosine_results = engine.find_similar_groups("APT28", metric="cosine")

        # All should return results, but potentially different ordering
        assert len(jaccard_results) > 0
        assert len(overlap_results) > 0
        assert len(cosine_results) > 0

    def test_find_similar_groups_invalid_metric(self, mock_store: MagicMock):
        """Test error when using invalid metric."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Invalid metric"):
            engine.find_similar_groups("APT28", metric="invalid")

    def test_find_similar_groups_group_not_found(self, mock_store: MagicMock):
        """Test error when group not found."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Group not found"):
            engine.find_similar_groups("NonExistent")

    def test_find_similar_groups_empty_techniques(self, mock_store: MagicMock):
        """Test finding similar groups when target has no techniques."""
        empty_group = Group(
            id="G9998",
            stix_id="intrusion-set--98",
            name="EmptyGroup",
            description="...",
            techniques=set(),
        )
        mock_store.groups["G9998"] = empty_group
        mock_store.groups_by_name["emptygroup"] = empty_group

        engine = ATTACKQueryEngine(mock_store)

        results = engine.find_similar_groups("EmptyGroup")
        assert results == []

    def test_find_similar_groups_result_format(self, mock_store: MagicMock):
        """Test the format of similar groups results."""
        engine = ATTACKQueryEngine(mock_store)

        results = engine.find_similar_groups("APT28")

        for result in results:
            assert "group" in result
            assert "group_id" in result
            assert "similarity" in result
            assert "shared_count" in result
            assert "technique_count" in result
            assert 0 <= result["similarity"] <= 1

    def test_find_similar_groups_skips_empty_other_groups(self, mock_store: MagicMock):
        """Test that groups with no techniques are skipped in comparison."""
        # Add a group with no techniques
        empty_group = Group(
            id="G9999",
            stix_id="intrusion-set--99",
            name="NoTechGroup",
            description="...",
            techniques=set(),
        )
        mock_store.groups["G9999"] = empty_group
        mock_store.groups_by_name["notechgroup"] = empty_group

        engine = ATTACKQueryEngine(mock_store)

        # Search for groups similar to APT28 - should not include empty group
        results = engine.find_similar_groups("APT28")
        result_names = {r["group"] for r in results}
        assert "NoTechGroup" not in result_names

    def test_find_similar_groups_skips_no_overlap(self, mock_store: MagicMock):
        """Test that groups with no technique overlap are excluded."""
        # Add a group with techniques that don't overlap with APT28
        no_overlap_group = Group(
            id="G9997",
            stix_id="intrusion-set--97",
            name="NoOverlapGroup",
            description="...",
            techniques={"T1071"},  # APT28 doesn't have T1071
        )
        mock_store.groups["G9997"] = no_overlap_group
        mock_store.groups_by_name["nooverlapgroup"] = no_overlap_group

        engine = ATTACKQueryEngine(mock_store)

        # APT28 has T1566, T1059, T1078 - no overlap with T1071
        results = engine.find_similar_groups("APT28")
        result_names = {r["group"] for r in results}
        assert "NoOverlapGroup" not in result_names


class TestATTACKQueryEngineEdgeCases:
    """Tests for edge cases in ATTACKQueryEngine."""

    def test_techniques_intersection_empty_list(self, mock_store: MagicMock):
        """Test techniques_intersection with empty group list."""
        engine = ATTACKQueryEngine(mock_store)

        result = engine.techniques_intersection([])

        assert result == set()

    def test_tactics_intersection_empty_list(self, mock_store: MagicMock):
        """Test tactics_intersection with empty group list."""
        engine = ATTACKQueryEngine(mock_store)

        result = engine.tactics_intersection([])

        assert result == set()

    def test_group_techniques_hierarchically_unknown_technique(self, mock_store: MagicMock):
        """Test hierarchical grouping with unknown technique IDs."""
        engine = ATTACKQueryEngine(mock_store)

        # Include a technique ID that doesn't exist
        result = engine.group_techniques_hierarchically(
            {"T1566", "T9999", "T1059"}  # T9999 doesn't exist
        )

        # Should skip unknown technique and return hierarchy for known ones
        assert "T1566" in result
        assert "T1059" in result
        assert "T9999" not in result

    def test_get_techniques_by_tactic_unknown_tactic(self, mock_store: MagicMock):
        """Test get_techniques_by_tactic with unknown tactic."""
        engine = ATTACKQueryEngine(mock_store)

        with pytest.raises(ValueError, match="Tactic not found"):
            engine.get_techniques_by_tactic("nonexistent-tactic")

    def test_export_navigator_layer_subtechnique_no_tactics(self, mock_store: MagicMock):
        """Test export_navigator_layer with sub-technique that has no tactics."""
        # Add a sub-technique with empty tactics list
        empty_tactics_subtech = Technique(
            id="T1566.099",
            stix_id="attack-pattern--99",
            name="Empty Tactics Subtech",
            description="...",
            tactics=[],  # Empty tactics
            is_subtechnique=True,
            parent_id="T1566",
        )
        mock_store.techniques["T1566.099"] = empty_tactics_subtech

        engine = ATTACKQueryEngine(mock_store)

        # Should handle empty tactics gracefully
        layer = engine.export_navigator_layer(
            {"T1566.099"},
            name="Test Layer",
        )

        assert layer["name"] == "Test Layer"
        assert len(layer["techniques"]) == 1
        # The tactic field should be empty string for sub-technique with no tactics
        assert layer["techniques"][0]["tactic"] == ""

    def test_export_navigator_layer_parent_technique_in_result(self, mock_store: MagicMock):
        """Test export_navigator_layer with parent technique."""
        engine = ATTACKQueryEngine(mock_store)

        # Export parent technique (not a sub-technique)
        layer = engine.export_navigator_layer(
            {"T1566"},
            name="Parent Only",
        )

        assert len(layer["techniques"]) == 1
        assert layer["techniques"][0]["techniqueID"] == "T1566"

    def test_techniques_union_empty_list(self, mock_store: MagicMock):
        """Test techniques_union with empty group list."""
        engine = ATTACKQueryEngine(mock_store)

        result = engine.techniques_union([])

        assert result == set()
