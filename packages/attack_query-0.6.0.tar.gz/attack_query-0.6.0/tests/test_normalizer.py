"""Tests for attack_query.normalizer."""

from __future__ import annotations

from unittest.mock import MagicMock

from attack_query.normalizer import NORMALIZE_PROMPT, QueryNormalizer


class MockCompletionModel:
    """Mock CompletionModel for testing."""

    def __init__(self, response: str = "techniques used by APT28"):
        self._response = response
        self.last_prompt: str | None = None

    @property
    def model_name(self) -> str:
        return "mock:test"

    def complete(self, prompt: str) -> str:
        self.last_prompt = prompt
        return self._response


class TestQueryNormalizer:
    """Tests for QueryNormalizer."""

    def test_init_with_model(self):
        """Test initializing with just a model."""
        model = MockCompletionModel()
        normalizer = QueryNormalizer(model)

        assert normalizer.model is model
        assert normalizer.store is None

    def test_init_with_model_and_store(self):
        """Test initializing with model and store."""
        model = MockCompletionModel()
        store = MagicMock()
        normalizer = QueryNormalizer(model, store=store)

        assert normalizer.model is model
        assert normalizer.store is store

    def test_normalize_basic(self):
        """Test basic query normalization."""
        model = MockCompletionModel(response="techniques used by APT28")
        normalizer = QueryNormalizer(model)

        result = normalizer.normalize("what attacks does fancy bear do")

        assert result == "techniques used by APT28"
        assert model.last_prompt is not None
        assert "what attacks does fancy bear do" in model.last_prompt

    def test_normalize_strips_whitespace(self):
        """Test that whitespace is stripped from response."""
        model = MockCompletionModel(response="  techniques used by APT28  \n")
        normalizer = QueryNormalizer(model)

        result = normalizer.normalize("test query")

        assert result == "techniques used by APT28"

    def test_normalize_strips_double_quotes(self):
        """Test that surrounding double quotes are removed."""
        model = MockCompletionModel(response='"techniques used by APT28"')
        normalizer = QueryNormalizer(model)

        result = normalizer.normalize("test query")

        assert result == "techniques used by APT28"

    def test_normalize_strips_single_quotes(self):
        """Test that surrounding single quotes are removed."""
        model = MockCompletionModel(response="'techniques used by APT28'")
        normalizer = QueryNormalizer(model)

        result = normalizer.normalize("test query")

        assert result == "techniques used by APT28"

    def test_normalize_preserves_internal_quotes(self):
        """Test that internal quotes are preserved."""
        model = MockCompletionModel(response='who is "Fancy Bear"')
        normalizer = QueryNormalizer(model)

        result = normalizer.normalize("test query")

        assert result == 'who is "Fancy Bear"'

    def test_normalize_prompt_contains_query(self):
        """Test that the prompt includes the user query."""
        model = MockCompletionModel()
        normalizer = QueryNormalizer(model)

        normalizer.normalize("show me APT29 techniques")

        assert model.last_prompt is not None
        assert "show me APT29 techniques" in model.last_prompt

    def test_normalize_prompt_contains_canonical_forms(self):
        """Test that the prompt includes canonical form examples."""
        model = MockCompletionModel()
        normalizer = QueryNormalizer(model)

        normalizer.normalize("test")

        assert model.last_prompt is not None
        assert "techniques used by GROUP" in model.last_prompt
        assert "groups using TECHNIQUE_ID" in model.last_prompt
        assert "software used by GROUP" in model.last_prompt


class TestNormalizePrompt:
    """Tests for the NORMALIZE_PROMPT template."""

    def test_prompt_is_formattable(self):
        """Test that the prompt can be formatted with a query."""
        formatted = NORMALIZE_PROMPT.format(query="test query")

        assert "test query" in formatted
        assert "{query}" not in formatted

    def test_prompt_contains_all_canonical_forms(self):
        """Test that all canonical forms are documented in the prompt."""
        expected_forms = [
            "techniques used by GROUP",
            "techniques used by GROUP1 or GROUP2",
            "techniques used by GROUP1 and GROUP2",
            "techniques used by GROUP1 but not GROUP2",
            "techniques NOT used by GROUP",
            "groups using TECHNIQUE_ID",
            "compare GROUP1 and GROUP2",
            "groups similar to GROUP",
            "similarity GROUP1 GROUP2",
            "software used by GROUP",
            "groups using SOFTWARE",
            "techniques for SOFTWARE",
            "mitigations for TECHNIQUE_ID",
            "techniques mitigated by MITIGATION",
            "campaigns by GROUP",
            "techniques in CAMPAIGN",
            "campaigns in YEAR",
            "sub-techniques of TECHNIQUE_ID",
            "parent of TECHNIQUE_ID",
            "who is GROUP",
            "aliases of GROUP",
        ]

        for form in expected_forms:
            assert form in NORMALIZE_PROMPT, f"Missing canonical form: {form}"

    def test_prompt_mentions_known_groups(self):
        """Test that the prompt mentions known group examples."""
        assert "APT28" in NORMALIZE_PROMPT
        assert "APT29" in NORMALIZE_PROMPT
        assert "Fancy Bear" in NORMALIZE_PROMPT

    def test_prompt_mentions_technique_format(self):
        """Test that the prompt explains technique ID format."""
        assert "T1566" in NORMALIZE_PROMPT
        assert "T1566.001" in NORMALIZE_PROMPT
