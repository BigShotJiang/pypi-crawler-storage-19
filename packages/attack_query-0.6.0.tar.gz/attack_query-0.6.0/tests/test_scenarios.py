"""Scenario-based tests for real-world security operations use cases.

These tests validate attack-query against practical workflows used by:
- Threat intelligence analysts
- Detection engineers
- Security architects
- Red team operators
- Incident responders

Each test class represents a distinct use case with realistic queries.
"""

from __future__ import annotations

import pytest

from attack_query.engine import ATTACKQueryEngine
from attack_query.parser import NLQueryParser
from attack_query.store import ATTACKDataStore

# Comprehensive STIX fixture data for scenario testing
SCENARIO_STIX_DATA = {
    "type": "bundle",
    "id": "bundle--scenarios",
    "objects": [
        # Version metadata
        {
            "type": "x-mitre-collection",
            "id": "x-mitre-collection--test",
            "x_mitre_version": "15.0",
        },
        # === TACTICS ===
        {
            "type": "x-mitre-tactic",
            "id": "x-mitre-tactic--initial-access",
            "name": "Initial Access",
            "x_mitre_shortname": "initial-access",
            "description": "Initial access tactic",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "TA0001"}
            ],
        },
        {
            "type": "x-mitre-tactic",
            "id": "x-mitre-tactic--execution",
            "name": "Execution",
            "x_mitre_shortname": "execution",
            "description": "Execution tactic",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "TA0002"}
            ],
        },
        {
            "type": "x-mitre-tactic",
            "id": "x-mitre-tactic--persistence",
            "name": "Persistence",
            "x_mitre_shortname": "persistence",
            "description": "Persistence tactic",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "TA0003"}
            ],
        },
        {
            "type": "x-mitre-tactic",
            "id": "x-mitre-tactic--credential-access",
            "name": "Credential Access",
            "x_mitre_shortname": "credential-access",
            "description": "Credential access tactic",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "TA0006"}
            ],
        },
        {
            "type": "x-mitre-tactic",
            "id": "x-mitre-tactic--lateral-movement",
            "name": "Lateral Movement",
            "x_mitre_shortname": "lateral-movement",
            "description": "Lateral movement tactic",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "TA0008"}
            ],
        },
        # === TECHNIQUES ===
        # Initial Access techniques
        {
            "type": "attack-pattern",
            "id": "attack-pattern--phishing",
            "name": "Phishing",
            "description": "Adversaries may send phishing messages",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1566"}
            ],
        },
        {
            "type": "attack-pattern",
            "id": "attack-pattern--phishing-attachment",
            "name": "Spearphishing Attachment",
            "description": "Adversaries may send spearphishing emails with malicious attachment",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "x_mitre_is_subtechnique": True,
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1566.001"}
            ],
        },
        {
            "type": "attack-pattern",
            "id": "attack-pattern--phishing-link",
            "name": "Spearphishing Link",
            "description": "Adversaries may send spearphishing emails with malicious link",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "x_mitre_is_subtechnique": True,
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1566.002"}
            ],
        },
        {
            "type": "attack-pattern",
            "id": "attack-pattern--valid-accounts",
            "name": "Valid Accounts",
            "description": "Adversaries may use valid accounts to gain access",
            "x_mitre_platforms": ["Windows", "Linux", "macOS", "Azure AD"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "initial-access"},
                {"kill_chain_name": "mitre-attack", "phase_name": "persistence"},
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1078"}
            ],
        },
        # Execution techniques
        {
            "type": "attack-pattern",
            "id": "attack-pattern--cmd-script",
            "name": "Command and Scripting Interpreter",
            "description": "Adversaries may abuse command and script interpreters",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "execution"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1059"}
            ],
        },
        {
            "type": "attack-pattern",
            "id": "attack-pattern--powershell",
            "name": "PowerShell",
            "description": "Adversaries may abuse PowerShell",
            "x_mitre_platforms": ["Windows"],
            "x_mitre_is_subtechnique": True,
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "execution"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1059.001"}
            ],
        },
        # Credential Access techniques
        {
            "type": "attack-pattern",
            "id": "attack-pattern--cred-dump",
            "name": "OS Credential Dumping",
            "description": "Adversaries may dump credentials from the operating system",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "credential-access"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1003"}
            ],
        },
        {
            "type": "attack-pattern",
            "id": "attack-pattern--lsass-dump",
            "name": "LSASS Memory",
            "description": "Adversaries may dump LSASS memory",
            "x_mitre_platforms": ["Windows"],
            "x_mitre_is_subtechnique": True,
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "credential-access"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1003.001"}
            ],
        },
        {
            "type": "attack-pattern",
            "id": "attack-pattern--brute-force",
            "name": "Brute Force",
            "description": "Adversaries may use brute force techniques",
            "x_mitre_platforms": ["Windows", "Linux", "macOS", "Azure AD"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "credential-access"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1110"}
            ],
        },
        # Lateral Movement techniques
        {
            "type": "attack-pattern",
            "id": "attack-pattern--remote-services",
            "name": "Remote Services",
            "description": "Adversaries may use remote services to move laterally",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "lateral-movement"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1021"}
            ],
        },
        {
            "type": "attack-pattern",
            "id": "attack-pattern--smb-admin",
            "name": "SMB/Windows Admin Shares",
            "description": "Adversaries may use SMB admin shares",
            "x_mitre_platforms": ["Windows"],
            "x_mitre_is_subtechnique": True,
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "lateral-movement"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1021.002"}
            ],
        },
        # Persistence technique
        {
            "type": "attack-pattern",
            "id": "attack-pattern--scheduled-task",
            "name": "Scheduled Task/Job",
            "description": "Adversaries may use scheduled tasks for persistence",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "kill_chain_phases": [
                {"kill_chain_name": "mitre-attack", "phase_name": "persistence"},
                {"kill_chain_name": "mitre-attack", "phase_name": "execution"},
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "T1053"}
            ],
        },
        # === GROUPS (Threat Actors) ===
        {
            "type": "intrusion-set",
            "id": "intrusion-set--apt28",
            "name": "APT28",
            "description": "APT28 is a Russian threat group",
            "aliases": ["Fancy Bear", "Sofacy", "Pawn Storm", "STRONTIUM"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "G0007"}
            ],
        },
        {
            "type": "intrusion-set",
            "id": "intrusion-set--apt29",
            "name": "APT29",
            "description": "APT29 is a Russian threat group",
            "aliases": ["Cozy Bear", "The Dukes", "NOBELIUM"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "G0016"}
            ],
        },
        {
            "type": "intrusion-set",
            "id": "intrusion-set--apt33",
            "name": "APT33",
            "description": "APT33 is an Iranian threat group",
            "aliases": ["Elfin", "Holmium", "Magnallium"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "G0064"}
            ],
        },
        {
            "type": "intrusion-set",
            "id": "intrusion-set--fin7",
            "name": "FIN7",
            "description": "FIN7 is a financially motivated threat group",
            "aliases": ["Carbanak Group", "Navigator Group"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "G0046"}
            ],
        },
        # === SOFTWARE ===
        {
            "type": "malware",
            "id": "malware--mimikatz",
            "name": "Mimikatz",
            "description": "Credential dumping tool",
            "x_mitre_aliases": ["Mimikatz", "sekurlsa"],
            "x_mitre_platforms": ["Windows"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "S0002"}
            ],
        },
        {
            "type": "tool",
            "id": "tool--cobalt-strike",
            "name": "Cobalt Strike",
            "description": "Commercial adversary simulation platform",
            "x_mitre_aliases": ["Cobalt Strike", "CobaltStrike", "Beacon"],
            "x_mitre_platforms": ["Windows", "Linux"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "S0154"}
            ],
        },
        {
            "type": "tool",
            "id": "tool--psexec",
            "name": "PsExec",
            "description": "Microsoft Sysinternals tool",
            "x_mitre_aliases": ["PsExec"],
            "x_mitre_platforms": ["Windows"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "S0029"}
            ],
        },
        # === MITIGATIONS ===
        {
            "type": "course-of-action",
            "id": "course-of-action--user-training",
            "name": "User Training",
            "description": "Train users to identify social engineering",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "M1017"}
            ],
        },
        {
            "type": "course-of-action",
            "id": "course-of-action--mfa",
            "name": "Multi-factor Authentication",
            "description": "Require MFA for accounts",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "M1032"}
            ],
        },
        {
            "type": "course-of-action",
            "id": "course-of-action--priv-account",
            "name": "Privileged Account Management",
            "description": "Manage privileged accounts",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "M1026"}
            ],
        },
        {
            "type": "course-of-action",
            "id": "course-of-action--credential-protection",
            "name": "Credential Access Protection",
            "description": "Protect credentials from dumping",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "M1043"}
            ],
        },
        # === DATA SOURCES & COMPONENTS ===
        {
            "type": "x-mitre-data-source",
            "id": "x-mitre-data-source--process",
            "name": "Process",
            "description": "Information about running processes",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "x_mitre_collection_layers": ["Host"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "DS0009"}
            ],
        },
        {
            "type": "x-mitre-data-source",
            "id": "x-mitre-data-source--logon",
            "name": "Logon Session",
            "description": "Logon session information",
            "x_mitre_platforms": ["Windows", "Linux", "macOS"],
            "x_mitre_collection_layers": ["Host"],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "DS0028"}
            ],
        },
        {
            "type": "x-mitre-data-component",
            "id": "x-mitre-data-component--process-creation",
            "name": "Process Creation",
            "description": "Process creation events",
            "x_mitre_log_sources": [
                {"name": "Sysmon", "channel": "Microsoft-Windows-Sysmon/Operational"},
                {"name": "Windows Security", "channel": "Security"},
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "DC0001"}
            ],
        },
        {
            "type": "x-mitre-data-component",
            "id": "x-mitre-data-component--logon-session",
            "name": "Logon Session Creation",
            "description": "Logon session creation events",
            "x_mitre_log_sources": [
                {"name": "Windows Security", "channel": "Security"}
            ],
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "DC0002"}
            ],
        },
        # === CAMPAIGNS ===
        {
            "type": "campaign",
            "id": "campaign--solarwinds",
            "name": "SolarWinds Compromise",
            "description": "Supply chain attack via SolarWinds Orion",
            "aliases": ["SUNBURST", "Solorigate"],
            "first_seen": "2020-03-01T00:00:00.000Z",
            "last_seen": "2021-01-01T00:00:00.000Z",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "C0024"}
            ],
        },
        {
            "type": "campaign",
            "id": "campaign--2023-phishing",
            "name": "2023 Credential Phishing",
            "description": "Large-scale credential phishing campaign",
            "first_seen": "2023-01-15T00:00:00.000Z",
            "last_seen": "2023-06-30T00:00:00.000Z",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "C0030"}
            ],
        },
        {
            "type": "campaign",
            "id": "campaign--2022-ransomware",
            "name": "2022 Ransomware Wave",
            "description": "Ransomware campaign targeting healthcare",
            "first_seen": "2022-03-01T00:00:00.000Z",
            "last_seen": "2022-12-31T00:00:00.000Z",
            "external_references": [
                {"source_name": "mitre-attack", "external_id": "C0028"}
            ],
        },
        # === RELATIONSHIPS ===
        # APT28 uses techniques
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt28",
            "target_ref": "attack-pattern--phishing",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt28",
            "target_ref": "attack-pattern--phishing-attachment",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt28",
            "target_ref": "attack-pattern--cmd-script",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt28",
            "target_ref": "attack-pattern--powershell",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt28",
            "target_ref": "attack-pattern--cred-dump",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt28",
            "target_ref": "attack-pattern--valid-accounts",
        },
        # APT29 uses techniques
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt29",
            "target_ref": "attack-pattern--phishing",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt29",
            "target_ref": "attack-pattern--phishing-link",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt29",
            "target_ref": "attack-pattern--valid-accounts",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt29",
            "target_ref": "attack-pattern--cred-dump",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt29",
            "target_ref": "attack-pattern--scheduled-task",
        },
        # APT33 uses techniques
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt33",
            "target_ref": "attack-pattern--phishing",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt33",
            "target_ref": "attack-pattern--powershell",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt33",
            "target_ref": "attack-pattern--brute-force",
        },
        # FIN7 uses techniques
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--fin7",
            "target_ref": "attack-pattern--phishing-attachment",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--fin7",
            "target_ref": "attack-pattern--powershell",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--fin7",
            "target_ref": "attack-pattern--remote-services",
        },
        # Group uses software
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt28",
            "target_ref": "malware--mimikatz",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--apt29",
            "target_ref": "tool--cobalt-strike",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "intrusion-set--fin7",
            "target_ref": "tool--cobalt-strike",
        },
        # Software uses techniques
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "malware--mimikatz",
            "target_ref": "attack-pattern--cred-dump",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "malware--mimikatz",
            "target_ref": "attack-pattern--lsass-dump",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "tool--cobalt-strike",
            "target_ref": "attack-pattern--cmd-script",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "tool--cobalt-strike",
            "target_ref": "attack-pattern--powershell",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "tool--cobalt-strike",
            "target_ref": "attack-pattern--remote-services",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "tool--psexec",
            "target_ref": "attack-pattern--smb-admin",
        },
        # Mitigations mitigate techniques
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--user-training",
            "target_ref": "attack-pattern--phishing",
        },
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--user-training",
            "target_ref": "attack-pattern--phishing-attachment",
        },
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--user-training",
            "target_ref": "attack-pattern--phishing-link",
        },
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--mfa",
            "target_ref": "attack-pattern--valid-accounts",
        },
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--mfa",
            "target_ref": "attack-pattern--brute-force",
        },
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--priv-account",
            "target_ref": "attack-pattern--cred-dump",
        },
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--credential-protection",
            "target_ref": "attack-pattern--cred-dump",
        },
        {
            "type": "relationship",
            "relationship_type": "mitigates",
            "source_ref": "course-of-action--credential-protection",
            "target_ref": "attack-pattern--lsass-dump",
        },
        # Campaign relationships
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "campaign--solarwinds",
            "target_ref": "attack-pattern--valid-accounts",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "campaign--solarwinds",
            "target_ref": "attack-pattern--scheduled-task",
        },
        {
            "type": "relationship",
            "relationship_type": "attributed-to",
            "source_ref": "campaign--solarwinds",
            "target_ref": "intrusion-set--apt29",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "campaign--2023-phishing",
            "target_ref": "attack-pattern--phishing",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "campaign--2023-phishing",
            "target_ref": "attack-pattern--phishing-link",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "campaign--2022-ransomware",
            "target_ref": "attack-pattern--phishing-attachment",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "campaign--2022-ransomware",
            "target_ref": "attack-pattern--cred-dump",
        },
        {
            "type": "relationship",
            "relationship_type": "uses",
            "source_ref": "campaign--2022-ransomware",
            "target_ref": "attack-pattern--remote-services",
        },
    ],
}


@pytest.fixture
def scenario_store() -> ATTACKDataStore:
    """Create a store with scenario test data."""
    store = ATTACKDataStore(quiet=True)
    store._parse_data(SCENARIO_STIX_DATA)
    return store


@pytest.fixture
def scenario_engine(scenario_store: ATTACKDataStore) -> ATTACKQueryEngine:
    """Create an engine with scenario test data."""
    return ATTACKQueryEngine(scenario_store)


@pytest.fixture
def scenario_parser(scenario_engine: ATTACKQueryEngine) -> NLQueryParser:
    """Create a parser with scenario test data."""
    return NLQueryParser(scenario_engine)


# =============================================================================
# USE CASE 1: THREAT ACTOR PROFILING
# =============================================================================


class TestThreatActorProfiling:
    """
    Use Case: Threat intelligence analysts profile APT groups by analyzing
    their technique usage, comparing groups, and finding similar actors.

    Real-world scenario: "We've been targeted by APT28. What techniques
    should we expect, and are there similar groups we should watch?"
    """

    def test_what_techniques_does_apt29_use(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What techniques does APT29 use?"""
        result = scenario_parser.parse_and_execute("techniques used by APT29")

        assert result["query_type"] == "techniques_by_groups"
        techniques = result["techniques"]

        # APT29 uses: Phishing, Phishing Link, Valid Accounts, Cred Dump, Scheduled Task
        assert len(techniques) == 5
        technique_ids = {t["id"] for t in techniques}
        assert "T1566" in technique_ids  # Phishing
        assert "T1078" in technique_ids  # Valid Accounts
        assert "T1003" in technique_ids  # Credential Dumping

    def test_compare_apt28_and_apt29_techniques(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Compare APT28 and APT29 techniques"""
        result = scenario_parser.parse_and_execute("compare APT28 and APT29")

        assert result["query_type"] == "compare_groups"

        # Both use Phishing, Valid Accounts, Credential Dumping
        shared_ids = {t["id"] for t in result["shared"]}
        assert "T1566" in shared_ids
        assert "T1078" in shared_ids
        assert "T1003" in shared_ids

        # APT28 unique: PowerShell, Phishing Attachment, Cmd Script
        unique_first_ids = {t["id"] for t in result["unique_to_first"]}
        assert "T1059.001" in unique_first_ids

        # APT29 unique: Phishing Link, Scheduled Task
        unique_second_ids = {t["id"] for t in result["unique_to_second"]}
        assert "T1566.002" in unique_second_ids
        assert "T1053" in unique_second_ids

        # Similarity score should be moderate (3 shared, several unique)
        assert 0.2 < result["jaccard_similarity"] < 0.7

    def test_which_threat_actors_use_phishing(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Which threat actors use T1566 (Phishing)?"""
        result = scenario_parser.parse_and_execute("groups using T1566")

        assert result["query_type"] == "groups_using_technique"
        groups = result["groups"]

        # APT28, APT29, and APT33 all use Phishing
        assert "APT28" in groups
        assert "APT29" in groups
        assert "APT33" in groups
        assert len(groups) == 3

    def test_find_groups_similar_to_apt28(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Find groups similar to APT28"""
        result = scenario_parser.parse_and_execute("groups similar to APT28")

        assert result["query_type"] == "similar_groups"

        # Should find APT29 as similar (shared techniques)
        group_names = [g["group"] for g in result["similar_groups"]]
        assert "APT29" in group_names

    def test_alias_resolution_fancy_bear(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Who is Fancy Bear?"""
        result = scenario_parser.parse_and_execute("who is Fancy Bear")

        assert result["query_type"] == "group_info"
        assert result["id"] == "G0007"  # APT28's ID
        assert result["name"] == "APT28"

    def test_techniques_used_by_multiple_groups_union(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Techniques used by APT28 or APT29 (union)"""
        result = scenario_parser.parse_and_execute("techniques used by APT28 or APT29")

        assert result["query_type"] == "techniques_by_groups"
        assert result["operation"] == "union"
        techniques = result["techniques"]

        # Union should include all techniques from both groups
        assert len(techniques) >= 7  # At least 7 unique techniques

    def test_techniques_used_by_multiple_groups_intersection(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Techniques used by APT28 and APT29 (intersection)"""
        result = scenario_parser.parse_and_execute("techniques used by APT28 and APT29")

        assert result["query_type"] == "techniques_by_groups"
        assert result["operation"] == "intersection"
        technique_ids = {t["id"] for t in result["techniques"]}

        # Intersection should only include shared techniques
        assert "T1566" in technique_ids  # Both use Phishing
        assert "T1078" in technique_ids  # Both use Valid Accounts
        assert "T1003" in technique_ids  # Both use Credential Dumping


# =============================================================================
# USE CASE 2: DETECTION COVERAGE GAP ANALYSIS
# =============================================================================


class TestDetectionCoverageGapAnalysis:
    """
    Use Case: Detection engineers map data sources to techniques to
    understand what they can detect with available telemetry.

    Real-world scenario: "We have Sysmon deployed. What techniques
    can we detect with process creation events?"
    """

    def test_list_available_data_sources(
        self, scenario_parser: NLQueryParser, scenario_store: ATTACKDataStore
    ):
        """Query: What data sources are available?"""
        result = scenario_parser.parse_and_execute("data sources")

        assert result["query_type"] == "list_data_sources"
        # Should have Process and Logon Session data sources
        assert len(scenario_store.data_sources) == 2

    def test_data_source_info_process(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Data source info for Process"""
        result = scenario_parser.parse_and_execute("data source info Process")

        assert result["query_type"] == "data_source_info"
        assert result["name"] == "Process"
        assert "Windows" in result["platforms"]
        assert "Host" in result["collection_layers"]

    def test_list_data_components(
        self, scenario_parser: NLQueryParser, scenario_store: ATTACKDataStore
    ):
        """Query: What data components are available?"""
        result = scenario_parser.parse_and_execute("data components")

        assert result["query_type"] == "list_data_components"
        assert len(scenario_store.data_components) == 2

    def test_data_component_info_with_log_sources(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Data component info showing log sources"""
        result = scenario_parser.parse_and_execute("data component info Process Creation")

        assert result["query_type"] == "data_component_info"
        assert result["name"] == "Process Creation"
        assert len(result["log_sources"]) == 2
        # Sysmon is a log source for process creation
        log_source_names = [ls["name"] for ls in result["log_sources"]]
        assert "Sysmon" in log_source_names


# =============================================================================
# USE CASE 3: SECURITY CONTROL MAPPING
# =============================================================================


class TestSecurityControlMapping:
    """
    Use Case: Security architects map mitigations to techniques to
    understand defensive coverage and prioritize security investments.

    Real-world scenario: "How do we protect against credential theft
    techniques? What mitigations should we implement?"
    """

    def test_mitigations_for_phishing(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What mitigations exist for T1566 (Phishing)?"""
        result = scenario_parser.parse_and_execute("mitigations for T1566")

        assert result["query_type"] == "mitigations_for_technique"
        mitigation_ids = {m["id"] for m in result["mitigations"]}

        # User Training mitigates Phishing
        assert "M1017" in mitigation_ids

    def test_mitigations_for_credential_dumping(
        self, scenario_parser: NLQueryParser
    ):
        """Query: How to mitigate T1003 (Credential Dumping)?"""
        result = scenario_parser.parse_and_execute("how to mitigate T1003")

        assert result["query_type"] == "mitigations_for_technique"
        mitigation_ids = {m["id"] for m in result["mitigations"]}

        # Privileged Account Management and Credential Protection mitigate cred dump
        assert "M1026" in mitigation_ids
        assert "M1043" in mitigation_ids

    def test_techniques_mitigated_by_mfa(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What techniques does MFA mitigate?"""
        result = scenario_parser.parse_and_execute("techniques mitigated by M1032")

        assert result["query_type"] == "techniques_mitigated_by"
        technique_ids = {t["id"] for t in result["techniques"]}

        # MFA mitigates Valid Accounts and Brute Force
        assert "T1078" in technique_ids
        assert "T1110" in technique_ids

    def test_mitigation_info(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Mitigation info for User Training"""
        result = scenario_parser.parse_and_execute("mitigation info M1017")

        assert result["query_type"] == "mitigation_info"
        assert result["name"] == "User Training"
        assert result["technique_count"] == 3  # Phishing + 2 sub-techniques


# =============================================================================
# USE CASE 4: RED TEAM EXERCISE PLANNING
# =============================================================================


class TestRedTeamExercisePlanning:
    """
    Use Case: Red team operators plan adversary emulation exercises
    by selecting techniques based on tactics and available tooling.

    Real-world scenario: "We're emulating APT28. What initial access
    techniques should we use, and what tools do they employ?"
    """

    def test_techniques_for_initial_access_tactic(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Techniques used by APT28 for Initial Access"""
        result = scenario_parser.parse_and_execute("techniques used by APT28 for initial-access")

        assert result["query_type"] == "techniques_by_groups"
        assert result["tactic_filter"] == "initial-access"
        technique_ids = {t["id"] for t in result["techniques"]}

        # APT28 uses Phishing and Valid Accounts for initial access
        assert "T1566" in technique_ids
        assert "T1078" in technique_ids

    def test_subtechniques_of_phishing(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What are the sub-techniques of T1566?"""
        result = scenario_parser.parse_and_execute("sub-techniques of T1566")

        assert result["query_type"] == "subtechniques_of"
        subtechnique_ids = {t["id"] for t in result["subtechniques"]}

        # Should have Attachment and Link sub-techniques
        assert "T1566.001" in subtechnique_ids
        assert "T1566.002" in subtechnique_ids

    def test_software_used_by_apt28(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What software does APT28 use?"""
        result = scenario_parser.parse_and_execute("software used by APT28")

        assert result["query_type"] == "software_by_group"
        software_ids = {s["id"] for s in result["software"]}

        # APT28 uses Mimikatz
        assert "S0002" in software_ids

    def test_techniques_for_cobalt_strike(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What techniques does Cobalt Strike implement?"""
        result = scenario_parser.parse_and_execute("techniques for Cobalt Strike")

        assert result["query_type"] == "techniques_by_software"
        technique_ids = {t["id"] for t in result["techniques"]}

        # Cobalt Strike implements Command and Scripting, PowerShell, Remote Services
        assert "T1059" in technique_ids
        assert "T1059.001" in technique_ids
        assert "T1021" in technique_ids

    def test_groups_using_cobalt_strike(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Which groups use Cobalt Strike?"""
        result = scenario_parser.parse_and_execute("groups using Cobalt Strike")

        assert result["query_type"] == "groups_using_software"
        groups = result["groups"]

        # APT29 and FIN7 use Cobalt Strike
        assert "APT29" in groups
        assert "FIN7" in groups

    def test_tactics_used_by_apt28(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What tactics does APT28 use?"""
        result = scenario_parser.parse_and_execute("tactics used by APT28")

        assert result["query_type"] == "tactics_by_groups"
        tactic_shortnames = {t["shortname"] for t in result["tactics"]}

        # APT28 uses Initial Access, Execution, Credential Access, Persistence
        assert "initial-access" in tactic_shortnames
        assert "execution" in tactic_shortnames
        assert "credential-access" in tactic_shortnames


# =============================================================================
# USE CASE 5: INCIDENT RESPONSE MAPPING
# =============================================================================


class TestIncidentResponseMapping:
    """
    Use Case: Incident responders map observed behaviors to ATT&CK
    and identify likely threat actors based on technique usage.

    Real-world scenario: "We observed credential dumping and lateral
    movement. Which groups use these techniques? Are there related campaigns?"
    """

    def test_groups_using_credential_dumping(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Which groups use T1003 (Credential Dumping)?"""
        result = scenario_parser.parse_and_execute("groups using T1003")

        assert result["query_type"] == "groups_using_technique"
        groups = result["groups"]

        # APT28 and APT29 use credential dumping
        assert "APT28" in groups
        assert "APT29" in groups

    def test_campaigns_by_apt29(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What campaigns are attributed to APT29?"""
        result = scenario_parser.parse_and_execute("campaigns by APT29")

        assert result["query_type"] == "campaigns_by_group"
        campaign_ids = {c["id"] for c in result["campaigns"]}

        # SolarWinds campaign is attributed to APT29
        assert "C0024" in campaign_ids

    def test_techniques_in_solarwinds_campaign(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What techniques were used in SolarWinds campaign?"""
        result = scenario_parser.parse_and_execute("techniques in C0024")

        assert result["query_type"] == "techniques_in_campaign"
        technique_ids = {t["id"] for t in result["techniques"]}

        # SolarWinds used Valid Accounts and Scheduled Task
        assert "T1078" in technique_ids
        assert "T1053" in technique_ids

    def test_campaigns_in_2023(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What campaigns were active in 2023?"""
        result = scenario_parser.parse_and_execute("campaigns in 2023")

        assert result["query_type"] == "campaigns_in_year"
        campaign_ids = {c["id"] for c in result["campaigns"]}

        # 2023 Credential Phishing campaign was active
        assert "C0030" in campaign_ids

    def test_techniques_used_in_2022(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What techniques were used in campaigns during 2022?"""
        result = scenario_parser.parse_and_execute("techniques used in 2022")

        assert result["query_type"] == "techniques_in_year"
        technique_ids = {t["id"] for t in result["techniques"]}

        # 2022 Ransomware campaign used Phishing Attachment, Cred Dump, Remote Services
        assert "T1566.001" in technique_ids
        assert "T1003" in technique_ids
        assert "T1021" in technique_ids

    def test_campaign_info_with_timeline(
        self, scenario_parser: NLQueryParser
    ):
        """Query: Campaign info showing timeline"""
        result = scenario_parser.parse_and_execute("campaign info C0024")

        assert result["query_type"] == "campaign_info"
        assert result["name"] == "SolarWinds Compromise"
        assert result["first_seen"] is not None
        assert result["last_seen"] is not None
        assert "APT29" in result["groups"]  # Attribution

    def test_techniques_not_used_by_apt28(
        self, scenario_parser: NLQueryParser
    ):
        """Query: What techniques does APT28 NOT use? (for gap analysis)"""
        result = scenario_parser.parse_and_execute("techniques NOT used by APT28")

        assert result["query_type"] == "techniques_not_used_by"
        technique_ids = {t["id"] for t in result["techniques"]}

        # APT28 doesn't use Brute Force, Scheduled Task, Remote Services
        assert "T1110" in technique_ids
        assert "T1053" in technique_ids
        assert "T1021" in technique_ids


# =============================================================================
# WORKFLOW INTEGRATION TESTS
# =============================================================================


class TestWorkflowIntegration:
    """
    Integration tests that chain multiple queries together,
    simulating real analyst workflows.
    """

    def test_workflow_investigate_threat_actor(
        self,
        scenario_parser: NLQueryParser,
        scenario_store: ATTACKDataStore,
    ):
        """
        Workflow: Investigate a threat actor end-to-end.

        1. Identify the group from an alias
        2. Get their techniques
        3. Find mitigations for their most common techniques
        4. Find similar groups to monitor
        """
        # Step 1: Identify group from alias
        alias_result = scenario_parser.parse_and_execute("who is Fancy Bear")
        group_id = alias_result["id"]
        group = scenario_store.get_group(group_id)
        assert group.name == "APT28"

        # Step 2: Get techniques
        tech_result = scenario_parser.parse_and_execute(f"techniques used by {group.name}")
        assert len(tech_result["techniques"]) >= 5

        # Step 3: Get mitigations for phishing (common technique)
        mit_result = scenario_parser.parse_and_execute("mitigations for T1566")
        mitigation_ids = {m["id"] for m in mit_result["mitigations"]}
        assert "M1017" in mitigation_ids  # User Training

        # Step 4: Find similar groups
        similar_result = scenario_parser.parse_and_execute(f"groups similar to {group.name}")
        similar_names = [g["group"] for g in similar_result["similar_groups"]]
        assert "APT29" in similar_names

    def test_workflow_detection_engineering(
        self,
        scenario_parser: NLQueryParser,
    ):
        """
        Workflow: Detection engineering coverage analysis.

        1. List data components available
        2. Check what a data component can detect
        3. Find techniques used by threat actors in our sector
        """
        # Step 1: List data components
        dc_result = scenario_parser.parse_and_execute("data components")
        assert dc_result["query_type"] == "list_data_components"

        # Step 2: Get data component info
        dc_info_result = scenario_parser.parse_and_execute("data component info Process Creation")
        assert dc_info_result["name"] == "Process Creation"

        # Step 3: Get techniques from relevant threat actors
        tech_result = scenario_parser.parse_and_execute("techniques used by APT28 or APT29")
        assert len(tech_result["techniques"]) >= 7

    def test_workflow_incident_response(
        self,
        scenario_parser: NLQueryParser,
    ):
        """
        Workflow: Incident response triage.

        1. Observed technique: credential dumping
        2. Find groups known to use this technique
        3. Get other techniques those groups use
        4. Check for related campaigns
        """
        # Step 1 & 2: Find groups using credential dumping
        groups_result = scenario_parser.parse_and_execute("groups using T1003")
        groups = groups_result["groups"]
        assert "APT28" in groups
        assert "APT29" in groups

        # Step 3: Get all techniques from those groups
        for group_name in groups:
            tech_result = scenario_parser.parse_and_execute(f"techniques used by {group_name}")
            assert len(tech_result["techniques"]) >= 3  # Each group uses multiple techniques

        # Step 4: Check APT29 campaigns (one of the groups)
        campaign_result = scenario_parser.parse_and_execute("campaigns by APT29")
        campaign_ids = {c["id"] for c in campaign_result["campaigns"]}
        assert "C0024" in campaign_ids  # SolarWinds
