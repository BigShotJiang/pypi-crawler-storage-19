# setup.py
from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

# 可选：读取 requirements.txt
try:
    with open("requirements.txt") as f:
        requirements = f.read().splitlines()
except FileNotFoundError:
    requirements = []

setup(
    name="hebill",
    version="1.0.0",
    author="He Bill",
    author_email="hebill@qq.com",
    description="Hebill Utilities",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/hebill/hebill",  # 项目主页
    packages=['hebill'],
    python_requires=">=3.12",
    install_requires=requirements,
)
