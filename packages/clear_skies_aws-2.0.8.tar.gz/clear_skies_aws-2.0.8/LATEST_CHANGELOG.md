## [2.0.8] - 2026-01-12

### Changed
- Update clear-skies

### Fixed
- Ssm command

