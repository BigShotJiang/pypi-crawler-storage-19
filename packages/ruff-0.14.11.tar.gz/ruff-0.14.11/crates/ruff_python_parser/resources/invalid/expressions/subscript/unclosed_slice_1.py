x[::

def foo():
    pass