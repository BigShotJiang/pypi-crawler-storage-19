"""Tests for materialize MachineStates."""
