"""Core AutoML components."""

