"""Model factory and definitions."""

