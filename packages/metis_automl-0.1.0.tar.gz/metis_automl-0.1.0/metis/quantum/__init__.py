"""Quantum-enhanced optimization components."""

