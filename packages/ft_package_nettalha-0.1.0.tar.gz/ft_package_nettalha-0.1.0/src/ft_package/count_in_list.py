def count_in_list(word_lists, serach_word):
    count = 0
    for word in word_lists:
        if word == serach_word:
            count = count + 1
    return count