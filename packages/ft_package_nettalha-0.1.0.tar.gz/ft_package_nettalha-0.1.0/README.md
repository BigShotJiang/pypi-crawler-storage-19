# ft_package-nettalha

A simple Python function to count occurrences of a word in a list.

## Installation

You can install this package using pip:

```bash
pip install ft_package-nettalha
```

## Usage

Import the function and use it as follows:
```python
from ft_package-nettalha import count_in_list

words = ['apple', 'banana', 'apple', 'orange', 'apple']
search_word = 'apple'
result = count_in_list(words, search_word)
print(result)  # Output: 3
```

## Author

Noureddine Ett

## License

This project is licensed under the terms of the MIT license.