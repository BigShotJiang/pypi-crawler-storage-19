"""Slicing infrastructure module."""
