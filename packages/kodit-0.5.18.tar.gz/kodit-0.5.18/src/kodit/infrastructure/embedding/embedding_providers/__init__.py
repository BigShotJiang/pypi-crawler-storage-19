"""Embedding providers module."""
