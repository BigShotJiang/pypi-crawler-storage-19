"""Snippet enrichment package."""
