"""Physical architecture enrichment package."""
