"""Tests for commit handlers."""
