"""Tests for application handlers."""
