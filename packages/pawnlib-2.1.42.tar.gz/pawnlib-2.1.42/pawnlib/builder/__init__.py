from .generator import AppGenerator
