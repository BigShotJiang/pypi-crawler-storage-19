from brilliance_admin import schema, sqlalchemy
from brilliance_admin.translations import TranslateText as _
from example.sections.models import Merchant


class MerchantAdmin(sqlalchemy.SQLAlchemyAdmin):
    model = Merchant
    title = _('merchants')
    icon = 'mdi-card-account-details-outline'

    ordering_fields = [
        'id',
        'user_id',
    ]
    search_fields = [
        'id',
        'title',
    ]

    table_schema = sqlalchemy.SQLAlchemyFieldsSchema(
        model=Merchant,
        readonly_fields=[
            'created_at',
        ],
        fields=[
            'id',
            'user_id',
            'title',
            'description',
            'created_at',
            'terminals',
        ],
        title=schema.StringField(multilined=True, required=True),
        description=schema.StringField(tinymce=True, required=True),
    )
    table_filters = sqlalchemy.SQLAlchemyFieldsSchema(
        model=Merchant,
        fields=[
            'id',
            'user_id',
            'created_at',
            'terminals',
        ],
        created_at=schema.DateTimeField(range=True),
    )
