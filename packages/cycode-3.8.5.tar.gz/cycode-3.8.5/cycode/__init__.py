__version__ = '3.8.5'  # DON'T TOUCH. Placeholder. Will be filled automatically on poetry build from Git Tag
