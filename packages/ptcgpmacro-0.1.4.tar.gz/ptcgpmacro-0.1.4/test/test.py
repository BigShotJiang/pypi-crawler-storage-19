import ptcgpmacro

# 라이브러리 명령어로 ptcgp.zip 생성
ptcgpmacro.build_ptcgp_zip("ptcgp.zip")