"""
Positional encoding modules for INL-LLM.

Contains:
- RotaryPositionalEmbedding: RoPE for modern attention
- PositionalEncoding: Classic sinusoidal positional encoding
"""

import torch
import torch.nn as nn
import math
from typing import Tuple


class RotaryPositionalEmbedding(nn.Module):
    """
    Rotary Position Embedding (RoPE)

    Encodes position in the rotation of query/key vectors.
    Better extrapolation than absolute positional encodings.
    Used in LLaMA, GPT-NeoX, etc.
    """
    def __init__(self, dim: int, max_seq_len: int = 4096, base: float = 10000.0):
        super().__init__()
        self.dim = dim
        self.max_seq_len = max_seq_len
        self.base = base

        # Precompute inverse frequencies
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer('inv_freq', inv_freq)

        # Precompute cos/sin for efficiency
        self._precompute_cos_sin(max_seq_len)

    def _precompute_cos_sin(self, seq_len: int):
        """Precompute cos and sin for all positions."""
        t = torch.arange(seq_len, device=self.inv_freq.device, dtype=self.inv_freq.dtype)
        freqs = torch.outer(t, self.inv_freq)  # [seq_len, dim/2]
        # Duplicate for pairs: [seq_len, dim]
        emb = torch.cat([freqs, freqs], dim=-1)
        self.register_buffer('cos_cached', emb.cos().unsqueeze(0).unsqueeze(0))  # [1, 1, seq_len, dim]
        self.register_buffer('sin_cached', emb.sin().unsqueeze(0).unsqueeze(0))  # [1, 1, seq_len, dim]

    def _rotate_half(self, x: torch.Tensor) -> torch.Tensor:
        """Rotate half of the dimensions."""
        x1 = x[..., :x.shape[-1] // 2]
        x2 = x[..., x.shape[-1] // 2:]
        return torch.cat([-x2, x1], dim=-1)

    def forward(self, q: torch.Tensor, k: torch.Tensor, start_pos: int = 0) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Apply rotary embeddings to query and key.

        Args:
            q: Query tensor [batch, num_heads, seq_len, head_dim]
            k: Key tensor [batch, num_heads, seq_len, head_dim]
            start_pos: Starting position (for KV cache)

        Returns:
            Rotated q, k tensors
        """
        seq_len = q.shape[2]

        # Extend cache if needed
        if start_pos + seq_len > self.cos_cached.shape[2]:
            self._precompute_cos_sin(start_pos + seq_len)

        cos = self.cos_cached[:, :, start_pos:start_pos + seq_len, :q.shape[-1]]
        sin = self.sin_cached[:, :, start_pos:start_pos + seq_len, :q.shape[-1]]

        # Apply rotation
        q_embed = (q * cos) + (self._rotate_half(q) * sin)
        k_embed = (k * cos) + (self._rotate_half(k) * sin)

        return q_embed, k_embed


class PositionalEncoding(nn.Module):
    """
    Classic sinusoidal positional encoding.

    Used as fallback or for specific architectures.
    """
    def __init__(self, d_model: int, max_len: int = 5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))

    def forward(self, x, start_pos: int = 0):
        """
        Apply positional encoding.

        Args:
            x: Input tensor [batch_size, seq_len, d_model]
            start_pos: Starting position for positional encoding (for KV cache)

        Returns:
            x with positional encoding added
        """
        seq_len = x.size(1)
        return x + self.pe[:, start_pos:start_pos + seq_len, :]
