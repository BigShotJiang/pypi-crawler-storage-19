"""
Attention modules for INL-LLM.

Contains:
- GroupedQueryAttention: GQA with RoPE, KV cache, and Flash Attention support
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
from typing import Optional, Tuple

from .positional import RotaryPositionalEmbedding
from .cache import INLCacheLayer

# Check if SDPA is available (PyTorch 2.0+) - for Flash Attention
HAS_SDPA = hasattr(F, "scaled_dot_product_attention")


class GroupedQueryAttention(nn.Module):
    """
    Grouped Query Attention (GQA) with RoPE, KV cache, and Flash Attention support.

    GQA reduces memory usage by using fewer KV heads than Q heads.
    - MHA: num_kv_heads = num_heads (full)
    - MQA: num_kv_heads = 1 (minimal)
    - GQA: 1 < num_kv_heads < num_heads (balanced)

    2024 Innovations:
    - Flash Attention via PyTorch SDPA (2-4x faster, O(n) memory)
    - Automatic fallback if SDPA not available

    Used in LLaMA 2, Mistral, etc.
    """

    def __init__(
        self,
        embed_dim: int,
        num_heads: int,
        num_kv_heads: Optional[int] = None,  # If None, defaults to num_heads (MHA)
        dropout: float = 0.0,
        max_seq_len: int = 4096,
        rope_base: float = 10000.0,
        use_flash_attention: bool = True,  # 2024: Use SDPA for Flash Attention
    ):
        super().__init__()

        if embed_dim % num_heads != 0:
            raise ValueError(f"embed_dim ({embed_dim}) must be divisible by num_heads ({num_heads})")

        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads if num_kv_heads is not None else num_heads
        self.head_dim = embed_dim // num_heads
        self.num_kv_groups = num_heads // self.num_kv_heads  # How many Q heads per KV head
        self.dropout = dropout

        # 2024: Flash Attention via SDPA (requires PyTorch 2.0+)
        self.use_flash_attention = use_flash_attention and HAS_SDPA

        # Separate Q, K, V projections (no bias, like LLaMA)
        self.q_proj = nn.Linear(embed_dim, num_heads * self.head_dim, bias=False)
        self.k_proj = nn.Linear(embed_dim, self.num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(embed_dim, self.num_kv_heads * self.head_dim, bias=False)
        self.out_proj = nn.Linear(embed_dim, embed_dim, bias=False)

        # RoPE
        self.rope = RotaryPositionalEmbedding(self.head_dim, max_seq_len, rope_base)

        self.attn_dropout = nn.Dropout(dropout)
        self.resid_dropout = nn.Dropout(dropout)

        # Initialize weights
        self._reset_parameters()

    def _reset_parameters(self):
        """Initialize parameters."""
        nn.init.xavier_uniform_(self.q_proj.weight)
        nn.init.xavier_uniform_(self.k_proj.weight)
        nn.init.xavier_uniform_(self.v_proj.weight)
        nn.init.xavier_uniform_(self.out_proj.weight)

    def _repeat_kv(self, x: torch.Tensor) -> torch.Tensor:
        """
        Repeat KV heads to match Q heads.

        Args:
            x: [batch, num_kv_heads, seq_len, head_dim]

        Returns:
            [batch, num_heads, seq_len, head_dim]
        """
        if self.num_kv_groups == 1:
            return x

        batch, num_kv_heads, seq_len, head_dim = x.shape
        # [B, num_kv_heads, 1, S, D] -> [B, num_kv_heads, num_kv_groups, S, D]
        x = x.unsqueeze(2).expand(batch, num_kv_heads, self.num_kv_groups, seq_len, head_dim)
        return x.reshape(batch, self.num_heads, seq_len, head_dim)

    def forward(
        self,
        x: torch.Tensor,
        attn_mask: Optional[torch.Tensor] = None,
        cache_layer: Optional[INLCacheLayer] = None,
        use_cache: bool = False,
        start_pos: int = 0
    ) -> Tuple[torch.Tensor, Optional[Tuple[torch.Tensor, torch.Tensor]]]:
        """
        Forward pass with GQA, RoPE, and optional KV caching.

        Args:
            x: Input tensor [batch_size, seq_len, embed_dim]
            attn_mask: Attention mask [seq_len, seq_len] or [tgt_len, src_len]
            cache_layer: Cache layer to update (if using cache)
            use_cache: Whether to use/update cache
            start_pos: Starting position for RoPE (for KV cache)

        Returns:
            attn_output: [batch_size, seq_len, embed_dim]
            new_cache: Updated (keys, values) if use_cache else None
        """
        batch_size, seq_len, _ = x.shape

        # Project Q, K, V separately
        q = self.q_proj(x)  # [B, S, num_heads * head_dim]
        k = self.k_proj(x)  # [B, S, num_kv_heads * head_dim]
        v = self.v_proj(x)  # [B, S, num_kv_heads * head_dim]

        # Reshape to [B, num_heads/num_kv_heads, S, head_dim]
        q = q.view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = k.view(batch_size, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = v.view(batch_size, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)

        # Apply RoPE to Q and K
        q, k = self.rope(q, k, start_pos=start_pos)

        # Handle cache
        if use_cache and cache_layer is not None:
            k, v = cache_layer.update_attention(k, v)

        # Repeat KV heads to match Q heads
        k = self._repeat_kv(k)  # [B, num_heads, src_len, head_dim]
        v = self._repeat_kv(v)  # [B, num_heads, src_len, head_dim]

        # 2024: Use Flash Attention (SDPA) if available - 2-4x faster, O(n) memory
        if self.use_flash_attention:
            # SDPA automatically selects best backend:
            # - Flash Attention (if available)
            # - Memory Efficient Attention (fallback)
            # - Standard Math Attention (fallback)
            dropout_p = self.dropout if self.training else 0.0

            # For SDPA, we need to handle the mask differently
            # is_causal=True uses optimized causal mask internally
            if attn_mask is None:
                # No mask provided - use causal mask
                attn_output = F.scaled_dot_product_attention(
                    q, k, v,
                    attn_mask=None,
                    dropout_p=dropout_p,
                    is_causal=True
                )
            else:
                # Custom mask provided - convert bool mask to float for SDPA
                # SDPA expects additive mask (0 = attend, -inf = mask)
                sdpa_mask = attn_mask.unsqueeze(0).unsqueeze(0)  # [1, 1, seq, seq]
                sdpa_mask = sdpa_mask.masked_fill(sdpa_mask, float('-inf'))
                sdpa_mask = sdpa_mask.masked_fill(~sdpa_mask.bool(), 0.0)

                attn_output = F.scaled_dot_product_attention(
                    q, k, v,
                    attn_mask=sdpa_mask,
                    dropout_p=dropout_p,
                    is_causal=False  # We provide our own mask
                )
        else:
            # Standard attention fallback (for PyTorch < 2.0)
            scale = 1.0 / math.sqrt(self.head_dim)
            attn_weights = torch.matmul(q, k.transpose(-2, -1)) * scale

            # Apply attention mask
            if attn_mask is not None:
                attn_mask = attn_mask.unsqueeze(0).unsqueeze(0)
                attn_weights = attn_weights.masked_fill(attn_mask, float('-inf'))

            attn_weights = F.softmax(attn_weights, dim=-1)
            attn_weights = self.attn_dropout(attn_weights)

            # Apply attention to values
            attn_output = torch.matmul(attn_weights, v)

        # Reshape and project
        attn_output = attn_output.transpose(1, 2).reshape(batch_size, seq_len, self.embed_dim)
        attn_output = self.out_proj(attn_output)
        attn_output = self.resid_dropout(attn_output)

        cache_output = (k, v) if use_cache else None
        return attn_output, cache_output


# Keep old class as alias for backward compatibility
INLCachedAttention = GroupedQueryAttention
