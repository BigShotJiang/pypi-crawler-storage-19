"""
ULTRA-Optimized Integrator Language Model (INL-LLM)

This file is kept for backward compatibility.
All classes are now imported from modular files:

- normalization.py: RMSNorm, SwiGLU
- positional.py: RotaryPositionalEmbedding, PositionalEncoding
- cache.py: INLCacheLayer, INLCache
- attention.py: GroupedQueryAttention, INLCachedAttention
- layers.py: UltraOptimizedINLBlock
- model.py: UltraOptimizedIntegratorLanguageModel, create_ultra_optimized_model

Author: Boris Peyriguere
"""

# Re-export everything from modular files for backward compatibility
from .normalization import RMSNorm, SwiGLU
from .positional import RotaryPositionalEmbedding, PositionalEncoding
from .cache import INLCacheLayer, INLCache
from .attention import GroupedQueryAttention, INLCachedAttention
from .layers import UltraOptimizedINLBlock
from .model import (
    UltraOptimizedIntegratorLanguageModel,
    create_ultra_optimized_model,
    HAS_SDPA,
    HAS_MOE
)

__all__ = [
    # Normalization
    'RMSNorm',
    'SwiGLU',
    # Positional
    'RotaryPositionalEmbedding',
    'PositionalEncoding',
    # Cache
    'INLCacheLayer',
    'INLCache',
    # Attention
    'GroupedQueryAttention',
    'INLCachedAttention',
    # Layers
    'UltraOptimizedINLBlock',
    # Model
    'UltraOptimizedIntegratorLanguageModel',
    'create_ultra_optimized_model',
    # Feature flags
    'HAS_SDPA',
    'HAS_MOE'
]


if __name__ == '__main__':
    # Test the refactored imports
    import torch

    print("\n" + "=" * 70)
    print("INL-LLM MODEL - Testing Refactored Imports")
    print("=" * 70 + "\n")

    # Create model
    model = create_ultra_optimized_model(size='small', vocab_size=50000)

    # Test forward
    batch_size = 2
    seq_len = 10
    input_ids = torch.randint(0, 50000, (batch_size, seq_len))

    print("Running forward pass...")
    logits, aux, _ = model(input_ids, return_aux=True)

    print(f"Input shape: {input_ids.shape}")
    print(f"Output shape: {logits.shape}")
    print(f"Aux layers: {len(aux)}")

    # Test generation
    print("\nTesting generation...")
    prompt = torch.randint(0, 50000, (1, 5))
    generated = model.generate(prompt, max_new_tokens=20, temperature=0.8)

    print(f"Prompt length: {prompt.shape[1]}")
    print(f"Generated length: {generated.shape[1]}")

    print("\n" + "=" * 70)
    print("REFACTORED INL-LLM WORKING PERFECTLY!")
    print("=" * 70 + "\n")
