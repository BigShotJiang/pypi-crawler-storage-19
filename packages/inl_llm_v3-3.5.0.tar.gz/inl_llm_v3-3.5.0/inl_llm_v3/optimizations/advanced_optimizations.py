"""
Advanced Optimizations for INL-LLM

Implements additional efficiency techniques:
1. Shared Controllers: Share control MLPs across layers (-15-20% params)
2. Sparse Harmonic Excitation: Only excite subset of dimensions (-10x compute)
3. Mixture of Integrators (MoI): Conditional computation like MoE
4. Hierarchical Equilibrium: Global + local offsets for μ

Author: Boris Peyriguère
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple, Dict, List
import math


class SharedController(nn.Module):
    """
    Shared controller MLP across multiple INL layers.

    Instead of each layer having its own controller (α, β, g, v_cand),
    we use ONE shared controller + small layer-specific modulation.

    Benefit: 15-20% parameter reduction on controller networks
    """

    def __init__(
        self,
        hidden_dim: int,
        output_dim: int,
        num_layers: int,
        hidden_controller: int = 64
    ):
        """
        Args:
            hidden_dim: Context dimension
            output_dim: State dimension
            num_layers: Number of layers sharing this controller
            hidden_controller: Hidden size for controller MLP
        """
        super().__init__()

        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.num_layers = num_layers

        # Single shared controller (used by all layers)
        self.controller_h = nn.Linear(hidden_dim, hidden_controller)
        self.controller_x = nn.Linear(output_dim, hidden_controller)
        self.controller_v = nn.Linear(output_dim, hidden_controller)
        self.controller_mlp = nn.Sequential(
            nn.ReLU(),
            nn.Linear(hidden_controller, 4 * output_dim)
        )

        # Layer-specific modulation (tiny parameters)
        # Each layer gets 4 scalar multipliers (α, β, g, v_cand)
        self.layer_scalers = nn.Parameter(torch.ones(num_layers, 4))
        self.layer_biases = nn.Parameter(torch.zeros(num_layers, 4))

        # Initialize
        self._init_weights()

    def _init_weights(self):
        """Initialize controller weights."""
        with torch.no_grad():
            nn.init.xavier_uniform_(self.controller_h.weight)
            nn.init.xavier_uniform_(self.controller_x.weight)
            nn.init.xavier_uniform_(self.controller_v.weight)
            self.controller_h.bias.zero_()
            self.controller_x.bias.zero_()
            self.controller_v.bias.zero_()
            self.controller_mlp[-1].weight.normal_(0.0, 0.01)

    def forward(
        self,
        h: torch.Tensor,
        x: torch.Tensor,
        v: torch.Tensor,
        layer_idx: int
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Compute controller parameters for specific layer.

        Args:
            h: Context [batch, hidden_dim]
            x: State [batch, output_dim]
            v: Velocity [batch, output_dim]
            layer_idx: Which layer is requesting control

        Returns:
            alpha, beta, gate, v_cand (all [batch, output_dim])
        """
        # Shared computation
        controller_hidden = self.controller_h(h) + self.controller_x(x) + self.controller_v(v)
        controller_output = self.controller_mlp(controller_hidden)

        # Split into components
        alpha_base, beta_base, gate_base, v_cand_base = torch.split(
            controller_output, self.output_dim, dim=1
        )

        # Layer-specific modulation
        scaler = self.layer_scalers[layer_idx]  # [4]
        bias = self.layer_biases[layer_idx]      # [4]

        alpha = torch.sigmoid(alpha_base * scaler[0] + bias[0])
        beta = F.softplus(beta_base * scaler[1] + bias[1])
        gate = torch.sigmoid(gate_base * scaler[2] + bias[2])
        v_cand = v_cand_base * scaler[3] + bias[3]

        return alpha, beta, gate, v_cand

    def num_parameters(self) -> int:
        """Count parameters."""
        shared = sum(p.numel() for p in [
            self.controller_h.weight, self.controller_h.bias,
            self.controller_x.weight, self.controller_x.bias,
            self.controller_v.weight, self.controller_v.bias
        ]) + sum(p.numel() for p in self.controller_mlp.parameters())

        layer_specific = self.layer_scalers.numel() + self.layer_biases.numel()

        return shared + layer_specific


class SparseHarmonicINL(nn.Module):
    """
    INL with Sparse Harmonic Excitation.

    Only applies harmonic noise to a subset of dimensions (e.g., 10%).
    Reduces compute by 10x while maintaining exploration.
    """

    def __init__(
        self,
        hidden_dim: int,
        output_dim: int,
        sparsity: float = 0.1,
        target_value: float = 5.0,
        dt: float = 0.1,
        excitation_amplitude: float = 0.03
    ):
        """
        Args:
            hidden_dim: Context dimension
            output_dim: State dimension
            sparsity: Fraction of dimensions to excite (0.1 = 10%)
            target_value: Initial equilibrium
            dt: Time step
            excitation_amplitude: Amplitude of excitation
        """
        super().__init__()

        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.sparsity = sparsity
        self.dt = dt

        # Learnable μ
        self.mu = nn.Parameter(torch.full((output_dim,), target_value))

        # Excitation parameters (only for sparse subset)
        self.num_excited = max(1, int(output_dim * sparsity))

        # Fixed sparse indices (deterministic)
        indices = torch.linspace(0, output_dim - 1, self.num_excited).long()
        self.register_buffer('excited_indices', indices)

        # Learnable excitation params (only for excited dims)
        self.register_buffer('excitation_amplitude', torch.tensor(excitation_amplitude))
        self.excitation_gamma = nn.Parameter(torch.ones(self.num_excited))
        self.excitation_phi = nn.Parameter(torch.zeros(self.num_excited))

        # Simple controller (for demo - would use shared in practice)
        self.controller = nn.Sequential(
            nn.Linear(hidden_dim + 2 * output_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 3 * output_dim)  # α, β, g
        )

    def forward(
        self,
        h: torch.Tensor,
        x: torch.Tensor,
        v: torch.Tensor,
        step: int = 0
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
        """Forward with sparse excitation."""
        batch_size = x.shape[0]

        # Compute controllers
        ctx = torch.cat([h, x, v], dim=-1)
        controller_out = self.controller(ctx)
        alpha_raw, beta_raw, gate_raw = torch.split(controller_out, self.output_dim, dim=1)

        alpha = torch.sigmoid(alpha_raw)
        beta = F.softplus(beta_raw)
        gate = torch.sigmoid(gate_raw)

        # Velocity update
        error = x - self.mu
        v_next = alpha * v - beta * error

        # Sparse harmonic excitation (only on subset of dims)
        if self.excitation_amplitude.item() > 0 and self.training:
            t = float(step)
            # Compute noise only for excited dimensions
            noise_sparse = self.excitation_amplitude * torch.sin(
                self.excitation_gamma * t + self.excitation_phi
            )  # [num_excited]

            # Apply to specific indices (sparse operation)
            v_next[:, self.excited_indices] += noise_sparse.unsqueeze(0)

        # State update
        x_next = x + self.dt * gate * v_next

        aux = {'alpha': alpha, 'beta': beta, 'gate': gate}
        return x_next, v_next, aux

    def init_state(self, batch_size: int, device: torch.device):
        """Initialize state."""
        x0 = self.mu.unsqueeze(0).expand(batch_size, -1).to(device)
        v0 = torch.zeros(batch_size, self.output_dim, device=device)
        return x0, v0


class MixtureOfIntegrators(nn.Module):
    """
    Mixture of Integrators (MoI) - like Mixture of Experts for INL.

    Routes each token to top-k integrator experts.
    Enables sparse, conditional computation.

    Features:
    - Top-k sparse routing
    - Shared expert (always active, handles common patterns)
    - Load balancing loss (prevents expert collapse)
    - Layer embedding (experts specialize by layer position)
    - Usage statistics tracking

    Inspired by DeepSeek-MoE: shared expert learns common patterns,
    routed experts specialize on specific token types.

    Benefit: Can scale capacity without scaling compute linearly
    """

    def __init__(
        self,
        hidden_dim: int,
        output_dim: int,
        num_experts: int = 8,
        top_k: int = 2,
        target_value: float = 5.0,
        dt: float = 0.1,
        load_balance_weight: float = 0.01,
        num_layers: int = 24,
        layer_idx: int = 0,
        use_shared_expert: bool = True
    ):
        """
        Args:
            hidden_dim: Context dimension
            output_dim: State dimension
            num_experts: Number of routed INL experts
            top_k: Use top-k routed experts per token
            target_value: Initial equilibrium
            dt: Time step
            load_balance_weight: Weight for load balancing aux loss
            num_layers: Total number of layers (for layer embedding)
            layer_idx: This layer's index (for layer embedding)
            use_shared_expert: Whether to use a shared expert (always active)
        """
        super().__init__()

        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.num_experts = num_experts
        self.top_k = top_k
        self.dt = dt
        self.load_balance_weight = load_balance_weight
        self.layer_idx = layer_idx
        self.use_shared_expert = use_shared_expert

        # Shared equilibrium (all experts share same μ)
        self.mu = nn.Parameter(torch.full((output_dim,), target_value))

        # Layer embedding: experts know where they are (early/mid/late)
        self.layer_embedding = nn.Embedding(num_layers, 32)

        # Router: decides which routed expert(s) to use
        # Input: context + layer_embedding (experts can specialize by layer)
        self.router = nn.Linear(hidden_dim + 32, num_experts)

        # Shared expert (always active - handles common patterns like grammar)
        if use_shared_expert:
            self.shared_expert = nn.Sequential(
                nn.Linear(hidden_dim + 2 * output_dim, 64),
                nn.ReLU(),
                nn.Linear(64, 3 * output_dim)  # α, β, g
            )
            # Learnable weight for shared expert contribution
            self.shared_weight = nn.Parameter(torch.tensor(0.5))

        # Routed expert-specific controllers (stacked for efficiency + checkpoint compatibility)
        expert_input_dim = hidden_dim + 2 * output_dim
        expert_hidden = 64
        expert_output = 3 * output_dim

        # Stacked weights: [num_experts, in_dim, out_dim]
        self.expert_w1 = nn.Parameter(torch.randn(num_experts, expert_input_dim, expert_hidden) * 0.02)
        self.expert_b1 = nn.Parameter(torch.zeros(num_experts, expert_hidden))
        self.expert_w2 = nn.Parameter(torch.randn(num_experts, expert_hidden, expert_output) * 0.02)
        self.expert_b2 = nn.Parameter(torch.zeros(num_experts, expert_output))

        # Usage statistics (for monitoring)
        self.register_buffer('expert_counts', torch.zeros(num_experts))
        self.register_buffer('total_tokens', torch.zeros(1))

    def _compute_expert_dynamics(
        self,
        ctrl_out: torch.Tensor,
        x: torch.Tensor,
        v: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """Compute INL dynamics from controller output."""
        alpha_raw, beta_raw, gate_raw = torch.split(ctrl_out, self.output_dim, dim=1)

        alpha = torch.sigmoid(alpha_raw)
        beta = F.softplus(beta_raw)
        gate = torch.sigmoid(gate_raw)

        # INL dynamics
        error = x - self.mu
        v_next = alpha * v - beta * error
        x_next = x + self.dt * gate * v_next

        return x_next, v_next

    def forward(
        self,
        h: torch.Tensor,
        x: torch.Tensor,
        v: torch.Tensor,
        step: int = 0
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
        """
        Forward with expert routing + shared expert.

        OPTIMIZED: Batched expert computation - groups tokens by expert
        for efficient parallel processing instead of per-token loops.

        Args:
            h: Context [batch, hidden_dim]
            x: State [batch, output_dim]
            v: Velocity [batch, output_dim]
            step: Integration step

        Returns:
            x_next, v_next, aux_info
        """
        batch_size = x.shape[0]
        device = h.device

        # Context for controllers
        ctx = torch.cat([h, x, v], dim=-1)  # [batch, hidden_dim + 2*output_dim]

        # === SHARED EXPERT (always active) ===
        if self.use_shared_expert:
            shared_ctrl = self.shared_expert(ctx)
            x_shared, v_shared = self._compute_expert_dynamics(shared_ctrl, x, v)
            shared_w = torch.sigmoid(self.shared_weight)  # [0, 1]
        else:
            x_shared = torch.zeros_like(x)
            v_shared = torch.zeros_like(v)
            shared_w = 0.0

        # === ROUTED EXPERTS (BATCHED) ===
        # Get layer embedding (experts know which layer they're in)
        layer_idx_tensor = torch.tensor([self.layer_idx], device=device)
        layer_emb = self.layer_embedding(layer_idx_tensor)  # [1, 32]
        layer_emb = layer_emb.expand(batch_size, -1)  # [batch, 32]

        # Route: which experts to use? (context + layer info)
        router_input = torch.cat([h, layer_emb], dim=-1)  # [batch, hidden_dim + 32]
        router_logits = self.router(router_input)  # [batch, num_experts]
        router_probs = F.softmax(router_logits, dim=-1)

        # Select top-k experts
        top_k_probs, top_k_indices = torch.topk(router_probs, self.top_k, dim=-1)
        top_k_probs = top_k_probs / top_k_probs.sum(dim=-1, keepdim=True)  # Renormalize

        # === BATCHED EXPERT COMPUTATION ===
        # Instead of looping per-token, group tokens by expert and process in batch
        x_routed = torch.zeros_like(x)
        v_routed = torch.zeros_like(v)

        # Flatten top-k selections: each token appears top_k times
        # flat_indices[i] = which expert for this (token, k) pair
        flat_indices = top_k_indices.view(-1)  # [batch * top_k]
        flat_weights = top_k_probs.view(-1, 1)  # [batch * top_k, 1]

        # Expand ctx, x, v to match flat structure
        ctx_expanded = ctx.unsqueeze(1).expand(-1, self.top_k, -1).reshape(-1, ctx.size(-1))  # [batch*top_k, ctx_dim]
        x_expanded = x.unsqueeze(1).expand(-1, self.top_k, -1).reshape(-1, self.output_dim)  # [batch*top_k, output_dim]
        v_expanded = v.unsqueeze(1).expand(-1, self.top_k, -1).reshape(-1, self.output_dim)  # [batch*top_k, output_dim]

        # Process each expert in batch (one forward per expert, not per token!)
        x_results = torch.zeros_like(x_expanded)
        v_results = torch.zeros_like(v_expanded)

        for exp_id in range(self.num_experts):
            # Find all tokens routed to this expert
            mask = (flat_indices == exp_id)
            if not mask.any():
                continue

            # Batch forward for this expert
            ctx_batch = ctx_expanded[mask]  # [num_tokens_for_expert, ctx_dim]
            x_batch = x_expanded[mask]
            v_batch = v_expanded[mask]

            # Use stacked weights for efficiency
            h1 = torch.mm(ctx_batch, self.expert_w1[exp_id]) + self.expert_b1[exp_id]
            h1 = F.relu(h1)
            ctrl_out = torch.mm(h1, self.expert_w2[exp_id]) + self.expert_b2[exp_id]
            x_out, v_out = self._compute_expert_dynamics(ctrl_out, x_batch, v_batch)

            # Store results
            x_results[mask] = x_out
            v_results[mask] = v_out

        # Apply weights and aggregate back to [batch, output_dim]
        x_weighted = x_results * flat_weights  # [batch*top_k, output_dim]
        v_weighted = v_results * flat_weights

        # Reshape and sum over top_k dimension
        x_routed = x_weighted.view(batch_size, self.top_k, -1).sum(dim=1)  # [batch, output_dim]
        v_routed = v_weighted.view(batch_size, self.top_k, -1).sum(dim=1)

        # === COMBINE: shared + routed ===
        if self.use_shared_expert:
            x_next = shared_w * x_shared + (1 - shared_w) * x_routed
            v_next = shared_w * v_shared + (1 - shared_w) * v_routed
        else:
            x_next = x_routed
            v_next = v_routed

        # Update usage statistics (batched)
        if self.training:
            # Count expert usage efficiently
            for exp_id in range(self.num_experts):
                count = (flat_indices == exp_id).sum().item()
                self.expert_counts[exp_id] += count
            self.total_tokens += batch_size

        # Compute load balancing loss (training only)
        load_balance_loss = None
        if self.training and self.load_balance_weight > 0:
            load_balance_loss = self._compute_load_balance_loss(router_probs)

        aux = {
            'router_probs': router_probs,
            'top_k_experts': top_k_indices,
            'expert_weights': top_k_probs,
            'shared_weight': shared_w if self.use_shared_expert else None,
            'load_balance_loss': load_balance_loss,
            'expert_usage': self.get_expert_usage()
        }

        return x_next, v_next, aux

    def _compute_load_balance_loss(self, router_probs: torch.Tensor) -> torch.Tensor:
        """
        Load balancing loss to prevent expert collapse.

        Encourages uniform expert usage across batch.
        """
        # Average probability per expert across batch
        expert_probs = router_probs.mean(dim=0)  # [num_experts]

        # Squared sum penalty (encourages uniform distribution)
        load_balance_loss = self.num_experts * (expert_probs ** 2).sum()

        return self.load_balance_weight * load_balance_loss

    def get_expert_usage(self) -> torch.Tensor:
        """Get normalized expert usage statistics."""
        if self.total_tokens > 0:
            return self.expert_counts / (self.total_tokens * self.top_k)
        return torch.ones(self.num_experts, device=self.expert_counts.device) / self.num_experts

    def reset_stats(self):
        """Reset usage statistics."""
        self.expert_counts.zero_()
        self.total_tokens.zero_()

    def init_state(self, batch_size: int, device: torch.device):
        """Initialize state."""
        x0 = self.mu.unsqueeze(0).expand(batch_size, -1).to(device)
        v0 = torch.zeros(batch_size, self.output_dim, device=device)
        return x0, v0


class HierarchicalEquilibriumINL(nn.Module):
    """
    Hierarchical Equilibrium Learning.

    Instead of learning μ per dimension independently:
    - Learn global μ_global (1 parameter)
    - Learn local offsets per group (d_model // group_size parameters)

    Benefit: Fewer parameters, better generalization
    """

    def __init__(
        self,
        hidden_dim: int,
        output_dim: int,
        group_size: int = 64,
        target_value: float = 5.0,
        dt: float = 0.1
    ):
        """
        Args:
            hidden_dim: Context dimension
            output_dim: State dimension
            group_size: Size of each group sharing offset
            target_value: Initial global equilibrium
            dt: Time step
        """
        super().__init__()

        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.group_size = group_size
        self.dt = dt

        # Global equilibrium (shared by all)
        self.mu_global = nn.Parameter(torch.tensor(target_value))

        # Local offsets per group
        num_groups = (output_dim + group_size - 1) // group_size
        self.mu_local_offsets = nn.Parameter(torch.zeros(num_groups))

        # Simple controller
        self.controller = nn.Sequential(
            nn.Linear(hidden_dim + 2 * output_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 3 * output_dim)
        )

    def get_mu(self) -> torch.Tensor:
        """
        Compute full μ from hierarchical representation.

        Returns:
            mu: [output_dim]
        """
        # Repeat each group offset
        mu_local = self.mu_local_offsets.repeat_interleave(self.group_size)

        # Trim to exact size
        mu_local = mu_local[:self.output_dim]

        # Combine global + local
        mu = self.mu_global + mu_local
        return mu

    def forward(
        self,
        h: torch.Tensor,
        x: torch.Tensor,
        v: torch.Tensor,
        step: int = 0
    ) -> Tuple[torch.Tensor, torch.Tensor, Dict]:
        """Forward with hierarchical equilibrium."""
        mu = self.get_mu()

        # Controller
        ctx = torch.cat([h, x, v], dim=-1)
        ctrl_out = self.controller(ctx)
        alpha_raw, beta_raw, gate_raw = torch.split(ctrl_out, self.output_dim, dim=1)

        alpha = torch.sigmoid(alpha_raw)
        beta = F.softplus(beta_raw)
        gate = torch.sigmoid(gate_raw)

        # Dynamics
        error = x - mu
        v_next = alpha * v - beta * error
        x_next = x + self.dt * gate * v_next

        aux = {'mu': mu, 'mu_global': self.mu_global, 'mu_offsets': self.mu_local_offsets}
        return x_next, v_next, aux

    def init_state(self, batch_size: int, device: torch.device):
        """Initialize state."""
        mu = self.get_mu()
        x0 = mu.unsqueeze(0).expand(batch_size, -1).to(device)
        v0 = torch.zeros(batch_size, self.output_dim, device=device)
        return x0, v0

    def num_mu_parameters(self) -> int:
        """Count parameters used for μ."""
        return 1 + self.mu_local_offsets.numel()


def compute_advanced_optimization_gains(
    d_model: int = 2048,
    num_layers: int = 24,
    hidden_controller: int = 64
):
    """
    Compute parameter savings from advanced optimizations.

    Args:
        d_model: Model dimension
        num_layers: Number of layers
        hidden_controller: Controller hidden size
    """
    print("=" * 70)
    print("ADVANCED OPTIMIZATION ANALYSIS")
    print("=" * 70)

    # 1. Shared Controllers
    print("\n1. SHARED CONTROLLERS")
    print("-" * 70)

    # Standard: each layer has own controller
    params_per_controller = (
        d_model * hidden_controller +  # h projection
        d_model * hidden_controller +  # x projection
        d_model * hidden_controller +  # v projection
        hidden_controller * (4 * d_model)  # output
    )
    standard_total = params_per_controller * num_layers

    # Shared: one controller + layer modulation
    shared_base = params_per_controller
    layer_modulation = num_layers * 8  # 4 scalers + 4 biases per layer
    shared_total = shared_base + layer_modulation

    reduction_pct = (1 - shared_total / standard_total) * 100

    print(f"  Standard (independent): {standard_total:,} params")
    print(f"  Shared + modulation:    {shared_total:,} params")
    print(f"  💾 REDUCTION: {reduction_pct:.1f}%")

    # 2. Sparse Harmonic
    print("\n2. SPARSE HARMONIC EXCITATION")
    print("-" * 70)
    sparsity = 0.1
    compute_reduction = 1 / sparsity
    print(f"  Sparsity: {sparsity*100:.0f}% of dimensions excited")
    print(f"  ⚡ COMPUTE REDUCTION: {compute_reduction:.0f}x less operations")

    # 3. Hierarchical μ
    print("\n3. HIERARCHICAL EQUILIBRIUM")
    print("-" * 70)
    group_size = 64
    num_groups = (d_model + group_size - 1) // group_size

    standard_mu = d_model
    hierarchical_mu = 1 + num_groups
    mu_reduction = (1 - hierarchical_mu / standard_mu) * 100

    print(f"  Standard μ:       {standard_mu:,} params")
    print(f"  Hierarchical μ:   {hierarchical_mu:,} params (global + {num_groups} groups)")
    print(f"  💾 REDUCTION: {mu_reduction:.1f}%")

    # 4. Combined impact
    print("\n4. COMBINED IMPACT")
    print("-" * 70)
    print(f"  Controller params saved:  {standard_total - shared_total:,}")
    print(f"  Harmonic compute:         {compute_reduction:.0f}x faster")
    print(f"  Equilibrium params saved: {standard_mu - hierarchical_mu}")
    print(f"  Overall controller reduction: {reduction_pct:.1f}%")

    print("\n" + "=" * 70)


if __name__ == '__main__':
    print("\n")

    # Test 1: Shared Controllers
    print("=" * 70)
    print("TEST 1: Shared Controllers")
    print("=" * 70)

    shared_ctrl = SharedController(
        hidden_dim=512,
        output_dim=512,
        num_layers=12
    )

    h = torch.randn(2, 512)
    x = torch.randn(2, 512)
    v = torch.randn(2, 512)

    for layer_idx in range(3):
        alpha, beta, gate, v_cand = shared_ctrl(h, x, v, layer_idx)
        print(f"Layer {layer_idx}: alpha={alpha.mean().item():.3f}, beta={beta.mean().item():.3f}")

    print(f"✅ Shared controller parameters: {shared_ctrl.num_parameters():,}")

    # Test 2: Sparse Harmonic
    print("\n" + "=" * 70)
    print("TEST 2: Sparse Harmonic Excitation")
    print("=" * 70)

    sparse_inl = SparseHarmonicINL(
        hidden_dim=512,
        output_dim=512,
        sparsity=0.1
    )

    x0, v0 = sparse_inl.init_state(2, 'cpu')
    x_next, v_next, aux = sparse_inl(h, x0, v0, step=0)

    print(f"✅ Sparse excitation: {sparse_inl.num_excited}/{sparse_inl.output_dim} dims excited")
    print(f"   Sparsity: {sparse_inl.sparsity*100:.0f}%")

    # Test 3: Mixture of Integrators
    print("\n" + "=" * 70)
    print("TEST 3: Mixture of Integrators")
    print("=" * 70)

    moi = MixtureOfIntegrators(
        hidden_dim=512,
        output_dim=512,
        num_experts=8,
        top_k=2
    )

    x0, v0 = moi.init_state(2, 'cpu')
    x_next, v_next, aux = moi(h, x0, v0, step=0)

    print(f"✅ MoI: {moi.num_experts} experts, top-{moi.top_k} routing")
    print(f"   Expert distribution: {aux['top_k_experts']}")

    # Test 4: Hierarchical Equilibrium
    print("\n" + "=" * 70)
    print("TEST 4: Hierarchical Equilibrium")
    print("=" * 70)

    hier_inl = HierarchicalEquilibriumINL(
        hidden_dim=512,
        output_dim=512,
        group_size=64
    )

    x0, v0 = hier_inl.init_state(2, 'cpu')
    x_next, v_next, aux = hier_inl(h, x0, v0)

    print(f"✅ Hierarchical μ: {hier_inl.num_mu_parameters()} params (vs 512 standard)")
    print(f"   Global μ: {aux['mu_global'].item():.3f}")
    print(f"   Local offsets: {aux['mu_offsets'][:3].tolist()}")

    # Analysis
    print("\n")
    compute_advanced_optimization_gains(
        d_model=2048,
        num_layers=24,
        hidden_controller=64
    )
