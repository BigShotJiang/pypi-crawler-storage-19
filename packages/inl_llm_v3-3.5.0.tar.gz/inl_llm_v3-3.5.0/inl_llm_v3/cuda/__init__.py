"""
INL-LLM CUDA/Triton Kernels

Optimized GPU kernels for INL dynamics using Triton.
Provides 2-5x speedup on forward pass by fusing operations.

Fused kernels:
- INL dynamics (5 ops -> 1 kernel)
- MoE with CGGR (5-6x speedup)
- SwiGLU activation
- RMSNorm
- Robotics Control Loop (sense -> process -> actuate)

Usage:
    from inl_llm_v3.cuda import fused_inl_dynamics, FusedMoEINL, fused_swiglu
    from inl_llm_v3.cuda import RoboticsINLLayer, fused_inl_residual

Requirements:
    pip install triton
"""

from .triton_kernels import (
    fused_inl_dynamics,
    fused_inl_dynamics_backward,
    fused_inl_dynamics_autograd,
    fused_swiglu,
    fused_rmsnorm,
    # Robotics Control Loop Pattern
    fused_inl_residual,
    RoboticsINLLayer,
    HAS_TRITON
)

from .fused_moe import (
    FusedMoEINL,
    fused_expert_forward
)

__all__ = [
    # INL dynamics
    'fused_inl_dynamics',
    'fused_inl_dynamics_backward',
    'fused_inl_dynamics_autograd',
    # Activations
    'fused_swiglu',
    'fused_rmsnorm',
    # MoE
    'FusedMoEINL',
    'fused_expert_forward',
    # Robotics Control Loop
    'fused_inl_residual',
    'RoboticsINLLayer',
    # Flags
    'HAS_TRITON'
]
