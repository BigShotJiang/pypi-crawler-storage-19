#!/usr/bin/env python3
"""
INL-LLM CUDA Benchmark

Tests performance of Triton kernels vs PyTorch baseline.
Run on H200 to measure actual speedup.

Usage:
    python -m inl_llm_v3.cuda.benchmark

Author: Boris Peyriguere
"""

import torch
import time
import argparse
from typing import Tuple

# Check CUDA availability
if not torch.cuda.is_available():
    print("CUDA not available. Exiting.")
    exit(1)

device = torch.device('cuda')

# Import our modules
from .triton_kernels import (
    fused_inl_dynamics,
    fused_inl_dynamics_autograd,
    HAS_TRITON
)
from .fused_moe import FusedMoEINL


def pytorch_inl_dynamics(x, v, mu, alpha, beta, gate, dt=0.1):
    """Baseline PyTorch implementation."""
    error = x - mu
    v_next = alpha * v - beta * error
    x_next = x + dt * gate * v_next
    return x_next, v_next


def benchmark_inl_dynamics(
    batch_sizes=[256, 512, 1024, 2048, 4096],
    dims=[512, 1024, 2048, 4096],
    n_warmup=20,
    n_iter=100
):
    """
    Benchmark INL dynamics: Triton vs PyTorch.
    """
    print("\n" + "="*70)
    print("INL DYNAMICS BENCHMARK")
    print("="*70)

    if not HAS_TRITON:
        print("Triton not available - only showing PyTorch baseline")

    results = []

    for batch_size in batch_sizes:
        for dim in dims:
            # Create test tensors
            x = torch.randn(batch_size, dim, device=device, dtype=torch.float32)
            v = torch.randn(batch_size, dim, device=device, dtype=torch.float32)
            mu = torch.randn(dim, device=device, dtype=torch.float32)
            alpha = torch.sigmoid(torch.randn(batch_size, dim, device=device))
            beta = torch.nn.functional.softplus(torch.randn(batch_size, dim, device=device))
            gate = torch.sigmoid(torch.randn(batch_size, dim, device=device))

            # Warmup
            for _ in range(n_warmup):
                _ = pytorch_inl_dynamics(x, v, mu, alpha, beta, gate)
                if HAS_TRITON:
                    _ = fused_inl_dynamics(x, v, mu, alpha, beta, gate)
            torch.cuda.synchronize()

            # Benchmark PyTorch
            torch.cuda.synchronize()
            start = time.perf_counter()
            for _ in range(n_iter):
                x_pt, v_pt = pytorch_inl_dynamics(x, v, mu, alpha, beta, gate)
            torch.cuda.synchronize()
            pytorch_time = (time.perf_counter() - start) / n_iter * 1000

            # Benchmark Triton
            if HAS_TRITON:
                torch.cuda.synchronize()
                start = time.perf_counter()
                for _ in range(n_iter):
                    x_tr, v_tr = fused_inl_dynamics(x, v, mu, alpha, beta, gate)
                torch.cuda.synchronize()
                triton_time = (time.perf_counter() - start) / n_iter * 1000
                speedup = pytorch_time / triton_time

                # Verify correctness
                max_diff_x = (x_pt - x_tr).abs().max().item()
                max_diff_v = (v_pt - v_tr).abs().max().item()
            else:
                triton_time = 0
                speedup = 0
                max_diff_x = 0
                max_diff_v = 0

            results.append({
                'batch': batch_size,
                'dim': dim,
                'pytorch_ms': pytorch_time,
                'triton_ms': triton_time,
                'speedup': speedup,
                'diff_x': max_diff_x,
                'diff_v': max_diff_v
            })

            print(f"batch={batch_size:4d}, dim={dim:4d}: "
                  f"PyTorch={pytorch_time:.3f}ms, "
                  f"Triton={triton_time:.3f}ms, "
                  f"speedup={speedup:.2f}x, "
                  f"max_diff={max(max_diff_x, max_diff_v):.2e}")

    return results


def benchmark_moe(
    batch_sizes=[256, 512, 1024],
    hidden_dim=2048,
    num_experts_list=[4, 8, 16],
    top_k_list=[1, 2],
    n_warmup=20,
    n_iter=100
):
    """
    Benchmark MoE: Fused vs Original.
    """
    print("\n" + "="*70)
    print("MIXTURE OF INTEGRATORS (MoE) BENCHMARK")
    print("="*70)

    # Import original for comparison
    try:
        from ..optimizations.advanced_optimizations import MixtureOfIntegrators
        has_original = True
    except ImportError:
        has_original = False
        print("Original MixtureOfIntegrators not found, showing fused only")

    results = []

    for batch_size in batch_sizes:
        for num_experts in num_experts_list:
            for top_k in top_k_list:
                if top_k > num_experts:
                    continue

                # Create modules
                fused = FusedMoEINL(
                    hidden_dim=hidden_dim,
                    output_dim=hidden_dim,
                    num_experts=num_experts,
                    top_k=top_k
                ).to(device).eval()

                if has_original:
                    original = MixtureOfIntegrators(
                        hidden_dim=hidden_dim,
                        output_dim=hidden_dim,
                        num_experts=num_experts,
                        top_k=top_k
                    ).to(device).eval()

                # Create inputs
                h = torch.randn(batch_size, hidden_dim, device=device)
                x = torch.randn(batch_size, hidden_dim, device=device)
                v = torch.randn(batch_size, hidden_dim, device=device)

                # Warmup
                with torch.no_grad():
                    for _ in range(n_warmup):
                        _ = fused(h, x, v)
                        if has_original:
                            _ = original(h, x, v)
                torch.cuda.synchronize()

                # Benchmark fused
                with torch.no_grad():
                    torch.cuda.synchronize()
                    start = time.perf_counter()
                    for _ in range(n_iter):
                        x_fused, v_fused, _ = fused(h, x, v)
                    torch.cuda.synchronize()
                    fused_time = (time.perf_counter() - start) / n_iter * 1000

                # Benchmark original
                if has_original:
                    with torch.no_grad():
                        torch.cuda.synchronize()
                        start = time.perf_counter()
                        for _ in range(n_iter):
                            x_orig, v_orig, _ = original(h, x, v)
                        torch.cuda.synchronize()
                        original_time = (time.perf_counter() - start) / n_iter * 1000
                    speedup = original_time / fused_time
                else:
                    original_time = 0
                    speedup = 0

                results.append({
                    'batch': batch_size,
                    'experts': num_experts,
                    'top_k': top_k,
                    'fused_ms': fused_time,
                    'original_ms': original_time,
                    'speedup': speedup
                })

                print(f"batch={batch_size:4d}, experts={num_experts:2d}, top_k={top_k}: "
                      f"Fused={fused_time:.3f}ms, "
                      f"Original={original_time:.3f}ms, "
                      f"speedup={speedup:.2f}x")

    return results


def benchmark_training_step(
    batch_size=256,
    seq_len=2048,
    hidden_dim=2048,
    num_layers=24,
    n_warmup=5,
    n_iter=20
):
    """
    Benchmark a full training forward+backward pass.
    """
    print("\n" + "="*70)
    print("FULL TRAINING STEP BENCHMARK")
    print("="*70)

    # Create a simple model with MoE layers
    class TestModel(torch.nn.Module):
        def __init__(self, use_fused=True):
            super().__init__()
            self.layers = torch.nn.ModuleList([
                FusedMoEINL(
                    hidden_dim=hidden_dim,
                    output_dim=hidden_dim,
                    num_experts=4,
                    top_k=1,
                    num_layers=num_layers,
                    layer_idx=i
                ) if use_fused else None
                for i in range(num_layers)
            ])
            self.fc = torch.nn.Linear(hidden_dim, hidden_dim)

        def forward(self, x):
            batch_size, seq_len, dim = x.shape
            x_flat = x.view(-1, dim)
            v = torch.zeros_like(x_flat)

            for layer in self.layers:
                x_flat, v, _ = layer(x_flat, x_flat, v)

            x = x_flat.view(batch_size, seq_len, dim)
            return self.fc(x).mean()

    model = TestModel(use_fused=True).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)

    # Create input
    x = torch.randn(batch_size, seq_len, hidden_dim, device=device)

    # Warmup
    for _ in range(n_warmup):
        optimizer.zero_grad()
        loss = model(x)
        loss.backward()
        optimizer.step()
    torch.cuda.synchronize()

    # Benchmark
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(n_iter):
        optimizer.zero_grad()
        loss = model(x)
        loss.backward()
        optimizer.step()
    torch.cuda.synchronize()
    total_time = (time.perf_counter() - start) / n_iter * 1000

    tokens_per_step = batch_size * seq_len
    tokens_per_sec = tokens_per_step / (total_time / 1000)

    print(f"\nConfiguration:")
    print(f"  Batch size: {batch_size}")
    print(f"  Sequence length: {seq_len}")
    print(f"  Hidden dim: {hidden_dim}")
    print(f"  Num layers: {num_layers}")
    print(f"\nResults:")
    print(f"  Time per step: {total_time:.2f} ms")
    print(f"  Tokens per step: {tokens_per_step:,}")
    print(f"  Throughput: {tokens_per_sec:,.0f} tok/s")

    # Memory usage
    memory_allocated = torch.cuda.memory_allocated() / 1e9
    memory_reserved = torch.cuda.memory_reserved() / 1e9
    print(f"\nMemory:")
    print(f"  Allocated: {memory_allocated:.2f} GB")
    print(f"  Reserved: {memory_reserved:.2f} GB")

    return {
        'time_ms': total_time,
        'tokens_per_sec': tokens_per_sec,
        'memory_gb': memory_allocated
    }


def print_gpu_info():
    """Print GPU information."""
    print("\n" + "="*70)
    print("GPU INFORMATION")
    print("="*70)

    props = torch.cuda.get_device_properties(0)
    print(f"Device: {props.name}")
    print(f"Compute capability: {props.major}.{props.minor}")
    print(f"Total memory: {props.total_memory / 1e9:.1f} GB")
    print(f"SM count: {props.multi_processor_count}")

    if HAS_TRITON:
        import triton
        print(f"Triton version: {triton.__version__}")
    else:
        print("Triton: NOT INSTALLED")


def main():
    parser = argparse.ArgumentParser(description='INL-LLM CUDA Benchmark')
    parser.add_argument('--all', action='store_true', help='Run all benchmarks')
    parser.add_argument('--dynamics', action='store_true', help='Benchmark INL dynamics')
    parser.add_argument('--moe', action='store_true', help='Benchmark MoE')
    parser.add_argument('--training', action='store_true', help='Benchmark training step')
    parser.add_argument('--quick', action='store_true', help='Quick benchmark with fewer iterations')

    args = parser.parse_args()

    # Default to all if nothing specified
    if not (args.dynamics or args.moe or args.training):
        args.all = True

    n_iter = 20 if args.quick else 100
    n_warmup = 5 if args.quick else 20

    print_gpu_info()

    if args.all or args.dynamics:
        benchmark_inl_dynamics(
            batch_sizes=[512, 1024, 2048] if args.quick else [256, 512, 1024, 2048, 4096],
            dims=[1024, 2048] if args.quick else [512, 1024, 2048, 4096],
            n_warmup=n_warmup,
            n_iter=n_iter
        )

    if args.all or args.moe:
        benchmark_moe(
            batch_sizes=[256, 512] if args.quick else [256, 512, 1024],
            num_experts_list=[4, 8] if args.quick else [4, 8, 16],
            n_warmup=n_warmup,
            n_iter=n_iter
        )

    if args.all or args.training:
        benchmark_training_step(
            batch_size=128 if args.quick else 256,
            num_layers=12 if args.quick else 24,
            n_warmup=3 if args.quick else 5,
            n_iter=10 if args.quick else 20
        )

    print("\n" + "="*70)
    print("BENCHMARK COMPLETE")
    print("="*70)


if __name__ == "__main__":
    main()
