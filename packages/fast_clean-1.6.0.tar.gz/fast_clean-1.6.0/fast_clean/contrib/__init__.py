"""
Package containing applications.
"""
