"""Built-in tools for Promethian agents.

These tools are always available regardless of what's in the knowledge base.
"""

from __future__ import annotations

from promethian.tools.browser import (
    BrowserTool,
    BrowserResult,
    get_browser,
    close_browser,
)

from promethian.tools.bash import (
    BashTool,
    BashResult,
    get_bash,
    reset_bash,
)

from promethian.tools.web_search import (
    APISearchTool,
    DDGSearchTool,
    WebSearchResult,
    SearchResult,
    get_web_search,
    reset_web_search,
)

from promethian.tools.web_fetch import (
    WebFetchTool,
    FetchResult,
    get_web_fetch,
    reset_web_fetch,
)

__all__ = [
    # Browser tools
    "BrowserTool",
    "BrowserResult",
    "get_browser",
    "close_browser",
    # Bash tools
    "BashTool",
    "BashResult",
    "get_bash",
    "reset_bash",
    # Web search tools
    "APISearchTool",
    "DDGSearchTool",
    "WebSearchResult",
    "SearchResult",
    "get_web_search",
    "reset_web_search",
    # Web fetch tools
    "WebFetchTool",
    "FetchResult",
    "get_web_fetch",
    "reset_web_fetch",
]
