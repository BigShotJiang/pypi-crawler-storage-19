from src.es_query_gen.builder import QueryBuilder
from src.es_query_gen.parser import ESResponseParser
from src.es_query_gen.connection import connect_es, search

config = {
    "size": 10,
    "searchFilters": {
        "equals": [
            {
                "field": "age",
                "value": "35"
            }
        ],
        "rangeFilters": [
            {
                "field": "dob",
                "rangeType": "date",
                "dateFormat": "%m/%d/%Y",
                "gte": {
                    "month": 2,
                    "years": -60
                },
                "lt": {
                    "month": 9,
                    "day": 10,
                    "years": -20
                }
            }
        ]
    },
    "sortList": [
        {
            "field": "dob",
            "order": "asc"
        }
    ],
    "returnFields": ["name", "dob", "phone"],
    "aggs": [
        {
            "name": "address_bucket",
            "field": "address.keyword",
            "size": 100,
            "order": "asc"
        },
        {
            "name": "dob_bucket",
            "field": "dob",
            "size": 100,
            "order": "asc"
        },
        {
            "name": "name_bucket",
            "field": "name.keyword",
            "size": 100,
            "order": "desc"
        }
    ]
}

return_query = QueryBuilder().build(config)

print(return_query)


es_client = connect_es(host='localhost', username='elastic', password='e6JUk1MB', request_timeout=50, connections_per_node=50)

response = search(index='pd_test', query=return_query)

ESResponseParser_instance = ESResponseParser(query_config=config)
response = ESResponseParser_instance.parse_data(response)

print(response)