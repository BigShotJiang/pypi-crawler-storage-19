from elasticsearch import Elasticsearch, helpers
import json
from src.es_query_gen.connection import ESClientSingleton, connect_es

# 1. Initialize the client
# Replace with your ES endpoint and credentials
client = connect_es(host='localhost', username='elastic', password='e6JUk1MB', request_timeout=10)
    

def index_json_data(index_name, data):
    """
    Uploads a list of dictionaries to a specific ES index.
    """
    # Check connection
    if not client.ping():
        print("Could not connect to Elasticsearch!")
        return

    # Create the index if it doesn't exist (optional)
    if not client.indices.exists(index=index_name):
        schema = {
            "settings": {
                "analysis": {
                    "normalizer": {
                        "lowercase_normalizer": {
                            "type": "custom",
                            "filter": ["lowercase"]
                        }
                    }
                }
            },
            "mappings": {
                "properties": {
                    "name": {
                        "type": "text",
                        "fields": {
                            "keyword": {"type": "keyword", "normalizer": "lowercase_normalizer"}
                        }
                    },
                    "dob": {
                        "type": "date",
                        "format": "MM/dd/yyyy"
                    },
                    "age": {"type": "integer"},
                    "address": {
                        "type": "text",
                        "fields": {
                            "keyword": {"type": "keyword", "normalizer": "lowercase_normalizer"}
                        }
                    },
                    "phone": {"type": "keyword", "normalizer": "lowercase_normalizer"}
                }
            }
        }
        client.indices.create(index=index_name, body=schema)
        print(f"Created index: {index_name}")

    # Prepare the actions for the Bulk API (more efficient than single indexing)
    actions = [
        {
            "_index": index_name,
            "_source": record
        }
        for record in data
    ]

    # Execute bulk upload
    success, errors = helpers.bulk(client, actions)
    
    print(f"Successfully indexed {success} documents.")
    if errors:
        print(f"Errors encountered: {errors}")
    
    client.close()

# Example Usage
if __name__ == "__main__":
    # Your JSON data (can be loaded from a file using json.load())
    sample_data = [
        {
            "name": "Alice Smith",
            "dob": "09/10/1990",
            "age": 35,
            "address": "123 Maple St, NY",
            "phone": "555-0101"
        },
        {
            "name": "Alice Smith",
            "dob": "09/10/1992",
            "age": 35,
            "address": "123 Maple St, NY",
            "phone": "555-0101"
        },
        {
            "name": "Sam Smith",
            "dob": "09/10/1992",
            "age": 35,
            "address": "123 Maple St, NY",
            "phone": "555-0101"
        },
        {
            "name": "John Miller",
            "dob": "05/11/1990",
            "age": 35,
            "address": "404 Walnut Dr, OH",
            "phone": "555-0707"
        },
        {
            "name": "Charlie Brown",
            "dob": "01/15/1992",
            "age": 34,
            "address": "789 Pine Rd, TX",
            "phone": "555-0103"
        },
        {
            "name": "Lucy Van Pelt",
            "dob": "01/11/1990",
            "age": 35,
            "address": "404 Walnut Dr, OH",
            "phone": "555-0707"
        },
         {
            "name": "Stone Pelt",
            "dob": "01/11/1990",
            "age": 35,
            "address": "404 Walnut Dr, OH",
            "phone": "555-0707"
        },
        {
            "name": "Bob Johnson",
            "dob": "02/11/1990",
            "age": 35,
            "address": "404 Walnut Dr, OH",
            "phone": "555-0707"
        },
        {
            "name": "Diana Prince",
            "dob": "03/30/1988",
            "age": 37,
            "address": "101 Cedar Ln, WA",
            "phone": "555-0104"
        },
        {
            "name": "Ethan Hunt",
            "dob": "07/04/1995",
            "age": 30,
            "address": "202 Birch Blvd, FL",
            "phone": "555-0105"
        },
        {
            "name": "Fiona Gallagher",
            "dob": "12/12/1991",
            "age": 34,
            "address": "303 Elm St, IL",
            "phone": "555-0106"
        },
        {
            "name": "Hannah Abbott",
            "dob": "02/28/1998",
            "age": 27,
            "address": "505 Cherry Ct, MI",
            "phone": "555-0108"
        },
        {
            "name": "Ian Wright",
            "dob": "06/10/1993",
            "age": 32,
            "address": "606 Spruce Way, GA",
            "phone": "555-0109"
        },
        {
            "name": "Jane Doe",
            "dob": "11/05/1887",
            "age": 38,
            "address": "707 Ash Dr, AZ",
            "phone": "555-0110"
        },
        {
            "name": "Kevin Hart",
            "dob": "04/14/1979",
            "age": 46,
            "address": "808 Poplar Pl, NV",
            "phone": "555-0111"
        },
        {
            "name": "Laura Palmer",
            "dob": "09/25/1994",
            "age": 31,
            "address": "909 Willow Cir, OR",
            "phone": "555-0112"
        },
        {
            "name": "Michael Scott",
            "dob": "03/15/1965",
            "age": 60,
            "address": "1725 Slough Ave, PA",
            "phone": "555-0113"
        },
        {
            "name": "Nancy Drew",
            "dob": "01/01/2000",
            "age": 26,
            "address": "111 Mystery Ln, CT",
            "phone": "555-0114"
        },
        {
            "name": "Oscar Martinez",
            "dob": "12/31/1982",
            "age": 43,
            "address": "222 Accounting Way, PA",
            "phone": "555-0115"
        },
        {
            "name": "Pam Beesly",
            "dob": "03/25/1984",
            "age": 41,
            "address": "333 Art St, NY",
            "phone": "555-0116"
        },
        {
            "name": "Quentin Tarantino",
            "dob": "03/27/1963",
            "age": 62,
            "address": "444 Movie Blvd, CA",
            "phone": "555-0117"
        },
        {
            "name": "Riley Reid",
            "dob": "05/18/1996",
            "age": 29,
            "address": "555 Sunset Strip, NV",
            "phone": "555-0118"
        },
        {
            "name": "Steve Rogers",
            "dob": "07/04/1918",
            "age": 107,
            "address": "666 Brooklyn Heights, NY",
            "phone": "555-0119"
        }
    ]

    index_json_data("pd_test", sample_data)