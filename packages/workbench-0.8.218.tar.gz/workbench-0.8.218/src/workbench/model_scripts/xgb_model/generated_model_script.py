# XGBoost Model Template for Workbench
#
# This template handles both classification and regression models with:
# - K-fold cross-validation ensemble training (or single train/val split)
# - Out-of-fold predictions for validation metrics
# - Uncertainty quantification for regression models
# - Sample weights support
# - Categorical feature handling
# - Compressed feature decompression
#
# NOTE: Imports are structured to minimize serverless endpoint startup time.
# Heavy imports (sklearn, awswrangler) are deferred to training time.

import json
import os

import joblib
import numpy as np
import pandas as pd
import xgboost as xgb

from model_script_utils import (
    convert_categorical_types,
    decompress_features,
    expand_proba_column,
    input_fn,
    match_features_case_insensitive,
    output_fn,
)
from uq_harness import (
    compute_confidence,
    load_uq_models,
    predict_intervals,
)

# =============================================================================
# Default Hyperparameters
# =============================================================================
DEFAULT_HYPERPARAMETERS = {
    # Training parameters
    "n_folds": 5,  # Number of CV folds (1 = single train/val split)
    # Core tree parameters
    "n_estimators": 300,
    "max_depth": 7,
    "learning_rate": 0.05,
    # Sampling parameters (less aggressive - ensemble provides regularization)
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    # Regularization (lighter - ensemble averaging reduces overfitting)
    "min_child_weight": 3,
    "gamma": 0.1,
    "reg_alpha": 0.1,
    "reg_lambda": 1.0,
    # Random seed
    "seed": 42,
}

# Workbench-specific parameters (not passed to XGBoost)
WORKBENCH_PARAMS = {"n_folds"}

# Regression-only parameters (filtered out for classifiers)
REGRESSION_ONLY_PARAMS = {"objective"}

# Template parameters (filled in by Workbench)
TEMPLATE_PARAMS = {
    "model_type": "uq_regressor",
    "target": "mppb",
    "features": ['fingerprint'],
    "id_column": "molecule_name",
    "compressed_features": ['fingerprint'],
    "model_metrics_s3_path": "s3://sandbox-sageworks-artifacts/models/mppb-reg-fp/training",
    "hyperparameters": {},
}


# =============================================================================
# Model Loading (for SageMaker inference)
# =============================================================================
def model_fn(model_dir: str) -> dict:
    """Load XGBoost ensemble from the specified directory."""
    # Load ensemble metadata
    metadata_path = os.path.join(model_dir, "ensemble_metadata.json")
    if os.path.exists(metadata_path):
        with open(metadata_path) as f:
            metadata = json.load(f)
        n_ensemble = metadata["n_ensemble"]
    else:
        n_ensemble = 1  # Legacy single model

    # Load ensemble models
    ensemble_models = []
    for i in range(n_ensemble):
        model_path = os.path.join(model_dir, f"xgb_model_{i}.joblib")
        if not os.path.exists(model_path):
            model_path = os.path.join(model_dir, "xgb_model.joblib")  # Legacy fallback
        ensemble_models.append(joblib.load(model_path))

    print(f"Loaded {len(ensemble_models)} model(s)")

    # Load label encoder (classifier only)
    label_encoder = None
    encoder_path = os.path.join(model_dir, "label_encoder.joblib")
    if os.path.exists(encoder_path):
        label_encoder = joblib.load(encoder_path)

    # Load category mappings
    category_mappings = {}
    category_path = os.path.join(model_dir, "category_mappings.json")
    if os.path.exists(category_path):
        with open(category_path) as f:
            category_mappings = json.load(f)

    # Load UQ models (regression only)
    uq_models, uq_metadata = None, None
    uq_path = os.path.join(model_dir, "uq_metadata.json")
    if os.path.exists(uq_path):
        uq_models, uq_metadata = load_uq_models(model_dir)

    return {
        "ensemble_models": ensemble_models,
        "n_ensemble": n_ensemble,
        "label_encoder": label_encoder,
        "category_mappings": category_mappings,
        "uq_models": uq_models,
        "uq_metadata": uq_metadata,
    }


# =============================================================================
# Inference (for SageMaker inference)
# =============================================================================
def predict_fn(df: pd.DataFrame, model_dict: dict) -> pd.DataFrame:
    """Make predictions with XGBoost ensemble."""
    model_dir = os.environ.get("SM_MODEL_DIR", "/opt/ml/model")
    with open(os.path.join(model_dir, "feature_columns.json")) as f:
        features = json.load(f)
    print(f"Model Features: {features}")

    # Extract model components
    ensemble_models = model_dict["ensemble_models"]
    label_encoder = model_dict.get("label_encoder")
    category_mappings = model_dict.get("category_mappings", {})
    uq_models = model_dict.get("uq_models")
    uq_metadata = model_dict.get("uq_metadata")
    compressed_features = TEMPLATE_PARAMS["compressed_features"]

    # Prepare features
    matched_df = match_features_case_insensitive(df, features)
    matched_df, _ = convert_categorical_types(matched_df, features, category_mappings)

    if compressed_features:
        print("Decompressing features for prediction...")
        matched_df, features = decompress_features(matched_df, features, compressed_features)

    X = matched_df[features]

    # Collect ensemble predictions
    all_preds = [m.predict(X) for m in ensemble_models]
    ensemble_preds = np.stack(all_preds, axis=0)

    if label_encoder is not None:
        # Classification: average probabilities, then argmax
        all_probs = [m.predict_proba(X) for m in ensemble_models]
        avg_probs = np.mean(np.stack(all_probs, axis=0), axis=0)
        class_preds = np.argmax(avg_probs, axis=1)

        df["prediction"] = label_encoder.inverse_transform(class_preds)
        df["pred_proba"] = [p.tolist() for p in avg_probs]
        df = expand_proba_column(df, label_encoder.classes_)
    else:
        # Regression: average predictions
        df["prediction"] = np.mean(ensemble_preds, axis=0)
        df["prediction_std"] = np.std(ensemble_preds, axis=0)

        # Add UQ intervals if available
        if uq_models and uq_metadata:
            df = predict_intervals(df, X, uq_models, uq_metadata)
            df = compute_confidence(df, uq_metadata["median_interval_width"], "q_10", "q_90")

    print(f"Inference complete: {len(df)} predictions, {len(ensemble_models)} ensemble members")
    return df


# =============================================================================
# Training
# =============================================================================
if __name__ == "__main__":
    # -------------------------------------------------------------------------
    # Training-only imports (deferred to reduce serverless startup time)
    # -------------------------------------------------------------------------
    import argparse

    import awswrangler as wr
    from sklearn.model_selection import KFold, StratifiedKFold, train_test_split
    from sklearn.preprocessing import LabelEncoder

    from model_script_utils import (
        check_dataframe,
        compute_classification_metrics,
        compute_regression_metrics,
        print_classification_metrics,
        print_confusion_matrix,
        print_regression_metrics,
    )
    from uq_harness import (
        save_uq_models,
        train_uq_models,
    )

    # -------------------------------------------------------------------------
    # Setup: Parse arguments and load data
    # -------------------------------------------------------------------------
    parser = argparse.ArgumentParser()
    parser.add_argument("--model-dir", type=str, default=os.environ.get("SM_MODEL_DIR", "/opt/ml/model"))
    parser.add_argument("--train", type=str, default=os.environ.get("SM_CHANNEL_TRAIN", "/opt/ml/input/data/train"))
    parser.add_argument("--output-data-dir", type=str, default=os.environ.get("SM_OUTPUT_DATA_DIR", "/opt/ml/output/data"))
    args = parser.parse_args()

    # Extract template parameters
    target = TEMPLATE_PARAMS["target"]
    features = TEMPLATE_PARAMS["features"]
    orig_features = features.copy()
    id_column = TEMPLATE_PARAMS["id_column"]
    compressed_features = TEMPLATE_PARAMS["compressed_features"]
    model_type = TEMPLATE_PARAMS["model_type"]
    model_metrics_s3_path = TEMPLATE_PARAMS["model_metrics_s3_path"]
    hyperparameters = {**DEFAULT_HYPERPARAMETERS, **(TEMPLATE_PARAMS["hyperparameters"] or {})}

    # Load training data
    training_files = [os.path.join(args.train, f) for f in os.listdir(args.train) if f.endswith(".csv")]
    print(f"Training Files: {training_files}")
    all_df = pd.concat([pd.read_csv(f, engine="python") for f in training_files])
    check_dataframe(all_df, "training_df")

    print(f"Target: {target}")
    print(f"Features: {features}")
    print(f"Hyperparameters: {hyperparameters}")

    # -------------------------------------------------------------------------
    # Preprocessing: Categorical features and decompression
    # -------------------------------------------------------------------------
    all_df, category_mappings = convert_categorical_types(all_df, features)

    if compressed_features:
        print(f"Decompressing features: {compressed_features}")
        all_df, features = decompress_features(all_df, features, compressed_features)

    # -------------------------------------------------------------------------
    # Classification setup
    # -------------------------------------------------------------------------
    label_encoder = None
    if model_type == "classifier":
        label_encoder = LabelEncoder()
        all_df[target] = label_encoder.fit_transform(all_df[target])
        print(f"Class labels: {label_encoder.classes_.tolist()}")

    # -------------------------------------------------------------------------
    # Cross-validation setup
    # -------------------------------------------------------------------------
    n_folds = hyperparameters["n_folds"]
    xgb_params = {k: v for k, v in hyperparameters.items() if k not in WORKBENCH_PARAMS}

    # Map 'seed' to 'random_state' for XGBoost
    if "seed" in xgb_params:
        xgb_params["random_state"] = xgb_params.pop("seed")

    # Handle objective: filter regression-only params for classifiers, set default for regressors
    if model_type == "classifier":
        xgb_params = {k: v for k, v in xgb_params.items() if k not in REGRESSION_ONLY_PARAMS}
    else:
        # Default to MAE (reg:absoluteerror) for regression if not specified
        xgb_params.setdefault("objective", "reg:absoluteerror")

    print(f"XGBoost params: {xgb_params}")

    if n_folds == 1:
        # Single train/val split
        if "training" in all_df.columns:
            print("Using 'training' column for train/val split")
            train_idx = np.where(all_df["training"])[0]
            val_idx = np.where(~all_df["training"])[0]
        else:
            print("WARNING: No 'training' column found, using random 80/20 split")
            indices = np.arange(len(all_df))
            train_idx, val_idx = train_test_split(indices, test_size=0.2, random_state=42)
        folds = [(train_idx, val_idx)]
    else:
        # K-fold cross-validation
        if model_type == "classifier":
            kfold = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
            folds = list(kfold.split(all_df, all_df[target]))
        else:
            kfold = KFold(n_splits=n_folds, shuffle=True, random_state=42)
            folds = list(kfold.split(all_df))

    print(f"Training {'single model' if n_folds == 1 else f'{n_folds}-fold ensemble'}...")

    # -------------------------------------------------------------------------
    # Training loop
    # -------------------------------------------------------------------------
    # Initialize out-of-fold storage
    oof_predictions = np.full(len(all_df), np.nan, dtype=np.float64)
    if model_type == "classifier":
        num_classes = len(label_encoder.classes_)
        oof_proba = np.full((len(all_df), num_classes), np.nan, dtype=np.float64)
    else:
        oof_proba = None

    # Check for sample weights
    has_sample_weights = "sample_weight" in all_df.columns
    if has_sample_weights:
        sw = all_df["sample_weight"]
        print(f"Using sample weights: min={sw.min():.2f}, max={sw.max():.2f}, mean={sw.mean():.2f}")

    # Train ensemble
    ensemble_models = []
    for fold_idx, (train_idx, val_idx) in enumerate(folds):
        print(f"\n{'='*50}")
        print(f"Fold {fold_idx + 1}/{len(folds)} - Train: {len(train_idx)}, Val: {len(val_idx)}")
        print(f"{'='*50}")

        # Prepare fold data
        X_train = all_df.iloc[train_idx][features]
        y_train = all_df.iloc[train_idx][target]
        X_val = all_df.iloc[val_idx][features]
        sample_weights = all_df.iloc[train_idx]["sample_weight"] if has_sample_weights else None

        # Create model with fold-specific random state for diversity
        fold_params = {**xgb_params, "random_state": xgb_params.get("random_state", 42) + fold_idx}
        if model_type == "classifier":
            model = xgb.XGBClassifier(enable_categorical=True, **fold_params)
        else:
            model = xgb.XGBRegressor(enable_categorical=True, **fold_params)

        # Train
        model.fit(X_train, y_train, sample_weight=sample_weights)
        ensemble_models.append(model)

        # Out-of-fold predictions
        oof_predictions[val_idx] = model.predict(X_val)
        if model_type == "classifier":
            oof_proba[val_idx] = model.predict_proba(X_val)

    print(f"\nTraining complete! Trained {len(ensemble_models)} model(s).")

    # -------------------------------------------------------------------------
    # Prepare validation results
    # -------------------------------------------------------------------------
    if n_folds == 1:
        # Single fold: only validation rows
        val_mask = ~np.isnan(oof_predictions)
        df_val = all_df[val_mask].copy()
        predictions = oof_predictions[val_mask]
        if oof_proba is not None:
            oof_proba = oof_proba[val_mask]
    else:
        # K-fold: all rows have out-of-fold predictions
        df_val = all_df.copy()
        predictions = oof_predictions

    # Decode labels for classification
    if model_type == "classifier":
        df_val[target] = label_encoder.inverse_transform(df_val[target].astype(int))
        df_val["prediction"] = label_encoder.inverse_transform(predictions.astype(int))
        if oof_proba is not None:
            df_val["pred_proba"] = [p.tolist() for p in oof_proba]
            df_val = expand_proba_column(df_val, label_encoder.classes_)
    else:
        df_val["prediction"] = predictions

    # -------------------------------------------------------------------------
    # Compute and print metrics
    # -------------------------------------------------------------------------
    y_true = df_val[target].values
    y_pred = df_val["prediction"].values

    if model_type == "classifier":
        label_names = label_encoder.classes_
        score_df = compute_classification_metrics(y_true, y_pred, label_names, target)
        print_classification_metrics(score_df, target, label_names)
        print_confusion_matrix(y_true, y_pred, label_names)
    else:
        metrics = compute_regression_metrics(y_true, y_pred)
        print_regression_metrics(metrics)

        # Compute ensemble prediction_std
        if n_folds > 1:
            all_preds = np.stack([m.predict(all_df[features]) for m in ensemble_models])
            df_val["prediction_std"] = np.std(all_preds, axis=0)
            print(f"Ensemble std - mean: {df_val['prediction_std'].mean():.4f}, max: {df_val['prediction_std'].max():.4f}")
        else:
            df_val["prediction_std"] = 0.0

        # Train UQ models for uncertainty quantification
        print("\n" + "=" * 50)
        print("Training UQ Models")
        print("=" * 50)
        uq_models, uq_metadata = train_uq_models(
            all_df[features], all_df[target], df_val[features], y_true
        )
        df_val = predict_intervals(df_val, df_val[features], uq_models, uq_metadata)
        df_val = compute_confidence(df_val, uq_metadata["median_interval_width"])

    # -------------------------------------------------------------------------
    # Save validation predictions to S3
    # -------------------------------------------------------------------------
    output_columns = []
    if id_column in df_val.columns:
        output_columns.append(id_column)
    output_columns += [target, "prediction"]

    if model_type != "classifier":
        output_columns.append("prediction_std")
        output_columns += [c for c in df_val.columns if c.startswith("q_") or c == "confidence"]

    output_columns += [c for c in df_val.columns if c.endswith("_proba")]

    wr.s3.to_csv(df_val[output_columns], f"{model_metrics_s3_path}/validation_predictions.csv", index=False)

    # -------------------------------------------------------------------------
    # Save model artifacts
    # -------------------------------------------------------------------------
    for idx, m in enumerate(ensemble_models):
        joblib.dump(m, os.path.join(args.model_dir, f"xgb_model_{idx}.joblib"))
    print(f"Saved {len(ensemble_models)} model(s)")

    with open(os.path.join(args.model_dir, "ensemble_metadata.json"), "w") as f:
        json.dump({"n_ensemble": len(ensemble_models), "n_folds": n_folds}, f)

    with open(os.path.join(args.model_dir, "feature_columns.json"), "w") as f:
        json.dump(orig_features, f)

    with open(os.path.join(args.model_dir, "category_mappings.json"), "w") as f:
        json.dump(category_mappings, f)

    with open(os.path.join(args.model_dir, "hyperparameters.json"), "w") as f:
        json.dump(hyperparameters, f, indent=2)

    if label_encoder:
        joblib.dump(label_encoder, os.path.join(args.model_dir, "label_encoder.joblib"))

    if model_type != "classifier":
        save_uq_models(uq_models, uq_metadata, args.model_dir)

    print(f"\nModel training complete! Artifacts saved to {args.model_dir}")
