import typer
from typing_extensions import Annotated

from aphcli.api.artifacts import (
    grant_artifact_access,
    list_artifact_access,
    list_artifacts_access,
    revoke_artifact_access,
)
from aphcli.api.utils.comms import RequestError
from aphcli.api.utils.prettytable_helpers import table_from_collection_of_dicts
from aphcli.orgs import format_recipient_org_id
from aphcli.utils import validate_is_logged_in

app = typer.Typer(
    no_args_is_help=True,
    context_settings={"help_option_names": ["-h", "--help"]},
)


def _format_created_by(created_by) -> str:
    if not isinstance(created_by, dict):
        return str(created_by) if created_by is not None else ""

    email = created_by.get("email")
    given_name = created_by.get("givenName")
    family_name = created_by.get("familyName")

    if email:
        return email

    parts = [p for p in [given_name, family_name] if p]
    if parts:
        return " ".join(parts)

    return ""


@app.command(
    name="list",
    help=(
        "List artifacts your organization can share, or, when --artifact-id is "
        "provided, list access grants for that artifact."
    ),
)
def list_artifacts_or_grants(
    artifact_id: Annotated[
        str,
        typer.Option(
            "--artifact-id",
            "--id",
            "-i",
            help=(
                "Artifact ID to list access grants for (shorthand: -i / --id). "
                "If omitted, list shareable artifacts for your organization."
            ),
        ),
    ] = None,
    page_size: Annotated[
        int,
        typer.Option(
            "--page-size",
            "-s",
            help="Number of artifacts to return when listing shareable artifacts.",
            min=1,
            show_default=True,
        ),
    ] = 20,
    artifact_type: Annotated[
        str,
        typer.Option(
            "--type",
            "-t",
            help=(
                "Artifact type filter when listing shareable artifacts "
                "(checkpoint, metric, log, result)."
            ),
        ),
    ] = None,
):
    validate_is_logged_in()

    if artifact_id:
        try:
            grants = list_artifact_access(artifact_id)
            if not grants:
                print("No access grants found for this artifact.")
                return

            rows = []
            for grant in grants:
                recipient_org_id = format_recipient_org_id(grant.get("recipientOrgID"))

                row = {
                    "access_id": grant.get("id"),
                    "recipientEmail": grant.get("recipientEmail"),
                    "recipientOrgID": recipient_org_id,
                    "createdAt": grant.get("createdAt"),
                }
                rows.append(row)

            table = table_from_collection_of_dicts(
                rows,
                field_names=[
                    "access_id",
                    "recipientEmail",
                    "recipientOrgID",
                    "createdAt",
                ],
                include_index=True,
                left_align=True,
            )
            # Avoid wrapping IDs across multiple lines to make copying easier.
            table._max_table_width = 0
            print(table)
            return
        except RequestError as err:
            if err.status_code == 404:
                print("Artifact not found.")
                raise typer.Exit(1)
            elif err.status_code == 401:
                print("You are not authorized. Please log in or check your permissions.")
                raise typer.Exit(1)
            else:
                message = err.message or "Error while listing access grants."
                print(message)
                raise typer.Exit(1)

    try:
        artifacts = list_artifacts_access(
            page_size=page_size, artifact_type=artifact_type
        )
        if not artifacts:
            print("No artifacts available for sharing.")
            return

        # Prepare a slimmed-down view with a stringified creator field.
        rows = []
        for artifact in artifacts:
            row = {
                "artifact_id": artifact.get("ID"),
                "name": artifact.get("name"),
                "type": artifact.get("type"),
                "createdBy": _format_created_by(artifact.get("ownerCreatedBy")),
                "createdAt": artifact.get("createdAt"),
            }
            rows.append(row)

        table = table_from_collection_of_dicts(
            rows,
            field_names=["artifact_id", "name", "type", "createdBy", "createdAt"],
            include_index=True,
            left_align=True,
        )
        # Avoid wrapping IDs across multiple lines to make copying easier.
        table._max_table_width = 0
        print(table)
    except RequestError as err:
        message = err.message or "Error while listing artifacts."
        print(message)
        raise typer.Exit(1)


@app.command(help="Grant access to an artifact.")
def grant(
    artifact_id: Annotated[
        str,
        typer.Option(
            "--artifact-id",
            "--id",
            "-i",
            help="ID of the artifact to grant access to (shorthand: -i / --id).",
        ),
    ],
    email: Annotated[
        str,
        typer.Option(
            "--email",
            "-e",
            help="Email that should get access to this artifact (shorthand: -e).",
        ),
    ] = None,
    org_id: Annotated[
        str,
        typer.Option(
            "--org-id",
            "-o",
            help=(
                "Organization ID that should get access to this artifact "
                "(shorthand: -o). Use a value from `apheris orgs list`."
            ),
        ),
    ] = None,
):
    validate_is_logged_in()

    if bool(email) == bool(org_id):
        print("Specify exactly one of --email or --org-id.")
        raise typer.Exit(1)

    try:
        grant = grant_artifact_access(
            artifact_id, recipient_email=email, recipient_org_id=org_id
        )
        recipient = grant.get("recipientEmail") or format_recipient_org_id(
            grant.get("recipientOrgID")
        )
        grant_id = grant.get("id")

        if grant_id:
            print(f"Access granted to {recipient}. Access grant ID: {grant_id}")
        else:
            print(f"Access granted to {recipient}.")
    except RequestError as err:
        if err.status_code == 404:
            print("Artifact or target not found.")
            raise typer.Exit(1)
        elif err.status_code == 401:
            print("You are not authorized. Please log in or check your permissions.")
            raise typer.Exit(1)
        elif err.status_code == 409:
            print("An access grant for this recipient already exists.")
            raise typer.Exit(1)
        else:
            message = err.message or "Error while granting access to artifact."
            print(message)
            raise typer.Exit(1)


@app.command(help="Revoke access to an artifact.")
def revoke(
    artifact_id: Annotated[
        str,
        typer.Option(
            "--artifact-id",
            "--id",
            "-i",
            help="ID of the artifact (shorthand: -i / --id).",
        ),
    ],
    access_id: Annotated[
        str,
        typer.Option(
            "--access-id",
            "-a",
            help="ID of the access grant to revoke (shorthand: -a).",
        ),
    ],
):
    validate_is_logged_in()
    try:
        revoke_artifact_access(artifact_id, access_id)
        print(f"Access grant {access_id} revoked for artifact {artifact_id}.")
    except RequestError as err:
        if err.status_code == 404:
            print("Artifact or access grant not found.")
            raise typer.Exit(1)
        elif err.status_code == 401:
            print("You are not authorized. Please log in or check your permissions.")
            raise typer.Exit(1)
        else:
            message = err.message or "Error while revoking access."
            print(message)
            raise typer.Exit(1)
