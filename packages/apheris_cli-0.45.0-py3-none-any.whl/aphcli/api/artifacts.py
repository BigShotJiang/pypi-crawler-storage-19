from typing import Any, Dict, List

from apheris_auth.config import settings

from aphcli.utils import get_oauth_session

from .utils.comms import exception_handled_request


def list_artifacts_access(
    page_size: int = 50,
    artifact_type: str | None = None,
) -> List[Dict[str, Any]]:
    """
    List artifacts created by the current user's organization that can be shared.

    The returned list is ordered by the artifact's creation time (`createdAt`).

    Maps to:
        GET /v1/artifacts/access

    Args:
        page_size: Number of items to return (query: `page_size`). Must be a positive
            integer.
        artifact_type: Optional artifact type filter (query: `type`), e.g.
            "checkpoint", "metric", "log", "result". If provided, must be a non-empty
            string.
    """
    if not isinstance(page_size, int) or page_size < 1:
        raise ValueError("page_size must be a positive integer.")

    if artifact_type is not None:
        if not isinstance(artifact_type, str):
            raise ValueError("artifact_type must be a string when provided.")
        if not artifact_type.strip():
            raise ValueError("artifact_type must be a non-empty string when provided.")

    session = get_oauth_session()
    url = f"{settings.API_ORCHESTRATOR_BASE_URL}/v1/artifacts/access"
    payload: Dict[str, Any] = {"page_size": page_size}
    if artifact_type:
        payload["type"] = artifact_type

    response = exception_handled_request(session, url, "get", payload=payload)
    data = response.json()

    artifacts = data.get("artifacts", [])
    if artifacts is None:
        return []

    return artifacts


def list_artifact_access(artifact_id: str) -> List[Dict[str, Any]]:
    """
    List access grants for a specific artifact.

    Maps to:
        GET /v1/artifacts/{id}/access
    """
    session = get_oauth_session()
    url = f"{settings.API_ORCHESTRATOR_BASE_URL}/v1/artifacts/{artifact_id}/access"

    response = exception_handled_request(session, url, "get")
    data = response.json()

    grants = data.get("grants", [])
    if grants is None:
        return []

    return grants


def grant_artifact_access(
    artifact_id: str,
    recipient_email: str | None = None,
    recipient_org_id: str | None = None,
) -> Dict[str, Any]:
    """
    Grant access to an artifact for either an email or an organization.

    Maps to:
        POST /v1/artifacts/{id}/access
    """
    if bool(recipient_email) == bool(recipient_org_id):
        raise ValueError("Specify exactly one of recipient_email or recipient_org_id.")

    session = get_oauth_session()
    url = f"{settings.API_ORCHESTRATOR_BASE_URL}/v1/artifacts/{artifact_id}/access"

    payload: Dict[str, Any] = {}
    if recipient_email:
        payload["recipientEmail"] = recipient_email
    if recipient_org_id:
        payload["recipientOrgID"] = recipient_org_id

    response = exception_handled_request(session, url, "post", json=payload)
    return response.json()


def revoke_artifact_access(artifact_id: str, access_id: str) -> None:
    """
    Revoke an existing access grant for an artifact.

    Maps to:
        DELETE /v1/artifacts/{id}/access/{accessID}
    """
    session = get_oauth_session()
    url = (
        f"{settings.API_ORCHESTRATOR_BASE_URL}/v1/artifacts/"
        f"{artifact_id}/access/{access_id}"
    )

    # We don't expect a JSON body back; just ensure the request succeeds.
    exception_handled_request(session, url, "delete")
