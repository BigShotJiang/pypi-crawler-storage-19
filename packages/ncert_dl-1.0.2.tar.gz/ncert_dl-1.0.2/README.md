# ncert-dl

**ncert-dl** is a command-line tool that downloads official NCERT textbooks directly from `ncert.nic.in` for Class 10 (and partially Class 9). It organizes them into clean folders with human-readable chapter names.

## Features

*   **Official Source**: Downloads directly from the NCERT website.
*   **Interactive UI**: Select class, subjects, and language using a checkbox menu.
*   **Smart Renaming**: Automatically converts cryptic filenames (e.g., `jemh101.pdf`) to readable ones (e.g., `Mathematics/01_Chapter.pdf`).
*   **Clean Organization**: structured folders by Subject > Chapter.
*   **Resumable**: Skips already downloaded files and handles interruptions gracefully.
*   **Cross-Platform**: Works on Windows, macOS, and Linux.

## Installation

```bash
pipx install ncert-dl
```

Or with pip:

```bash
pip install ncert-dl
```

## Usage

Simply run the command:

```bash
ncert-dl
```

Follow the interactive prompts:
1.  **Select Class** (e.g., 10)
2.  **Select Subjects** (e.g., Mathematics, Science)
3.  **Select Language** (English or Hindi)

The tool will download the PDFs and organize them in a `NCERT_Downloads` directory.

## How It Works

NCERT uses a predictable naming convention for their PDF files. This tool reverses that convention to generate URLs dynamically.

*   **Maths/Science**: `[prefix][class][chapter].pdf` (e.g., `jemh101.pdf`)
*   **Social Science**: Specific mappings (e.g., `jess101.pdf` -> History Ch 1)

This ensures the downloader is fast, reliable, and doesn't rely on web scraping.

## Disclaimer

This tool is for educational purposes only. It effectively automates the manual process of downloading textbooks from the official portal. Please respect copyright and terms of service of the source website.
