# r321cloud - 文件加密云存储库

ヾ(≧▽≦*)o 欢迎使用 r321cloud！一个可爱的文件加密云存储工具。

## ✨ 功能特性

### 🔒 核心功能
- **文件加密**：使用 AES 加密算法保护你的文件
- **云端存储**：基于 Gitee 的可靠云存储
- **版本控制**：自动同步和版本管理
- **跨平台**：支持 Windows、macOS、Linux、Android

### 🎨 特色亮点
- **可爱的颜文字界面**：所有交互都带有可爱的颜文字表情
- **进度条显示**：加密/解密过程有可视化进度
- **元数据支持**：加密文件包含描述、上传者等信息
- **配置加密**：敏感信息（API token）已加密存储

## 📦 安装

### 方法1：从源码安装
```bash
# 克隆仓库
git clone https://gitee.com/ruin321/r321cloud.git
cd r321cloud/py

# 安装依赖
pip install -r requirements.txt

# 安装包
pip install -e .
```

### 方法2：直接使用
```bash
# 进入项目目录
cd /path/to/r321cloud/py

# 直接运行（无需安装）
python -m r321cloud.cli --help
```

## 🚀 快速开始

### 1. 查看帮助
```bash
r321-cloud --help
```

### 2. 配置访问令牌
```bash
# 设置你的 Gitee access_token
r321-cloud config --set-token YOUR_GITEE_TOKEN
```

### 3. 加密文件
```bash
# 加密文件（会有交互式提示）
r321-cloud filelock example.txt
```

### 4. 获取文件列表
```bash
# 从云端获取文件列表
r321-cloud get

# 查看本地文件列表
r321-cloud list
```

## 📖 完整命令参考

### 基础命令
| 命令 | 说明 | 示例 |
|------|------|------|
| `get` | 从 Gitee 获取文件列表 | `r321-cloud get` |
| `list` | 显示本地文件列表 | `r321-cloud list` |
| `search` | 搜索文件 | `r321-cloud search 关键词` |
| `filelock` | 加密文件 | `r321-cloud filelock 文件` |
| `preview` | 预览加密文件信息 | `r321-cloud preview 加密文件` |
| `download` | 下载文件 | `r321-cloud download 文件名` |
| `config` | 配置管理 | `r321-cloud config` |
| `about` | 关于信息 | `r321-cloud about` |

### 配置管理 (`config`)
```bash
# 查看当前配置和使用说明
r321-cloud config

# 设置 access_token
r321-cloud config --set-token YOUR_TOKEN

# 启用开发者模式（开发中功能）
r321-cloud config --set-dev-mode true

# 禁用开发者模式
r321-cloud config --set-dev-mode false
```

### 下载源管理 (`source`)
```bash
# 导出当前配置为加密数据
r321-cloud source export --output config.encrypted

# 从文件导入配置
r321-cloud source import --file config.encrypted

# 查看加密配置信息
r321-cloud source info --file config.encrypted
```

### 开发者模式 (`devmode`)
```bash
# 查看开发者模式状态
r321-cloud devmode status

# 上传文件（开发中）
r321-cloud devmode upload 文件 --message "说明"

# 运行测试（开发中）
r321-cloud devmode test
```

## 🔧 高级功能

### 更换下载源
r321cloud 支持通过加密配置更换下载源，非常适合团队协作：

```bash
# 1. 导出当前配置
r321-cloud source export --output team_config.encrypted

# 2. 分享给团队成员
# 3. 团队成员导入配置
r321-cloud source import --file team_config.encrypted
```

### 自定义加密密码
```bash
# 加密文件时使用自定义密码
r321-cloud filelock secret.txt --password "我的密码"

# 导出配置时使用自定义密码
r321-cloud source export --output backup.encrypted --password "备份密码"
```

## 🛠️ 项目结构

```
py/
├── r321cloud/                    # 主包
│   ├── __init__.py              # 包初始化
│   ├── cli.py                   # 命令行接口（主文件）
│   ├── gitee.py                 # Gitee API 客户端
│   └── utils/                   # 工具模块
│       ├── __init__.py
│       ├── config.py            # 配置管理
│       ├── encryption.py        # 文件加密工具
│       └── config_encryption.py # 配置加密工具
├── setup.py                     # 安装配置
├── requirements.txt             # 依赖包
├── upload_files.py              # 文件上传脚本
└── README.md                    # 本文档
```

## 🔐 安全说明

### 加密机制
- **文件加密**：使用 PBKDF2 密钥派生 + AES 加密
- **配置加密**：独立的加密系统保护 API 密钥
- **默认密码**：`default_password`（文件加密）、`r321cloud_config`（配置加密）

### 安全建议
1. **使用强密码**：建议为重要文件设置自定义密码
2. **保管好配置**：导出的配置包含敏感信息，请妥善保管
3. **定期更新**：定期更新 access_token 增强安全性
4. **备份重要文件**：重要文件建议本地备份

## 🤝 贡献指南

欢迎贡献代码！请遵循以下步骤：

1. Fork 本仓库
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情

## 👤 作者

**ruin321**
- Gitee: [@ruin321](https://gitee.com/ruin321)
- 项目: [r321cloud](https://gitee.com/ruin321/r321cloud)

## 🙏 致谢

感谢以下开源项目：
- [cryptography](https://cryptography.io/) - 加密库
- [requests](https://docs.python-requests.org/) - HTTP 库
- [Gitee API](https://gitee.com/api/v5) - 云存储平台

## 🐛 问题反馈

如果你遇到任何问题或有建议：
1. 查看 [Issues](https://gitee.com/ruin321/r321cloud/issues)
2. 创建新 Issue 描述问题
3. 提供详细的复现步骤和环境信息

---

ヾ(￣▽￣)Bye~ 感谢使用 r321cloud！希望这个工具能帮助你安全地管理文件！