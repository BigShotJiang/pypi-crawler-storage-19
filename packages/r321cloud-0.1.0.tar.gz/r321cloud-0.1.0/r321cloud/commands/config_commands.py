"""
配置管理命令模块
处理配置管理和下载源配置
"""

from r321cloud.utils.config import Config
from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji, format_with_kaomoji


def cmd_config(args) -> None:
    """配置管理"""
    config = Config.load()
    print(f"{KAOMOJI['info']} 当前配置:")
    print(f"  owner: {config.get('owner')}")
    print(f"  repo: {config.get('repo')}")
    print(f"  branch: {config.get('branch')}")
    print(f"  access_token: {'已设置 ✓' if config.get('access_token') else '未设置 ✗'}")
    print(f"  dev_mode: {'已启用 ✓' if config.get('dev_mode') else '未启用 ✗'}")

    # 如果没有提供任何设置参数，显示使用说明
    if not args.set_token and args.set_dev_mode is None:
        print(f"\n{KAOMOJI['info']} 使用说明:")
        print(f"  • 设置 access_token: r321-cloud config --set-token YOUR_TOKEN")
        print(f"  • 启用开发者模式: r321-cloud config --set-dev-mode true")
        print(f"  • 禁用开发者模式: r321-cloud config --set-dev-mode false")
        print(f"  • 开发者模式启用后，可以使用 'r321-cloud devmode' 命令")
        print(f"  • 更换下载源: r321-cloud source export/import")
        print(f"  • 查看详细帮助: r321-cloud config --help")
        
        # 如果是默认配置，添加特别提示
        if Config.is_default_config():
            print(f"\n{KAOMOJI['info']} ⚠️  当前使用的是默认配置:")
            print(f"  • 无法导出默认配置（保护重要信息）")
            print(f"  • 请先设置你自己的API密钥或导入其他人的配置")
    
    if args.set_token:
        Config.set("access_token", args.set_token)
        print(f"{KAOMOJI['success']} access_token 已更新 ovo")
    
    if args.set_dev_mode is not None:
        if args.set_dev_mode.lower() == "true":
            print(f"\n{KAOMOJI['info']} 提示！ 此功能以及里头的选项均在开发中(>Д<)")
            print("是否启用？  输入y继续")
            user_input = input("> ").strip().lower()
            if user_input == "y":
                Config.set("dev_mode", True)
                print(f"{KAOMOJI['success']} 开发者模式已启用 ovo")
                print(f"{KAOMOJI['happy']} 现在可以使用 'r321-cloud devmode' 命令了！")
            else:
                print(f"{KAOMOJI['info']} 已取消启用开发者模式")
        else:
            Config.set("dev_mode", False)
            print(f"{KAOMOJI['success']} 开发者模式已禁用 ovo")
            print(f"{KAOMOJI['info']} 'r321-cloud devmode' 命令已隐藏")


def cmd_source(args) -> None:
    """管理下载源配置"""
    if args.action == "export":
        # 检查是否是默认配置
        if Config.is_default_config():
            print(f"\n{KAOMOJI['error']} You big baka! (╯°□°）╯︵ ┻━┻")
            print(f"{KAOMOJI['error']} How could I possibly hand over such an important configuration to you?! (ﾉ≧∇≦)ﾉ")
            print(f"\n{KAOMOJI['info']} 温馨提示: 这是默认配置，请先设置你自己的仓库信息！")
            print(f"{KAOMOJI['info']} 使用 'r321-cloud config --set-token YOUR_TOKEN' 设置你的API密钥")
            print(f"{KAOMOJI['info']} 或者使用 'r321-cloud source import' 导入其他人的配置")
            return
        
        # 导出当前配置
        print(f"{KAOMOJI['thinking']} 正在导出当前配置...")
        
        password = args.password if args.password else input("请输入加密密码(留空使用默认密码): ").strip()
        if not password:
            password = "r321cloud_config"
            print(f"{KAOMOJI['info']} 使用默认密码: r321cloud_config")
        
        try:
            encrypted_config = Config.export_encrypted(password)
            
            if args.output:
                # 保存到文件
                with open(args.output, "w", encoding="utf-8") as f:
                    f.write(encrypted_config)
                print(f"{KAOMOJI['success']} 配置已加密并保存到: {args.output}")
                print(f"{KAOMOJI['lock']} 请妥善保管此文件，包含敏感的API密钥信息")
            else:
                # 输出到控制台
                print(f"\n{KAOMOJI['success']} 加密配置生成成功:")
                print("=" * 60)
                print(encrypted_config)
                print("=" * 60)
                print(f"{KAOMOJI['info']} 请复制上面的加密配置，用于在其他设备上恢复")
            
        except Exception as e:
            print(f"{KAOMOJI['error']} 导出配置失败: {e}")
    
    elif args.action == "import":
        # 导入配置
        print(f"{KAOMOJI['thinking']} 正在导入配置...")
        
        password = args.password if args.password else input("请输入加密密码(留空使用默认密码): ").strip()
        if not password:
            password = "r321cloud_config"
            print(f"{KAOMOJI['info']} 使用默认密码: r321cloud_config")
        
        # 获取加密配置
        if args.file:
            # 从文件读取
            try:
                with open(args.file, "r", encoding="utf-8") as f:
                    encrypted_config = f.read()
            except Exception as e:
                print(f"{KAOMOJI['error']} 读取文件失败: {e}")
                return
        elif args.config_data:
            # 直接使用提供的配置数据
            encrypted_config = args.config_data
        else:
            print(f"{KAOMOJI['error']} 请提供加密配置数据或文件路径")
            return
        
        # 先检查配置信息
        try:
            config_info = Config.get_config_info(encrypted_config)
            if not config_info.get("is_valid"):
                print(f"{KAOMOJI['error']} 无效的配置格式")
                return
            
            print(f"{KAOMOJI['info']} 配置信息:")
            print(f"  版本: {config_info.get('version')}")
            print(f"  类型: {config_info.get('type')}")
            print(f"  描述: {config_info.get('metadata', {}).get('description', '无')}")
            
            # 确认导入
            print(f"\n{KAOMOJI['info']} 警告: 这将覆盖当前的仓库配置!")
            confirm = input("是否继续? (输入y确认): ").strip().lower()
            if confirm != "y":
                print(f"{KAOMOJI['info']} 已取消导入")
                return
            
            # 导入配置
            imported_config = Config.import_encrypted(encrypted_config, password)
            
            print(f"{KAOMOJI['success']} 配置导入成功! ovo")
            print(f"\n{KAOMOJI['info']} 已更新的配置:")
            print(f"  仓库: {imported_config.get('owner')}/{imported_config.get('repo')}")
            print(f"  分支: {imported_config.get('branch')}")
            print(f"  API密钥: {'已设置 ✓' if imported_config.get('access_token') else '未设置 ✗'}")
            print(f"\n{KAOMOJI['happy']} 下载源已更换完成!")
            
        except ValueError as e:
            print(f"{KAOMOJI['error']} 配置导入失败: {e}")
            print(f"{KAOMOJI['info']} 请检查密码是否正确")
        except Exception as e:
            print(f"{KAOMOJI['error']} 导入过程中出现错误: {e}")
    
    elif args.action == "info":
        # 查看配置信息
        if not args.config_data and not args.file:
            print(f"{KAOMOJI['error']} 请提供加密配置数据或文件路径")
            return
        
        # 获取加密配置
        if args.file:
            try:
                with open(args.file, "r", encoding="utf-8") as f:
                    encrypted_config = f.read()
            except Exception as e:
                print(f"{KAOMOJI['error']} 读取文件失败: {e}")
                return
        else:
            encrypted_config = args.config_data
        
        # 显示配置信息
        config_info = Config.get_config_info(encrypted_config)
        
        print(f"{KAOMOJI['info']} 配置信息:")
        print(f"  有效性: {'有效 ✓' if config_info.get('is_valid') else '无效 ✗'}")
        print(f"  版本: {config_info.get('version')}")
        print(f"  类型: {config_info.get('type')}")
        
        metadata = config_info.get('metadata', {})
        if metadata:
            print(f"  描述: {metadata.get('description', '无')}")
            print(f"  创建时间: {metadata.get('created_at', '未知')}")
        
        if config_info.get('is_valid'):
            print(f"\n{KAOMOJI['happy']} 这是一个有效的r321cloud配置")
            print(f"{KAOMOJI['info']} 使用 'r321-cloud source import' 命令导入此配置")
