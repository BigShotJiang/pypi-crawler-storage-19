"""
信息命令模块
处理关于信息等展示功能
"""

from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji, format_with_kaomoji

# 版本信息
VERSION = "0.2.0"
AUTHOR = "ruin321"
UPDATE_LOG = "优化：使用 raw 链接获取文件，添加下载功能"


def cmd_about(args) -> None:
    """显示关于信息"""
    print(f"{KAOMOJI['welcome']}")
    print(f"  r321cloud - 文件加密云存储库")
    print(f"  版本: {VERSION}")
    print(f"  作者: {AUTHOR}")
    print(f"  更新记录: {UPDATE_LOG}")
    print(f"{KAOMOJI['happy']} 感谢使用！")