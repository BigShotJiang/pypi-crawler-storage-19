"""
文件操作命令模块
处理文件的加密、解密、搜索、列表等操作
"""

import json
import os
import getpass
import platform
from typing import Dict, Any
from r321cloud.utils.encryption import FileEncryption
from r321cloud.gitee import GiteeClient
from r321cloud.utils.config import Config
from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji, format_with_kaomoji


def get_windows_desktop_path() -> str:
    """获取 Windows 桌面路径，如果不可用则返回 C 盘根目录"""
    if platform.system() == "Windows":
        # 尝试获取桌面路径
        desktop_path = os.path.join(os.path.expanduser('~'), 'Desktop')
        
        # 检查桌面路径是否可写
        try:
            # 尝试创建测试文件
            test_file = os.path.join(desktop_path, '.test_write')
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return desktop_path
        except (PermissionError, OSError):
            # 桌面不可写，尝试 C 盘根目录
            c_drive = "C:\\"
            try:
                # 检查 C 盘是否可写
                test_file = os.path.join(c_drive, '.test_write')
                with open(test_file, 'w') as f:
                    f.write('test')
                os.remove(test_file)
                return c_drive
            except (PermissionError, OSError):
                # 如果 C 盘也不可写，返回当前目录
                return os.getcwd()
    
    # 非 Windows 系统，返回当前目录
    return os.getcwd()


def get_output_path(args_output: str, default_filename: str) -> str:
    """获取输出路径，优先使用桌面（Windows）"""
    if args_output:
        return args_output
    
    # Windows 环境下使用桌面或 C 盘
    if platform.system() == "Windows":
        save_path = get_windows_desktop_path()
        return os.path.join(save_path, default_filename)
    
    # 非 Windows 环境，使用当前目录
    return default_filename


def cmd_get(args) -> None:
    """从 Gitee 获取文件列表"""
    print(f"{KAOMOJI['cloud']} 正在获取文件列表...")
    client = GiteeClient()
    files = client.get_file_list()
    
    if files is None:
        print(f"{KAOMOJI['error']} 获取文件列表失败")
        print(f"{KAOMOJI['info']} 请检查：")
        print("  1. 网络连接是否正常")
        print("  2. API密钥是否正确配置")
        print("  3. 仓库配置是否正确")
        return
    
    if not files:
        print(f"{KAOMOJI['info']} 云端暂无文件")
    else:
        print(f"{KAOMOJI['success']} 成功获取 {len(files)} 个文件列表 ovo")


def cmd_list(args) -> None:
    """显示文件列表"""
    files_json_path = os.path.join("files", "files.json")
    if not os.path.exists(files_json_path):
        print(f"{KAOMOJI['info']} 请先使用 'r321-cloud get' 获取文件列表")
        return

    with open(files_json_path, "r", encoding="utf-8") as f:
        files = json.load(f)

    if not files:
        print(f"{KAOMOJI['info']} 暂无文件哦~")
        return

    print(f"ヾ(≧▽≦*)o 共 {len(files)} 个文件:")
    for idx, file_info in enumerate(files, 1):
        print(f"  {idx}. {file_info.get('name', '未知')}")


def cmd_search(args) -> None:
    """搜索文件"""
    files_json_path = os.path.join("files", "files.json")
    if not os.path.exists(files_json_path):
        print(f"{KAOMOJI['info']} 请先使用 'r321-cloud get' 获取文件列表")
        return

    with open(files_json_path, "r", encoding="utf-8") as f:
        files = json.load(f)

    keyword = args.keyword.lower()
    results = []

    for file_info in files:
        name = file_info.get("name", "").lower()
        if keyword in name or name.startswith(keyword):
            results.append(file_info)

    if not results:
        print(f"(・_・?) 未找到包含 '{args.keyword}' 的文件")
        return

    print(f"(*^▽^*) 找到 {len(results)} 个匹配的文件:")
    for idx, file_info in enumerate(results, 1):
        print(f"  {idx}. {file_info.get('name', '未知')}")


def cmd_filelock(args) -> None:
    """加密文件"""
    from r321cloud.utils.error_handler import (
        safe_file_path, validate_password, 
        FileNotFoundError, EncryptionError, handle_errors
    )
    
    @handle_errors
    def _filelock():
        # 验证文件路径
        file_path = safe_file_path(args.file)
        
        print(f"{KAOMOJI['loading']} 正在加密文件... (｡•̀ᴗ-)✧")

        # 检查是否使用no-lock模式
        if args.no_lock:
            print(f"{KAOMOJI['info']} 使用无密码保护模式 (no_lock=true)")
            password = ""  # 空密码表示无密码保护
            no_lock_flag = "true"
        else:
            password = args.password if args.password else getpass.getpass("请输入加密密码(留空使用默认密码): ")
            if not password:
                password = "default_password"
                print(f"{KAOMOJI['info']} 使用默认密码: default_password")
            else:
                # 验证密码强度
                try:
                    validate_password(password, min_length=4)
                except EncryptionError as e:
                    print(f"{KAOMOJI['error']} {e.message}")
                    print(f"{KAOMOJI['info']} 提示: 密码至少需要4个字符")
                    return
            no_lock_flag = "false"

        description = args.description if args.description else input("请输入文件简介(留空跳过): ")
        uploader = args.uploader if args.uploader else input("请输入上传者名称(留空跳过): ")

        encryptor = FileEncryption(password)

        # 进度条回调
        def progress_callback(current, total, message):
            percent = int(current / total * 100)
            bar_length = 30
            filled = int(bar_length * current / total)
            bar = '█' * filled + '░' * (bar_length - filled)
            print(f"\r  [{bar}] {percent}% - {message}", end='', flush=True)

        # 调用加密函数，传递no_lock标记
        try:
            encrypted_text = encryptor.encrypt_file(file_path, description, uploader, progress_callback, no_lock=no_lock_flag)
            print()  # 换行
        except Exception as e:
            raise EncryptionError(f"加密文件失败: {str(e)}")

        output_file = args.output if args.output else f"{os.path.basename(file_path)}.encrypted"
        
        try:
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(encrypted_text)
        except IOError as e:
            raise FileNotFoundError(f"无法保存加密文件: {output_file}", str(e))

        print(f"{KAOMOJI['success']} {KAOMOJI['lock']} 文件已加密并保存到: {output_file} ovo")
    
    _filelock()


def cmd_preview(args) -> None:
    """预览加密文件的元数据"""
    if not os.path.exists(args.file):
        print(f"(╥﹏╥) 文件不存在: {args.file}")
        return

    print(f"{KAOMOJI['thinking']} 正在读取文件信息... (｡•̀ᴗ-)✧")

    with open(args.file, "r", encoding="utf-8") as f:
        encrypted_text = f.read()

    encryptor = FileEncryption()
    try:
        metadata = encryptor.get_metadata(encrypted_text)

        print(f"\n{KAOMOJI['happy']} 文件信息预览:")
        print(f"{'='*40}")
        print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
        print(f"  文件大小: {metadata.get('file_size', 0)} 字节")
        print(f"  上传者: {metadata.get('uploader', '未知')}")
        print(f"  文件描述: {metadata.get('description', '无')}")
        print(f"{'='*40}")
        print(f"{KAOMOJI['lock']} 文件已加密保护，使用 fileunlock 命令解密 ovo")

    except Exception as e:
        print(f"{KAOMOJI['error']} 读取文件信息失败: {e}")


def cmd_fileunlock(args) -> None:
    """解密加密文件并显示内容"""
    if not os.path.exists(args.file):
        print(f"(╥﹏╥) 文件不存在: {args.file}")
        return

    print(f"{KAOMOJI['loading']} 正在读取加密文件... (｡•̀ᴗ-)✧")

    with open(args.file, "r", encoding="utf-8") as f:
        encrypted_text = f.read()

    encryptor = FileEncryption()
    try:
        # 获取文件元数据
        metadata = encryptor.get_metadata(encrypted_text)
        
        print(f"\n{KAOMOJI['happy']} 文件信息:")
        print(f"{'='*40}")
        print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
        print(f"  文件大小: {metadata.get('file_size', 0)} 字节")
        print(f"  上传者: {metadata.get('uploader', '未知')}")
        print(f"  文件描述: {metadata.get('description', '无')}")
        
        # 检查是否有no_lock标记
        no_lock = metadata.get('no_lock')
        if no_lock == "true":
            print(f"  加密状态: 🔓 无密码保护 (no_lock=true)")
            password_required = False
        else:
            print(f"  加密状态: 🔒 需要密码解密")
            password_required = True
        
        print(f"{'='*40}")
        
        # 询问用户是否要解密并显示内容
        print(f"\n{KAOMOJI['thinking']} 是否要解密并查看文件内容? (输入y查看，其他键跳过)")
        user_choice = input("> ").strip().lower()
        
        if user_choice == "y":
            print(f"{KAOMOJI['loading']} 正在解密文件内容...")
            
            try:
                if password_required:
                    # 询问密码
                    password = getpass.getpass("请输入解密密码: ")
                    if not password:
                        print(f"{KAOMOJI['info']} 使用默认密码: 123")
                        password = "123"
                    decryptor = FileEncryption(password)
                else:
                    # 无密码文件，直接解密
                    decryptor = FileEncryption()
                
                decrypted_content = decryptor.decrypt_file(encrypted_text)
                
                # 显示文件内容（前1000字符）
                content_preview = decrypted_content.decode('utf-8')[:1000]
                print(f"\n{KAOMOJI['happy']} 文件内容预览:")
                print(f"{'='*50}")
                print(content_preview)
                if len(decrypted_content) > 1000:
                    print(f"... (显示前1000字符，完整内容{len(decrypted_content)}字符)")
                print(f"{'='*50}")
                
                # 询问是否保存到本地
                print(f"\n{KAOMOJI['thinking']} 是否保存到本地文件? (输入y保存，其他键跳过)")
                save_choice = input("> ").strip().lower()
                
                if save_choice == "y":
                    # 获取输出路径（Windows 环境优先使用桌面）
                    default_filename = metadata.get('original_filename', os.path.basename(args.file).replace('.encrypted', ''))
                    output_path = get_output_path(args.output, default_filename)
                    
                    # 确保目录存在
                    output_dir = os.path.dirname(output_path)
                    if output_dir:
                        os.makedirs(output_dir, exist_ok=True)
                    
                    with open(output_path, "wb") as f:
                        f.write(decrypted_content)
                    print(f"{KAOMOJI['success']} {KAOMOJI['unlock']} 文件已解密并保存到: {output_path} ovo")
                else:
                    print(f"{KAOMOJI['info']} 已跳过保存")
                    
            except Exception as e:
                print(f"{KAOMOJI['error']} 解密失败: {e}")
                if password_required:
                    print(f"{KAOMOJI['info']} 提示: 密码可能不正确，请重试")
        else:
            print(f"{KAOMOJI['info']} 已跳过解密")
            
    except Exception as e:
        print(f"{KAOMOJI['error']} 解析文件信息失败: {e}")
        print(f"{KAOMOJI['info']} 这可能不是一个有效的加密文件")


def cmd_download(args) -> None:
    """查看加密文件信息（不实际下载）"""
    files_json_path = os.path.join("files", "files.json")
    if not os.path.exists(files_json_path):
        print(f"{KAOMOJI['info']} 请先使用 'r321-cloud get' 获取文件列表")
        return

    with open(files_json_path, "r", encoding="utf-8") as f:
        files = json.load(f)

    file_info = None
    for f in files:
        if f.get("name") == args.filename:
            file_info = f
            break

    if not file_info:
        print(f"(・_・?) 未找到文件: {args.filename}")
        return

    print(f"{KAOMOJI['download']} 正在获取文件信息... (｡•̀ᴗ-)✧")

    client = GiteeClient()
    # 文件在根目录下，不需要添加files/前缀
    encrypted_content = client.get_file_content(args.filename)

    if encrypted_content is None:
        print(f"{KAOMOJI['error']} 获取文件失败")
        return

    print(f"\n{KAOMOJI['happy']} 文件信息:")
    print(f"{'='*50}")
    
    try:
        # 解析加密文件获取元数据
        encryptor = FileEncryption()
        metadata = encryptor.get_metadata(encrypted_content)
        
        # 显示基本信息
        print(f"  文件名: {args.filename}")
        print(f"  原始文件名: {metadata.get('original_filename', '未知')}")
        print(f"  文件大小: {metadata.get('file_size', 0)} 字节")
        print(f"  上传者: {metadata.get('uploader', '未知')}")
        print(f"  文件描述: {metadata.get('description', '无')}")
        
        # 检查是否有no_lock标记
        no_lock = metadata.get('no_lock')
        if no_lock == "true":
            print(f"  加密状态: 🔓 无密码保护 (no_lock=true)")
            password_required = False
        else:
            print(f"  加密状态: 🔒 需要密码解密")
            password_required = True
        
        print(f"{'='*50}")
        
        # 询问用户是否要查看内容
        print(f"\n{KAOMOJI['thinking']} 是否要查看文件内容? (输入y查看，其他键跳过)")
        user_choice = input("> ").strip().lower()
        
        if user_choice == "y":
            print(f"{KAOMOJI['loading']} 正在解密文件内容...")
            
            try:
                if password_required:
                    # 询问密码
                    password = getpass.getpass("请输入解密密码(留空使用默认密码123): ")
                    if not password:
                        print(f"{KAOMOJI['info']} 使用默认密码: 123")
                        password = "123"
                    decryptor = FileEncryption(password)
                    decrypted_content = decryptor.decrypt_file(encrypted_content)
                else:
                    # 无密码文件，直接解密
                    decryptor = FileEncryption()
                    decrypted_content = decryptor.decrypt_file(encrypted_content)
                
                # 显示文件内容（前1000字符）
                content_preview = decrypted_content.decode('utf-8')[:1000]
                print(f"\n{KAOMOJI['happy']} 文件内容预览:")
                print(f"{'='*50}")
                print(content_preview)
                if len(decrypted_content) > 1000:
                    print(f"... (显示前1000字符，完整内容{len(decrypted_content)}字符)")
                print(f"{'='*50}")
                
                # 询问是否保存到本地
                print(f"\n{KAOMOJI['thinking']} 是否保存到本地文件? (输入y保存，其他键跳过)")
                save_choice = input("> ").strip().lower()
                
                if save_choice == "y":
                    # 获取输出路径（Windows 环境优先使用桌面）
                    default_filename = metadata.get('original_filename', args.filename)
                    output_path = get_output_path(args.output, default_filename)
                    
                    # 确保目录存在
                    output_dir = os.path.dirname(output_path)
                    if output_dir:
                        os.makedirs(output_dir, exist_ok=True)
                    
                    with open(output_path, "wb") as f:
                        f.write(decrypted_content)
                    print(f"{KAOMOJI['success']} 文件已保存到: {output_path} ovo")
                else:
                    print(f"{KAOMOJI['info']} 已跳过保存")
                    
            except Exception as e:
                print(f"{KAOMOJI['error']} 解密失败: {e}")
                if password_required:
                    print(f"{KAOMOJI['info']} 提示: 可能需要其他密码，默认密码为'123'")
        else:
            print(f"{KAOMOJI['info']} 已跳过查看内容")
            
    except Exception as e:
        print(f"{KAOMOJI['error']} 解析文件信息失败: {e}")
        print(f"{KAOMOJI['info']} 这可能不是一个有效的加密文件")
