"""
交互式工具模块
提供更好的用户交互体验
"""

import getpass
from typing import Optional, Callable, Any
from r321cloud.utils.error_handler import handle_errors


def ask_yes_no(question: str, default: bool = False) -> bool:
    """询问是/否问题，支持默认值"""
    options = "[Y/n]" if default else "[y/N]"
    while True:
        try:
            answer = input(f"{question} {options}: ").strip().lower()
            if not answer:
                return default
            if answer in ["y", "yes", "是"]:
                return True
            if answer in ["n", "no", "否"]:
                return False
            print("请输入 y/n 或 是/否")
        except KeyboardInterrupt:
            print("\n操作已取消")
            return False
        except EOFError:
            print("\n输入结束")
            return False


def ask_with_default(prompt: str, default: str = "") -> str:
    """询问问题，支持默认值"""
    if default:
        prompt = f"{prompt} (默认: {default}): "
    else:
        prompt = f"{prompt}: "
    
    try:
        answer = input(prompt).strip()
        return answer if answer else default
    except KeyboardInterrupt:
        print("\n操作已取消")
        return ""
    except EOFError:
        print("\n输入结束")
        return ""


def ask_password(prompt: str = "请输入密码", confirm: bool = False) -> str:
    """安全地询问密码，可选确认"""
    while True:
        try:
            password = getpass.getpass(f"{prompt}: ")
            if not password:
                print("密码不能为空")
                continue
                
            if confirm:
                confirm_password = getpass.getpass("请确认密码: ")
                if password != confirm_password:
                    print("两次输入的密码不一致，请重新输入")
                    continue
            
            return password
        except KeyboardInterrupt:
            print("\n操作已取消")
            return ""
        except EOFError:
            print("\n输入结束")
            return ""


def select_from_list(items: list, prompt: str = "请选择") -> Optional[int]:
    """从列表中选择项目"""
    if not items:
        print("没有可选项")
        return None
    
    print(f"\n{prompt}:")
    for i, item in enumerate(items, 1):
        print(f"  {i}. {item}")
    
    while True:
        try:
            choice = input(f"请输入序号 (1-{len(items)}): ").strip()
            if not choice:
                return None
            
            index = int(choice) - 1
            if 0 <= index < len(items):
                return index
            else:
                print(f"请输入 1-{len(items)} 之间的数字")
        except ValueError:
            print("请输入有效的数字")
        except KeyboardInterrupt:
            print("\n操作已取消")
            return None
        except EOFError:
            print("\n输入结束")
            return None


def show_progress(current: int, total: int, message: str = "", bar_length: int = 30) -> None:
    """显示进度条"""
    if total == 0:
        return
    
    percent = int(current / total * 100)
    filled = int(bar_length * current / total)
    bar = '█' * filled + '░' * (bar_length - filled)
    
    if message:
        print(f"\r  [{bar}] {percent}% - {message}", end='', flush=True)
    else:
        print(f"\r  [{bar}] {percent}%", end='', flush=True)
    
    if current >= total:
        print()  # 完成后换行


def format_table(data: list, headers: list = None, max_width: int = 80) -> str:
    """格式化表格输出"""
    if not data:
        return "暂无数据"
    
    if headers is None:
        headers = list(data[0].keys()) if data else []
    
    # 计算列宽
    col_widths = []
    for header in headers:
        max_len = len(str(header))
        for row in data:
            value = str(row.get(header, ""))
            max_len = max(max_len, len(value))
        col_widths.append(min(max_len, max_width // len(headers)))
    
    # 构建表格
    lines = []
    
    # 表头
    header_line = " | ".join(str(h).ljust(w) for h, w in zip(headers, col_widths))
    lines.append(header_line)
    lines.append("-" * len(header_line))
    
    # 数据行
    for row in data:
        row_line = " | ".join(str(row.get(h, "")).ljust(w)[:w] for h, w in zip(headers, col_widths))
        lines.append(row_line)
    
    return "\n".join(lines)


def confirm_dangerous_action(action: str, details: str = "") -> bool:
    """确认危险操作"""
    print(f"⚠️  警告: 即将执行危险操作")
    print(f"   操作: {action}")
    if details:
        print(f"   详情: {details}")
    print("\n此操作可能:")
    print("  • 覆盖现有文件")
    print("  • 删除重要数据")
    print("  • 修改系统配置")
    
    return ask_yes_no("是否继续?", default=False)


def interactive_wrapper(func: Callable[..., Any]) -> Callable[..., Any]:
    """交互式包装器，处理用户中断"""
    @handle_errors
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeyboardInterrupt:
            print("\n\n操作已被用户中断")
            return None
        except EOFError:
            print("\n\n输入结束")
            return None
    return wrapper


# 常用的交互模板
def file_selection_prompt() -> str:
    """文件选择提示"""
    return ask_with_default("请输入文件路径", "")


def encryption_options() -> dict:
    """加密选项交互"""
    options = {}
    
    print("\n🔒 加密选项:")
    
    # 密码保护模式
    use_password = ask_yes_no("是否使用密码保护?", default=True)
    if use_password:
        options["password"] = ask_password("请输入加密密码", confirm=True)
    else:
        options["no_lock"] = True
        print("⚠️  注意: 无密码保护模式安全性较低")
    
    # 文件描述
    options["description"] = ask_with_default("请输入文件描述", "")
    
    # 上传者
    options["uploader"] = ask_with_default("请输入上传者名称", "")
    
    return options
