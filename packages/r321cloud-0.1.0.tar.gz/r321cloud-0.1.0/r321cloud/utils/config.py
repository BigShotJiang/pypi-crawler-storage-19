"""
配置管理模块
"""

import os
import json
from typing import Dict, Any
from .config_encryption import ConfigEncryption, validate_config


class Config:
    DEFAULT_CONFIG = {
        "access_token": "",
        "owner": "ruin321",
        "repo": "r321cloud",
        "branch": "master",
        "dev_mode": False,
        "api_base": "https://gitee.com/api/v5",
        "raw_base": "https://gitee.com"
    }

    CONFIG_FILE = os.path.expanduser("~/.r321cloud_config.json")

    @classmethod
    def load(cls) -> Dict[str, Any]:
        if os.path.exists(cls.CONFIG_FILE):
            try:
                with open(cls.CONFIG_FILE, "r", encoding="utf-8") as f:
                    config = json.load(f)
                    return {**cls.DEFAULT_CONFIG, **config}
            except (json.JSONDecodeError, IOError):
                pass
        return cls.DEFAULT_CONFIG.copy()

    @classmethod
    def save(cls, config: Dict[str, Any]) -> None:
        with open(cls.CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)

    @classmethod
    def get(cls, key: str, default: Any = None) -> Any:
        config = cls.load()
        return config.get(key, default)

    @classmethod
    def set(cls, key: str, value: Any) -> None:
        config = cls.load()
        config[key] = value
        cls.save(config)
    
    @classmethod
    def update_all(cls, new_config: Dict[str, Any]) -> None:
        """更新所有配置
        
        Args:
            new_config: 新的配置字典
        """
        config = cls.load()
        config.update(new_config)
        cls.save(config)
    
    @classmethod
    def export_encrypted(cls, password: str = "r321cloud_config") -> str:
        """导出加密的配置
        
        Args:
            password: 加密密码
            
        Returns:
            加密后的配置字符串
        """
        config = cls.load()
        
        # 准备要加密的配置数据
        config_to_encrypt = {
            "owner": config.get("owner", ""),
            "repo": config.get("repo", ""),
            "branch": config.get("branch", ""),
            "access_token": config.get("access_token", ""),
            "api_base": config.get("api_base", "https://gitee.com/api/v5"),
            "raw_base": config.get("raw_base", "https://gitee.com"),
            "description": f"r321cloud 配置 - {config.get('owner')}/{config.get('repo')}"
        }
        
        # 加密配置
        encryptor = ConfigEncryption(password)
        return encryptor.encrypt_config(config_to_encrypt)
    
    @classmethod
    def import_encrypted(cls, encrypted_config: str, password: str = "r321cloud_config") -> Dict[str, Any]:
        """从加密数据导入配置
        
        Args:
            encrypted_config: 加密的配置字符串
            password: 解密密码
            
        Returns:
            导入的配置字典
            
        Raises:
            ValueError: 如果配置无效或解密失败
        """
        # 解密配置
        encryptor = ConfigEncryption(password)
        imported_config = encryptor.decrypt_config(encrypted_config)
        
        # 验证配置
        if not validate_config(imported_config):
            raise ValueError("配置数据无效")
        
        # 更新配置
        config_updates = {
            "owner": imported_config.get("owner"),
            "repo": imported_config.get("repo"),
            "branch": imported_config.get("branch"),
            "access_token": imported_config.get("access_token"),
            "api_base": imported_config.get("api_base", "https://gitee.com/api/v5"),
            "raw_base": imported_config.get("raw_base", "https://gitee.com")
        }
        
        cls.update_all(config_updates)
        return config_updates
    
    @classmethod
    def get_config_info(cls, encrypted_config: str) -> Dict[str, Any]:
        """获取加密配置的信息（不解密）
        
        Args:
            encrypted_config: 加密的配置字符串
            
        Returns:
            配置信息字典
        """
        from .config_encryption import ConfigEncryption
        encryptor = ConfigEncryption()
        return encryptor.get_config_info(encrypted_config)
    
    @classmethod
    def is_default_config(cls) -> bool:
        """检查当前配置是否是默认配置（硬编码在gitee.py中的配置）
        
        Returns:
            如果是默认配置返回True，否则返回False
        """
        config = cls.load()
        
        # 默认配置的特征：
        # 1. owner是"ruin321"
        # 2. repo是"r321cloud" 
        # 3. branch是"master"
        # 4. access_token为空（用户未设置）
        # 5. 没有自定义的api_base和raw_base
        
        is_default = (
            config.get("owner") == "ruin321" and
            config.get("repo") == "r321cloud" and
            config.get("branch") == "master" and
            config.get("access_token") == "" and
            config.get("api_base") == "https://gitee.com/api/v5" and
            config.get("raw_base") == "https://gitee.com"
        )
        
        return is_default