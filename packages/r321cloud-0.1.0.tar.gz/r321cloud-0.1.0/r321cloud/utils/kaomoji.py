"""
颜文字表情库
统一管理所有颜文字表情，保持项目风格一致
"""

KAOMOJI = {
    # 欢迎和问候
    "welcome": "ヾ(≧▽≦*)o 欢迎使用 r321cloud！",
    "bye": "ヾ(￣▽￣)Bye~ 下次见！",
    "happy": "(*^▽^*) 好耶！",
    
    # 操作状态
    "success": "o(*￣▽￣*)ブ 操作成功！",
    "error": "(╥﹏╥) 操作失败...",
    "loading": "(｡•̀ᴗ-)✧ 正在处理中...",
    "thinking": "(・_・?) 正在思考...",
    
    # 信息提示
    "info": "(￣▽￣) 温馨提示：",
    "warning": "⚠️ 警告：",
    "tip": "💡 提示：",
    
    # 功能相关
    "lock": "🔒 文件已加密保护",
    "unlock": "🔓 文件已解锁",
    "download": "⬇️ 下载文件中...",
    "cloud": "☁️ 云端同步中...",
    "search": "🔍 搜索中...",
    "list": "📋 文件列表：",
    
    # 特殊表情
    "baka": "(╯°□°）╯︵ ┻━┻ You big baka!",
    "excited": "ヽ(✿ﾟ▽ﾟ)ノ 好兴奋！",
    "cute": "(*/ω＼*) 好害羞~",
    "cool": "( •̀ ω •́ )✧ 酷！",
    "sad": "(；′⌒`) 好难过...",
    "angry": "(╬▔皿▔)╯ 生气！",
    "confused": "(⊙_⊙)？ 什么情况？",
    "surprised": "Σ(っ °Д °;)っ 震惊！",
    "love": "(❤ ω ❤) 喜欢~",
    "star": "☆*: .｡. o(≧▽≦)o .｡.:*☆ 星星眼",
    
    # 进度相关
    "progress_start": "🚀 开始处理...",
    "progress_mid": "⏳ 处理中...",
    "progress_end": "✅ 处理完成！",
    
    # 文件操作
    "file_saved": "💾 文件已保存",
    "file_encrypted": "🔐 文件已加密",
    "file_decrypted": "🔓 文件已解密",
    "file_uploaded": "📤 文件已上传",
    "file_downloaded": "📥 文件已下载",
    
    # 网络状态
    "connecting": "📡 连接中...",
    "connected": "✅ 连接成功",
    "disconnected": "❌ 连接断开",
    
    # 开发者模式
    "dev_mode": "👨‍💻 开发者模式",
    "dev_warning": "🚧 开发中功能",
    "dev_test": "🧪 测试中...",
}


def get_kaomoji(key: str, default: str = "") -> str:
    """获取颜文字表情，如果不存在则返回默认值"""
    return KAOMOJI.get(key, default)


def print_kaomoji(key: str, message: str = "") -> None:
    """打印颜文字表情和消息"""
    kaomoji = get_kaomoji(key, "")
    if kaomoji and message:
        print(f"{kaomoji} {message}")
    elif kaomoji:
        print(kaomoji)
    elif message:
        print(message)


def format_with_kaomoji(key: str, message: str) -> str:
    """格式化消息和颜文字"""
    kaomoji = get_kaomoji(key, "")
    if kaomoji:
        return f"{kaomoji} {message}"
    return message