"""
配置加密工具
用于加密和解密仓库配置，实现更换下载源功能
"""

import json
import base64
from typing import Dict, Any
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC


class ConfigEncryption:
    """配置加密工具类"""
    
    PBKDF2_ITERATIONS = 480000
    
    def __init__(self, password: str = "r321cloud_config"):
        """初始化配置加密工具
        
        Args:
            password: 加密密码，默认为 'r321cloud_config'
        """
        self.password = password
    
    def _generate_key(self, salt: bytes) -> bytes:
        """生成加密密钥"""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=self.PBKDF2_ITERATIONS,
        )
        key = base64.urlsafe_b64encode(kdf.derive(self.password.encode()))
        return key
    
    def encrypt_config(self, config_data: Dict[str, Any]) -> str:
        """加密配置数据
        
        Args:
            config_data: 配置字典，包含以下字段：
                - owner: 仓库所有者
                - repo: 仓库名称
                - branch: 分支名称
                - access_token: API访问令牌
                - api_base: API基础URL（可选）
                - raw_base: 原始文件基础URL（可选）
        
        Returns:
            加密后的配置字符串（JSON格式）
        """
        import os
        
        # 生成随机盐值
        salt = os.urandom(16)
        
        # 生成密钥
        key = self._generate_key(salt)
        fernet = Fernet(key)
        
        # 将配置数据转换为JSON字符串
        config_json = json.dumps(config_data, ensure_ascii=False)
        
        # 加密配置数据
        encrypted_data = fernet.encrypt(config_json.encode())
        
        # 构建结果
        result = {
            "version": "1.0",
            "type": "r321cloud_config",
            "salt": base64.b64encode(salt).decode(),
            "encrypted_config": base64.b64encode(encrypted_data).decode(),
            "metadata": {
                "description": "r321cloud 仓库配置",
                "created_at": "2026-01-10"
            }
        }
        
        return json.dumps(result, ensure_ascii=False, indent=2)
    
    def decrypt_config(self, encrypted_config: str) -> Dict[str, Any]:
        """解密配置数据
        
        Args:
            encrypted_config: 加密的配置字符串
            
        Returns:
            解密后的配置字典
            
        Raises:
            ValueError: 如果配置格式无效或解密失败
        """
        try:
            # 解析加密数据
            data = json.loads(encrypted_config)
            
            # 验证数据格式
            if data.get("type") != "r321cloud_config":
                raise ValueError("无效的配置类型")
            
            # 获取盐值和加密数据
            salt = base64.b64decode(data["salt"])
            encrypted_data = base64.b64decode(data["encrypted_config"])
            
            # 生成密钥
            key = self._generate_key(salt)
            fernet = Fernet(key)
            
            # 解密数据
            decrypted_json = fernet.decrypt(encrypted_data).decode()
            
            # 解析配置
            config_data = json.loads(decrypted_json)
            
            return config_data
            
        except (json.JSONDecodeError, KeyError, base64.binascii.Error) as e:
            raise ValueError(f"配置解析失败: {e}")
        except Exception as e:
            raise ValueError(f"配置解密失败: {e}")
    
    def get_config_info(self, encrypted_config: str) -> Dict[str, Any]:
        """获取配置信息（不解密敏感数据）
        
        Args:
            encrypted_config: 加密的配置字符串
            
        Returns:
            配置信息字典，包含版本、类型和元数据
        """
        try:
            data = json.loads(encrypted_config)
            return {
                "version": data.get("version", "未知"),
                "type": data.get("type", "未知"),
                "metadata": data.get("metadata", {}),
                "is_valid": data.get("type") == "r321cloud_config"
            }
        except json.JSONDecodeError:
            return {
                "version": "未知",
                "type": "无效",
                "metadata": {},
                "is_valid": False
            }


def create_default_config() -> Dict[str, Any]:
    """创建默认配置模板
    
    Returns:
        默认配置字典
    """
    return {
        "owner": "ruin321",
        "repo": "r321cloud",
        "branch": "master",
        "access_token": "",
        "api_base": "https://gitee.com/api/v5",
        "raw_base": "https://gitee.com",
        "description": "默认仓库配置"
    }


def validate_config(config_data: Dict[str, Any]) -> bool:
    """验证配置数据是否有效
    
    Args:
        config_data: 配置字典
        
    Returns:
        是否有效
    """
    # 必需字段（access_token可以为空，因为用户可能还没设置）
    required_fields = ["owner", "repo", "branch"]
    
    for field in required_fields:
        if field not in config_data:
            return False
    
    # access_token字段必须存在（但可以为空字符串）
    if "access_token" not in config_data:
        return False
    
    return True