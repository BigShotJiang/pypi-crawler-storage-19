"""
Gitee API 客户端
用于从 Gitee 获取文件列表和上传文件
"""

import json
import base64
import os
from typing import Dict, List, Optional, Any
import requests

from r321cloud.utils.config import Config


class GiteeClient:
    def __init__(self):
        config = Config.load()
        self._auth = config.get("access_token", "")
        self._owner = config.get("owner", "ruin321")
        self._repo = config.get("repo", "r321cloud")
        self._branch = config.get("branch", "master")
        self._api_base = config.get("api_base", "https://gitee.com/api/v5")
        self._raw_base = config.get("raw_base", "https://gitee.com")

    def _get_raw_url(self, file_path: str) -> str:
        return f"{self._raw_base}/{self._owner}/{self._repo}/raw/{self._branch}/{file_path}"

    def get_file_content(self, file_path: str) -> Optional[str]:
        """通过 Gitee API 获取文件内容"""
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/{file_path}"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        params = {
            "access_token": self._auth,
            "ref": self._branch
        }

        try:
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()

            # 如果返回的是列表，说明是目录，无法获取内容
            if isinstance(data, list):
                print(f"错误: {file_path} 是一个目录，不是文件")
                return None

            # 检查是否是文件（应该有 type 字段）
            if data.get("type") != "file":
                print(f"错误: {file_path} 不是一个文件")
                return None

            content = data.get("content", "")

            if content:
                return base64.b64decode(content).decode("utf-8")
            return None

        except requests.exceptions.RequestException as e:
            print(f"获取文件内容失败: {e}")
            return None

    def get_file_list(self) -> Optional[List[Dict[str, Any]]]:
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/files.json"

        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }

        params = {
            "access_token": self._auth,
            "ref": self._branch
        }

        try:
            response = requests.get(url, params=params, headers=headers)

            if response.status_code == 404:
                files = []
            else:
                response.raise_for_status()
                data = response.json()
                
                # 检查data是否是字典（文件内容）还是列表（目录内容）
                if isinstance(data, list):
                    # 返回的是目录内容，说明files.json不存在
                    files = []
                else:
                    content = data.get("content", "")

                    if content:
                        decoded_content = base64.b64decode(content).decode("utf-8")
                        files = json.loads(decoded_content)
                    else:
                        files = []

            os.makedirs("files", exist_ok=True)
            with open("files/files.json", "w", encoding="utf-8") as f:
                json.dump(files, f, ensure_ascii=False, indent=2)

            return files

        except requests.exceptions.RequestException:
            # 不打印错误信息，让调用者处理
            return None

    def upload_file(self, file_path: str, content: str, message: str = "上传文件") -> bool:
        filename = os.path.basename(file_path)
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/{file_path}"

        encoded_content = base64.b64encode(content.encode("utf-8")).decode("utf-8")

        params = {"access_token": self._auth}
        data = {
            "access_token": self._auth,
            "content": encoded_content,
            "message": message
        }

        try:
            response = requests.get(url, params=params)
            if response.status_code == 200:
                resp_data = response.json()
                if isinstance(resp_data, dict):
                    data["sha"] = resp_data.get("sha")
                    response = requests.put(url, data=data)
                else:
                    response = requests.post(url, data=data)
            else:
                response = requests.post(url, data=data)

            response.raise_for_status()
            return True

        except requests.exceptions.RequestException as e:
            print(f"上传文件失败: {e}")
            return False