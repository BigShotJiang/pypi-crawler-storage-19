"""
r321cloud 命令行工具 - 重构版
模块化重构，将功能拆分为独立的命令模块
"""

import argparse
from r321cloud.utils.config import Config
from r321cloud.commands import (
    cmd_get, cmd_list, cmd_search, cmd_filelock, cmd_fileunlock, 
    cmd_download, cmd_preview, cmd_config, cmd_source, cmd_about,
    cmd_devmode_upload, cmd_devmode_status, cmd_devmode_test
)


# 版本信息（保持向后兼容）
VERSION = "0.2.0"
AUTHOR = "ruin321"
UPDATE_LOG = "优化：使用 raw 链接获取文件，添加下载功能"

# 导入统一的颜文字库
from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji, format_with_kaomoji


def main():
    # 检查开发者模式是否启用
    dev_mode_enabled = Config.get("dev_mode", False)
    
    parser = argparse.ArgumentParser(
        description=f"{KAOMOJI['welcome']} r321cloud - 文件加密云存储库",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    subparsers = parser.add_subparsers(dest="command", help="可用命令")

    # 文件操作命令
    parser_get = subparsers.add_parser("get", help="从 Gitee 获取文件列表")
    parser_get.set_defaults(func=cmd_get)

    parser_list = subparsers.add_parser("list", help="显示文件列表")
    parser_list.set_defaults(func=cmd_list)

    parser_search = subparsers.add_parser("search", help="搜索本地文件列表")
    parser_search.add_argument("keyword", help="搜索关键词")
    parser_search.set_defaults(func=cmd_search)

    parser_filelock = subparsers.add_parser("filelock", help="加密文件")
    parser_filelock.add_argument("file", help="要加密的文件路径")
    parser_filelock.add_argument("--password", help="加密密码(可选)")
    parser_filelock.add_argument("--description", help="文件简介(可选)")
    parser_filelock.add_argument("--uploader", help="上传者名称(可选)")
    parser_filelock.add_argument("--output", help="输出文件路径(可选)")
    parser_filelock.add_argument("--no-lock", action="store_true", help="无密码保护模式")
    parser_filelock.set_defaults(func=cmd_filelock)

    parser_preview = subparsers.add_parser("preview", help="预览加密文件的元数据")
    parser_preview.add_argument("file", help="要预览的加密文件路径")
    parser_preview.set_defaults(func=cmd_preview)

    parser_fileunlock = subparsers.add_parser("fileunlock", help="解密加密文件并显示内容")
    parser_fileunlock.add_argument("file", help="要解密的加密文件路径")
    parser_fileunlock.add_argument("--output", help="输出文件路径(可选)")
    parser_fileunlock.set_defaults(func=cmd_fileunlock)

    parser_download = subparsers.add_parser("download", help="下载文件到本地")
    parser_download.add_argument("filename", help="要下载的文件名")
    parser_download.add_argument("--output", help="输出文件路径(可选)")
    parser_download.set_defaults(func=cmd_download)

    # 配置管理命令
    parser_config = subparsers.add_parser("config", help="配置管理", 
                                         formatter_class=argparse.RawDescriptionHelpFormatter,
                                         description=f"""{KAOMOJI['info']} 配置管理命令

使用示例:
  r321-cloud config                    # 查看当前配置和使用说明
  r321-cloud config --set-token TOKEN  # 设置 access_token
  r321-cloud config --set-dev-mode true  # 启用开发者模式
  r321-cloud config --set-dev-mode false # 禁用开发者模式

开发者模式:
  • 启用后可以使用 'r321-cloud devmode' 命令
  • 包含开发中的功能，如上传等
  • 启用时有安全警告提示""")
    parser_config.add_argument("--set-token", help="设置 access token")
    parser_config.add_argument("--set-dev-mode", help="设置开发者模式 (true/false)")
    parser_config.set_defaults(func=cmd_config)

    parser_source = subparsers.add_parser("source", help="管理下载源配置",
                                         formatter_class=argparse.RawDescriptionHelpFormatter,
                                         description=f"""{KAOMOJI['cloud']} 下载源管理命令

功能: 通过加密配置数据更换下载源（仓库/API密钥等）

使用示例:
  r321-cloud source export [--output 文件]      # 导出当前配置为加密数据
  r321-cloud source import --file 加密文件      # 从文件导入配置
  r321-cloud source import --data "加密数据"    # 直接导入加密数据
  r321-cloud source info --file 加密文件        # 查看加密配置信息
  r321-cloud source info --data "加密数据"      # 直接查看加密配置信息

注意:
  • 导出配置包含敏感的API密钥，请妥善保管
  • 导入配置会覆盖当前的仓库设置
  • 默认加密密码: r321cloud_config""")
    parser_source.add_argument("action", choices=["export", "import", "info"], 
                              help="操作类型: export(导出), import(导入), info(查看信息)")
    parser_source.add_argument("--file", help="加密配置文件路径")
    parser_source.add_argument("--data", dest="config_data", help="加密配置数据字符串")
    parser_source.add_argument("--output", help="导出文件路径")
    parser_source.add_argument("--password", help="加密/解密密码")
    parser_source.set_defaults(func=cmd_source)

    # 信息命令
    parser_about = subparsers.add_parser("about", help="显示制作者/版本/更新记录信息")
    parser_about.set_defaults(func=cmd_about)

    # 开发者模式下的命令
    if dev_mode_enabled:
        parser_devmode = subparsers.add_parser("devmode", help="开发者模式命令 (开发中)",
                                             formatter_class=argparse.RawDescriptionHelpFormatter,
                                             description=f"""{KAOMOJI['thinking']} 开发者模式命令 (开发中)

⚠️  警告: 此功能仍在开发中，可能存在不稳定情况
    启用方法: r321-cloud config --set-dev-mode true

可用命令:
  status   查看开发者模式状态
  upload   上传文件到云端 (开发中)
  test     测试功能 (开发中)

注意: 禁用开发者模式后此命令将隐藏""")
        devmode_subparsers = parser_devmode.add_subparsers(dest="devmode_command", help="开发者模式子命令")
        
        # 状态命令
        parser_status = devmode_subparsers.add_parser("status", help="查看开发者模式状态")
        parser_status.set_defaults(func=cmd_devmode_status)
        
        # 上传命令 (开发中)
        parser_upload = devmode_subparsers.add_parser("upload", help="上传文件到云端 (开发中)")
        parser_upload.add_argument("file", help="要上传的文件路径")
        parser_upload.add_argument("--message", help="提交信息", default="上传文件")
        parser_upload.set_defaults(func=cmd_devmode_upload)
        
        # 测试命令 (开发中)
        parser_test = devmode_subparsers.add_parser("test", help="测试功能 (开发中)")
        parser_test.set_defaults(func=cmd_devmode_test)

    args = parser.parse_args()

    if args.command:
        # 处理开发者模式命令
        if args.command == "devmode" and dev_mode_enabled:
            if hasattr(args, 'devmode_command') and args.devmode_command:
                args.func(args)
            else:
                parser_devmode.print_help()
        else:
            args.func(args)
    else:
        # 显示帮助信息，如果开发者模式启用则提示
        parser.print_help()
        if dev_mode_enabled:
            print(f"\n{KAOMOJI['happy']} 开发者模式已启用！输入 'r321-cloud devmode' 查看开发中功能 ovo")


if __name__ == "__main__":
    main()