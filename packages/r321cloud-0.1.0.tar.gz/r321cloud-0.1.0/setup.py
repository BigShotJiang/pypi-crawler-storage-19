from setuptools import setup, find_packages

setup(
    name="r321cloud",
    version="0.1.0",
    author="ruin321",
    description="r321cloud - 文件加密云存储库",
    packages=find_packages(),
    install_requires=[
        "cryptography>=41.0.0",
        "requests>=2.31.0",
    ],
    entry_points={
        "console_scripts": [
            "r321-cloud=r321cloud.cli:main",
        ],
    },
    python_requires=">=3.7",
)