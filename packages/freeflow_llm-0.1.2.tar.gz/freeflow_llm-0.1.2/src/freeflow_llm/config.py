"""
Configuration settings for FreeFlow LLM.

This module contains default configuration values for providers and models.
"""

DEFAULT_MAX_TOKENS = 1024

DEFAULT_MODELS = {
    "groq": "llama-3.3-70b-versatile",
    "gemini": "gemini-2.5-flash",
    "mistral": "mistral-small-latest",
    "github": "gpt-4o-mini",
    "openrouter": "meta-llama/llama-3.1-8b-instruct:free",
}

DEFAULT_TEMPERATURE = 1.0

DEFAULT_TOP_P = 1.0
