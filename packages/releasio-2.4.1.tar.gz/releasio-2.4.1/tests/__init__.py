"""Tests for releasio."""
