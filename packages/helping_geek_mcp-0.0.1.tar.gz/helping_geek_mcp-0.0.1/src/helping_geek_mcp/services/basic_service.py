"""
Sample service for basic operations.
"""

from typing import Dict, Any


class BasicService:
    """
    A basic service demonstrating service structure.
    """
    
    def __init__(self):
        """Initialize the service."""
        self.name = "BasicService"
        self.version = "0.0.1"
    
    def execute(self, operation: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a service operation.
        
        Args:
            operation: Operation name
            params: Operation parameters
        
        Returns:
            Operation result
        """
        if operation == "echo":
            return {"status": "success", "data": params}
        elif operation == "status":
            return {"status": "running", "service": self.name, "version": self.version}
        else:
            return {"status": "error", "message": f"Unknown operation: {operation}"}
    
    def health_check(self) -> bool:
        """
        Check service health.
        
        Returns:
            True if healthy
        """
        return True
