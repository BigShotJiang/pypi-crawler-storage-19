"""
Basic data processing utilities.
"""

import json
from pathlib import Path
from typing import Any, Optional


class DataProcessor:
    """
    Simple data transformation helper for demonstration.
    """
    
    def __init__(self, base_dir: Optional[Path] = None):
        """
        Initialize data processor.
        
        Args:
            base_dir: Base directory for data files
        """
        self.base_dir = base_dir or Path.home() / ".helping_geek_mcp"
    
    def transform(self, data: dict, format_type: str = "json") -> str:
        """
        Transform data to different format.
        
        Args:
            data: Input data dictionary
            format_type: Output format (json, xml, yaml)
        
        Returns:
            Formatted data string
        """
        if format_type == "json":
            return self.to_json(data)
        elif format_type == "xml":
            return self.to_xml(data)
        elif format_type == "yaml":
            return self.to_yaml(data)
        else:
            return str(data)
    
    def to_json(self, data: dict, indent: int = 2) -> str:
        """
        Convert data to JSON.
        
        Args:
            data: Input data
            indent: Indentation spaces
        
        Returns:
            JSON string
        """
        return json.dumps(data, indent=indent)
    
    def to_xml(self, data: dict, root_tag: str = "root") -> str:
        """
        Convert data to simple XML format.
        
        Args:
            data: Input data
            root_tag: Root XML tag
        
        Returns:
            XML string
        """
        xml_parts = [f"<{root_tag}>"]
        for key, value in data.items():
            xml_parts.append(f"  <{key}>{value}</{key}>")
        xml_parts.append(f"</{root_tag}>")
        return "\n".join(xml_parts)
    
    def to_yaml(self, data: dict) -> str:
        """
        Convert data to simple YAML format.
        
        Args:
            data: Input data
        
        Returns:
            YAML-like string
        """
        yaml_parts = []
        for key, value in data.items():
            yaml_parts.append(f"{key}: {value}")
        return "\n".join(yaml_parts)
    
    def filter_data(self, data: list, key: str, value: Any) -> list:
        """
        Filter list of dictionaries by key-value pair.
        
        Args:
            data: List of dictionaries
            key: Key to filter by
            value: Value to match
        
        Returns:
            Filtered list
        """
        return [item for item in data if item.get(key) == value]
    
    def sort_data(self, data: list, key: str, reverse: bool = False) -> list:
        """
        Sort list of dictionaries by key.
        
        Args:
            data: List of dictionaries
            key: Key to sort by
            reverse: Sort in reverse order
        
        Returns:
            Sorted list
        """
        return sorted(data, key=lambda x: x.get(key, ""), reverse=reverse)
