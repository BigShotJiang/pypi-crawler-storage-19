"""
Basic string manipulation utilities.
"""


class StringHelper:
    """
    Simple string processing helper for demonstration.
    """
    
    def process(self, text: str, operation: str = "uppercase") -> str:
        """
        Process text with basic operations.
        
        Args:
            text: Input text
            operation: Operation type (uppercase, lowercase, reverse, capitalize)
        
        Returns:
            Processed text
        """
        if operation == "uppercase":
            return text.upper()
        elif operation == "lowercase":
            return text.lower()
        elif operation == "reverse":
            return text[::-1]
        elif operation == "capitalize":
            return text.capitalize()
        else:
            return text
    
    def split_text(self, text: str, delimiter: str = " ") -> list:
        """
        Split text by delimiter.
        
        Args:
            text: Input text
            delimiter: Delimiter character
        
        Returns:
            List of text segments
        """
        return text.split(delimiter)
    
    def join_text(self, segments: list, separator: str = " ") -> str:
        """
        Join text segments.
        
        Args:
            segments: List of text segments
            separator: Separator character
        
        Returns:
            Joined text
        """
        return separator.join(str(s) for s in segments)
    
    def truncate(self, text: str, max_length: int = 100, suffix: str = "...") -> str:
        """
        Truncate text to maximum length.
        
        Args:
            text: Input text
            max_length: Maximum length
            suffix: Suffix to add when truncated
        
        Returns:
            Truncated text
        """
        if len(text) <= max_length:
            return text
        return text[:max_length - len(suffix)] + suffix
