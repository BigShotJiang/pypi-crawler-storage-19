"""
Basic constants for the MCP server.
"""

from pathlib import Path


class ServerConstants:
    """Server-level constants."""
    
    SERVER_NAME = "Helping Geek MCP"
    VERSION = "0.0.1"
    AUTHOR = "helpinggeek1234@gmail.com"
    
    DEFAULT_TIMEOUT = 60
    MAX_RETRIES = 3
    
    # Default directories
    DEFAULT_BASE_DIR = Path.home() / ".helping_geek_mcp"
    CONFIG_DIR = "config"
    STATIC_DIR = "static"
    TEMPLATES_DIR = "static/templates"
    LOGS_DIR = "logs"


class ProcessingConstants:
    """Data processing constants."""
    
    MAX_TEXT_LENGTH = 10000
    DEFAULT_DELIMITER = " "
    DEFAULT_SEPARATOR = " "
    TRUNCATE_SUFFIX = "..."
    
    SUPPORTED_FORMATS = ["json", "xml", "yaml"]
    DEFAULT_FORMAT = "json"


class TemplateConstants:
    """Template-related constants."""
    
    DEFAULT_TEMPLATES = [
        "greeting",
        "notification",
        "summary",
        "error"
    ]
