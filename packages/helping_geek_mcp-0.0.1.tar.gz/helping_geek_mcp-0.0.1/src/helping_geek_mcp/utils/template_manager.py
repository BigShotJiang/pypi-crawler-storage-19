"""
Basic template management utilities.
"""

from pathlib import Path
from typing import Dict, Optional


class TemplateManager:
    """
    Simple template manager for demonstration.
    """
    
    def __init__(self, base_dir: Optional[Path] = None):
        """
        Initialize template manager.
        
        Args:
            base_dir: Base directory for template files
        """
        self.base_dir = base_dir or Path.home() / ".helping_geek_mcp"
        self.templates_dir = self.base_dir / "static" / "templates"
        self._templates = self._load_default_templates()
    
    def _load_default_templates(self) -> Dict[str, str]:
        """Load default templates."""
        return {
            "greeting": "Hello, {name}! Welcome to {service}.",
            "notification": "You have {count} new {item_type}.",
            "summary": "Summary: {title}\nDate: {date}\nStatus: {status}",
            "error": "Error occurred: {error_message}\nCode: {error_code}",
        }
    
    def get_template(self, template_name: str, variables: Dict[str, str] = None) -> str:
        """
        Get template and fill with variables.
        
        Args:
            template_name: Name of the template
            variables: Variables to substitute
        
        Returns:
            Filled template string
        """
        template = self._templates.get(template_name, "Template not found: {template_name}")
        
        if variables:
            try:
                return template.format(**variables)
            except KeyError as e:
                return f"Missing variable in template: {e}"
        
        return template
    
    def add_template(self, name: str, content: str) -> None:
        """
        Add a new template.
        
        Args:
            name: Template name
            content: Template content
        """
        self._templates[name] = content
    
    def list_templates(self) -> list:
        """
        List all available templates.
        
        Returns:
            List of template names
        """
        return list(self._templates.keys())
    
    def render(self, content: str, variables: Dict[str, str]) -> str:
        """
        Render content with variables.
        
        Args:
            content: Template content
            variables: Variables to substitute
        
        Returns:
            Rendered content
        """
        try:
            return content.format(**variables)
        except KeyError as e:
            return f"Missing variable: {e}"
