"""
Helping Geek MCP - A sample MCP server for educational purposes.
"""

__version__ = "0.0.1"
__author__ = "Helping Geek"
__email__ = "helpinggeek1234@gmail.com"

from helping_geek_mcp.server import main

__all__ = ["main"]
