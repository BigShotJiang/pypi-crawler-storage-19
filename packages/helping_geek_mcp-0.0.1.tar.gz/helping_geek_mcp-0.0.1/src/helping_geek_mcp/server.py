#!/usr/bin/env python3
"""
MCP Python Server - Basic Sample Implementation

This is a sample server demonstrating the Model Context Protocol (MCP) structure.
It contains basic functions and utilities for educational purposes.
"""

import logging
import sys
from pathlib import Path
from typing import Optional
from mcp.server.fastmcp import FastMCP

# Import basic utilities
from helping_geek_mcp.utils.string_helper import StringHelper
from helping_geek_mcp.utils.data_processor import DataProcessor
from helping_geek_mcp.utils.template_manager import TemplateManager
from helping_geek_mcp.config import ConfigManager

# Module-level logger
logger = logging.getLogger(__name__)

# Base directory for data files
BASE_DIR: Optional[Path] = None
LOGGING_ENABLED: bool = False

# Manager instances
string_helper = StringHelper()
data_processor = DataProcessor()
template_manager = TemplateManager()
config_manager = ConfigManager()


def initialize_components():
    """
    Initialize all components with BASE_DIR.
    Sets up logging and creates all instances.
    """
    global BASE_DIR, LOGGING_ENABLED, string_helper, data_processor, template_manager, config_manager
    
    if LOGGING_ENABLED:
        logger.info(f"Initializing components with BASE_DIR: {BASE_DIR}")
    
    # Re-initialize with BASE_DIR if needed
    string_helper = StringHelper()
    data_processor = DataProcessor(base_dir=BASE_DIR)
    template_manager = TemplateManager(base_dir=BASE_DIR)
    config_manager = ConfigManager(base_dir=BASE_DIR)


def setup_logging(log_level: str = "INFO"):
    """
    Configure logging for the server.
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
    """
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stderr)
        ]
    )


# Create FastMCP server instance
mcp = FastMCP("Helping Geek MCP")


@mcp.tool()
def process_text(text: str, operation: str = "uppercase") -> str:
    """
    Process text with basic string operations.
    
    Args:
        text: Input text to process
        operation: Operation to perform (uppercase, lowercase, reverse, capitalize)
    
    Returns:
        Processed text string
    """
    if not LOGGING_ENABLED:
        initialize_components()
    
    logger.info(f"Processing text with operation: {operation}")
    return string_helper.process(text, operation)


@mcp.tool()
def transform_data(data: dict, format_type: str = "json") -> str:
    """
    Transform data between different formats.
    
    Args:
        data: Input data dictionary
        format_type: Output format (json, xml, yaml)
    
    Returns:
        Formatted data string
    """
    if not LOGGING_ENABLED:
        initialize_components()
    
    logger.info(f"Transforming data to format: {format_type}")
    return data_processor.transform(data, format_type)


@mcp.tool()
def get_template(template_name: str, variables: dict = None) -> str:
    """
    Get a template and optionally fill it with variables.
    
    Args:
        template_name: Name of the template
        variables: Variables to substitute in template
    
    Returns:
        Template content with variables substituted
    """
    if not LOGGING_ENABLED:
        initialize_components()
    
    logger.info(f"Getting template: {template_name}")
    return template_manager.get_template(template_name, variables or {})


@mcp.tool()
def get_config(key: str) -> str:
    """
    Get configuration value by key.
    
    Args:
        key: Configuration key
    
    Returns:
        Configuration value
    """
    if not LOGGING_ENABLED:
        initialize_components()
    
    logger.info(f"Getting config for key: {key}")
    return config_manager.get(key)


@mcp.resource("config://settings")
def get_settings() -> str:
    """
    Get current server settings.
    
    Returns:
        Server settings as JSON string
    """
    if not LOGGING_ENABLED:
        initialize_components()
    
    return config_manager.get_all_settings()


def main():
    """
    Main entry point for the server.
    """
    import argparse
    
    parser = argparse.ArgumentParser(description="Helping Geek MCP Server")
    parser.add_argument("command", nargs="?", default="start", help="Command to run")
    parser.add_argument("--base-dir", type=str, help="Base directory for data files")
    parser.add_argument("--log-level", type=str, default="INFO", help="Logging level")
    parser.add_argument("--enable-logging", action="store_true", help="Enable logging")
    
    args = parser.parse_args()
    
    global BASE_DIR, LOGGING_ENABLED
    
    if args.base_dir:
        BASE_DIR = Path(args.base_dir)
    
    LOGGING_ENABLED = args.enable_logging
    
    if LOGGING_ENABLED:
        setup_logging(args.log_level)
        logger.info("Starting Helping Geek MCP Server")
    
    if args.command == "start":
        # Initialize components before starting server
        initialize_components()
        # Run the MCP server
        mcp.run()
    else:
        print(f"Unknown command: {args.command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
