"""
Basic configuration manager for sample MCP server.
"""

import json
from pathlib import Path
from typing import Any, Optional


class ConfigManager:
    """
    Manages configuration settings for the MCP server.
    This is a simplified demonstration version.
    """
    
    def __init__(self, base_dir: Optional[Path] = None):
        """
        Initialize the configuration manager.
        
        Args:
            base_dir: Base directory for configuration files
        """
        self.base_dir = base_dir or Path.home() / ".helping_geek_mcp"
        self.config_file = self.base_dir / "config" / "settings.json"
        self._config = self._load_default_config()
    
    def _load_default_config(self) -> dict:
        """Load default configuration."""
        return {
            "version": "0.0.1",
            "server_name": "Helping Geek MCP",
            "author": "helpinggeek1234@gmail.com",
            "timeout": 60,
            "max_retries": 3
        }
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a configuration value.
        
        Args:
            key: Configuration key
            default: Default value if key not found
        
        Returns:
            Configuration value
        """
        return self._config.get(key, default)
    
    def set(self, key: str, value: Any) -> None:
        """
        Set a configuration value.
        
        Args:
            key: Configuration key
            value: Configuration value
        """
        self._config[key] = value
    
    def get_all_settings(self) -> str:
        """
        Get all settings as JSON string.
        
        Returns:
            JSON string of all settings
        """
        return json.dumps(self._config, indent=2)
    
    def save(self) -> None:
        """Save configuration to file."""
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_file, 'w') as f:
            json.dump(self._config, f, indent=2)
    
    def load(self) -> None:
        """Load configuration from file."""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                self._config = json.load(f)
