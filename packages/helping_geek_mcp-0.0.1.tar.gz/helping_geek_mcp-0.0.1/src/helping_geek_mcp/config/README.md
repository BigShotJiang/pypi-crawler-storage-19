# Configuration Files

This directory contains configuration files for the Helping Geek MCP server.

## Files

- `config_manager.py`: Main configuration management class
- `sample_config.json`: Sample configuration with default settings

## Usage

The configuration manager provides basic key-value storage for server settings.
