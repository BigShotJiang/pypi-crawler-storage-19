"""
Prompts module for Helping Geek MCP.
"""

__all__ = []
