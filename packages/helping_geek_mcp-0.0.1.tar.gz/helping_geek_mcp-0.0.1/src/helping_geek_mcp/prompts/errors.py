"""
Sample error definitions for the MCP server.
"""


class ServerError(Exception):
    """Base exception for server errors."""
    pass


class ConfigurationError(ServerError):
    """Configuration-related errors."""
    pass


class ProcessingError(ServerError):
    """Data processing errors."""
    pass


class TemplateError(ServerError):
    """Template-related errors."""
    pass


class ValidationError(ServerError):
    """Input validation errors."""
    pass
