"""
Tests for string helper utility.
"""

import pytest
from helping_geek_mcp.utils.string_helper import StringHelper


class TestStringHelper:
    """Test cases for StringHelper class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.helper = StringHelper()
    
    def test_process_uppercase(self):
        """Test uppercase operation."""
        result = self.helper.process("hello", "uppercase")
        assert result == "HELLO"
    
    def test_process_lowercase(self):
        """Test lowercase operation."""
        result = self.helper.process("HELLO", "lowercase")
        assert result == "hello"
    
    def test_process_reverse(self):
        """Test reverse operation."""
        result = self.helper.process("hello", "reverse")
        assert result == "olleh"
    
    def test_process_capitalize(self):
        """Test capitalize operation."""
        result = self.helper.process("hello world", "capitalize")
        assert result == "Hello world"
    
    def test_split_text(self):
        """Test text splitting."""
        result = self.helper.split_text("hello world test")
        assert result == ["hello", "world", "test"]
    
    def test_join_text(self):
        """Test text joining."""
        result = self.helper.join_text(["hello", "world", "test"])
        assert result == "hello world test"
    
    def test_truncate(self):
        """Test text truncation."""
        result = self.helper.truncate("hello world", max_length=8)
        assert result == "hello..."
