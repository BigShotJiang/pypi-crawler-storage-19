"""
Tests for template manager utility.
"""

import pytest
from helping_geek_mcp.utils.template_manager import TemplateManager


class TestTemplateManager:
    """Test cases for TemplateManager class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.manager = TemplateManager()
    
    def test_get_template_without_variables(self):
        """Test getting template without variables."""
        result = self.manager.get_template("greeting")
        assert "Hello" in result
    
    def test_get_template_with_variables(self):
        """Test getting template with variables."""
        variables = {"name": "Alice", "service": "MCP"}
        result = self.manager.get_template("greeting", variables)
        assert "Alice" in result
        assert "MCP" in result
    
    def test_add_template(self):
        """Test adding new template."""
        self.manager.add_template("test", "Test: {value}")
        result = self.manager.get_template("test", {"value": "123"})
        assert result == "Test: 123"
    
    def test_list_templates(self):
        """Test listing templates."""
        templates = self.manager.list_templates()
        assert "greeting" in templates
        assert "notification" in templates
        assert "summary" in templates
    
    def test_render(self):
        """Test rendering content."""
        content = "Hello {name}, you have {count} items"
        variables = {"name": "Bob", "count": "5"}
        result = self.manager.render(content, variables)
        assert result == "Hello Bob, you have 5 items"
