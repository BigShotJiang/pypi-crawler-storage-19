"""
Tests for configuration manager.
"""

import pytest
from helping_geek_mcp.config import ConfigManager


class TestConfigManager:
    """Test cases for ConfigManager class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.manager = ConfigManager()
    
    def test_get_existing_key(self):
        """Test getting existing configuration key."""
        result = self.manager.get("version")
        assert result == "0.0.1"
    
    def test_get_missing_key_with_default(self):
        """Test getting missing key with default value."""
        result = self.manager.get("nonexistent", "default_value")
        assert result == "default_value"
    
    def test_set_and_get(self):
        """Test setting and getting configuration."""
        self.manager.set("test_key", "test_value")
        result = self.manager.get("test_key")
        assert result == "test_value"
    
    def test_get_all_settings(self):
        """Test getting all settings."""
        result = self.manager.get_all_settings()
        assert "version" in result
        assert "0.0.1" in result
