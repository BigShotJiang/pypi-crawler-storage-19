"""
Tests for basic service.
"""

import pytest
from helping_geek_mcp.services.basic_service import BasicService


class TestBasicService:
    """Test cases for BasicService class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.service = BasicService()
    
    def test_echo_operation(self):
        """Test echo operation."""
        params = {"message": "hello"}
        result = self.service.execute("echo", params)
        assert result["status"] == "success"
        assert result["data"] == params
    
    def test_status_operation(self):
        """Test status operation."""
        result = self.service.execute("status", {})
        assert result["status"] == "running"
        assert result["service"] == "BasicService"
        assert result["version"] == "0.0.1"
    
    def test_unknown_operation(self):
        """Test unknown operation."""
        result = self.service.execute("unknown", {})
        assert result["status"] == "error"
        assert "Unknown operation" in result["message"]
    
    def test_health_check(self):
        """Test health check."""
        result = self.service.health_check()
        assert result is True
