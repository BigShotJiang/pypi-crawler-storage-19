"""
Tests for data processor utility.
"""

import pytest
from helping_geek_mcp.utils.data_processor import DataProcessor


class TestDataProcessor:
    """Test cases for DataProcessor class."""
    
    def setup_method(self):
        """Set up test fixtures."""
        self.processor = DataProcessor()
    
    def test_to_json(self):
        """Test JSON conversion."""
        data = {"key": "value", "number": 42}
        result = self.processor.to_json(data)
        assert '"key": "value"' in result
        assert '"number": 42' in result
    
    def test_to_xml(self):
        """Test XML conversion."""
        data = {"key": "value", "number": 42}
        result = self.processor.to_xml(data)
        assert "<root>" in result
        assert "<key>value</key>" in result
        assert "</root>" in result
    
    def test_to_yaml(self):
        """Test YAML conversion."""
        data = {"key": "value", "number": 42}
        result = self.processor.to_yaml(data)
        assert "key: value" in result
        assert "number: 42" in result
    
    def test_filter_data(self):
        """Test data filtering."""
        data = [
            {"name": "Alice", "age": 30},
            {"name": "Bob", "age": 25},
            {"name": "Charlie", "age": 30}
        ]
        result = self.processor.filter_data(data, "age", 30)
        assert len(result) == 2
        assert result[0]["name"] == "Alice"
    
    def test_sort_data(self):
        """Test data sorting."""
        data = [
            {"name": "Charlie", "age": 30},
            {"name": "Alice", "age": 25},
            {"name": "Bob", "age": 35}
        ]
        result = self.processor.sort_data(data, "name")
        assert result[0]["name"] == "Alice"
        assert result[-1]["name"] == "Charlie"
