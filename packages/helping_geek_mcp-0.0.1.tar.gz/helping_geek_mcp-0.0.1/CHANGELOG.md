# Changelog

All notable changes to this project will be documented in this file.

## [0.0.1] - 2026-01-12

### Added
- Initial release of Helping Geek MCP server
- Basic server structure with MCP protocol support
- Sample utilities and tools for demonstration
- Configuration management examples
- Basic template system
- Example prompts and services structure
- Unit test framework
- Documentation and setup guides

### Notes
- This is a proof-of-concept release for PyPI publishing demonstration
- Not intended for production use
