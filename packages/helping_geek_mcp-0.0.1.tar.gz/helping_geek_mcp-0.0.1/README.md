# Helping Geek MCP Server

A sample Model Context Protocol (MCP) server demonstrating basic utilities and tools for educational purposes.

## What is This?

This is a demonstration MCP (Model Context Protocol) server created as a proof-of-concept for publishing Python packages to PyPI. It showcases the basic structure and components needed for an MCP server without containing production-level functionality.

## Features

- **Basic String Operations**: Simple text manipulation utilities
- **Data Processing**: Basic data transformation functions
- **Template Management**: Simple template handling demonstrations
- **Configuration**: Example configuration management

This is a sample project designed for learning and testing the PyPI publishing workflow.

## Quick Setup

### 1. Install the Server

```bash
pip install helping-geek-mcp
```

### 2. Configure Your AI Assistant

#### For Cline (VS Code Extension)

Add this to your Cline MCP settings:

```json
{
  "mcpServers": {
    "helping-geek-mcp": {
      "timeout": 60,
      "command": "helping-geek-mcp",
      "args": ["start"],
      "env": {}
    }
  }
}
```

#### For Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "helping-geek-mcp": {
      "command": "helping-geek-mcp",
      "args": ["start"]
    }
  }
}
```

## Development

### Install for Development

```bash
git clone https://github.com/helpinggeek/helping-geek-mcp.git
cd helping-geek-mcp
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest
```

### Build Package

```bash
python -m build
```

### Publish to PyPI

```bash
twine upload dist/*
```

## Project Structure

```
python-server/
├── src/
│   └── helping_geek_mcp/
│       ├── server.py
│       ├── config/
│       ├── prompts/
│       ├── services/
│       ├── tools/
│       └── utils/
├── tests/
├── docs/
├── pyproject.toml
├── README.md
└── LICENSE
```

## License

MIT License - See LICENSE file for details

## Contact

For questions or feedback, reach out to helpinggeek1234@gmail.com

## Disclaimer

This is a sample project for educational purposes and PyPI publishing demonstration. Not intended for production use.
