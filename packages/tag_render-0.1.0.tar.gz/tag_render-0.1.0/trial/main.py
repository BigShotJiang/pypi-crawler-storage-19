import tag_render
from PIL import Image

class ModelRender:
    """Binding to Rust code that renders .stl and .obj files"""
    def __init__(self):
        """Initialises the Rust App. This must be done only once."""
        self.renderer = tag_render.ModelRender()

    def model_render(self, path: str, size: tuple[int, int]) -> Image.Image:
        """Renders a .stl or .obj file from its path to an image of the specified size. Throws exceptions."""
        image_pixels: tag_render.ImagePixels = self.renderer.image(path, size)
        return Image.frombytes("RGBA", size, image_pixels.data)
