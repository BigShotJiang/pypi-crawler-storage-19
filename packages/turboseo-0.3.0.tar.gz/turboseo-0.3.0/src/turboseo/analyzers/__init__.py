"""
TurboSEO Analyzers

Content analysis modules for SEO and human writing detection.
"""

from turboseo.analyzers.content_fetcher import (
    FetchedContent,
    fetch_url,
    parse_html,
)
from turboseo.analyzers.content_length import (
    LengthResult,
    LengthStatus,
    analyze_length,
    compare_lengths,
    get_content_types,
    get_targets,
)
from turboseo.analyzers.content_scrubber import (
    EmDashReplacement,
    ScrubResult,
    scrub_content,
)
from turboseo.analyzers.keywords import (
    KeywordResult,
    StuffingDetail,
    StuffingRisk,
    analyze_keywords,
)
from turboseo.analyzers.readability import (
    ReadabilityResult,
    analyze_readability,
)
from turboseo.analyzers.search_intent import (
    IntentResult,
    SearchIntent,
    analyze_intent,
)
from turboseo.analyzers.seo_score import (
    SEOResult,
    analyze_seo,
)
from turboseo.analyzers.writing_standards import (
    WritingIssue,
    WritingStandardsResult,
    analyze_writing_standards,
)

# Conditional import for topic clustering (requires sklearn)
try:
    from turboseo.analyzers.topic_clustering import (
        LSIKeywords,
        TopicCluster,
        TopicClusteringResult,
        analyze_topics,
    )

    _TOPIC_CLUSTERING_AVAILABLE = True
except ImportError:
    _TOPIC_CLUSTERING_AVAILABLE = False

__all__ = [
    # Content fetcher
    "FetchedContent",
    "fetch_url",
    "parse_html",
    # Content length
    "LengthResult",
    "LengthStatus",
    "analyze_length",
    "compare_lengths",
    "get_content_types",
    "get_targets",
    # Content scrubber
    "EmDashReplacement",
    "ScrubResult",
    "scrub_content",
    # Keywords
    "KeywordResult",
    "StuffingDetail",
    "StuffingRisk",
    "analyze_keywords",
    # Readability
    "ReadabilityResult",
    "analyze_readability",
    # Search intent
    "IntentResult",
    "SearchIntent",
    "analyze_intent",
    # SEO score
    "SEOResult",
    "analyze_seo",
    # Writing standards
    "WritingIssue",
    "WritingStandardsResult",
    "analyze_writing_standards",
]

# Add topic clustering exports if available
if _TOPIC_CLUSTERING_AVAILABLE:
    __all__.extend([
        "LSIKeywords",
        "TopicCluster",
        "TopicClusteringResult",
        "analyze_topics",
    ])
