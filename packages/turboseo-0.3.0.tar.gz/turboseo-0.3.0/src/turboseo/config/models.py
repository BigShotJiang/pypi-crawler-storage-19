"""
Configuration models for TurboSEO.
"""

from pydantic import BaseModel, Field


class ThresholdSettings(BaseModel):
    """Threshold settings for analyzers."""

    # Readability
    min_readability_score: int = Field(default=60, description="Minimum readability score")
    target_flesch_min: int = Field(default=60, description="Target Flesch Reading Ease minimum")
    target_flesch_max: int = Field(default=70, description="Target Flesch Reading Ease maximum")
    max_sentence_length: int = Field(default=25, description="Maximum sentence length before warning")

    # Keywords
    target_keyword_density: float = Field(default=1.5, description="Target keyword density %")
    max_keyword_density: float = Field(default=2.5, description="Maximum keyword density before warning")
    min_transition_density: float = Field(default=0.5, description="Minimum transitions per 100 words")

    # Content
    min_word_count: int = Field(default=300, description="Minimum word count")
    max_word_count: int = Field(default=5000, description="Maximum word count")

    # Writing standards
    strict_mode: bool = Field(default=False, description="Use stricter thresholds for writing checks")


class KeywordSettings(BaseModel):
    """Keyword configuration for the project."""

    primary: list[str] = Field(default_factory=list, description="Primary keywords to focus on")
    secondary: list[str] = Field(default_factory=list, description="Secondary keywords")
    avoid: list[str] = Field(default_factory=list, description="Words/phrases to avoid")


class ContentSettings(BaseModel):
    """Content settings for the project."""

    default_type: str = Field(default="blog_post", description="Default content type")
    target_audience: str = Field(default="general", description="Target audience description")
    writing_style: str = Field(default="professional", description="Writing style description")
    tone: str = Field(default="informative", description="Content tone")


class ProjectConfig(BaseModel):
    """Complete project configuration."""

    # Project info
    name: str = Field(description="Project name")
    description: str = Field(default="", description="Project description")
    url: str = Field(default="", description="Project website URL")

    # Settings
    thresholds: ThresholdSettings = Field(default_factory=ThresholdSettings)
    keywords: KeywordSettings = Field(default_factory=KeywordSettings)
    content: ContentSettings = Field(default_factory=ContentSettings)

    # Context (from webpage crawl or manual)
    context: str = Field(default="", description="Project context/background info")
