"""
TurboSEO Configuration System

Project-based configuration for customizing TurboSEO behavior.
"""

from turboseo.config.loader import (
    create_gitignore_entry,
    find_project_root,
    get_config_dir,
    get_global_dir,
    load_config,
    save_config,
)
from turboseo.config.models import (
    ContentSettings,
    KeywordSettings,
    ProjectConfig,
    ThresholdSettings,
)
from turboseo.config.projects import (
    ProjectInfo,
    add_project,
    get_project,
    list_projects,
    remove_project,
)

__all__ = [
    # Models
    "ProjectConfig",
    "ThresholdSettings",
    "KeywordSettings",
    "ContentSettings",
    # Loader
    "load_config",
    "save_config",
    "find_project_root",
    "get_config_dir",
    "get_global_dir",
    "create_gitignore_entry",
    # Projects
    "ProjectInfo",
    "list_projects",
    "add_project",
    "remove_project",
    "get_project",
]
