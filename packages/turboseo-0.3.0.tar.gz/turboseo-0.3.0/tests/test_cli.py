"""Tests for TurboSEO CLI."""

from click.testing import CliRunner

from turboseo.cli.main import cli


def test_cli_version():
    """Test version command."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "turboseo" in result.output
    assert "version" in result.output


def test_cli_help():
    """Test help output."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "TurboSEO" in result.output
    assert "check" in result.output
    assert "analyze" in result.output
    # New commands
    assert "init" in result.output
    assert "config" in result.output
    assert "projects" in result.output


def test_cli_init_help():
    """Test init command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["init", "--help"])
    assert result.exit_code == 0
    assert "Initialize" in result.output
    assert "--name" in result.output
    assert "--url" in result.output


def test_cli_config_help():
    """Test config command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["config", "--help"])
    assert result.exit_code == 0
    assert "View or modify" in result.output


def test_cli_projects_help():
    """Test projects command help."""
    runner = CliRunner()
    result = runner.invoke(cli, ["projects", "--help"])
    assert result.exit_code == 0
    assert "Manage" in result.output
    assert "list" in result.output
    assert "add" in result.output
    assert "remove" in result.output
