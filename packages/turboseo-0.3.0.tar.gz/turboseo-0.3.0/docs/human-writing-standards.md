# Human writing standards

TurboSEO detects AI-sounding writing patterns based on [Wikipedia's "Signs of AI Writing"](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing) guidelines. This document explains what patterns are detected and how to fix them.

## Scoring

Content starts at 100 points. Points are deducted for each issue found:

| Severity | Deduction | Strict Mode |
|----------|-----------|-------------|
| High | -4 points | -5 points |
| Medium | -2 points | -3 points |
| Low | -1 point | -2 points |

### Grades

| Score | Grade | Meaning |
|-------|-------|---------|
| 90-100 | A | Sounds human - ready to publish |
| 80-89 | B | Minor AI tells - quick fixes needed |
| 70-79 | C | Noticeable patterns - revision needed |
| 60-69 | D | Obvious AI writing - significant rewrite |
| <60 | F | Clearly AI-generated - full rewrite |

## Pattern categories

### 1. AI vocabulary

Certain words are rarely used by human writers but appear frequently in AI-generated content. Each word has a weight based on how strongly it signals AI writing.

**High-weight words (4-5 points):**
- delve, delving
- tapestry
- testament
- multifaceted
- paramount
- beacon
- embark, embarking
- garner, garnered
- underscore, underscores
- realm, realms
- ever-evolving
- game-changer

**Medium-weight words (3 points):**
- crucial
- robust
- leverage, leveraging
- vibrant
- resonate, resonates
- nuanced
- elevate

**Lower-weight words (2 points):**
- comprehensive
- enhance, enhanced
- landscape (used abstractly)
- navigate (used metaphorically)
- journey (used metaphorically)

**Alternatives provided:**

The analyzer suggests replacements for each word:

| AI Word | Alternatives |
|---------|--------------|
| delve | explore, examine, look at, dig into |
| tapestry | mix, combination, variety, collection |
| pivotal | important, key, critical, major |
| leverage | use, apply, take advantage of |
| seamless | smooth, easy, integrated, effortless |
| groundbreaking | new, innovative, first, novel |

### 2. Puffery patterns

Phrases that sound impressive but lack substance:

| Pattern | Weight | Fix |
|---------|--------|-----|
| "stands as a testament" | 10 | Replace with "shows", "proves", "demonstrates" |
| "plays a vital/crucial role" | 8 | State the specific impact |
| "rich tapestry/heritage" | 8 | Describe specifically or use "mix of" |
| "enduring legacy" | 8 | Be specific about the actual result |
| "continues to captivate" | 8 | Describe what it does and for whom |
| "groundbreaking approach" | 8 | Explain what makes it new |
| "nestled in" | 6 | Replace with "located in" or just "in" |
| "deeply rooted" | 6 | Be specific about the connection |
| "boasts a" | 5 | Replace with "has" or "offers" |
| "at the forefront" | 5 | Be specific about leadership |
| "world-renowned" | 5 | Explain who recognizes it and why |

### 3. Superficial analysis

Sentence-ending phrases that pad content without adding value:

| Pattern | Weight | Fix |
|---------|--------|-----|
| ", highlighting the importance..." | 8 | Remove phrase, state importance directly |
| ", emphasizing the significance..." | 8 | Remove phrase, be direct |
| ", underscoring the need..." | 8 | State the point directly |
| ", showcasing..." | 6 | Describe in a new sentence |
| ", demonstrating..." | 5 | State directly |
| ", ensuring..." | 5 | Make it a separate point |
| ", fostering..." | 5 | Describe how it encourages |
| ", reflecting..." | 5 | Explain the connection |

**Before:**
> The company launched a new product, highlighting the importance of innovation in today's market.

**After:**
> The company launched a new product. Innovation matters in today's market because [specific reason].

### 4. Structural red flags

Formulaic patterns that scream "AI wrote this":

| Pattern | Weight | Fix |
|---------|--------|-----|
| "In conclusion,", "Overall," | 10 | Just conclude directly |
| "Despite X, Y faces challenges" | 12 | Be specific about challenges |
| "Not only X but also Y" | 8 | Simplify to "X and Y" |
| "It's not just about X, it's..." | 8 | State your point directly |
| "cannot be overstated" | 10 | State the specific importance |
| "It is important to note" | 6 | Just state the point |
| "This is where X comes in" | 5 | Introduce the solution directly |

**Before:**
> In conclusion, the importance of SEO cannot be overstated.

**After:**
> SEO drives 53% of website traffic. Without it, your content stays invisible.

### 5. Formatting issues

**Em-dash overuse:**
- Threshold: More than 5 em-dashes per 1000 words
- Weight: Medium
- Fix: Use commas, periods, or parentheses instead

**Title case in headings:**
- Detected in markdown headings (## Like This Heading)
- Weight: Low
- Fix: Use sentence case (## Like this heading)

## Rule of three detection

AI often produces lists of exactly three items. While not always bad, overuse is suspicious:

- Three adjectives in a row
- Three examples consistently
- Three bullet points per section

## Tips for human-sounding content

### Do:
- Use simple, direct language
- Be specific instead of general
- Show, don't tell
- Vary sentence structure
- Include personal observations
- Use contractions naturally

### Don't:
- Start sentences with "It is important to note"
- Use the same transition words repeatedly
- End sentences with "-ing" phrases that summarize
- Announce what you're about to say ("In this article, we will...")
- Use corporate buzzwords

## Checking your content

```bash
# Quick check
turboseo check article.md

# Strict mode for higher standards
turboseo check article.md --strict

# Get detailed JSON for each issue
turboseo check article.md --json | jq '.issues[]'
```

## Target scores by use case

| Content Type | Minimum Score |
|--------------|---------------|
| Published articles | 85+ |
| Blog posts | 80+ |
| Product descriptions | 75+ |
| Internal documentation | 70+ |
