# TurboSEO Documentation

TurboSEO is an open-source SEO content toolkit that helps you write content that ranks—and sounds human.

## What makes TurboSEO different?

Most SEO tools help you optimize for search engines. TurboSEO also optimizes for **not sounding like AI wrote it**.

Based on [Wikipedia's "Signs of AI Writing"](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing) guidelines, TurboSEO detects patterns that make content sound machine-generated and provides actionable suggestions to fix them.

## Documentation

| Document | Description |
|----------|-------------|
| [Getting Started](getting-started.md) | Installation, setup, and first analysis |
| [Human Writing Standards](human-writing-standards.md) | Understanding AI patterns and scoring |
| [CLI Reference](cli-reference.md) | Command-line interface documentation |
| [Claude Code Integration](claude-code-integration.md) | Slash commands and agents |
| [Analyzers](analyzers.md) | Python module reference |

## Key features

- **Human Writing Score** (0-100) - Detects AI-sounding patterns with specific suggestions
- **SEO Analysis** - Keywords, readability, structure, and meta tag analysis
- **CLI Tool** - Quick analysis from your terminal
- **Claude Code Integration** - 10 slash commands and 7 specialized agents
- **No paid APIs** - Core features work without subscriptions

## Quick example

```bash
# Install
pip install turboseo

# Check if your content sounds human
turboseo check article.md

# Full SEO analysis
turboseo analyze article.md --keyword "podcast hosting"
```

## Scoring grades

| Score | Grade | Meaning |
|-------|-------|---------|
| 90-100 | A | Sounds human |
| 80-89 | B | Minor AI tells |
| 70-79 | C | Noticeable AI patterns |
| 60-69 | D | Obvious AI writing |
| <60 | F | Clearly AI-generated |

## Architecture

```
turboseo/
├── src/turboseo/
│   ├── analyzers/        # 7 analysis modules
│   │   ├── writing_standards.py  # AI pattern detection
│   │   ├── readability.py        # Readability metrics
│   │   ├── keywords.py           # Keyword analysis
│   │   ├── seo_score.py          # Composite scoring
│   │   ├── search_intent.py      # Intent classification
│   │   ├── content_fetcher.py    # URL parsing
│   │   └── content_length.py     # Length benchmarks
│   └── cli/
│       └── main.py               # CLI commands
├── .claude/
│   ├── commands/         # 10 slash commands
│   └── agents/           # 7 AI agents
└── tests/                # 264 tests, 83% coverage
```

## License

MIT License - see [LICENSE](../LICENSE) for details.
