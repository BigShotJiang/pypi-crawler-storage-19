# Copyright 2025 Bosutech XXI S.L.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from collections.abc import Sequence
from enum import Enum
from typing import Annotated, Any, Generic, Literal, TypeVar
from uuid import UUID

import pydantic
from pydantic import AliasChoices, BaseModel, Discriminator, Tag, field_validator, model_validator
from pydantic.config import ConfigDict
from typing_extensions import Self

from .common import FieldTypeName, Paragraph
from .metadata import ResourceProcessingStatus
from .utils import DateTime, SlugString

F = TypeVar("F", bound=BaseModel)


class And(BaseModel, Generic[F], extra="forbid"):
    """AND of other expressions"""

    operands: Sequence[F] = pydantic.Field(
        title="And Operands",
        serialization_alias="and",
        validation_alias=AliasChoices("operands", "and"),
        min_length=1,
    )

    @pydantic.model_serializer
    def serialize_boolean(self, info: pydantic.SerializationInfo) -> dict[str, Any]:
        return {"and": [op.model_dump(exclude_unset=info.exclude_unset) for op in self.operands]}


class Or(BaseModel, Generic[F], extra="forbid"):
    """OR of other expressions"""

    operands: Sequence[F] = pydantic.Field(
        title="Or Operands",
        serialization_alias="or",
        validation_alias=AliasChoices("operands", "or"),
        min_length=1,
    )

    @pydantic.model_serializer
    def serialize_boolean(self, info: pydantic.SerializationInfo) -> dict[str, Any]:
        return {"or": [op.model_dump(exclude_unset=info.exclude_unset) for op in self.operands]}


class Not(BaseModel, Generic[F], extra="forbid"):
    """NOT another expression"""

    operand: F = pydantic.Field(
        title="Not Operand", serialization_alias="not", validation_alias=AliasChoices("operand", "not")
    )

    @pydantic.model_serializer
    def serialize_boolean(self, info: pydantic.SerializationInfo) -> dict[str, Any]:
        return {"not": self.operand.model_dump(exclude_unset=info.exclude_unset)}


class FilterProp(BaseModel):
    prop: Any

    @model_validator(mode="after")
    def set_discriminator(self) -> Self:
        # Ensure discriminator is explicitly set so it's always serialized
        self.prop = self.prop
        return self


class Resource(FilterProp, extra="forbid"):
    """Matches all fields of a resource given its id or slug"""

    model_config = ConfigDict(title="Resource Filter")

    prop: Literal["resource"] = "resource"
    id: str | None = pydantic.Field(default=None, description="UUID of the resource to match")
    slug: SlugString | None = pydantic.Field(default=None, description="Slug of the resource to match")

    @field_validator("id", mode="after")
    def validate_id(cls, v: str) -> str:
        if v is not None:
            try:
                UUID(v)
            except ValueError:
                raise ValueError("Invalid UUID")
        return v

    @model_validator(mode="after")
    def single_field(self) -> Self:
        if self.id is not None and self.slug is not None:
            raise ValueError("Must set only one of `id` and `slug`")
        if self.id is None and self.slug is None:
            raise ValueError("Must set `id` or `slug`")
        return self


class Field(FilterProp, extra="forbid"):
    """Matches a field or set of fields"""

    prop: Literal["field"] = "field"
    type: FieldTypeName = pydantic.Field(description="Type of the field to match, ")
    name: str | None = pydantic.Field(
        default=None,
        title="Field Filter",
        description="Name of the field to match. If blank, matches all fields of the given type",
    )


class Keyword(FilterProp, extra="forbid"):
    """Matches all fields that contain a keyword"""

    prop: Literal["keyword"] = "keyword"
    word: str = pydantic.Field(description="Keyword to find")


class DateCreated(FilterProp, extra="forbid"):
    """Matches all fields created in a date range"""

    prop: Literal["created"] = "created"
    since: DateTime | None = pydantic.Field(
        default=None, description="Start of the date range. Leave blank for unbounded"
    )
    until: DateTime | None = pydantic.Field(
        default=None, description="End of the date range. Leave blank for unbounded"
    )

    @model_validator(mode="after")
    def some_set(self) -> Self:
        if self.since is None and self.until is None:
            raise ValueError("Must set `since` or `until` (or both)")
        return self


class DateModified(FilterProp, extra="forbid"):
    """Matches all fields modified in a date range"""

    prop: Literal["modified"] = "modified"
    since: DateTime | None = pydantic.Field(
        default=None, description="Start of the date range. Leave blank for unbounded"
    )
    until: DateTime | None = pydantic.Field(
        default=None, description="End of the date range. Leave blank for unbounded"
    )

    @model_validator(mode="after")
    def some_set(self) -> Self:
        if self.since is None and self.until is None:
            raise ValueError("Must set `since` or `until` (or both)")
        return self


class Label(FilterProp, extra="forbid"):
    """Matches fields/paragraphs with a label (or labelset)"""

    prop: Literal["label"] = "label"
    labelset: str = pydantic.Field(description="The ID of the labelset to match")
    label: str | None = pydantic.Field(
        default=None,
        description="The label to match. If blank, matches all labels in the given labelset",
    )


class ResourceMimetype(FilterProp, extra="forbid"):
    """Matches resources with a mimetype.

    The mimetype of a resource can be assigned independently of the mimetype of its fields.
    In resources with multiple fields, you may prefer to use `field_mimetype`"""

    prop: Literal["resource_mimetype"] = "resource_mimetype"
    type: str = pydantic.Field(
        description="Type of the mimetype to match. e.g: In image/jpeg, type is image"
    )
    subtype: str | None = pydantic.Field(
        default=None,
        description=(
            "Type of the mimetype to match. e.g: In image/jpeg, subtype is jpeg."
            "Leave blank to match all mimetype of the type"
        ),
    )


class FieldMimetype(FilterProp, extra="forbid"):
    """Matches fields with a mimetype"""

    prop: Literal["field_mimetype"] = "field_mimetype"
    type: str = pydantic.Field(
        description="Type of the mimetype to match. e.g: In image/jpeg, type is image"
    )
    subtype: str | None = pydantic.Field(
        default=None,
        description=(
            "Type of the mimetype to match. e.g: In image/jpeg, subtype is jpeg."
            "Leave blank to match all mimetype of the type"
        ),
    )


class Entity(FilterProp, extra="forbid"):
    """Matches fields that contains a detected entity"""

    prop: Literal["entity"] = "entity"
    subtype: str = pydantic.Field(description="Type of the entity. e.g: PERSON")
    value: str | None = pydantic.Field(
        default=None,
        description="Value of the entity. e.g: Anna. If blank, matches any entity of the given type",
    )


class Language(FilterProp, extra="forbid"):
    """Matches the language of the field"""

    prop: Literal["language"] = "language"
    only_primary: bool = pydantic.Field(
        default=False,
        description="Match only the primary language of the document. By default, matches any language that appears in the document",
    )
    language: str = pydantic.Field(description="The code of the language to match, e.g: en")


class OriginTag(FilterProp, extra="forbid"):
    """Matches all fields with a given origin tag"""

    prop: Literal["origin_tag"] = "origin_tag"
    tag: str = pydantic.Field(description="The tag to match")


class OriginMetadata(FilterProp, extra="forbid"):
    """Matches metadata from the origin"""

    prop: Literal["origin_metadata"] = "origin_metadata"
    field: str = pydantic.Field(title="Origin Metadata Field", description="Metadata field")
    value: str | None = pydantic.Field(
        default=None,
        description="Value of the metadata field. If blank, matches any document with the given metadata field set (to any value)",
    )


class OriginPath(FilterProp, extra="forbid"):
    """Matches the origin path"""

    prop: Literal["origin_path"] = "origin_path"
    prefix: str | None = pydantic.Field(
        default=None,
        description=(
            "Prefix of the path, matches all paths under this prefix"
            "e.g: `prefix=/dir/` matches `/dir` and `/dir/a/b` but not `/dirrrr`"
        ),
    )


class OriginSource(FilterProp, extra="forbid"):
    """Matches the origin source id"""

    prop: Literal["origin_source"] = "origin_source"
    id: str | None = pydantic.Field(default=None, description=("Source ID"))


class OriginCollaborator(FilterProp, extra="forbid"):
    """Matches the origin collaborators"""

    prop: Literal["origin_collaborator"] = "origin_collaborator"
    collaborator: str = pydantic.Field(description=("Collaborator"))


class Generated(FilterProp, extra="forbid"):
    """Matches if the field was generated by the given source"""

    prop: Literal["generated"] = "generated"
    by: Literal["data-augmentation"] = pydantic.Field(
        description="Generator for this field. Currently, only data-augmentation is supported"
    )
    da_task: str | None = pydantic.Field(
        default=None, description="Matches field generated by an specific DA task, given its prefix"
    )


class Kind(FilterProp, extra="forbid"):
    """Matches paragraphs of a certain kind"""

    prop: Literal["kind"] = "kind"
    kind: Paragraph.TypeParagraph = pydantic.Field(description="The kind of paragraph to match")


class Status(FilterProp, extra="forbid"):
    """Matches resource in a certain processing status"""

    prop: Literal["status"] = "status"
    status: ResourceProcessingStatus = pydantic.Field(description="The status of the resource")


# The discriminator function is optional, everything works without it.
# We implement it because it makes pydantic produce more user-friendly errors
def filter_discriminator(v: Any) -> str | None:
    if isinstance(v, dict):
        if "and" in v:
            return "and"
        elif "or" in v:
            return "or"
        elif "not" in v:
            return "not"
        else:
            return v.get("prop")

    if isinstance(v, And):
        return "and"
    elif isinstance(v, Or):
        return "or"
    elif isinstance(v, Not):
        return "not"
    else:
        return getattr(v, "prop", None)


FieldFilterExpression = Annotated[
    Annotated[And["FieldFilterExpression"], Tag("and")]
    | Annotated[Or["FieldFilterExpression"], Tag("or")]
    | Annotated[Not["FieldFilterExpression"], Tag("not")]
    | Annotated[Resource, Tag("resource")]
    | Annotated[Field, Tag("field")]
    | Annotated[Keyword, Tag("keyword")]
    | Annotated[DateCreated, Tag("created")]
    | Annotated[DateModified, Tag("modified")]
    | Annotated[Label, Tag("label")]
    | Annotated[ResourceMimetype, Tag("resource_mimetype")]
    | Annotated[FieldMimetype, Tag("field_mimetype")]
    | Annotated[Entity, Tag("entity")]
    | Annotated[Language, Tag("language")]
    | Annotated[OriginTag, Tag("origin_tag")]
    | Annotated[OriginMetadata, Tag("origin_metadata")]
    | Annotated[OriginPath, Tag("origin_path")]
    | Annotated[OriginSource, Tag("origin_source")]
    | Annotated[OriginCollaborator, Tag("origin_collaborator")]
    | Annotated[Generated, Tag("generated")],
    Discriminator(filter_discriminator),
]

ParagraphFilterExpression = Annotated[
    Annotated[And["ParagraphFilterExpression"], Tag("and")]
    | Annotated[Or["ParagraphFilterExpression"], Tag("or")]
    | Annotated[Not["ParagraphFilterExpression"], Tag("not")]
    | Annotated[Label, Tag("label")]
    | Annotated[Kind, Tag("kind")],
    Discriminator(filter_discriminator),
]

ResourceFilterExpression = Annotated[
    Annotated[And["ResourceFilterExpression"], Tag("and")]
    | Annotated[Or["ResourceFilterExpression"], Tag("or")]
    | Annotated[Not["ResourceFilterExpression"], Tag("not")]
    | Annotated[Resource, Tag("resource")]
    | Annotated[DateCreated, Tag("created")]
    | Annotated[DateModified, Tag("modified")]
    | Annotated[Label, Tag("label")]
    | Annotated[ResourceMimetype, Tag("resource_mimetype")]
    | Annotated[Language, Tag("language")]
    | Annotated[OriginTag, Tag("origin_tag")]
    | Annotated[OriginMetadata, Tag("origin_metadata")]
    | Annotated[OriginPath, Tag("origin_path")]
    | Annotated[OriginSource, Tag("origin_source")]
    | Annotated[OriginCollaborator, Tag("origin_collaborator")]
    | Annotated[Status, Tag("status")],
    Discriminator(filter_discriminator),
]


class FilterExpression(BaseModel, extra="forbid"):
    """Returns only documents that match this filter expression.
    Filtering examples can be found here: https://docs.nuclia.dev/docs/rag/advanced/search-filters

    This allows building complex filtering expressions and replaces the following parameters:
    `fields`, `filters`, `range_*`, `resource_filters`, `keyword_filters`.
    """

    class Operator(str, Enum):
        AND = "and"
        OR = "or"

    field: FieldFilterExpression | None = pydantic.Field(
        default=None, title="Field Filters", description="Filter to apply to fields"
    )
    paragraph: ParagraphFilterExpression | None = pydantic.Field(
        default=None, description="Filter to apply to each text block"
    )

    operator: Operator = pydantic.Field(
        default=Operator.AND,
        description=(
            "How to combine field and paragraph filters (default is AND)."
            "AND returns text blocks that match both filters."
            "OR returns text_blocks that match one of the two filters"
        ),
    )


class CatalogFilterExpression(BaseModel, extra="forbid"):
    """Returns only documents that match this filter expression.
    Filtering examples can be found here: https://docs.nuclia.dev/docs/rag/advanced/search-filters

    This allows building complex filtering expressions and replaces the following parameters:
    `filters`, `range_*`, `with_status`.
    """

    resource: ResourceFilterExpression = pydantic.Field(
        title="Resource filters", description="Filter to apply to resources"
    )
