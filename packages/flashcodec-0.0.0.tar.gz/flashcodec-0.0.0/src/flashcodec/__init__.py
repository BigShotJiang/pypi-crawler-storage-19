"""FlashCodec - placeholder package"""
