class QwakCommandException(Exception):
    pass
