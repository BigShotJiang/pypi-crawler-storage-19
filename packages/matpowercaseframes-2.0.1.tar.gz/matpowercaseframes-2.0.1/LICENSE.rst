AMES License

Copyright (c) 2020, Battelle Memorial Institute

Copyright 2007 - 2022: numerous others credited in:
https://github.com/ames-market/psst/AUTHORS.rst

Version 5.0, June 2020

https://github.com/ames-market

===============================================================================
MATPOWER Case Frames License

Copyright (c) 2022 by Muhammad Yasirroni from EPSLab, Universitas Gadjah Mada

MATPOWER Case Frames is the PSST fork from:
https://github.com/ames-market/psst

Latest commit: 703492fa85fc384f47603cc5a34dfccbce14e457

===============================================================================

TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

1. Battelle Memorial Institute (hereinafter Battelle) hereby grants
   permission to any person or entity lawfully obtaining a copy of
   this software and associated documentation files (hereinafter "the
   Software") to redistribute and use the Software in source and
   binary forms, with or without modification.  Such person or entity
   may use, copy, modify, merge, publish, distribute, sublicense,
   and/or sell copies of the Software, and may permit others to do so,
   subject to the following conditions:
   - Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimers.
   - Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in
     the documentation and/or other materials provided with the
     distribution.
   - Other than as used herein, neither the name Battelle Memorial
     Institute or Battelle may be used in any form whatsoever without
     the express written consent of Battelle.

2. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL BATTELLE OR
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
   OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

===============================================================================

DISCLAIMER

The Software was produced by Battelle under Contract No.
DE-AC05-76RL01830 with the Department of Energy.  The U.S. Government
is granted for itself and others acting on its behalf a nonexclusive,
paid-up, irrevocable worldwide license in this data to reproduce,
prepare derivative works, distribute copies to the public, perform
publicly and display publicly, and to permit others to do so.  The
specific term of the license can be identified by inquiry made to
Battelle or DOE.  Neither the United States nor the United States
Department of Energy, nor any of their employees, makes any warranty,
express or implied, or assumes any legal liability or responsibility
for the accuracy, completeness or usefulness of any data, apparatus,
product or process disclosed, or represents that its use would not
infringe privately owned rights.