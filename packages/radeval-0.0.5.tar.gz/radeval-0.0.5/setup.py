from setuptools import setup, find_packages

setup(
    name='RadEval',
    version='0.0.5',
    author='Jean-Benoit Delbrouck, Justin Xu, Xi Zhang',
    maintainer='Xi Zhang, JB Delbrouck',
    url='https://github.com/jbdel/RadEval',
    project_urls={
        'Bug Reports': 'https://github.com/jbdel/RadEval/issues',
        'Source': 'https://github.com/jbdel/RadEval',
        'Documentation': 'https://github.com/jbdel/RadEval/blob/main/README.md',
    },
    license='MIT',
    description='All-in-one metrics for evaluating AI-generated radiology text',
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3 :: Only',
    ],
    keywords=[
        'radiology',
        'evaluation',
        'natural language processing',
        'radiology report',
        'medical NLP',
        'clinical text generation',
        'LLM',
        'bioNLP',
        'chexbert',
        'radgraph',
        'medical AI'
    ],
    python_requires='>=3.9,<3.12',
    install_requires=[
        'torch==2.9.1',
        'transformers==4.57.3',
        'radgraph',
        'rouge_score',
        'bert-score==0.3.13',
        'scikit-learn>=1.8.0',
        'numpy<2',
        'medspacy',
        'stanza',
        'pillow==10.3.0',
        'sentencepiece==0.2.0', # for GREEN
        'datasets==2.19.0',
        'torchvision',
        'opencv-python==4.10.0.84',
        'matplotlib',
        'accelerate==0.30.1',
        'pandas'
    ],
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "RadEval.factual.SRRBert": ["*.json"],
    },
    zip_safe=False,
    )