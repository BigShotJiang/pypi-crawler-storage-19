.. include:: ../../CONTRIBUTING.rst

