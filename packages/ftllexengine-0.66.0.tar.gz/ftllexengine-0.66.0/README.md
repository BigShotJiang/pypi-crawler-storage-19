<!--
RETRIEVAL_HINTS:
  keywords: [ftllexengine, fluent, localization, i18n, l10n, ftl, translation, plurals, babel, cldr, python, parsing, currency, dates, thread-safe]
  answers: [what is ftllexengine, how to install, quick start, fluent python, localization library, currency parsing, date parsing, thread safety]
  related: [docs/QUICK_REFERENCE.md, docs/DOC_00_Index.md, docs/PARSING_GUIDE.md, docs/TERMINOLOGY.md]
-->

[![FTLLexEngine Art](https://raw.githubusercontent.com/resoltico/FTLLexEngine/main/images/FTLLexEngine.jpg)](https://github.com/resoltico/FTLLexEngine)

-----

[![PyPI](https://img.shields.io/pypi/v/ftllexengine.svg)](https://pypi.org/project/ftllexengine/)
[![Python 3.13+](https://img.shields.io/badge/python-3.13+-blue.svg)](https://www.python.org/downloads/)
[![codecov](https://codecov.io/github/resoltico/FTLLexEngine/graph/badge.svg?token=Q5KUGU3S3U)](https://codecov.io/github/resoltico/FTLLexEngine)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

-----

# FTLLexEngine

**Thread-safe localization with bidirectional parsing. Accept user input in any locale, get structured data back.**

Your customer types `"1 234,56"` in Latvia or `"1,234.56"` in the US. FTLLexEngine parses both to `Decimal('1234.56')`. When parsing fails, you get errors as data - not exceptions - so you can show helpful feedback.

Built on the [Fluent specification](https://projectfluent.org/) that powers Firefox. 200+ locales via Unicode CLDR.

---

## Why FTLLexEngine?

- **Bidirectional** - Format data for display *and* parse user input back to Python types
- **Thread-safe** - No global state. Serve 1000 concurrent requests without locale conflicts
- **Financial-grade** - `Decimal` precision throughout. No float rounding surprises
- **Introspectable** - Query what variables a message needs before you call it
- **Declarative grammar** - Plurals, gender, cases in `.ftl` files. Code stays clean

---

## Quickstart

```python
from ftllexengine import FluentBundle

bundle = FluentBundle("en_US")
bundle.add_resource("""
order = { $count ->
    [one]   1 coffee
   *[other] { $count } coffees
}
""")

result, _ = bundle.format_pattern("order", {"count": 5})
# "5 coffees"
```

---

## Table of Contents

- [Installation](#installation)
- [Your Cafe Speaks Every Language](#your-cafe-speaks-every-language)
- [Customers Type Prices. You Get Decimals.](#customers-type-prices-you-get-decimals)
- [100 Orders Per Second? No Problem.](#100-orders-per-second-no-problem)
- [Know What Your Messages Need](#know-what-your-messages-need)
- [When to Use FTLLexEngine](#when-to-use-ftllexengine)
- [Documentation](#documentation)
- [Contributing](#contributing)
- [License](#license)

---

## Installation

```bash
pip install ftllexengine[babel]
```

Or with uv:

```bash
uv add ftllexengine[babel]
```

**Requirements**: Python >= 3.13 | Babel >= 2.17

<details>
<summary>Parser-only installation (no Babel dependency)</summary>

```bash
pip install ftllexengine
```

**Works without Babel:**
- FTL syntax parsing (`parse_ftl()`, `serialize_ftl()`)
- AST manipulation and transformation
- Validation and introspection

**Requires Babel:**
- `FluentBundle` (locale-aware formatting)
- `FluentLocalization` (multi-locale fallback)
- Bidirectional parsing (numbers, dates, currency)

</details>

---

## Your Cafe Speaks Every Language

You run a coffee shop. "1 coffee" or "5 coffees" - simple in English. But your app goes global.

**The problem:** Polish has four plural forms. Arabic has six. Your if-statements turn into spaghetti.

**The solution:** Move grammar rules to `.ftl` files. Your code just passes data.

**cafe.ftl**
```fluent
order-message = { $count ->
    [0]     no coffees ordered
    [one]   1 coffee ordered
   *[other] { $count } coffees ordered
}

total = Total: { CURRENCY($amount, currency: "USD") }
```

```python
from pathlib import Path
from decimal import Decimal
from ftllexengine import FluentBundle

bundle = FluentBundle("en_US")
bundle.add_resource(Path("cafe.ftl").read_text())

result, _ = bundle.format_pattern("order-message", {"count": 5})
# "5 coffees ordered"

result, _ = bundle.format_pattern("total", {"amount": Decimal("18.75")})
# "Total: $18.75"
```

Now add Polish - four plural forms, zero code changes:

**cafe_pl.ftl**
```fluent
order-message = { $count ->
    [0]     brak kaw
    [one]   1 kawa
    [few]   { $count } kawy
    [many]  { $count } kaw
   *[other] { $count } kawy
}
```

```python
bundle = FluentBundle("pl_PL")
bundle.add_resource(Path("cafe_pl.ftl").read_text())

result, _ = bundle.format_pattern("order-message", {"count": 5})
# "5 kaw"

result, _ = bundle.format_pattern("order-message", {"count": 2})
# "2 kawy"
```

German, Japanese, Arabic - same pattern. Translators edit `.ftl` files. Developers ship features.

---

## Customers Type Prices. You Get Decimals.

A customer in Germany types their tip: `"5,00"`. A customer in the US types `"5.00"`. Both mean five dollars.

Most libraries only format *outbound* - they turn your data into display strings. FTLLexEngine works *both directions*.

```python
from decimal import Decimal
from ftllexengine.parsing import parse_currency, parse_decimal, parse_date

# American customer types a tip
tip_result, errors = parse_currency("$5.00", "en_US", default_currency="USD")
if not errors:
    tip, currency = tip_result  # (Decimal('5.00'), 'USD')

# German customer types a price
price, errors = parse_decimal("13,50", "de_DE")
# Decimal('13.50')

# Latvian format: space for thousands
price, errors = parse_decimal("1 234,56", "lv_LV")
# Decimal('1234.56')

# Dates work too
date_val, errors = parse_date("Jan 15, 2026", "en_US")
# datetime.date(2026, 1, 15)
```

**When parsing fails, you get errors - not exceptions:**

```python
price, errors = parse_decimal("five fifty", "en_US")
# price = None
# errors = (FluentParseError(...),)

# Show helpful feedback
if errors:
    print("Please enter a number like 5.50")
```

### Financial Calculations Stay Exact

Your cafe calculates bills. Float math fails you: `0.1 + 0.2 = 0.30000000000000004`.

FTLLexEngine uses `Decimal` throughout:

```python
from decimal import Decimal
from ftllexengine.parsing import parse_currency

tip_result, errors = parse_currency("$5.00", "en_US", default_currency="USD")
if not errors:
    tip, currency = tip_result  # (Decimal('5.00'), 'USD')

    subtotal = Decimal("13.50")  # 3 espressos at $4.50
    tax = subtotal * Decimal("0.08")  # 8% tax
    total = subtotal + tax + tip
    # Decimal('19.58') - exact, every time
```

---

## 100 Orders Per Second? No Problem.

Your cafe gets busy. Flask, FastAPI, Django - 100 concurrent requests, each customer in a different locale.

**The problem:** Python's `locale` module uses global state. Thread A sets German, Thread B reads it, chaos ensues.

**The solution:** FTLLexEngine uses isolated contexts. No global state. No locks you manage. No race conditions.

```python
from concurrent.futures import ThreadPoolExecutor
from ftllexengine.runtime.locale_context import LocaleContext

us_ctx = LocaleContext.create("en_US")
de_ctx = LocaleContext.create("de_DE")
jp_ctx = LocaleContext.create("ja_JP")

def format_receipt(amount, ctx):
    return ctx.format_currency(amount, currency="USD")

with ThreadPoolExecutor(max_workers=100) as executor:
    futures = [
        executor.submit(format_receipt, 1234.50, us_ctx),  # "$1,234.50"
        executor.submit(format_receipt, 1234.50, de_ctx),  # "1.234,50 $"
        executor.submit(format_receipt, 1234.50, jp_ctx),  # "$1,234.50"
    ]
    receipts = [f.result() for f in futures]
```

Each `LocaleContext` is a frozen dataclass. Immutable. Thread-safe by design.

`FluentBundle` is also thread-safe. All public methods use an internal readers-writer lock:
- Multiple threads can format messages simultaneously (read lock)
- Adding resources or functions acquires exclusive access (write lock)
- You don't manage any of this - it just works

---

## Know What Your Messages Need

Your AI agent generates order confirmations. Before it calls `format_pattern()`, it needs to know: *what variables does this message require?*

```python
from ftllexengine import FluentBundle

bundle = FluentBundle("en_US")
bundle.add_resource("""
order-confirmation = { $customer_name }, your order of { $quantity }
    { $quantity ->
        [one] coffee
       *[other] coffees
    } is ready. Total: { CURRENCY($total, currency: "USD") }
""")

info = bundle.introspect_message("order-confirmation")

info.get_variable_names()
# frozenset({'customer_name', 'quantity', 'total'})

info.get_function_names()
# frozenset({'CURRENCY'})

info.has_selectors
# True (uses plural selection)

info.requires_variable("customer_name")
# True
```

**Use cases:**
- AI agents verify they have all required data before formatting
- Form builders auto-generate input fields from message templates
- Linters catch missing variables at build time, not runtime

---

## When to Use FTLLexEngine

### Use It When:

| Scenario | Why FTLLexEngine |
| :--- | :--- |
| **Parsing user input** | Errors as data, not exceptions. Show helpful feedback. |
| **Financial calculations** | `Decimal` precision. No float rounding bugs. |
| **Web servers** | Thread-safe. No global locale state. |
| **Complex plurals** | Polish has 4 forms. Arabic has 6. Handle them declaratively. |
| **Multi-locale apps** | 200+ locales. CLDR-compliant. |
| **AI integrations** | Introspect messages before formatting. |
| **Content/code separation** | Translators edit `.ftl` files. Developers ship code. |

### Use Something Simpler When:

| Scenario | Why Skip It |
| :--- | :--- |
| **Single locale, no user input** | `f"{value:,.2f}"` is enough |
| **No grammar logic** | No plurals, no conditionals |
| **Zero dependencies required** | You need pure stdlib |

---

## Documentation

| Resource | Description |
|:---------|:------------|
| [Quick Reference](docs/QUICK_REFERENCE.md) | Copy-paste patterns for common tasks |
| [API Reference](docs/DOC_00_Index.md) | Complete class and function documentation |
| [Parsing Guide](docs/PARSING_GUIDE.md) | Bidirectional parsing deep-dive |
| [Terminology](docs/TERMINOLOGY.md) | Fluent and FTLLexEngine concepts |
| [Examples](examples/) | Working code you can run |

---

## Contributing

Contributions welcome. See [CONTRIBUTING.md](CONTRIBUTING.md) for setup and guidelines.

---

## License

MIT License - See [LICENSE](LICENSE).

Implements the [Fluent Specification](https://github.com/projectfluent/fluent/blob/master/spec/fluent.ebnf) (Apache 2.0).

**Legal**: [PATENTS.md](PATENTS.md) | [NOTICE](NOTICE)
