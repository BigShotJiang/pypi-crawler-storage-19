"""Estimator algorithms."""
