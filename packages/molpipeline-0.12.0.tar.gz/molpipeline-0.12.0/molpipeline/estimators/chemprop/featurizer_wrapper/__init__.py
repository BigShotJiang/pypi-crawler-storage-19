"""Wrapper for Chemprop Featurizer."""
