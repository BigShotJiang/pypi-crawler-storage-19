"""Module for model calibration."""
