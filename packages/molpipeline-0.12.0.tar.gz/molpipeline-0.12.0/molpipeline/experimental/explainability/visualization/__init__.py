"""Visualization module for explainability."""
