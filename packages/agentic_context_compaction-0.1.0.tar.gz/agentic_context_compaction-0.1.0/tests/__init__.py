"""Tests for context-compactor."""
