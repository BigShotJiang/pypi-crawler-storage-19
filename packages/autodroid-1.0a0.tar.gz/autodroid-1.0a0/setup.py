from setuptools import setup, find_packages

setup(
    name="autodroid",
    version="1.0A",
    packages=find_packages(),
    install_requires=[],
)
