import os

TEST_BUCKET = os.getenv("GCSFS_TEST_BUCKET", "gcsfs_test")
TEST_VERSIONED_BUCKET = os.getenv("GCSFS_TEST_VERSIONED_BUCKET", "gcsfs_test_versioned")
TEST_HNS_BUCKET = os.getenv("GCSFS_HNS_TEST_BUCKET", "gcsfs_hns_test")
TEST_ZONAL_BUCKET = os.getenv("GCSFS_ZONAL_TEST_BUCKET", "gcsfs_zonal_test")
TEST_HNS_BUCKET = os.getenv("GCSFS_HNS_TEST_BUCKET", "gcsfs_hns_test")
TEST_PROJECT = os.getenv("GCSFS_TEST_PROJECT", "project")
TEST_REQUESTER_PAYS_BUCKET = f"{TEST_BUCKET}_req_pay"
TEST_KMS_KEY = os.getenv(
    "GCSFS_TEST_KMS_KEY",
    f"projects/{TEST_PROJECT}/locations/us/keyRings/gcsfs_test/cryptKeys/gcsfs_test_key",
)

# =============================================================================
# Performance Benchmark Settings
# =============================================================================
BENCHMARK_FILTER = os.environ.get("GCSFS_BENCHMARK_FILTER", "")
BENCHMARK_SKIP_TESTS = os.environ.get("GCSFS_BENCHMARK_SKIP_TESTS", "true").lower() in (
    "true",
    "1",
)
