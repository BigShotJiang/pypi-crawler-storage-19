import os
import json
import glob
import re

def find_notebooks(root_dir):
    return glob.glob(os.path.join(root_dir, 'etc', '**', '*.ipynb'), recursive=True)

def resolve_path(notebook_path, file_path):
    # notebook_path is relative to project root, e.g., etc/subdir/nb.ipynb
    # file_path is relative to notebook, e.g., ../../data/file.csv
    
    nb_dir = os.path.dirname(notebook_path)
    joined = os.path.join(nb_dir, file_path)
    norm = os.path.normpath(joined)
    
    return norm

def extract_paths_from_output(text):
    paths = []
    # Pattern for SHA1 hash (40 hex chars)
    # We look for lines containing a hash and a path
    
    # Replace literal \n with actual newline if it looks like a repr
    if '\n' in text:
        text = text.replace('\n', '\n')
        
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Regex for 40 hex chars
        match = re.search(r'\b([0-9a-f]{40})\b', line)
        if match:
            # Found a hash. The rest of the line might be the path.
            # Remove the hash and whitespace
            rest = line.replace(match.group(1), '').strip()
            
            # Clean up rest
            # Remove surrounding quotes if present
            rest = rest.strip('"\'')
            rest = rest.strip() # Strip again after removing quotes
            
            if rest:
                paths.append(rest)
    return paths

def parse_notebook(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        try:
            nb = json.load(f)
        except json.JSONDecodeError:
            return [], []

    inputs = []
    outputs = []
    
    # scan for tags first
    for cell in nb.get('cells', []):
        tags = cell.get('metadata', {}).get('tags', [])
        
        found_paths = []
        if 'indata' in tags or 'outdata' in tags:
            # Check outputs
            for output in cell.get('outputs', []):
                if output.get('output_type') == 'stream':
                    text = "".join(output.get('text', []))
                    found_paths.extend(extract_paths_from_output(text))
                elif output.get('output_type') == 'execute_result':
                     data = output.get('data', {})
                     if 'text/plain' in data:
                         text = "".join(data['text/plain'])
                         found_paths.extend(extract_paths_from_output(text))
            
            if 'indata' in tags:
                inputs.extend(found_paths)
            if 'outdata' in tags:
                outputs.extend(found_paths)

    # If no tags found, try section headers fallback
    current_section = None
    for cell in nb.get('cells', []):
        if cell['cell_type'] == 'markdown':
            source = "".join(cell.get('source', [])).lower()
            if 'data dependencies' in source or 'dependencies' in source or 'input' in source:
                current_section = 'indata'
            elif 'export artefact' in source or 'output' in source:
                current_section = 'outdata'
            elif source.startswith('#'):
                pass
        
        elif cell['cell_type'] == 'code':
            # Check if we already processed this cell via tags
            tags = cell.get('metadata', {}).get('tags', [])
            if 'indata' in tags or 'outdata' in tags:
                continue # Already processed

            # Look for hash outputs
            found_paths = []
            for output in cell.get('outputs', []):
                if output.get('output_type') == 'stream':
                    text = "".join(output.get('text', []))
                    found_paths.extend(extract_paths_from_output(text))
                elif output.get('output_type') == 'execute_result':
                     data = output.get('data', {})
                     if 'text/plain' in data:
                         text = "".join(data['text/plain'])
                         found_paths.extend(extract_paths_from_output(text))
            
            if found_paths:
                # If no section defined yet, assume indata (inputs usually come first)
                section = current_section if current_section else 'indata'
                
                if section == 'indata':
                    inputs.extend(found_paths)
                elif section == 'outdata':
                    outputs.extend(found_paths)

    return inputs, outputs

def generate_dot(graph):
    lines = []
    lines.append('digraph DataFlow {')
    lines.append('  rankdir=LR;')
    lines.append('  node [shape=box, style=filled, fillcolor=white];')
    
    for nb_path, (inputs, outputs) in graph.items():
        if not inputs and not outputs:
            continue
            
        lines.append(f'  "{nb_path}" [fillcolor="#E0F7FA", color="#006064"];')
        
        for inp in inputs:
            # resolve path
            full_inp = resolve_path(nb_path, inp)
            lines.append(f'  "{full_inp}" -> "{nb_path}";')
            
        for out in outputs:
            full_out = resolve_path(nb_path, out)
            lines.append(f'  "{nb_path}" -> "{full_out}";')
            
    lines.append('}')
    return "\n".join(lines)
