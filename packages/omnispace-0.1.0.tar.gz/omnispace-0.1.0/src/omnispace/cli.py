import argparse
import sys
import shutil
import subprocess
import os
from .graph import find_notebooks, parse_notebook, generate_dot

def main():
    parser = argparse.ArgumentParser(description="Generate data dependency graph from notebooks.")
    parser.add_argument("root_dir", nargs="?", default=".", help="Root directory to scan (default: current directory)")
    parser.add_argument("-o", "--output", help="Output DOT file path")
    parser.add_argument("--svg", help="Output SVG file path (requires graphviz 'dot' installed)")
    
    args = parser.parse_args()
    
    notebooks = find_notebooks(args.root_dir)
    graph = {}
    
    for nb in notebooks:
        # nb is relative to root, e.g. ./etc/file.ipynb
        # normalize to remove ./
        nb_rel = os.path.normpath(nb)
        inputs, outputs = parse_notebook(nb)
        # deduplicate
        inputs = list(set(inputs))
        outputs = list(set(outputs))
        graph[nb_rel] = (inputs, outputs)
        
    dot_content = generate_dot(graph)
    
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(dot_content)
    
    if args.svg:
        if shutil.which('dot') is None:
            print("Error: 'dot' executable not found. Please install Graphviz to generate SVG.", file=sys.stderr)
            sys.exit(1)
        
        try:
            # Run dot command: dot -Tsvg -o output.svg
            # pass dot_content via stdin
            subprocess.run(
                ['dot', '-Tsvg', '-o', args.svg],
                input=dot_content,
                text=True,
                check=True
            )
            print(f"SVG graph saved to {args.svg}")
        except subprocess.CalledProcessError as e:
            print(f"Error running 'dot': {e}", file=sys.stderr)
            sys.exit(1)
            
    if not args.output and not args.svg:
        print(dot_content)

if __name__ == "__main__":
    main()
