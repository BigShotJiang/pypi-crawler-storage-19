from typing import Iterator

from textual.widget import Widget

from azure_explorer.managers import (
    ServiceBusManager,
    TopicManager,
    TopicSubscriptionManager,
)
from azure_explorer.widgets.components.windows import Browser, Selector


class EntitySelector(Selector):
    def __init__(self, sb_manager: ServiceBusManager):
        self.sb_manager = sb_manager
        super().__init__()

    def iter_options(self):
        yield ("topic", "Topics")
        yield ("queue", "Queues")

    def get_option_widget(self, id_):
        if id_ == "topic":
            return TopicExplorer(self.sb_manager)


class TopicExplorer(Browser):
    COLUMN_NAMES = ["Name"]

    def __init__(self, sb_manager: ServiceBusManager):
        self.sb_manager = sb_manager
        super().__init__()

    def check_valid(self) -> bool:
        self.sb_manager.check_access()

    def iter_rows(self) -> Iterator[tuple[str, tuple]]:
        for topic in self.sb_manager.list_topics():
            yield topic.name, (topic.name,)

    def get_item_widget(self, item: str) -> Widget:
        topic_manager = self.sb_manager.get_topic_manager(
            topic_name=item,
        )
        return TopicSubscriptionExplorer(topic_manager)


class TopicSubscriptionExplorer(Browser):
    COLUMN_NAMES = ["Name", "Active Messages", "Dead-letter Messages"]

    def __init__(self, topic_manager: TopicManager):
        self.topic_manager = topic_manager
        super().__init__()

    def check_valid(self):
        return self.topic_manager.check_access()

    def iter_rows(self) -> Iterator[tuple[str, tuple]]:
        for sub in self.topic_manager.list_subscription():
            yield sub.name, (
                sub.name,
                sub.num_active_messages,
                sub.num_deadletter_messages,
            )

    def get_item_widget(self, id_: str) -> Widget:
        subscription_manager = self.topic_manager.get_subscription_manager(
            subscription_name=id_,
        )

        return ActiveMessageExplorer(subscription_manager)


class ActiveMessageExplorer(Browser):
    COLUMN_NAMES = ["Message ID"]

    def __init__(self, subscription_manager: TopicSubscriptionManager):
        self.subscription_manager = subscription_manager
        super().__init__()

    def check_valid(self):
        return self.subscription_manager.check_access()

    def iter_rows(self) -> Iterator[tuple[str, tuple]]:
        for message_id in self.subscription_manager.list_active_messages():
            yield message_id, (message_id,)
