from azure.core.credentials import TokenCredential
from azure.servicebus import ServiceBusClient
from azure.servicebus.management import ServiceBusAdministrationClient

from azure_explorer.managers.base import Manager

MAX_MESSAGES_PEEK = 10


class TopicSubscriptionManager(Manager):
    def __init__(
        self,
        service_bus_name: str,
        topic_name: str,
        subscription_name: str,
        credential: TokenCredential,
    ):
        self.service_bus_name = service_bus_name
        self.credential = credential
        self.topic_name = topic_name
        self.subscription_name = subscription_name
        self.service_bus_client = ServiceBusClient(
            fully_qualified_namespace=f"{service_bus_name}.servicebus.windows.net",
            credential=credential,
        )
        self.service_bus_adm_client = ServiceBusAdministrationClient(
            fully_qualified_namespace=f"{service_bus_name}.servicebus.windows.net",
            credential=credential,
        )
        self.runtime_properties = (
            self.service_bus_adm_client.get_subscription_runtime_properties(
                self.topic_name, self.subscription_name
            )
        )

    def check_access(self) -> bool:
        receiver = self.service_bus_client.get_subscription_receiver(
            self.topic_name, self.subscription_name
        )
        next(receiver.peek_messages(max_message_count=1))

    def num_active_messages(self):
        return self.runtime_properties.active_message_count

    def num_deadletter_messages(self):
        return self.runtime_properties.dead_letter_message_count

    def list_active_messages(self):
        receiver = self.service_bus_client.get_subscription_receiver(
            self.topic_name, self.subscription_name
        )

        msg_ids = []

        for msg in receiver.peek_messages(max_message_count=MAX_MESSAGES_PEEK):
            msg_ids.append(msg.message_id)

        return msg_ids
