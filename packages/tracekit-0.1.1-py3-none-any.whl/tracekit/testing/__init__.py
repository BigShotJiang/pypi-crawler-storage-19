"""Testing utilities for TraceKit.

This module provides synthetic test data generation with known ground truth
for validation and testing purposes.
"""

from tracekit.testing.synthetic import (
    GroundTruth,
    SyntheticDataGenerator,
    SyntheticMessageConfig,
    SyntheticPacketConfig,
    SyntheticSignalConfig,
    generate_digital_signal,
    generate_packets,
    generate_protocol_messages,
    generate_test_dataset,
)

__all__ = [
    "GroundTruth",
    "SyntheticDataGenerator",
    "SyntheticMessageConfig",
    "SyntheticPacketConfig",
    "SyntheticSignalConfig",
    "generate_digital_signal",
    "generate_packets",
    "generate_protocol_messages",
    "generate_test_dataset",
]
