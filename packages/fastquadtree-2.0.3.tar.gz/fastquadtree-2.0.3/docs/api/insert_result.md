# fastquadtree.InsertResult
::: fastquadtree.InsertResult
