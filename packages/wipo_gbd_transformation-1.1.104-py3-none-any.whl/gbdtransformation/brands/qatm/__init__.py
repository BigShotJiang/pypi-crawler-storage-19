render = 'JSON'
source = 'national'

# QA/T/1/188453
appnum_mask = [ 'QA/T/1/(\\d*)' ]
