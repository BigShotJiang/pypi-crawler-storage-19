# Changelog

## [0.1.1](https://github.com/DSestu/test_python_project_template/compare/0.1.0...v0.1.1) (2026-01-09)


### Miscellaneous Chores

* Fix typo in README.md ([e03e4a0](https://github.com/DSestu/test_python_project_template/commit/e03e4a094b55d80d807fd026161398503691cf29))
