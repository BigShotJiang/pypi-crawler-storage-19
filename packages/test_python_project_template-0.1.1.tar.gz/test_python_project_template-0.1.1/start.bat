uvx --with-editable . test_python_project_template
