from setuptools import setup, find_packages

def readme():
  with open('README.md', 'r', encoding='utf-8') as f:
    return f.read()

setup(
  name='AI-Fabric-v2',
  version='1.0.5',
  author='Tikhonov Ivan',
  author_email='tihonovivan737@gmail.com',
  long_description=readme(),
  long_description_content_type='text/markdown',
  packages=find_packages(),
  python_requires='>=3.7'
)