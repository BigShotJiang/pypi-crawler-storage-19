import time
from celery import shared_task, Task as CeleryTask
import celery
from celery.result import ResultSet, AsyncResult
from celery.exceptions import SoftTimeLimitExceeded, TimeLimitExceeded
import redis

from history4feed.h4fscripts.sitemap_helpers import fetch_posts_links_with_serper

from ..app import models
from . import h4f, wayback_helpers, logger, exceptions
from datetime import UTC, datetime
from history4feed.app.settings import history4feed_server_settings as settings

from urllib.parse import urlparse
from contextlib import contextmanager
from django.core.cache import cache
from rest_framework.exceptions import APIException, Throttled
from django.db import transaction

LOCK_EXPIRE = 60 * 60

def get_lock_id(feed: models.Feed):
    lock_id = f"feed-lock-{feed.id}"
    logger.debug("using lock id %s", lock_id)
    return lock_id

def queue_lock(feed: models.Feed, job=None):
    lock_value = dict(feed_id=str(feed.id))
    if job:
        lock_value["job_id"] = str(job.id)
        
    status = cache.add(get_lock_id(feed), lock_value, timeout=LOCK_EXPIRE)
    return status


@transaction.atomic()
def new_job(feed: models.Feed, include_remote_blogs, use_feed_url_only, force_full_fetch=True):
    earliest_item_requested = feed.latest_item_pubdate
    if feed.feed_type == models.FeedType.SEARCH_INDEX:
        earliest_item_requested = feed.freshness
    earliest_item_requested = earliest_item_requested or settings.EARLIEST_SEARCH_DATE
    if force_full_fetch:
        earliest_item_requested = settings.EARLIEST_SEARCH_DATE
    
    job_obj = models.Job.objects.create(
        feed=feed,
        earliest_item_requested=earliest_item_requested,
        latest_item_requested=datetime.now(UTC),
        include_remote_blogs=include_remote_blogs,
        extra_data=dict(force_full_fetch=force_full_fetch, use_feed_url_only=use_feed_url_only, use_scrapfly_asp=feed.use_scrapfly_asp),
    )
    if not queue_lock(feed, job_obj):
        raise Throttled(detail={"message": "A job is already running for this feed", **cache.get(get_lock_id(feed))})

    task = (start_job.s(job_obj.pk) | retrieve_posts_from_links.s(job_obj.pk))
    task.stamp(job_id=str(job_obj.id))
    task.apply_async(countdown=5, link_error=error_handler.s(job_obj.pk))
    return job_obj

def new_patch_posts_job(feed: models.Feed, posts: list[models.Post], include_remote_blogs=True):
    job_obj = models.Job.objects.create(
        feed=feed,
        state=models.JobState.PENDING,
        include_remote_blogs=include_remote_blogs,
        extra_data=dict(use_scrapfly_asp=feed.use_scrapfly_asp),
    )
    ft_jobs = [models.FulltextJob.objects.create(
        job_id=job_obj.id,
        post_id=post.id,
        link=post.link,
    ) for post in posts]
    chain = celery.chain([retrieve_full_text.si(ft_job.pk) for ft_job in ft_jobs])
    chain.stamp(job_id=str(job_obj.id))
    task = ( start_post_job.si(job_obj.id) | chain | collect_and_schedule_removal.si(job_obj.pk))
    task.stamp(job_id=str(job_obj.id))
    task.apply_async(link_error=error_handler.s(job_obj.pk), countdown=5)
    return job_obj

@shared_task(bind=True, default_retry_delay=10)
def start_post_job(self: CeleryTask, job_id):
    job = models.Job.objects.get(pk=job_id)
    if job.is_cancelled():
        job.info = "job cancelled while in queue"
        job.save(update_fields=['info'])
        return False
    if not queue_lock(job.feed, job):
        return self.retry(max_retries=360)
    job.update_state(models.JobState.RUNNING)
    return True

@shared_task(soft_time_limit=600, time_limit=800)
def start_job(job_id):
    job = models.Job.objects.get(pk=job_id)
    feed = job.feed
    job.update_state(models.JobState.RUNNING)
    try:
        if feed.feed_type == models.FeedType.SEARCH_INDEX or job.extra_data["use_feed_url_only"]:
            return [feed.url]
        return wayback_helpers.get_wayback_urls(feed.url, job.earliest_item_requested, job.latest_item_requested)
    except BaseException as e:
        job.update_state(models.JobState.FAILED)
        job.info = str(e)
        job.save(update_fields=['info'])
        return []



@shared_task(bind=True)
def retrieve_posts_from_links(self, urls, job_id):
    if not urls:
        return self.replace(collect_and_schedule_removal.si(job_id))
    full_text_chain = models.Job.objects.get(pk=job_id)
    feed = full_text_chain.feed
    chains = []
    parsed_feed = {}
    job = models.Job.objects.get(id=job_id)
    job.extra_data["urls"] = [dict(link=url, state='queued', posts_added=0) for url in urls]
    job.save(update_fields=['extra_data'])
    for index, url in enumerate(urls):
        if job.is_cancelled():
            break
        job.extra_data["urls"][index]['state'] = 'processing'
        job.save(update_fields=['extra_data'])
        error = None
        if feed.feed_type == models.FeedType.SEARCH_INDEX:
            posts = retrieve_posts_from_serper(feed, job, url)
        else:
            parsed_feed, posts, error = retrieve_posts_from_url(url, feed, job)
        if error:
            logger.exception(error)
            job.extra_data["urls"][index]['state'] = 'failed'
            job.save(update_fields=['extra_data'])
            continue
        if not posts:
            job.extra_data["urls"][index]['state'] = 'completed'
            job.save(update_fields=['extra_data'])
            logger.warning('no new post in `%s`', url)
            continue
        job.extra_data["urls"][index]['state'] = 'completed'
        job.extra_data["urls"][index]['posts_added'] = len(posts)
        job.save(update_fields=['extra_data'])

        full_text_chain = create_fulltexts_task_chain(job_id, posts)
        full_text_chain.stamp(job_id=str(job_id))
        chains.append(full_text_chain)

    if parsed_feed:
        feed.set_description(parsed_feed['description'])
        feed.set_title(parsed_feed['title'])
    feed.freshness = job.run_datetime
    
    feed.save()
    logger.info("====\n"*5)
    
    callback = collect_and_schedule_removal.si(job_id)
    if chains:
        return self.replace(celery.chord(chains, callback))
    return self.replace(callback)

def create_fulltexts_task_chain(job_id, posts):
    chain_tasks = []
    for post in posts:
        ftjob_entry = models.FulltextJob.objects.create(
                job_id=job_id,
                post_id=post.id,
                link=post.link,
            )
        task = retrieve_full_text.si(ftjob_entry.pk)
        task.stamp(job_id=str(job_id))
        chain_tasks.append(task)
        
    return celery.chain(chain_tasks)

def retrieve_posts_from_serper(feed: models.Feed, job: models.Job, url: str):
    start_time = job.earliest_item_requested
    if not start_time.tzinfo:
        start_time = start_time.replace(tzinfo=UTC)
    crawled_posts = fetch_posts_links_with_serper(url, from_time=start_time, to_time=job.run_datetime)
    posts = []
    for post_dict in crawled_posts.values():
        if post := add_post_to_db(feed, job, post_dict):
            posts.append(post)
    return posts

class JobCancelled(Exception):
    pass

@shared_task(bind=True)
def collect_and_schedule_removal(sender, job_id):
    logger.print(f"===> {sender=}, {job_id=} ")
    job = models.Job.objects.get(pk=job_id)
    remove_lock(job)
    if job.state == models.JobState.RUNNING:
        job.update_state(models.JobState.SUCCESS)

def remove_lock(job):
    if cache.delete(get_lock_id(job.feed)):
        logger.debug("lock deleted")
    else:
        logger.debug("Failed to remove lock")

def retrieve_posts_from_url(url, db_feed: models.Feed, job: models.Job):
    back_off_seconds = settings.WAYBACK_SLEEP_SECONDS
    all_posts: list[models.Post] = []
    error = None
    parsed_feed = {}
    for i in range(settings.REQUEST_RETRY_COUNT):
        if i != 0:
            time.sleep(back_off_seconds)
        try:
            if job.is_cancelled():
                raise JobCancelled("job was terminated by user")
            data, content_type, url = h4f.fetch_page_with_retries(url)
            parsed_feed = h4f.parse_feed_from_content(data, url)
            match parsed_feed['feed_type']:
                case models.FeedType.ATOM:
                    posts = h4f.parse_posts_from_atom_feed(url, data)
                case models.FeedType.RSS:
                    posts = h4f.parse_posts_from_rss_feed(url, data)
                case _:
                    raise exceptions.UnknownFeedtypeException("unknown feed type `{}` at {}".format(parsed_feed['feed_type'], url))
            for post_dict in posts.values():
                # make sure that post and feed share the same domain
                post = add_post_to_db(db_feed, job, post_dict)
                if not post:
                    continue
                all_posts.append(post)
            db_feed.save()
            logger.info(f"saved {len(posts)} posts for {url}")
            break
        except ConnectionError as e:
            logger.error(e, exc_info=True)
            error = e
            logger.info(f"job with url {url} ran into an issue {e}, backing off for {back_off_seconds} seconds")
            back_off_seconds *= 1.2
        except BaseException as e:
            logger.error(e, exc_info=True)
            error = e
            break
    return parsed_feed, all_posts, error

def add_post_to_db(db_feed: models.Feed, job: models.Job, post_dict: h4f.PostDict):
    # make sure that post and feed share the same domain
    if job.should_skip_post(post_dict.link):
        models.FulltextJob.objects.create(
                job_id=job.id,
                status=models.FullTextState.SKIPPED,
                link=post_dict.link,
        )
        return None
    categories = post_dict.categories
    del post_dict.categories
    post, created = models.Post.objects.get_or_create(defaults=post_dict.__dict__, feed=db_feed, link=post_dict.link)
    if not created or post.deleted_manually:
        return None

    post.save()
    post.add_categories(categories)
    return post
        

@shared_task(soft_time_limit=settings.FULLTEXT_FETCH_TIMEOUT_SECONDS, time_limit=settings.FULLTEXT_FETCH_TIMEOUT_SECONDS + 20)
def retrieve_full_text(ftjob_pk):
    fulltext_job = models.FulltextJob.objects.get(pk=ftjob_pk)
    use_scrapfly_asp = fulltext_job.job.extra_data["use_scrapfly_asp"]
    try:
        if fulltext_job.is_cancelled():
            raise JobCancelled()
        else:
            fulltext_job.post.description, fulltext_job.post.content_type = h4f.get_full_text(fulltext_job.post.link, use_scrapfly_asp=use_scrapfly_asp)
            fulltext_job.status = models.FullTextState.RETRIEVED
            fulltext_job.error_str = ""
            fulltext_job.post.is_full_text = True
    except JobCancelled:
        fulltext_job.status = models.FullTextState.CANCELLED
        fulltext_job.error_str = "job cancelled while retrieving fulltext"
    except (SoftTimeLimitExceeded, TimeLimitExceeded) as e:
        fulltext_job.status = models.FullTextState.TIMED_OUT
        fulltext_job.error_str = f"task timed out: {str(e)}"
        logger.warning(f"Task retrieve_full_text for ftjob {ftjob_pk} timed out")
    except BaseException as e:
        fulltext_job.error_str = str(e)
        fulltext_job.status = models.FullTextState.FAILED
    fulltext_job.save()
    fulltext_job.post.save()


from celery import signals
@signals.worker_ready.connect
def mark_old_jobs_as_failed(**kwargs):
    models.Job.objects.filter(state__in=[models.JobState.PENDING, models.JobState.RUNNING]).update(state=models.JobState.CANCELLED, info="job cancelled automatically on server startup")

@shared_task
def error_handler(request, exc: Exception, traceback, job_id):
    job = models.Job.objects.get(pk=job_id)
    job.update_state(models.JobState.FAILED)
    job.info = f"job failed: {exc}"
    job.save(update_fields=['info'])
    remove_lock(job)
    logger.error('Job {3} with task_id {0} raised exception: {1!r}\n{2!r}'.format(
          request.id, exc, traceback, job_id))