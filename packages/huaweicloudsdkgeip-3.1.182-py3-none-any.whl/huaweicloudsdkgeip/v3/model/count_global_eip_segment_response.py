# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CountGlobalEipSegmentResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'request_id': 'str',
        'global_eip_segment': 'CountGeipSegments',
        'x_request_id': 'str'
    }

    attribute_map = {
        'request_id': 'request_id',
        'global_eip_segment': 'global_eip_segment',
        'x_request_id': 'X-Request-Id'
    }

    def __init__(self, request_id=None, global_eip_segment=None, x_request_id=None):
        r"""CountGlobalEipSegmentResponse

        The model defined in huaweicloud sdk

        :param request_id: 本次请求的编号
        :type request_id: str
        :param global_eip_segment: 
        :type global_eip_segment: CountGeipSegments
        :param x_request_id: 
        :type x_request_id: str
        """
        
        super().__init__()

        self._request_id = None
        self._global_eip_segment = None
        self._x_request_id = None
        self.discriminator = None

        if request_id is not None:
            self.request_id = request_id
        if global_eip_segment is not None:
            self.global_eip_segment = global_eip_segment
        if x_request_id is not None:
            self.x_request_id = x_request_id

    @property
    def request_id(self):
        r"""Gets the request_id of this CountGlobalEipSegmentResponse.

        本次请求的编号

        :return: The request_id of this CountGlobalEipSegmentResponse.
        :rtype: str
        """
        return self._request_id

    @request_id.setter
    def request_id(self, request_id):
        r"""Sets the request_id of this CountGlobalEipSegmentResponse.

        本次请求的编号

        :param request_id: The request_id of this CountGlobalEipSegmentResponse.
        :type request_id: str
        """
        self._request_id = request_id

    @property
    def global_eip_segment(self):
        r"""Gets the global_eip_segment of this CountGlobalEipSegmentResponse.

        :return: The global_eip_segment of this CountGlobalEipSegmentResponse.
        :rtype: CountGeipSegments
        """
        return self._global_eip_segment

    @global_eip_segment.setter
    def global_eip_segment(self, global_eip_segment):
        r"""Sets the global_eip_segment of this CountGlobalEipSegmentResponse.

        :param global_eip_segment: The global_eip_segment of this CountGlobalEipSegmentResponse.
        :type global_eip_segment: CountGeipSegments
        """
        self._global_eip_segment = global_eip_segment

    @property
    def x_request_id(self):
        r"""Gets the x_request_id of this CountGlobalEipSegmentResponse.

        :return: The x_request_id of this CountGlobalEipSegmentResponse.
        :rtype: str
        """
        return self._x_request_id

    @x_request_id.setter
    def x_request_id(self, x_request_id):
        r"""Sets the x_request_id of this CountGlobalEipSegmentResponse.

        :param x_request_id: The x_request_id of this CountGlobalEipSegmentResponse.
        :type x_request_id: str
        """
        self._x_request_id = x_request_id

    def to_dict(self):
        import warnings
        warnings.warn("CountGlobalEipSegmentResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CountGlobalEipSegmentResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
