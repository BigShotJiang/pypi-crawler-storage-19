# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AssociateGeipSegmentInstanceRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'global_eip_segment_id': 'str',
        'body': 'AssociateInstanceGlobalEipSegmentRequestBody'
    }

    attribute_map = {
        'global_eip_segment_id': 'global_eip_segment_id',
        'body': 'body'
    }

    def __init__(self, global_eip_segment_id=None, body=None):
        r"""AssociateGeipSegmentInstanceRequest

        The model defined in huaweicloud sdk

        :param global_eip_segment_id: 
        :type global_eip_segment_id: str
        :param body: Body of the AssociateGeipSegmentInstanceRequest
        :type body: :class:`huaweicloudsdkgeip.v3.AssociateInstanceGlobalEipSegmentRequestBody`
        """
        
        

        self._global_eip_segment_id = None
        self._body = None
        self.discriminator = None

        self.global_eip_segment_id = global_eip_segment_id
        if body is not None:
            self.body = body

    @property
    def global_eip_segment_id(self):
        r"""Gets the global_eip_segment_id of this AssociateGeipSegmentInstanceRequest.

        :return: The global_eip_segment_id of this AssociateGeipSegmentInstanceRequest.
        :rtype: str
        """
        return self._global_eip_segment_id

    @global_eip_segment_id.setter
    def global_eip_segment_id(self, global_eip_segment_id):
        r"""Sets the global_eip_segment_id of this AssociateGeipSegmentInstanceRequest.

        :param global_eip_segment_id: The global_eip_segment_id of this AssociateGeipSegmentInstanceRequest.
        :type global_eip_segment_id: str
        """
        self._global_eip_segment_id = global_eip_segment_id

    @property
    def body(self):
        r"""Gets the body of this AssociateGeipSegmentInstanceRequest.

        :return: The body of this AssociateGeipSegmentInstanceRequest.
        :rtype: :class:`huaweicloudsdkgeip.v3.AssociateInstanceGlobalEipSegmentRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this AssociateGeipSegmentInstanceRequest.

        :param body: The body of this AssociateGeipSegmentInstanceRequest.
        :type body: :class:`huaweicloudsdkgeip.v3.AssociateInstanceGlobalEipSegmentRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssociateGeipSegmentInstanceRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
