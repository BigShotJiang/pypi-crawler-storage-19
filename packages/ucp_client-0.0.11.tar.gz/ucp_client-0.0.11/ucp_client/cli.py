#   Copyright 2026 UCP Authors
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

"""UCP CLI - Command line interface for UCP client utilities."""

import os
import subprocess
import sys
from pathlib import Path

import click


def get_ucp_server_dir() -> Path:
    """Get the path to the ucp-server directory."""
    # First, check if mockup_server is bundled with the package (installed via pip)
    package_server = Path(__file__).parent / "mockup_server"
    if package_server.exists():
        return package_server
    
    # Check if ucp-server is in the current working directory (development mode)
    cwd_server = Path.cwd() / "ucp-server"
    if cwd_server.exists():
        return cwd_server
    
    # Check if ucp-server is relative to this package's parent (development mode)
    package_dir = Path(__file__).parent.parent
    package_server_alt = package_dir / "ucp-server"
    if package_server_alt.exists():
        return package_server_alt
    
    raise click.ClickException(
        "Could not find ucp-server directory. "
        "Please reinstall the ucp-client package or run from the project root."
    )


# ANSI color codes
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
RED = "\033[0;31m"
NC = "\033[0m"  # No Color


@click.group()
@click.version_option(version="0.0.5", prog_name="ucp")
def cli():
    """UCP Client CLI - Universal Checkout Protocol utilities."""
    pass


def check_server_dependencies():
    """Check if server dependencies are installed."""
    missing = []
    try:
        import fastapi  # noqa: F401
    except ImportError:
        missing.append("fastapi")
    try:
        import uvicorn  # noqa: F401
    except ImportError:
        missing.append("uvicorn")
    try:
        import absl  # noqa: F401
    except ImportError:
        missing.append("absl-py")
    try:
        import sqlalchemy  # noqa: F401
    except ImportError:
        missing.append("sqlalchemy")
    try:
        import aiosqlite  # noqa: F401
    except ImportError:
        missing.append("aiosqlite")
    
    return missing


@cli.command("mockup_server")
@click.option(
    "--port",
    default=8182,
    help="Port to run the server on",
    show_default=True,
)
@click.option(
    "--db-dir",
    default=None,
    help="Directory for database files (default: ./db)",
)
def mockup_server(port: int, db_dir: str | None):
    """Start the UCP mockup server with sample data.
    
    This command initializes the database with test data and starts
    the UCP merchant server for development and testing.
    
    Requires server dependencies: pip install ucp-client[server]
    """
    # Check for server dependencies
    missing = check_server_dependencies()
    if missing:
        raise click.ClickException(
            f"Missing server dependencies: {', '.join(missing)}\n"
            f"Install them with: pip install ucp-client[server]"
        )
    
    try:
        server_dir = get_ucp_server_dir()
    except click.ClickException as e:
        raise e
    
    # Set up paths
    if db_dir is None:
        db_dir = Path.cwd() / "db"
    else:
        db_dir = Path(db_dir)
    
    products_db = db_dir / "products.db"
    transactions_db = db_dir / "transactions.db"
    test_data_dir = server_dir / "test_data"
    
    # Create database directory
    click.echo(f"{GREEN}Initializing database...{NC}")
    db_dir.mkdir(parents=True, exist_ok=True)
    
    # Run import_csv.py to initialize the database
    click.echo(f"{YELLOW}Importing test data from {test_data_dir}...{NC}")
    
    import_script = server_dir / "import_csv.py"
    import_cmd = [
        sys.executable,
        str(import_script),
        f"--products_db_path={products_db}",
        f"--transactions_db_path={transactions_db}",
        f"--data_dir={test_data_dir}",
    ]
    
    # Add server_dir to PYTHONPATH so imports work
    env = os.environ.copy()
    env["PYTHONPATH"] = str(server_dir) + os.pathsep + env.get("PYTHONPATH", "")
    
    result = subprocess.run(import_cmd, env=env)
    if result.returncode != 0:
        raise click.ClickException("Failed to initialize database")
    
    # Start the server
    click.echo(f"{GREEN}Starting server on port {port}...{NC}")
    click.echo(f"{YELLOW}Server: http://localhost:{port}{NC}")
    
    server_script = server_dir / "server.py"
    server_cmd = [
        sys.executable,
        str(server_script),
        f"--products_db_path={products_db}",
        f"--transactions_db_path={transactions_db}",
        f"--port={port}",
    ]
    
    try:
        subprocess.run(server_cmd, env=env)
    except KeyboardInterrupt:
        click.echo(f"\n{YELLOW}Server stopped.{NC}")
        sys.exit(0)


@cli.command("clean")
@click.option(
    "--db-dir",
    default=None,
    help="Directory for database files (default: ./db)",
)
def clean(db_dir: str | None):
    """Clean up database files created by mockup_server."""
    if db_dir is None:
        db_dir = Path.cwd() / "db"
    else:
        db_dir = Path(db_dir)
    
    if not db_dir.exists():
        click.echo(f"{YELLOW}No database directory found at {db_dir}{NC}")
        return
    
    products_db = db_dir / "products.db"
    transactions_db = db_dir / "transactions.db"
    
    removed = False
    for db_file in [products_db, transactions_db]:
        if db_file.exists():
            db_file.unlink()
            click.echo(f"{GREEN}Removed {db_file}{NC}")
            removed = True
    
    # Remove directory if empty
    if db_dir.exists() and not any(db_dir.iterdir()):
        db_dir.rmdir()
        click.echo(f"{GREEN}Removed empty directory {db_dir}{NC}")
    
    if not removed:
        click.echo(f"{YELLOW}No database files found to clean{NC}")
    else:
        click.echo(f"{GREEN}Cleanup complete!{NC}")


def main():
    """Entry point for the CLI."""
    cli()


if __name__ == "__main__":
    main()
