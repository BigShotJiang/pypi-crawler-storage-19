from enum import Enum
import pyvisa

class RigolDP800:
    class Channel:
        class Number(int, Enum):
            CH1 = 1
            CH2 = 2
            CH3 = 3

    class Output:
        class State(int, Enum):
            OFF = 0
            ON = 1

    def __init__(self, instr: pyvisa.Resource):
        self.instr = instr
        return

    def query_source_current_level_immediate_amplitude(self, channel: int) -> float:
        if channel not in RigolDP800.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":SOUR{channel}:CURR?"
        resp = self.instr.query(msg)
        level = float(resp.strip())
        return level

    def write_source_current_level_immediate_amplitude(self, channel: int, amplitude: float):
        if channel not in RigolDP800.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":SOUR{channel}:CURR {amplitude}"
        self.instr.write(msg)
        return

    def query_source_voltage_level_immediate_amplitude(self, channel: int) -> float:
        if channel not in RigolDP800.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":SOUR{channel}:VOLT?"
        resp = self.instr.query(msg)
        level = float(resp.strip())
        return level

    def write_source_voltage_level_immediate_amplitude(self, channel: int, amplitude: float):
        if channel not in RigolDP800.Channel.Number:
            raise ValueError("Invalid channel number")

        msg = f":SOUR{channel}:VOLT {amplitude}"
        self.instr.write(msg)
        return

    def query_output_state(self, channel: int) -> int:
        if channel not in RigolDP800.Channel:
            raise ValueError("Invalid channel number")

        msg = f":OUTP:STAT? CH{channel}"
        resp = self.instr.query(msg)
        state = int(resp.strip())

        if state not in RigolDP800.Output.State:
            raise ValueError("Invalid output state")
        return state

    def write_output_state(self, channel: int, state: int):
        if channel not in RigolDP800.Channel:
            raise ValueError("Invalid channel number")

        if state not in RigolDP800.Output.State:
            raise ValueError("Invalid output state")

        msg = f":OUTP:STAT CH{channel},{state}"
        self.instr.write(msg)
        return
