import h5py
import cupy as cp
from __init__ import MaxPooling2D, Flatten, BatchNorm2D, DenseLayer, Conv2D, NeuralNetwork, ReLU, Sigmoid, \
    Softmax, Tanh, AveragePooling2D, Embedding, RNN, LSTM, minLSTM, GRU, minGRU, LastState



def save_model(network, file_path):
    with h5py.File(file_path, 'w') as f:
        f.attrs['learning_rate'] = network.learning_rate
        f.attrs['optimizer'] = network.optimizer
        for i, layer in enumerate(network.layers):
            group = f.create_group(f'layer_{i}')
            group.attrs['type'] = layer.__class__.__name__
            if hasattr(layer, 'weights') and hasattr(layer, 'biases'):
                if isinstance(layer, (Embedding, DenseLayer, Conv2D, BatchNorm2D)):
                    group.create_dataset('weights', data=cp.asnumpy(layer.weights))
                    group.create_dataset('biases', data=cp.asnumpy(layer.biases))
                elif isinstance(layer, (RNN, LSTM, minLSTM, GRU, minGRU)):
                    group.attrs['input_size'] = layer.input_size
                    group.attrs['hidden_size'] = layer.hidden_size
                    group.attrs['num_layers'] = layer.num_layers
                    if hasattr(layer, 'activation_func') and layer.activation_func:
                        if isinstance(layer.activation_func, type):
                            activation_class_name = layer.activation_func.__name__
                        else:
                            activation_class_name = layer.activation_func.__class__.__name__
                        group.attrs['activation'] = activation_class_name
                    else:
                        group.attrs['activation'] = 'None'
                    for layer_idx in range(layer.num_layers):
                        sub_group = group.create_group(f'sub_layer_{layer_idx}')
                        sub_group.create_dataset('weights', data=cp.asnumpy(layer.weights[layer_idx]))
                        sub_group.create_dataset('biases', data=cp.asnumpy(layer.biases[layer_idx]))
            if isinstance(layer, Embedding):
                group.attrs['num_embeddings'] = layer.params['num_embeddings']
                group.attrs['embedding_dim'] = layer.params['embedding_dim']
                group.attrs['padding_idx'] = layer.params['padding_idx'] if layer.params['padding_idx'] is not None else -1
            elif isinstance(layer, DenseLayer):
                group.attrs['activation'] = layer.activation_func.__class__.__name__ if layer.activation_func else 'None'
            elif isinstance(layer, Conv2D):
                group.attrs['activation'] = layer.activation_func.__class__.__name__ if layer.activation_func else 'None'
                group.attrs['num_filters'] = layer.params['num_filters']
                group.attrs['kernel_size'] = layer.params['kernel_size']
                group.attrs['stride'] = layer.params['stride']
                group.attrs['padding'] = layer.params['padding']
                group.attrs['in_channels'] = layer.params['in_channels']
            elif isinstance(layer, BatchNorm2D):
                group.create_dataset('running_mean', data=cp.asnumpy(layer.running_mean))
                group.create_dataset('running_var', data=cp.asnumpy(layer.running_var))
                group.attrs['num_features'] = layer.num_features
                group.attrs['momentum'] = layer.momentum
                group.attrs['epsilon'] = layer.epsilon
            elif isinstance(layer, (MaxPooling2D, AveragePooling2D)):
                group.attrs['pool_size'] = layer.pool_size
                group.attrs['stride'] = layer.stride

def load_model(file_path):
    with h5py.File(file_path, 'r') as f:
        learning_rate = f.attrs['learning_rate']
        optimizer = f.attrs['optimizer']
        network = NeuralNetwork(learning_rate=learning_rate, optimizer=optimizer)
        activation_mapping = {
            'ReLU': ReLU,
            'Sigmoid': Sigmoid,
            'Softmax': Softmax,
            'Tanh': Tanh,
            'None': None
        }
        for i in range(len(f.keys())):
            group = f[f'layer_{i}']
            layer_type = group.attrs['type']
            if layer_type == 'DenseLayer':
                weights = cp.asarray(group['weights'])
                biases = cp.asarray(group['biases'])
                activation_name = group.attrs['activation']
                activation_func = activation_mapping[activation_name]() if activation_name != 'None' else None
                layer = DenseLayer(weights.shape[0], weights.shape[1], activation_func)
                layer.weights = weights
                layer.biases = biases
            elif layer_type == 'Conv2D':
                weights = cp.asarray(group['weights'])
                biases = cp.asarray(group['biases'])
                activation_name = group.attrs['activation']
                activation_func = activation_mapping[activation_name]() if activation_name != 'None' else None
                layer = Conv2D(
                    num_filters=group.attrs['num_filters'],
                    kernel_size=group.attrs['kernel_size'],
                    stride=group.attrs['stride'],
                    padding=group.attrs['padding'],
                    in_channels=group.attrs['in_channels'],
                    weights_initializer='he',
                    activation_func=activation_func
                )
                layer.weights = weights
                layer.biases = biases
            elif layer_type == 'BatchNorm2D':
                weights = cp.asarray(group['weights'])
                biases = cp.asarray(group['biases'])
                running_mean = cp.asarray(group['running_mean'])
                running_var = cp.asarray(group['running_var'])
                layer = BatchNorm2D(
                    num_features=group.attrs['num_features'],
                    momentum=group.attrs['momentum'],
                    eps=group.attrs['epsilon']
                )
                layer.weights = weights
                layer.biases = biases
                layer.running_mean = running_mean
                layer.running_var = running_var
            elif layer_type == 'MaxPooling2D':
                layer = MaxPooling2D(
                    pool_size=group.attrs['pool_size'],
                    stride=group.attrs['stride']
                )
            elif layer_type == 'AveragePooling2D':
                layer = AveragePooling2D(
                    pool_size=group.attrs['pool_size'],
                    stride=group.attrs['stride']
                )
            elif layer_type == 'Flatten':
                layer = Flatten()
            elif layer_type == 'Embedding':
                weights = cp.asarray(group['weights'])
                biases = cp.asarray(group['biases'])
                num_embeddings = group.attrs['num_embeddings']
                embedding_dim = group.attrs['embedding_dim']
                padding_idx = group.attrs['padding_idx'] if group.attrs['padding_idx'] != -1 else None
                layer = Embedding(num_embeddings, embedding_dim, weights_initializer='uniform', padding_idx=padding_idx)
                layer.weights = weights
                layer.biases = biases
            elif layer_type in ['RNN', 'LSTM', 'GRU']:
                input_size = group.attrs['input_size']
                hidden_size = group.attrs['hidden_size']
                num_layers = group.attrs['num_layers']
                activation_name = group.attrs['activation']
                activation_func = activation_mapping[activation_name]() if activation_name != 'None' else None
                if layer_type == 'RNN':
                    layer = RNN(input_size, hidden_size, activation_func, num_layers=num_layers)
                elif layer_type == 'LSTM':
                    layer = LSTM(input_size, hidden_size, activation_func=activation_func, num_layers=num_layers)
                elif layer_type == 'GRU':
                    layer = GRU(input_size, hidden_size, activation_func=activation_func, num_layers=num_layers)
                for layer_idx in range(num_layers):
                    sub_group = group[f'sub_layer_{layer_idx}']
                    layer.weights[layer_idx] = cp.asarray(sub_group['weights'])
                    layer.biases[layer_idx] = cp.asarray(sub_group['biases'])
            elif layer_type == 'minLSTM':
                input_size = group.attrs['input_size']
                hidden_size = group.attrs['hidden_size']
                num_layers = group.attrs['num_layers']
                layer = minLSTM(input_size, hidden_size, num_layers=num_layers)
                for layer_idx in range(num_layers):
                    sub_group = group[f'sub_layer_{layer_idx}']
                    layer.weights[layer_idx] = cp.asarray(sub_group['weights'])
                    layer.biases[layer_idx] = cp.asarray(sub_group['biases'])
            elif layer_type == 'minGRU':
                input_size = group.attrs['input_size']
                hidden_size = group.attrs['hidden_size']
                num_layers = group.attrs['num_layers']
                layer = minGRU(input_size, hidden_size, num_layers=num_layers)
                for layer_idx in range(num_layers):
                    sub_group = group[f'sub_layer_{layer_idx}']
                    layer.weights[layer_idx] = cp.asarray(sub_group['weights'])
                    layer.biases[layer_idx] = cp.asarray(sub_group['biases'])
            elif layer_type == 'LastState':
                layer = LastState()
            else:
                raise ValueError(f"Unknown layer type: {layer_type}")
            network.add_layer(layer)
    return network