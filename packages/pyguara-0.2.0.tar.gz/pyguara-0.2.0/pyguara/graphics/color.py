"""Colors definitions."""
