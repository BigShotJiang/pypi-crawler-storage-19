"""General purpose constants Definition."""
