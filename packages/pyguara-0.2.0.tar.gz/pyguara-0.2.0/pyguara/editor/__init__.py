"""Editor module for PyGuara."""
