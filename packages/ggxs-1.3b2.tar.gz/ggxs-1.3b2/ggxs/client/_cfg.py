
## configurari de client ##
VERSION = "V 4.00"
GAME_VERSION_URL = "https://empire-html5.goodgamestudios.com/default/items/ItemsVersion.properties"
CLIENT_ORIGIN = "https://empire-html5.goodgamestudios.com"
SERVERS_DB = "https://empire-html5.goodgamestudios.com/config/network/1.xml"
LANG_DB = "https://langserv.public.ggs-ep.com/em/en"


## client headers ##
WS_HEADERS = {
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "identity",  
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Connection": "Upgrade",
    "Upgrade": "websocket",
    "Sec-WebSocket-Version": "13",
    "Origin": "https://empire.goodgamestudios.com",
}


AD_HEADERS = {
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "identity",  
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Connection": "keep-alive",
    "Referer": "https://empire.goodgamestudios.com/",
    "Origin": "https://empire.goodgamestudios.com",
    "Accept-Language": "en-US,en;q=0.9",
}




DEFAULT_UA_LIST = [

    # Chrome – Windows 11
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36",

    # Chrome – Windows 10
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36",

    # Chrome – macOS Sonoma
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36",

    # Chrome – Linux
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36",


    # ───────── Firefox (foarte safe, trafic real) ─────────
    # Firefox – Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) "
    "Gecko/20100101 Firefox/123.0",

    # Firefox – macOS
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.2; rv:123.0) "
    "Gecko/20100101 Firefox/123.0",

    # Firefox – Linux
    "Mozilla/5.0 (X11; Linux x86_64; rv:122.0) "
    "Gecko/20100101 Firefox/122.0",


    # ───────── Edge (Chromium, foarte comun) ─────────
    # Edge – Windows 11
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0",

    # Edge – Windows 10
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",


    # ───────── Safari (doar macOS, fără fake) ─────────
    # Safari – macOS Sonoma
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/17.3 Safari/605.1.15",

    # Safari – macOS Ventura
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) "
    "Version/16.6 Safari/605.1.15",


    # ───────── Opera (puține, dar reale) ─────────
    # Opera – Windows
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/121.0.0.0 Safari/537.36 OPR/107.0.0.0",

]


G_SERVERS = {
    "International 1": ("wss://ep-live-mz-int1-sk1-gb1-game.goodgamestudios.com", "EmpireEx"),
    "Germany 1": ("wss://ep-live-de1-game.goodgamestudios.com", "EmpireEx_2"),
    "France 1": ("wss://ep-live-fr1-game.goodgamestudios.com", "EmpireEx_3"),
    "Czech Republic 1": ("wss://ep-live-mz-cz1-es2-game.goodgamestudios.com", "EmpireEx_4"),
    "Poland 1": ("wss://ep-live-pl1-game.goodgamestudios.com", "EmpireEx_5"),
    "Portuguese 1": ("wss://ep-live-pt1-game.goodgamestudios.com", "EmpireEx_6"),
    "International 2": ("wss://ep-live-mz-int2-es1-it1-game.goodgamestudios.com", "EmpireEx_7"),
    "Spain 1": ("wss://ep-live-mz-int2-es1-it1-game.goodgamestudios.com", "EmpireEx_8"),
    "Italy 1": ("wss://ep-live-mz-int2-es1-it1-game.goodgamestudios.com", "EmpireEx_9"),
    "Turkey 1": ("wss://ep-live-mz-tr1-nl1-bg1-game.goodgamestudios.com", "EmpireEx_10"),
    "Netherlands 1": ("wss://ep-live-mz-tr1-nl1-bg1-game.goodgamestudios.com", "EmpireEx_11"),
    "Hungary 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_12"),
    "Nordic 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_13"),
    "Russia 1": ("wss://ep-live-ru1-game.goodgamestudios.com", "EmpireEx_14"),
    "Romania 1": ("wss://ep-live-ro1-game.goodgamestudios.com", "EmpireEx_15"),
    "Bulgaria 1": ("wss://ep-live-mz-tr1-nl1-bg1-game.goodgamestudios.com", "EmpireEx_16"),
    "Hungary 2": ("wss://ep-live-hu2-game.goodgamestudios.com", "EmpireEx_17"),
    "Slovakia 1": ("wss://ep-live-mz-int1-sk1-gb1-game.goodgamestudios.com", "EmpireEx_18"),
    "United Kingdom 1": ("wss://ep-live-mz-int1-sk1-gb1-game.goodgamestudios.com", "EmpireEx_19"),
    "Brazil 1": ("wss://ep-live-br1-game.goodgamestudios.com", "EmpireEx_20"),
    "United States 1": ("wss://ep-live-us1-game.goodgamestudios.com", "EmpireEx_21"),
    "Australia 1": ("wss://ep-live-au1-game.goodgamestudios.com", "EmpireEx_22"),
    "South Korea 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_23"),
    "Japan 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_24"),
    "Hispanic America 1": ("wss://ep-live-his1-game.goodgamestudios.com", "EmpireEx_25"),
    "India 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_26"),
    "China 1": ("wss://ep-live-mz-kr1-jp1-in1-cn1-game.goodgamestudios.com", "EmpireEx_27"),
    "Greece 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_28"),
    "Lithuania 1": ("wss://ep-live-mz-hu1-skn1-gr1-lt1-game.goodgamestudios.com", "EmpireEx_29"),
    "Saudi Arabia 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_32"),
    "United Arab Emirates 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_33"),
    "Egypt 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_34"),
    "Arab League 1": ("wss://ep-live-mz-sa1-ae1-eg1-arab1-game.goodgamestudios.com", "EmpireEx_35"),
    "Asia 1": ("wss://ep-live-mz-asia1-hant1-game.goodgamestudios.com", "EmpireEx_36"),
    "Chinese (traditional) 1": ("wss://ep-live-mz-asia1-hant1-game.goodgamestudios.com", "EmpireEx_37"),
    "Spain 2": ("wss://ep-live-mz-cz1-es2-game.goodgamestudios.com", "EmpireEx_38"),
    "International 3": ("wss://ep-live-int3-game.goodgamestudios.com", "EmpireEx_43"),
    "World 1": ("wss://ep-live-world1-game.goodgamestudios.com", "EmpireEx_46"),
    "World 2": ("wss://ep-live-world2-game.goodgamestudios.com", "EmpireEx_46"),
}