::: asimpy.gate
