::: asimpy.interrupt
