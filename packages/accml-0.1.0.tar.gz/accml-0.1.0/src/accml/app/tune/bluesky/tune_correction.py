import asyncio
import logging

from .tune_correction_controller import BlueskyTuneCorrectionController
from ..model import TuneResponseCollection
from ..oracle import TuneOracle
from ..policy import TunePolicy
from ....core.interfaces.measurement_execution_engine import MeasurementExecutionEngine
from ....core.model.command import ReadCommand
from ....custom.simulators.interface.calculation_output import Tune

logger = logging.getLogger("accml")


def tune_correction(
    dm: TuneResponseCollection,
    tune_target: Tune,
    mexec: MeasurementExecutionEngine,
    **kwargs
):
    oracle = TuneOracle(col=dm, target=tune_target)
    policy = TunePolicy(scale=.5)
    logger.info("correction start")
    controller = BlueskyTuneCorrectionController(
        oracle=oracle,
        policy=policy,
        mexec=mexec,
        num_readings=3,
        wait_before_read=0.5,
        delay=0.5,
    )

    rcmds = [ReadCommand(id="tune", property="transversal")]
    set_cmds = [
        ReadCommand(id=elm.pc_name, property="delta_set_current") for elm in dm.col
    ]

    async def run_continuously():
        await controller.continuous(read_commands=rcmds, set_commands=set_cmds, n_steps=10)

    asyncio.get_event_loop().run_until_complete(run_continuously())
