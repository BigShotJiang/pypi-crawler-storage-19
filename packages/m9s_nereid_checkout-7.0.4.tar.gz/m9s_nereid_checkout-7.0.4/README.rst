Nereid Checkout Module
######################
