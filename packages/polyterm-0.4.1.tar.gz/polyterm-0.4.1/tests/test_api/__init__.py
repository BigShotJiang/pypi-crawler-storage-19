"""API client tests"""

