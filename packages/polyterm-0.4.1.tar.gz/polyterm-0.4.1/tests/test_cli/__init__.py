"""CLI tests"""

