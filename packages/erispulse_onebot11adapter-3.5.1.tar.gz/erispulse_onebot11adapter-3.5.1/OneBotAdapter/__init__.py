from .Core import OneBotAdapter
