Plotly for funcnodes
