use assert_cmd::cargo::cargo_bin_cmd;
use predicates::prelude::*;
use tempfile::TempDir;

fn write_file(dir: &TempDir, path: &str, contents: &str) {
    let full = dir.path().join(path);
    if let Some(parent) = full.parent() {
        std::fs::create_dir_all(parent).unwrap();
    }
    std::fs::write(full, contents).unwrap();
}

fn repeat_lines(count: usize) -> String {
    let mut out = String::new();
    for _ in 0..count {
        out.push_str("line\n");
    }
    out
}

#[test]
fn default_check_success() {
    let temp = TempDir::new().unwrap();
    write_file(&temp, "src/main.rs", "fn main() {}\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .assert()
        .success()
        .stdout(predicate::str::contains("files passed"));
}

#[test]
fn check_explicit_files() {
    let temp = TempDir::new().unwrap();
    write_file(&temp, "a.txt", "a\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["check", "a.txt"])
        .assert()
        .success()
        .stdout(predicate::str::contains("files passed"));
}

#[test]
fn check_reads_stdin_list() {
    let temp = TempDir::new().unwrap();
    write_file(&temp, "a.txt", "a\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["check", "-"])
        .write_stdin("a.txt\n")
        .assert()
        .success();
}

#[test]
fn exit_code_error_on_violation() {
    let temp = TempDir::new().unwrap();
    let contents = repeat_lines(501);
    write_file(&temp, "big.txt", &contents);

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["check", "big.txt"])
        .assert()
        .failure()
        .stdout(predicate::str::contains("✖"))
        .stdout(predicate::str::contains("over limit"));
}

#[test]
fn quiet_suppresses_warnings_and_summary() {
    let temp = TempDir::new().unwrap();
    let config = r#"default_max_lines = 500
[[rules]]
path = "**/*.txt"
max_lines = 1
severity = "warning"
"#;
    write_file(&temp, "loq.toml", config);
    write_file(&temp, "warn.txt", "a\nb\n");

    let output = cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--quiet", "check", "warn.txt"])
        .output()
        .unwrap();
    assert!(output.status.success());
    assert!(output.stdout.is_empty());
}

#[test]
fn silent_prints_nothing() {
    let temp = TempDir::new().unwrap();
    let contents = repeat_lines(501);
    write_file(&temp, "big.txt", &contents);

    let output = cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--silent", "check", "big.txt"])
        .output()
        .unwrap();
    assert!(!output.status.success());
    assert!(output.stdout.is_empty());
    assert!(output.stderr.is_empty());
}

#[test]
fn missing_file_warns() {
    let temp = TempDir::new().unwrap();

    // Missing files are only shown in verbose mode
    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--verbose", "check", "missing.txt"])
        .assert()
        .success()
        .stdout(predicate::str::contains("⚠"))
        .stdout(predicate::str::contains("file not found"));
}

#[test]
fn verbose_includes_config_and_rule() {
    let temp = TempDir::new().unwrap();
    let config = "default_max_lines = 1\n";
    write_file(&temp, "loq.toml", config);
    write_file(&temp, "a.txt", "a\nb\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--verbose", "check", "a.txt"])
        .assert()
        .failure()
        .stdout(predicate::str::contains("config:"))
        .stdout(predicate::str::contains("rule:"));
}

#[test]
fn verbose_includes_skip_warnings() {
    let temp = TempDir::new().unwrap();

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--verbose", "check", "missing.txt"])
        .assert()
        .success()
        .stdout(predicate::str::contains("⚠"))
        .stdout(predicate::str::contains("file not found"));
}

#[test]
fn init_writes_config() {
    let temp = TempDir::new().unwrap();

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["init"])
        .assert()
        .success();

    let content = std::fs::read_to_string(temp.path().join("loq.toml")).unwrap();
    assert!(content.contains("default_max_lines = 500"));
}

#[test]
fn init_fails_when_exists() {
    let temp = TempDir::new().unwrap();
    write_file(&temp, "loq.toml", "default_max_lines = 10\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["init"])
        .assert()
        .failure()
        .stderr(predicate::str::contains("already exists"));
}

#[test]
fn init_accepts_verbosity_flags() {
    let temp = TempDir::new().unwrap();

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--quiet", "init"])
        .assert()
        .success();

    assert!(temp.path().join("loq.toml").exists());
}

#[test]
fn init_baseline_adds_exempt() {
    let temp = TempDir::new().unwrap();
    let contents = repeat_lines(501);
    write_file(&temp, "src/legacy.txt", &contents);

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["init", "--baseline"])
        .assert()
        .success();

    let content = std::fs::read_to_string(temp.path().join("loq.toml")).unwrap();
    assert!(content.contains("\"src/legacy.txt\""));
}

#[test]
fn config_error_is_reported() {
    let temp = TempDir::new().unwrap();
    write_file(&temp, "bad.toml", "max_line = 10\n");
    write_file(&temp, "a.txt", "a\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--config", "bad.toml", "check", "a.txt"])
        .assert()
        .failure()
        .stderr(predicate::str::contains("unknown key"));
}

#[test]
fn quiet_mode_shows_errors_only() {
    let temp = TempDir::new().unwrap();
    let config = r#"default_max_lines = 1
[[rules]]
path = "warn.txt"
max_lines = 1
severity = "warning"
"#;
    write_file(&temp, "loq.toml", config);
    write_file(&temp, "warn.txt", "a\nb\n");
    let big = repeat_lines(501);
    write_file(&temp, "error.txt", &big);

    let output = cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--quiet"])
        .output()
        .unwrap();
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(stdout.contains("✖"));
    assert!(stdout.contains("over limit"));
    assert!(!stdout.contains("⚠"));
}

#[test]
fn verbose_shows_matched_rule_pattern() {
    let temp = TempDir::new().unwrap();
    let config = r#"default_max_lines = 100
[[rules]]
path = "**/*.rs"
max_lines = 1
"#;
    write_file(&temp, "loq.toml", config);
    write_file(&temp, "main.rs", "fn main() {}\nfn other() {}\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--verbose", "check", "main.rs"])
        .assert()
        .failure()
        .stdout(predicate::str::contains("match: **/*.rs"));
}

#[test]
fn warning_severity_shows_yellow() {
    let temp = TempDir::new().unwrap();
    let config = r#"default_max_lines = 100
[[rules]]
path = "**/*.txt"
max_lines = 1
severity = "warning"
"#;
    write_file(&temp, "loq.toml", config);
    write_file(&temp, "warn.txt", "a\nb\nc\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["check", "warn.txt"])
        .assert()
        .success()
        .stdout(predicate::str::contains("⚠"))
        .stdout(predicate::str::contains("over limit"));
}

#[test]
fn verbose_shows_warning_severity_label() {
    let temp = TempDir::new().unwrap();
    let config = r#"default_max_lines = 100
[[rules]]
path = "**/*.txt"
max_lines = 1
severity = "warning"
"#;
    write_file(&temp, "loq.toml", config);
    write_file(&temp, "warn.txt", "a\nb\nc\n");

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--verbose", "check", "warn.txt"])
        .assert()
        .success()
        .stdout(predicate::str::contains("severity=warning"));
}

#[test]
fn verbose_shows_builtin_config_source() {
    let temp = TempDir::new().unwrap();
    let contents = repeat_lines(501);
    write_file(&temp, "a.txt", &contents);

    cargo_bin_cmd!("loq")
        .current_dir(temp.path())
        .args(["--verbose", "check", "a.txt"])
        .assert()
        .failure()
        .stdout(predicate::str::contains("<built-in>"));
}
