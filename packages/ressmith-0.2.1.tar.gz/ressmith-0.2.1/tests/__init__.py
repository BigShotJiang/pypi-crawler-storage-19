"""Tests for ResSmith."""

