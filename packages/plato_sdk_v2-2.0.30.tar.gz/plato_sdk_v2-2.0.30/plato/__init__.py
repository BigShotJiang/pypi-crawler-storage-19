# Plato SDK
#
# v1: Legacy SDK (deprecated)
# v2: New SDK with separate sync/async modules
# agents: Code execution agent framework
# sims: Simulation clients (Spree, Firefly, etc.)
#
# Usage (v2 - recommended):
#   from plato.v2 import AsyncPlato, Plato, Env
#
# Usage (agents):
#   from plato.agents import CodeAgent, CodeExecutor
#
# Usage (sims):
#   from plato.sims import SpreeClient, FireflyClient

from importlib.metadata import PackageNotFoundError, version

from plato import v2 as v2

try:
    __version__ = version("plato-sdk-v2")
except PackageNotFoundError:
    __version__ = "0.0.0"  # Fallback for development

__all__ = ["v2", "__version__"]


def __getattr__(name: str):
    """Lazy import to avoid loading all modules at once."""
    if name in ("Plato", "SyncPlato", "PlatoTask", "v1"):
        try:
            from plato import v1

            if name == "v1":
                return v1
            return getattr(v1, name)
        except ImportError:
            raise AttributeError(f"module 'plato' has no attribute '{name}' (v1 unavailable)")

    if name == "agents":
        from plato import agents

        return agents

    if name == "sims":
        from plato import sims

        return sims

    raise AttributeError(f"module 'plato' has no attribute '{name}'")
