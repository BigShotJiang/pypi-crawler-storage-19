# Content analysis utilities
