"""Version information."""

import importlib.metadata

__version__ = importlib.metadata.version("swiftgalaxy")
