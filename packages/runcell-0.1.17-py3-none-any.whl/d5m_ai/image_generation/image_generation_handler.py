"""
Image generation proxy handler.

Forwards image generation requests to the remote backend server.
"""

import asyncio
import aiohttp
import certifi
import json
import logging
import ssl
from typing import Optional
from jupyter_server.base.handlers import APIHandler
from tornado import web

from ..auth.token_handler import get_current_user_token_string
from ..utils import build_remote_backend_url

logging.basicConfig(level=logging.INFO)


class ImageGenerationProxyHandler(APIHandler):
    """Proxy handler for image generation requests."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.remote_backend_url = build_remote_backend_url("chat").removesuffix("/chat")
        logging.info(f"[IMAGE-GEN-PROXY] Initialized with remote backend: {self.remote_backend_url}")

    def _create_ssl_context(self):
        try:
            certifi_ca_bundle = certifi.where()
            return ssl.create_default_context(cafile=certifi_ca_bundle)
        except Exception as error:
            logging.warning(f"[IMAGE-GEN-PROXY] Failed to use certifi CA bundle: {error}")
            return ssl.create_default_context()

    async def get_user_token(self) -> Optional[str]:
        local_token = get_current_user_token_string()
        if local_token:
            logging.info(f"[IMAGE-GEN-PROXY] Found token in local file (length: {len(local_token)})")
            return local_token

        auth_header = self.request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            logging.info("[IMAGE-GEN-PROXY] Found token in Authorization header")
            return auth_header[7:]

        logging.warning("[IMAGE-GEN-PROXY] No user token found")
        return None

    @web.authenticated
    async def post(self):
        try:
            try:
                body = json.loads(self.request.body or b"{}")
            except json.JSONDecodeError:
                self.set_status(400)
                self.finish(json.dumps({"error": "Invalid JSON in request body"}))
                return

            prompt = body.get("prompt")
            if not prompt or not str(prompt).strip():
                self.set_status(400)
                self.finish(json.dumps({"error": "Missing prompt"}))
                return

            user_token = await self.get_user_token()
            if not user_token:
                self.set_status(401)
                self.finish(json.dumps({"error": "No authentication token found"}))
                return

            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {user_token}"
            }

            request_data = dict(body)
            request_data["prompt"] = str(prompt).strip()

            ssl_context = self._create_ssl_context()
            timeout = aiohttp.ClientTimeout(total=90)

            async with aiohttp.ClientSession(timeout=timeout) as session:
                url = f"{self.remote_backend_url}/image_generate"
                logging.info(f"[IMAGE-GEN-PROXY] Forwarding request to: {url}")

                async with session.post(
                    url,
                    json=request_data,
                    headers=headers,
                    ssl=ssl_context
                ) as response:
                    response_text = await response.text()
                    if response.status == 200:
                        try:
                            response_data = json.loads(response_text)
                            self.finish(json.dumps(response_data))
                        except json.JSONDecodeError:
                            logging.error(f"[IMAGE-GEN-PROXY] Invalid JSON response: {response_text}")
                            self.set_status(502)
                            self.finish(json.dumps({"error": "Invalid response from server"}))
                    else:
                        logging.error(f"[IMAGE-GEN-PROXY] Remote backend error {response.status}: {response_text}")
                        self.set_status(response.status)
                        self.finish(response_text)

        except asyncio.TimeoutError:
            logging.error("[IMAGE-GEN-PROXY] Request timeout")
            self.set_status(408)
            self.finish(json.dumps({"error": "Request timeout"}))
        except Exception as error:
            logging.error(f"[IMAGE-GEN-PROXY] Unexpected error: {error}")
            self.set_status(500)
            self.finish(json.dumps({"error": f"Internal server error: {error}"}))
