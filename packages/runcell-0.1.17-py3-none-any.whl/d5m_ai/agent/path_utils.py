"""
Path helpers for resolving Jupyter contents paths safely.
"""

from __future__ import annotations

import os
import re
from typing import Tuple


def resolve_contents_path(file_path: str, root_dir: str) -> Tuple[str, str | None]:
    """
    Convert filesystem paths to Jupyter contents paths when possible.

    Returns:
        (resolved_path, error_message)
    """
    normalized = file_path.replace("\\", "/")
    is_absolute = normalized.startswith("/") or re.match(r"^[A-Za-z]:/", normalized)
    if not is_absolute:
        while normalized.startswith("./"):
            normalized = normalized[2:]
        return normalized, None

    root_dir = os.path.realpath(os.path.abspath(str(root_dir)))
    abs_path = os.path.realpath(os.path.abspath(file_path))

    try:
        common = os.path.commonpath([root_dir, abs_path])
    except ValueError:
        return normalized, _outside_root_message(file_path)

    if common != root_dir:
        return normalized, _outside_root_message(file_path)

    rel_path = os.path.relpath(abs_path, root_dir)
    return rel_path.replace(os.sep, "/"), None


def _outside_root_message(file_path: str) -> str:
    return (
        f"Error: File path '{file_path}' is outside the Jupyter server working directory "
        "and cannot be accessed for safety. Use a path under the working directory or open the file in Jupyter first."
    )
