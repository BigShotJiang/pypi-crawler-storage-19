"""Types.

Central object types
--------------------

.. autoclass:: ArtifactKind
.. autoclass:: TransformKind
.. autoclass:: DtypeStr

Basic types
-----------

.. autoclass:: UPathStr
.. autoclass:: StrField
.. autoclass:: ListLike
.. autoclass:: FieldAttr
"""

from __future__ import annotations

from typing import Literal, Union

import numpy as np
import pandas as pd
from django.db.models.query_utils import DeferredAttribute as FieldAttr
from lamindb_setup.types import UPathStr  # noqa: F401

# need to use Union because __future__.annotations doesn't do the job here <3.10
# typing.TypeAlias, >3.10 on but already deprecated
ListLike = Union[list[str], pd.Series, np.array]
StrField = Union[str, FieldAttr]  # typing.TypeAlias

TransformKind = Literal["pipeline", "notebook", "script", "function"]
TransformType = TransformKind  # backward compat
ArtifactKind = Literal["dataset", "model", "__lamindb_run__", "__lamindb_config__"]

DtypeStr = Literal[
    "num",  # numericals
    "str",  # string
    "int",  # integer / numpy.integer
    "float",  # float
    "bool",  # boolean
    "date",  # date
    "datetime",  # datetime
    "dict",  # dictionary
    "object",  # this is a pandas input dtype, we're only using it for complicated types, not for strings
    "path",  # path, validated as str, but specially treated in the UI
]
"""String-serialized data type.

String-serialized representations of common data types.

Overview
========

============  ============  =================================================
description   lamindb       pandas
============  ============  =================================================
numerical     `"num"`       `int | float`
integer       `"int"`       `int64 | int32 | int16 | int8 | uint | ...`
float         `"float"`     `float64 | float32 | float16 | float8 | ...`
string        `"str"`       `object`
datetime      `"datetime"`  `datetime`
date          `"date"`      `object` (pandera requires an ISO-format string, convert with `df["date"] = df["date"].dt.date`)
dictionary    `"dict"`      `object`
path          `"path"`      `str` (pandas does not have a dedicated path type, validated as `str`)
============  ============  =================================================

Categoricals
============

`lamindb` allows you to define a registry to which categoricals values are restricted.

For example, `'cat[ULabel]'` or `'cat[bionty.CellType]'` indicate that permissible values are stored in the `name` field of the `ULabel` or `CellType` registry, respectively.

You can also restrict to sub-types defined in registries via the `type` column, e.g., `'cat[ULabel[123456ABCDEFG]]'` indicates that values must be of the type with `uid="123456ABCDEFG"` within the `ULabel` registry.

Literal
=======

A `DtypeStr` object in `lamindb` is a `Literal` up to further specification of `"cat"`.

"""
Dtype = DtypeStr  # backward compat
