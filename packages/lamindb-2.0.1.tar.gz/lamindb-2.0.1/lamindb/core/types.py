from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from anndata import AnnData
from lamindb_setup.types import UPathStr

from lamindb.base.types import (
    Dtype,
    FieldAttr,
    ListLike,
    StrField,
    TransformKind,
)

MuData = TypeVar("MuData")
SpatialData = TypeVar("SpatialData")

ScverseDataStructures = AnnData | MuData | SpatialData
