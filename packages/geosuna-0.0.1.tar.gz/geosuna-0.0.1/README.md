Géosuna DOI
===========

Python library to validate [Géosuna](https://ids.osuna.univ-nantes.fr/) resources to register DOI in [DataCite](https://datacite.org/).


## Install this package
```bash
pip install geosuna
```

## Validate a ressource
```bash
geosuna-validate 2ae0bfa2-d8fa-42ab-bc16-4724a3b36a29 626c9459-1cd8-43a2-a371-6856e442a4aa
```

## Create a new DOI
```bash
geosuna-doi 626c9459-1cd8-43a2-a371-6856e442a4aa
```

## Create DOI badges
```bash
geosuna-doi --badges 626c9459-1cd8-43a2-a371-6856e442a4aa
```

## Developer

This package is managed with [uv](https://docs.astral.sh/uv/).

Check the syntax:
```bash
uv run ruff fmt
uv run ruff check
```

Run the tests:
```bash
uv run pytest
```
