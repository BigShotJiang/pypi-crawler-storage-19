"""Test package version."""

import re

import geosuna


def test_package_version():
    """Test package version."""
    assert re.match(r"^\d+\.\d+.\d+$", geosuna.__version__)
