"""GeoNetwork submodule."""

from .validate import validate

__all__ = [
    "validate",
]
