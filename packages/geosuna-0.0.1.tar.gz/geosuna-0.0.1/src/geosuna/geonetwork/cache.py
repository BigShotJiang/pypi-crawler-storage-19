"""GeoNetwork datasets cache."""

from pathlib import Path
from tempfile import gettempdir

# Temporary cache folder for ressources assets
TMP = Path(gettempdir())

CACHE = TMP / 'geonetwork'
CACHE.mkdir(parents=True, exist_ok=True)
