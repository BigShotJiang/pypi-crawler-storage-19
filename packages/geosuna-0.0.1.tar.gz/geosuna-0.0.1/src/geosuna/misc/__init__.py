"""Miscellaneous submodule."""

from .size import file_size


__all__ = [
    "file_size",
]
