"""Miscellaneous file size submodule."""

from math import log2

import requests

SIZE_UNITS = ["", "k", "M", "G", "T", "P"]


def file_size(url):
    size = int(requests.head(url).headers["Content-Length"])
    i = int(log2(size) // 10)
    return f"{size / 2 ** (10 * i):.0f} {SIZE_UNITS[i]}B"
