"""Geosuna DOI version."""

__version__ = "0.0.1"
