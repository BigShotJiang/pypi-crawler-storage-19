"""Datacite credentials."""

from os import environ

import requests


# DataCite API endpoints
if environ.get("DATACITE_PROD"):
    API = "https://api.datacite.org"
    MDS = "https://mds.datacite.org"
    PREFIX = "10.18465"
elif environ.get("DATACITE_TEST"):
    API = "https://api.test.datacite.org"
    MDS = "https://mds.test.datacite.org"
    PREFIX = "10.15454"
else:
    raise KeyError('Missing DATACITE configuration')


SESSION = requests.Session()
SESSION.auth = (environ.get("DATACITE_USERNAME"), environ.get("DATACITE_PASSWORD"))
SESSION.headers.update(
    {
        "content-type": "application/json",
        "accept": "application/vnd.api+json",
    }
)
