"""DOI submodule."""

from .datacite import GeoNetworkDOI

__all__ = [
    "GeoNetworkDOI",
]
