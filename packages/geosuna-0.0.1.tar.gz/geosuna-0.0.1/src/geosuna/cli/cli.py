"""GeoNetwork commande line interface."""

import sys
from argparse import ArgumentParser

from ..geonetwork import validate
from ..doi import GeoNetworkDOI


def cli_validate(argv=None):
    """CLI to validate geonetwork ressources."""
    parser = ArgumentParser(description='Geonetwork ressource validator')
    parser.add_argument('uuid', help='Ressource UUID.', nargs='+')

    args, _ = parser.parse_known_args(argv)

    for uuid in args.uuid:
        if validate(uuid, verbose=False):
            print("  🙌 Valid: A DOI can be issued for this resource")
        print()


def cli_doi(argv=None):
    """CLI to publish DOI from a geonetwork ressources."""
    parser = ArgumentParser(description="DataCite DOI publication")
    parser.add_argument("uuid", nargs="+", help="One or multiple GéOsuna UUID.")
    parser.add_argument("--draft", action="store_true", help="Draft DOI.")
    parser.add_argument("--publish", action="store_true", help="Publish DOI.")
    parser.add_argument(
        "--delete", action="store_true", help="Delete DOI (only unregistered)."
    )
    parser.add_argument("--hide", action="store_true", help="Hide DOI.")
    parser.add_argument(
        "--badges",
        action="store_true",
        help="Create markdown badges for published badges.",
    )

    args, _ = parser.parse_known_args(argv)

    dois = [GeoNetworkDOI(uuid) for uuid in args.uuid]

    if args.badges:
        for doi in dois:
            match doi.status:
                case "findable":
                    print(doi.badge(color="blue"))

                case "registered":
                    print(doi.badge(color="orange"))
        return

    for doi in dois:
        match doi.status:
            case "undefined":
                if args.draft:
                    doi.draft()

                elif args.publish:
                    doi.publish()

            case "draft":
                if args.delete:
                    doi.delete()

                elif args.publish:
                    doi.publish()

            case "registered":
                if args.publish:
                    doi.publish(force=True)

            case "findable":
                if args.hide:
                    doi.hide()

    for doi in dois:
        match doi.status:
            case "undefined":
                print(
                    f"{doi.uuid} | ❌ no DOI         | {IDS}/resources/records/{doi.uuid}"
                )
            case "draft":
                print(f"{doi.uuid} | 🔨 DOI drafted    | {doi.datacite}")
            case "registered":
                print(f"{doi.uuid} | 📋 DOI registered | doi: {doi}")
            case "findable":
                print(f"{doi.uuid} | 🌍 DOI findable   | doi: {doi}")
