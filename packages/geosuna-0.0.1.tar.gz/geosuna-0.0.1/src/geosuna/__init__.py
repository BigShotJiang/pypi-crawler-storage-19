"""Geosuna DOI module."""

from .geonetwork import validate

from .__version__ import __version__


__all__ = [
    "validate",
    "__version__",
]
