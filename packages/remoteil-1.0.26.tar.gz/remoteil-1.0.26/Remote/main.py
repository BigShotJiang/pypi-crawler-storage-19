from pyrogram import Client, filters
import logging
import time
from .config import config
from .filters import admin_or_owner_filter
from .inline_buttons.main import get_main_menu_inline_keyboard 
from .inline_buttons.account import get_account_menu_inline_keyboard, get_back_to_account_menu_inline_keyboard, get_set_code_pass_menu_inline_keyboard, get_back_to_set_code_pass_menu_inline_keyboard
from .inline_buttons.spammer import get_attack_menu_inline_keyboard, get_back_to_spammer_menu_inline_keyboard
from .systems.state_manger import StateManager
from .systems.session_manger import SessionManager
from .function.func import show_accounts
from .function.func import (add_account_phone, change_first_name, delete_account,
                            join_chat, leave_chat, set_profile_photo,
                            verify_code, verify_password, start_spam,
                            changed_time_sleep, handle_add_caption, handle_remove_target,
                            handle_add_target, handle_add_text, handle_delete_caption,
                            handle_delete_text, stop_spam_handler)

# Initialize state manager
state_handler = StateManager()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/main.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


@Client.on_message(filters.command("start", '', '/'))
async def start_bot(client, message):
    """🚀 Handle /start command"""
    welcome_text = """
    ✨ **Welcome to Remote Account Manager** ✨
    
    🤖 *Powerful Telegram Bot for Account Management*
    
    🔹 **Features:**
    • Multiple Account Management
    • Advanced Spammer Control
    • Profile Customization
    • Group Operations
    
    👇 Select an option below to get started!
    """
    await message.reply(
        text=welcome_text,
        reply_markup=get_main_menu_inline_keyboard()
    )


@Client.on_callback_query(admin_or_owner_filter)
async def handle_callback(client, callback_query):
    """🔘 Handle all callback queries"""
    data = callback_query.data
    user_id = callback_query.from_user.id

    try:
        # 🔙 BACK BUTTONS SECTION
        if data == "back_main_data":
            await callback_query.message.edit_text(
                "🏠 **Main Menu**\n\nSelect an option below:",
                reply_markup=get_main_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "back_spamer_data":
            await callback_query.message.edit_text(
                "⚡ **Spammer Control Panel**",
                reply_markup=get_attack_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "back_account_data":
            await callback_query.message.edit_text(
                "👤 **Account Management**",
                reply_markup=get_account_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "go_account_menu_data":
            await callback_query.message.edit_text(
                "👤 **Account Management Panel**",
                reply_markup=get_account_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "go_account_spammer_data":
            await callback_query.message.edit_text(
                "⚡ **Spammer Control Panel**",
                reply_markup=get_attack_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "back_set_code_pass_data":
            await callback_query.message.edit_text(
                "🔐 **Verification Menu**\n\nPlease select an option:",
                reply_markup=get_set_code_pass_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )

        # 👤 ACCOUNT MANAGEMENT SECTION
        elif data == "add_account_data":
            state_handler.set_state(user_id, 'addAcc')
            await callback_query.answer("📱 Send phone number")
            await callback_query.message.edit_text(
                "📱 **Add New Account**\n\n"
                "Please send your phone number in international format:\n"
                "`+989123456789`\n\n"
                "⚠️ *Make sure to include country code!*",
                reply_markup=get_set_code_pass_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "set_code_account_data":
            state_handler.set_state(user_id, 'waiting_code')
            await callback_query.answer("🔢 Enter verification code")
            await callback_query.message.edit_text(
                "🔢 **Verification Code Required**\n\n"
                "Please enter the 5-digit verification code sent to your phone:\n\n"
                "⏰ *Code expires in 2 minutes*",
                reply_markup=get_back_to_set_code_pass_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "set_pass_account_data":
            state_handler.set_state(user_id, 'waiting_password')
            await callback_query.answer("🔐 Enter 2FA password")
            await callback_query.message.edit_text(
                "🔐 **Two-Factor Authentication**\n\n"
                "This account has 2FA enabled.\n"
                "Please enter your password:",
                reply_markup=get_back_to_set_code_pass_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "delete_account_data":
            state_handler.set_state(user_id, 'delAcc')
            await callback_query.answer("🗑️ Enter account to delete")
            await callback_query.message.edit_text(
                "🗑️ **Delete Account**\n\n"
                "Enter the phone number of the account you want to remove:\n"
                "Format: `+989123456789`",
                reply_markup=get_back_to_account_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "list_account_data":
            state_handler.set_state(user_id, 'seeAccList')
            await show_accounts(callback_query)
            await callback_query.answer("📋 Loading account list...")
        
        elif data == "profile_photo_data":
            state_handler.set_state(user_id, 'profilePhoto')
            await callback_query.message.edit_text(
                "🖼️ **Change Profile Photo**\n\n"
                "Send a new profile photo or type 'cancel' to abort.\n\n"
                "📸 *Supported formats: JPG, PNG*",
                reply_markup=get_back_to_account_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("📸 Send photo")
        
        elif data == "profile_name_data":
            state_handler.set_state(user_id, 'profileName')
            await callback_query.message.edit_text(
                "✏️ **Change Profile Name**\n\n"
                "Enter new profile name or type 'cancel':",
                reply_markup=get_back_to_account_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("✏️ Enter new name")
        
        elif data == "join_group_data":
            state_handler.set_state(user_id, 'joinGP')
            await callback_query.message.edit_text(
                "➕ **Join Group**\n\n"
                "Send group invite link or username:\n"
                "• https://t.me/joinchat/xxxx\n"
                "• @username",
                reply_markup=get_back_to_account_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("🔗 Send group link")
        
        elif data == "leave_group_data":
            state_handler.set_state(user_id, 'leaveGP')
            await callback_query.message.edit_text(
                "➡️ **Leave Group**\n\n"
                "Send group invite link or Chat ID to leave:",
                reply_markup=get_back_to_account_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("🚪 Send group to leave")

        # ⚡ SPAMMER CONTROL SECTION
        elif data == "start_spam_data":
            state_handler.set_state(user_id, 'startSpammer')
            await callback_query.answer("🚀 Starting spammer...")
            
            await callback_query.message.edit_text(
                "🚀 **Spammer Activated**\n\n"
                "✅ Spammer started working in background.\n"
                "📊 Monitoring active sessions...",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "stop_spam_data":
            state_handler.set_state(user_id, 'stopSpammer')
            
            await callback_query.message.edit_text(
                "🛑 **Stop Spammer**\n\n"
                "Do you want to clear all texts as well?\n\n"
                "Type: `yes` or `no`",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "speed_spam_data":
            state_handler.set_state(user_id, 'speed')
            await callback_query.answer("⚡ Adjust speed")
            
            await callback_query.message.edit_text(
                "⚡ **Spammer Speed Control**\n\n"
                "Enter delay between messages (in seconds):\n\n"
                "📌 *Example:* `2` = 2 seconds delay\n"
                "📌 *Recommended:* 3-5 seconds",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "add_target_data":
            state_handler.set_state(user_id, 'addTar')
            await callback_query.answer("🎯 Add target")
            
            await callback_query.message.edit_text(
                "🎯 **Add Target**\n\n"
                "Send new target link or Chat ID:\n\n"
                "🔗 *Supported formats:*\n"
                "• https://t.me/username\n"
                "• @username\n"
                "• Chat ID (numeric)",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "remove_target_data":
            state_handler.set_state(user_id, 'removeTar')
            await callback_query.answer("➖ Remove target")
            
            await callback_query.message.edit_text(
                "➖ **Remove Target**\n\n"
                "Send target Chat ID to delete from list:",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "list_target_data":
            target_list = "\n".join(f"• `{item}`" for item in config["chat"])
            if not target_list:
                target_list = "📭 *No targets added yet*"
            
            await callback_query.answer("📋 Loading target list...")
            
            
            await callback_query.message.edit_text(
                f"🎯 **Target List**\n\n"
                f"{target_list}\n\n"
                f"📊 *Total: {len(config['chat'])} targets*",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
        
        elif data == "add_text_data":
            state_handler.set_state(user_id, 'addText')
            
            await callback_query.message.edit_text(
                "📝 **Add Spam Text**\n\n"
                "Send new text to add to spam list:",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("📝 Add text")
        
        elif data == "del_text_data":
            state_handler.set_state(user_id, 'delText')
            
            await callback_query.message.edit_text(
                "🗑️ **Clear All Texts**\n\n"
                "Are you sure you want to clear ALL texts?\n\n"
                "Type: `yes` to confirm\n"
                "Type: `no` to cancel",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("⚠️ Confirm deletion")
        
        elif data == "show_text_data":
            if config["texts"]:
                text_list = ""
                for i, text in enumerate(config["texts"], 1):
                    text_list += f"{i}. `{text[:50]}...`\n" if len(text) > 50 else f"{i}. `{text}`\n"
                
                response_text = (
                    f"📝 **Text List**\n\n"
                    f"{text_list}\n"
                    f"📊 *Total: {len(config['texts'])} texts*"
                )
            else:
                response_text = "📭 **No texts available**\n\nAdd some texts first!"
            
            await callback_query.message.edit_text(
                response_text,
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("📋 Showing texts")
        
        elif data == "add_caption_data":
            state_handler.set_state(user_id, 'addCap') 
            await callback_query.message.edit_text(
                "🏷️ **Add Caption**\n\n"
                "Send caption text (will be added to all messages):",
                reply_markup=get_back_to_spammer_menu_inline_keyboard(),
                reply_to_message_id=user_id
            )
            await callback_query.answer("🏷️ Add caption")
        
        elif data == "del_caption_data":
            state_handler.set_state(user_id, 'delCap')
            
            await callback_query.message.edit_text(
                "✂️ **Delete Caption**\n\n"
                "Do you want to delete the current caption?\n\n"
                "Type: `yes` or `no`",
                reply_markup=get_back_to_spammer_menu_inline_keyboard()
            )
            await callback_query.answer("⚠️ Confirm caption deletion")
        
        elif data == "show_caption_data":
            caption_text = config["caption"] if config["caption"] else "📭 *No caption set*"
            
            await callback_query.message.edit_text(
                f"🏷️ **Current Caption**\n\n`{caption_text}`",
                reply_markup=get_back_to_spammer_menu_inline_keyboard()
            )
            
    except Exception as e:
        error_msg = f"⚠️ **An error occurred!**\n\n`{str(e)[:200]}...`"
        await callback_query.answer("❌ Error occurred!", show_alert=True)
        logger.error(f"Callback error: {e}")


@Client.on_message(filters.text & admin_or_owner_filter)
async def text_message_handler(client, message):
    """📝 Handle all text messages for state operations"""
    user_id = message.from_user.id
    text_msg = message.text.strip()
    
    state_data = state_handler.get_state(user_id)
    if not state_data:
        return
    
    state = state_data['state']
    
    try:
        # Get the message ID to reply to
        reply_to_message_id = user_id
        
        # 🗺️ STATE ROUTING
        state_handlers = {
            "addAcc": lambda: add_account_phone(message, text_msg, reply_to_message_id),
            "delAcc": lambda: delete_account(message, text_msg, reply_to_message_id),
            "waiting_code": lambda: verify_code(message, text_msg, reply_to_message_id),
            "waiting_password": lambda: verify_password(message, text_msg, reply_to_message_id),
            "profileName": lambda: change_first_name(message, text_msg, reply_to_message_id),
            "profilePhoto": lambda: set_profile_photo(message, reply_to_message_id) if text_msg.lower() == "set" else None,
            "joinGP": lambda: join_chat(message, text_msg, reply_to_message_id),
            "leaveGP": lambda: leave_chat(message, text_msg, reply_to_message_id),
            "startSpammer": lambda: start_spam(message, text_msg, reply_to_message_id),
            "stopSpammer": lambda: stop_spam_handler(message, text_msg, reply_to_message_id),
            "speed": lambda: changed_time_sleep(message, int(text_msg), reply_to_message_id),
            "addTar": lambda: handle_add_target(message, text_msg, reply_to_message_id),
            "removeTar": lambda: handle_remove_target(message, text_msg, reply_to_message_id),
            "addText": lambda: handle_add_text(message, text_msg, reply_to_message_id),
            "delText": lambda: handle_delete_text(message, text_msg, reply_to_message_id),
            "addCap": lambda: handle_add_caption(message, text_msg, reply_to_message_id),
            "delCap": lambda: handle_delete_caption(message, text_msg, reply_to_message_id),
        }
        
        handler = state_handlers.get(state)
        if handler:
            await handler()
        
        state_handler.clear_state(user_id)
        
    except ValueError as e:
        error_text = f"❌ **Invalid Input**\n\nPlease check your input format.\n\n`{str(e)}`"
        await message.reply_text(error_text, reply_to_message_id=reply_to_message_id)
        logger.error(f"Value error in text handler: {e}")
        state_handler.clear_state(user_id)
        
    except Exception as e:
        # Try to reply to the original message if available
        error_text = f"⚠️ **Operation Failed**\n\n`{str(e)[:150]}...`"
        
        try:
            if reply_to_message_id:
                await message.reply_text(error_text, reply_to_message_id=reply_to_message_id)
            else:
                await message.reply_text(error_text)
        except:
            await message.reply_text("❌ An unexpected error occurred!")
        
        logger.error(f"Error in text handler (state: {state}): {e}")
        state_handler.clear_state(user_id)