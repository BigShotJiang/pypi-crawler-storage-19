from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message

def get_main_menu_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([ 
        [ 
            InlineKeyboardButton("👤 Account Manager", callback_data="go_account_menu_data"),
            InlineKeyboardButton("⚡ Spammer Control", callback_data="go_account_spammer_data"),
        ],  
        [
            InlineKeyboardButton("🆘 Help & Support", url="https://t.me/Mr_ahmadirad"),
        ]
    ])