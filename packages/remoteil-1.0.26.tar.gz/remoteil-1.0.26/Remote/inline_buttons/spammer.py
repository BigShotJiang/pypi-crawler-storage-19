from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message
    
def get_attack_menu_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🚀 Start Spammer", callback_data="start_spam_data"),
            InlineKeyboardButton("🛑 Stop Spammer", callback_data="stop_spam_data"),
        ],
        [    
            InlineKeyboardButton("⚡ Spammer Speed", callback_data="speed_spam_data"),
        ],
        [
            InlineKeyboardButton("➕ Add Target", callback_data="add_target_data"),
            InlineKeyboardButton("➖ Remove Target", callback_data="remove_target_data"),
        ],
        [    
            InlineKeyboardButton("📋 Target List", callback_data="list_target_data"),
        ],
        [
            InlineKeyboardButton("📝 Add Text", callback_data="add_text_data"),
            InlineKeyboardButton("🗑 Clear Text", callback_data="del_text_data"),
        ],
        [
            InlineKeyboardButton("👁️ Show Texts", callback_data="show_text_data")
        ], 
        [
            InlineKeyboardButton("🏷️ Add Caption", callback_data="add_caption_data"),
            InlineKeyboardButton("✂️ Clear Caption", callback_data="del_caption_data"),
        ], 
        [
            InlineKeyboardButton("👁️ Show Caption", callback_data="show_caption_data")
        ], 
        [
            InlineKeyboardButton("🔙 Back to Main", callback_data="back_main_data")
        ], 
    ])


def get_back_to_spammer_menu_inline_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [ 
            InlineKeyboardButton("◀️ Back to Spammer Menu", callback_data="back_spamer_data")
        ], 
    ])