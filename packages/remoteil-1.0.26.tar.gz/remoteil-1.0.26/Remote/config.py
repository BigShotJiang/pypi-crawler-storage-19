config = {
    "owner":[5053851121],
    "admin": [5053851121],
    "bot_token": "7585920459:AAH9opUlfMXYK7gY9yG58jqqwuP6ot5leJ4",
    "name": "MrAhmadiRad",
    "api_id": 12176206,
    "api_hash": "b8eff20a7e8adcdaa3daa3bc789a5b41",
    "caption": "",
    "speed": 1,
    "run": False,
    "chat": [],
    "texts": [],
}  
ACCOUNTS_FOLDER = 'accs' 