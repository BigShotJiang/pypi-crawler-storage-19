from pyrogram import errors
import threading , logging , asyncio
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/FloodWaitManager.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class FloodWaitManager:
    def __init__(self):
        self.account_limits = {}
        self.global_stats = {'success': 0, 'floodwaits': 0, 'errors': 0}
        self.lock = threading.Lock()
    
    async def safe_operation(self, client, operation, *args, max_retries=3, operation_type="unknown"):
        for attempt in range(max_retries):
            try:
                result = await operation(*args)
                with self.lock:
                    self.global_stats['success'] += 1
                return result
            
            except errors.FloodWait as e:
                wait_time = e.value
                with self.lock:
                    self.global_stats['floodwaits'] += 1
                logger.warning(f"FloodWait: Waiting {wait_time}s for {operation_type}")
                await asyncio.sleep(wait_time + 2)  # 2 ثانیه اضافه برای اطمینان
            
            except errors.RPCError as e:
                logger.error(f"RPC Error in {operation_type}: {e}")
                if attempt == max_retries - 1:
                    with self.lock:
                        self.global_stats['errors'] += 1
                    raise e
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
            
            except Exception as e:
                logger.error(f"Unexpected error in {operation_type}: {e}")
                if attempt == max_retries - 1:
                    with self.lock:
                        self.global_stats['errors'] += 1
                    raise e
                await asyncio.sleep(1)
        
        return None
