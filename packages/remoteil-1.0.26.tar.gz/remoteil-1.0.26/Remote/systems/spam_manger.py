import threading , time
class SpamManager:
    def __init__(self):
        self.spam_operations = {}
        self.current_spam_indexes = {}
        self.lock = threading.Lock()
    
    def start_spam_operation(self, chat_id, operation_data):
        with self.lock:
            self.spam_operations[chat_id] = {
                'active': True,
                'chat_id': operation_data['chat_id'],
                'accounts': operation_data['accounts'][:],  # کپی کردن لیست
                'texts': operation_data['texts'][:],  # کپی کردن لیست
                'delay': operation_data['delay'],
                'message_count': 0,
                'start_time': time.time(),
                'last_account_index': 0
            }
            self.current_spam_indexes[chat_id] = 0
    
    def stop_spam_operation(self, chat_id):
        with self.lock:
            if chat_id in self.spam_operations:
                operation_data = self.spam_operations.pop(chat_id)
                self.current_spam_indexes.pop(chat_id, None)
                return operation_data
            return None
    
    def is_spam_active(self, chat_id):
        with self.lock:
            return chat_id in self.spam_operations and self.spam_operations[chat_id]['active']
    
    def increment_message_count(self, chat_id):
        with self.lock:
            if chat_id in self.spam_operations:
                self.spam_operations[chat_id]['message_count'] += 1
    
    def get_next_account_index(self, chat_id):
        with self.lock:
            if chat_id not in self.spam_operations:
                return 0
            operation = self.spam_operations[chat_id]
            if not operation['accounts']:
                return 0
            current_index = self.current_spam_indexes[chat_id]
            next_index = (current_index + 1) % len(operation['accounts'])
            self.current_spam_indexes[chat_id] = next_index
            return current_index
    
    def get_spam_operation(self, chat_id):
        with self.lock:
            return self.spam_operations.get(chat_id)
