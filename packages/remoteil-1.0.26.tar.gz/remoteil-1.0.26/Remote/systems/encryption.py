import os
from pathlib import Path
from cryptography.fernet import Fernet

class EncryptionManager:
    def __init__(self):
        self.key_file = 'downloads/encryption.key'
        self.backup_file = 'backups/encryption_key.backup'
        self.key = self._load_or_create_key()
    
    def _ensure_directories(self):
        """اطمینان از وجود پوشه‌های مورد نیاز"""
        # ایجاد پوشه downloads اگر وجود ندارد
        Path('downloads').mkdir(parents=True, exist_ok=True)
        # ایجاد پوشه backups اگر وجود ندارد
        Path('backups').mkdir(parents=True, exist_ok=True)
        # ایجاد پوشه Rimots برای سشن‌ها
        Path('Rimots').mkdir(parents=True, exist_ok=True)
        # ایجاد پوشه sessions برای کلاینت‌ها
        Path('sessions').mkdir(parents=True, exist_ok=True)
    
    def _load_or_create_key(self):
        """بارگذاری کلید موجود یا ایجاد کلید جدید"""
        # اول مطمئن شو پوشه‌ها وجود دارند
        self._ensure_directories()
        
        # اول سعی کن کلید اصلی رو بارگذاری کنی
        if os.path.exists(self.key_file):
            try:
                with open(self.key_file, 'rb') as f:
                    key = f.read()
                # print(f"✅ کلید از {self.key_file} بارگذاری شد")
                return key
            except Exception as e:
                print(f"⚠️ خطا در بارگذاری کلید اصلی: {e}")
                # اگر خطا داشت، ادامه بده و کلید جدید بساز
        
        # اگر کلید اصلی وجود نداشت، از بک‌آپ بارگذاری کن
        if os.path.exists(self.backup_file):
            try:
                with open(self.backup_file, 'rb') as f:
                    key = f.read()
                # کلید بک‌آپ رو در محل اصلی هم ذخیره کن
                with open(self.key_file, 'wb') as f:
                    f.write(key)
                # print(f"✅ کلید از بک‌آپ {self.backup_file} بارگذاری شد")
                return key
            except Exception as e:
                print(f"⚠️ خطا در بارگذاری کلید بک‌آپ: {e}")
                # اگر بک‌آپ هم مشکل داشت، ادامه بده
        
        # اگر هیچ کلیدی وجود نداشت، کلید جدید بساز
        print("🔑 در حال ایجاد کلید رمزنگاری جدید...")
        key = Fernet.generate_key()
        
        try:
            # ذخیره در فایل اصلی
            with open(self.key_file, 'wb') as f:
                f.write(key)
            # print(f"✅ کلید جدید در {self.key_file} ذخیره شد")
            
            # ذخیره بک‌آپ
            with open(self.backup_file, 'wb') as f:
                f.write(key)
            # print(f"✅ بک‌آپ کلید در {self.backup_file} ذخیره شد")
            
        except Exception as e:
            print(f"⚠️ خطا در ذخیره کلید: {e}")
            # اگر خطا در ذخیره فایل داشتیم، حداقل کلید رو برگردونیم
            pass
        
        return key
    
    def encrypt_data(self, data):
        """رمزنگاری داده"""
        fernet = Fernet(self.key)
        if isinstance(data, str):
            data = data.encode()
        return fernet.encrypt(data)
    
    def decrypt_data(self, encrypted_data):
        """رمزگشایی داده"""
        fernet = Fernet(self.key)
        return fernet.decrypt(encrypted_data).decode()
    
    def backup_key(self):
        """ایجاد بک‌آپ از کلید"""
        try:
            self._ensure_directories()
            with open(self.backup_file, 'wb') as f:
                f.write(self.key)
            # print(f"✅ بک‌آپ کلید در {self.backup_file} ایجاد شد")
            return True
        except Exception as e:
            print(f"❌ خطا در ایجاد بک‌آپ: {e}")
            return False