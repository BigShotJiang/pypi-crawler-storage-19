import threading , logging , time
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/OperationManager.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class OperationManager:
    def __init__(self):
        self.active_operations = {}
        self.operation_progress = {}
        self.operation_results = {}
        self.lock = threading.Lock()
    
    def start_operation(self, operation_id, operation_type, total_steps):
        with self.lock:
            self.active_operations[operation_id] = {
                'type': operation_type,
                'total_steps': total_steps,
                'current_step': 0,
                'start_time': time.time(),
                'status': 'running',
                'errors': []
            }
            self.operation_progress[operation_id] = 0
            logger.info(f"Operation started: {operation_type} (ID: {operation_id})")
            return operation_id
    
    def update_progress(self, operation_id, current_step, message=None):
        with self.lock:
            if operation_id in self.active_operations:
                self.active_operations[operation_id]['current_step'] = current_step
                progress = (current_step / self.active_operations[operation_id]['total_steps']) * 100
                self.operation_progress[operation_id] = progress
                
                if message:
                    self.operation_results[operation_id] = self.operation_results.get(operation_id, [])
                    self.operation_results[operation_id].append(message)
    
    def add_error(self, operation_id, error_message):
        with self.lock:
            if operation_id in self.active_operations:
                self.active_operations[operation_id]['errors'].append(error_message)
                logger.error(f"Operation {operation_id} error: {error_message}")
    
    def complete_operation(self, operation_id, final_message=None):
        with self.lock:
            if operation_id in self.active_operations:
                self.active_operations[operation_id]['status'] = 'completed'
                self.active_operations[operation_id]['end_time'] = time.time()
                
                if final_message:
                    self.operation_results[operation_id] = self.operation_results.get(operation_id, [])
                    self.operation_results[operation_id].append(final_message)
                
                logger.info(f"Operation completed: {operation_id}")
    
    def stop_operation(self, operation_id):
        with self.lock:
            if operation_id in self.active_operations:
                self.active_operations[operation_id]['status'] = 'stopped'
                self.active_operations[operation_id]['end_time'] = time.time()
                logger.info(f"Operation stopped: {operation_id}")
                return True
            return False
    
    def get_operation_status(self, operation_id):
        with self.lock:
            return self.active_operations.get(operation_id)
