from .encryption import EncryptionManager
import threading , logging
import os
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/SessionManager.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class SessionManager:
    def __init__(self):
        self.encryption = EncryptionManager()
        self.lock = threading.Lock()
    
    def save_session(self, phone_number, session_data):
        try:
            with self.lock:
                encrypted_data = self.encryption.encrypt_data(session_data)
                session_file = f'Rimots/{phone_number}.enc'
                with open(session_file, 'wb') as f:
                    f.write(encrypted_data)
                logger.info(f"Session saved for {phone_number}")
                return True
        except Exception as e:
            logger.error(f"Error saving session for {phone_number}: {e}")
            return False
    
    def load_session(self, phone_number):
        try:
            with self.lock:
                session_file = f'Rimots/{phone_number}.enc'
                if not os.path.exists(session_file):
                    return None
                with open(session_file, 'rb') as f:
                    encrypted_data = f.read()
                return self.encryption.decrypt_data(encrypted_data)
        except Exception as e:
            logger.error(f"Error loading session for {phone_number}: {e}")
            return None
    
    def delete_session(self, phone_number):
        try:
            with self.lock:
                session_file = f'Rimots/{phone_number}.enc'
                if os.path.exists(session_file):
                    # بازنویسی امن قبل از حذف
                    with open(session_file, 'wb') as f:
                        f.write(os.urandom(1024))
                    os.remove(session_file)
                    logger.info(f"Session deleted for {phone_number}")
                    return True
        except Exception as e:
            logger.error(f"Error deleting session for {phone_number}: {e}")
        return False

    def get_all_sessions(self):
        try:
            with self.lock:
                sessions = []
                for f in os.listdir('Rimots'):
                    if f.endswith('.enc'):
                        sessions.append(f.replace('.enc', ''))
                return sessions
        except Exception as e:
            logger.error(f"Error getting sessions: {e}")
            return []
