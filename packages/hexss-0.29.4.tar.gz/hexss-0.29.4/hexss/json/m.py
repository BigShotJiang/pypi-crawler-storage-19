import json

file_path = 'config.json'

with open(file_path, 'r') as f:
    data = json.load(f)

if 'ui' in data and 'colors' in data['ui']:
    data['ui']['colors'].pop('val', None)

with open(file_path, 'w') as f:
    json.dump(data, f, indent=4)
