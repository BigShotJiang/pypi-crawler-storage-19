# app.py
import random
import time
from pathlib import Path

import cv2
import numpy as np
from flask import Flask, jsonify, request, Response, render_template
from media_dataset import MediaDataset


def get_media_list(data_dir: Path):
    items = []
    for path in data_dir.glob('*'):
        if path.is_dir():
            items.append(path.name)
        if path.is_file():
            if path.suffix in ['.mp4', '.avi', '.mkv']:
                items.append(path.name)
    return items


app = Flask(__name__)


@app.route('/api/get_media_list')
def api_get_media_list():
    data: dict = app.config['data']
    media_dir: Path = data['media_dir']
    return jsonify(get_media_list(media_dir))


@app.route('/api/set_media')
def api_set_media():
    data: dict = app.config['data']
    media_dir: Path = data['media_dir']
    source = request.args.get('source')
    data['media'] = MediaDataset(media_dir / source)
    return jsonify({'source': data['media'].source_path.name})


@app.route('/api/get_frame_keys')
def api_get_frame_keys():
    data: dict = app.config['data']
    media: MediaDataset = data['media']
    return jsonify({'source': media.source_path.name, 'frame_keys': media.get_frame_keys()})


@app.route('/api/get_data_to_ui')
def api_get_annotation():
    data: dict = app.config['data']
    media: MediaDataset = data['media']
    frame_key = request.args.get('frame_key')
    frame = media.read_frame(frame_key)
    encode_param = [cv2.IMWRITE_JPEG_QUALITY, 95]
    ret, buffer = cv2.imencode('.jpg', frame, encode_param)
    frame_bytes = buffer.tobytes()
    frame_bytes = b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n'
    return jsonify({
        'source': media.source_path.name,
        'frame_key': frame_key,
        'annotation': media.get_annotation(frame_key),
        'frame_bytes': frame_bytes
    })


@app.route('/api/stream/frame')
def api_stream_frame():
    data: dict = app.config['data']
    media: MediaDataset = data['media']

    def generate():
        while data.get('running', False):
            encode_param = [cv2.IMWRITE_JPEG_QUALITY, 95]
            ret, buffer = cv2.imencode('.jpg', media.frame, encode_param)
            frame_bytes = buffer.tobytes()
            yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n'
            time.sleep(0.1)

    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/test/video')
def get_video():
    def generate():
        while True:
            frame = np.full(
                (random.randint(100, 480), random.randint(100, 640), 3),
                (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)),
                dtype=np.uint8
            )
            encode_param = [cv2.IMWRITE_JPEG_QUALITY, 95]
            ret, buffer = cv2.imencode('.jpg', frame, encode_param)
            frame_bytes = buffer.tobytes()
            yield b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n'
            time.sleep(0.1)

    return Response(generate(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/')
def index():
    return render_template('index.html')


def run(data):
    app.config['data'] = data
    app.run(host='0.0.0.0', port=5000)


if __name__ == '__main__':
    run({
        'running': True,
        'media_dir': Path('data01'),
        'media': None
    })
