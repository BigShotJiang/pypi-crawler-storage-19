from pathlib import Path

import cv2
import numpy as np
from flask import Flask, jsonify, request, Response, render_template
from media_dataset import MediaDataset

app = Flask(__name__)


def get_media_list(data_dir: Path):
    items = []
    if not data_dir.exists():
        return items

    for path in data_dir.glob('*'):
        if path.is_dir():
            items.append(path.name)
        if path.is_file():
            if path.suffix.lower() in ['.mp4', '.avi', '.mkv', '.mov']:
                items.append(path.name)
    return sorted(items)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/get_media_list')
def api_get_media_list():
    data: dict = app.config['data']
    media_dir: Path = data['media_dir']
    return jsonify(get_media_list(media_dir))


@app.route('/api/set_media')
def api_set_media():
    data: dict = app.config['data']
    media_dir: Path = data['media_dir']
    source = request.args.get('source')
    try:
        data['media'] = MediaDataset(media_dir / source)
        return jsonify({
            'status': 'success',
            'source': data['media'].source_path.name
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 400


@app.route('/api/get_frame_keys')
def api_get_frame_keys():
    """API: ส่งรายการ Index ของเฟรมทั้งหมดให้ Slider"""
    data: dict = app.config['data']
    media: MediaDataset = data['media']

    if media is None:
        return jsonify({'frame_keys': []})

    return jsonify({
        'source': media.source_path.name,
        'frame_keys': media.get_frame_keys()
    })


@app.route('/api/update_frame')
def api_update_frame():
    """
    /api/update_frame?frame_key=${frameKey}
    """
    data: dict = app.config['data']
    media: MediaDataset = data['media']
    frame_key = request.args.get('frame_key')

    media.read_frame(frame_key)
    return jsonify({
        'status': 'success',
        'frame_key': frame_key,
        'annotation': media.get_annotation(frame_key)
    })


@app.route('/api/get_image')
def api_get_image():
    """
    API: ส่งรูปภาพ Jpeg ของเฟรมปัจจุบัน
    Frontend จะเรียกใช้ผ่าน <img src="/api/get_image">
    """
    data: dict = app.config['data']
    media: MediaDataset = data['media']

    if media is None or not hasattr(media, 'frame') or media.frame is None:
        blank = np.zeros((100, 100, 3), np.uint8)
        ret, buffer = cv2.imencode('.jpg', blank)
    else:
        ret, buffer = cv2.imencode('.jpg', media.frame)

    return Response(buffer.tobytes(), mimetype='image/jpeg')


@app.route('/api/update_box', methods=['POST'])
def api_update_box():
    """
    Receives JSON data to update or create a box.
    Expects: { "frame_key": str, "box_id": str, "xywhn": [float, float, float, float] }
    """
    data_store: dict = app.config['data']
    media: MediaDataset = data_store['media']

    req = request.json
    frame_key = req.get('frame_key')
    box_id = req.get('box_id')
    xywhn = req.get('xywhn')

    if not all([frame_key, box_id, xywhn]):
        return jsonify({'error': 'Missing parameters'}), 400

    try:
        xywhn = [float(x) for x in xywhn]
        media.update_box(frame_key, box_id, xywhn)

        return jsonify({
            'status': 'success',
            'box_id': box_id,
            'xywhn': xywhn
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


def run(data):
    app.config['data'] = data
    app.run(host='0.0.0.0', port=5000, debug=True)


if __name__ == '__main__':
    data_path = Path('data01')
    if not data_path.exists():
        data_path.mkdir(parents=True, exist_ok=True)
        print(f"Created data directory at {data_path}")

    run({
        'running': True,
        'media_dir': data_path,
        'media': None
    })
