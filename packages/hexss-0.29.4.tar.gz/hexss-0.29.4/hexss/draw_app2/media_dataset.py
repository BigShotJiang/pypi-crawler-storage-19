from typing import Dict, List, Any, Optional
from pathlib import Path

import cv2
from hexss import json_load, json_update
from hexss.box import Box


class MediaDataset:
    def __init__(self, source_path: Path | str) -> None:
        self.source_path = Path(source_path)
        if not self.source_path.exists():
            raise FileNotFoundError(f"Path does not exist: {self.source_path}")

        self.is_dir = self.source_path.is_dir()
        self.annotation_path = self.source_path.with_suffix('.json')
        self.annotations = json_load(self.annotation_path, default={})

        self.cap: Optional[cv2.VideoCapture] = None
        if not self.is_dir:
            self.cap = cv2.VideoCapture(str(self.source_path))
            if not self.cap.isOpened():
                raise ValueError(f"Failed to open video file: {self.source_path}")

        self.frame = None

    def get_frame_keys(self) -> List[str]:
        if self.is_dir:
            return sorted([p.name for p in self.source_path.glob('*.png')])
        else:
            if self.cap is None: return []
            frame_count = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))
            return [str(i) for i in range(frame_count)]

    def read_frame(self, frame_key: str) -> cv2.Mat:
        if self.is_dir:
            img_path = self.source_path / frame_key
            self.frame = cv2.imread(str(img_path))
        else:
            if self.cap is None:
                raise RuntimeError("Video capture is not initialized")
            frame_idx = int(frame_key)
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
            ret, frame = self.cap.read()
            if ret:
                self.frame = frame

        return self.frame

    def get_annotation(self, frame_key: str) -> Dict[str, Any]:
        return self.annotations.get(frame_key, {})

    def set(self, k, v):
        self.annotations = json_update(self.annotation_path, {k: v}, deep="/")

    def update_box(self, frame_key: str, box_id: str, xywhn: list | tuple,
                   detection_label=None, classification_label=None):
        new_data = {f"{frame_key}/boxes/{box_id}/xywhn": xywhn}
        if detection_label:
            new_data[f"{frame_key}/boxes/{box_id}/detection/label"] = detection_label
        if classification_label:
            new_data[f"{frame_key}/boxes/{box_id}/classification/label"] = classification_label
        self.annotations = json_update(self.annotation_path, new_data, deep="/")

    def release(self):
        if self.cap is not None:
            self.cap.release()
            self.cap = None

    def __del__(self):
        self.release()


if __name__ == '__main__':
    # example
    path = Path('data01/img01')
    # path = Path('data01/video01.mp4')

    dataset = MediaDataset(path)
    print(f"Annotation Path: {dataset.annotation_path}")

    frame_keys = dataset.get_frame_keys()
    print(f"Total Frames: {len(frame_keys)}")
    for frame_key in frame_keys:
        print(f"Frame Key: {frame_key}")
        img = dataset.read_frame(frame_key)

        frame_data = dataset.get_annotation(frame_key)
        boxes_data = frame_data.get('boxes')

        if boxes_data:
            for box_id, box_info in boxes_data.items():

                dataset.set(f"{frame_key}/boxes/{box_id}/detection/label", "a1")

                box = Box(xywhn=box_info['xywhn'], size=img.shape[:2])
                p1 = box.x1y1.astype(int)
                p2 = box.x2y2.astype(int)
                cv2.rectangle(img, p1, p2, (0, 0, 255), 2)
                label = box_info.get('detection', {}).get('label')
                if label:
                    cv2.putText(img, str(label), (p1[0], p1[1] - 10),
                                0, 0.5, (0, 0, 255), 1)

        cv2.imshow('img', cv2.resize(img, None, fx=0.5, fy=0.5))
        key = cv2.waitKey(0) & 0xFF
        if key == ord('q'):
            break
        if key == ord('a'):
            print(boxes_data.keys())
            box_id = list(boxes_data.keys())[0]
            box_info = boxes_data[box_id]
            xn, yn, wn, hn = box_info['xywhn']
            xn = 1.1 * xn
            dataset.update_box(frame_key, box_id, [xn, yn, wn, hn], detection_label='a', classification_label='b')
