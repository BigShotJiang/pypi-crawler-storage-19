"""Authentication commands."""

import asyncio
import os

import click
from rich.console import Console

from iseq_flow.auth import (
    AuthError,
    clear_token,
    device_flow_login,
    get_stored_token,
    is_token_expired,
    password_login,
    store_token,
)

console = Console()


@click.command()
@click.option("--email", "-e", envvar="FLOW_EMAIL", help="Email for password auth (or set FLOW_EMAIL)")
@click.option("--password", "-p", envvar="FLOW_PASSWORD", help="Password for auth (or set FLOW_PASSWORD)")
def login(email: str | None, password: str | None):
    """
    Login to Flow.

    \b
    By default uses OAuth Device Flow (opens browser).
    For headless/CI environments, use --email and --password options.

    \b
    Examples:
      flow login                           # Interactive Device Flow
      flow login -e user@example.com -p x  # Password auth (no 2FA)
      FLOW_EMAIL=x FLOW_PASSWORD=y flow login  # Via env vars
    """
    try:
        if email and password:
            # Use password-based authentication
            console.print(f"[dim]Logging in as {email}...[/dim]")
            token = asyncio.run(password_login(email, password))
        else:
            # Use Device Flow (interactive)
            token = asyncio.run(device_flow_login())

        store_token(token)
        console.print()
        console.print("[green]Successfully logged in![/green]")
    except AuthError as e:
        console.print(f"[red]Login failed:[/red] {e}")
        raise SystemExit(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Login cancelled.[/yellow]")
        raise SystemExit(1)


@click.command()
def logout():
    """Logout and clear stored credentials."""
    clear_token()
    console.print("[green]Logged out successfully.[/green]")


@click.command()
def status():
    """Show current authentication status."""
    token = get_stored_token()

    if not token:
        console.print("[yellow]Not logged in.[/yellow]")
        console.print("Run [bold]flow login[/bold] to authenticate.")
        return

    if is_token_expired(token):
        console.print("[yellow]Token expired.[/yellow]")
        console.print("Run [bold]flow login[/bold] to re-authenticate.")
        return

    console.print("[green]Logged in.[/green]")

    # Try to decode token to show user info
    try:
        import base64
        import json

        # Decode JWT payload (middle part)
        payload_b64 = token.access_token.split(".")[1]
        # Add padding if needed
        payload_b64 += "=" * (4 - len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))

        if "email" in payload:
            console.print(f"User: [cyan]{payload['email']}[/cyan]")
        elif "sub" in payload:
            console.print(f"Subject: [cyan]{payload['sub']}[/cyan]")

    except Exception:
        pass  # Don't fail if we can't decode token
