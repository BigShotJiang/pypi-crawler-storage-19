"""API clients for file-service and compute-service."""

from dataclasses import dataclass, field

import httpx

from iseq_flow.auth import get_valid_token
from iseq_flow.config import get_settings


class APIError(Exception):
    """API error with status code."""

    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


# File service models


@dataclass
class FileItem:
    """File or folder item."""

    name: str
    display_name: str
    size: int | None
    last_modified: str | None
    is_folder: bool
    content_type: str | None = None


@dataclass
class ListFilesResult:
    """Result of listing files."""

    bucket_name: str
    path: str
    folders: list[FileItem]
    files: list[FileItem]


# Compute service models


@dataclass
class Pipeline:
    """Pipeline definition."""

    id: str
    name: str
    slug: str
    description: str | None
    source_type: str
    default_profile: str
    execution_mode: str
    is_active: bool


@dataclass
class Run:
    """Pipeline run."""

    id: str
    name: str
    project_id: str
    pipeline_id: str
    status: str
    container_image: str | None = None
    profile: str | None = None
    params: dict = field(default_factory=dict)
    job_id: str | None = None
    output_path: str | None = None
    error_message: str | None = None
    created_at: str | None = None
    started_at: str | None = None
    finished_at: str | None = None
    created_by: str | None = None
    tags: list[str] = field(default_factory=list)


class FlowAPIClient:
    """Client for file-service API."""

    def __init__(self, token: str | None = None):
        self.settings = get_settings()
        self._token = token

    async def _get_token(self) -> str:
        """Get valid access token."""
        if self._token:
            return self._token

        token = await get_valid_token()
        if not token:
            raise APIError("Not authenticated. Run 'flow login' first.", status_code=401)
        return token

    async def _request(
        self,
        method: str,
        path: str,
        params: dict | None = None,
        json: dict | None = None,
    ) -> dict:
        """Make authenticated API request."""
        token = await self._get_token()
        url = f"{self.settings.api_url}{path}"

        async with httpx.AsyncClient() as client:
            response = await client.request(
                method,
                url,
                params=params,
                json=json,
                headers={"Authorization": f"Bearer {token}"},
                timeout=30.0,
            )

            if response.status_code == 401:
                raise APIError("Authentication expired. Run 'flow login' again.", status_code=401)
            elif response.status_code == 404:
                raise APIError("Resource not found.", status_code=404)
            elif response.status_code >= 400:
                detail = response.json().get("detail", response.text)
                raise APIError(f"API error: {detail}", status_code=response.status_code)

            return response.json()

    async def list_files(self, project_id: str, path: str = "") -> ListFilesResult:
        """List files in a project at a given path."""
        data = await self._request(
            "GET",
            "/api/v1/files",
            params={"project_id": project_id, "path": path},
        )

        return ListFilesResult(
            bucket_name=data["bucket_name"],
            path=data["path"],
            folders=[FileItem(**f) for f in data["folders"]],
            files=[FileItem(**f) for f in data["files"]],
        )

    async def get_download_url(self, project_id: str, path: str) -> str:
        """Get signed URL for downloading a file."""
        data = await self._request(
            "GET",
            "/api/v1/files/download-url",
            params={"project_id": project_id, "path": path},
        )
        return data["url"]

    async def get_upload_url(
        self, project_id: str, path: str, content_type: str = "application/octet-stream"
    ) -> str:
        """Get signed URL for uploading a file."""
        data = await self._request(
            "POST",
            "/api/v1/files/upload-url",
            params={"project_id": project_id},
            json={"path": path, "content_type": content_type},
        )
        return data["url"]

    async def download_file(self, url: str, output_path: str) -> None:
        """Download file from signed URL."""
        async with httpx.AsyncClient() as client:
            async with client.stream("GET", url, timeout=300.0) as response:
                if response.status_code != 200:
                    raise APIError(f"Download failed: {response.status_code}")

                with open(output_path, "wb") as f:
                    async for chunk in response.aiter_bytes(chunk_size=8192):
                        f.write(chunk)

    async def upload_file(self, url: str, file_path: str, content_type: str) -> None:
        """Upload file to signed URL."""
        with open(file_path, "rb") as f:
            content = f.read()

        async with httpx.AsyncClient() as client:
            response = await client.put(
                url,
                content=content,
                headers={"Content-Type": content_type},
                timeout=300.0,
            )

            if response.status_code not in (200, 201):
                raise APIError(f"Upload failed: {response.status_code}")


class ComputeAPIClient:
    """Client for compute-service API."""

    def __init__(self, token: str | None = None):
        self.settings = get_settings()
        self._token = token

    async def _get_token(self) -> str:
        """Get valid access token."""
        if self._token:
            return self._token

        token = await get_valid_token()
        if not token:
            raise APIError("Not authenticated. Run 'flow login' first.", status_code=401)
        return token

    async def _request(
        self,
        method: str,
        path: str,
        params: dict | None = None,
        json: dict | None = None,
        headers: dict | None = None,
    ) -> dict:
        """Make authenticated API request to compute-service."""
        token = await self._get_token()
        url = f"{self.settings.compute_url}{path}"

        request_headers = {"Authorization": f"Bearer {token}"}
        if headers:
            request_headers.update(headers)

        async with httpx.AsyncClient() as client:
            response = await client.request(
                method,
                url,
                params=params,
                json=json,
                headers=request_headers,
                timeout=30.0,
            )

            if response.status_code == 401:
                raise APIError(
                    "Authentication expired. Run 'flow login' again.", status_code=401
                )
            elif response.status_code == 404:
                raise APIError("Resource not found.", status_code=404)
            elif response.status_code >= 400:
                detail = response.json().get("detail", response.text)
                raise APIError(f"API error: {detail}", status_code=response.status_code)

            # Handle 204 No Content
            if response.status_code == 204:
                return {}

            return response.json()

    # Pipeline methods

    async def list_pipelines(self) -> list[Pipeline]:
        """List all active pipelines."""
        data = await self._request("GET", "/api/v1/pipelines")
        return [
            Pipeline(
                id=p["id"],
                name=p["name"],
                slug=p["slug"],
                description=p.get("description"),
                source_type=p["source_type"],
                default_profile=p["default_profile"],
                execution_mode=p["execution_mode"],
                is_active=p["is_active"],
            )
            for p in data
        ]

    async def get_pipeline(self, slug: str) -> Pipeline:
        """Get pipeline by slug."""
        data = await self._request("GET", f"/api/v1/pipelines/slug/{slug}")
        return Pipeline(
            id=data["id"],
            name=data["name"],
            slug=data["slug"],
            description=data.get("description"),
            source_type=data["source_type"],
            default_profile=data["default_profile"],
            execution_mode=data["execution_mode"],
            is_active=data["is_active"],
        )

    # Run methods

    async def list_runs(self, project_id: str, limit: int = 50) -> list[Run]:
        """List runs for a project."""
        data = await self._request(
            "GET",
            "/api/v1/runs",
            params={"limit": limit},
            headers={"X-Project-ID": project_id},
        )
        return [self._parse_run(r) for r in data]

    async def submit_run(
        self,
        project_id: str,
        pipeline_id: str,
        params: dict | None = None,
        tags: list[str] | None = None,
        profile: str | None = None,
    ) -> Run:
        """Submit a new pipeline run."""
        request_body = {
            "pipeline_id": pipeline_id,
            "params": params or {},
            "tags": tags or [],
        }
        if profile:
            request_body["profile"] = profile

        data = await self._request(
            "POST",
            "/api/v1/runs",
            json=request_body,
            headers={"X-Project-ID": project_id},
        )
        return self._parse_run(data)

    async def get_run(self, run_id: str) -> Run:
        """Get run details by ID."""
        data = await self._request("GET", f"/api/v1/runs/{run_id}")
        return self._parse_run(data)

    async def cancel_run(self, run_id: str) -> None:
        """Cancel a running or queued run."""
        await self._request("DELETE", f"/api/v1/runs/{run_id}")

    def _parse_run(self, data: dict) -> Run:
        """Parse run data from API response."""
        return Run(
            id=data["id"],
            name=data["name"],
            project_id=data["project_id"],
            pipeline_id=data["pipeline_id"],
            status=data["status"],
            container_image=data.get("container_image"),
            profile=data.get("profile"),
            params=data.get("params", {}),
            job_id=data.get("job_id"),
            output_path=data.get("output_path"),
            error_message=data.get("error_message"),
            created_at=data.get("created_at"),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            created_by=data.get("created_by"),
            tags=data.get("tags", []),
        )
