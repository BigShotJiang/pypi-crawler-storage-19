SDK_VERSION = "1.0.0"  # overwritten by VCS in packaging if you want (optional)
