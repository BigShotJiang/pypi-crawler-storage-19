"""
AIEL facade namespace.

Provides stable import paths for curated integrations shipped/guaranteed by runtime bundles.
Example:
  from aiel.langgraph.graph import StateGraph, START, END
"""
__all__ = ["pydantic", "langgraph", "langchain", "langsmith"]
