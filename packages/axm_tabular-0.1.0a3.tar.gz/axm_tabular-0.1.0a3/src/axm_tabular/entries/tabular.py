"""TabularEntry model for AXM Data Catalog (Plugin).

Uses unified Column and TabularSpec from axm-core.
"""

from typing import Literal

from pydantic import Field

from axm.catalog.entries.column import Column, TabularSpec
from axm.catalog.entries.data import (
    DataEntry,
    Schema,
    SchemaFormat,
)

# Re-export for backward compatibility
__all__ = ["Column", "TabularEntry", "TabularSchema", "TabularSpec"]


class TabularSchema(Schema):
    """Schema definition for tabular data.

    Matches the YAML structure where details are nested in 'spec'.
    Uses Column and TabularSpec from axm-core for unified data quality.
    """

    format: Literal[SchemaFormat.TABULAR] = SchemaFormat.TABULAR
    spec: TabularSpec


class TabularEntry(DataEntry):
    """A data catalog entry for tabular data.

    Specialized entry with typed schema for columnar data.
    """

    # Override schema with specialized TabularSchema
    data_schema: TabularSchema = Field(alias="schema")

    @property
    def format(self) -> str:
        """Return the data format identifier."""
        return "tabular"
