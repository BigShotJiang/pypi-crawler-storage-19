const state = {
    currentFrame: null,
    columns: [],
    rows: [],
    total: 0,
    offset: 0,
    limit: 100,
    sortCol: null,
    sortDir: 'asc',
    searchTerm: '',
    loading: false,
    preloadComplete: false,
    tableHeight: null,
    sectionOrder: ['section-stats', 'section-sql', 'section-join']
};

const $ = id => document.getElementById(id);

function showLoadingOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'loading-overlay';
    overlay.innerHTML = `
        <div class="spinner"></div>
        <p>Connecting to Spark...</p>
    `;
    document.body.appendChild(overlay);
}

function hideLoadingOverlay() {
    const overlay = $('loading-overlay');
    if (overlay) overlay.remove();
}

async function checkPreloadStatus() {
    try {
        const data = await fetchJSON('/api/status');
        state.preloadComplete = data.ready;
        if (!data.ready) {
            showLoadingOverlay();
        }
    } catch (e) {
        // Status endpoint unavailable, proceed normally
        state.preloadComplete = true;
    }
}

async function fetchJSON(url, options = {}) {
    const res = await fetch(url, options);
    if (!res.ok) {
        const err = await res.json().catch(() => ({ error: res.statusText }));
        throw new Error(err.error || 'Request failed');
    }
    return res.json();
}

async function loadFrames() {
    try {
        const data = await fetchJSON('/api/frames');
        const select = $('frame-select');
        select.innerHTML = '<option value="">Select DataFrame...</option>';
        data.frames.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            select.appendChild(opt);
        });
    } catch (e) {
        showError('Failed to load frames: ' + e.message);
    }
}

async function loadSchema(name) {
    const data = await fetchJSON(`/api/frames/${name}/schema`);
    state.columns = data.columns || [];
    renderHeader();
}

async function loadData(name, offset = 0) {
    if (state.loading) return;
    state.loading = true;

    const startTime = performance.now();
    let timerInterval = null;

    if (offset === 0) {
        timerInterval = setInterval(() => {
            const elapsed = ((performance.now() - startTime) / 1000).toFixed(1);
            $('load-status').textContent = `Waiting for Databricks... ${elapsed}s`;
        }, 100);
    } else {
        $('load-status').textContent = 'Loading more...';
    }

    try {
        const url = `/api/frames/${name}/data?offset=${offset}&limit=${state.limit}`;
        const data = await fetchJSON(url);

        if (timerInterval) clearInterval(timerInterval);
        const totalElapsed = ((performance.now() - startTime) / 1000).toFixed(2);

        if (offset === 0) {
            state.rows = data.rows;
        } else {
            state.rows = state.rows.concat(data.rows);
        }
        state.total = data.total;
        state.offset = offset + data.rows.length;

        renderRows();
        updateStatus();

        if (data.timing && offset === 0) {
            const { spark_ms, local_ms, cached } = data.timing;
            if (cached) {
                $('load-status').textContent = 'Loaded from cache';
            } else {
                const spark_s = (spark_ms / 1000).toFixed(2);
                const local_s = (local_ms / 1000).toFixed(2);
                $('load-status').textContent =
                    `Spark: ${spark_s}s | Local: ${local_s}s | Total: ${totalElapsed}s`;
            }
        } else {
            $('load-status').textContent = '';
        }
    } catch (e) {
        if (timerInterval) clearInterval(timerInterval);
        showError('Failed to load data: ' + e.message);
        $('load-status').textContent = '';
    } finally {
        state.loading = false;
    }
}

async function loadStats(name) {
    try {
        const data = await fetchJSON(`/api/frames/${name}/stats`);
        renderStats(data);
    } catch (e) {
        $('stats-content').innerHTML = `<p class="error">${e.message}</p>`;
    }
}

function renderHeader() {
    const thead = $('table-head');
    thead.innerHTML = '';
    const tr = document.createElement('tr');

    state.columns.forEach(col => {
        const th = document.createElement('th');
        th.textContent = col.name;
        th.dataset.col = col.name;
        th.title = `${col.type}${col.nullable ? ' (nullable)' : ''}`;

        if (state.sortCol === col.name) {
            th.className = state.sortDir === 'asc' ? 'sorted-asc' : 'sorted-desc';
        }

        th.onclick = () => toggleSort(col.name);
        tr.appendChild(th);
    });

    thead.appendChild(tr);
}

function renderRows() {
    const tbody = $('table-body');
    tbody.innerHTML = '';

    let rows = state.rows;

    if (state.searchTerm) {
        const term = state.searchTerm.toLowerCase();
        rows = rows.filter(row =>
            Object.values(row).some(v =>
                String(v).toLowerCase().includes(term)
            )
        );
    }

    if (state.sortCol) {
        rows = [...rows].sort((a, b) => {
            const av = a[state.sortCol];
            const bv = b[state.sortCol];
            if (av === null) return 1;
            if (bv === null) return -1;
            const cmp = av < bv ? -1 : av > bv ? 1 : 0;
            return state.sortDir === 'asc' ? cmp : -cmp;
        });
    }

    rows.forEach(row => {
        const tr = document.createElement('tr');
        state.columns.forEach(col => {
            const td = document.createElement('td');
            const val = row[col.name];
            if (val === null) {
                td.textContent = 'null';
                td.className = 'null';
            } else {
                td.textContent = String(val);
                td.title = String(val);
            }
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });
}

function renderStats(data) {
    const container = $('stats-content');
    container.innerHTML = '';

    const rowCard = document.createElement('div');
    rowCard.className = 'stat-card';
    rowCard.innerHTML = `<h4>Total Rows</h4><p>${data.row_count?.toLocaleString() || 'N/A'}</p>`;
    container.appendChild(rowCard);

    if (data.columns) {
        data.columns.forEach(col => {
            const card = document.createElement('div');
            card.className = 'stat-card';
            let html = `<h4>${col.name}</h4>`;
            html += `<p>Type: ${col.type}</p>`;
            html += `<p>Nulls: ${col.null_count?.toLocaleString() || 0}</p>`;
            if (col.min !== undefined) html += `<p>Min: ${col.min}</p>`;
            if (col.max !== undefined) html += `<p>Max: ${col.max}</p>`;
            card.innerHTML = html;
            container.appendChild(card);
        });
    }
}

function toggleSort(colName) {
    if (state.sortCol === colName) {
        state.sortDir = state.sortDir === 'asc' ? 'desc' : 'asc';
    } else {
        state.sortCol = colName;
        state.sortDir = 'asc';
    }
    renderHeader();
    renderRows();
}

function updateStatus() {
    const showing = state.searchTerm ? 'filtered' : state.rows.length;
    $('row-count').textContent = `Showing ${showing} of ${state.total.toLocaleString()} rows`;
}

function showError(msg) {
    const tbody = $('table-body');
    tbody.innerHTML = `<tr><td colspan="${state.columns.length || 1}" class="error">${msg}</td></tr>`;
}

async function exportData(format) {
    if (!state.currentFrame) return;

    try {
        const res = await fetch(`/api/frames/${state.currentFrame}/export`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ format })
        });

        if (!res.ok) throw new Error('Export failed');

        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${state.currentFrame}.${format}`;
        a.click();
        URL.revokeObjectURL(url);
    } catch (e) {
        alert('Export failed: ' + e.message);
    }
}

async function runSQL() {
    const sql = $('sql-input').value.trim();
    if (!sql) return;

    const resultDiv = $('sql-result');
    resultDiv.innerHTML = '<p class="loading">Running query...</p>';

    try {
        const data = await fetchJSON('/api/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sql })
        });

        if (data.rows.length === 0) {
            resultDiv.innerHTML = '<p>No results</p>';
            return;
        }

        const cols = Object.keys(data.rows[0]);
        let html = '<table><thead><tr>';
        cols.forEach(c => html += `<th>${c}</th>`);
        html += '</tr></thead><tbody>';

        data.rows.forEach(row => {
            html += '<tr>';
            cols.forEach(c => {
                const v = row[c];
                html += v === null
                    ? '<td class="null">null</td>'
                    : `<td>${v}</td>`;
            });
            html += '</tr>';
        });

        html += '</tbody></table>';
        html += `<p style="margin-top:8px;font-size:12px;color:var(--text-muted)">${data.total} rows</p>`;
        resultDiv.innerHTML = html;
    } catch (e) {
        resultDiv.innerHTML = `<p class="error">${e.message}</p>`;
    }
}

function setupInfiniteScroll() {
    const container = $('table-container');
    container.addEventListener('scroll', () => {
        if (state.loading || state.offset >= state.total) return;

        const { scrollTop, scrollHeight, clientHeight } = container;
        if (scrollTop + clientHeight >= scrollHeight - 100) {
            loadData(state.currentFrame, state.offset);
        }
    });
}

function loadTableHeight() {
    const saved = localStorage.getItem('mangleframes-table-height');
    if (saved) {
        state.tableHeight = parseInt(saved, 10);
        applyTableHeight();
    }
}

function applyTableHeight() {
    const container = $('table-container');
    if (state.tableHeight) {
        container.style.setProperty('--table-height', `${state.tableHeight}px`);
    }
}

function saveTableHeight() {
    if (state.tableHeight) {
        localStorage.setItem('mangleframes-table-height', state.tableHeight);
    }
}

function setupResizeHandle() {
    const handle = $('resize-handle');
    const container = $('table-container');
    let startY, startHeight;

    handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        startY = e.clientY;
        startHeight = container.offsetHeight;
        handle.classList.add('dragging');
        document.addEventListener('mousemove', onDrag);
        document.addEventListener('mouseup', onDragEnd);
    });

    function onDrag(e) {
        const delta = e.clientY - startY;
        const newHeight = Math.max(150, startHeight + delta);
        state.tableHeight = newHeight;
        applyTableHeight();
    }

    function onDragEnd() {
        handle.classList.remove('dragging');
        document.removeEventListener('mousemove', onDrag);
        document.removeEventListener('mouseup', onDragEnd);
        saveTableHeight();
    }
}

function loadSectionOrder() {
    const saved = localStorage.getItem('mangleframes-section-order');
    if (saved) {
        try {
            const order = JSON.parse(saved);
            if (Array.isArray(order) && order.length === 3) {
                state.sectionOrder = order;
            }
        } catch (e) {
            // Invalid JSON, use default
        }
    }
    applySectionOrder();
}

function saveSectionOrder() {
    localStorage.setItem('mangleframes-section-order', JSON.stringify(state.sectionOrder));
}

function applySectionOrder() {
    const main = document.querySelector('main');
    const statusBar = document.querySelector('.status-bar');

    state.sectionOrder.forEach(id => {
        const section = $(id);
        if (section) {
            main.insertBefore(section, null);
        }
    });
}

function setupSectionDrag() {
    let draggedSection = null;

    document.querySelectorAll('.drag-handle').forEach(handle => {
        handle.addEventListener('dragstart', (e) => {
            draggedSection = handle.closest('details');
            draggedSection.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', draggedSection.id);
        });

        handle.addEventListener('dragend', () => {
            if (draggedSection) {
                draggedSection.classList.remove('dragging');
                draggedSection = null;
            }
            document.querySelectorAll('details.drag-over').forEach(el => {
                el.classList.remove('drag-over');
            });
        });
    });

    state.sectionOrder.forEach(id => {
        const section = $(id);
        if (!section) return;

        section.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            if (draggedSection && section !== draggedSection) {
                section.classList.add('drag-over');
            }
        });

        section.addEventListener('dragleave', () => {
            section.classList.remove('drag-over');
        });

        section.addEventListener('drop', (e) => {
            e.preventDefault();
            section.classList.remove('drag-over');

            if (!draggedSection || section === draggedSection) return;

            const draggedId = draggedSection.id;
            const targetId = section.id;

            const draggedIdx = state.sectionOrder.indexOf(draggedId);
            const targetIdx = state.sectionOrder.indexOf(targetId);

            if (draggedIdx === -1 || targetIdx === -1) return;

            state.sectionOrder.splice(draggedIdx, 1);
            state.sectionOrder.splice(targetIdx, 0, draggedId);

            applySectionOrder();
            saveSectionOrder();
        });
    });
}

function setupWebSocket() {
    const ws = new WebSocket(`ws://${location.host}/ws`);

    ws.onmessage = (event) => {
        const msg = JSON.parse(event.data);
        if (msg.type === 'refresh') {
            loadFrames();
        } else if (msg.type === 'preload_complete') {
            state.preloadComplete = true;
            hideLoadingOverlay();
            loadFrames().then(() => {
                if (msg.frame) {
                    $('frame-select').value = msg.frame;
                    $('frame-select').dispatchEvent(new Event('change'));
                }
            });
        }
    };

    ws.onclose = () => setTimeout(setupWebSocket, 3000);
}

function init() {
    loadTableHeight();
    loadSectionOrder();
    setupResizeHandle();
    setupSectionDrag();
    checkPreloadStatus();
    loadFrames();
    setupInfiniteScroll();
    setupWebSocket();
    initJoinAnalysis();

    $('frame-select').onchange = async (e) => {
        const name = e.target.value;
        if (!name) return;

        state.currentFrame = name;
        state.rows = [];
        state.offset = 0;
        state.sortCol = null;

        // Fetch schema and data in parallel for faster display
        await Promise.all([loadSchema(name), loadData(name)]);
        loadStats(name);  // Fire-and-forget, updates UI when ready
    };

    $('refresh-btn').onclick = () => {
        loadFrames();
        populateJoinFrameSelectors();
        if (state.currentFrame) {
            state.rows = [];
            state.offset = 0;
            loadData(state.currentFrame);
        }
    };

    $('search-input').oninput = (e) => {
        state.searchTerm = e.target.value;
        renderRows();
        updateStatus();
    };

    document.querySelectorAll('.export-buttons button').forEach(btn => {
        btn.onclick = () => exportData(btn.dataset.format);
    });

    $('run-sql').onclick = runSQL;
    $('sql-input').onkeydown = (e) => {
        if (e.ctrlKey && e.key === 'Enter') runSQL();
    };
}

// Join Analysis Module
const joinState = {
    leftFrame: null,
    rightFrame: null,
    leftKeys: [],
    rightKeys: [],
    leftColumns: [],
    rightColumns: [],
    currentSide: 'left',
    unmatched: { left: [], right: [] },
    unmatchedTotal: { left: 0, right: 0 },
    offset: 0,
    limit: 100,
    // History analysis extensions
    additionalFrames: [],
    bucketSize: 'month',
    coverageData: null
};

function initJoinAnalysis() {
    populateJoinFrameSelectors();
    setupJoinEventListeners();
    setupHistoryEventListeners();
}

async function populateJoinFrameSelectors() {
    try {
        const data = await fetchJSON('/api/frames');
        ['join-left-frame', 'join-right-frame'].forEach(id => {
            const select = $(id);
            select.innerHTML = '<option value="">Select frame...</option>';
            data.frames.forEach(name => {
                const opt = document.createElement('option');
                opt.value = name;
                opt.textContent = name;
                select.appendChild(opt);
            });
        });
    } catch (e) {
        console.error('Failed to load frames for join:', e);
    }
}

function setupJoinEventListeners() {
    console.log('[JOIN DEBUG] Setup:', { left: $('join-left-frame'), right: $('join-right-frame') });
    $('join-left-frame').onchange = (e) => {
        console.log('[JOIN DEBUG] Left frame selected:', e.target.value);
        loadColumnsForJoin('left', e.target.value);
    };
    $('join-right-frame').onchange = (e) => {
        console.log('[JOIN DEBUG] Right frame selected:', e.target.value);
        loadColumnsForJoin('right', e.target.value);
    };
    $('analyze-join').onclick = runJoinAnalysis;

    document.querySelectorAll('.viewer-tabs .tab').forEach(tab => {
        tab.onclick = () => switchUnmatchedTab(tab.dataset.side);
    });

    $('prev-page').onclick = () => paginateUnmatched(-1);
    $('next-page').onclick = () => paginateUnmatched(1);

    document.querySelectorAll('.unmatched-viewer .export-group button').forEach(btn => {
        btn.onclick = () => exportUnmatched(btn.dataset.format);
    });
}

async function loadColumnsForJoin(side, frameName) {
    if (!frameName) {
        joinState[side + 'Columns'] = [];
        joinState[side + 'Keys'] = [];
        renderColumnChips(side);
        return;
    }

    try {
        const schema = await fetchJSON(`/api/frames/${frameName}/schema`);
        joinState[side + 'Frame'] = frameName;
        joinState[side + 'Columns'] = schema.columns || [];
        joinState[side + 'Keys'] = [];
        renderColumnChips(side);
    } catch (e) {
        console.error(`Failed to load schema for ${frameName}:`, e);
    }
}

function renderColumnChips(side) {
    const parent = $(`${side}-columns`);
    const container = parent?.querySelector('.column-chips');
    console.log('[JOIN DEBUG] Container:', { side, parent, container, columns: joinState[side + 'Columns']?.length });
    if (!container) return;
    container.innerHTML = '';

    const columns = joinState[side + 'Columns'];
    const selectedKeys = joinState[side + 'Keys'];

    columns.forEach(col => {
        const chip = document.createElement('span');
        chip.className = 'column-chip';
        chip.dataset.column = col.name;

        const idx = selectedKeys.indexOf(col.name);
        if (idx >= 0) {
            chip.classList.add('selected');
            chip.innerHTML = `<span class="chip-order">${idx + 1}</span>${col.name}`;
        } else {
            chip.textContent = col.name;
        }

        chip.onclick = () => toggleKeyColumn(side, col.name);
        container.appendChild(chip);
    });
}

function toggleKeyColumn(side, colName) {
    const keys = joinState[side + 'Keys'];
    const idx = keys.indexOf(colName);

    if (idx >= 0) {
        keys.splice(idx, 1);
    } else {
        keys.push(colName);
    }

    renderColumnChips(side);
}

async function runJoinAnalysis() {
    const { leftFrame, rightFrame, leftKeys, rightKeys } = joinState;

    if (!leftFrame || !rightFrame) {
        alert('Please select both frames');
        return;
    }
    if (leftKeys.length === 0 || rightKeys.length === 0) {
        alert('Please select join keys for both frames');
        return;
    }
    if (leftKeys.length !== rightKeys.length) {
        alert('Key counts must match between frames');
        return;
    }

    const btn = $('analyze-join');
    btn.disabled = true;
    btn.textContent = 'Analyzing...';

    try {
        const result = await fetchJSON('/api/join/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                left_frame: leftFrame,
                right_frame: rightFrame,
                left_keys: leftKeys,
                right_keys: rightKeys
            })
        });

        displayJoinStatistics(result.statistics);
        joinState.unmatched.left = result.left_unmatched.rows;
        joinState.unmatched.right = result.right_unmatched.rows;
        joinState.unmatchedTotal.left = result.left_unmatched.total;
        joinState.unmatchedTotal.right = result.right_unmatched.total;

        $('tab-left-count').textContent = result.left_unmatched.total.toLocaleString();
        $('tab-right-count').textContent = result.right_unmatched.total.toLocaleString();

        $('join-stats').style.display = 'block';
        $('unmatched-viewer').style.display = 'block';

        switchUnmatchedTab('left');
    } catch (e) {
        alert('Analysis failed: ' + e.message);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Analyze Join';
    }
}

function displayJoinStatistics(stats) {
    const matchPct = (stats.match_rate_left * 100).toFixed(1) + '%';
    $('stat-match-rate').textContent = matchPct;
    $('stat-cardinality').textContent = stats.cardinality;

    $('stat-left-total').textContent = stats.left_total.toLocaleString();
    $('stat-left-unmatched').textContent = (stats.left_total - stats.matched_left).toLocaleString();
    $('stat-left-nulls').textContent = stats.left_null_keys.toLocaleString();
    $('stat-left-dupes').textContent = stats.left_duplicate_keys.toLocaleString();

    $('stat-right-total').textContent = stats.right_total.toLocaleString();
    $('stat-right-unmatched').textContent = (stats.right_total - stats.matched_right).toLocaleString();
    $('stat-right-nulls').textContent = stats.right_null_keys.toLocaleString();
    $('stat-right-dupes').textContent = stats.right_duplicate_keys.toLocaleString();
}

function switchUnmatchedTab(side) {
    joinState.currentSide = side;
    joinState.offset = 0;

    document.querySelectorAll('.viewer-tabs .tab').forEach(t => {
        t.classList.toggle('active', t.dataset.side === side);
    });

    renderUnmatchedTable();
}

function renderUnmatchedTable() {
    const side = joinState.currentSide;
    const rows = joinState.unmatched[side];
    const total = joinState.unmatchedTotal[side];

    const thead = $('unmatched-head');
    const tbody = $('unmatched-body');

    if (!rows || rows.length === 0) {
        thead.innerHTML = '';
        tbody.innerHTML = '<tr><td colspan="10" style="text-align:center;padding:20px;">No unmatched rows</td></tr>';
        $('unmatched-status').textContent = 'No unmatched rows';
        $('prev-page').disabled = true;
        $('next-page').disabled = true;
        return;
    }

    const cols = Object.keys(rows[0]);
    thead.innerHTML = '<tr>' + cols.map(c => `<th>${c}</th>`).join('') + '</tr>';

    tbody.innerHTML = rows.map(row =>
        '<tr>' + cols.map(c => {
            const v = row[c];
            return v === null
                ? '<td class="null">null</td>'
                : `<td title="${v}">${v}</td>`;
        }).join('') + '</tr>'
    ).join('');

    $('unmatched-status').textContent =
        `Showing ${joinState.offset + 1}-${joinState.offset + rows.length} of ${total.toLocaleString()} unmatched`;

    $('prev-page').disabled = joinState.offset === 0;
    $('next-page').disabled = joinState.offset + rows.length >= total;
}

async function paginateUnmatched(direction) {
    const newOffset = joinState.offset + (direction * joinState.limit);
    if (newOffset < 0) return;

    joinState.offset = newOffset;
    await fetchUnmatchedPage();
}

async function fetchUnmatchedPage() {
    const { leftFrame, rightFrame, leftKeys, rightKeys, currentSide, offset, limit } = joinState;

    const params = new URLSearchParams({
        left_frame: leftFrame,
        right_frame: rightFrame,
        left_keys: leftKeys.join(','),
        right_keys: rightKeys.join(','),
        offset: offset,
        limit: limit
    });

    try {
        const result = await fetchJSON(`/api/join/unmatched/${currentSide}?${params}`);
        joinState.unmatched[currentSide] = result.rows;
        joinState.unmatchedTotal[currentSide] = result.total;
        renderUnmatchedTable();
    } catch (e) {
        console.error('Failed to fetch unmatched rows:', e);
    }
}

async function exportUnmatched(format) {
    const { leftFrame, rightFrame, leftKeys, rightKeys, currentSide } = joinState;

    try {
        const res = await fetch('/api/join/export', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                left_frame: leftFrame,
                right_frame: rightFrame,
                left_keys: leftKeys,
                right_keys: rightKeys,
                side: currentSide,
                format
            })
        });

        if (!res.ok) throw new Error('Export failed');

        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${currentSide}_unmatched.${format}`;
        a.click();
        URL.revokeObjectURL(url);
    } catch (e) {
        alert('Export failed: ' + e.message);
    }
}

// History Coverage Analysis Module
function setupHistoryEventListeners() {
    $('add-frame-btn').onclick = addAdditionalFrame;
    $('analyze-history').onclick = runHistoryAnalysis;
    $('bucket-size').onchange = (e) => {
        joinState.bucketSize = e.target.value;
    };
}

function addAdditionalFrame() {
    if (joinState.additionalFrames.length >= 3) {
        alert('Maximum 5 frames total (2 primary + 3 additional)');
        return;
    }

    joinState.additionalFrames.push({
        frame: null,
        targetFrame: null,
        sourceKeys: [],
        targetKeys: [],
        columns: [],
        targetColumns: []
    });

    renderAdditionalFrames();
}

async function renderAdditionalFrames() {
    const container = $('additional-frames-list');
    container.innerHTML = '';

    const data = await fetchJSON('/api/frames').catch(() => ({ frames: [] }));
    const allFrames = data.frames || [];

    joinState.additionalFrames.forEach((af, idx) => {
        const div = document.createElement('div');
        div.className = 'additional-frame-row';
        div.innerHTML = buildAdditionalFrameHtml(idx, af, allFrames);
        container.appendChild(div);

        div.querySelector('.source-frame-select').onchange = (e) => {
            loadAdditionalFrameColumns(idx, e.target.value);
        };
        div.querySelector('.target-frame-select').onchange = (e) => {
            loadTargetFrameColumns(idx, e.target.value);
        };
        div.querySelector('.remove-frame-btn').onclick = () => removeAdditionalFrame(idx);

        if (af.frame) renderAdditionalFrameKeyMapping(idx);
    });
}

function buildAdditionalFrameHtml(idx, af, allFrames) {
    const targetOptions = getAvailableTargetFrames(idx);
    return `
        <div class="additional-frame-header">
            <select class="source-frame-select" data-idx="${idx}">
                <option value="">Select frame...</option>
                ${allFrames.map(f => `<option value="${f}" ${af.frame === f ? 'selected' : ''}>${f}</option>`).join('')}
            </select>
            <span class="join-arrow">joins</span>
            <select class="target-frame-select" data-idx="${idx}">
                <option value="">Select target...</option>
                ${targetOptions.map(f => `<option value="${f}" ${af.targetFrame === f ? 'selected' : ''}>${f}</option>`).join('')}
            </select>
            <button class="remove-frame-btn" data-idx="${idx}" title="Remove">×</button>
        </div>
        <div class="key-mapping-section" id="key-mapping-${idx}">
            <div class="source-keys-picker">
                <span class="picker-label">Source Keys</span>
                <div class="column-chips" id="source-chips-${idx}"></div>
            </div>
            <div class="target-keys-picker">
                <span class="picker-label">Target Keys</span>
                <div class="column-chips" id="target-chips-${idx}"></div>
            </div>
        </div>
    `;
}

function getAvailableTargetFrames(currentIdx) {
    const targets = [];
    if (joinState.leftFrame) targets.push(joinState.leftFrame);
    if (joinState.rightFrame) targets.push(joinState.rightFrame);
    joinState.additionalFrames.forEach((af, i) => {
        if (i < currentIdx && af.frame) targets.push(af.frame);
    });
    return targets;
}

async function loadAdditionalFrameColumns(idx, frameName) {
    const af = joinState.additionalFrames[idx];
    if (!frameName) {
        Object.assign(af, { frame: null, sourceKeys: [], columns: [] });
        renderAdditionalFrameKeyMapping(idx);
        return;
    }

    try {
        const schema = await fetchJSON(`/api/frames/${frameName}/schema`);
        Object.assign(af, {
            frame: frameName,
            columns: schema.columns || [],
            sourceKeys: []
        });
        renderAdditionalFrameKeyMapping(idx);
    } catch (e) {
        console.error(`Failed to load schema for ${frameName}:`, e);
    }
}

async function loadTargetFrameColumns(idx, targetFrameName) {
    const af = joinState.additionalFrames[idx];
    if (!targetFrameName) {
        Object.assign(af, { targetFrame: null, targetKeys: [], targetColumns: [] });
        renderAdditionalFrameKeyMapping(idx);
        return;
    }

    try {
        const schema = await getTargetFrameSchema(targetFrameName);
        Object.assign(af, {
            targetFrame: targetFrameName,
            targetColumns: schema.columns || [],
            targetKeys: []
        });
        renderAdditionalFrameKeyMapping(idx);
    } catch (e) {
        console.error(`Failed to load target schema for ${targetFrameName}:`, e);
    }
}

async function getTargetFrameSchema(frameName) {
    if (frameName === joinState.leftFrame && joinState.leftColumns.length > 0) {
        return { columns: joinState.leftColumns };
    }
    if (frameName === joinState.rightFrame && joinState.rightColumns.length > 0) {
        return { columns: joinState.rightColumns };
    }
    const existing = joinState.additionalFrames.find(af => af.frame === frameName);
    if (existing && existing.columns.length > 0) {
        return { columns: existing.columns };
    }
    return await fetchJSON(`/api/frames/${frameName}/schema`);
}

function renderAdditionalFrameKeyMapping(idx) {
    const af = joinState.additionalFrames[idx];
    renderKeyChips(`source-chips-${idx}`, af.columns, af.sourceKeys, (col) => toggleSourceKey(idx, col));
    renderKeyChips(`target-chips-${idx}`, af.targetColumns, af.targetKeys, (col) => toggleTargetKey(idx, col));
}

function renderKeyChips(containerId, columns, selectedKeys, onToggle) {
    const container = document.getElementById(containerId);
    if (!container) return;
    container.innerHTML = '';

    (columns || []).forEach(col => {
        const chip = document.createElement('span');
        chip.className = 'column-chip';
        const keyIndex = selectedKeys.indexOf(col.name);
        if (keyIndex >= 0) {
            chip.classList.add('selected');
            chip.innerHTML = `<span class="chip-order">${keyIndex + 1}</span>${col.name}`;
        } else {
            chip.textContent = col.name;
        }
        chip.onclick = () => onToggle(col.name);
        container.appendChild(chip);
    });
}

function toggleSourceKey(idx, colName) {
    const af = joinState.additionalFrames[idx];
    toggleKeyInArray(af.sourceKeys, colName);
    renderAdditionalFrameKeyMapping(idx);
}

function toggleTargetKey(idx, colName) {
    const af = joinState.additionalFrames[idx];
    toggleKeyInArray(af.targetKeys, colName);
    renderAdditionalFrameKeyMapping(idx);
}

function toggleKeyInArray(keyArray, colName) {
    const keyIdx = keyArray.indexOf(colName);
    if (keyIdx >= 0) {
        keyArray.splice(keyIdx, 1);
    } else {
        keyArray.push(colName);
    }
}

function removeAdditionalFrame(idx) {
    joinState.additionalFrames.splice(idx, 1);
    renderAdditionalFrames();
}

function getAllFrameConfigs() {
    const configs = [];
    const joinPairs = [];

    if (joinState.leftFrame && joinState.leftKeys.length > 0) {
        configs.push({ frame: joinState.leftFrame, columns: joinState.leftKeys });
    }
    if (joinState.rightFrame && joinState.rightKeys.length > 0) {
        configs.push({ frame: joinState.rightFrame, columns: joinState.rightKeys });
    }

    // Primary left-right join pair
    if (joinState.leftFrame && joinState.rightFrame &&
        joinState.leftKeys.length > 0 && joinState.rightKeys.length > 0) {
        joinPairs.push({
            source_frame: joinState.leftFrame,
            target_frame: joinState.rightFrame,
            source_keys: joinState.leftKeys,
            target_keys: joinState.rightKeys
        });
    }

    // Additional frames with explicit join pairs
    joinState.additionalFrames.forEach(af => {
        if (af.frame && af.sourceKeys.length > 0) {
            configs.push({ frame: af.frame, columns: af.sourceKeys });
        }
        if (af.frame && af.targetFrame &&
            af.sourceKeys.length > 0 && af.targetKeys.length > 0) {
            joinPairs.push({
                source_frame: af.frame,
                target_frame: af.targetFrame,
                source_keys: af.sourceKeys,
                target_keys: af.targetKeys
            });
        }
    });

    return { configs, joinPairs };
}

async function runHistoryAnalysis() {
    const { configs, joinPairs } = getAllFrameConfigs();

    if (configs.length < 2) {
        alert('Select at least 2 frames with join keys');
        return;
    }

    if (joinPairs.length === 0) {
        alert('Configure at least one join pair with source and target keys');
        return;
    }

    const btn = $('analyze-history');
    btn.disabled = true;
    btn.textContent = 'Analyzing...';

    try {
        const result = await fetchJSON('/api/history/analyze', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                frames: configs,
                join_pairs: joinPairs,
                bucket_size: joinState.bucketSize
            })
        });

        joinState.coverageData = result;
        renderCoverageTimeline(result);
        renderTemporalCoverage(result);
        renderPredictions(result);
        renderPairwiseOverlaps(result);

    } catch (e) {
        alert('Analysis failed: ' + e.message);
    } finally {
        btn.disabled = false;
        btn.textContent = 'Analyze Coverage';
    }
}

function renderCoverageTimeline(result) {
    const container = $('coverage-timeline');
    const chart = $('timeline-chart');
    const labels = $('timeline-labels');

    if (!result.timeline || result.timeline.length === 0) {
        container.style.display = 'none';
        return;
    }

    container.style.display = 'block';
    chart.innerHTML = '';
    labels.innerHTML = '';

    const frames = result.frames;
    const timeline = result.timeline;

    // Add dense class for many buckets to reduce bar width
    chart.classList.toggle('dense', timeline.length > 200);
    const buckets = timeline.map(t => t.bucket);

    // Create row for each frame
    frames.forEach(frame => {
        const row = document.createElement('div');
        row.className = 'timeline-row';

        const label = document.createElement('span');
        label.className = 'timeline-label';
        label.textContent = frame;
        label.title = `Data presence for ${frame} over time`;
        row.appendChild(label);

        const bars = document.createElement('div');
        bars.className = 'timeline-bars';

        timeline.forEach(bucket => {
            const bar = document.createElement('div');
            bar.className = 'timeline-bar';
            const count = bucket.frame_counts[frame] || 0;
            bar.classList.add(count > 0 ? 'present' : 'absent');
            bar.title = `${bucket.bucket}: ${count.toLocaleString()} rows`;
            bars.appendChild(bar);
        });

        row.appendChild(bars);
        chart.appendChild(row);
    });

    // Add INNER join coverage row
    const innerRow = document.createElement('div');
    innerRow.className = 'timeline-row timeline-row-inner';

    const innerLabel = document.createElement('span');
    innerLabel.className = 'timeline-label';
    innerLabel.textContent = 'INNER (all)';
    innerLabel.title = 'Shows periods where an INNER join across all frames would retain data';
    innerRow.appendChild(innerLabel);

    const innerBars = document.createElement('div');
    innerBars.className = 'timeline-bars';

    timeline.forEach(bucket => {
        const bar = document.createElement('div');
        bar.className = 'timeline-bar';
        bar.classList.add(bucket.all_present ? 'all-present' : 'partial');
        bar.title = bucket.all_present ? `${bucket.bucket}: All frames present` : `${bucket.bucket}: Partial coverage`;
        innerBars.appendChild(bar);
    });

    innerRow.appendChild(innerBars);
    chart.appendChild(innerRow);

    // Add time labels
    if (buckets.length > 0) {
        const labelRow = document.createElement('div');
        labelRow.className = 'timeline-labels-row';
        labelRow.innerHTML = `
            <span class="timeline-label"></span>
            <div class="timeline-label-bar">
                <span>${buckets[0]}</span>
                <span>${buckets[buckets.length - 1]}</span>
            </div>
        `;
        labels.appendChild(labelRow);
    }
}

function renderPredictions(result) {
    const container = $('join-predictions');
    const tbody = $('predictions-body');

    if (!result.predictions || result.predictions.length === 0) {
        container.style.display = 'none';
        return;
    }

    container.style.display = 'block';
    tbody.innerHTML = '';

    result.predictions.forEach(pred => {
        const tr = document.createElement('tr');

        const nullCols = Object.entries(pred.null_columns || {})
            .map(([frame, count]) => `${frame}: ${count.toLocaleString()}`)
            .join(', ') || 'None';

        tr.innerHTML = `
            <td>${pred.join_type}</td>
            <td>${pred.estimated_rows.toLocaleString()}</td>
            <td>${nullCols}</td>
            <td>${pred.coverage_pct.toFixed(1)}%</td>
        `;
        tbody.appendChild(tr);
    });
}

function renderPairwiseOverlaps(result) {
    const container = $('pairwise-overlaps');
    const grid = $('overlaps-grid');

    if (!result.pairwise_overlaps || result.pairwise_overlaps.length === 0) {
        container.style.display = 'none';
        return;
    }

    container.style.display = 'block';
    grid.innerHTML = '';

    result.pairwise_overlaps.forEach(overlap => {
        const card = document.createElement('div');
        card.className = 'overlap-card';
        card.innerHTML = `
            <div class="overlap-header">${overlap.frame1} ↔ ${overlap.frame2}</div>
            <div class="overlap-stats">
                <div class="overlap-stat" title="Percentage of keys shared between both frames (common keys / larger key set)">
                    <span class="overlap-value">${overlap.overlap_pct.toFixed(1)}%</span>
                    <span class="overlap-label">Overlap</span>
                </div>
                <div class="overlap-stat" title="Count of distinct keys that exist in both frames">
                    <span class="overlap-value">${overlap.both.toLocaleString()}</span>
                    <span class="overlap-label">Common Keys</span>
                </div>
            </div>
            <div class="overlap-details">
                <span title="Keys in ${overlap.frame1} but not ${overlap.frame2} - would be NULL in RIGHT join or dropped in INNER">${overlap.frame1} only: ${overlap.left_only.toLocaleString()}</span>
                <span title="Keys in ${overlap.frame2} but not ${overlap.frame1} - would be NULL in LEFT join or dropped in INNER">${overlap.frame2} only: ${overlap.right_only.toLocaleString()}</span>
            </div>
        `;
        grid.appendChild(card);
    });
}

function renderTemporalCoverage(result) {
    const container = $('temporal-coverage');
    const banner = $('overlap-zone-banner');
    const tbody = $('temporal-ranges-body');
    const dataLossSection = $('data-loss-section');
    const dataLossGrid = $('data-loss-grid');
    const gapsSection = $('internal-gaps-section');
    const gapsList = $('internal-gaps-list');

    if (!result.temporal_ranges || result.temporal_ranges.length === 0) {
        container.style.display = 'none';
        return;
    }

    container.style.display = 'block';
    tbody.innerHTML = '';

    // Render overlap zone banner
    if (result.overlap_zone) {
        const oz = result.overlap_zone;
        if (oz.valid) {
            banner.className = 'overlap-zone-banner overlap-valid';
            banner.innerHTML = `
                <span class="overlap-zone-label">Overlap Zone (Safe for INNER Join):</span>
                <span class="overlap-zone-range">${oz.start} → ${oz.end}</span>
                <span class="overlap-zone-span">(${oz.span})</span>
            `;
        } else {
            banner.className = 'overlap-zone-banner overlap-invalid';
            banner.innerHTML = `
                <span class="overlap-zone-warning">No date overlap between frames - INNER join would return 0 rows</span>
            `;
        }
        banner.style.display = 'flex';
    } else {
        banner.style.display = 'none';
    }

    // Render temporal ranges table
    let hasAnyGaps = false;
    result.temporal_ranges.forEach(range => {
        const tr = document.createElement('tr');
        const gapCount = range.internal_gaps ? range.internal_gaps.length : 0;
        if (gapCount > 0) hasAnyGaps = true;

        tr.innerHTML = `
            <td>${range.frame}</td>
            <td>${range.min_date || '-'}</td>
            <td>${range.max_date || '-'}</td>
            <td>${formatDateSpan(range.min_date, range.max_date)}</td>
            <td>${range.total_rows.toLocaleString()}</td>
            <td class="${range.null_dates > 0 ? 'issue' : ''}">${range.null_dates.toLocaleString()}</td>
            <td class="${gapCount > 0 ? 'issue' : ''}">${gapCount}</td>
        `;
        tbody.appendChild(tr);
    });

    // Render data loss section
    if (result.data_loss && result.data_loss.length > 0) {
        const hasLoss = result.data_loss.some(dl => dl.total_lost > 0);
        if (hasLoss) {
            dataLossSection.style.display = 'block';
            dataLossGrid.innerHTML = '';

            result.data_loss.forEach(loss => {
                if (loss.total_lost === 0) return;

                const card = document.createElement('div');
                card.className = 'data-loss-card';
                card.innerHTML = `
                    <div class="data-loss-frame">${loss.frame}</div>
                    <div class="data-loss-stats">
                        <div class="data-loss-stat">
                            <span class="data-loss-value">${loss.total_lost.toLocaleString()}</span>
                            <span class="data-loss-label">rows lost (${loss.pct_lost.toFixed(1)}%)</span>
                        </div>
                    </div>
                    <div class="data-loss-breakdown">
                        ${loss.rows_before_overlap > 0 ? `<span>Before overlap: ${loss.rows_before_overlap.toLocaleString()}</span>` : ''}
                        ${loss.rows_after_overlap > 0 ? `<span>After overlap: ${loss.rows_after_overlap.toLocaleString()}</span>` : ''}
                    </div>
                `;
                dataLossGrid.appendChild(card);
            });
        } else {
            dataLossSection.style.display = 'none';
        }
    } else {
        dataLossSection.style.display = 'none';
    }

    // Render internal gaps section
    if (hasAnyGaps) {
        gapsSection.style.display = 'block';
        gapsList.innerHTML = '';

        result.temporal_ranges.forEach(range => {
            if (!range.internal_gaps || range.internal_gaps.length === 0) return;

            const gapItem = document.createElement('div');
            gapItem.className = 'gap-item';

            const gapDescriptions = range.internal_gaps.map(gap =>
                `${gap.start} → ${gap.end} (${gap.periods} ${range.granularity}s)`
            ).join(', ');

            gapItem.innerHTML = `
                <span class="gap-frame">${range.frame}:</span>
                <span class="gap-details">${gapDescriptions}</span>
            `;
            gapsList.appendChild(gapItem);
        });
    } else {
        gapsSection.style.display = 'none';
    }
}

function formatDateSpan(minDate, maxDate) {
    if (!minDate || !maxDate) return '-';

    const start = new Date(minDate);
    const end = new Date(maxDate);
    const days = Math.floor((end - start) / (1000 * 60 * 60 * 24));

    if (days < 0) return '-';

    const years = Math.floor(days / 365);
    const months = Math.floor((days % 365) / 30);
    const remainingDays = days % 30;

    const parts = [];
    if (years > 0) parts.push(`${years}y`);
    if (months > 0) parts.push(`${months}m`);
    if (remainingDays > 0 || parts.length === 0) parts.push(`${remainingDays}d`);

    return parts.join(' ');
}

document.addEventListener('DOMContentLoaded', init);
