#!/usr/bin/env python3
"""Download 20K full listing details from Funda API."""

import json
import time
import requests
from datetime import datetime
from pathlib import Path

SEARCH_URL = "https://listing-search-wonen.funda.io/_msearch/template"
DETAIL_URL = "https://listing-detail-page.funda.io/api/v4/listing/object/nl/{listing_id}"

SEARCH_HEADERS = {
    "user-agent": "Dart/3.9 (dart:io)",
    "content-type": "application/x-ndjson",
    "referer": "https://www.funda.nl/",
}

DETAIL_HEADERS = {
    "user-agent": "Dart/3.9 (dart:io)",
    "x-funda-app-platform": "android",
}

# Price partitions (each under 10K to avoid ES limit)
PRICE_PARTITIONS = [
    (0, 250000),        # ~4,300
    (250000, 300000),   # ~5,000
    (300000, 340000),   # ~5,500
    (340000, 380000),   # ~5,500
]

def search_with_retry(page, price_min, price_max, retries=3):
    params = {
        "availability": ["available", "negotiations"],
        "type": ["single"],
        "zoning": ["residential"],
        "object_type": ["house", "apartment"],
        "publication_date": {"no_preference": True},
        "offering_type": "buy",
        "page": {"from": page * 15},
        "sort": {"field": "publish_date_utc", "order": "desc"},
    }

    price_filter = {}
    if price_min:
        price_filter["from"] = price_min
    if price_max:
        price_filter["to"] = price_max
    params["price"] = {"selling_price": price_filter}

    index_line = json.dumps({"index": "listings-wonen-searcher-alias-prod"})
    query_line = json.dumps({"id": "search_result_20250805", "params": params})
    payload = f"{index_line}\n{query_line}\n"

    for attempt in range(retries):
        try:
            resp = requests.post(SEARCH_URL, headers=SEARCH_HEADERS, data=payload, timeout=30)
            data = resp.json()
            if "responses" in data:
                response = data["responses"][0]
                total = response["hits"]["total"]["value"]
                hits = response["hits"]["hits"]
                return [h["_id"] for h in hits], total
        except Exception as e:
            pass
        time.sleep(2 ** attempt)
    return [], 0


def get_detail_with_retry(lid, retries=3):
    for attempt in range(retries):
        try:
            url = DETAIL_URL.format(listing_id=lid)
            resp = requests.get(url, headers=DETAIL_HEADERS, timeout=30)
            if resp.status_code == 200:
                return resp.json()
            elif resp.status_code == 404:
                return None
        except:
            pass
        time.sleep(1)
    return None


def main():
    target = 20000
    output_file = Path("/Users/mohamedhamza/gits/pyfunda/funda_20k.json")
    checkpoint_file = Path("/Users/mohamedhamza/gits/pyfunda/checkpoint_20k.json")

    print(f"=== Funda Download: {target:,} listings ===")
    print(f"Started: {datetime.now().strftime('%H:%M:%S')}")
    print()

    # Load checkpoint
    all_ids = []
    downloaded = {}

    if checkpoint_file.exists():
        with open(checkpoint_file) as f:
            cp = json.load(f)
            all_ids = cp.get("ids", [])
            downloaded = cp.get("downloaded", {})
        print(f"Resumed: {len(all_ids)} IDs, {len(downloaded)} downloaded")

    # Step 1: Collect IDs
    if len(all_ids) < target:
        print("Step 1: Collecting listing IDs...")

        for price_min, price_max in PRICE_PARTITIONS:
            if len(all_ids) >= target:
                break

            # Get total for this partition
            _, total = search_with_retry(0, price_min, price_max)
            total = min(total, 9990)  # ES limit
            remaining = target - len(all_ids)
            to_fetch = min(total, remaining)

            print(f"  €{price_min//1000}K-{price_max//1000}K: {total} available, fetching {to_fetch}")

            page = 0
            partition_ids = []
            while len(partition_ids) < to_fetch:
                ids, _ = search_with_retry(page, price_min, price_max)
                if not ids:
                    break
                partition_ids.extend(ids)
                page += 1
                time.sleep(0.5)

            all_ids.extend(partition_ids[:to_fetch])
            print(f"    Got {len(partition_ids[:to_fetch])} IDs (total: {len(all_ids)})")

        # Save checkpoint
        with open(checkpoint_file, "w") as f:
            json.dump({"ids": all_ids, "downloaded": downloaded}, f)

        print(f"\nCollected {len(all_ids)} IDs")

    # Step 2: Download details
    print(f"\nStep 2: Downloading details...")

    to_download = [lid for lid in all_ids if lid not in downloaded]
    print(f"  {len(to_download)} remaining to download")

    start = time.time()
    errors = 0

    for i, lid in enumerate(to_download):
        detail = get_detail_with_retry(lid)
        if detail:
            downloaded[lid] = detail
        else:
            errors += 1

        done = len(downloaded)
        if done % 500 == 0:
            elapsed = time.time() - start
            rate = (i+1) / elapsed if elapsed > 0 else 0
            eta = (len(to_download) - i - 1) / rate / 60 if rate > 0 else 0
            print(f"  {done}/{len(all_ids)} ({done*100//len(all_ids)}%) | "
                  f"{rate:.1f}/s | ETA: {eta:.0f}min | Errors: {errors}")

            # Save checkpoint
            with open(checkpoint_file, "w") as f:
                json.dump({"ids": all_ids, "downloaded": downloaded}, f)

        time.sleep(0.15)

    # Save final output
    print(f"\nSaving to {output_file}...")
    with open(output_file, "w") as f:
        json.dump({
            "metadata": {
                "count": len(downloaded),
                "downloaded_at": datetime.now().isoformat(),
            },
            "listings": downloaded
        }, f)

    # Cleanup
    if checkpoint_file.exists():
        checkpoint_file.unlink()

    elapsed = time.time() - start
    size_mb = output_file.stat().st_size / 1024 / 1024
    print(f"\nDone! {len(downloaded)} listings in {elapsed/60:.1f} min")
    print(f"File: {size_mb:.1f} MB")


if __name__ == "__main__":
    main()
