#!/usr/bin/env python3
"""Download full listing details from Funda API."""

import json
import time
import requests
from pathlib import Path
from datetime import datetime

# API endpoints
SEARCH_URL = "https://listing-search-wonen.funda.io/_msearch/template"
DETAIL_URL = "https://listing-detail-page.funda.io/api/v4/listing/object/nl/{listing_id}"

SEARCH_HEADERS = {
    "user-agent": "Dart/3.9 (dart:io)",
    "content-type": "application/x-ndjson",
    "referer": "https://www.funda.nl/",
}

DETAIL_HEADERS = {
    "user-agent": "Dart/3.9 (dart:io)",
    "x-funda-app-platform": "android",
}

# Price partitions to stay under 10K limit per query
PRICE_PARTITIONS = [
    (0, 250000),        # ~4,360 listings
    (250000, 300000),   # ~5,500 listings
    (300000, 350000),   # ~8,800 listings
    # Add more if needed for >20K
]

def search_listings(price_min, price_max, page=0, retries=3):
    """Search for listings in a price range."""
    params = {
        "availability": ["available", "negotiations"],
        "type": ["single"],
        "zoning": ["residential"],
        "object_type": ["house", "apartment"],
        "publication_date": {"no_preference": True},
        "offering_type": "buy",
        "page": {"from": page * 15},
        "sort": {"field": "publish_date_utc", "order": "desc"},
    }

    price_filter = {}
    if price_min:
        price_filter["from"] = price_min
    if price_max:
        price_filter["to"] = price_max
    if price_filter:
        params["price"] = {"selling_price": price_filter}

    index_line = json.dumps({"index": "listings-wonen-searcher-alias-prod"})
    query_line = json.dumps({"id": "search_result_20250805", "params": params})
    payload = f"{index_line}\n{query_line}\n"

    for attempt in range(retries):
        try:
            resp = requests.post(SEARCH_URL, headers=SEARCH_HEADERS, data=payload, timeout=30)
            data = resp.json()

            if "responses" not in data:
                raise Exception(f"Invalid response: {data}")

            response = data["responses"][0]
            if "error" in response:
                raise Exception(f"Search error: {response['error']}")

            total = response["hits"]["total"]["value"]
            hits = response["hits"]["hits"]
            listing_ids = [hit["_id"] for hit in hits]

            return listing_ids, total
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(2 ** attempt)  # Exponential backoff
            else:
                raise e

    return [], 0


def get_all_ids_for_partition(price_min, price_max, max_listings=None):
    """Get all listing IDs for a price partition."""
    all_ids = []
    page = 0

    # First request to get total
    ids, total = search_listings(price_min, price_max, page=0)
    all_ids.extend(ids)

    if total > 10000:
        print(f"  WARNING: {total} listings exceeds 10K limit, will only get first ~10K")
        total = min(total, 9990)

    if max_listings:
        total = min(total, max_listings)

    print(f"  Fetching IDs for €{price_min//1000}K-{price_max//1000 if price_max else '∞'}K: {total} listings")

    # Fetch remaining pages
    while len(all_ids) < total:
        page += 1
        ids, _ = search_listings(price_min, price_max, page=page)
        if not ids:
            break
        all_ids.extend(ids)

        if len(all_ids) % 300 == 0:
            print(f"    Got {len(all_ids)}/{total} IDs...")

        time.sleep(0.15)  # Delay between search requests to avoid rate limiting

    return all_ids[:total]


def get_listing_detail(listing_id, retries=3):
    """Get full details for a single listing."""
    url = DETAIL_URL.format(listing_id=listing_id)

    for attempt in range(retries):
        try:
            resp = requests.get(url, headers=DETAIL_HEADERS, timeout=30)
            if resp.status_code == 200:
                return resp.json()
            elif resp.status_code == 404:
                return None
            else:
                raise Exception(f"HTTP {resp.status_code}")
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(2 ** attempt)
            else:
                return None

    return None


def main():
    target_count = 20000
    output_file = Path("funda_listings_20k.json")
    checkpoint_file = Path("funda_checkpoint.json")

    print(f"=== Funda Full Listing Download ===")
    print(f"Target: {target_count:,} listings")
    print(f"Output: {output_file}")
    print()

    # Load checkpoint if exists
    all_ids = []
    downloaded = {}

    if checkpoint_file.exists():
        with open(checkpoint_file) as f:
            checkpoint = json.load(f)
            all_ids = checkpoint.get("ids", [])
            downloaded = checkpoint.get("downloaded", {})
            print(f"Resumed from checkpoint: {len(all_ids)} IDs, {len(downloaded)} downloaded")

    # Step 1: Collect listing IDs from price partitions
    if not all_ids:
        print("Step 1: Collecting listing IDs...")

        for price_min, price_max in PRICE_PARTITIONS:
            remaining = target_count - len(all_ids)
            if remaining <= 0:
                break

            ids = get_all_ids_for_partition(price_min, price_max, max_listings=remaining)
            all_ids.extend(ids)
            print(f"  Total IDs so far: {len(all_ids)}")

            if len(all_ids) >= target_count:
                break

        all_ids = all_ids[:target_count]
        print(f"\nCollected {len(all_ids)} listing IDs")

        # Save checkpoint
        with open(checkpoint_file, "w") as f:
            json.dump({"ids": all_ids, "downloaded": downloaded}, f)

    # Step 2: Download full details
    print(f"\nStep 2: Downloading full details...")

    start_time = time.time()
    errors = 0

    for i, listing_id in enumerate(all_ids):
        if listing_id in downloaded:
            continue

        try:
            detail = get_listing_detail(listing_id)
            if detail:
                downloaded[listing_id] = detail
            else:
                errors += 1
        except Exception as e:
            errors += 1
            print(f"  Error on {listing_id}: {e}")

        # Progress update
        done = len(downloaded)
        if done % 100 == 0:
            elapsed = time.time() - start_time
            rate = done / elapsed if elapsed > 0 else 0
            eta = (len(all_ids) - done) / rate if rate > 0 else 0
            print(f"  Progress: {done}/{len(all_ids)} ({done*100//len(all_ids)}%) | "
                  f"Rate: {rate:.1f}/s | ETA: {eta/60:.1f} min | Errors: {errors}")

            # Save checkpoint every 100
            with open(checkpoint_file, "w") as f:
                json.dump({"ids": all_ids, "downloaded": downloaded}, f)

        time.sleep(0.1)  # 100ms delay between detail requests

    # Save final output
    print(f"\nSaving {len(downloaded)} listings to {output_file}...")

    with open(output_file, "w") as f:
        json.dump({
            "metadata": {
                "count": len(downloaded),
                "downloaded_at": datetime.now().isoformat(),
                "price_partitions": PRICE_PARTITIONS,
            },
            "listings": downloaded
        }, f)

    # Cleanup checkpoint
    if checkpoint_file.exists():
        checkpoint_file.unlink()

    elapsed = time.time() - start_time
    print(f"\nDone! Downloaded {len(downloaded)} listings in {elapsed/60:.1f} minutes")
    print(f"Errors: {errors}")
    print(f"File size: {output_file.stat().st_size / 1024 / 1024:.1f} MB")


if __name__ == "__main__":
    main()
