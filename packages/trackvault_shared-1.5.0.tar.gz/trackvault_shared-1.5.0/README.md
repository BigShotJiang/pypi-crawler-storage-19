# TrackVault Shared Library

Shared utilities and services for TrackVault microservices.

## 🚀 Quick Installation

### Option 1: Install from PyPI (Recommended for Production)

```bash
# Install from PyPI
pip install trackvault-shared>=1.5.0
```

**Benefits:**
- ✅ Standard Python package installation
- ✅ Versioned releases
- ✅ Works in any environment
- ✅ CI/CD friendly
- ✅ No authentication required (public package)

### Option 2: Install Locally (Development Only)

For local development, install in editable mode:

```bash
# From backend/ directory
cd backend
pip install -e ../trackvault-shared-lib
```

**Benefits:**
- ✅ Changes are immediately available (no reinstall needed)
- ✅ Perfect for active development

**Note:** For production/CI/CD, use PyPI (Option 1).

## Features

- **Event Bus**: Redis Streams-based event publishing and subscription
- **Plans Registry**: Multi-tenancy plan definitions and validation
- **Health Checks**: Comprehensive health monitoring utilities
- **Circuit Breaker**: Prevent cascade failures
- **Retry Pattern**: Exponential backoff for resilient operations
- **Event Schemas**: Standardized event types for microservice communication
- **Soft Delete**: Soft delete mixins for Beanie models

## Quick Start

```python
from trackvault_shared import get_project_event_bus, PLANS

# Event Bus
bus = get_project_event_bus("redis://localhost:6379/0")
await bus.publish("project.created", {"project_id": "123"})

# Plans Registry
plan = get_plan_by_name("team")
print(plan["workspace_limits"])
```

## 📚 Publishing

To publish a new version:

1. Update version in `pyproject.toml`
2. Create a GitHub release (tag: `v1.5.0`)
3. GitHub Actions automatically publishes to PyPI

**PyPI API Token Setup:**
1. Go to https://pypi.org/manage/account/token/
2. Create API token with "Upload packages" scope
3. Add as secret `PYPI_API_TOKEN` in GitHub repository settings

## License

MIT License - see LICENSE file for details.

