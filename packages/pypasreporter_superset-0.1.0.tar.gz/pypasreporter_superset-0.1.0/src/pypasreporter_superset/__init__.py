"""
pyPASreporter-superset: Lightweight Apache Superset wrapper for DuckDB analytics.

This package provides a zero-configuration Superset deployment that:
- Uses SQLite for metadata (no PostgreSQL required)
- Uses SimpleCache (no Redis required)
- Runs synchronously (no Celery required)
- Connects to DuckDB in read-only mode
- Ships with admin/admin default credentials

Usage:
    superset-runner init --duckdb ./data.duckdb
    superset-runner run --port 8088
"""

from __future__ import annotations

__version__ = "0.1.0"
__all__ = [
    "SupersetConfig",
    "SupersetBootstrap",
    "__version__",
]

from .bootstrap import SupersetBootstrap
from .config import SupersetConfig
