"""
Superset Configuration Management.

Provides configuration dataclass and environment setup for standalone Superset.
No Redis, no PostgreSQL, just SQLite + DuckDB.
"""

from __future__ import annotations

import os
import secrets
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class SupersetConfig:
    """
    Configuration for standalone Superset deployment.

    Attributes:
        base_dir: Base directory for Superset files (default: .superset)
        duckdb_path: Path to the DuckDB database to connect to
        port: Webserver port (default: 8088)
        host: Webserver bind address (default: 127.0.0.1)
        secret_key: Flask secret key (generated if not provided)
        admin_username: Admin username (default: admin)
        admin_password: Admin password (default: admin)
        app_name: Application name shown in Superset UI
    """

    base_dir: Path = field(default_factory=lambda: Path(".superset"))
    duckdb_path: Path | None = None
    port: int = 8088
    host: str = "127.0.0.1"
    secret_key: str | None = None
    admin_username: str = "admin"
    admin_password: str = "admin"
    app_name: str = "Superset Analytics"

    def __post_init__(self) -> None:
        """Validate and resolve paths."""
        if isinstance(self.base_dir, str):
            self.base_dir = Path(self.base_dir)
        if self.duckdb_path and isinstance(self.duckdb_path, str):
            self.duckdb_path = Path(self.duckdb_path)

    @property
    def superset_home(self) -> Path:
        """Superset home directory."""
        return self.base_dir / "superset_home"

    @property
    def metadata_db_path(self) -> Path:
        """Path to SQLite metadata database."""
        return self.base_dir / "metadata" / "superset.db"

    @property
    def logs_dir(self) -> Path:
        """Logs directory."""
        return self.base_dir / "logs"

    @property
    def secret_key_file(self) -> Path:
        """Path to secret key file."""
        return self.base_dir / ".secret_key"

    @property
    def config_file(self) -> Path:
        """Path to generated superset_config.py."""
        return self.base_dir / "superset_config.py"

    @property
    def cache_dir(self) -> Path:
        """Path to file-based cache directory."""
        return self.base_dir / "cache"

    @property
    def datasources_dir(self) -> Path:
        """Directory for datasource YAML files."""
        return self.base_dir / "datasources"

    def ensure_directories(self) -> None:
        """Create required directories."""
        self.superset_home.mkdir(parents=True, exist_ok=True)
        self.metadata_db_path.parent.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.datasources_dir.mkdir(parents=True, exist_ok=True)

    def get_or_create_secret_key(self) -> str:
        """Get existing secret key or create a new one."""
        if self.secret_key:
            return self.secret_key

        if self.secret_key_file.exists():
            return self.secret_key_file.read_text().strip()

        # Generate new secret key
        new_key = secrets.token_hex(32)
        self.secret_key_file.parent.mkdir(parents=True, exist_ok=True)
        self.secret_key_file.write_text(new_key)
        # Secure the file
        os.chmod(self.secret_key_file, 0o600)
        return new_key

    def get_environment(self) -> dict[str, str]:
        """Get environment variables for Superset."""
        env = os.environ.copy()
        env.update({
            "SUPERSET_HOME": str(self.superset_home.resolve()),
            "SUPERSET_CONFIG_PATH": str(self.config_file.resolve()),
            "FLASK_APP": "superset",
            "FLASK_ENV": "production",
        })
        if self.duckdb_path:
            env["DUCKDB_PATH"] = str(self.duckdb_path.resolve())
        return env

    def get_metadata_uri(self) -> str:
        """Get SQLAlchemy URI for metadata database."""
        return f"sqlite:///{self.metadata_db_path.resolve()}"

    def get_duckdb_uri(self) -> str:
        """Get SQLAlchemy URI for DuckDB data source."""
        if not self.duckdb_path:
            raise ValueError("DuckDB path not configured")
        return f"duckdb:///{self.duckdb_path.resolve()}"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SupersetConfig:
        """Create config from dictionary."""
        return cls(
            base_dir=Path(data.get("base_dir", ".superset")),
            duckdb_path=Path(data["duckdb_path"]) if data.get("duckdb_path") else None,
            port=data.get("port", 8088),
            host=data.get("host", "127.0.0.1"),
            secret_key=data.get("secret_key"),
            admin_username=data.get("admin_username", "admin"),
            admin_password=data.get("admin_password", "admin"),
            app_name=data.get("app_name", "Superset Analytics"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "base_dir": str(self.base_dir),
            "duckdb_path": str(self.duckdb_path) if self.duckdb_path else None,
            "port": self.port,
            "host": self.host,
            "admin_username": self.admin_username,
            "admin_password": self.admin_password,
            "app_name": self.app_name,
        }
