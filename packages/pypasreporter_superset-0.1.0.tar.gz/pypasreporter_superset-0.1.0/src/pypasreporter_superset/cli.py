"""
CLI for pyPASreporter-superset.

Provides commands to initialize and run Superset with DuckDB.

Usage:
    superset-runner init --duckdb ./data.duckdb
    superset-runner run
    superset-runner status
    superset-runner reset
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import click

from . import __version__
from .bootstrap import SupersetBootstrap
from .config import SupersetConfig
from .server import get_server_url, run_flask_dev, run_gunicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


def get_config(
    base_dir: str | None,
    duckdb_path: str | None,
    host: str,
    port: int,
    admin_user: str,
    admin_password: str,
    app_name: str,
) -> SupersetConfig:
    """Build config from CLI options."""
    return SupersetConfig(
        base_dir=Path(base_dir) if base_dir else Path(".superset"),
        duckdb_path=Path(duckdb_path) if duckdb_path else None,
        host=host,
        port=port,
        admin_username=admin_user,
        admin_password=admin_password,
        app_name=app_name,
    )


@click.group()
@click.version_option(version=__version__, prog_name="pyPASreporter-superset")
def main() -> None:
    """
    pyPASreporter-superset: Lightweight Apache Superset for DuckDB analytics.

    Zero-configuration deployment:
    - No PostgreSQL required (uses SQLite)
    - No Redis required (uses SimpleCache)
    - No Celery required (runs synchronously)

    Quick start:
        superset-runner init --duckdb ./data.duckdb
        superset-runner run
    """
    pass


@main.command()
@click.option(
    "--base-dir", "-d",
    type=click.Path(),
    default=".superset",
    help="Base directory for Superset files (default: .superset)",
)
@click.option(
    "--duckdb", "-db",
    type=click.Path(exists=True),
    help="Path to DuckDB database file",
)
@click.option(
    "--host", "-h",
    default="127.0.0.1",
    help="Host to bind to (default: 127.0.0.1)",
)
@click.option(
    "--port", "-p",
    type=int,
    default=8088,
    help="Port to bind to (default: 8088)",
)
@click.option(
    "--admin-user",
    default="admin",
    help="Admin username (default: admin)",
)
@click.option(
    "--admin-password",
    default="admin",
    help="Admin password (default: admin)",
)
@click.option(
    "--app-name",
    default="Superset Analytics",
    help="Application name shown in UI",
)
@click.option(
    "--skip-migrations",
    is_flag=True,
    help="Skip database migrations (for re-init)",
)
@click.option(
    "--skip-admin",
    is_flag=True,
    help="Skip admin user creation",
)
@click.option(
    "--skip-datasource",
    is_flag=True,
    help="Skip DuckDB datasource import",
)
def init(
    base_dir: str,
    duckdb: str | None,
    host: str,
    port: int,
    admin_user: str,
    admin_password: str,
    app_name: str,
    skip_migrations: bool,
    skip_admin: bool,
    skip_datasource: bool,
) -> None:
    """
    Initialize Superset for first use.

    Creates directories, generates config, runs migrations, creates admin user,
    and imports the DuckDB datasource.

    Examples:
        superset-runner init --duckdb ./data.duckdb
        superset-runner init -db ./analytics.duckdb --port 9090
    """
    config = get_config(base_dir, duckdb, host, port, admin_user, admin_password, app_name)

    # Check dependencies
    bootstrap = SupersetBootstrap(config)
    missing = bootstrap.check_dependencies()
    if missing:
        click.echo(f"Missing dependencies: {', '.join(missing)}", err=True)
        click.echo("Install them with: pip install " + " ".join(missing), err=True)
        sys.exit(1)

    try:
        bootstrap.initialize(
            skip_migrations=skip_migrations,
            skip_admin=skip_admin,
            skip_datasource=skip_datasource,
        )
        click.echo()
        click.echo(click.style("✓ Superset initialized successfully!", fg="green", bold=True))
        click.echo()
        click.echo(f"  Base directory: {config.base_dir.resolve()}")
        click.echo(f"  Admin username: {config.admin_username}")
        click.echo(f"  Admin password: {config.admin_password}")
        if config.duckdb_path:
            click.echo(f"  DuckDB:         {config.duckdb_path}")
        click.echo()
        click.echo("Run 'superset-runner run' to start the server.")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        logger.exception("Initialization failed")
        sys.exit(1)


@main.command()
@click.option(
    "--base-dir", "-d",
    type=click.Path(exists=True),
    default=".superset",
    help="Base directory for Superset files",
)
@click.option(
    "--host", "-h",
    default="127.0.0.1",
    help="Host to bind to",
)
@click.option(
    "--port", "-p",
    type=int,
    default=8088,
    help="Port to bind to",
)
@click.option(
    "--workers", "-w",
    type=int,
    default=2,
    help="Number of Gunicorn workers (default: 2)",
)
@click.option(
    "--threads", "-t",
    type=int,
    default=4,
    help="Number of threads per worker (default: 4)",
)
@click.option(
    "--timeout",
    type=int,
    default=120,
    help="Worker timeout in seconds (default: 120)",
)
@click.option(
    "--reload",
    is_flag=True,
    help="Enable auto-reload (development only)",
)
@click.option(
    "--dev",
    is_flag=True,
    help="Use Flask development server instead of Gunicorn",
)
def run(
    base_dir: str,
    host: str,
    port: int,
    workers: int,
    threads: int,
    timeout: int,
    reload: bool,
    dev: bool,
) -> None:
    """
    Start the Superset web server.

    Uses Gunicorn by default (production). Use --dev for Flask dev server.

    Examples:
        superset-runner run
        superset-runner run --port 9090
        superset-runner run --dev --reload
    """
    config = SupersetConfig(
        base_dir=Path(base_dir),
        host=host,
        port=port,
    )

    if not config.config_file.exists():
        click.echo("Superset not initialized. Run 'superset-runner init' first.", err=True)
        sys.exit(1)

    url = get_server_url(config)
    click.echo()
    click.echo(click.style(f"Starting Superset at {url}", fg="cyan", bold=True))
    click.echo("Press Ctrl+C to stop.")
    click.echo()

    try:
        if dev:
            exit_code = run_flask_dev(config, debug=reload)
        else:
            exit_code = run_gunicorn(
                config,
                workers=workers,
                threads=threads,
                timeout=timeout,
                reload=reload,
            )
        sys.exit(exit_code)
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except KeyboardInterrupt:
        click.echo("\nServer stopped.")
        sys.exit(0)


@main.command()
@click.option(
    "--base-dir", "-d",
    type=click.Path(exists=True),
    default=".superset",
    help="Base directory for Superset files",
)
def status(base_dir: str) -> None:
    """
    Show Superset installation status.

    Displays configuration, paths, and dependency status.
    """
    config = SupersetConfig(base_dir=Path(base_dir))
    bootstrap = SupersetBootstrap(config)

    click.echo()
    click.echo(click.style("Superset Status", fg="cyan", bold=True))
    click.echo("=" * 40)

    # Check if initialized
    if config.config_file.exists():
        click.echo(click.style("✓ Initialized", fg="green"))
    else:
        click.echo(click.style("✗ Not initialized", fg="red"))
        click.echo("  Run 'superset-runner init' first.")
        return

    click.echo()
    click.echo("Paths:")
    click.echo(f"  Base directory:   {config.base_dir.resolve()}")
    click.echo(f"  Config file:      {config.config_file}")
    click.echo(f"  Metadata DB:      {config.metadata_db_path}")
    click.echo(f"  Logs:             {config.logs_dir}")

    click.echo()
    click.echo("Dependencies:")
    missing = bootstrap.check_dependencies()
    if not missing:
        click.echo(click.style("  ✓ All dependencies installed", fg="green"))
    else:
        for dep in missing:
            click.echo(click.style(f"  ✗ Missing: {dep}", fg="red"))

    click.echo()


@main.command()
@click.option(
    "--base-dir", "-d",
    type=click.Path(exists=True),
    default=".superset",
    help="Base directory for Superset files",
)
@click.option(
    "--yes", "-y",
    is_flag=True,
    help="Skip confirmation prompt",
)
def reset(base_dir: str, yes: bool) -> None:
    """
    Reset Superset installation (delete all data).

    This will delete all dashboards, charts, datasets, and configuration.
    """
    config = SupersetConfig(base_dir=Path(base_dir))

    if not config.base_dir.exists():
        click.echo("Nothing to reset - base directory does not exist.")
        return

    if not yes:
        click.confirm(
            f"This will delete all data in {config.base_dir.resolve()}. Continue?",
            abort=True,
        )

    bootstrap = SupersetBootstrap(config)
    bootstrap.reset(confirm=True)

    click.echo(click.style("✓ Superset data deleted.", fg="green"))


@main.command("add-db")
@click.option(
    "--base-dir", "-d",
    type=click.Path(exists=True),
    default=".superset",
    help="Base directory for Superset files",
)
@click.argument("duckdb_path", type=click.Path(exists=True))
@click.option(
    "--name", "-n",
    default="duckdb",
    help="Database name in Superset (default: duckdb)",
)
def add_database(base_dir: str, duckdb_path: str, name: str) -> None:
    """
    Add or update a DuckDB database connection.

    DUCKDB_PATH is the path to the DuckDB file.

    Examples:
        superset-runner add-db ./data.duckdb
        superset-runner add-db ./analytics.duckdb --name analytics
    """
    config = SupersetConfig(
        base_dir=Path(base_dir),
        duckdb_path=Path(duckdb_path),
    )

    if not config.config_file.exists():
        click.echo("Superset not initialized. Run 'superset-runner init' first.", err=True)
        sys.exit(1)

    bootstrap = SupersetBootstrap(config)
    bootstrap._generate_datasource_yaml()
    bootstrap._import_datasource()

    click.echo(click.style(f"✓ Database '{name}' added.", fg="green"))
    click.echo(f"  DuckDB: {duckdb_path}")


if __name__ == "__main__":
    main()
