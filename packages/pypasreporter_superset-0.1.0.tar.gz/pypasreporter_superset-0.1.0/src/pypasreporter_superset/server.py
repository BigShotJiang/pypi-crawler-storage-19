"""
Superset Server Runner.

Provides functions to start Superset with Gunicorn or Flask dev server.
"""

from __future__ import annotations

import logging
import subprocess
import sys
import time

from .config import SupersetConfig

logger = logging.getLogger(__name__)


def kill_existing_server(port: int) -> None:
    """Kill any existing process listening on the specified port.

    Args:
        port: Port number to check and clear
    """
    try:
        result = subprocess.run(
            ["lsof", "-ti", f":{port}"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0 and result.stdout.strip():
            pids = result.stdout.strip().split("\n")
            for pid in pids:
                if pid:
                    try:
                        subprocess.run(["kill", "-9", pid], check=False)
                        logger.info(f"Killed existing server process (PID {pid}) on port {port}")
                    except Exception:
                        pass
            time.sleep(0.5)
    except FileNotFoundError:
        try:
            subprocess.run(
                ["fuser", "-k", f"{port}/tcp"],
                capture_output=True,
                check=False,
            )
        except FileNotFoundError:
            logger.debug("Neither lsof nor fuser available to check port")


def run_gunicorn(
    config: SupersetConfig,
    workers: int = 2,
    threads: int = 4,
    timeout: int = 120,
    reload: bool = False,
    kill_existing: bool = True,
) -> int:
    """
    Run Superset using Gunicorn (production server).

    Args:
        config: Superset configuration
        workers: Number of worker processes
        threads: Number of threads per worker
        timeout: Worker timeout in seconds
        reload: Enable auto-reload (for development)
        kill_existing: Kill any existing server on the port

    Returns:
        Gunicorn exit code
    """
    if not config.config_file.exists():
        raise FileNotFoundError(
            f"Superset config not found: {config.config_file}\n"
            "Run 'superset-runner init' first."
        )

    if config.duckdb_path and not config.duckdb_path.exists():
        logger.warning(f"DuckDB file not found: {config.duckdb_path}")
        logger.warning("You may need to create the database first.")

    bind = f"{config.host}:{config.port}"

    cmd = [
        sys.executable, "-m", "gunicorn",
        "--bind", bind,
        "--workers", str(workers),
        "--worker-class", "gthread",
        "--threads", str(threads),
        "--timeout", str(timeout),
        "--access-logfile", str(config.logs_dir / "access.log"),
        "--error-logfile", str(config.logs_dir / "error.log"),
    ]

    if reload:
        cmd.append("--reload")

    cmd.append("superset.app:create_app()")

    env = config.get_environment()

    logger.info(f"Starting Superset on http://{bind}")
    logger.info(f"Superset home: {config.superset_home}")
    logger.info(f"Config file: {config.config_file}")

    if config.duckdb_path:
        logger.info(f"DuckDB: {config.duckdb_path}")

    if kill_existing:
        kill_existing_server(config.port)

    result = subprocess.run(cmd, env=env)
    return result.returncode


def run_flask_dev(
    config: SupersetConfig,
    debug: bool = True,
    kill_existing: bool = True,
) -> int:
    """
    Run Superset using Flask development server.

    Only for development/testing. Use Gunicorn for production.

    Args:
        config: Superset configuration
        debug: Enable Flask debug mode
        kill_existing: Kill any existing server on the port

    Returns:
        Server exit code
    """
    if not config.config_file.exists():
        raise FileNotFoundError(
            f"Superset config not found: {config.config_file}\n"
            "Run 'superset-runner init' first."
        )

    env = config.get_environment()
    env["FLASK_DEBUG"] = "1" if debug else "0"

    cmd = [
        sys.executable, "-m", "flask", "run",
        "--host", config.host,
        "--port", str(config.port),
    ]

    if debug:
        cmd.append("--reload")

    logger.info(f"Starting Superset development server on http://{config.host}:{config.port}")

    if kill_existing:
        kill_existing_server(config.port)

    result = subprocess.run(cmd, env=env)
    return result.returncode


def get_server_url(config: SupersetConfig) -> str:
    """Get the server URL for a config."""
    return f"http://{config.host}:{config.port}"
