"""
Tests for SupersetBootstrap class.
"""

from __future__ import annotations

import pytest

from pypasreporter_superset.bootstrap import SupersetBootstrap
from pypasreporter_superset.config import SupersetConfig


class TestSupersetBootstrap:
    """Tests for SupersetBootstrap class."""

    def test_init(self, superset_config):
        """Test bootstrap initialization."""
        bootstrap = SupersetBootstrap(superset_config)
        assert bootstrap.config == superset_config

    def test_generate_config_file(self, superset_config):
        """Test config file generation."""
        bootstrap = SupersetBootstrap(superset_config)

        # Ensure directories first
        superset_config.ensure_directories()

        # Generate the config file
        bootstrap._generate_config_file()

        # Verify file exists and contains expected content
        assert superset_config.config_file.exists()
        content = superset_config.config_file.read_text()

        # Check essential settings
        assert "SECRET_KEY" in content
        assert "SQLALCHEMY_DATABASE_URI" in content
        assert "sqlite:///" in content  # SQLite metadata
        assert "CACHE_TYPE" in content
        assert "SimpleCache" in content  # No Redis
        assert "CELERY_CONFIG" in content
        assert "Test Superset" in content  # App name

    def test_generate_datasource_yaml(self, superset_config):
        """Test datasource YAML generation."""
        bootstrap = SupersetBootstrap(superset_config)

        # Ensure directories first
        superset_config.ensure_directories()

        # Generate datasource YAML
        bootstrap._generate_datasource_yaml()

        # Verify file exists
        datasource_file = superset_config.datasources_dir / "duckdb.yaml"
        assert datasource_file.exists()

        content = datasource_file.read_text()
        assert "database_name: duckdb" in content
        assert "duckdb:///" in content
        assert "read_only" in content  # DuckDB should be read-only
        assert "allow_dml: false" in content

    def test_generate_datasource_yaml_no_duckdb(self, temp_dir):
        """Test datasource YAML is not generated when no DuckDB path."""
        config = SupersetConfig(base_dir=temp_dir)
        config.ensure_directories()

        bootstrap = SupersetBootstrap(config)
        bootstrap._generate_datasource_yaml()

        # No datasource file should be created
        datasource_file = config.datasources_dir / "duckdb.yaml"
        assert not datasource_file.exists()

    def test_check_dependencies(self, superset_config):
        """Test dependency checking."""
        bootstrap = SupersetBootstrap(superset_config)

        # This will return actual missing deps based on environment
        missing = bootstrap.check_dependencies()

        # Should return a list (empty or with package names)
        assert isinstance(missing, list)

    def test_get_superset_executable_not_found(self, superset_config):
        """Test error when superset executable not found."""
        import shutil

        # Skip if superset is actually installed
        if shutil.which("superset"):
            pytest.skip("superset is installed, cannot test 'not found' scenario")

        bootstrap = SupersetBootstrap(superset_config)

        with pytest.raises(FileNotFoundError, match="superset executable not found"):
            bootstrap._get_superset_executable()

    def test_reset_without_confirm(self, superset_config):
        """Test that reset requires confirmation."""
        bootstrap = SupersetBootstrap(superset_config)

        with pytest.raises(ValueError, match="Must pass confirm=True"):
            bootstrap.reset(confirm=False)

    def test_reset_with_confirm(self, superset_config):
        """Test reset with confirmation."""
        # Create the directories
        superset_config.ensure_directories()
        assert superset_config.base_dir.exists()

        bootstrap = SupersetBootstrap(superset_config)
        bootstrap.reset(confirm=True)

        # Directory should be deleted
        assert not superset_config.base_dir.exists()

    def test_reset_nonexistent_dir(self, superset_config):
        """Test reset when directory doesn't exist."""
        # Don't create directories
        assert not superset_config.base_dir.exists()

        bootstrap = SupersetBootstrap(superset_config)
        # Should not raise an error
        bootstrap.reset(confirm=True)


class TestSupersetBootstrapIntegration:
    """Integration tests that require Superset to be installed."""

    @pytest.mark.skipif(
        True,  # Always skip - these require actual Superset installation
        reason="Integration tests require apache-superset installed",
    )
    def test_full_initialization(self, superset_config):
        """Test full Superset initialization."""
        bootstrap = SupersetBootstrap(superset_config)

        # Check dependencies
        missing = bootstrap.check_dependencies()
        if missing:
            pytest.skip(f"Missing dependencies: {missing}")

        # Run full initialization
        bootstrap.initialize()

        # Verify everything is set up
        assert superset_config.config_file.exists()
        assert superset_config.metadata_db_path.exists()
