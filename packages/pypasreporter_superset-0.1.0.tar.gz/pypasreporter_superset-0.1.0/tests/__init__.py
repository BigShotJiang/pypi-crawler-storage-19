"""
Tests for pypasreporter_superset package.
"""
