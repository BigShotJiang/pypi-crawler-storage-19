"""
Tests for server module.
"""

from __future__ import annotations

from pypasreporter_superset.server import get_server_url


class TestServerHelpers:
    """Tests for server helper functions."""

    def test_get_server_url(self, superset_config):
        """Test server URL generation."""
        url = get_server_url(superset_config)

        assert url == f"http://{superset_config.host}:{superset_config.port}"
        assert url == "http://127.0.0.1:18088"

    def test_get_server_url_custom_host(self, temp_dir):
        """Test server URL with custom host."""
        from pypasreporter_superset.config import SupersetConfig

        config = SupersetConfig(
            base_dir=temp_dir,
            host="0.0.0.0",
            port=9090,
        )

        url = get_server_url(config)
        assert url == "http://0.0.0.0:9090"
