"""
Tests for CLI commands.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from pypasreporter_superset.cli import main


@pytest.fixture
def runner():
    """Create a CLI test runner."""
    return CliRunner()


class TestCLI:
    """Tests for CLI commands."""

    def test_version(self, runner):
        """Test --version flag."""
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "pyPASreporter-superset" in result.output

    def test_help(self, runner):
        """Test --help flag."""
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "Zero-configuration deployment" in result.output
        assert "init" in result.output
        assert "run" in result.output
        assert "status" in result.output
        assert "reset" in result.output

    def test_init_help(self, runner):
        """Test init --help."""
        result = runner.invoke(main, ["init", "--help"])
        assert result.exit_code == 0
        assert "--duckdb" in result.output
        assert "--admin-user" in result.output
        assert "--admin-password" in result.output

    def test_run_help(self, runner):
        """Test run --help."""
        result = runner.invoke(main, ["run", "--help"])
        assert result.exit_code == 0
        assert "--workers" in result.output
        assert "--threads" in result.output
        assert "--dev" in result.output

    def test_status_help(self, runner):
        """Test status --help."""
        result = runner.invoke(main, ["status", "--help"])
        assert result.exit_code == 0
        assert "--base-dir" in result.output

    def test_reset_help(self, runner):
        """Test reset --help."""
        result = runner.invoke(main, ["reset", "--help"])
        assert result.exit_code == 0
        assert "--yes" in result.output

    def test_add_db_help(self, runner):
        """Test add-db --help."""
        result = runner.invoke(main, ["add-db", "--help"])
        assert result.exit_code == 0
        assert "--name" in result.output


class TestInitCommand:
    """Tests for init command."""

    @patch("pypasreporter_superset.cli.SupersetBootstrap")
    def test_init_missing_dependencies(self, mock_bootstrap_class, runner, temp_dir, temp_duckdb):
        """Test init fails with missing dependencies."""
        mock_bootstrap = mock_bootstrap_class.return_value
        mock_bootstrap.check_dependencies.return_value = ["apache-superset"]

        result = runner.invoke(main, [
            "init",
            "--base-dir", str(temp_dir / ".superset"),
            "--duckdb", str(temp_duckdb),
        ])

        assert result.exit_code == 1
        assert "Missing dependencies" in result.output
        assert "apache-superset" in result.output

    @patch("pypasreporter_superset.cli.SupersetBootstrap")
    def test_init_success(self, mock_bootstrap_class, runner, temp_dir, temp_duckdb):
        """Test successful init."""
        mock_bootstrap = mock_bootstrap_class.return_value
        mock_bootstrap.check_dependencies.return_value = []

        result = runner.invoke(main, [
            "init",
            "--base-dir", str(temp_dir / ".superset"),
            "--duckdb", str(temp_duckdb),
            "--admin-user", "myadmin",
            "--admin-password", "mypass",
        ])

        assert result.exit_code == 0
        assert "initialized successfully" in result.output
        mock_bootstrap.initialize.assert_called_once()


class TestRunCommand:
    """Tests for run command."""

    def test_run_not_initialized(self, runner, temp_dir):
        """Test run fails when not initialized."""
        result = runner.invoke(main, [
            "run",
            "--base-dir", str(temp_dir),
        ])

        assert result.exit_code == 1
        assert "not initialized" in result.output


class TestStatusCommand:
    """Tests for status command."""

    def test_status_not_initialized(self, runner, temp_dir):
        """Test status shows not initialized."""
        (temp_dir / ".superset").mkdir()

        result = runner.invoke(main, [
            "status",
            "--base-dir", str(temp_dir / ".superset"),
        ])

        assert result.exit_code == 0
        assert "Not initialized" in result.output

    @patch("pypasreporter_superset.cli.SupersetBootstrap")
    def test_status_initialized(self, mock_bootstrap_class, runner, superset_config):
        """Test status shows initialized."""
        # Create config file to indicate initialization
        superset_config.ensure_directories()
        superset_config.config_file.write_text("# test config")

        mock_bootstrap = mock_bootstrap_class.return_value
        mock_bootstrap.check_dependencies.return_value = []

        result = runner.invoke(main, [
            "status",
            "--base-dir", str(superset_config.base_dir),
        ])

        assert result.exit_code == 0
        assert "Initialized" in result.output
        assert "Paths:" in result.output


class TestResetCommand:
    """Tests for reset command."""

    def test_reset_nonexistent(self, runner, temp_dir):
        """Test reset on nonexistent directory."""
        result = runner.invoke(main, [
            "reset",
            "--base-dir", str(temp_dir / "nonexistent"),
            "--yes",
        ])

        # Should fail because path doesn't exist
        assert result.exit_code != 0

    def test_reset_with_confirmation(self, runner, superset_config):
        """Test reset with --yes flag."""
        superset_config.ensure_directories()
        superset_config.config_file.write_text("# test")

        assert superset_config.base_dir.exists()

        result = runner.invoke(main, [
            "reset",
            "--base-dir", str(superset_config.base_dir),
            "--yes",
        ])

        assert result.exit_code == 0
        assert "deleted" in result.output
        assert not superset_config.base_dir.exists()

    def test_reset_without_confirmation_aborts(self, runner, superset_config):
        """Test reset without --yes aborts on no input."""
        superset_config.ensure_directories()

        result = runner.invoke(main, [
            "reset",
            "--base-dir", str(superset_config.base_dir),
        ], input="n\n")

        # Should abort
        assert result.exit_code == 1 or "Aborted" in result.output
