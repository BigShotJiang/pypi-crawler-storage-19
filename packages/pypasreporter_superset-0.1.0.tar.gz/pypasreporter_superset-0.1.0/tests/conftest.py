"""
Pytest fixtures for pyPASreporter-superset tests.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest


@pytest.fixture
def temp_dir():
    """Create a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def temp_duckdb(temp_dir):
    """Create a temporary DuckDB database."""
    import duckdb

    db_path = temp_dir / "test.duckdb"
    conn = duckdb.connect(str(db_path))

    # Create a simple test table
    conn.execute("""
        CREATE TABLE test_table (
            id INTEGER PRIMARY KEY,
            name VARCHAR,
            created_at TIMESTAMP
        )
    """)
    conn.execute("""
        INSERT INTO test_table VALUES
        (1, 'Alice', '2024-01-01 00:00:00'),
        (2, 'Bob', '2024-01-02 00:00:00'),
        (3, 'Charlie', '2024-01-03 00:00:00')
    """)
    conn.close()

    yield db_path


@pytest.fixture
def superset_config(temp_dir, temp_duckdb):
    """Create a SupersetConfig for testing."""
    from pypasreporter_superset.config import SupersetConfig

    return SupersetConfig(
        base_dir=temp_dir / ".superset",
        duckdb_path=temp_duckdb,
        port=18088,  # Use different port to avoid conflicts
        admin_username="testadmin",
        admin_password="testpass",
        app_name="Test Superset",
    )
