"""
Tests for SupersetConfig class.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from pypasreporter_superset.config import SupersetConfig


class TestSupersetConfig:
    """Tests for SupersetConfig dataclass."""

    def test_default_values(self):
        """Test that default values are set correctly."""
        config = SupersetConfig()

        assert config.base_dir == Path(".superset")
        assert config.duckdb_path is None
        assert config.port == 8088
        assert config.host == "127.0.0.1"
        assert config.admin_username == "admin"
        assert config.admin_password == "admin"
        assert config.app_name == "Superset Analytics"

    def test_custom_values(self, temp_dir, temp_duckdb):
        """Test custom configuration values."""
        config = SupersetConfig(
            base_dir=temp_dir / "custom",
            duckdb_path=temp_duckdb,
            port=9090,
            host="0.0.0.0",
            admin_username="myuser",
            admin_password="mypass",
            app_name="My Analytics",
        )

        assert config.base_dir == temp_dir / "custom"
        assert config.duckdb_path == temp_duckdb
        assert config.port == 9090
        assert config.host == "0.0.0.0"
        assert config.admin_username == "myuser"
        assert config.admin_password == "mypass"
        assert config.app_name == "My Analytics"

    def test_path_properties(self, superset_config):
        """Test derived path properties."""
        config = superset_config

        assert config.superset_home == config.base_dir / "superset_home"
        assert config.metadata_db_path == config.base_dir / "metadata" / "superset.db"
        assert config.logs_dir == config.base_dir / "logs"
        assert config.config_file == config.base_dir / "superset_config.py"
        assert config.cache_dir == config.base_dir / "cache"
        assert config.datasources_dir == config.base_dir / "datasources"

    def test_ensure_directories(self, superset_config):
        """Test that ensure_directories creates required directories."""
        config = superset_config

        # Directories shouldn't exist yet
        assert not config.superset_home.exists()

        # Create directories
        config.ensure_directories()

        # Now they should exist
        assert config.superset_home.exists()
        assert config.metadata_db_path.parent.exists()
        assert config.logs_dir.exists()
        assert config.cache_dir.exists()
        assert config.datasources_dir.exists()

    def test_get_or_create_secret_key(self, superset_config):
        """Test secret key generation and persistence."""
        config = superset_config

        # First call should generate a key
        key1 = config.get_or_create_secret_key()
        assert key1
        assert len(key1) == 64  # 32 bytes = 64 hex chars

        # Second call should return same key
        key2 = config.get_or_create_secret_key()
        assert key1 == key2

        # Key should be persisted to file
        assert config.secret_key_file.exists()
        assert config.secret_key_file.read_text().strip() == key1

    def test_explicit_secret_key(self, temp_dir):
        """Test that explicit secret key is used when provided."""
        config = SupersetConfig(
            base_dir=temp_dir,
            secret_key="my-explicit-key",
        )

        assert config.get_or_create_secret_key() == "my-explicit-key"

    def test_get_metadata_uri(self, superset_config):
        """Test SQLite metadata URI generation."""
        uri = superset_config.get_metadata_uri()

        assert uri.startswith("sqlite:///")
        assert "superset.db" in uri

    def test_get_duckdb_uri(self, superset_config):
        """Test DuckDB URI generation."""
        uri = superset_config.get_duckdb_uri()

        assert uri.startswith("duckdb:///")
        assert "test.duckdb" in uri

    def test_get_duckdb_uri_raises_without_path(self, temp_dir):
        """Test that get_duckdb_uri raises when no path is set."""
        config = SupersetConfig(base_dir=temp_dir)

        with pytest.raises(ValueError, match="DuckDB path not configured"):
            config.get_duckdb_uri()

    def test_get_environment(self, superset_config):
        """Test environment variable generation."""
        env = superset_config.get_environment()

        assert "SUPERSET_HOME" in env
        assert "SUPERSET_CONFIG_PATH" in env
        assert "FLASK_APP" in env
        assert env["FLASK_APP"] == "superset"
        assert "DUCKDB_PATH" in env

    def test_from_dict(self, temp_duckdb):
        """Test creating config from dictionary."""
        data = {
            "base_dir": "/tmp/test",
            "duckdb_path": str(temp_duckdb),
            "port": 9090,
            "admin_username": "custom_admin",
        }

        config = SupersetConfig.from_dict(data)

        assert config.base_dir == Path("/tmp/test")
        assert config.duckdb_path == temp_duckdb
        assert config.port == 9090
        assert config.admin_username == "custom_admin"

    def test_to_dict(self, superset_config):
        """Test converting config to dictionary."""
        data = superset_config.to_dict()

        assert "base_dir" in data
        assert "duckdb_path" in data
        assert "port" in data
        assert data["port"] == 18088
        assert data["admin_username"] == "testadmin"

    def test_string_path_conversion(self, temp_duckdb):
        """Test that string paths are converted to Path objects."""
        config = SupersetConfig(
            base_dir="/tmp/test",
            duckdb_path=str(temp_duckdb),
        )

        assert isinstance(config.base_dir, Path)
        assert isinstance(config.duckdb_path, Path)
