# Job application required inputs (from buse)

## A Thinking Ape — Software Engineer Co-op/Intern (May - Aug 2026)
- Required: First name, last name, email, country, phone, location (city), “How did you hear about this job?”, “Is your co-op a registered co-op program at your school?” (select), “What interests you about building mobile games?” (textarea), “What are some things you hope to learn during your co-op term?” (textarea), “Are you currently located in Canada and legally eligible to work in Canada?” (select).
- Present (not necessarily required): Resume/CV upload, cover letter upload, LinkedIn, website, pronouns, academic year (checkboxes).

## Wurl — Full Stack Software Engineer Intern
- Required: First name, last name, email, country, phone, LinkedIn profile.
- Present (not necessarily required): Resume/CV upload, cover letter upload, other website, prior AppLovin employment, work authorization, visa sponsorship, salary expectation, voluntary self-ID.

## Ithaka — Intern Software Engineer
- Required: First name, last name, email, country, phone; Education (school, degree, discipline, start month/year, end month/year); “Actively enrolled summer 2026?” (select); Michigan connection (select); onsite 5-day requirement (select); years of web/React experience (select); GQL familiarity (textarea); home address; US work eligibility (select); sponsorship/support needed (select); minor work permit (select); verification of identity/work authorization (select); certification (select).
- Present (not necessarily required): Preferred first name, resume/CV upload, cover letter upload.

## Velera — Intern Software Engineer (.Net)
- Required to start (Workday): Create account with email, password, verify password.
- Full application fields appear after account creation/sign-in.

## CACI — Software Development/Engineer Intern (Summer 2026)
- Required to start (Workday): Create account with email, password, verify password; Accept acknowledgment checkbox is shown.
- Full application fields appear after account creation/sign-in.

## Symmetry Systems — Full Stack Software Engineer Intern
- Required: Full name, email, GitHub URL.
- Present (not necessarily required): Resume/CV upload, phone, location, current company, LinkedIn/Twitter/Portfolio/Other links, additional info.

## Dropbox — Software Engineer Intern (Summer 2026)
- Required: First name, last name, email, phone; Education (school, degree, discipline, start/end month+year); Employment (company name, title, start/end month+year); “Legal first name”.
- Present (not necessarily required): Resume/CV upload, cover letter upload, LinkedIn/website, pronouns, location intent/current location, relocation, work authorization, source, prior Dropbox, student groups.

## Dexcom — Intern I, Software Engineering (JR115298)
- Required to start (Workday): Create account with email, password, verify password, acknowledge terms checkbox.
- Full application fields appear after account creation/sign-in.

## Dexcom — Intern I, Software Engineer (JR115313)
- Required to start (Workday): Create account with email, password, verify password, acknowledge terms checkbox.
- Full application fields appear after account creation/sign-in.

## Anima — Intern/New Grad Software Engineer
- Required: Name, email, referral source, resume/CV upload.
- Required questions:
  1) Why Anima over any other company?
  2) Most technically complex project + highest-impact contribution.
  3) Example of going to extreme lengths to get something done.
  4) Important insight you hold that others disagree with and why it matters.

## Velera — Intern ServiceNow Engineer (REMOTE)
- Required to start (Workday): Create account with email, password, verify password.
- Full application fields appear after account creation/sign-in.

## Velera — Intern - .Net Software Engineer (REMOTE)
- Required to start (Workday): Create account with email, password, verify password.
- Full application fields appear after account creation/sign-in.

## Velera — Intern - Data Engineer (REMOTE)
- Required to start (Workday): Create account with email, password, verify password.
- Full application fields appear after account creation/sign-in.

## Oracle — Cloud Product Release Intern (Remote in USA)
- Required (first step): Email address; agree to terms and conditions (checkbox).
- Optional: Switch to phone communication.

## Veeam — AI Intern, Veeam Data Cloud (Remote in USA)
- Required: First name, last name, preferred first name, email, country, phone; resume/CV upload; education (school, degree, end month/year); country of residence; work authorization; visa sponsorship (select); ZIP code; state of residence; prior Veeam employment (select); outside business ownership (select); if yes, describe outside business.

## Stanford Health Care — Summer 2026 Internship (Hybrid)
- Required to start (Workday): Create account with email, password, verify password; acknowledge account checkbox.
- Full application fields appear after account creation/sign-in.

## Motorola Solutions — Java Software Engineer Intern (Hybrid)
- Required to start (Workday): Create account with email, password, verify password; consent checkbox.
- Full application fields appear after account creation/sign-in.

## 8am (AffiniPay) — Software Engineering Internship (Remote in USA)
- Required: First name, last name, email, country, phone; resume/CV upload; “Have you previously worked for 8am?” (select); visa sponsorship required (select); work authorization countries (select); desired compensation (text); LinkedIn profile; home address.
- Present (not necessarily required): Cover letter upload, portfolio/website, “How did you hear about us?”.

## OpenSesame — Software Engineering Internship (Remote)
- Required: First name, last name, email; resume/CV upload; creative project link (textarea); availability for Summer 2026 (select).
- Present (not necessarily required): Phone, LinkedIn.

## Walrus — Full Stack Developer Intern (Remote in USA)
- Required: Name, referral source, phone, email, LinkedIn; city during internship; resume/CV upload; transcript upload; GPA; work authorization (select); sponsorship needed (select).

## Tessera Labs — Software Engineering Intern, Frontend (Remote in USA)
- Required: Legal name, email, resume/CV upload, phone, LinkedIn; work authorization (select); sponsorship needed (select); graduation date; current school.
- Present (not necessarily required): GitHub, portfolio.

## Ever.Ag — Data Engineer Intern (Remote in USA)
- Required: First name, last name, email, country, phone; resume/CV upload; education (degree, discipline, end month/year).
- Present (not necessarily required): Education start month/year; cover letter upload.

## Clerkie — Software Engineer Internship (Remote in USA)
- Required: First name, last name, email, country, phone; resume/CV upload; LinkedIn; “Why Clerkie?” (textarea); “Tell us about a technical project you are proud of” (textarea); “Creative ways you have used code” (textarea); GPA; salary expectations; work authorization (select); fun fact (textarea).
- Present (not necessarily required): Cover letter upload, GitHub URL.

## Quora — Software Engineer Intern (iOS) (Remote in Canada)
- Required: Full name, email, phone, LinkedIn; resume/CV upload; school name; discipline/major; projected graduation date; enrolled at Canadian university (select); availability for January 2026 (select).
- Present (not necessarily required): Current location, SMS consent.

## FINN — Internship Backend Engineering (Remote in Germany)
- Required: Resume/CV upload; full name, email, current location; preferred start date; availability length; enrolled in a German university (select); lectures during internship (select); additional file upload (label not shown).

## Dropbox — Software Engineer Intern (Summer 2026) (Remote in Poland)
- Required (likely): First name, last name, email, phone; resume/CV upload; legal first name.
- Present (not necessarily required): Cover letter upload; pronouns; current location; relocate (select); work authorization (select); source; prior Dropbox employment; student groups.

## Entrust — Software Engineering Intern (Hybrid, Ottawa)
- Required to start (Workday): Create account with email, password, verify password; “I have read the information above to create an account” checkbox.
- Full application fields appear after account creation/sign-in.

## VSP Vision Care — Software Engineering Intern (Remote in USA)
- Required to start (Workday): Create account with email, password, verify password.
- Full application fields appear after account creation/sign-in.
