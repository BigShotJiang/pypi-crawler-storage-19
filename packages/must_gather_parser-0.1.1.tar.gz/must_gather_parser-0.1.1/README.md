```
import asyncio
from must_gather_parser import MustGather
import json

async def main():
    mg = MustGather("~/cases/04348667")
    x = await mg.get_resources(resource_kind_plural="pods", group="core", all_namespaces=True)
    print(json.dumps(x))
    await mg.close()


if __name__ == "__main__":
    asyncio.run(main())
```