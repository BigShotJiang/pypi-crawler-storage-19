"""
Phone Agent - 基于AI的手机自动化框架。

支持UBOX SDK设备的Agent能力，SDK已统一支持Android、iOS和HarmonyOS三端。
用户只需要在创建UBox时传入ModelConfig和AgentConfig，然后使用device.agent()方法即可。
"""

# 只导出用户需要的配置类
from .agent import AgentConfig, PhoneAgent
from .model import ModelConfig

__version__ = "0.1.0"
__all__ = [
    "ModelConfig",
    "AgentConfig",
    "PhoneAgent",
]
