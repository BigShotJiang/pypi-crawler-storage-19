"""YFinance MCP Server - Main entry point.

This module provides the FastMCP server that exposes yfinance functionality
as MCP tools for AI assistants.
"""

from mcp.server.fastmcp import FastMCP

from .tools import ticker, batch, search, market


# Create the MCP server instance
mcp = FastMCP(
    "yfinance-mcp",
    description="MCP Server for Yahoo Finance API - provides AI-friendly financial data tools"
)

# Register all tools
ticker.register(mcp)
batch.register(mcp)
search.register(mcp)
market.register(mcp)


def main():
    """Main entry point for the yfinance-mcp server."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
