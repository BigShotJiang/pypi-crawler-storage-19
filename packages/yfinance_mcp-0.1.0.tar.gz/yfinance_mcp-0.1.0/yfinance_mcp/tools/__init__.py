"""Tools package for YFinance MCP Server."""
