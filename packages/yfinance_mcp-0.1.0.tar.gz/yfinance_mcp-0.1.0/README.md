# YFinance MCP Server

MCP Server for Yahoo Finance API - provides AI-friendly financial data tools.

## Installation

```bash
# Using uvx (recommended)
uvx yfinance-mcp

# Or install with pip
pip install yfinance-mcp
```

## Configuration

Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "yfinance": {
      "command": "uvx",
      "args": ["yfinance-mcp"]
    }
  }
}
```

## Available Tools

| Tool | Description |
|------|-------------|
| `get_ticker_info` | Get basic stock information |
| `get_price_history` | Get historical price data |
| `get_financials` | Get financial statements |
| `get_holders` | Get holder information |
| `get_earnings` | Get earnings data |
| `get_analyst_data` | Get analyst data |
| `get_options` | Get options chain |
| `get_dividends_splits` | Get dividends/splits history |
| `get_sustainability` | Get ESG data |
| `get_ticker_calendar` | Get calendar/news/SEC filings |
| `download` | Batch download historical data |
| `get_tickers_info` | Batch get stock info |
| `search` | Search stocks/news |
| `lookup` | Lookup financial instruments |
| `get_market_calendar` | Get market calendar |
| `screen_stocks` | Stock screening |
| `get_sector_data` | Get sector data |
| `get_industry_data` | Get industry data |

## License

Apache-2.0
