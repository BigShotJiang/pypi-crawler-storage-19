"""
Custom logging handlers for AC Logger package.

Includes handlers for:
- File stack management with nested log files
- CloudWatch integration
- Rotating file handlers with custom features
"""

import logging
import logging.handlers
import threading
from datetime import datetime
from pathlib import Path
from queue import Empty
from queue import Queue
from typing import Any


class SafeRotatingFileHandler(logging.handlers.RotatingFileHandler):
    """
    RotatingFileHandler that safely ignores rotation errors (e.g. permission denied).
    """

    def doRollover(self):  # noqa: N802
        """
        Do a rollover, as described in __init__().
        If rotation fails due to permission/OS errors, we just ignore it
        and continue writing to the current file (or stop rotating).
        """
        try:
            super().doRollover()
        except (PermissionError, OSError) as e:
            import sys

            print(
                f"WARNING: Log rotation failed for {self.baseFilename}: {e}. Continuing without rotation.",
                file=sys.stderr,
            )


class FileStackHandler(logging.Handler):
    """
    A logging handler that supports nested log files with stack management.

    Features:
    - Push new log files onto a stack
    - Pop log files to return to parent files
    - Automatic file rotation and management
    - Thread-safe operations
    """

    def __init__(self, base_log_path: str, max_file_size: int = 10 * 1024 * 1024, backup_count: int = 5, max_stack_depth: int = 10):
        super().__init__()
        self.base_log_path = Path(base_log_path)
        self.max_file_size = max_file_size
        self.backup_count = backup_count
        self.max_stack_depth = max_stack_depth

        # Stack to manage nested log files
        self._file_stack: list[logging.handlers.RotatingFileHandler] = []
        self._lock = threading.RLock()

        # Create base directory
        self.base_log_path.parent.mkdir(parents=True, exist_ok=True)

        # Initialize with base file
        self._push_file(str(self.base_log_path))

    def _push_file(self, file_path: str) -> None:
        """Push a new file handler onto the stack."""
        with self._lock:
            if len(self._file_stack) >= self.max_stack_depth:
                raise RuntimeError(f"Maximum stack depth ({self.max_stack_depth}) exceeded")

            # Create rotating file handler
            handler = SafeRotatingFileHandler(file_path, maxBytes=self.max_file_size, backupCount=self.backup_count, encoding="utf-8")
            handler.setFormatter(self.formatter)
            handler.setLevel(self.level)

            self._file_stack.append(handler)

    def push_log_file(self, filename: str, subdirectory: str | None = None) -> str:
        """
        Push a new log file onto the stack.

        Args:
            filename: Name of the log file
            subdirectory: Optional subdirectory for the log file

        Returns:
            Full path of the created log file
        """
        with self._lock:
            if subdirectory:
                log_dir = self.base_log_path.parent / subdirectory
                log_dir.mkdir(parents=True, exist_ok=True)
                file_path = log_dir / filename
            else:
                file_path = self.base_log_path.parent / filename

            # Add timestamp if file already exists
            if file_path.exists():
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                file_path = file_path.with_stem(f"{file_path.stem}_{timestamp}")

            self._push_file(str(file_path))
            return str(file_path)

    def pop_log_file(self) -> str | None:
        """
        Pop the current log file from the stack and return to the parent file.

        Returns:
            Path of the popped file, or None if already at base level
        """
        with self._lock:
            if len(self._file_stack) <= 1:
                return None  # Can't pop the base file

            # Close and remove the current handler
            current_handler = self._file_stack.pop()
            file_path = current_handler.baseFilename
            current_handler.close()

            return file_path

    def get_current_file(self) -> str:
        """Get the path of the current log file."""
        with self._lock:
            if self._file_stack:
                return self._file_stack[-1].baseFilename
            return str(self.base_log_path)

    def get_stack_depth(self) -> int:
        """Get the current stack depth."""
        with self._lock:
            return len(self._file_stack)

    def get_stack_info(self) -> list[str]:
        """Get information about all files in the stack."""
        with self._lock:
            return [handler.baseFilename for handler in self._file_stack]

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record to the current file."""
        with self._lock:
            if self._file_stack:
                current_handler = self._file_stack[-1]
                current_handler.emit(record)

    def close(self) -> None:
        """Close all file handlers."""
        with self._lock:
            for handler in self._file_stack:
                handler.close()
            self._file_stack.clear()
        super().close()


class CloudWatchHandler(logging.Handler):
    """
    A logging handler that sends logs to AWS CloudWatch.

    Features:
    - Batched log sending for efficiency
    - Automatic retry on failures
    - Graceful fallback when CloudWatch is unavailable
    """

    def __init__(self, log_group: str, log_stream: str | None = None, region: str = "us-east-1", batch_size: int = 10, send_interval: float = 5.0):
        super().__init__()
        self.log_group = log_group
        self.log_stream = log_stream or f"ac-logger-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        self.region = region
        self.batch_size = batch_size
        self.send_interval = send_interval

        # Initialize CloudWatch client
        self._client: Any = None
        self._sequence_token: str | None = None
        self._log_queue: Queue = Queue()
        self._lock: threading.Lock = threading.Lock()
        self._timer: threading.Timer | None = None

        try:
            self._initialize_cloudwatch()
        except Exception as e:
            # Graceful degradation - log locally if CloudWatch fails
            self._client = None
            print(f"Warning: CloudWatch initialization failed: {e}")

    def _initialize_cloudwatch(self) -> None:
        """Initialize CloudWatch client and log group/stream."""
        try:
            import boto3
            from botocore.exceptions import ClientError

            self._client = boto3.client("logs", region_name=self.region)

            # Create log group if it doesn't exist
            if self._client:
                try:
                    self._client.create_log_group(logGroupName=self.log_group)
                except ClientError as e:
                    if e.response["Error"]["Code"] != "ResourceAlreadyExistsException":
                        raise

                # Create log stream if it doesn't exist
                try:
                    self._client.create_log_stream(logGroupName=self.log_group, logStreamName=self.log_stream)
                except ClientError as e:
                    if e.response["Error"]["Code"] != "ResourceAlreadyExistsException":
                        raise

        except ImportError:
            raise ImportError("boto3 is required for CloudWatch logging. Install with: pip install boto3")

    def _send_batch(self) -> None:
        """Send a batch of log events to CloudWatch."""
        if not self._client:
            return

        events = []
        try:
            # Collect events from queue
            while len(events) < self.batch_size:
                try:
                    event = self._log_queue.get_nowait()
                    events.append(event)
                except Empty:
                    break

            if not events:
                return

            # Sort events by timestamp
            events.sort(key=lambda x: x["timestamp"])

            # Send to CloudWatch
            kwargs = {"logGroupName": self.log_group, "logStreamName": self.log_stream, "logEvents": events}

            if self._sequence_token:
                kwargs["sequenceToken"] = self._sequence_token

            response = self._client.put_log_events(**kwargs)
            self._sequence_token = response.get("nextSequenceToken")

        except Exception as e:
            # Put events back in queue for retry
            for event in events:
                self._log_queue.put(event)
            print(f"CloudWatch logging error: {e}")

        finally:
            # Schedule next batch send
            self._schedule_next_send()

    def _schedule_next_send(self) -> None:
        """Schedule the next batch send."""
        with self._lock:
            if self._timer:
                self._timer.cancel()
            timer = threading.Timer(self.send_interval, self._send_batch)
            timer.daemon = True
            timer.start()
            self._timer = timer

    def emit(self, record: logging.LogRecord) -> None:
        """Emit a log record to CloudWatch."""
        if not self._client:
            return

        try:
            # Format the record
            message = self.format(record)

            # Create CloudWatch log event
            event = {
                "timestamp": int(record.created * 1000),  # CloudWatch expects milliseconds
                "message": message,
            }

            # Add to queue
            self._log_queue.put(event)

            # Start sending if not already started
            if not self._timer:
                self._schedule_next_send()

        except Exception as e:
            print(f"Error queuing log for CloudWatch: {e}")

    def flush(self) -> None:
        """Flush any pending log events."""
        if self._timer:
            self._timer.cancel()
        self._send_batch()

    def close(self) -> None:
        """Close the handler and flush pending events."""
        self.flush()
        if self._timer:
            self._timer.cancel()
        super().close()
