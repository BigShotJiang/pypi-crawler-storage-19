"""Nova Agent - Browser automation agent for Nova QA platform."""

__version__ = "0.1.1"
__all__ = ["__version__"]
