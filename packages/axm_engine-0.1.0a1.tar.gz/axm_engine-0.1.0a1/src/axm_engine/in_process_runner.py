"""In-process operation runner for AXM.

Executes operations directly in the current Python process,
passing data objects (DataFrames, etc.) without serialization.
"""

from collections.abc import Callable
from typing import Any


class InProcessOperationRunner:
    """Execute operations in-process without subprocess isolation.

    This is the default runner for most use cases. Operations receive
    data objects directly (e.g., DataFrames) and return results in memory.

    Advantages:
        - No serialization overhead
        - Direct DataFrame/object passing
        - Simple and fast
    """

    def run_function(
        self,
        func: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any]],
        inputs: dict[str, Any],
        parameters: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute an operation function with given inputs.

        Args:
            func: The operation function with signature (inputs, parameters) -> dict.
            inputs: Dictionary of input data (DataFrames, etc.).
            parameters: Runtime parameters for the operation.

        Returns:
            Dictionary of output data from the operation.

        Raises:
            Exception: Any exception raised by the operation is propagated.
        """
        return func(inputs, parameters)
