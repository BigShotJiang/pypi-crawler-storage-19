"""Environment management for uv workspace synchronization."""

import subprocess
from pathlib import Path

SYNC_MARKER = ".axm_synced"


class EnvironmentManager:
    """Manage uv environment synchronization and caching.

    Provides methods to sync workspaces and track sync status
    to avoid redundant uv sync calls during pipeline execution.
    """

    def sync_workspace(self, workspace_root: Path) -> None:
        """Sync all packages in workspace.

        Args:
            workspace_root: Path to the workspace root (contains pyproject.toml).

        Raises:
            RuntimeError: If uv sync fails.
        """
        result = subprocess.run(
            ["uv", "sync", "--all-packages"],  # noqa: S607
            cwd=workspace_root,
            capture_output=True,
            text=True,
            check=False,
        )

        if result.returncode != 0:
            raise RuntimeError(f"uv sync failed: {result.stderr}")

    def is_synced(self, package_dir: Path) -> bool:
        """Check if package environment is already synced.

        A package is considered synced if:
        1. The .axm_synced marker file exists
        2. The marker is newer than pyproject.toml

        Args:
            package_dir: Path to the package directory.

        Returns:
            True if synced, False otherwise.
        """
        marker = package_dir / SYNC_MARKER
        pyproject = package_dir / "pyproject.toml"

        if not marker.exists():
            return False

        if not pyproject.exists():
            return True

        # Check if pyproject.toml is newer than marker
        return pyproject.stat().st_mtime <= marker.stat().st_mtime

    def mark_synced(self, package_dir: Path) -> None:
        """Mark package as synced by creating/updating marker file.

        Args:
            package_dir: Path to the package directory.
        """
        marker = package_dir / SYNC_MARKER
        marker.touch()
