from pydantic import BaseModel

from axm.catalog.entries import OperationEntry, PipelineEntry
from axm_engine.context import RuntimeContext
from axm_engine.dag import topological_sort


class PlanStep(BaseModel):
    """A single step in the execution plan."""

    step_id: str
    operation_ref: OperationEntry
    dependencies: list[str]
    # In the future: expected_inputs, expected_outputs Schema


class ExecutionPlan(BaseModel):
    """The static result of the planning phase."""

    steps: list[PlanStep]


class PipelinePlanner:
    """Analyzes a PipelineEntry and produces an executable plan.

    This is the "Logic Level 2" check:
    - Validates DAG structure (cycles).
    - Resolves all Operation references.
    - (Future) Validates data type compatibility between steps.
    """

    def __init__(self, context: RuntimeContext) -> None:
        self.context = context

    def plan(self, pipeline: PipelineEntry) -> ExecutionPlan:
        # 1. Prepare graph
        steps_map = {step.id: step for step in pipeline.dag.steps}
        deps = {step.id: step.dependencies for step in pipeline.dag.steps}

        # 2. Sort (Validate DAG cycles)
        # topological_sort raises ValueError if cycle detected
        ordered_step_ids = topological_sort(list(steps_map.keys()), deps)

        plan_steps = []
        for step_id in ordered_step_ids:
            step = steps_map[step_id]

            # 3. Resolve operations (Validate References)
            # Use namespaced lookup to avoid collision with data entries
            op_key = f"operation:{step.operation}"
            op_entry = self.context.catalog[op_key]

            plan_steps.append(
                PlanStep(
                    step_id=step_id,
                    operation_ref=op_entry,
                    dependencies=step.dependencies,
                )
            )

        return ExecutionPlan(steps=plan_steps)
