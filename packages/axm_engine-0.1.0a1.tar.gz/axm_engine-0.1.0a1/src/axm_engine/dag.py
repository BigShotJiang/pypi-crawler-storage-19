"""DAG management and topological sorting for pipelines."""

from collections import deque
from collections.abc import Iterable
from typing import TypeVar

T = TypeVar("T")


def topological_sort(nodes: Iterable[T], dependencies: dict[T, list[T]]) -> list[T]:
    """Perform topological sort on a graph.

    Args:
        nodes: List of all node identifiers.
        dependencies: Map of node ID -> list of its dependency node IDs.

    Returns:
        Ordered list of nodes.

    Raises:
        ValueError: If a cycle is detected.
    """
    # Calculate in-degrees
    in_degree = dict.fromkeys(nodes, 0)
    adj: dict[T, list[T]] = {node: [] for node in nodes}

    for node, deps in dependencies.items():
        for dep in deps:
            if dep not in adj:
                # Should not happen if nodes list is complete
                continue
            adj[dep].append(node)
            in_degree[node] += 1

    # Queue for nodes with in-degree 0
    queue = deque([node for node in nodes if in_degree[node] == 0])
    result = []

    while queue:
        u = queue.popleft()
        result.append(u)

        for v in adj[u]:
            in_degree[v] -= 1
            if in_degree[v] == 0:
                queue.append(v)

    if len(result) != len(list(nodes)):
        raise ValueError("Cycle detected in DAG")

    return result
