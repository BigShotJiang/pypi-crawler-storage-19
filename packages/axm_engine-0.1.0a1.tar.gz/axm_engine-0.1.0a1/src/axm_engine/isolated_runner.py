"""Isolated operation runner for subprocess-based uv execution."""

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from axm_engine.context import OperationRequest
from axm_engine.environment import EnvironmentManager


class IsolatedOperationRunner:
    """Execute operations in isolated uv environments via subprocess.

    Uses uv to run operations in their own isolated virtual environments,
    ensuring dependency isolation between operations.
    """

    def __init__(self, env_manager: EnvironmentManager | None = None) -> None:
        """Initialize runner with optional environment manager.

        Args:
            env_manager: Optional environment manager for sync caching.
        """
        self._env_manager = env_manager or EnvironmentManager()

    def run(
        self,
        request: OperationRequest,
        package_dir: Path,
        skip_sync: bool = False,
    ) -> dict[str, Any]:
        """Execute operation in isolated subprocess.

        Args:
            request: The operation request with inputs.
            package_dir: Path to the operation's package directory.
            skip_sync: If True, skip uv sync (use when already synced).

        Returns:
            Dictionary of outputs from the operation.

        Raises:
            RuntimeError: If the subprocess fails.
            ValueError: If output cannot be parsed as JSON.
        """
        package_name = package_dir.name
        entrypoint = request.operation.spec.entrypoint

        # Serialize inputs and parameters to JSON
        inputs_json = json.dumps(request.inputs)
        params_json = json.dumps(request.parameters)

        # Generate wrapper script that imports and runs the operation
        # Operations expect signature: fn(inputs: dict, parameters: dict) -> dict
        wrapper_script = f"""
import json
import sys
from {package_name} import {entrypoint}

inputs = json.loads(sys.argv[1])
parameters = json.loads(sys.argv[2])
result = {entrypoint}(inputs, parameters)
print(json.dumps(result))
"""

        # Write wrapper to temp file
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as tmp:
            tmp.write(wrapper_script)
            script_path = tmp.name

        try:
            # Execute via uv run
            cmd = ["uv", "run"]

            # Skip sync if already synced (performance optimization)
            if skip_sync or self._env_manager.is_synced(package_dir):
                cmd.append("--no-sync")

            cmd.extend(
                [
                    "--package",
                    package_name,
                    "python",
                    script_path,
                    inputs_json,
                    params_json,
                ]
            )

            result = subprocess.run(  # noqa: S603
                cmd,
                cwd=package_dir.parent,  # Run from operations/ dir
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode != 0:
                raise RuntimeError(
                    f"Operation failed with exit code {result.returncode}: "
                    f"{result.stderr}"
                )

            # Parse JSON output
            try:
                return json.loads(result.stdout)  # type: ignore[no-any-return]
            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Failed to parse operation output as JSON: {e}"
                ) from e

        finally:
            # Clean up temp file
            Path(script_path).unlink(missing_ok=True)
