"""Runtime context models for AXM execution."""

from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field

from axm.catalog.entries import OperationEntry
from axm.core.protocols import BaseCatalog


class RuntimeContext(BaseModel):
    """Global context for a pipeline or operation execution.

    Holds references to shared resources like the catalog, configuration,
    and unique run identifiers.

    Attributes:
        run_id: Unique identifier for this execution trace.
        start_time: When the execution started (UTC).
        catalog: Reference to the loaded catalog (optional, for lookup).
        config: Arbitrary runtime configuration (env vars, dry-run flags).
    """

    run_id: str = Field(default_factory=lambda: str(uuid4()))
    start_time: datetime = Field(default_factory=lambda: datetime.now(UTC))
    config: dict[str, Any] = Field(default_factory=dict)
    _catalog: Any | None = None

    def set_catalog(self, catalog: BaseCatalog[Any]) -> None:
        """Attach a catalog to the context."""
        self._catalog = catalog

    @property
    def catalog(self) -> BaseCatalog[Any]:
        """Get the attached catalog or raise error."""
        if self._catalog is None:
            raise RuntimeError("Catalog not attached to RuntimeContext")
        return self._catalog  # type: ignore[no-any-return]


class OperationRequest(BaseModel):
    """Request to execute a specific operation.

    Encapsulates all information needed by a Runner to execute a task.

    Attributes:
        operation: The OperationEntry definition to run.
        inputs: Mapping of binding names to runtime values (e.g. DataFrames or Paths).
                Note: In Phase 1, these might be Paths or Dicts.
        parameters: Runtime parameters to inject into the operation.
    """

    operation: OperationEntry
    inputs: dict[str, Any] = Field(default_factory=dict)
    parameters: dict[str, Any] = Field(default_factory=dict)
