"""Pipeline dependency collection and merging utilities."""

import tomllib
from pathlib import Path

import tomli_w


def collect_pipeline_deps(project_root: Path, operation_names: list[str]) -> list[str]:
    """Collect dependencies from all operations in a pipeline.

    Args:
        project_root: Root directory of the AXM project.
        operation_names: List of operation names to collect deps from.

    Returns:
        List of dependency specifications (e.g., ["polars>=1.0", "numpy"]).
    """
    all_deps: list[str] = []
    operations_dir = project_root / "operations"

    for op_name in operation_names:
        op_dir = operations_dir / op_name
        pyproject_path = op_dir / "pyproject.toml"

        if not pyproject_path.exists():
            continue

        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)

        deps = data.get("project", {}).get("dependencies", [])
        all_deps.extend(deps)

    return all_deps


def merge_deps(project_root: Path, new_deps: list[str]) -> None:
    """Merge new dependencies into the project's pyproject.toml.

    Args:
        project_root: Root directory of the AXM project.
        new_deps: List of new dependency specifications to add.
    """
    pyproject_path = project_root / "pyproject.toml"

    with open(pyproject_path, "rb") as f:
        data = tomllib.load(f)

    existing_deps: list[str] = data.get("project", {}).get("dependencies", [])

    # Deduplicate: extract package names for comparison
    existing_names = {_extract_package_name(d) for d in existing_deps}

    for dep in new_deps:
        pkg_name = _extract_package_name(dep)
        if pkg_name not in existing_names:
            existing_deps.append(dep)
            existing_names.add(pkg_name)

    # Update data
    if "project" not in data:
        data["project"] = {}
    data["project"]["dependencies"] = existing_deps

    # Write back
    with open(pyproject_path, "wb") as f:
        tomli_w.dump(data, f)


def _extract_package_name(dep: str) -> str:
    """Extract package name from dependency spec.

    Examples:
        "polars>=1.0" -> "polars"
        "numpy" -> "numpy"
        "pandas[excel]>=2.0" -> "pandas"
    """
    # Remove extras like [excel]
    dep = dep.split("[")[0]
    # Remove version specifiers
    for sep in [">=", "<=", "==", "!=", ">", "<", "~="]:
        dep = dep.split(sep)[0]
    return dep.strip().lower()
