"""Main execution logic for AXM operations."""

from typing import Any

from axm_engine.context import OperationRequest, RuntimeContext
from axm_engine.io import IOManager
from axm_engine.runner import PythonFunctionRunner


class OperationRunner:
    """Orchestrates the Zero-Trust execution of an operation.

    By default, operations run in-process with DataFrames passed directly.
    The framework handles all I/O and validation.
    """

    def __init__(
        self, context: RuntimeContext, io_manager: IOManager | None = None
    ) -> None:
        self.context = context
        self.io = io_manager or IOManager()
        self._python_runner = PythonFunctionRunner()

    def run(self, request: OperationRequest) -> dict[str, Any]:
        """Execute the operation request and return output values.

        Zero-Trust Workflow:
        1. Load and validate all inputs via IOManager.
        2. Execute operation in-process (receives DataFrames directly).
        3. Validate and save outputs via IOManager.
        """
        # 1. Load all inputs (Zero-Trust: framework handles I/O)
        loaded_inputs = {}
        if request.operation.inputs:
            # Operation defines explicit bindings — use them
            for binding in request.operation.inputs:
                if binding.name in request.inputs:
                    # Already provided in memory (e.g. from previous step)
                    loaded_inputs[binding.name] = request.inputs[binding.name]
                else:
                    # Load and validate via IOManager
                    entry = self.context.catalog[binding.data_ref]
                    loaded_inputs[binding.name] = self.io.load(entry)
        else:
            # No explicit bindings — pass through all inputs (simple operations)
            loaded_inputs = dict(request.inputs)

        # 2. Execute operation in-process
        result = self._python_runner.run(
            request.model_copy(update={"inputs": loaded_inputs})
        )

        # 3. Validate and save outputs
        outputs = {}
        if isinstance(result, dict):
            for binding in request.operation.outputs:
                if binding.name in result:
                    entry = self.context.catalog[binding.data_ref]
                    val = result[binding.name]
                    self.io.save(entry, val)
                    outputs[binding.name] = val
        elif len(request.operation.outputs) == 1:
            binding = request.operation.outputs[0]
            entry = self.context.catalog[binding.data_ref]
            self.io.save(entry, result)
            outputs[binding.name] = result

        return outputs
