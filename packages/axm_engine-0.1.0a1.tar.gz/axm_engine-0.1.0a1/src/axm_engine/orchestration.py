"""Pipeline orchestration and execution."""

from typing import Any

from axm.catalog.entries.pipeline import PipelineEntry
from axm_engine.context import OperationRequest, RuntimeContext
from axm_engine.dag import topological_sort
from axm_engine.execution import OperationRunner
from axm_engine.io import IOManager


class PipelineRunner:
    """Orchestrates the execution of a PipelineEntry DAG.

    Manages step dependencies and intermediate data flow.
    """

    def __init__(
        self, context: RuntimeContext, io_manager: IOManager | None = None
    ) -> None:
        self.context = context
        self.io = io_manager or IOManager()
        self._op_runner = OperationRunner(context, io_manager=self.io)

    def run(
        self, pipeline: PipelineEntry, inputs: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Execute the pipeline DAG.

        Workflow:
        1. Sort steps topologically.
        2. Execute each step, capturing outputs.
        3. Pass outputs of one step as inputs to dependent steps.
        """
        # 1. Prepare graph
        steps = {step.id: step for step in pipeline.dag.steps}
        deps = {step.id: step.dependencies for step in pipeline.dag.steps}

        # 2. Sort
        ordered_step_ids = topological_sort(list(steps.keys()), deps)

        # 3. Execution state (capturing intermediate results)
        # key: step_id, value: dict[binding_name, data]
        results: dict[str, dict[str, Any]] = {}

        # Load pipeline inputs from catalog via IOManager
        pipeline_inputs: dict[str, Any] = inputs or {}
        for binding in pipeline.inputs:
            if binding.name not in pipeline_inputs:
                # Load from catalog using data: namespace
                data_key = f"data:{binding.data_ref}"
                try:
                    data_entry = self.context.catalog[data_key]
                    pipeline_inputs[binding.name] = self.io.load(data_entry)
                except KeyError:
                    # Fallback: try loading without namespace
                    data_entry = self.context.catalog[binding.data_ref]
                    pipeline_inputs[binding.name] = self.io.load(data_entry)

        # 4. Run loop
        for step_id in ordered_step_ids:
            step = steps[step_id]

            # Resolve operation entry (use namespaced lookup)
            op_key = f"operation:{step.operation}"
            op_entry = self.context.catalog[op_key]

            # Prepare inputs for this step
            # Start with pipeline inputs for root steps, then add dependency outputs
            step_inputs = dict(pipeline_inputs) if not step.dependencies else {}
            for dep_id in step.dependencies:
                # Merge all outputs from dependency result as potential inputs
                step_inputs.update(results[dep_id])

            # Request execution
            request = OperationRequest(
                operation=op_entry, inputs=step_inputs, parameters=step.arguments
            )

            # Execute step
            step_outputs = self._op_runner.run(request)

            # Store results
            results[step_id] = step_outputs

        # 5. Return final results (mapping to pipeline output bindings)
        final_outputs = {}
        # Simple heuristic: return outputs of all steps if no explicit mapping
        for _step_id, res in results.items():
            final_outputs.update(res)

        return final_outputs
