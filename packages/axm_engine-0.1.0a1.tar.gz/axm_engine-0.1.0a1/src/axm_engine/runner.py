"""Runners for executing operation code."""

import importlib
from collections.abc import Callable
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from typing import TYPE_CHECKING, Any

from axm.catalog.entries.operation import OperationType
from axm_engine.context import OperationRequest

if TYPE_CHECKING:
    from axm.catalog.entries.operation import OperationEntry


class PythonFunctionRunner:
    """Executes Python functions dynamically.

    Supports entrypoints in the format 'module.submodule:function_name'.
    """

    def run(self, request: OperationRequest) -> Any:
        """Execute a Python operation with the given inputs."""
        spec = request.operation.spec
        if not spec.entrypoint:
            raise ValueError(
                f"No entrypoint defined for operation {request.operation.name}"
            )

        if spec.type == OperationType.PYTHON_FILE and spec.source:
            func = self._resolve_from_file(
                request.operation, spec.source, spec.entrypoint
            )
        else:
            func = self._resolve_entrypoint(spec.entrypoint)

        # Call with standard AXM operation signature: func(inputs, parameters)
        return func(request.inputs, request.parameters)

    def _resolve_entrypoint(self, entrypoint: str) -> Callable[..., Any]:
        """Resolve a string entrypoint to a callable function.

        Format: 'module.path:function_name'
        """
        if ":" not in entrypoint:
            raise ValueError(
                f"Invalid entrypoint format: '{entrypoint}'. Expected 'module:function'"
            )

        module_path, func_name = entrypoint.split(":")
        module = importlib.import_module(module_path)
        return self._get_callable(module, func_name)

    def _resolve_from_file(
        self, operation: "OperationEntry", source_path: str, function_name: str
    ) -> Callable[..., Any]:
        """Load a Python function from a specific file path.

        Resolves relative paths using the operation's _source_path.
        """
        path = Path(source_path)

        # Resolve relative paths using operation's source location
        if not path.is_absolute() and operation._source_path:
            path = (operation._source_path.parent / source_path).resolve()

        spec = spec_from_file_location("dynamic_mod", str(path))
        if not spec or not spec.loader:
            raise ImportError(f"Could not load module from {path}")

        module = module_from_spec(spec)
        spec.loader.exec_module(module)
        return self._get_callable(module, function_name)

    def _get_callable(self, module: Any, func_name: str) -> Callable[..., Any]:
        """Helper to get and verify a callable from a module."""
        func = getattr(module, func_name)
        if not callable(func):
            raise TypeError(f"Attribute '{func_name}' is not callable")
        return func  # type: ignore[no-any-return]
