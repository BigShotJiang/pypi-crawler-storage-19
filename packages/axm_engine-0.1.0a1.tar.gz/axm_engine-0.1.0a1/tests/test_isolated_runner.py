"""Tests for IsolatedOperationRunner - subprocess-based uv execution."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from axm.catalog.entries.operation import (
    DataBinding,
    OperationEntry,
    OperationSpec,
    OperationType,
)
from axm_engine.context import OperationRequest
from axm_engine.isolated_runner import IsolatedOperationRunner


@pytest.fixture
def sample_operation() -> OperationEntry:
    """Create a sample operation entry for testing."""
    return OperationEntry(
        axm="1.0",
        kind="operation",
        name="resize_image",
        version="1.0.0",
        identity={
            "display_name": "Resize Image",
            "description": "Test operation",
            "domain": "test",
            "owner": {"team": "test", "contact": "test@example.com"},
        },
        spec=OperationSpec(
            type=OperationType.PYTHON_FILE,
            source="resize_image.py",
            entrypoint="resize_image",
        ),
        inputs=[DataBinding(name="input_data", data_ref="raw_data", version="*")],
        outputs=[DataBinding(name="output_data", data_ref="processed_data")],
    )


@pytest.fixture
def sample_request(sample_operation: OperationEntry) -> OperationRequest:
    """Create a sample operation request."""
    return OperationRequest(
        operation=sample_operation,
        inputs={"input_data": {"key": "value"}},
        parameters={},
    )


class TestIsolatedOperationRunner:
    """Tests for IsolatedOperationRunner."""

    def test_generates_correct_uv_command(
        self, sample_request: OperationRequest, tmp_path: Path
    ) -> None:
        """Test that runner generates correct uv run command."""
        runner = IsolatedOperationRunner()
        package_dir = tmp_path / "operations" / "resize_image"
        package_dir.mkdir(parents=True)
        (package_dir / "pyproject.toml").write_text('[project]\nname = "resize_image"')

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout=json.dumps({"output_data": "result"}),
                stderr="",
            )

            runner.run(sample_request, package_dir)

            # Verify uv run was called
            mock_run.assert_called_once()
            call_args = mock_run.call_args
            cmd = call_args[0][0]

            assert "uv" in cmd[0]
            assert "run" in cmd
            assert "--package" in cmd
            assert "resize_image" in cmd

    def test_serializes_inputs_as_json(
        self, sample_request: OperationRequest, tmp_path: Path
    ) -> None:
        """Test that inputs are serialized to JSON for subprocess."""
        runner = IsolatedOperationRunner()
        package_dir = tmp_path / "operations" / "resize_image"
        package_dir.mkdir(parents=True)
        (package_dir / "pyproject.toml").write_text('[project]\nname = "resize_image"')

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout=json.dumps({"output_data": "result"}),
                stderr="",
            )

            runner.run(sample_request, package_dir)

            # Check that inputs were passed (in some form)
            # The full command or input should contain our serialized data
            assert mock_run.called

    def test_parses_json_output(
        self, sample_request: OperationRequest, tmp_path: Path
    ) -> None:
        """Test that JSON output from subprocess is correctly parsed."""
        runner = IsolatedOperationRunner()
        package_dir = tmp_path / "operations" / "resize_image"
        package_dir.mkdir(parents=True)
        (package_dir / "pyproject.toml").write_text('[project]\nname = "resize_image"')

        expected_result = {"output_data": {"processed": True, "count": 42}}

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout=json.dumps(expected_result),
                stderr="",
            )

            result = runner.run(sample_request, package_dir)

            assert result == expected_result

    def test_raises_on_subprocess_failure(
        self, sample_request: OperationRequest, tmp_path: Path
    ) -> None:
        """Test that subprocess failures raise appropriate errors."""
        runner = IsolatedOperationRunner()
        package_dir = tmp_path / "operations" / "resize_image"
        package_dir.mkdir(parents=True)
        (package_dir / "pyproject.toml").write_text('[project]\nname = "resize_image"')

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1,
                stdout="",
                stderr="ModuleNotFoundError: No module named 'pillow'",
            )

            with pytest.raises(RuntimeError, match="Operation failed"):
                runner.run(sample_request, package_dir)

    def test_raises_on_invalid_json_output(
        self, sample_request: OperationRequest, tmp_path: Path
    ) -> None:
        """Test that invalid JSON output raises error."""
        runner = IsolatedOperationRunner()
        package_dir = tmp_path / "operations" / "resize_image"
        package_dir.mkdir(parents=True)
        (package_dir / "pyproject.toml").write_text('[project]\nname = "resize_image"')

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0,
                stdout="not valid json {{{",
                stderr="",
            )

            with pytest.raises(ValueError, match="output"):
                runner.run(sample_request, package_dir)
