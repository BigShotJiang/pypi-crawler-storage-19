from unittest.mock import MagicMock, patch

import pytest

from axm.catalog.entries import (
    DAG,
    Identity,
    OperationEntry,
    OperationSpec,
    OperationType,
    Owner,
    PipelineEntry,
    PipelineStep,
)
from axm_engine.context import RuntimeContext
from axm_engine.dag import topological_sort
from axm_engine.orchestration import PipelineRunner


def test_topological_sort_simple():
    nodes = ["A", "B", "C"]
    deps = {"B": ["A"], "C": ["B"], "A": []}
    ordered = topological_sort(nodes, deps)
    assert ordered == ["A", "B", "C"]


def test_topological_sort_cycle():
    nodes = ["A", "B"]
    deps = {"A": ["B"], "B": ["A"]}
    with pytest.raises(ValueError, match="Cycle detected"):
        topological_sort(nodes, deps)


@pytest.fixture
def complex_pipeline():
    return PipelineEntry(
        name="complex_p",
        version="1.0.0",
        identity=Identity(
            display_name="Complex",
            description="desc",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        dag=DAG(
            steps=[
                PipelineStep(id="step2", operation="op2", dependencies=["step1"]),
                PipelineStep(id="step1", operation="op1"),
                PipelineStep(id="step3", operation="op3", dependencies=["step1"]),
            ]
        ),
    )


def test_pipeline_runner_execution_order(complex_pipeline):
    context = MagicMock(spec=RuntimeContext)

    # Create real OperationEntry objects
    def make_op(name):
        return OperationEntry(
            name=name,
            version="1.0",
            identity=Identity(
                display_name=name,
                description="desc",
                domain="test",
                owner=Owner(team="test", contact="test@test.com"),
            ),
            spec=OperationSpec(
                type=OperationType.PYTHON_PACKAGE, entrypoint=f"pkg:{name}"
            ),
        )

    op1 = make_op("op1")
    op2 = make_op("op2")
    op3 = make_op("op3")

    # Mock __getitem__ (catalog[name]) with namespaced support
    def get_entry(name):
        # Strip namespace prefix if present
        if name.startswith("operation:"):
            name = name.split(":", 1)[1]
        mapping = {
            "op1": op1,
            "op2": op2,
            "op3": op3,
        }
        return mapping[name]

    context.catalog.__getitem__.side_effect = get_entry

    runner = PipelineRunner(context)

    with patch("axm_engine.execution.OperationRunner.run") as mock_run:
        mock_run.return_value = {"data": "ok"}

        runner.run(complex_pipeline)

        # Verify call order: step1 MUST be first
        assert mock_run.call_count == 3
        first_call_args = mock_run.call_args_list[0]
        # In our topological sort, ties are stable (A, B, C order if no deps)
        # But here step1 is clearly the only root.
        assert first_call_args[0][0].operation == op1


def test_pipeline_runner_with_inputs():
    """Test pipeline runner passes inputs to root steps."""
    from axm.catalog.entries import DataBinding

    pipeline = PipelineEntry(
        name="input_pipeline",
        version="1.0.0",
        identity=Identity(
            display_name="Input",
            description="desc",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        inputs=[DataBinding(name="raw_data", data_ref="raw_data_entry")],
        dag=DAG(
            steps=[
                PipelineStep(id="step1", operation="op1"),
            ]
        ),
    )

    context = MagicMock(spec=RuntimeContext)

    op1 = OperationEntry(
        name="op1",
        version="1.0",
        identity=Identity(
            display_name="op1",
            description="desc",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        spec=OperationSpec(type=OperationType.PYTHON_PACKAGE, entrypoint="pkg:op1"),
    )

    def get_entry(name):
        if name.startswith("operation:"):
            return op1
        # Only reached if pipeline has explicit inputs - see line 51-58
        raise KeyError(name)

    context.catalog.__getitem__.side_effect = get_entry

    runner = PipelineRunner(context)

    with patch("axm_engine.execution.OperationRunner.run") as mock_run:
        mock_run.return_value = {"output": "result"}

        # Provide inputs directly
        runner.run(pipeline, inputs={"raw_data": "input_value"})

        assert mock_run.call_count == 1
        call_args = mock_run.call_args_list[0][0][0]
        assert call_args.inputs["raw_data"] == "input_value"
