"""Test in-process pipeline execution."""

from axm_engine.in_process_runner import InProcessOperationRunner


class TestInProcessOperationRunner:
    """Test executing operations in-process (no subprocess)."""

    def test_run_simple_function(self) -> None:
        """Execute a simple operation function in-process."""
        # Arrange
        runner = InProcessOperationRunner()

        # Simple function that processes data
        def clean_data(inputs: dict, parameters: dict) -> dict:
            data = inputs["raw"]
            return {"clean": data.upper()}

        # Act
        result = runner.run_function(
            func=clean_data,
            inputs={"raw": "hello"},
            parameters={},
        )

        # Assert
        assert result == {"clean": "HELLO"}

    def test_run_with_dataframe(self) -> None:
        """Execute operation that processes DataFrame."""
        import polars as pl

        runner = InProcessOperationRunner()

        def transform(inputs: dict, parameters: dict) -> dict:
            df: pl.DataFrame = inputs["input_df"]
            result = df.with_columns(pl.col("value") * 2)
            return {"output_df": result}

        input_df = pl.DataFrame({"value": [1, 2, 3]})

        result = runner.run_function(
            func=transform,
            inputs={"input_df": input_df},
            parameters={},
        )

        expected = pl.DataFrame({"value": [2, 4, 6]})
        assert result["output_df"].equals(expected)
