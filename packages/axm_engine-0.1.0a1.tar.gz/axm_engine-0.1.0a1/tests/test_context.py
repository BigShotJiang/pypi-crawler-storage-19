"""Tests for RuntimeContext."""

import pytest

from axm_engine.context import RuntimeContext


def test_runtime_context_init():
    """Should initialize with defaults."""
    ctx = RuntimeContext()
    assert ctx.run_id is not None
    assert ctx.start_time is not None
    assert ctx.config == {}


def test_catalog_access():
    """Should raise error if catalog accessed without setting."""
    ctx = RuntimeContext()
    with pytest.raises(RuntimeError, match="Catalog not attached"):
        _ = ctx.catalog


def test_catalog_setting():
    """Should allow setting and retrieving catalog."""

    class MockCatalog:
        pass

    catalog = MockCatalog()
    ctx = RuntimeContext()
    ctx.set_catalog(catalog)  # type: ignore
    assert ctx.catalog is catalog
