from unittest.mock import MagicMock

import pytest

from axm.catalog.entries import (
    Identity,
    OperationEntry,
    OperationSpec,
    OperationType,
    Owner,
)
from axm_engine.context import OperationRequest
from axm_engine.runner import PythonFunctionRunner


@pytest.fixture
def mock_operation():
    return OperationEntry(
        name="test_op",
        version="1.0.0",
        identity=Identity(
            display_name="Test Op",
            description="A test operation",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        spec=OperationSpec(
            type=OperationType.PYTHON_PACKAGE, package="math", entrypoint="math:sqrt"
        ),
    )


def sample_func(inputs: dict, parameters: dict) -> dict:
    """Sample operation following AXM signature."""
    return {"result": inputs["x"] * inputs["x"]}


def test_python_runner_executes_function(mock_operation, monkeypatch):
    runner = PythonFunctionRunner()

    # Mock a module with our test function
    mock_module = MagicMock()
    mock_module.sample_func = sample_func
    monkeypatch.setattr(
        "importlib.import_module", lambda m: mock_module if m == "my_pkg" else None
    )

    mock_operation.spec.entrypoint = "my_pkg:sample_func"

    request = OperationRequest(operation=mock_operation, inputs={"x": 4})

    result = runner.run(request)
    assert result == {"result": 16}


def test_python_runner_resolves_module_function(mock_operation):
    # This test verifies it can load from a string entrypoint
    runner = PythonFunctionRunner()
    func = runner._resolve_entrypoint("math:sqrt")
    import math

    assert func == math.sqrt


def test_python_runner_no_entrypoint_error():
    """Test error when no entrypoint is defined."""
    operation = OperationEntry(
        name="no_entry",
        version="1.0.0",
        identity=Identity(
            display_name="No Entry",
            description="Op without entrypoint",
            domain="test",
            owner=Owner(team="t", contact="t@t.com"),
        ),
        spec=OperationSpec(type=OperationType.PYTHON_PACKAGE),
    )
    runner = PythonFunctionRunner()
    request = OperationRequest(operation=operation, inputs={})

    with pytest.raises(ValueError, match="No entrypoint defined"):
        runner.run(request)


def test_python_runner_invalid_entrypoint_format():
    """Test error for invalid entrypoint format (missing colon)."""
    runner = PythonFunctionRunner()

    with pytest.raises(ValueError, match="Invalid entrypoint format"):
        runner._resolve_entrypoint("math.sqrt")


def test_python_runner_resolve_from_file(tmp_path):
    """Test resolving a function from a file."""
    py_file = tmp_path / "my_op.py"
    py_file.write_text(
        """
def my_func(inputs, parameters):
    return {"result": "success"}
"""
    )

    operation = OperationEntry(
        name="file_op",
        version="1.0.0",
        identity=Identity(
            display_name="File",
            description="d",
            domain="t",
            owner=Owner(team="t", contact="t@t.com"),
        ),
        spec=OperationSpec(
            type=OperationType.PYTHON_FILE,
            source=str(py_file),
            entrypoint="my_func",
        ),
    )
    operation._source_path = tmp_path / "op.axm"

    runner = PythonFunctionRunner()
    request = OperationRequest(operation=operation, inputs={})
    result = runner.run(request)

    assert result == {"result": "success"}


def test_python_runner_non_callable_error(mock_operation, monkeypatch):
    """Test error when entrypoint is not callable."""
    mock_module = MagicMock()
    mock_module.not_a_function = "just a string"
    monkeypatch.setattr("importlib.import_module", lambda m: mock_module)

    runner = PythonFunctionRunner()

    with pytest.raises(TypeError, match="not callable"):
        runner._resolve_entrypoint("module:not_a_function")
