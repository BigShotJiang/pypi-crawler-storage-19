from unittest.mock import MagicMock, patch

import polars as pl
import pytest

from axm.catalog.entries import DataEntry
from axm.core import Severity, ValidationError, ValidationResult
from axm_engine.io import IOManager


def test_load_validates_data_before_returning():
    """Should validate data using the entry's validator before returning it."""
    # Setup
    manager = IOManager()

    # Mock DataEntry with schema format
    # Pydantic models need explicit mocking for fields if using MagicMock(spec=...)
    mock_entry = MagicMock(spec=DataEntry)
    mock_entry.name = "test_data"
    mock_entry.data_schema = MagicMock()
    mock_entry.data_schema.format = "tabular"  # Needed by SchemaValidator
    mock_entry.validate_entry.return_value = ValidationResult(is_valid=True, errors=[])

    df = pl.DataFrame({"a": [1]})
    manager._read_data = MagicMock(return_value=df)  # type: ignore

    # Validation passes
    mock_validation_result = ValidationResult(is_valid=True, errors=[])

    with patch("axm.catalog.validation.SchemaValidator") as mock_validator_cls:
        instance = mock_validator_cls.return_value
        instance.validate.return_value = mock_validation_result

        # Call the load method
        result = manager.load(mock_entry)

        # Assertions
        assert result.equals(df)
        manager._read_data.assert_called_once_with(mock_entry)

        # Verify Validator was instantiated with entry and called with data
        mock_validator_cls.assert_called_once_with(mock_entry)
        instance.validate.assert_called_once_with(df)


def test_load_raises_on_invalid_data():
    """Should raise ValueError if validation fails."""
    manager = IOManager()

    mock_entry = MagicMock(spec=DataEntry)
    mock_entry.name = "bad_data"
    mock_entry.data_schema = MagicMock()
    mock_entry.data_schema.format = "tabular"

    # Validation fails
    # Need to pass required 'field' to ValidationError
    errors = [
        ValidationError(message="Bad data", severity=Severity.ERROR, field="some_col")
    ]
    mock_validation_result = ValidationResult(is_valid=False, errors=errors)

    # Mock SchemaValidator
    with patch("axm.catalog.validation.SchemaValidator") as mock_validator_cls:
        # Setup mock behavior
        instance = mock_validator_cls.return_value
        instance.validate.return_value = mock_validation_result

        # Mock read
        manager._read_data = MagicMock(return_value="some_data")  # type: ignore

        with pytest.raises(ValueError, match="Data validation failed"):
            manager.load(mock_entry)


def test_read_data_uses_registry():
    """Should resolve and execute operation from registry."""
    manager = IOManager()

    mock_entry = MagicMock(spec=DataEntry)
    mock_entry.data_schema = MagicMock()
    mock_entry.data_schema.format = "tabular"
    mock_entry.location = MagicMock()
    mock_entry.location.path_template = "test.csv"

    mock_op = MagicMock()
    mock_op.execute.return_value = MagicMock(success=True, data="some_data")

    with patch(
        "axm.operations.OperationRegistry.get", return_value=mock_op
    ) as mock_get:
        result = manager._read_data(mock_entry)

        assert result == "some_data"
        mock_get.assert_called_once_with("tabular.load")
        mock_op.execute.assert_called_once()


def test_save_validates_before_saving():
    """Should validate data before attempting to save."""
    manager = IOManager()

    # Use simple MagicMock to avoid Pydantic spec issues
    mock_entry = MagicMock()
    mock_entry.name = "test_entry"
    mock_entry.data_schema.format = "tabular"
    mock_entry.location.path_template = "out.csv"

    data = {"col": [1, 2]}

    with (
        patch("axm.catalog.validation.SchemaValidator") as mock_validator_cls,
        patch("axm.operations.OperationRegistry.get") as mock_get,
    ):
        # Validation OK
        mock_validator_cls.return_value.validate.return_value.is_valid = True

        # Save OK
        mock_op = MagicMock()
        mock_op.execute.return_value.success = True
        mock_get.return_value = mock_op

        manager.save(mock_entry, data)

        # Check validation
        mock_validator_cls.assert_called_once_with(mock_entry)
        mock_validator_cls.return_value.validate.assert_called_once_with(data)

        # Check save operation
        mock_get.assert_called_once_with("tabular.save")
        mock_op.execute.assert_called_once()


def test_save_raises_on_validation_failure():
    """Should raise ValueError if data to save is invalid."""
    manager = IOManager()
    mock_entry = MagicMock()
    mock_entry.name = "test_entry"

    with patch("axm.catalog.validation.SchemaValidator") as mock_validator_cls:
        mock_validator_cls.return_value.validate.return_value.is_valid = False
        mock_validator_cls.return_value.validate.return_value.errors = ["Some error"]

        with pytest.raises(ValueError, match="Output validation failed"):
            manager.save(mock_entry, "bad_data")


def test_read_data_raises_on_failure():
    """Should raise OSError if read operation fails."""
    manager = IOManager()
    mock_entry = MagicMock()
    mock_entry.name = "test_entry"
    mock_entry.data_schema.format = "tabular"
    mock_entry.location.path_template = "test.csv"

    with patch("axm.operations.OperationRegistry.get") as mock_get:
        mock_op = MagicMock()
        mock_op.execute.return_value.success = False
        mock_op.execute.return_value.error = "File not found"
        mock_get.return_value = mock_op

        with pytest.raises(OSError, match="Failed to load"):
            manager._read_data(mock_entry)


def test_save_raises_on_failure():
    """Should raise OSError if save operation fails."""
    manager = IOManager()
    mock_entry = MagicMock()
    mock_entry.name = "test_entry"
    mock_entry.data_schema.format = "tabular"
    mock_entry.location.path_template = "test.csv"

    # Mock validation pass
    with (
        patch("axm.catalog.validation.SchemaValidator") as mock_val,
        patch("axm.operations.OperationRegistry.get") as mock_get,
    ):
        mock_val.return_value.validate.return_value.is_valid = True

        # Mock save op fail
        mock_op = MagicMock()
        mock_op.execute.return_value.success = False
        mock_op.execute.return_value.error = "Permission denied"
        mock_get.return_value = mock_op

        with pytest.raises(OSError, match="Failed to save"):
            manager.save(mock_entry, "data")
