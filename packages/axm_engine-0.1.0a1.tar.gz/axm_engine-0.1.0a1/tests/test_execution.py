from unittest.mock import MagicMock, patch

import polars as pl
import pytest

from axm.catalog.entries import (
    DataBinding,
    Identity,
    OperationEntry,
    OperationSpec,
    OperationType,
    Owner,
)
from axm_engine.context import OperationRequest, RuntimeContext
from axm_engine.execution import OperationRunner
from axm_engine.io import IOManager


@pytest.fixture
def mock_catalog():
    catalog = MagicMock()
    # Mock some data entries
    input_entry = MagicMock()
    input_entry.name = "input_data"
    input_entry.data_schema.format = "tabular"

    output_entry = MagicMock()
    output_entry.name = "output_data"
    output_entry.data_schema.format = "tabular"

    catalog.get_entry.side_effect = (
        lambda name: input_entry if name == "input_data" else output_entry
    )
    return catalog


@pytest.fixture
def mock_operation():
    return OperationEntry(
        name="process_op",
        version="1.0.0",
        identity=Identity(
            display_name="Process",
            description="Process data",
            domain="test",
            owner=Owner(team="test", contact="test@test.com"),
        ),
        spec=OperationSpec(
            type=OperationType.PYTHON_PACKAGE, entrypoint="my_pkg:process"
        ),
        inputs=[DataBinding(name="df", data_ref="input_data")],
        outputs=[DataBinding(name="result", data_ref="output_data")],
    )


def test_operation_runner_integrated_flow(mock_catalog, mock_operation):
    context = RuntimeContext()
    context.set_catalog(mock_catalog)

    io_manager = MagicMock(spec=IOManager)
    input_df = pl.DataFrame({"a": [1]})
    io_manager.load.return_value = input_df

    runner = OperationRunner(context, io_manager=io_manager)

    # Mock the actual code execution
    def mock_process(df):
        return df.with_columns(b=pl.col("a") * 2)

    with patch(
        "axm_engine.runner.PythonFunctionRunner.run",
        return_value=mock_process(input_df),
    ):
        request = OperationRequest(operation=mock_operation)
        outputs = runner.run(request)

        # Verify flow
        io_manager.load.assert_called_once()
        io_manager.save.assert_called_once()

        assert "result" in outputs
        assert outputs["result"].shape == (1, 2)
        assert outputs["result"]["b"][0] == 2
