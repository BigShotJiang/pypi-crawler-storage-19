"""Tests for EnvironmentManager - uv environment caching."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from axm_engine.environment import EnvironmentManager


class TestEnvironmentManager:
    """Tests for EnvironmentManager."""

    def test_sync_workspace_calls_uv_sync(self, tmp_path: Path) -> None:
        """Test that sync_workspace calls uv sync --all-packages."""
        manager = EnvironmentManager()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)

            manager.sync_workspace(tmp_path)

            mock_run.assert_called_once()
            cmd = mock_run.call_args[0][0]
            assert "uv" in cmd[0]
            assert "sync" in cmd
            assert "--all-packages" in cmd

    def test_sync_workspace_raises_on_failure(self, tmp_path: Path) -> None:
        """Test that sync_workspace raises on uv failure."""
        manager = EnvironmentManager()

        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=1, stderr="Error: uv sync failed"
            )

            with pytest.raises(RuntimeError, match="sync failed"):
                manager.sync_workspace(tmp_path)

    def test_is_synced_returns_false_when_no_marker(self, tmp_path: Path) -> None:
        """Test is_synced returns False when no sync marker exists."""
        manager = EnvironmentManager()
        package_dir = tmp_path / "operations" / "my_op"
        package_dir.mkdir(parents=True)

        assert manager.is_synced(package_dir) is False

    def test_is_synced_returns_true_when_marker_exists(self, tmp_path: Path) -> None:
        """Test is_synced returns True when sync marker exists and is fresh."""
        manager = EnvironmentManager()
        package_dir = tmp_path / "operations" / "my_op"
        package_dir.mkdir(parents=True)

        # Create pyproject.toml and marker
        (package_dir / "pyproject.toml").write_text("[project]\nname = 'my_op'")
        (package_dir / ".axm_synced").write_text("")

        assert manager.is_synced(package_dir) is True

    def test_is_synced_returns_false_when_pyproject_newer(self, tmp_path: Path) -> None:
        """Test is_synced returns False when pyproject.toml is newer than marker."""
        import time

        manager = EnvironmentManager()
        package_dir = tmp_path / "operations" / "my_op"
        package_dir.mkdir(parents=True)

        # Create marker first
        marker = package_dir / ".axm_synced"
        marker.write_text("")

        # Wait a bit and update pyproject.toml
        time.sleep(0.01)
        (package_dir / "pyproject.toml").write_text("[project]\nname = 'my_op'")

        assert manager.is_synced(package_dir) is False

    def test_mark_synced_creates_marker(self, tmp_path: Path) -> None:
        """Test mark_synced creates the sync marker file."""
        manager = EnvironmentManager()
        package_dir = tmp_path / "operations" / "my_op"
        package_dir.mkdir(parents=True)

        manager.mark_synced(package_dir)

        assert (package_dir / ".axm_synced").exists()
