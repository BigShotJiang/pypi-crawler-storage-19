from unittest.mock import MagicMock

import pytest

from axm.catalog.entries import (
    DAG,
    Identity,
    OperationEntry,
    OperationSpec,
    OperationType,
    Owner,
    PipelineEntry,
    PipelineStep,
)
from axm_engine.context import RuntimeContext
from axm_engine.planning import ExecutionPlan, PipelinePlanner, PlanStep


@pytest.fixture
def simple_pipeline():
    return PipelineEntry(
        name="simple_p",
        version="1.0.0",
        identity=Identity(
            display_name="Simple",
            description="A simple pipeline",
            domain="core",
            owner=Owner(team="test", contact="a@a.com"),
        ),
        dag=DAG(
            steps=[
                PipelineStep(id="step2", operation="op2", dependencies=["step1"]),
                PipelineStep(id="step1", operation="op1"),
            ]
        ),
    )


def test_planner_creates_execution_plan(simple_pipeline):
    context = MagicMock(spec=RuntimeContext)

    # Mock catalog
    mock_op = OperationEntry(
        name="op1",
        version="1.0",
        identity=Identity(
            display_name="Simple",
            description="A simple pipeline",
            domain="core",
            owner=Owner(team="test", contact="a@a.com"),
        ),
        spec=OperationSpec(type=OperationType.PYTHON_PACKAGE, entrypoint="pkg:op1"),
    )
    context.catalog.__getitem__.return_value = mock_op

    planner = PipelinePlanner(context)
    plan = planner.plan(simple_pipeline)

    assert isinstance(plan, ExecutionPlan)
    assert len(plan.steps) == 2

    # Check topological order
    assert plan.steps[0].step_id == "step1"
    assert plan.steps[1].step_id == "step2"

    # Check step details
    assert isinstance(plan.steps[0], PlanStep)
    assert plan.steps[0].operation_ref.name == "op1"
