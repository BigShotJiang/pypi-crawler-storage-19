"""Initial test to verify package structure."""

import axm_engine


def test_import():
    """Verify that axm_engine can be imported."""
    assert axm_engine.__doc__ == "Execution Engine for AXM."
