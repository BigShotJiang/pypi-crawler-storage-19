"""Test pipeline dependency merging."""

from pathlib import Path

from axm_engine.deps import collect_pipeline_deps, merge_deps


class TestCollectPipelineDeps:
    """Test collecting dependencies from operations."""

    def test_collect_deps_from_single_operation(self, tmp_path: Path) -> None:
        """Collect deps from one operation with pyproject.toml."""
        # Arrange
        op_dir = tmp_path / "operations" / "clean_users"
        op_dir.mkdir(parents=True)
        (op_dir / "pyproject.toml").write_text("""
[project]
name = "clean_users"
dependencies = ["polars>=1.0.0"]
""")

        # Act
        deps = collect_pipeline_deps(tmp_path, ["clean_users"])

        # Assert
        assert "polars>=1.0.0" in deps

    def test_collect_deps_from_multiple_operations(self, tmp_path: Path) -> None:
        """Collect deps from multiple operations."""
        # Arrange
        ops = [("op_a", "polars>=1.0"), ("op_b", "numpy"), ("op_c", "pandas")]
        for name, dep in ops:
            op_dir = tmp_path / "operations" / name
            op_dir.mkdir(parents=True)
            (op_dir / "pyproject.toml").write_text(f"""
[project]
name = "{name}"
dependencies = ["{dep}"]
""")

        # Act
        deps = collect_pipeline_deps(tmp_path, ["op_a", "op_b", "op_c"])

        # Assert
        assert "polars>=1.0" in deps
        assert "numpy" in deps
        assert "pandas" in deps

    def test_collect_deps_handles_missing_pyproject(self, tmp_path: Path) -> None:
        """Operations without pyproject.toml are skipped."""
        # Arrange
        op_dir = tmp_path / "operations" / "simple_op"
        op_dir.mkdir(parents=True)
        # No pyproject.toml

        # Act
        deps = collect_pipeline_deps(tmp_path, ["simple_op"])

        # Assert
        assert deps == []


class TestMergeDeps:
    """Test merging dependencies into project pyproject.toml."""

    def test_merge_deps_adds_to_existing(self, tmp_path: Path) -> None:
        """Merge new deps into existing pyproject.toml."""
        # Arrange
        (tmp_path / "pyproject.toml").write_text("""
[project]
name = "my-project"
dependencies = ["axm"]
""")

        # Act
        merge_deps(tmp_path, ["polars>=1.0", "numpy"])

        # Assert
        content = (tmp_path / "pyproject.toml").read_text()
        assert "polars>=1.0" in content
        assert "numpy" in content
        assert "axm" in content  # Original preserved

    def test_merge_deps_deduplicates(self, tmp_path: Path) -> None:
        """Duplicate deps are not added twice."""
        # Arrange
        (tmp_path / "pyproject.toml").write_text("""
[project]
name = "my-project"
dependencies = ["polars>=1.0"]
""")

        # Act
        merge_deps(tmp_path, ["polars>=1.0", "polars>=1.0"])

        # Assert
        content = (tmp_path / "pyproject.toml").read_text()
        # Should only have one polars entry
        assert content.count("polars") == 1
