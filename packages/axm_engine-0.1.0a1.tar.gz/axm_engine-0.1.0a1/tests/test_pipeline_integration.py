from unittest.mock import MagicMock, patch

import polars as pl
import pytest

from axm.catalog.entries import (
    DAG,
    DataBinding,
    Identity,
    OperationEntry,
    OperationSpec,
    OperationType,
    Owner,
    PipelineEntry,
    PipelineStep,
)
from axm_engine.context import RuntimeContext
from axm_engine.io import IOManager
from axm_engine.orchestration import PipelineRunner


@pytest.fixture
def mock_catalog():
    catalog = MagicMock()

    # 1. Input Entry
    input_data = MagicMock()
    input_data.name = "raw_users"
    input_data.data_schema.format = "tabular"

    # 2. Intermediate Entry (Internal to pipeline)
    # Note: Intermediate data often doesn't have a catalog entry
    # if it's strictly memory-only
    # But AXM likes to have bindings.

    # 3. Output Entry
    output_data = MagicMock()
    output_data.name = "final_users"
    output_data.data_schema.format = "tabular"

    # 4. Ops
    op1 = OperationEntry(
        name="op1",
        version="1.0",
        identity=Identity(
            display_name="Op1",
            description="D",
            domain="T",
            owner=Owner(team="T", contact="C"),
        ),
        spec=OperationSpec(type=OperationType.PYTHON_PACKAGE, entrypoint="pkg:op1"),
        inputs=[DataBinding(name="df", data_ref="raw_users")],
        outputs=[DataBinding(name="out1", data_ref="intermediate")],
    )

    op2 = OperationEntry(
        name="op2",
        version="1.0",
        identity=Identity(
            display_name="Op2",
            description="D",
            domain="T",
            owner=Owner(team="T", contact="C"),
        ),
        spec=OperationSpec(type=OperationType.PYTHON_PACKAGE, entrypoint="pkg:op2"),
        inputs=[DataBinding(name="out1", data_ref="intermediate")],
        outputs=[DataBinding(name="final", data_ref="final_users")],
    )

    def get_item(name):
        # Strip namespace prefix if present
        if name.startswith("operation:"):
            name = name.split(":", 1)[1]
        mapping = {
            "raw_users": input_data,
            "intermediate": input_data,  # Reuse mock for intermediate
            "final_users": output_data,
            "op1": op1,
            "op2": op2,
        }
        if name in mapping:
            return mapping[name]
        raise KeyError(name)

    catalog.__getitem__.side_effect = get_item

    return catalog


def test_e2e_pipeline_execution(mock_catalog):
    context = RuntimeContext()
    context.set_catalog(mock_catalog)

    # Mock IO
    io_manager = MagicMock(spec=IOManager)
    initial_df = pl.DataFrame({"id": [1]})
    io_manager.load.return_value = initial_df

    runner = PipelineRunner(context, io_manager=io_manager)

    # Pipeline definition
    pipeline = PipelineEntry(
        name="p1",
        version="1.0",
        identity=Identity(
            display_name="P1",
            description="D",
            domain="T",
            owner=Owner(team="T", contact="C"),
        ),
        dag=DAG(
            steps=[
                PipelineStep(id="s1", operation="op1"),
                PipelineStep(id="s2", operation="op2", dependencies=["s1"]),
            ]
        ),
    )

    # Mock code execution for op1 and op2
    def op1_func(df):
        return {"out1": df.with_columns(step1=pl.lit(True))}

    def op2_func(out1):
        return {"final": out1.with_columns(step2=pl.lit(True))}

    # Patch PythonFunctionRunner.run to simulate calling these functions
    with patch("axm_engine.runner.PythonFunctionRunner.run") as mock_python_run:
        # First call for op1, second for op2
        mock_python_run.side_effect = [
            op1_func(initial_df),
            op2_func(op1_func(initial_df)["out1"]),
        ]

        results = runner.run(pipeline)

        # Assertions
        assert mock_python_run.call_count == 2
        assert io_manager.load.call_count == 1  # Only loaded 'raw_users'
        assert io_manager.save.call_count == 2  # Saved 'intermediate' AND 'final_users'

        assert "final" in results
        final_df = results["final"]
        assert "step1" in final_df.columns
        assert "step2" in final_df.columns
