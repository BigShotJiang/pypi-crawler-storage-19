import asyncio
import os

from timbal import Agent

os.environ.pop("ANTHROPIC_API_KEY", None)
# os.environ["TIMBAL_APP_ID"] = "172"
os.environ["TIMBAL_PROJECT_ID"] = "60"
os.environ["TIMBAL_LOG_EVENTS"] = "START,OUTPUT,DELTA"


def get_datetime():
    from datetime import datetime

    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


from timbal.tools import WebSearch

agent = Agent(
    name="test-proxies",
    model="anthropic/claude-haiku-4-5",  # type: ignore
    tools=[get_datetime, WebSearch()],  # type: ignore
    model_params={"max_tokens": 2048},  # type: ignore
)


async def main():
    # await agent(prompt="when does fcbarcelona play next?", max_tokens=1024).collect()
    # await agent(prompt="hola", max_tokens=1024).collect()
    while True:
        prompt = input("User: ")
        if prompt.strip() == "q":
            break
        await agent(prompt=prompt, max_tokens=1024).collect()


if __name__ == "__main__":
    asyncio.run(main())
