# API Reference

::: logxide
