"""
删除文件功能模块
提供安全的文件删除功能（不对外开放）
"""

import os
import json
import requests
from typing import Optional, Dict, Any

from r321cloud.utils.config import Config
from r321cloud.utils.kaomoji import KAOMOJI, print_kaomoji


class DeleteManager:
    """删除文件管理器"""
    
    def __init__(self):
        config = Config.load()
        self._auth = config.get("access_token", "")
        self._owner = config.get("owner", "ruin321")
        self._repo = config.get("repo", "r321cloud")
        self._branch = config.get("branch", "master")
        self._api_base = config.get("api_base", "https://gitee.com/api/v5")
    
    def delete_file(self, filename: str, commit_message: str = "删除文件") -> bool:
        """删除云端文件
        
        Args:
            filename: 要删除的文件名
            commit_message: 提交信息
            
        Returns:
            bool: 删除是否成功
        """
        try:
            print(f"{KAOMOJI['delete']} 正在删除文件: {filename}")
            print(f"{KAOMOJI['thinking']} 提交信息: {commit_message}")
            
            # 首先获取文件的SHA
            file_info = self._get_file_info(filename)
            if not file_info:
                print(f"{KAOMOJI['error']} 文件不存在或无法获取文件信息: {filename}")
                return False
            
            file_sha = file_info.get("sha")
            if not file_sha:
                print(f"{KAOMOJI['error']} 无法获取文件的SHA值")
                return False
            
            # 删除文件
            url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/{filename}"
            
            data = {
                "access_token": self._auth,
                "sha": file_sha,
                "message": commit_message,
                "branch": self._branch
            }
            
            response = requests.delete(url, json=data)
            
            if response.status_code == 200:
                print(f"{KAOMOJI['success']} 文件删除成功: {filename}")
                print(f"{KAOMOJI['file_deleted']} 文件已从云端移除")
                return True
            else:
                print(f"{KAOMOJI['error']} 删除文件失败: {response.status_code}")
                print(f"{KAOMOJI['info']} 响应内容: {response.text}")
                return False
                
        except Exception as e:
            print(f"{KAOMOJI['error']} 删除文件时出错: {e}")
            return False
    
    def _get_file_info(self, filename: str) -> Optional[Dict[str, Any]]:
        """获取文件信息（包括SHA值）
        
        Args:
            filename: 文件名
            
        Returns:
            Optional[Dict]: 文件信息字典，如果文件不存在则返回None
        """
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/{filename}"
        
        params = {
            "access_token": self._auth,
            "ref": self._branch
        }
        
        try:
            response = requests.get(url, params=params)
            if response.status_code == 200:
                return response.json()
            else:
                return None
        except Exception as e:
            print(f"{KAOMOJI['error']} 获取文件信息失败: {e}")
            return None
    
    def delete_split_file(self, original_filename: str, commit_message: str = "删除分流文件") -> bool:
        """删除分流文件（包括所有分块和元数据）
        
        Args:
            original_filename: 原始文件名
            commit_message: 提交信息
            
        Returns:
            bool: 删除是否成功
        """
        try:
            print(f"{KAOMOJI['delete']} 正在删除分流文件: {original_filename}")
            print(f"{KAOMOJI['info']} 这将删除所有分块文件和元数据文件")
            
            # 获取所有文件列表
            url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/"
            
            params = {
                "access_token": self._auth,
                "ref": self._branch
            }
            
            response = requests.get(url, params=params)
            if response.status_code != 200:
                print(f"{KAOMOJI['error']} 获取文件列表失败")
                return False
            
            all_files = response.json()
            if not isinstance(all_files, list):
                print(f"{KAOMOJI['error']} 获取的文件列表格式不正确")
                return False
            
            # 查找分流文件相关的文件
            files_to_delete = []
            metadata_file = None
            
            for file_info in all_files:
                if file_info.get("type") != "file":
                    continue
                
                filename = file_info.get("name", "")
                
                # 检查是否是分流文件的分块
                if filename.startswith(original_filename) and ".encrypted." in filename:
                    files_to_delete.append({
                        "name": filename,
                        "sha": file_info.get("sha")
                    })
                
                # 检查是否是元数据文件
                if filename.endswith(".split.metadata.json") and original_filename in filename:
                    metadata_file = {
                        "name": filename,
                        "sha": file_info.get("sha")
                    }
            
            if not files_to_delete and not metadata_file:
                print(f"{KAOMOJI['info']} 未找到与 '{original_filename}' 相关的分流文件")
                return False
            
            # 删除所有找到的文件
            success_count = 0
            total_count = len(files_to_delete) + (1 if metadata_file else 0)
            
            print(f"{KAOMOJI['info']} 找到 {total_count} 个相关文件需要删除")
            
            # 删除分块文件
            for file_info in files_to_delete:
                if self._delete_single_file(file_info["name"], file_info["sha"], 
                                          f"{commit_message} [分块文件]"):
                    success_count += 1
            
            # 删除元数据文件
            if metadata_file:
                if self._delete_single_file(metadata_file["name"], metadata_file["sha"],
                                          f"{commit_message} [元数据文件]"):
                    success_count += 1
            
            if success_count == total_count:
                print(f"{KAOMOJI['success']} 分流文件删除完成！")
                print(f"{KAOMOJI['file_deleted']} 成功删除 {success_count}/{total_count} 个文件")
                return True
            else:
                print(f"{KAOMOJI['warning']} 部分文件删除失败")
                print(f"{KAOMOJI['info']} 成功删除 {success_count}/{total_count} 个文件")
                return False
                
        except Exception as e:
            print(f"{KAOMOJI['error']} 删除分流文件时出错: {e}")
            return False
    
    def _delete_single_file(self, filename: str, sha: str, commit_message: str) -> bool:
        """删除单个文件
        
        Args:
            filename: 文件名
            sha: 文件的SHA值
            commit_message: 提交信息
            
        Returns:
            bool: 删除是否成功
        """
        url = f"{self._api_base}/repos/{self._owner}/{self._repo}/contents/{filename}"
        
        data = {
            "access_token": self._auth,
            "sha": sha,
            "message": commit_message,
            "branch": self._branch
        }
        
        try:
            response = requests.delete(url, json=data)
            return response.status_code == 200
        except Exception:
            return False


# 创建全局实例
_delete_manager = DeleteManager()


def ok(filename: str) -> bool:
    """删除文件的便捷函数
    
    Args:
        filename: 要删除的文件名
        
    Returns:
        bool: 删除是否成功
        
    Example:
        >>> from r321cloud import delete
        >>> delete.ok("test.txt")
    """
    return _delete_manager.delete_file(filename, "删除文件")


def delete_split_file(original_filename: str) -> bool:
    """删除分流文件的便捷函数
    
    Args:
        original_filename: 原始文件名
        
    Returns:
        bool: 删除是否成功
        
    Example:
        >>> from r321cloud import delete
        >>> delete.delete_split_file("large_file")
    """
    return _delete_manager.delete_split_file(original_filename, "删除分流文件")


def delete_with_message(filename: str, message: str) -> bool:
    """使用自定义提交信息删除文件
    
    Args:
        filename: 要删除的文件名
        message: 自定义提交信息
        
    Returns:
        bool: 删除是否成功
        
    Example:
        >>> from r321cloud import delete
        >>> delete.delete_with_message("test.txt", "清理测试文件")
    """
    return _delete_manager.delete_file(filename, message)


# 导出函数
__all__ = ['ok', 'delete_split_file', 'delete_with_message', 'DeleteManager']