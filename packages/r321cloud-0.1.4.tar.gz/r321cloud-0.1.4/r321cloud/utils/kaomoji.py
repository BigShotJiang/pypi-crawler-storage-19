"""
颜文字表情库
统一管理所有颜文字表情，保持项目风格一致
"""

KAOMOJI = {
    # 欢迎和问候
    "welcome": "ヾ(≧▽≦*)o 欢迎使用 r321cloud！",
    "bye": "ヾ(￣▽￣)Bye~ 下次见！",
    "happy": "(*^▽^*) 好耶！",
    "hello": "ヽ(^◇^*)/ 你好呀！",
    "morning": "☀️ (^o^)/ 早上好！",
    "night": "🌙 (～ o ～)~zZ 晚安~",
    
    # 操作状态
    "success": "o(*￣▽￣*)ブ 操作成功！",
    "error": "(╥﹏╥) 操作失败...",
    "loading": "(｡•̀ᴗ-)✧ 正在处理中...",
    "thinking": "(・_・?) 正在思考...",
    "waiting": "⏰ (￣ω￣;) 等待中...",
    "ready": "🎯 (ง •_•)ง 准备就绪！",
    "done": "✨ (•̀ᴗ•́)و ̑̑ 完成！",
    
    # 信息提示
    "info": "(￣▽￣) 温馨提示：",
    "warning": "⚠️ 警告：",
    "tip": "💡 提示：",
    "note": "📝 注意：",
    "reminder": "🔔 提醒：",
    "important": "❗ 重要：",
    
    # 功能相关
    "lock": "🔒 文件已加密保护",
    "unlock": "🔓 文件已解锁",
    "download": "⬇️ 下载文件中...",
    "cloud": "☁️ 云端同步中...",
    "search": "🔍 搜索中...",
    "list": "📋 文件列表：",
    "upload": "📤 上传文件中...",
    "delete": "🗑️ 删除文件中...",
    "copy": "📋 复制中...",
    "move": "📦 移动中...",
    "rename": "🏷️ 重命名中...",
    
    # 特殊表情
    "baka": "(╯°□°）╯︵ ┻━┻ You big baka!",
    "excited": "ヽ(✿ﾟ▽ﾟ)ノ 好兴奋！",
    "cute": "(*/ω＼*) 好害羞~",
    "cool": "( •̀ ω •́ )✧ 酷！",
    "sad": "(；′⌒`) 好难过...",
    "angry": "(╬▔皿▔)╯ 生气！",
    "confused": "(⊙_⊙)？ 什么情况？",
    "surprised": "Σ(っ °Д °;)っ 震惊！",
    "love": "(❤ ω ❤) 喜欢~",
    "star": "☆*: .｡. o(≧▽≦)o .｡.:*☆ 星星眼",
    "party": "🎉 (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ 派对时间！",
    "magic": "✨ (ﾉ>ω<)ﾉ :｡･:*:･ﾟ'★,｡･:*:･ﾟ'☆ 魔法！",
    "music": "🎵 ♪(^∇^*) 音乐时间~",
    "food": "🍕 (๑•́ ₃ •̀๑) 想吃...",
    "sleepy": "😴 (。-ω-)zzz 好困...",
    "shy": "😳 (/ω＼) 害羞...",
    "proud": "😎 (￣▽￣)ノ 骄傲！",
    
    # 进度相关
    "progress_start": "🚀 开始处理...",
    "progress_mid": "⏳ 处理中...",
    "progress_end": "✅ 处理完成！",
    "progress_25": "▰▱▱▱▱ 25%",
    "progress_50": "▰▰▱▱▱ 50%",
    "progress_75": "▰▰▰▱▱ 75%",
    "progress_100": "▰▰▰▰▰ 100%",
    
    # 文件操作
    "file_saved": "💾 文件已保存",
    "file_encrypted": "🔐 文件已加密",
    "file_decrypted": "🔓 文件已解密",
    "file_uploaded": "📤 文件已上传",
    "file_downloaded": "📥 文件已下载",
    "file_deleted": "🗑️ 文件已删除",
    "file_copied": "📋 文件已复制",
    "file_moved": "📦 文件已移动",
    "file_renamed": "🏷️ 文件已重命名",
    "file_created": "📄 文件已创建",
    "file_opened": "📂 文件已打开",
    "file_closed": "📁 文件已关闭",
    
    # 网络状态
    "connecting": "📡 连接中...",
    "connected": "✅ 连接成功",
    "disconnected": "❌ 连接断开",
    "uploading": "📤 上传中...",
    "downloading": "📥 下载中...",
    "syncing": "🔄 同步中...",
    
    # 开发者模式
    "dev_mode": "👨‍💻 开发者模式",
    "dev_warning": "🚧 开发中功能",
    "dev_test": "🧪 测试中...",
    "debug": "🐛 调试中...",
    "bug": "🪲 发现bug！",
    "fix": "🔧 修复中...",
    "feature": "✨ 新功能！",
    
    # 安全相关
    "secure": "🔐 安全模式",
    "insecure": "⚠️ 不安全",
    "verified": "✅ 已验证",
    "unverified": "❌ 未验证",
    "encrypted": "🔒 已加密",
    "decrypted": "🔓 已解密",
    
    # 天气和心情
    "sunny": "☀️ (^o^)/ 晴天！",
    "rainy": "🌧️ (；´д｀)ゞ 下雨了...",
    "cloudy": "☁️ (´･_･`) 多云...",
    "snowy": "❄️ (´▽｀) 下雪啦！",
    "windy": "🌬️ (￣▽￣*)ゞ 起风了~",
    
    # 动物表情
    "cat": "🐱 (=^･ω･^=) 喵~",
    "dog": "🐶 (◕ᴥ◕) 汪！",
    "fox": "🦊 (｡･ω･｡) 狐狸~",
    "bear": "🐻 (•ө•)♡ 熊~",
    "rabbit": "🐰 (⁄ ⁄•⁄ω⁄•⁄ ⁄) 兔子~",
    "panda": "🐼 (●'◡'●) 熊猫~",
    "bird": "🐦 (•‿•) 小鸟~",
    "fish": "🐟 (๑•̀ㅂ•́)و✧ 鱼~",
    
    # 节日和庆祝
    "birthday": "🎂 (ﾉ◕ヮ◕)ﾉ*:･ﾟ✧ 生日快乐！",
    "christmas": "🎄 (´▽｀)ノ♪ 圣诞快乐！",
    "newyear": "🎊 (ﾉ>ω<)ﾉ :｡･:*:･ﾟ'★,｡･:*:･ﾟ'☆ 新年快乐！",
    "valentine": "💝 (｡♥‿♥｡) 情人节快乐！",
    "halloween": "🎃 (◕‿◕✿) 万圣节快乐！",
}


def get_kaomoji(key: str, default: str = "") -> str:
    """获取颜文字表情，如果不存在则返回默认值"""
    return KAOMOJI.get(key, default)


def print_kaomoji(key: str, message: str = "") -> None:
    """打印颜文字表情和消息"""
    kaomoji = get_kaomoji(key, "")
    if kaomoji and message:
        print(f"{kaomoji} {message}")
    elif kaomoji:
        print(kaomoji)
    elif message:
        print(message)


def format_with_kaomoji(key: str, message: str) -> str:
    """格式化消息和颜文字"""
    kaomoji = get_kaomoji(key, "")
    if kaomoji:
        return f"{kaomoji} {message}"
    return message