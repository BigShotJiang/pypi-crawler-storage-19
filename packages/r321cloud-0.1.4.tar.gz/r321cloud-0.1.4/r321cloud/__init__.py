"""
r321cloud - 文件加密云存储库
"""

__version__ = "0.1.0"
__author__ = "ruin321"

# 导出delete模块
from .delete import ok, delete_split_file, delete_with_message, DeleteManager

__all__ = [
    'ok',
    'delete_split_file', 
    'delete_with_message',
    'DeleteManager'
]