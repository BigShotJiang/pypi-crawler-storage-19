from setuptools import setup

# Version mirrors BFEE2 but this is a separate alias package
setup(version="3.0.1")
