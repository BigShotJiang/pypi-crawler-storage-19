"""dbt project generation utilities."""
