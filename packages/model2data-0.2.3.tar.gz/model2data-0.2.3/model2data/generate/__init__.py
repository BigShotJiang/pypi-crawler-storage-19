"""Data generation utilities."""
