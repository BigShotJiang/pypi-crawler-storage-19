import { u as useNodeStore } from "./PopOver-b22f049e.js";
import { d as defineComponent, r as ref, C as onMounted, X as nextTick, k as onUnmounted, o as openBlock, c as createElementBlock, m as createVNode, p as withCtx, q as createTextVNode, f as createCommentVNode, i as _export_sfc } from "./index-fb6493ae.js";
import { G as GenericNodeSettings } from "./genericNodeSettings-99014e1d.js";
import "./DesignerView-e6f5c0e8.js";
import "./index-3ba44389.js";
import "./vue-codemirror.esm-0965f39f.js";
const _hoisted_1 = {
  key: 0,
  class: "listbox-wrapper"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Union",
  setup(__props, { expose: __expose }) {
    const nodeStore = useNodeStore();
    const showContextMenu = ref(false);
    const dataLoaded = ref(false);
    const nodeData = ref(null);
    const unionInput = ref({ mode: "relaxed" });
    const nodeUnion = ref(null);
    const loadNodeData = async (nodeId) => {
      var _a;
      console.log("loadNodeData from union ");
      nodeData.value = await nodeStore.getNodeData(nodeId, false);
      nodeUnion.value = (_a = nodeData.value) == null ? void 0 : _a.setting_input;
      if (nodeData.value) {
        if (nodeUnion.value) {
          if (nodeUnion.value.union_input) {
            unionInput.value = nodeUnion.value.union_input;
          } else {
            nodeUnion.value.union_input = unionInput.value;
          }
        }
      }
      dataLoaded.value = true;
      console.log("loadNodeData from groupby");
    };
    const handleClickOutside = (event) => {
      const targetEvent = event.target;
      if (targetEvent.id === "pivot-context-menu")
        return;
      showContextMenu.value = false;
    };
    const pushNodeData = async () => {
      if (unionInput.value) {
        nodeStore.updateSettings(nodeUnion);
      }
    };
    __expose({
      loadNodeData,
      pushNodeData
    });
    onMounted(async () => {
      await nextTick();
      window.addEventListener("click", handleClickOutside);
    });
    onUnmounted(() => {
      window.removeEventListener("click", handleClickOutside);
    });
    return (_ctx, _cache) => {
      return dataLoaded.value && nodeUnion.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(GenericNodeSettings, {
          modelValue: nodeUnion.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => nodeUnion.value = $event)
        }, {
          default: withCtx(() => _cache[1] || (_cache[1] = [
            createTextVNode(" 'Union multiple tables into one table, this node does not have settings' ")
          ])),
          _: 1,
          __: [1]
        }, 8, ["modelValue"])
      ])) : createCommentVNode("", true);
    };
  }
});
const Union_vue_vue_type_style_index_0_scoped_424387d2_lang = "";
const Union = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-424387d2"]]);
export {
  Union as default
};
