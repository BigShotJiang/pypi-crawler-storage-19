import { d as defineComponent, r as ref, B as watch, o as openBlock, c as createElementBlock, i as _export_sfc } from "./index-fb6493ae.js";
const _hoisted_1 = { class: "parquet-table-settings" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "outputParquet",
  props: {
    modelValue: {
      type: Object,
      required: true
    }
  },
  emits: ["update:modelValue"],
  setup(__props) {
    const props = __props;
    const localParquetTable = ref(props.modelValue);
    watch(
      () => props.modelValue,
      (newVal) => {
        localParquetTable.value = newVal;
      },
      { deep: true }
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1);
    };
  }
});
const outputParquet_vue_vue_type_style_index_0_scoped_13145634_lang = "";
const ParquetTableConfig = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-13145634"]]);
export {
  ParquetTableConfig as default
};
