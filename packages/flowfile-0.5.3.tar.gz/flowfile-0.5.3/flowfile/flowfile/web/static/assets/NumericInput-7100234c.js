import { _ as _sfc_main } from "./NumericInput.vue_vue_type_script_setup_true_lang-5130219f.js";
import "./index-fb6493ae.js";
export {
  _sfc_main as default
};
