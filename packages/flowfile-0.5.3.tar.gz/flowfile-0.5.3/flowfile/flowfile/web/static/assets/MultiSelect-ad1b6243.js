import { _ as _sfc_main } from "./MultiSelect.vue_vue_type_script_setup_true_lang-e278950d.js";
import "./index-fb6493ae.js";
export {
  _sfc_main as default
};
