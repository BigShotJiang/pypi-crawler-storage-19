import { _ as _sfc_main } from "./TextInput.vue_vue_type_script_setup_true_lang-abad1ca2.js";
import "./index-fb6493ae.js";
export {
  _sfc_main as default
};
