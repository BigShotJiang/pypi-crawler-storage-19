import { P as PopOver } from "./PopOver-b22f049e.js";
import { d as defineComponent, o as openBlock, x as createBlock, p as withCtx, b as createBaseVNode, t as toDisplayString, i as _export_sfc } from "./index-fb6493ae.js";
const _hoisted_1 = { class: "icon-wrapper" };
const _hoisted_2 = { class: "unavailable-icon" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "UnavailableFields",
  props: {
    iconText: {
      type: String,
      default: "!"
      // Default to '!' if no input is provided
    },
    tooltipText: {
      type: String,
      default: "Field not available"
      // Default tooltip text
    }
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(PopOver, { content: __props.tooltipText }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createBaseVNode("span", _hoisted_2, toDisplayString(__props.iconText), 1)
          ])
        ]),
        _: 1
      }, 8, ["content"]);
    };
  }
});
const UnavailableFields_vue_vue_type_style_index_0_scoped_fa8da205_lang = "";
const unavailableField = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-fa8da205"]]);
export {
  unavailableField as u
};
