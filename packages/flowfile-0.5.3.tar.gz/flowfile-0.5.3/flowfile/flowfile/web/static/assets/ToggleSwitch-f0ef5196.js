import { _ as _sfc_main } from "./ToggleSwitch.vue_vue_type_script_setup_true_lang-5605c793.js";
import "./index-fb6493ae.js";
export {
  _sfc_main as default
};
