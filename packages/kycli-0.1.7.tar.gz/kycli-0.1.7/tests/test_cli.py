import pytest
import os
import sys
from unittest.mock import patch, MagicMock
from kycli.cli import main



def test_cli_save_new(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "user", "balu"]):
        main()
    captured = capsys.readouterr()
    assert "Saved: user (New)" in captured.out

def test_cli_save_overwrite(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "user", "balu"]):
        main()
    capsys.readouterr()
    with patch("sys.argv", ["kys", "user", "new_balu"]):
        with patch("builtins.input", return_value="y"):
            main()
    assert "Updated: user" in capsys.readouterr().out

def test_cli_get(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "color", "blue"]):
        main()
    capsys.readouterr()
    with patch("sys.argv", ["kyg", "color"]):
        main()
    assert "blue" in capsys.readouterr().out.strip()

def test_cli_delete_and_restore(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "temp", "val"]):
        main()
    capsys.readouterr()
    with patch("sys.argv", ["kyd", "temp"]):
        with patch("builtins.input", return_value="temp"):
            main()
    assert "Deleted and moved to archive" in capsys.readouterr().out
    with patch("sys.argv", ["kyr", "temp"]):
        main()
    assert "Restored: temp" in capsys.readouterr().out

def test_cli_delete_cancel(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "secure", "locked"]):
        main()
    capsys.readouterr()
    with patch("sys.argv", ["kyd", "secure"]):
        with patch("builtins.input", return_value="wrong"):
            main()
    assert "Confirmation failed" in capsys.readouterr().out

def test_cli_list(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "k1", "v1"]): main()
    with patch("sys.argv", ["kyl"]): main()
    assert "k1" in capsys.readouterr().out

def test_cli_export_import(clean_home_db, tmp_path, capsys):
    export_file = str(tmp_path / "backup.json")
    with patch("sys.argv", ["kys", "exp", "val"]): main()
    capsys.readouterr()
    with patch("sys.argv", ["kye", export_file, "json"]): main()
    assert "Exported data" in capsys.readouterr().out
    other_home = tmp_path / "other"
    other_home.mkdir()
    with patch.dict(os.environ, {"HOME": str(other_home)}):
        with patch("sys.argv", ["kyi", export_file]): main()
        assert "Imported data" in capsys.readouterr().out

def test_cli_json_fail_remains_string(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "bad_json", '{"key": "unclosed_quote}']): main()
    capsys.readouterr()
    with patch("sys.argv", ["kyg", "bad_json"]): main()
    assert '{"key": "unclosed_quote}' in capsys.readouterr().out

def test_cli_save_no_change(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "k", "v"]): main()
    capsys.readouterr()
    with patch("kycli.cli.Kycore") as mock_core:
        mock_core.return_value.__enter__.return_value.getkey.return_value = "v"
        mock_core.return_value.__enter__.return_value.save.return_value = "nochange"
        with patch("sys.argv", ["kys", "k", "v"]): main()
    assert "➖ No change: k" in capsys.readouterr().out

def test_cli_kyv_specific_key(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "log", "entry1"]): main()
    capsys.readouterr()
    with patch("sys.argv", ["kyv", "log"]): main()
    assert "entry1" in capsys.readouterr().out

def test_cli_kyf_no_match(clean_home_db, capsys):
    with patch("sys.argv", ["kyf", "nothing_like_this"]): main()
    assert "No matches found" in capsys.readouterr().out

def test_cli_kyf_usage(clean_home_db, capsys):
    with patch("sys.argv", ["kyf"]): main()
    assert "Usage: kyf" in capsys.readouterr().out

def test_cli_import_error(clean_home_db, capsys):
    with patch("sys.argv", ["kyi", "ghost.csv"]): main()
    assert "Error: File not found" in capsys.readouterr().out

def test_cli_usage_errors(clean_home_db, capsys):
    cmds = [["kys", "one"], ["kyg"], ["kyd"], ["kyr"], ["kye"], ["kyi"]]
    for cmd in cmds:
        with patch("sys.argv", cmd): main()
        assert f"Usage: {cmd[0]}" in capsys.readouterr().out

def test_cli_list_no_keys(clean_home_db, capsys):
    with patch("sys.argv", ["kyl"]): main()
    assert "No keys found" in capsys.readouterr().out

def test_cli_full_history(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "a", "1"]): main()
    with patch("sys.argv", ["kyv", "-h"]): main()
    assert "Full Audit History" in capsys.readouterr().out

def test_cli_history_empty(clean_home_db, capsys):
    with patch("sys.argv", ["kyv", "missing"]): main()
    assert "No history found" in capsys.readouterr().out

def test_cli_unexpected_error(clean_home_db, capsys):
    with patch("kycli.cli.Kycore", side_effect=Exception("BOOM")):
        with pytest.raises(SystemExit): main()
    assert "Unexpected Error: BOOM" in capsys.readouterr().out

def test_cli_invalid_command_fallback(clean_home_db, capsys):
    with patch("sys.argv", ["unknown_cmd"]): main()
    assert "Invalid command" in capsys.readouterr().out

def test_cli_save_identical(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "same", "val"]): main()
    capsys.readouterr()
    with patch("sys.argv", ["kys", "same", "val"]): main()
    assert "Value is identical" in capsys.readouterr().out

def test_cli_save_aborted(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "abort", "v1"]): main()
    capsys.readouterr()
    with patch("sys.argv", ["kys", "abort", "v2"]):
        with patch("builtins.input", return_value="n"): main()
    assert "Aborted" in capsys.readouterr().out

def test_cli_search(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "doc", "hello world"]): main()
    capsys.readouterr()
    with patch("sys.argv", ["kyf", "hello"]): main()
    assert "doc" in capsys.readouterr().out

def test_cli_json_save_and_get(clean_home_db, capsys):
    with patch("sys.argv", ["kys", "user", '{"name": "balu"}']): main()
    capsys.readouterr()
    with patch("sys.argv", ["kyg", "user"]): main()
    assert '"name": "balu"' in capsys.readouterr().out

def test_cli_help(clean_home_db, capsys):
    with patch("sys.argv", ["kyh"]): main()
    assert "Available commands" in capsys.readouterr().out

def test_cli_validation_v_error(clean_home_db, capsys):
    with patch("sys.argv", ["kys", " ", "val"]): main()
    assert "Validation Error" in capsys.readouterr().out

def test_cli_kyv_no_history(clean_home_db, capsys):
    with patch("sys.argv", ["kyv", "non_existent"]):
        main()
    assert "No history found" in capsys.readouterr().out

def test_cli_execute_command(clean_home_db):
    from kycli.cli import main
    # Save a command
    with patch("sys.argv", ["kys", "hi", "echo hello"]):
        main()
    
    # Execute it
    with patch("sys.argv", ["kyc", "hi"]):
        with patch("subprocess.run") as mock_run:
            main()
            mock_run.assert_called()
            # The command should be 'echo hello'
            args, kwargs = mock_run.call_args
            assert args[0] == "echo hello"

def test_cli_execute_dynamic(clean_home_db):
    from kycli.cli import main
    with patch("sys.argv", ["kys", "list", "ls"]):
        main()
    
    with patch("sys.argv", ["kyc", "list", "-la"]):
        with patch("subprocess.run") as mock_run:
            main()
            args, kwargs = mock_run.call_args
            assert args[0] == "ls -la"

def test_cli_execute_error(clean_home_db):
    from kycli.cli import main
    with patch("sys.argv", ["kys", "bad", "exit 1"]):
        main()
    
    with patch("sys.argv", ["kyc", "bad"]):
        import subprocess
        with patch("subprocess.run", side_effect=subprocess.CalledProcessError(1, "exit 1")) as mock_run:
            main() # Should catch CalledProcessError
        
        with patch("subprocess.run", side_effect=RuntimeError("fail")) as mock_run:
            main() # Should catch Exception

def test_cli_help_default(clean_home_db):
    from kycli.cli import main
    # Run with empty args and prog name kycli to hit line 40
    with patch("sys.argv", ["kycli"]):
        with patch("kycli.cli.print_help") as mock_help:
            main()
            mock_help.assert_called()


def test_cli_execute_usage_errors(clean_home_db):
    from kycli.cli import main
    # Hit line 178-179
    with patch("sys.argv", ["kyc"]):
        main()
    
    # Hit line 183-184
    with patch("sys.argv", ["kyc", "nonexistent"]):
        main()

def test_cli_restore_to(clean_home_db, capsys):
    from kycli.cli import main
    import time
    from datetime import datetime, timezone
    # Use different keys to avoid confirmation prompt during setup
    with patch("sys.argv", ["kys", "pre_k1", "v1"]): main()
    time.sleep(1.1)
    t1 = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    time.sleep(1.1)
    with patch("sys.argv", ["kys", "post_k1", "v2"]): main()
    capsys.readouterr()
    
    with patch("sys.argv", ["kyrt", t1]): main()
    assert "Database restored" in capsys.readouterr().out

def test_cli_compact(clean_home_db, capsys):
    from kycli.cli import main
    with patch("sys.argv", ["kyco", "0"]): main()
    assert "Compaction complete" in capsys.readouterr().out

def test_cli_restore_to_usage(clean_home_db, capsys):
    from kycli.cli import main
    with patch("sys.argv", ["kyrt"]): 
        main()
    assert "Usage: kyrt" in capsys.readouterr().out

