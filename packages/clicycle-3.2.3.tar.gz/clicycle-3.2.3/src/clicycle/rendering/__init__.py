"""Rendering module for clicycle."""
