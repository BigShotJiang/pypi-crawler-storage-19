"""Tests for evaluation utilities."""
