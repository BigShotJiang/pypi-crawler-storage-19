"""Tests for PDF normalizer."""

import tempfile
from pathlib import Path

import pytest

# Check if PDF support is available
try:
    import fitz
    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

pytestmark = pytest.mark.skipif(not HAS_PYMUPDF, reason="pymupdf not installed")


@pytest.fixture
def simple_pdf(tmp_path: Path) -> Path:
    """Create a simple PDF for testing."""
    pdf_path = tmp_path / "test.pdf"

    doc = fitz.open()

    # Add first page
    page1 = doc.new_page(width=612, height=792)
    page1.insert_text((72, 72), "Page 1: Introduction", fontsize=16)
    page1.insert_text((72, 100), "This is the first page of the document.")
    page1.insert_text((72, 120), "It contains some introductory text.")

    # Add second page
    page2 = doc.new_page(width=612, height=792)
    page2.insert_text((72, 72), "Page 2: Content", fontsize=16)
    page2.insert_text((72, 100), "This is the second page with more content.")
    page2.insert_text((72, 120), "Configuration settings:")
    page2.insert_text((72, 140), "timeout: 30")
    page2.insert_text((72, 160), "debug: true")

    # Set metadata
    doc.set_metadata({
        "title": "Test Document",
        "author": "Test Author",
        "subject": "Testing",
    })

    doc.save(pdf_path)
    doc.close()

    return pdf_path


@pytest.fixture
def pdf_with_toc(tmp_path: Path) -> Path:
    """Create a PDF with table of contents."""
    pdf_path = tmp_path / "toc.pdf"

    doc = fitz.open()

    # Add pages
    for i in range(3):
        page = doc.new_page()
        page.insert_text((72, 72), f"Chapter {i + 1}", fontsize=18)
        page.insert_text((72, 100), f"Content for chapter {i + 1}")

    # Add table of contents
    toc = [
        [1, "Chapter 1", 1],
        [1, "Chapter 2", 2],
        [1, "Chapter 3", 3],
    ]
    doc.set_toc(toc)

    doc.save(pdf_path)
    doc.close()

    return pdf_path


@pytest.fixture
def empty_pdf(tmp_path: Path) -> Path:
    """Create an empty PDF (no text content)."""
    pdf_path = tmp_path / "empty.pdf"

    doc = fitz.open()
    doc.new_page()  # Add empty page
    doc.save(pdf_path)
    doc.close()

    return pdf_path


class TestPDFNormalizer:
    """Tests for PDFNormalizer class."""

    def test_normalize_simple_pdf(self, simple_pdf: Path):
        """Test normalizing a simple PDF."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()
        result = normalizer.normalize(str(simple_pdf))

        assert result.type == "pdf"
        assert result.metadata["page_count"] == 2
        assert result.metadata["title"] == "Test Document"
        assert result.metadata["author"] == "Test Author"
        assert result.metadata["word_count"] > 0

    def test_normalize_extracts_text(self, simple_pdf: Path):
        """Test that text is extracted from pages."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()
        result = normalizer.normalize(str(simple_pdf))

        # Check page entities exist
        page_entities = [e for e in result.entities if e.name.startswith("page_")]
        assert len(page_entities) == 2

        # Check text content
        page1 = next(e for e in result.entities if e.name == "page_1")
        assert "Introduction" in page1.value["text"]

        page2 = next(e for e in result.entities if e.name == "page_2")
        assert "timeout" in page2.value["text"]

    def test_normalize_with_toc(self, pdf_with_toc: Path):
        """Test normalizing PDF with table of contents."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()
        result = normalizer.normalize(str(pdf_with_toc))

        assert result.metadata["has_toc"] is True

        # Find toc entity
        toc_entity = next((e for e in result.entities if e.name == "toc"), None)
        assert toc_entity is not None

        toc_entries = toc_entity.value["entries"]
        assert len(toc_entries) == 3
        assert toc_entries[0]["title"] == "Chapter 1"

    def test_normalize_empty_pdf(self, empty_pdf: Path):
        """Test normalizing empty PDF."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()
        result = normalizer.normalize(str(empty_pdf))

        assert result.type == "pdf"
        assert result.metadata["page_count"] == 1
        assert result.metadata["word_count"] == 0
        assert result.structure["has_text"] is False

    def test_can_handle_pdf_by_extension(self, tmp_path: Path):
        """Test can_handle with .pdf extension."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()
        pdf_path = tmp_path / "test.pdf"
        pdf_path.touch()  # Create empty file

        assert normalizer.can_handle(str(pdf_path)) is True
        assert normalizer.can_handle(str(pdf_path), "pdf") is True

    def test_can_handle_pdf_by_content(self, simple_pdf: Path):
        """Test can_handle detects PDF by magic bytes."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()

        # Rename to remove extension
        no_ext = simple_pdf.parent / "noext"
        simple_pdf.rename(no_ext)

        assert normalizer.can_handle(str(no_ext)) is True

    def test_can_handle_non_pdf(self, tmp_path: Path):
        """Test can_handle returns False for non-PDF."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()

        json_file = tmp_path / "test.json"
        json_file.write_text('{"key": "value"}')

        assert normalizer.can_handle(str(json_file)) is False

    def test_normalize_nonexistent_file(self, tmp_path: Path):
        """Test normalizing nonexistent file raises error."""
        from what_changed.normalize.pdf import PDFNormalizer
        from what_changed.normalize.base import NormalizationError

        normalizer = PDFNormalizer()

        with pytest.raises(NormalizationError, match="not found"):
            normalizer.normalize(str(tmp_path / "nonexistent.pdf"))

    def test_supported_types(self):
        """Test supported_types property."""
        from what_changed.normalize.pdf import PDFNormalizer

        normalizer = PDFNormalizer()
        assert "pdf" in normalizer.supported_types


class TestPDFTypeDetection:
    """Tests for PDF type detection."""

    def test_detect_pdf_by_extension(self, simple_pdf: Path):
        """Test detecting PDF by extension."""
        from what_changed.detect import TypeDetector, SourceType

        detector = TypeDetector()
        result = detector.detect(str(simple_pdf))

        assert result.source_type == SourceType.PDF
        assert result.confidence >= 0.9

    def test_detect_pdf_by_content(self, simple_pdf: Path):
        """Test detecting PDF by content."""
        from what_changed.detect import TypeDetector, SourceType

        # Rename to remove extension
        no_ext = simple_pdf.parent / "noext_detect"
        simple_pdf.rename(no_ext)

        detector = TypeDetector()
        result = detector.detect(str(no_ext))

        assert result.source_type == SourceType.PDF


class TestPDFComparison:
    """Tests for comparing PDF files."""

    def test_compare_pdfs_with_text_changes(self, tmp_path: Path):
        """Test comparing PDFs with text changes."""
        from what_changed.normalize.pdf import PDFNormalizer
        from what_changed.diff import SemanticDiff

        # Create first PDF
        pdf_a = tmp_path / "a.pdf"
        doc_a = fitz.open()
        page_a = doc_a.new_page()
        page_a.insert_text((72, 72), "Version 1.0")
        page_a.insert_text((72, 100), "Original content")
        doc_a.save(pdf_a)
        doc_a.close()

        # Create second PDF with changes
        pdf_b = tmp_path / "b.pdf"
        doc_b = fitz.open()
        page_b = doc_b.new_page()
        page_b.insert_text((72, 72), "Version 2.0")
        page_b.insert_text((72, 100), "Modified content")
        doc_b.save(pdf_b)
        doc_b.close()

        # Normalize and compare
        normalizer = PDFNormalizer()
        obj_a = normalizer.normalize(str(pdf_a))
        obj_b = normalizer.normalize(str(pdf_b))

        differ = SemanticDiff()
        result = differ.diff(obj_a, obj_b)

        # Should detect changes
        assert result.total_changes > 0

    def test_compare_pdfs_page_count_change(self, tmp_path: Path):
        """Test comparing PDFs with different page counts."""
        from what_changed.normalize.pdf import PDFNormalizer
        from what_changed.diff import SemanticDiff

        # Create first PDF with 1 page
        pdf_a = tmp_path / "a.pdf"
        doc_a = fitz.open()
        doc_a.new_page()
        doc_a.save(pdf_a)
        doc_a.close()

        # Create second PDF with 2 pages
        pdf_b = tmp_path / "b.pdf"
        doc_b = fitz.open()
        doc_b.new_page()
        doc_b.new_page()
        doc_b.save(pdf_b)
        doc_b.close()

        # Normalize and compare
        normalizer = PDFNormalizer()
        obj_a = normalizer.normalize(str(pdf_a))
        obj_b = normalizer.normalize(str(pdf_b))

        differ = SemanticDiff()
        result = differ.diff(obj_a, obj_b)

        # Should detect page addition
        assert result.added_count > 0 or result.modified_count > 0


class TestPDFIntegration:
    """Integration tests for PDF support."""

    def test_registry_includes_pdf_normalizer(self):
        """Test that registry includes PDF normalizer when available."""
        from what_changed.normalize import create_default_registry

        registry = create_default_registry()

        assert "pdf" in registry.registered_types

    def test_end_to_end_pdf_comparison(self, tmp_path: Path):
        """Test full pipeline with PDF files."""
        from what_changed.normalize import create_default_registry
        from what_changed.diff import SemanticDiff
        from what_changed.graph import GraphBuilder
        from what_changed.rules import create_default_engine
        from what_changed.explain import Explainer

        # Create two PDFs
        pdf_a = tmp_path / "old.pdf"
        doc_a = fitz.open()
        page_a = doc_a.new_page()
        page_a.insert_text((72, 72), "Configuration")
        page_a.insert_text((72, 100), "timeout: 30")
        doc_a.set_metadata({"title": "Config v1"})
        doc_a.save(pdf_a)
        doc_a.close()

        pdf_b = tmp_path / "new.pdf"
        doc_b = fitz.open()
        page_b = doc_b.new_page()
        page_b.insert_text((72, 72), "Configuration")
        page_b.insert_text((72, 100), "timeout: 10")
        doc_b.set_metadata({"title": "Config v2"})
        doc_b.save(pdf_b)
        doc_b.close()

        # Run full pipeline
        registry = create_default_registry()
        obj_a = registry.normalize(str(pdf_a))
        obj_b = registry.normalize(str(pdf_b))

        differ = SemanticDiff()
        diff_result = differ.diff(obj_a, obj_b)

        builder = GraphBuilder()
        graph = builder.build(diff_result)

        engine = create_default_engine()
        rule_results = engine.apply(graph)

        explainer = Explainer()
        explanations = explainer.explain_graph(graph, rule_results)

        # Should produce some output
        assert diff_result.total_changes > 0
