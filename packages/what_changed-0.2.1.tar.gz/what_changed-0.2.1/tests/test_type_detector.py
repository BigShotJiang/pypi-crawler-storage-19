"""Tests for type detection."""

from pathlib import Path

import pytest

from what_changed.detect.type_detector import TypeDetector, SourceType, DetectionResult


class TestTypeDetector:
    """Tests for the TypeDetector class."""

    @pytest.fixture
    def detector(self) -> TypeDetector:
        """Create a TypeDetector instance."""
        return TypeDetector()

    # === URL Detection ===

    def test_detect_http_url(self, detector: TypeDetector):
        """Test detection of HTTP URLs."""
        result = detector.detect("http://example.com/api")
        assert result.source_type == SourceType.URL
        assert result.url == "http://example.com/api"
        assert result.confidence == 1.0

    def test_detect_https_url(self, detector: TypeDetector):
        """Test detection of HTTPS URLs."""
        result = detector.detect("https://api.example.com/v1/users")
        assert result.source_type == SourceType.URL
        assert result.confidence == 1.0

    def test_detect_localhost_url(self, detector: TypeDetector):
        """Test detection of localhost URLs."""
        result = detector.detect("http://localhost:8080/api")
        assert result.source_type == SourceType.URL

    def test_detect_ip_url(self, detector: TypeDetector):
        """Test detection of IP-based URLs."""
        result = detector.detect("http://192.168.1.1:3000/")
        assert result.source_type == SourceType.URL

    # === File Extension Detection ===

    def test_detect_json_by_extension(self, detector: TypeDetector, json_file_a: Path):
        """Test detection of JSON files by extension."""
        result = detector.detect(str(json_file_a))
        assert result.source_type == SourceType.JSON
        assert result.confidence >= 0.9

    def test_detect_yaml_by_extension(self, detector: TypeDetector, yaml_file: Path):
        """Test detection of YAML files by extension."""
        result = detector.detect(str(yaml_file))
        assert result.source_type == SourceType.YAML
        assert result.confidence >= 0.9

    def test_detect_env_by_name(self, detector: TypeDetector, env_file_a: Path):
        """Test detection of .env files by name pattern."""
        result = detector.detect(str(env_file_a))
        assert result.source_type == SourceType.ENV

    def test_detect_text_by_extension(self, detector: TypeDetector, text_file_a: Path):
        """Test detection of text files by extension."""
        result = detector.detect(str(text_file_a))
        assert result.source_type == SourceType.TEXT

    # === Directory Detection ===

    def test_detect_directory(self, detector: TypeDetector, dir_a: Path):
        """Test detection of directories."""
        result = detector.detect(str(dir_a))
        assert result.source_type == SourceType.DIRECTORY
        assert result.confidence == 1.0

    # === Non-existent Files ===

    def test_detect_nonexistent_file(self, detector: TypeDetector):
        """Test detection of non-existent files."""
        result = detector.detect("/nonexistent/path/file.json")
        assert result.source_type == SourceType.UNKNOWN
        assert result.confidence == 0.0

    # === Content-based Detection ===

    def test_detect_json_by_content(self, detector: TypeDetector, temp_dir: Path):
        """Test detection of JSON by content when no extension."""
        path = temp_dir / "noext"
        path.write_text('{"key": "value"}')
        result = detector.detect(str(path))
        assert result.source_type == SourceType.JSON

    def test_detect_env_by_content(self, detector: TypeDetector, temp_dir: Path):
        """Test detection of ENV by content when no extension."""
        path = temp_dir / "noext"
        path.write_text("DATABASE_URL=postgres://localhost\nDEBUG=true")
        result = detector.detect(str(path))
        assert result.source_type == SourceType.ENV

    # === Detection Result Properties ===

    def test_is_config_json(self, detector: TypeDetector, json_file_a: Path):
        """Test is_config property for JSON files."""
        result = detector.detect(str(json_file_a))
        assert result.is_config is True

    def test_is_config_text(self, detector: TypeDetector, text_file_a: Path):
        """Test is_config property for text files."""
        result = detector.detect(str(text_file_a))
        assert result.is_config is False

    def test_is_local_file(self, detector: TypeDetector, json_file_a: Path):
        """Test is_local property for local files."""
        result = detector.detect(str(json_file_a))
        assert result.is_local is True

    def test_is_local_url(self, detector: TypeDetector):
        """Test is_local property for URLs."""
        result = detector.detect("https://example.com")
        assert result.is_local is False


class TestSourceType:
    """Tests for SourceType enum."""

    def test_source_type_values(self):
        """Test that all expected source types exist."""
        assert SourceType.URL
        assert SourceType.DIRECTORY
        assert SourceType.JSON
        assert SourceType.YAML
        assert SourceType.ENV
        assert SourceType.TOML
        assert SourceType.INI
        assert SourceType.TEXT
        assert SourceType.BINARY
        assert SourceType.UNKNOWN


class TestDetectionResult:
    """Tests for DetectionResult dataclass."""

    def test_detection_result_creation(self):
        """Test creating a DetectionResult."""
        result = DetectionResult(
            source_type=SourceType.JSON,
            path=Path("/test/file.json"),
            url=None,
            confidence=0.95,
        )
        assert result.source_type == SourceType.JSON
        assert result.confidence == 0.95
        assert result.is_config is True
        assert result.is_local is True
