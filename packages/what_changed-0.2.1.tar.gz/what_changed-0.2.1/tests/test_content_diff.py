"""Tests for content diff functionality."""

import pytest
from what_changed.diff.content_diff import (
    ContentDiffer,
    ContentDiff,
    Hunk,
    LineDiff,
    LineChangeType,
    generate_inline_diff,
    word_diff,
)


class TestContentDiffer:
    """Tests for the ContentDiffer class."""

    def test_diff_identical_text(self):
        """Identical text should produce no changes."""
        differ = ContentDiffer()
        result = differ.diff_text("hello\nworld", "hello\nworld")

        assert not result.has_changes
        assert result.lines_added == 0
        assert result.lines_removed == 0
        assert len(result.hunks) == 0

    def test_diff_added_lines(self):
        """Should detect added lines."""
        differ = ContentDiffer()
        old = "line1\nline2"
        new = "line1\nline2\nline3"

        result = differ.diff_text(old, new)

        assert result.has_changes
        assert result.lines_added >= 1  # At least one line added
        assert len(result.hunks) >= 1
        # Verify line3 is in the added lines
        added_content = [l.content for hunk in result.hunks for l in hunk.lines if l.line_type == LineChangeType.ADDED]
        assert "line3" in added_content

    def test_diff_removed_lines(self):
        """Should detect removed lines."""
        differ = ContentDiffer()
        old = "line1\nline2\nline3"
        new = "line1\nline2"

        result = differ.diff_text(old, new)

        assert result.has_changes
        assert result.lines_removed >= 1  # At least one line removed
        # Verify line3 is in the removed lines
        removed_content = [l.content for hunk in result.hunks for l in hunk.lines if l.line_type == LineChangeType.REMOVED]
        assert "line3" in removed_content

    def test_diff_modified_lines(self):
        """Should detect modified lines."""
        differ = ContentDiffer()
        old = "hello world"
        new = "hello universe"

        result = differ.diff_text(old, new)

        assert result.has_changes
        assert result.lines_added == 1
        assert result.lines_removed == 1

    def test_diff_complex_changes(self):
        """Should handle complex multi-line changes."""
        differ = ContentDiffer()
        old = """Line 1
Line 2
Line 3
Line 4
Line 5"""
        new = """Line 1
Modified Line 2
Line 3
New Line
Line 5"""

        result = differ.diff_text(old, new)

        assert result.has_changes
        # Line 2 modified, Line 4 removed, New Line added
        assert result.lines_added >= 2
        assert result.lines_removed >= 2

    def test_unified_diff_format(self):
        """Should produce valid unified diff format."""
        differ = ContentDiffer()
        old = "line1\nline2\nline3"
        new = "line1\nmodified\nline3"

        result = differ.diff_text(old, new, old_label="a/file.txt", new_label="b/file.txt")
        unified = result.to_unified_diff()

        assert "--- a/file.txt" in unified
        assert "+++ b/file.txt" in unified
        assert "-line2" in unified
        assert "+modified" in unified

    def test_context_lines(self):
        """Should include context lines around changes."""
        differ = ContentDiffer(context_lines=2)
        old = "1\n2\n3\n4\n5\n6\n7\n8\n9\n10"
        new = "1\n2\n3\nMODIFIED\n5\n6\n7\n8\n9\n10"

        result = differ.diff_text(old, new)

        assert result.has_changes
        # Should have context around the change
        for hunk in result.hunks:
            context_lines = [l for l in hunk.lines if l.line_type == LineChangeType.CONTEXT]
            assert len(context_lines) > 0


class TestHunk:
    """Tests for the Hunk class."""

    def test_header_format(self):
        """Should format hunk header correctly."""
        hunk = Hunk(old_start=1, old_count=5, new_start=1, new_count=6)
        assert hunk.header == "@@ -1,5 +1,6 @@"


class TestInlineDiff:
    """Tests for inline diff functions."""

    def test_generate_inline_diff(self):
        """Should highlight character-level changes."""
        old, new = generate_inline_diff("hello world", "hello universe")

        # The inline diff should show what was removed in old and what was added in new
        assert "[-" in old  # Something was marked as removed
        assert "[+" in new  # Something was marked as added

    def test_word_diff(self):
        """Should produce word-level diff."""
        result = word_diff("The quick brown fox", "The slow brown dog")

        assert "[-quick-]" in result
        assert "{+slow+}" in result
        assert "[-fox-]" in result
        assert "{+dog+}" in result


class TestDocumentDiffIntegration:
    """Integration tests for document diffing."""

    def test_pdf_text_extraction_diff(self):
        """Should diff extracted PDF text properly."""
        # Simulate PDF page text
        old_page = """John Doe
Senior Software Engineer
john.doe@email.com

Experience:
- 5 years at TechCorp
- Led team of 10 engineers"""

        new_page = """John Doe
Senior Staff Engineer
john.doe@email.com

Experience:
- 7 years at TechCorp
- Led team of 15 engineers"""

        differ = ContentDiffer()
        result = differ.diff_text(old_page, new_page)

        assert result.has_changes
        unified = result.to_unified_diff()

        # Should show the title change
        assert "-Senior Software Engineer" in unified
        assert "+Senior Staff Engineer" in unified

        # Should show the years/team changes (with the leading dash)
        assert "- 5 years" in unified or "-5 years" in unified or "5 years" in unified
        assert "- 7 years" in unified or "-7 years" in unified or "7 years" in unified

    def test_markdown_section_diff(self):
        """Should diff markdown sections properly."""
        old_section = """## Installation

Install using pip:

```bash
pip install mypackage
```

Then import it:

```python
import mypackage
```"""

        new_section = """## Installation

Install using pip:

```bash
pip install mypackage[extra]
```

Then import it:

```python
from mypackage import main
```"""

        differ = ContentDiffer()
        result = differ.diff_text(old_section, new_section)

        assert result.has_changes
        unified = result.to_unified_diff()

        assert "-pip install mypackage" in unified
        assert "+pip install mypackage[extra]" in unified
        assert "-import mypackage" in unified
        assert "+from mypackage import main" in unified


class TestDiffStatistics:
    """Tests for diff statistics."""

    def test_lines_changed_calculation(self):
        """Should calculate lines_changed as min of added/removed."""
        differ = ContentDiffer()

        # 2 lines modified (2 removed, 2 added)
        old = "a\nb\nc"
        new = "x\ny\nc"
        result = differ.diff_text(old, new)

        assert result.lines_changed == min(result.lines_added, result.lines_removed)

    def test_empty_diff(self):
        """Should handle empty strings."""
        differ = ContentDiffer()
        result = differ.diff_text("", "")

        assert not result.has_changes
        assert result.lines_added == 0
        assert result.lines_removed == 0

    def test_all_new_content(self):
        """Should handle completely new content."""
        differ = ContentDiffer()
        result = differ.diff_text("", "new content\nmore content")

        assert result.has_changes
        assert result.lines_added == 2
        assert result.lines_removed == 0

    def test_all_removed_content(self):
        """Should handle completely removed content."""
        differ = ContentDiffer()
        result = differ.diff_text("old content\nmore content", "")

        assert result.has_changes
        assert result.lines_added == 0
        assert result.lines_removed == 2
