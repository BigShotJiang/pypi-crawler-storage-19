"""Tests for extended normalizers (CSV, Markdown, Docker, etc.)."""

import pytest
from pathlib import Path
import tempfile
import json


class TestCSVNormalizer:
    """Tests for CSV normalizer."""

    def test_can_handle_csv(self, tmp_path):
        from what_changed.normalize.data import CSVNormalizer

        normalizer = CSVNormalizer()
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("a,b,c\n1,2,3")

        assert normalizer.can_handle(str(csv_file))
        assert normalizer.can_handle(str(csv_file), "csv")

    def test_can_handle_tsv(self, tmp_path):
        from what_changed.normalize.data import CSVNormalizer

        normalizer = CSVNormalizer()
        tsv_file = tmp_path / "data.tsv"
        tsv_file.write_text("a\tb\tc\n1\t2\t3")

        assert normalizer.can_handle(str(tsv_file))

    def test_normalize_csv(self, tmp_path):
        from what_changed.normalize.data import CSVNormalizer

        normalizer = CSVNormalizer()
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("name,age,city\nAlice,30,NYC\nBob,25,LA")

        result = normalizer.normalize(str(csv_file))

        assert result.type == "csv"
        assert result.structure["row_count"] == 2
        assert result.structure["column_count"] == 3
        assert result.structure["headers"] == ["name", "age", "city"]

    def test_normalize_empty_csv(self, tmp_path):
        from what_changed.normalize.data import CSVNormalizer

        normalizer = CSVNormalizer()
        csv_file = tmp_path / "empty.csv"
        csv_file.write_text("")

        result = normalizer.normalize(str(csv_file))
        assert result.structure["row_count"] == 0


class TestMarkdownNormalizer:
    """Tests for Markdown normalizer."""

    def test_can_handle_md(self, tmp_path):
        from what_changed.normalize.markdown import MarkdownNormalizer

        normalizer = MarkdownNormalizer()
        md_file = tmp_path / "readme.md"
        md_file.write_text("# Hello")

        assert normalizer.can_handle(str(md_file))

    def test_normalize_markdown(self, tmp_path):
        from what_changed.normalize.markdown import MarkdownNormalizer

        normalizer = MarkdownNormalizer()
        md_file = tmp_path / "doc.md"
        md_file.write_text("""# Title

Some content here.

## Section 1

More content.

### Subsection

Even more content.

## Section 2

[Link](https://example.com)

```python
print("hello")
```
""")

        result = normalizer.normalize(str(md_file))

        assert result.type == "markdown"
        assert result.metadata["link_count"] == 1
        assert result.metadata["code_block_count"] == 1
        # Check sections exist
        section_entities = [e for e in result.entities if e.entity_type.name == "SECTION"]
        assert len(section_entities) > 0


class TestDockerfileNormalizer:
    """Tests for Dockerfile normalizer."""

    def test_can_handle_dockerfile(self, tmp_path):
        from what_changed.normalize.docker import DockerfileNormalizer

        normalizer = DockerfileNormalizer()
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.11")

        assert normalizer.can_handle(str(dockerfile))

    def test_normalize_dockerfile(self, tmp_path):
        from what_changed.normalize.docker import DockerfileNormalizer

        normalizer = DockerfileNormalizer()
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("""FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

EXPOSE 8000

CMD ["python", "app.py"]
""")

        result = normalizer.normalize(str(dockerfile))

        assert result.type == "dockerfile"
        assert result.metadata["base_image"] == "python:3.11-slim"
        assert "8000" in result.metadata["exposed_ports"]

    def test_multistage_dockerfile(self, tmp_path):
        from what_changed.normalize.docker import DockerfileNormalizer

        normalizer = DockerfileNormalizer()
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("""FROM node:18 AS builder
WORKDIR /app
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
""")

        result = normalizer.normalize(str(dockerfile))

        assert result.metadata["is_multistage"]
        assert result.structure["stages"] == 2


class TestDockerComposeNormalizer:
    """Tests for docker-compose normalizer."""

    def test_can_handle_compose(self, tmp_path):
        from what_changed.normalize.docker import DockerComposeNormalizer

        normalizer = DockerComposeNormalizer()
        compose = tmp_path / "docker-compose.yml"
        compose.write_text("version: '3'")

        assert normalizer.can_handle(str(compose))

    def test_normalize_compose(self, tmp_path):
        from what_changed.normalize.docker import DockerComposeNormalizer

        normalizer = DockerComposeNormalizer()
        compose = tmp_path / "docker-compose.yml"
        compose.write_text("""version: '3.8'

services:
  web:
    image: nginx:alpine
    ports:
      - "80:80"
    depends_on:
      - api

  api:
    build: ./api
    environment:
      - DATABASE_URL=postgres://db:5432

  db:
    image: postgres:15
    volumes:
      - db_data:/var/lib/postgresql/data

volumes:
  db_data:

networks:
  backend:
""")

        result = normalizer.normalize(str(compose))

        assert result.type == "docker-compose"
        assert result.structure["service_count"] == 3
        assert result.structure["volume_count"] == 1
        assert result.structure["network_count"] == 1
        assert "web" in result.metadata["services"]


class TestPackageJsonNormalizer:
    """Tests for package.json normalizer."""

    def test_can_handle_package_json(self, tmp_path):
        from what_changed.normalize.dependencies import PackageJsonNormalizer

        normalizer = PackageJsonNormalizer()
        pkg = tmp_path / "package.json"
        pkg.write_text('{"name": "test"}')

        assert normalizer.can_handle(str(pkg))

    def test_normalize_package_json(self, tmp_path):
        from what_changed.normalize.dependencies import PackageJsonNormalizer

        normalizer = PackageJsonNormalizer()
        pkg = tmp_path / "package.json"
        pkg.write_text(json.dumps({
            "name": "my-app",
            "version": "1.0.0",
            "dependencies": {
                "express": "^4.18.0",
                "lodash": "^4.17.21"
            },
            "devDependencies": {
                "jest": "^29.0.0"
            },
            "scripts": {
                "start": "node index.js",
                "test": "jest"
            }
        }))

        result = normalizer.normalize(str(pkg))

        assert result.type == "package-json"
        assert result.structure["name"] == "my-app"
        assert result.structure["dependency_count"] == 2
        assert result.structure["dev_dependency_count"] == 1
        assert "start" in result.structure["scripts"]


class TestRequirementsTxtNormalizer:
    """Tests for requirements.txt normalizer."""

    def test_can_handle_requirements(self, tmp_path):
        from what_changed.normalize.dependencies import RequirementsTxtNormalizer

        normalizer = RequirementsTxtNormalizer()
        req = tmp_path / "requirements.txt"
        req.write_text("flask>=2.0.0")

        assert normalizer.can_handle(str(req))

    def test_normalize_requirements(self, tmp_path):
        from what_changed.normalize.dependencies import RequirementsTxtNormalizer

        normalizer = RequirementsTxtNormalizer()
        req = tmp_path / "requirements.txt"
        req.write_text("""# Dependencies
flask>=2.0.0
requests==2.28.0
numpy~=1.24.0
pandas[excel]>=1.5.0

# Dev dependencies
pytest>=7.0.0
""")

        result = normalizer.normalize(str(req))

        assert result.type == "requirements"
        assert result.structure["package_count"] == 5
        assert "flask" in result.structure["packages"]


class TestPyprojectTomlNormalizer:
    """Tests for pyproject.toml normalizer."""

    def test_can_handle_pyproject(self, tmp_path):
        from what_changed.normalize.dependencies import PyprojectTomlNormalizer

        normalizer = PyprojectTomlNormalizer()
        pyproj = tmp_path / "pyproject.toml"
        pyproj.write_text('[project]\nname = "test"')

        assert normalizer.can_handle(str(pyproj))

    def test_normalize_pyproject(self, tmp_path):
        from what_changed.normalize.dependencies import PyprojectTomlNormalizer

        normalizer = PyprojectTomlNormalizer()
        pyproj = tmp_path / "pyproject.toml"
        pyproj.write_text("""[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "my-package"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = [
    "requests>=2.28.0",
    "pydantic>=2.0.0",
]

[project.optional-dependencies]
dev = ["pytest>=7.0.0"]

[project.scripts]
my-cli = "my_package.cli:main"

[tool.ruff]
line-length = 100
""")

        result = normalizer.normalize(str(pyproj))

        assert result.type == "pyproject"
        assert result.structure["name"] == "my-package"
        assert result.structure["dependency_count"] == 2
        assert "dev" in result.structure["optional_dependency_groups"]


class TestZipNormalizer:
    """Tests for ZIP archive normalizer."""

    def test_can_handle_zip(self, tmp_path):
        from what_changed.normalize.archive import ZipNormalizer
        import zipfile

        normalizer = ZipNormalizer()
        zip_file = tmp_path / "test.zip"

        with zipfile.ZipFile(zip_file, "w") as zf:
            zf.writestr("test.txt", "hello")

        assert normalizer.can_handle(str(zip_file))

    def test_normalize_zip(self, tmp_path):
        from what_changed.normalize.archive import ZipNormalizer
        import zipfile

        normalizer = ZipNormalizer()
        zip_file = tmp_path / "archive.zip"

        with zipfile.ZipFile(zip_file, "w") as zf:
            zf.writestr("readme.md", "# Test")
            zf.writestr("src/main.py", "print('hello')")
            zf.writestr("src/utils.py", "# utils")

        result = normalizer.normalize(str(zip_file))

        assert result.type == "zip"
        assert result.structure["file_count"] == 3


class TestTarNormalizer:
    """Tests for tar archive normalizer."""

    def test_can_handle_tar(self, tmp_path):
        from what_changed.normalize.archive import TarNormalizer
        import tarfile

        normalizer = TarNormalizer()
        tar_file = tmp_path / "test.tar"

        with tarfile.open(tar_file, "w") as tf:
            info = tarfile.TarInfo(name="test.txt")
            info.size = 5
            tf.addfile(info, fileobj=__import__("io").BytesIO(b"hello"))

        assert normalizer.can_handle(str(tar_file))

    def test_normalize_tar_gz(self, tmp_path):
        from what_changed.normalize.archive import TarNormalizer
        import tarfile
        import io

        normalizer = TarNormalizer()
        tar_file = tmp_path / "archive.tar.gz"

        with tarfile.open(tar_file, "w:gz") as tf:
            for name in ["file1.txt", "file2.py"]:
                info = tarfile.TarInfo(name=name)
                content = b"content"
                info.size = len(content)
                tf.addfile(info, fileobj=io.BytesIO(content))

        result = normalizer.normalize(str(tar_file))

        assert result.type == "tar"
        assert result.structure["file_count"] == 2


class TestGoModNormalizer:
    """Tests for go.mod normalizer."""

    def test_can_handle_go_mod(self, tmp_path):
        from what_changed.normalize.dependencies import GoModNormalizer

        normalizer = GoModNormalizer()
        gomod = tmp_path / "go.mod"
        gomod.write_text("module example.com/myapp")

        assert normalizer.can_handle(str(gomod))

    def test_normalize_go_mod(self, tmp_path):
        from what_changed.normalize.dependencies import GoModNormalizer

        normalizer = GoModNormalizer()
        gomod = tmp_path / "go.mod"
        gomod.write_text("""module github.com/example/myapp

go 1.21

require (
    github.com/gin-gonic/gin v1.9.0
    github.com/spf13/cobra v1.7.0
)

replace github.com/old/pkg => github.com/new/pkg v1.0.0
""")

        result = normalizer.normalize(str(gomod))

        assert result.type == "go-mod"
        assert result.structure["module"] == "github.com/example/myapp"
        assert result.structure["go_version"] == "1.21"
        assert result.structure["require_count"] == 2


class TestCargoTomlNormalizer:
    """Tests for Cargo.toml normalizer."""

    def test_can_handle_cargo(self, tmp_path):
        from what_changed.normalize.dependencies import CargoTomlNormalizer

        normalizer = CargoTomlNormalizer()
        cargo = tmp_path / "Cargo.toml"
        cargo.write_text('[package]\nname = "test"')

        assert normalizer.can_handle(str(cargo))

    def test_normalize_cargo(self, tmp_path):
        from what_changed.normalize.dependencies import CargoTomlNormalizer

        normalizer = CargoTomlNormalizer()
        cargo = tmp_path / "Cargo.toml"
        cargo.write_text("""[package]
name = "my-crate"
version = "0.1.0"
edition = "2021"

[dependencies]
serde = { version = "1.0", features = ["derive"] }
tokio = "1.0"

[dev-dependencies]
criterion = "0.5"

[features]
default = ["std"]
std = []
""")

        result = normalizer.normalize(str(cargo))

        assert result.type == "cargo"
        assert result.structure["name"] == "my-crate"
        assert result.structure["dependency_count"] == 2


class TestGemfileNormalizer:
    """Tests for Gemfile normalizer."""

    def test_can_handle_gemfile(self, tmp_path):
        from what_changed.normalize.dependencies import GemfileNormalizer

        normalizer = GemfileNormalizer()
        gemfile = tmp_path / "Gemfile"
        gemfile.write_text('gem "rails"')

        assert normalizer.can_handle(str(gemfile))

    def test_normalize_gemfile(self, tmp_path):
        from what_changed.normalize.dependencies import GemfileNormalizer

        normalizer = GemfileNormalizer()
        gemfile = tmp_path / "Gemfile"
        gemfile.write_text("""source 'https://rubygems.org'

gem 'rails', '~> 7.0'
gem 'pg', '~> 1.4'
gem 'puma', '>= 5.0'

group :development, :test do
  gem 'rspec-rails'
  gem 'factory_bot_rails'
end
""")

        result = normalizer.normalize(str(gemfile))

        assert result.type == "gemfile"
        assert result.structure["gem_count"] >= 3


class TestDependencyRules:
    """Tests for dependency breaking change rules."""

    def test_removed_dependency_rule(self):
        from what_changed.rules.dependencies import RemovedDependencyRule
        from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
        from what_changed.diff.semantic_diff import ChangeType

        rule = RemovedDependencyRule()

        node = ChangeNode(
            id="dep_removed",
            name="lodash",
            node_type=NodeType.CONFIG_KEY,
            change_type=ChangeType.REMOVED,
            path="dependencies.devDependencies.lodash",
        )
        graph = ChangeGraph()

        result = rule.evaluate(node, graph)

        assert result.matched
        assert result.score == 5  # Dev dependency

    def test_major_version_bump_rule(self):
        from what_changed.rules.dependencies import MajorVersionBumpRule
        from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
        from what_changed.diff.semantic_diff import ChangeType

        rule = MajorVersionBumpRule()

        node = ChangeNode(
            id="version_bump",
            name="express",
            node_type=NodeType.CONFIG_KEY,
            change_type=ChangeType.MODIFIED,
            path="dependencies.express",
            metadata={"old_value": "^4.18.0", "new_value": "^5.0.0"},
        )
        graph = ChangeGraph()

        result = rule.evaluate(node, graph)

        assert result.matched
        assert result.score == 7


class TestTypeDetectorExtended:
    """Tests for extended type detection."""

    def test_detect_csv(self, tmp_path):
        from what_changed.detect import TypeDetector, SourceType

        detector = TypeDetector()
        csv_file = tmp_path / "data.csv"
        csv_file.write_text("a,b,c")

        result = detector.detect(str(csv_file))
        assert result.source_type == SourceType.CSV

    def test_detect_markdown(self, tmp_path):
        from what_changed.detect import TypeDetector, SourceType

        detector = TypeDetector()
        md_file = tmp_path / "readme.md"
        md_file.write_text("# Title")

        result = detector.detect(str(md_file))
        assert result.source_type == SourceType.MARKDOWN

    def test_detect_dockerfile(self, tmp_path):
        from what_changed.detect import TypeDetector, SourceType

        detector = TypeDetector()
        dockerfile = tmp_path / "Dockerfile"
        dockerfile.write_text("FROM python:3.11")

        result = detector.detect(str(dockerfile))
        assert result.source_type == SourceType.DOCKERFILE

    def test_detect_docker_compose(self, tmp_path):
        from what_changed.detect import TypeDetector, SourceType

        detector = TypeDetector()
        compose = tmp_path / "docker-compose.yml"
        compose.write_text("version: '3'")

        result = detector.detect(str(compose))
        assert result.source_type == SourceType.DOCKER_COMPOSE

    def test_detect_package_json(self, tmp_path):
        from what_changed.detect import TypeDetector, SourceType

        detector = TypeDetector()
        pkg = tmp_path / "package.json"
        pkg.write_text('{"name": "test"}')

        result = detector.detect(str(pkg))
        assert result.source_type == SourceType.PACKAGE_JSON

    def test_detect_sql(self, tmp_path):
        from what_changed.detect import TypeDetector, SourceType

        detector = TypeDetector()
        sql_file = tmp_path / "schema.sql"
        sql_file.write_text("CREATE TABLE users (id INT);")

        result = detector.detect(str(sql_file))
        assert result.source_type == SourceType.SQL
