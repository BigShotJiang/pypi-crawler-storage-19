"""Tests for normalizers."""

import json
from pathlib import Path

import pytest

from what_changed.normalize.base import (
    NormalizedObject,
    Entity,
    EntityType,
    NormalizationError,
)
from what_changed.normalize.config import ConfigNormalizer
from what_changed.normalize.text import TextNormalizer
from what_changed.normalize.dir import DirectoryNormalizer
from what_changed.normalize.registry import NormalizerRegistry, create_default_registry


class TestConfigNormalizer:
    """Tests for ConfigNormalizer."""

    @pytest.fixture
    def normalizer(self) -> ConfigNormalizer:
        """Create a ConfigNormalizer instance."""
        return ConfigNormalizer()

    # === JSON Normalization ===

    def test_normalize_json(self, normalizer: ConfigNormalizer, json_file_a: Path):
        """Test normalizing a JSON file."""
        result = normalizer.normalize(str(json_file_a))

        assert isinstance(result, NormalizedObject)
        assert result.type == "json"
        assert result.source_path == json_file_a
        assert len(result.entities) > 0

    def test_normalize_json_structure(self, normalizer: ConfigNormalizer, json_file_a: Path):
        """Test that JSON structure is captured."""
        result = normalizer.normalize(str(json_file_a))

        assert "total_keys" in result.structure
        assert "max_depth" in result.structure
        assert "top_level_keys" in result.structure

    def test_normalize_json_entities(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test that JSON keys become entities."""
        content = {"name": "test", "count": 42}
        path = temp_dir / "simple.json"
        path.write_text(json.dumps(content))

        result = normalizer.normalize(str(path))

        paths = result.get_all_paths()
        assert "name" in paths
        assert "count" in paths

    def test_normalize_json_nested(self, normalizer: ConfigNormalizer, deep_nested_json_a: Path):
        """Test normalizing deeply nested JSON."""
        result = normalizer.normalize(str(deep_nested_json_a))

        # Should have entities for each level
        paths = result.get_all_paths()
        assert "l1" in paths
        assert "l1.l2" in paths
        assert "l1.l2.l3.l4.l5.value" in paths

    def test_normalize_json_array(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing JSON with arrays."""
        content = {"items": [{"id": 1}, {"id": 2}]}
        path = temp_dir / "array.json"
        path.write_text(json.dumps(content))

        result = normalizer.normalize(str(path))

        paths = result.get_all_paths()
        assert "items" in paths
        assert "items[0]" in paths
        assert "items[1]" in paths

    def test_normalize_empty_json(self, normalizer: ConfigNormalizer, empty_json: Path):
        """Test normalizing an empty JSON object."""
        result = normalizer.normalize(str(empty_json))

        assert result.type == "json"
        assert len(result.entities) == 0

    def test_normalize_malformed_json_raises(self, normalizer: ConfigNormalizer, malformed_json: Path):
        """Test that malformed JSON raises NormalizationError."""
        with pytest.raises(NormalizationError) as exc_info:
            normalizer.normalize(str(malformed_json))

        assert "parse" in str(exc_info.value).lower()

    # === YAML Normalization ===

    def test_normalize_yaml(self, normalizer: ConfigNormalizer, yaml_file: Path):
        """Test normalizing a YAML file."""
        result = normalizer.normalize(str(yaml_file))

        assert result.type == "yaml"
        paths = result.get_all_paths()
        assert "database" in paths
        assert "database.host" in paths

    # === ENV Normalization ===

    def test_normalize_env(self, normalizer: ConfigNormalizer, env_file_a: Path):
        """Test normalizing an ENV file."""
        result = normalizer.normalize(str(env_file_a))

        assert result.type == "env"
        paths = result.get_all_paths()
        assert "DATABASE_URL" in paths
        assert "DEBUG" in paths
        assert "SECRET_KEY" in paths

    def test_normalize_env_with_comments(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test that ENV comments are ignored."""
        content = "# Comment\nKEY=value\n# Another comment\nKEY2=value2"
        path = temp_dir / ".env"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        paths = result.get_all_paths()
        assert "KEY" in paths
        assert "KEY2" in paths
        assert len([p for p in paths if "Comment" in p]) == 0

    # === Can Handle ===

    def test_can_handle_json(self, normalizer: ConfigNormalizer, json_file_a: Path):
        """Test can_handle for JSON files."""
        assert normalizer.can_handle(str(json_file_a)) is True

    def test_can_handle_yaml(self, normalizer: ConfigNormalizer, yaml_file: Path):
        """Test can_handle for YAML files."""
        assert normalizer.can_handle(str(yaml_file)) is True

    def test_can_handle_env(self, normalizer: ConfigNormalizer, env_file_a: Path):
        """Test can_handle for ENV files."""
        assert normalizer.can_handle(str(env_file_a)) is True

    def test_cannot_handle_text(self, normalizer: ConfigNormalizer, text_file_a: Path):
        """Test can_handle returns False for plain text."""
        assert normalizer.can_handle(str(text_file_a)) is False

    def test_cannot_handle_directory(self, normalizer: ConfigNormalizer, dir_a: Path):
        """Test can_handle returns False for directories."""
        assert normalizer.can_handle(str(dir_a)) is False

    # === TOML Normalization ===

    def test_normalize_toml(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing a TOML file."""
        content = """[database]
host = "localhost"
port = 5432

[server]
debug = true
"""
        path = temp_dir / "config.toml"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "toml"
        paths = result.get_all_paths()
        assert "database" in paths
        assert "database.host" in paths
        assert "database.port" in paths
        assert "server" in paths
        assert "server.debug" in paths

    def test_normalize_toml_nested(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing TOML with nested tables."""
        content = """[owner]
name = "Test"

[database]
server = "192.168.1.1"

[servers.alpha]
ip = "10.0.0.1"

[servers.beta]
ip = "10.0.0.2"
"""
        path = temp_dir / "nested.toml"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "toml"
        paths = result.get_all_paths()
        assert "owner.name" in paths
        assert "servers" in paths

    def test_can_handle_toml(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test can_handle for TOML files."""
        path = temp_dir / "config.toml"
        path.write_text("[section]\nkey = 'value'")
        assert normalizer.can_handle(str(path)) is True

    # === INI Normalization ===

    def test_normalize_ini(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing an INI file."""
        content = """[database]
host = localhost
port = 5432

[logging]
level = DEBUG
file = app.log
"""
        path = temp_dir / "config.ini"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "ini"
        paths = result.get_all_paths()
        assert "database" in paths
        assert "database.host" in paths
        assert "logging" in paths
        assert "logging.level" in paths

    def test_normalize_ini_with_defaults(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing INI with DEFAULT section."""
        content = """[DEFAULT]
timeout = 30

[database]
host = localhost

[api]
host = api.example.com
"""
        path = temp_dir / "defaults.ini"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "ini"
        paths = result.get_all_paths()
        assert "DEFAULT" in paths
        assert "DEFAULT.timeout" in paths

    def test_normalize_cfg_file(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing a .cfg file."""
        content = """[section]
option = value
"""
        path = temp_dir / "setup.cfg"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "ini"

    def test_can_handle_ini(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test can_handle for INI files."""
        path = temp_dir / "config.ini"
        path.write_text("[section]\nkey = value")
        assert normalizer.can_handle(str(path)) is True

    # === JSON Edge Cases ===

    def test_normalize_json_array_root(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing JSON with array as root."""
        content = '[1, 2, 3, "four"]'
        path = temp_dir / "array.json"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "json"
        # Should wrap in _root key
        paths = result.get_all_paths()
        assert "_root" in paths

    def test_normalize_json_with_null(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing JSON with null values."""
        content = '{"key": null, "other": "value"}'
        path = temp_dir / "null.json"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        entity = result.get_entity_by_path("key")
        assert entity is not None
        assert entity.value is None
        assert entity.metadata["value_type"] == "null"

    def test_normalize_json_with_float(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing JSON with float values."""
        content = '{"price": 19.99, "rate": 0.05}'
        path = temp_dir / "float.json"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        entity = result.get_entity_by_path("price")
        assert entity is not None
        assert entity.metadata["value_type"] == "float"

    def test_normalize_json_with_boolean(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing JSON with boolean values."""
        content = '{"enabled": true, "disabled": false}'
        path = temp_dir / "bool.json"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        entity = result.get_entity_by_path("enabled")
        assert entity is not None
        assert entity.metadata["value_type"] == "boolean"

    def test_normalize_json_array_with_scalars(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing JSON array with scalar values."""
        content = '{"tags": ["python", "testing", "cli"]}'
        path = temp_dir / "scalars.json"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        paths = result.get_all_paths()
        assert "tags" in paths
        assert "tags[0]" in paths
        assert "tags[1]" in paths
        assert "tags[2]" in paths

        # Check value type of array item
        tags_entity = result.get_entity_by_path("tags")
        assert tags_entity is not None
        assert tags_entity.metadata["value_type"] == "array"

    # === YAML Edge Cases ===

    def test_normalize_yaml_empty(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing empty YAML file."""
        path = temp_dir / "empty.yaml"
        path.write_text("")

        result = normalizer.normalize(str(path))

        assert result.type == "yaml"
        assert len(result.entities) == 0

    def test_normalize_yaml_null(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing YAML with null/~."""
        content = "key: ~\nother: null"
        path = temp_dir / "null.yaml"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        entity = result.get_entity_by_path("key")
        assert entity is not None
        assert entity.value is None

    def test_normalize_yaml_array_root(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing YAML with array as root."""
        content = "- item1\n- item2\n- item3"
        path = temp_dir / "list.yaml"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "yaml"
        # Should wrap in _root key
        paths = result.get_all_paths()
        assert "_root" in paths

    # === ENV Edge Cases ===

    def test_normalize_env_quoted_values(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing ENV with quoted values."""
        content = '''KEY1="double quoted"
KEY2='single quoted'
KEY3=unquoted'''
        path = temp_dir / ".env"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        key1 = result.get_entity_by_path("KEY1")
        assert key1 is not None
        assert key1.value == "double quoted"

        key2 = result.get_entity_by_path("KEY2")
        assert key2 is not None
        assert key2.value == "single quoted"

    def test_normalize_env_boolean_values(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing ENV with boolean values."""
        content = "ENABLED=true\nDISABLED=false\nDEBUG=TRUE\nVERBOSE=FALSE"
        path = temp_dir / ".env"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        enabled = result.get_entity_by_path("ENABLED")
        assert enabled is not None
        assert enabled.value is True

        disabled = result.get_entity_by_path("DISABLED")
        assert disabled is not None
        assert disabled.value is False

    def test_normalize_env_numeric_values(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing ENV with numeric values."""
        content = "PORT=8080\nRATIO=0.75\nCOUNT=100"
        path = temp_dir / ".env"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        port = result.get_entity_by_path("PORT")
        assert port is not None
        assert port.value == 8080
        assert isinstance(port.value, int)

        ratio = result.get_entity_by_path("RATIO")
        assert ratio is not None
        assert ratio.value == 0.75
        assert isinstance(ratio.value, float)

    def test_normalize_env_empty_lines(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test normalizing ENV with empty lines."""
        content = "KEY1=value1\n\n\nKEY2=value2\n"
        path = temp_dir / ".env"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        paths = result.get_all_paths()
        assert "KEY1" in paths
        assert "KEY2" in paths
        assert len(paths) == 2

    # === Content Detection ===

    def test_detect_json_by_content(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test detecting JSON by content when no extension."""
        path = temp_dir / "noext"
        path.write_text('{"key": "value"}')

        result = normalizer.normalize(str(path))
        assert result.type == "json"

    def test_detect_json_array_by_content(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test detecting JSON array by content when no extension."""
        path = temp_dir / "noext"
        path.write_text('[1, 2, 3]')

        result = normalizer.normalize(str(path))
        assert result.type == "json"

    def test_detect_ini_by_content(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test detecting INI by content when no extension."""
        # INI with comment first (so it doesn't start with [ which triggers JSON detection)
        path = temp_dir / "noext"
        path.write_text("; INI comment\n[section]\nkey = value")

        result = normalizer.normalize(str(path))
        assert result.type == "ini"

    def test_detect_env_by_content(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test detecting ENV by content when no extension."""
        path = temp_dir / "noext"
        path.write_text("DATABASE_URL=localhost\nDEBUG=true")

        result = normalizer.normalize(str(path))
        assert result.type == "env"

    def test_detect_yaml_fallback(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test that YAML is the fallback when format is ambiguous."""
        path = temp_dir / "noext"
        path.write_text("key: value\nother: data")

        result = normalizer.normalize(str(path))
        assert result.type == "yaml"

    # === can_handle Edge Cases ===

    def test_can_handle_with_source_type(self, normalizer: ConfigNormalizer):
        """Test can_handle with explicit source_type."""
        assert normalizer.can_handle("anyfile", source_type="json") is True
        assert normalizer.can_handle("anyfile", source_type="yaml") is True
        assert normalizer.can_handle("anyfile", source_type="yml") is True
        assert normalizer.can_handle("anyfile", source_type="env") is True
        assert normalizer.can_handle("anyfile", source_type="toml") is True
        assert normalizer.can_handle("anyfile", source_type="ini") is True
        assert normalizer.can_handle("anyfile", source_type="cfg") is True

    def test_can_handle_dotenv_variants(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test can_handle for various .env file patterns."""
        for name in [".env", ".env.local", ".env.production", ".env.test"]:
            path = temp_dir / name
            path.write_text("KEY=value")
            assert normalizer.can_handle(str(path)) is True

    def test_cannot_handle_nonexistent(self, normalizer: ConfigNormalizer):
        """Test can_handle returns False for non-existent files."""
        assert normalizer.can_handle("/nonexistent/file.json") is False

    # === Error Handling ===

    def test_normalize_nonexistent_raises(self, normalizer: ConfigNormalizer):
        """Test that non-existent file raises NormalizationError."""
        with pytest.raises(NormalizationError):
            normalizer.normalize("/nonexistent/file.json")

    def test_normalize_directory_raises(self, normalizer: ConfigNormalizer, temp_dir: Path):
        """Test that normalizing a directory raises NormalizationError."""
        with pytest.raises(NormalizationError) as exc_info:
            normalizer.normalize(str(temp_dir))
        assert "Not a file" in str(exc_info.value)

    # === Properties ===

    def test_supported_types_property(self, normalizer: ConfigNormalizer):
        """Test supported_types property."""
        types = normalizer.supported_types
        assert "json" in types
        assert "yaml" in types
        assert "yml" in types
        assert "env" in types
        assert "toml" in types
        assert "ini" in types
        assert "cfg" in types


class TestTextNormalizer:
    """Tests for TextNormalizer."""

    @pytest.fixture
    def normalizer(self) -> TextNormalizer:
        """Create a TextNormalizer instance."""
        return TextNormalizer()

    def test_normalize_text(self, normalizer: TextNormalizer, text_file_a: Path):
        """Test normalizing a text file."""
        result = normalizer.normalize(str(text_file_a))

        assert result.type == "text"
        assert len(result.entities) > 0

    def test_normalize_text_lines(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test that each line becomes an entity."""
        content = "Line 1\nLine 2\nLine 3"
        path = temp_dir / "lines.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert len(result.entities) == 3
        assert all(e.entity_type == EntityType.LINE for e in result.entities)

    def test_normalize_text_structure(self, normalizer: TextNormalizer, text_file_a: Path):
        """Test text structure information."""
        result = normalizer.normalize(str(text_file_a))

        assert "total_lines" in result.structure
        assert "total_chars" in result.structure
        assert "blank_lines" in result.structure

    def test_normalize_text_metadata(self, normalizer: TextNormalizer, text_file_a: Path):
        """Test text metadata."""
        result = normalizer.normalize(str(text_file_a))

        assert "filename" in result.metadata
        assert "extension" in result.metadata
        assert result.metadata["extension"] == ".txt"

    def test_can_handle_text(self, normalizer: TextNormalizer, text_file_a: Path):
        """Test can_handle for text files."""
        assert normalizer.can_handle(str(text_file_a)) is True

    def test_can_handle_markdown(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test can_handle for markdown files."""
        path = temp_dir / "readme.md"
        path.write_text("# Title\n\nContent")
        assert normalizer.can_handle(str(path)) is True

    def test_can_handle_with_source_type(self, normalizer: TextNormalizer):
        """Test can_handle with explicit source_type."""
        assert normalizer.can_handle("anyfile", source_type="text") is True
        assert normalizer.can_handle("anyfile", source_type="txt") is True
        assert normalizer.can_handle("anyfile", source_type="md") is True
        assert normalizer.can_handle("anyfile", source_type="log") is True
        assert normalizer.can_handle("anyfile", source_type="csv") is True
        assert normalizer.can_handle("anyfile", source_type="rst") is True

    def test_can_handle_no_extension_text_content(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test can_handle detects text files without extension."""
        path = temp_dir / "noextension"
        path.write_text("This is plain text content\nWith multiple lines")
        assert normalizer.can_handle(str(path)) is True

    def test_cannot_handle_binary_file(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test can_handle returns False for binary files."""
        path = temp_dir / "binary.bin"
        path.write_bytes(b'\x00\x01\x02\x03\x04\x05')  # Binary content with null bytes
        assert normalizer.can_handle(str(path)) is False

    def test_cannot_handle_nonexistent(self, normalizer: TextNormalizer):
        """Test can_handle returns False for non-existent files."""
        assert normalizer.can_handle("/nonexistent/file.txt") is False

    def test_normalize_nonexistent_raises(self, normalizer: TextNormalizer):
        """Test that non-existent file raises NormalizationError."""
        with pytest.raises(NormalizationError):
            normalizer.normalize("/nonexistent/file.txt")

    def test_normalize_directory_raises(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test that normalizing a directory raises NormalizationError."""
        with pytest.raises(NormalizationError) as exc_info:
            normalizer.normalize(str(temp_dir))
        assert "Not a file" in str(exc_info.value)

    def test_normalize_latin1_fallback(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test fallback to latin-1 encoding for non-UTF8 files."""
        path = temp_dir / "latin1.txt"
        # Write latin-1 encoded content that's not valid UTF-8
        path.write_bytes(b'Caf\xe9 and na\xefve')  # "Café and naïve" in latin-1

        result = normalizer.normalize(str(path))

        assert result.type == "text"
        assert len(result.entities) > 0

    def test_normalize_line_metadata(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test that line entities have proper metadata."""
        content = "  indented line\nblank follows\n\nnormal line"
        path = temp_dir / "lines.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        # Check indented line metadata
        indented = result.entities[0]
        assert indented.metadata["indent"] == 2
        assert indented.metadata["is_blank"] is False
        assert indented.metadata["line_number"] == 1

        # Check blank line metadata
        blank = result.entities[2]
        assert blank.metadata["is_blank"] is True
        assert blank.metadata["length"] == 0

    def test_normalize_blank_lines_count(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test blank lines are counted correctly."""
        content = "line1\n\nline3\n\n\nline6"
        path = temp_dir / "blanks.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.structure["blank_lines"] == 3
        assert result.structure["total_lines"] == 6

    def test_normalize_size_bytes(self, normalizer: TextNormalizer, temp_dir: Path):
        """Test that size_bytes is included in metadata."""
        content = "Hello, World!"
        path = temp_dir / "size.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert "size_bytes" in result.metadata
        assert result.metadata["size_bytes"] > 0

    def test_supported_types_property(self, normalizer: TextNormalizer):
        """Test supported_types property."""
        types = normalizer.supported_types
        assert "text" in types
        assert "txt" in types
        assert "md" in types
        assert "rst" in types
        assert "log" in types
        assert "csv" in types


class TestBlockTextNormalizer:
    """Tests for BlockTextNormalizer."""

    @pytest.fixture
    def normalizer(self):
        """Create a BlockTextNormalizer instance."""
        from what_changed.normalize.text import BlockTextNormalizer
        return BlockTextNormalizer()

    def test_can_handle_returns_false(self, normalizer):
        """Test that can_handle always returns False (must be explicitly requested)."""
        assert normalizer.can_handle("any_file.txt") is False
        assert normalizer.can_handle("any_file.txt", source_type="text") is False

    def test_normalize_creates_blocks(self, normalizer, temp_dir: Path):
        """Test that blocks are created from consecutive lines."""
        content = """First block line 1
First block line 2

Second block line 1
Second block line 2
Second block line 3

Third block"""
        path = temp_dir / "blocks.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.type == "text_blocks"
        assert len(result.entities) == 3

    def test_normalize_block_metadata(self, normalizer, temp_dir: Path):
        """Test block entity metadata."""
        content = "Line 1\nLine 2\n\nLine 4"
        path = temp_dir / "blocks.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        first_block = result.entities[0]
        assert first_block.metadata["start_line"] == 1
        assert first_block.metadata["end_line"] == 2
        assert first_block.metadata["line_count"] == 2

        second_block = result.entities[1]
        assert second_block.metadata["start_line"] == 4
        assert second_block.metadata["end_line"] == 4
        assert second_block.metadata["line_count"] == 1

    def test_normalize_block_content(self, normalizer, temp_dir: Path):
        """Test that block content is correct."""
        content = "Line A\nLine B\n\nLine C"
        path = temp_dir / "blocks.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.entities[0].value == "Line A\nLine B"
        assert result.entities[1].value == "Line C"

    def test_normalize_structure(self, normalizer, temp_dir: Path):
        """Test block structure information."""
        content = "Block 1\n\nBlock 2\n\nBlock 3"
        path = temp_dir / "blocks.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.structure["total_lines"] == 5
        assert result.structure["total_blocks"] == 3

    def test_normalize_nonexistent_raises(self, normalizer):
        """Test that non-existent file raises NormalizationError."""
        with pytest.raises(NormalizationError):
            normalizer.normalize("/nonexistent/file.txt")

    def test_normalize_single_block(self, normalizer, temp_dir: Path):
        """Test file with no blank lines creates single block."""
        content = "Line 1\nLine 2\nLine 3"
        path = temp_dir / "single.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert len(result.entities) == 1
        assert result.entities[0].metadata["line_count"] == 3

    def test_normalize_empty_file(self, normalizer, temp_dir: Path):
        """Test normalizing an empty file."""
        path = temp_dir / "empty.txt"
        path.write_text("")

        result = normalizer.normalize(str(path))

        assert result.type == "text_blocks"
        assert len(result.entities) == 0

    def test_normalize_only_blank_lines(self, normalizer, temp_dir: Path):
        """Test file with only blank lines."""
        content = "\n\n\n"
        path = temp_dir / "blanks.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert len(result.entities) == 0

    def test_normalize_metadata(self, normalizer, temp_dir: Path):
        """Test block normalizer metadata."""
        content = "content"
        path = temp_dir / "meta.txt"
        path.write_text(content)

        result = normalizer.normalize(str(path))

        assert result.metadata["filename"] == "meta.txt"

    def test_supported_types_property(self, normalizer):
        """Test supported_types property."""
        types = normalizer.supported_types
        assert "text_blocks" in types


class TestDirectoryNormalizer:
    """Tests for DirectoryNormalizer."""

    @pytest.fixture
    def normalizer(self) -> DirectoryNormalizer:
        """Create a DirectoryNormalizer instance."""
        return DirectoryNormalizer()

    def test_normalize_directory(self, normalizer: DirectoryNormalizer, dir_a: Path):
        """Test normalizing a directory."""
        result = normalizer.normalize(str(dir_a))

        assert result.type == "directory"
        assert result.source_path == dir_a

    def test_normalize_directory_structure(self, normalizer: DirectoryNormalizer, dir_a: Path):
        """Test directory structure information."""
        result = normalizer.normalize(str(dir_a))

        assert "total_files" in result.structure
        assert "total_directories" in result.structure
        assert "total_size" in result.structure

    def test_normalize_directory_files(self, normalizer: DirectoryNormalizer, dir_a: Path):
        """Test that files are captured as entities."""
        result = normalizer.normalize(str(dir_a))

        paths = result.get_all_paths()
        assert "src/main.py" in paths
        assert "src/utils.py" in paths
        assert "config.json" in paths

    def test_normalize_directory_metadata(self, normalizer: DirectoryNormalizer, dir_a: Path):
        """Test file metadata (hash, size)."""
        result = normalizer.normalize(str(dir_a))

        # Find a file entity
        file_entity = result.get_entity_by_path("config.json")
        assert file_entity is not None
        assert "hash" in file_entity.metadata
        assert "size" in file_entity.metadata

    def test_normalize_empty_directory(self, normalizer: DirectoryNormalizer, temp_dir: Path):
        """Test normalizing an empty directory."""
        empty_dir = temp_dir / "empty"
        empty_dir.mkdir()

        result = normalizer.normalize(str(empty_dir))

        assert result.type == "directory"
        assert result.structure["total_files"] == 0

    def test_ignores_git_directory(self, normalizer: DirectoryNormalizer, temp_dir: Path):
        """Test that .git directory is ignored."""
        project = temp_dir / "project"
        project.mkdir()
        (project / ".git").mkdir()
        (project / ".git" / "config").write_text("git config")
        (project / "main.py").write_text("code")

        result = normalizer.normalize(str(project))

        paths = result.get_all_paths()
        assert not any(".git" in p for p in paths)

    def test_can_handle_directory(self, normalizer: DirectoryNormalizer, dir_a: Path):
        """Test can_handle for directories."""
        assert normalizer.can_handle(str(dir_a)) is True

    def test_cannot_handle_file(self, normalizer: DirectoryNormalizer, json_file_a: Path):
        """Test can_handle returns False for files."""
        assert normalizer.can_handle(str(json_file_a)) is False


class TestNormalizerRegistry:
    """Tests for NormalizerRegistry."""

    @pytest.fixture
    def registry(self) -> NormalizerRegistry:
        """Create a default registry."""
        return create_default_registry()

    def test_normalize_json(self, registry: NormalizerRegistry, json_file_a: Path):
        """Test registry normalizes JSON files."""
        result = registry.normalize(str(json_file_a))
        assert result.type == "json"

    def test_normalize_yaml(self, registry: NormalizerRegistry, yaml_file: Path):
        """Test registry normalizes YAML files."""
        result = registry.normalize(str(yaml_file))
        assert result.type == "yaml"

    def test_normalize_directory(self, registry: NormalizerRegistry, dir_a: Path):
        """Test registry normalizes directories."""
        result = registry.normalize(str(dir_a))
        assert result.type == "directory"

    def test_normalize_text(self, registry: NormalizerRegistry, text_file_a: Path):
        """Test registry normalizes text files."""
        result = registry.normalize(str(text_file_a))
        assert result.type == "text"

    def test_get_normalizer_json(self, registry: NormalizerRegistry, json_file_a: Path):
        """Test getting normalizer for JSON."""
        normalizer = registry.get_normalizer(str(json_file_a))
        assert isinstance(normalizer, ConfigNormalizer)

    def test_detect_type(self, registry: NormalizerRegistry, json_file_a: Path):
        """Test type detection through registry."""
        from what_changed.detect import SourceType

        source_type = registry.detect_type(str(json_file_a))
        assert source_type == SourceType.JSON


class TestNormalizedObject:
    """Tests for NormalizedObject dataclass."""

    def test_entity_count(self):
        """Test entity_count property."""
        entities = [
            Entity(id="1", name="a", entity_type=EntityType.KEY, value="v", path="a"),
            Entity(id="2", name="b", entity_type=EntityType.KEY, value="v", path="b"),
        ]
        obj = NormalizedObject(
            type="test",
            entities=entities,
            structure={},
            metadata={},
        )
        assert obj.entity_count == 2

    def test_get_entity_by_id(self):
        """Test get_entity_by_id method."""
        entity = Entity(id="test-id", name="test", entity_type=EntityType.KEY, value="v", path="test")
        obj = NormalizedObject(
            type="test",
            entities=[entity],
            structure={},
            metadata={},
        )

        found = obj.get_entity_by_id("test-id")
        assert found == entity

        not_found = obj.get_entity_by_id("nonexistent")
        assert not_found is None

    def test_get_entity_by_path(self):
        """Test get_entity_by_path method."""
        entity = Entity(id="1", name="test", entity_type=EntityType.KEY, value="v", path="config.test")
        obj = NormalizedObject(
            type="test",
            entities=[entity],
            structure={},
            metadata={},
        )

        found = obj.get_entity_by_path("config.test")
        assert found == entity

    def test_get_all_paths(self):
        """Test get_all_paths method."""
        entities = [
            Entity(id="1", name="a", entity_type=EntityType.KEY, value="v", path="path.a"),
            Entity(id="2", name="b", entity_type=EntityType.KEY, value="v", path="path.b"),
        ]
        obj = NormalizedObject(
            type="test",
            entities=entities,
            structure={},
            metadata={},
        )

        paths = obj.get_all_paths()
        assert paths == {"path.a", "path.b"}

    def test_to_dict(self):
        """Test to_dict method."""
        obj = NormalizedObject(
            type="test",
            entities=[],
            structure={"key": "value"},
            metadata={"meta": "data"},
        )

        d = obj.to_dict()
        assert d["type"] == "test"
        assert d["structure"] == {"key": "value"}
        assert d["metadata"] == {"meta": "data"}


class TestEntity:
    """Tests for Entity dataclass."""

    def test_entity_creation(self):
        """Test creating an entity."""
        entity = Entity(
            id="test-id",
            name="test",
            entity_type=EntityType.KEY,
            value="value",
            path="config.test",
        )
        assert entity.id == "test-id"
        assert entity.name == "test"
        assert entity.value == "value"

    def test_entity_with_children(self):
        """Test entity with children."""
        child = Entity(id="child", name="child", entity_type=EntityType.VALUE, value="v", path="parent.child")
        parent = Entity(
            id="parent",
            name="parent",
            entity_type=EntityType.SECTION,
            value={},
            path="parent",
            children=[child],
        )

        assert parent.has_children is True
        assert parent.get_child("child") == child

    def test_entity_flatten(self):
        """Test flatten method."""
        grandchild = Entity(id="gc", name="gc", entity_type=EntityType.VALUE, value="v", path="p.c.gc")
        child = Entity(id="c", name="c", entity_type=EntityType.SECTION, value={}, path="p.c", children=[grandchild])
        parent = Entity(id="p", name="p", entity_type=EntityType.SECTION, value={}, path="p", children=[child])

        flattened = parent.flatten()
        assert len(flattened) == 3
        assert parent in flattened
        assert child in flattened
        assert grandchild in flattened

    def test_entity_hash_and_eq(self):
        """Test entity hashing and equality."""
        e1 = Entity(id="same-id", name="a", entity_type=EntityType.KEY, value="v1", path="a")
        e2 = Entity(id="same-id", name="b", entity_type=EntityType.KEY, value="v2", path="b")
        e3 = Entity(id="diff-id", name="a", entity_type=EntityType.KEY, value="v1", path="a")

        assert e1 == e2  # Same ID
        assert e1 != e3  # Different ID
        assert hash(e1) == hash(e2)
