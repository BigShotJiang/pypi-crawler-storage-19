"""Tests for OpenAPI/Swagger normalizer."""

import json
from pathlib import Path

import pytest
import yaml

# Check if OpenAPI support is available
try:
    from openapi_spec_validator import validate

    HAS_OPENAPI = True
except ImportError:
    HAS_OPENAPI = False

pytestmark = pytest.mark.skipif(not HAS_OPENAPI, reason="openapi-spec-validator not installed")


@pytest.fixture
def openapi3_spec(tmp_path: Path) -> Path:
    """Create an OpenAPI 3.0 spec for testing."""
    spec = {
        "openapi": "3.0.0",
        "info": {
            "title": "Test API",
            "version": "1.0.0",
            "description": "A test API",
        },
        "servers": [{"url": "https://api.example.com/v1"}],
        "paths": {
            "/users": {
                "get": {
                    "operationId": "getUsers",
                    "summary": "Get all users",
                    "parameters": [
                        {
                            "name": "limit",
                            "in": "query",
                            "required": False,
                            "schema": {"type": "integer"},
                        }
                    ],
                    "responses": {
                        "200": {
                            "description": "Success",
                            "content": {
                                "application/json": {
                                    "schema": {"$ref": "#/components/schemas/UserList"}
                                }
                            },
                        }
                    },
                },
                "post": {
                    "operationId": "createUser",
                    "summary": "Create a user",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/User"}
                            }
                        }
                    },
                    "responses": {"201": {"description": "Created"}},
                },
            },
            "/users/{id}": {
                "get": {
                    "operationId": "getUser",
                    "summary": "Get a user",
                    "parameters": [
                        {
                            "name": "id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        }
                    ],
                    "responses": {"200": {"description": "Success"}},
                }
            },
        },
        "components": {
            "schemas": {
                "User": {
                    "type": "object",
                    "required": ["name", "email"],
                    "properties": {
                        "id": {"type": "string"},
                        "name": {"type": "string"},
                        "email": {"type": "string"},
                    },
                },
                "UserList": {
                    "type": "array",
                    "items": {"$ref": "#/components/schemas/User"},
                },
            },
            "securitySchemes": {
                "bearerAuth": {"type": "http", "scheme": "bearer"}
            },
        },
    }

    spec_path = tmp_path / "openapi.yaml"
    spec_path.write_text(yaml.dump(spec))
    return spec_path


@pytest.fixture
def swagger2_spec(tmp_path: Path) -> Path:
    """Create a Swagger 2.0 spec for testing."""
    spec = {
        "swagger": "2.0",
        "info": {"title": "Legacy API", "version": "2.0.0"},
        "basePath": "/api/v2",
        "paths": {
            "/items": {
                "get": {
                    "operationId": "getItems",
                    "responses": {"200": {"description": "Success"}},
                }
            }
        },
        "definitions": {
            "Item": {
                "type": "object",
                "properties": {"id": {"type": "integer"}, "name": {"type": "string"}},
            }
        },
    }

    spec_path = tmp_path / "swagger.json"
    spec_path.write_text(json.dumps(spec))
    return spec_path


class TestOpenAPINormalizer:
    """Tests for OpenAPINormalizer class."""

    def test_normalize_openapi3(self, openapi3_spec: Path):
        """Test normalizing OpenAPI 3.0 spec."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()
        result = normalizer.normalize(str(openapi3_spec))

        assert result.type == "openapi"
        assert result.metadata["spec_version"] == "3.0.0"
        assert result.metadata["title"] == "Test API"
        assert result.metadata["api_version"] == "1.0.0"
        assert result.structure["endpoint_count"] == 3

    def test_normalize_swagger2(self, swagger2_spec: Path):
        """Test normalizing Swagger 2.0 spec."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()
        result = normalizer.normalize(str(swagger2_spec))

        assert result.type == "swagger"
        assert result.metadata["spec_version"] == "2.0"
        assert result.metadata["title"] == "Legacy API"

    def test_extracts_paths(self, openapi3_spec: Path):
        """Test that paths are extracted as entities."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()
        result = normalizer.normalize(str(openapi3_spec))

        # Find path entities
        path_entities = [e for e in result.entities if e.path.startswith("paths.")]
        assert len(path_entities) == 2

        # Check /users path
        users_path = next(e for e in path_entities if e.name == "/users")
        assert "get" in users_path.metadata["methods"]
        assert "post" in users_path.metadata["methods"]

    def test_extracts_schemas(self, openapi3_spec: Path):
        """Test that schemas are extracted as entities."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()
        result = normalizer.normalize(str(openapi3_spec))

        # Find schema entities
        schema_entities = [e for e in result.entities if e.path.startswith("schemas.")]
        assert len(schema_entities) == 2

        # Check User schema
        user_schema = next(e for e in schema_entities if e.name == "User")
        assert "name" in user_schema.metadata["properties"]
        assert "email" in user_schema.metadata["required"]

    def test_extracts_security(self, openapi3_spec: Path):
        """Test that security schemes are extracted."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()
        result = normalizer.normalize(str(openapi3_spec))

        # Find security entity
        security = next((e for e in result.entities if e.name == "security"), None)
        assert security is not None
        assert "bearerAuth" in security.metadata["schemes"]

    def test_can_handle_openapi(self, openapi3_spec: Path):
        """Test can_handle with OpenAPI file."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()
        assert normalizer.can_handle(str(openapi3_spec)) is True
        assert normalizer.can_handle(str(openapi3_spec), "openapi") is True

    def test_can_handle_swagger(self, swagger2_spec: Path):
        """Test can_handle with Swagger file."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()
        assert normalizer.can_handle(str(swagger2_spec)) is True
        assert normalizer.can_handle(str(swagger2_spec), "swagger") is True

    def test_can_handle_non_openapi(self, tmp_path: Path):
        """Test can_handle returns False for non-OpenAPI files."""
        from what_changed.normalize.openapi import OpenAPINormalizer

        normalizer = OpenAPINormalizer()

        # Regular JSON file
        json_file = tmp_path / "config.json"
        json_file.write_text(json.dumps({"key": "value"}))
        assert normalizer.can_handle(str(json_file)) is False

        # Regular YAML file
        yaml_file = tmp_path / "config.yaml"
        yaml_file.write_text("key: value")
        assert normalizer.can_handle(str(yaml_file)) is False

    def test_normalize_nonexistent_file(self, tmp_path: Path):
        """Test normalizing nonexistent file raises error."""
        from what_changed.normalize.openapi import OpenAPINormalizer
        from what_changed.normalize.base import NormalizationError

        normalizer = OpenAPINormalizer()

        with pytest.raises(NormalizationError, match="not found"):
            normalizer.normalize(str(tmp_path / "nonexistent.yaml"))


class TestOpenAPIComparison:
    """Tests for comparing OpenAPI specs."""

    def test_compare_added_endpoint(self, tmp_path: Path):
        """Test detecting added endpoints."""
        from what_changed.normalize.openapi import OpenAPINormalizer
        from what_changed.diff import SemanticDiff

        # Original spec
        spec_a = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "1.0.0"},
            "paths": {"/users": {"get": {"responses": {"200": {"description": "OK"}}}}},
        }

        # New spec with added endpoint
        spec_b = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "1.1.0"},
            "paths": {
                "/users": {"get": {"responses": {"200": {"description": "OK"}}}},
                "/items": {"get": {"responses": {"200": {"description": "OK"}}}},
            },
        }

        path_a = tmp_path / "a.yaml"
        path_b = tmp_path / "b.yaml"
        path_a.write_text(yaml.dump(spec_a))
        path_b.write_text(yaml.dump(spec_b))

        normalizer = OpenAPINormalizer()
        obj_a = normalizer.normalize(str(path_a))
        obj_b = normalizer.normalize(str(path_b))

        differ = SemanticDiff()
        result = differ.diff(obj_a, obj_b)

        assert result.added_count > 0

    def test_compare_removed_endpoint(self, tmp_path: Path):
        """Test detecting removed endpoints (breaking change)."""
        from what_changed.normalize.openapi import OpenAPINormalizer
        from what_changed.diff import SemanticDiff
        from what_changed.graph import GraphBuilder
        from what_changed.rules import create_default_engine

        # Original spec with two endpoints
        spec_a = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "1.0.0"},
            "paths": {
                "/users": {"get": {"responses": {"200": {"description": "OK"}}}},
                "/items": {"get": {"responses": {"200": {"description": "OK"}}}},
            },
        }

        # New spec with endpoint removed
        spec_b = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "2.0.0"},
            "paths": {"/users": {"get": {"responses": {"200": {"description": "OK"}}}}},
        }

        path_a = tmp_path / "a.yaml"
        path_b = tmp_path / "b.yaml"
        path_a.write_text(yaml.dump(spec_a))
        path_b.write_text(yaml.dump(spec_b))

        normalizer = OpenAPINormalizer()
        obj_a = normalizer.normalize(str(path_a))
        obj_b = normalizer.normalize(str(path_b))

        differ = SemanticDiff()
        diff_result = differ.diff(obj_a, obj_b)

        builder = GraphBuilder()
        graph = builder.build(diff_result)

        engine = create_default_engine()
        engine.apply(graph)

        # Should have breaking changes
        breaking = graph.get_breaking_changes()
        assert len(breaking) > 0

    def test_compare_changed_schema(self, tmp_path: Path):
        """Test detecting schema changes."""
        from what_changed.normalize.openapi import OpenAPINormalizer
        from what_changed.diff import SemanticDiff

        # Original spec
        spec_a = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "1.0.0"},
            "paths": {},
            "components": {
                "schemas": {
                    "User": {
                        "type": "object",
                        "required": ["name"],
                        "properties": {"name": {"type": "string"}},
                    }
                }
            },
        }

        # New spec with added required field
        spec_b = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "1.1.0"},
            "paths": {},
            "components": {
                "schemas": {
                    "User": {
                        "type": "object",
                        "required": ["name", "email"],
                        "properties": {
                            "name": {"type": "string"},
                            "email": {"type": "string"},
                        },
                    }
                }
            },
        }

        path_a = tmp_path / "a.yaml"
        path_b = tmp_path / "b.yaml"
        path_a.write_text(yaml.dump(spec_a))
        path_b.write_text(yaml.dump(spec_b))

        normalizer = OpenAPINormalizer()
        obj_a = normalizer.normalize(str(path_a))
        obj_b = normalizer.normalize(str(path_b))

        differ = SemanticDiff()
        result = differ.diff(obj_a, obj_b)

        # Should detect schema changes
        assert result.modified_count > 0


class TestOpenAPIIntegration:
    """Integration tests for OpenAPI support."""

    def test_registry_includes_openapi_normalizer(self):
        """Test that registry includes OpenAPI normalizer when available."""
        from what_changed.normalize import create_default_registry

        registry = create_default_registry()

        assert "openapi" in registry.registered_types or "swagger" in registry.registered_types

    def test_end_to_end_openapi_comparison(self, tmp_path: Path):
        """Test full pipeline with OpenAPI specs."""
        from what_changed.normalize import create_default_registry
        from what_changed.diff import SemanticDiff
        from what_changed.graph import GraphBuilder
        from what_changed.rules import create_default_engine
        from what_changed.explain import Explainer

        # Create two OpenAPI specs
        spec_a = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "1.0.0"},
            "paths": {
                "/users": {
                    "get": {"responses": {"200": {"description": "OK"}}},
                    "delete": {"responses": {"204": {"description": "Deleted"}}},
                }
            },
        }

        spec_b = {
            "openapi": "3.0.0",
            "info": {"title": "API", "version": "2.0.0"},
            "paths": {
                "/users": {"get": {"responses": {"200": {"description": "OK"}}}},
                "/products": {"get": {"responses": {"200": {"description": "OK"}}}},
            },
        }

        path_a = tmp_path / "old.yaml"
        path_b = tmp_path / "new.yaml"
        path_a.write_text(yaml.dump(spec_a))
        path_b.write_text(yaml.dump(spec_b))

        # Run full pipeline
        registry = create_default_registry()
        obj_a = registry.normalize(str(path_a))
        obj_b = registry.normalize(str(path_b))

        differ = SemanticDiff()
        diff_result = differ.diff(obj_a, obj_b)

        builder = GraphBuilder()
        graph = builder.build(diff_result)

        engine = create_default_engine()
        rule_results = engine.apply(graph)

        explainer = Explainer()
        explanations = explainer.explain_graph(graph, rule_results)

        # Should produce some output (DELETE endpoint removed = breaking)
        assert diff_result.total_changes > 0
