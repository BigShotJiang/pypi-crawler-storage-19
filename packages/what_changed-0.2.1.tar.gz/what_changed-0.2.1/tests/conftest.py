"""Pytest configuration and shared fixtures."""

import json
import tempfile
from pathlib import Path
from typing import Generator

import pytest


@pytest.fixture
def temp_dir() -> Generator[Path, None, None]:
    """Create a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def json_file_a(temp_dir: Path) -> Path:
    """Create a sample JSON file (version A)."""
    content = {
        "app": {"name": "test-app", "version": "1.0.0"},
        "database": {"host": "localhost", "port": 5432},
        "debug": True,
    }
    path = temp_dir / "config_a.json"
    path.write_text(json.dumps(content, indent=2))
    return path


@pytest.fixture
def json_file_b(temp_dir: Path) -> Path:
    """Create a sample JSON file (version B) with changes."""
    content = {
        "app": {"name": "test-app", "version": "2.0.0"},
        "database": {"host": "prod.db.com", "port": 5432, "ssl": True},
        "debug": False,
        "new_key": "added",
    }
    path = temp_dir / "config_b.json"
    path.write_text(json.dumps(content, indent=2))
    return path


@pytest.fixture
def json_file_identical(temp_dir: Path) -> tuple[Path, Path]:
    """Create two identical JSON files."""
    content = {"key": "value", "number": 42}
    path_a = temp_dir / "identical_a.json"
    path_b = temp_dir / "identical_b.json"
    path_a.write_text(json.dumps(content))
    path_b.write_text(json.dumps(content))
    return path_a, path_b


@pytest.fixture
def yaml_file(temp_dir: Path) -> Path:
    """Create a sample YAML file."""
    content = """database:
  host: localhost
  port: 5432
debug: true
"""
    path = temp_dir / "config.yaml"
    path.write_text(content)
    return path


@pytest.fixture
def env_file_a(temp_dir: Path) -> Path:
    """Create a sample ENV file (version A)."""
    content = """# Environment config
DATABASE_URL=postgres://localhost:5432/app
DEBUG=true
SECRET_KEY=dev-secret-123
"""
    path = temp_dir / ".env.a"
    path.write_text(content)
    return path


@pytest.fixture
def env_file_b(temp_dir: Path) -> Path:
    """Create a sample ENV file (version B) with changes."""
    content = """# Environment config
DATABASE_URL=postgres://prod.db.com:5432/app
DEBUG=false
SECRET_KEY=prod-secret-xyz
API_KEY=new-api-key
"""
    path = temp_dir / ".env.b"
    path.write_text(content)
    return path


@pytest.fixture
def text_file_a(temp_dir: Path) -> Path:
    """Create a sample text file (version A)."""
    content = """Line 1
Line 2
Line 3
"""
    path = temp_dir / "file_a.txt"
    path.write_text(content)
    return path


@pytest.fixture
def text_file_b(temp_dir: Path) -> Path:
    """Create a sample text file (version B) with changes."""
    content = """Line 1
Line 2 modified
Line 3
Line 4 added
"""
    path = temp_dir / "file_b.txt"
    path.write_text(content)
    return path


@pytest.fixture
def dir_a(temp_dir: Path) -> Path:
    """Create a sample directory structure (version A)."""
    dir_path = temp_dir / "project_a"
    dir_path.mkdir()
    (dir_path / "src").mkdir()
    (dir_path / "src" / "main.py").write_text("print('hello')")
    (dir_path / "src" / "utils.py").write_text("def helper(): pass")
    (dir_path / "config.json").write_text('{"version": "1.0"}')
    return dir_path


@pytest.fixture
def dir_b(temp_dir: Path) -> Path:
    """Create a sample directory structure (version B) with changes."""
    dir_path = temp_dir / "project_b"
    dir_path.mkdir()
    (dir_path / "src").mkdir()
    (dir_path / "docs").mkdir()
    (dir_path / "src" / "main.py").write_text("print('hello world')")
    (dir_path / "src" / "helpers.py").write_text("def new_helper(): pass")
    (dir_path / "config.json").write_text('{"version": "2.0"}')
    (dir_path / "docs" / "README.md").write_text("# Docs")
    return dir_path


@pytest.fixture
def empty_json(temp_dir: Path) -> Path:
    """Create an empty JSON object file."""
    path = temp_dir / "empty.json"
    path.write_text("{}")
    return path


@pytest.fixture
def malformed_json(temp_dir: Path) -> Path:
    """Create a malformed JSON file."""
    path = temp_dir / "malformed.json"
    path.write_text('{"key": "value",}')  # Trailing comma
    return path


@pytest.fixture
def deep_nested_json_a(temp_dir: Path) -> Path:
    """Create a deeply nested JSON file (version A)."""
    content = {
        "l1": {"l2": {"l3": {"l4": {"l5": {"value": "original"}}}}}
    }
    path = temp_dir / "deep_a.json"
    path.write_text(json.dumps(content))
    return path


@pytest.fixture
def deep_nested_json_b(temp_dir: Path) -> Path:
    """Create a deeply nested JSON file (version B) with deep change."""
    content = {
        "l1": {"l2": {"l3": {"l4": {"l5": {"value": "changed"}}}}}
    }
    path = temp_dir / "deep_b.json"
    path.write_text(json.dumps(content))
    return path


@pytest.fixture
def type_change_json_a(temp_dir: Path) -> Path:
    """Create a JSON file with string values (for type change testing)."""
    content = {"port": "8080", "enabled": "true", "count": "42"}
    path = temp_dir / "types_a.json"
    path.write_text(json.dumps(content))
    return path


@pytest.fixture
def type_change_json_b(temp_dir: Path) -> Path:
    """Create a JSON file with typed values (for type change testing)."""
    content = {"port": 8080, "enabled": True, "count": 42}
    path = temp_dir / "types_b.json"
    path.write_text(json.dumps(content))
    return path
