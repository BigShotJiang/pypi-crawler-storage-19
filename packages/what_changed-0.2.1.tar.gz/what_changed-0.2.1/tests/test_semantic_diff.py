"""Tests for semantic diff engine."""

from pathlib import Path

import pytest

from what_changed.normalize import create_default_registry
from what_changed.diff.semantic_diff import SemanticDiff, DiffResult, Change, ChangeType


class TestSemanticDiff:
    """Tests for SemanticDiff class."""

    @pytest.fixture
    def differ(self) -> SemanticDiff:
        """Create a SemanticDiff instance."""
        return SemanticDiff()

    @pytest.fixture
    def registry(self):
        """Create a default normalizer registry."""
        return create_default_registry()

    # === Basic Diff Operations ===

    def test_diff_returns_diff_result(self, differ: SemanticDiff, registry, json_file_a: Path, json_file_b: Path):
        """Test that diff returns a DiffResult."""
        obj_a = registry.normalize(str(json_file_a))
        obj_b = registry.normalize(str(json_file_b))

        result = differ.diff(obj_a, obj_b)

        assert isinstance(result, DiffResult)

    def test_diff_source_info(self, differ: SemanticDiff, registry, json_file_a: Path, json_file_b: Path):
        """Test that DiffResult contains source information."""
        obj_a = registry.normalize(str(json_file_a))
        obj_b = registry.normalize(str(json_file_b))

        result = differ.diff(obj_a, obj_b)

        assert str(json_file_a) in result.source_a
        assert str(json_file_b) in result.source_b
        assert result.type_a == "json"
        assert result.type_b == "json"

    # === Detecting Changes ===

    def test_diff_detects_additions(self, differ: SemanticDiff, registry, json_file_a: Path, json_file_b: Path):
        """Test that added keys are detected."""
        obj_a = registry.normalize(str(json_file_a))
        obj_b = registry.normalize(str(json_file_b))

        result = differ.diff(obj_a, obj_b)

        added = result.get_changes_by_type(ChangeType.ADDED)
        added_paths = [c.path for c in added]

        assert any("new_key" in p for p in added_paths)

    def test_diff_detects_removals(self, differ: SemanticDiff, registry, temp_dir: Path):
        """Test that removed keys are detected."""
        import json

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"keep": "value", "remove": "me"}))
        file_b.write_text(json.dumps({"keep": "value"}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        removed = result.get_changes_by_type(ChangeType.REMOVED)
        removed_paths = [c.path for c in removed]

        assert "remove" in removed_paths

    def test_diff_detects_modifications(self, differ: SemanticDiff, registry, json_file_a: Path, json_file_b: Path):
        """Test that modified values are detected."""
        obj_a = registry.normalize(str(json_file_a))
        obj_b = registry.normalize(str(json_file_b))

        result = differ.diff(obj_a, obj_b)

        modified = result.get_changes_by_type(ChangeType.MODIFIED)
        modified_paths = [c.path for c in modified]

        # version changed from 1.0.0 to 2.0.0
        assert any("version" in p for p in modified_paths)

    def test_diff_detects_type_changes(self, differ: SemanticDiff, registry, type_change_json_a: Path, type_change_json_b: Path):
        """Test that type changes are detected."""
        obj_a = registry.normalize(str(type_change_json_a))
        obj_b = registry.normalize(str(type_change_json_b))

        result = differ.diff(obj_a, obj_b)

        type_changed = result.get_changes_by_type(ChangeType.TYPE_CHANGED)
        assert len(type_changed) > 0

        # Check metadata contains type info
        for change in type_changed:
            assert "old_type" in change.metadata
            assert "new_type" in change.metadata

    # === Identical Files ===

    def test_diff_identical_files(self, differ: SemanticDiff, registry, json_file_identical: tuple[Path, Path]):
        """Test diff of identical files."""
        file_a, file_b = json_file_identical

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        # Should have no significant changes
        assert result.added_count == 0
        assert result.removed_count == 0
        # Identical values shouldn't show as modified
        modified = [c for c in result.changes if c.change_type == ChangeType.MODIFIED]
        assert len(modified) == 0

    # === Deep Nesting ===

    def test_diff_deep_nested(self, differ: SemanticDiff, registry, deep_nested_json_a: Path, deep_nested_json_b: Path):
        """Test diff of deeply nested structures."""
        obj_a = registry.normalize(str(deep_nested_json_a))
        obj_b = registry.normalize(str(deep_nested_json_b))

        result = differ.diff(obj_a, obj_b)

        # Should detect the deep change
        modified = result.get_changes_by_type(ChangeType.MODIFIED)
        deep_changes = [c for c in modified if "l5" in c.path]
        assert len(deep_changes) > 0

    # === DiffResult Properties ===

    def test_diff_result_has_changes(self, differ: SemanticDiff, registry, json_file_a: Path, json_file_b: Path):
        """Test has_changes property."""
        obj_a = registry.normalize(str(json_file_a))
        obj_b = registry.normalize(str(json_file_b))

        result = differ.diff(obj_a, obj_b)

        assert result.has_changes is True
        assert result.total_changes > 0

    def test_diff_result_no_changes(self, differ: SemanticDiff, registry, json_file_identical: tuple[Path, Path]):
        """Test has_changes is False for identical files."""
        file_a, file_b = json_file_identical

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        # No additions, removals, or type changes
        assert result.added_count == 0
        assert result.removed_count == 0
        assert result.type_changed_count == 0

    def test_diff_result_breaking_changes(self, differ: SemanticDiff, registry, temp_dir: Path):
        """Test breaking_changes property."""
        import json

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"removed_key": "value"}))
        file_b.write_text(json.dumps({}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        breaking = result.breaking_changes
        assert len(breaking) > 0
        assert all(c.is_breaking for c in breaking)

    def test_get_changes_by_path(self, differ: SemanticDiff, registry, json_file_a: Path, json_file_b: Path):
        """Test get_changes_by_path method."""
        obj_a = registry.normalize(str(json_file_a))
        obj_b = registry.normalize(str(json_file_b))

        result = differ.diff(obj_a, obj_b)

        # Get changes under 'database' path
        db_changes = result.get_changes_by_path("database")
        assert len(db_changes) > 0
        assert all(c.path.startswith("database") for c in db_changes)

    # === Directory Diff ===

    def test_diff_directories(self, differ: SemanticDiff, registry, dir_a: Path, dir_b: Path):
        """Test diff of directories."""
        obj_a = registry.normalize(str(dir_a))
        obj_b = registry.normalize(str(dir_b))

        result = differ.diff(obj_a, obj_b)

        assert result.has_changes
        # utils.py was removed
        removed = result.get_changes_by_type(ChangeType.REMOVED)
        assert any("utils.py" in c.path for c in removed)
        # helpers.py was added
        added = result.get_changes_by_type(ChangeType.ADDED)
        assert any("helpers.py" in c.path for c in added)

    # === ENV Diff ===

    def test_diff_env_files(self, differ: SemanticDiff, registry, env_file_a: Path, env_file_b: Path):
        """Test diff of ENV files."""
        obj_a = registry.normalize(str(env_file_a))
        obj_b = registry.normalize(str(env_file_b))

        result = differ.diff(obj_a, obj_b)

        assert result.has_changes
        # DATABASE_URL changed
        modified = result.get_changes_by_type(ChangeType.MODIFIED)
        assert any("DATABASE_URL" in c.path for c in modified)
        # API_KEY added
        added = result.get_changes_by_type(ChangeType.ADDED)
        assert any("API_KEY" in c.path for c in added)


    # === Rename Detection ===

    def test_diff_detects_renames(self, differ: SemanticDiff, registry, temp_dir: Path):
        """Test that renames are detected."""
        import json

        # Create files where a key is renamed but value is similar
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"old_name": "same_value", "keep": "value"}))
        file_b.write_text(json.dumps({"new_name": "same_value", "keep": "value"}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        # Should detect rename
        renamed = result.get_changes_by_type(ChangeType.RENAMED)
        assert len(renamed) > 0
        assert result.renamed_count > 0

    def test_diff_rename_metadata(self, differ: SemanticDiff, registry, temp_dir: Path):
        """Test that rename changes have proper metadata."""
        import json

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"old_key": "value"}))
        file_b.write_text(json.dumps({"new_key": "value"}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        renamed = result.get_changes_by_type(ChangeType.RENAMED)
        if renamed:
            change = renamed[0]
            assert "old_name" in change.metadata
            assert "new_name" in change.metadata
            assert "old_path" in change.metadata
            assert "new_path" in change.metadata

    def test_diff_disable_rename_detection(self, registry, temp_dir: Path):
        """Test that rename detection can be disabled."""
        import json

        differ = SemanticDiff(detect_renames=False)

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"old_name": "value"}))
        file_b.write_text(json.dumps({"new_name": "value"}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        # Should not detect rename, should see add and remove instead
        renamed = result.get_changes_by_type(ChangeType.RENAMED)
        assert len(renamed) == 0
        assert result.added_count > 0
        assert result.removed_count > 0

    def test_diff_similarity_threshold(self, registry, temp_dir: Path):
        """Test similarity threshold affects rename detection."""
        import json

        # With high threshold, slightly different values won't match
        differ_strict = SemanticDiff(similarity_threshold=0.99)

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"old_key": "value_1"}))
        file_b.write_text(json.dumps({"new_key": "value_2"}))  # Slightly different value

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ_strict.diff(obj_a, obj_b)

        # Strict threshold should not detect rename
        renamed = result.get_changes_by_type(ChangeType.RENAMED)
        assert len(renamed) == 0

    # === String Diff Details ===

    def test_diff_string_changes_have_details(self, differ: SemanticDiff, registry, temp_dir: Path):
        """Test that string changes include diff details."""
        import json

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"content": "line1\nline2\nline3"}))
        file_b.write_text(json.dumps({"content": "line1\nmodified\nline3\nline4"}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        modified = result.get_changes_by_type(ChangeType.MODIFIED)
        content_changes = [c for c in modified if c.path == "content"]
        assert len(content_changes) > 0

        change = content_changes[0]
        assert "lines_added" in change.metadata or "old_length" in change.metadata

    # === Values Differ Edge Cases ===

    def test_diff_none_values(self, differ: SemanticDiff, registry, temp_dir: Path):
        """Test diffing with None values."""
        import json

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"key": None}))
        file_b.write_text(json.dumps({"key": "value"}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        # Should detect change from None to value
        assert result.has_changes

    def test_diff_both_none_values(self, differ: SemanticDiff, registry, temp_dir: Path):
        """Test that two None values are considered equal."""
        import json

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"key": None}))
        file_b.write_text(json.dumps({"key": None}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        # key should not show as modified
        modified = [c for c in result.changes if c.path == "key" and c.change_type == ChangeType.MODIFIED]
        assert len(modified) == 0

    # === Numeric Similarity ===

    def test_diff_numeric_similarity_in_renames(self, registry, temp_dir: Path):
        """Test numeric similarity for rename detection."""
        import json

        differ = SemanticDiff(similarity_threshold=0.5)

        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        # Values are numerically similar (within 10%)
        file_a.write_text(json.dumps({"old_count": 100}))
        file_b.write_text(json.dumps({"new_count": 105}))

        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        result = differ.diff(obj_a, obj_b)

        # Should potentially detect as rename due to numeric similarity
        # (depends on threshold and weighting)
        assert result.has_changes

    # === File Hash Detection ===

    def test_diff_file_hash_change(self, differ: SemanticDiff, registry, dir_a: Path, dir_b: Path):
        """Test detection of file changes via hash."""
        obj_a = registry.normalize(str(dir_a))
        obj_b = registry.normalize(str(dir_b))

        result = differ.diff(obj_a, obj_b)

        # main.py was modified (content changed)
        modified = result.get_changes_by_type(ChangeType.MODIFIED)
        main_changes = [c for c in modified if "main.py" in c.path]
        assert len(main_changes) > 0

    # === Source URL/Path Handling ===

    def test_diff_source_fallback(self, differ: SemanticDiff):
        """Test source fallback when no path/URL is set."""
        from what_changed.normalize.base import NormalizedObject, Entity, EntityType

        obj_a = NormalizedObject(
            type="test",
            entities=[Entity(id="1", name="key", entity_type=EntityType.KEY, value="a", path="key")],
            structure={},
            metadata={},
        )
        obj_b = NormalizedObject(
            type="test",
            entities=[Entity(id="2", name="key", entity_type=EntityType.KEY, value="b", path="key")],
            structure={},
            metadata={},
        )

        result = differ.diff(obj_a, obj_b)

        # Should use "A" and "B" as fallback
        assert result.source_a == "A"
        assert result.source_b == "B"


class TestChange:
    """Tests for Change dataclass."""

    def test_change_is_breaking_removed(self):
        """Test that REMOVED changes are breaking."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.REMOVED,
            path="test.key",
            entity_type=EntityType.KEY,
            old_value="value",
        )
        assert change.is_breaking is True

    def test_change_is_breaking_type_changed(self):
        """Test that TYPE_CHANGED changes are breaking."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.TYPE_CHANGED,
            path="test.key",
            entity_type=EntityType.KEY,
            old_value="42",
            new_value=42,
            metadata={"old_type": "string", "new_type": "integer"},
        )
        assert change.is_breaking is True

    def test_change_not_breaking_added(self):
        """Test that ADDED changes are not breaking."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.ADDED,
            path="test.key",
            entity_type=EntityType.KEY,
            new_value="value",
        )
        assert change.is_breaking is False

    def test_change_not_breaking_modified(self):
        """Test that MODIFIED changes are not breaking."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.MODIFIED,
            path="test.key",
            entity_type=EntityType.KEY,
            old_value="old",
            new_value="new",
        )
        assert change.is_breaking is False

    def test_change_description_added(self):
        """Test description for ADDED change."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.ADDED,
            path="config.new_key",
            entity_type=EntityType.KEY,
            new_value="value",
        )
        desc = change.description
        assert "Added" in desc
        assert "config.new_key" in desc

    def test_change_description_removed(self):
        """Test description for REMOVED change."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.REMOVED,
            path="config.old_key",
            entity_type=EntityType.KEY,
            old_value="value",
        )
        desc = change.description
        assert "Removed" in desc
        assert "config.old_key" in desc

    def test_change_description_modified(self):
        """Test change description generation."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.MODIFIED,
            path="config.timeout",
            entity_type=EntityType.KEY,
            old_value=30,
            new_value=10,
        )
        desc = change.description
        assert "Modified" in desc
        assert "config.timeout" in desc

    def test_change_description_renamed(self):
        """Test description for RENAMED change."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.RENAMED,
            path="config.new_name",
            entity_type=EntityType.KEY,
            old_value="value",
            new_value="value",
            metadata={"old_name": "old_name", "new_name": "new_name"},
        )
        desc = change.description
        assert "Renamed" in desc
        assert "old_name" in desc
        assert "new_name" in desc

    def test_change_description_type_changed(self):
        """Test description for TYPE_CHANGED change."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.TYPE_CHANGED,
            path="config.port",
            entity_type=EntityType.KEY,
            old_value="8080",
            new_value=8080,
            metadata={"old_type": "string", "new_type": "integer"},
        )
        desc = change.description
        assert "Type changed" in desc
        assert "string" in desc
        assert "integer" in desc

    def test_change_description_moved(self):
        """Test description for MOVED change."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.MOVED,
            path="config.section.key",
            entity_type=EntityType.KEY,
            old_value="value",
            new_value="value",
        )
        desc = change.description
        assert "Moved" in desc
        assert "config.section.key" in desc

    def test_change_description_unchanged(self):
        """Test description for UNCHANGED change."""
        from what_changed.normalize.base import EntityType

        change = Change(
            change_type=ChangeType.UNCHANGED,
            path="config.key",
            entity_type=EntityType.KEY,
            old_value="value",
            new_value="value",
        )
        desc = change.description
        assert "Unchanged" in desc
        assert "config.key" in desc


class TestChangeType:
    """Tests for ChangeType enum."""

    def test_change_type_values(self):
        """Test that all change types exist."""
        assert ChangeType.ADDED
        assert ChangeType.REMOVED
        assert ChangeType.MODIFIED
        assert ChangeType.RENAMED
        assert ChangeType.TYPE_CHANGED
        assert ChangeType.MOVED
        assert ChangeType.UNCHANGED


class TestDiffResult:
    """Tests for DiffResult dataclass."""

    def test_diff_result_creation(self):
        """Test creating a DiffResult."""
        result = DiffResult(
            source_a="file_a.json",
            source_b="file_b.json",
            type_a="json",
            type_b="json",
        )
        assert result.source_a == "file_a.json"
        assert result.has_changes is False
        assert result.total_changes == 0

    def test_diff_result_counts(self):
        """Test change count properties."""
        from what_changed.normalize.base import EntityType

        result = DiffResult(
            source_a="a",
            source_b="b",
            type_a="json",
            type_b="json",
            changes=[
                Change(change_type=ChangeType.ADDED, path="a", entity_type=EntityType.KEY),
                Change(change_type=ChangeType.REMOVED, path="b", entity_type=EntityType.KEY),
                Change(change_type=ChangeType.MODIFIED, path="c", entity_type=EntityType.KEY),
            ],
            added_count=1,
            removed_count=1,
            modified_count=1,
        )

        assert result.total_changes == 3
        assert result.added_count == 1
        assert result.removed_count == 1
        assert result.modified_count == 1
