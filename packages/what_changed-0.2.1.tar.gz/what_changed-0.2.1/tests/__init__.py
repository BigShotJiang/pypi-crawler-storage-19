"""Tests for what-changed."""
