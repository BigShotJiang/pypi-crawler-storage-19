"""Tests for git integration."""

import os
import subprocess
import tempfile
from pathlib import Path

import pytest

from what_changed.git.repository import GitRepository, GitRef, GitFile, GitError
from what_changed.git.compare import GitComparer, GitCompareSpec, parse_git_source, is_git_repo


class TestGitCompareSpec:
    """Tests for GitCompareSpec parsing."""

    def test_parse_double_dot(self):
        """Test parsing double dot syntax."""
        spec = GitCompareSpec.parse("HEAD~1..HEAD")
        assert spec.ref_a == "HEAD~1"
        assert spec.ref_b == "HEAD"
        assert spec.path is None

    def test_parse_triple_dot(self):
        """Test parsing triple dot syntax."""
        spec = GitCompareSpec.parse("main...feature")
        assert spec.ref_a == "main"
        assert spec.ref_b == "feature"

    def test_parse_with_path(self):
        """Test parsing with path suffix."""
        spec = GitCompareSpec.parse("v1.0..v2.0:src/config.json")
        assert spec.ref_a == "v1.0"
        assert spec.ref_b == "v2.0"
        assert spec.path == "src/config.json"

    def test_parse_with_directory_path(self):
        """Test parsing with directory path."""
        spec = GitCompareSpec.parse("main..HEAD:config/")
        assert spec.ref_a == "main"
        assert spec.ref_b == "HEAD"
        assert spec.path == "config/"

    def test_parse_branch_names(self):
        """Test parsing branch names."""
        spec = GitCompareSpec.parse("feature/auth..main")
        assert spec.ref_a == "feature/auth"
        assert spec.ref_b == "main"

    def test_parse_invalid_no_dots(self):
        """Test that single ref raises error."""
        with pytest.raises(ValueError, match="Invalid git comparison spec"):
            GitCompareSpec.parse("HEAD")

    def test_parse_invalid_missing_ref(self):
        """Test that missing ref raises error."""
        with pytest.raises(ValueError, match="Both refs must be specified"):
            GitCompareSpec.parse("HEAD..")

        with pytest.raises(ValueError, match="Both refs must be specified"):
            GitCompareSpec.parse("..HEAD")


class TestParseGitSource:
    """Tests for parse_git_source helper."""

    def test_valid_git_spec(self):
        """Test valid git spec returns GitCompareSpec."""
        result = parse_git_source("HEAD~1..HEAD")
        assert result is not None
        assert result.ref_a == "HEAD~1"

    def test_not_git_spec(self):
        """Test non-git source returns None."""
        assert parse_git_source("config.json") is None
        assert parse_git_source("/path/to/file") is None

    def test_relative_path_not_git_spec(self):
        """Test relative path with .. is not treated as git spec."""
        assert parse_git_source("../config.json") is None

    def test_invalid_git_spec_returns_none(self):
        """Test invalid git spec returns None."""
        assert parse_git_source("..HEAD") is None


@pytest.fixture
def git_repo(tmp_path: Path):
    """Create a temporary git repository with some commits."""
    repo_path = tmp_path / "test_repo"
    repo_path.mkdir()

    # Initialize repo
    subprocess.run(["git", "init"], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=repo_path,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test User"],
        cwd=repo_path,
        check=True,
        capture_output=True,
    )

    # Create initial commit
    config_file = repo_path / "config.json"
    config_file.write_text('{"timeout": 30, "debug": false}')
    subprocess.run(["git", "add", "."], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial commit"],
        cwd=repo_path,
        check=True,
        capture_output=True,
    )

    # Create second commit with changes
    config_file.write_text('{"timeout": 10, "debug": true, "new_key": "value"}')
    subprocess.run(["git", "add", "."], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Update config"],
        cwd=repo_path,
        check=True,
        capture_output=True,
    )

    return repo_path


class TestGitRepository:
    """Tests for GitRepository class."""

    def test_init_valid_repo(self, git_repo: Path):
        """Test initializing with valid repo."""
        repo = GitRepository(git_repo)
        assert repo.path == git_repo

    def test_init_invalid_repo(self, tmp_path: Path):
        """Test initializing with invalid repo raises error."""
        with pytest.raises(GitError, match="Not a git repository"):
            GitRepository(tmp_path)

    def test_resolve_ref_head(self, git_repo: Path):
        """Test resolving HEAD ref."""
        repo = GitRepository(git_repo)
        ref = repo.resolve_ref("HEAD")
        assert ref.ref == "HEAD"
        assert len(ref.commit_sha) == 40
        assert len(ref.short_sha) == 7

    def test_resolve_ref_head_tilde(self, git_repo: Path):
        """Test resolving HEAD~1 ref."""
        repo = GitRepository(git_repo)
        ref = repo.resolve_ref("HEAD~1")
        assert ref.ref == "HEAD~1"
        assert len(ref.commit_sha) == 40

    def test_resolve_invalid_ref(self, git_repo: Path):
        """Test resolving invalid ref raises error."""
        repo = GitRepository(git_repo)
        with pytest.raises(GitError, match="Cannot resolve reference"):
            repo.resolve_ref("nonexistent-branch-xyz")

    def test_get_file_at_ref(self, git_repo: Path):
        """Test getting file content at ref."""
        repo = GitRepository(git_repo)
        git_file = repo.get_file_at_ref("HEAD", "config.json")
        assert git_file.path == "config.json"
        assert b"timeout" in git_file.content
        assert b"10" in git_file.content  # New value

    def test_get_file_at_older_ref(self, git_repo: Path):
        """Test getting file content at older ref."""
        repo = GitRepository(git_repo)
        git_file = repo.get_file_at_ref("HEAD~1", "config.json")
        assert b"30" in git_file.content  # Old value

    def test_get_nonexistent_file(self, git_repo: Path):
        """Test getting nonexistent file raises error."""
        repo = GitRepository(git_repo)
        with pytest.raises(GitError, match="Cannot get file"):
            repo.get_file_at_ref("HEAD", "nonexistent.json")

    def test_extract_file_to_temp(self, git_repo: Path):
        """Test extracting file to temp location."""
        with GitRepository(git_repo) as repo:
            temp_path = repo.extract_file_to_temp("HEAD", "config.json")
            assert temp_path.exists()
            assert temp_path.suffix == ".json"
            content = temp_path.read_text()
            assert "timeout" in content

    def test_list_changed_files(self, git_repo: Path):
        """Test listing changed files between refs."""
        repo = GitRepository(git_repo)
        files = repo.list_changed_files("HEAD~1", "HEAD")
        assert "config.json" in files

    def test_get_commit_info(self, git_repo: Path):
        """Test getting commit info."""
        repo = GitRepository(git_repo)
        info = repo.get_commit_info("HEAD")
        assert len(info["sha"]) == 40
        assert info["author_name"] == "Test User"
        assert info["subject"] == "Update config"

    def test_cleanup(self, git_repo: Path):
        """Test cleanup removes temp files."""
        repo = GitRepository(git_repo)
        temp_path = repo.extract_file_to_temp("HEAD", "config.json")
        assert temp_path.exists()

        repo.cleanup()
        assert not temp_path.exists()

    def test_context_manager(self, git_repo: Path):
        """Test context manager cleans up."""
        with GitRepository(git_repo) as repo:
            temp_path = repo.extract_file_to_temp("HEAD", "config.json")
            assert temp_path.exists()

        assert not temp_path.exists()


class TestGitComparer:
    """Tests for GitComparer class."""

    def test_extract_for_comparison_file(self, git_repo: Path):
        """Test extracting single file for comparison."""
        spec = GitCompareSpec(ref_a="HEAD~1", ref_b="HEAD", path="config.json")

        with GitComparer(git_repo) as comparer:
            path_a, path_b = comparer.extract_for_comparison(spec)

            assert path_a.exists()
            assert path_b.exists()

            content_a = path_a.read_text()
            content_b = path_b.read_text()

            assert "30" in content_a  # Old timeout
            assert "10" in content_b  # New timeout

    def test_get_changed_files(self, git_repo: Path):
        """Test getting changed files."""
        spec = GitCompareSpec(ref_a="HEAD~1", ref_b="HEAD")

        with GitComparer(git_repo) as comparer:
            files = comparer.get_changed_files(spec)
            assert "config.json" in files

    def test_get_comparison_summary(self, git_repo: Path):
        """Test getting comparison summary."""
        spec = GitCompareSpec(ref_a="HEAD~1", ref_b="HEAD")

        with GitComparer(git_repo) as comparer:
            summary = comparer.get_comparison_summary(spec)

            assert "ref_a" in summary
            assert "ref_b" in summary
            assert summary["changed_files_count"] >= 1
            assert summary["ref_b"]["subject"] == "Update config"


class TestIsGitRepo:
    """Tests for is_git_repo helper."""

    def test_valid_repo(self, git_repo: Path):
        """Test valid repo returns True."""
        assert is_git_repo(git_repo) is True

    def test_invalid_repo(self, tmp_path: Path):
        """Test non-repo returns False."""
        assert is_git_repo(tmp_path) is False


class TestGitRef:
    """Tests for GitRef dataclass."""

    def test_short_sha_auto_generated(self):
        """Test short_sha is auto-generated."""
        ref = GitRef(
            ref="HEAD",
            commit_sha="abc123def456789012345678901234567890abcd",
            ref_type="commit",
        )
        assert ref.short_sha == "abc123d"

    def test_short_sha_preserved(self):
        """Test explicit short_sha is preserved."""
        ref = GitRef(
            ref="HEAD",
            commit_sha="abc123def456789012345678901234567890abcd",
            ref_type="commit",
            short_sha="custom",
        )
        assert ref.short_sha == "custom"
