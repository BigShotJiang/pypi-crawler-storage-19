"""Tests for change graph model and builder."""

import json
from pathlib import Path

import pytest

from what_changed.diff.semantic_diff import Change, ChangeType, DiffResult
from what_changed.normalize.base import EntityType
from what_changed.graph.model import (
    ChangeGraph,
    ChangeNode,
    ChangeEdge,
    NodeType,
    EdgeType,
    RiskLevel,
)
from what_changed.graph.builder import GraphBuilder


class TestRiskLevel:
    """Tests for RiskLevel enum."""

    def test_risk_level_values(self):
        """Test that all risk levels exist."""
        assert RiskLevel.SAFE
        assert RiskLevel.RISKY
        assert RiskLevel.BREAKING

    def test_from_score_safe(self):
        """Test from_score returns SAFE for low scores."""
        assert RiskLevel.from_score(0) == RiskLevel.SAFE
        assert RiskLevel.from_score(4) == RiskLevel.SAFE

    def test_from_score_risky(self):
        """Test from_score returns RISKY for medium scores."""
        assert RiskLevel.from_score(5) == RiskLevel.RISKY
        assert RiskLevel.from_score(7) == RiskLevel.RISKY

    def test_from_score_breaking(self):
        """Test from_score returns BREAKING for high scores."""
        assert RiskLevel.from_score(8) == RiskLevel.BREAKING
        assert RiskLevel.from_score(10) == RiskLevel.BREAKING
        assert RiskLevel.from_score(100) == RiskLevel.BREAKING


class TestNodeType:
    """Tests for NodeType enum."""

    def test_node_type_values(self):
        """Test that all node types exist."""
        assert NodeType.FILE
        assert NodeType.DIRECTORY
        assert NodeType.ENTITY
        assert NodeType.ENDPOINT
        assert NodeType.CONFIG_KEY
        assert NodeType.SYMBOL
        assert NodeType.ROOT


class TestEdgeType:
    """Tests for EdgeType enum."""

    def test_edge_type_values(self):
        """Test that all edge types exist."""
        assert EdgeType.ADDED
        assert EdgeType.REMOVED
        assert EdgeType.MODIFIED
        assert EdgeType.RENAMED
        assert EdgeType.DEPENDS_ON
        assert EdgeType.CONTAINS
        assert EdgeType.REFERENCES


class TestChangeNode:
    """Tests for ChangeNode dataclass."""

    def test_change_node_creation(self):
        """Test creating a ChangeNode."""
        node = ChangeNode(
            id="test-id",
            name="test",
            node_type=NodeType.CONFIG_KEY,
            path="config.test",
        )
        assert node.id == "test-id"
        assert node.name == "test"
        assert node.node_type == NodeType.CONFIG_KEY
        assert node.path == "config.test"

    def test_change_node_defaults(self):
        """Test ChangeNode default values."""
        node = ChangeNode(
            id="test",
            name="test",
            node_type=NodeType.ENTITY,
            path="test",
        )
        assert node.change_type is None
        assert node.change is None
        assert node.risk_score == 0
        assert node.risk_level == RiskLevel.SAFE
        assert node.metadata == {}

    def test_change_node_with_change(self):
        """Test ChangeNode with change information."""
        change = Change(
            change_type=ChangeType.MODIFIED,
            path="config.value",
            entity_type=EntityType.KEY,
            old_value="old",
            new_value="new",
        )
        node = ChangeNode(
            id="test",
            name="value",
            node_type=NodeType.CONFIG_KEY,
            path="config.value",
            change_type=ChangeType.MODIFIED,
            change=change,
            risk_score=5,
            risk_level=RiskLevel.RISKY,
        )
        assert node.change_type == ChangeType.MODIFIED
        assert node.change == change
        assert node.risk_score == 5
        assert node.risk_level == RiskLevel.RISKY

    def test_change_node_hash(self):
        """Test ChangeNode hashing is based on ID."""
        node1 = ChangeNode(id="same-id", name="a", node_type=NodeType.ENTITY, path="a")
        node2 = ChangeNode(id="same-id", name="b", node_type=NodeType.FILE, path="b")
        assert hash(node1) == hash(node2)

    def test_change_node_equality(self):
        """Test ChangeNode equality is based on ID."""
        node1 = ChangeNode(id="same-id", name="a", node_type=NodeType.ENTITY, path="a")
        node2 = ChangeNode(id="same-id", name="b", node_type=NodeType.FILE, path="b")
        node3 = ChangeNode(id="diff-id", name="a", node_type=NodeType.ENTITY, path="a")
        assert node1 == node2
        assert node1 != node3


class TestChangeEdge:
    """Tests for ChangeEdge dataclass."""

    def test_change_edge_creation(self):
        """Test creating a ChangeEdge."""
        edge = ChangeEdge(
            source_id="src",
            target_id="tgt",
            edge_type=EdgeType.CONTAINS,
        )
        assert edge.source_id == "src"
        assert edge.target_id == "tgt"
        assert edge.edge_type == EdgeType.CONTAINS
        assert edge.metadata == {}

    def test_change_edge_with_metadata(self):
        """Test ChangeEdge with metadata."""
        edge = ChangeEdge(
            source_id="src",
            target_id="tgt",
            edge_type=EdgeType.MODIFIED,
            metadata={"change_type": "MODIFIED"},
        )
        assert edge.metadata == {"change_type": "MODIFIED"}


class TestChangeGraph:
    """Tests for ChangeGraph class."""

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        """Create an empty ChangeGraph."""
        return ChangeGraph()

    @pytest.fixture
    def sample_nodes(self) -> list[ChangeNode]:
        """Create sample nodes for testing."""
        return [
            ChangeNode(id="root", name="Root", node_type=NodeType.ROOT, path=""),
            ChangeNode(id="parent", name="Parent", node_type=NodeType.ENTITY, path="parent"),
            ChangeNode(id="child1", name="Child1", node_type=NodeType.CONFIG_KEY, path="parent.child1"),
            ChangeNode(id="child2", name="Child2", node_type=NodeType.CONFIG_KEY, path="parent.child2"),
        ]

    def test_add_node(self, graph: ChangeGraph):
        """Test adding a node."""
        node = ChangeNode(id="test", name="test", node_type=NodeType.ENTITY, path="test")
        graph.add_node(node)
        assert graph.node_count == 1
        assert graph.get_node("test") == node

    def test_add_edge(self, graph: ChangeGraph, sample_nodes: list[ChangeNode]):
        """Test adding an edge."""
        for node in sample_nodes:
            graph.add_node(node)

        edge = ChangeEdge(
            source_id="parent",
            target_id="child1",
            edge_type=EdgeType.CONTAINS,
        )
        graph.add_edge(edge)
        assert graph.edge_count == 1

    def test_get_node(self, graph: ChangeGraph):
        """Test getting a node by ID."""
        node = ChangeNode(id="test", name="test", node_type=NodeType.ENTITY, path="test")
        graph.add_node(node)

        found = graph.get_node("test")
        assert found == node

        not_found = graph.get_node("nonexistent")
        assert not_found is None

    def test_get_nodes(self, graph: ChangeGraph, sample_nodes: list[ChangeNode]):
        """Test iterating over nodes."""
        for node in sample_nodes:
            graph.add_node(node)

        nodes_list = list(graph.get_nodes())
        assert len(nodes_list) == len(sample_nodes)

    def test_get_children(self, graph: ChangeGraph, sample_nodes: list[ChangeNode]):
        """Test getting child nodes."""
        for node in sample_nodes:
            graph.add_node(node)

        graph.add_edge(ChangeEdge(source_id="parent", target_id="child1", edge_type=EdgeType.CONTAINS))
        graph.add_edge(ChangeEdge(source_id="parent", target_id="child2", edge_type=EdgeType.CONTAINS))

        children = graph.get_children("parent")
        assert len(children) == 2
        child_ids = {c.id for c in children}
        assert child_ids == {"child1", "child2"}

    def test_get_parents(self, graph: ChangeGraph, sample_nodes: list[ChangeNode]):
        """Test getting parent nodes."""
        for node in sample_nodes:
            graph.add_node(node)

        graph.add_edge(ChangeEdge(source_id="parent", target_id="child1", edge_type=EdgeType.CONTAINS))

        parents = graph.get_parents("child1")
        assert len(parents) == 1
        assert parents[0].id == "parent"

    def test_get_descendants(self, graph: ChangeGraph, sample_nodes: list[ChangeNode]):
        """Test getting transitive descendants."""
        for node in sample_nodes:
            graph.add_node(node)

        graph.add_edge(ChangeEdge(source_id="root", target_id="parent", edge_type=EdgeType.CONTAINS))
        graph.add_edge(ChangeEdge(source_id="parent", target_id="child1", edge_type=EdgeType.CONTAINS))
        graph.add_edge(ChangeEdge(source_id="parent", target_id="child2", edge_type=EdgeType.CONTAINS))

        descendants = graph.get_descendants("root")
        assert len(descendants) == 3
        desc_ids = {d.id for d in descendants}
        assert desc_ids == {"parent", "child1", "child2"}

    def test_get_ancestors(self, graph: ChangeGraph, sample_nodes: list[ChangeNode]):
        """Test getting transitive ancestors."""
        for node in sample_nodes:
            graph.add_node(node)

        graph.add_edge(ChangeEdge(source_id="root", target_id="parent", edge_type=EdgeType.CONTAINS))
        graph.add_edge(ChangeEdge(source_id="parent", target_id="child1", edge_type=EdgeType.CONTAINS))

        ancestors = graph.get_ancestors("child1")
        assert len(ancestors) == 2
        anc_ids = {a.id for a in ancestors}
        assert anc_ids == {"root", "parent"}

    def test_root_property(self, graph: ChangeGraph):
        """Test root node property."""
        assert graph.root is None

        root = ChangeNode(id="root", name="Root", node_type=NodeType.ROOT, path="")
        graph.add_node(root)
        graph.root = root

        assert graph.root == root

    def test_get_nodes_by_risk(self, graph: ChangeGraph):
        """Test filtering nodes by risk level."""
        nodes = [
            ChangeNode(id="safe", name="safe", node_type=NodeType.ENTITY, path="safe", risk_level=RiskLevel.SAFE),
            ChangeNode(id="risky", name="risky", node_type=NodeType.ENTITY, path="risky", risk_level=RiskLevel.RISKY),
            ChangeNode(id="breaking", name="breaking", node_type=NodeType.ENTITY, path="breaking", risk_level=RiskLevel.BREAKING),
        ]
        for node in nodes:
            graph.add_node(node)

        safe = graph.get_nodes_by_risk(RiskLevel.SAFE)
        assert len(safe) == 1
        assert safe[0].id == "safe"

        breaking = graph.get_breaking_changes()
        assert len(breaking) == 1
        assert breaking[0].id == "breaking"

    def test_get_nodes_by_change_type(self, graph: ChangeGraph):
        """Test filtering nodes by change type."""
        nodes = [
            ChangeNode(id="added", name="added", node_type=NodeType.ENTITY, path="added", change_type=ChangeType.ADDED),
            ChangeNode(id="removed", name="removed", node_type=NodeType.ENTITY, path="removed", change_type=ChangeType.REMOVED),
        ]
        for node in nodes:
            graph.add_node(node)

        added = graph.get_nodes_by_change_type(ChangeType.ADDED)
        assert len(added) == 1
        assert added[0].id == "added"

    def test_compute_impact_score(self, graph: ChangeGraph):
        """Test computing impact score."""
        root = ChangeNode(id="root", name="root", node_type=NodeType.ROOT, path="", risk_score=5)
        child = ChangeNode(id="child", name="child", node_type=NodeType.ENTITY, path="child", risk_score=3)
        graph.add_node(root)
        graph.add_node(child)
        graph.add_edge(ChangeEdge(source_id="root", target_id="child", edge_type=EdgeType.CONTAINS))

        impact = graph.compute_impact_score("root")
        assert impact == 8  # 5 + 3

    def test_get_most_impactful(self, graph: ChangeGraph):
        """Test getting most impactful nodes."""
        nodes = [
            ChangeNode(id="low", name="low", node_type=NodeType.ENTITY, path="low", risk_score=1),
            ChangeNode(id="high", name="high", node_type=NodeType.ENTITY, path="high", risk_score=10),
            ChangeNode(id="medium", name="medium", node_type=NodeType.ENTITY, path="medium", risk_score=5),
        ]
        for node in nodes:
            graph.add_node(node)

        most_impactful = graph.get_most_impactful(2)
        assert len(most_impactful) == 2
        assert most_impactful[0].id == "high"
        assert most_impactful[1].id == "medium"

    def test_to_dict(self, graph: ChangeGraph, sample_nodes: list[ChangeNode]):
        """Test converting graph to dictionary."""
        for node in sample_nodes[:2]:
            graph.add_node(node)

        graph.add_edge(ChangeEdge(source_id="root", target_id="parent", edge_type=EdgeType.CONTAINS))

        d = graph.to_dict()
        assert "nodes" in d
        assert "edges" in d
        assert "summary" in d
        assert len(d["nodes"]) == 2
        assert len(d["edges"]) == 1
        assert d["summary"]["total_nodes"] == 2
        assert d["summary"]["total_edges"] == 1


class TestGraphBuilder:
    """Tests for GraphBuilder class."""

    @pytest.fixture
    def builder(self) -> GraphBuilder:
        """Create a GraphBuilder instance."""
        return GraphBuilder()

    @pytest.fixture
    def simple_diff_result(self) -> DiffResult:
        """Create a simple DiffResult for testing."""
        return DiffResult(
            source_a="file_a.json",
            source_b="file_b.json",
            type_a="json",
            type_b="json",
            changes=[
                Change(
                    change_type=ChangeType.MODIFIED,
                    path="config.value",
                    entity_type=EntityType.KEY,
                    old_value="old",
                    new_value="new",
                ),
                Change(
                    change_type=ChangeType.ADDED,
                    path="config.new_key",
                    entity_type=EntityType.KEY,
                    new_value="value",
                ),
            ],
            added_count=1,
            modified_count=1,
        )

    def test_build_creates_graph(self, builder: GraphBuilder, simple_diff_result: DiffResult):
        """Test that build creates a ChangeGraph."""
        graph = builder.build(simple_diff_result)
        assert isinstance(graph, ChangeGraph)
        assert graph.node_count > 0

    def test_build_creates_root(self, builder: GraphBuilder, simple_diff_result: DiffResult):
        """Test that build creates a root node."""
        graph = builder.build(simple_diff_result)
        assert graph.root is not None
        assert graph.root.node_type == NodeType.ROOT

    def test_build_root_metadata(self, builder: GraphBuilder, simple_diff_result: DiffResult):
        """Test that root node has correct metadata."""
        graph = builder.build(simple_diff_result)
        root = graph.root
        assert root.metadata["source_a"] == "file_a.json"
        assert root.metadata["source_b"] == "file_b.json"
        assert root.metadata["type_a"] == "json"
        assert root.metadata["type_b"] == "json"

    def test_build_creates_change_nodes(self, builder: GraphBuilder, simple_diff_result: DiffResult):
        """Test that build creates nodes for each change."""
        graph = builder.build(simple_diff_result)

        # Find change nodes (exclude root and intermediate nodes)
        change_nodes = [n for n in graph.get_nodes() if n.change is not None]
        assert len(change_nodes) == 2

    def test_build_node_change_types(self, builder: GraphBuilder, simple_diff_result: DiffResult):
        """Test that nodes have correct change types."""
        graph = builder.build(simple_diff_result)

        change_nodes = [n for n in graph.get_nodes() if n.change is not None]
        change_types = {n.change_type for n in change_nodes}
        assert ChangeType.MODIFIED in change_types
        assert ChangeType.ADDED in change_types

    def test_build_creates_hierarchy(self, builder: GraphBuilder, simple_diff_result: DiffResult):
        """Test that build creates hierarchical edges."""
        graph = builder.build(simple_diff_result)

        # Root should have children
        children = graph.get_children("_root")
        assert len(children) > 0

    def test_build_with_deep_paths(self, builder: GraphBuilder):
        """Test building graph with deeply nested paths."""
        diff_result = DiffResult(
            source_a="a.json",
            source_b="b.json",
            type_a="json",
            type_b="json",
            changes=[
                Change(
                    change_type=ChangeType.MODIFIED,
                    path="level1.level2.level3.value",
                    entity_type=EntityType.KEY,
                    old_value="old",
                    new_value="new",
                ),
            ],
            modified_count=1,
        )

        graph = builder.build(diff_result)

        # Should have intermediate nodes
        assert graph.node_count > 2  # Root + change + intermediates

    def test_build_with_file_paths(self, builder: GraphBuilder):
        """Test building graph with file paths."""
        diff_result = DiffResult(
            source_a="dir_a",
            source_b="dir_b",
            type_a="directory",
            type_b="directory",
            changes=[
                Change(
                    change_type=ChangeType.ADDED,
                    path="src/utils/helper.py",
                    entity_type=EntityType.FILE,
                    new_value="content",
                ),
            ],
            added_count=1,
        )

        graph = builder.build(diff_result)
        assert graph.node_count > 1

    def test_build_with_array_paths(self, builder: GraphBuilder):
        """Test building graph with array index paths."""
        diff_result = DiffResult(
            source_a="a.json",
            source_b="b.json",
            type_a="json",
            type_b="json",
            changes=[
                Change(
                    change_type=ChangeType.MODIFIED,
                    path="items[0].name",
                    entity_type=EntityType.KEY,
                    old_value="old",
                    new_value="new",
                ),
            ],
            modified_count=1,
        )

        graph = builder.build(diff_result)
        assert graph.node_count > 1

    def test_build_node_metadata(self, builder: GraphBuilder, simple_diff_result: DiffResult):
        """Test that change nodes have metadata."""
        graph = builder.build(simple_diff_result)

        change_nodes = [n for n in graph.get_nodes() if n.change is not None]
        for node in change_nodes:
            assert "entity_type" in node.metadata

    def test_build_with_empty_diff(self, builder: GraphBuilder):
        """Test building graph with no changes."""
        diff_result = DiffResult(
            source_a="a.json",
            source_b="b.json",
            type_a="json",
            type_b="json",
            changes=[],
        )

        graph = builder.build(diff_result)

        # Should still have root node
        assert graph.node_count == 1
        assert graph.root is not None

    def test_builder_include_unchanged(self):
        """Test builder with include_unchanged option."""
        builder = GraphBuilder(include_unchanged=True)
        assert builder.include_unchanged is True

        builder2 = GraphBuilder(include_unchanged=False)
        assert builder2.include_unchanged is False

    def test_value_summarization(self, builder: GraphBuilder):
        """Test that values are summarized in node metadata."""
        diff_result = DiffResult(
            source_a="a.json",
            source_b="b.json",
            type_a="json",
            type_b="json",
            changes=[
                Change(
                    change_type=ChangeType.MODIFIED,
                    path="large_value",
                    entity_type=EntityType.KEY,
                    old_value={"key" + str(i): i for i in range(100)},
                    new_value={"key" + str(i): i for i in range(50)},
                ),
            ],
            modified_count=1,
        )

        graph = builder.build(diff_result)

        change_nodes = [n for n in graph.get_nodes() if n.change is not None]
        assert len(change_nodes) == 1
        node = change_nodes[0]

        # Should be summarized, not raw dict
        assert "<dict with" in str(node.metadata.get("old_value", ""))


class TestGraphIntegration:
    """Integration tests for graph building with real diff results."""

    def test_build_from_json_diff(self, temp_dir: Path):
        """Test building graph from JSON file diff."""
        from what_changed.normalize import create_default_registry
        from what_changed.diff.semantic_diff import SemanticDiff

        # Create test files
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"name": "test", "version": "1.0"}))
        file_b.write_text(json.dumps({"name": "test", "version": "2.0", "new": "key"}))

        # Normalize and diff
        registry = create_default_registry()
        obj_a = registry.normalize(str(file_a))
        obj_b = registry.normalize(str(file_b))

        differ = SemanticDiff()
        diff_result = differ.diff(obj_a, obj_b)

        # Build graph
        builder = GraphBuilder()
        graph = builder.build(diff_result)

        assert graph.node_count > 0
        assert graph.root is not None

        # Should have changes
        change_nodes = [n for n in graph.get_nodes() if n.change is not None]
        assert len(change_nodes) > 0
