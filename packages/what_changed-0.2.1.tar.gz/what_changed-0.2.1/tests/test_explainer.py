"""Tests for explanation generator."""

import pytest

from what_changed.diff.semantic_diff import ChangeType
from what_changed.graph.model import (
    ChangeGraph,
    ChangeNode,
    NodeType,
    RiskLevel,
)
from what_changed.rules.base import RuleResult
from what_changed.explain.explainer import (
    Explainer,
    Explanation,
    ConfidenceLevel,
)


class TestConfidenceLevel:
    """Tests for ConfidenceLevel enum."""

    def test_confidence_level_values(self):
        """Test that all confidence levels exist."""
        assert ConfidenceLevel.HIGH
        assert ConfidenceLevel.MEDIUM
        assert ConfidenceLevel.LOW


class TestExplanation:
    """Tests for Explanation dataclass."""

    def test_explanation_creation(self):
        """Test creating an Explanation."""
        explanation = Explanation(
            entity="timeout",
            change_summary="Changed: timeout (30 -> 10)",
            impact="Timeout decreased significantly",
            what_could_break="Services may timeout more frequently",
            confidence=ConfidenceLevel.HIGH,
            risk_level=RiskLevel.RISKY,
            risk_score=7,
            path="config.timeout",
        )
        assert explanation.entity == "timeout"
        assert explanation.risk_score == 7
        assert explanation.confidence == ConfidenceLevel.HIGH

    def test_explanation_defaults(self):
        """Test Explanation default values."""
        explanation = Explanation(
            entity="test",
            change_summary="Test change",
            impact="Test impact",
            what_could_break="Nothing",
            confidence=ConfidenceLevel.LOW,
            risk_level=RiskLevel.SAFE,
            risk_score=0,
            path="test.path",
        )
        assert explanation.rule_matches == []
        assert explanation.details == {}

    def test_explanation_to_dict(self):
        """Test converting Explanation to dictionary."""
        explanation = Explanation(
            entity="key",
            change_summary="Added: key",
            impact="Low impact",
            what_could_break="Nothing",
            confidence=ConfidenceLevel.MEDIUM,
            risk_level=RiskLevel.SAFE,
            risk_score=2,
            path="config.key",
            rule_matches=["Rule matched"],
            details={"new_value": "test"},
        )

        d = explanation.to_dict()
        assert d["entity"] == "key"
        assert d["change"] == "Added: key"
        assert d["confidence"] == "medium"
        assert d["risk_level"] == "safe"
        assert d["risk_score"] == 2
        assert d["rule_matches"] == ["Rule matched"]


class TestExplainer:
    """Tests for Explainer class."""

    @pytest.fixture
    def explainer(self) -> Explainer:
        """Create an Explainer instance."""
        return Explainer()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        """Create a simple ChangeGraph."""
        g = ChangeGraph()
        root = ChangeNode(id="_root", name="Root", node_type=NodeType.ROOT, path="")
        g.add_node(root)
        g.root = root
        return g

    def test_explain_added(self, explainer: Explainer):
        """Test explaining an added entity."""
        node = ChangeNode(
            id="added",
            name="new_key",
            node_type=NodeType.CONFIG_KEY,
            path="config.new_key",
            change_type=ChangeType.ADDED,
            risk_score=2,
            risk_level=RiskLevel.SAFE,
        )

        explanation = explainer.explain(node, [])
        assert "Added" in explanation.change_summary
        assert explanation.entity == "new_key"
        assert explanation.risk_level == RiskLevel.SAFE

    def test_explain_removed(self, explainer: Explainer):
        """Test explaining a removed entity."""
        node = ChangeNode(
            id="removed",
            name="old_key",
            node_type=NodeType.CONFIG_KEY,
            path="config.old_key",
            change_type=ChangeType.REMOVED,
            risk_score=7,
            risk_level=RiskLevel.RISKY,
        )

        rule_result = RuleResult(
            rule_name="removed_entity",
            matched=True,
            score=7,
            reason="Removed config_key: old_key",
        )

        explanation = explainer.explain(node, [rule_result])
        assert "Removed" in explanation.change_summary
        assert explanation.risk_score == 7
        assert len(explanation.rule_matches) == 1

    def test_explain_modified(self, explainer: Explainer):
        """Test explaining a modified entity."""
        node = ChangeNode(
            id="modified",
            name="timeout",
            node_type=NodeType.CONFIG_KEY,
            path="config.timeout",
            change_type=ChangeType.MODIFIED,
            risk_score=5,
            risk_level=RiskLevel.RISKY,
            metadata={"old_value": "30", "new_value": "10"},
        )

        explanation = explainer.explain(node, [])
        assert "Changed" in explanation.change_summary
        assert "30" in explanation.change_summary
        assert "10" in explanation.change_summary

    def test_explain_type_changed(self, explainer: Explainer):
        """Test explaining a type change."""
        node = ChangeNode(
            id="type_changed",
            name="port",
            node_type=NodeType.CONFIG_KEY,
            path="config.port",
            change_type=ChangeType.TYPE_CHANGED,
            risk_score=9,
            risk_level=RiskLevel.BREAKING,
            metadata={"old_type": "string", "new_type": "integer"},
        )

        explanation = explainer.explain(node, [])
        assert "Type changed" in explanation.change_summary
        assert "string" in explanation.change_summary
        assert "integer" in explanation.change_summary

    def test_explain_renamed(self, explainer: Explainer):
        """Test explaining a renamed entity."""
        node = ChangeNode(
            id="renamed",
            name="new_name",
            node_type=NodeType.CONFIG_KEY,
            path="config.new_name",
            change_type=ChangeType.RENAMED,
            risk_score=6,
            risk_level=RiskLevel.RISKY,
            metadata={"old_name": "old_name", "new_name": "new_name"},
        )

        explanation = explainer.explain(node, [])
        assert "Renamed" in explanation.change_summary
        assert "old_name" in explanation.change_summary

    def test_confidence_no_rules(self, explainer: Explainer):
        """Test confidence is LOW when no rules match."""
        node = ChangeNode(
            id="test",
            name="test",
            node_type=NodeType.ENTITY,
            path="test",
            change_type=ChangeType.MODIFIED,
            risk_score=0,
            risk_level=RiskLevel.SAFE,
        )

        explanation = explainer.explain(node, [])
        assert explanation.confidence == ConfidenceLevel.LOW

    def test_confidence_high_score_rule(self, explainer: Explainer):
        """Test confidence is HIGH when high-scoring rule matches."""
        node = ChangeNode(
            id="test",
            name="password",
            node_type=NodeType.CONFIG_KEY,
            path="config.password",
            change_type=ChangeType.MODIFIED,
            risk_score=9,
            risk_level=RiskLevel.BREAKING,
        )

        rule_result = RuleResult(
            rule_name="critical_path",
            matched=True,
            score=9,
            reason="Change to security-critical path",
        )

        explanation = explainer.explain(node, [rule_result])
        assert explanation.confidence == ConfidenceLevel.HIGH

    def test_confidence_many_rules(self, explainer: Explainer):
        """Test confidence is HIGH when many rules match."""
        node = ChangeNode(
            id="test",
            name="database_url",
            node_type=NodeType.CONFIG_KEY,
            path="config.database_url",
            change_type=ChangeType.MODIFIED,
            risk_score=7,
            risk_level=RiskLevel.RISKY,
        )

        rule_results = [
            RuleResult(rule_name="rule1", matched=True, score=3, reason="Reason 1"),
            RuleResult(rule_name="rule2", matched=True, score=4, reason="Reason 2"),
            RuleResult(rule_name="rule3", matched=True, score=4, reason="Reason 3"),
        ]

        explanation = explainer.explain(node, rule_results)
        assert explanation.confidence == ConfidenceLevel.HIGH

    def test_explain_graph(self, explainer: Explainer, graph: ChangeGraph):
        """Test explaining all nodes in a graph."""
        # Add some change nodes
        node1 = ChangeNode(
            id="high_risk",
            name="password",
            node_type=NodeType.CONFIG_KEY,
            path="config.password",
            change_type=ChangeType.REMOVED,
            risk_score=9,
            risk_level=RiskLevel.BREAKING,
        )
        node2 = ChangeNode(
            id="low_risk",
            name="description",
            node_type=NodeType.CONFIG_KEY,
            path="config.description",
            change_type=ChangeType.MODIFIED,
            risk_score=2,
            risk_level=RiskLevel.SAFE,
        )
        graph.add_node(node1)
        graph.add_node(node2)

        rule_results = {
            "high_risk": [RuleResult(rule_name="test", matched=True, score=9, reason="Critical")],
            "low_risk": [RuleResult(rule_name="test", matched=True, score=2, reason="Minor")],
        }

        explanations = explainer.explain_graph(graph, rule_results)

        assert len(explanations) == 2
        # Should be sorted by risk score descending
        assert explanations[0].risk_score >= explanations[1].risk_score
        assert explanations[0].entity == "password"

    def test_explain_graph_min_risk(self, explainer: Explainer, graph: ChangeGraph):
        """Test filtering by minimum risk level."""
        node1 = ChangeNode(
            id="risky",
            name="timeout",
            node_type=NodeType.CONFIG_KEY,
            path="config.timeout",
            change_type=ChangeType.MODIFIED,
            risk_score=6,
            risk_level=RiskLevel.RISKY,
        )
        node2 = ChangeNode(
            id="safe",
            name="comment",
            node_type=NodeType.CONFIG_KEY,
            path="config.comment",
            change_type=ChangeType.MODIFIED,
            risk_score=1,
            risk_level=RiskLevel.SAFE,
        )
        graph.add_node(node1)
        graph.add_node(node2)

        # Only include RISKY and above
        explanations = explainer.explain_graph(graph, {}, min_risk=RiskLevel.RISKY)

        assert len(explanations) == 1
        assert explanations[0].entity == "timeout"

    def test_explain_graph_skips_root(self, explainer: Explainer, graph: ChangeGraph):
        """Test that root node is skipped."""
        explanations = explainer.explain_graph(graph, {})
        assert len(explanations) == 0

    def test_impact_from_template(self, explainer: Explainer):
        """Test that impact is generated from template."""
        node = ChangeNode(
            id="test",
            name="key",
            node_type=NodeType.CONFIG_KEY,
            path="config.key",
            change_type=ChangeType.REMOVED,
            risk_score=8,
            risk_level=RiskLevel.BREAKING,
        )

        explanation = explainer.explain(node, [])
        # Should use the REMOVED + BREAKING template
        assert "failure" in explanation.impact.lower() or "depend" in explanation.impact.lower()

    def test_impact_from_rule_reason(self, explainer: Explainer):
        """Test that impact uses rule reason when available."""
        node = ChangeNode(
            id="test",
            name="timeout",
            node_type=NodeType.CONFIG_KEY,
            path="config.timeout",
            change_type=ChangeType.MODIFIED,
            risk_score=7,
            risk_level=RiskLevel.RISKY,
        )

        rule_result = RuleResult(
            rule_name="timeout_decreased",
            matched=True,
            score=7,
            reason="Timeout decreased by 67%",
        )

        explanation = explainer.explain(node, [rule_result])
        assert "67%" in explanation.impact

    def test_what_could_break_removed(self, explainer: Explainer):
        """Test what_could_break for removed entities."""
        node = ChangeNode(
            id="test",
            name="api_key",
            node_type=NodeType.CONFIG_KEY,
            path="config.api_key",
            change_type=ChangeType.REMOVED,
            risk_score=7,
            risk_level=RiskLevel.RISKY,
        )

        explanation = explainer.explain(node, [])
        assert "config.api_key" in explanation.what_could_break or "api_key" in explanation.what_could_break

    def test_what_could_break_added(self, explainer: Explainer):
        """Test what_could_break for added entities."""
        node = ChangeNode(
            id="test",
            name="new_feature",
            node_type=NodeType.CONFIG_KEY,
            path="config.new_feature",
            change_type=ChangeType.ADDED,
            risk_score=2,
            risk_level=RiskLevel.SAFE,
        )

        explanation = explainer.explain(node, [])
        # Added usually doesn't break much
        assert "required" in explanation.what_could_break.lower() or "nothing" in explanation.what_could_break.lower()

    def test_value_formatting_long(self, explainer: Explainer):
        """Test that long values are truncated in summary."""
        node = ChangeNode(
            id="test",
            name="content",
            node_type=NodeType.CONFIG_KEY,
            path="config.content",
            change_type=ChangeType.MODIFIED,
            risk_score=3,
            risk_level=RiskLevel.SAFE,
            metadata={
                "old_value": "a" * 100,
                "new_value": "b" * 100,
            },
        )

        explanation = explainer.explain(node, [])
        # Should have truncation
        assert "..." in explanation.change_summary

    def test_value_formatting_none(self, explainer: Explainer):
        """Test that None values are formatted as 'null'."""
        node = ChangeNode(
            id="test",
            name="optional",
            node_type=NodeType.CONFIG_KEY,
            path="config.optional",
            change_type=ChangeType.MODIFIED,
            risk_score=2,
            risk_level=RiskLevel.SAFE,
            metadata={"old_value": "value", "new_value": None},
        )

        explanation = explainer.explain(node, [])
        assert "null" in explanation.change_summary


class TestExplainerIntegration:
    """Integration tests for Explainer with graph and rules."""

    def test_full_explanation_flow(self):
        """Test complete flow: graph -> rules -> explanation."""
        from what_changed.rules.engine import create_default_engine
        from what_changed.graph.builder import GraphBuilder
        from what_changed.diff.semantic_diff import DiffResult, Change
        from what_changed.normalize.base import EntityType

        # Create a diff result
        diff_result = DiffResult(
            source_a="config_a.json",
            source_b="config_b.json",
            type_a="json",
            type_b="json",
            changes=[
                Change(
                    change_type=ChangeType.MODIFIED,
                    path="database.password",
                    entity_type=EntityType.KEY,
                    old_value="dev_password",
                    new_value="prod_password",
                ),
                Change(
                    change_type=ChangeType.REMOVED,
                    path="deprecated_key",
                    entity_type=EntityType.KEY,
                    old_value="value",
                ),
            ],
            modified_count=1,
            removed_count=1,
        )

        # Build graph
        builder = GraphBuilder()
        graph = builder.build(diff_result)

        # Apply rules
        engine = create_default_engine()
        rule_results = engine.apply(graph)

        # Generate explanations
        explainer = Explainer()
        explanations = explainer.explain_graph(graph, rule_results)

        assert len(explanations) >= 2

        # Password change should be flagged
        password_exp = next(
            (e for e in explanations if "password" in e.path.lower()),
            None
        )
        assert password_exp is not None
        assert password_exp.risk_score > 0
