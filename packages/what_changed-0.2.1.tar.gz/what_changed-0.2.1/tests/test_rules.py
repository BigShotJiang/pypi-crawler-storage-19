"""Tests for rules engine and heuristic rules."""

import pytest

from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import (
    ChangeGraph,
    ChangeNode,
    ChangeEdge,
    NodeType,
    EdgeType,
    RiskLevel,
)
from what_changed.rules.base import Rule, RuleResult
from what_changed.rules.engine import RuleEngine, create_default_engine
from what_changed.rules.generic import (
    RemovedEntityRule,
    TypeChangedRule,
    RenamedEntityRule,
    AddedEntityRule,
    ModifiedValueRule,
    CriticalPathRule,
    BreakingNamePatternRule,
)
from what_changed.rules.config import (
    TimeoutDecreasedRule,
    UrlHostChangedRule,
    PortChangedRule,
    RequiredFieldAddedRule,
    DefaultValueRemovedRule,
    EnvironmentSpecificRule,
)


class TestRuleResult:
    """Tests for RuleResult dataclass."""

    def test_rule_result_creation(self):
        """Test creating a RuleResult."""
        result = RuleResult(
            rule_name="test",
            matched=True,
            score=5,
            reason="Test reason",
        )
        assert result.rule_name == "test"
        assert result.matched is True
        assert result.score == 5
        assert result.reason == "Test reason"

    def test_rule_result_defaults(self):
        """Test RuleResult default values."""
        result = RuleResult(rule_name="test", matched=False)
        assert result.score == 0
        assert result.reason == ""
        assert result.details == {}

    def test_rule_result_description(self):
        """Test RuleResult description property."""
        matched = RuleResult(rule_name="test", matched=True, score=7, reason="Danger")
        assert "[test]" in matched.description
        assert "Danger" in matched.description
        assert "7" in matched.description

        not_matched = RuleResult(rule_name="test", matched=False)
        assert not_matched.description == ""


class TestRuleEngine:
    """Tests for RuleEngine class."""

    @pytest.fixture
    def engine(self) -> RuleEngine:
        """Create an empty RuleEngine."""
        return RuleEngine()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        """Create a simple ChangeGraph."""
        g = ChangeGraph()
        root = ChangeNode(id="_root", name="Root", node_type=NodeType.ROOT, path="")
        g.add_node(root)
        g.root = root
        return g

    def test_register_rule(self, engine: RuleEngine):
        """Test registering a rule."""
        rule = RemovedEntityRule()
        engine.register(rule)
        assert engine.rule_count == 1

    def test_register_many_rules(self, engine: RuleEngine):
        """Test registering multiple rules."""
        rules = [RemovedEntityRule(), TypeChangedRule(), AddedEntityRule()]
        engine.register_many(rules)
        assert engine.rule_count == 3

    def test_evaluate_node(self, engine: RuleEngine, graph: ChangeGraph):
        """Test evaluating a node against rules."""
        engine.register(RemovedEntityRule())

        removed_node = ChangeNode(
            id="removed",
            name="key",
            node_type=NodeType.CONFIG_KEY,
            path="config.key",
            change_type=ChangeType.REMOVED,
        )
        graph.add_node(removed_node)

        results = engine.evaluate_node(removed_node, graph)
        assert len(results) == 1
        assert results[0].matched is True

    def test_evaluate_node_no_match(self, engine: RuleEngine, graph: ChangeGraph):
        """Test evaluating a node with no matching rules."""
        engine.register(RemovedEntityRule())

        added_node = ChangeNode(
            id="added",
            name="key",
            node_type=NodeType.CONFIG_KEY,
            path="config.key",
            change_type=ChangeType.ADDED,
        )
        graph.add_node(added_node)

        results = engine.evaluate_node(added_node, graph)
        assert len(results) == 0

    def test_score_node(self, engine: RuleEngine, graph: ChangeGraph):
        """Test scoring a node."""
        engine.register(RemovedEntityRule())

        node = ChangeNode(
            id="removed",
            name="key",
            node_type=NodeType.CONFIG_KEY,
            path="config.key",
            change_type=ChangeType.REMOVED,
        )
        graph.add_node(node)

        score, results = engine.score_node(node, graph)
        assert score > 0
        assert len(results) == 1

    def test_score_node_multiple_rules(self, engine: RuleEngine, graph: ChangeGraph):
        """Test scoring with multiple matching rules."""
        engine.register(RemovedEntityRule())
        engine.register(CriticalPathRule())

        node = ChangeNode(
            id="removed",
            name="password",
            node_type=NodeType.CONFIG_KEY,
            path="config.password",
            change_type=ChangeType.REMOVED,
        )
        graph.add_node(node)

        score, results = engine.score_node(node, graph)
        assert len(results) == 2
        # Score should be max of all matching rules
        assert score == max(r.score for r in results)

    def test_apply_to_graph(self, engine: RuleEngine, graph: ChangeGraph):
        """Test applying rules to entire graph."""
        engine.register(RemovedEntityRule())
        engine.register(AddedEntityRule())

        removed = ChangeNode(
            id="removed",
            name="old",
            node_type=NodeType.CONFIG_KEY,
            path="config.old",
            change_type=ChangeType.REMOVED,
        )
        added = ChangeNode(
            id="added",
            name="new",
            node_type=NodeType.CONFIG_KEY,
            path="config.new",
            change_type=ChangeType.ADDED,
        )
        graph.add_node(removed)
        graph.add_node(added)

        all_results = engine.apply(graph)

        assert "removed" in all_results
        assert "added" in all_results

        # Check that nodes were updated
        assert removed.risk_score > 0
        assert added.risk_score > 0
        assert removed.risk_level != RiskLevel.SAFE

    def test_apply_skips_root(self, engine: RuleEngine, graph: ChangeGraph):
        """Test that apply skips root nodes."""
        engine.register(RemovedEntityRule())

        all_results = engine.apply(graph)
        assert "_root" not in all_results

    def test_rules_property(self, engine: RuleEngine):
        """Test getting registered rules."""
        rules = [RemovedEntityRule(), AddedEntityRule()]
        engine.register_many(rules)

        returned_rules = engine.rules
        assert len(returned_rules) == 2
        # Should be a copy
        returned_rules.append(TypeChangedRule())
        assert engine.rule_count == 2


class TestCreateDefaultEngine:
    """Tests for create_default_engine function."""

    def test_creates_engine_with_rules(self):
        """Test that default engine has rules registered."""
        engine = create_default_engine()
        assert engine.rule_count > 0

    def test_has_generic_rules(self):
        """Test that default engine has generic rules."""
        engine = create_default_engine()
        rule_names = {r.name for r in engine.rules}
        assert "removed_entity" in rule_names
        assert "type_changed" in rule_names
        assert "added_entity" in rule_names

    def test_has_config_rules(self):
        """Test that default engine has config rules."""
        engine = create_default_engine()
        rule_names = {r.name for r in engine.rules}
        assert "timeout_decreased" in rule_names
        assert "url_host_changed" in rule_names
        assert "port_changed" in rule_names


class TestRemovedEntityRule:
    """Tests for RemovedEntityRule."""

    @pytest.fixture
    def rule(self) -> RemovedEntityRule:
        return RemovedEntityRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_removed(self, rule: RemovedEntityRule, graph: ChangeGraph):
        """Test rule matches removed entities."""
        node = ChangeNode(
            id="test",
            name="key",
            node_type=NodeType.CONFIG_KEY,
            path="config.key",
            change_type=ChangeType.REMOVED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score > 0

    def test_no_match_added(self, rule: RemovedEntityRule, graph: ChangeGraph):
        """Test rule doesn't match added entities."""
        node = ChangeNode(
            id="test",
            name="key",
            node_type=NodeType.CONFIG_KEY,
            path="config.key",
            change_type=ChangeType.ADDED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is False

    def test_score_by_node_type(self, rule: RemovedEntityRule, graph: ChangeGraph):
        """Test that score varies by node type."""
        file_node = ChangeNode(
            id="file",
            name="file.py",
            node_type=NodeType.FILE,
            path="src/file.py",
            change_type=ChangeType.REMOVED,
        )
        endpoint_node = ChangeNode(
            id="endpoint",
            name="/api/users",
            node_type=NodeType.ENDPOINT,
            path="/api/users",
            change_type=ChangeType.REMOVED,
        )

        file_result = rule.evaluate(file_node, graph)
        endpoint_result = rule.evaluate(endpoint_node, graph)

        # Endpoint removal should be more severe
        assert endpoint_result.score > file_result.score


class TestTypeChangedRule:
    """Tests for TypeChangedRule."""

    @pytest.fixture
    def rule(self) -> TypeChangedRule:
        return TypeChangedRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_type_changed(self, rule: TypeChangedRule, graph: ChangeGraph):
        """Test rule matches type changes."""
        node = ChangeNode(
            id="test",
            name="port",
            node_type=NodeType.CONFIG_KEY,
            path="config.port",
            change_type=ChangeType.TYPE_CHANGED,
            metadata={"old_type": "string", "new_type": "integer"},
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 7

    def test_breaking_type_combinations(self, rule: TypeChangedRule, graph: ChangeGraph):
        """Test breaking type combinations get higher scores."""
        # string -> integer is very breaking
        node1 = ChangeNode(
            id="test1",
            name="value",
            node_type=NodeType.CONFIG_KEY,
            path="value",
            change_type=ChangeType.TYPE_CHANGED,
            metadata={"old_type": "string", "new_type": "integer"},
        )
        # integer -> string is less breaking
        node2 = ChangeNode(
            id="test2",
            name="value",
            node_type=NodeType.CONFIG_KEY,
            path="value",
            change_type=ChangeType.TYPE_CHANGED,
            metadata={"old_type": "integer", "new_type": "string"},
        )

        result1 = rule.evaluate(node1, graph)
        result2 = rule.evaluate(node2, graph)

        assert result1.score >= result2.score


class TestAddedEntityRule:
    """Tests for AddedEntityRule."""

    @pytest.fixture
    def rule(self) -> AddedEntityRule:
        return AddedEntityRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_added(self, rule: AddedEntityRule, graph: ChangeGraph):
        """Test rule matches added entities."""
        node = ChangeNode(
            id="test",
            name="new_key",
            node_type=NodeType.CONFIG_KEY,
            path="config.new_key",
            change_type=ChangeType.ADDED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True

    def test_added_has_low_score(self, rule: AddedEntityRule, graph: ChangeGraph):
        """Test that regular additions have low scores."""
        node = ChangeNode(
            id="test",
            name="optional",
            node_type=NodeType.CONFIG_KEY,
            path="config.optional",
            change_type=ChangeType.ADDED,
        )
        result = rule.evaluate(node, graph)
        assert result.score < 5

    def test_required_pattern_high_score(self, rule: AddedEntityRule, graph: ChangeGraph):
        """Test that required field patterns get high scores."""
        node = ChangeNode(
            id="test",
            name="required_field",
            node_type=NodeType.CONFIG_KEY,
            path="config.required_field",
            change_type=ChangeType.ADDED,
        )
        result = rule.evaluate(node, graph)
        assert result.score >= 8


class TestModifiedValueRule:
    """Tests for ModifiedValueRule."""

    @pytest.fixture
    def rule(self) -> ModifiedValueRule:
        return ModifiedValueRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_modified(self, rule: ModifiedValueRule, graph: ChangeGraph):
        """Test rule matches modifications."""
        node = ChangeNode(
            id="test",
            name="value",
            node_type=NodeType.CONFIG_KEY,
            path="config.value",
            change_type=ChangeType.MODIFIED,
            metadata={"old_value": "old", "new_value": "new"},
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True

    def test_large_numeric_change(self, rule: ModifiedValueRule, graph: ChangeGraph):
        """Test large numeric changes get higher scores."""
        # More than 100% change
        node = ChangeNode(
            id="test",
            name="count",
            node_type=NodeType.CONFIG_KEY,
            path="config.count",
            change_type=ChangeType.MODIFIED,
            metadata={"old_value": "10", "new_value": "100"},
        )
        result = rule.evaluate(node, graph)
        assert result.score >= 5


class TestCriticalPathRule:
    """Tests for CriticalPathRule."""

    @pytest.fixture
    def rule(self) -> CriticalPathRule:
        return CriticalPathRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_password(self, rule: CriticalPathRule, graph: ChangeGraph):
        """Test rule matches password paths."""
        node = ChangeNode(
            id="test",
            name="password",
            node_type=NodeType.CONFIG_KEY,
            path="database.password",
            change_type=ChangeType.MODIFIED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 9

    def test_matches_api_key(self, rule: CriticalPathRule, graph: ChangeGraph):
        """Test rule matches API key paths."""
        node = ChangeNode(
            id="test",
            name="API_KEY",
            node_type=NodeType.CONFIG_KEY,
            path="config.API_KEY",
            change_type=ChangeType.MODIFIED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True

    def test_matches_sensitive(self, rule: CriticalPathRule, graph: ChangeGraph):
        """Test rule matches sensitive paths."""
        node = ChangeNode(
            id="test",
            name="database_host",
            node_type=NodeType.CONFIG_KEY,
            path="config.database_host",
            change_type=ChangeType.MODIFIED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        # Sensitive but not critical
        assert result.score == 7


class TestBreakingNamePatternRule:
    """Tests for BreakingNamePatternRule."""

    @pytest.fixture
    def rule(self) -> BreakingNamePatternRule:
        return BreakingNamePatternRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_deprecated(self, rule: BreakingNamePatternRule, graph: ChangeGraph):
        """Test rule matches deprecated entities."""
        node = ChangeNode(
            id="test",
            name="deprecated_function",
            node_type=NodeType.SYMBOL,
            path="deprecated_function",
            change_type=ChangeType.REMOVED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 7

    def test_matches_versioned(self, rule: BreakingNamePatternRule, graph: ChangeGraph):
        """Test rule matches versioned entities."""
        node = ChangeNode(
            id="test",
            name="api_v2",
            node_type=NodeType.ENDPOINT,
            path="api_v2",
            change_type=ChangeType.MODIFIED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True


class TestTimeoutDecreasedRule:
    """Tests for TimeoutDecreasedRule."""

    @pytest.fixture
    def rule(self) -> TimeoutDecreasedRule:
        return TimeoutDecreasedRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_timeout_decrease(self, rule: TimeoutDecreasedRule, graph: ChangeGraph):
        """Test rule matches decreased timeout."""
        node = ChangeNode(
            id="test",
            name="timeout",
            node_type=NodeType.CONFIG_KEY,
            path="config.timeout",
            change_type=ChangeType.MODIFIED,
            metadata={"old_value": "30", "new_value": "10"},
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 7

    def test_no_match_timeout_increase(self, rule: TimeoutDecreasedRule, graph: ChangeGraph):
        """Test rule doesn't match increased timeout."""
        node = ChangeNode(
            id="test",
            name="timeout",
            node_type=NodeType.CONFIG_KEY,
            path="config.timeout",
            change_type=ChangeType.MODIFIED,
            metadata={"old_value": "10", "new_value": "30"},
        )
        result = rule.evaluate(node, graph)
        assert result.matched is False

    def test_parses_duration_strings(self, rule: TimeoutDecreasedRule, graph: ChangeGraph):
        """Test parsing of duration strings."""
        node = ChangeNode(
            id="test",
            name="ttl",
            node_type=NodeType.CONFIG_KEY,
            path="config.ttl",
            change_type=ChangeType.MODIFIED,
            metadata={"old_value": "1h", "new_value": "30m"},
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True


class TestUrlHostChangedRule:
    """Tests for UrlHostChangedRule."""

    @pytest.fixture
    def rule(self) -> UrlHostChangedRule:
        return UrlHostChangedRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_host_change(self, rule: UrlHostChangedRule, graph: ChangeGraph):
        """Test rule matches URL host changes."""
        node = ChangeNode(
            id="test",
            name="api_url",
            node_type=NodeType.CONFIG_KEY,
            path="config.api_url",
            change_type=ChangeType.MODIFIED,
            metadata={
                "old_value": "https://dev.api.com/v1",
                "new_value": "https://prod.api.com/v1",
            },
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 8

    def test_no_match_same_host(self, rule: UrlHostChangedRule, graph: ChangeGraph):
        """Test rule doesn't match when host is same."""
        node = ChangeNode(
            id="test",
            name="api_url",
            node_type=NodeType.CONFIG_KEY,
            path="config.api_url",
            change_type=ChangeType.MODIFIED,
            metadata={
                "old_value": "https://api.com/v1",
                "new_value": "https://api.com/v2",
            },
        )
        result = rule.evaluate(node, graph)
        # Path changed, so might still match with lower score
        assert not result.matched or result.score < 8


class TestPortChangedRule:
    """Tests for PortChangedRule."""

    @pytest.fixture
    def rule(self) -> PortChangedRule:
        return PortChangedRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_port_change(self, rule: PortChangedRule, graph: ChangeGraph):
        """Test rule matches port changes."""
        node = ChangeNode(
            id="test",
            name="port",
            node_type=NodeType.CONFIG_KEY,
            path="database.port",
            change_type=ChangeType.MODIFIED,
            metadata={"old_value": "5432", "new_value": "5433"},
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 7

    def test_no_match_non_port(self, rule: PortChangedRule, graph: ChangeGraph):
        """Test rule doesn't match non-port fields."""
        node = ChangeNode(
            id="test",
            name="count",
            node_type=NodeType.CONFIG_KEY,
            path="config.count",
            change_type=ChangeType.MODIFIED,
            metadata={"old_value": "100", "new_value": "200"},
        )
        result = rule.evaluate(node, graph)
        assert result.matched is False


class TestRequiredFieldAddedRule:
    """Tests for RequiredFieldAddedRule."""

    @pytest.fixture
    def rule(self) -> RequiredFieldAddedRule:
        return RequiredFieldAddedRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_required_added(self, rule: RequiredFieldAddedRule, graph: ChangeGraph):
        """Test rule matches added required fields."""
        node = ChangeNode(
            id="test",
            name="required_auth",
            node_type=NodeType.CONFIG_KEY,
            path="config.required_auth",
            change_type=ChangeType.ADDED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 8

    def test_no_match_optional(self, rule: RequiredFieldAddedRule, graph: ChangeGraph):
        """Test rule doesn't match optional fields."""
        node = ChangeNode(
            id="test",
            name="optional",
            node_type=NodeType.CONFIG_KEY,
            path="config.optional",
            change_type=ChangeType.ADDED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is False


class TestDefaultValueRemovedRule:
    """Tests for DefaultValueRemovedRule."""

    @pytest.fixture
    def rule(self) -> DefaultValueRemovedRule:
        return DefaultValueRemovedRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_default_removed(self, rule: DefaultValueRemovedRule, graph: ChangeGraph):
        """Test rule matches removed default values."""
        node = ChangeNode(
            id="test",
            name="default_timeout",
            node_type=NodeType.CONFIG_KEY,
            path="config.default_timeout",
            change_type=ChangeType.REMOVED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 6

    def test_no_match_non_default(self, rule: DefaultValueRemovedRule, graph: ChangeGraph):
        """Test rule doesn't match non-default fields."""
        node = ChangeNode(
            id="test",
            name="timeout",
            node_type=NodeType.CONFIG_KEY,
            path="config.timeout",
            change_type=ChangeType.REMOVED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is False


class TestEnvironmentSpecificRule:
    """Tests for EnvironmentSpecificRule."""

    @pytest.fixture
    def rule(self) -> EnvironmentSpecificRule:
        return EnvironmentSpecificRule()

    @pytest.fixture
    def graph(self) -> ChangeGraph:
        return ChangeGraph()

    def test_matches_production(self, rule: EnvironmentSpecificRule, graph: ChangeGraph):
        """Test rule matches production configs with high score."""
        node = ChangeNode(
            id="test",
            name="production_url",
            node_type=NodeType.CONFIG_KEY,
            path="config.production_url",
            change_type=ChangeType.MODIFIED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score >= 9

    def test_matches_dev_lower_score(self, rule: EnvironmentSpecificRule, graph: ChangeGraph):
        """Test rule matches dev configs with lower score."""
        node = ChangeNode(
            id="test",
            name="development_url",
            node_type=NodeType.CONFIG_KEY,
            path="config.development_url",
            change_type=ChangeType.MODIFIED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is True
        assert result.score < 6

    def test_no_match_added(self, rule: EnvironmentSpecificRule, graph: ChangeGraph):
        """Test rule doesn't match added entities."""
        node = ChangeNode(
            id="test",
            name="production_key",
            node_type=NodeType.CONFIG_KEY,
            path="config.production_key",
            change_type=ChangeType.ADDED,
        )
        result = rule.evaluate(node, graph)
        assert result.matched is False
