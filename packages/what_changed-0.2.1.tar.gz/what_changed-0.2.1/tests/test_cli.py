"""Tests for CLI commands."""

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from what_changed.cli.main import app


runner = CliRunner()


class TestCompareCommand:
    """Tests for the compare command."""

    def test_compare_json_files(self, temp_dir: Path):
        """Test comparing two JSON files."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"key": "old_value"}))
        file_b.write_text(json.dumps({"key": "new_value"}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b)])

        assert result.exit_code in [0, 1, 2]  # Valid exit codes
        # Should produce some output
        assert len(result.stdout) > 0

    def test_compare_identical_files(self, temp_dir: Path):
        """Test comparing identical files returns exit code 0."""
        content = {"name": "test", "value": 42}
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps(content))
        file_b.write_text(json.dumps(content))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b)])

        # Identical files should be safe (exit code 0)
        assert result.exit_code == 0

    def test_compare_with_breaking_changes(self, temp_dir: Path):
        """Test that breaking changes return exit code 2."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        # Removing a key is typically breaking
        file_a.write_text(json.dumps({"password": "secret", "api_key": "key123"}))
        file_b.write_text(json.dumps({}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b)])

        # Should be breaking (exit code 2)
        assert result.exit_code == 2

    def test_compare_json_output(self, temp_dir: Path):
        """Test JSON output format."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"key": "value1"}))
        file_b.write_text(json.dumps({"key": "value2"}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b), "--json"])

        # Output should be valid JSON
        assert result.exit_code in [0, 1, 2]
        output_data = json.loads(result.stdout)
        assert "sources" in output_data or "summary" in output_data or "changes" in output_data

    def test_compare_summary(self, temp_dir: Path):
        """Test summary output format."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"key": "value"}))
        file_b.write_text(json.dumps({"key": "new_value", "added": "key"}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b), "--summary"])

        assert result.exit_code in [0, 1, 2]
        # Summary should be shorter than full output
        assert len(result.stdout) > 0

    def test_compare_breaking_only(self, temp_dir: Path):
        """Test breaking-only filter."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"safe_key": "value", "dangerous_password": "secret"}))
        file_b.write_text(json.dumps({"safe_key": "new_value"}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b), "--breaking-only"])

        assert result.exit_code in [0, 1, 2]

    def test_compare_nonexistent_file(self, temp_dir: Path):
        """Test error handling for nonexistent files."""
        file_a = temp_dir / "exists.json"
        file_a.write_text(json.dumps({"key": "value"}))

        result = runner.invoke(app, ["compare", str(file_a), "/nonexistent/file.json"])

        # Should return error exit code
        assert result.exit_code == 3
        assert "Error" in result.stdout or "not found" in result.stdout.lower()

    def test_compare_malformed_json(self, temp_dir: Path):
        """Test error handling for malformed JSON."""
        file_a = temp_dir / "valid.json"
        file_b = temp_dir / "invalid.json"
        file_a.write_text(json.dumps({"key": "value"}))
        file_b.write_text('{"key": "value",}')  # Invalid JSON

        result = runner.invoke(app, ["compare", str(file_a), str(file_b)])

        assert result.exit_code == 3
        assert "Error" in result.stdout

    def test_compare_directories(self, temp_dir: Path):
        """Test comparing directories."""
        dir_a = temp_dir / "dir_a"
        dir_b = temp_dir / "dir_b"
        dir_a.mkdir()
        dir_b.mkdir()

        (dir_a / "file.txt").write_text("content")
        (dir_b / "file.txt").write_text("modified content")

        result = runner.invoke(app, ["compare", str(dir_a), str(dir_b)])

        assert result.exit_code in [0, 1, 2]

    def test_compare_env_files(self, temp_dir: Path):
        """Test comparing ENV files."""
        file_a = temp_dir / ".env.a"
        file_b = temp_dir / ".env.b"
        file_a.write_text("DATABASE_URL=localhost\nDEBUG=true")
        file_b.write_text("DATABASE_URL=production.db.com\nDEBUG=false")

        result = runner.invoke(app, ["compare", str(file_a), str(file_b)])

        assert result.exit_code in [0, 1, 2]

    def test_compare_no_color(self, temp_dir: Path):
        """Test --no-color option."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"key": "value"}))
        file_b.write_text(json.dumps({"key": "new"}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b), "--no-color"])

        assert result.exit_code in [0, 1, 2]

    def test_compare_verbose(self, temp_dir: Path):
        """Test verbose output."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        file_a.write_text(json.dumps({"password": "old"}))
        file_b.write_text(json.dumps({"password": "new"}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b), "--verbose"])

        assert result.exit_code in [0, 1, 2]
        # Verbose should have more output


class TestDetectCommand:
    """Tests for the detect command."""

    def test_detect_json_file(self, temp_dir: Path):
        """Test detecting JSON file type."""
        file = temp_dir / "config.json"
        file.write_text(json.dumps({"key": "value"}))

        result = runner.invoke(app, ["detect", str(file)])

        assert result.exit_code == 0
        assert "JSON" in result.stdout

    def test_detect_yaml_file(self, temp_dir: Path):
        """Test detecting YAML file type."""
        file = temp_dir / "config.yaml"
        file.write_text("key: value\nlist:\n  - item1\n  - item2")

        result = runner.invoke(app, ["detect", str(file)])

        assert result.exit_code == 0
        assert "YAML" in result.stdout

    def test_detect_env_file(self, temp_dir: Path):
        """Test detecting ENV file type."""
        file = temp_dir / ".env"
        file.write_text("DATABASE_URL=localhost\nDEBUG=true")

        result = runner.invoke(app, ["detect", str(file)])

        assert result.exit_code == 0
        assert "ENV" in result.stdout

    def test_detect_directory(self, temp_dir: Path):
        """Test detecting directory type."""
        dir_path = temp_dir / "mydir"
        dir_path.mkdir()

        result = runner.invoke(app, ["detect", str(dir_path)])

        assert result.exit_code == 0
        assert "DIRECTORY" in result.stdout

    def test_detect_text_file(self, temp_dir: Path):
        """Test detecting text file type."""
        file = temp_dir / "readme.txt"
        file.write_text("This is a text file.\nWith multiple lines.")

        result = runner.invoke(app, ["detect", str(file)])

        assert result.exit_code == 0
        assert "TEXT" in result.stdout

    def test_detect_nonexistent(self, temp_dir: Path):
        """Test detecting nonexistent file."""
        result = runner.invoke(app, ["detect", "/nonexistent/file"])

        assert result.exit_code == 0  # detect doesn't fail, just reports UNKNOWN
        assert "UNKNOWN" in result.stdout


class TestVersionOption:
    """Tests for version option."""

    def test_version_flag(self):
        """Test --version flag with compare command."""
        result = runner.invoke(app, ["compare", "--version"])

        # Version should be printed
        assert "version" in result.stdout.lower()

    def test_version_short_flag(self):
        """Test -V flag with compare command."""
        result = runner.invoke(app, ["compare", "-V"])

        # Version should be printed
        assert "version" in result.stdout.lower()


class TestHelpOption:
    """Tests for help options."""

    def test_no_args_shows_help(self):
        """Test that no args shows help."""
        result = runner.invoke(app, [])

        # Should show help (no_args_is_help=True)
        assert "Usage" in result.stdout or "compare" in result.stdout

    def test_compare_help(self):
        """Test compare --help."""
        result = runner.invoke(app, ["compare", "--help"])

        assert result.exit_code == 0
        assert "Compare" in result.stdout or "source" in result.stdout.lower()

    def test_detect_help(self):
        """Test detect --help."""
        result = runner.invoke(app, ["detect", "--help"])

        assert result.exit_code == 0
        assert "Detect" in result.stdout or "type" in result.stdout.lower()


class TestExitCodes:
    """Tests for exit code semantics."""

    def test_exit_code_0_safe(self, temp_dir: Path):
        """Test exit code 0 for safe changes."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        # Adding a new optional key is usually safe
        file_a.write_text(json.dumps({"existing": "value"}))
        file_b.write_text(json.dumps({"existing": "value", "new_optional": "key"}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b)])

        # Safe additions should be exit code 0 or 1 depending on rules
        assert result.exit_code in [0, 1]

    def test_exit_code_2_breaking(self, temp_dir: Path):
        """Test exit code 2 for breaking changes."""
        file_a = temp_dir / "a.json"
        file_b = temp_dir / "b.json"
        # Removing password-related keys is typically breaking
        file_a.write_text(json.dumps({"database": {"password": "secret", "host": "localhost"}}))
        file_b.write_text(json.dumps({"database": {"host": "localhost"}}))

        result = runner.invoke(app, ["compare", str(file_a), str(file_b)])

        # Removing password should be breaking
        assert result.exit_code == 2

    def test_exit_code_3_error(self):
        """Test exit code 3 for errors."""
        result = runner.invoke(app, ["compare", "/nonexistent/a", "/nonexistent/b"])

        assert result.exit_code == 3
