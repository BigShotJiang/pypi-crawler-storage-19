"""Directory normalizer."""

import hashlib
from pathlib import Path
from typing import Optional, Set
import os

from what_changed.normalize.base import (
    Normalizer,
    NormalizedObject,
    NormalizationError,
    Entity,
    EntityType,
)


# Default patterns to ignore
DEFAULT_IGNORE_PATTERNS = {
    # Version control
    '.git', '.svn', '.hg', '.bzr',
    # Dependencies
    'node_modules', '__pycache__', '.venv', 'venv', 'env',
    '.tox', '.nox', '.pytest_cache', '.mypy_cache', '.ruff_cache',
    # Build outputs
    'dist', 'build', 'target', '*.egg-info',
    # IDE
    '.idea', '.vscode', '*.swp', '*.swo',
    # OS
    '.DS_Store', 'Thumbs.db',
}


def _should_ignore(name: str, ignore_patterns: Set[str]) -> bool:
    """Check if a file/directory should be ignored."""
    # Exact match
    if name in ignore_patterns:
        return True

    # Glob-like pattern (*.ext)
    for pattern in ignore_patterns:
        if pattern.startswith('*') and name.endswith(pattern[1:]):
            return True

    return False


def _compute_file_hash(path: Path, quick: bool = True) -> str:
    """
    Compute a hash for a file.

    Args:
        path: Path to the file
        quick: If True, only hash first/last chunks for speed

    Returns:
        Hash string
    """
    try:
        size = path.stat().st_size

        if quick and size > 65536:
            # For large files, hash first and last 32KB
            hasher = hashlib.md5()
            with open(path, 'rb') as f:
                hasher.update(f.read(32768))
                f.seek(-32768, 2)
                hasher.update(f.read(32768))
            hasher.update(str(size).encode())
            return hasher.hexdigest()[:16]
        else:
            # Hash entire file for small files
            hasher = hashlib.md5()
            with open(path, 'rb') as f:
                for chunk in iter(lambda: f.read(65536), b''):
                    hasher.update(chunk)
            return hasher.hexdigest()[:16]
    except (OSError, IOError):
        return "error"


class DirectoryNormalizer(Normalizer):
    """
    Normalizer for directories.

    Creates a hierarchical entity structure representing the directory tree.
    Each file and directory becomes an entity with relevant metadata.
    """

    SUPPORTED_TYPES = ["directory", "dir", "folder"]

    def __init__(
        self,
        ignore_patterns: Optional[Set[str]] = None,
        max_depth: Optional[int] = None,
        include_hidden: bool = False,
        compute_hashes: bool = True,
    ):
        """
        Initialize the directory normalizer.

        Args:
            ignore_patterns: Patterns to ignore (defaults to common patterns)
            max_depth: Maximum depth to traverse (None = unlimited)
            include_hidden: Whether to include hidden files/directories
            compute_hashes: Whether to compute file hashes
        """
        self.ignore_patterns = ignore_patterns or DEFAULT_IGNORE_PATTERNS
        self.max_depth = max_depth
        self.include_hidden = include_hidden
        self.compute_hashes = compute_hashes

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        """Check if this normalizer can handle the source."""
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True

        path = Path(source)
        return path.exists() and path.is_dir()

    def normalize(self, source: str) -> NormalizedObject:
        """
        Normalize a directory into entities.

        Creates a tree structure where:
        - Each directory is a DIRECTORY entity with children
        - Each file is a FILE entity with metadata
        """
        root_path = Path(source)

        if not root_path.exists():
            raise NormalizationError(f"Directory not found: {source}", source)

        if not root_path.is_dir():
            raise NormalizationError(f"Not a directory: {source}", source)

        # Build entity tree
        root_entity, stats = self._build_entity_tree(root_path, "", 0)

        return NormalizedObject(
            type="directory",
            entities=root_entity.children if root_entity.children else [root_entity],
            structure={
                "total_files": stats["files"],
                "total_directories": stats["directories"],
                "total_size": stats["size"],
                "max_depth": stats["max_depth"],
                "file_types": dict(stats["extensions"]),
            },
            metadata={
                "root_path": str(root_path.absolute()),
                "root_name": root_path.name,
            },
            source_path=root_path,
        )

    def _build_entity_tree(
        self,
        path: Path,
        relative_path: str,
        depth: int,
    ) -> tuple[Entity, dict]:
        """
        Recursively build the entity tree for a directory.

        Returns:
            Tuple of (Entity, stats_dict)
        """
        stats = {
            "files": 0,
            "directories": 0,
            "size": 0,
            "max_depth": depth,
            "extensions": {},
        }

        children: list[Entity] = []

        try:
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            entries = []

        for entry in entries:
            name = entry.name

            # Check if should ignore
            if _should_ignore(name, self.ignore_patterns):
                continue

            # Check hidden files
            if not self.include_hidden and name.startswith('.'):
                continue

            entry_relative = f"{relative_path}/{name}" if relative_path else name
            entry_id = hashlib.md5(entry_relative.encode()).hexdigest()[:12]

            if entry.is_dir():
                # Check depth limit
                if self.max_depth is not None and depth >= self.max_depth:
                    continue

                # Recurse into directory
                child_entity, child_stats = self._build_entity_tree(
                    entry, entry_relative, depth + 1
                )

                # Merge stats
                stats["directories"] += 1 + child_stats["directories"]
                stats["files"] += child_stats["files"]
                stats["size"] += child_stats["size"]
                stats["max_depth"] = max(stats["max_depth"], child_stats["max_depth"])
                for ext, count in child_stats["extensions"].items():
                    stats["extensions"][ext] = stats["extensions"].get(ext, 0) + count

                children.append(child_entity)

            elif entry.is_file():
                stats["files"] += 1

                try:
                    file_stat = entry.stat()
                    file_size = file_stat.st_size
                    modified_time = file_stat.st_mtime
                except (OSError, IOError):
                    file_size = 0
                    modified_time = 0

                stats["size"] += file_size

                # Track extension
                ext = entry.suffix.lower() or "(no extension)"
                stats["extensions"][ext] = stats["extensions"].get(ext, 0) + 1

                # Compute hash if enabled
                file_hash = None
                if self.compute_hashes:
                    file_hash = _compute_file_hash(entry)

                file_entity = Entity(
                    id=f"file_{entry_id}",
                    name=name,
                    entity_type=EntityType.FILE,
                    value=None,  # Don't store content
                    path=entry_relative,
                    metadata={
                        "size": file_size,
                        "extension": entry.suffix,
                        "modified": modified_time,
                        "hash": file_hash,
                    },
                )
                children.append(file_entity)

        # Create directory entity
        dir_id = hashlib.md5(relative_path.encode() if relative_path else b"_root").hexdigest()[:12]
        dir_entity = Entity(
            id=f"dir_{dir_id}",
            name=path.name or str(path),
            entity_type=EntityType.DIRECTORY,
            value=None,
            path=relative_path or ".",
            metadata={
                "depth": depth,
                "child_count": len(children),
                "file_count": sum(1 for c in children if c.entity_type == EntityType.FILE),
                "dir_count": sum(1 for c in children if c.entity_type == EntityType.DIRECTORY),
            },
            children=children,
        )

        return dir_entity, stats

    @property
    def supported_types(self) -> list[str]:
        """List of source types this normalizer supports."""
        return self.SUPPORTED_TYPES.copy()
