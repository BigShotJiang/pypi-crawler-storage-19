"""Markdown document normalizer."""

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)


@dataclass
class MarkdownSection:
    """A section in a markdown document."""
    level: int
    title: str
    content: str
    line_number: int
    children: list["MarkdownSection"] = field(default_factory=list)


class MarkdownNormalizer:
    """Normalizer for Markdown files with structure extraction."""

    SUPPORTED_TYPES = ["markdown", "md"]

    # Patterns
    HEADER_PATTERN = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)
    LINK_PATTERN = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
    IMAGE_PATTERN = re.compile(r"!\[([^\]]*)\]\(([^)]+)\)")
    CODE_BLOCK_PATTERN = re.compile(r"```(\w*)\n(.*?)```", re.DOTALL)
    INLINE_CODE_PATTERN = re.compile(r"`([^`]+)`")
    LIST_PATTERN = re.compile(r"^[\s]*[-*+]\s+(.+)$", re.MULTILINE)
    NUMBERED_LIST_PATTERN = re.compile(r"^[\s]*\d+\.\s+(.+)$", re.MULTILINE)

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.suffix.lower() in (".md", ".markdown", ".mdown")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            structure = self._parse_structure(content)
            entities = self._build_entities(content, structure)

            return NormalizedObject(
                type="markdown",
                entities=entities,
                structure={
                    "sections": [self._section_to_dict(s) for s in structure],
                    "section_count": self._count_sections(structure),
                },
                metadata={
                    "word_count": len(content.split()),
                    "line_count": content.count("\n") + 1,
                    "link_count": len(self.LINK_PATTERN.findall(content)),
                    "image_count": len(self.IMAGE_PATTERN.findall(content)),
                    "code_block_count": len(self.CODE_BLOCK_PATTERN.findall(content)),
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse Markdown: {e}", source, e)

    def _parse_structure(self, content: str) -> list[MarkdownSection]:
        """Parse markdown into hierarchical sections."""
        sections: list[MarkdownSection] = []
        lines = content.split("\n")

        current_sections: dict[int, MarkdownSection] = {}
        current_content_lines: list[str] = []
        current_line = 0

        for i, line in enumerate(lines):
            header_match = re.match(r"^(#{1,6})\s+(.+)$", line)

            if header_match:
                # Save content to previous section
                if current_sections:
                    max_level = max(current_sections.keys())
                    current_sections[max_level].content = "\n".join(current_content_lines).strip()

                level = len(header_match.group(1))
                title = header_match.group(2).strip()

                section = MarkdownSection(
                    level=level,
                    title=title,
                    content="",
                    line_number=i + 1,
                )

                # Find parent
                parent_level = None
                for l in range(level - 1, 0, -1):
                    if l in current_sections:
                        parent_level = l
                        break

                if parent_level:
                    current_sections[parent_level].children.append(section)
                else:
                    sections.append(section)

                # Clear deeper levels
                for l in list(current_sections.keys()):
                    if l >= level:
                        del current_sections[l]

                current_sections[level] = section
                current_content_lines = []
            else:
                current_content_lines.append(line)

        # Save final content
        if current_sections:
            max_level = max(current_sections.keys())
            current_sections[max_level].content = "\n".join(current_content_lines).strip()

        return sections

    def _section_to_dict(self, section: MarkdownSection) -> dict:
        return {
            "level": section.level,
            "title": section.title,
            "line_number": section.line_number,
            "content_length": len(section.content),
            "children": [self._section_to_dict(c) for c in section.children],
        }

    def _count_sections(self, sections: list[MarkdownSection]) -> int:
        count = len(sections)
        for s in sections:
            count += self._count_sections(s.children)
        return count

    def _build_entities(self, content: str, sections: list[MarkdownSection]) -> list[Entity]:
        entities: list[Entity] = []

        # Document overview
        doc_entity = Entity(
            id="document",
            name="document",
            entity_type=EntityType.DOCUMENT,
            value={
                "content": content[:5000],  # First 5000 chars for comparison
                "word_count": len(content.split()),
            },
            path="_document",
            metadata={},
            children=[],
        )
        entities.append(doc_entity)

        # Sections as entities
        def add_section_entities(secs: list[MarkdownSection], parent_path: str = ""):
            for sec in secs:
                path = f"{parent_path}.{sec.title}" if parent_path else sec.title
                sec_entity = Entity(
                    id=f"section_{sec.line_number}",
                    name=sec.title,
                    entity_type=EntityType.SECTION,
                    value={
                        "level": sec.level,
                        "content": sec.content[:2000],
                        "line_number": sec.line_number,
                    },
                    path=f"sections.{path}",
                    metadata={"level": sec.level, "line": sec.line_number},
                    children=[],
                )
                entities.append(sec_entity)
                add_section_entities(sec.children, path)

        add_section_entities(sections)

        # Links as entities
        links = self.LINK_PATTERN.findall(content)
        if links:
            links_entity = Entity(
                id="links",
                name="links",
                entity_type=EntityType.SECTION,
                value={"links": [{"text": t, "url": u} for t, u in links]},
                path="_links",
                metadata={"count": len(links)},
                children=[],
            )
            entities.append(links_entity)

        # Code blocks as entities
        code_blocks = self.CODE_BLOCK_PATTERN.findall(content)
        if code_blocks:
            blocks_entity = Entity(
                id="code_blocks",
                name="code_blocks",
                entity_type=EntityType.SECTION,
                value={"blocks": [{"language": lang, "code": code[:1000]} for lang, code in code_blocks]},
                path="_code_blocks",
                metadata={"count": len(code_blocks)},
                children=[],
            )
            entities.append(blocks_entity)

        return entities
