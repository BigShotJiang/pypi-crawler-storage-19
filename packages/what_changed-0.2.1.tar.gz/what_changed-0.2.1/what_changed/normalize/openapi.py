"""OpenAPI/Swagger normalizer for API specification comparison."""

import json
from pathlib import Path
from typing import Any, Optional

import yaml

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)

# Optional import - OpenAPI support requires openapi-spec-validator
try:
    from openapi_spec_validator import validate
    from openapi_spec_validator.readers import read_from_filename

    HAS_OPENAPI = True
except ImportError:
    HAS_OPENAPI = False


class OpenAPINormalizer:
    """Normalizer for OpenAPI/Swagger specifications."""

    SUPPORTED_TYPES = ["openapi", "swagger"]

    def __init__(self):
        if not HAS_OPENAPI:
            raise ImportError(
                "OpenAPI support requires openapi-spec-validator. "
                "Install with: pip install what-changed[openapi]"
            )

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        """Check if this normalizer can handle the given source."""
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True

        # Check file content for OpenAPI/Swagger markers
        path = Path(source)
        if not path.exists() or not path.is_file():
            return False

        # Only check JSON and YAML files
        if path.suffix.lower() not in (".json", ".yaml", ".yml"):
            return False

        try:
            content = path.read_text(encoding="utf-8")

            # Quick check for OpenAPI/Swagger markers
            if path.suffix.lower() == ".json":
                data = json.loads(content)
            else:
                data = yaml.safe_load(content)

            if isinstance(data, dict):
                # OpenAPI 3.x
                if "openapi" in data:
                    return True
                # Swagger 2.0
                if "swagger" in data:
                    return True

        except Exception:
            pass

        return False

    @property
    def supported_types(self) -> list[str]:
        """List of source types this normalizer supports."""
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        """
        Normalize an OpenAPI/Swagger specification.

        Args:
            source: Path to the spec file

        Returns:
            NormalizedObject containing API structure
        """
        path = Path(source)

        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        if not path.is_file():
            raise NormalizationError(f"Not a file: {source}", source)

        try:
            # Read and parse the spec
            spec, spec_url = read_from_filename(str(path))

            # Validate (optional, but helps catch issues)
            try:
                validate(spec)
            except Exception:
                pass  # Continue even if validation fails

            # Determine version
            if "openapi" in spec:
                version = spec.get("openapi", "3.0.0")
                spec_type = "openapi"
            else:
                version = spec.get("swagger", "2.0")
                spec_type = "swagger"

            # Build entities
            entities = self._build_entities(spec, spec_type)

            # Extract info
            info = spec.get("info", {})

            return NormalizedObject(
                type=spec_type,
                entities=entities,
                structure={
                    "spec_version": version,
                    "title": info.get("title", ""),
                    "api_version": info.get("version", ""),
                    "endpoint_count": len(self._get_all_endpoints(spec)),
                    "schema_count": len(self._get_schemas(spec)),
                },
                metadata={
                    "spec_type": spec_type,
                    "spec_version": version,
                    "title": info.get("title", ""),
                    "description": info.get("description", ""),
                    "api_version": info.get("version", ""),
                },
                source_path=path,
            )
        except NormalizationError:
            raise
        except Exception as e:
            raise NormalizationError(f"Failed to parse OpenAPI spec: {e}", source, e)

    def _build_entities(self, spec: dict, spec_type: str) -> list[Entity]:
        """Build entity list from OpenAPI spec."""
        entities: list[Entity] = []

        # Info entity
        info = spec.get("info", {})
        if info:
            info_entity = Entity(
                id="info",
                name="info",
                entity_type=EntityType.METADATA,
                value=info,
                path="info",
                metadata={},
                children=[],
            )
            entities.append(info_entity)

        # Servers entity (OpenAPI 3.x)
        servers = spec.get("servers", [])
        if servers:
            servers_entity = Entity(
                id="servers",
                name="servers",
                entity_type=EntityType.SECTION,
                value=servers,
                path="servers",
                metadata={"count": len(servers)},
                children=[],
            )
            entities.append(servers_entity)

        # Base path (Swagger 2.0)
        if "basePath" in spec:
            basepath_entity = Entity(
                id="basePath",
                name="basePath",
                entity_type=EntityType.SECTION,
                value=spec["basePath"],
                path="basePath",
                metadata={},
                children=[],
            )
            entities.append(basepath_entity)

        # Paths/Endpoints
        paths = spec.get("paths", {})
        for path_url, path_item in paths.items():
            path_entity = self._build_path_entity(path_url, path_item)
            entities.append(path_entity)

        # Schemas/Definitions
        schemas = self._get_schemas(spec)
        for schema_name, schema_def in schemas.items():
            schema_entity = Entity(
                id=f"schema_{schema_name}",
                name=schema_name,
                entity_type=EntityType.SECTION,
                value=schema_def,
                path=f"schemas.{schema_name}",
                metadata={
                    "type": schema_def.get("type", "object"),
                    "properties": list(schema_def.get("properties", {}).keys()),
                    "required": schema_def.get("required", []),
                },
                children=[],
            )
            entities.append(schema_entity)

        # Security definitions
        security = spec.get("securityDefinitions") or spec.get("components", {}).get("securitySchemes", {})
        if security:
            security_entity = Entity(
                id="security",
                name="security",
                entity_type=EntityType.SECTION,
                value=security,
                path="security",
                metadata={"schemes": list(security.keys())},
                children=[],
            )
            entities.append(security_entity)

        return entities

    def _build_path_entity(self, path_url: str, path_item: dict) -> Entity:
        """Build entity for an API path."""
        # Extract operations
        operations = {}
        operation_children: list[Entity] = []

        for method in ["get", "post", "put", "patch", "delete", "options", "head"]:
            if method in path_item:
                op = path_item[method]
                operations[method] = op

                # Create child entity for the operation
                op_entity = Entity(
                    id=f"op_{path_url}_{method}",
                    name=method.upper(),
                    entity_type=EntityType.ENDPOINT,
                    value=op,
                    path=f"paths.{path_url}.{method}",
                    metadata={
                        "method": method,
                        "operation_id": op.get("operationId", ""),
                        "summary": op.get("summary", ""),
                        "parameters": [p.get("name") for p in op.get("parameters", [])],
                        "responses": list(op.get("responses", {}).keys()),
                        "deprecated": op.get("deprecated", False),
                    },
                    children=[],
                )
                operation_children.append(op_entity)

        # Path parameters
        path_params = path_item.get("parameters", [])

        return Entity(
            id=f"path_{path_url}",
            name=path_url,
            entity_type=EntityType.ENDPOINT,
            value=path_item,
            path=f"paths.{path_url}",
            metadata={
                "methods": list(operations.keys()),
                "path_parameters": [p.get("name") for p in path_params if p.get("in") == "path"],
            },
            children=operation_children,
        )

    def _get_all_endpoints(self, spec: dict) -> list[tuple[str, str]]:
        """Get all endpoints as (path, method) tuples."""
        endpoints = []
        paths = spec.get("paths", {})

        for path_url, path_item in paths.items():
            for method in ["get", "post", "put", "patch", "delete", "options", "head"]:
                if method in path_item:
                    endpoints.append((path_url, method))

        return endpoints

    def _get_schemas(self, spec: dict) -> dict:
        """Get schemas from spec (handles both OpenAPI 3.x and Swagger 2.0)."""
        # OpenAPI 3.x
        if "components" in spec:
            return spec.get("components", {}).get("schemas", {})
        # Swagger 2.0
        return spec.get("definitions", {})


def is_openapi_available() -> bool:
    """Check if OpenAPI support is available."""
    return HAS_OPENAPI
