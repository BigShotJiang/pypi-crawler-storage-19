"""PDF normalizer for extracting text and metadata from PDF files."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional
import io

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)

# Optional import - PDF support requires pymupdf
try:
    import fitz  # PyMuPDF

    HAS_PYMUPDF = True
except ImportError:
    HAS_PYMUPDF = False

# Optional OCR support
try:
    from PIL import Image
    import pytesseract
    import shutil
    import os
    import sys

    # Auto-detect Tesseract if not in PATH
    if not shutil.which("tesseract"):
        search_paths = []

        if sys.platform == "win32":
            # Windows paths
            search_paths = [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Tesseract-OCR\tesseract.exe"),
            ]
        elif sys.platform == "darwin":
            # macOS paths (Homebrew)
            search_paths = [
                "/usr/local/bin/tesseract",
                "/opt/homebrew/bin/tesseract",
            ]
        else:
            # Linux paths
            search_paths = [
                "/usr/bin/tesseract",
                "/usr/local/bin/tesseract",
            ]

        for path in search_paths:
            if os.path.exists(path):
                pytesseract.pytesseract.tesseract_cmd = path
                break

    HAS_OCR = True
except ImportError:
    HAS_OCR = False


@dataclass
class PDFPage:
    """Represents a single PDF page."""

    number: int
    text: str
    width: float
    height: float
    word_count: int
    char_count: int
    has_images: bool
    image_count: int
    ocr_text: str = ""  # Text extracted via OCR from images
    is_scanned: bool = False  # True if page appears to be a scanned image


@dataclass
class PDFStructure:
    """Normalized structure of a PDF document."""

    page_count: int
    pages: list[PDFPage] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    toc: list[tuple[int, str, int]] = field(default_factory=list)  # level, title, page
    total_word_count: int = 0
    total_char_count: int = 0
    total_image_count: int = 0
    file_size: int = 0
    has_text: bool = True
    has_ocr_text: bool = False  # True if OCR was used to extract text
    is_scanned: bool = False  # True if most pages are scanned images


class PDFNormalizer:
    """Normalizer for PDF documents."""

    SUPPORTED_TYPES = ["pdf"]

    def __init__(self):
        if not HAS_PYMUPDF:
            raise ImportError(
                "PDF support requires pymupdf. Install with: pip install what-changed[pdf]"
            )

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        """Check if this normalizer can handle the given source."""
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True

        # Check file extension
        path = Path(source)
        if path.suffix.lower() == ".pdf":
            return True

        # Check magic bytes if file exists
        if path.exists() and path.is_file():
            try:
                with open(path, "rb") as f:
                    header = f.read(5)
                return header == b"%PDF-"
            except (OSError, IOError):
                pass

        return False

    @property
    def supported_types(self) -> list[str]:
        """List of source types this normalizer supports."""
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        """
        Normalize a PDF file.

        Args:
            source: Path to the PDF file

        Returns:
            NormalizedObject containing PDF structure and content
        """
        path = Path(source)

        if not path.exists():
            raise NormalizationError(f"PDF file not found: {source}", source)

        if not path.is_file():
            raise NormalizationError(f"Not a file: {source}", source)

        try:
            structure = self._extract_structure(path)
            entities = self._build_entities(structure)

            return NormalizedObject(
                type="pdf",
                entities=entities,
                structure={
                    "page_count": structure.page_count,
                    "total_word_count": structure.total_word_count,
                    "total_char_count": structure.total_char_count,
                    "total_image_count": structure.total_image_count,
                    "has_text": structure.has_text,
                    "has_ocr_text": structure.has_ocr_text,
                    "is_scanned": structure.is_scanned,
                    "file_size": structure.file_size,
                    "toc": [
                        {"level": level, "title": title, "page": page}
                        for level, title, page in structure.toc
                    ],
                },
                metadata={
                    "page_count": structure.page_count,
                    "word_count": structure.total_word_count,
                    "char_count": structure.total_char_count,
                    "image_count": structure.total_image_count,
                    "has_toc": len(structure.toc) > 0,
                    "is_scanned": structure.is_scanned,
                    "ocr_available": HAS_OCR,
                    "file_size": structure.file_size,
                    **structure.metadata,
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse PDF: {e}", source, e)

    def _extract_structure(self, path: Path) -> PDFStructure:
        """Extract structure from PDF file."""
        doc = fitz.open(path)

        # Check if document is encrypted/password-protected
        if doc.is_encrypted:
            doc.close()
            raise NormalizationError(
                f"PDF is password-protected. Cannot compare encrypted PDFs without the password.",
                str(path)
            )

        try:
            structure = PDFStructure(
                page_count=len(doc),
                file_size=path.stat().st_size,
            )

            # Extract metadata
            metadata = doc.metadata
            if metadata:
                structure.metadata = {
                    k: v for k, v in metadata.items() if v
                }

            # Extract table of contents
            toc = doc.get_toc()
            if toc:
                structure.toc = [(level, title, page) for level, title, page in toc]

            # Extract pages
            total_words = 0
            total_chars = 0
            total_images = 0
            has_any_text = False
            has_any_ocr = False
            scanned_pages = 0

            for page_num, page in enumerate(doc):
                text = page.get_text()
                words = text.split()
                word_count = len(words)
                char_count = len(text)

                # Count images
                image_list = page.get_images()
                image_count = len(image_list)

                if text.strip():
                    has_any_text = True

                # Detect if this page is a scanned image (has images but no/little text)
                is_scanned = image_count > 0 and word_count < 10
                ocr_text = ""

                # Try OCR if page appears to be scanned and OCR is available
                if is_scanned and HAS_OCR:
                    ocr_text = self._ocr_page(page, doc)
                    if ocr_text.strip():
                        has_any_ocr = True
                        scanned_pages += 1

                pdf_page = PDFPage(
                    number=page_num + 1,
                    text=text,
                    width=page.rect.width,
                    height=page.rect.height,
                    word_count=word_count,
                    char_count=char_count,
                    has_images=image_count > 0,
                    image_count=image_count,
                    ocr_text=ocr_text,
                    is_scanned=is_scanned,
                )
                structure.pages.append(pdf_page)

                total_words += word_count
                total_chars += char_count
                total_images += image_count

            structure.total_word_count = total_words
            structure.total_char_count = total_chars
            structure.total_image_count = total_images
            structure.has_text = has_any_text or has_any_ocr
            structure.has_ocr_text = has_any_ocr
            structure.is_scanned = scanned_pages > len(doc) / 2  # Mostly scanned

            return structure
        finally:
            doc.close()

    def _ocr_page(self, page, doc) -> str:
        """Extract text from page images using OCR."""
        if not HAS_OCR:
            return ""

        try:
            # Render page to image at decent resolution for OCR
            mat = fitz.Matrix(2, 2)  # 2x zoom for better OCR
            pix = page.get_pixmap(matrix=mat)

            # Convert to PIL Image
            img_data = pix.tobytes("png")
            img = Image.open(io.BytesIO(img_data))

            # Run OCR
            text = pytesseract.image_to_string(img)
            return text.strip()
        except Exception:
            # OCR failed, return empty
            return ""

    def _build_entities(self, structure: PDFStructure) -> list[Entity]:
        """Build entity list from PDF structure."""
        entities: list[Entity] = []

        # Document-level entity
        doc_entity = Entity(
            id="document",
            name="document",
            entity_type=EntityType.DOCUMENT,
            value={
                "page_count": structure.page_count,
                "word_count": structure.total_word_count,
                "char_count": structure.total_char_count,
                "image_count": structure.total_image_count,
                "has_text": structure.has_text,
                "has_ocr_text": structure.has_ocr_text,
                "is_scanned": structure.is_scanned,
                "file_size": structure.file_size,
            },
            path="_document",
            metadata={
                "page_count": structure.page_count,
                "has_toc": len(structure.toc) > 0,
                "is_scanned": structure.is_scanned,
            },
            children=[],
        )
        entities.append(doc_entity)

        # Metadata entity
        if structure.metadata:
            metadata_entity = Entity(
                id="metadata",
                name="metadata",
                entity_type=EntityType.METADATA,
                value=structure.metadata,
                path="_metadata",
                metadata={},
                children=[],
            )
            entities.append(metadata_entity)

        # Table of contents entity
        if structure.toc:
            toc_entity = Entity(
                id="toc",
                name="toc",
                entity_type=EntityType.SECTION,
                value={
                    "entries": [
                        {"level": level, "title": title, "page": page}
                        for level, title, page in structure.toc
                    ]
                },
                path="_toc",
                metadata={"entry_count": len(structure.toc)},
                children=[],
            )
            entities.append(toc_entity)

        # Page entities
        for page in structure.pages:
            # Use OCR text if page is scanned and has no regular text
            effective_text = page.text if page.text.strip() else page.ocr_text
            effective_word_count = page.word_count if page.text.strip() else len(page.ocr_text.split())

            page_entity = Entity(
                id=f"page_{page.number}",
                name=f"page_{page.number}",
                entity_type=EntityType.PAGE,
                value={
                    "number": page.number,
                    "text": effective_text,
                    "word_count": effective_word_count,
                    "char_count": page.char_count if page.text.strip() else len(page.ocr_text),
                    "width": page.width,
                    "height": page.height,
                    "has_images": page.has_images,
                    "image_count": page.image_count,
                    "is_scanned": page.is_scanned,
                    "ocr_text": page.ocr_text if page.is_scanned else None,
                },
                path=f"page_{page.number}",
                metadata={
                    "page_number": page.number,
                    "word_count": effective_word_count,
                    "is_scanned": page.is_scanned,
                },
                children=[],
            )
            entities.append(page_entity)

        return entities


def is_pdf_available() -> bool:
    """Check if PDF support is available."""
    return HAS_PYMUPDF


def is_ocr_available() -> bool:
    """Check if OCR support is available for scanned PDFs."""
    return HAS_OCR
