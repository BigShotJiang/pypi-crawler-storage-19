"""SQL schema normalizer."""

import re
from pathlib import Path
from typing import Any, Optional

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)

# Optional sqlparse support
try:
    import sqlparse
    from sqlparse.sql import Statement, Token, Identifier, IdentifierList, Parenthesis
    from sqlparse.tokens import Keyword, Name, Punctuation
    HAS_SQLPARSE = True
except ImportError:
    HAS_SQLPARSE = False


class SQLNormalizer:
    """Normalizer for SQL schema files."""

    SUPPORTED_TYPES = ["sql", "ddl"]

    def __init__(self):
        if not HAS_SQLPARSE:
            raise ImportError(
                "SQL support requires sqlparse. Install with: pip install what-changed[sql]"
            )

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.suffix.lower() in (".sql", ".ddl")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            parsed = self._parse_sql(content)
            entities = self._build_entities(parsed)

            return NormalizedObject(
                type="sql",
                entities=entities,
                structure={
                    "table_count": len(parsed["tables"]),
                    "index_count": len(parsed["indexes"]),
                    "view_count": len(parsed["views"]),
                    "tables": list(parsed["tables"].keys()),
                },
                metadata={
                    "table_count": len(parsed["tables"]),
                    "index_count": len(parsed["indexes"]),
                    "view_count": len(parsed["views"]),
                    "statement_count": parsed["statement_count"],
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse SQL: {e}", source, e)

    def _parse_sql(self, content: str) -> dict:
        """Parse SQL into structured data."""
        result = {
            "tables": {},
            "indexes": {},
            "views": {},
            "statement_count": 0,
        }

        statements = sqlparse.parse(content)
        result["statement_count"] = len(statements)

        for stmt in statements:
            stmt_type = stmt.get_type()
            normalized = sqlparse.format(
                str(stmt),
                keyword_case="upper",
                strip_comments=True
            ).strip()

            if not normalized:
                continue

            # CREATE TABLE
            if stmt_type == "CREATE" and "TABLE" in normalized.upper():
                table = self._parse_create_table(normalized)
                if table:
                    result["tables"][table["name"]] = table

            # CREATE INDEX
            elif stmt_type == "CREATE" and "INDEX" in normalized.upper():
                index = self._parse_create_index(normalized)
                if index:
                    result["indexes"][index["name"]] = index

            # CREATE VIEW
            elif stmt_type == "CREATE" and "VIEW" in normalized.upper():
                view = self._parse_create_view(normalized)
                if view:
                    result["views"][view["name"]] = view

        return result

    def _parse_create_table(self, sql: str) -> Optional[dict]:
        """Parse CREATE TABLE statement."""
        # Extract table name
        match = re.search(
            r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\"\[]?(\w+)[`\"\]]?",
            sql,
            re.IGNORECASE
        )
        if not match:
            return None

        table_name = match.group(1)

        # Extract columns
        columns = []
        constraints = []

        # Find the parentheses containing column definitions
        paren_match = re.search(r"\((.*)\)", sql, re.DOTALL)
        if paren_match:
            col_str = paren_match.group(1)
            # Split by commas (handling nested parentheses)
            parts = self._split_columns(col_str)

            for part in parts:
                part = part.strip()
                if not part:
                    continue

                upper_part = part.upper()

                # Check if it's a constraint
                if any(kw in upper_part for kw in [
                    "PRIMARY KEY", "FOREIGN KEY", "UNIQUE", "CHECK", "CONSTRAINT"
                ]):
                    constraints.append(part)
                else:
                    col = self._parse_column(part)
                    if col:
                        columns.append(col)

        return {
            "name": table_name,
            "columns": columns,
            "constraints": constraints,
            "sql": sql,
        }

    def _split_columns(self, col_str: str) -> list[str]:
        """Split column definitions handling nested parentheses."""
        parts = []
        current = []
        depth = 0

        for char in col_str:
            if char == "(":
                depth += 1
                current.append(char)
            elif char == ")":
                depth -= 1
                current.append(char)
            elif char == "," and depth == 0:
                parts.append("".join(current))
                current = []
            else:
                current.append(char)

        if current:
            parts.append("".join(current))

        return parts

    def _parse_column(self, col_def: str) -> Optional[dict]:
        """Parse a column definition."""
        # Simple pattern: name type [constraints]
        match = re.match(
            r"[`\"\[]?(\w+)[`\"\]]?\s+(\w+(?:\([^)]+\))?)\s*(.*)",
            col_def.strip(),
            re.IGNORECASE
        )
        if not match:
            return None

        name = match.group(1)
        data_type = match.group(2)
        rest = match.group(3).upper()

        return {
            "name": name,
            "type": data_type,
            "nullable": "NOT NULL" not in rest,
            "primary_key": "PRIMARY KEY" in rest,
            "unique": "UNIQUE" in rest,
            "default": self._extract_default(match.group(3)),
        }

    def _extract_default(self, rest: str) -> Optional[str]:
        """Extract DEFAULT value from column definition."""
        match = re.search(r"DEFAULT\s+([^\s,]+)", rest, re.IGNORECASE)
        if match:
            return match.group(1)
        return None

    def _parse_create_index(self, sql: str) -> Optional[dict]:
        """Parse CREATE INDEX statement."""
        match = re.search(
            r"CREATE\s+(?:UNIQUE\s+)?INDEX\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\"\[]?(\w+)[`\"\]]?\s+"
            r"ON\s+[`\"\[]?(\w+)[`\"\]]?\s*\(([^)]+)\)",
            sql,
            re.IGNORECASE
        )
        if not match:
            return None

        return {
            "name": match.group(1),
            "table": match.group(2),
            "columns": [c.strip().strip("`\"[]") for c in match.group(3).split(",")],
            "unique": "UNIQUE" in sql.upper(),
            "sql": sql,
        }

    def _parse_create_view(self, sql: str) -> Optional[dict]:
        """Parse CREATE VIEW statement."""
        match = re.search(
            r"CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+[`\"\[]?(\w+)[`\"\]]?\s+AS\s+(.+)",
            sql,
            re.IGNORECASE | re.DOTALL
        )
        if not match:
            return None

        return {
            "name": match.group(1),
            "query": match.group(2).strip(),
            "sql": sql,
        }

    def _build_entities(self, parsed: dict) -> list[Entity]:
        entities: list[Entity] = []

        # Tables
        for name, table in parsed["tables"].items():
            table_entity = Entity(
                id=f"table_{name}",
                name=name,
                entity_type=EntityType.SECTION,
                value={
                    "columns": table["columns"],
                    "constraints": table["constraints"],
                },
                path=f"tables.{name}",
                metadata={
                    "column_count": len(table["columns"]),
                    "constraint_count": len(table["constraints"]),
                },
                children=[],
            )
            entities.append(table_entity)

            # Column entities
            for col in table["columns"]:
                col_entity = Entity(
                    id=f"col_{name}_{col['name']}",
                    name=col["name"],
                    entity_type=EntityType.SECTION,
                    value=col,
                    path=f"tables.{name}.columns.{col['name']}",
                    metadata={
                        "type": col["type"],
                        "nullable": col["nullable"],
                    },
                    children=[],
                )
                entities.append(col_entity)

        # Indexes
        for name, index in parsed["indexes"].items():
            index_entity = Entity(
                id=f"index_{name}",
                name=name,
                entity_type=EntityType.SECTION,
                value=index,
                path=f"indexes.{name}",
                metadata={
                    "table": index["table"],
                    "unique": index["unique"],
                },
                children=[],
            )
            entities.append(index_entity)

        # Views
        for name, view in parsed["views"].items():
            view_entity = Entity(
                id=f"view_{name}",
                name=name,
                entity_type=EntityType.SECTION,
                value=view,
                path=f"views.{name}",
                metadata={},
                children=[],
            )
            entities.append(view_entity)

        return entities


def is_sql_available() -> bool:
    return HAS_SQLPARSE
