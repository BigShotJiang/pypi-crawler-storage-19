"""Dependency file normalizers (package.json, requirements.txt, etc.)."""

import json
import re
from pathlib import Path
from typing import Any, Optional

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)


class PackageJsonNormalizer:
    """Normalizer for package.json files."""

    SUPPORTED_TYPES = ["package-json", "npm"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.name.lower() == "package.json"

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            data = json.loads(content)

            if not isinstance(data, dict):
                raise NormalizationError("Invalid package.json", source)

            entities = self._build_entities(data)

            deps = data.get("dependencies", {})
            dev_deps = data.get("devDependencies", {})
            peer_deps = data.get("peerDependencies", {})
            optional_deps = data.get("optionalDependencies", {})

            return NormalizedObject(
                type="package-json",
                entities=entities,
                structure={
                    "name": data.get("name"),
                    "version": data.get("version"),
                    "dependency_count": len(deps),
                    "dev_dependency_count": len(dev_deps),
                    "peer_dependency_count": len(peer_deps),
                    "scripts": list(data.get("scripts", {}).keys()),
                },
                metadata={
                    "name": data.get("name"),
                    "version": data.get("version"),
                    "main": data.get("main"),
                    "type": data.get("type"),
                    "license": data.get("license"),
                    "engines": data.get("engines"),
                },
                source_path=path,
            )
        except json.JSONDecodeError as e:
            raise NormalizationError(f"Invalid JSON: {e}", source, e)
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse package.json: {e}", source, e)

    def _build_entities(self, data: dict) -> list[Entity]:
        entities: list[Entity] = []

        # Metadata entity
        meta_entity = Entity(
            id="metadata",
            name="metadata",
            entity_type=EntityType.METADATA,
            value={
                "name": data.get("name"),
                "version": data.get("version"),
                "description": data.get("description"),
                "main": data.get("main"),
                "type": data.get("type"),
            },
            path="_metadata",
            metadata={},
            children=[],
        )
        entities.append(meta_entity)

        # Dependencies
        for dep_type in ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"]:
            deps = data.get(dep_type, {})
            if deps:
                # Create text representation for diffing
                deps_text = "\n".join(f"{name}: {version}" for name, version in sorted(deps.items()))
                dep_entity = Entity(
                    id=f"deps_{dep_type}",
                    name=dep_type,
                    entity_type=EntityType.DOCUMENT,  # Use DOCUMENT for content diffing
                    value={"packages": deps, "text": deps_text},
                    path=f"dependencies.{dep_type}",
                    metadata={"count": len(deps)},
                    children=[],
                )
                entities.append(dep_entity)

                # Individual dependencies
                for name, version in deps.items():
                    pkg_entity = Entity(
                        id=f"pkg_{dep_type}_{name}",
                        name=name,
                        entity_type=EntityType.SECTION,
                        value={"name": name, "version": version, "type": dep_type, "text": f"{name}: {version}"},
                        path=f"dependencies.{dep_type}.{name}",
                        metadata={"version": version},
                        children=[],
                    )
                    entities.append(pkg_entity)

        # Scripts
        scripts = data.get("scripts", {})
        if scripts:
            scripts_entity = Entity(
                id="scripts",
                name="scripts",
                entity_type=EntityType.SECTION,
                value=scripts,
                path="scripts",
                metadata={"count": len(scripts)},
                children=[],
            )
            entities.append(scripts_entity)

        return entities


class RequirementsTxtNormalizer:
    """Normalizer for requirements.txt files."""

    SUPPORTED_TYPES = ["requirements", "pip"]

    # Patterns for parsing requirements
    REQ_PATTERN = re.compile(
        r"^(?P<name>[a-zA-Z0-9][-a-zA-Z0-9._]*)"
        r"(?:\[(?P<extras>[^\]]+)\])?"
        r"(?P<specifier>(?:[<>=!~]+[^;#\s]+)?)"
        r"(?:;(?P<marker>[^#]+))?"
        r"(?:\s*#(?P<comment>.*))?$"
    )

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        name = path.name.lower()
        return name in ("requirements.txt", "requirements-dev.txt", "requirements-test.txt") or \
               name.startswith("requirements") and name.endswith(".txt")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            requirements = self._parse_requirements(content)
            entities = self._build_entities(requirements)

            return NormalizedObject(
                type="requirements",
                entities=entities,
                structure={
                    "package_count": len(requirements),
                    "packages": [r["name"] for r in requirements],
                },
                metadata={
                    "package_count": len(requirements),
                    "has_version_pins": any(r["specifier"] for r in requirements),
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse requirements.txt: {e}", source, e)

    def _parse_requirements(self, content: str) -> list[dict]:
        requirements = []

        for line in content.split("\n"):
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            # Skip options like -r, -e, --index-url
            if line.startswith("-"):
                continue

            match = self.REQ_PATTERN.match(line)
            if match:
                requirements.append({
                    "name": match.group("name"),
                    "extras": match.group("extras"),
                    "specifier": match.group("specifier") or "",
                    "marker": match.group("marker"),
                    "raw": line,
                })
            else:
                # Try simple package name
                parts = re.split(r"[<>=!~\[]", line)
                if parts:
                    requirements.append({
                        "name": parts[0].strip(),
                        "extras": None,
                        "specifier": line[len(parts[0]):].strip() if len(parts) > 1 else "",
                        "marker": None,
                        "raw": line,
                    })

        return requirements

    def _build_entities(self, requirements: list[dict]) -> list[Entity]:
        entities: list[Entity] = []

        # All packages entity
        all_entity = Entity(
            id="packages",
            name="packages",
            entity_type=EntityType.SECTION,
            value={"packages": requirements},
            path="_packages",
            metadata={"count": len(requirements)},
            children=[],
        )
        entities.append(all_entity)

        # Individual packages
        for req in requirements:
            pkg_entity = Entity(
                id=f"pkg_{req['name']}",
                name=req["name"],
                entity_type=EntityType.SECTION,
                value=req,
                path=f"packages.{req['name']}",
                metadata={"specifier": req["specifier"]},
                children=[],
            )
            entities.append(pkg_entity)

        return entities


class PyprojectTomlNormalizer:
    """Normalizer for pyproject.toml files."""

    SUPPORTED_TYPES = ["pyproject", "pyproject-toml"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.name.lower() == "pyproject.toml"

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            # Use tomllib for Python 3.11+
            import tomllib
            content = path.read_bytes()
            data = tomllib.loads(content.decode("utf-8"))

            entities = self._build_entities(data)

            project = data.get("project", {})
            deps = project.get("dependencies", [])
            optional_deps = project.get("optional-dependencies", {})

            return NormalizedObject(
                type="pyproject",
                entities=entities,
                structure={
                    "name": project.get("name"),
                    "version": project.get("version"),
                    "dependency_count": len(deps),
                    "optional_dependency_groups": list(optional_deps.keys()),
                    "build_system": data.get("build-system", {}).get("build-backend"),
                },
                metadata={
                    "name": project.get("name"),
                    "version": project.get("version"),
                    "requires_python": project.get("requires-python"),
                    "license": project.get("license"),
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse pyproject.toml: {e}", source, e)

    def _build_entities(self, data: dict) -> list[Entity]:
        entities: list[Entity] = []

        project = data.get("project", {})

        # Project metadata
        meta_entity = Entity(
            id="metadata",
            name="metadata",
            entity_type=EntityType.METADATA,
            value={
                "name": project.get("name"),
                "version": project.get("version"),
                "description": project.get("description"),
                "requires_python": project.get("requires-python"),
            },
            path="_metadata",
            metadata={},
            children=[],
        )
        entities.append(meta_entity)

        # Dependencies
        deps = project.get("dependencies", [])
        if deps:
            deps_entity = Entity(
                id="dependencies",
                name="dependencies",
                entity_type=EntityType.SECTION,
                value={"packages": deps},
                path="project.dependencies",
                metadata={"count": len(deps)},
                children=[],
            )
            entities.append(deps_entity)

        # Optional dependencies
        optional_deps = project.get("optional-dependencies", {})
        for group, group_deps in optional_deps.items():
            group_entity = Entity(
                id=f"optional_{group}",
                name=group,
                entity_type=EntityType.SECTION,
                value={"packages": group_deps},
                path=f"project.optional-dependencies.{group}",
                metadata={"count": len(group_deps)},
                children=[],
            )
            entities.append(group_entity)

        # Scripts
        scripts = project.get("scripts", {})
        if scripts:
            scripts_entity = Entity(
                id="scripts",
                name="scripts",
                entity_type=EntityType.SECTION,
                value=scripts,
                path="project.scripts",
                metadata={"count": len(scripts)},
                children=[],
            )
            entities.append(scripts_entity)

        # Build system
        build_system = data.get("build-system", {})
        if build_system:
            build_entity = Entity(
                id="build_system",
                name="build-system",
                entity_type=EntityType.SECTION,
                value=build_system,
                path="build-system",
                metadata={},
                children=[],
            )
            entities.append(build_entity)

        # Tool configurations
        tool = data.get("tool", {})
        for tool_name, tool_config in tool.items():
            tool_entity = Entity(
                id=f"tool_{tool_name}",
                name=tool_name,
                entity_type=EntityType.SECTION,
                value=tool_config,
                path=f"tool.{tool_name}",
                metadata={},
                children=[],
            )
            entities.append(tool_entity)

        return entities


class GemfileNormalizer:
    """Normalizer for Gemfile (Ruby dependencies)."""

    SUPPORTED_TYPES = ["gemfile", "ruby"]

    GEM_PATTERN = re.compile(
        r"^\s*gem\s+['\"]([^'\"]+)['\"](?:\s*,\s*['\"]([^'\"]+)['\"])?"
    )

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.name in ("Gemfile", "Gemfile.lock")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            gems = self._parse_gems(content)
            entities = self._build_entities(gems)

            return NormalizedObject(
                type="gemfile",
                entities=entities,
                structure={
                    "gem_count": len(gems),
                    "gems": [g["name"] for g in gems],
                },
                metadata={
                    "gem_count": len(gems),
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse Gemfile: {e}", source, e)

    def _parse_gems(self, content: str) -> list[dict]:
        gems = []
        current_group = None

        for line in content.split("\n"):
            line = line.strip()

            # Check for group
            if line.startswith("group"):
                match = re.search(r":(\w+)", line)
                if match:
                    current_group = match.group(1)
                continue

            if line == "end":
                current_group = None
                continue

            # Parse gem
            match = self.GEM_PATTERN.match(line)
            if match:
                gems.append({
                    "name": match.group(1),
                    "version": match.group(2) or "",
                    "group": current_group,
                })

        return gems

    def _build_entities(self, gems: list[dict]) -> list[Entity]:
        entities: list[Entity] = []

        # All gems
        all_entity = Entity(
            id="gems",
            name="gems",
            entity_type=EntityType.SECTION,
            value={"gems": gems},
            path="_gems",
            metadata={"count": len(gems)},
            children=[],
        )
        entities.append(all_entity)

        # Individual gems
        for gem in gems:
            gem_entity = Entity(
                id=f"gem_{gem['name']}",
                name=gem["name"],
                entity_type=EntityType.SECTION,
                value=gem,
                path=f"gems.{gem['name']}",
                metadata={"version": gem["version"], "group": gem["group"]},
                children=[],
            )
            entities.append(gem_entity)

        return entities


class CargoTomlNormalizer:
    """Normalizer for Cargo.toml (Rust dependencies)."""

    SUPPORTED_TYPES = ["cargo", "rust"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.name.lower() == "cargo.toml"

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            import tomllib
            content = path.read_bytes()
            data = tomllib.loads(content.decode("utf-8"))

            entities = self._build_entities(data)

            package = data.get("package", {})
            deps = data.get("dependencies", {})
            dev_deps = data.get("dev-dependencies", {})
            build_deps = data.get("build-dependencies", {})

            return NormalizedObject(
                type="cargo",
                entities=entities,
                structure={
                    "name": package.get("name"),
                    "version": package.get("version"),
                    "dependency_count": len(deps),
                    "dev_dependency_count": len(dev_deps),
                    "build_dependency_count": len(build_deps),
                },
                metadata={
                    "name": package.get("name"),
                    "version": package.get("version"),
                    "edition": package.get("edition"),
                    "license": package.get("license"),
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse Cargo.toml: {e}", source, e)

    def _build_entities(self, data: dict) -> list[Entity]:
        entities: list[Entity] = []

        package = data.get("package", {})

        # Package metadata
        meta_entity = Entity(
            id="metadata",
            name="metadata",
            entity_type=EntityType.METADATA,
            value={
                "name": package.get("name"),
                "version": package.get("version"),
                "edition": package.get("edition"),
                "authors": package.get("authors"),
            },
            path="_metadata",
            metadata={},
            children=[],
        )
        entities.append(meta_entity)

        # Dependencies
        for dep_type in ["dependencies", "dev-dependencies", "build-dependencies"]:
            deps = data.get(dep_type, {})
            if deps:
                dep_entity = Entity(
                    id=f"deps_{dep_type}",
                    name=dep_type,
                    entity_type=EntityType.SECTION,
                    value=deps,
                    path=f"{dep_type}",
                    metadata={"count": len(deps)},
                    children=[],
                )
                entities.append(dep_entity)

        # Features
        features = data.get("features", {})
        if features:
            features_entity = Entity(
                id="features",
                name="features",
                entity_type=EntityType.SECTION,
                value=features,
                path="features",
                metadata={"count": len(features)},
                children=[],
            )
            entities.append(features_entity)

        return entities


class GoModNormalizer:
    """Normalizer for go.mod files."""

    SUPPORTED_TYPES = ["go-mod", "go"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.name.lower() == "go.mod"

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            parsed = self._parse_go_mod(content)
            entities = self._build_entities(parsed)

            return NormalizedObject(
                type="go-mod",
                entities=entities,
                structure={
                    "module": parsed["module"],
                    "go_version": parsed["go_version"],
                    "require_count": len(parsed["require"]),
                    "replace_count": len(parsed["replace"]),
                },
                metadata={
                    "module": parsed["module"],
                    "go_version": parsed["go_version"],
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse go.mod: {e}", source, e)

    def _parse_go_mod(self, content: str) -> dict:
        result = {
            "module": "",
            "go_version": "",
            "require": [],
            "replace": [],
            "exclude": [],
        }

        in_block = None
        for line in content.split("\n"):
            line = line.strip()

            if not line or line.startswith("//"):
                continue

            # Module declaration
            if line.startswith("module "):
                result["module"] = line[7:].strip()
                continue

            # Go version
            if line.startswith("go "):
                result["go_version"] = line[3:].strip()
                continue

            # Block start
            if line.startswith("require ("):
                in_block = "require"
                continue
            if line.startswith("replace ("):
                in_block = "replace"
                continue
            if line.startswith("exclude ("):
                in_block = "exclude"
                continue

            # Block end
            if line == ")":
                in_block = None
                continue

            # Single line require
            if line.startswith("require "):
                parts = line[8:].split()
                if len(parts) >= 2:
                    result["require"].append({"path": parts[0], "version": parts[1]})
                continue

            # In block
            if in_block:
                parts = line.split()
                if len(parts) >= 2:
                    if in_block == "replace":
                        # replace old => new
                        if "=>" in line:
                            old_new = line.split("=>")
                            old_parts = old_new[0].strip().split()
                            new_parts = old_new[1].strip().split()
                            result["replace"].append({
                                "old": old_parts[0] if old_parts else "",
                                "new": new_parts[0] if new_parts else "",
                            })
                    else:
                        result[in_block].append({"path": parts[0], "version": parts[1]})

        return result

    def _build_entities(self, parsed: dict) -> list[Entity]:
        entities: list[Entity] = []

        # Module metadata
        meta_entity = Entity(
            id="metadata",
            name="metadata",
            entity_type=EntityType.METADATA,
            value={
                "module": parsed["module"],
                "go_version": parsed["go_version"],
            },
            path="_metadata",
            metadata={},
            children=[],
        )
        entities.append(meta_entity)

        # Requirements
        if parsed["require"]:
            req_entity = Entity(
                id="require",
                name="require",
                entity_type=EntityType.SECTION,
                value={"packages": parsed["require"]},
                path="require",
                metadata={"count": len(parsed["require"])},
                children=[],
            )
            entities.append(req_entity)

            for req in parsed["require"]:
                pkg_entity = Entity(
                    id=f"req_{req['path'].replace('/', '_')}",
                    name=req["path"],
                    entity_type=EntityType.SECTION,
                    value=req,
                    path=f"require.{req['path']}",
                    metadata={"version": req["version"]},
                    children=[],
                )
                entities.append(pkg_entity)

        # Replace directives
        if parsed["replace"]:
            replace_entity = Entity(
                id="replace",
                name="replace",
                entity_type=EntityType.SECTION,
                value={"replacements": parsed["replace"]},
                path="replace",
                metadata={"count": len(parsed["replace"])},
                children=[],
            )
            entities.append(replace_entity)

        return entities
