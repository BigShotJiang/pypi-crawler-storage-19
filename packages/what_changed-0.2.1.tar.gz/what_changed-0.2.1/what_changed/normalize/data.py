"""Data format normalizers (CSV, Excel)."""

import csv
from pathlib import Path
from typing import Any, Optional

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)

# Optional Excel support
try:
    import openpyxl
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False


class CSVNormalizer:
    """Normalizer for CSV files."""

    SUPPORTED_TYPES = ["csv", "tsv"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.suffix.lower() in (".csv", ".tsv")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            delimiter = "\t" if path.suffix.lower() == ".tsv" else ","

            with open(path, "r", encoding="utf-8", newline="") as f:
                # Detect if has header
                sample = f.read(8192)
                f.seek(0)
                sniffer = csv.Sniffer()
                try:
                    has_header = sniffer.has_header(sample)
                except csv.Error:
                    has_header = True

                f.seek(0)
                reader = csv.reader(f, delimiter=delimiter)
                rows = list(reader)

            if not rows:
                return self._empty_result(source, path)

            headers = rows[0] if has_header else [f"col_{i}" for i in range(len(rows[0]))]
            data_rows = rows[1:] if has_header else rows

            entities = self._build_entities(headers, data_rows)

            return NormalizedObject(
                type="csv",
                entities=entities,
                structure={
                    "row_count": len(data_rows),
                    "column_count": len(headers),
                    "headers": headers,
                    "has_header": has_header,
                },
                metadata={
                    "row_count": len(data_rows),
                    "column_count": len(headers),
                    "file_size": path.stat().st_size,
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse CSV: {e}", source, e)

    def _empty_result(self, source: str, path: Path) -> NormalizedObject:
        return NormalizedObject(
            type="csv",
            entities=[],
            structure={"row_count": 0, "column_count": 0, "headers": []},
            metadata={"row_count": 0, "column_count": 0},
            source_path=path,
        )

    def _build_entities(self, headers: list[str], rows: list[list[str]]) -> list[Entity]:
        entities: list[Entity] = []

        # Schema entity (column definitions) - store as text for diffing
        schema_text = ",".join(headers)
        schema_entity = Entity(
            id="schema",
            name="schema",
            entity_type=EntityType.SECTION,
            value={"columns": headers, "text": schema_text},
            path="_schema",
            metadata={"column_count": len(headers)},
            children=[],
        )
        entities.append(schema_entity)

        # Data entity - store as text for row-by-row diffing
        sample_rows = rows[:100]
        # Convert rows to text for diffing
        row_texts = [",".join(str(cell) for cell in row) for row in sample_rows]
        data_text = "\n".join(row_texts)

        data_entity = Entity(
            id="data",
            name="data",
            entity_type=EntityType.DOCUMENT,  # Use DOCUMENT for content diffing
            value={"rows": sample_rows, "headers": headers, "text": data_text},
            path="_data",
            metadata={"sample_size": len(sample_rows)},
            children=[],
        )
        entities.append(data_entity)

        # Column statistics
        for i, header in enumerate(headers):
            col_values = [row[i] if i < len(row) else "" for row in rows]
            unique_count = len(set(col_values))
            empty_count = sum(1 for v in col_values if not v.strip())

            col_entity = Entity(
                id=f"col_{header}",
                name=header,
                entity_type=EntityType.SECTION,
                value={
                    "index": i,
                    "unique_count": unique_count,
                    "empty_count": empty_count,
                    "sample_values": list(set(col_values))[:10],
                },
                path=f"columns.{header}",
                metadata={"index": i},
                children=[],
            )
            entities.append(col_entity)

        return entities


class ExcelNormalizer:
    """Normalizer for Excel files."""

    SUPPORTED_TYPES = ["excel", "xlsx", "xls"]

    def __init__(self):
        if not HAS_OPENPYXL:
            raise ImportError(
                "Excel support requires openpyxl. Install with: pip install what-changed[excel]"
            )

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.suffix.lower() in (".xlsx", ".xls", ".xlsm")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            workbook = openpyxl.load_workbook(path, read_only=True, data_only=True)

            entities = []
            total_rows = 0
            total_cells = 0

            for sheet_name in workbook.sheetnames:
                sheet = workbook[sheet_name]
                rows = list(sheet.iter_rows(values_only=True))

                if not rows:
                    continue

                # First row as headers
                headers = [str(h) if h else f"col_{i}" for i, h in enumerate(rows[0])]
                data_rows = rows[1:]

                total_rows += len(data_rows)
                total_cells += len(data_rows) * len(headers)

                sheet_entity = Entity(
                    id=f"sheet_{sheet_name}",
                    name=sheet_name,
                    entity_type=EntityType.SECTION,
                    value={
                        "headers": headers,
                        "row_count": len(data_rows),
                        "sample_rows": [list(r) for r in data_rows[:50]],
                    },
                    path=f"sheets.{sheet_name}",
                    metadata={
                        "row_count": len(data_rows),
                        "column_count": len(headers),
                    },
                    children=[],
                )
                entities.append(sheet_entity)

            workbook.close()

            return NormalizedObject(
                type="excel",
                entities=entities,
                structure={
                    "sheet_count": len(workbook.sheetnames),
                    "sheet_names": workbook.sheetnames,
                    "total_rows": total_rows,
                },
                metadata={
                    "sheet_count": len(workbook.sheetnames),
                    "total_rows": total_rows,
                    "file_size": path.stat().st_size,
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse Excel: {e}", source, e)


def is_excel_available() -> bool:
    return HAS_OPENPYXL
