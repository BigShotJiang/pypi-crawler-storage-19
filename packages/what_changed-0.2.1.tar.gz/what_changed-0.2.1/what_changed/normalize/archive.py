"""Archive content normalizer (ZIP, tar, etc.)."""

import tarfile
import zipfile
from pathlib import Path
from typing import Any, Optional
import hashlib

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)


class ZipNormalizer:
    """Normalizer for ZIP archives."""

    SUPPORTED_TYPES = ["zip", "jar", "war", "ear"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.suffix.lower() in (".zip", ".jar", ".war", ".ear", ".whl", ".egg")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            with zipfile.ZipFile(path, "r") as zf:
                entries = []
                total_size = 0
                total_compressed = 0

                for info in zf.infolist():
                    entry = {
                        "name": info.filename,
                        "size": info.file_size,
                        "compressed_size": info.compress_size,
                        "is_dir": info.is_dir(),
                        "crc": info.CRC,
                        "compress_type": info.compress_type,
                    }
                    entries.append(entry)
                    total_size += info.file_size
                    total_compressed += info.compress_size

                entities = self._build_entities(entries)

                # File listing by directory
                dirs = set()
                files = []
                for e in entries:
                    if e["is_dir"]:
                        dirs.add(e["name"])
                    else:
                        files.append(e["name"])
                        # Add parent dirs
                        parts = e["name"].split("/")
                        for i in range(1, len(parts)):
                            dirs.add("/".join(parts[:i]) + "/")

                return NormalizedObject(
                    type="zip",
                    entities=entities,
                    structure={
                        "file_count": len(files),
                        "directory_count": len(dirs),
                        "total_size": total_size,
                        "compressed_size": total_compressed,
                    },
                    metadata={
                        "file_count": len(files),
                        "directory_count": len(dirs),
                        "total_size": total_size,
                        "compressed_size": total_compressed,
                        "compression_ratio": round(total_compressed / total_size, 2) if total_size else 0,
                        "archive_size": path.stat().st_size,
                    },
                    source_path=path,
                )
        except zipfile.BadZipFile as e:
            raise NormalizationError(f"Invalid ZIP file: {e}", source, e)
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse ZIP: {e}", source, e)

    def _build_entities(self, entries: list[dict]) -> list[Entity]:
        entities: list[Entity] = []

        # Archive overview
        overview_entity = Entity(
            id="overview",
            name="overview",
            entity_type=EntityType.METADATA,
            value={
                "entry_count": len(entries),
                "files": [e["name"] for e in entries if not e["is_dir"]],
            },
            path="_overview",
            metadata={},
            children=[],
        )
        entities.append(overview_entity)

        # Group by extension
        by_ext: dict[str, list[dict]] = {}
        for entry in entries:
            if entry["is_dir"]:
                continue
            ext = Path(entry["name"]).suffix.lower() or ".none"
            if ext not in by_ext:
                by_ext[ext] = []
            by_ext[ext].append(entry)

        for ext, ext_entries in by_ext.items():
            ext_entity = Entity(
                id=f"ext_{ext}",
                name=ext,
                entity_type=EntityType.SECTION,
                value={
                    "files": [e["name"] for e in ext_entries],
                    "total_size": sum(e["size"] for e in ext_entries),
                },
                path=f"extensions.{ext}",
                metadata={"count": len(ext_entries)},
                children=[],
            )
            entities.append(ext_entity)

        # Individual file entities (for important files)
        important_files = [
            "manifest.mf", "package.json", "pom.xml", "build.gradle",
            "setup.py", "pyproject.toml", "cargo.toml", "go.mod"
        ]
        for entry in entries:
            if entry["is_dir"]:
                continue
            filename = Path(entry["name"]).name.lower()
            if filename in important_files or entry["name"].endswith(".md"):
                file_entity = Entity(
                    id=f"file_{entry['crc']}",
                    name=entry["name"],
                    entity_type=EntityType.SECTION,
                    value=entry,
                    path=f"files.{entry['name']}",
                    metadata={"size": entry["size"]},
                    children=[],
                )
                entities.append(file_entity)

        return entities


class TarNormalizer:
    """Normalizer for tar archives."""

    SUPPORTED_TYPES = ["tar", "tgz", "tar.gz", "tar.bz2", "tar.xz"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        name = path.name.lower()
        return (
            name.endswith(".tar") or
            name.endswith(".tar.gz") or
            name.endswith(".tgz") or
            name.endswith(".tar.bz2") or
            name.endswith(".tar.xz")
        )

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            mode = "r:*"  # Auto-detect compression
            with tarfile.open(path, mode) as tf:
                entries = []
                total_size = 0

                for member in tf.getmembers():
                    entry = {
                        "name": member.name,
                        "size": member.size,
                        "is_dir": member.isdir(),
                        "is_file": member.isfile(),
                        "is_link": member.issym() or member.islnk(),
                        "mode": member.mode,
                        "uid": member.uid,
                        "gid": member.gid,
                    }
                    entries.append(entry)
                    if member.isfile():
                        total_size += member.size

                entities = self._build_entities(entries)

                dirs = [e for e in entries if e["is_dir"]]
                files = [e for e in entries if e["is_file"]]

                return NormalizedObject(
                    type="tar",
                    entities=entities,
                    structure={
                        "file_count": len(files),
                        "directory_count": len(dirs),
                        "total_size": total_size,
                    },
                    metadata={
                        "file_count": len(files),
                        "directory_count": len(dirs),
                        "total_size": total_size,
                        "archive_size": path.stat().st_size,
                    },
                    source_path=path,
                )
        except tarfile.TarError as e:
            raise NormalizationError(f"Invalid tar file: {e}", source, e)
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse tar: {e}", source, e)

    def _build_entities(self, entries: list[dict]) -> list[Entity]:
        entities: list[Entity] = []

        # Archive overview
        files = [e for e in entries if e["is_file"]]
        overview_entity = Entity(
            id="overview",
            name="overview",
            entity_type=EntityType.METADATA,
            value={
                "entry_count": len(entries),
                "files": [e["name"] for e in files],
            },
            path="_overview",
            metadata={},
            children=[],
        )
        entities.append(overview_entity)

        # Group by extension
        by_ext: dict[str, list[dict]] = {}
        for entry in files:
            ext = Path(entry["name"]).suffix.lower() or ".none"
            if ext not in by_ext:
                by_ext[ext] = []
            by_ext[ext].append(entry)

        for ext, ext_entries in by_ext.items():
            ext_entity = Entity(
                id=f"ext_{ext}",
                name=ext,
                entity_type=EntityType.SECTION,
                value={
                    "files": [e["name"] for e in ext_entries],
                    "total_size": sum(e["size"] for e in ext_entries),
                },
                path=f"extensions.{ext}",
                metadata={"count": len(ext_entries)},
                children=[],
            )
            entities.append(ext_entity)

        return entities
