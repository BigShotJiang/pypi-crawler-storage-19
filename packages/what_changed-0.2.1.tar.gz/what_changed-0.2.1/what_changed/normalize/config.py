"""Configuration file normalizers (JSON, YAML, ENV, TOML, INI)."""

import json
import re
from pathlib import Path
from typing import Any, Optional
import hashlib

try:
    import yaml
    YAML_AVAILABLE = True
except ImportError:
    YAML_AVAILABLE = False

try:
    import tomllib
    TOML_AVAILABLE = True
except ImportError:
    try:
        import tomli as tomllib
        TOML_AVAILABLE = True
    except ImportError:
        TOML_AVAILABLE = False

from configparser import ConfigParser

from what_changed.normalize.base import (
    Normalizer,
    NormalizedObject,
    NormalizationError,
    Entity,
    EntityType,
)


def _make_entity_id(path: str, value: Any) -> str:
    """Generate a stable entity ID from path and value."""
    value_str = str(value) if not isinstance(value, (dict, list)) else type(value).__name__
    return hashlib.md5(f"{path}:{value_str}".encode()).hexdigest()[:12]


def _get_value_type(value: Any) -> str:
    """Get a string representation of the value type."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    return "unknown"


def _dict_to_entities(
    data: dict[str, Any],
    parent_path: str = "",
    depth: int = 0,
) -> list[Entity]:
    """
    Convert a dictionary to a list of entities.

    Creates a hierarchical structure where each key becomes an entity,
    and nested dicts/lists are represented as children.
    """
    entities: list[Entity] = []

    for key, value in data.items():
        current_path = f"{parent_path}.{key}" if parent_path else key
        entity_id = _make_entity_id(current_path, value)

        if isinstance(value, dict):
            # Create entity for the dict itself with children
            children = _dict_to_entities(value, current_path, depth + 1)
            entity = Entity(
                id=f"key_{entity_id}",
                name=key,
                entity_type=EntityType.SECTION,
                value=value,
                path=current_path,
                metadata={
                    "depth": depth,
                    "value_type": "object",
                    "child_count": len(value),
                },
                children=children,
            )
        elif isinstance(value, list):
            # Create entity for the list with children for each item
            children: list[Entity] = []
            for i, item in enumerate(value):
                item_path = f"{current_path}[{i}]"
                item_id = _make_entity_id(item_path, item)

                if isinstance(item, dict):
                    item_children = _dict_to_entities(item, item_path, depth + 2)
                    child = Entity(
                        id=f"item_{item_id}",
                        name=f"[{i}]",
                        entity_type=EntityType.SECTION,
                        value=item,
                        path=item_path,
                        metadata={
                            "depth": depth + 1,
                            "value_type": "object",
                            "index": i,
                        },
                        children=item_children,
                    )
                else:
                    child = Entity(
                        id=f"item_{item_id}",
                        name=f"[{i}]",
                        entity_type=EntityType.VALUE,
                        value=item,
                        path=item_path,
                        metadata={
                            "depth": depth + 1,
                            "value_type": _get_value_type(item),
                            "index": i,
                        },
                    )
                children.append(child)

            entity = Entity(
                id=f"key_{entity_id}",
                name=key,
                entity_type=EntityType.KEY,
                value=value,
                path=current_path,
                metadata={
                    "depth": depth,
                    "value_type": "array",
                    "item_count": len(value),
                },
                children=children,
            )
        else:
            # Scalar value
            entity = Entity(
                id=f"key_{entity_id}",
                name=key,
                entity_type=EntityType.KEY,
                value=value,
                path=current_path,
                metadata={
                    "depth": depth,
                    "value_type": _get_value_type(value),
                },
            )

        entities.append(entity)

    return entities


class ConfigNormalizer(Normalizer):
    """
    Normalizer for configuration files.

    Supports JSON, YAML, ENV, TOML, and INI formats.
    Converts all formats to a common entity structure.
    """

    SUPPORTED_TYPES = ["json", "yaml", "yml", "env", "toml", "ini", "cfg"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        """Check if this normalizer can handle the source."""
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True

        path = Path(source)
        if path.exists() and path.is_file():
            # Check by extension
            suffix = path.suffix.lower().lstrip('.')
            if suffix in self.SUPPORTED_TYPES:
                return True

            # Check for .env files
            if path.name.startswith('.env'):
                return True

        return False

    def normalize(self, source: str) -> NormalizedObject:
        """Normalize a configuration file."""
        path = Path(source)

        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        if not path.is_file():
            raise NormalizationError(f"Not a file: {source}", source)

        # Determine format
        format_type = self._detect_format(path)

        # Parse based on format
        try:
            if format_type == "json":
                data = self._parse_json(path)
            elif format_type in ("yaml", "yml"):
                data = self._parse_yaml(path)
            elif format_type == "env":
                data = self._parse_env(path)
            elif format_type == "toml":
                data = self._parse_toml(path)
            elif format_type in ("ini", "cfg"):
                data = self._parse_ini(path)
            else:
                raise NormalizationError(f"Unsupported format: {format_type}", source)
        except NormalizationError:
            raise
        except Exception as e:
            raise NormalizationError(f"Failed to parse {format_type}: {e}", source, e)

        # Convert to entities
        entities = _dict_to_entities(data)

        # Calculate structure info
        def count_keys(d: dict, depth: int = 0) -> tuple[int, int]:
            """Count total keys and max depth."""
            total = 0
            max_depth = depth
            for v in d.values():
                total += 1
                if isinstance(v, dict):
                    sub_total, sub_depth = count_keys(v, depth + 1)
                    total += sub_total
                    max_depth = max(max_depth, sub_depth)
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, dict):
                            sub_total, sub_depth = count_keys(item, depth + 1)
                            total += sub_total
                            max_depth = max(max_depth, sub_depth)
            return total, max_depth

        total_keys, max_depth = count_keys(data)

        return NormalizedObject(
            type=format_type,
            entities=entities,
            structure={
                "format": format_type,
                "total_keys": total_keys,
                "max_depth": max_depth,
                "top_level_keys": list(data.keys()),
            },
            metadata={
                "filename": path.name,
                "extension": path.suffix,
                "size_bytes": path.stat().st_size,
            },
            source_path=path,
        )

    def _detect_format(self, path: Path) -> str:
        """Detect the configuration format from the file."""
        suffix = path.suffix.lower().lstrip('.')

        if suffix in ("json",):
            return "json"
        if suffix in ("yaml", "yml"):
            return "yaml"
        if suffix in ("toml",):
            return "toml"
        if suffix in ("ini", "cfg"):
            return "ini"

        # Check for .env files
        if path.name.startswith('.env') or suffix == "env":
            return "env"

        # Try to detect from content
        try:
            content = path.read_text(encoding='utf-8').strip()

            # JSON starts with { or [
            if content.startswith(('{', '[')):
                return "json"

            # TOML has [section] headers
            if re.search(r'^\[[^\]]+\]', content, re.MULTILINE):
                # Could be INI or TOML - check for TOML-specific syntax
                if '=' in content and ('"""' in content or "'''" in content or '[[' in content):
                    return "toml"
                return "ini"

            # ENV has KEY=value pattern (skip comment lines)
            for line in content.split('\n'):
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if re.match(r'^[A-Z_][A-Z0-9_]*=', line):
                    return "env"
                break  # First non-comment line doesn't match ENV pattern

            # Default to YAML
            return "yaml"
        except Exception:
            return "yaml"

    def _parse_json(self, path: Path) -> dict[str, Any]:
        """Parse a JSON file."""
        content = path.read_text(encoding='utf-8')
        data = json.loads(content)
        if not isinstance(data, dict):
            # Wrap non-dict JSON in a root key
            return {"_root": data}
        return data

    def _parse_yaml(self, path: Path) -> dict[str, Any]:
        """Parse a YAML file."""
        if not YAML_AVAILABLE:
            raise NormalizationError(
                "YAML parsing requires PyYAML. Install with: pip install pyyaml",
                str(path),
            )

        content = path.read_text(encoding='utf-8')
        data = yaml.safe_load(content)

        if data is None:
            return {}
        if not isinstance(data, dict):
            return {"_root": data}
        return data

    def _parse_env(self, path: Path) -> dict[str, Any]:
        """Parse an ENV file."""
        data: dict[str, Any] = {}
        content = path.read_text(encoding='utf-8')

        for line in content.splitlines():
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith('#'):
                continue

            # Parse KEY=value
            if '=' in line:
                key, _, value = line.partition('=')
                key = key.strip()

                # Remove quotes from value
                value = value.strip()
                if (value.startswith('"') and value.endswith('"')) or \
                   (value.startswith("'") and value.endswith("'")):
                    value = value[1:-1]

                # Try to parse as number or boolean
                parsed_value: Any = value
                if value.lower() in ('true', 'false'):
                    parsed_value = value.lower() == 'true'
                else:
                    try:
                        parsed_value = int(value)
                    except ValueError:
                        try:
                            parsed_value = float(value)
                        except ValueError:
                            pass

                data[key] = parsed_value

        return data

    def _parse_toml(self, path: Path) -> dict[str, Any]:
        """Parse a TOML file."""
        if not TOML_AVAILABLE:
            raise NormalizationError(
                "TOML parsing requires tomllib (Python 3.11+) or tomli. "
                "Install with: pip install tomli",
                str(path),
            )

        content = path.read_bytes()
        return tomllib.loads(content.decode('utf-8'))

    def _parse_ini(self, path: Path) -> dict[str, Any]:
        """Parse an INI file."""
        parser = ConfigParser()
        parser.read(path, encoding='utf-8')

        data: dict[str, Any] = {}

        # Handle default section
        if parser.defaults():
            data["DEFAULT"] = dict(parser.defaults())

        # Handle other sections
        for section in parser.sections():
            data[section] = {}
            for key, value in parser.items(section):
                # Skip keys from DEFAULT that appear in every section
                if key in parser.defaults() and parser.defaults()[key] == value:
                    continue
                data[section][key] = value

        return data

    @property
    def supported_types(self) -> list[str]:
        """List of source types this normalizer supports."""
        return self.SUPPORTED_TYPES.copy()
