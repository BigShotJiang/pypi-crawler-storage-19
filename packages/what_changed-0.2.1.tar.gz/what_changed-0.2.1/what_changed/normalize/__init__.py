"""Normalization module for converting various inputs to a common format."""

from what_changed.normalize.base import (
    Normalizer,
    NormalizedObject,
    NormalizationError,
    Entity,
    EntityType,
)
from what_changed.normalize.registry import NormalizerRegistry, create_default_registry

__all__ = [
    "Normalizer",
    "NormalizedObject",
    "NormalizationError",
    "Entity",
    "EntityType",
    "NormalizerRegistry",
    "create_default_registry",
]
