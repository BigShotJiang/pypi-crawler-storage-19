"""Image metadata normalizer with OCR support."""

from pathlib import Path
from typing import Any, Optional

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)

# Optional PIL support
try:
    from PIL import Image
    from PIL.ExifTags import TAGS, GPSTAGS
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

# Optional OCR support
try:
    import pytesseract
    import shutil
    import os
    import sys

    # Auto-detect Tesseract if not in PATH
    if not shutil.which("tesseract"):
        search_paths = []

        if sys.platform == "win32":
            # Windows paths
            search_paths = [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
                os.path.expandvars(r"%LOCALAPPDATA%\Tesseract-OCR\tesseract.exe"),
            ]
        elif sys.platform == "darwin":
            # macOS paths (Homebrew)
            search_paths = [
                "/usr/local/bin/tesseract",
                "/opt/homebrew/bin/tesseract",
            ]
        else:
            # Linux paths
            search_paths = [
                "/usr/bin/tesseract",
                "/usr/local/bin/tesseract",
            ]

        for path in search_paths:
            if os.path.exists(path):
                pytesseract.pytesseract.tesseract_cmd = path
                break

    HAS_OCR = True
except ImportError:
    HAS_OCR = False


class ImageNormalizer:
    """Normalizer for image files (metadata comparison)."""

    SUPPORTED_TYPES = ["image", "png", "jpg", "jpeg", "gif", "bmp", "tiff", "webp"]

    def __init__(self):
        if not HAS_PIL:
            raise ImportError(
                "Image support requires Pillow. Install with: pip install what-changed[image]"
            )

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        return path.suffix.lower() in (
            ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".tif", ".webp"
        )

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            with Image.open(path) as img:
                # Basic image info
                width, height = img.size
                mode = img.mode
                format_name = img.format

                # EXIF data
                exif_data = self._extract_exif(img)

                # OCR text extraction
                ocr_text = self._extract_ocr_text(img)
                has_text = bool(ocr_text and ocr_text.strip())
                word_count = len(ocr_text.split()) if has_text else 0

                entities = self._build_entities(img, path, ocr_text)

                return NormalizedObject(
                    type="image",
                    entities=entities,
                    structure={
                        "width": width,
                        "height": height,
                        "mode": mode,
                        "format": format_name,
                        "has_exif": bool(exif_data),
                        "has_text": has_text,
                        "word_count": word_count,
                    },
                    metadata={
                        "width": width,
                        "height": height,
                        "aspect_ratio": round(width / height, 2) if height else 0,
                        "mode": mode,
                        "format": format_name,
                        "file_size": path.stat().st_size,
                        "has_text": has_text,
                        "word_count": word_count,
                        "ocr_available": HAS_OCR,
                        **exif_data,
                    },
                    source_path=path,
                )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse image: {e}", source, e)

    def _extract_ocr_text(self, img: "Image.Image") -> str:
        """Extract text from image using OCR."""
        if not HAS_OCR:
            return ""

        try:
            # Run OCR on the image
            text = pytesseract.image_to_string(img)
            return text.strip()
        except Exception:
            # OCR failed, return empty
            return ""

    def _extract_exif(self, img: "Image.Image") -> dict:
        """Extract EXIF metadata from image."""
        exif_data = {}

        try:
            exif = img._getexif()
            if exif:
                for tag_id, value in exif.items():
                    tag = TAGS.get(tag_id, tag_id)
                    # Skip binary data
                    if isinstance(value, bytes):
                        continue
                    # Convert to string for JSON serialization
                    if hasattr(value, "numerator"):  # Rational number
                        value = float(value)
                    exif_data[str(tag)] = value
        except (AttributeError, KeyError):
            pass

        return exif_data

    def _build_entities(self, img: "Image.Image", path: Path, ocr_text: str = "") -> list[Entity]:
        entities: list[Entity] = []

        width, height = img.size

        # Image info entity
        info_entity = Entity(
            id="image_info",
            name="image_info",
            entity_type=EntityType.METADATA,
            value={
                "width": width,
                "height": height,
                "mode": img.mode,
                "format": img.format,
                "file_size": path.stat().st_size,
            },
            path="_info",
            metadata={},
            children=[],
        )
        entities.append(info_entity)

        # OCR text content entity (if text was extracted)
        if ocr_text and ocr_text.strip():
            text_entity = Entity(
                id="text_content",
                name="text_content",
                entity_type=EntityType.SECTION,
                value={
                    "text": ocr_text,
                    "word_count": len(ocr_text.split()),
                    "char_count": len(ocr_text),
                },
                path="_text",
                metadata={
                    "word_count": len(ocr_text.split()),
                    "source": "ocr",
                },
                children=[],
            )
            entities.append(text_entity)

        # Dimensions entity
        dim_entity = Entity(
            id="dimensions",
            name="dimensions",
            entity_type=EntityType.SECTION,
            value={
                "width": width,
                "height": height,
                "aspect_ratio": round(width / height, 2) if height else 0,
                "megapixels": round((width * height) / 1_000_000, 2),
            },
            path="_dimensions",
            metadata={},
            children=[],
        )
        entities.append(dim_entity)

        # EXIF entity if available
        exif_data = self._extract_exif(img)
        if exif_data:
            exif_entity = Entity(
                id="exif",
                name="exif",
                entity_type=EntityType.METADATA,
                value=exif_data,
                path="_exif",
                metadata={"field_count": len(exif_data)},
                children=[],
            )
            entities.append(exif_entity)

            # Camera info
            camera_fields = ["Make", "Model", "LensModel", "Software"]
            camera_data = {k: v for k, v in exif_data.items() if k in camera_fields}
            if camera_data:
                camera_entity = Entity(
                    id="camera",
                    name="camera",
                    entity_type=EntityType.SECTION,
                    value=camera_data,
                    path="_camera",
                    metadata={},
                    children=[],
                )
                entities.append(camera_entity)

            # Exposure info
            exposure_fields = [
                "ExposureTime", "FNumber", "ISOSpeedRatings", "FocalLength",
                "ExposureProgram", "MeteringMode", "Flash"
            ]
            exposure_data = {k: v for k, v in exif_data.items() if k in exposure_fields}
            if exposure_data:
                exposure_entity = Entity(
                    id="exposure",
                    name="exposure",
                    entity_type=EntityType.SECTION,
                    value=exposure_data,
                    path="_exposure",
                    metadata={},
                    children=[],
                )
                entities.append(exposure_entity)

        # Color mode entity
        mode_entity = Entity(
            id="color_mode",
            name="color_mode",
            entity_type=EntityType.SECTION,
            value={
                "mode": img.mode,
                "bands": img.getbands(),
                "palette": img.palette.mode if img.palette else None,
            },
            path="_color",
            metadata={},
            children=[],
        )
        entities.append(mode_entity)

        return entities


def is_image_available() -> bool:
    """Check if image support is available."""
    return HAS_PIL


def is_image_ocr_available() -> bool:
    """Check if OCR support is available for images."""
    return HAS_PIL and HAS_OCR
