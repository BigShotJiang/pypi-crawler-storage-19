"""Base classes for normalization."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any, Optional


class EntityType(Enum):
    """Types of entities that can be extracted from sources."""

    # Config entities
    KEY = auto()
    VALUE = auto()
    SECTION = auto()
    ENVIRONMENT_VAR = auto()

    # File/Directory entities
    FILE = auto()
    DIRECTORY = auto()

    # Document entities
    DOCUMENT = auto()
    METADATA = auto()
    PAGE = auto()

    # Code entities (for future use)
    FUNCTION = auto()
    CLASS = auto()
    METHOD = auto()
    VARIABLE = auto()
    IMPORT = auto()

    # API entities (for future use)
    ENDPOINT = auto()
    PARAMETER = auto()
    RESPONSE = auto()

    # Generic
    TEXT_BLOCK = auto()
    LINE = auto()
    UNKNOWN = auto()


@dataclass
class Entity:
    """
    Represents a single entity extracted from a source.

    An entity is the smallest unit of comparison - it could be a config key,
    a file, a function, an API endpoint, etc.
    """

    id: str  # Unique identifier within the normalized object
    name: str  # Human-readable name
    entity_type: EntityType
    value: Any  # The actual value/content
    path: str  # Path within the source (e.g., "config.database.host")
    metadata: dict[str, Any] = field(default_factory=dict)
    children: list["Entity"] = field(default_factory=list)

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Entity):
            return False
        return self.id == other.id

    @property
    def has_children(self) -> bool:
        """Check if this entity has child entities."""
        return len(self.children) > 0

    def get_child(self, name: str) -> Optional["Entity"]:
        """Get a child entity by name."""
        for child in self.children:
            if child.name == name:
                return child
        return None

    def flatten(self) -> list["Entity"]:
        """Flatten this entity and all descendants into a list."""
        result = [self]
        for child in self.children:
            result.extend(child.flatten())
        return result


@dataclass
class NormalizedObject:
    """
    A normalized representation of any source.

    This is the common format that all sources are converted to,
    enabling semantic comparison regardless of original format.
    """

    type: str  # Type identifier (e.g., "json", "yaml", "directory")
    entities: list[Entity]  # List of top-level entities
    structure: dict[str, Any]  # Structural information about the source
    metadata: dict[str, Any]  # Additional metadata

    # Source information
    source_path: Optional[Path] = None
    source_url: Optional[str] = None

    @property
    def entity_count(self) -> int:
        """Total number of entities including nested ones."""
        return sum(len(e.flatten()) for e in self.entities)

    def get_entity_by_id(self, entity_id: str) -> Optional[Entity]:
        """Find an entity by its ID."""
        for entity in self.entities:
            for e in entity.flatten():
                if e.id == entity_id:
                    return e
        return None

    def get_entity_by_path(self, path: str) -> Optional[Entity]:
        """Find an entity by its path."""
        for entity in self.entities:
            for e in entity.flatten():
                if e.path == path:
                    return e
        return None

    def get_all_paths(self) -> set[str]:
        """Get all entity paths in this normalized object."""
        paths: set[str] = set()
        for entity in self.entities:
            for e in entity.flatten():
                paths.add(e.path)
        return paths

    def to_dict(self) -> dict[str, Any]:
        """Convert to a dictionary representation."""

        def entity_to_dict(e: Entity) -> dict[str, Any]:
            return {
                "id": e.id,
                "name": e.name,
                "type": e.entity_type.name,
                "value": e.value if not isinstance(e.value, (dict, list)) else str(type(e.value)),
                "path": e.path,
                "metadata": e.metadata,
                "children": [entity_to_dict(c) for c in e.children],
            }

        return {
            "type": self.type,
            "entities": [entity_to_dict(e) for e in self.entities],
            "structure": self.structure,
            "metadata": self.metadata,
            "source_path": str(self.source_path) if self.source_path else None,
            "source_url": self.source_url,
        }


class Normalizer(ABC):
    """
    Abstract base class for normalizers.

    A normalizer converts a specific type of source into a NormalizedObject.
    Each normalizer should handle one or more related source types.
    """

    @abstractmethod
    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        """
        Check if this normalizer can handle the given source.

        Args:
            source: Path or URL to the source
            source_type: Optional hint about the source type

        Returns:
            True if this normalizer can handle the source
        """
        ...

    @abstractmethod
    def normalize(self, source: str) -> NormalizedObject:
        """
        Normalize the source into a NormalizedObject.

        Args:
            source: Path or URL to the source

        Returns:
            NormalizedObject representation of the source

        Raises:
            NormalizationError: If normalization fails
        """
        ...

    @property
    @abstractmethod
    def supported_types(self) -> list[str]:
        """List of source types this normalizer supports."""
        ...


class NormalizationError(Exception):
    """Raised when normalization fails."""

    def __init__(self, message: str, source: str, cause: Optional[Exception] = None):
        super().__init__(message)
        self.source = source
        self.cause = cause
