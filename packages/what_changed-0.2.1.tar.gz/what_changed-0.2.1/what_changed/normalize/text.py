"""Text file normalizer."""

from pathlib import Path
from typing import Optional
import hashlib

from what_changed.normalize.base import (
    Normalizer,
    NormalizedObject,
    NormalizationError,
    Entity,
    EntityType,
)


class TextNormalizer(Normalizer):
    """
    Normalizer for plain text files.

    Converts text files into a normalized form where each line is an entity.
    This serves as a fallback for files that don't have a more specific normalizer.
    """

    SUPPORTED_TYPES = ["text", "txt", "md", "rst", "log", "csv"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        """Check if this normalizer can handle the source."""
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True

        path = Path(source)
        if path.exists() and path.is_file():
            # Check extension
            suffix = path.suffix.lower().lstrip('.')
            if suffix in self.SUPPORTED_TYPES:
                return True

            # Try to read as text
            try:
                with open(path, 'rb') as f:
                    head = f.read(1024)
                # Check for binary content
                if b'\x00' not in head:
                    try:
                        head.decode('utf-8')
                        return True
                    except UnicodeDecodeError:
                        pass
            except (OSError, IOError):
                pass

        return False

    def normalize(self, source: str) -> NormalizedObject:
        """
        Normalize a text file.

        Each line becomes an entity with:
        - id: hash of line number and content
        - name: "line_{n}"
        - value: the line content
        - path: "{n}" (line number as string)
        """
        path = Path(source)

        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        if not path.is_file():
            raise NormalizationError(f"Not a file: {source}", source)

        try:
            # Try UTF-8 with BOM first (Windows), then plain UTF-8
            content = path.read_text(encoding='utf-8-sig')
        except UnicodeDecodeError:
            try:
                content = path.read_text(encoding='latin-1')
            except Exception as e:
                raise NormalizationError(f"Failed to read file: {e}", source, e)
        except Exception as e:
            raise NormalizationError(f"Failed to read file: {e}", source, e)

        lines = content.splitlines()
        entities: list[Entity] = []

        for i, line in enumerate(lines, start=1):
            line_id = hashlib.md5(f"{i}:{line}".encode()).hexdigest()[:12]
            entity = Entity(
                id=f"line_{line_id}",
                name=f"line_{i}",
                entity_type=EntityType.LINE,
                value=line,
                path=str(i),
                metadata={
                    "line_number": i,
                    "length": len(line),
                    "is_blank": len(line.strip()) == 0,
                    "indent": len(line) - len(line.lstrip()) if line else 0,
                },
            )
            entities.append(entity)

        return NormalizedObject(
            type="text",
            entities=entities,
            structure={
                "total_lines": len(lines),
                "total_chars": len(content),
                "blank_lines": sum(1 for line in lines if not line.strip()),
                "encoding": "utf-8",
            },
            metadata={
                "filename": path.name,
                "extension": path.suffix,
                "size_bytes": path.stat().st_size,
            },
            source_path=path,
        )

    @property
    def supported_types(self) -> list[str]:
        """List of source types this normalizer supports."""
        return self.SUPPORTED_TYPES.copy()


class BlockTextNormalizer(Normalizer):
    """
    Alternative text normalizer that groups lines into blocks.

    Useful for files where logical grouping matters (like code or documentation).
    Blocks are separated by blank lines.
    """

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        """This normalizer must be explicitly requested."""
        return False  # Not auto-selected

    def normalize(self, source: str) -> NormalizedObject:
        """
        Normalize a text file into blocks.

        Consecutive non-blank lines are grouped into blocks.
        """
        path = Path(source)

        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding='utf-8')
        except Exception as e:
            raise NormalizationError(f"Failed to read file: {e}", source, e)

        lines = content.splitlines()
        entities: list[Entity] = []
        current_block: list[str] = []
        block_start = 1
        block_num = 0

        def flush_block() -> None:
            nonlocal current_block, block_num
            if current_block:
                block_num += 1
                block_content = '\n'.join(current_block)
                block_id = hashlib.md5(block_content.encode()).hexdigest()[:12]
                entities.append(Entity(
                    id=f"block_{block_id}",
                    name=f"block_{block_num}",
                    entity_type=EntityType.TEXT_BLOCK,
                    value=block_content,
                    path=f"{block_start}-{block_start + len(current_block) - 1}",
                    metadata={
                        "start_line": block_start,
                        "end_line": block_start + len(current_block) - 1,
                        "line_count": len(current_block),
                    },
                ))
                current_block = []

        for i, line in enumerate(lines, start=1):
            if not line.strip():
                flush_block()
                block_start = i + 1
            else:
                if not current_block:
                    block_start = i
                current_block.append(line)

        flush_block()  # Don't forget the last block

        return NormalizedObject(
            type="text_blocks",
            entities=entities,
            structure={
                "total_lines": len(lines),
                "total_blocks": len(entities),
            },
            metadata={
                "filename": path.name,
            },
            source_path=path,
        )

    @property
    def supported_types(self) -> list[str]:
        return ["text_blocks"]
