"""Registry for managing normalizers."""

from typing import Optional

from what_changed.detect import TypeDetector, SourceType
from what_changed.normalize.base import Normalizer, NormalizedObject, NormalizationError


class NormalizerRegistry:
    """
    Registry for normalizers.

    Manages the collection of normalizers and selects the appropriate one
    for each source based on type detection.
    """

    def __init__(self) -> None:
        self._normalizers: list[Normalizer] = []
        self._type_detector = TypeDetector()

    def register(self, normalizer: Normalizer) -> None:
        """
        Register a normalizer.

        Normalizers are tried in order of registration, so register
        more specific normalizers before general ones.
        """
        self._normalizers.append(normalizer)

    def get_normalizer(self, source: str) -> Optional[Normalizer]:
        """
        Get an appropriate normalizer for the given source.

        Args:
            source: Path or URL to the source

        Returns:
            A normalizer that can handle the source, or None if no match
        """
        detection = self._type_detector.detect(source)
        source_type = detection.source_type.name.lower()

        for normalizer in self._normalizers:
            if normalizer.can_handle(source, source_type):
                return normalizer

        return None

    def normalize(self, source: str) -> NormalizedObject:
        """
        Normalize a source using the appropriate normalizer.

        Args:
            source: Path or URL to the source

        Returns:
            NormalizedObject representation of the source

        Raises:
            NormalizationError: If no normalizer can handle the source
        """
        normalizer = self.get_normalizer(source)
        if normalizer is None:
            detection = self._type_detector.detect(source)
            raise NormalizationError(
                f"No normalizer found for source type: {detection.source_type.name}",
                source,
            )

        return normalizer.normalize(source)

    def detect_type(self, source: str) -> SourceType:
        """Detect the type of a source."""
        return self._type_detector.detect(source).source_type

    @property
    def registered_types(self) -> list[str]:
        """Get all types supported by registered normalizers."""
        types: list[str] = []
        for normalizer in self._normalizers:
            types.extend(normalizer.supported_types)
        return list(set(types))


def create_default_registry() -> NormalizerRegistry:
    """
    Create a registry with all default normalizers.

    Returns:
        NormalizerRegistry with standard normalizers registered
    """
    from what_changed.normalize.text import TextNormalizer
    from what_changed.normalize.config import ConfigNormalizer
    from what_changed.normalize.dir import DirectoryNormalizer

    registry = NormalizerRegistry()

    # Register normalizers in order of specificity (most specific first)

    # PDF normalizer (optional, requires pymupdf)
    try:
        from what_changed.normalize.pdf import PDFNormalizer, is_pdf_available
        if is_pdf_available():
            registry.register(PDFNormalizer())
    except ImportError:
        pass

    # OpenAPI normalizer (optional, requires openapi-spec-validator)
    try:
        from what_changed.normalize.openapi import OpenAPINormalizer, is_openapi_available
        if is_openapi_available():
            registry.register(OpenAPINormalizer())
    except ImportError:
        pass

    # Excel normalizer (optional, requires openpyxl)
    try:
        from what_changed.normalize.data import ExcelNormalizer, is_excel_available
        if is_excel_available():
            registry.register(ExcelNormalizer())
    except ImportError:
        pass

    # Image normalizer (optional, requires pillow)
    try:
        from what_changed.normalize.image import ImageNormalizer, is_image_available
        if is_image_available():
            registry.register(ImageNormalizer())
    except ImportError:
        pass

    # SQL normalizer (optional, requires sqlparse)
    try:
        from what_changed.normalize.sql import SQLNormalizer, is_sql_available
        if is_sql_available():
            registry.register(SQLNormalizer())
    except ImportError:
        pass

    # CSV normalizer (no extra deps)
    from what_changed.normalize.data import CSVNormalizer
    registry.register(CSVNormalizer())

    # Markdown normalizer (no extra deps)
    from what_changed.normalize.markdown import MarkdownNormalizer
    registry.register(MarkdownNormalizer())

    # Docker normalizers (no extra deps)
    from what_changed.normalize.docker import DockerfileNormalizer, DockerComposeNormalizer
    registry.register(DockerfileNormalizer())
    registry.register(DockerComposeNormalizer())

    # Dependency file normalizers (no extra deps)
    from what_changed.normalize.dependencies import (
        PackageJsonNormalizer,
        RequirementsTxtNormalizer,
        PyprojectTomlNormalizer,
        GemfileNormalizer,
        CargoTomlNormalizer,
        GoModNormalizer,
    )
    registry.register(PackageJsonNormalizer())
    registry.register(RequirementsTxtNormalizer())
    registry.register(PyprojectTomlNormalizer())
    registry.register(GemfileNormalizer())
    registry.register(CargoTomlNormalizer())
    registry.register(GoModNormalizer())

    # Archive normalizers (no extra deps)
    from what_changed.normalize.archive import ZipNormalizer, TarNormalizer
    registry.register(ZipNormalizer())
    registry.register(TarNormalizer())

    # General normalizers (register last)
    registry.register(ConfigNormalizer())
    registry.register(DirectoryNormalizer())
    registry.register(TextNormalizer())

    return registry
