"""Docker file normalizers (Dockerfile, docker-compose)."""

import re
from pathlib import Path
from typing import Any, Optional

import yaml

from what_changed.normalize.base import (
    NormalizedObject,
    NormalizationError,
    EntityType,
    Entity,
)


class DockerfileNormalizer:
    """Normalizer for Dockerfiles."""

    SUPPORTED_TYPES = ["dockerfile"]

    # Dockerfile instructions
    INSTRUCTIONS = {
        "FROM", "RUN", "CMD", "LABEL", "MAINTAINER", "EXPOSE", "ENV",
        "ADD", "COPY", "ENTRYPOINT", "VOLUME", "USER", "WORKDIR",
        "ARG", "ONBUILD", "STOPSIGNAL", "HEALTHCHECK", "SHELL",
    }

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        name = path.name.lower()
        return name in ("dockerfile", "containerfile") or name.startswith("dockerfile.")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            instructions = self._parse_instructions(content)
            entities = self._build_entities(instructions)

            # Extract key info
            base_images = [i["args"] for i in instructions if i["instruction"] == "FROM"]
            exposed_ports = []
            for i in instructions:
                if i["instruction"] == "EXPOSE":
                    exposed_ports.extend(i["args"].split())

            env_vars = {}
            for i in instructions:
                if i["instruction"] == "ENV":
                    parts = i["args"].split("=", 1)
                    if len(parts) == 2:
                        env_vars[parts[0].strip()] = parts[1].strip()
                    else:
                        parts = i["args"].split(None, 1)
                        if len(parts) == 2:
                            env_vars[parts[0]] = parts[1]

            return NormalizedObject(
                type="dockerfile",
                entities=entities,
                structure={
                    "instruction_count": len(instructions),
                    "base_images": base_images,
                    "exposed_ports": exposed_ports,
                    "stages": len(base_images),
                },
                metadata={
                    "base_image": base_images[0] if base_images else None,
                    "exposed_ports": exposed_ports,
                    "env_vars": list(env_vars.keys()),
                    "is_multistage": len(base_images) > 1,
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse Dockerfile: {e}", source, e)

    def _parse_instructions(self, content: str) -> list[dict]:
        """Parse Dockerfile into instructions."""
        instructions = []
        lines = content.split("\n")

        current_instruction = None
        current_args = []

        for i, line in enumerate(lines):
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#"):
                continue

            # Check for line continuation
            if current_instruction and line.endswith("\\"):
                current_args.append(line[:-1].strip())
                continue

            # End of continuation
            if current_instruction:
                current_args.append(line)
                instructions.append({
                    "instruction": current_instruction,
                    "args": " ".join(current_args),
                    "line": i + 1,
                })
                current_instruction = None
                current_args = []
                continue

            # New instruction
            parts = line.split(None, 1)
            if parts and parts[0].upper() in self.INSTRUCTIONS:
                instruction = parts[0].upper()
                args = parts[1] if len(parts) > 1 else ""

                if args.endswith("\\"):
                    current_instruction = instruction
                    current_args = [args[:-1].strip()]
                else:
                    instructions.append({
                        "instruction": instruction,
                        "args": args,
                        "line": i + 1,
                    })

        return instructions

    def _build_entities(self, instructions: list[dict]) -> list[Entity]:
        entities: list[Entity] = []

        # Create a full dockerfile representation for diffing
        full_text = "\n".join(f"{inst['instruction']} {inst['args']}" for inst in instructions)
        dockerfile_entity = Entity(
            id="dockerfile",
            name="dockerfile",
            entity_type=EntityType.DOCUMENT,
            value={"text": full_text, "instruction_count": len(instructions)},
            path="_dockerfile",
            metadata={"instruction_count": len(instructions)},
            children=[],
        )
        entities.append(dockerfile_entity)

        # Group by instruction type
        by_type: dict[str, list[dict]] = {}
        for inst in instructions:
            key = inst["instruction"]
            if key not in by_type:
                by_type[key] = []
            by_type[key].append(inst)

        # Create entity for each instruction type with text for diffing
        for inst_type, insts in by_type.items():
            inst_text = "\n".join(i["args"] for i in insts)
            entity = Entity(
                id=f"instruction_{inst_type.lower()}",
                name=inst_type,
                entity_type=EntityType.SECTION,
                value={
                    "instructions": [{"args": i["args"], "line": i["line"]} for i in insts],
                    "text": inst_text,
                },
                path=f"instructions.{inst_type}",
                metadata={"count": len(insts)},
                children=[],
            )
            entities.append(entity)

        # Individual instruction entities for detailed comparison
        for i, inst in enumerate(instructions):
            entity = Entity(
                id=f"step_{i}",
                name=f"{inst['instruction']}",
                entity_type=EntityType.SECTION,
                value={"text": inst["args"], **inst},
                path=f"steps.{i}",
                metadata={"line": inst["line"]},
                children=[],
            )
            entities.append(entity)

        return entities


class DockerComposeNormalizer:
    """Normalizer for docker-compose files."""

    SUPPORTED_TYPES = ["docker-compose", "compose"]

    def can_handle(self, source: str, source_type: Optional[str] = None) -> bool:
        if source_type and source_type.lower() in self.SUPPORTED_TYPES:
            return True
        path = Path(source)
        name = path.name.lower()
        return name in ("docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml")

    @property
    def supported_types(self) -> list[str]:
        return self.SUPPORTED_TYPES

    def normalize(self, source: str) -> NormalizedObject:
        path = Path(source)
        if not path.exists():
            raise NormalizationError(f"File not found: {source}", source)

        try:
            content = path.read_text(encoding="utf-8")
            data = yaml.safe_load(content)

            if not isinstance(data, dict):
                raise NormalizationError("Invalid docker-compose file", source)

            entities = self._build_entities(data)

            services = data.get("services", {})
            volumes = data.get("volumes", {})
            networks = data.get("networks", {})

            return NormalizedObject(
                type="docker-compose",
                entities=entities,
                structure={
                    "version": data.get("version", "unknown"),
                    "service_count": len(services),
                    "volume_count": len(volumes),
                    "network_count": len(networks),
                },
                metadata={
                    "version": data.get("version"),
                    "services": list(services.keys()),
                    "volumes": list(volumes.keys()) if isinstance(volumes, dict) else [],
                    "networks": list(networks.keys()) if isinstance(networks, dict) else [],
                },
                source_path=path,
            )
        except Exception as e:
            if isinstance(e, NormalizationError):
                raise
            raise NormalizationError(f"Failed to parse docker-compose: {e}", source, e)

    def _build_entities(self, data: dict) -> list[Entity]:
        entities: list[Entity] = []

        # Services
        services = data.get("services", {})
        for name, config in services.items():
            if not isinstance(config, dict):
                continue

            entity = Entity(
                id=f"service_{name}",
                name=name,
                entity_type=EntityType.SECTION,
                value=config,
                path=f"services.{name}",
                metadata={
                    "image": config.get("image"),
                    "build": config.get("build"),
                    "ports": config.get("ports", []),
                    "environment": list(config.get("environment", {}).keys()) if isinstance(config.get("environment"), dict) else config.get("environment", []),
                    "depends_on": config.get("depends_on", []),
                },
                children=[],
            )
            entities.append(entity)

        # Volumes
        volumes = data.get("volumes", {})
        if isinstance(volumes, dict):
            for name, config in volumes.items():
                entity = Entity(
                    id=f"volume_{name}",
                    name=name,
                    entity_type=EntityType.SECTION,
                    value=config or {},
                    path=f"volumes.{name}",
                    metadata={},
                    children=[],
                )
                entities.append(entity)

        # Networks
        networks = data.get("networks", {})
        if isinstance(networks, dict):
            for name, config in networks.items():
                entity = Entity(
                    id=f"network_{name}",
                    name=name,
                    entity_type=EntityType.SECTION,
                    value=config or {},
                    path=f"networks.{name}",
                    metadata={},
                    children=[],
                )
                entities.append(entity)

        return entities
