"""Semantic diff engine for comparing normalized objects."""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Optional
import difflib

from what_changed.normalize.base import NormalizedObject, Entity, EntityType
from what_changed.diff.content_diff import ContentDiff, ContentDiffer


class ChangeType(Enum):
    """Types of changes that can be detected."""

    ADDED = auto()
    REMOVED = auto()
    MODIFIED = auto()
    RENAMED = auto()
    TYPE_CHANGED = auto()
    MOVED = auto()
    UNCHANGED = auto()


@dataclass
class Change:
    """Represents a single change between two entities."""

    change_type: ChangeType
    path: str
    entity_type: EntityType

    # The old and new values (None if not applicable)
    old_value: Any = None
    new_value: Any = None

    # The old and new entities
    old_entity: Optional[Entity] = None
    new_entity: Optional[Entity] = None

    # Additional context
    metadata: dict[str, Any] = field(default_factory=dict)

    # Content diff for text-based changes (documents, text files)
    content_diff: Optional[ContentDiff] = None

    @property
    def is_breaking(self) -> bool:
        """Quick check if this might be a breaking change."""
        return self.change_type in {
            ChangeType.REMOVED,
            ChangeType.TYPE_CHANGED,
        }

    @property
    def description(self) -> str:
        """Generate a human-readable description of the change."""
        type_name = self.entity_type.name.lower()

        if self.change_type == ChangeType.ADDED:
            return f"Added {type_name}: {self.path}"
        elif self.change_type == ChangeType.REMOVED:
            return f"Removed {type_name}: {self.path}"
        elif self.change_type == ChangeType.MODIFIED:
            return f"Modified {type_name}: {self.path}"
        elif self.change_type == ChangeType.RENAMED:
            old_name = self.metadata.get("old_name", "?")
            new_name = self.metadata.get("new_name", "?")
            return f"Renamed {type_name}: {old_name} -> {new_name}"
        elif self.change_type == ChangeType.TYPE_CHANGED:
            old_type = self.metadata.get("old_type", "?")
            new_type = self.metadata.get("new_type", "?")
            return f"Type changed at {self.path}: {old_type} -> {new_type}"
        elif self.change_type == ChangeType.MOVED:
            return f"Moved {type_name}: {self.path}"
        else:
            return f"Unchanged: {self.path}"


@dataclass
class DiffResult:
    """Result of comparing two normalized objects."""

    source_a: str  # Path/URL of source A
    source_b: str  # Path/URL of source B
    type_a: str  # Type of source A
    type_b: str  # Type of source B

    changes: list[Change] = field(default_factory=list)

    # Summary statistics
    added_count: int = 0
    removed_count: int = 0
    modified_count: int = 0
    renamed_count: int = 0
    type_changed_count: int = 0

    @property
    def has_changes(self) -> bool:
        """Check if there are any changes."""
        return len(self.changes) > 0

    @property
    def total_changes(self) -> int:
        """Total number of changes."""
        return len(self.changes)

    @property
    def breaking_changes(self) -> list[Change]:
        """Get potentially breaking changes."""
        return [c for c in self.changes if c.is_breaking]

    def get_changes_by_type(self, change_type: ChangeType) -> list[Change]:
        """Get all changes of a specific type."""
        return [c for c in self.changes if c.change_type == change_type]

    def get_changes_by_path(self, path_prefix: str) -> list[Change]:
        """Get all changes under a specific path prefix."""
        return [c for c in self.changes if c.path.startswith(path_prefix)]


class SemanticDiff:
    """
    Engine for semantic comparison of normalized objects.

    Performs structural comparison that understands the meaning of changes,
    not just textual differences.
    """

    def __init__(
        self,
        similarity_threshold: float = 0.6,
        detect_renames: bool = True,
        deep_compare: bool = True,
    ):
        """
        Initialize the semantic diff engine.

        Args:
            similarity_threshold: Threshold for detecting renames (0-1)
            detect_renames: Whether to detect renamed entities
            deep_compare: Whether to deeply compare nested structures
        """
        self.similarity_threshold = similarity_threshold
        self.detect_renames = detect_renames
        self.deep_compare = deep_compare

    def diff(self, obj_a: NormalizedObject, obj_b: NormalizedObject) -> DiffResult:
        """
        Compare two normalized objects.

        Args:
            obj_a: The "before" object
            obj_b: The "after" object

        Returns:
            DiffResult containing all detected changes
        """
        result = DiffResult(
            source_a=str(obj_a.source_path or obj_a.source_url or "A"),
            source_b=str(obj_b.source_path or obj_b.source_url or "B"),
            type_a=obj_a.type,
            type_b=obj_b.type,
        )

        # Build path -> entity maps for both objects
        entities_a = self._build_entity_map(obj_a)
        entities_b = self._build_entity_map(obj_b)

        paths_a = set(entities_a.keys())
        paths_b = set(entities_b.keys())

        # Find removed paths (in A but not in B)
        removed_paths = paths_a - paths_b

        # Find added paths (in B but not in A)
        added_paths = paths_b - paths_a

        # Find common paths (may be modified)
        common_paths = paths_a & paths_b

        # Try to detect renames
        renames: dict[str, str] = {}  # old_path -> new_path
        if self.detect_renames and removed_paths and added_paths:
            renames = self._detect_renames(
                {p: entities_a[p] for p in removed_paths},
                {p: entities_b[p] for p in added_paths},
            )

            # Remove renamed paths from added/removed
            for old_path, new_path in renames.items():
                removed_paths.discard(old_path)
                added_paths.discard(new_path)

        # Process removed entities
        for path in sorted(removed_paths):
            entity = entities_a[path]
            change = Change(
                change_type=ChangeType.REMOVED,
                path=path,
                entity_type=entity.entity_type,
                old_value=entity.value,
                old_entity=entity,
            )
            result.changes.append(change)
            result.removed_count += 1

        # Process added entities
        for path in sorted(added_paths):
            entity = entities_b[path]
            change = Change(
                change_type=ChangeType.ADDED,
                path=path,
                entity_type=entity.entity_type,
                new_value=entity.value,
                new_entity=entity,
            )
            result.changes.append(change)
            result.added_count += 1

        # Process renames
        for old_path, new_path in renames.items():
            old_entity = entities_a[old_path]
            new_entity = entities_b[new_path]

            change = Change(
                change_type=ChangeType.RENAMED,
                path=new_path,
                entity_type=new_entity.entity_type,
                old_value=old_entity.value,
                new_value=new_entity.value,
                old_entity=old_entity,
                new_entity=new_entity,
                metadata={
                    "old_path": old_path,
                    "new_path": new_path,
                    "old_name": old_entity.name,
                    "new_name": new_entity.name,
                },
            )
            result.changes.append(change)
            result.renamed_count += 1

        # Process common paths (check for modifications)
        for path in sorted(common_paths):
            entity_a = entities_a[path]
            entity_b = entities_b[path]

            change = self._compare_entities(entity_a, entity_b, path)
            if change is not None:
                result.changes.append(change)
                if change.change_type == ChangeType.MODIFIED:
                    result.modified_count += 1
                elif change.change_type == ChangeType.TYPE_CHANGED:
                    result.type_changed_count += 1

        return result

    def _build_entity_map(self, obj: NormalizedObject) -> dict[str, Entity]:
        """Build a map of path -> entity for all entities in the object."""
        entity_map: dict[str, Entity] = {}

        for entity in obj.entities:
            for e in entity.flatten():
                entity_map[e.path] = e

        return entity_map

    def _detect_renames(
        self,
        removed: dict[str, Entity],
        added: dict[str, Entity],
    ) -> dict[str, str]:
        """
        Detect potential renames by comparing removed and added entities.

        Returns:
            Dict mapping old paths to new paths for detected renames
        """
        renames: dict[str, str] = {}

        # Group by entity type for more accurate matching
        removed_by_type: dict[EntityType, list[tuple[str, Entity]]] = {}
        added_by_type: dict[EntityType, list[tuple[str, Entity]]] = {}

        for path, entity in removed.items():
            removed_by_type.setdefault(entity.entity_type, []).append((path, entity))

        for path, entity in added.items():
            added_by_type.setdefault(entity.entity_type, []).append((path, entity))

        # Match within same entity types
        for entity_type in removed_by_type:
            if entity_type not in added_by_type:
                continue

            removed_list = removed_by_type[entity_type]
            added_list = added_by_type[entity_type]

            used_added: set[str] = set()

            for old_path, old_entity in removed_list:
                best_match: Optional[tuple[str, float]] = None

                for new_path, new_entity in added_list:
                    if new_path in used_added:
                        continue

                    similarity = self._compute_similarity(old_entity, new_entity)
                    if similarity >= self.similarity_threshold:
                        if best_match is None or similarity > best_match[1]:
                            best_match = (new_path, similarity)

                if best_match is not None:
                    renames[old_path] = best_match[0]
                    used_added.add(best_match[0])

        return renames

    def _compute_similarity(self, entity_a: Entity, entity_b: Entity) -> float:
        """
        Compute similarity between two entities.

        Returns a value between 0 and 1, where 1 means identical.
        """
        # Name similarity (using sequence matcher)
        name_sim = difflib.SequenceMatcher(
            None, entity_a.name, entity_b.name
        ).ratio()

        # Value similarity
        value_sim = 0.0
        if entity_a.value is not None and entity_b.value is not None:
            if entity_a.value == entity_b.value:
                value_sim = 1.0
            elif isinstance(entity_a.value, str) and isinstance(entity_b.value, str):
                value_sim = difflib.SequenceMatcher(
                    None, entity_a.value, entity_b.value
                ).ratio()
            elif isinstance(entity_a.value, (int, float)) and isinstance(entity_b.value, (int, float)):
                # For numbers, consider them similar if within 10%
                try:
                    max_val = max(abs(entity_a.value), abs(entity_b.value))
                    if max_val > 0:
                        diff = abs(entity_a.value - entity_b.value) / max_val
                        value_sim = max(0, 1 - diff)
                except (TypeError, ZeroDivisionError):
                    pass

        # Metadata similarity (e.g., file hash for directories)
        meta_sim = 0.0
        if entity_a.metadata.get("hash") and entity_b.metadata.get("hash"):
            if entity_a.metadata["hash"] == entity_b.metadata["hash"]:
                meta_sim = 1.0

        # Weight the similarities
        if meta_sim > 0:
            # If we have hash match, weight it heavily
            return 0.3 * name_sim + 0.1 * value_sim + 0.6 * meta_sim
        else:
            return 0.4 * name_sim + 0.6 * value_sim

    def _compare_entities(
        self,
        entity_a: Entity,
        entity_b: Entity,
        path: str,
    ) -> Optional[Change]:
        """
        Compare two entities at the same path.

        Returns:
            A Change if entities differ, None if identical
        """
        # Check for type change
        value_type_a = entity_a.metadata.get("value_type")
        value_type_b = entity_b.metadata.get("value_type")

        if value_type_a and value_type_b and value_type_a != value_type_b:
            return Change(
                change_type=ChangeType.TYPE_CHANGED,
                path=path,
                entity_type=entity_b.entity_type,
                old_value=entity_a.value,
                new_value=entity_b.value,
                old_entity=entity_a,
                new_entity=entity_b,
                metadata={
                    "old_type": value_type_a,
                    "new_type": value_type_b,
                },
            )

        # Check for value change
        if self._values_differ(entity_a.value, entity_b.value):
            # Generate diff details for strings
            diff_details = {}
            content_diff = None

            if isinstance(entity_a.value, str) and isinstance(entity_b.value, str):
                diff_details = self._generate_string_diff(entity_a.value, entity_b.value)
                # Generate content diff for text
                if self.deep_compare:
                    differ = ContentDiffer()
                    content_diff = differ.diff_text(
                        entity_a.value,
                        entity_b.value,
                        old_label=f"a/{path}",
                        new_label=f"b/{path}",
                    )
            elif isinstance(entity_a.value, dict) and isinstance(entity_b.value, dict):
                # For dict values (like pages), try to extract text content
                content_diff = self._extract_text_diff(entity_a.value, entity_b.value, path)
                if content_diff and content_diff.has_changes:
                    diff_details["lines_added"] = content_diff.lines_added
                    diff_details["lines_removed"] = content_diff.lines_removed

            return Change(
                change_type=ChangeType.MODIFIED,
                path=path,
                entity_type=entity_b.entity_type,
                old_value=entity_a.value,
                new_value=entity_b.value,
                old_entity=entity_a,
                new_entity=entity_b,
                metadata=diff_details,
                content_diff=content_diff,
            )

        # Check metadata changes (e.g., file size, hash)
        if entity_a.entity_type == EntityType.FILE:
            if entity_a.metadata.get("hash") != entity_b.metadata.get("hash"):
                return Change(
                    change_type=ChangeType.MODIFIED,
                    path=path,
                    entity_type=entity_b.entity_type,
                    old_entity=entity_a,
                    new_entity=entity_b,
                    metadata={
                        "old_size": entity_a.metadata.get("size"),
                        "new_size": entity_b.metadata.get("size"),
                        "old_hash": entity_a.metadata.get("hash"),
                        "new_hash": entity_b.metadata.get("hash"),
                    },
                )

        return None

    def _values_differ(self, value_a: Any, value_b: Any) -> bool:
        """Check if two values are different."""
        # Handle None
        if value_a is None and value_b is None:
            return False
        if value_a is None or value_b is None:
            return True

        # Direct comparison for most types
        if type(value_a) != type(value_b):
            return True

        return value_a != value_b

    def _generate_string_diff(self, old: str, new: str) -> dict[str, Any]:
        """Generate diff details for string changes."""
        # Count changes
        old_lines = old.splitlines() if '\n' in old else [old]
        new_lines = new.splitlines() if '\n' in new else [new]

        diff = list(difflib.unified_diff(old_lines, new_lines, lineterm=''))

        additions = sum(1 for line in diff if line.startswith('+') and not line.startswith('+++'))
        deletions = sum(1 for line in diff if line.startswith('-') and not line.startswith('---'))

        return {
            "lines_added": additions,
            "lines_removed": deletions,
            "old_length": len(old),
            "new_length": len(new),
        }

    def _extract_text_diff(
        self,
        old_dict: dict[str, Any],
        new_dict: dict[str, Any],
        path: str,
    ) -> Optional[ContentDiff]:
        """
        Extract and diff text content from dict values.

        This is used for entities like PDF pages that store text in a dict.
        """
        # Common text field names
        text_fields = ["text", "content", "body", "value", "data"]

        old_text = None
        new_text = None

        for field in text_fields:
            if field in old_dict and isinstance(old_dict[field], str):
                old_text = old_dict[field]
            if field in new_dict and isinstance(new_dict[field], str):
                new_text = new_dict[field]
            if old_text and new_text:
                break

        if old_text is None and new_text is None:
            return None

        old_text = old_text or ""
        new_text = new_text or ""

        if old_text == new_text:
            return None

        differ = ContentDiffer()
        return differ.diff_text(
            old_text,
            new_text,
            old_label=f"a/{path}",
            new_label=f"b/{path}",
        )
