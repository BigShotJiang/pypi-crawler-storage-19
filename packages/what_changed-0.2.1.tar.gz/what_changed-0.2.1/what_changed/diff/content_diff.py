"""Content-aware diffing for documents and text files.

This module provides actual text diffs (like git diff) for document types,
rather than just structural comparison.
"""

import difflib
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional


class LineChangeType(Enum):
    """Type of line change."""
    ADDED = auto()
    REMOVED = auto()
    CONTEXT = auto()
    HEADER = auto()


@dataclass
class LineDiff:
    """A single line in a diff."""
    line_type: LineChangeType
    content: str
    old_line_num: Optional[int] = None
    new_line_num: Optional[int] = None


@dataclass
class Hunk:
    """A hunk of changes (contiguous block of differences)."""
    old_start: int
    old_count: int
    new_start: int
    new_count: int
    lines: list[LineDiff] = field(default_factory=list)

    @property
    def header(self) -> str:
        """Generate the hunk header like @@ -1,5 +1,6 @@"""
        return f"@@ -{self.old_start},{self.old_count} +{self.new_start},{self.new_count} @@"


@dataclass
class ContentDiff:
    """Result of comparing two text contents."""
    old_label: str
    new_label: str
    hunks: list[Hunk] = field(default_factory=list)

    # Statistics
    lines_added: int = 0
    lines_removed: int = 0
    lines_changed: int = 0

    @property
    def has_changes(self) -> bool:
        return len(self.hunks) > 0

    def to_unified_diff(self, context_lines: int = 3) -> str:
        """Generate unified diff format string."""
        if not self.hunks:
            return ""

        lines = [
            f"--- {self.old_label}",
            f"+++ {self.new_label}",
        ]

        for hunk in self.hunks:
            lines.append(hunk.header)
            for line in hunk.lines:
                if line.line_type == LineChangeType.ADDED:
                    lines.append(f"+{line.content}")
                elif line.line_type == LineChangeType.REMOVED:
                    lines.append(f"-{line.content}")
                elif line.line_type == LineChangeType.CONTEXT:
                    lines.append(f" {line.content}")

        return "\n".join(lines)


class ContentDiffer:
    """
    Generates content-aware diffs for text content.

    Unlike structural comparison, this shows actual line-by-line changes
    similar to git diff.
    """

    def __init__(self, context_lines: int = 3):
        self.context_lines = context_lines

    def diff_text(
        self,
        old_text: str,
        new_text: str,
        old_label: str = "a",
        new_label: str = "b",
    ) -> ContentDiff:
        """
        Generate a diff between two text strings.

        Args:
            old_text: The original text
            new_text: The modified text
            old_label: Label for the old version
            new_label: Label for the new version

        Returns:
            ContentDiff with all changes
        """
        old_lines = old_text.splitlines(keepends=True)
        new_lines = new_text.splitlines(keepends=True)

        result = ContentDiff(
            old_label=old_label,
            new_label=new_label,
        )

        # Use difflib to get opcodes
        matcher = difflib.SequenceMatcher(None, old_lines, new_lines)

        # Group changes into hunks
        hunks = self._generate_hunks(matcher, old_lines, new_lines)
        result.hunks = hunks

        # Calculate statistics
        for hunk in hunks:
            for line in hunk.lines:
                if line.line_type == LineChangeType.ADDED:
                    result.lines_added += 1
                elif line.line_type == LineChangeType.REMOVED:
                    result.lines_removed += 1

        result.lines_changed = min(result.lines_added, result.lines_removed)

        return result

    def _generate_hunks(
        self,
        matcher: difflib.SequenceMatcher,
        old_lines: list[str],
        new_lines: list[str],
    ) -> list[Hunk]:
        """Generate hunks from the sequence matcher opcodes."""
        hunks: list[Hunk] = []
        current_hunk: Optional[Hunk] = None

        opcodes = matcher.get_opcodes()

        for tag, i1, i2, j1, j2 in opcodes:
            if tag == 'equal':
                # Context lines
                lines_in_block = list(range(i1, i2))

                if current_hunk is not None:
                    # Add trailing context to current hunk
                    context_end = min(len(lines_in_block), self.context_lines)
                    for idx in range(context_end):
                        line_num = i1 + idx
                        current_hunk.lines.append(LineDiff(
                            line_type=LineChangeType.CONTEXT,
                            content=old_lines[line_num].rstrip('\n\r'),
                            old_line_num=line_num + 1,
                            new_line_num=j1 + idx + 1,
                        ))
                        current_hunk.old_count += 1
                        current_hunk.new_count += 1

                    # Finalize the hunk if there's a gap
                    if len(lines_in_block) > self.context_lines * 2:
                        hunks.append(current_hunk)
                        current_hunk = None

            elif tag in ('replace', 'delete', 'insert'):
                # Start new hunk if needed
                if current_hunk is None:
                    # Add leading context
                    context_start = max(0, i1 - self.context_lines)
                    current_hunk = Hunk(
                        old_start=context_start + 1,
                        old_count=0,
                        new_start=max(0, j1 - self.context_lines) + 1,
                        new_count=0,
                    )

                    # Add context lines
                    for idx in range(context_start, i1):
                        corresponding_new = j1 - (i1 - idx)
                        current_hunk.lines.append(LineDiff(
                            line_type=LineChangeType.CONTEXT,
                            content=old_lines[idx].rstrip('\n\r'),
                            old_line_num=idx + 1,
                            new_line_num=corresponding_new + 1 if corresponding_new >= 0 else None,
                        ))
                        current_hunk.old_count += 1
                        current_hunk.new_count += 1

                # Add removed lines
                if tag in ('replace', 'delete'):
                    for idx in range(i1, i2):
                        current_hunk.lines.append(LineDiff(
                            line_type=LineChangeType.REMOVED,
                            content=old_lines[idx].rstrip('\n\r'),
                            old_line_num=idx + 1,
                        ))
                        current_hunk.old_count += 1

                # Add inserted lines
                if tag in ('replace', 'insert'):
                    for idx in range(j1, j2):
                        current_hunk.lines.append(LineDiff(
                            line_type=LineChangeType.ADDED,
                            content=new_lines[idx].rstrip('\n\r'),
                            new_line_num=idx + 1,
                        ))
                        current_hunk.new_count += 1

        # Don't forget the last hunk
        if current_hunk is not None:
            hunks.append(current_hunk)

        return hunks

    def diff_lines(
        self,
        old_lines: list[str],
        new_lines: list[str],
        old_label: str = "a",
        new_label: str = "b",
    ) -> ContentDiff:
        """
        Generate a diff between two lists of lines.

        Args:
            old_lines: The original lines
            new_lines: The modified lines
            old_label: Label for the old version
            new_label: Label for the new version

        Returns:
            ContentDiff with all changes
        """
        old_text = "\n".join(old_lines)
        new_text = "\n".join(new_lines)
        return self.diff_text(old_text, new_text, old_label, new_label)


def generate_inline_diff(old: str, new: str) -> tuple[str, str]:
    """
    Generate inline diff highlighting what changed within lines.

    Returns tuple of (old_highlighted, new_highlighted) with markers.
    """
    matcher = difflib.SequenceMatcher(None, old, new)

    old_result = []
    new_result = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            old_result.append(old[i1:i2])
            new_result.append(new[j1:j2])
        elif tag == 'replace':
            old_result.append(f"[-{old[i1:i2]}-]")
            new_result.append(f"[+{new[j1:j2]}+]")
        elif tag == 'delete':
            old_result.append(f"[-{old[i1:i2]}-]")
        elif tag == 'insert':
            new_result.append(f"[+{new[j1:j2]}+]")

    return "".join(old_result), "".join(new_result)


def word_diff(old: str, new: str) -> str:
    """
    Generate a word-by-word diff, similar to git diff --word-diff.

    Returns a string with [-removed-] and {+added+} markers.
    """
    old_words = old.split()
    new_words = new.split()

    matcher = difflib.SequenceMatcher(None, old_words, new_words)
    result = []

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            result.append(" ".join(old_words[i1:i2]))
        elif tag == 'replace':
            if i1 < i2:
                result.append(f"[-{' '.join(old_words[i1:i2])}-]")
            if j1 < j2:
                result.append(f"{{+{' '.join(new_words[j1:j2])}+}}")
        elif tag == 'delete':
            result.append(f"[-{' '.join(old_words[i1:i2])}-]")
        elif tag == 'insert':
            result.append(f"{{+{' '.join(new_words[j1:j2])}+}}")

    return " ".join(result)
