"""Output renderer for change reports."""

import json
import os
import sys
from dataclasses import dataclass
from enum import Enum, auto
from typing import Any, Optional, TextIO, TYPE_CHECKING

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich.syntax import Syntax
from rich import box

from what_changed.graph.model import ChangeGraph, ChangeNode, RiskLevel
from what_changed.explain.explainer import Explanation, ConfidenceLevel
from what_changed.diff.semantic_diff import DiffResult, ChangeType
from what_changed.diff.content_diff import ContentDiff, LineChangeType

if TYPE_CHECKING:
    from what_changed.normalize.base import NormalizedObject


class OutputFormat(Enum):
    """Output format options."""

    HUMAN = auto()
    JSON = auto()
    SUMMARY = auto()
    FORMAT_SPECIFIC = auto()  # Use format-aware rendering


@dataclass
class RenderConfig:
    """Configuration for rendering output."""

    format: OutputFormat = OutputFormat.HUMAN
    show_safe: bool = True
    breaking_only: bool = False
    verbose: bool = False
    color: bool = True


class Renderer:
    """
    Renders change reports in various formats.

    Supports human-readable (rich), JSON, and summary formats.
    """

    # Risk level colors
    RISK_COLORS = {
        RiskLevel.BREAKING: "red",
        RiskLevel.RISKY: "yellow",
        RiskLevel.SAFE: "green",
    }

    # Risk level symbols (ASCII for Windows compatibility)
    RISK_SYMBOLS = {
        RiskLevel.BREAKING: "[X]",
        RiskLevel.RISKY: "[!]",
        RiskLevel.SAFE: "[o]",
    }

    # Change type symbols
    CHANGE_SYMBOLS = {
        ChangeType.ADDED: "+",
        ChangeType.REMOVED: "-",
        ChangeType.MODIFIED: "~",
        ChangeType.RENAMED: "->",
        ChangeType.TYPE_CHANGED: "!",
    }

    def __init__(self, config: Optional[RenderConfig] = None):
        """
        Initialize the renderer.

        Args:
            config: Rendering configuration
        """
        self.config = config or RenderConfig()

        # Handle Windows console encoding issues
        # Force UTF-8 mode on Windows to support Unicode characters
        if sys.platform == "win32":
            # Try to enable UTF-8 mode for Windows console
            try:
                sys.stdout.reconfigure(encoding='utf-8', errors='replace')
                sys.stderr.reconfigure(encoding='utf-8', errors='replace')
            except (AttributeError, OSError):
                pass  # Not supported on older Python versions

        self.console = Console(
            force_terminal=self.config.color,
            no_color=not self.config.color,
            legacy_windows=sys.platform == "win32",  # Use safe rendering on Windows
        )

    def render(
        self,
        diff_result: DiffResult,
        graph: ChangeGraph,
        explanations: list[Explanation],
        output: Optional[TextIO] = None,
        obj_a: Optional["NormalizedObject"] = None,
        obj_b: Optional["NormalizedObject"] = None,
    ) -> None:
        """
        Render the change report.

        Args:
            diff_result: The diff result
            graph: The change graph
            explanations: List of explanations
            output: Optional output stream (defaults to stdout)
            obj_a: Optional normalized object A (for format-specific rendering)
            obj_b: Optional normalized object B (for format-specific rendering)
        """
        if self.config.format == OutputFormat.JSON:
            self._render_json(diff_result, graph, explanations, output)
        elif self.config.format == OutputFormat.SUMMARY:
            self._render_summary(diff_result, graph, explanations)
        elif self.config.format == OutputFormat.FORMAT_SPECIFIC and obj_a and obj_b:
            self._render_format_specific(obj_a, obj_b, diff_result, graph)
        else:
            self._render_human(diff_result, graph, explanations)

    def _render_format_specific(
        self,
        obj_a: "NormalizedObject",
        obj_b: "NormalizedObject",
        diff_result: DiffResult,
        graph: ChangeGraph,
    ) -> None:
        """Render using format-specific renderer."""
        from what_changed.output.formats import create_format_registry
        from what_changed.output.formats.base import RenderContext

        registry = create_format_registry()

        # Try to find a renderer for the format type
        format_type = obj_a.type
        renderer = registry.get_renderer(format_type)

        if renderer:
            ctx = RenderContext(
                console=self.console,
                obj_a=obj_a,
                obj_b=obj_b,
                diff_result=diff_result,
                graph=graph,
                verbose=self.config.verbose,
                color=self.config.color,
                breaking_only=self.config.breaking_only,
                show_safe=self.config.show_safe,
            )
            renderer.render(ctx)
        else:
            # Fallback to generic human rendering
            explanations = []  # Would need to regenerate or pass through
            self.console.print(f"[dim]No format-specific renderer for '{format_type}', using generic output[/dim]")
            self._print_header(diff_result, graph)
            self._print_summary(graph)

    def _render_human(
        self,
        diff_result: DiffResult,
        graph: ChangeGraph,
        explanations: list[Explanation],
    ) -> None:
        """Render human-readable output."""
        # Filter explanations based on config
        filtered = self._filter_explanations(explanations)

        if not filtered:
            self.console.print("\n[green]OK: No significant changes detected[/green]\n")
            return

        # Print header
        self._print_header(diff_result, graph)

        # Print summary
        self._print_summary(graph)

        # Print changes
        self._print_changes(filtered)

        # Print footer
        self._print_footer(graph)

    def _print_header(self, diff_result: DiffResult, graph: ChangeGraph) -> None:
        """Print the report header."""
        self.console.print()
        self.console.print(
            Panel(
                f"[bold]Comparing:[/bold]\n"
                f"  A: {diff_result.source_a} ({diff_result.type_a})\n"
                f"  B: {diff_result.source_b} ({diff_result.type_b})",
                title="[bold cyan]what-changed[/bold cyan]",
                border_style="cyan",
            )
        )
        self.console.print()

    def _print_summary(self, graph: ChangeGraph) -> None:
        """Print change summary."""
        breaking = len(graph.get_breaking_changes())
        risky = len(graph.get_risky_changes())
        safe = len(graph.get_safe_changes())

        # Create summary table
        table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        table.add_column("Type", style="bold")
        table.add_column("Count", justify="right")

        if breaking > 0:
            table.add_row(
                f"{self.RISK_SYMBOLS[RiskLevel.BREAKING]} Breaking",
                f"[red]{breaking}[/red]"
            )
        if risky > 0:
            table.add_row(
                f"{self.RISK_SYMBOLS[RiskLevel.RISKY]} Risky",
                f"[yellow]{risky}[/yellow]"
            )
        if safe > 0 and self.config.show_safe:
            table.add_row(
                f"{self.RISK_SYMBOLS[RiskLevel.SAFE]} Safe",
                f"[green]{safe}[/green]"
            )

        self.console.print(Panel(table, title="Summary", border_style="dim"))
        self.console.print()

    def _print_changes(self, explanations: list[Explanation]) -> None:
        """Print detailed changes."""
        current_risk: Optional[RiskLevel] = None

        for exp in explanations:
            # Print section header when risk level changes
            if exp.risk_level != current_risk:
                current_risk = exp.risk_level
                color = self.RISK_COLORS[exp.risk_level]
                self.console.print(
                    f"\n[bold {color}]{self.RISK_SYMBOLS[exp.risk_level]} "
                    f"{exp.risk_level.name} Changes:[/bold {color}]"
                )
                self.console.print()

            # Print change detail
            self._print_change_detail(exp)

    def _print_change_detail(self, exp: Explanation) -> None:
        """Print a single change in detail."""
        color = self.RISK_COLORS[exp.risk_level]

        # Build the change panel content
        content = Text()

        # Change summary
        content.append("Change: ", style="bold")
        content.append(exp.change_summary + "\n")

        # Path
        content.append("Path: ", style="bold")
        content.append(exp.path + "\n", style="dim")

        # For documents, show impact differently
        if exp.is_document:
            content.append("\n")
            if exp.content_diff and exp.content_diff.has_changes:
                content.append(f"+{exp.content_diff.lines_added} lines added, ", style="green")
                content.append(f"-{exp.content_diff.lines_removed} lines removed\n", style="red")
        else:
            # Impact
            content.append("\nImpact: ", style="bold")
            content.append(exp.impact + "\n")

            # What could break
            content.append("\nCould break: ", style="bold")
            content.append(exp.what_could_break + "\n")

        # Confidence (only for non-documents)
        if not exp.is_document:
            content.append("\nConfidence: ", style="bold")
            conf_style = {
                ConfidenceLevel.HIGH: "green",
                ConfidenceLevel.MEDIUM: "yellow",
                ConfidenceLevel.LOW: "dim",
            }[exp.confidence]
            content.append(exp.confidence.name.lower(), style=conf_style)

        # Rule matches (verbose mode)
        if self.config.verbose and exp.rule_matches:
            content.append("\n\nMatched rules:\n", style="bold dim")
            for match in exp.rule_matches:
                content.append(f"  - {match}\n", style="dim")

        self.console.print(
            Panel(
                content,
                title=f"[{color}]{exp.entity}[/{color}]" + (f" (score: {exp.risk_score})" if not exp.is_document else ""),
                border_style=color,
                padding=(0, 1),
            )
        )

        # Print actual diff for documents
        if exp.content_diff and exp.content_diff.has_changes:
            self._print_content_diff(exp.content_diff)

    def _print_content_diff(self, diff: ContentDiff, max_lines: int = 50) -> None:
        """Print the actual content diff in git-diff style."""
        if not diff.hunks:
            return

        diff_lines = []
        line_count = 0

        for hunk in diff.hunks:
            diff_lines.append(f"[dim]{hunk.header}[/dim]")
            line_count += 1

            for line in hunk.lines:
                if line_count >= max_lines:
                    diff_lines.append(f"[dim]... ({len(diff.hunks)} hunks, showing first {max_lines} lines)[/dim]")
                    break

                if line.line_type == LineChangeType.ADDED:
                    diff_lines.append(f"[green]+{line.content}[/green]")
                elif line.line_type == LineChangeType.REMOVED:
                    diff_lines.append(f"[red]-{line.content}[/red]")
                elif line.line_type == LineChangeType.CONTEXT:
                    diff_lines.append(f"[dim] {line.content}[/dim]")

                line_count += 1

            if line_count >= max_lines:
                break

        diff_output = "\n".join(diff_lines)
        self.console.print(Panel(diff_output, title="Diff", border_style="dim", padding=(0, 1)))

    def _print_footer(self, graph: ChangeGraph) -> None:
        """Print the report footer."""
        breaking = len(graph.get_breaking_changes())
        risky = len(graph.get_risky_changes())

        self.console.print()

        if breaking > 0:
            self.console.print(
                f"[bold red]WARNING: {breaking} breaking change(s) detected. "
                f"Review carefully before deploying.[/bold red]"
            )
        elif risky > 0:
            self.console.print(
                f"[yellow]WARNING: {risky} potentially risky change(s). "
                f"Consider reviewing before deployment.[/yellow]"
            )
        else:
            self.console.print(
                "[green]OK: All changes appear safe.[/green]"
            )

        self.console.print()

    def _render_summary(
        self,
        diff_result: DiffResult,
        graph: ChangeGraph,
        explanations: list[Explanation],
    ) -> None:
        """Render a brief summary."""
        breaking = len(graph.get_breaking_changes())
        risky = len(graph.get_risky_changes())
        safe = len(graph.get_safe_changes())
        total = breaking + risky + safe

        self.console.print(f"\nTotal changes: {total}")
        self.console.print(f"  {self.RISK_SYMBOLS[RiskLevel.BREAKING]} Breaking: {breaking}")
        self.console.print(f"  {self.RISK_SYMBOLS[RiskLevel.RISKY]} Risky: {risky}")
        self.console.print(f"  {self.RISK_SYMBOLS[RiskLevel.SAFE]} Safe: {safe}")

        if breaking > 0:
            self.console.print(f"\n[red]Exit code: 2 (breaking changes)[/red]")
        elif risky > 0:
            self.console.print(f"\n[yellow]Exit code: 1 (risky changes)[/yellow]")
        else:
            self.console.print(f"\n[green]Exit code: 0 (safe)[/green]")

        self.console.print()

    def _render_json(
        self,
        diff_result: DiffResult,
        graph: ChangeGraph,
        explanations: list[Explanation],
        output: Optional[TextIO] = None,
    ) -> None:
        """Render JSON output."""
        filtered = self._filter_explanations(explanations)

        data = {
            "comparison": {
                "source_a": diff_result.source_a,
                "source_b": diff_result.source_b,
                "type_a": diff_result.type_a,
                "type_b": diff_result.type_b,
            },
            "summary": {
                "total_changes": len(filtered),
                "breaking": len([e for e in filtered if e.risk_level == RiskLevel.BREAKING]),
                "risky": len([e for e in filtered if e.risk_level == RiskLevel.RISKY]),
                "safe": len([e for e in filtered if e.risk_level == RiskLevel.SAFE]),
            },
            "changes": [e.to_dict() for e in filtered],
            "graph": graph.to_dict() if self.config.verbose else None,
        }

        json_str = json.dumps(data, indent=2, default=str)

        if output:
            output.write(json_str)
        else:
            print(json_str)

    def _filter_explanations(
        self,
        explanations: list[Explanation],
    ) -> list[Explanation]:
        """Filter explanations based on config."""
        result = explanations

        if self.config.breaking_only:
            result = [e for e in result if e.risk_level == RiskLevel.BREAKING]
        elif not self.config.show_safe:
            result = [e for e in result if e.risk_level != RiskLevel.SAFE]

        return result

    def render_tree(self, graph: ChangeGraph) -> None:
        """Render the change graph as a tree."""
        root = graph.root
        if not root:
            return

        tree = Tree(f"[bold]{root.name}[/bold]")
        self._add_children_to_tree(tree, graph, root.id)

        self.console.print(tree)

    def _add_children_to_tree(
        self,
        tree: Tree,
        graph: ChangeGraph,
        node_id: str,
    ) -> None:
        """Recursively add children to a tree."""
        children = graph.get_children(node_id)

        for child in children:
            color = self.RISK_COLORS.get(child.risk_level, "white")
            symbol = self.CHANGE_SYMBOLS.get(child.change_type, "?")

            label = f"[{color}]{symbol} {child.name}[/{color}]"
            if child.risk_score > 0:
                label += f" [dim](score: {child.risk_score})[/dim]"

            branch = tree.add(label)
            self._add_children_to_tree(branch, graph, child.id)
