"""Visual comparison statistics with terminal-style graphs."""

from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table
from rich.layout import Layout
from rich.text import Text
from rich import box

from what_changed.normalize.base import NormalizedObject
from what_changed.diff.semantic_diff import DiffResult, ChangeType
from what_changed.graph.model import ChangeGraph, RiskLevel


def render_comparison_stats(
    obj_a: NormalizedObject,
    obj_b: NormalizedObject,
    diff_result: DiffResult,
    graph: ChangeGraph,
) -> None:
    """
    Render visual comparison statistics in trading terminal style.
    """
    console = Console()
    _render_dashboard(console, obj_a, obj_b, diff_result, graph)


def _render_dashboard(
    console: Console,
    obj_a: NormalizedObject,
    obj_b: NormalizedObject,
    diff_result: DiffResult,
    graph: ChangeGraph,
) -> None:
    """Render the full dashboard."""
    console.print()

    # Title bar
    title = Text()
    title.append("what-changed", style="bold cyan")
    title.append(" | ", style="dim")
    title.append(f"{diff_result.source_a}", style="yellow")
    title.append(" vs ", style="dim")
    title.append(f"{diff_result.source_b}", style="green")
    console.print(Panel(title, style="cyan"))
    console.print()

    # Top row: Entity comparison chart + Change distribution chart
    _render_entity_chart(console, obj_a, obj_b)
    console.print()
    _render_change_chart(console, graph)
    console.print()

    # Middle row: Stats tables side by side
    _render_stats_tables(console, obj_a, obj_b, graph)
    console.print()

    # Bottom: Live changes table (like trades table)
    _render_changes_table(console, graph)
    console.print()


def _render_entity_chart(
    console: Console,
    obj_a: NormalizedObject,
    obj_b: NormalizedObject,
) -> None:
    """Render entity count comparison as a mini chart."""
    count_a = len(obj_a.entities)
    count_b = len(obj_b.entities)

    # Create sparkline-style visualization
    max_val = max(count_a, count_b, 1)

    # Generate a "trend" line showing the change
    chart_width = 50
    chart_height = 6

    # Create ASCII line chart
    lines = []
    header = f"[cyan]Entities[/cyan] [dim]({obj_a.type} comparison)[/dim]"

    # Calculate positions
    start_y = int((count_a / max_val) * (chart_height - 1))
    end_y = int((count_b / max_val) * (chart_height - 1))

    # Draw the chart
    for row in range(chart_height - 1, -1, -1):
        line = ""
        for col in range(chart_width):
            # Interpolate y position
            progress = col / (chart_width - 1)
            current_y = int(start_y + (end_y - start_y) * progress)

            if current_y == row:
                if end_y > start_y:
                    line += "[green]^[/green]"
                elif end_y < start_y:
                    line += "[red]v[/red]"
                else:
                    line += "[yellow]-[/yellow]"
            elif row < current_y:
                if col == 0 or col == chart_width - 1:
                    line += "[dim]|[/dim]"
                else:
                    line += " "
            else:
                line += " "

        # Add Y-axis label
        if row == chart_height - 1:
            label = f"[dim]{max_val:>4}[/dim] "
        elif row == 0:
            label = f"[dim]{0:>4}[/dim] "
        else:
            label = "      "

        lines.append(label + line)

    # X-axis
    x_axis = "      " + "[dim]" + "-" * chart_width + "[/dim]"
    x_labels = f"      [yellow]A:{count_a}[/yellow]" + " " * (chart_width - 15) + f"[green]B:{count_b}[/green]"

    lines.append(x_axis)
    lines.append(x_labels)

    # Change indicator
    diff = count_b - count_a
    pct = ((count_b - count_a) / count_a * 100) if count_a > 0 else 0
    if diff > 0:
        change_text = f"[green]+{diff} (+{pct:.1f}%)[/green]"
    elif diff < 0:
        change_text = f"[red]{diff} ({pct:.1f}%)[/red]"
    else:
        change_text = "[dim]No change[/dim]"

    lines.append(f"\n      Change: {change_text}")

    chart_content = "\n".join(lines)
    console.print(Panel(
        chart_content,
        title=header,
        border_style="cyan",
        padding=(0, 1),
    ))


def _render_change_chart(console: Console, graph: ChangeGraph) -> None:
    """Render change type distribution as bar chart."""
    # Count by type
    type_counts = {}
    for node in graph.get_nodes():
        ct = node.change_type
        if ct:
            type_counts[ct] = type_counts.get(ct, 0) + 1

    if not type_counts:
        return

    max_count = max(type_counts.values())
    bar_width = 40

    lines = []
    lines.append("[cyan]Change Distribution[/cyan]")
    lines.append("")

    type_info = [
        (ChangeType.ADDED, "ADDED   ", "green", "+"),
        (ChangeType.REMOVED, "REMOVED ", "red", "-"),
        (ChangeType.MODIFIED, "MODIFIED", "yellow", "~"),
        (ChangeType.RENAMED, "RENAMED ", "cyan", ">"),
        (ChangeType.TYPE_CHANGED, "TYPE CHG", "magenta", "!"),
    ]

    for ct, label, color, symbol in type_info:
        count = type_counts.get(ct, 0)
        if count > 0:
            bar_len = int((count / max_count) * bar_width)
            bar = symbol * bar_len
            padding = " " * (bar_width - bar_len)
            lines.append(f"  [{color}]{label}[/{color}] [{color}]{bar}[/{color}]{padding} {count}")

    console.print(Panel(
        "\n".join(lines),
        border_style="dim",
        padding=(0, 1),
    ))


def _render_stats_tables(
    console: Console,
    obj_a: NormalizedObject,
    obj_b: NormalizedObject,
    graph: ChangeGraph,
) -> None:
    """Render side-by-side stats tables."""
    # Chart stats table (like in the image)
    stats_table = Table(
        title="[cyan]chart stats[/cyan]",
        box=box.SIMPLE,
        show_header=True,
        header_style="bold dim",
        padding=(0, 1),
    )
    stats_table.add_column("metric", style="cyan")
    stats_table.add_column("low", justify="right")
    stats_table.add_column("high", justify="right")
    stats_table.add_column("average", justify="right")
    stats_table.add_column("% change", justify="right")

    # Calculate metrics
    count_a = len(obj_a.entities)
    count_b = len(obj_b.entities)

    breaking = len(graph.get_breaking_changes())
    risky = len(graph.get_risky_changes())
    safe = len(graph.get_safe_changes())
    total = breaking + risky + safe

    # Add rows
    pct_change = ((count_b - count_a) / count_a * 100) if count_a > 0 else 0
    pct_color = "green" if pct_change >= 0 else "red"
    stats_table.add_row(
        "entities",
        str(min(count_a, count_b)),
        str(max(count_a, count_b)),
        f"{(count_a + count_b) / 2:.1f}",
        f"[{pct_color}]{pct_change:+.2f}%[/{pct_color}]"
    )

    if total > 0:
        risk_score = (breaking * 10 + risky * 5 + safe * 1) / total
        health = 100 - (breaking * 20 + risky * 5)
        health = max(0, min(100, health))
        health_color = "green" if health >= 70 else "yellow" if health >= 40 else "red"

        stats_table.add_row(
            "risk score",
            f"[green]{safe}[/green]",
            f"[red]{breaking}[/red]",
            f"{risk_score:.1f}",
            f"[{health_color}]{health:.0f}%[/{health_color}]"
        )

    # Risk breakdown table
    risk_table = Table(
        title="[cyan]risk breakdown[/cyan]",
        box=box.SIMPLE,
        show_header=True,
        header_style="bold dim",
        padding=(0, 1),
    )
    risk_table.add_column("level", style="bold")
    risk_table.add_column("count", justify="right")
    risk_table.add_column("pct", justify="right")
    risk_table.add_column("bar", width=20)

    if total > 0:
        for level, count, color in [
            ("BREAKING", breaking, "red"),
            ("RISKY", risky, "yellow"),
            ("SAFE", safe, "green"),
        ]:
            if count > 0:
                pct = (count / total) * 100
                bar_len = int((count / total) * 20)
                bar = "#" * bar_len
                risk_table.add_row(
                    f"[{color}]{level}[/{color}]",
                    str(count),
                    f"{pct:.1f}%",
                    f"[{color}]{bar}[/{color}]"
                )

    # Print tables side by side using columns
    console.print(stats_table)
    console.print()
    console.print(risk_table)


def _render_changes_table(console: Console, graph: ChangeGraph) -> None:
    """Render live changes table (like trades table)."""
    table = Table(
        title="[cyan]changes & running totals[/cyan]",
        box=box.SIMPLE,
        show_header=True,
        header_style="bold dim",
        padding=(0, 1),
        show_lines=False,
    )

    table.add_column("path", style="cyan", max_width=30)
    table.add_column("type", justify="center")
    table.add_column("risk", justify="center")
    table.add_column("score", justify="right")
    table.add_column("impact", max_width=30)

    # Get all changes sorted by risk score
    changes = list(graph.get_nodes())
    changes.sort(key=lambda n: n.risk_score, reverse=True)

    # Show top 15 changes
    for node in changes[:15]:
        if not node.change_type:
            continue

        # Type with color
        type_colors = {
            ChangeType.ADDED: ("green", "+ADD"),
            ChangeType.REMOVED: ("red", "-DEL"),
            ChangeType.MODIFIED: ("yellow", "~MOD"),
            ChangeType.RENAMED: ("cyan", ">REN"),
            ChangeType.TYPE_CHANGED: ("magenta", "!TYP"),
        }
        color, type_str = type_colors.get(node.change_type, ("white", "???"))

        # Risk with color
        risk_colors = {
            RiskLevel.BREAKING: ("red", "BREAK"),
            RiskLevel.RISKY: ("yellow", "RISKY"),
            RiskLevel.SAFE: ("green", "SAFE"),
        }
        risk_color, risk_str = risk_colors.get(node.risk_level, ("white", "???"))

        # Score color
        score_color = "red" if node.risk_score >= 7 else "yellow" if node.risk_score >= 4 else "green"

        # Truncate path
        path = node.path
        if len(path) > 28:
            path = "..." + path[-25:]

        # Impact description
        impact = node.name
        if len(impact) > 28:
            impact = impact[:25] + "..."

        table.add_row(
            path,
            f"[{color}]{type_str}[/{color}]",
            f"[{risk_color}]{risk_str}[/{risk_color}]",
            f"[{score_color}]{node.risk_score}[/{score_color}]",
            impact,
        )

    if len(changes) > 15:
        table.add_row(
            f"[dim]... and {len(changes) - 15} more[/dim]",
            "", "", "", ""
        )

    console.print(Panel(table, border_style="dim"))


def _make_sparkline(values: list[float], width: int = 20) -> str:
    """Create a mini sparkline chart."""
    if not values:
        return ""

    min_val = min(values)
    max_val = max(values)
    range_val = max_val - min_val if max_val != min_val else 1

    # Sparkline characters (low to high)
    chars = " _.-~'^"

    result = []
    for v in values:
        normalized = (v - min_val) / range_val
        char_idx = int(normalized * (len(chars) - 1))
        result.append(chars[char_idx])

    return "".join(result)
