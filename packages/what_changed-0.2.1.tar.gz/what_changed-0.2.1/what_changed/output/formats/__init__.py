"""Format-specific renderers for different file types."""

from what_changed.output.formats.base import FormatRenderer, FormatRendererRegistry
from what_changed.output.formats.config import ConfigRenderer
from what_changed.output.formats.document import DocumentRenderer
from what_changed.output.formats.dependencies import DependenciesRenderer
from what_changed.output.formats.dockerfile import DockerfileRenderer
from what_changed.output.formats.openapi import OpenAPIRenderer
from what_changed.output.formats.sql import SQLRenderer
from what_changed.output.formats.csv_data import CSVRenderer
from what_changed.output.formats.directory import DirectoryRenderer
from what_changed.output.formats.image import ImageRenderer
from what_changed.output.formats.text import TextRenderer


def create_format_registry() -> FormatRendererRegistry:
    """Create the default format renderer registry with all renderers."""
    registry = FormatRendererRegistry()

    # Register all format-specific renderers
    registry.register(ConfigRenderer())
    registry.register(DocumentRenderer())
    registry.register(DependenciesRenderer())
    registry.register(DockerfileRenderer())
    registry.register(OpenAPIRenderer())
    registry.register(SQLRenderer())
    registry.register(CSVRenderer())
    registry.register(DirectoryRenderer())
    registry.register(ImageRenderer())
    registry.register(TextRenderer())  # Fallback for text-based

    return registry


__all__ = [
    "FormatRenderer",
    "FormatRendererRegistry",
    "create_format_registry",
]
