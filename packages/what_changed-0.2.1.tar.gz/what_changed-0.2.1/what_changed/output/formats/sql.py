"""SQL schema renderer."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class SQLRenderer(FormatRenderer):
    """
    Renderer for SQL schema files.

    Displays schema changes with:
    - Table additions/removals
    - Column changes with type info
    - Index changes
    - Constraint changes
    - Migration-style output
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["sql", "ddl", "schema"]

    def render(self, ctx: RenderContext) -> None:
        """Render SQL schema comparison."""
        self.render_header(ctx, "SQL Schema Comparison")
        self.render_change_summary(ctx)

        # Filter changes
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in schema[/green]\n")
            return

        # Schema overview
        self._render_schema_overview(ctx)

        # Categorize changes
        table_changes = {}
        index_changes = []
        view_changes = []
        other_changes = []

        for change in filtered_changes:
            path = change.path.lower()
            if "/tables/" in path or path.startswith("table_"):
                table_name = self._extract_table_name(change)
                table_changes.setdefault(table_name, []).append(change)
            elif "/indexes/" in path or "index_" in path:
                index_changes.append(change)
            elif "/views/" in path or "view_" in path:
                view_changes.append(change)
            else:
                other_changes.append(change)

        # Render table changes
        if table_changes:
            self._render_table_changes(ctx, table_changes)

        # Render index changes
        if index_changes:
            self._render_index_changes(ctx, index_changes)

        # Render view changes
        if view_changes:
            self._render_view_changes(ctx, view_changes)

    def _render_schema_overview(self, ctx: RenderContext) -> None:
        """Render schema overview comparison."""
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]Schema Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Object Type", style="bold white")
        table.add_column("Before", justify="right", style="yellow")
        table.add_column("After", justify="right", style="green")
        table.add_column("Change", justify="center")

        metrics = [
            ("Tables", "table_count"),
            ("Indexes", "index_count"),
            ("Views", "view_count"),
        ]

        for label, key in metrics:
            val_a = struct_a.get(key, 0)
            val_b = struct_b.get(key, 0)
            diff = val_b - val_a

            if diff > 0:
                change_str = f"[green bold]+{diff}[/green bold]"
            elif diff < 0:
                change_str = f"[red bold]{diff}[/red bold]"
            else:
                change_str = "[dim]=[/dim]"

            table.add_row(label, str(val_a), str(val_b), change_str)

        ctx.console.print(table)
        ctx.console.print()

    def _render_table_changes(
        self, ctx: RenderContext, table_changes: dict[str, list[Change]]
    ) -> None:
        """Render table-level changes."""
        ctx.console.print(Panel("[bold]Table Changes[/bold]", border_style="cyan", padding=(0, 2)))
        ctx.console.print()

        # Categorize tables by risk
        dropped_tables = []
        created_tables = []
        breaking_altered = []
        risky_altered = []
        safe_altered = []

        for table_name, changes in table_changes.items():
            all_removed = all(c.change_type == ChangeType.REMOVED for c in changes)
            all_added = all(c.change_type == ChangeType.ADDED for c in changes)

            if all_removed:
                dropped_tables.append((table_name, changes))
            elif all_added:
                created_tables.append((table_name, changes))
            else:
                # Check risk level
                risks = [ctx.get_change_risk(c) for c in changes]
                if any(r == RiskLevel.BREAKING for r in risks):
                    breaking_altered.append((table_name, changes))
                elif any(r == RiskLevel.RISKY for r in risks):
                    risky_altered.append((table_name, changes))
                else:
                    safe_altered.append((table_name, changes))

        # Dropped tables (breaking)
        if dropped_tables:
            ctx.console.print("[bold red][X] Dropped Tables (Breaking)[/bold red]")
            for table_name, changes in dropped_tables:
                columns = self._extract_column_names(changes)
                ctx.console.print(
                    f"  [red]DROP TABLE[/red] [bold]{table_name}[/bold] "
                    f"[dim]({len(columns)} columns)[/dim]"
                )
            ctx.console.print()

        # Breaking alterations
        if breaking_altered:
            ctx.console.print("[bold red][X] Breaking Table Alterations[/bold red]")
            for table_name, changes in breaking_altered:
                self._render_table_alter(ctx, table_name, changes, "red")

        # Risky alterations
        if risky_altered and not ctx.breaking_only:
            ctx.console.print("[bold yellow][!] Risky Table Alterations[/bold yellow]")
            for table_name, changes in risky_altered:
                self._render_table_alter(ctx, table_name, changes, "yellow")

        # Safe alterations
        if safe_altered and ctx.show_safe and not ctx.breaking_only:
            ctx.console.print("[bold green][o] Safe Table Alterations[/bold green]")
            for table_name, changes in safe_altered:
                self._render_table_alter(ctx, table_name, changes, "green")

        # Created tables
        if created_tables and not ctx.breaking_only:
            ctx.console.print("[bold green][o] Created Tables[/bold green]")
            for table_name, changes in created_tables:
                columns = self._extract_column_info(changes)
                self._render_create_table(ctx, table_name, columns)
            ctx.console.print()

    def _render_table_alter(
        self, ctx: RenderContext, table_name: str, changes: list[Change], color: str
    ) -> None:
        """Render ALTER TABLE style changes."""
        content = Text()
        content.append(f"ALTER TABLE ", style=color)
        content.append(f"{table_name}\n", style="bold")

        # Group by change type
        added_cols = [c for c in changes if c.change_type == ChangeType.ADDED and "column" in c.path.lower()]
        dropped_cols = [c for c in changes if c.change_type == ChangeType.REMOVED and "column" in c.path.lower()]
        modified_cols = [c for c in changes if c.change_type == ChangeType.MODIFIED and "column" in c.path.lower()]
        type_changes = [c for c in changes if c.change_type == ChangeType.TYPE_CHANGED]

        for change in dropped_cols:
            col_name = self._extract_column_name(change)
            content.append("  DROP COLUMN ", style="red")
            content.append(f"{col_name}\n", style="red bold")

        for change in type_changes:
            col_name = self._extract_column_name(change)
            old_type = change.metadata.get("old_type", "?")
            new_type = change.metadata.get("new_type", "?")
            content.append("  ALTER COLUMN ", style="magenta")
            content.append(f"{col_name} ", style="bold")
            content.append(f"{old_type}", style="red")
            content.append(" -> ", style="dim")
            content.append(f"{new_type}\n", style="green")

        for change in modified_cols:
            col_name = self._extract_column_name(change)
            content.append("  MODIFY COLUMN ", style="yellow")
            content.append(f"{col_name}\n", style="bold")

        for change in added_cols:
            col_name = self._extract_column_name(change)
            col_type = self._extract_column_type(change)
            content.append("  ADD COLUMN ", style="green")
            content.append(f"{col_name} ", style="bold")
            content.append(f"{col_type}\n", style="cyan")

        ctx.console.print(Panel(content, border_style=color))

        # Verbose output
        if ctx.verbose:
            for change in changes:
                self.render_verbose_info(ctx, change)

        ctx.console.print()

    def _render_create_table(
        self, ctx: RenderContext, table_name: str, columns: list[dict]
    ) -> None:
        """Render CREATE TABLE style output."""
        content = Text()
        content.append("CREATE TABLE ", style="green")
        content.append(f"{table_name} (\n", style="bold")

        for i, col in enumerate(columns[:10]):
            name = col.get("name", "?")
            col_type = col.get("type", "?")
            nullable = col.get("nullable", True)
            pk = col.get("primary_key", False)

            content.append(f"  {name} ", style="bold")
            content.append(f"{col_type}", style="cyan")
            if pk:
                content.append(" PRIMARY KEY", style="yellow")
            elif not nullable:
                content.append(" NOT NULL", style="yellow")

            if i < len(columns) - 1:
                content.append(",")
            content.append("\n")

        if len(columns) > 10:
            content.append(f"  ... +{len(columns) - 10} more columns\n", style="dim")

        content.append(")", style="green")

        ctx.console.print(Panel(content, border_style="green"))

    def _render_index_changes(self, ctx: RenderContext, changes: list[Change]) -> None:
        """Render index changes."""
        ctx.console.print(Panel("[bold]Index Changes[/bold]", border_style="cyan", padding=(0, 2)))
        ctx.console.print()

        # Group by risk
        breaking = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        def render_group(changes: list[Change], title: str, color: str) -> None:
            if not changes:
                return
            ctx.console.print(f"[bold {color}]{title}[/bold {color}]")

            table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
            table.add_column("", width=3)
            table.add_column("Index", style="cyan", max_width=25)
            table.add_column("Table", max_width=20)
            table.add_column("Columns", max_width=30)

            for change in changes:
                symbol, sym_color = self.format_change_type(change.change_type)
                index_name = change.path.split("/")[-1]

                table_name = "?"
                columns = []
                for entity in [change.new_entity, change.old_entity]:
                    if entity and isinstance(entity.value, dict):
                        table_name = entity.value.get("table", table_name)
                        columns = entity.value.get("columns", columns)
                        break

                table.add_row(
                    f"[{sym_color}]{symbol}[/{sym_color}]",
                    f"[{color}]{index_name}[/{color}]",
                    table_name,
                    ", ".join(columns) if columns else "?",
                )

            ctx.console.print(table)
            ctx.console.print()

        if breaking:
            render_group(breaking, "[X] Breaking Index Changes", "red")
        if risky and not ctx.breaking_only:
            render_group(risky, "[!] Risky Index Changes", "yellow")
        if safe and ctx.show_safe and not ctx.breaking_only:
            render_group(safe, "[o] Safe Index Changes", "green")

    def _render_view_changes(self, ctx: RenderContext, changes: list[Change]) -> None:
        """Render view changes."""
        ctx.console.print(Panel("[bold]View Changes[/bold]", border_style="cyan", padding=(0, 2)))
        ctx.console.print()

        # Group by risk
        breaking = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        def render_group(changes: list[Change], title: str, color: str) -> None:
            if not changes:
                return
            ctx.console.print(f"[bold {color}]{title}[/bold {color}]")

            for change in changes:
                symbol, sym_color = self.format_change_type(change.change_type)
                view_name = change.path.split("/")[-1]

                if change.change_type == ChangeType.ADDED:
                    ctx.console.print(f"  [green]+ CREATE VIEW {view_name}[/green]")
                elif change.change_type == ChangeType.REMOVED:
                    ctx.console.print(f"  [red]- DROP VIEW {view_name}[/red]")
                else:
                    ctx.console.print(f"  [yellow]~ ALTER VIEW {view_name}[/yellow]")

            ctx.console.print()

        if breaking:
            render_group(breaking, "[X] Breaking View Changes", "red")
        if risky and not ctx.breaking_only:
            render_group(risky, "[!] Risky View Changes", "yellow")
        if safe and ctx.show_safe and not ctx.breaking_only:
            render_group(safe, "[o] Safe View Changes", "green")

    def _extract_table_name(self, change: Change) -> str:
        """Extract table name from change path."""
        path = change.path
        if "/tables/" in path:
            parts = path.split("/tables/")[1].split("/")
            return parts[0]
        if path.startswith("table_"):
            return path.split("/")[0].replace("table_", "")
        return path.split("/")[0]

    def _extract_column_name(self, change: Change) -> str:
        """Extract column name from change."""
        path = change.path
        parts = path.split("/")
        for i, part in enumerate(parts):
            if "column" in part.lower() and i + 1 < len(parts):
                return parts[i + 1]
        return parts[-1]

    def _extract_column_type(self, change: Change) -> str:
        """Extract column type from change."""
        for entity in [change.new_entity, change.old_entity]:
            if entity and isinstance(entity.value, dict):
                return entity.value.get("type", "?")
        return "?"

    def _extract_column_names(self, changes: list[Change]) -> list[str]:
        """Extract all column names from changes."""
        names = []
        for change in changes:
            if "column" in change.path.lower():
                names.append(self._extract_column_name(change))
        return names

    def _extract_column_info(self, changes: list[Change]) -> list[dict]:
        """Extract column information from changes."""
        columns = []
        for change in changes:
            if "column" not in change.path.lower():
                continue

            col_info = {
                "name": self._extract_column_name(change),
                "type": "?",
                "nullable": True,
                "primary_key": False,
            }

            for entity in [change.new_entity, change.old_entity]:
                if entity and isinstance(entity.value, dict):
                    col_info.update(entity.value)
                    break

            columns.append(col_info)

        return columns
