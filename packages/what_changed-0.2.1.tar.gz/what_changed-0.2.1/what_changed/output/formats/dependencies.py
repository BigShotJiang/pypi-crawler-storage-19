"""Dependencies renderer (package.json, requirements.txt, Gemfile, etc.)."""

from typing import Any, Optional
import re

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class DependenciesRenderer(FormatRenderer):
    """
    Renderer for dependency/package files.

    Displays dependency changes with:
    - Version upgrade/downgrade indicators
    - Major/minor/patch version detection
    - Grouped by dependency type (prod/dev)
    - Breaking version change warnings
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return [
            "package.json",
            "requirements.txt",
            "requirements",
            "pyproject.toml",
            "pyproject",
            "gemfile",
            "cargo.toml",
            "cargo",
            "go.mod",
            "composer.json",
            "pom.xml",
        ]

    def render(self, ctx: RenderContext) -> None:
        """Render dependencies comparison."""
        self.render_header(ctx, "Dependencies Comparison")
        self.render_change_summary(ctx)

        # Filter changes
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in dependencies[/green]\n")
            return

        # Render version changes overview
        self._render_version_overview(ctx, filtered_changes)

        # Render detailed changes
        self._render_dependency_changes(ctx, filtered_changes)

    def _render_version_overview(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render quick overview of version changes."""
        # Count change types
        added = [c for c in filtered_changes if c.change_type == ChangeType.ADDED]
        removed = [c for c in filtered_changes if c.change_type == ChangeType.REMOVED]
        modified = [c for c in filtered_changes if c.change_type == ChangeType.MODIFIED]

        # Analyze version changes
        major_upgrades = 0
        minor_upgrades = 0
        patch_upgrades = 0
        downgrades = 0

        for change in modified:
            version_change = self._analyze_version_change(change)
            if version_change == "major":
                major_upgrades += 1
            elif version_change == "minor":
                minor_upgrades += 1
            elif version_change == "patch":
                patch_upgrades += 1
            elif version_change == "downgrade":
                downgrades += 1

        # Build overview
        overview = Text()
        if added:
            overview.append(f"+{len(added)} added  ", style="bold green")
        if removed:
            overview.append(f"-{len(removed)} removed  ", style="bold red")
        if major_upgrades:
            overview.append(f"^{major_upgrades} major  ", style="bold red")
        if minor_upgrades:
            overview.append(f"^{minor_upgrades} minor  ", style="bold yellow")
        if patch_upgrades:
            overview.append(f"^{patch_upgrades} patch  ", style="bold green")
        if downgrades:
            overview.append(f"v{downgrades} downgrade  ", style="bold magenta")

        if overview.plain:
            ctx.console.print(Panel(overview, title="[bold]Summary[/bold]", border_style="dim"))
            ctx.console.print()

    def _render_dependency_changes(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render detailed dependency changes table."""
        if not filtered_changes:
            ctx.console.print("[dim]No dependency changes[/dim]")
            return

        # Group by risk level first
        breaking = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        # Breaking changes
        if breaking:
            ctx.console.print("[bold red][X] Breaking Changes[/bold red]")

            # Sub-categorize
            major_changes = [c for c in breaking if self._analyze_version_change(c) == "major"]
            removed = [c for c in breaking if c.change_type == ChangeType.REMOVED]
            other_breaking = [c for c in breaking if c not in major_changes and c not in removed]

            if major_changes:
                ctx.console.print("[dim]Major Version Changes:[/dim]")
                self._render_version_table(ctx, major_changes, "red")

            if removed:
                ctx.console.print("[dim]Removed Dependencies:[/dim]")
                self._render_simple_table(ctx, removed, "red", show_old=True)

            if other_breaking:
                self._render_version_table(ctx, other_breaking, "red")

            ctx.console.print()

        # Risky changes
        if risky and not ctx.breaking_only:
            ctx.console.print("[bold yellow][!] Risky Changes[/bold yellow]")

            minor_upgrades = [c for c in risky if self._analyze_version_change(c) == "minor"]
            downgrades = [c for c in risky if self._analyze_version_change(c) == "downgrade"]
            other_risky = [c for c in risky if c not in minor_upgrades and c not in downgrades]

            if minor_upgrades:
                ctx.console.print("[dim]Minor Version Upgrades:[/dim]")
                self._render_version_table(ctx, minor_upgrades, "yellow")

            if downgrades:
                ctx.console.print("[dim]Version Downgrades:[/dim]")
                self._render_version_table(ctx, downgrades, "magenta")

            if other_risky:
                self._render_version_table(ctx, other_risky, "yellow")

            ctx.console.print()

        # Safe changes
        if safe and ctx.show_safe and not ctx.breaking_only:
            ctx.console.print("[bold green][o] Safe Changes[/bold green]")

            patch_upgrades = [c for c in safe if self._analyze_version_change(c) == "patch"]
            added = [c for c in safe if c.change_type == ChangeType.ADDED]
            other_safe = [c for c in safe if c not in patch_upgrades and c not in added]

            if patch_upgrades:
                ctx.console.print("[dim]Patch Version Upgrades:[/dim]")
                self._render_version_table(ctx, patch_upgrades, "green")

            if added:
                ctx.console.print("[dim]Added Dependencies:[/dim]")
                self._render_simple_table(ctx, added, "green", show_old=False)

            if other_safe:
                self._render_version_table(ctx, other_safe, "green")

            ctx.console.print()

    def _render_version_table(
        self, ctx: RenderContext, changes: list[Change], color: str
    ) -> None:
        """Render a table of version changes."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("Package", style="cyan", max_width=30)
        table.add_column("Old Version", justify="right", max_width=15)
        table.add_column("", justify="center", width=3)
        table.add_column("New Version", justify="right", max_width=15)
        table.add_column("Change", justify="center", width=8)

        for change in changes:
            pkg_name = self._extract_package_name(change)
            old_ver = self._extract_version(change.old_value)
            new_ver = self._extract_version(change.new_value)
            change_type = self._analyze_version_change(change)

            arrow = "->"
            change_label = change_type.upper() if change_type else "?"

            table.add_row(
                pkg_name,
                f"[red]{old_ver}[/red]",
                f"[{color}]{arrow}[/{color}]",
                f"[green]{new_ver}[/green]",
                f"[{color}]{change_label}[/{color}]",
            )

            if ctx.verbose:
                self.render_verbose_info(ctx, change)

        ctx.console.print(table)

    def _render_simple_table(
        self, ctx: RenderContext, changes: list[Change], color: str, show_old: bool
    ) -> None:
        """Render a simple add/remove table."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("Package", style="cyan", max_width=30)
        table.add_column("Version", max_width=20)
        table.add_column("Type", max_width=15)

        for change in changes:
            pkg_name = self._extract_package_name(change)
            value = change.old_value if show_old else change.new_value
            version = self._extract_version(value)
            dep_type = self._extract_dep_type(change)

            table.add_row(
                f"[{color}]{pkg_name}[/{color}]",
                version,
                f"[dim]{dep_type}[/dim]",
            )

            if ctx.verbose:
                self.render_verbose_info(ctx, change)

        ctx.console.print(table)

    def _extract_package_name(self, change: Change) -> str:
        """Extract package name from change."""
        path = change.path
        for prefix in [
            "dependencies/",
            "devDependencies/",
            "packages/",
            "require/",
        ]:
            if path.startswith(prefix):
                return path[len(prefix):].split("/")[0]

        if isinstance(change.new_value, dict):
            if "name" in change.new_value:
                return change.new_value["name"]
        if isinstance(change.old_value, dict):
            if "name" in change.old_value:
                return change.old_value["name"]

        return path.split("/")[-1]

    def _extract_version(self, value: Any) -> str:
        """Extract version string from value."""
        if value is None:
            return "?"
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            return value.get("version", value.get("specifier", "?"))
        return str(value)

    def _extract_dep_type(self, change: Change) -> str:
        """Extract dependency type (dev, prod, etc.)."""
        path = change.path.lower()
        if "dev" in path:
            return "dev"
        if "peer" in path:
            return "peer"
        if "optional" in path:
            return "optional"
        return "prod"

    def _analyze_version_change(self, change: Change) -> Optional[str]:
        """Analyze what kind of version change this is."""
        old_ver = self._extract_version(change.old_value)
        new_ver = self._extract_version(change.new_value)

        old_parts = self._parse_version(old_ver)
        new_parts = self._parse_version(new_ver)

        if not old_parts or not new_parts:
            return None

        old_major, old_minor, old_patch = old_parts
        new_major, new_minor, new_patch = new_parts

        # Check for downgrade
        if new_major < old_major:
            return "downgrade"
        if new_major == old_major and new_minor < old_minor:
            return "downgrade"
        if new_major == old_major and new_minor == old_minor and new_patch < old_patch:
            return "downgrade"

        # Check for upgrade type
        if new_major > old_major:
            return "major"
        if new_minor > old_minor:
            return "minor"
        if new_patch > old_patch:
            return "patch"

        return None

    def _parse_version(self, version: str) -> Optional[tuple[int, int, int]]:
        """Parse a semver-like version string."""
        if not version or version == "?":
            return None

        version = version.lstrip("^~>=<")

        match = re.match(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", version)
        if not match:
            return None

        major = int(match.group(1))
        minor = int(match.group(2)) if match.group(2) else 0
        patch = int(match.group(3)) if match.group(3) else 0

        return (major, minor, patch)
