"""Image file renderer."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.columns import Columns
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class ImageRenderer(FormatRenderer):
    """
    Renderer for image file comparisons.

    Displays image changes with:
    - Dimension comparison (width x height)
    - Format/mode changes
    - EXIF metadata comparison
    - File size comparison
    - OCR text comparison
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["image", "png", "jpg", "jpeg", "gif", "bmp", "tiff", "webp"]

    def render(self, ctx: RenderContext) -> None:
        """Render image comparison."""
        self.render_header(ctx, "Image Comparison")
        self.render_change_summary(ctx)

        # Filter changes based on context settings
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in image[/green]\n")
            return

        # Image overview comparison
        self._render_image_overview(ctx)

        # OCR text comparison (if text was extracted)
        self._render_text_comparison(ctx)

        # Dimension visualization
        self._render_dimension_comparison(ctx)

        # Metadata changes
        self._render_metadata_changes(ctx, filtered_changes)

    def _render_image_overview(self, ctx: RenderContext) -> None:
        """Render side-by-side image overview with improved styling."""
        meta_a = ctx.obj_a.metadata
        meta_b = ctx.obj_b.metadata
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        # Build comparison table
        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]Image Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Property", style="bold white")
        table.add_column("Before", justify="center", style="yellow")
        table.add_column("After", justify="center", style="green")
        table.add_column("Change", justify="center")

        # Dimensions
        w_a = meta_a.get("width", struct_a.get("width", 0))
        h_a = meta_a.get("height", struct_a.get("height", 0))
        w_b = meta_b.get("width", struct_b.get("width", 0))
        h_b = meta_b.get("height", struct_b.get("height", 0))

        dim_a = f"{w_a} x {h_a}"
        dim_b = f"{w_b} x {h_b}"

        if w_a != w_b or h_a != h_b:
            if w_b > w_a or h_b > h_a:
                change = "[green bold]LARGER[/green bold]"
            else:
                change = "[yellow bold]SMALLER[/yellow bold]"
        else:
            change = "[dim]=[/dim]"

        table.add_row("Dimensions", dim_a, dim_b, change)

        # Megapixels
        mp_a = meta_a.get("megapixels", (w_a * h_a) / 1_000_000 if w_a and h_a else 0)
        mp_b = meta_b.get("megapixels", (w_b * h_b) / 1_000_000 if w_b and h_b else 0)
        if mp_a or mp_b:
            diff = mp_b - mp_a
            if diff > 0.1:
                mp_change = f"[green bold]+{diff:.1f}MP[/green bold]"
            elif diff < -0.1:
                mp_change = f"[red bold]{diff:.1f}MP[/red bold]"
            else:
                mp_change = "[dim]=[/dim]"
            table.add_row("Megapixels", f"{mp_a:.2f}MP", f"{mp_b:.2f}MP", mp_change)

        # Aspect ratio
        ar_a = meta_a.get("aspect_ratio", w_a / h_a if h_a else 0)
        ar_b = meta_b.get("aspect_ratio", w_b / h_b if h_b else 0)
        if ar_a or ar_b:
            ar_changed = abs(ar_a - ar_b) > 0.01
            ar_change = "[yellow bold]CHANGED[/yellow bold]" if ar_changed else "[dim]=[/dim]"
            table.add_row("Aspect Ratio", f"{ar_a:.2f}", f"{ar_b:.2f}", ar_change)

        # Format
        fmt_a = meta_a.get("format", struct_a.get("format", "?"))
        fmt_b = meta_b.get("format", struct_b.get("format", "?"))
        fmt_change = "[yellow bold]CHANGED[/yellow bold]" if fmt_a != fmt_b else "[dim]=[/dim]"
        table.add_row("Format", str(fmt_a), str(fmt_b), fmt_change)

        # Color mode
        mode_a = meta_a.get("mode", struct_a.get("mode", "?"))
        mode_b = meta_b.get("mode", struct_b.get("mode", "?"))
        mode_change = "[yellow bold]CHANGED[/yellow bold]" if mode_a != mode_b else "[dim]=[/dim]"
        table.add_row("Color Mode", str(mode_a), str(mode_b), mode_change)

        # File size
        size_a = meta_a.get("file_size", 0)
        size_b = meta_b.get("file_size", 0)
        if size_a or size_b:
            diff = size_b - size_a
            if diff > 0:
                size_change = f"[red bold]+{self._format_size(diff)}[/red bold]"
            elif diff < 0:
                size_change = f"[green bold]-{self._format_size(abs(diff))}[/green bold]"
            else:
                size_change = "[dim]=[/dim]"
            table.add_row(
                "File Size",
                self._format_size(size_a),
                self._format_size(size_b),
                size_change,
            )

        ctx.console.print(table)
        ctx.console.print()

    def _render_text_comparison(self, ctx: RenderContext) -> None:
        """Render OCR text comparison if text was extracted."""
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        has_text_a = struct_a.get("has_text", False)
        has_text_b = struct_b.get("has_text", False)

        if not has_text_a and not has_text_b:
            return

        # Get text from entities
        text_a = ""
        text_b = ""

        for entity in ctx.obj_a.entities:
            if entity.name == "text_content":
                text_a = entity.value.get("text", "")
                break

        for entity in ctx.obj_b.entities:
            if entity.name == "text_content":
                text_b = entity.value.get("text", "")
                break

        if not text_a and not text_b:
            return

        ctx.console.print(Panel(
            "[bold]OCR Text Content[/bold]",
            border_style="cyan",
            padding=(0, 2),
        ))
        ctx.console.print()

        # Word count comparison
        words_a = len(text_a.split()) if text_a else 0
        words_b = len(text_b.split()) if text_b else 0

        if text_a == text_b:
            ctx.console.print(Panel(
                f"[green bold]Text Identical[/green bold] ({words_a} words)",
                border_style="green",
            ))
        else:
            # Summary
            summary = Text()
            summary.append(f"Words: {words_a} -> {words_b}  ", style="bold")
            if words_b > words_a:
                summary.append(f"(+{words_b - words_a})", style="green")
            elif words_b < words_a:
                summary.append(f"({words_b - words_a})", style="red")

            ctx.console.print(Panel(
                f"[yellow bold]Text Differs[/yellow bold]",
                subtitle=str(summary),
                border_style="yellow",
            ))
            ctx.console.print()

            # Show text side by side
            table = Table(
                box=box.ROUNDED,
                show_header=True,
                header_style="bold dim",
                border_style="dim",
            )
            table.add_column("Before", style="red", max_width=40)
            table.add_column("After", style="green", max_width=40)

            # Truncate if too long
            text_a_display = text_a[:500] + "..." if len(text_a) > 500 else text_a
            text_b_display = text_b[:500] + "..." if len(text_b) > 500 else text_b

            table.add_row(text_a_display or "[dim](no text)[/dim]", text_b_display or "[dim](no text)[/dim]")
            ctx.console.print(table)

        ctx.console.print()

    def _render_dimension_comparison(self, ctx: RenderContext) -> None:
        """Render visual dimension comparison."""
        meta_a = ctx.obj_a.metadata
        meta_b = ctx.obj_b.metadata
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        w_a = meta_a.get("width", struct_a.get("width", 0))
        h_a = meta_a.get("height", struct_a.get("height", 0))
        w_b = meta_b.get("width", struct_b.get("width", 0))
        h_b = meta_b.get("height", struct_b.get("height", 0))

        if not (w_a and h_a and w_b and h_b):
            return

        # Only show if dimensions are different
        if w_a == w_b and h_a == h_b:
            return

        # Create ASCII visualization
        max_display = 20
        scale = max_display / max(w_a, h_a, w_b, h_b)

        box_a = self._create_dimension_box(
            int(w_a * scale), int(h_a * scale), "Before", f"{w_a}x{h_a}"
        )
        box_b = self._create_dimension_box(
            int(w_b * scale), int(h_b * scale), "After", f"{w_b}x{h_b}"
        )

        ctx.console.print(
            Columns([Panel(box_a, border_style="yellow"), Panel(box_b, border_style="green")])
        )
        ctx.console.print()

    def _create_dimension_box(
        self, width: int, height: int, label: str, size_text: str
    ) -> str:
        """Create ASCII box representing dimensions."""
        width = max(width, 3)
        height = max(height, 2)

        lines = []
        lines.append(f"[bold]{label}[/bold]")
        lines.append(f"[dim]{size_text}[/dim]")
        lines.append("")

        # Top border
        lines.append("+" + "-" * width + "+")

        # Content
        for i in range(height):
            if i == height // 2:
                # Center line with dimensions
                content = size_text.center(width)
                lines.append("|" + content + "|")
            else:
                lines.append("|" + " " * width + "|")

        # Bottom border
        lines.append("+" + "-" * width + "+")

        return "\n".join(lines)

    def _render_metadata_changes(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render EXIF and other metadata changes with risk grouping."""
        # Find metadata changes from filtered list
        metadata_changes = [
            c
            for c in filtered_changes
            if c.entity_type == EntityType.METADATA
            or "exif" in c.path.lower()
            or "camera" in c.path.lower()
        ]

        if not metadata_changes:
            return

        ctx.console.print(Panel(
            "[bold]Metadata Changes[/bold]",
            border_style="cyan",
            padding=(0, 2),
        ))
        ctx.console.print()

        # Group by risk
        breaking = [c for c in metadata_changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in metadata_changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in metadata_changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        def render_group(changes: list[Change], title: str, color: str) -> None:
            if not changes:
                return
            ctx.console.print(f"[bold {color}]{title}[/bold {color}]")

            table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
            table.add_column("", width=3)
            table.add_column("Property", style="cyan", max_width=25)
            table.add_column("Before", max_width=25)
            table.add_column("After", max_width=25)

            for change in changes[:15]:
                symbol, sym_color = self.format_change_type(change.change_type)
                prop_name = change.path.split("/")[-1]

                old_val = self.format_value(change.old_value, 25) if change.old_value else "-"
                new_val = self.format_value(change.new_value, 25) if change.new_value else "-"

                table.add_row(
                    f"[{sym_color}]{symbol}[/{sym_color}]",
                    prop_name,
                    f"[red dim]{old_val}[/red dim]" if change.old_value else "[dim]-[/dim]",
                    f"[green]{new_val}[/green]" if change.new_value else "[dim]-[/dim]",
                )

                # Verbose output
                if ctx.verbose:
                    self.render_verbose_info(ctx, change)

            if len(changes) > 15:
                table.add_row("", f"[dim]... +{len(changes) - 15} more[/dim]", "", "")

            ctx.console.print(table)
            ctx.console.print()

        if breaking:
            render_group(breaking, "[X] Breaking Changes", "red")
        if risky and not ctx.breaking_only:
            render_group(risky, "[!] Risky Changes", "yellow")
        if safe and ctx.show_safe and not ctx.breaking_only:
            render_group(safe, "[o] Safe Changes", "green")

    def _format_size(self, size: int) -> str:
        """Format file size for display."""
        if size < 1024:
            return f"{size}B"
        elif size < 1024 * 1024:
            return f"{size / 1024:.1f}KB"
        else:
            return f"{size / (1024 * 1024):.1f}MB"
