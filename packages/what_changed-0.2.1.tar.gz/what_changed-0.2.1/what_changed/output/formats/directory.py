"""Directory comparison renderer."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class DirectoryRenderer(FormatRenderer):
    """
    Renderer for directory comparisons.

    Displays directory changes with:
    - Tree structure visualization
    - File counts and sizes
    - Added/removed/modified files
    - File type breakdown
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["directory", "dir", "folder"]

    def render(self, ctx: RenderContext) -> None:
        """Render directory comparison."""
        self.render_header(ctx, "Directory Comparison")
        self.render_change_summary(ctx)

        # Filter changes
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in directory[/green]\n")
            return

        # Directory overview
        self._render_directory_overview(ctx)

        # File type breakdown
        self._render_file_type_changes(ctx)

        # File changes tree
        self._render_file_tree(ctx, filtered_changes)

    def _render_directory_overview(self, ctx: RenderContext) -> None:
        """Render directory overview comparison."""
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]Directory Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Metric", style="bold white")
        table.add_column("Before", justify="right", style="yellow")
        table.add_column("After", justify="right", style="green")
        table.add_column("Change", justify="center")

        metrics = [
            ("Files", "total_files"),
            ("Directories", "total_directories"),
            ("Total Size", "total_size"),
        ]

        for label, key in metrics:
            val_a = struct_a.get(key, 0)
            val_b = struct_b.get(key, 0)

            # Format size values
            if key == "total_size":
                val_a_str = self._format_size(val_a)
                val_b_str = self._format_size(val_b)
                diff = val_b - val_a
                if diff > 0:
                    change_str = f"[red bold]+{self._format_size(diff)}[/red bold]"
                elif diff < 0:
                    change_str = f"[green bold]-{self._format_size(abs(diff))}[/green bold]"
                else:
                    change_str = "[dim]=[/dim]"
            else:
                val_a_str = str(val_a)
                val_b_str = str(val_b)
                diff = val_b - val_a
                if diff > 0:
                    change_str = f"[green bold]+{diff}[/green bold]"
                elif diff < 0:
                    change_str = f"[red bold]{diff}[/red bold]"
                else:
                    change_str = "[dim]=[/dim]"

            table.add_row(label, val_a_str, val_b_str, change_str)

        ctx.console.print(table)
        ctx.console.print()

    def _render_file_type_changes(self, ctx: RenderContext) -> None:
        """Render file type breakdown."""
        types_a = ctx.obj_a.structure.get("file_types", {})
        types_b = ctx.obj_b.structure.get("file_types", {})

        all_types = set(types_a.keys()) | set(types_b.keys())

        if not all_types:
            return

        # Only show if there are significant differences
        has_changes = False
        for ext in all_types:
            if types_a.get(ext, 0) != types_b.get(ext, 0):
                has_changes = True
                break

        if not has_changes:
            return

        ctx.console.print(Panel("[bold]File Type Changes[/bold]", border_style="cyan", padding=(0, 2)))
        ctx.console.print()

        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("Extension", style="cyan")
        table.add_column("Before", justify="right")
        table.add_column("After", justify="right")
        table.add_column("Change", justify="center")

        # Sort by total count
        sorted_types = sorted(
            all_types, key=lambda x: max(types_a.get(x, 0), types_b.get(x, 0)), reverse=True
        )

        for ext in sorted_types[:15]:
            count_a = types_a.get(ext, 0)
            count_b = types_b.get(ext, 0)
            diff = count_b - count_a

            if diff == 0:
                continue

            if diff > 0:
                change_str = f"[green bold]+{diff}[/green bold]"
            else:
                change_str = f"[red bold]{diff}[/red bold]"

            table.add_row(
                ext if ext else "(no ext)",
                str(count_a),
                str(count_b),
                change_str,
            )

        ctx.console.print(table)
        ctx.console.print()

    def _render_file_tree(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render file changes as a tree."""
        if not filtered_changes:
            ctx.console.print("[dim]No file changes[/dim]")
            return

        # Group by risk level
        breaking = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        # Breaking files
        if breaking:
            # Further categorize
            removed = [c for c in breaking if c.change_type == ChangeType.REMOVED]
            other_breaking = [c for c in breaking if c.change_type != ChangeType.REMOVED]

            if removed:
                ctx.console.print("[bold red][X] Removed Files (Breaking)[/bold red]")
                self._render_file_list(ctx, removed, "red")
                ctx.console.print()

            if other_breaking:
                ctx.console.print("[bold red][X] Breaking File Changes[/bold red]")
                self._render_file_list(ctx, other_breaking, "red")
                ctx.console.print()

        # Risky files
        if risky and not ctx.breaking_only:
            modified = [c for c in risky if c.change_type == ChangeType.MODIFIED]
            other_risky = [c for c in risky if c.change_type != ChangeType.MODIFIED]

            if modified:
                ctx.console.print("[bold yellow][!] Modified Files[/bold yellow]")
                self._render_file_list(ctx, modified, "yellow")
                ctx.console.print()

            if other_risky:
                ctx.console.print("[bold yellow][!] Risky File Changes[/bold yellow]")
                self._render_file_list(ctx, other_risky, "yellow")
                ctx.console.print()

        # Safe files
        if safe and ctx.show_safe and not ctx.breaking_only:
            added = [c for c in safe if c.change_type == ChangeType.ADDED]
            other_safe = [c for c in safe if c.change_type != ChangeType.ADDED]

            if added:
                ctx.console.print("[bold green][o] Added Files[/bold green]")
                self._render_file_list(ctx, added, "green")
                ctx.console.print()

            if other_safe:
                ctx.console.print("[bold green][o] Safe File Changes[/bold green]")
                self._render_file_list(ctx, other_safe, "green")
                ctx.console.print()

    def _render_file_list(
        self, ctx: RenderContext, changes: list[Change], color: str
    ) -> None:
        """Render a list of file changes."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("", width=3)
        table.add_column("Path", style="cyan", max_width=50)
        table.add_column("Size", justify="right", width=10)
        table.add_column("Type", width=8)

        for change in changes[:20]:
            symbol, sym_color = self.format_change_type(change.change_type)
            path = change.path
            if len(path) > 50:
                path = "..." + path[-47:]

            # Get size
            size = self._get_file_size(change)
            size_str = self._format_size(size) if size else "-"

            # Get type
            entity = change.new_entity or change.old_entity
            file_type = "file"
            if entity:
                if entity.entity_type == EntityType.DIRECTORY:
                    file_type = "dir"
                ext = entity.metadata.get("extension", "")
                if ext:
                    file_type = ext

            table.add_row(
                f"[{sym_color}]{symbol}[/{sym_color}]",
                f"[{color}]{path}[/{color}]",
                size_str,
                file_type,
            )

            # Verbose output
            if ctx.verbose:
                self.render_verbose_info(ctx, change)

        if len(changes) > 20:
            table.add_row("", f"[dim]... +{len(changes) - 20} more files[/dim]", "", "")

        ctx.console.print(table)

    def _get_file_size(self, change: Change) -> Optional[int]:
        """Get file size from change."""
        for entity in [change.new_entity, change.old_entity]:
            if entity and entity.metadata.get("size"):
                return entity.metadata["size"]
        return None

    def _format_size(self, size: int) -> str:
        """Format file size for display."""
        if size < 1024:
            return f"{size}B"
        elif size < 1024 * 1024:
            return f"{size / 1024:.1f}KB"
        elif size < 1024 * 1024 * 1024:
            return f"{size / (1024 * 1024):.1f}MB"
        else:
            return f"{size / (1024 * 1024 * 1024):.1f}GB"
