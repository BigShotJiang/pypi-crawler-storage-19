"""CSV and data file renderer."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class CSVRenderer(FormatRenderer):
    """
    Renderer for CSV and tabular data files.

    Displays data changes with:
    - Schema/column comparison
    - Row count changes
    - Sample data comparison
    - Column statistics
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["csv", "tsv", "excel", "xlsx", "xls", "data"]

    def render(self, ctx: RenderContext) -> None:
        """Render CSV/data comparison."""
        self.render_header(ctx, "Data File Comparison")
        self.render_change_summary(ctx)

        # Filter changes
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in data file[/green]\n")
            return

        # Data overview
        self._render_data_overview(ctx)

        # Schema comparison
        self._render_schema_comparison(ctx)

        # Data changes
        self._render_data_changes(ctx, filtered_changes)

    def _render_data_overview(self, ctx: RenderContext) -> None:
        """Render data file overview."""
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]Data Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Metric", style="bold white")
        table.add_column("Before", justify="right", style="yellow")
        table.add_column("After", justify="right", style="green")
        table.add_column("Change", justify="center")

        metrics = [
            ("Rows", "row_count"),
            ("Columns", "column_count"),
            ("Sheets", "sheet_count"),
        ]

        for label, key in metrics:
            val_a = struct_a.get(key, 0)
            val_b = struct_b.get(key, 0)

            if val_a == 0 and val_b == 0:
                continue

            diff = val_b - val_a
            if diff > 0:
                change_str = f"[green bold]+{diff}[/green bold]"
            elif diff < 0:
                change_str = f"[red bold]{diff}[/red bold]"
            else:
                change_str = "[dim]=[/dim]"

            pct = ((val_b - val_a) / val_a * 100) if val_a > 0 else 0
            if abs(pct) > 1:
                change_str += f" [dim]({pct:+.1f}%)[/dim]"

            table.add_row(label, str(val_a), str(val_b), change_str)

        ctx.console.print(table)
        ctx.console.print()

    def _render_schema_comparison(self, ctx: RenderContext) -> None:
        """Render column/schema comparison."""
        headers_a = set(ctx.obj_a.structure.get("headers", []))
        headers_b = set(ctx.obj_b.structure.get("headers", []))

        added_cols = headers_b - headers_a
        removed_cols = headers_a - headers_b
        common_cols = headers_a & headers_b

        if not added_cols and not removed_cols:
            return

        ctx.console.print(Panel("[bold]Schema Changes[/bold]", border_style="cyan", padding=(0, 2)))
        ctx.console.print()

        # Removed columns (breaking)
        if removed_cols:
            ctx.console.print("[bold red][X] Removed Columns (Breaking)[/bold red]")
            for col in sorted(removed_cols):
                ctx.console.print(f"  [red]- {col}[/red]")
            ctx.console.print()

        # Added columns (safe)
        if added_cols and not ctx.breaking_only:
            ctx.console.print("[bold green][o] Added Columns[/bold green]")
            for col in sorted(added_cols):
                ctx.console.print(f"  [green]+ {col}[/green]")
            ctx.console.print()

        # Show column order if it changed
        headers_a_list = ctx.obj_a.structure.get("headers", [])
        headers_b_list = ctx.obj_b.structure.get("headers", [])

        if headers_a_list and headers_b_list and not ctx.breaking_only:
            common_order_a = [h for h in headers_a_list if h in common_cols]
            common_order_b = [h for h in headers_b_list if h in common_cols]

            if common_order_a != common_order_b:
                ctx.console.print("[yellow][!] Column order changed[/yellow]")
                ctx.console.print()

    def _render_data_changes(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render actual data changes."""
        if not filtered_changes:
            ctx.console.print("[dim]No data changes detected[/dim]")
            return

        # Group by risk
        breaking = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in filtered_changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        # Find content diff if available
        content_changes = [c for c in filtered_changes if c.content_diff and c.content_diff.has_changes]

        if content_changes:
            ctx.console.print(Panel("[bold]Data Changes[/bold]", border_style="cyan", padding=(0, 2)))
            ctx.console.print()

            for change in content_changes[:3]:
                diff = change.content_diff
                lines = []
                line_count = 0
                max_lines = 15

                for hunk in diff.hunks:
                    lines.append(f"[cyan bold]{hunk.header}[/cyan bold]")
                    line_count += 1

                    for line in hunk.lines:
                        if line_count >= max_lines:
                            break

                        from what_changed.diff.content_diff import LineChangeType

                        if line.line_type == LineChangeType.ADDED:
                            lines.append(f"[green]+{line.content}[/green]")
                        elif line.line_type == LineChangeType.REMOVED:
                            lines.append(f"[red]-{line.content}[/red]")
                        else:
                            lines.append(f"[dim] {line.content}[/dim]")

                        line_count += 1

                    if line_count >= max_lines:
                        lines.append(
                            f"[dim]... ({diff.lines_added} added, {diff.lines_removed} removed total)[/dim]"
                        )
                        break

                # Get risk level for border color
                risk = ctx.get_change_risk(change)
                risk_symbol, risk_color = self.format_risk_level(risk)

                ctx.console.print(
                    Panel(
                        "\n".join(lines),
                        title=f"[cyan]{change.path}[/cyan] {risk_symbol}",
                        subtitle=f"[green]+{diff.lines_added}[/green] [red]-{diff.lines_removed}[/red]",
                        border_style=risk_color,
                    )
                )

                # Verbose output
                if ctx.verbose:
                    self.render_verbose_info(ctx, change)

                ctx.console.print()

        # Render sample data comparison if available
        if not ctx.breaking_only:
            self._render_sample_comparison(ctx)

    def _render_sample_comparison(self, ctx: RenderContext) -> None:
        """Render sample data side by side."""
        sample_a = self._get_sample_rows(ctx.obj_a)
        sample_b = self._get_sample_rows(ctx.obj_b)

        if not sample_a and not sample_b:
            return

        headers_a = ctx.obj_a.structure.get("headers", [])
        headers_b = ctx.obj_b.structure.get("headers", [])

        # Show sample from A
        if sample_a and headers_a:
            ctx.console.print("[dim]Sample from Before:[/dim]")
            table_a = self._create_sample_table(headers_a, sample_a[:5])
            ctx.console.print(table_a)
            ctx.console.print()

        # Show sample from B
        if sample_b and headers_b:
            ctx.console.print("[dim]Sample from After:[/dim]")
            table_b = self._create_sample_table(headers_b, sample_b[:5])
            ctx.console.print(table_b)
            ctx.console.print()

    def _get_sample_rows(self, obj) -> list:
        """Extract sample rows from normalized object."""
        for entity in obj.entities:
            if entity.entity_type == EntityType.DOCUMENT:
                if isinstance(entity.value, dict):
                    return entity.value.get("rows", [])
        return []

    def _create_sample_table(self, headers: list, rows: list) -> Table:
        """Create a table showing sample data."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")

        # Add columns (limit to 6)
        display_headers = headers[:6]
        for header in display_headers:
            table.add_column(str(header), max_width=20)

        if len(headers) > 6:
            table.add_column(f"... +{len(headers) - 6}", style="dim")

        # Add rows
        for row in rows:
            values = []
            for i, header in enumerate(display_headers):
                if isinstance(row, dict):
                    val = row.get(header, "")
                elif isinstance(row, (list, tuple)) and i < len(row):
                    val = row[i]
                else:
                    val = ""

                val_str = str(val)
                if len(val_str) > 20:
                    val_str = val_str[:17] + "..."
                values.append(val_str)

            if len(headers) > 6:
                values.append("...")

            table.add_row(*values)

        return table
