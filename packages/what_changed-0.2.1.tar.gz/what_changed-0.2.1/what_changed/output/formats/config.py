"""Config file renderer (JSON, YAML, TOML, INI, ENV)."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType


class ConfigRenderer(FormatRenderer):
    """
    Renderer for configuration files.

    Displays config changes as a tree structure with:
    - Type indicators for each value
    - Color-coded changes (added/removed/modified)
    - Nested structure visualization
    - Value comparisons side-by-side
    """

    @property
    def supported_types(self) -> list[str]:
        return ["json", "yaml", "toml", "ini", "env", "config"]

    def render(self, ctx: RenderContext) -> None:
        """Render config comparison."""
        self.render_header(ctx, "Configuration Comparison")
        self.render_change_summary(ctx)

        # Filter changes based on context settings
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes:
            if ctx.breaking_only:
                ctx.console.print("[green]No breaking changes detected[/green]\n")
            else:
                ctx.console.print("[green]No changes detected[/green]\n")
            return

        # Group changes by top-level key
        changes_by_section = self._group_changes_by_section(filtered_changes)

        # Render the config diff tree
        self._render_config_tree(ctx, changes_by_section)

        # Render detailed change table
        self._render_change_details(ctx, filtered_changes)

    def _group_changes_by_section(
        self, changes: list[Change]
    ) -> dict[str, list[Change]]:
        """Group changes by their top-level section."""
        grouped: dict[str, list[Change]] = {}
        for change in changes:
            parts = change.path.split(".")
            section = parts[0] if parts else "(root)"
            grouped.setdefault(section, []).append(change)
        return grouped

    def _render_config_tree(
        self, ctx: RenderContext, changes_by_section: dict[str, list[Change]]
    ) -> None:
        """Render changes as a tree structure."""
        if not changes_by_section:
            ctx.console.print("[dim]No configuration changes[/dim]")
            return

        root = Tree("[bold cyan]config[/bold cyan]")

        for section, changes in sorted(changes_by_section.items()):
            # Determine section color based on changes
            has_breaking = any(
                c.change_type in {ChangeType.REMOVED, ChangeType.TYPE_CHANGED}
                for c in changes
            )
            has_additions = any(c.change_type == ChangeType.ADDED for c in changes)
            has_modifications = any(
                c.change_type == ChangeType.MODIFIED for c in changes
            )

            if has_breaking:
                section_style = "red"
            elif has_additions:
                section_style = "green"
            elif has_modifications:
                section_style = "yellow"
            else:
                section_style = "white"

            section_node = root.add(
                f"[{section_style}]{section}[/{section_style}] "
                f"[dim]({len(changes)} changes)[/dim]"
            )

            # Add individual changes
            for change in changes:
                self._add_change_to_tree(section_node, change)

        ctx.console.print(Panel(root, title="Changes", border_style="dim"))
        ctx.console.print()

    def _add_change_to_tree(self, parent: Tree, change: Change) -> None:
        """Add a single change to the tree."""
        symbol, color = self.format_change_type(change.change_type)

        # Build the label
        path_parts = change.path.split(".")
        key_name = path_parts[-1] if path_parts else change.path

        # Get type indicator
        type_indicator = self._get_type_indicator(change)

        label = Text()
        label.append(f"{symbol} ", style=color)
        label.append(key_name, style=f"bold {color}")

        if type_indicator:
            label.append(f" {type_indicator}", style="dim")

        # Add value comparison for modifications
        if change.change_type == ChangeType.MODIFIED:
            old_val = self.format_value(change.old_value, max_len=25)
            new_val = self.format_value(change.new_value, max_len=25)
            label.append(f"\n    ", style="dim")
            label.append(old_val, style="red dim")
            label.append(" -> ", style="dim")
            label.append(new_val, style="green")
        elif change.change_type == ChangeType.ADDED:
            new_val = self.format_value(change.new_value, max_len=40)
            label.append(f" = ", style="dim")
            label.append(new_val, style="green")
        elif change.change_type == ChangeType.REMOVED:
            old_val = self.format_value(change.old_value, max_len=40)
            label.append(f" = ", style="dim")
            label.append(old_val, style="red dim strikethrough")
        elif change.change_type == ChangeType.TYPE_CHANGED:
            old_type = change.metadata.get("old_type", "?")
            new_type = change.metadata.get("new_type", "?")
            label.append(f"\n    type: ", style="dim")
            label.append(old_type, style="red")
            label.append(" -> ", style="dim")
            label.append(new_type, style="magenta")

        parent.add(label)

    def _get_type_indicator(self, change: Change) -> str:
        """Get a type indicator for the value."""
        value = change.new_value if change.new_value is not None else change.old_value

        if value is None:
            return "<null>"
        if isinstance(value, bool):
            return "<bool>"
        if isinstance(value, int):
            return "<int>"
        if isinstance(value, float):
            return "<float>"
        if isinstance(value, str):
            return "<str>"
        if isinstance(value, dict):
            return "<object>"
        if isinstance(value, list):
            return "<array>"
        return ""

    def _render_change_details(self, ctx: RenderContext, changes: list[Change]) -> None:
        """Render detailed table of all changes."""
        if not changes:
            return

        # Group changes by risk level using actual risk from graph
        from what_changed.graph.model import RiskLevel

        breaking = []
        risky = []
        safe = []

        for c in changes:
            risk = ctx.get_change_risk(c)
            if risk == RiskLevel.BREAKING:
                breaking.append(c)
            elif risk == RiskLevel.RISKY:
                risky.append(c)
            else:
                safe.append(c)

        # Breaking changes table
        if breaking:
            ctx.console.print("[bold red][X] Breaking Changes[/bold red]")
            table = self._create_config_table()
            for change in breaking:
                self._add_change_row(table, change, "red")
            ctx.console.print(table)
            ctx.console.print()

        # Risky changes table
        if risky and not ctx.breaking_only:
            ctx.console.print("[bold yellow][!] Risky Changes[/bold yellow]")
            table = self._create_config_table()
            for change in risky:
                self._add_change_row(table, change, "yellow")
            ctx.console.print(table)
            ctx.console.print()

        # Safe changes
        if safe and ctx.show_safe and not ctx.breaking_only:
            ctx.console.print("[bold green][o] Safe Changes[/bold green]")
            table = self._create_config_table()
            for change in safe:
                self._add_change_row(table, change, "green")
            ctx.console.print(table)
            ctx.console.print()

    def _create_config_table(self) -> Table:
        """Create the config changes table."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("Path", style="cyan", max_width=35)
        table.add_column("Type", justify="center", width=8)
        table.add_column("Old Value", max_width=25)
        table.add_column("New Value", max_width=25)
        return table

    def _add_change_row(self, table: Table, change: Change, color: str) -> None:
        """Add a change row to the table."""
        symbol, _ = self.format_change_type(change.change_type)
        type_ind = self._get_type_indicator(change)

        old_val = self.format_value(change.old_value, max_len=25) if change.old_value is not None else "-"
        new_val = self.format_value(change.new_value, max_len=25) if change.new_value is not None else "-"

        table.add_row(
            f"[{color}]{symbol}[/{color}] {change.path}",
            type_ind,
            f"[red]{old_val}[/red]" if change.old_value is not None else "[dim]-[/dim]",
            f"[green]{new_val}[/green]" if change.new_value is not None else "[dim]-[/dim]",
        )
