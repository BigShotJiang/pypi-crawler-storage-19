"""Dockerfile renderer."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class DockerfileRenderer(FormatRenderer):
    """
    Renderer for Dockerfile and docker-compose files.

    Displays changes with:
    - Instruction-by-instruction comparison
    - Base image change highlighting
    - Environment variable changes
    - Port/volume changes
    - Multi-stage build visualization
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["dockerfile", "docker-compose", "compose"]

    def render(self, ctx: RenderContext) -> None:
        """Render Dockerfile comparison."""
        is_compose = "compose" in ctx.obj_a.type.lower()
        title = "Docker Compose Comparison" if is_compose else "Dockerfile Comparison"
        self.render_header(ctx, title)
        self.render_change_summary(ctx)

        # Filter changes
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in Dockerfile[/green]\n")
            return

        if is_compose:
            self._render_compose_changes(ctx, filtered_changes)
        else:
            self._render_dockerfile_changes(ctx, filtered_changes)

    def _render_dockerfile_changes(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render Dockerfile-specific changes."""
        # Metadata comparison
        self._render_docker_overview(ctx)

        # Group changes by instruction type
        instruction_changes = self._group_by_instruction(filtered_changes)

        # Helper to render instruction group
        def render_group(instructions: list[str], title: str, default_color: str) -> None:
            group_changes = []
            for inst in instructions:
                if inst in instruction_changes:
                    group_changes.extend(instruction_changes[inst])

            if not group_changes:
                return

            # Group by risk
            breaking = [c for c in group_changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
            risky = [c for c in group_changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
            safe = [c for c in group_changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

            if breaking:
                ctx.console.print(f"[bold red][X] {title} (Breaking)[/bold red]")
                self._render_instruction_changes(ctx, breaking, "red")

            if risky and not ctx.breaking_only:
                ctx.console.print(f"[bold yellow][!] {title}[/bold yellow]")
                self._render_instruction_changes(ctx, risky, "yellow")

            if safe and ctx.show_safe and not ctx.breaking_only:
                ctx.console.print(f"[bold green][o] {title}[/bold green]")
                self._render_instruction_changes(ctx, safe, "green")

        # Base image changes
        render_group(["FROM"], "Base Image Changes", "red")

        # Environment changes
        render_group(["ENV", "ARG"], "Environment Variable Changes", "yellow")

        # Exposed ports
        render_group(["EXPOSE"], "Exposed Port Changes", "yellow")

        # Entrypoint/CMD changes
        render_group(["ENTRYPOINT", "CMD"], "Entrypoint/Command Changes", "yellow")

        # Health check
        render_group(["HEALTHCHECK"], "Health Check Changes", "cyan")

        # Build steps
        render_group(["RUN", "COPY", "ADD", "WORKDIR"], "Build Step Changes", "cyan")

        # Other changes
        other_keys = set(instruction_changes.keys()) - {
            "FROM", "ENV", "ARG", "EXPOSE", "ENTRYPOINT", "CMD",
            "RUN", "COPY", "ADD", "WORKDIR", "HEALTHCHECK",
        }
        if other_keys:
            other_changes = []
            for key in other_keys:
                other_changes.extend(instruction_changes[key])
            if other_changes and not ctx.breaking_only:
                ctx.console.print("[bold dim]Other Changes[/bold dim]")
                self._render_instruction_changes(ctx, other_changes, "dim")

    def _render_docker_overview(self, ctx: RenderContext) -> None:
        """Render overview of Docker changes."""
        meta_a = ctx.obj_a.metadata
        meta_b = ctx.obj_b.metadata
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]Docker Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Property", style="bold white")
        table.add_column("Before", max_width=30, style="yellow")
        table.add_column("After", max_width=30, style="green")

        # Base image
        base_a = meta_a.get("base_image", struct_a.get("base_images", ["?"])[0] if struct_a.get("base_images") else "?")
        base_b = meta_b.get("base_image", struct_b.get("base_images", ["?"])[0] if struct_b.get("base_images") else "?")
        if isinstance(base_a, list):
            base_a = base_a[0] if base_a else "?"
        if isinstance(base_b, list):
            base_b = base_b[0] if base_b else "?"

        base_style_a = "red" if base_a != base_b else "yellow"
        base_style_b = "green" if base_a != base_b else "green"
        table.add_row(
            "Base Image",
            f"[{base_style_a}]{base_a}[/{base_style_a}]",
            f"[{base_style_b}]{base_b}[/{base_style_b}]",
        )

        # Multi-stage
        stages_a = struct_a.get("stages", 1)
        stages_b = struct_b.get("stages", 1)
        if stages_a > 1 or stages_b > 1:
            table.add_row("Stages", str(stages_a), str(stages_b))

        # Instruction count
        inst_a = struct_a.get("instruction_count", "?")
        inst_b = struct_b.get("instruction_count", "?")
        table.add_row("Instructions", str(inst_a), str(inst_b))

        # Exposed ports
        ports_a = meta_a.get("exposed_ports", struct_a.get("exposed_ports", []))
        ports_b = meta_b.get("exposed_ports", struct_b.get("exposed_ports", []))
        if ports_a or ports_b:
            table.add_row(
                "Ports",
                ", ".join(map(str, ports_a)) if ports_a else "-",
                ", ".join(map(str, ports_b)) if ports_b else "-",
            )

        ctx.console.print(table)
        ctx.console.print()

    def _group_by_instruction(self, changes: list[Change]) -> dict[str, list[Change]]:
        """Group changes by Docker instruction type."""
        grouped: dict[str, list[Change]] = {}

        for change in changes:
            instruction = self._get_instruction_type(change)
            grouped.setdefault(instruction, []).append(change)

        return grouped

    def _get_instruction_type(self, change: Change) -> str:
        """Get the Docker instruction type from a change."""
        path = change.path.upper()

        instructions = [
            "FROM", "RUN", "CMD", "LABEL", "EXPOSE", "ENV",
            "ADD", "COPY", "ENTRYPOINT", "VOLUME", "USER",
            "WORKDIR", "ARG", "ONBUILD", "STOPSIGNAL", "HEALTHCHECK", "SHELL",
        ]

        for inst in instructions:
            if inst in path:
                return inst

        for entity in [change.new_entity, change.old_entity]:
            if entity and isinstance(entity.value, dict):
                if "instruction" in entity.value:
                    return entity.value["instruction"].upper()

        return "OTHER"

    def _render_instruction_changes(
        self, ctx: RenderContext, changes: list[Change], color: str
    ) -> None:
        """Render changes for a specific instruction type."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("", width=3)
        table.add_column("Instruction", style="cyan", max_width=12)
        table.add_column("Before", max_width=35)
        table.add_column("After", max_width=35)

        for change in changes[:10]:
            symbol, sym_color = self.format_change_type(change.change_type)
            instruction = self._get_instruction_type(change)

            old_val = self._format_instruction_value(change.old_value)
            new_val = self._format_instruction_value(change.new_value)

            table.add_row(
                f"[{sym_color}]{symbol}[/{sym_color}]",
                instruction,
                f"[red dim]{old_val}[/red dim]" if old_val else "[dim]-[/dim]",
                f"[green]{new_val}[/green]" if new_val else "[dim]-[/dim]",
            )

            if ctx.verbose:
                self.render_verbose_info(ctx, change)

        if len(changes) > 10:
            table.add_row("", f"[dim]+{len(changes) - 10} more[/dim]", "", "")

        ctx.console.print(table)
        ctx.console.print()

    def _format_instruction_value(self, value: Any) -> str:
        """Format an instruction value for display."""
        if value is None:
            return ""
        if isinstance(value, str):
            if len(value) > 35:
                return value[:32] + "..."
            return value
        if isinstance(value, dict):
            if "args" in value:
                args = value["args"]
                if len(args) > 35:
                    return args[:32] + "..."
                return args
            if "text" in value:
                text = value["text"]
                if len(text) > 35:
                    return text[:32] + "..."
                return text
        return str(value)[:35]

    def _render_compose_changes(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render docker-compose specific changes."""
        # Group by service/resource
        services = {}
        volumes = {}
        networks = {}
        other = []

        for change in filtered_changes:
            path = change.path.lower()
            if path.startswith("services/"):
                service = change.path.split("/")[1]
                services.setdefault(service, []).append(change)
            elif path.startswith("volumes/"):
                vol = change.path.split("/")[1]
                volumes.setdefault(vol, []).append(change)
            elif path.startswith("networks/"):
                net = change.path.split("/")[1]
                networks.setdefault(net, []).append(change)
            else:
                other.append(change)

        # Render services
        if services:
            ctx.console.print(Panel("[bold]Service Changes[/bold]", border_style="cyan", padding=(0, 2)))
            ctx.console.print()
            self._render_service_changes(ctx, services)

        # Render volumes
        if volumes:
            ctx.console.print(Panel("[bold]Volume Changes[/bold]", border_style="yellow", padding=(0, 2)))
            ctx.console.print()
            self._render_resource_changes(ctx, volumes, "volume")

        # Render networks
        if networks:
            ctx.console.print(Panel("[bold]Network Changes[/bold]", border_style="blue", padding=(0, 2)))
            ctx.console.print()
            self._render_resource_changes(ctx, networks, "network")

    def _render_service_changes(
        self, ctx: RenderContext, services: dict[str, list[Change]]
    ) -> None:
        """Render service-level changes."""
        for service_name, changes in sorted(services.items()):
            # Determine service status
            all_added = all(c.change_type == ChangeType.ADDED for c in changes)
            all_removed = all(c.change_type == ChangeType.REMOVED for c in changes)

            # Get overall risk
            risks = [ctx.get_change_risk(c) for c in changes]
            has_breaking = any(r == RiskLevel.BREAKING for r in risks)
            has_risky = any(r == RiskLevel.RISKY for r in risks)

            if all_added:
                header = f"[green]+ {service_name}[/green] (new service)"
                color = "green"
            elif all_removed:
                header = f"[red]- {service_name}[/red] (removed)"
                color = "red"
            elif has_breaking:
                header = f"[red][X] {service_name}[/red]"
                color = "red"
            elif has_risky:
                header = f"[yellow][!] {service_name}[/yellow]"
                color = "yellow"
            else:
                header = f"[cyan]~ {service_name}[/cyan]"
                color = "cyan"

            # Build change list
            content = Text()
            for change in changes[:8]:
                symbol, sym_color = self.format_change_type(change.change_type)
                parts = change.path.split("/")
                prop = parts[-1] if len(parts) > 2 else parts[-1]

                content.append(f"  {symbol} ", style=sym_color)
                content.append(f"{prop}", style=sym_color)

                if change.change_type == ChangeType.MODIFIED:
                    old_val = self.format_value(change.old_value, 15)
                    new_val = self.format_value(change.new_value, 15)
                    content.append(f": {old_val} -> {new_val}", style="dim")
                elif change.new_value is not None:
                    new_val = self.format_value(change.new_value, 25)
                    content.append(f": {new_val}", style="dim")
                content.append("\n")

            if len(changes) > 8:
                content.append(f"  ... +{len(changes) - 8} more changes", style="dim")

            ctx.console.print(Panel(content, title=header, border_style=color))
            ctx.console.print()

    def _render_resource_changes(
        self, ctx: RenderContext, resources: dict[str, list[Change]], resource_type: str
    ) -> None:
        """Render volume/network changes."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("", width=3)
        table.add_column(resource_type.title(), style="cyan")
        table.add_column("Change", max_width=40)

        for name, changes in sorted(resources.items()):
            for change in changes:
                symbol, color = self.format_change_type(change.change_type)
                desc = change.change_type.name.lower()
                table.add_row(f"[{color}]{symbol}[/{color}]", name, desc)

        ctx.console.print(table)
        ctx.console.print()
