"""Base class for format-specific renderers."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich import box

from what_changed.normalize.base import NormalizedObject, Entity, EntityType
from what_changed.diff.semantic_diff import DiffResult, Change, ChangeType
from what_changed.graph.model import ChangeGraph, RiskLevel


@dataclass
class RenderContext:
    """Context passed to format-specific renderers."""

    console: Console
    obj_a: NormalizedObject
    obj_b: NormalizedObject
    diff_result: DiffResult
    graph: ChangeGraph
    verbose: bool = False
    color: bool = True
    breaking_only: bool = False
    show_safe: bool = True
    rule_results: dict = None  # Map of node IDs to rule match results

    def _find_node_for_change(self, change: Change):
        """Find the graph node corresponding to a change."""
        # Try direct lookup
        node = self.graph.get_node(f"change_{change.path}")
        if node:
            return node

        node = self.graph.get_node(change.path)
        if node:
            return node

        # Search through nodes by path
        for n in self.graph.get_nodes():
            if n.path == change.path:
                return n
            if n.change and n.change.path == change.path:
                return n

        return None

    def filter_changes(self, changes: list[Change]) -> list[Change]:
        """Filter changes based on breaking_only and show_safe settings."""
        if not changes:
            return changes

        filtered = []
        for change in changes:
            node = self._find_node_for_change(change)
            if not node:
                # No node found, include by default unless breaking_only
                if not self.breaking_only:
                    filtered.append(change)
                continue

            risk = node.risk_level
            if self.breaking_only:
                if risk == RiskLevel.BREAKING:
                    filtered.append(change)
            elif not self.show_safe:
                if risk in (RiskLevel.BREAKING, RiskLevel.RISKY):
                    filtered.append(change)
            else:
                filtered.append(change)

        return filtered

    def get_change_risk(self, change: Change) -> RiskLevel:
        """Get risk level for a change."""
        node = self._find_node_for_change(change)
        if node:
            return node.risk_level
        return RiskLevel.SAFE


class FormatRenderer(ABC):
    """Base class for format-specific renderers."""

    # Format types this renderer handles
    @property
    @abstractmethod
    def supported_types(self) -> list[str]:
        """List of format type strings this renderer handles."""
        ...

    @abstractmethod
    def render(self, ctx: RenderContext) -> None:
        """
        Render the comparison for this format type.

        Args:
            ctx: The render context containing all data
        """
        ...

    def can_handle(self, format_type: str) -> bool:
        """Check if this renderer can handle the given format type."""
        return format_type.lower() in [t.lower() for t in self.supported_types]

    # Common utilities for all renderers

    def render_header(self, ctx: RenderContext, title: str) -> None:
        """Render the comparison header."""
        ctx.console.print()
        header = Text()
        header.append(f"{title}\n", style="bold cyan")
        header.append(f"  A: ", style="dim")
        header.append(str(ctx.diff_result.source_a), style="yellow")
        header.append(f"\n  B: ", style="dim")
        header.append(str(ctx.diff_result.source_b), style="green")

        ctx.console.print(Panel(header, border_style="cyan"))
        ctx.console.print()

    def render_change_summary(self, ctx: RenderContext) -> None:
        """Render a quick summary of changes."""
        breaking = len(ctx.graph.get_breaking_changes())
        risky = len(ctx.graph.get_risky_changes())
        safe = len(ctx.graph.get_safe_changes())

        summary = Text()
        if breaking > 0:
            summary.append(f"[X] {breaking} breaking  ", style="bold red")
        if risky > 0:
            summary.append(f"[!] {risky} risky  ", style="bold yellow")
        if safe > 0:
            summary.append(f"[o] {safe} safe", style="bold green")

        if breaking == 0 and risky == 0 and safe == 0:
            summary.append("No changes detected", style="dim")

        ctx.console.print(summary)
        ctx.console.print()

    def format_change_type(self, change_type: ChangeType) -> tuple[str, str]:
        """Get symbol and color for a change type."""
        mapping = {
            ChangeType.ADDED: ("+", "green"),
            ChangeType.REMOVED: ("-", "red"),
            ChangeType.MODIFIED: ("~", "yellow"),
            ChangeType.RENAMED: (">", "cyan"),
            ChangeType.TYPE_CHANGED: ("!", "magenta"),
            ChangeType.MOVED: ("^", "blue"),
            ChangeType.UNCHANGED: (" ", "dim"),
        }
        return mapping.get(change_type, ("?", "white"))

    def format_risk_level(self, risk_level: RiskLevel) -> tuple[str, str]:
        """Get symbol and color for a risk level."""
        mapping = {
            RiskLevel.BREAKING: ("[X]", "red"),
            RiskLevel.RISKY: ("[!]", "yellow"),
            RiskLevel.SAFE: ("[o]", "green"),
        }
        return mapping.get(risk_level, ("?", "white"))

    def format_value(self, value: Any, max_len: int = 40) -> str:
        """Format a value for display, truncating if necessary."""
        if value is None:
            return "(none)"
        if isinstance(value, dict):
            return f"{{...{len(value)} keys}}"
        if isinstance(value, list):
            return f"[...{len(value)} items]"
        s = str(value)
        if len(s) > max_len:
            return s[: max_len - 3] + "..."
        return s

    def create_change_table(self, columns: list[str]) -> Table:
        """Create a styled table for showing changes."""
        table = Table(
            box=box.SIMPLE,
            show_header=True,
            header_style="bold dim",
            padding=(0, 1),
        )
        for col in columns:
            table.add_column(col)
        return table

    def render_verbose_info(self, ctx: RenderContext, change: Change) -> None:
        """Render verbose information for a change (rule matches, etc.)."""
        if not ctx.verbose:
            return

        node = ctx._find_node_for_change(change)
        if not node:
            return

        # Show rule matches if available
        if ctx.rule_results and node.id in ctx.rule_results:
            results = ctx.rule_results[node.id]
            if results:
                ctx.console.print("  [dim]Matched rules:[/dim]")
                for result in results:
                    ctx.console.print(f"    [dim]- {result.rule_name}: {result.reason} (score: {result.score})[/dim]")

        # Show score
        if node.risk_score > 0:
            ctx.console.print(f"  [dim]Risk score: {node.risk_score}[/dim]")


class FormatRendererRegistry:
    """Registry for format-specific renderers."""

    def __init__(self) -> None:
        self._renderers: list[FormatRenderer] = []

    def register(self, renderer: FormatRenderer) -> None:
        """Register a format renderer."""
        self._renderers.append(renderer)

    def get_renderer(self, format_type: str) -> Optional[FormatRenderer]:
        """Get the appropriate renderer for a format type."""
        for renderer in self._renderers:
            if renderer.can_handle(format_type):
                return renderer
        return None

    def get_all_supported_types(self) -> list[str]:
        """Get all supported format types."""
        types = []
        for renderer in self._renderers:
            types.extend(renderer.supported_types)
        return types
