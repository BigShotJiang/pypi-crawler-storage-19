"""Document renderer (PDF, Markdown, Text documents)."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich.columns import Columns
from rich.syntax import Syntax
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class DocumentRenderer(FormatRenderer):
    """
    Renderer for document files (PDF, Markdown).

    Displays document changes with:
    - Page/section-by-page comparison
    - Word count changes
    - Structure/outline changes
    - Content diffs where available
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["pdf", "markdown", "md"]

    def render(self, ctx: RenderContext) -> None:
        """Render document comparison."""
        doc_type = ctx.obj_a.type.upper()
        self.render_header(ctx, f"{doc_type} Document Comparison")
        self.render_change_summary(ctx)

        # Filter changes based on context settings
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in document[/green]\n")
            return

        # Render document overview comparison
        self._render_overview(ctx)

        # Render structure/outline changes
        self._render_structure_changes(ctx, filtered_changes)

        # Render content changes
        self._render_content_changes(ctx, filtered_changes)

    def _render_overview(self, ctx: RenderContext) -> None:
        """Render side-by-side document overview."""
        meta_a = ctx.obj_a.metadata
        meta_b = ctx.obj_b.metadata
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        # Create comparison table
        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]Document Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Metric", style="bold white")
        table.add_column("Before", justify="right", style="yellow")
        table.add_column("After", justify="right", style="green")
        table.add_column("Change", justify="center")

        # Common metrics to compare
        metrics = [
            ("📄 Pages", "page_count", struct_a, struct_b),
            ("📝 Words", "word_count", meta_a, meta_b),
            ("🔤 Characters", "char_count", meta_a, meta_b),
            ("📑 Sections", "section_count", struct_a, struct_b),
            ("🔗 Links", "link_count", meta_a, meta_b),
            ("🖼️ Images", "image_count", meta_a, meta_b),
            ("💻 Code Blocks", "code_block_count", meta_a, meta_b),
        ]

        has_metrics = False
        for label, key, dict_a, dict_b in metrics:
            val_a = dict_a.get(key) or dict_a.get(f"total_{key}")
            val_b = dict_b.get(key) or dict_b.get(f"total_{key}")

            if val_a is not None or val_b is not None:
                has_metrics = True
                val_a = val_a or 0
                val_b = val_b or 0
                diff = val_b - val_a

                if diff > 0:
                    change_text = f"[green bold]+{diff}[/green bold]"
                elif diff < 0:
                    change_text = f"[red bold]{diff}[/red bold]"
                else:
                    change_text = "[dim]=[/dim]"

                # Use simpler label without emoji for Windows
                simple_label = label.split(" ", 1)[-1] if " " in label else label
                table.add_row(simple_label, str(val_a), str(val_b), change_text)

        if has_metrics:
            ctx.console.print(table)
            ctx.console.print()

    def _render_structure_changes(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render document structure/outline changes."""
        # Find section/page changes from filtered list
        section_changes = [
            c
            for c in filtered_changes
            if c.entity_type in {EntityType.SECTION, EntityType.PAGE}
        ]

        if not section_changes:
            return

        # Create a visual header
        ctx.console.print(Panel(
            "[bold]Document Structure Changes[/bold]",
            border_style="cyan",
            padding=(0, 2),
        ))
        ctx.console.print()

        # Group by type
        pages = [c for c in section_changes if c.entity_type == EntityType.PAGE]
        sections = [c for c in section_changes if c.entity_type == EntityType.SECTION]

        if pages:
            self._render_page_changes(ctx, pages)

        if sections:
            self._render_section_changes(ctx, sections)

    def _render_page_changes(self, ctx: RenderContext, pages: list[Change]) -> None:
        """Render page-level changes with improved GUI."""
        # Group pages by risk level
        breaking = []
        risky = []
        safe = []

        for change in pages:
            risk = ctx.get_change_risk(change)
            if risk == RiskLevel.BREAKING:
                breaking.append(change)
            elif risk == RiskLevel.RISKY:
                risky.append(change)
            else:
                safe.append(change)

        # Render each group
        if breaking:
            self._render_page_table(ctx, breaking, "[X] Breaking Page Changes", "red")

        if risky and not ctx.breaking_only:
            self._render_page_table(ctx, risky, "[!] Risky Page Changes", "yellow")

        if safe and ctx.show_safe and not ctx.breaking_only:
            self._render_page_table(ctx, safe, "[o] Safe Page Changes", "green")

    def _render_page_table(self, ctx: RenderContext, pages: list[Change], title: str, color: str) -> None:
        """Render a table of page changes."""
        ctx.console.print(f"[bold {color}]{title}[/bold {color}]")

        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("Page", justify="center", width=8)
        table.add_column("Change", width=12)
        table.add_column("Words", justify="right", width=14)
        table.add_column("Details", max_width=40)

        for change in pages[:20]:  # Limit to first 20
            symbol, sym_color = self.format_change_type(change.change_type)

            # Extract page info
            page_num = self._get_page_number(change)
            word_change = self._get_word_change(change)
            details = self._get_change_details(change)

            table.add_row(
                f"[{sym_color}]{page_num}[/{sym_color}]",
                f"[{sym_color}]{symbol} {change.change_type.name[:8]}[/{sym_color}]",
                word_change or "[dim]-[/dim]",
                details or "[dim]-[/dim]",
            )

            # Show verbose info
            if ctx.verbose:
                self.render_verbose_info(ctx, change)

        if len(pages) > 20:
            table.add_row(
                "[dim]...[/dim]",
                f"[dim]+{len(pages) - 20} more[/dim]",
                "",
                "",
            )

        ctx.console.print(table)
        ctx.console.print()

    def _render_section_changes(
        self, ctx: RenderContext, sections: list[Change]
    ) -> None:
        """Render section/heading changes as outline."""
        # Group by risk
        breaking = [c for c in sections if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in sections if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in sections if ctx.get_change_risk(c) == RiskLevel.SAFE]

        def render_tree(changes: list[Change], title: str, color: str) -> None:
            tree = Tree(f"[bold {color}]{title}[/bold {color}]")

            for change in changes:
                symbol, sym_color = self.format_change_type(change.change_type)

                # Get section info
                section_name = change.path.split("/")[-1] if "/" in change.path else change.path
                level = self._get_section_level(change)

                label = Text()
                label.append(f"{symbol} ", style=sym_color)
                label.append(section_name, style=f"bold {sym_color}")

                if level:
                    label.append(f" (h{level})", style="dim")

                if change.change_type == ChangeType.MODIFIED:
                    word_change = self._get_word_change(change)
                    if word_change:
                        label.append(f" {word_change}", style="dim")

                tree.add(label)

            ctx.console.print(Panel(tree, border_style=color))
            ctx.console.print()

        if breaking:
            render_tree(breaking, "[X] Breaking Section Changes", "red")

        if risky and not ctx.breaking_only:
            render_tree(risky, "[!] Risky Section Changes", "yellow")

        if safe and ctx.show_safe and not ctx.breaking_only:
            render_tree(safe, "[o] Safe Section Changes", "green")

    def _render_content_changes(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render actual content diffs."""
        # Find changes with content diffs
        content_changes = [
            c for c in filtered_changes if c.content_diff and c.content_diff.has_changes
        ]

        # Find added pages/sections that don't have diffs but have content
        added_pages = [
            c for c in filtered_changes
            if c.change_type == ChangeType.ADDED
            and c.entity_type in {EntityType.PAGE, EntityType.SECTION}
            and c not in content_changes
        ]

        if not content_changes and not added_pages:
            return

        ctx.console.print(Panel(
            "[bold]Content Diff[/bold]",
            border_style="cyan",
            padding=(0, 2),
        ))
        ctx.console.print()

        # Show summary first
        total_added = sum(c.content_diff.lines_added for c in content_changes)
        total_removed = sum(c.content_diff.lines_removed for c in content_changes)

        summary = Text()
        summary.append(f"+{total_added} lines added  ", style="bold green")
        summary.append(f"-{total_removed} lines removed", style="bold red")
        if added_pages:
            summary.append(f"  +{len(added_pages)} new pages/sections", style="bold cyan")
        ctx.console.print(Panel(summary, border_style="dim"))
        ctx.console.print()

        for change in content_changes[:5]:  # Show first 5 content diffs
            self._render_content_diff(ctx, change)

        # Show added pages content
        for change in added_pages[:3]:  # Show first 3 added pages
            self._render_added_page(ctx, change)

        remaining = len(content_changes) - 5 + len(added_pages) - 3
        if remaining > 0:
            ctx.console.print(
                f"[dim]... and {remaining} more content changes[/dim]"
            )
            ctx.console.print()

    def _render_added_page(self, ctx: RenderContext, change: Change) -> None:
        """Render content of a newly added page/section."""
        # Try to get text content from the new entity
        text_content = ""
        word_count = 0

        if change.new_entity:
            value = change.new_entity.value
            if isinstance(value, dict):
                text_content = value.get("text", "")
                word_count = value.get("word_count", len(text_content.split()))
            elif isinstance(value, str):
                text_content = value
                word_count = len(text_content.split())

        if not text_content:
            return

        # Truncate if too long
        lines = text_content.split("\n")
        max_lines = 20

        display_lines = []
        for line in lines[:max_lines]:
            line = line.strip()
            if len(line) > 100:
                line = line[:97] + "..."
            display_lines.append(f"[green]+{line}[/green]")

        if len(lines) > max_lines:
            display_lines.append(f"[dim]... +{len(lines) - max_lines} more lines[/dim]")

        path_display = change.path
        if len(path_display) > 50:
            path_display = "..." + path_display[-47:]

        ctx.console.print(
            Panel(
                "\n".join(display_lines),
                title=f"[green]+ {path_display}[/green] (NEW)",
                subtitle=f"[green]+{word_count} words[/green]",
                border_style="green",
            )
        )

        # Verbose output
        if ctx.verbose:
            self.render_verbose_info(ctx, change)

        ctx.console.print()

    def _render_content_diff(self, ctx: RenderContext, change: Change) -> None:
        """Render a single content diff with improved styling."""
        diff = change.content_diff
        if not diff:
            return

        # Build diff display
        lines = []
        line_count = 0
        max_lines = 30

        for hunk in diff.hunks:
            lines.append(f"[cyan bold]{hunk.header}[/cyan bold]")
            line_count += 1

            for line in hunk.lines:
                if line_count >= max_lines:
                    remaining = diff.lines_added + diff.lines_removed - line_count
                    lines.append(
                        f"[dim]... {remaining} more lines ({diff.lines_added} added, {diff.lines_removed} removed total)[/dim]"
                    )
                    break

                from what_changed.diff.content_diff import LineChangeType

                content = line.content
                # Truncate very long lines
                if len(content) > 100:
                    content = content[:97] + "..."

                if line.line_type == LineChangeType.ADDED:
                    lines.append(f"[green]+{content}[/green]")
                elif line.line_type == LineChangeType.REMOVED:
                    lines.append(f"[red]-{content}[/red]")
                else:
                    lines.append(f"[dim] {content}[/dim]")

                line_count += 1

            if line_count >= max_lines:
                break

        path_display = change.path
        if len(path_display) > 50:
            path_display = "..." + path_display[-47:]

        # Get risk level for border color
        risk = ctx.get_change_risk(change)
        risk_symbol, risk_color = self.format_risk_level(risk)

        ctx.console.print(
            Panel(
                "\n".join(lines),
                title=f"[cyan]{path_display}[/cyan] {risk_symbol}",
                subtitle=f"[green]+{diff.lines_added}[/green] [red]-{diff.lines_removed}[/red]",
                border_style=risk_color,
            )
        )

        # Verbose output
        if ctx.verbose:
            self.render_verbose_info(ctx, change)

        ctx.console.print()

    def _get_page_number(self, change: Change) -> str:
        """Extract page number from change."""
        # Try metadata first
        if change.new_entity and change.new_entity.metadata.get("page_number"):
            return str(change.new_entity.metadata["page_number"])
        if change.old_entity and change.old_entity.metadata.get("page_number"):
            return str(change.old_entity.metadata["page_number"])

        # Try to extract from path
        path = change.path
        if "page_" in path:
            try:
                return path.split("page_")[1].split("/")[0]
            except (IndexError, ValueError):
                pass

        return "?"

    def _get_word_change(self, change: Change) -> str:
        """Get word count change as a formatted string."""
        old_words = 0
        new_words = 0

        if change.old_entity:
            old_words = change.old_entity.metadata.get("word_count", 0)
            if isinstance(change.old_value, dict):
                old_words = change.old_value.get("word_count", old_words)

        if change.new_entity:
            new_words = change.new_entity.metadata.get("word_count", 0)
            if isinstance(change.new_value, dict):
                new_words = change.new_value.get("word_count", new_words)

        diff = new_words - old_words
        if diff > 0:
            return f"[green]+{diff} words[/green]"
        elif diff < 0:
            return f"[red]{diff} words[/red]"
        return ""

    def _get_section_level(self, change: Change) -> Optional[int]:
        """Get section heading level."""
        if change.new_entity:
            return change.new_entity.metadata.get("level")
        if change.old_entity:
            return change.old_entity.metadata.get("level")
        return None

    def _get_change_details(self, change: Change) -> str:
        """Get brief details about the change."""
        if change.change_type == ChangeType.MODIFIED:
            if change.content_diff:
                return f"+{change.content_diff.lines_added}/-{change.content_diff.lines_removed} lines"
            return "Content modified"
        elif change.change_type == ChangeType.ADDED:
            return "New page/section"
        elif change.change_type == ChangeType.REMOVED:
            return "Removed"
        return ""
