"""Plain text file renderer."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.columns import Columns
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class TextRenderer(FormatRenderer):
    """
    Renderer for plain text and log files.

    Displays text changes with:
    - Git-style unified diff
    - Line count statistics
    - Highlighted additions/removals
    - Context around changes
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["text", "txt", "log", "rst", "plain"]

    def render(self, ctx: RenderContext) -> None:
        """Render text file comparison."""
        self.render_header(ctx, "Text File Comparison")
        self.render_change_summary(ctx)

        # Filter changes based on context settings
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in text file[/green]\n")
            return

        # Text overview
        self._render_text_overview(ctx, filtered_changes)

        # Show diff
        self._render_text_diff(ctx, filtered_changes)

    def _render_text_overview(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render text file overview with improved styling."""
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        # Overview table
        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]Text File Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Metric", style="bold white")
        table.add_column("Before", justify="right", style="yellow")
        table.add_column("After", justify="right", style="green")
        table.add_column("Change", justify="center")

        metrics = [
            ("Lines", "total_lines"),
            ("Characters", "total_chars"),
            ("Blank Lines", "blank_lines"),
        ]

        for label, key in metrics:
            val_a = struct_a.get(key, 0)
            val_b = struct_b.get(key, 0)

            diff = val_b - val_a
            if diff > 0:
                change_str = f"[green bold]+{diff}[/green bold]"
            elif diff < 0:
                change_str = f"[red bold]{diff}[/red bold]"
            else:
                change_str = "[dim]=[/dim]"

            table.add_row(label, str(val_a), str(val_b), change_str)

        # Calculate additions/removals from filtered changes
        total_added = sum(c.metadata.get("lines_added", 0) for c in filtered_changes)
        total_removed = sum(c.metadata.get("lines_removed", 0) for c in filtered_changes)

        if total_added or total_removed:
            table.add_row("", "", "", "")
            table.add_row(
                "[green]+ Added[/green]",
                "",
                "",
                f"[green bold]+{total_added} lines[/green bold]",
            )
            table.add_row(
                "[red]- Removed[/red]",
                "",
                "",
                f"[red bold]-{total_removed} lines[/red bold]",
            )

        ctx.console.print(table)
        ctx.console.print()

    def _render_text_diff(self, ctx: RenderContext, filtered_changes: list[Change]) -> None:
        """Render git-style text diff with improved GUI."""
        # Find changes with content diffs
        content_changes = [
            c for c in filtered_changes if c.content_diff and c.content_diff.has_changes
        ]

        if not content_changes:
            # Try to show line-based changes
            line_changes = [c for c in filtered_changes if c.entity_type == EntityType.LINE]
            if line_changes:
                self._render_line_changes(ctx, line_changes)
            elif filtered_changes:
                # Generic change display
                self._render_generic_changes(ctx, filtered_changes)
            else:
                ctx.console.print("[dim]No detailed diff available[/dim]")
            return

        # Show header panel
        ctx.console.print(Panel(
            "[bold]Unified Diff[/bold]",
            border_style="cyan",
            padding=(0, 2),
        ))
        ctx.console.print()

        # Show summary
        total_added = sum(c.content_diff.lines_added for c in content_changes)
        total_removed = sum(c.content_diff.lines_removed for c in content_changes)

        summary = Text()
        summary.append(f"+{total_added} lines added  ", style="bold green")
        summary.append(f"-{total_removed} lines removed", style="bold red")
        ctx.console.print(Panel(summary, border_style="dim"))
        ctx.console.print()

        for change in content_changes:
            self._render_content_diff(ctx, change)

    def _render_line_changes(
        self, ctx: RenderContext, changes: list[Change]
    ) -> None:
        """Render line-by-line changes with risk grouping."""
        ctx.console.print(Panel(
            "[bold]Line Changes[/bold]",
            border_style="cyan",
            padding=(0, 2),
        ))
        ctx.console.print()

        # Group by change type
        added = [c for c in changes if c.change_type == ChangeType.ADDED]
        removed = [c for c in changes if c.change_type == ChangeType.REMOVED]
        modified = [c for c in changes if c.change_type == ChangeType.MODIFIED]

        # Show summary
        summary = Text()
        if added:
            summary.append(f"+{len(added)} added  ", style="bold green")
        if removed:
            summary.append(f"-{len(removed)} removed  ", style="bold red")
        if modified:
            summary.append(f"~{len(modified)} modified", style="bold yellow")

        ctx.console.print(Panel(summary, border_style="dim"))
        ctx.console.print()

        # Group by risk level
        breaking = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        # Render each group
        if breaking:
            self._render_line_group(ctx, breaking, "[X] Breaking Changes", "red")

        if risky and not ctx.breaking_only:
            self._render_line_group(ctx, risky, "[!] Risky Changes", "yellow")

        if safe and ctx.show_safe and not ctx.breaking_only:
            self._render_line_group(ctx, safe, "[o] Safe Changes", "green")

    def _render_line_group(
        self, ctx: RenderContext, changes: list[Change], title: str, color: str
    ) -> None:
        """Render a group of line changes."""
        ctx.console.print(f"[bold {color}]{title}[/bold {color}]")

        lines = []
        max_lines = 30

        for change in changes[:max_lines]:
            symbol, sym_color = self.format_change_type(change.change_type)
            line_num = change.metadata.get("line_number", "?")

            if change.change_type == ChangeType.MODIFIED:
                old_content = self._get_line_content(change.old_value)
                new_content = self._get_line_content(change.new_value)
                lines.append(f"[red]-{line_num:4}| {old_content}[/red]")
                lines.append(f"[green]+{line_num:4}| {new_content}[/green]")
            elif change.change_type == ChangeType.REMOVED:
                content = self._get_line_content(change.old_value)
                lines.append(f"[{sym_color}]{symbol}{line_num:4}| {content}[/{sym_color}]")
            else:
                content = self._get_line_content(change.new_value)
                lines.append(f"[{sym_color}]{symbol}{line_num:4}| {content}[/{sym_color}]")

        if len(changes) > max_lines:
            lines.append(f"[dim]... and {len(changes) - max_lines} more changes[/dim]")

        ctx.console.print(Panel("\n".join(lines), border_style=color))
        ctx.console.print()

    def _render_generic_changes(self, ctx: RenderContext, changes: list[Change]) -> None:
        """Render generic changes when no detailed diff is available."""
        ctx.console.print(Panel(
            "[bold]Changes Detected[/bold]",
            border_style="cyan",
            padding=(0, 2),
        ))
        ctx.console.print()

        # Group by risk
        breaking = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        def render_group(changes: list[Change], title: str, color: str) -> None:
            if not changes:
                return
            ctx.console.print(f"[bold {color}]{title}[/bold {color}]")
            table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
            table.add_column("", width=3)
            table.add_column("Path", style="cyan", max_width=40)
            table.add_column("Change", max_width=30)

            for change in changes[:10]:
                symbol, sym_color = self.format_change_type(change.change_type)
                desc = change.change_type.name
                table.add_row(
                    f"[{sym_color}]{symbol}[/{sym_color}]",
                    change.path,
                    desc,
                )

            if len(changes) > 10:
                table.add_row("", f"[dim]+{len(changes) - 10} more[/dim]", "")

            ctx.console.print(table)
            ctx.console.print()

        if breaking:
            render_group(breaking, "[X] Breaking Changes", "red")
        if risky and not ctx.breaking_only:
            render_group(risky, "[!] Risky Changes", "yellow")
        if safe and ctx.show_safe and not ctx.breaking_only:
            render_group(safe, "[o] Safe Changes", "green")

    def _render_content_diff(self, ctx: RenderContext, change: Change) -> None:
        """Render a unified diff for a change with improved styling."""
        diff = change.content_diff
        if not diff:
            return

        lines = []
        line_count = 0
        max_lines = 100

        # Header
        lines.append(f"[dim]--- a/{change.path}[/dim]")
        lines.append(f"[dim]+++ b/{change.path}[/dim]")

        for hunk in diff.hunks:
            if line_count >= max_lines:
                break

            lines.append(f"[cyan bold]{hunk.header}[/cyan bold]")
            line_count += 1

            for line in hunk.lines:
                if line_count >= max_lines:
                    lines.append(
                        f"[dim]... ({diff.lines_added} added, {diff.lines_removed} removed total)[/dim]"
                    )
                    break

                from what_changed.diff.content_diff import LineChangeType

                content = line.content
                if len(content) > 100:
                    content = content[:97] + "..."

                if line.line_type == LineChangeType.ADDED:
                    lines.append(f"[green]+{content}[/green]")
                elif line.line_type == LineChangeType.REMOVED:
                    lines.append(f"[red]-{content}[/red]")
                else:
                    lines.append(f"[dim] {content}[/dim]")

                line_count += 1

        # Get risk level for border color
        risk = ctx.get_change_risk(change)
        risk_symbol, risk_color = self.format_risk_level(risk)

        ctx.console.print(Panel(
            "\n".join(lines),
            title=f"[cyan]{change.path}[/cyan] {risk_symbol}",
            subtitle=f"[green]+{diff.lines_added}[/green] [red]-{diff.lines_removed}[/red]",
            border_style=risk_color,
        ))

        # Verbose output
        if ctx.verbose:
            self.render_verbose_info(ctx, change)

        ctx.console.print()

    def _get_line_content(self, value: Any) -> str:
        """Extract line content from value."""
        if value is None:
            return ""
        if isinstance(value, str):
            if len(value) > 80:
                return value[:77] + "..."
            return value
        if isinstance(value, dict):
            line = value.get("line", value.get("content", ""))
            if len(line) > 80:
                return line[:77] + "..."
            return line
        return str(value)[:80]
