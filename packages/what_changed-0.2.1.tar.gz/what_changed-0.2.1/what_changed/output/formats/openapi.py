"""OpenAPI/Swagger specification renderer."""

from typing import Any, Optional

from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.text import Text
from rich import box

from what_changed.output.formats.base import FormatRenderer, RenderContext
from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import RiskLevel


class OpenAPIRenderer(FormatRenderer):
    """
    Renderer for OpenAPI/Swagger specifications.

    Displays API changes with:
    - Endpoint additions/removals
    - Parameter changes
    - Response code changes
    - Schema/model changes
    - Breaking change detection
    - Risk-based filtering
    """

    @property
    def supported_types(self) -> list[str]:
        return ["openapi", "swagger", "api"]

    def render(self, ctx: RenderContext) -> None:
        """Render OpenAPI comparison."""
        self.render_header(ctx, "API Specification Comparison")
        self.render_change_summary(ctx)

        # Filter changes
        filtered_changes = ctx.filter_changes(ctx.diff_result.changes)

        if not filtered_changes and ctx.breaking_only:
            ctx.console.print("[green]No breaking changes detected in API spec[/green]\n")
            return

        # API overview
        self._render_api_overview(ctx)

        # Categorize changes
        endpoint_changes = []
        schema_changes = []
        security_changes = []
        other_changes = []

        for change in filtered_changes:
            path = change.path.lower()
            if "/paths/" in path or change.entity_type == EntityType.ENDPOINT:
                endpoint_changes.append(change)
            elif "/schemas/" in path or "/definitions/" in path:
                schema_changes.append(change)
            elif "/security" in path:
                security_changes.append(change)
            else:
                other_changes.append(change)

        # Render endpoint changes (most important)
        if endpoint_changes:
            self._render_endpoint_changes(ctx, endpoint_changes)

        # Render schema changes
        if schema_changes:
            self._render_schema_changes(ctx, schema_changes)

        # Render security changes
        if security_changes:
            self._render_security_changes(ctx, security_changes)

        # Other changes
        if other_changes and ctx.verbose:
            self._render_other_changes(ctx, other_changes)

    def _render_api_overview(self, ctx: RenderContext) -> None:
        """Render API overview comparison."""
        struct_a = ctx.obj_a.structure
        struct_b = ctx.obj_b.structure

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            header_style="bold cyan",
            title="[bold]API Overview[/bold]",
            title_style="cyan",
            border_style="dim",
        )
        table.add_column("Property", style="bold white")
        table.add_column("Before", style="yellow")
        table.add_column("After", style="green")

        # API title/version
        title_a = struct_a.get("title", "?")
        title_b = struct_b.get("title", "?")
        if title_a != title_b:
            table.add_row("Title", title_a, title_b)

        ver_a = struct_a.get("api_version", "?")
        ver_b = struct_b.get("api_version", "?")
        ver_style_a = "red" if ver_a != ver_b else "yellow"
        ver_style_b = "green" if ver_a != ver_b else "green"
        table.add_row(
            "API Version",
            f"[{ver_style_a}]{ver_a}[/{ver_style_a}]",
            f"[{ver_style_b}]{ver_b}[/{ver_style_b}]",
        )

        # Endpoint counts
        ep_a = struct_a.get("endpoint_count", 0)
        ep_b = struct_b.get("endpoint_count", 0)
        diff = ep_b - ep_a
        diff_str = f" ([green]+{diff}[/green])" if diff > 0 else f" ([red]{diff}[/red])" if diff < 0 else ""
        table.add_row("Endpoints", str(ep_a), f"{ep_b}{diff_str}")

        # Schema counts
        sc_a = struct_a.get("schema_count", 0)
        sc_b = struct_b.get("schema_count", 0)
        diff = sc_b - sc_a
        diff_str = f" ([green]+{diff}[/green])" if diff > 0 else f" ([red]{diff}[/red])" if diff < 0 else ""
        table.add_row("Schemas", str(sc_a), f"{sc_b}{diff_str}")

        ctx.console.print(table)
        ctx.console.print()

    def _render_endpoint_changes(
        self, ctx: RenderContext, changes: list[Change]
    ) -> None:
        """Render endpoint-level changes."""
        ctx.console.print(Panel("[bold]Endpoint Changes[/bold]", border_style="cyan", padding=(0, 2)))
        ctx.console.print()

        # Group by path
        by_path: dict[str, list[Change]] = {}
        for change in changes:
            endpoint_path = self._extract_endpoint_path(change)
            by_path.setdefault(endpoint_path, []).append(change)

        # Categorize by risk level
        breaking_endpoints = []
        risky_endpoints = []
        safe_endpoints = []

        for path, path_changes in by_path.items():
            risks = [ctx.get_change_risk(c) for c in path_changes]
            if any(r == RiskLevel.BREAKING for r in risks):
                breaking_endpoints.append((path, path_changes))
            elif any(r == RiskLevel.RISKY for r in risks):
                risky_endpoints.append((path, path_changes))
            else:
                safe_endpoints.append((path, path_changes))

        # Render each group
        if breaking_endpoints:
            ctx.console.print("[bold red][X] Breaking Endpoint Changes[/bold red]")
            table = self._create_endpoint_table()
            for path, path_changes in breaking_endpoints:
                methods = self._extract_methods(path_changes)
                all_removed = all(c.change_type == ChangeType.REMOVED for c in path_changes)
                status = "REMOVED" if all_removed else "BREAKING"
                table.add_row(
                    "[red]-[/red]" if all_removed else "[red]![/red]",
                    f"[red]{path}[/red]",
                    f"[red]{' '.join(methods)}[/red]",
                    f"[red]{status}[/red]",
                )
            ctx.console.print(table)
            ctx.console.print()

        if risky_endpoints and not ctx.breaking_only:
            ctx.console.print("[bold yellow][!] Risky Endpoint Changes[/bold yellow]")
            for path, path_changes in risky_endpoints:
                self._render_endpoint_detail(ctx, path, path_changes, "yellow")

        if safe_endpoints and ctx.show_safe and not ctx.breaking_only:
            ctx.console.print("[bold green][o] Safe Endpoint Changes[/bold green]")
            table = self._create_endpoint_table()
            for path, path_changes in safe_endpoints:
                methods = self._extract_methods(path_changes)
                all_added = all(c.change_type == ChangeType.ADDED for c in path_changes)
                status = "NEW" if all_added else "MODIFIED"
                table.add_row(
                    "[green]+[/green]" if all_added else "[green]~[/green]",
                    f"[green]{path}[/green]",
                    f"[green]{' '.join(methods)}[/green]",
                    f"[green]{status}[/green]",
                )
            ctx.console.print(table)
            ctx.console.print()

    def _create_endpoint_table(self) -> Table:
        """Create table for endpoint display."""
        table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
        table.add_column("", width=3)
        table.add_column("Path", style="cyan", max_width=40)
        table.add_column("Methods", width=20)
        table.add_column("Status", width=12)
        return table

    def _render_endpoint_detail(
        self, ctx: RenderContext, path: str, changes: list[Change], color: str
    ) -> None:
        """Render detailed changes for a single endpoint."""
        content = Text()

        # Group changes by type
        param_changes = [c for c in changes if "parameter" in c.path.lower()]
        response_changes = [c for c in changes if "response" in c.path.lower()]
        other = [c for c in changes if c not in param_changes and c not in response_changes]

        for change in other[:5]:
            symbol, sym_color = self.format_change_type(change.change_type)
            desc = self._describe_change(change)
            content.append(f"{symbol} ", style=sym_color)
            content.append(f"{desc}\n", style=sym_color)

        if param_changes:
            content.append("\n[dim]Parameters:[/dim]\n")
            for change in param_changes[:5]:
                symbol, sym_color = self.format_change_type(change.change_type)
                param_name = change.path.split("/")[-1]
                content.append(f"  {symbol} ", style=sym_color)
                content.append(f"{param_name}\n", style=sym_color)

        if response_changes:
            content.append("\n[dim]Responses:[/dim]\n")
            for change in response_changes[:5]:
                symbol, sym_color = self.format_change_type(change.change_type)
                resp_code = self._extract_response_code(change)
                content.append(f"  {symbol} ", style=sym_color)
                content.append(f"{resp_code}\n", style=sym_color)

        ctx.console.print(
            Panel(content, title=f"[{color}]~ {path}[/{color}]", border_style=color)
        )

        # Verbose output
        if ctx.verbose:
            for change in changes:
                self.render_verbose_info(ctx, change)

        ctx.console.print()

    def _render_schema_changes(self, ctx: RenderContext, changes: list[Change]) -> None:
        """Render schema/model changes."""
        ctx.console.print(Panel("[bold]Schema Changes[/bold]", border_style="cyan", padding=(0, 2)))
        ctx.console.print()

        # Group by schema name
        by_schema: dict[str, list[Change]] = {}
        for change in changes:
            schema_name = self._extract_schema_name(change)
            by_schema.setdefault(schema_name, []).append(change)

        # Group by risk
        breaking = []
        risky = []
        safe = []

        for schema_name, schema_changes in by_schema.items():
            risks = [ctx.get_change_risk(c) for c in schema_changes]
            if any(r == RiskLevel.BREAKING for r in risks):
                breaking.append((schema_name, schema_changes))
            elif any(r == RiskLevel.RISKY for r in risks):
                risky.append((schema_name, schema_changes))
            else:
                safe.append((schema_name, schema_changes))

        def render_group(items: list, title: str, color: str) -> None:
            if not items:
                return
            ctx.console.print(f"[bold {color}]{title}[/bold {color}]")

            table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
            table.add_column("", width=3)
            table.add_column("Schema", style="cyan", max_width=25)
            table.add_column("Change", max_width=40)

            for schema_name, schema_changes in items:
                all_removed = all(c.change_type == ChangeType.REMOVED for c in schema_changes)
                all_added = all(c.change_type == ChangeType.ADDED for c in schema_changes)

                if all_removed:
                    symbol = "-"
                    desc = "removed"
                elif all_added:
                    symbol = "+"
                    desc = "added"
                else:
                    symbol = "~"
                    props = [c.path.split("/")[-1] for c in schema_changes[:3]]
                    desc = ", ".join(props)
                    if len(schema_changes) > 3:
                        desc += f" +{len(schema_changes) - 3} more"

                table.add_row(
                    f"[{color}]{symbol}[/{color}]",
                    f"[{color}]{schema_name}[/{color}]",
                    desc,
                )

            ctx.console.print(table)
            ctx.console.print()

        if breaking:
            render_group(breaking, "[X] Breaking Schema Changes", "red")
        if risky and not ctx.breaking_only:
            render_group(risky, "[!] Risky Schema Changes", "yellow")
        if safe and ctx.show_safe and not ctx.breaking_only:
            render_group(safe, "[o] Safe Schema Changes", "green")

    def _render_security_changes(
        self, ctx: RenderContext, changes: list[Change]
    ) -> None:
        """Render security-related changes."""
        ctx.console.print(Panel("[bold]Security Changes[/bold]", border_style="red", padding=(0, 2)))
        ctx.console.print()

        # Group by risk
        breaking = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.BREAKING]
        risky = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.RISKY]
        safe = [c for c in changes if ctx.get_change_risk(c) == RiskLevel.SAFE]

        def render_group(changes: list[Change], title: str, color: str) -> None:
            if not changes:
                return
            ctx.console.print(f"[bold {color}]{title}[/bold {color}]")

            table = Table(box=box.SIMPLE, show_header=True, header_style="bold dim")
            table.add_column("", width=3)
            table.add_column("Security", max_width=30)
            table.add_column("Change", max_width=40)

            for change in changes:
                symbol, sym_color = self.format_change_type(change.change_type)
                sec_name = change.path.split("/")[-1]
                desc = change.change_type.name.lower()

                table.add_row(
                    f"[{sym_color}]{symbol}[/{sym_color}]",
                    sec_name,
                    desc,
                )

            ctx.console.print(table)
            ctx.console.print()

        if breaking:
            render_group(breaking, "[X] Breaking Security Changes", "red")
        if risky and not ctx.breaking_only:
            render_group(risky, "[!] Risky Security Changes", "yellow")
        if safe and ctx.show_safe and not ctx.breaking_only:
            render_group(safe, "[o] Safe Security Changes", "green")

    def _render_other_changes(self, ctx: RenderContext, changes: list[Change]) -> None:
        """Render other/miscellaneous changes."""
        ctx.console.print("[dim]Other Changes[/dim]")

        for change in changes[:10]:
            symbol, color = self.format_change_type(change.change_type)
            ctx.console.print(f"  [{color}]{symbol}[/{color}] {change.path}")

        if len(changes) > 10:
            ctx.console.print(f"  [dim]... +{len(changes) - 10} more[/dim]")
        ctx.console.print()

    def _extract_endpoint_path(self, change: Change) -> str:
        """Extract the API path from a change."""
        path = change.path
        if "/paths/" in path:
            parts = path.split("/paths/")[1].split("/")
            api_path = parts[0].replace("~1", "/").replace("~0", "~")
            return api_path
        return path

    def _extract_methods(self, changes: list[Change]) -> list[str]:
        """Extract HTTP methods from changes."""
        methods = set()
        for change in changes:
            path = change.path.lower()
            for method in ["get", "post", "put", "patch", "delete", "options", "head"]:
                if f"/{method}" in path or f".{method}" in path:
                    methods.add(method.upper())

            for entity in [change.new_entity, change.old_entity]:
                if entity and entity.metadata.get("method"):
                    methods.add(entity.metadata["method"].upper())

        return sorted(methods) if methods else ["?"]

    def _extract_schema_name(self, change: Change) -> str:
        """Extract schema name from change path."""
        path = change.path
        for marker in ["/schemas/", "/definitions/"]:
            if marker in path:
                parts = path.split(marker)[1].split("/")
                return parts[0]
        return path.split("/")[-1]

    def _extract_response_code(self, change: Change) -> str:
        """Extract response code from change."""
        path = change.path
        if "/responses/" in path:
            parts = path.split("/responses/")[1].split("/")
            return parts[0]
        return "?"

    def _describe_change(self, change: Change) -> str:
        """Create a short description of a change."""
        parts = change.path.split("/")
        relevant = [p for p in parts if p and not p.startswith("paths")]
        return " > ".join(relevant[-3:]) if len(relevant) > 3 else " > ".join(relevant)
