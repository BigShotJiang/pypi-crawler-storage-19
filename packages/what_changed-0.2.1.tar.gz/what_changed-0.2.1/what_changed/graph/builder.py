"""Builder for constructing change graphs from diff results."""

from typing import Optional
import hashlib

from what_changed.diff.semantic_diff import DiffResult, Change, ChangeType
from what_changed.normalize.base import EntityType
from what_changed.graph.model import (
    ChangeGraph,
    ChangeNode,
    ChangeEdge,
    NodeType,
    EdgeType,
    RiskLevel,
)


def _entity_type_to_node_type(entity_type: EntityType) -> NodeType:
    """Map entity types to node types."""
    mapping = {
        EntityType.FILE: NodeType.FILE,
        EntityType.DIRECTORY: NodeType.DIRECTORY,
        EntityType.KEY: NodeType.CONFIG_KEY,
        EntityType.VALUE: NodeType.CONFIG_KEY,
        EntityType.SECTION: NodeType.ENTITY,
        EntityType.ENVIRONMENT_VAR: NodeType.CONFIG_KEY,
        EntityType.FUNCTION: NodeType.SYMBOL,
        EntityType.CLASS: NodeType.SYMBOL,
        EntityType.METHOD: NodeType.SYMBOL,
        EntityType.VARIABLE: NodeType.SYMBOL,
        EntityType.ENDPOINT: NodeType.ENDPOINT,
        EntityType.PARAMETER: NodeType.ENTITY,
        EntityType.RESPONSE: NodeType.ENTITY,
        EntityType.LINE: NodeType.ENTITY,
        EntityType.TEXT_BLOCK: NodeType.ENTITY,
    }
    return mapping.get(entity_type, NodeType.ENTITY)


def _change_type_to_edge_type(change_type: ChangeType) -> EdgeType:
    """Map change types to edge types."""
    mapping = {
        ChangeType.ADDED: EdgeType.ADDED,
        ChangeType.REMOVED: EdgeType.REMOVED,
        ChangeType.MODIFIED: EdgeType.MODIFIED,
        ChangeType.RENAMED: EdgeType.RENAMED,
        ChangeType.TYPE_CHANGED: EdgeType.MODIFIED,
        ChangeType.MOVED: EdgeType.MODIFIED,
    }
    return mapping.get(change_type, EdgeType.MODIFIED)


class GraphBuilder:
    """
    Builds a change graph from diff results.

    The graph builder creates a hierarchical structure representing all changes,
    their relationships, and prepares nodes for risk scoring.
    """

    def __init__(self, include_unchanged: bool = False):
        """
        Initialize the graph builder.

        Args:
            include_unchanged: Whether to include unchanged entities in the graph
        """
        self.include_unchanged = include_unchanged

    def build(self, diff_result: DiffResult) -> ChangeGraph:
        """
        Build a change graph from a diff result.

        Args:
            diff_result: The result of semantic diff

        Returns:
            A ChangeGraph representing all changes
        """
        graph = ChangeGraph()

        # Create root node
        root = ChangeNode(
            id="_root",
            name="Changes",
            node_type=NodeType.ROOT,
            path="",
            metadata={
                "source_a": diff_result.source_a,
                "source_b": diff_result.source_b,
                "type_a": diff_result.type_a,
                "type_b": diff_result.type_b,
                "total_changes": diff_result.total_changes,
            },
        )
        graph.add_node(root)
        graph.root = root

        # Group changes by parent path for hierarchy
        path_nodes: dict[str, ChangeNode] = {}

        for change in diff_result.changes:
            # Create node for this change
            node = self._create_node_from_change(change)
            graph.add_node(node)
            path_nodes[change.path] = node

            # Find or create parent nodes
            parent_id = self._find_or_create_parent(
                change.path, graph, path_nodes
            )

            # Add edge from parent to this node
            edge_type = _change_type_to_edge_type(change.change_type)
            graph.add_edge(ChangeEdge(
                source_id=parent_id,
                target_id=node.id,
                edge_type=edge_type,
                metadata={
                    "change_type": change.change_type.name,
                },
            ))

        # Add dependency edges based on path relationships
        self._add_dependency_edges(graph, path_nodes)

        return graph

    def _create_node_from_change(self, change: Change) -> ChangeNode:
        """Create a change node from a Change object."""
        node_id = hashlib.md5(f"{change.path}:{change.change_type.name}".encode()).hexdigest()[:16]

        node_type = _entity_type_to_node_type(change.entity_type)

        # Extract name from path
        name = change.path.split('/')[-1] if '/' in change.path else change.path
        name = name.split('.')[-1] if '.' in name and not name.startswith('.') else name

        return ChangeNode(
            id=f"change_{node_id}",
            name=name,
            node_type=node_type,
            path=change.path,
            change_type=change.change_type,
            change=change,
            metadata={
                "entity_type": change.entity_type.name,
                "old_value": self._summarize_value(change.old_value),
                "new_value": self._summarize_value(change.new_value),
                **change.metadata,
            },
        )

    def _find_or_create_parent(
        self,
        path: str,
        graph: ChangeGraph,
        path_nodes: dict[str, ChangeNode],
    ) -> str:
        """
        Find or create parent nodes for a path.

        Returns the ID of the immediate parent node.
        """
        # Parse the path to find parent
        parts = self._split_path(path)

        if len(parts) <= 1:
            # Direct child of root
            return "_root"

        # Build parent path
        parent_path = self._join_path(parts[:-1])

        # Check if parent node already exists
        if parent_path in path_nodes:
            return path_nodes[parent_path].id

        # Create intermediate parent node
        parent_node = ChangeNode(
            id=f"parent_{hashlib.md5(parent_path.encode()).hexdigest()[:12]}",
            name=parts[-2],
            node_type=NodeType.ENTITY,
            path=parent_path,
            metadata={"is_intermediate": True},
        )
        graph.add_node(parent_node)
        path_nodes[parent_path] = parent_node

        # Recursively find/create grandparent
        grandparent_id = self._find_or_create_parent(parent_path, graph, path_nodes)

        # Connect parent to grandparent
        graph.add_edge(ChangeEdge(
            source_id=grandparent_id,
            target_id=parent_node.id,
            edge_type=EdgeType.CONTAINS,
        ))

        return parent_node.id

    def _split_path(self, path: str) -> list[str]:
        """Split a path into its components."""
        # Handle various path formats:
        # - config.database.host
        # - /path/to/file
        # - key[0].subkey

        if '/' in path:
            # File/directory path
            return [p for p in path.split('/') if p]
        elif '.' in path and not path.startswith('.'):
            # Dot-notation path (config keys)
            # Handle array indices like key[0]
            result = []
            for part in path.split('.'):
                if '[' in part:
                    # Split array indices
                    base = part.split('[')[0]
                    result.append(base)
                    # Extract indices
                    indices = part.count('[')
                    for i in range(indices):
                        start = part.find('[', part.find('[' * i)) + 1
                        end = part.find(']', start)
                        result.append(f"[{part[start:end]}]")
                else:
                    result.append(part)
            return result
        else:
            return [path]

    def _join_path(self, parts: list[str]) -> str:
        """Join path parts back together."""
        # Check if this looks like a file path or config path
        if any('/' in p or len(p) > 30 for p in parts):
            return '/'.join(parts)

        # Config-style path
        result = []
        for part in parts:
            if part.startswith('['):
                # Array index - append without dot
                result.append(part)
            else:
                result.append('.' + part if result else part)
        return ''.join(result)

    def _add_dependency_edges(
        self,
        graph: ChangeGraph,
        path_nodes: dict[str, ChangeNode],
    ) -> None:
        """
        Add dependency edges based on relationships between changes.

        For example, if a config key is renamed, other changes that depend
        on that key would get a DEPENDS_ON edge.
        """
        # For now, we add simple heuristic dependencies:
        # - If two changes share a common prefix, they may be related

        nodes_list = list(path_nodes.values())

        for i, node_a in enumerate(nodes_list):
            for node_b in nodes_list[i + 1:]:
                # Check if paths suggest dependency
                if self._paths_suggest_dependency(node_a.path, node_b.path):
                    graph.add_edge(ChangeEdge(
                        source_id=node_a.id,
                        target_id=node_b.id,
                        edge_type=EdgeType.REFERENCES,
                        metadata={"inferred": True},
                    ))

    def _paths_suggest_dependency(self, path_a: str, path_b: str) -> bool:
        """
        Check if two paths suggest a dependency relationship.

        This is a heuristic - more sophisticated analysis would be needed
        for accurate dependency detection.
        """
        # Check if one path is a prefix of another
        if path_a.startswith(path_b) or path_b.startswith(path_a):
            return False  # Already covered by hierarchy

        # Check if they share a significant common prefix
        parts_a = self._split_path(path_a)
        parts_b = self._split_path(path_b)

        common = 0
        for pa, pb in zip(parts_a, parts_b):
            if pa == pb:
                common += 1
            else:
                break

        # If they share at least 2 levels but are different leaf nodes
        if common >= 2 and len(parts_a) > common and len(parts_b) > common:
            return True

        return False

    def _summarize_value(self, value: object) -> Optional[str]:
        """Create a summary string for a value."""
        if value is None:
            return None

        if isinstance(value, (dict, list)):
            return f"<{type(value).__name__} with {len(value)} items>"

        str_value = str(value)
        if len(str_value) > 100:
            return str_value[:97] + "..."
        return str_value
