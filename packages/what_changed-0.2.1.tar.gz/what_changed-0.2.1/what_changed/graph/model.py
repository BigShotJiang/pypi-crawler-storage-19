"""Change graph model using networkx."""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Optional, Iterator

import networkx as nx

from what_changed.diff.semantic_diff import Change, ChangeType
from what_changed.normalize.base import EntityType


class NodeType(Enum):
    """Types of nodes in the change graph."""

    FILE = auto()
    DIRECTORY = auto()
    ENTITY = auto()
    ENDPOINT = auto()
    CONFIG_KEY = auto()
    SYMBOL = auto()
    ROOT = auto()


class EdgeType(Enum):
    """Types of edges in the change graph."""

    ADDED = auto()
    REMOVED = auto()
    MODIFIED = auto()
    RENAMED = auto()
    DEPENDS_ON = auto()
    CONTAINS = auto()
    REFERENCES = auto()


class RiskLevel(Enum):
    """Risk level classification for changes."""

    SAFE = auto()      # Score < 5
    RISKY = auto()     # Score 5-7
    BREAKING = auto()  # Score >= 8

    @classmethod
    def from_score(cls, score: int) -> "RiskLevel":
        """Determine risk level from numeric score."""
        if score >= 8:
            return cls.BREAKING
        elif score >= 5:
            return cls.RISKY
        else:
            return cls.SAFE


@dataclass
class ChangeNode:
    """A node in the change graph representing an entity or change."""

    id: str
    name: str
    node_type: NodeType
    path: str

    # Change information
    change_type: Optional[ChangeType] = None
    change: Optional[Change] = None

    # Risk assessment
    risk_score: int = 0
    risk_level: RiskLevel = RiskLevel.SAFE

    # Metadata
    metadata: dict[str, Any] = field(default_factory=dict)

    def __hash__(self) -> int:
        return hash(self.id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ChangeNode):
            return False
        return self.id == other.id


@dataclass
class ChangeEdge:
    """An edge in the change graph representing a relationship."""

    source_id: str
    target_id: str
    edge_type: EdgeType
    metadata: dict[str, Any] = field(default_factory=dict)


class ChangeGraph:
    """
    A graph representation of changes for analysis and visualization.

    Uses networkx internally for graph operations.
    """

    def __init__(self) -> None:
        self._graph: nx.DiGraph = nx.DiGraph()
        self._nodes: dict[str, ChangeNode] = {}
        self._root_id: Optional[str] = None

    def add_node(self, node: ChangeNode) -> None:
        """Add a node to the graph."""
        self._nodes[node.id] = node
        self._graph.add_node(
            node.id,
            name=node.name,
            node_type=node.node_type.name,
            path=node.path,
            change_type=node.change_type.name if node.change_type else None,
            risk_score=node.risk_score,
            risk_level=node.risk_level.name,
            metadata=node.metadata,
        )

    def add_edge(self, edge: ChangeEdge) -> None:
        """Add an edge to the graph."""
        self._graph.add_edge(
            edge.source_id,
            edge.target_id,
            edge_type=edge.edge_type.name,
            metadata=edge.metadata,
        )

    def get_node(self, node_id: str) -> Optional[ChangeNode]:
        """Get a node by ID."""
        return self._nodes.get(node_id)

    def get_nodes(self) -> Iterator[ChangeNode]:
        """Iterate over all nodes."""
        return iter(self._nodes.values())

    def get_edges(self) -> Iterator[tuple[str, str, dict]]:
        """Iterate over all edges."""
        return iter(self._graph.edges(data=True))

    def get_children(self, node_id: str) -> list[ChangeNode]:
        """Get all child nodes (outgoing edges)."""
        children = []
        for _, target in self._graph.out_edges(node_id):
            if target in self._nodes:
                children.append(self._nodes[target])
        return children

    def get_parents(self, node_id: str) -> list[ChangeNode]:
        """Get all parent nodes (incoming edges)."""
        parents = []
        for source, _ in self._graph.in_edges(node_id):
            if source in self._nodes:
                parents.append(self._nodes[source])
        return parents

    def get_descendants(self, node_id: str) -> list[ChangeNode]:
        """Get all descendants (transitive children)."""
        descendants = []
        for desc_id in nx.descendants(self._graph, node_id):
            if desc_id in self._nodes:
                descendants.append(self._nodes[desc_id])
        return descendants

    def get_ancestors(self, node_id: str) -> list[ChangeNode]:
        """Get all ancestors (transitive parents)."""
        ancestors = []
        for anc_id in nx.ancestors(self._graph, node_id):
            if anc_id in self._nodes:
                ancestors.append(self._nodes[anc_id])
        return ancestors

    @property
    def root(self) -> Optional[ChangeNode]:
        """Get the root node if set."""
        if self._root_id:
            return self._nodes.get(self._root_id)
        return None

    @root.setter
    def root(self, node: ChangeNode) -> None:
        """Set the root node."""
        self._root_id = node.id

    @property
    def node_count(self) -> int:
        """Number of nodes in the graph."""
        return len(self._nodes)

    @property
    def edge_count(self) -> int:
        """Number of edges in the graph."""
        return self._graph.number_of_edges()

    def get_nodes_by_risk(self, risk_level: RiskLevel) -> list[ChangeNode]:
        """Get all nodes with a specific risk level."""
        return [n for n in self._nodes.values() if n.risk_level == risk_level]

    def get_nodes_by_change_type(self, change_type: ChangeType) -> list[ChangeNode]:
        """Get all nodes with a specific change type."""
        return [n for n in self._nodes.values() if n.change_type == change_type]

    def get_breaking_changes(self) -> list[ChangeNode]:
        """Get all nodes classified as breaking."""
        return self.get_nodes_by_risk(RiskLevel.BREAKING)

    def get_risky_changes(self) -> list[ChangeNode]:
        """Get all nodes classified as risky."""
        return self.get_nodes_by_risk(RiskLevel.RISKY)

    def get_safe_changes(self) -> list[ChangeNode]:
        """Get all nodes classified as safe."""
        return self.get_nodes_by_risk(RiskLevel.SAFE)

    def compute_impact_score(self, node_id: str) -> int:
        """
        Compute the total impact score for a node and its descendants.

        This helps identify the most impactful changes.
        """
        total = 0
        node = self._nodes.get(node_id)
        if node:
            total = node.risk_score

        for desc in self.get_descendants(node_id):
            total += desc.risk_score

        return total

    def get_most_impactful(self, n: int = 10) -> list[ChangeNode]:
        """Get the N most impactful changes."""
        scored = [(node, self.compute_impact_score(node.id)) for node in self._nodes.values()]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [node for node, _ in scored[:n]]

    def to_dict(self) -> dict[str, Any]:
        """Convert the graph to a dictionary representation."""
        return {
            "nodes": [
                {
                    "id": node.id,
                    "name": node.name,
                    "type": node.node_type.name,
                    "path": node.path,
                    "change_type": node.change_type.name if node.change_type else None,
                    "risk_score": node.risk_score,
                    "risk_level": node.risk_level.name,
                    "metadata": node.metadata,
                }
                for node in self._nodes.values()
            ],
            "edges": [
                {
                    "source": source,
                    "target": target,
                    "type": data.get("edge_type"),
                    "metadata": data.get("metadata", {}),
                }
                for source, target, data in self._graph.edges(data=True)
            ],
            "summary": {
                "total_nodes": self.node_count,
                "total_edges": self.edge_count,
                "breaking_count": len(self.get_breaking_changes()),
                "risky_count": len(self.get_risky_changes()),
                "safe_count": len(self.get_safe_changes()),
            },
        }

    @property
    def networkx_graph(self) -> nx.DiGraph:
        """Get the underlying networkx graph."""
        return self._graph
