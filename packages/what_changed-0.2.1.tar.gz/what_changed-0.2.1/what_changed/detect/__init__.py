"""Type detection module."""

from what_changed.detect.type_detector import TypeDetector, SourceType

__all__ = ["TypeDetector", "SourceType"]
