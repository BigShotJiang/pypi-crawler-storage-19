"""Type detection for input sources."""

from dataclasses import dataclass
from enum import Enum, auto
from pathlib import Path
from typing import Optional
import re


class SourceType(Enum):
    """Enumeration of detectable source types."""

    URL = auto()
    DIRECTORY = auto()
    ARCHIVE = auto()
    JSON = auto()
    YAML = auto()
    ENV = auto()
    TOML = auto()
    INI = auto()
    XML = auto()
    PDF = auto()
    OPENAPI = auto()
    CSV = auto()
    MARKDOWN = auto()
    DOCKERFILE = auto()
    DOCKER_COMPOSE = auto()
    PACKAGE_JSON = auto()
    REQUIREMENTS_TXT = auto()
    PYPROJECT_TOML = auto()
    GEMFILE = auto()
    CARGO_TOML = auto()
    GO_MOD = auto()
    IMAGE = auto()
    SQL = auto()
    TEXT = auto()
    BINARY = auto()
    UNKNOWN = auto()


@dataclass
class DetectionResult:
    """Result of type detection."""

    source_type: SourceType
    path: Optional[Path]
    url: Optional[str]
    confidence: float  # 0.0 to 1.0

    @property
    def is_config(self) -> bool:
        """Check if this is a configuration file type."""
        return self.source_type in {
            SourceType.JSON,
            SourceType.YAML,
            SourceType.ENV,
            SourceType.TOML,
            SourceType.INI,
            SourceType.XML,
            SourceType.OPENAPI,
        }

    @property
    def is_document(self) -> bool:
        """Check if this is a document file type."""
        return self.source_type in {
            SourceType.PDF,
            SourceType.TEXT,
        }

    @property
    def is_local(self) -> bool:
        """Check if this is a local file or directory."""
        return self.source_type not in {SourceType.URL, SourceType.UNKNOWN}


class TypeDetector:
    """Detects the type of input source."""

    # URL pattern
    URL_PATTERN = re.compile(
        r'^https?://'
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'
        r'localhost|'
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'
        r'(?::\d+)?'
        r'(?:/?|[/?]\S+)$',
        re.IGNORECASE
    )

    # Archive extensions
    ARCHIVE_EXTENSIONS = {'.zip', '.tar', '.gz', '.tgz', '.tar.gz', '.bz2', '.xz', '.7z', '.rar', '.jar', '.war', '.ear', '.whl'}

    # Config file mappings (extension -> type)
    CONFIG_EXTENSIONS = {
        '.json': SourceType.JSON,
        '.yaml': SourceType.YAML,
        '.yml': SourceType.YAML,
        '.env': SourceType.ENV,
        '.toml': SourceType.TOML,
        '.ini': SourceType.INI,
        '.cfg': SourceType.INI,
        '.xml': SourceType.XML,
        '.pdf': SourceType.PDF,
        '.csv': SourceType.CSV,
        '.tsv': SourceType.CSV,
        '.md': SourceType.MARKDOWN,
        '.markdown': SourceType.MARKDOWN,
        '.sql': SourceType.SQL,
        '.ddl': SourceType.SQL,
    }

    # Image extensions
    IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.gif', '.bmp', '.tiff', '.tif', '.webp'}

    # PDF magic bytes
    PDF_MAGIC = b'%PDF-'

    # Text file extensions
    TEXT_EXTENSIONS = {
        '.txt', '.md', '.rst', '.csv', '.log',
        '.py', '.js', '.ts', '.java', '.c', '.cpp', '.h', '.hpp',
        '.go', '.rs', '.rb', '.php', '.sh', '.bash', '.zsh',
        '.html', '.css', '.scss', '.less', '.sql',
    }

    # Known config filenames (without extension check)
    CONFIG_FILENAMES = {
        '.env': SourceType.ENV,
        '.env.local': SourceType.ENV,
        '.env.development': SourceType.ENV,
        '.env.production': SourceType.ENV,
        '.env.test': SourceType.ENV,
        'dockerfile': SourceType.DOCKERFILE,
        'containerfile': SourceType.DOCKERFILE,
        'docker-compose.yml': SourceType.DOCKER_COMPOSE,
        'docker-compose.yaml': SourceType.DOCKER_COMPOSE,
        'compose.yml': SourceType.DOCKER_COMPOSE,
        'compose.yaml': SourceType.DOCKER_COMPOSE,
        'package.json': SourceType.PACKAGE_JSON,
        'requirements.txt': SourceType.REQUIREMENTS_TXT,
        'requirements-dev.txt': SourceType.REQUIREMENTS_TXT,
        'requirements-test.txt': SourceType.REQUIREMENTS_TXT,
        'pyproject.toml': SourceType.PYPROJECT_TOML,
        'gemfile': SourceType.GEMFILE,
        'cargo.toml': SourceType.CARGO_TOML,
        'go.mod': SourceType.GO_MOD,
        'makefile': SourceType.TEXT,
        '.gitignore': SourceType.TEXT,
        '.dockerignore': SourceType.TEXT,
    }

    def detect(self, source: str) -> DetectionResult:
        """
        Detect the type of the given source.

        Detection order:
        1. URL
        2. Directory
        3. Archive
        4. Known text formats
        5. Binary fallback

        Args:
            source: Path string or URL to detect

        Returns:
            DetectionResult with type information
        """
        # Check for URL first
        if self._is_url(source):
            return DetectionResult(
                source_type=SourceType.URL,
                path=None,
                url=source,
                confidence=1.0,
            )

        # Convert to Path for file system checks
        path = Path(source)

        # Check if it exists
        if not path.exists():
            return DetectionResult(
                source_type=SourceType.UNKNOWN,
                path=path,
                url=None,
                confidence=0.0,
            )

        # Check for directory
        if path.is_dir():
            return DetectionResult(
                source_type=SourceType.DIRECTORY,
                path=path,
                url=None,
                confidence=1.0,
            )

        # Check for archive
        if self._is_archive(path):
            return DetectionResult(
                source_type=SourceType.ARCHIVE,
                path=path,
                url=None,
                confidence=1.0,
            )

        # Check for known config types by filename
        filename = path.name.lower()
        if filename in self.CONFIG_FILENAMES:
            return DetectionResult(
                source_type=self.CONFIG_FILENAMES[filename],
                path=path,
                url=None,
                confidence=0.9,
            )

        # Check for known config types by extension
        suffix = path.suffix.lower()
        if suffix in self.CONFIG_EXTENSIONS:
            return DetectionResult(
                source_type=self.CONFIG_EXTENSIONS[suffix],
                path=path,
                url=None,
                confidence=0.95,
            )

        # Check for image files by extension
        if suffix in self.IMAGE_EXTENSIONS:
            return DetectionResult(
                source_type=SourceType.IMAGE,
                path=path,
                url=None,
                confidence=0.95,
            )

        # Check for text files by extension
        if suffix in self.TEXT_EXTENSIONS:
            return DetectionResult(
                source_type=SourceType.TEXT,
                path=path,
                url=None,
                confidence=0.9,
            )

        # Try content-based detection for files without clear extension
        detected_type, confidence = self._detect_by_content(path)
        return DetectionResult(
            source_type=detected_type,
            path=path,
            url=None,
            confidence=confidence,
        )

    def _is_url(self, source: str) -> bool:
        """Check if source is a URL."""
        return bool(self.URL_PATTERN.match(source))

    def _is_archive(self, path: Path) -> bool:
        """Check if path is an archive file."""
        # Handle compound extensions like .tar.gz
        name = path.name.lower()
        for ext in self.ARCHIVE_EXTENSIONS:
            if name.endswith(ext):
                return True
        return False

    def _detect_by_content(self, path: Path) -> tuple[SourceType, float]:
        """
        Detect type by examining file content.

        Returns:
            Tuple of (SourceType, confidence)
        """
        try:
            # Read first few bytes to check for binary
            with open(path, 'rb') as f:
                head = f.read(8192)

            # Check for PDF magic bytes first
            if head.startswith(self.PDF_MAGIC):
                return SourceType.PDF, 0.95

            # Check for null bytes (binary indicator)
            if b'\x00' in head:
                return SourceType.BINARY, 0.8

            # Try to decode as text
            try:
                text = head.decode('utf-8')
            except UnicodeDecodeError:
                return SourceType.BINARY, 0.7

            # Try to detect format from content
            text_stripped = text.strip()

            # JSON detection
            if text_stripped.startswith(('{', '[')):
                return SourceType.JSON, 0.7

            # YAML detection (common patterns)
            if self._looks_like_yaml(text_stripped):
                return SourceType.YAML, 0.6

            # ENV detection
            if self._looks_like_env(text_stripped):
                return SourceType.ENV, 0.6

            # XML detection
            if text_stripped.startswith('<?xml') or text_stripped.startswith('<'):
                return SourceType.XML, 0.7

            # Default to text
            return SourceType.TEXT, 0.5

        except (OSError, IOError):
            return SourceType.UNKNOWN, 0.0

    def _looks_like_yaml(self, text: str) -> bool:
        """Check if text looks like YAML content."""
        lines = text.split('\n')[:10]
        yaml_patterns = 0

        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # Check for key: value pattern
            if re.match(r'^[\w_-]+:\s*', line):
                yaml_patterns += 1
            # Check for list item
            if line.startswith('- '):
                yaml_patterns += 1

        return yaml_patterns >= 2

    def _looks_like_env(self, text: str) -> bool:
        """Check if text looks like ENV content."""
        lines = text.split('\n')[:10]
        env_patterns = 0

        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # Check for KEY=value pattern
            if re.match(r'^[A-Z_][A-Z0-9_]*=', line):
                env_patterns += 1

        return env_patterns >= 2
