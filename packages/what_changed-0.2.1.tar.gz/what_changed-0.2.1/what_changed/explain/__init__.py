"""Explanation generation module."""

from what_changed.explain.explainer import Explainer, Explanation

__all__ = ["Explainer", "Explanation"]
