"""Explanation generator for changes."""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Optional

from what_changed.diff.semantic_diff import ChangeType
from what_changed.diff.content_diff import ContentDiff
from what_changed.graph.model import ChangeGraph, ChangeNode, RiskLevel, NodeType
from what_changed.rules.base import RuleResult
from what_changed.normalize.base import EntityType


class ConfidenceLevel(Enum):
    """Confidence level for explanations."""

    HIGH = auto()
    MEDIUM = auto()
    LOW = auto()


@dataclass
class Explanation:
    """
    A human-readable explanation of a change.

    Each explanation includes:
    - What changed
    - Why it matters (impact)
    - What could break
    - Confidence level
    """

    entity: str
    change_summary: str
    impact: str
    what_could_break: str
    confidence: ConfidenceLevel
    risk_level: RiskLevel
    risk_score: int
    path: str
    rule_matches: list[str] = field(default_factory=list)
    details: dict[str, Any] = field(default_factory=dict)

    # For documents: actual content diff
    content_diff: Optional[ContentDiff] = None

    # Whether this is a document type (changes explanation style)
    is_document: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "entity": self.entity,
            "change": self.change_summary,
            "impact": self.impact,
            "what_could_break": self.what_could_break,
            "confidence": self.confidence.name.lower(),
            "risk_level": self.risk_level.name.lower(),
            "risk_score": self.risk_score,
            "path": self.path,
            "rule_matches": self.rule_matches,
            "details": self.details,
        }


class Explainer:
    """
    Generates human-readable explanations for changes.

    The explainer analyzes change nodes and their rule matches to
    produce clear, actionable explanations.
    """

    # Document types that should use content-diff style output
    DOCUMENT_TYPES = {
        "pdf", "markdown", "md", "text", "txt", "csv", "docx",
    }

    # Entity types that indicate document content
    DOCUMENT_ENTITY_TYPES = {
        EntityType.PAGE,
        EntityType.SECTION,
        EntityType.DOCUMENT,
        EntityType.TEXT_BLOCK,
        EntityType.LINE,
    }

    # Document-specific impact templates
    DOCUMENT_IMPACT_TEMPLATES = {
        ChangeType.REMOVED: "Content removed from document",
        ChangeType.ADDED: "New content added to document",
        ChangeType.MODIFIED: "Content modified in document",
    }

    # Document-specific break templates
    DOCUMENT_BREAK_TEMPLATES = {
        ChangeType.REMOVED: "Removed content may affect document completeness",
        ChangeType.ADDED: "New content has been added",
        ChangeType.MODIFIED: "Text has been changed - review the diff below",
    }

    # Impact templates based on change type and risk level
    IMPACT_TEMPLATES = {
        (ChangeType.REMOVED, RiskLevel.BREAKING): (
            "This removal is likely to cause immediate failures in code or "
            "systems that depend on this {entity_type}."
        ),
        (ChangeType.REMOVED, RiskLevel.RISKY): (
            "Removing this {entity_type} may cause issues if other components "
            "rely on it. Verify no dependencies exist."
        ),
        (ChangeType.REMOVED, RiskLevel.SAFE): (
            "This removal appears safe, but verify it's not used elsewhere."
        ),
        (ChangeType.TYPE_CHANGED, RiskLevel.BREAKING): (
            "Type changes are breaking. Code expecting {old_type} will fail "
            "when receiving {new_type}."
        ),
        (ChangeType.TYPE_CHANGED, RiskLevel.RISKY): (
            "This type change may cause parsing or validation errors in "
            "consumers expecting the original type."
        ),
        (ChangeType.MODIFIED, RiskLevel.BREAKING): (
            "This modification to a critical value may break dependent systems."
        ),
        (ChangeType.MODIFIED, RiskLevel.RISKY): (
            "This value change could affect system behavior. Review downstream usage."
        ),
        (ChangeType.MODIFIED, RiskLevel.SAFE): (
            "This modification appears low-risk, but verify expected behavior."
        ),
        (ChangeType.RENAMED, RiskLevel.RISKY): (
            "Renaming may break references to the old name. Update all consumers."
        ),
        (ChangeType.ADDED, RiskLevel.RISKY): (
            "This addition may require updates to existing code or configurations."
        ),
        (ChangeType.ADDED, RiskLevel.SAFE): (
            "This addition is generally safe. No action required unless it's a required field."
        ),
    }

    # What could break templates
    BREAK_TEMPLATES = {
        ChangeType.REMOVED: [
            "Code referencing {path} will throw errors",
            "API clients expecting {entity} will fail",
            "Configuration parsers may fail on missing keys",
        ],
        ChangeType.TYPE_CHANGED: [
            "Type assertions or casts will fail",
            "Serialization/deserialization may break",
            "Validation logic may reject the new type",
        ],
        ChangeType.MODIFIED: [
            "Behavior dependent on the old value",
            "Caching or memoization based on this value",
            "Integration tests expecting the old value",
        ],
        ChangeType.RENAMED: [
            "Code using the old name: {old_name}",
            "External references to {old_name}",
            "Documentation referencing the old name",
        ],
        ChangeType.ADDED: [
            "Nothing directly, unless this is a required field",
            "Existing validation may need updates",
        ],
    }

    def __init__(self) -> None:
        pass

    def explain(
        self,
        node: ChangeNode,
        rule_results: list[RuleResult],
    ) -> Explanation:
        """
        Generate an explanation for a change node.

        Args:
            node: The change node to explain
            rule_results: Results from rule evaluation

        Returns:
            An Explanation object
        """
        # Check if this is a document type
        is_document = self._is_document_change(node)

        # Determine confidence based on rule matches
        confidence = self._determine_confidence(node, rule_results)

        # Generate change summary
        change_summary = self._generate_change_summary(node, is_document)

        # Generate impact statement
        if is_document:
            impact = self._generate_document_impact(node)
        else:
            impact = self._generate_impact(node, rule_results)

        # Generate what could break
        if is_document:
            what_could_break = self._generate_document_break_statement(node)
        else:
            what_could_break = self._generate_break_statement(node, rule_results)

        # Extract rule match descriptions
        rule_matches = [r.description for r in rule_results if r.matched]

        # Get content diff if available
        content_diff = None
        if node.change and node.change.content_diff:
            content_diff = node.change.content_diff

        return Explanation(
            entity=node.name,
            change_summary=change_summary,
            impact=impact,
            what_could_break=what_could_break,
            confidence=confidence,
            risk_level=node.risk_level,
            risk_score=node.risk_score,
            path=node.path,
            rule_matches=rule_matches,
            details=node.metadata,
            content_diff=content_diff,
            is_document=is_document,
        )

    def explain_graph(
        self,
        graph: ChangeGraph,
        rule_results: dict[str, list[RuleResult]],
        min_risk: RiskLevel = RiskLevel.SAFE,
    ) -> list[Explanation]:
        """
        Generate explanations for all changes in a graph.

        Args:
            graph: The change graph
            rule_results: Map of node IDs to rule results
            min_risk: Minimum risk level to include

        Returns:
            List of explanations, sorted by risk score (descending)
        """
        explanations: list[Explanation] = []

        for node in graph.get_nodes():
            if node.change_type is None:
                continue

            if node.risk_level.value < min_risk.value:
                continue

            results = rule_results.get(node.id, [])
            explanation = self.explain(node, results)
            explanations.append(explanation)

        # Sort by risk score descending
        explanations.sort(key=lambda e: e.risk_score, reverse=True)

        return explanations

    def _is_document_change(self, node: ChangeNode) -> bool:
        """Check if this change is a document-type change."""
        # Check path for document indicators
        path_lower = node.path.lower()
        if any(path_lower.startswith(dt) or f".{dt}" in path_lower for dt in ["page_", "section", "_document"]):
            return True

        # Check if the change has text content
        if node.change and node.change.content_diff:
            return True

        # Check entity type via change
        if node.change and node.change.old_entity:
            if node.change.old_entity.entity_type in self.DOCUMENT_ENTITY_TYPES:
                return True

        return False

    def _generate_document_impact(self, node: ChangeNode) -> str:
        """Generate impact statement for document changes."""
        template = self.DOCUMENT_IMPACT_TEMPLATES.get(node.change_type)
        if template:
            return template

        # For modified content, show stats
        if node.change and node.change.content_diff:
            diff = node.change.content_diff
            return f"{diff.lines_added} lines added, {diff.lines_removed} lines removed"

        return "Document content changed"

    def _generate_document_break_statement(self, node: ChangeNode) -> str:
        """Generate break statement for document changes."""
        template = self.DOCUMENT_BREAK_TEMPLATES.get(node.change_type)
        if template:
            return template
        return "Review the content changes"

    def _determine_confidence(
        self,
        node: ChangeNode,
        rule_results: list[RuleResult],
    ) -> ConfidenceLevel:
        """Determine confidence level for the explanation."""
        if not rule_results:
            return ConfidenceLevel.LOW

        # Multiple matching rules = higher confidence
        if len(rule_results) >= 3:
            return ConfidenceLevel.HIGH

        # High-scoring rules = higher confidence
        max_score = max(r.score for r in rule_results)
        if max_score >= 8:
            return ConfidenceLevel.HIGH
        elif max_score >= 5:
            return ConfidenceLevel.MEDIUM

        return ConfidenceLevel.LOW

    def _generate_change_summary(self, node: ChangeNode, is_document: bool = False) -> str:
        """Generate a summary of what changed."""
        if node.change_type == ChangeType.ADDED:
            return f"Added: {node.name}"

        elif node.change_type == ChangeType.REMOVED:
            return f"Removed: {node.name}"

        elif node.change_type == ChangeType.MODIFIED:
            # For documents, show diff stats instead of value comparison
            if is_document and node.change and node.change.content_diff:
                diff = node.change.content_diff
                return f"Modified: {node.name} (+{diff.lines_added}/-{diff.lines_removed} lines)"

            old_val = self._format_value(node.metadata.get("old_value"))
            new_val = self._format_value(node.metadata.get("new_value"))
            return f"Changed: {node.name} ({old_val} -> {new_val})"

        elif node.change_type == ChangeType.TYPE_CHANGED:
            old_type = node.metadata.get("old_type", "unknown")
            new_type = node.metadata.get("new_type", "unknown")
            return f"Type changed: {node.name} ({old_type} -> {new_type})"

        elif node.change_type == ChangeType.RENAMED:
            old_name = node.metadata.get("old_name", "?")
            new_name = node.metadata.get("new_name", "?")
            return f"Renamed: {old_name} -> {new_name}"

        return f"Changed: {node.name}"

    def _generate_impact(
        self,
        node: ChangeNode,
        rule_results: list[RuleResult],
    ) -> str:
        """Generate an impact statement."""
        # Try to get specific impact from rule results
        for result in rule_results:
            if result.reason:
                return result.reason

        # Fall back to template
        key = (node.change_type, node.risk_level)
        template = self.IMPACT_TEMPLATES.get(key)

        if template:
            return template.format(
                entity_type=node.node_type.name.lower(),
                old_type=node.metadata.get("old_type", "unknown"),
                new_type=node.metadata.get("new_type", "unknown"),
            )

        # Default impact statement
        return f"This {node.change_type.name.lower()} may affect dependent systems."

    def _generate_break_statement(
        self,
        node: ChangeNode,
        rule_results: list[RuleResult],
    ) -> str:
        """Generate a statement about what could break."""
        templates = self.BREAK_TEMPLATES.get(node.change_type, [])

        if not templates:
            return "Unknown potential impact"

        # Use first template that makes sense
        template = templates[0]

        return template.format(
            path=node.path,
            entity=node.name,
            old_name=node.metadata.get("old_name", node.name),
        )

    def _format_value(self, value: Any) -> str:
        """Format a value for display."""
        if value is None:
            return "null"

        str_value = str(value)
        if len(str_value) > 50:
            return str_value[:47] + "..."

        return str_value
