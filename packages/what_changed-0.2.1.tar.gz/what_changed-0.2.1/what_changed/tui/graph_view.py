"""TUI graph view for interactive change exploration."""

from typing import Optional

from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import Footer, Header, Static, Tree
from textual.widgets.tree import TreeNode

from what_changed.graph.model import ChangeGraph, ChangeNode, RiskLevel
from what_changed.diff.semantic_diff import ChangeType
from what_changed.explain.explainer import Explanation


# Risk level colors for TUI
RISK_STYLES = {
    RiskLevel.BREAKING: "bold red",
    RiskLevel.RISKY: "bold yellow",
    RiskLevel.SAFE: "bold green",
}

RISK_SYMBOLS = {
    RiskLevel.BREAKING: "[X]",
    RiskLevel.RISKY: "[!]",
    RiskLevel.SAFE: "[o]",
}

CHANGE_SYMBOLS = {
    ChangeType.ADDED: "+",
    ChangeType.REMOVED: "-",
    ChangeType.MODIFIED: "~",
    ChangeType.RENAMED: "->",
    ChangeType.TYPE_CHANGED: "!",
}


class ChangeDetail(Static):
    """Widget to display details of a selected change."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._current_explanation: Optional[Explanation] = None

    def set_explanation(self, explanation: Optional[Explanation]) -> None:
        """Update the displayed explanation."""
        self._current_explanation = explanation
        self.refresh()

    def render(self) -> Text:
        """Render the explanation details."""
        if self._current_explanation is None:
            return Text("Select a change to view details", style="dim")

        exp = self._current_explanation
        text = Text()

        # Header
        risk_style = RISK_STYLES.get(exp.risk_level, "")
        text.append(f"{RISK_SYMBOLS.get(exp.risk_level, '?')} ", style=risk_style)
        text.append(exp.entity, style="bold")
        text.append(f" (score: {exp.risk_score})\n\n")

        # Change summary
        text.append("Change:\n", style="bold")
        text.append(f"  {exp.change_summary}\n\n")

        # Path
        text.append("Path:\n", style="bold")
        text.append(f"  {exp.path}\n\n", style="dim")

        # Impact
        text.append("Impact:\n", style="bold")
        text.append(f"  {exp.impact}\n\n")

        # What could break
        text.append("Could Break:\n", style="bold")
        text.append(f"  {exp.what_could_break}\n\n")

        # Confidence
        text.append("Confidence: ", style="bold")
        text.append(f"{exp.confidence.name.lower()}\n\n")

        # Rule matches
        if exp.rule_matches:
            text.append("Matched Rules:\n", style="bold")
            for match in exp.rule_matches:
                text.append(f"  • {match}\n", style="dim")

        return text


class ChangeSummary(Static):
    """Widget to display change summary."""

    def __init__(self, graph: ChangeGraph, **kwargs) -> None:
        super().__init__(**kwargs)
        self._graph = graph

    def render(self) -> Text:
        """Render the summary."""
        breaking = len(self._graph.get_breaking_changes())
        risky = len(self._graph.get_risky_changes())
        safe = len(self._graph.get_safe_changes())

        text = Text()
        text.append("Summary\n", style="bold underline")
        text.append(f"\n[X] Breaking: {breaking}", style="red")
        text.append(f"\n[!] Risky: {risky}", style="yellow")
        text.append(f"\n[o] Safe: {safe}", style="green")
        text.append(f"\n\nTotal: {breaking + risky + safe}")

        return text


class ChangeTree(Tree):
    """Tree widget for displaying changes."""

    def __init__(
        self,
        graph: ChangeGraph,
        explanations: dict[str, Explanation],
        **kwargs,
    ) -> None:
        super().__init__("Changes", **kwargs)
        self._graph = graph
        self._explanations = explanations
        self._build_tree()

    def _build_tree(self) -> None:
        """Build the tree from the change graph."""
        # Group by risk level
        breaking = self._graph.get_breaking_changes()
        risky = self._graph.get_risky_changes()
        safe = self._graph.get_safe_changes()

        if breaking:
            breaking_node = self.root.add("[X] Breaking", expand=True)
            for node in breaking:
                self._add_change_node(breaking_node, node)

        if risky:
            risky_node = self.root.add("[!] Risky", expand=True)
            for node in risky:
                self._add_change_node(risky_node, node)

        if safe:
            safe_node = self.root.add("[o] Safe", expand=False)
            for node in safe:
                self._add_change_node(safe_node, node)

    def _add_change_node(self, parent: TreeNode, node: ChangeNode) -> None:
        """Add a change node to the tree."""
        symbol = CHANGE_SYMBOLS.get(node.change_type, "?")
        label = f"{symbol} {node.name}"

        tree_node = parent.add_leaf(label, data=node.id)


class GraphViewApp(App):
    """TUI application for viewing change graphs."""

    TITLE = "what-changed"
    CSS = """
    Screen {
        layout: horizontal;
    }

    #sidebar {
        width: 35%;
        min-width: 30;
        border-right: solid $primary;
    }

    #main {
        width: 65%;
    }

    #summary {
        height: auto;
        max-height: 10;
        padding: 1;
        border-bottom: solid $primary;
    }

    #tree {
        height: 1fr;
    }

    #detail {
        padding: 1 2;
        height: 100%;
    }

    ChangeDetail {
        height: 100%;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
        Binding("enter", "select", "Select", show=False),
        Binding("?", "help", "Help"),
    ]

    def __init__(
        self,
        graph: ChangeGraph,
        explanations: list[Explanation],
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self._graph = graph
        self._explanations = {e.path: e for e in explanations}
        self._detail_widget: Optional[ChangeDetail] = None

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Header()

        with Horizontal():
            with Vertical(id="sidebar"):
                yield ChangeSummary(self._graph, id="summary")
                yield ChangeTree(
                    self._graph,
                    self._explanations,
                    id="tree",
                )

            with Container(id="main"):
                self._detail_widget = ChangeDetail(id="detail")
                yield self._detail_widget

        yield Footer()

    def on_tree_node_selected(self, event: Tree.NodeSelected) -> None:
        """Handle tree node selection."""
        if event.node.data is None:
            return

        node_id = event.node.data
        node = self._graph.get_node(node_id)

        if node and node.path in self._explanations:
            explanation = self._explanations[node.path]
            if self._detail_widget:
                self._detail_widget.set_explanation(explanation)

    def action_help(self) -> None:
        """Show help."""
        self.notify(
            "Navigation: j/k or arrows | Enter: select | q: quit",
            title="Help",
        )


def run_graph_tui(graph: ChangeGraph, explanations: list[Explanation]) -> None:
    """
    Run the graph TUI application.

    Args:
        graph: The change graph to display
        explanations: List of explanations
    """
    app = GraphViewApp(graph, explanations)
    app.run()
