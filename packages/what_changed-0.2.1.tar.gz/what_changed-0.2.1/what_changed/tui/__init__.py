"""TUI module for interactive graph visualization."""
