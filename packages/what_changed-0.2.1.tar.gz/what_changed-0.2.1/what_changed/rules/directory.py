"""Rules specific to directory/file system changes."""

import re
from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
from what_changed.diff.semantic_diff import ChangeType
from what_changed.rules.base import Rule, RuleResult


class CriticalFileRemovedRule(Rule):
    """Detects when critical files are removed."""

    CRITICAL_PATTERNS = [
        (r"^\.env$", 9, "Environment file"),
        (r"^config\.", 8, "Config file"),
        (r"^package\.json$", 8, "Package manifest"),
        (r"^requirements\.txt$", 8, "Python requirements"),
        (r"^Dockerfile$", 8, "Dockerfile"),
        (r"^docker-compose\.ya?ml$", 8, "Docker Compose"),
        (r"^Makefile$", 7, "Makefile"),
        (r"^\.gitignore$", 4, "Git ignore"),
        (r"^README", 3, "README"),
        (r"^LICENSE", 5, "License file"),
    ]

    def __init__(self):
        super().__init__(
            name="critical_file_removed",
            description="Detects when important files are removed",
        )
        self._patterns = [
            (re.compile(p, re.IGNORECASE), score, desc)
            for p, score, desc in self.CRITICAL_PATTERNS
        ]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.REMOVED:
            return self._no_match()

        if node.node_type not in (NodeType.FILE, NodeType.ENTITY):
            return self._no_match()

        filename = node.name
        for pattern, score, desc in self._patterns:
            if pattern.search(filename):
                return self._match(
                    score=score,
                    reason=f"{desc} removed: {filename}",
                )

        return self._no_match()


class SourceCodeRemovedRule(Rule):
    """Detects when source code files are removed."""

    SOURCE_EXTENSIONS = [
        ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rs",
        ".rb", ".php", ".c", ".cpp", ".h", ".cs", ".swift", ".kt",
    ]

    def __init__(self):
        super().__init__(
            name="source_code_removed",
            description="Detects when source code files are removed",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.REMOVED:
            return self._no_match()

        if node.node_type not in (NodeType.FILE, NodeType.ENTITY):
            return self._no_match()

        ext = node.metadata.get("extension", "")
        if not ext:
            for source_ext in self.SOURCE_EXTENSIONS:
                if node.name.endswith(source_ext):
                    ext = source_ext
                    break

        if ext in self.SOURCE_EXTENSIONS:
            return self._match(
                score=6,
                reason=f"Source file removed: {node.name}",
            )

        return self._no_match()


class DirectoryStructureChangedRule(Rule):
    """Detects significant directory structure changes."""

    IMPORTANT_DIRS = [
        (r"^src/?$", 8, "Source directory"),
        (r"^lib/?$", 7, "Library directory"),
        (r"^tests?/?$", 6, "Test directory"),
        (r"^config/?$", 7, "Config directory"),
        (r"^public/?$", 6, "Public assets"),
        (r"^static/?$", 5, "Static files"),
        (r"^docs?/?$", 4, "Documentation"),
    ]

    def __init__(self):
        super().__init__(
            name="directory_structure_changed",
            description="Detects changes to important directories",
        )
        self._patterns = [
            (re.compile(p, re.IGNORECASE), score, desc)
            for p, score, desc in self.IMPORTANT_DIRS
        ]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.node_type != NodeType.DIRECTORY:
            return self._no_match()

        dirname = node.name
        for pattern, score, desc in self._patterns:
            if pattern.search(dirname):
                if node.change_type == ChangeType.REMOVED:
                    return self._match(
                        score=score,
                        reason=f"{desc} removed: {dirname}",
                    )
                elif node.change_type == ChangeType.ADDED:
                    return self._match(
                        score=2,
                        reason=f"{desc} added: {dirname}",
                    )

        return self._no_match()


class LargeFileChangeRule(Rule):
    """Detects significant file size changes."""

    def __init__(self, threshold_bytes: int = 1024 * 100):  # 100KB
        super().__init__(
            name="large_file_change",
            description="Detects significant file size changes",
        )
        self._threshold = threshold_bytes

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        old_size = node.metadata.get("old_size", 0)
        new_size = node.metadata.get("new_size", 0)

        if old_size == 0 and new_size == 0:
            return self._no_match()

        size_diff = abs(new_size - old_size)
        if size_diff > self._threshold:
            if new_size > old_size:
                return self._match(
                    score=4,
                    reason=f"File size increased significantly (+{self._format_size(size_diff)})",
                )
            else:
                return self._match(
                    score=5,
                    reason=f"File size decreased significantly (-{self._format_size(size_diff)})",
                )

        return self._no_match()

    def _format_size(self, size: int) -> str:
        if size < 1024:
            return f"{size}B"
        elif size < 1024 * 1024:
            return f"{size / 1024:.1f}KB"
        else:
            return f"{size / (1024 * 1024):.1f}MB"


def get_directory_rules() -> list[Rule]:
    """Get all directory-related rules."""
    return [
        CriticalFileRemovedRule(),
        SourceCodeRemovedRule(),
        DirectoryStructureChangedRule(),
        LargeFileChangeRule(),
    ]
