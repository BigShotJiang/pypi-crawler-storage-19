"""Rules specific to configuration file changes."""

import re
from typing import Any, Optional

from what_changed.diff.semantic_diff import ChangeType
from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
from what_changed.rules.base import Rule, RuleResult


class TimeoutDecreasedRule(Rule):
    """Rule for detecting decreased timeout values."""

    TIMEOUT_PATTERNS = [
        r'timeout',
        r'ttl',
        r'expire',
        r'max[_-]?age',
        r'duration',
        r'interval',
        r'retry[_-]?delay',
    ]

    def __init__(self):
        super().__init__(
            name="timeout_decreased",
            description="Detects when timeout/TTL values are decreased",
        )
        self._patterns = [re.compile(p, re.IGNORECASE) for p in self.TIMEOUT_PATTERNS]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        # Check if this is a timeout-related field
        is_timeout = False
        for pattern in self._patterns:
            if pattern.search(node.name) or pattern.search(node.path):
                is_timeout = True
                break

        if not is_timeout:
            return self._no_match()

        # Get values
        old_value = node.metadata.get("old_value")
        new_value = node.metadata.get("new_value")

        # Try to compare as numbers
        try:
            old_num = self._parse_duration(old_value)
            new_num = self._parse_duration(new_value)

            if old_num is not None and new_num is not None:
                if new_num < old_num:
                    decrease_pct = ((old_num - new_num) / old_num) * 100
                    return self._match(
                        score=7,
                        reason=f"Timeout decreased by {decrease_pct:.0f}%: {node.path}",
                        details={
                            "old_value": old_value,
                            "new_value": new_value,
                            "decrease_percent": decrease_pct,
                        },
                    )
        except (TypeError, ValueError):
            pass

        return self._no_match()

    def _parse_duration(self, value: Any) -> Optional[float]:
        """Parse a duration value to seconds."""
        if value is None:
            return None

        if isinstance(value, (int, float)):
            return float(value)

        str_value = str(value).lower().strip()

        # Try to parse common duration formats
        patterns = [
            (r'^(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?$', 1),  # seconds
            (r'^(\d+(?:\.\d+)?)\s*m(?:in(?:ute)?s?)?$', 60),  # minutes
            (r'^(\d+(?:\.\d+)?)\s*h(?:our)?s?$', 3600),  # hours
            (r'^(\d+(?:\.\d+)?)\s*ms$', 0.001),  # milliseconds
        ]

        for pattern, multiplier in patterns:
            match = re.match(pattern, str_value)
            if match:
                return float(match.group(1)) * multiplier

        # Try plain number
        try:
            return float(str_value)
        except ValueError:
            return None


class UrlHostChangedRule(Rule):
    """Rule for detecting changes to URL hosts."""

    URL_PATTERNS = [
        r'url',
        r'endpoint',
        r'host',
        r'server',
        r'api[_-]?base',
        r'base[_-]?url',
    ]

    def __init__(self):
        super().__init__(
            name="url_host_changed",
            description="Detects when URL or host values change",
        )
        self._patterns = [re.compile(p, re.IGNORECASE) for p in self.URL_PATTERNS]
        self._url_re = re.compile(r'https?://([^/:\s]+)', re.IGNORECASE)

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        # Check if this is a URL-related field
        is_url_field = False
        for pattern in self._patterns:
            if pattern.search(node.name) or pattern.search(node.path):
                is_url_field = True
                break

        if not is_url_field:
            return self._no_match()

        old_value = str(node.metadata.get("old_value", ""))
        new_value = str(node.metadata.get("new_value", ""))

        # Extract hosts from URLs
        old_host = self._extract_host(old_value)
        new_host = self._extract_host(new_value)

        if old_host and new_host and old_host != new_host:
            return self._match(
                score=8,
                reason=f"URL host changed: {old_host} -> {new_host}",
                details={
                    "old_host": old_host,
                    "new_host": new_host,
                    "old_value": old_value,
                    "new_value": new_value,
                },
            )

        # Even if we can't extract host, significant URL changes are risky
        if old_value != new_value and (
            old_value.startswith(('http://', 'https://')) or
            new_value.startswith(('http://', 'https://'))
        ):
            return self._match(
                score=6,
                reason=f"URL value changed: {node.path}",
                details={
                    "old_value": old_value,
                    "new_value": new_value,
                },
            )

        return self._no_match()

    def _extract_host(self, url: str) -> Optional[str]:
        """Extract the host from a URL."""
        match = self._url_re.search(url)
        if match:
            return match.group(1).lower()
        return None


class PortChangedRule(Rule):
    """Rule for detecting port changes."""

    PORT_PATTERNS = [
        r'port',
        r'listen',
    ]

    def __init__(self):
        super().__init__(
            name="port_changed",
            description="Detects when port numbers change",
        )
        self._patterns = [re.compile(p, re.IGNORECASE) for p in self.PORT_PATTERNS]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        # Check if this is a port-related field
        is_port_field = False
        for pattern in self._patterns:
            if pattern.search(node.name) or pattern.search(node.path):
                is_port_field = True
                break

        if not is_port_field:
            return self._no_match()

        old_value = node.metadata.get("old_value")
        new_value = node.metadata.get("new_value")

        try:
            old_port = int(str(old_value))
            new_port = int(str(new_value))

            if old_port != new_port:
                return self._match(
                    score=7,
                    reason=f"Port changed: {old_port} -> {new_port}",
                    details={
                        "old_port": old_port,
                        "new_port": new_port,
                    },
                )
        except (ValueError, TypeError):
            pass

        return self._no_match()


class RequiredFieldAddedRule(Rule):
    """Rule for detecting addition of required fields."""

    REQUIRED_PATTERNS = [
        r'required',
        r'mandatory',
        r'must[_-]?have',
    ]

    def __init__(self):
        super().__init__(
            name="required_field_added",
            description="Detects when new required fields are added",
        )
        self._patterns = [re.compile(p, re.IGNORECASE) for p in self.REQUIRED_PATTERNS]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.ADDED:
            return self._no_match()

        # Check if this is a required field
        for pattern in self._patterns:
            if pattern.search(node.name) or pattern.search(node.path):
                return self._match(
                    score=8,
                    reason=f"Required field added: {node.path}",
                    details={
                        "pattern": pattern.pattern,
                    },
                )

        return self._no_match()


class DefaultValueRemovedRule(Rule):
    """Rule for detecting removal of default values."""

    DEFAULT_PATTERNS = [
        r'default',
        r'fallback',
    ]

    def __init__(self):
        super().__init__(
            name="default_value_removed",
            description="Detects when default values are removed",
        )
        self._patterns = [re.compile(p, re.IGNORECASE) for p in self.DEFAULT_PATTERNS]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.REMOVED:
            return self._no_match()

        # Check if this is a default value
        for pattern in self._patterns:
            if pattern.search(node.name) or pattern.search(node.path):
                return self._match(
                    score=6,
                    reason=f"Default value removed: {node.path}",
                    details={
                        "pattern": pattern.pattern,
                        "old_value": node.metadata.get("old_value"),
                    },
                )

        return self._no_match()


class EnvironmentSpecificRule(Rule):
    """Rule for detecting environment-specific changes."""

    ENV_PATTERNS = [
        (r'prod(?:uction)?', 9, "Production"),
        (r'staging', 7, "Staging"),
        (r'dev(?:elopment)?', 4, "Development"),
        (r'test(?:ing)?', 3, "Testing"),
    ]

    def __init__(self):
        super().__init__(
            name="environment_specific",
            description="Detects changes to environment-specific configuration",
        )
        self._patterns = [
            (re.compile(p, re.IGNORECASE), score, env_name)
            for p, score, env_name in self.ENV_PATTERNS
        ]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type not in {ChangeType.MODIFIED, ChangeType.REMOVED}:
            return self._no_match()

        for pattern, score, env_name in self._patterns:
            if pattern.search(node.path) or pattern.search(node.name):
                return self._match(
                    score=score,
                    reason=f"{env_name} configuration changed: {node.path}",
                    details={
                        "environment": env_name,
                        "change_type": node.change_type.name,
                    },
                )

        return self._no_match()
