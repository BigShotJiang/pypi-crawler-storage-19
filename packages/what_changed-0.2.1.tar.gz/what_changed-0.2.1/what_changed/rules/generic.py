"""Generic rules that apply to all types of changes."""

import re
from typing import Optional

from what_changed.diff.semantic_diff import ChangeType
from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
from what_changed.rules.base import Rule, RuleResult


class RemovedEntityRule(Rule):
    """Rule for detecting removed entities."""

    def __init__(self):
        super().__init__(
            name="removed_entity",
            description="Detects when an entity is removed",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.REMOVED:
            return self._no_match()

        # Score based on node type
        scores = {
            NodeType.FILE: 6,
            NodeType.DIRECTORY: 7,
            NodeType.CONFIG_KEY: 7,
            NodeType.ENDPOINT: 10,
            NodeType.SYMBOL: 8,
            NodeType.ENTITY: 5,
        }
        score = scores.get(node.node_type, 5)

        return self._match(
            score=score,
            reason=f"Removed {node.node_type.name.lower()}: {node.name}",
            details={"node_type": node.node_type.name},
        )


class TypeChangedRule(Rule):
    """Rule for detecting type changes."""

    def __init__(self):
        super().__init__(
            name="type_changed",
            description="Detects when a value's type changes",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.TYPE_CHANGED:
            return self._no_match()

        old_type = node.metadata.get("old_type", "unknown")
        new_type = node.metadata.get("new_type", "unknown")

        # Some type changes are more breaking than others
        breaking_combinations = {
            ("string", "integer"): 9,
            ("string", "boolean"): 9,
            ("integer", "string"): 7,
            ("object", "string"): 9,
            ("array", "string"): 9,
            ("string", "object"): 8,
            ("string", "array"): 8,
        }

        score = breaking_combinations.get((old_type, new_type), 7)

        return self._match(
            score=score,
            reason=f"Type changed from {old_type} to {new_type}",
            details={
                "old_type": old_type,
                "new_type": new_type,
            },
        )


class RenamedEntityRule(Rule):
    """Rule for detecting renamed entities."""

    def __init__(self):
        super().__init__(
            name="renamed_entity",
            description="Detects when an entity is renamed",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.RENAMED:
            return self._no_match()

        old_name = node.metadata.get("old_name", "")
        new_name = node.metadata.get("new_name", "")

        # Renaming public interfaces is riskier
        score = 4

        # Check if this looks like a public/exported name
        if not old_name.startswith('_') and not new_name.startswith('_'):
            score = 6

        return self._match(
            score=score,
            reason=f"Renamed: {old_name} -> {new_name}",
            details={
                "old_name": old_name,
                "new_name": new_name,
            },
        )


class AddedEntityRule(Rule):
    """Rule for detecting added entities."""

    def __init__(self):
        super().__init__(
            name="added_entity",
            description="Detects when an entity is added",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.ADDED:
            return self._no_match()

        # Added entities are usually safe, but some patterns are risky
        score = 2

        # Check for required field patterns in name
        name_lower = node.name.lower()
        if any(kw in name_lower for kw in ['required', 'mandatory', 'must']):
            score = 8
            return self._match(
                score=score,
                reason=f"Added possibly required field: {node.name}",
                details={"possibly_required": True},
            )

        return self._match(
            score=score,
            reason=f"Added {node.node_type.name.lower()}: {node.name}",
            details={"node_type": node.node_type.name},
        )


class ModifiedValueRule(Rule):
    """Rule for detecting modified values with magnitude assessment."""

    def __init__(self):
        super().__init__(
            name="modified_value",
            description="Detects value modifications and assesses magnitude",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        old_value = node.metadata.get("old_value")
        new_value = node.metadata.get("new_value")

        # Default score for modifications
        score = 3

        # Analyze the magnitude of change
        if old_value is not None and new_value is not None:
            old_str = str(old_value)
            new_str = str(new_value)

            # Large text changes
            if len(new_str) > 100 or len(old_str) > 100:
                diff_ratio = abs(len(new_str) - len(old_str)) / max(len(old_str), len(new_str), 1)
                if diff_ratio > 0.5:
                    score = 5

            # Check for numeric changes
            try:
                old_num = float(old_str)
                new_num = float(new_str)
                if old_num != 0:
                    change_ratio = abs(new_num - old_num) / abs(old_num)
                    if change_ratio > 1.0:  # More than 100% change
                        score = 6
                    elif change_ratio > 0.5:  # More than 50% change
                        score = 4
            except (ValueError, TypeError):
                pass

        return self._match(
            score=score,
            reason=f"Modified value at: {node.path}",
            details={
                "old_value": old_value,
                "new_value": new_value,
            },
        )


class CriticalPathRule(Rule):
    """Rule for detecting changes to critical paths/keys."""

    CRITICAL_PATTERNS = [
        r'password',
        r'secret',
        r'api[_-]?key',
        r'token',
        r'credential',
        r'auth',
        r'private[_-]?key',
        r'certificate',
        r'ssl',
        r'tls',
    ]

    SENSITIVE_PATTERNS = [
        r'database',
        r'db[_-]?host',
        r'connection[_-]?string',
        r'endpoint',
        r'url',
        r'host',
        r'port',
        r'timeout',
    ]

    def __init__(self):
        super().__init__(
            name="critical_path",
            description="Detects changes to security-critical or sensitive paths",
        )
        self._critical_re = [re.compile(p, re.IGNORECASE) for p in self.CRITICAL_PATTERNS]
        self._sensitive_re = [re.compile(p, re.IGNORECASE) for p in self.SENSITIVE_PATTERNS]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path_lower = node.path.lower()
        name_lower = node.name.lower()

        # Check for critical patterns
        for pattern in self._critical_re:
            if pattern.search(path_lower) or pattern.search(name_lower):
                return self._match(
                    score=9,
                    reason=f"Change to security-critical path: {node.path}",
                    details={"pattern": "critical", "matched": pattern.pattern},
                )

        # Check for sensitive patterns
        for pattern in self._sensitive_re:
            if pattern.search(path_lower) or pattern.search(name_lower):
                return self._match(
                    score=7,
                    reason=f"Change to sensitive configuration: {node.path}",
                    details={"pattern": "sensitive", "matched": pattern.pattern},
                )

        return self._no_match()


class BreakingNamePatternRule(Rule):
    """Rule for detecting names that suggest breaking changes."""

    BREAKING_PATTERNS = [
        (r'deprecated', 7, "Deprecated entity changed"),
        (r'legacy', 6, "Legacy entity changed"),
        (r'v\d+', 5, "Versioned entity changed"),
        (r'breaking', 9, "Entity marked as breaking"),
        (r'migration', 7, "Migration-related change"),
    ]

    def __init__(self):
        super().__init__(
            name="breaking_name_pattern",
            description="Detects changes to entities with breaking-related names",
        )
        self._patterns = [
            (re.compile(p, re.IGNORECASE), score, reason)
            for p, score, reason in self.BREAKING_PATTERNS
        ]

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path_lower = node.path.lower()
        name_lower = node.name.lower()

        for pattern, score, reason in self._patterns:
            if pattern.search(path_lower) or pattern.search(name_lower):
                return self._match(
                    score=score,
                    reason=f"{reason}: {node.name}",
                    details={"pattern": pattern.pattern},
                )

        return self._no_match()
