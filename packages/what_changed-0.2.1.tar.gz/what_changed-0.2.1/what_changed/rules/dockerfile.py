"""Rules specific to Dockerfile changes."""

import re
from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
from what_changed.diff.semantic_diff import ChangeType
from what_changed.rules.base import Rule, RuleResult


class BaseImageChangedRule(Rule):
    """Detects when Docker base image changes."""

    def __init__(self):
        super().__init__(
            name="base_image_changed",
            description="Detects when the Docker base image is changed (FROM instruction)",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        path = node.path.upper()
        name = node.name.upper()

        # Check if this is a FROM instruction (entity name is "FROM" or path contains FROM)
        if name != "FROM" and "FROM" not in path and "INSTRUCTIONS.FROM" not in path:
            return self._no_match()

        old_value = str(node.metadata.get("old_value", ""))
        new_value = str(node.metadata.get("new_value", ""))

        # Extract image names
        old_image = self._extract_image_name(old_value)
        new_image = self._extract_image_name(new_value)
        old_tag = self._extract_tag(old_value)
        new_tag = self._extract_tag(new_value)

        # Different base image entirely = BREAKING
        if old_image != new_image:
            return self._match(
                score=9,
                reason=f"Base image changed: {old_image} -> {new_image}",
                details={"old_image": old_value, "new_image": new_value},
            )

        # Major version change = BREAKING
        old_major = self._extract_major_version(old_tag)
        new_major = self._extract_major_version(new_tag)
        if old_major is not None and new_major is not None and old_major != new_major:
            return self._match(
                score=8,
                reason=f"Base image major version changed: {old_tag} -> {new_tag}",
                details={"old_tag": old_tag, "new_tag": new_tag},
            )

        # Minor/patch version change = RISKY
        if old_tag != new_tag:
            return self._match(
                score=5,
                reason=f"Base image tag changed: {old_tag} -> {new_tag}",
                details={"old_tag": old_tag, "new_tag": new_tag},
            )

        return self._no_match()

    def _extract_image_name(self, value: str) -> str:
        """Extract image name without tag."""
        parts = value.split(":")
        return parts[0].strip()

    def _extract_tag(self, value: str) -> str:
        """Extract tag from image reference."""
        parts = value.split(":")
        return parts[1].strip() if len(parts) > 1 else "latest"

    def _extract_major_version(self, tag: str) -> int | None:
        """Extract major version number from tag."""
        match = re.search(r"(\d+)", tag)
        if match:
            return int(match.group(1))
        return None


class DockerPortChangedRule(Rule):
    """Detects when Docker EXPOSE ports change."""

    def __init__(self):
        super().__init__(
            name="docker_port_changed",
            description="Detects when exposed ports change in Dockerfile",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path = node.path.upper()
        name = node.name.upper()

        if name != "EXPOSE" and "EXPOSE" not in path:
            return self._no_match()

        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=8,
                reason=f"Exposed port removed: {node.metadata.get('old_value', 'unknown')}",
            )

        if node.change_type == ChangeType.MODIFIED:
            old_val = node.metadata.get("old_value", "")
            new_val = node.metadata.get("new_value", "")
            return self._match(
                score=7,
                reason=f"Exposed port changed: {old_val} -> {new_val}",
            )

        if node.change_type == ChangeType.ADDED:
            return self._match(
                score=3,
                reason=f"New port exposed: {node.metadata.get('new_value', 'unknown')}",
            )

        return self._no_match()


class DockerEnvChangedRule(Rule):
    """Detects when Docker ENV variables change."""

    def __init__(self):
        super().__init__(
            name="docker_env_changed",
            description="Detects changes to Docker environment variables",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path = node.path.upper()
        name = node.name.upper()

        if name != "ENV" and "ENV" not in path:
            return self._no_match()

        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=7,
                reason=f"Environment variable removed",
            )

        if node.change_type == ChangeType.MODIFIED:
            return self._match(
                score=5,
                reason=f"Environment variable modified",
            )

        if node.change_type == ChangeType.ADDED:
            return self._match(
                score=3,
                reason=f"Environment variable added",
            )

        return self._no_match()


class DockerEntrypointChangedRule(Rule):
    """Detects when Docker ENTRYPOINT or CMD changes."""

    def __init__(self):
        super().__init__(
            name="docker_entrypoint_changed",
            description="Detects changes to Docker ENTRYPOINT or CMD",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path = node.path.upper()
        name = node.name.upper()

        is_entrypoint = name == "ENTRYPOINT" or "ENTRYPOINT" in path
        is_cmd = name == "CMD" or ("CMD" in path and "HEALTHCHECK" not in path)

        if not (is_entrypoint or is_cmd):
            return self._no_match()

        instruction = "ENTRYPOINT" if is_entrypoint else "CMD"

        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=9,
                reason=f"{instruction} removed - container may not start",
            )

        if node.change_type == ChangeType.MODIFIED:
            return self._match(
                score=7,
                reason=f"{instruction} changed - container behavior will differ",
            )

        if node.change_type == ChangeType.ADDED:
            return self._match(
                score=4,
                reason=f"{instruction} added",
            )

        return self._no_match()


class DockerHealthcheckRule(Rule):
    """Detects changes to Docker HEALTHCHECK."""

    def __init__(self):
        super().__init__(
            name="docker_healthcheck_changed",
            description="Detects changes to Docker HEALTHCHECK",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path = node.path.upper()
        name = node.name.upper()

        if name != "HEALTHCHECK" and "HEALTHCHECK" not in path:
            return self._no_match()

        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=6,
                reason="HEALTHCHECK removed - container health monitoring disabled",
            )

        if node.change_type == ChangeType.MODIFIED:
            return self._match(
                score=4,
                reason="HEALTHCHECK modified",
            )

        if node.change_type == ChangeType.ADDED:
            return self._match(
                score=2,
                reason="HEALTHCHECK added - good practice",
            )

        return self._no_match()


class DockerRunChangedRule(Rule):
    """Detects changes to Docker RUN commands."""

    def __init__(self):
        super().__init__(
            name="docker_run_changed",
            description="Detects changes to Docker RUN commands",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path = node.path.upper()
        name = node.name.upper()

        if name != "RUN" and "RUN" not in path:
            return self._no_match()

        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=6,
                reason="Build step removed",
            )

        if node.change_type == ChangeType.MODIFIED:
            old_val = str(node.metadata.get("old_value", ""))
            new_val = str(node.metadata.get("new_value", ""))

            # Check for security-related changes
            security_keywords = ["chmod", "chown", "adduser", "useradd", "sudo", "apt", "yum", "apk"]
            if any(kw in new_val.lower() for kw in security_keywords):
                return self._match(
                    score=6,
                    reason="Security-relevant RUN command modified",
                )

            return self._match(
                score=4,
                reason="Build step modified",
            )

        if node.change_type == ChangeType.ADDED:
            return self._match(
                score=3,
                reason="Build step added",
            )

        return self._no_match()


def get_dockerfile_rules() -> list[Rule]:
    """Get all Dockerfile-related rules."""
    return [
        BaseImageChangedRule(),
        DockerPortChangedRule(),
        DockerEnvChangedRule(),
        DockerEntrypointChangedRule(),
        DockerHealthcheckRule(),
        DockerRunChangedRule(),
    ]
