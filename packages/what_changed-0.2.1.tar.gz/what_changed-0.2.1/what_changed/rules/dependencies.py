"""Rules for detecting breaking changes in dependency files."""

import re
from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
from what_changed.diff.semantic_diff import ChangeType
from what_changed.rules.base import Rule, RuleResult


class RemovedDependencyRule(Rule):
    """Detects removed dependencies."""

    def __init__(self):
        super().__init__(
            name="removed_dependency",
            description="Detects when a dependency is removed",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.REMOVED:
            return self._no_match()

        # Check if it's a dependency
        if not self._is_dependency(node):
            return self._no_match()

        # Dev dependencies are less critical
        if self._is_dev_dependency(node):
            return self._match(
                score=5,
                reason=f"Removed dev dependency: {node.name}",
            )

        return self._match(
            score=8,
            reason=f"Removed dependency: {node.name}",
        )

    def _is_dependency(self, node: ChangeNode) -> bool:
        path = node.path.lower()
        return any(kw in path for kw in [
            "dependencies", "require", "packages", "gems", "pkg_"
        ])

    def _is_dev_dependency(self, node: ChangeNode) -> bool:
        path = node.path.lower()
        return any(kw in path for kw in [
            "devdependencies", "dev-dependencies", "dev_", "test"
        ])


class MajorVersionBumpRule(Rule):
    """Detects major version bumps in dependencies."""

    def __init__(self):
        super().__init__(
            name="major_version_bump",
            description="Detects major version bumps that may introduce breaking changes",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        # Check if it's a version change
        old_value = node.metadata.get("old_value")
        new_value = node.metadata.get("new_value")

        if not isinstance(old_value, str) or not isinstance(new_value, str):
            return self._no_match()

        old_major = self._extract_major(old_value)
        new_major = self._extract_major(new_value)

        if old_major is None or new_major is None:
            return self._no_match()

        if new_major > old_major:
            return self._match(
                score=7,
                reason=f"Major version bump: {node.name} ({old_value} -> {new_value})",
            )

        return self._no_match()

    def _extract_major(self, version: str) -> int | None:
        # Handle various version formats: ^1.0.0, ~1.0.0, >=1.0.0, ==1.0.0, 1.0.0
        match = re.search(r"(\d+)", version)
        if match:
            return int(match.group(1))
        return None


class AddedDependencyRule(Rule):
    """Detects added dependencies."""

    def __init__(self):
        super().__init__(
            name="added_dependency",
            description="Detects when a new dependency is added",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.ADDED:
            return self._no_match()

        # Check if it's a dependency
        path = node.path.lower()
        if not any(kw in path for kw in [
            "dependencies", "require", "packages", "gems", "pkg_"
        ]):
            return self._no_match()

        return self._match(
            score=3,
            reason=f"Added dependency: {node.name}",
        )


class ChangedScriptRule(Rule):
    """Detects changes to package scripts."""

    def __init__(self):
        super().__init__(
            name="changed_script",
            description="Detects changes to npm/project scripts",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if "scripts" not in node.path.lower():
            return self._no_match()

        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=6,
                reason=f"Removed script: {node.name}",
            )

        if node.change_type == ChangeType.MODIFIED:
            return self._match(
                score=4,
                reason=f"Modified script: {node.name}",
            )

        return self._no_match()


class ChangedEngineRule(Rule):
    """Detects changes to engine/runtime requirements."""

    def __init__(self):
        super().__init__(
            name="changed_engine",
            description="Detects changes to engine/runtime version requirements",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        path = node.path.lower()
        name = node.name.lower()

        # Check for engine requirements
        is_engine = any(kw in path or kw in name for kw in [
            "engines", "python_requires", "requires_python", "go_version",
            "node", "npm", "edition"
        ])

        if not is_engine:
            return self._no_match()

        if node.change_type in (ChangeType.MODIFIED, ChangeType.ADDED):
            return self._match(
                score=7,
                reason=f"Changed runtime requirement: {node.name}",
            )

        return self._no_match()


class ConstraintRelaxedRule(Rule):
    """Detects when version constraints are relaxed."""

    def __init__(self):
        super().__init__(
            name="constraint_relaxed",
            description="Detects when version constraints become less strict",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        old_value = str(node.metadata.get("old_value", ""))
        new_value = str(node.metadata.get("new_value", ""))

        # Check if constraint was relaxed (pinned -> unpinned, == -> ^, etc.)
        old_strict = self._is_strict_constraint(old_value)
        new_strict = self._is_strict_constraint(new_value)

        if old_strict and not new_strict:
            return self._match(
                score=5,
                reason=f"Relaxed version constraint: {node.name} ({old_value} -> {new_value})",
            )

        return self._no_match()

    def _is_strict_constraint(self, version: str) -> bool:
        # Strict: ==, exact version without prefix
        if version.startswith("=="):
            return True
        if re.match(r"^\d+\.\d+\.\d+$", version):
            return True
        return False


class ConstraintTightenedRule(Rule):
    """Detects when version constraints are tightened."""

    def __init__(self):
        super().__init__(
            name="constraint_tightened",
            description="Detects when version constraints become more strict",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        old_value = str(node.metadata.get("old_value", ""))
        new_value = str(node.metadata.get("new_value", ""))

        # Check if constraint was tightened (^ -> ==, etc.)
        old_strict = self._is_strict_constraint(old_value)
        new_strict = self._is_strict_constraint(new_value)

        if not old_strict and new_strict:
            return self._match(
                score=4,
                reason=f"Tightened version constraint: {node.name} ({old_value} -> {new_value})",
            )

        return self._no_match()

    def _is_strict_constraint(self, version: str) -> bool:
        if version.startswith("=="):
            return True
        if re.match(r"^\d+\.\d+\.\d+$", version):
            return True
        return False


def get_dependency_rules() -> list[Rule]:
    """Get all dependency-related rules."""
    return [
        RemovedDependencyRule(),
        MajorVersionBumpRule(),
        AddedDependencyRule(),
        ChangedScriptRule(),
        ChangedEngineRule(),
        ConstraintRelaxedRule(),
        ConstraintTightenedRule(),
    ]
