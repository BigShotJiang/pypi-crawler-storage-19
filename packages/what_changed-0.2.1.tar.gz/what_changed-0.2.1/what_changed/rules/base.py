"""Base classes for heuristic rules."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional

from what_changed.graph.model import ChangeNode, ChangeGraph


@dataclass
class RuleResult:
    """Result of applying a rule to a change."""

    rule_name: str
    matched: bool
    score: int = 0
    reason: str = ""
    details: dict[str, Any] = field(default_factory=dict)

    @property
    def description(self) -> str:
        """Get a description of why this rule matched."""
        if not self.matched:
            return ""
        return f"[{self.rule_name}] {self.reason} (score: {self.score})"


class Rule(ABC):
    """
    Abstract base class for heuristic rules.

    Rules evaluate changes and assign risk scores based on heuristics.
    Each rule focuses on a specific type of change pattern.
    """

    def __init__(self, name: str, description: str):
        """
        Initialize a rule.

        Args:
            name: Short name for the rule
            description: Human-readable description of what the rule detects
        """
        self.name = name
        self.description = description

    @abstractmethod
    def evaluate(
        self,
        node: ChangeNode,
        graph: ChangeGraph,
    ) -> RuleResult:
        """
        Evaluate a change node against this rule.

        Args:
            node: The change node to evaluate
            graph: The full change graph for context

        Returns:
            RuleResult indicating if the rule matched and the score
        """
        ...

    def _no_match(self) -> RuleResult:
        """Create a non-matching result."""
        return RuleResult(
            rule_name=self.name,
            matched=False,
        )

    def _match(
        self,
        score: int,
        reason: str,
        details: Optional[dict[str, Any]] = None,
    ) -> RuleResult:
        """Create a matching result."""
        return RuleResult(
            rule_name=self.name,
            matched=True,
            score=score,
            reason=reason,
            details=details or {},
        )
