"""Rule engine for applying heuristic rules to change graphs."""

from typing import Optional

from what_changed.graph.model import ChangeGraph, ChangeNode, RiskLevel
from what_changed.rules.base import Rule, RuleResult


class RuleEngine:
    """
    Engine for applying heuristic rules to change graphs.

    The engine maintains a collection of rules and applies them to each
    change node in a graph, computing risk scores and levels.
    """

    def __init__(self) -> None:
        self._rules: list[Rule] = []

    def register(self, rule: Rule) -> None:
        """Register a rule with the engine."""
        self._rules.append(rule)

    def register_many(self, rules: list[Rule]) -> None:
        """Register multiple rules."""
        self._rules.extend(rules)

    def evaluate_node(
        self,
        node: ChangeNode,
        graph: ChangeGraph,
    ) -> list[RuleResult]:
        """
        Evaluate all rules against a single node.

        Returns:
            List of matching rule results
        """
        results: list[RuleResult] = []

        for rule in self._rules:
            result = rule.evaluate(node, graph)
            if result.matched:
                results.append(result)

        return results

    def score_node(
        self,
        node: ChangeNode,
        graph: ChangeGraph,
    ) -> tuple[int, list[RuleResult]]:
        """
        Compute the risk score for a node.

        The score is the maximum score from all matching rules.

        Returns:
            Tuple of (score, list of matching results)
        """
        results = self.evaluate_node(node, graph)

        if not results:
            return 0, []

        # Use maximum score (most severe matching rule)
        max_score = max(r.score for r in results)

        return max_score, results

    def apply(self, graph: ChangeGraph) -> dict[str, list[RuleResult]]:
        """
        Apply all rules to all nodes in a graph.

        This updates each node's risk_score and risk_level, and returns
        a mapping of node IDs to their matching rule results.

        Returns:
            Dict mapping node IDs to their matching rule results
        """
        all_results: dict[str, list[RuleResult]] = {}

        for node in graph.get_nodes():
            # Skip root and intermediate nodes
            if node.change_type is None:
                continue

            score, results = self.score_node(node, graph)

            # Update node
            node.risk_score = score
            node.risk_level = RiskLevel.from_score(score)

            all_results[node.id] = results

        return all_results

    @property
    def rule_count(self) -> int:
        """Number of registered rules."""
        return len(self._rules)

    @property
    def rules(self) -> list[Rule]:
        """Get all registered rules."""
        return self._rules.copy()


def create_default_engine() -> RuleEngine:
    """
    Create a rule engine with all default rules.

    Returns:
        RuleEngine with standard rules registered
    """
    from what_changed.rules.generic import (
        RemovedEntityRule,
        TypeChangedRule,
        RenamedEntityRule,
        AddedEntityRule,
        ModifiedValueRule,
        CriticalPathRule,
        BreakingNamePatternRule,
    )
    from what_changed.rules.config import (
        TimeoutDecreasedRule,
        UrlHostChangedRule,
        PortChangedRule,
        RequiredFieldAddedRule,
        DefaultValueRemovedRule,
        EnvironmentSpecificRule,
    )

    engine = RuleEngine()

    # Register generic rules
    engine.register_many([
        RemovedEntityRule(),
        TypeChangedRule(),
        RenamedEntityRule(),
        AddedEntityRule(),
        ModifiedValueRule(),
        CriticalPathRule(),
        BreakingNamePatternRule(),
    ])

    # Register config-specific rules
    engine.register_many([
        TimeoutDecreasedRule(),
        UrlHostChangedRule(),
        PortChangedRule(),
        RequiredFieldAddedRule(),
        DefaultValueRemovedRule(),
        EnvironmentSpecificRule(),
    ])

    # Register API-specific rules
    from what_changed.rules.api import get_api_rules
    engine.register_many(get_api_rules())

    # Register dependency-specific rules
    from what_changed.rules.dependencies import get_dependency_rules
    engine.register_many(get_dependency_rules())

    # Register Dockerfile-specific rules
    from what_changed.rules.dockerfile import get_dockerfile_rules
    engine.register_many(get_dockerfile_rules())

    # Register directory-specific rules
    from what_changed.rules.directory import get_directory_rules
    engine.register_many(get_directory_rules())

    return engine
