"""Rules for detecting breaking changes in API specifications."""

from what_changed.graph.model import ChangeNode, ChangeGraph, NodeType
from what_changed.diff.semantic_diff import ChangeType
from what_changed.rules.base import Rule, RuleResult


class RemovedEndpointRule(Rule):
    """Detects removed API endpoints."""

    def __init__(self):
        super().__init__(
            name="removed_endpoint",
            description="Detects when an API endpoint is removed",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.REMOVED:
            return self._no_match()

        # Check if this is an endpoint
        if node.node_type != NodeType.ENDPOINT and "paths." not in node.path:
            return self._no_match()

        # Check if it's a path or an operation
        if any(m in node.path for m in [".get", ".post", ".put", ".patch", ".delete"]):
            return self._match(
                score=10,
                reason=f"Removed API operation: {node.name}",
            )

        if node.path.startswith("paths."):
            return self._match(
                score=10,
                reason=f"Removed API endpoint: {node.name}",
            )

        return self._no_match()


class RemovedParameterRule(Rule):
    """Detects removed required parameters."""

    def __init__(self):
        super().__init__(
            name="removed_parameter",
            description="Detects when an API parameter is removed",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.REMOVED:
            return self._no_match()

        if "parameters" not in node.path:
            return self._no_match()

        # Check if it was a required parameter
        is_required = node.metadata.get("required", False)
        old_value = node.metadata.get("old_value", {})
        if isinstance(old_value, dict):
            is_required = old_value.get("required", False)

        if is_required:
            return self._match(
                score=9,
                reason=f"Removed required parameter: {node.name}",
            )

        return self._match(
            score=5,
            reason=f"Removed optional parameter: {node.name}",
        )


class AddedRequiredParameterRule(Rule):
    """Detects added required parameters (breaking for clients)."""

    def __init__(self):
        super().__init__(
            name="added_required_parameter",
            description="Detects when a required API parameter is added",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.ADDED:
            return self._no_match()

        if "parameters" not in node.path:
            return self._no_match()

        # Check if it's a required parameter
        new_value = node.metadata.get("new_value", {})
        is_required = False

        if isinstance(new_value, dict):
            is_required = new_value.get("required", False)

        if is_required:
            return self._match(
                score=8,
                reason=f"Added required parameter: {node.name}",
            )

        return self._no_match()


class ChangedResponseCodeRule(Rule):
    """Detects changes to response codes."""

    def __init__(self):
        super().__init__(
            name="changed_response_code",
            description="Detects changes to API response codes",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if "responses" not in node.path:
            return self._no_match()

        # Removed response code
        if node.change_type == ChangeType.REMOVED:
            # Removing success responses is breaking
            if node.name.startswith("2"):
                return self._match(
                    score=8,
                    reason=f"Removed success response: {node.name}",
                )
            return self._match(
                score=4,
                reason=f"Removed response code: {node.name}",
            )

        # Added response code
        if node.change_type == ChangeType.ADDED:
            return self._match(
                score=2,
                reason=f"Added response code: {node.name}",
            )

        return self._no_match()


class ChangedSchemaRule(Rule):
    """Detects breaking changes to schemas."""

    def __init__(self):
        super().__init__(
            name="changed_schema",
            description="Detects breaking changes to API schemas",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if "schemas." not in node.path and "definitions." not in node.path:
            return self._no_match()

        # Removed schema
        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=9,
                reason=f"Removed schema: {node.name}",
            )

        # Type changed
        if node.change_type == ChangeType.TYPE_CHANGED:
            return self._match(
                score=9,
                reason=f"Schema type changed: {node.name}",
            )

        # Modified schema
        if node.change_type == ChangeType.MODIFIED:
            # Check for removed required fields
            old_value = node.metadata.get("old_value", {})
            new_value = node.metadata.get("new_value", {})

            if isinstance(old_value, dict) and isinstance(new_value, dict):
                old_required = set(old_value.get("required", []))
                new_required = set(new_value.get("required", []))

                # Removed required fields is breaking
                removed_required = old_required - new_required
                if removed_required:
                    return self._match(
                        score=7,
                        reason=f"Required fields removed from schema: {', '.join(removed_required)}",
                    )

                # Added required fields is breaking
                added_required = new_required - old_required
                if added_required:
                    return self._match(
                        score=8,
                        reason=f"New required fields added to schema: {', '.join(added_required)}",
                    )

        return self._no_match()


class DeprecatedEndpointRule(Rule):
    """Detects endpoints marked as deprecated."""

    def __init__(self):
        super().__init__(
            name="deprecated_endpoint",
            description="Detects when endpoints are marked deprecated",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.change_type != ChangeType.MODIFIED:
            return self._no_match()

        if "deprecated" not in node.name.lower():
            return self._no_match()

        old_value = node.metadata.get("old_value")
        new_value = node.metadata.get("new_value")

        # Newly deprecated
        if old_value is False and new_value is True:
            return self._match(
                score=6,
                reason="Endpoint marked as deprecated",
            )

        return self._no_match()


class ChangedSecurityRule(Rule):
    """Detects changes to security requirements."""

    def __init__(self):
        super().__init__(
            name="changed_security",
            description="Detects changes to API security requirements",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if "security" not in node.path.lower():
            return self._no_match()

        if node.change_type == ChangeType.REMOVED:
            return self._match(
                score=8,
                reason=f"Removed security scheme: {node.name}",
            )

        if node.change_type == ChangeType.ADDED:
            return self._match(
                score=7,
                reason=f"Added security requirement: {node.name}",
            )

        if node.change_type == ChangeType.MODIFIED:
            return self._match(
                score=7,
                reason=f"Modified security configuration: {node.name}",
            )

        return self._no_match()


class ChangedBasePathRule(Rule):
    """Detects changes to API base path or servers."""

    def __init__(self):
        super().__init__(
            name="changed_base_path",
            description="Detects changes to API base URL/path",
        )

    def evaluate(self, node: ChangeNode, graph: ChangeGraph) -> RuleResult:
        if node.name not in ("basePath", "servers") and "servers" not in node.path:
            return self._no_match()

        if node.change_type in (ChangeType.MODIFIED, ChangeType.REMOVED):
            return self._match(
                score=9,
                reason=f"API base URL changed: {node.name}",
            )

        return self._no_match()


def get_api_rules() -> list[Rule]:
    """Get all API-related rules."""
    return [
        RemovedEndpointRule(),
        RemovedParameterRule(),
        AddedRequiredParameterRule(),
        ChangedResponseCodeRule(),
        ChangedSchemaRule(),
        DeprecatedEndpointRule(),
        ChangedSecurityRule(),
        ChangedBasePathRule(),
    ]
