"""Git comparison utilities."""

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from what_changed.git.repository import GitRepository, GitError


@dataclass
class GitCompareSpec:
    """Specification for what to compare in git."""

    ref_a: str
    ref_b: str
    path: Optional[str] = None  # Specific file or directory to compare

    @classmethod
    def parse(cls, spec: str) -> "GitCompareSpec":
        """
        Parse a git comparison specification.

        Supports formats:
            - "HEAD~1..HEAD" or "HEAD~1...HEAD" - range syntax
            - "main..feature" - branch comparison
            - "v1.0..v2.0" - tag comparison
            - "abc123..def456" - commit comparison
            - "HEAD~1..HEAD:path/to/file" - with path
            - "main..feature:src/" - with directory path
        """
        # Check for path suffix
        path = None
        if ":" in spec and not spec.startswith(":"):
            # Split on last colon (to handle Windows paths correctly in ref)
            parts = spec.rsplit(":", 1)
            if len(parts) == 2 and parts[1]:
                spec = parts[0]
                path = parts[1]

        # Parse range
        if "..." in spec:
            parts = spec.split("...", 1)
        elif ".." in spec:
            parts = spec.split("..", 1)
        else:
            raise ValueError(
                f"Invalid git comparison spec: {spec}. "
                "Expected format: ref_a..ref_b or ref_a...ref_b"
            )

        if len(parts) != 2 or not parts[0] or not parts[1]:
            raise ValueError(
                f"Invalid git comparison spec: {spec}. "
                "Both refs must be specified: ref_a..ref_b"
            )

        return cls(ref_a=parts[0], ref_b=parts[1], path=path)


class GitComparer:
    """Compare files between git refs."""

    def __init__(self, repo_path: Optional[Path] = None):
        """
        Initialize git comparer.

        Args:
            repo_path: Path to git repository. Defaults to current directory.
        """
        self.repo_path = Path(repo_path) if repo_path else Path.cwd()
        self._repo: Optional[GitRepository] = None

    def _get_repo(self) -> GitRepository:
        """Get or create repository instance."""
        if self._repo is None:
            self._repo = GitRepository(self.repo_path)
        return self._repo

    def extract_for_comparison(
        self, spec: GitCompareSpec
    ) -> tuple[Path, Path]:
        """
        Extract files/directories for comparison.

        Args:
            spec: Git comparison specification

        Returns:
            Tuple of (path_a, path_b) pointing to extracted content
        """
        repo = self._get_repo()

        if spec.path:
            # Check if path is a file or directory in the newer ref
            try:
                # Try to get as file first
                path_a = repo.extract_file_to_temp(spec.ref_a, spec.path)
                path_b = repo.extract_file_to_temp(spec.ref_b, spec.path)
            except GitError:
                # Try as directory
                path_a = repo.extract_tree_to_temp(spec.ref_a, spec.path)
                path_b = repo.extract_tree_to_temp(spec.ref_b, spec.path)
        else:
            # Extract entire trees
            path_a = repo.extract_tree_to_temp(spec.ref_a)
            path_b = repo.extract_tree_to_temp(spec.ref_b)

        return path_a, path_b

    def get_changed_files(self, spec: GitCompareSpec) -> list[str]:
        """Get list of changed files between refs."""
        repo = self._get_repo()
        files = repo.list_changed_files(spec.ref_a, spec.ref_b)

        if spec.path:
            # Filter to only files under the specified path
            prefix = spec.path.rstrip("/") + "/"
            if spec.path.endswith("/"):
                files = [f for f in files if f.startswith(prefix) or f == spec.path.rstrip("/")]
            else:
                files = [f for f in files if f == spec.path or f.startswith(prefix)]

        return files

    def get_comparison_summary(self, spec: GitCompareSpec) -> dict:
        """Get summary information about the comparison."""
        repo = self._get_repo()

        info_a = repo.get_commit_info(spec.ref_a)
        info_b = repo.get_commit_info(spec.ref_b)
        changed_files = self.get_changed_files(spec)

        return {
            "ref_a": {
                "ref": spec.ref_a,
                "sha": info_a["sha"],
                "short_sha": info_a["short_sha"],
                "subject": info_a["subject"],
                "author": info_a["author_name"],
            },
            "ref_b": {
                "ref": spec.ref_b,
                "sha": info_b["sha"],
                "short_sha": info_b["short_sha"],
                "subject": info_b["subject"],
                "author": info_b["author_name"],
            },
            "changed_files_count": len(changed_files),
            "path_filter": spec.path,
        }

    def cleanup(self):
        """Clean up temporary files."""
        if self._repo:
            self._repo.cleanup()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
        return False


def parse_git_source(source: str) -> Optional[GitCompareSpec]:
    """
    Check if a source string is a git comparison spec.

    Returns GitCompareSpec if valid, None otherwise.
    """
    # Must contain .. or ... to be a git spec
    if ".." not in source:
        return None

    # Skip if it looks like a file path with ..
    if "/" in source.split("..")[0] or "\\" in source.split("..")[0]:
        # Could be a path like "../file.json"
        if source.startswith(".."):
            return None

    try:
        return GitCompareSpec.parse(source)
    except ValueError:
        return None


def is_git_repo(path: Optional[Path] = None) -> bool:
    """Check if path is inside a git repository."""
    try:
        GitRepository(path or Path.cwd())
        return True
    except GitError:
        return False
