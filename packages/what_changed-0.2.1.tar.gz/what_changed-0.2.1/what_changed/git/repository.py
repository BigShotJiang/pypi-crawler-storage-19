"""Git repository interaction utilities."""

import os
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


class GitError(Exception):
    """Git operation error."""

    pass


@dataclass
class GitRef:
    """A git reference (commit, branch, tag)."""

    ref: str
    commit_sha: str
    ref_type: str  # "commit", "branch", "tag"
    short_sha: str = ""

    def __post_init__(self):
        if not self.short_sha and self.commit_sha:
            self.short_sha = self.commit_sha[:7]


@dataclass
class GitFile:
    """A file extracted from a git commit."""

    path: str
    content: bytes
    temp_path: Optional[Path] = None


@dataclass
class GitRepository:
    """Interface for git repository operations."""

    path: Path
    _temp_dirs: list = field(default_factory=list, repr=False)

    def __post_init__(self):
        self.path = Path(self.path).resolve()
        if not self._is_git_repo():
            raise GitError(f"Not a git repository: {self.path}")

    def _is_git_repo(self) -> bool:
        """Check if path is inside a git repository."""
        try:
            self._run_git("rev-parse", "--git-dir")
            return True
        except GitError:
            return False

    def _run_git(self, *args: str, capture_output: bool = True) -> subprocess.CompletedProcess:
        """Run a git command."""
        cmd = ["git", "-C", str(self.path)] + list(args)
        try:
            result = subprocess.run(
                cmd,
                capture_output=capture_output,
                text=True,
                check=True,
            )
            return result
        except subprocess.CalledProcessError as e:
            raise GitError(f"Git command failed: {' '.join(cmd)}\n{e.stderr}")
        except FileNotFoundError:
            raise GitError("Git is not installed or not in PATH")

    def resolve_ref(self, ref: str) -> GitRef:
        """Resolve a reference to a commit SHA."""
        # Get full SHA
        try:
            result = self._run_git("rev-parse", ref)
            commit_sha = result.stdout.strip()
        except GitError as e:
            raise GitError(f"Cannot resolve reference '{ref}': {e}")

        # Determine ref type
        ref_type = "commit"

        # Check if it's a branch
        try:
            self._run_git("show-ref", "--verify", f"refs/heads/{ref}")
            ref_type = "branch"
        except GitError:
            pass

        # Check if it's a tag
        try:
            self._run_git("show-ref", "--verify", f"refs/tags/{ref}")
            ref_type = "tag"
        except GitError:
            pass

        return GitRef(ref=ref, commit_sha=commit_sha, ref_type=ref_type)

    def get_file_at_ref(self, ref: str, file_path: str) -> GitFile:
        """Get file content at a specific ref."""
        resolved = self.resolve_ref(ref)

        # Normalize path separators for git
        git_path = file_path.replace("\\", "/")

        try:
            result = subprocess.run(
                ["git", "-C", str(self.path), "show", f"{resolved.commit_sha}:{git_path}"],
                capture_output=True,
                check=True,
            )
            return GitFile(path=file_path, content=result.stdout)
        except subprocess.CalledProcessError as e:
            raise GitError(f"Cannot get file '{file_path}' at ref '{ref}': {e.stderr.decode()}")

    def extract_file_to_temp(self, ref: str, file_path: str) -> Path:
        """Extract a file at a ref to a temporary location."""
        git_file = self.get_file_at_ref(ref, file_path)

        # Create temp directory if needed
        temp_dir = tempfile.mkdtemp(prefix="what-changed-")
        self._temp_dirs.append(temp_dir)

        # Preserve file extension for type detection
        ext = Path(file_path).suffix
        name = Path(file_path).stem

        temp_path = Path(temp_dir) / f"{name}_{ref[:7]}{ext}"
        temp_path.write_bytes(git_file.content)

        return temp_path

    def extract_tree_to_temp(self, ref: str, tree_path: str = ".") -> Path:
        """Extract a directory tree at a ref to a temporary location."""
        resolved = self.resolve_ref(ref)

        # Create temp directory
        temp_dir = tempfile.mkdtemp(prefix="what-changed-")
        self._temp_dirs.append(temp_dir)

        target_dir = Path(temp_dir) / f"{resolved.short_sha}"
        target_dir.mkdir()

        # Get list of files in the tree
        git_tree_path = tree_path.replace("\\", "/")
        if git_tree_path == ".":
            git_tree_path = ""

        try:
            result = self._run_git(
                "ls-tree", "-r", "--name-only", resolved.commit_sha, git_tree_path
            )
            files = result.stdout.strip().split("\n") if result.stdout.strip() else []
        except GitError:
            files = []

        # Extract each file
        for file_path in files:
            if not file_path:
                continue

            try:
                git_file = self.get_file_at_ref(ref, file_path)

                # Determine target path
                if git_tree_path:
                    rel_path = file_path[len(git_tree_path):].lstrip("/")
                else:
                    rel_path = file_path

                target_path = target_dir / rel_path
                target_path.parent.mkdir(parents=True, exist_ok=True)
                target_path.write_bytes(git_file.content)
            except GitError:
                # Skip files that can't be read (e.g., submodules)
                continue

        return target_dir

    def list_changed_files(self, ref_a: str, ref_b: str) -> list[str]:
        """List files changed between two refs."""
        resolved_a = self.resolve_ref(ref_a)
        resolved_b = self.resolve_ref(ref_b)

        result = self._run_git(
            "diff", "--name-only", resolved_a.commit_sha, resolved_b.commit_sha
        )

        files = result.stdout.strip().split("\n") if result.stdout.strip() else []
        return [f for f in files if f]

    def get_commit_info(self, ref: str) -> dict:
        """Get commit information."""
        resolved = self.resolve_ref(ref)

        # Get commit details
        result = self._run_git(
            "log", "-1", "--format=%H%n%h%n%an%n%ae%n%at%n%s", resolved.commit_sha
        )

        lines = result.stdout.strip().split("\n")
        return {
            "sha": lines[0],
            "short_sha": lines[1],
            "author_name": lines[2],
            "author_email": lines[3],
            "timestamp": int(lines[4]),
            "subject": lines[5] if len(lines) > 5 else "",
        }

    def get_current_branch(self) -> Optional[str]:
        """Get current branch name."""
        try:
            result = self._run_git("rev-parse", "--abbrev-ref", "HEAD")
            branch = result.stdout.strip()
            return branch if branch != "HEAD" else None
        except GitError:
            return None

    def cleanup(self):
        """Clean up temporary files."""
        import shutil

        for temp_dir in self._temp_dirs:
            try:
                shutil.rmtree(temp_dir)
            except Exception:
                pass
        self._temp_dirs.clear()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
        return False
