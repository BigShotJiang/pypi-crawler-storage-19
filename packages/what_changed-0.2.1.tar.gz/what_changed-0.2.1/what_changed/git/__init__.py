"""Git integration for comparing commits, branches, and tags."""

from what_changed.git.repository import GitRepository, GitError
from what_changed.git.compare import GitComparer

__all__ = ["GitRepository", "GitComparer", "GitError"]
