"""CLI module for what-changed."""
