"""CLI entry point for what-changed."""

import sys
from pathlib import Path
from typing import Optional

# Fix Windows console encoding for Unicode support
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except (AttributeError, OSError):
        pass

import typer
from rich.console import Console

from what_changed import __version__
from what_changed.normalize import create_default_registry, NormalizationError
from what_changed.diff import SemanticDiff
from what_changed.graph import GraphBuilder
from what_changed.rules import create_default_engine
from what_changed.explain import Explainer
from what_changed.output import Renderer, OutputFormat, RenderConfig
from what_changed.graph.model import RiskLevel
from what_changed.git import GitComparer, GitError
from what_changed.git.compare import GitCompareSpec, is_git_repo


app = typer.Typer(
    name="what-changed",
    help="Compare anything and explain what changed and what might break.",
    no_args_is_help=True,
)

console = Console()


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        console.print(f"what-changed version {__version__}")
        raise typer.Exit()


@app.command()
def compare(
    source_a: str = typer.Argument(
        ...,
        help="First source (file, directory, or URL)",
    ),
    source_b: str = typer.Argument(
        ...,
        help="Second source (file, directory, or URL)",
    ),
    summary: bool = typer.Option(
        False,
        "--summary",
        "-s",
        help="Show only a brief summary",
    ),
    breaking_only: bool = typer.Option(
        False,
        "--breaking-only",
        "-b",
        help="Show only breaking changes",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON",
    ),
    graph: bool = typer.Option(
        False,
        "--graph",
        "-g",
        help="Show interactive graph TUI",
    ),
    stats: bool = typer.Option(
        False,
        "--stats",
        help="Show visual comparison stats with graphs",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show verbose output including rule matches",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Disable colored output",
    ),
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
) -> None:
    """
    Compare two sources and explain what changed.

    SOURCES can be files, directories, or URLs. The tool automatically
    detects the type and performs semantic comparison.

    Exit codes:
      0 - No breaking or risky changes
      1 - Risky changes detected
      2 - Breaking changes detected

    Examples:

        what-changed config.old.json config.new.json

        what-changed ./old-project ./new-project

        what-changed .env.staging .env.production --breaking-only
    """
    try:
        exit_code = run_comparison(
            source_a=source_a,
            source_b=source_b,
            summary=summary,
            breaking_only=breaking_only,
            json_output=json_output,
            show_graph=graph,
            show_stats=stats,
            verbose=verbose,
            color=not no_color,
        )
        raise typer.Exit(code=exit_code)

    except (SystemExit, typer.Exit):
        # Let typer.Exit propagate normally
        raise
    except NormalizationError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=3)
    except FileNotFoundError as e:
        console.print(f"[red]Error:[/red] File not found: {e}")
        raise typer.Exit(code=3)
    except Exception as e:
        if verbose:
            console.print_exception()
        else:
            console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=3)


def run_comparison(
    source_a: str,
    source_b: str,
    summary: bool = False,
    breaking_only: bool = False,
    json_output: bool = False,
    show_graph: bool = False,
    show_stats: bool = False,
    verbose: bool = False,
    color: bool = True,
) -> int:
    """
    Run the comparison pipeline.

    Returns:
        Exit code (0=safe, 1=risky, 2=breaking)
    """
    # Step 1: Create registry and normalize both sources
    registry = create_default_registry()

    # Validate sources exist
    path_a = Path(source_a)
    path_b = Path(source_b)

    if not source_a.startswith(('http://', 'https://')) and not path_a.exists():
        raise FileNotFoundError(source_a)
    if not source_b.startswith(('http://', 'https://')) and not path_b.exists():
        raise FileNotFoundError(source_b)

    # Normalize
    normalized_a = registry.normalize(source_a)
    normalized_b = registry.normalize(source_b)

    # Step 2: Perform semantic diff
    differ = SemanticDiff()
    diff_result = differ.diff(normalized_a, normalized_b)

    # Step 3: Build change graph
    builder = GraphBuilder()
    change_graph = builder.build(diff_result)

    # Step 4: Apply heuristic rules
    rule_engine = create_default_engine()
    rule_results = rule_engine.apply(change_graph)

    # Step 5: Generate explanations
    explainer = Explainer()
    explanations = explainer.explain_graph(change_graph, rule_results)

    # Step 6: Render output
    if show_graph:
        # Launch TUI
        from what_changed.tui.graph_view import run_graph_tui
        run_graph_tui(change_graph, explanations)
    elif show_stats:
        # Show visual stats comparison
        from what_changed.output.stats import render_comparison_stats
        render_comparison_stats(normalized_a, normalized_b, diff_result, change_graph)
    else:
        # Determine output format
        if json_output:
            output_format = OutputFormat.JSON
        elif summary:
            output_format = OutputFormat.SUMMARY
        else:
            # Use format-specific rendering for human output
            output_format = OutputFormat.FORMAT_SPECIFIC

        config = RenderConfig(
            format=output_format,
            show_safe=not breaking_only,
            breaking_only=breaking_only,
            verbose=verbose,
            color=color,
        )

        renderer = Renderer(config)
        renderer.render(
            diff_result,
            change_graph,
            explanations,
            obj_a=normalized_a,
            obj_b=normalized_b,
        )

    # Determine exit code
    breaking_count = len(change_graph.get_breaking_changes())
    risky_count = len(change_graph.get_risky_changes())

    if breaking_count > 0:
        return 2
    elif risky_count > 0:
        return 1
    else:
        return 0


@app.command()
def detect(
    source: str = typer.Argument(
        ...,
        help="Source to detect type for",
    ),
) -> None:
    """
    Detect and display the type of a source.

    Useful for debugging type detection.
    """
    from what_changed.detect import TypeDetector

    detector = TypeDetector()
    result = detector.detect(source)

    console.print(f"\nSource: {source}")
    console.print(f"Type: [bold]{result.source_type.name}[/bold]")
    console.print(f"Confidence: {result.confidence:.0%}")

    if result.path:
        console.print(f"Path: {result.path}")
    if result.url:
        console.print(f"URL: {result.url}")

    console.print()


@app.command()
def git(
    ref_spec: str = typer.Argument(
        ...,
        help="Git ref comparison (e.g., 'HEAD~1..HEAD', 'main..feature', 'v1.0..v2.0')",
    ),
    path: Optional[str] = typer.Option(
        None,
        "--path",
        "-p",
        help="Specific file or directory to compare",
    ),
    summary: bool = typer.Option(
        False,
        "--summary",
        "-s",
        help="Show only a brief summary",
    ),
    breaking_only: bool = typer.Option(
        False,
        "--breaking-only",
        "-b",
        help="Show only breaking changes",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON",
    ),
    graph: bool = typer.Option(
        False,
        "--graph",
        "-g",
        help="Show interactive graph TUI",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show verbose output including rule matches",
    ),
    no_color: bool = typer.Option(
        False,
        "--no-color",
        help="Disable colored output",
    ),
    repo: Optional[str] = typer.Option(
        None,
        "--repo",
        "-r",
        help="Path to git repository (defaults to current directory)",
    ),
) -> None:
    """
    Compare changes between git commits, branches, or tags.

    REF_SPEC specifies what to compare using git range syntax:

    \b
    Examples:
        what-changed git HEAD~1..HEAD              # Last commit
        what-changed git main..feature             # Branch diff
        what-changed git v1.0..v2.0                # Tag comparison
        what-changed git abc123..def456            # Commit SHAs
        what-changed git HEAD~5..HEAD -p config/   # Only config directory
        what-changed git main..HEAD -p .env        # Only .env file

    Exit codes:
      0 - No breaking or risky changes
      1 - Risky changes detected
      2 - Breaking changes detected
      3 - Error occurred
    """
    try:
        # Parse the ref spec
        try:
            spec = GitCompareSpec.parse(ref_spec)
            if path:
                spec.path = path
        except ValueError as e:
            console.print(f"[red]Error:[/red] {e}")
            raise typer.Exit(code=3)

        # Check if in git repo
        repo_path = Path(repo) if repo else Path.cwd()
        if not is_git_repo(repo_path):
            console.print(f"[red]Error:[/red] Not a git repository: {repo_path}")
            raise typer.Exit(code=3)

        # Run git comparison
        exit_code = run_git_comparison(
            spec=spec,
            repo_path=repo_path,
            summary=summary,
            breaking_only=breaking_only,
            json_output=json_output,
            show_graph=graph,
            verbose=verbose,
            color=not no_color,
        )
        raise typer.Exit(code=exit_code)

    except (SystemExit, typer.Exit):
        raise
    except GitError as e:
        console.print(f"[red]Git Error:[/red] {e}")
        raise typer.Exit(code=3)
    except Exception as e:
        if verbose:
            console.print_exception()
        else:
            console.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(code=3)


def run_git_comparison(
    spec: GitCompareSpec,
    repo_path: Path,
    summary: bool = False,
    breaking_only: bool = False,
    json_output: bool = False,
    show_graph: bool = False,
    verbose: bool = False,
    color: bool = True,
) -> int:
    """
    Run git comparison pipeline.

    Returns:
        Exit code (0=safe, 1=risky, 2=breaking)
    """
    with GitComparer(repo_path) as comparer:
        # Show comparison info
        if not json_output:
            info = comparer.get_comparison_summary(spec)
            console.print()
            console.print(f"[dim]Comparing:[/dim] {info['ref_a']['short_sha']} ({info['ref_a']['ref']})")
            console.print(f"[dim]       to:[/dim] {info['ref_b']['short_sha']} ({info['ref_b']['ref']})")
            if info['path_filter']:
                console.print(f"[dim]     path:[/dim] {info['path_filter']}")
            console.print(f"[dim]    files:[/dim] {info['changed_files_count']} changed")
            console.print()

        # Extract files to temp directories
        path_a, path_b = comparer.extract_for_comparison(spec)

        # Run standard comparison pipeline
        return run_comparison(
            source_a=str(path_a),
            source_b=str(path_b),
            summary=summary,
            breaking_only=breaking_only,
            json_output=json_output,
            show_graph=show_graph,
            verbose=verbose,
            color=color,
        )


if __name__ == "__main__":
    app()
