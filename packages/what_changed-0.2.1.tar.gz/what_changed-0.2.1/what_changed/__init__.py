"""what-changed: A universal CLI tool for semantic change detection."""

__version__ = "0.2.0"
