# what-changed Examples Guide

This folder contains sample files to test all features of `what-changed`.

## Quick Start

```bash
cd examples
```

---

## 1. JSON Configuration

Compare JSON config files with tree visualization:

```bash
what-changed compare before/config.json after/config.json
```

**What to notice:**
- Tree-structured change view
- Type indicators (`<str>`, `<int>`, `<bool>`)
- Breaking/risky/safe categorization
- Removed keys marked as breaking

---

## 2. YAML Configuration

Compare YAML files:

```bash
what-changed compare before/config.yaml after/config.yaml
```

**What to notice:**
- Same tree view as JSON
- Nested structure preserved
- Array changes tracked

---

## 3. Environment Files (.env)

Compare environment configurations:

```bash
what-changed compare before/.env after/.env
```

**What to notice:**
- Environment variable changes
- Secrets detection (shows `${VAR}` patterns)
- Added/removed variables

---

## 4. Dockerfile

Compare Dockerfiles with instruction-level analysis:

```bash
what-changed compare before/Dockerfile after/Dockerfile
```

**What to notice:**
- Base image changes (python:3.9-slim -> python:3.12-alpine)
- Port changes (8000 -> 8080, 443)
- New HEALTHCHECK instruction
- ENTRYPOINT/CMD changes
- Security-relevant RUN commands

---

## 5. Package.json (Node.js Dependencies)

Compare Node.js package files:

```bash
what-changed compare before/package.json after/package.json
```

**What to notice:**
- Dependency version changes
- Removed packages (moment -> dayjs)
- Added packages
- Script changes

---

## 6. Requirements.txt (Python Dependencies)

Compare Python requirements:

```bash
what-changed compare before/requirements.txt after/requirements.txt
```

**What to notice:**
- Major version upgrades marked as BREAKING
- Minor version upgrades
- Removed dependencies (redis)
- Added dependencies (pydantic, alembic, ruff)

---

## 7. SQL Schema

Compare database schemas:

```bash
what-changed compare before/schema.sql after/schema.sql
```

**What to notice:**
- New tables (tags, post_tags)
- New columns (role, is_active, slug, etc.)
- New indexes
- Constraint changes (ON DELETE CASCADE)

---

## 8. CSV Data

Compare data files:

```bash
what-changed compare before/users.csv after/users.csv
```

**What to notice:**
- Schema changes (new columns: role, last_login)
- Row counts
- Data diff preview
- Removed rows (Bob Wilson)
- Added rows

---

## 9. OpenAPI Specification

Compare API specs:

```bash
what-changed compare before/api.yaml after/api.yaml
```

**What to notice:**
- API version change (1.0.0 -> 2.0.0)
- New endpoints (PATCH, DELETE, /users/{id}/posts)
- Parameter type changes (integer -> uuid)
- New query parameters (pagination)
- Schema definitions

---

## 10. Markdown Documentation

Compare documentation:

```bash
what-changed compare before/README.md after/README.md
```

**What to notice:**
- Line-by-line diff
- Section changes
- Content additions

---

## 11. Directory Comparison

Compare entire project directories:

```bash
what-changed compare before/project after/project
```

**What to notice:**
- File counts and sizes
- New directories (lib/)
- Removed files (README.md)
- Modified files
- File type distribution

---

## 12. Image Comparison (with OCR)

Compare images and extract text:

```bash
what-changed compare before/dashboard.png after/dashboard.png
```

**What to notice:**
- Dimension comparison
- File size changes
- OCR text extraction and diff
- Text content changes detected

---

## 13. PDF Documents

Compare PDF documents with page-level analysis:

```bash
what-changed compare before/manual.pdf after/manual.pdf
```

**What to notice:**
- Document overview (pages, words, characters)
- Page-by-page change tracking
- Content diff for modified pages
- Full content display for new pages
- OCR support for scanned PDFs (requires Tesseract)

---

## Output Options

### Summary Only
```bash
what-changed compare before/config.json after/config.json --summary
```

### Breaking Changes Only
```bash
what-changed compare before/config.json after/config.json --breaking-only
```

### JSON Output
```bash
what-changed compare before/config.json after/config.json --json
```

### Verbose Mode (shows rule matches)
```bash
what-changed compare before/config.json after/config.json --verbose
```

### Interactive Graph TUI
```bash
what-changed compare before/config.json after/config.json --graph
```

### Visual Stats Dashboard
```bash
what-changed compare before/config.json after/config.json --stats
```

---

## Git Integration

Compare between git commits:

```bash
# Last commit
what-changed git HEAD~1..HEAD

# Between branches
what-changed git main..feature-branch

# Between tags
what-changed git v1.0.0..v2.0.0

# Specific file only
what-changed git HEAD~1..HEAD -p src/config.json
```

---

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | No breaking or risky changes |
| 1 | Risky changes detected |
| 2 | Breaking changes detected |
| 3 | Error occurred |

Use in CI/CD:
```bash
what-changed compare old.json new.json || echo "Changes detected!"
```

---

## Type Detection

Check what type is detected for a file:

```bash
what-changed detect before/config.json
what-changed detect before/Dockerfile
what-changed detect before/requirements.txt
```
