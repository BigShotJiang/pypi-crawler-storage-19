"""Utility functions."""

def format_name(name):
    return name.strip().title()

def validate_email(email):
    return "@" in email
