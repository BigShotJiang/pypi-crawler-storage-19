"""Main application module."""

def hello():
    return "Hello, World!"

def calculate(a, b):
    return a + b

if __name__ == "__main__":
    print(hello())
