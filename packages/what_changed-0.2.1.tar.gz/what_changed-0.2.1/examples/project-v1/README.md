# MyApp v1.0

A simple application.

## Installation

Run `pip install myapp`
