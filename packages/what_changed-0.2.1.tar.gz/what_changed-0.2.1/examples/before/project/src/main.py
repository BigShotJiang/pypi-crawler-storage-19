def main(): print("Hello")
