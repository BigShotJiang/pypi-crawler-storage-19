# MyApp v2.0

A powerful web application with real-time features.

## Installation

1. Clone the repository
2. Install dependencies: `npm install`
3. Set up environment variables (see `.env.example`)
4. Run database migrations: `npm run migrate`
5. Start the application: `npm start`

## Features

- User authentication with JWT
- Role-based access control
- CRUD operations with validation
- REST API with OpenAPI documentation
- Real-time notifications via WebSocket
- Rate limiting and security headers
- Comprehensive logging with Sentry

## Configuration

Copy `.env.example` to `.env` and configure:

| Variable | Description | Required |
|----------|-------------|----------|
| DATABASE_URL | PostgreSQL connection string | Yes |
| REDIS_URL | Redis connection for caching | Yes |
| JWT_SECRET | Secret for JWT tokens | Yes |
| SENTRY_DSN | Sentry error tracking | No |

## API Documentation

API docs available at `/api/docs` when running locally.

## Testing

```bash
npm test           # Run tests
npm run test:cov   # With coverage
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

Apache 2.0
