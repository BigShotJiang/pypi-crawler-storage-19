# MyApp v2.0

A powerful application with new features.

## Installation

Run `pip install myapp`

## New in v2

- Added greeting functionality
- Improved calculate function
- New helper utilities
