"""Helper functions - new in v2."""

def log_message(msg, level="INFO"):
    print(f"[{level}] {msg}")

def retry(func, attempts=3):
    for i in range(attempts):
        try:
            return func()
        except Exception:
            if i == attempts - 1:
                raise
