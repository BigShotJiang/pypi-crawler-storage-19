"""Main application module - v2."""

def hello(name="World"):
    return f"Hello, {name}!"

def calculate(a, b, operation="add"):
    if operation == "add":
        return a + b
    elif operation == "subtract":
        return a - b
    return None

def greet_user(user):
    """New function in v2."""
    return f"Welcome, {user}!"

if __name__ == "__main__":
    print(hello("Developer"))
