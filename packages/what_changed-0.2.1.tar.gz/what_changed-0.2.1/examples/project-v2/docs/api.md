# API Documentation

## Endpoints

### GET /hello
Returns a greeting message.

### POST /calculate
Performs calculations.
