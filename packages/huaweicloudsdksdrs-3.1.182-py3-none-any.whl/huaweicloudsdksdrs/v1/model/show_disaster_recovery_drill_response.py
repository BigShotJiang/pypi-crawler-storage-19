# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowDisasterRecoveryDrillResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'disaster_recovery_drill': 'ShowDisasterRecoveryDrillParams'
    }

    attribute_map = {
        'disaster_recovery_drill': 'disaster_recovery_drill'
    }

    def __init__(self, disaster_recovery_drill=None):
        r"""ShowDisasterRecoveryDrillResponse

        The model defined in huaweicloud sdk

        :param disaster_recovery_drill: 
        :type disaster_recovery_drill: :class:`huaweicloudsdksdrs.v1.ShowDisasterRecoveryDrillParams`
        """
        
        super().__init__()

        self._disaster_recovery_drill = None
        self.discriminator = None

        if disaster_recovery_drill is not None:
            self.disaster_recovery_drill = disaster_recovery_drill

    @property
    def disaster_recovery_drill(self):
        r"""Gets the disaster_recovery_drill of this ShowDisasterRecoveryDrillResponse.

        :return: The disaster_recovery_drill of this ShowDisasterRecoveryDrillResponse.
        :rtype: :class:`huaweicloudsdksdrs.v1.ShowDisasterRecoveryDrillParams`
        """
        return self._disaster_recovery_drill

    @disaster_recovery_drill.setter
    def disaster_recovery_drill(self, disaster_recovery_drill):
        r"""Sets the disaster_recovery_drill of this ShowDisasterRecoveryDrillResponse.

        :param disaster_recovery_drill: The disaster_recovery_drill of this ShowDisasterRecoveryDrillResponse.
        :type disaster_recovery_drill: :class:`huaweicloudsdksdrs.v1.ShowDisasterRecoveryDrillParams`
        """
        self._disaster_recovery_drill = disaster_recovery_drill

    def to_dict(self):
        import warnings
        warnings.warn("ShowDisasterRecoveryDrillResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowDisasterRecoveryDrillResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
