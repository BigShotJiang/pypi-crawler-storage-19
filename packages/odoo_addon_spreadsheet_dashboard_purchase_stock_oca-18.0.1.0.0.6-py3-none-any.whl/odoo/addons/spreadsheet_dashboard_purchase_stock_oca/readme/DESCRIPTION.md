Spreadsheet dashboard for purchases.
