"""Application configuration.

Core application settings like app name, environment, debug mode, etc.
"""

import os


config = {
    "title": os.getenv("APP_NAME", "Neva Application"),
    "env": os.getenv("APP_ENV", "production"),
    "debug": bool(os.getenv("APP_DEBUG", 0)),
    "url": os.getenv("APP_URL", "http://localhost:8000"),
    "timezone": os.getenv("APP_TIMEZONE", "UTC"),
    "locale": os.getenv("APP_LOCALE", "en"),
    "fallback_locale": "en",
}
