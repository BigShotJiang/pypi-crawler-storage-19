"""Service Provider Configuration.

This file defines all service providers that should be automatically registered
when the application boots. This is similar to Laravel's config/app.php providers array.

Add your custom service providers to the list below. They will be registered
automatically when you create your App instance.

Example:
    from my_app.providers import CacheServiceProvider

    config = {
        "providers": [
            CacheServiceProvider,
        ],
    }
"""

from example.providers import CacheServiceProvider

config = {
    "providers": [CacheServiceProvider],
}
