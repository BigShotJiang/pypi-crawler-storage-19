"""Database configuration."""

from neva.database.config import DatabaseConfig, SQLiteConnection

sqlite_config: SQLiteConnection = {
    "engine": "tortoise.backends.sqlite",
    "credentials": {
        "file_path": ":memory:",
    },
}

config: DatabaseConfig = {
    "connections": {
        "default": sqlite_config,
    },
    "apps": {
        "app": {
            "models": ["example.models"],
            "default_connection": "default",
        }
    },
}
