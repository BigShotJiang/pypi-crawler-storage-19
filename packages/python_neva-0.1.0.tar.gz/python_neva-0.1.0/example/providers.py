"""Example Neva service provider classes."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Self, override
from neva import Ok, Result
from neva.arch import ServiceProvider
from example.facades import Cache
from example.services import CacheService


class CacheServiceProvider(ServiceProvider):
    """Cache service provider with lifespan management."""

    @override
    def register(self) -> Result[Self, str]:
        self.app.bind(CacheService)

        return Ok(self)

    @asynccontextmanager
    async def lifespan(self) -> AsyncIterator[None]:
        """Lifespan context manager for cache warmup and cleanup.

        Startup: Warm up cache with initial values
        Shutdown: Flush cache
        """
        Cache.put("app.version", "1.0.0")
        Cache.put("app.booted_at", "2024-01-01")

        yield

        Cache.flush()
