"""Type stub for cache facade."""

from typing import override
from neva.arch import Facade

class Cache(Facade):
    @classmethod
    @override
    def get_facade_accessor(cls) -> type: ...
    @classmethod
    def get(cls, key: str) -> str | None:
        """Get value from cache.

        Returns:
            Value if key exists, None otherwise.
        """

    @classmethod
    def put(cls, key: str, value: str) -> None:
        """Store value in cache."""

    @classmethod
    def has(cls, key: str) -> bool:
        """Check if key exists in cache.

        Returns:
            True if key exists, False otherwise.
        """

    @classmethod
    def flush(cls) -> None:
        """Clear all cached items."""
