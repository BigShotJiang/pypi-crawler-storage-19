"""Example facades for static access to application components."""

from typing import override
from neva.arch import Facade
from example.services import CacheService


class Cache(Facade):
    """Cache facade for static access."""

    @classmethod
    @override
    def get_facade_accessor(cls) -> type:
        return CacheService
