"""Example model."""

from typing import final, override
import uuid
import pydantic
from tortoise import Model, fields
from tortoise.manager import Manager
from tortoise.contrib.pydantic import pydantic_model_creator
from tortoise.queryset import QuerySet

from neva.database.repository import BaseRepository


class UserManager(Manager):
    """Manager for users."""

    @override
    def get_queryset(self) -> QuerySet["User"]:
        return super(UserManager, self).get_queryset().filter(active=True)


class User(Model):
    """The user model."""

    id = fields.UUIDField(primary_key=True, default_factory=uuid.uuid4)
    first_name = fields.CharField(max_length=255)
    last_name = fields.CharField(max_length=255)
    active = fields.BooleanField(default=True)

    all_objects: Manager = Manager()

    def full_name(self) -> str:
        """Compute the full name.

        Returns:
            Full name.
        """
        return f"{self.first_name} {self.last_name}"

    @final
    class Meta:
        """Meta class for orm."""

        manager = UserManager()

    @final
    class PydanticMeta:
        """Meta class for pydantic."""

        exclude = ("pwd_hash",)
        computed = ("full_name",)


UserSerializer = pydantic_model_creator(User)


class UserCreateSchema(pydantic.BaseModel):
    """User creation schema."""

    first_name: str
    last_name: str


class UserUpdateSchema(pydantic.BaseModel):
    """User update schema."""

    first_name: str
    last_name: str
    active: bool


class UserRepository(BaseRepository[User, UserCreateSchema, UserUpdateSchema]):
    """User repository."""

    def __init__(self) -> None:
        """Initialize the repository."""
        super().__init__(User)
