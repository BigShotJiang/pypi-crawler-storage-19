"""Example service classes."""


class CacheService:
    """Simple in-memory cache service."""

    def __init__(self) -> None:
        """Initialize cache service."""
        self.prefix: str = "neva_"
        self._store: dict[str, str] = {}

    def get(self, key: str) -> str | None:
        """Get value from cache.

        Returns:
            Value if key exists, None otherwise.
        """
        full_key = f"{self.prefix}{key}"
        value = self._store.get(full_key)
        return value

    def put(self, key: str, value: str) -> None:
        """Store value in cache."""
        full_key = f"{self.prefix}{key}"
        self._store[full_key] = value

    def has(self, key: str) -> bool:
        """Check if key exists in cache.

        Returns:
            True if key exists, False otherwise.
        """
        full_key = f"{self.prefix}{key}"
        return full_key in self._store

    def flush(self) -> None:
        """Clear all cached items."""
        self._store.clear()
