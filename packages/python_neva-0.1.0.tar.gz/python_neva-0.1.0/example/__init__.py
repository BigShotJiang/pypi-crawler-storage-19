"""Example module for Neva application."""
