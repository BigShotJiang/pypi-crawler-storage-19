"""Complete Neva Application Example.

Run with:
    fastapi dev examples/example.py

Or with uvicorn:
    uvicorn examples.example:app --reload
"""

import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import fastapi

from neva.arch import App
from neva.obs import CorrelationMiddleware, ProfilerMiddleware
from neva.support.facade import Config, Log
from example.facades import Cache
from example.models import User, UserCreateSchema, UserRepository, UserSerializer


@asynccontextmanager
async def app_lifespan(_: App) -> AsyncIterator[None]:
    """Custom application lifespan logic.

    This runs AFTER all service provider lifespans have been entered.
    All provider contexts are active during this lifespan.
    """
    Log.info("🚀 Application ready!")
    Log.info(f"📝 App name: {Config.get('app.title').unwrap()}")
    Log.info(f"🐛 Debug mode: {Config.get('app.debug').unwrap()}")

    yield

    Log.info("👋 Application shutting down...")


app = App(
    lifespan=app_lifespan,
    middlewares=[
        ProfilerMiddleware,
        CorrelationMiddleware,
    ],
)


@app.get("/")
async def root() -> dict[str, Any]:
    """Root endpoint showing app info.

    Returns:
        App info.
    """
    return {
        "app": Config.get("app.title").unwrap(),
        "version": Cache.get("app.version"),
        "debug": Config.get("app.debug").unwrap(),
        "message": "Welcome to Neva! Check /docs for API documentation.",
    }


@app.get("/config/{key:path}")
async def get_config(key: str) -> dict[str, Any]:
    """Get configuration value by key (dot notation supported).

    Returns:
        Configuration value.

    Raises:
        HTTPException: If configuration key not found.
    """
    result = Config.get(key)

    if result.is_ok:
        return {
            "key": key,
            "value": result.unwrap(),
            "source": "config",
        }
    else:
        raise fastapi.HTTPException(
            status_code=404,
            detail=f"Configuration key '{key}' not found",
        )


@app.get("/users", response_model=list[UserSerializer])  # type: ignore [invalid-type-form]
async def get_users() -> list[User]:
    """Get all users.

    Returns:
        List of users.
    """
    user_repo = UserRepository()
    users = await user_repo.all()
    return users


@app.post("/users")
async def create_user(data: UserCreateSchema) -> uuid.UUID:
    """Create a new user.

    Returns:
        The user's ID.
    """
    user_repo = UserRepository()
    user = await user_repo.create(data)
    return user.id


@app.get("/users/{user_id}", response_model=UserSerializer)  # type: ignore [invalid-type-form]
async def get_user(user_id: uuid.UUID) -> User | None:
    """Return a user by ID."""
    return await User.filter(id=user_id).first()
