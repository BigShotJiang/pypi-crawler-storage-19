# ReadAnyBook 📚

A RAG-based cheat sheet generator that transforms books and papers into structured, 12-page LaTeX cheat sheets.

## Features

- **Multi-format Document Support**: PDF, EPUB, HTML, LaTeX, Markdown
- **Intelligent Chunking**: Math-aware and code-aware text splitting
- **Hybrid Retrieval**: Dense embeddings + BM25 with reciprocal rank fusion
- **Multi-pass Generation**: Separate extraction for concepts, formulas, algorithms, and models
- **LaTeX Output**: Professional cheat sheets compiled to PDF
- **Multiple LLM Backends**: HuggingFace, Ollama, vLLM, OpenAI-compatible APIs
- **Vector Store Options**: ChromaDB, Qdrant, Weaviate

## Quick Start

### Installation

```bash
# Basic installation
pip install readanybook

# With CLI support
pip install readanybook[cli]

# With all features
pip install readanybook[all]
```

### From Source

```bash
git clone https://github.com/readanybook/readanybook.git
cd readanybook
pip install -e ".[dev]"
```

### Usage

#### Command Line

```bash
# Generate a cheat sheet from a PDF
read-any-book build document.pdf -o cheatsheet.pdf

# Use a specific profile
read-any-book build document.pdf --profile math_paper

# Index a document
read-any-book index document.pdf --collection my_collection

# Search indexed documents
read-any-book search "gradient descent" --collection my_collection
```

#### Python API

```python
from readanybook import CheatSheetPipeline, Settings

# Initialize pipeline
settings = Settings()
pipeline = CheatSheetPipeline(settings)

# Process document
pipeline.ingest("textbook.pdf")
pipeline.index(collection_name="textbook")

# Generate cheat sheet
content = pipeline.generate_content()
cheat_sheet = pipeline.build(content, "output/cheatsheet.pdf")

print(f"Generated: {cheat_sheet.pdf_path}")
```

#### REST API

```bash
# Start the API server
uvicorn readanybook.api:app --host 0.0.0.0 --port 8000

# Upload a document
curl -X POST "http://localhost:8000/upload" \
  -F "file=@document.pdf" \
  -F "collection_name=my_docs"

# Generate cheat sheet
curl -X POST "http://localhost:8000/generate" \
  -H "Content-Type: application/json" \
  -d '{"collection_name": "my_docs", "title": "My Cheat Sheet"}'
```

## Configuration

Create a `config.yaml` file or use environment variables:

```yaml
# Embedding model
embedding:
  model_name: "BAAI/bge-base-en-v1.5"
  device: "cuda"

# Vector store
vectordb:
  store_type: "chroma"
  persist_directory: "./data/chroma"

# LLM settings
llm:
  backend: "ollama"
  model_name: "llama3:8b"

# Retrieval
retrieval:
  mode: "hybrid"
  top_k: 15
  
# LaTeX output
latex:
  columns: 2
  font_size: 10
  paper_size: "a4paper"
```

### Configuration Profiles

Use built-in profiles for different document types:

```bash
# For technical books
read-any-book build book.pdf --profile technical_book

# For math papers
read-any-book build paper.pdf --profile math_paper

# For non-technical books
read-any-book build novel.pdf --profile nontechnical_book
```

## Architecture

```
readanybook/
├── core/           # Domain logic
│   ├── ingestion.py    # Document parsing
│   ├── chunking.py     # Text splitting
│   ├── indexing.py     # Embedding & indexing
│   ├── retrieval.py    # Hybrid retrieval
│   ├── models.py       # LLM clients
│   ├── prompts.py      # Prompt templates
│   └── pipeline.py     # Main orchestrator
├── generation/     # Content generation
│   ├── concepts.py     # Concept extraction
│   ├── formulas.py     # Formula extraction
│   ├── algorithms.py   # Algorithm synthesis
│   ├── models_theory.py # Model summarization
│   └── latex_builder.py # LaTeX generation
├── evaluation/     # Quality metrics
│   ├── rag_eval.py     # RAG evaluation
│   └── metrics.py      # Content metrics
├── infra/          # Infrastructure
│   ├── settings.py     # Configuration
│   ├── vectordb.py     # Vector stores
│   ├── logging.py      # Logging
│   └── tracing.py      # Observability
├── api/            # REST API
├── cli/            # Command line interface
├── templates/      # LaTeX templates
└── config/         # Default configs
```

## Requirements

- Python 3.10+
- PyTorch 2.0+
- LaTeX distribution (for PDF compilation)
  - TeX Live, MiKTeX, or Tectonic

### LaTeX Installation

```bash
# Ubuntu/Debian
sudo apt install texlive-full

# macOS
brew install --cask mactex

# Or use Tectonic (lightweight)
cargo install tectonic
```

## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Format code
black readanybook tests
isort readanybook tests

# Type check
mypy readanybook

# Lint
ruff check readanybook
```

## Examples

See the [examples](examples/) directory for:

- Processing academic papers
- Creating ML textbook cheat sheets
- Custom template usage
- API integration examples

## License

MIT License - see [LICENSE](LICENSE) for details.

## Contributing

Contributions welcome! Please read [CONTRIBUTING.md](CONTRIBUTING.md) first.

## Acknowledgments

- Built with 🤗 Transformers, ChromaDB, and FastAPI
- Inspired by the need for better study materials
