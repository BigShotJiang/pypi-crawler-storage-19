"""
ReadAnyBook - A RAG-based cheat sheet generator for books and papers.

This package provides a modular pipeline for:
1. Ingesting books/papers (PDF, EPUB, HTML)
2. Building structured knowledge stores (chunks + embeddings + metadata)
3. Running specialized generation passes (concepts, formulas, models, pseudocode)
4. Assembling comprehensive LaTeX cheat sheets
5. Compiling to PDF
"""

__version__ = "0.1.0"
__author__ = "ReadAnyBook Team"

from .core.pipeline import CheatSheetPipeline
from .infra.settings import Settings

__all__ = [
    "CheatSheetPipeline",
    "Settings",
    "__version__",
]
