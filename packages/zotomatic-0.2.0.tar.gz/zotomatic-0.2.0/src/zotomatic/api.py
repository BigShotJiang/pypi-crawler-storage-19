# src/zotomatic/api.py
