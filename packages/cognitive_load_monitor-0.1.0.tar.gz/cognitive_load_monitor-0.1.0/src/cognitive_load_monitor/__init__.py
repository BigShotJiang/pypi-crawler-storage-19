"""
Cognitive Load Monitor for AI Agents

A lightweight, drop-in module for AI agents to self-report cognitive load
using observable runtime metrics.
"""

from .monitor import (
    CognitiveLoadMonitor,
    CognitiveLoadReport,
    MetricWeights,
    LoadTrend,
)

__version__ = "0.1.0"
__author__ = "Synapse Data"
__all__ = [
    "CognitiveLoadMonitor",
    "CognitiveLoadReport",
    "MetricWeights",
    "LoadTrend",
]
