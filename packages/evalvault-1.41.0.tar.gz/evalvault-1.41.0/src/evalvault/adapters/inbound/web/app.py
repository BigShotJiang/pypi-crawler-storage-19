"""EvalVault Web UI - Streamlit Application."""

from __future__ import annotations

import sys
from datetime import date, datetime, time, timedelta
from pathlib import Path

# Streamlit 앱 실행 시 src 경로 추가
src_path = Path(__file__).parent.parent.parent.parent.parent
if str(src_path) not in sys.path:
    sys.path.insert(0, str(src_path))


def create_app():
    """Streamlit 앱 생성 및 설정."""
    import streamlit as st

    from evalvault.adapters.inbound.web.adapter import create_adapter
    from evalvault.adapters.inbound.web.pages import (
        render_history_page,
        render_reports_page,
    )
    from evalvault.adapters.inbound.web.session import init_session

    # 페이지 설정
    st.set_page_config(
        page_title="EvalVault",
        page_icon="📊",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    # 세션 초기화
    session = init_session()

    # 어댑터 초기화 (세션에 캐시)
    if "adapter" not in st.session_state:
        st.session_state.adapter = create_adapter()

    adapter = st.session_state.adapter

    # 사이드바
    with st.sidebar:
        st.title("📊 EvalVault")
        st.caption("RAG Evaluation System")

        st.divider()

        # 네비게이션
        page = st.radio(
            "Navigation",
            options=[
                "🏠 Home",
                "📊 Evaluate",
                "📋 History",
                "🔧 Improve",
                "📄 Reports",
                "🧾 고객 리포트",
            ],
            label_visibility="collapsed",
        )

        st.divider()

        # 설정 섹션
        with st.expander("⚙️ Settings", expanded=False):
            st.caption("Model Configuration")
            model = st.selectbox(
                "Default Model",
                options=[
                    "gpt-5-nano (OpenAI)",
                    "gemma3:1b (Ollama, dev)",
                    "gpt-oss-safeguard:20b (Ollama, prod)",
                ],
                index=0,
            )
            session.selected_model = model

        # 버전 정보
        st.caption("v1.3.0 | Powered by Ragas + Langfuse")

    # 메인 컨텐츠
    if page == "🏠 Home":
        render_home_page(adapter, session)
    elif page == "📊 Evaluate":
        render_evaluate_page(adapter, session)
    elif page == "📋 History":
        render_history_page(adapter, session)
    elif page == "🔧 Improve":
        render_improvement_page(adapter, session)
    elif page == "📄 Reports":
        render_reports_page(adapter, session)
    elif page == "🧾 고객 리포트":
        render_customer_report_page(adapter, session)


def _project_label(option: str) -> str:
    from evalvault.adapters.inbound.web.components import (
        ALL_PROJECTS_TOKEN,
        UNASSIGNED_PROJECT_TOKEN,
    )

    if option == ALL_PROJECTS_TOKEN:
        return "전체"
    if option == UNASSIGNED_PROJECT_TOKEN:
        return "미분류"
    return option


def _resolve_date_range(
    range_label: str,
    custom_range: tuple[date, date] | None,
) -> tuple[datetime | None, datetime | None]:
    today = datetime.now().date()
    if range_label == "전체":
        return None, None
    if range_label == "최근 7일":
        start = today - timedelta(days=6)
        end = today
    elif range_label == "최근 30일":
        start = today - timedelta(days=29)
        end = today
    elif range_label == "최근 90일":
        start = today - timedelta(days=89)
        end = today
    elif range_label == "올해":
        start = date(today.year, 1, 1)
        end = today
    elif range_label == "직접 선택" and custom_range and len(custom_range) == 2:
        start, end = custom_range
    else:
        return None, None

    return datetime.combine(start, time.min), datetime.combine(end, time.max)


def _previous_period_range(
    date_from: datetime | None,
    date_to: datetime | None,
) -> tuple[datetime | None, datetime | None]:
    if not date_from or not date_to:
        return None, None

    delta_days = (date_to.date() - date_from.date()).days + 1
    prev_end = date_from.date() - timedelta(days=1)
    prev_start = prev_end - timedelta(days=delta_days - 1)
    return datetime.combine(prev_start, time.min), datetime.combine(prev_end, time.max)


def _filter_runs_by_date(
    runs,
    date_from: datetime | None,
    date_to: datetime | None,
):
    if not date_from and not date_to:
        return list(runs)
    filtered = []
    for run in runs:
        if date_from and run.started_at < date_from:
            continue
        if date_to and run.started_at > date_to:
            continue
        filtered.append(run)
    return filtered


def _build_customer_report_html(
    *,
    stats,
    range_label: str,
    project_labels: list[str],
    trend_fig,
    metric_fig,
) -> str:
    trend_html = trend_fig.to_html(full_html=False, include_plotlyjs="cdn")
    metric_html = metric_fig.to_html(full_html=False, include_plotlyjs=False)
    projects_display = ", ".join(project_labels) if project_labels else "전체"
    cost_value = stats.total_cost or 0.0
    pass_rate = stats.avg_pass_rate * 100

    return f"""<!doctype html>
<html lang="ko">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>EvalVault 고객 리포트</title>
    <style>
      body {{
        font-family: "Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", sans-serif;
        margin: 0;
        background: #0f172a;
        color: #e2e8f0;
      }}
      .container {{
        max-width: 1200px;
        margin: 0 auto;
        padding: 32px 24px 56px;
      }}
      .meta {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 16px;
        margin: 24px 0;
      }}
      .card {{
        background: #111827;
        border: 1px solid #1f2937;
        border-radius: 16px;
        padding: 18px;
      }}
      .card h3 {{
        margin: 0 0 8px;
        font-size: 14px;
        color: #94a3b8;
      }}
      .card p {{
        margin: 0;
        font-size: 22px;
        font-weight: 600;
      }}
      .section-title {{
        margin: 32px 0 12px;
        font-size: 18px;
      }}
      .badge {{
        display: inline-block;
        padding: 6px 12px;
        border-radius: 999px;
        background: #1e293b;
        color: #cbd5f5;
        font-size: 12px;
      }}
    </style>
  </head>
  <body>
    <div class="container">
      <h1>EvalVault 고객 리포트</h1>
      <p class="badge">기간: {range_label} · 프로젝트: {projects_display}</p>

      <div class="meta">
        <div class="card">
          <h3>평가 수</h3>
          <p>{stats.total_runs:,}</p>
        </div>
        <div class="card">
          <h3>테스트 케이스</h3>
          <p>{stats.total_test_cases:,}</p>
        </div>
        <div class="card">
          <h3>평균 통과율</h3>
          <p>{pass_rate:.1f}%</p>
        </div>
        <div class="card">
          <h3>총 비용 (USD)</h3>
          <p>${cost_value:,.2f}</p>
        </div>
      </div>

      <h2 class="section-title">Pass Rate 트렌드</h2>
      {trend_html}

      <h2 class="section-title">메트릭 평균 추이</h2>
      {metric_html}
    </div>
  </body>
</html>
"""


def render_home_page(adapter, session):
    """홈 페이지 렌더링."""
    import streamlit as st

    from evalvault.adapters.inbound.web.components import (
        ALL_PROJECTS_TOKEN,
        DashboardStats,
        RecentRunsList,
        build_project_options,
        create_metric_trend_chart,
        create_trend_chart,
        filter_runs_by_projects,
    )

    st.header("📊 Dashboard")
    st.markdown(
        """
        EvalVault는 RAG (Retrieval-Augmented Generation) 시스템을 평가하고
        분석하기 위한 도구입니다.
        """
    )

    # 평가 데이터 조회
    runs = adapter.list_runs(limit=200)

    st.subheader("필터")
    filter_col1, filter_col2, filter_col3 = st.columns([2, 2, 3])

    with filter_col1:
        range_label = st.selectbox(
            "기간",
            options=["최근 7일", "최근 30일", "최근 90일", "올해", "전체", "직접 선택"],
            index=1,
        )
        custom_range = None
        if range_label == "직접 선택":
            today = datetime.now().date()
            custom_range = st.date_input(
                "기간 선택",
                value=(today - timedelta(days=29), today),
            )

    with filter_col2:
        project_options = build_project_options(runs)
        selected_projects = st.multiselect(
            "프로젝트",
            options=project_options,
            default=[ALL_PROJECTS_TOKEN],
            format_func=_project_label,
        )

    with filter_col3:
        st.caption("기간과 프로젝트 기준으로 대시보드를 집계합니다.")
        if range_label == "전체":
            st.caption("기간: 전체")
        elif range_label == "직접 선택" and custom_range and len(custom_range) == 2:
            st.caption(f"기간: {custom_range[0]} ~ {custom_range[1]}")
        else:
            st.caption(f"기간: {range_label}")

    date_from, date_to = _resolve_date_range(range_label, custom_range)
    filtered_runs = filter_runs_by_projects(runs, selected_projects)
    filtered_runs = _filter_runs_by_date(filtered_runs, date_from, date_to)
    filtered_runs = sorted(filtered_runs, key=lambda r: r.started_at, reverse=True)

    prev_from, prev_to = _previous_period_range(date_from, date_to)
    prev_runs = filter_runs_by_projects(runs, selected_projects)
    prev_runs = _filter_runs_by_date(prev_runs, prev_from, prev_to)
    prev_stats = DashboardStats.from_runs(prev_runs) if prev_from and prev_to else None

    # 대시보드 통계 계산
    stats = DashboardStats.from_runs(filtered_runs)
    deltas = stats.compare_to(prev_stats) if prev_stats else None

    # 통계 카드 섹션
    st.subheader("요약 지표")
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            label="평가 수",
            value=f"{stats.total_runs:,}",
            delta=deltas["total_runs"] if deltas else None,
        )

    with col2:
        st.metric(
            label="테스트 케이스",
            value=f"{stats.total_test_cases:,}",
            delta=deltas["total_test_cases"] if deltas else None,
        )

    with col3:
        pass_rate_value = stats.avg_pass_rate * 100
        pass_rate_delta = deltas["avg_pass_rate"] * 100 if deltas else None
        st.metric(
            label="평균 통과율",
            value=f"{pass_rate_value:.1f}%",
            delta=f"{pass_rate_delta:+.1f}p" if pass_rate_delta is not None else None,
        )

    with col4:
        cost_value = stats.total_cost or 0.0
        cost_delta = deltas["total_cost"] if deltas else None
        st.metric(
            label="총 비용 (USD)",
            value=f"${cost_value:,.2f}",
            delta=f"{cost_delta:+.2f}" if cost_delta is not None else None,
        )

    # 차트 섹션
    st.divider()
    chart_col1, chart_col2 = st.columns(2)

    with chart_col1:
        trend_fig = create_trend_chart(filtered_runs, title="기간별 Pass Rate")
        st.plotly_chart(trend_fig, width="stretch", key="home_trend_chart")

    with chart_col2:
        metric_candidates = sorted(
            {
                metric
                for run in filtered_runs
                for metric in (getattr(run, "avg_metric_scores", {}) or {})
            }
        )
        selected_metrics = st.multiselect(
            "메트릭 트렌드",
            options=metric_candidates,
            default=metric_candidates[:2],
            key="home_metric_trend",
        )
        metric_fig = create_metric_trend_chart(
            filtered_runs,
            selected_metrics,
            title="메트릭 평균 추이",
        )
        st.plotly_chart(metric_fig, width="stretch", key="home_metric_trend_chart")

    # 지원 메트릭 섹션
    st.divider()
    with st.expander("📊 지원 메트릭", expanded=False):
        metrics = adapter.get_available_metrics()
        descriptions = adapter.get_metric_descriptions()

        cols = st.columns(3)
        for i, metric in enumerate(metrics):
            with cols[i % 3]:
                st.markdown(
                    f"""
                    <div style="
                        padding: 0.75rem;
                        border-radius: 0.5rem;
                        border: 1px solid #334155;
                        margin-bottom: 0.5rem;
                    ">
                        <strong>{metric}</strong><br>
                        <small style="color: #94A3B8;">{descriptions.get(metric, "")}</small>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

    # 품질 게이트 및 개선 제안 섹션
    st.divider()
    st.subheader("품질 현황 및 개선 제안")

    if filtered_runs:
        # 가장 최근 실행의 품질 게이트 표시
        latest_run = filtered_runs[0]
        try:
            gate_report = adapter.check_quality_gate(latest_run.run_id)

            gate_col1, gate_col2 = st.columns([1, 2])

            with gate_col1:
                # 품질 게이트 상태
                if gate_report.overall_passed:
                    st.success("✅ 품질 게이트 PASS")
                else:
                    st.error("❌ 품질 게이트 FAIL")

                st.caption(f"최근 평가: {latest_run.run_id[:12]}...")

            with gate_col2:
                # 메트릭별 상태 (실패 메트릭 강조)
                failed_metrics = [r for r in gate_report.results if not r.passed]
                passed_metrics = [r for r in gate_report.results if r.passed]

                if failed_metrics:
                    st.markdown("**개선 필요 메트릭:**")
                    for result in failed_metrics[:3]:  # 상위 3개만
                        gap_pct = abs(result.gap) * 100
                        st.markdown(
                            f"- 🔴 **{result.metric}**: {result.score:.2f} / {result.threshold:.2f} "
                            f"(갭: -{gap_pct:.1f}%)"
                        )

                if passed_metrics:
                    with st.expander(f"✅ 통과 메트릭 ({len(passed_metrics)}개)"):
                        for result in passed_metrics:
                            st.markdown(
                                f"- {result.metric}: {result.score:.2f} / {result.threshold:.2f}"
                            )

            # 빠른 개선 제안 링크
            if failed_metrics:
                st.markdown("---")
                col1, col2 = st.columns([3, 1])
                with col1:
                    st.info(
                        f"💡 {len(failed_metrics)}개 메트릭이 임계값 미달입니다. "
                        "개선 가이드를 확인하세요."
                    )
                with col2:
                    if st.button("🔧 개선 가이드", key="home_improve_btn"):
                        session.current_run_id = latest_run.run_id

        except Exception as e:
            st.warning(f"품질 게이트 정보를 가져오는 데 실패했습니다: {e}")
    else:
        st.info("아직 평가 결과가 없습니다.")

    # 최근 평가 목록
    st.divider()
    st.subheader("최근 평가")

    recent_list = RecentRunsList(runs=filtered_runs, max_items=5)

    if not recent_list.is_empty:
        for run in recent_list.displayed_runs:
            col1, col2, col3, col4, col5 = st.columns([3, 1, 1, 1, 1])
            with col1:
                emoji = recent_list.get_pass_rate_emoji(run.pass_rate)
                project_label = run.project_name or "미분류"
                st.text(f"{emoji} {run.dataset_name}")
                st.caption(f"프로젝트: {project_label}")
                extra_bits: list[str] = []
                if run.phoenix_precision is not None:
                    extra_bits.append(f"P@K {run.phoenix_precision:.2f}")
                if run.phoenix_drift is not None:
                    extra_bits.append(f"Drift {run.phoenix_drift:.2f}")
                if extra_bits:
                    st.caption(" | ".join(extra_bits))
                if run.phoenix_experiment_url:
                    st.caption(f"[Phoenix Experiment]({run.phoenix_experiment_url})")
            with col2:
                st.text(run.model_name)
            with col3:
                pass_rate_pct = run.pass_rate * 100
                if pass_rate_pct >= 70:
                    st.success(f"{pass_rate_pct:.1f}%")
                elif pass_rate_pct >= 50:
                    st.warning(f"{pass_rate_pct:.1f}%")
                else:
                    st.error(f"{pass_rate_pct:.1f}%")
            with col4:
                st.text(run.started_at.strftime("%m/%d"))
            with col5:
                if st.button("🔧", key=f"improve_{run.run_id}", help="개선 가이드"):
                    session.current_run_id = run.run_id

        if recent_list.has_more:
            st.caption(f"+{recent_list.remaining_count} more runs...")
    else:
        st.info("아직 평가 이력이 없습니다. 첫 평가를 실행해보세요!")


def render_evaluate_page(adapter, session):
    """평가 실행 페이지 렌더링."""
    import streamlit as st

    from evalvault.adapters.inbound.web.components import (
        FileUploadHandler,
        MetricSelector,
    )
    from evalvault.adapters.inbound.web.components.projects import collect_project_names

    st.header("📊 Evaluate")
    st.markdown("데이터셋을 업로드하고 RAG 평가를 실행합니다.")
    st.markdown(
        """
        <style>
        .mode-pill {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            border-radius: 999px;
            font-size: 0.85rem;
            font-weight: 600;
            color: white;
        }
        .mode-pill.simple { background: #0ea5e9; }
        .mode-pill.full { background: #7c3aed; }
        </style>
        """,
        unsafe_allow_html=True,
    )

    st.subheader("0. 실행 모드 선택")
    mode_label = st.radio(
        "모드",
        options=["Simple", "Full"],
        horizontal=True,
        index=0 if session.selected_run_mode == "simple" else 1,
        help="Simple은 기본 메트릭/트래커를 고정하고 Full은 모든 고급 옵션을 노출합니다.",
    )
    session.selected_run_mode = "simple" if mode_label == "Simple" else "full"
    simple_mode_active = session.selected_run_mode == "simple"
    pill_class = "simple" if simple_mode_active else "full"
    st.markdown(
        f"<span class='mode-pill {pill_class}'>Mode · {mode_label}</span>",
        unsafe_allow_html=True,
    )
    if simple_mode_active:
        st.info("심플 모드는 faithfulness/answer_relevancy + Phoenix tracker를 고정합니다.")
    else:
        st.caption(
            "전체 모드: Domain Memory·Prompt·Phoenix dataset/experiment 옵션을 사용할 수 있습니다."
        )

    # 초기화
    upload_handler = FileUploadHandler()
    metric_selector = MetricSelector()

    # 파일 업로드 섹션
    st.subheader("1. 데이터셋 업로드")

    uploaded_file = st.file_uploader(
        "데이터셋 업로드",
        type=["csv", "json", "xlsx"],
        help="CSV, JSON, 또는 Excel 형식의 데이터셋을 업로드하세요.",
    )

    validation_result = None
    if uploaded_file:
        # 파일 검증
        content = uploaded_file.read()
        uploaded_file.seek(0)  # 다시 읽을 수 있도록 리셋

        validation_result = upload_handler.validate_file(uploaded_file.name, content)

        if validation_result.is_valid:
            st.success(
                f"✅ {uploaded_file.name} ({validation_result.row_count} rows, "
                f"{validation_result.file_type.upper()})"
            )
            if validation_result.dataset_name:
                st.caption(f"Dataset: {validation_result.dataset_name}")
            # 임계값 정보 표시
            if validation_result.thresholds:
                threshold_str = ", ".join(
                    f"{k}: {v:.2f}" for k, v in validation_result.thresholds.items()
                )
                st.caption(f"📏 임계값: {threshold_str}")
            else:
                st.caption("📏 임계값: 기본값 0.7 적용 (JSON에 thresholds 미지정)")
        else:
            st.error(f"❌ {validation_result.error_message}")

    # 프로젝트 선택 섹션
    st.divider()
    st.subheader("2. 프로젝트 선택")

    existing_projects = collect_project_names(adapter.list_runs(limit=200))
    project_choice = st.selectbox(
        "프로젝트",
        options=["선택 안 함", "직접 입력"] + existing_projects,
        index=0,
        help="평가 결과를 프로젝트 단위로 묶어 대시보드에서 필터링할 수 있습니다.",
    )

    project_name = None
    if project_choice == "직접 입력":
        project_name = st.text_input(
            "새 프로젝트 이름",
            value=session.selected_project or "",
            placeholder="예: 보험 QA 개선",
        ).strip()
    elif project_choice != "선택 안 함":
        project_name = project_choice

    session.selected_project = project_name or None

    # 메트릭 선택 섹션
    st.divider()
    st.subheader("3. 메트릭 선택")

    # 카테고리별 그룹화
    categories = metric_selector.get_metrics_by_category()

    selected_metrics = []
    for category, metrics in categories.items():
        with st.expander(f"📁 {category.title()}", expanded=category == "generation"):
            cols = st.columns(2)
            for i, metric in enumerate(metrics):
                with cols[i % 2]:
                    icon = metric_selector.get_icon(metric)
                    desc = metric_selector.get_description(metric)
                    default_selected = metric in metric_selector.get_default_metrics()
                    checkbox_disabled = simple_mode_active
                    checked = st.checkbox(
                        f"{icon} {metric}",
                        value=default_selected,
                        help=desc,
                        disabled=checkbox_disabled,
                        key=f"metric_{metric}",
                    )
                    if checked:
                        selected_metrics.append(metric)

    if simple_mode_active:
        selected_metrics = metric_selector.get_default_metrics()

    session.selected_metrics = selected_metrics

    # 선택된 메트릭 표시
    if selected_metrics:
        st.caption(f"Selected: {', '.join(selected_metrics)}")

    # 고급 옵션
    st.divider()
    with st.expander("⚙️ 고급 옵션"):
        col1, col2, col3 = st.columns(3)
        with col1:
            session.selected_model = st.selectbox(
                "모델",
                options=[
                    "gpt-5-nano (OpenAI)",
                    "gemma3:1b (Ollama, dev)",
                    "gpt-oss-safeguard:20b (Ollama, prod)",
                ],
                index=0,
            )
        with col2:
            session.langfuse_enabled = st.checkbox("Langfuse 트래킹", value=False)
        with col3:
            session.parallel_processing = st.checkbox("병렬 처리", value=True)

        # 임계값 안내 (데이터셋에서 로드됨)
        st.caption(
            "💡 메트릭 임계값은 데이터셋 JSON의 `thresholds`에서 로드됩니다. "
            "미지정 시 기본값 0.7 적용."
        )

    # 실행 버튼
    st.divider()
    can_run = (
        validation_result is not None
        and validation_result.is_valid
        and len(selected_metrics) > 0
        and not session.is_evaluating
    )

    col1, col2 = st.columns([3, 1])
    with col1:
        if st.button("🚀 평가 실행", type="primary", disabled=not can_run):
            # LLM 설정 확인
            if adapter._llm_adapter is None:
                st.error("LLM이 설정되지 않았습니다. .env 파일에 OPENAI_API_KEY를 설정해주세요.")
            else:
                try:
                    # 평가 시작 상태 설정
                    session.is_evaluating = True

                    # 파일 내용 읽기
                    file_content = uploaded_file.getvalue()

                    # st.status를 사용하여 진행 상태 표시
                    with st.status("🔄 평가 진행 중...", expanded=True) as status:
                        # Dataset 생성
                        status.write("📂 데이터셋 파싱 중...")
                        dataset = adapter.create_dataset_from_upload(
                            uploaded_file.name,
                            file_content,
                        )
                        status.write(f"✅ 데이터셋 로드 완료: {len(dataset.test_cases)}개 케이스")

                        # 데이터셋에서 Threshold 로드 (미지정 시 기본값 0.7)
                        thresholds = dataset.thresholds or {}
                        if thresholds:
                            status.write(f"📏 임계값 로드: {thresholds}")
                        else:
                            status.write("📏 임계값: 기본값 0.7 적용")

                        # 메트릭 정보 표시
                        status.write(f"📊 평가 메트릭: {', '.join(selected_metrics)}")
                        status.write("⏳ LLM API 호출 중... (1-2분 소요될 수 있습니다)")

                        # 평가 실행
                        import time

                        start_time = time.time()
                        parallel_mode = session.parallel_processing
                        mode_str = "병렬" if parallel_mode else "순차"
                        status.write(f"⚡ 실행 모드: {mode_str} 처리")

                        result = adapter.run_evaluation_with_dataset(
                            dataset=dataset,
                            metrics=selected_metrics,
                            thresholds=thresholds,
                            parallel=parallel_mode,
                            batch_size=5,
                            run_mode=session.selected_run_mode,
                            project_name=session.selected_project,
                        )
                        elapsed = time.time() - start_time

                        # 완료 상태로 업데이트
                        status.update(label="✅ 평가 완료!", state="complete", expanded=False)
                        status.write(f"⏱️ 소요 시간: {elapsed:.1f}초")

                    # 결과 표시
                    st.success(f"✅ 평가 완료! (Run ID: `{result.run_id}`)")
                    if session.selected_project:
                        st.caption(f"프로젝트: {session.selected_project}")

                    # 요약 메트릭
                    result_cols = st.columns(4)
                    with result_cols[0]:
                        st.metric("통과율", f"{result.pass_rate:.1%}")
                    with result_cols[1]:
                        st.metric("테스트 케이스", result.total_test_cases)
                    with result_cols[2]:
                        passed = result.passed_test_cases
                        st.metric("통과", f"{passed}/{result.total_test_cases}")
                    with result_cols[3]:
                        duration = result.duration_seconds or 0
                        st.metric("소요 시간", f"{duration:.1f}s")

                    # 메트릭별 점수
                    st.subheader("📊 메트릭별 결과")
                    metric_results = []
                    for metric in result.metrics_evaluated:
                        score = result.get_avg_score(metric)
                        threshold = thresholds.get(metric, 0.7)
                        passed = score >= threshold if score else False
                        metric_results.append(
                            {
                                "메트릭": metric,
                                "점수": f"{score:.3f}" if score else "N/A",
                                "임계값": f"{threshold:.2f}",
                                "결과": "✅ Pass" if passed else "❌ Fail",
                            }
                        )

                    st.dataframe(metric_results, width="stretch")

                    # 세션 상태 업데이트
                    session.current_run_id = result.run_id

                    # History 페이지 이동 안내
                    st.info(
                        f"📋 History 페이지에서 상세 결과를 확인할 수 있습니다. "
                        f"(Mode: {session.selected_run_mode.capitalize()})"
                    )

                except Exception as e:
                    st.error(f"❌ 평가 실패: {e}")
                    import traceback

                    st.code(traceback.format_exc())
                finally:
                    session.is_evaluating = False

    with col2:
        if session.is_evaluating:
            st.warning("실행 중...")

    # 상태 메시지
    if not uploaded_file:
        st.info("💡 먼저 데이터셋 파일을 업로드하세요.")
    elif not validation_result or not validation_result.is_valid:
        st.warning("⚠️ 유효한 데이터셋 파일을 업로드하세요.")
    elif not selected_metrics:
        st.warning("⚠️ 최소 하나의 메트릭을 선택하세요.")
    elif adapter._llm_adapter is None:
        st.warning("⚠️ LLM이 설정되지 않았습니다. .env에 OPENAI_API_KEY를 설정하세요.")


def render_improvement_page(adapter, session):
    """개선 가이드 페이지 렌더링."""
    import streamlit as st

    from evalvault.adapters.inbound.web.components import RunSelector, render_model_selector

    # LLM 분석 다이얼로그
    @st.dialog("🔧 LLM 개선 가이드 생성", width="large")
    def llm_improvement_dialog(run_id: str, run_name: str):
        """LLM 개선 가이드 생성 모달."""
        st.markdown(f"**대상 평가:** {run_name}")
        st.divider()

        # 모델 선택
        st.subheader("분석 모델 선택")
        selected_model = render_model_selector(
            st,
            key="dialog_improve_model",
            label="LLM 모델",
            help_text="개선 가이드 생성에 사용할 LLM 모델을 선택하세요.",
        )

        col1, col2 = st.columns([3, 1])
        with col1:
            generate_clicked = st.button(
                "🚀 분석 시작",
                type="primary",
                use_container_width=True,
            )
        with col2:
            if st.button("취소", use_container_width=True):
                st.rerun()

        if generate_clicked:
            model_id = selected_model.id if selected_model else None
            model_name = selected_model.display_name if selected_model else "기본 모델"

            with st.status("🔧 LLM 개선 가이드 생성 중...", expanded=True) as status:
                try:
                    status.write(f"📊 모델: **{model_name}**")
                    status.write("🧠 LLM 분석 시작...")
                    status.write("⏳ 약 1-2분 소요될 수 있습니다...")

                    # LLM 개선 가이드 생성
                    report = adapter.get_improvement_guide(
                        run_id,
                        include_llm=True,
                        model_id=model_id,
                    )

                    status.update(
                        label="✅ LLM 개선 가이드 생성 완료!",
                        state="complete",
                        expanded=False,
                    )

                    # 세션에 저장
                    session.improvement_report = report
                    st.session_state.last_improve_options = {
                        "run_id": run_id,
                        "include_llm": True,
                        "model_id": model_id,
                    }

                    st.success("✅ 개선 가이드 생성 완료!")
                    st.info("다이얼로그를 닫으면 결과를 확인할 수 있습니다.")

                    if st.button("📄 결과 확인", type="primary", use_container_width=True):
                        st.rerun()

                except Exception as e:  # noqa: BLE001
                    status.update(label="❌ 생성 실패", state="error")
                    st.error(f"❌ 개선 가이드 생성 실패: {e}")
                    import traceback

                    with st.expander("오류 상세"):
                        st.code(traceback.format_exc())

    st.header("🔧 개선 가이드")
    st.markdown("평가 결과를 분석하여 RAG 시스템 개선 방안을 제안합니다.")

    # 평가 결과 조회
    runs = adapter.list_runs(limit=50)

    if not runs:
        st.info("분석할 평가 결과가 없습니다. 먼저 평가를 실행해주세요.")
        return

    # 실행 선택 섹션
    st.subheader("1. 평가 선택")
    selector = RunSelector(runs=runs)
    options = selector.get_options()

    selected_option = st.selectbox(
        "분석할 평가 실행 선택",
        options=options,
        format_func=lambda x: x,
        help="개선 가이드를 생성할 평가 실행을 선택하세요.",
    )

    # 선택된 실행 ID 추출
    selected_run_id = selected_option.split(" | ")[0] if selected_option else None
    selected_run = selector.get_by_id(selected_run_id) if selected_run_id else None

    if not selected_run:
        return

    # 선택된 평가 정보 및 품질 게이트
    st.divider()
    st.subheader("2. 품질 현황")

    # 품질 게이트 체크
    try:
        gate_report = adapter.check_quality_gate(selected_run_id)

        # 전체 상태 표시
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("전체 통과율", f"{selected_run.pass_rate:.1%}")
        with col2:
            if gate_report.overall_passed:
                st.success("✅ 품질 게이트 PASS")
            else:
                st.error("❌ 품질 게이트 FAIL")
        with col3:
            st.metric("테스트 케이스", selected_run.total_test_cases)

        # 메트릭별 현황
        st.markdown("**메트릭별 현황**")
        for result in gate_report.results:
            col1, col2, col3, col4 = st.columns([3, 1, 1, 1])
            with col1:
                # 프로그레스 바
                st.progress(result.score, text=result.metric)
            with col2:
                st.text(f"{result.score:.2f}")
            with col3:
                st.text(f"/ {result.threshold:.2f}")
            with col4:
                if result.passed:
                    st.success("✅")
                else:
                    st.error("❌")

    except Exception as e:
        st.warning(f"품질 게이트 정보를 가져오는 데 실패했습니다: {e}")

    # 개선 가이드 생성 옵션
    st.divider()
    st.subheader("3. 개선 가이드 생성")

    analysis_type = st.radio(
        "분석 유형",
        options=["llm_analysis", "basic"],
        format_func=lambda x: {
            "llm_analysis": "🤖 LLM 분석 (권장) - AI 기반 심층 분석",
            "basic": "📝 기본 분석 - 규칙 기반 패턴 분석",
        }.get(x, x),
        horizontal=False,
        help="LLM 분석은 더 상세한 개선 제안을 제공합니다.",
    )

    # LLM 분석 선택 시
    if analysis_type == "llm_analysis":
        st.info(
            "💡 **LLM 분석**은 AI를 활용하여 실패 원인을 심층 분석하고 "
            "구체적인 개선 방안을 제안합니다. (LLM API 호출로 인해 1-2분 소요될 수 있습니다)"
        )

        if adapter._llm_adapter is None:
            st.error("LLM이 설정되지 않았습니다. .env 파일에 OPENAI_API_KEY를 설정해주세요.")
        elif selected_run is None:
            st.warning("먼저 평가를 선택해주세요.")
        else:
            if st.button(
                "🤖 LLM 분석 시작",
                type="primary",
                help="클릭하면 모달 창에서 분석을 수행합니다.",
            ):
                llm_improvement_dialog(
                    selected_run.run_id,
                    f"{selected_run.dataset_name} ({selected_run.run_id[:8]}...)",
                )

    # 기본 분석 선택 시
    else:
        if st.button("🔍 기본 분석 시작", type="primary"):
            with st.spinner("개선 가이드 생성 중..."):
                try:
                    report = adapter.get_improvement_guide(
                        selected_run_id,
                        include_llm=False,
                        model_id=None,
                    )

                    # 세션에 저장
                    session.improvement_report = report
                    st.session_state.last_improve_options = {
                        "run_id": selected_run_id,
                        "include_llm": False,
                        "model_id": None,
                    }
                    st.success("✅ 기본 분석 완료!")

                except Exception as e:
                    st.error(f"개선 가이드 생성 실패: {e}")
                    return

    # 옵션 변경 시 이전 결과 무효화
    if "last_improve_options" not in st.session_state:
        st.session_state.last_improve_options = {
            "run_id": None,
            "include_llm": False,
            "model_id": None,
        }

    options_changed = st.session_state.last_improve_options["run_id"] != selected_run_id

    if options_changed and hasattr(session, "improvement_report") and session.improvement_report:
        # 평가가 변경되면 이전 결과 무효화
        session.improvement_report = None

    # 개선 가이드 표시
    if hasattr(session, "improvement_report") and session.improvement_report:
        report = session.improvement_report

        st.divider()
        st.subheader("4. 개선 가이드")

        # 요약
        st.markdown(
            f"""
        **분석 요약**
        - 분석 대상: {report.run_id}
        - 테스트 케이스: {report.total_test_cases}개
        - 실패 케이스: {report.failed_test_cases}개
        - 통과율: {report.pass_rate:.1%}
        """
        )

        # 가이드 목록
        if report.guides:
            for i, guide in enumerate(report.guides, 1):
                priority_colors = {
                    "P0_CRITICAL": "🔴",
                    "P1_HIGH": "🟠",
                    "P2_MEDIUM": "🟡",
                    "P3_LOW": "🟢",
                }
                priority_icon = priority_colors.get(guide.priority.name, "⚪")

                with st.expander(
                    f"{priority_icon} {i}. {guide.component.value.title()} 개선 "
                    f"(예상 +{guide.total_expected_improvement:.0%})",
                    expanded=i == 1,
                ):
                    # 대상 메트릭
                    st.markdown(f"**대상 메트릭**: {', '.join(guide.target_metrics)}")

                    # 증거 데이터
                    if guide.evidence:
                        st.markdown("**증거 데이터**")
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("실패 케이스", guide.evidence.total_failures)
                        with col2:
                            if guide.evidence.avg_score_failures:
                                st.metric(
                                    "실패 평균 점수",
                                    f"{guide.evidence.avg_score_failures:.2f}",
                                )
                        with col3:
                            if guide.evidence.avg_score_passes:
                                st.metric(
                                    "통과 평균 점수",
                                    f"{guide.evidence.avg_score_passes:.2f}",
                                )

                    # 개선 액션
                    st.markdown("**권장 액션**")
                    for j, action in enumerate(guide.actions, 1):
                        effort_icons = {"low": "🟢", "medium": "🟡", "high": "🔴"}
                        effort_icon = effort_icons.get(action.effort.value, "⚪")

                        st.markdown(
                            f"{j}. **{action.title}** {effort_icon} "
                            f"(예상 +{action.expected_improvement:.0%})"
                        )
                        st.caption(action.description)

                        if action.implementation_hint:
                            st.code(action.implementation_hint, language="python")

                    # 검증 방법
                    if guide.verification_command:
                        st.markdown("**검증 방법**")
                        st.code(guide.verification_command, language="bash")
        else:
            st.info("탐지된 개선 패턴이 없습니다. 현재 시스템이 양호한 상태입니다.")

        # 마크다운 다운로드
        st.divider()
        if hasattr(report, "to_markdown"):
            st.download_button(
                "📥 마크다운 다운로드",
                data=report.to_markdown(),
                file_name=f"improvement_guide_{report.run_id}.md",
                mime="text/markdown",
            )


def render_customer_report_page(adapter, session):
    """고객 공유용 리포트 페이지 렌더링."""
    import streamlit as st

    from evalvault.adapters.inbound.web.components import (
        ALL_PROJECTS_TOKEN,
        DashboardStats,
        build_project_options,
        create_metric_trend_chart,
        create_trend_chart,
        filter_runs_by_projects,
    )

    st.header("🧾 고객 리포트")
    st.markdown(
        """
        고객에게 공유하기 쉬운 요약 리포트를 제공합니다.
        기간/프로젝트 필터를 적용한 뒤 HTML로 내보낼 수 있습니다.
        """
    )

    runs = adapter.list_runs(limit=300)

    filter_col1, filter_col2 = st.columns([2, 3])
    with filter_col1:
        range_label = st.selectbox(
            "기간",
            options=["최근 7일", "최근 30일", "최근 90일", "올해", "전체", "직접 선택"],
            index=1,
            key="customer_range",
        )
        custom_range = None
        if range_label == "직접 선택":
            today = datetime.now().date()
            custom_range = st.date_input(
                "기간 선택",
                value=(today - timedelta(days=29), today),
                key="customer_range_custom",
            )

    with filter_col2:
        project_options = build_project_options(runs)
        selected_projects = st.multiselect(
            "프로젝트",
            options=project_options,
            default=[ALL_PROJECTS_TOKEN],
            format_func=_project_label,
            key="customer_projects",
        )

    date_from, date_to = _resolve_date_range(range_label, custom_range)
    filtered_runs = filter_runs_by_projects(runs, selected_projects)
    filtered_runs = _filter_runs_by_date(filtered_runs, date_from, date_to)
    filtered_runs = sorted(filtered_runs, key=lambda r: r.started_at, reverse=True)

    stats = DashboardStats.from_runs(filtered_runs)

    st.subheader("요약")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("평가 수", f"{stats.total_runs:,}")
    with col2:
        st.metric("테스트 케이스", f"{stats.total_test_cases:,}")
    with col3:
        st.metric("평균 통과율", f"{stats.avg_pass_rate * 100:.1f}%")
    with col4:
        st.metric("총 비용 (USD)", f"${(stats.total_cost or 0.0):,.2f}")

    st.divider()
    chart_col1, chart_col2 = st.columns(2)
    with chart_col1:
        trend_fig = create_trend_chart(filtered_runs, title="기간별 Pass Rate")
        st.plotly_chart(trend_fig, width="stretch", key="customer_trend_chart")
    with chart_col2:
        metric_candidates = sorted(
            {
                metric
                for run in filtered_runs
                for metric in (getattr(run, "avg_metric_scores", {}) or {})
            }
        )
        selected_metrics = st.multiselect(
            "메트릭 트렌드",
            options=metric_candidates,
            default=metric_candidates[:2],
            key="customer_metric_trend",
        )
        metric_fig = create_metric_trend_chart(
            filtered_runs,
            selected_metrics,
            title="메트릭 평균 추이",
        )
        st.plotly_chart(metric_fig, width="stretch", key="customer_metric_trend_chart")

    st.divider()
    st.subheader("최근 평가 요약")
    if filtered_runs:
        summary_rows = [
            {
                "Date": run.started_at.strftime("%Y-%m-%d"),
                "Project": run.project_name or "미분류",
                "Dataset": run.dataset_name,
                "Model": run.model_name,
                "Pass Rate": f"{run.pass_rate * 100:.1f}%",
                "Test Cases": run.total_test_cases,
            }
            for run in filtered_runs[:10]
        ]
        st.dataframe(summary_rows, width="stretch")
    else:
        st.info("선택한 조건에 해당하는 평가가 없습니다.")

    st.divider()
    st.subheader("공유용 리포트")
    if ALL_PROJECTS_TOKEN in selected_projects:
        project_labels = ["전체"]
    else:
        project_labels = [_project_label(name) for name in selected_projects]

    if range_label == "직접 선택" and custom_range and len(custom_range) == 2:
        range_display = f"{custom_range[0]} ~ {custom_range[1]}"
    else:
        range_display = range_label

    html_report = _build_customer_report_html(
        stats=stats,
        range_label=range_display,
        project_labels=project_labels,
        trend_fig=trend_fig,
        metric_fig=metric_fig,
    )

    st.download_button(
        "📥 HTML 리포트 다운로드",
        data=html_report,
        file_name="evalvault_customer_report.html",
        mime="text/html",
    )
    st.caption("생성된 HTML을 고객에게 전달하면 읽기 전용 리포트로 활용할 수 있습니다.")


def main():
    """Streamlit 앱 진입점."""
    create_app()


if __name__ == "__main__":
    main()
