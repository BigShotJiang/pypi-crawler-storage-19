"""Structure validation utilities."""
