# Project Metrics

| Metric | Main code | Unit Tests | Total |
|--------|-----------|------------|-------|
| Lines Of Code (LOC) | 3330 | 6624 | 9954 |
| Source Lines Of Code (SLOC) | 1481 | 3925 | 5406 |
| Classes | 13 | 133 | 146 |
| Functions / Methods | 100 | 582 | 682 |
| Files | 15 | 48 | 63 |
