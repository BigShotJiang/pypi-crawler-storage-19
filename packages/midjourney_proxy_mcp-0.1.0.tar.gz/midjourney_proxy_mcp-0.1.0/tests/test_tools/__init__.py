"""Tests for MCP Tools."""
