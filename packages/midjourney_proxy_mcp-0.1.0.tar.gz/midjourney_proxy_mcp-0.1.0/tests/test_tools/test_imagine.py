"""Tests for midjourney_imagine tool."""

import pytest
from pytest_httpx import HTTPXMock

from midjourney_proxy_mcp.tools import midjourney_imagine

pytestmark = pytest.mark.asyncio


class TestMidjourneyImagine:
    """Tests for midjourney_imagine function."""

    async def test_imagine_success(self, httpx_mock: HTTPXMock) -> None:
        """프롬프트로 이미지 생성 요청 성공."""
        httpx_mock.add_response(
            method="POST",
            url="https://api.imagineapi.dev/items/images",
            match_json={"prompt": "A beautiful sunset over the ocean"},
            json={
                "data": {
                    "id": "img-123",
                    "prompt": "A beautiful sunset over the ocean",
                    "status": "pending",
                    "result": None,
                    "url": None,
                    "results": None,
                    "progress": None,
                    "upscaled_urls": None,
                    "upscaled": None,
                    "ref": None,
                    "error": None,
                    "user_created": "user-abc",
                    "date_created": "2024-01-01T00:00:00Z",
                }
            },
        )

        result = await midjourney_imagine(prompt="A beautiful sunset over the ocean")

        assert result["id"] == "img-123"
        assert result["prompt"] == "A beautiful sunset over the ocean"
        assert result["status"] == "pending"
        assert "message" in result

    async def test_imagine_with_ref(self, httpx_mock: HTTPXMock) -> None:
        """참조 ID와 함께 이미지 생성 요청."""
        httpx_mock.add_response(
            method="POST",
            url="https://api.imagineapi.dev/items/images",
            match_json={
                "prompt": "A majestic mountain --ar 16:9",
                "ref": "my-ref-123",
            },
            json={
                "data": {
                    "id": "img-456",
                    "prompt": "A majestic mountain --ar 16:9",
                    "status": "pending",
                    "result": None,
                    "url": None,
                    "results": None,
                    "progress": None,
                    "upscaled_urls": None,
                    "upscaled": None,
                    "ref": "my-ref-123",
                    "error": None,
                    "user_created": "user-abc",
                    "date_created": "2024-01-01T00:00:00Z",
                }
            },
        )

        result = await midjourney_imagine(
            prompt="A majestic mountain --ar 16:9",
            ref="my-ref-123",
        )

        assert result["id"] == "img-456"
        assert result["status"] == "pending"

    async def test_imagine_empty_prompt_fails(self) -> None:
        """빈 프롬프트는 ValidationError 발생."""
        from pydantic import ValidationError

        with pytest.raises(ValidationError):
            await midjourney_imagine(prompt="")

    async def test_imagine_api_error(self, httpx_mock: HTTPXMock) -> None:
        """API 오류 시 ImagineAPIError 발생."""
        from midjourney_proxy_mcp.client import ImagineAPIError

        httpx_mock.add_response(
            method="POST",
            url="https://api.imagineapi.dev/items/images",
            status_code=500,
            json={"error": "Internal server error"},
        )

        with pytest.raises(ImagineAPIError) as exc_info:
            await midjourney_imagine(prompt="test prompt")

        assert exc_info.value.status_code == 500


@pytest.mark.integration
class TestMidjourneyImagineIntegration:
    """Integration tests for midjourney_imagine (requires IMAGINEAPI_TOKEN)."""

    async def test_imagine_real_api(self) -> None:
        """실제 API로 이미지 생성 테스트."""
        result = await midjourney_imagine(
            prompt="A simple test image --test --turbo",
            ref="integration-test",
        )

        assert "id" in result
        assert result["status"] in ["pending", "in-progress"]
        assert "message" in result
