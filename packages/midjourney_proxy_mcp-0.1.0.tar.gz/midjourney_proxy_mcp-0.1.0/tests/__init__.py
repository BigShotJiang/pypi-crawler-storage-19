"""Tests for Midjourney Proxy MCP Server."""
