"""Tests for FastMCP server skeleton."""

import pytest

from midjourney_proxy_mcp.server import (
    VALID_STATUSES,
    list_images,
    main,
    mcp,
    resource_generations_by_status,
)


class TestServerSkeleton:
    """Tests for server skeleton."""

    def test_mcp_instance_exists(self) -> None:
        """Test that MCP instance is created."""
        assert mcp is not None
        assert mcp.name == "midjourney_mcp"

    def test_mcp_has_instructions(self) -> None:
        """Test that MCP has instructions."""
        assert mcp.instructions == "Generate Midjourney images via ImagineAPI"

    def test_main_function_exists(self) -> None:
        """Test that main function exists and is callable."""
        assert callable(main)

    def test_valid_statuses_defined(self) -> None:
        """Test that VALID_STATUSES contains expected values."""
        assert {"pending", "in-progress", "completed", "failed"} == VALID_STATUSES


@pytest.mark.asyncio
class TestListImagesValidation:
    """Tests for list_images status validation."""

    async def test_invalid_status_raises_error(self) -> None:
        """Invalid status raises ValueError with helpful message."""
        with pytest.raises(ValueError) as exc_info:
            await list_images(status="invalid-status")

        assert "Invalid status 'invalid-status'" in str(exc_info.value)
        assert "Allowed values:" in str(exc_info.value)


@pytest.mark.asyncio
class TestResourceGenerationsByStatusValidation:
    """Tests for resource_generations_by_status status validation."""

    async def test_invalid_status_raises_error(self) -> None:
        """Invalid status raises ValueError with helpful message."""
        with pytest.raises(ValueError) as exc_info:
            await resource_generations_by_status(status="invalid-status")

        assert "Invalid status 'invalid-status'" in str(exc_info.value)
        assert "Allowed values:" in str(exc_info.value)
