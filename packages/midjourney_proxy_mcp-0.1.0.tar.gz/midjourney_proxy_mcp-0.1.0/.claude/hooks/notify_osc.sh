#!/bin/bash
# Claude Code OSC Notification Script
# /dev/tty로 출력하여 터미널에 직접 전달

# stdin에서 JSON 읽기 (timeout으로 blocking 방지)
INPUT=$(timeout 1 cat 2>/dev/null || true)

# JSON 파싱
if command -v jq &>/dev/null && [ -n "$INPUT" ]; then
    SESSION_ID=$(echo "$INPUT" | jq -r '.session_id // empty' 2>/dev/null)
    CWD=$(echo "$INPUT" | jq -r '.cwd // empty' 2>/dev/null)
    EVENT=$(echo "$INPUT" | jq -r '.hook_event_name // empty' 2>/dev/null)
    NOTIF_TYPE=$(echo "$INPUT" | jq -r '.notification_type // empty' 2>/dev/null)
    MESSAGE=$(echo "$INPUT" | jq -r '.message // empty' 2>/dev/null)

    FOLDER=$(basename "${CWD:-$PWD}" 2>/dev/null)
    SHORT_ID="${SESSION_ID:0:8}"

    # 제목 구성
    TITLE="Claude"
    [ -n "$FOLDER" ] && TITLE="$TITLE - $FOLDER"
    [ -n "$SHORT_ID" ] && TITLE="$TITLE [$SHORT_ID]"

    # 본문 구성
    case "$EVENT" in
        "Stop")
            BODY="Task completed"
            ;;
        "Notification")
            case "$NOTIF_TYPE" in
                "permission_prompt") BODY="Permission needed" ;;
                "idle_prompt") BODY="Waiting for input" ;;
                *) BODY="${MESSAGE:-$NOTIF_TYPE}" ;;
            esac
            ;;
        *)
            BODY="${MESSAGE:-Notification}"
            ;;
    esac
else
    TITLE="${1:-Claude Code}"
    BODY="${2:-Task completed}"
fi

# OSC 777 알림 출력 (OSC 9는 중복 알림 발생하므로 제외)
# /dev/tty 사용 가능 시 직접 출력, 아니면 stdout
{
    printf '\033]777;notify;%s;%s\007' "$TITLE" "$BODY"
} > /dev/tty 2>/dev/null || {
    printf '\033]777;notify;%s;%s\007' "$TITLE" "$BODY"
}

exit 0
