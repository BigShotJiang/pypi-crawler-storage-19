---
description: Decompose Work
---

## Decompose Work

Break down large work items into manageable, independent issues. Follow project guidelines in `@CLAUDE.md`.

## Workflow

1. Check issue numbers: Run `gh issue list` to view current issue numbers
2. **Discover available components**:
   - Scan `.claude/agents/` for custom agents (read YAML frontmatter)
   - Detect test frameworks (jest.config.*, pytest.ini, vitest.config.*, pyproject.toml, etc.)
3. **Check TDD applicability** (if user hasn't specified):
   - Analyze work type: code implementation vs docs/infra/config
   - If test framework detected + code work → Ask: "TDD 기반으로 이슈 생성하시겠어요?"
   - If no test framework → Inform: "TDD 반영이 필요없습니다. (이유: 테스트 프레임워크 미감지)"
   - If non-code work (docs/infra) → Inform: "TDD 반영이 필요없습니다. (이유: 비코드 작업)"
   - If TDD selected: Add `<!-- TDD: enabled -->` marker to each issue body
4. Analyze work: Understand core requirements and objectives
5. Decompose work: Split major tasks into smaller, manageable sub-tasks or issues. **Aim for optimal count over excessive issues (keep it manageable)**
6. Analyze dependencies: Identify prerequisite tasks
7. Suggest milestone name: Propose a milestone to group decomposed tasks
8. Check related PRs (optional): Run `gh pr list --state closed --limit 20` for similar work references (skip if none)
9. Output decomposed issues: Display issues with proposed milestone name
10. Ask about GitHub creation: Use AskUserQuestion to let user decide on milestone and issue creation
    - Create milestone: `gh api repos/:owner/:repo/milestones -f title="Milestone Name" -f description="Description"`
    - Assign issues with `--milestone` option
11. **Add issues to GitHub Project (optional)**
   - Check for existing projects: `gh project list --owner <owner> --format json`
   - If no project exists: Display "No project found. You can create one with `/gh:init-project`" and skip
   - If project exists: Ask user via AskUserQuestion whether to add issues
   - If yes: Run `gh project item-add <project-number> --owner <owner> --url <issue-url>` for each issue

## Milestone Description Guidelines

Milestone description must include:
- Overall objectives and scope
- Issue processing order (dependency graph)
- Example: "Issue order: #1 -> #2 -> #3 -> #4"

## Issue Template

### Title
`[Type] Concise task description`

### Labels (Use actual repository labels)
**Note**: Before assigning labels, verify repository labels with `gh label list`.

Examples (vary by project, for reference only):
- **Type**: `type: feature`, `type: documentation`, `type: enhancement`, `type: bug`
- **Area**: `area: model/inference`, `area: model/training`, `area: dataset`, `area: detection`
- **Complexity**: `complexity: easy`, `complexity: medium`, `complexity: hard`
- **Priority**: `priority: high`, `priority: medium`, `priority: low`

### Description
<!-- TDD: enabled --> ← Add this marker if TDD was selected in Step 3

**Purpose**: [Why this is needed]

**Tasks**:
- [ ] Specific requirement 1
- [ ] Specific requirement 2

**Files to modify**:
- `path/filename` - Change description

**Completion criteria**:
- [ ] Implementation complete (all tasks checked)
- [ ] Execution verified (no runtime errors)
- [ ] Tests pass (if applicable)
- [ ] Added to demo page (for UI components, if applicable)

**Dependencies**:
- [ ] None or prerequisite issue #number

**Execution strategy**:
- **Pattern**: main-only | sequential | parallel | delegation
- **Delegate to**: (delegation only) agent name

**Execution diagram**:
```
+------+
| main |
+------+
```

**References** (optional):
- Add related PRs if available (e.g., PR #36 - brief description)
- Omit this section if none

---

## Execution Strategy Guide

### Component Discovery

Before decomposing issues, scan for available agents:
- **Agents**: `.claude/agents/*.md` (extract name, description from YAML frontmatter)

### Execution Patterns

```
Pattern A: main-only
+------+
| main |
+------+

Pattern B: sequential
+---------+     +------+
| explore | --> | main |
+---------+     +------+

Pattern C: parallel
+---------+
| explore |--+
+---------+  |  +------+
| explore |--+->| main |
+---------+  |  +------+
| explore |--+
+---------+

Pattern D: delegation
+------+     +----------------+
| main | --> | python-pro     |
+------+     | web-researcher |
             +----------------+

Note: main can spawn subagents at any point during execution
```

### Pattern Selection

| Situation | Pattern | Example |
|-----------|---------|---------|
| Simple fix/change | main-only | Bug fix, single file change |
| Analysis then implement | sequential | New feature, refactoring |
| Complex analysis needed | parallel | Large refactor, architecture change |
| Specialized work | delegation | Python optimization, technical research |

### Diagram in Issues

Always include an ASCII diagram in the issue body to visualize the execution flow:

```
// main-only
+------+
| main |
+------+

// delegation
+------+     +--------------------+
| main | --> | deepfake-cv-expert |
+------+     +--------------------+

// sequential
+---------+     +------+
| explore | --> | main |
+---------+     +------+
```

---

## Verification Guidelines

이슈 작업 완료 시 반드시 실행 검증 수행:

| 작업 유형 | 검증 방법 |
|-----------|-----------|
| Python 코드 | `python -m py_compile file.py` + 실제 실행 |
| TypeScript/JS | `tsc --noEmit` 또는 빌드 |
| API/서버 | 엔드포인트 호출 테스트 |
| CLI 도구 | 기본 명령어 실행 |
| 설정 파일 | 관련 도구로 로드 확인 |

**파일만 생성하고 실행 검증 없이 완료 처리 금지**
