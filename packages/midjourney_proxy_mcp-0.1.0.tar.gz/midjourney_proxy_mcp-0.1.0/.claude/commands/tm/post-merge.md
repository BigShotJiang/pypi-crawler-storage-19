---
description: Post-Merge Cleanup (TaskMaster Integration)
---

# Post-Merge Cleanup (TaskMaster Integration)

After PR merge, perform branch cleanup, TaskMaster status update, and CLAUDE.md update.

**Important - ID Distinction:**
- **GitHub PR/Issue**: `#1`, `#2` (GitHub numbers)
- **TaskMaster Task**: `task 1`, `task 1.1` (based on tasks.json)

Follow project guidelines in `@CLAUDE.md`.

---

## Arguments

`$ARGUMENTS` parsing:
- If provided: Use as PR number (e.g., `/tm:post-merge 42`)
- If empty: Determine from conversation context or show recent merged PR list for selection

---

## Workflow

### 1. Verify PR Information

```bash
# Use PR number if provided as argument
# Otherwise show recent merged PR list
gh pr list --state merged --limit 5

# Get PR details
gh pr view <PR_NUMBER> --json number,title,baseRefName,headRefName,body,state
```

**Verify:**
- Check if `state` is `MERGED`
- Extract `Task Master reference: task N` from PR body

### 2. Extract TaskMaster Task ID

Identify TaskMaster ID from PR body or linked Issue:

```bash
# Extract from PR body
gh pr view <PR_NUMBER> --json body | grep -o "Task Master reference: task [0-9.]*"

# Or extract from linked Issue
gh pr view <PR_NUMBER> --json closedIssues
```

**Example extraction result:**
```
Task Master reference: task 1
-> TaskMaster Task ID: 1
-> Related Subtasks: 1.1, 1.2, 1.3 (if any)
```

### 3. Update TaskMaster Status

```bash
# Check main task status
task-master show <TASK_ID>

# Verify all subtasks are done
# If subtasks exist and all are complete:
task-master set-status --id=<TASK_ID> --status=done

# If subtasks exist and only some are complete:
# -> Keep main task as in-progress
# -> Mark only completed subtasks as done
```

**Status Update Rules:**

| Situation | Main Task Status | Subtask Status |
|-----------|------------------|----------------|
| PR merged, no subtasks | done | N/A |
| PR merged, all subtasks complete | done | all done |
| PR merged, some subtasks remain | in-progress | only completed ones done |

### 4. Check Local Changes

```bash
git status --porcelain
```

- **Untracked files (`??`)**: Ignore and proceed (no impact on branch switch)
- **Modified/Staged files (`M`, `A`, `D`, etc.)**: Ask via AskUserQuestion for handling:
  - **Stash and proceed**: `git stash push -m "post-merge: temp save"`
  - **Discard changes**: `git checkout -- . && git clean -fd`
  - **Abort**: User handles manually
- **If stash selected**: After completion, ask via AskUserQuestion about stash restore:
  - **pop**: `git stash pop` (restore and remove stash)
  - **apply**: `git stash apply` (restore and keep stash)
  - **later**: User handles manually

### 5. Switch to Base Branch

```bash
git fetch origin
git checkout <baseRefName>  # usually main
git pull origin <baseRefName>
```

### 6. Clean Up Issue Branch (Optional)

Ask via AskUserQuestion about local branch deletion:

```bash
# If deletion desired
git branch -d <headRefName>  # e.g., issue-1
```

### 7. Check Next Task

```bash
# Check next available task in TaskMaster
task-master next

# Example output:
# Next task: Task 2 - Build design system and theme
# Dependencies satisfied: Task 1 (done)
```

### 8. Analyze and Update Configuration Files

**Target files (check if exist):**
- `CLAUDE.md` - Claude Code specific instructions
- `AGENTS.md` - Cross-tool AI coding agent instructions (Codex, Cursor, Gemini, etc.)
- `GEMINI.md` - Google Gemini CLI specific instructions

**For each existing file, analyze:**
- Temporary instructions related to resolved Issue/Task (mentions of `#1`, `task 1`)
- Outdated or inaccurate information
- Newly discovered patterns/conventions

**Draft update proposal and confirm with user for each file:**
- Delete: Temporary notes related to resolved issues
- Add: New patterns discovered during work
- Modify: Changed information

### 9. Commit Changes (Optional)

If any configuration files were modified, ask via AskUserQuestion about committing:

```bash
# Add all modified config files
git add CLAUDE.md AGENTS.md GEMINI.md 2>/dev/null || true
git commit -m "docs: update config files (reflecting task $TASK_ID completion)"
git push origin main
```

---

## Result Report

```
[Post-Merge Cleanup Complete]

PR Info:
- PR: #<PR_NUMBER>
- Title: <PR title>
- Branch: <headRefName> -> <baseRefName>

TaskMaster Status:
- Task ID: task <N>
- Status: done
- Subtasks: all complete (1.1, 1.2, 1.3)

Cleanup:
- [x] Local branch deleted: issue-<N>
- [x] TaskMaster status updated
- [ ] CLAUDE.md updated (no changes)
- [ ] AGENTS.md updated (no changes / not found)
- [ ] GEMINI.md updated (no changes / not found)

Next Steps:
- task-master next -> Task <M>
- Start with /tm:resolve-issue <M>
```

---

## Work Guidelines

> See [Work Guidelines](../guidelines/work-guidelines.md)

---

## ID Reference

> See [ID Reference](../guidelines/id-reference.md)
