---
description: Convert Draft to TaskMaster PRD
---

# Convert Draft to TaskMaster PRD

Convert a draft file to TaskMaster PRD format.

**Template:** Copy `.claude/guidelines/prd-guide.md` to create draft

**Principles:**
- Preserve original content (do not add or remove arbitrarily)
- Write in Korean
- Follow `.taskmaster/templates/example_prd.txt` format

---

## Arguments

Receive draft file path via `$ARGUMENTS`:
- Example: `/tm:convert-prd .taskmaster/docs/my-idea.md`
- If empty, request path input via AskUserQuestion

---

## Workflow

### 1. Read Draft

```bash
cat $ARGUMENTS
```

If file does not exist or is empty, request content.

### 2. Verify Target Format

`.taskmaster/templates/example_prd.txt` structure:

```
<context>
# Overview
# Core Features
# User Experience
</context>

<PRD>
# Technical Architecture
# Development Roadmap
# Logical Dependency Chain
# Risks and Mitigations
# Appendix
</PRD>
```

### 3. Convert

Rearrange draft content to match the format above:

| Draft Section | PRD Section |
|---------------|-------------|
| What to build | Overview |
| Key features | Core Features |
| (UX content) | User Experience |
| Tech stack | Technical Architecture |
| Build order | Development Roadmap, Logical Dependency Chain |
| Other (concerns) | Risks and Mitigations |
| Other (references) | Appendix |

**Conversion Rules:**
- Do not add content not in original
- Mark empty sections as "[To be written]"
- Write in Korean
- Organize Development Roadmap by Phase

### 4. Output Result

Output the complete converted PRD.

### 5. Save

Confirm via AskUserQuestion before saving:
- Default: `.taskmaster/docs/prd.md`
- Alternative paths allowed

### 6. Next Steps

```
[Conversion Complete]

Next step:
task-master parse-prd .taskmaster/docs/prd.md
```

---

## Output Format

```markdown
<context>
# Overview
[What to build content]

# Core Features
[Key features content]

# User Experience
[UX content or to be written]
</context>

<PRD>
# Technical Architecture
[Tech stack content]

# Development Roadmap
## Phase 1: [Name]
- [Feature]

## Phase 2: [Name]
- [Feature]

# Logical Dependency Chain
[Build order based dependencies]

# Risks and Mitigations
[Concerns]

# Appendix
[References]
</PRD>
```
