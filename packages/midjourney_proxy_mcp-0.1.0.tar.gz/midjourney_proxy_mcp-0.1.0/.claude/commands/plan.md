---
description: Start planning workflow with requirements interview (Prometheus) + built-in Plan Mode
---

# Strategic Planning Workflow

Two-phase planning: Requirements Interview (Prometheus) + Implementation Planning (built-in Plan Mode).

## Arguments

`$ARGUMENTS` is the task or feature to plan.

Examples:
- `/plan add user authentication with OAuth`
- `/plan refactor the database layer for better performance`
- `/plan implement dark mode across the application`

## Workflow

```
Phase 1: REQUIREMENTS INTERVIEW (Prometheus Agent)
    ↓
    - Intent classification
    - Systematic questions
    - Research if needed
    - Output: Interview Summary
    ↓
Phase 2: IMPLEMENTATION PLANNING (Built-in Plan Mode)
    ↓
    - EnterPlanMode with Interview Summary
    - Codebase exploration
    - Implementation plan
    - User approval → ExitPlanMode → Implementation
```

## Execution

### Phase 0: Trivial Task Check

Before launching Prometheus, assess if the task is trivial:
- Simple file edits (docs, config, resources)
- Clear requirements with no ambiguity
- No code implementation needed

If trivial, use `AskUserQuestion` to confirm:
- Option 1: "Skip planning, proceed directly"
- Option 2: "Run full planning workflow"

### Phase 1: Launch Prometheus Interview

```
Task({
  subagent_type: "prometheus",
  prompt: "Interview for: $ARGUMENTS",
  model: "opus"
})
```

Prometheus will:
1. Classify intent (trivial/refactor/new/mid-sized)
2. Ask clarifying questions using AskUserQuestion tool
3. Request research agents if needed (Explorer, web-researcher)
4. Return Interview Summary

### Phase 2: Enter Plan Mode

After Prometheus returns Interview Summary:

```
EnterPlanMode()
```

In Plan Mode:
1. Explore codebase based on Interview Summary
2. Design implementation approach
3. Present plan to user
4. After approval: `ExitPlanMode()` → Implementation

## When to Use

| Situation | Use /plan? |
|-----------|------------|
| Complex new feature | Yes |
| Multi-file refactoring | Yes |
| Unclear requirements | Yes |
| Simple bug fix | No (just fix it) |
| Trivial change | No |

## Skip Interview (Direct Plan Mode)

If requirements are already clear, skip Prometheus and go directly to Plan Mode:

```
Shift+Tab (twice) → Plan Mode
or
claude --permission-mode plan
```

## Error Handling

| Error | Action |
|-------|--------|
| No arguments | Ask for task description |
| Prometheus timeout | Fall back to direct Plan Mode |
| Trivial task detected | Skip interview, proceed directly |
