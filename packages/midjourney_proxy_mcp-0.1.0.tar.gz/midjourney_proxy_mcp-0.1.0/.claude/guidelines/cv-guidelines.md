# CV Guidelines

Best practices for Computer Vision tasks.

## BGR vs RGB Color Format

**Key Point**: OpenCV uses BGR, matplotlib uses RGB. When annotating with OpenCV-based libraries like supervision, keep the image in BGR format and convert to RGB only right before displaying with matplotlib.

```python
# Correct pattern
img = cv2.imread(path)                    # BGR
img = annotator.annotate(img, detections) # Keep BGR
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) # Convert just before display
plt.imshow(img)

# Wrong pattern (causes color inversion)
img = cv2.imread(path)
img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) # Too early
img = annotator.annotate(img, detections)  # BGR colors on RGB image -> inverted
plt.imshow(img)
```

## Ultralytics WandB Integration

Ultralytics YOLO has WandB disabled by default.

```bash
yolo settings wandb=True   # Enable
yolo settings wandb=False  # Disable
```
