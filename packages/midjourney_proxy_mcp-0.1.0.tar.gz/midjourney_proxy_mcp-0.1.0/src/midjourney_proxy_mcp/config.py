"""Configuration settings for Midjourney Proxy MCP Server."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_prefix="IMAGINEAPI_",
        env_file=".env",
        env_file_encoding="utf-8",
    )

    url: str = "https://api.imagineapi.dev"
    token: str = ""


settings = Settings()
