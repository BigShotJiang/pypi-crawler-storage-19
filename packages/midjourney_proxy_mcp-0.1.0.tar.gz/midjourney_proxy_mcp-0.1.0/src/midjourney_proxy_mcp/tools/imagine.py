"""Tool for generating Midjourney images."""

from typing import Any

from ..client import ImagineAPIClient
from ..models import ImageRequest


async def midjourney_imagine(prompt: str, ref: str | None = None) -> dict[str, Any]:
    """Generate an image using Midjourney.

    Args:
        prompt: Image generation prompt (supports Midjourney syntax, e.g., --ar 16:9)
        ref: Reference ID for tracking (optional)

    Returns:
        Dictionary containing generated image info:
        - id: Image ID (used for status queries)
        - prompt: The prompt used
        - status: Current status (pending, in-progress, completed, failed)
        - message: Guidance message

    Raises:
        ImagineAPIError: If API call fails
        ValidationError: If prompt is empty (Pydantic validation failure)
        ValueError: If token is not configured
    """
    request = ImageRequest(prompt=prompt, ref=ref)

    async with ImagineAPIClient() as client:
        image = await client.create_image(request)

    return {
        "id": image.id,
        "prompt": image.prompt,
        "status": image.status.value,
        "message": f"Image generation started. Use ID: {image.id} to check status.",
    }
