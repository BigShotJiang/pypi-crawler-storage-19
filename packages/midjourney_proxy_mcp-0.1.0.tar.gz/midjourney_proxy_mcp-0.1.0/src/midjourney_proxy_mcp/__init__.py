"""Midjourney Proxy MCP Server - Generate Midjourney images via ImagineAPI."""

__version__ = "0.1.0"
