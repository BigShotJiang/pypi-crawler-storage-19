"""Pydantic models for ImagineAPI requests and responses."""

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class ImageStatus(str, Enum):
    """Status of an image generation request."""

    PENDING = "pending"
    IN_PROGRESS = "in-progress"
    COMPLETED = "completed"
    FAILED = "failed"


class ImageRequest(BaseModel):
    """Request to generate a Midjourney image.

    This model uses strict validation since we control the input.
    """

    model_config = ConfigDict(strict=True)

    prompt: str = Field(..., min_length=1, max_length=4000, description="Midjourney prompt")
    ref: str | None = Field(default=None, description="Reference ID for tracking")


class ImageData(BaseModel):
    """Image generation data from ImagineAPI.

    Note: This model intentionally does NOT use strict=True to allow flexibility
    when parsing external API responses. The ImagineAPI may return slightly
    different types (e.g., int as string) or add new fields.
    """

    id: str = Field(..., description="Unique image ID")
    prompt: str = Field(..., description="Original prompt")
    status: ImageStatus = Field(..., description="Current status")
    result: str | None = Field(default=None, description="Result image URL when completed")
    url: str | None = Field(default=None, description="Alternative URL field from API")
    results: str | None = Field(default=None, description="Results field from API")
    progress: int | None = Field(default=None, ge=0, le=100, description="Progress percentage")
    upscaled_urls: list[str] | None = Field(default=None, description="Upscaled image URLs")
    upscaled: list[str] | None = Field(default=None, description="Upscaled image IDs")
    ref: str | None = Field(default=None, description="User reference ID for tracking")
    error: str | None = Field(default=None, description="Error message if failed")
    user_created: str | None = Field(default=None, description="User who created the image")
    date_created: str | None = Field(default=None, description="Creation timestamp")


class ImageResponse(BaseModel):
    """Response wrapper from ImagineAPI."""

    data: ImageData = Field(..., description="Image data")


class ImageListResponse(BaseModel):
    """List response from ImagineAPI."""

    data: list[ImageData] = Field(default_factory=list, description="List of images")
    meta: dict[str, Any] | None = Field(default=None, description="Pagination metadata")
