"""MCP Prompts for Midjourney workflow templates."""
