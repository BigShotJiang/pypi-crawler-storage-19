# Installation

## Prerequisites

- Python 3.11 or higher
- [ImagineAPI](https://www.imagineapi.dev/) account and API token

## Install from PyPI

### Using uvx (Recommended)

uvx provides zero-install execution - the package is downloaded and run on demand:

```bash
uvx midjourney-proxy-mcp
```

### Using pip

Install globally or in a virtual environment:

```bash
pip install midjourney-proxy-mcp
```

Then run:

```bash
midjourney-proxy-mcp
```

## Install from Source

Clone the repository and install with uv:

```bash
git clone https://github.com/YoungjaeDev/midjourney-proxy-mcp.git
cd midjourney-proxy-mcp
uv sync
```

Run the development server:

```bash
uv run midjourney-proxy-mcp
```

## Verify Installation

Test that the server starts correctly:

```bash
# Set required environment variable
export IMAGINEAPI_TOKEN="your-token-here"

# Run the server
uvx midjourney-proxy-mcp
```

The server will start and wait for MCP client connections via stdio.

## Docker (Coming Soon)

Docker support is planned for future releases.

## Next Steps

After installation, configure your MCP client:

- [Configuration Guide](configuration.md)
