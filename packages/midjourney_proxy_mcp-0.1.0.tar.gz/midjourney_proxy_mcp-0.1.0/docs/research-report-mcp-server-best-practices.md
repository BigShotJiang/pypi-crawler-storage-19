# Research Report: MCP Server Open Source Projects and Best Practices (2024-2025)

**Research Date**: 2026-01-08
**Mode**: Quick
**Search Range**: 2024-01 ~ 2026-01

## Summary

- MCP (Model Context Protocol) has become the de facto standard for connecting AI agents to tools and data, with rapid adoption since Anthropic's November 2024 launch
- The official `modelcontextprotocol/servers` repository (75k+ stars) provides reference implementations in both TypeScript and Python
- FastMCP (21k+ stars) has emerged as the preferred Python framework for building MCP servers with minimal boilerplate
- Both npm (npx) and PyPI (uvx) distribution patterns are well-established, with seamless zero-install experiences

---

## 1. High-Quality MCP Server Examples (500+ Stars)

### Official and First-Party Servers

| Repository | Stars | Language | Description |
|------------|-------|----------|-------------|
| [punkpeye/awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers) | 78,411 | Curated List | Comprehensive collection of MCP servers |
| [modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers) | 75,727 | TS/Python | Official reference implementations |
| [upstash/context7](https://github.com/upstash/context7) | 41,178 | TypeScript | Up-to-date code documentation for LLMs |
| [github/github-mcp-server](https://github.com/github/github-mcp-server) | 25,714 | Go | GitHub's official MCP Server |
| [microsoft/playwright-mcp](https://github.com/microsoft/playwright-mcp) | 25,211 | TypeScript | Browser automation via Playwright |
| [jlowin/fastmcp](https://github.com/jlowin/fastmcp) | 21,770 | Python | Fast, Pythonic MCP server framework |
| [modelcontextprotocol/python-sdk](https://github.com/modelcontextprotocol/python-sdk) | 20,996 | Python | Official Python SDK |
| [GLips/Figma-Context-MCP](https://github.com/GLips/Figma-Context-MCP) | 12,437 | TypeScript | Figma layout info for AI coding agents |
| [modelcontextprotocol/typescript-sdk](https://github.com/modelcontextprotocol/typescript-sdk) | 11,233 | TypeScript | Official TypeScript SDK |
| [awslabs/mcp](https://github.com/awslabs/mcp) | 7,806 | Various | AWS MCP Servers collection |
| [firecrawl/firecrawl-mcp-server](https://github.com/firecrawl/firecrawl-mcp-server) | 5,222 | TypeScript | Web scraping and search |

### Code Organization Patterns (from Official Servers)

The official `modelcontextprotocol/servers` repository uses a **monorepo structure with npm workspaces**:

```
src/
  everything/       # TypeScript - demo server
  filesystem/       # TypeScript - file system access
  memory/          # TypeScript - knowledge graph
  fetch/           # Python - web fetching
  git/             # Python - git operations
  time/            # Python - time utilities
```

**Key patterns observed:**
- Each server is a self-contained package with its own manifest
- TypeScript servers use `package.json` + `tsc` + `vitest`
- Python servers use `pyproject.toml` + `uv` + `pytest`
- Protocol-level identifier follows reverse-domain notation (e.g., `io.github.modelcontextprotocol/server-everything`)

---

## 2. Documentation Patterns

### README Structure for Successful MCP Servers

Based on analysis of high-star repositories, effective READMEs include:

1. **Installation commands** for multiple methods (npx, uvx, Docker)
2. **Configuration snippets** for each supported client (Claude Desktop, Cursor, VS Code)
3. **Tool/Resource/Prompt listings** with descriptions
4. **Environment variables** documentation
5. **Examples** of actual usage

### llms.txt Pattern

The `llms.txt` documentation pattern is emerging as a standard for AI-readable documentation:

- `llms.txt`: Index file with links and brief descriptions
- `llms-full.txt`: Complete content in a single file for LLM consumption
- MCP servers can expose these as resources for AI agents to consume

The official MCP documentation is available at:
- [modelcontextprotocol.io/llms-full.txt](https://modelcontextprotocol.io/llms-full.txt)

### Documentation Tools

- **Mintlify**: Used by official MCP documentation site
- **MkDocs**: Common choice for Python-based projects
- **Context7**: MCP server specifically for providing up-to-date documentation to LLMs

---

## 3. Multi-Client Support Configuration

### Configuration Format Differences

| Client | Config Location | Root Key |
|--------|----------------|----------|
| Claude Desktop | `~/Library/Application Support/Claude/claude_desktop_config.json` | `mcpServers` |
| Cursor | `.cursor/mcp.json` or global config | `mcpServers` |
| VS Code | `settings.json` | `mcp.servers` |
| Claude Code | `.claude/settings.json` | `mcpServers` |

### Universal Configuration Example

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/allowed/path"]
    },
    "fetch": {
      "command": "uvx",
      "args": ["mcp-server-fetch"]
    }
  }
}
```

### Best Practice: Provide Copy-Paste Snippets

Successful MCP servers include ready-to-use configuration blocks for:
- Claude Desktop (macOS/Windows paths)
- Cursor (project vs global)
- VS Code with Copilot
- Docker-based deployments

---

## 4. Packaging and Distribution

### npm Distribution (TypeScript)

**Package naming convention**: `@modelcontextprotocol/server-{name}` or `mcp-server-{name}`

**Recommended package.json structure**:
```json
{
  "name": "@your-org/mcp-server-example",
  "type": "module",
  "bin": {
    "mcp-server-example": "./dist/index.js"
  },
  "files": ["dist"],
  "scripts": {
    "build": "tsc",
    "prepack": "npm run build"
  },
  "exports": {
    ".": {
      "import": "./dist/esm/index.js",
      "require": "./dist/cjs/index.js"
    }
  }
}
```

**Installation methods**:
- `npx -y @your-org/mcp-server-example` (zero-install)
- `npm install -g @your-org/mcp-server-example` (global)

### PyPI Distribution (Python)

**Package naming convention**: `mcp-server-{name}`

**Recommended pyproject.toml structure**:
```toml
[project]
name = "mcp-server-example"
dependencies = ["mcp[cli]>=1.2.0"]

[project.scripts]
mcp-server-example = "mcp_server_example:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

**Installation methods**:
- `uvx mcp-server-example` (zero-install with uv)
- `pip install mcp-server-example` (traditional)

### Docker Distribution

For production deployments, Docker provides isolation and security:
- Images published under `mcp/*` namespace for Python servers
- Example: `docker run -it mcp/fetch`

### NVM/pyenv Users: Important Workaround

Claude Desktop may not inherit shell environment. Use absolute paths:
```json
{
  "mcpServers": {
    "example": {
      "command": "/Users/you/.nvm/versions/node/v20.0.0/bin/node",
      "args": ["/path/to/server/dist/index.js"]
    }
  }
}
```

---

## 5. TypeScript vs Python Comparison

### Ecosystem Statistics

| Metric | TypeScript | Python |
|--------|-----------|--------|
| Official SDK Stars | 11,233 | 20,996 |
| Primary Framework | `@modelcontextprotocol/sdk` | FastMCP (now part of SDK) |
| Transport Support | stdio, HTTP/SSE, WebSocket | stdio, HTTP/SSE |
| Package Manager | npm/npx | pip/uvx (uv) |

### TypeScript Advantages

| Aspect | Details |
|--------|---------|
| **Type Safety** | Compile-time error detection, better refactoring |
| **IDE Experience** | Superior VS Code integration, autocomplete |
| **Web Integration** | Natural fit for web APIs, browser extensions |
| **Validation** | Zod for runtime schema validation |
| **First-Party Support** | Official Anthropic SDK, tight protocol alignment |

### Python Advantages

| Aspect | Details |
|--------|---------|
| **FastMCP Ergonomics** | Decorator-based API, minimal boilerplate |
| **ML/Data Integration** | Native access to NumPy, Pandas, ML libraries |
| **Rapid Prototyping** | Dynamic typing, concise syntax |
| **Pydantic Integration** | Automatic schema generation from type hints |
| **Community Size** | Larger AI/ML developer community |

### When to Choose TypeScript

- Building editor-adjacent tools (code search, documentation lookup)
- Web and API integrations
- Teams with existing Node.js CI/CD pipelines
- Projects requiring strict type safety

### When to Choose Python

- Data processing and ML workloads
- Integration with existing Python data pipelines
- Rapid prototyping requirements
- Teams with Python-first operations

### Framework Comparison

| Framework | Language | Best For |
|-----------|----------|----------|
| Official TypeScript SDK | TypeScript | Production servers, type safety |
| FastMCP | Python | Rapid development, minimal boilerplate |
| FastAPI-MCP | Python | Leveraging existing FastAPI code |
| Foxy Contexts | Go | High performance, concurrency |
| Spring AI MCP | Java | Enterprise/Spring ecosystem |

---

## 6. Community Insights

### Key Takeaways from Reddit/Community

1. **Context Token Management**: MCP tools can consume significant context (66k+ tokens in some cases). Enable only needed servers per session.

2. **Security Best Practices**:
   - Never hardcode API keys in config files
   - Use environment variables for secrets
   - Scope directory access narrowly
   - Trust only official sources for initial MCP adoption

3. **Common Issues**:
   - NVM users need absolute paths
   - Restart Claude Desktop completely after config changes
   - Check `~/Library/Logs/Claude/mcp*.log` for debugging

4. **Logging Gotcha**: STDIO-based servers must NOT write to stdout (breaks JSON-RPC). Use stderr or file logging.

---

## 7. Recommendations

### For New MCP Server Projects

1. **Choose your stack based on integration needs**:
   - TypeScript for web/API tools, editor integrations
   - Python for data/ML tools, rapid prototyping

2. **Follow the official server structure**:
   - Use the monorepo pattern for multi-server projects
   - Implement proper error handling and logging to stderr

3. **Provide multi-client configuration**:
   - Include copy-paste JSON snippets for Claude Desktop, Cursor, VS Code
   - Document both npx/uvx and global installation methods

4. **Implement llms.txt**:
   - Create machine-readable documentation for AI consumption
   - Expose as an MCP resource if appropriate

5. **Consider production requirements early**:
   - Stateless HTTP mode for horizontal scaling
   - OAuth support for authenticated APIs
   - Docker packaging for isolation

### Code Quality Checklist

- [ ] No stdout output (use stderr for logging)
- [ ] Input validation with Zod (TS) or Pydantic (Python)
- [ ] Error handling with meaningful messages
- [ ] Environment variable configuration
- [ ] Multi-client config examples in README
- [ ] CI/CD for automated publishing

---

## 8. Gaps and Limitations

- **Remote MCP servers**: Web-based Claude only supports remote servers via "Integrations" (May 2025+)
- **Security**: 43% of tested MCP implementations had command injection vulnerabilities (per Equixly assessment)
- **Standardization**: Configuration format varies between clients
- **IDE Native Support**: llms.txt not yet natively supported in most IDEs (requires MCP server workaround)

---

## Sources

1. [Build an MCP server - Model Context Protocol](https://modelcontextprotocol.io/docs/develop/build-server) - Official documentation
2. [modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers) - Reference implementations (75k+ stars)
3. [jlowin/fastmcp](https://github.com/jlowin/fastmcp) - FastMCP Python framework (21k+ stars)
4. [MCP SDK Comparison - Stainless](https://www.stainless.com/mcp/mcp-sdk-comparison-python-vs-typescript-vs-go-implementations) - SDK comparison
5. [mcp-server-typescript vs mcp-server-python - Skywork](https://skywork.ai/blog/mcp-server-typescript-vs-mcp-server-python-2025-comparison/) - 2025 comparison guide
6. [MCP Server Executables Explained - DEV](https://dev.to/leomarsh/mcp-server-executables-explained-npx-uvx-docker-and-beyond-1i1n) - Installation methods
7. [Understanding MCP Servers Across Platforms - DEV](https://dev.to/darkmavis1980/understanding-mcp-servers-across-different-platforms-claude-desktop-vs-vs-code-vs-cursor-4opk) - Multi-client configuration
8. [Optimising MCP Server Context Usage - Scott Spence](https://scottspence.com/posts/optimising-mcp-server-context-usage-in-claude-code) - Context optimization
9. [A Deep Dive Into MCP - a16z](https://a16z.com/a-deep-dive-into-mcp-and-the-future-of-ai-tooling/) - Industry analysis
10. [Getting Started with Local MCP Servers - Claude Help Center](https://support.claude.com/en/articles/10949351-getting-started-with-local-mcp-servers-on-claude-desktop) - Official setup guide
