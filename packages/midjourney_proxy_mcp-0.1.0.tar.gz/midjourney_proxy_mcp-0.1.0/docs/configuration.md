# Configuration

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `IMAGINEAPI_URL` | ImagineAPI base URL | `https://api.imagineapi.dev` |
| `IMAGINEAPI_TOKEN` | API authentication token | (required) |

Get your API token from [ImagineAPI](https://www.imagineapi.dev/).

## Client Configuration

### Claude Desktop

Add to your `claude_desktop_config.json`:

=== "macOS"

    Location: `~/Library/Application Support/Claude/claude_desktop_config.json`

    ```json
    {
      "mcpServers": {
        "midjourney": {
          "command": "uvx",
          "args": ["midjourney-proxy-mcp"],
          "env": {
            "IMAGINEAPI_URL": "https://your-imagineapi.com",
            "IMAGINEAPI_TOKEN": "your-api-token"
          }
        }
      }
    }
    ```

=== "Windows"

    Location: `%APPDATA%\Claude\claude_desktop_config.json`

    ```json
    {
      "mcpServers": {
        "midjourney": {
          "command": "uvx",
          "args": ["midjourney-proxy-mcp"],
          "env": {
            "IMAGINEAPI_URL": "https://your-imagineapi.com",
            "IMAGINEAPI_TOKEN": "your-api-token"
          }
        }
      }
    }
    ```

!!! tip "Restart Required"
    After modifying the config, restart Claude Desktop completely for changes to take effect.

### Claude Code

Add the MCP server using the CLI:

```bash
claude mcp add midjourney -- uvx midjourney-proxy-mcp
```

Set environment variables in your shell profile or `.env` file:

```bash
export IMAGINEAPI_URL="https://your-imagineapi.com"
export IMAGINEAPI_TOKEN="your-api-token"
```

### Cursor

Add to `.cursor/mcp.json` in your project directory:

```json
{
  "mcpServers": {
    "midjourney": {
      "command": "uvx",
      "args": ["midjourney-proxy-mcp"],
      "env": {
        "IMAGINEAPI_URL": "https://your-imagineapi.com",
        "IMAGINEAPI_TOKEN": "your-api-token"
      }
    }
  }
}
```

### VS Code

Add to your VS Code `settings.json`:

```json
{
  "mcp.servers": {
    "midjourney": {
      "command": "uvx",
      "args": ["midjourney-proxy-mcp"],
      "env": {
        "IMAGINEAPI_URL": "https://your-imagineapi.com",
        "IMAGINEAPI_TOKEN": "your-api-token"
      }
    }
  }
}
```

## NVM/pyenv Users

If you use nvm or pyenv, Claude Desktop may not inherit your shell environment. Use absolute paths:

```json
{
  "mcpServers": {
    "midjourney": {
      "command": "/home/user/.local/bin/uvx",
      "args": ["midjourney-proxy-mcp"],
      "env": {
        "IMAGINEAPI_TOKEN": "your-api-token"
      }
    }
  }
}
```

Find your uvx path with:

```bash
which uvx
```

## Troubleshooting

### Server Not Starting

1. Check that `IMAGINEAPI_TOKEN` is set
2. Verify the token is valid with ImagineAPI
3. Check MCP client logs for errors

### Connection Issues

For Claude Desktop on macOS, check logs at:

```bash
tail -f ~/Library/Logs/Claude/mcp*.log
```

### Permission Errors

Ensure uvx is in your PATH and executable:

```bash
uvx --version
```
