# Resources

MCP Resources provide read-only data access. Unlike tools, resources are designed for passive data retrieval and can be subscribed to for updates.

## midjourney://generations

List all recent image generations.

### URI

```
midjourney://generations
```

### Response

Returns an array of generation records:

```json
[
  {
    "id": "abc123",
    "prompt": "A futuristic city at sunset",
    "status": "completed",
    "url": "https://cdn.example.com/grid.png",
    "upscaled_urls": ["..."],
    "created_at": "2024-01-15T10:30:00Z"
  },
  {
    "id": "def456",
    "prompt": "A serene mountain landscape",
    "status": "in-progress",
    "progress": 67,
    "created_at": "2024-01-15T10:35:00Z"
  }
]
```

---

## midjourney://generations/{status}

List generations filtered by status.

### URI Parameters

| Parameter | Description |
|-----------|-------------|
| `status` | One of: `pending`, `in-progress`, `completed`, `failed` |

### Examples

```
midjourney://generations/completed
midjourney://generations/failed
midjourney://generations/in-progress
```

### Response

Returns an array of generation records matching the specified status.

---

## midjourney://generation/{id}

Get detailed information for a specific generation.

### URI Parameters

| Parameter | Description |
|-----------|-------------|
| `id` | The image generation ID |

### Example

```
midjourney://generation/abc123
```

### Response

```json
{
  "id": "abc123",
  "prompt": "A futuristic city at sunset --ar 16:9 --v 7",
  "status": "completed",
  "progress": 100,
  "url": "https://cdn.example.com/grid.png",
  "upscaled_urls": [
    "https://cdn.example.com/image1.png",
    "https://cdn.example.com/image2.png",
    "https://cdn.example.com/image3.png",
    "https://cdn.example.com/image4.png"
  ],
  "error": null,
  "ref": "my-reference",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:32:00Z"
}
```

---

## midjourney://stats

Get aggregated generation statistics.

### URI

```
midjourney://stats
```

### Response

```json
{
  "total": 150,
  "by_status": {
    "pending": 5,
    "in-progress": 3,
    "completed": 135,
    "failed": 7
  },
  "completion_rate": 0.90,
  "recent_24h": 42
}
```

### Fields

| Field | Description |
|-------|-------------|
| `total` | Total number of generations |
| `by_status` | Count breakdown by status |
| `completion_rate` | Ratio of completed to total (excludes pending/in-progress) |
| `recent_24h` | Generations in the last 24 hours |
