# Tools

MCP Tools are actions that AI assistants can invoke to generate and query images.

## midjourney_imagine

Generate an image using Midjourney.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `prompt` | string | Yes | Image generation prompt (supports Midjourney syntax) |
| `ref` | string | No | Reference ID for tracking |

### Midjourney Syntax

The prompt supports standard Midjourney parameters:

| Parameter | Example | Description |
|-----------|---------|-------------|
| `--ar` | `--ar 16:9` | Aspect ratio |
| `--v` | `--v 7` | Model version |
| `--q` | `--q 2` | Quality level |
| `--s` | `--s 750` | Stylize value |
| `--c` | `--c 50` | Chaos value |
| `--no` | `--no text` | Negative prompt |
| `--tile` | `--tile` | Seamless pattern |
| `--seed` | `--seed 12345` | Reproducible seed |

### Response

```json
{
  "id": "abc123",
  "prompt": "A futuristic city --ar 16:9",
  "status": "pending",
  "message": "Image generation started"
}
```

### Example

```
midjourney_imagine(
  prompt="A serene Japanese garden with cherry blossoms --ar 16:9 --v 7 --s 500"
)
```

---

## midjourney_get_status

Get the status of an image generation.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `image_id` | string | Yes | Image ID to query |

### Response

```json
{
  "id": "abc123",
  "prompt": "A futuristic city --ar 16:9",
  "status": "completed",
  "progress": 100,
  "url": "https://cdn.example.com/grid.png",
  "upscaled_urls": [
    "https://cdn.example.com/image1.png",
    "https://cdn.example.com/image2.png",
    "https://cdn.example.com/image3.png",
    "https://cdn.example.com/image4.png"
  ],
  "error": null
}
```

### Status Values

| Status | Description |
|--------|-------------|
| `pending` | Request received, queued for processing |
| `in-progress` | Midjourney is generating (progress % available) |
| `completed` | Done, `upscaled_urls` contains 4 upscaled images |
| `failed` | Error occurred, check `error` field |

### Example

```
midjourney_get_status(image_id="abc123")
```

---

## midjourney_list_images

List recently generated images.

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `limit` | integer | No | Maximum number to retrieve (default: 10, max: 100) |
| `status` | string | No | Filter by status (pending, in-progress, completed, failed) |

### Response

```json
{
  "images": [
    {
      "id": "abc123",
      "prompt": "A futuristic city...",
      "status": "completed",
      "created_at": "2024-01-15T10:30:00Z"
    },
    {
      "id": "def456",
      "prompt": "A mountain landscape...",
      "status": "in-progress",
      "progress": 45,
      "created_at": "2024-01-15T10:35:00Z"
    }
  ],
  "total": 2
}
```

### Examples

List all recent images:

```
midjourney_list_images()
```

List completed images only:

```
midjourney_list_images(limit=20, status="completed")
```

List failed images for debugging:

```
midjourney_list_images(status="failed")
```
