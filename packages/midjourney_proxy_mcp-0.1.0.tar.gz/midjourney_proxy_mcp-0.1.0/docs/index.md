# Midjourney Proxy MCP

MCP server for [ImagineAPI](https://www.imagineapi.dev/) - generate Midjourney images from Claude, Cursor, and other AI tools.

## Overview

This MCP server provides a bridge between AI assistants and Midjourney image generation through ImagineAPI. It implements the Model Context Protocol (MCP), allowing seamless integration with Claude Desktop, Claude Code, Cursor, and other MCP-compatible clients.

## Features

- **Image Generation** - Create Midjourney images with full parameter support
- **Status Tracking** - Monitor generation progress and retrieve results
- **Batch Queries** - List and filter recent generations
- **Statistics** - Access aggregated generation metrics via MCP resources

## Quick Start

1. Install the server:

    ```bash
    uvx midjourney-proxy-mcp
    ```

2. Configure your MCP client with ImagineAPI credentials

3. Start generating images:

    ```
    midjourney_imagine(prompt="A serene mountain landscape --ar 16:9")
    ```

## Requirements

- Python 3.11+
- ImagineAPI account and API token

## Architecture

```
midjourney-proxy-mcp/
├── src/midjourney_proxy_mcp/
│   ├── server.py       # FastMCP main server
│   ├── client.py       # ImagineAPI HTTP client
│   ├── config.py       # Environment settings
│   ├── models.py       # Pydantic models
│   ├── tools/          # MCP Tool implementations
│   └── resources/      # MCP Resource implementations
└── tests/              # pytest tests
```

## Next Steps

- [Installation](installation.md) - Detailed setup instructions
- [Configuration](configuration.md) - Client configuration examples
- [Tools](tools.md) - Available MCP tools reference
- [Resources](resources.md) - MCP resources reference
