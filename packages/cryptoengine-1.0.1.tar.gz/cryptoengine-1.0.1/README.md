# 🔐 CryptoEngine
### Secure Encryption, Signing & Verification

<div align="center">
  <img src="ssh_encryptor/assets/icon.png" width="160" />
  <br>
  <strong>Secure encryption, signing & verification</strong>
  <br><br>
</div>

---

## 📌 Overview

**CryptoEngine enhances secure sharing of sensitive information across networks.**  
It is recommended for:

- Students 
- Developers  
- Security professionals  
- Cybersecurity enthusiasts 

CryptoEngine is a local-first desktop application. All operations happen on your machine — no data is sent to any remote service.

---

## ✨ Features

### 🔑 Hybrid Cryptography  
- RSA + AES hybrid encryption
- Encrypt data using SSH-compatible RSA public keys
- Decrypt using stored or manual private keys

### ✒ Digital Signatures  
- Create detached digital signatures for files or text  
- Verify message integrity and authenticity using public keys  

### 🧮 Hashing Toolkit  
- Compute hashes for files and text:
  - SHA-256
  - SHA-1
  - MD5  
- Easy copy of hex and Base64 digests

### 🗝 Key Manager  
- Save and manage named public keys  
- Save and manage private key file paths  
- Generate new SSH RSA key pairs from inside the app  
- Password-protect private keys during generation

### 🖥 Desktop UI  
- Tabbed interface:
  - **Hashing**
  - **Encrypt**
  - **Decrypt**
  - **Signature Verify**
  - **Key Manager**
  - **About**
- Designed for dark themes and developer workflows

---

## 🧰 Technology Stack

CryptoEngine is built with:

- **Python 3**
- **PyQt6** for the native desktop UI
- **cryptography** library for RSA, AES, and signing
- A **hybrid RSA + AES** design for efficient, secure encryption

---

## 📦 Installation (Development)

```bash
git clone https://github.com/your-user/crypto_engine.git
cd crypto_engine

python3 -m venv venv
source venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt
```

---

---

## 🏗️ Build Instructions (macOS, Windows & Linux)

CryptoEngine ships as pure Python + PyQt6, so you can build binaries using **PyInstaller**.

Ensure dependencies installed:

```bash
pip install -r requirements.txt
pip install pyinstaller
```

## 🍏 macOS (.app bundle)

```bash
    pyinstaller \
    --name CryptoEngine \
    --windowed \
    --icon ssh_encryptor/assets/icon.icns \
    --add-data "ssh_encryptor/assets:assets" \
    run.py
```

## 🪟 Windows (.exe)

```bash
    pyinstaller ^
    --onefile ^
    --windowed ^
    --icon ssh_encryptor/assets/icon.ico ^
    --add-data "ssh_encryptor\\assets;assets" ^
    run.py
  ```

## 🐧 Linux (binary or AppImage)

```bash
    pyinstaller \
    --name CryptoEngine \
    --windowed \
    --icon ssh_encryptor/assets/icon.png \
    --add-data "ssh_encryptor/assets:assets" \
    run.py
  ```

## 👤 Developer

<div align="center">
  <img src="ssh_encryptor/assets/me.jpeg" width="130" style="border-radius: 8px;" />
  <br><br>
    @wmhchathuranga
    Director — Bitrate Solutions (Pvt) Ltd.
    📧 wmhchathuranga@bitrate.lk
</div>

---

## 📝 License

CryptoEngine is open-source and released under the **MIT License**.  
You may use, modify, and redistribute freely.

See: [`LICENSE`](LICENSE)

### 📛 Trademark Notice
CryptoEngine™ and the CryptoEngine logo are trademarks of  
**Harshana Chathuranga / Bitrate Solutions (Pvt) Ltd**.

You may not:
- redistribute commercial products named *CryptoEngine*
- use the name or logo to imply endorsement
- publish forks/binaries under the CryptoEngine™ name

See: [`TRADEMARK.md`](TRADEMARK.md)

For commercial or white-label licensing:
📧 wmhchathuranga@bitrate.lk

## ❤️ Enjoy using CryptoEngine!

If you want **badges**, **animated GIF demo**, or an **installer `.pkg` section**, give the word — we’ll upgrade it 💪

