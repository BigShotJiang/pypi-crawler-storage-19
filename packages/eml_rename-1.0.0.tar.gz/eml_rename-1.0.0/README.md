# eml_rename project



[![Tests](https://github.com/turulomio/eml_rename/actions/workflows/tests.yml/badge.svg)](https://github.com/turulomio/eml_rename/actions/workflows/tests.yml)


Script renames all eml files in a directory using mail metadata

## Idea

I needed this tool to classify and order my mail files at work.

I took this idea from an article of Armand Niculescu (August 20, 2014) at https://www.media-division.com/using-python-to-batch-rename-email-files/ , so thanks an I hope you like this code.

## Features

<img src="https://raw.githubusercontent.com/turulomio/eml_rename/master/doc/command.gif?raw=true" width="100%"></img>

- Automatically renames all *.eml files in a directory, using email metadata. 
- Renamed files will have this format is 'YYYYMMDD HHMM [From] Subject'
- If 'YYYYMMDD HHMM [From]' format is detected the script won't rename the file. With this feature user can change subject manually and the script won't overwrite it.
- If you use --force parameter the script will overwrite all files even they have the 'YYYYMMDD HHMM [From]' format.
- Length of the new name will have 140 character as maximum, although you can change it with the --length parameter
- --save parameter renames files. If you don't use this parameter it will only pretend the result
- It uses concurrency to make process faster

## Configuración (Opcional)

Para utilizar la función de resumen por IA (`--ai`), necesitas una clave de API de Google Gemini. Puedes configurarla de dos maneras:

### 1. Variable de entorno
Define la variable `GOOGLE_API_KEY` en tu terminal:
```bash
export GOOGLE_API_KEY='tu_clave_aqui'
```

### 2. Archivo de configuración
Crea un archivo en `~/.config/eml-rename/config.ini` con el siguiente contenido:
```ini
[auth]
GOOGLE_API_KEY = tu_clave_aqui
```
