import os
from ..functions.builtins import HeEro
from ..functions.decorators import parse_self_x_item_value_or_set_by_instance_he_by_module_name
from .types.he import He


class System(He):
    def __init__(self):
        He.__init__(self, self)

    @property
    @parse_self_x_item_value_or_set_by_instance_he_by_module_name()
    def components(self): return

    @property
    @parse_self_x_item_value_or_set_by_instance_he_by_module_name()
    def configs(self): return

    @property
    @parse_self_x_item_value_or_set_by_instance_he_by_module_name()
    def debugs(self): return

    @property
    @parse_self_x_item_value_or_set_by_instance_he_by_module_name()
    def types(self): return

    def create_website(self, name:str=None): self.__i__.website_folder.copyto(self.components.folder(os.getcwd()).child_folder(name or 'website'))

