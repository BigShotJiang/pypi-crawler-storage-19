import os
from dotenv import load_dotenv

# Загружаем переменные из .env, если он есть
load_dotenv()

class TFAuth:
    def __init__(self):
        # Подтягиваем ключи из окружения
        self.google_id = os.getenv("GOOGLE_CLIENT_ID", "YOUR_GOOGLE_ID")
        self.fb_id = os.getenv("FACEBOOK_APP_ID", "YOUR_FB_ID")
        self.redirect_uri = os.getenv("REDIRECT_URI", "http://localhost:5000/callback")

    def get_google_url(self):
        return f"https://accounts.google.com/o/oauth2/v2/auth?client_id={self.google_id}&redirect_uri={self.redirect_uri}&response_type=code&scope=email%20profile"

    def get_fb_url(self):
        return f"https://www.facebook.com/v12.0/dialog/oauth?client_id={self.fb_id}&redirect_uri={self.redirect_uri}&scope=email"

    def generate_html(self):
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap');
        
        * {{ box-sizing: border-box; margin: 0; padding: 0; }}
        
        body {{
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(45deg, #21d4fd 0%, #b721ff 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        
        .login-container {{
            background: #fff;
            width: 380px;
            padding: 50px 40px;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            text-align: center;
        }}
        
        h2 {{
            margin-bottom: 35px;
            font-weight: 700;
            font-size: 32px;
            color: #333;
        }}
        
        .input-group {{
            text-align: left;
            margin-bottom: 25px;
            border-bottom: 2px solid #f2f2f2;
            transition: 0.3s;
        }}
        
        .input-group:focus-within {{
            border-bottom: 2px solid #b721ff;
        }}
        
        .input-group label {{
            font-size: 13px;
            color: #666;
            font-weight: 500;
            margin-left: 2px;
        }}
        
        .input-field {{
            display: flex;
            align-items: center;
            padding: 10px 0;
        }}
        
        .input-field i {{
            color: #adadad;
            margin-right: 12px;
            font-size: 18px;
        }}
        
        .input-field input {{
            border: none;
            outline: none;
            width: 100%;
            font-size: 15px;
            color: #333;
        }}
        
        .forgot-pass {{
            display: block;
            text-align: right;
            font-size: 13px;
            color: #666;
            text-decoration: none;
            margin-bottom: 30px;
            transition: 0.3s;
        }}
        
        .forgot-pass:hover {{
            color: #b721ff;
        }}
        
        .login-btn {{
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 30px;
            background: linear-gradient(to right, #21d4fd, #b721ff);
            color: white;
            font-weight: 600;
            cursor: pointer;
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 40px;
            box-shadow: 0 5px 15px rgba(183, 33, 255, 0.3);
            transition: 0.3s;
        }}
        
        .login-btn:hover {{
            opacity: 0.9;
            transform: scale(1.02);
        }}
        
        .social-text {{
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;
        }}
        
        .social-icons {{
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 50px;
        }}
        
        .social-icons a {{
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            font-size: 20px;
            transition: 0.3s;
        }}
        
        .social-icons a:hover {{ transform: translateY(-3px); opacity: 0.9; }}
        
        .fb {{ background: #3b5998; }}
        .tw {{ background: #1da1f2; }}
        .gp {{ background: #db4437; }}
        
        .signup-text {{
            font-size: 13px;
            color: #666;
            margin-top: 20px;
        }}
        
        .signup-link {{
            text-decoration: none;
            color: #333;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 14px;
            margin-top: 10px;
            display: inline-block;
        }}
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        
        <div class="input-group">
            <label>Username</label>
            <div class="input-field">
                <i class="fa-regular fa-user"></i>
                <input type="text" placeholder="Type your username">
            </div>
        </div>
        
        <div class="input-group">
            <label>Password</label>
            <div class="input-field">
                <i class="fa-solid fa-lock"></i>
                <input type="password" placeholder="Type your password">
            </div>
        </div>
        
        <a href="#" class="forgot-pass">Forgot password?</a>
        
        <button class="login-btn">LOGIN</button>
        
        <div class="social-text">Or Sign Up Using</div>
        
        <div class="social-icons">
            <a href="{self.get_fb_url()}" class="fb"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="tw"><i class="fab fa-twitter"></i></a>
            <a href="{self.get_google_url()}" class="gp"><i class="fab fa-google"></i></a>
        </div>
        
        <div class="social-text">Or Sign Up Using</div>
        <a href="#" class="signup-link">SIGN UP</a>
    </div>
</body>
</html>
        """

    def save_as_html(self, filename="index.html"):
        with open(filename, "w", encoding="utf-8") as f:
            f.write(self.generate_html())
