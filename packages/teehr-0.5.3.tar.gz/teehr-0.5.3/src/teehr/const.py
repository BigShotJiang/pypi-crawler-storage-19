"""This module contains constants
 used throughout the package."""
import os

# Primary evaluation directories
DATASET_DIR = "dataset"
CACHE_DIR = "cache"
SCRIPTS_DIR = "scripts"
LOCATIONS_DIR = "locations"
PRIMARY_TIMESERIES_DIR = "primary_timeseries"
LOCATION_CROSSWALKS_DIR = "location_crosswalks"
LOCATION_ATTRIBUTES_DIR = "location_attributes"
SECONDARY_TIMESERIES_DIR = "secondary_timeseries"
JOINED_TIMESERIES_DIR = "joined_timeseries"

# Fetching cache directories
FETCHING_CACHE_DIR = "fetching"
USGS_CACHE_DIR = "usgs"
NWM_CACHE_DIR = "nwm"
KERCHUNK_DIR = "kerchunk"
WEIGHTS_DIR = "weights"

# Loading cache directories
LOADING_CACHE_DIR = "loading"

S3_EVALUATIONS_PATH = "s3://ciroh-rti-public-data/teehr-data-warehouse/v0_4_evaluations/evaluations.yaml"

MAX_CPUS = max(os.cpu_count() - 1, 1)