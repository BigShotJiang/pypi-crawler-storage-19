"""
Snapshot Manager - AI Agent Interface for Codebase Understanding

This module provides a high-level interface for AI agents to:
1. Generate dependency snapshots (instant, no AI inference)
2. Query snapshots with multiple questions in parallel
3. Get structured dependency maps alongside code

Designed for AI coding agents to quickly understand codebases without
reading every file.
"""

from pathlib import Path
from typing import Dict, List, Any, Set, Optional
import json
from concurrent.futures import ThreadPoolExecutor, as_completed

from .config import get_project_root, load_config
from .analyzer import get_cache, run_full_analysis
from .snapshot import generate_snapshot, SnapshotOptions
from .ai.cache import SemanticCache
from .ai.client import ClaudeClient


class SnapshotManager:
    """
    High-level interface for AI agents to interact with codebase snapshots.

    A snapshot is a "magnifying glass" - it loads a controlled subset of code
    into context, with full dependency information, allowing fast exploration
    without flooding the main agent's context.
    """

    def __init__(self, project_root: Optional[Path] = None, api_key: Optional[str] = None):
        """
        Initialize the snapshot manager.

        Args:
            project_root: Path to project root (defaults to configured root)
            api_key: Anthropic API key for AI queries (optional)
        """
        self.project_root = project_root or get_project_root()
        self.api_key = api_key
        self.config = load_config()

        # Ensure analysis cache is loaded
        cache = get_cache()
        if not cache.is_valid():
            run_full_analysis(self.config)

        self.cache = get_cache()
        self.semantic_cache = SemanticCache(self.project_root)

    def get_entry_points(self) -> List[Dict[str, str]]:
        """
        Get all configured entry points.

        Returns:
            List of dicts with 'label', 'path', 'color', 'emoji'
        """
        all_entry_points = self.config.get("entry_points", [])
        enabled = [ep for ep in all_entry_points if ep.get("enabled", True)]

        return [
            {
                "label": ep["label"],
                "path": ep["path"],
                "color": ep.get("color", "#58a6ff"),
                "emoji": ep.get("emoji", "📍"),
            }
            for ep in enabled
        ]

    def preview_snapshot(
        self,
        file_path: str,
        parent_depth: int = 999,
        child_depth: int = 999,
        include_chain: bool = False,
        include_frontend: bool = False,
    ) -> Dict[str, Any]:
        """
        Preview a snapshot WITHOUT generating full content (DRY RUN).

        This is FAST and FREE - it shows you what would be included,
        estimated token count, and dependency graph WITHOUT reading
        file contents or making AI calls.

        **Defaults to full dependency tree (depth=999)** to capture complete
        context. Only reduce depth if preview shows >100k tokens.

        Use this to:
        - Check snapshot size before generating
        - See if you need to limit depth (only if >100k tokens)
        - View dependency structure
        - Estimate tokens for budget planning

        Args:
            file_path: Target file
            parent_depth: How many levels up (default: 999 = all parents)
            child_depth: How many levels down (default: 999 = all children)
            include_chain: Include chain to entry points
            include_frontend: Include templates/JS/CSS

        Returns:
            Dict with:
                - files: List of files that would be included
                - dependency_map: Graph structure
                - estimated_tokens: Rough token count (~4 chars/token)
                - estimated_cost: Rough cost estimate (input + output)
                - recommendations: Tips for optimization
        """
        from .parents import find_parents_to_depth
        from .children import get_children_to_depth, build_children_tree
        from .tokenizer import count_lines

        target_full = self.project_root / file_path
        if not target_full.exists():
            return {"error": f"File not found: {file_path}"}

        def to_rel(p: Path) -> str:
            try:
                return str(p.relative_to(self.project_root))
            except ValueError:
                return str(p)

        # Get parents
        parent_files = find_parents_to_depth(
            target_full,
            self.cache.reverse_index,
            self.cache.connected_files,
            parent_depth,
        ) if parent_depth > 0 else []

        # Get children
        child_files = get_children_to_depth(
            target_full,
            self.cache.forward_index,
            child_depth,
        ) if child_depth > 0 else []

        # Get chain files
        chain_files = {}
        if include_chain:
            from .chains import get_chain_to_entry_points
            chain_files = get_chain_to_entry_points(
                target_full,
                self.cache.entry_point_traces,
                self.project_root,
                None,
            )

        # Get frontend files
        frontend_files = []
        if include_frontend:
            from .analyzer import get_frontend_preview
            from .frontend_children import get_frontend_files_from_tree

            frontend_result = get_frontend_preview(file_path)
            if "tree" in frontend_result and frontend_result["tree"].get("children"):
                frontend_files = get_frontend_files_from_tree(
                    frontend_result["tree"], self.project_root
                )

        # Build file list with metrics (WITHOUT reading content)
        all_files = []
        total_lines = 0

        # Add parents
        for p in parent_files:
            lines = count_lines(p)
            total_lines += lines
            all_files.append({
                "path": to_rel(p),
                "type": "parent",
                "lines": lines,
                "estimated_tokens": lines * 4,  # Rough estimate
            })

        # Add target
        target_lines = count_lines(target_full)
        total_lines += target_lines
        all_files.append({
            "path": file_path,
            "type": "target",
            "lines": target_lines,
            "estimated_tokens": target_lines * 4,
        })

        # Add children
        for c in child_files:
            lines = count_lines(c)
            total_lines += lines
            all_files.append({
                "path": to_rel(c),
                "type": "child",
                "lines": lines,
                "estimated_tokens": lines * 4,
            })

        # Add frontend
        for f in frontend_files:
            lines = count_lines(f)
            total_lines += lines
            all_files.append({
                "path": to_rel(f),
                "type": "frontend",
                "lines": lines,
                "estimated_tokens": lines * 4,
            })

        # Calculate estimates
        estimated_input_tokens = total_lines * 4  # Rough: 1 line ≈ 4 tokens
        estimated_output_tokens = 1000  # Typical answer length

        # Cost estimate (Claude Sonnet 3.5 rates)
        input_cost_per_mtok = 3.00  # $3 per million input tokens
        output_cost_per_mtok = 15.00  # $15 per million output tokens

        estimated_input_cost = (estimated_input_tokens / 1_000_000) * input_cost_per_mtok
        estimated_output_cost = (estimated_output_tokens / 1_000_000) * output_cost_per_mtok
        total_estimated_cost = estimated_input_cost + estimated_output_cost

        # Build dependency map
        children_tree = build_children_tree(
            target_full,
            self.cache.forward_index,
            self.project_root,
        )

        dependency_map = {
            "target": file_path,
            "parent_count": len(parent_files),
            "child_count": len(child_files),
            "frontend_count": len(frontend_files),
            "chain_count": len(chain_files),
            "children_tree": children_tree,
        }

        # Recommendations
        recommendations = []
        if estimated_input_tokens > 100_000:
            recommendations.append("⚠️  Large snapshot (>100k tokens). Consider reducing depth.")
        if estimated_input_tokens > 200_000:
            recommendations.append("🚨 Very large snapshot (>200k tokens)! This will be expensive.")
        if parent_depth > 3:
            recommendations.append("💡 parent_depth > 3 can include many files. Try depth=2 first.")
        if child_depth > 2:
            recommendations.append("💡 child_depth > 2 grows exponentially. Try depth=1 first.")
        if len(frontend_files) > 20:
            recommendations.append("💡 Many frontend files included. Consider disabling if not needed.")
        if estimated_input_tokens < 5_000:
            recommendations.append("✅ Small snapshot - safe to generate!")

        return {
            "preview": True,
            "files": all_files,
            "dependency_map": dependency_map,
            "metrics": {
                "total_files": len(all_files),
                "total_lines": total_lines,
                "estimated_input_tokens": estimated_input_tokens,
                "estimated_output_tokens": estimated_output_tokens,
                "estimated_total_tokens": estimated_input_tokens + estimated_output_tokens,
            },
            "cost_estimate": {
                "input_cost": round(estimated_input_cost, 4),
                "output_cost": round(estimated_output_cost, 4),
                "total_cost": round(total_estimated_cost, 4),
                "currency": "USD",
                "model": "claude-sonnet-3.5",
            },
            "recommendations": recommendations,
            "config": {
                "parent_depth": parent_depth,
                "child_depth": child_depth,
                "include_chain": include_chain,
                "include_frontend": include_frontend,
            },
        }

    def create_snapshot(
        self,
        file_path: str,
        parent_depth: int = 999,
        child_depth: int = 999,
        include_chain: bool = False,
        include_frontend: bool = False,
        excluded_children: Optional[Set[str]] = None,
    ) -> Dict[str, Any]:
        """
        Create a rich snapshot with code + dependency map + analysis.

        This is the core "magnifying glass" - generate it instantly to explore
        a specific part of the codebase.

        **Defaults to full dependency tree (depth=999)** to capture complete
        context. Use preview_snapshot first if concerned about size.

        Args:
            file_path: Target file (relative to project root)
            parent_depth: How many levels up (default: 999 = all parents)
            child_depth: How many levels down (default: 999 = all children)
            include_chain: Include chain to entry points
            include_frontend: Include templates/JS/CSS
            excluded_children: Set of paths to exclude from children

        Returns:
            Dict with:
                - content: Full source code snapshot
                - dependency_map: Graph of relationships
                - analysis: Cached AI summaries if available
                - metrics: Token counts, file counts, etc.
        """
        options = SnapshotOptions(
            parent_depth=parent_depth,
            child_depth=child_depth,
            include_chain=include_chain,
            include_frontend=include_frontend,
            excluded_children=excluded_children or set(),
        )

        # Get frontend files if needed
        frontend_files = None
        if include_frontend:
            from .analyzer import get_frontend_preview
            from .frontend_children import get_frontend_files_from_tree

            frontend_result = get_frontend_preview(file_path)
            if "tree" in frontend_result and frontend_result["tree"].get("children"):
                frontend_files = get_frontend_files_from_tree(
                    frontend_result["tree"], self.project_root
                )

        # Generate snapshot
        snapshot_result = generate_snapshot(
            file_path,
            options,
            self.project_root,
            self.cache.reverse_index,
            self.cache.forward_index,
            self.cache.connected_files,
            self.cache.entry_point_traces,
            frontend_files=frontend_files,
        )

        if "error" in snapshot_result:
            return snapshot_result

        # Build dependency map
        target_full = self.project_root / file_path
        dependency_map = self._build_dependency_map(
            target_full,
            parent_depth,
            child_depth,
        )

        # Get cached analysis if available
        analysis_data = self.semantic_cache.get_analysis()

        # Filter analysis to only files in snapshot
        snapshot_files = set(dependency_map["all_files"])
        filtered_analysis = {}
        if analysis_data.get("files"):
            filtered_analysis = {
                path: data
                for path, data in analysis_data["files"].items()
                if path in snapshot_files
            }

        return {
            "content": snapshot_result["content"],
            "dependency_map": dependency_map,
            "analysis": {
                "files": filtered_analysis,
                "overview": analysis_data.get("overview"),
            },
            "metrics": snapshot_result["metrics"],
        }

    def _build_dependency_map(
        self,
        target_path: Path,
        parent_depth: int,
        child_depth: int,
    ) -> Dict[str, Any]:
        """
        Build a structured dependency map for the snapshot.

        Returns graph showing:
        - Who imports this file (parents/reverse)
        - What this file imports (children/forward)
        - Entry point connections
        """
        from .parents import find_parents_to_depth
        from .children import get_children_to_depth, build_children_tree

        def to_rel(p: Path) -> str:
            try:
                return str(p.relative_to(self.project_root))
            except ValueError:
                return str(p)

        target_rel = to_rel(target_path)

        # Get parents (who imports this)
        parent_files = find_parents_to_depth(
            target_path,
            self.cache.reverse_index,
            self.cache.connected_files,
            parent_depth,
        )

        # Get children (what this imports)
        child_files = get_children_to_depth(
            target_path,
            self.cache.forward_index,
            child_depth,
        )

        # Build children tree for structure
        children_tree = build_children_tree(
            target_path,
            self.cache.forward_index,
            self.project_root,
        )

        # Get direct dependencies
        direct_parents = list(self.cache.reverse_index.get(target_path.resolve(), set()))
        direct_children = list(self.cache.forward_index.get(target_path.resolve(), set()))

        # All files in snapshot
        all_files = {target_rel}
        all_files.update([to_rel(p) for p in parent_files])
        all_files.update([to_rel(c) for c in child_files])

        return {
            "target": target_rel,
            "all_files": list(all_files),
            "parents": [to_rel(p) for p in parent_files],
            "children": [to_rel(c) for c in child_files],
            "direct_parents": [to_rel(p) for p in direct_parents],
            "direct_children": [to_rel(c) for c in direct_children],
            "children_tree": children_tree,
            "stats": {
                "total_files": len(all_files),
                "parent_count": len(parent_files),
                "child_count": len(child_files),
                "direct_imports": len(direct_children),
                "direct_importers": len(direct_parents),
            },
        }

    def query_snapshot(
        self,
        snapshot: Dict[str, Any],
        question: str,
        detail_level: str = "normal",
    ) -> str:
        """
        Ask a single question about a snapshot.

        Args:
            snapshot: Snapshot from create_snapshot()
            question: Question to ask
            detail_level: "concise" (brief), "normal" (balanced), or "verbose" (detailed)

        Returns:
            AI-generated answer based on snapshot + analysis
        """
        if not self.api_key:
            return "Error: No API key configured. Set ANTHROPIC_API_KEY environment variable."

        # Build context from snapshot
        context_parts = []

        # Add dependency map
        dep_map = snapshot.get("dependency_map", {})
        if dep_map:
            context_parts.append("# DEPENDENCY MAP\n")
            context_parts.append(f"Target: {dep_map.get('target')}\n")
            context_parts.append(f"Total Files: {dep_map['stats']['total_files']}\n")
            context_parts.append(f"Parents (who imports this): {dep_map['stats']['parent_count']}\n")
            context_parts.append(f"Children (what this imports): {dep_map['stats']['child_count']}\n")
            context_parts.append(f"Direct imports: {dep_map['stats']['direct_imports']}\n")
            context_parts.append(f"Direct importers: {dep_map['stats']['direct_importers']}\n\n")

        # Add analysis summaries
        analysis = snapshot.get("analysis", {})
        if analysis.get("overview"):
            overview = analysis["overview"]
            context_parts.append("# SYSTEM OVERVIEW\n")
            context_parts.append(f"Architecture: {overview.get('architecture', 'N/A')}\n")
            context_parts.append(f"Entry Points: {', '.join(overview.get('entry_points', []))}\n")
            context_parts.append(f"Key Patterns: {', '.join(overview.get('key_patterns', []))}\n\n")

        if analysis.get("files"):
            context_parts.append("# FILE ANALYSES\n\n")
            for file_path, file_data in analysis["files"].items():
                context_parts.append(f"## {file_path}\n")
                context_parts.append(f"Layer: {file_data.get('layer', 'unknown')}\n")
                context_parts.append(f"Summary: {file_data.get('tier1', 'N/A')}\n")
                context_parts.append(f"Details: {file_data.get('tier2', 'N/A')}\n\n")

        # Add full code
        context_parts.append("# FULL CODE SNAPSHOT\n\n")
        context_parts.append(snapshot["content"])

        context = "".join(context_parts)

        # Query Claude - adjust prompt based on detail level
        detail_instructions = {
            "concise": """
CONCISE MODE - Be extremely brief:
- Answer: 1-2 sentences maximum
- Code references: 0-1 minimal examples (only if essential)
- Focus on direct answer to the question
- Skip architecture explanations unless asked""",
            "normal": """
NORMAL MODE - Balanced depth:
- Answer: 2-4 sentences with key details
- Code references: 2-3 relevant examples
- Include architecture context when relevant
- Balance brevity with completeness""",
            "verbose": """
VERBOSE MODE - Comprehensive detail:
- Answer: Full explanation with examples, edge cases, and context
- Code references: 4-6 examples covering different aspects
- Include architecture patterns, design decisions, trade-offs
- Explain WHY things are done this way, not just WHAT"""
        }

        system_prompt = f"""Codebase query engine for AI agents.

Context: dependency map, file summaries (tier1/2), full source code.

{detail_instructions.get(detail_level, detail_instructions["normal"])}

Return JSON with answer + code references + file recommendations:
{{
  "answer": "Explanation matching the detail level above",
  "code_references": [
    {{
      "path": "relative/path/to/file.py",
      "start": 100,
      "end": 150,
      "context": "Brief description of what this code section does"
    }}
  ],
  "primary_files": ["file1.py", "file2.py"] // 1-3 MOST RELEVANT files to understand this fully (SUGGESTIONS - agent decides whether to read)
}}

Rules:
- Answer focuses on WHAT/WHY (architecture, flow, relationships)
- Code references point to HOW (specific implementation snippets)
- primary_files are RECOMMENDATIONS only - the agent will decide whether to read them
  - Suggest files that contain core implementation, initialization, or complete context
  - Prioritize files >50 lines where snippets miss important context
  - List 1-3 most critical files for understanding the answer
- Cite specific line ranges where key logic lives
- Respect the detail level specified above

Return ONLY valid JSON."""

        client = ClaudeClient(api_key=self.api_key)
        response = client.client.messages.create(
            model=client.model,
            max_tokens=3000,
            system=system_prompt,
            messages=[
                {"role": "user", "content": f"{context}\n\n---\n\nQuestion: {question}"}
            ]
        )

        # Extract answer and parse JSON
        answer_text = ""
        for block in response.content:
            if hasattr(block, 'text'):
                answer_text += block.text

        # Parse JSON response (strip markdown if present)
        import json
        import re

        # Remove markdown code blocks if present
        cleaned = re.sub(r'^```json\s*|\s*```$', '', answer_text.strip(), flags=re.MULTILINE)
        cleaned = cleaned.strip()

        try:
            parsed = json.loads(cleaned)
            # Normalize: ensure primary_files exists (convert from primary_file if needed)
            if "primary_file" in parsed and "primary_files" not in parsed:
                parsed["primary_files"] = [parsed["primary_file"]] if parsed["primary_file"] else []
            elif "primary_files" not in parsed:
                parsed["primary_files"] = []
            return parsed
        except json.JSONDecodeError:
            # Fallback to plain text if JSON parsing fails
            return {
                "answer": answer_text,
                "code_references": [],
                "primary_files": []
            }

    def query_snapshot_batch(
        self,
        snapshot: Dict[str, Any],
        questions: List[str],
        detail_level: str = "normal",
        max_workers: int = 5,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Ask multiple questions about a snapshot IN PARALLEL.

        This is the killer feature for AI agents - ask 10 questions at once
        and get all answers in parallel, each with full snapshot context.

        Args:
            snapshot: Snapshot from create_snapshot()
            questions: List of questions to ask
            detail_level: "concise" (brief), "normal" (balanced), or "verbose" (detailed)
            max_workers: Max parallel requests (default 5)

        Returns:
            Dict mapping question -> {answer, code_references, primary_files}
        """
        results = {}

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all questions in parallel
            future_to_question = {
                executor.submit(self.query_snapshot, snapshot, q, detail_level): q
                for q in questions
            }

            # Collect results as they complete
            for future in as_completed(future_to_question):
                question = future_to_question[future]
                try:
                    answer = future.result()
                    results[question] = answer
                except Exception as e:
                    results[question] = f"Error: {str(e)}"

        return results

    def get_snapshot_overview(self, snapshot: Dict[str, Any]) -> str:
        """
        Get a structured overview of a snapshot - the default "first query" for AI agents.

        This provides a high-level map showing:
        - All files categorized by type (Backend, Frontend, Config, etc.)
        - Relative paths + lines of code for each file
        - Brief description of what each file does
        - Dependency structure (who imports what)

        Use this as the FIRST tool after creating a snapshot to understand
        what's included before diving deeper.

        Args:
            snapshot: Snapshot from create_snapshot()

        Returns:
            Formatted overview text with file map and descriptions
        """
        if not self.api_key:
            return "Error: No API key configured. Set ANTHROPIC_API_KEY environment variable."

        # Craft a carefully designed prompt for consistent, useful output
        overview_prompt = """Provide a comprehensive overview of this codebase snapshot in the following format:

## SNAPSHOT OVERVIEW

### Files Included
List ALL files in a table format with:
- Relative path
- Type (Backend Python / Frontend HTML / Frontend JS / Frontend CSS / Config / Other)
- Lines of code
- One-sentence description of purpose

Format as markdown table:
| File | Type | LOC | Description |
|------|------|-----|-------------|

### File Categories
Group files by type with counts:
- Backend Python: X files (Y total LOC)
- Frontend: X files (Y total LOC)
- Config/Other: X files (Y total LOC)

### Dependency Structure
High-level dependency flow:
- Entry points (if any)
- Main modules and what they import
- Frontend-backend connections (if any)

### Key Insights
- What is this snapshot focused on?
- What are the main architectural patterns?
- What would I explore next?

Be concise but complete. Focus on giving an AI agent a clear mental map."""

        return self.query_snapshot(snapshot, overview_prompt)

    def analyze_snapshot(self, snapshot: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate AI analysis (Tier 1 & 2 summaries) for snapshot.

        Args:
            snapshot: Snapshot from create_snapshot()

        Returns:
            Analysis data with tier1/tier2 for each file
        """
        if not self.api_key:
            return {"error": "No API key configured"}

        from .ai.analyzer import analyze_snapshot as ai_analyze

        result = ai_analyze(snapshot["content"], api_key=self.api_key)

        if "error" not in result:
            # Save to cache
            self.semantic_cache.update_analysis(result)

        return result

    def get_dependency_info(self, file_path: str) -> Dict[str, Any]:
        """
        Get complete dependency info without generating full snapshot.

        Useful for quick exploration: "What does this file import?"

        Args:
            file_path: File to inspect

        Returns:
            Dict with parents, children, chains to entry points
        """
        from .analyzer import get_full_dependency_info
        return get_full_dependency_info(file_path)

    def to_json(self, data: Any) -> str:
        """Convert data to JSON string for easy parsing by AI agents."""
        def path_serializer(obj):
            if isinstance(obj, Path):
                return str(obj)
            if isinstance(obj, set):
                return list(obj)
            raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

        return json.dumps(data, indent=2, default=path_serializer)
