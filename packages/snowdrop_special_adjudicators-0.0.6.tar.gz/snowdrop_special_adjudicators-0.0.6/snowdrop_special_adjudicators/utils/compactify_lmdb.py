import lmdb
from pathlib import Path

# Get the directory where this script lives
SCRIPT_DIR = Path(__file__).parent
# Go up one level to snowdrop_special_adjudicators, then into data
DATA_DIR = SCRIPT_DIR.parent / "data"
COMPACTED_DIR = DATA_DIR / "compacted"


def compact_lmdb(src_path: Path, dst_path: Path):
    """Create a compacted copy of an LMDB database."""
    src_env = lmdb.open(str(src_path), readonly=True)

    dst_path.mkdir(parents=True, exist_ok=True)

    src_env.copy(str(dst_path), compact=True)
    src_env.close()
    print(f"Compacted {src_path} -> {dst_path}")


# Run for each database
databases = [
    "graph_2_lookup.lmdb",
    "graph_5_lookup.lmdb",
    "graph_11_lookup.lmdb",
    "graph_12_lookup.lmdb",
    "graph_18_lookup.lmdb",
    "graph_19_lookup.lmdb",
    "graph_20_lookup.lmdb"
]

if __name__ == "__main__":
    for db in databases:
        compact_lmdb(DATA_DIR / db, COMPACTED_DIR / db)
    print("Done!")