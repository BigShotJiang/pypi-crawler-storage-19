import os
from supabase import create_client, ClientOptions
from dotenv import load_dotenv
import httpx

# Create client with longer timeout
timeout = httpx.Timeout(600.0)  # 10 minutes
options = ClientOptions(postgrest_client_timeout=600)

load_dotenv()

supabase = create_client(
    os.getenv("SUPABASE_URL"),
    os.getenv("SUPABASE_SERVICE_ROLE_KEY"),  # Find this in Project Settings > API > service_role
    options=options
)

# Manually set storage timeout
supabase.storage._client._timeout = timeout

file_path = os.path.join(os.getcwd(), '..', 'data', 'compacted', 'graph_5_lookup.lmdb', 'data.mdb')

with open(file_path, "rb") as f:
    response = supabase.storage.from_("lookup_tables").upload(
        "graph_5_lookup.lmdb/data.mdb",
        f,
        {"content-type": "application/octet-stream"}
    )
    print(response)
