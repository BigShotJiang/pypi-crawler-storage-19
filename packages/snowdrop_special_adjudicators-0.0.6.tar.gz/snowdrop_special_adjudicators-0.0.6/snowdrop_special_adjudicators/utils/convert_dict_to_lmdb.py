import lmdb
import struct
import sys
import os
import time

from snowdrop_tangled_game_engine import GraphProperties

from snowdrop_special_adjudicators.utils.utilities import load_lookup_table


def create_lmdb_from_dict(data: dict, data_dir: str, file_name: str):
    """One-time conversion of dict to LMDB."""
    if not os.path.exists(data_dir):
        os.mkdir(data_dir)

    path = os.path.join(data_dir, file_name)
    
    env = lmdb.open(path, map_size=10 * 1024**3)  # 10GB max
    with env.begin(write=True) as txn:
        for key, value in data.items():
            txn.put(key.encode(), struct.pack('e', value))  # 'e' = float16
    env.close()

    env = lmdb.open(path, readonly=True)
    stat = env.stat()
    info = env.info()

    print(f"Entries: {stat['entries']}")
    print(f"Actual data size: {stat['psize'] * info['last_pgno'] / 1024 ** 2:.1f} MB")

def main():

    # graph_number_list = [2, 11, 12, 18, 19, 20]   # leaving out 5
    graph_number_list = [5]   # just 5

    gp = GraphProperties()

    script_dir = os.path.dirname(os.path.abspath(__file__))  # Get the directory of the current script
    data_dir = os.path.join(script_dir, '..', 'data')

    for graph_number in graph_number_list:
        print('processing graph number', graph_number)
        graph_properties = gp.graph_database[graph_number]
        file_name = 'graph_' + str(graph_number) + '_lookup.lmdb'

        if os.path.exists(os.path.join(data_dir, file_name)):
            if input('lmdb file already exists, overwrite (y/n)?').lower() != 'y':
                sys.exit()

        print('creating lmdb file, this only happens once per graph...')

        print('loading raw lookup table ... ')
        start_time = time.time()
        full_lookup_table = load_lookup_table(data_dir=data_dir,
                                              graph_number=graph_number,
                                              vertex_count=graph_properties["num_nodes"],
                                              vertex_ownership=(graph_properties['player1_node'],
                                                                graph_properties['player2_node']))
        print('done, took', time.time() - start_time, 'seconds...')

        print('creating lmdb file for graph ' + str(graph_number) + ' ...')
        start_time = time.time()
        create_lmdb_from_dict(full_lookup_table, data_dir, file_name)
        print('done, took', time.time() - start_time, 'seconds...')

if __name__ == "__main__":
    sys.exit(main())
