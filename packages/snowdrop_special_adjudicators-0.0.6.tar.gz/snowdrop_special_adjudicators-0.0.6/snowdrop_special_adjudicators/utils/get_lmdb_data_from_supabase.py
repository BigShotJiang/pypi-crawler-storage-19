import os
import sys
import httpx
from supabase import create_client, ClientOptions
from dotenv import load_dotenv


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))  # Get the directory of the current script
    data_dir = os.path.join(script_dir, '..', 'data')

    download_lmdb_files(data_dir=data_dir)


def download_lmdb_files(data_dir: str):

    load_dotenv()

    # Create client with longer timeout
    timeout = httpx.Timeout(600.0)  # 10 minutes
    options = ClientOptions(postgrest_client_timeout=600)

    supabase = create_client(
        os.environ["SUPABASE_URL"],
        os.environ["SUPABASE_SERVICE_ROLE_KEY"],
        options=options
    )

    # Manually set storage timeout
    supabase.storage._client._timeout = timeout

    for graph_number in [2, 5, 11, 12 ,18, 19, 20]:
        remote_path = "graph_" + str(graph_number) + "_lookup.lmdb/data.mdb"
        local_path = os.path.join(data_dir, remote_path)
        os.makedirs(os.path.dirname(local_path), exist_ok=True)

        print('downloading', remote_path)

        data = supabase.storage.from_("lookup_tables").download(remote_path)

        with open(local_path, "wb") as f:
            f.write(data)

        print('done!')

if __name__ == "__main__":
    sys.exit(main())
