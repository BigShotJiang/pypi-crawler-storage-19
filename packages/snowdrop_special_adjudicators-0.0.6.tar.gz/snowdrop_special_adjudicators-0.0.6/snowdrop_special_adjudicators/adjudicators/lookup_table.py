import os
import sys
import lmdb
from typing import Optional
from pathlib import Path
import numpy as np

from snowdrop_special_adjudicators.utils.utilities import extract_state_key_from_game_state, load_lookup_table, extract_wld_from_lookup_table

from snowdrop_tangled_game_engine import GameState

from snowdrop_adjudicators import Adjudicator, AdjudicationResult, evaluate_winner


class LookupTableAdjudicator(Adjudicator):
    """Adjudicator implementation using pre-computed lookup tables"""

    def __init__(self) -> None:
        """Initialize the lookup table adjudicator"""
        super().__init__()
        # note: there is no data in /data -- the files are in supabase. run /utils/get_lmdb_data_from_supabase.py.
        self.data_dir: str = os.environ.get("SNOWDROP_DATA_DIR",
                                            str(Path(__file__).parent.parent / "data"))
        self.lookup_table: Optional[dict[str, np.float16]] | None = None
        self.epsilon: Optional[float] = None
        self.graph_number: Optional[int] = None
        self.use_lmdb = True
        self.lmdb_env: Optional[lmdb.Environment] | None = None
        self.lmdb_txn: Optional[lmdb.Transaction] | None = None

    def setup(self, **kwargs) -> None:
        """Configure lookup table parameters. kwargs is a dictionary with keys 'epsilon' and 'graph_number'
        and optional key 'data_dir'

        Keyword Args:
            data_dir (str, optional): Directory containing lookup table data files;
                default works for current lookup_tables
            epsilon (float): Draw boundary
            graph_number (int): Graph number
        Raises:
            ValueError: If parameters are invalid or data directory doesn't exist
        """
        if 'data_dir' in kwargs:
            if not isinstance(kwargs['data_dir'], str):
                raise ValueError("data_dir must be a string")
            if not os.path.isdir(kwargs['data_dir']):
                raise ValueError(f"Directory not found: {kwargs['data_dir']}")
            self.data_dir = kwargs['data_dir']

        if 'epsilon' not in kwargs:
            raise ValueError(f"epsilon must be provided in setup")
        else:
            if not isinstance(kwargs['epsilon'], float):
                raise ValueError("epsilon must be a float")
            self.epsilon = kwargs['epsilon']

        if 'graph_number' not in kwargs:
            raise ValueError(f"graph_number must be provided in setup")
        else:
            if not isinstance(kwargs['graph_number'], int):
                raise ValueError("graph_number must be an int")
            self.graph_number = kwargs['graph_number']

        if self.use_lmdb:
            self.lmdb_env = lmdb.open(os.path.join(self.data_dir, 'graph_' + str(self.graph_number) + '_lookup.lmdb'), readonly=True, lock=False)
            self.lmdb_txn = self.lmdb_env.begin()

        self._parameters = {'data_dir': self.data_dir,
                            'epsilon': self.epsilon,
                            'graph_number': self.graph_number}

    def _lmdb_lookup(self, key: str) -> np.float16 | None:
        raw = self.lmdb_txn.get(key.encode())
        return np.frombuffer(raw, dtype=np.float16)[0] if raw else None

    def _get_lookup_table(self, vertex_count: int, vertex_ownership: tuple[int, int]) -> None:
        """Load the appropriate lookup table for the given graph_number (vertex_count is passed in as a parameter)

        Raises:
            RuntimeError: If lookup table file cannot be loaded
        """

        if not isinstance(vertex_count, int):
            raise RuntimeError("vertex_count must be an int.")

        self.lookup_table = load_lookup_table(data_dir=self.data_dir,
                                              graph_number=self.graph_number,
                                              vertex_count=vertex_count,
                                              vertex_ownership=vertex_ownership)

        # print('WLD was: ', extract_wld_from_lookup_table(self.lookup_table, epsilon=self.epsilon))

    def adjudicate(self, game_state: GameState) -> AdjudicationResult:
        """Adjudicate the game state using the lookup table.

        Args:
            game_state: The current game state

        Returns:
            AdjudicationResult containing the adjudication details

        Raises:
            ValueError: If the game state is invalid or unsupported
            RuntimeError: If lookup table is not loaded
        """
        self._validate_game_state(game_state)

        # Load lookup table if needed
        if self.lookup_table is None and not self.use_lmdb:
            self._get_lookup_table(game_state['num_nodes'], (game_state['player1_node'], game_state['player2_node']))

            if not self.lookup_table:
                raise RuntimeError("Failed to load lookup table")

        # Extract lookup_table key from GameState instance
        lookup_state = extract_state_key_from_game_state(game_state)

        try:
            # this is the line where the key: value pair is extracted
            if self.use_lmdb:
                score: np.float16 = self._lmdb_lookup(str(lookup_state))
            else:
                score: np.float16 = self.lookup_table[str(lookup_state)]

            winner = evaluate_winner(float(score), self.epsilon)
        except KeyError:  # key not in results_dict
            raise RuntimeError("key not in lookup table...")

        return AdjudicationResult(
            game_state=game_state,
            adjudicator='lookup_table',
            winner=winner,
            score=float(score),
            influence_vector=None,  # available if we need them from the raw data
            correlation_matrix=None,
            parameters=self._parameters
        )


def main():
    adj = LookupTableAdjudicator()
    kwargs = {'epsilon': 0.0005,
              'graph_number': 5}
    adj.setup(**kwargs)

    game_state:GameState = {'graph_id': 5, 'player1_node': 5, 'player2_node': 7, 'num_nodes': 10,
                                              'edges': [(0, 2, 1), (0, 3, 1), (0, 6, 1), (1, 3, 3), (1, 4, 1),
                                                        (1, 7, 1), (2, 4, 3), (2, 8, 2), (3, 9, 3), (4, 5, 1),
                                                        (5, 6, 2), (5, 9, 3), (6, 7, 2), (7, 8, 2), (8, 9, 3)],
                                              'player1_id': 'player1', 'player2_id': 'player2', 'turn_count': 16,
                                              'current_player_index': 1}
    # '[0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 1, 1, 1, 3, 1, 1, 3, 2, 3, 1, 2, 3, 2, 2, 3]'
    res = adj.adjudicate(game_state)

    print()


if __name__ == "__main__":
    sys.exit(main())
