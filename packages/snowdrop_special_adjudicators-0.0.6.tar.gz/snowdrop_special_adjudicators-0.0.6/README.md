# snowdrop-special-adjudicators
Geordie's top secret Tangled adjudicators

## Data files
Data files have been moved to supabase buckets. There are automorphisms, adjudications, and lookup_tables buckets.
I did this because they are large and are messing with the git repo and poetry publish. I added a .env file with supabase
credentials and added dotenv to pyproject.toml.

There is a backup set of these locally at D://data_from_special_adjudications.