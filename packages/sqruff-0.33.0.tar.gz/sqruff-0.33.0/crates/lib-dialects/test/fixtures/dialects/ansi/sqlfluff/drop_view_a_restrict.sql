drop view a restrict
