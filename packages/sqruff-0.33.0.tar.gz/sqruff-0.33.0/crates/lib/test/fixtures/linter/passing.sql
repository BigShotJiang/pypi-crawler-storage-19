select a from b
