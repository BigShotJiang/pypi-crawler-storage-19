"""MangleFrames - PySpark DataFrame viewer with modern web UI."""
from __future__ import annotations

import time
from typing import TYPE_CHECKING

from .launcher import launch_viewer, open_browser
from .protocol import clear_stats_cache
from .server import DataFrameServer

if TYPE_CHECKING:
    from pyspark.sql import DataFrame

__version__ = "0.1.2"
__all__ = ["register", "unregister", "show"]

_registry: dict[str, DataFrame] = {}
_server: DataFrameServer | None = None
_viewer_launched = False


def register(name: str, df: DataFrame) -> None:
    """Register a DataFrame for viewing."""
    global _server

    _registry[name] = df
    clear_stats_cache(name)  # Invalidate cached stats for this name

    if _server is None:
        _server = DataFrameServer(_registry)
        _server.start()


def unregister(name: str) -> None:
    """Remove a DataFrame from the viewer."""
    if name in _registry:
        del _registry[name]
        clear_stats_cache(name)


def show(port: int = 8765, block: bool = True) -> None:
    """Open the viewer in a browser, launching the viewer if needed.

    Args:
        port: Port for the viewer web server.
        block: If True, block until Ctrl+C (keeps server alive).
    """
    global _viewer_launched, _server

    if _server is None or not _server.is_running:
        if not _registry:
            raise RuntimeError("No DataFrames registered. Call register() first.")
        _server = DataFrameServer(_registry)
        _server.start()

    if not _viewer_launched:
        launch_viewer(_server.socket_path, port)
        _viewer_launched = True

    open_browser(port)

    if block:
        try:
            print(f"MangleFrames viewer running at http://localhost:{port}")
            print("Press Ctrl+C to stop...")
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping MangleFrames...")
            _server.stop()
