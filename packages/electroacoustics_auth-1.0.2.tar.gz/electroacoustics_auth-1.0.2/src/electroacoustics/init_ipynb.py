# -*- coding: utf-8 -*-
# src\electroacoustics\init_ipynb.py

# Electroacoustics-AUTH Python distribution package
# Copyright (C) 2026 Christos Sevastiadis <csevast@auth.gr>
#
# This file is part of Electroacoustics-AUTH Python distribution package.
#
# Electroacoustics-AUTH is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program. If not, see <https://www.gnu.org/licenses/>.
"""
    Electroacoustics-AUTH package Jupyter Notebooks support module.

    Provides the essential imports and settings for running the Jupyter Notebooks
    for the Electroacoustics courses at Aristotle University of Thessaloniki. It
    imports the electroacoustics module from the Electroacoustics-AUTH package,
    as well as NumPy, Pandas, Matplotlib, and other commonly used libraries.

    Usage:
    Insert the following code in the first cell of your Jupyter Notebook:
    from electroacoustics.init_ipynb import *

"""
import warnings

import electroacoustics as ea
import numpy as np
import pandas as pd
from IPython.display import HTML, Latex, Markdown, Math, display
from matplotlib import pyplot as plt
from matplotlib import rc
from pandas.io.formats.style import Styler

__all__ = [
    "warnings",
    "ea",
    "np",
    "pd",
    "HTML",
    "Latex",
    "Markdown",
    "Math",
    "display",
    "plt",
    "rc",
    "Styler",
]
rc("text", usetex=True)
