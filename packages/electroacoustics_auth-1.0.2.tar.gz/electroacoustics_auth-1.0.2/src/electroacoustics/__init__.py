# -*- coding: utf-8 -*-
# src\electroacoustics\electroacoustics.py

# Electroacoustics-AUTH Python distribution package
# Copyright (C) 2026 Christos Sevastiadis <csevast@auth.gr>
#
# This file is part of Electroacoustics-AUTH Python distribution package.
#
# Electroacoustics-AUTH is free software: you can redistribute it and/or modify it under
# the terms of the GNU General Public License as published by the Free Software
# Foundation, either version 3 of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License along with this
# program. If not, see <https://www.gnu.org/licenses/>.
"""
    Electroacoustics-AUTH Python distribution package.

    Electroacoustics-AUTH is a Python distribution package that supports the teaching
    of Electroacoustics courses at Aristotle University of Thessaloniki. It consists
    of a tool library, electroacoustics, which contains constants, functions, and other
    Python objects used in lectures, exercises, and teaching materials, primarily within
    Jupyter Notebooks.

    Modules:
    - electroacoustics: Provides constants, functions, and other Python objects
      used in lectures, exercises, and teaching materials, primarily within
      Jupyter Notebooks.
    - init_ipynb: Provides the essential imports and settings for running the
      Jupyter Notebooks for the Electroacoustics courses at Aristotle University
      of Thessaloniki. It imports the electroacoustics module from the
      Electroacoustics-AUTH package, as well as NumPy, Pandas, Matplotlib, and
      other commonly used libraries.

    Examples:
    import electroacoustics
    or
    import electroacoustics as ea

    Documentation:
    Execute in command line:

    >python -c "import electroacoustics; dir(electroacoustics); help(electroacoustics)"

    or in the Python interpreter:
    >import electroacoustics
    >dir(electroacoustics)
    >help(electroacoustics)
    >import electroacoustics.init_ipynb
    >help(electroacoustics.init_ipynb)

"""

__author__ = "Christos Sevastiadis <csevast@ece.auth.gr>"
from importlib.metadata import PackageNotFoundError, version

from . import electroacoustics
from .electroacoustics import *

try:
    __version__ = version("electroacoustics-auth")
except PackageNotFoundError:
    __version__ = "0.0.0"

__doc__ = (__doc__ or "") + "\n\n" + (electroacoustics.__doc__ or "")

__all__ = list(set(electroacoustics.__all__) | {"__version__"})
