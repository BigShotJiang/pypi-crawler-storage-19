import os
from nicegui import ui, app
from supabase import create_client
import httpx
from rt_commission_dashboard.ui.theme import Theme
from rt_commission_dashboard.core.db_handler import get_db_handler
from rt_commission_dashboard.core.config import config

def login_page():
    Theme.apply_global_styles()

    # Center container
    with ui.column().classes('absolute-center w-full max-w-sm'):
        # Logo/Brand
        ui.label('RT Commission Dashboard').classes('text-3xl font-bold text-center w-full mb-8')

        with Theme.card():
            ui.label('Sign In').classes('text-xl font-bold mb-6 text-center w-full')

            email = ui.input('Email').props('outlined dense').classes('w-full mb-4 rt-input')
            password = ui.input('Password').props('outlined dense type=password').classes('w-full mb-6 rt-input')
            
            def handle_login():
                # Supabase auth path (default)
                if config.get_database_type() == 'supabase':
                    supabase_url = config.get_supabase_url()
                    supabase_anon = config.get_supabase_anon_key()
                    if not supabase_url or not supabase_anon:
                        ui.notify('Supabase not configured. Please complete setup.', type='warning')
                        ui.navigate.to('/setup')
                        return

                    client = create_client(supabase_url, supabase_anon)

                    try:
                        auth_response = client.auth.sign_in_with_password({
                            'email': email.value,
                            'password': password.value
                        })

                        user_id = auth_response.user.id

                        # Require approved profile record if present
                        profile_resp = client.table('profiles')\
                            .select('id,email,full_name,role,status,user_id')\
                            .eq('id', user_id)\
                            .maybe_single()\
                            .execute()

                        profile = profile_resp.data if hasattr(profile_resp, 'data') else None
                        if profile is None:
                            ui.notify('Account pending approval (profile not yet created).', type='warning')
                            client.auth.sign_out()
                            return

                        if profile.get('status') != 'approved':
                            ui.notify('Account pending approval. Please wait for admin approval.', type='warning')
                            client.auth.sign_out()
                            return

                        # Determine effective role and data user mapping
                        data_user_id = profile.get('user_id') if profile else None
                        data_user_role = None
                        if data_user_id:
                            try:
                                user_row = client.table('users').select('id, role, full_name').eq('id', data_user_id).maybe_single().execute()
                                if hasattr(user_row, 'data') and user_row.data:
                                    data_user_role = user_row.data.get('role')
                                    # Default full_name from users if profile missing it
                                    if not profile.get('full_name') and user_row.data.get('full_name'):
                                        profile['full_name'] = user_row.data.get('full_name')
                            except Exception:
                                pass

                        effective_role = profile.get('role') or data_user_role or 'ctv'

                        app.storage.user['authenticated'] = True
                        app.storage.user['user_info'] = {
                            'id': user_id,
                            'email': profile.get('email') if profile else email.value,
                            'role': effective_role,
                            'full_name': (profile or {}).get('full_name', ''),
                            'data_user_id': data_user_id
                        }
                        app.storage.user['supabase_token'] = auth_response.session.access_token
                        ui.notify('Welcome back!', type='positive')
                        ui.navigate.to('/')
                        return
                    except httpx.RequestError:
                        ui.notify('Cannot reach Supabase. Check URL/anon key or network/proxy and try again.', type='negative')
                        ui.navigate.to('/setup')
                        return
                    except Exception as exc:  # noqa: BLE001
                        ui.notify(f'Login failed: {exc}', type='negative')
                        return

                # SQLite fallback (legacy)
                db = get_db_handler()
                user = db.get_user(email.value)
                if user:
                    app.storage.user['authenticated'] = True
                    app.storage.user['user_info'] = user
                    ui.notify('Welcome back!', type='positive')
                    ui.navigate.to('/')
                else:
                    ui.notify('Invalid email (Try: admin@rt.local)', type='negative')

            ui.button('Login', on_click=handle_login).props('unelevated color=indigo-600').classes('w-full h-10')
            ui.link('Create account', '/signup').classes('block text-center mt-3 text-sm text-indigo-500')
            
        # Helper for Phase 1 testing
        with ui.expansion('Dev Hints', icon='code').classes('w-full mt-4 rt-muted text-sm'):
            with ui.column().classes('gap-1'):
                ui.label('Test Account:')
                ui.label('admin@rt.local (Admin)')
