# xEclipsity CLI
**this version is just in testing right now. next version will be full release**