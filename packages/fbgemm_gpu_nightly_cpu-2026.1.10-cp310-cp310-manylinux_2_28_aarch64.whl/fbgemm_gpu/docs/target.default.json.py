
{
    "version": "2026.1.10",
    "target": "default",
    "variant": "cpu"
}
