"""
Configuration classes for the LLM Handler module.

This module provides dataclasses for configuring the LLM handler,
including Langfuse integration settings.
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class LangfuseConfig:
    """Configuration for Langfuse integration.

    This immutable dataclass holds the credentials and settings needed
    to connect to Langfuse for prompt management and tracing.

    Args:
        secret_key: Langfuse secret key (starts with 'sk-lf-').
        public_key: Langfuse public key (starts with 'pk-lf-').
        host: Langfuse API host URL. Defaults to cloud.langfuse.com.

    Example:
        >>> config = LangfuseConfig(
        ...     secret_key="sk-lf-...",
        ...     public_key="pk-lf-...",
        ... )
        >>> config.host
        'https://cloud.langfuse.com'
    """

    secret_key: str
    public_key: str
    host: str = field(default="https://cloud.langfuse.com")

    def __post_init__(self) -> None:
        """Validate configuration after initialization."""
        if not self.secret_key:
            raise ValueError("secret_key cannot be empty")
        if not self.public_key:
            raise ValueError("public_key cannot be empty")
        if not self.host:
            raise ValueError("host cannot be empty")

