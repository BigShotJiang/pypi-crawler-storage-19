"""
LLM Handler sub-package for unified LLM interactions.

This package provides a Pythonic interface for calling various LLM providers
(OpenAI, Anthropic, Google) with integrated Langfuse prompt management and tracing.

Key Features:
    - Unified API across multiple providers (OpenAI, Anthropic, Google)
    - Langfuse integration for prompt management and tracing
    - Structured output support via Pydantic models
    - JSON mode for raw dictionary responses
    - Synchronous and asynchronous operations
    - Streaming support

Example:
    >>> from c1gpy.llm_handler import LLMHandler, LangfuseConfig, ModelProvider
    >>> from pydantic import BaseModel
    >>>
    >>> class ProductTitles(BaseModel):
    ...     titles: list[str]
    ...
    >>> handler = LLMHandler(
    ...     model_name="gpt-4o",
    ...     api_key="sk-...",
    ...     langfuse_prompt_name="product-title-generator",
    ...     langfuse_config=LangfuseConfig(
    ...         secret_key="sk-lf-...",
    ...         public_key="pk-lf-...",
    ...     ),
    ...     response_model=ProductTitles,
    ... )
    >>>
    >>> # Sync call
    >>> result = handler.call_model(keywords=["laptop", "gaming"], n_titles=5)
    >>> print(result.titles)
    >>>
    >>> # Async call
    >>> result = await handler.acall_model(keywords=["laptop"], n_titles=3)
    >>>
    >>> # Streaming
    >>> for chunk in handler.call_model_stream(keywords=["laptop"]):
    ...     print(chunk, end="")
"""

from c1gpy.llm_handler.config import LangfuseConfig
from c1gpy.llm_handler.exceptions import (
    LLMHandlerError,
    PromptCompilationError,
    PromptNotFoundError,
    ProviderError,
    ResponseParsingError,
)
from c1gpy.llm_handler.langfuse_client import get_langfuse_client
from c1gpy.llm_handler.handler import LLMHandler
from c1gpy.llm_handler.provider_registry import (
    ModelProvider,
    create_llm,
    detect_provider,
)

__all__ = [
    # Main handler
    "LLMHandler",
    # Configuration
    "LangfuseConfig",
    # Langfuse
    "get_langfuse_client",
    # Providers
    "ModelProvider",
    "create_llm",
    "detect_provider",
    # Exceptions
    "LLMHandlerError",
    "ProviderError",
    "PromptCompilationError",
    "PromptNotFoundError",
    "ResponseParsingError",
]
