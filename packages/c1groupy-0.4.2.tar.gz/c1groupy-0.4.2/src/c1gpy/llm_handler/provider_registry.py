"""Provider detection and model factories for :class:`~c1gpy.llm_handler.handler.LLMHandler`.

This module is intentionally small and focused:
- Map model names to providers (via prefixes).
- Build provider-specific LangChain chat models (via factories).

Factories use lazy imports so optional provider dependencies are only required
when that provider is used.
"""

import os
from enum import Enum
from typing import Any, Callable

from langchain_core.language_models.chat_models import BaseChatModel

from c1gpy.llm_handler.exceptions import ProviderError


class ModelProvider(Enum):
    """Supported LLM providers."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GOOGLE = "google"


_ENV_API_KEY_VARS: dict[ModelProvider, tuple[str, ...]] = {
    ModelProvider.OPENAI: ("OPENAI_API_KEY",),
    ModelProvider.ANTHROPIC: ("ANTHROPIC_API_KEY",),
    ModelProvider.GOOGLE: ("GOOGLE_API_KEY", "GEMINI_API_KEY"),
}


def _resolve_api_key(provider: ModelProvider, api_key: str | None) -> str:
    if api_key is not None and api_key.strip() != "":
        return api_key

    for env_var in _ENV_API_KEY_VARS.get(provider, ()):
        env_value = os.getenv(env_var)
        if env_value:
            return env_value

    raise ProviderError(
        "Missing API key. Provide 'api_key' or set one of these environment variables: "
        f"{_ENV_API_KEY_VARS.get(provider, ())}",
        provider=provider.value,
    )


# Registry of provider detection rules and LLM constructors.
_PROVIDER_REGISTRY: dict[
    ModelProvider,
    tuple[tuple[str, ...], Callable[[str, str, dict[str, Any]], BaseChatModel] | None],
] = {}


def register_provider(
    provider: ModelProvider,
    *,
    prefixes: tuple[str, ...] | None = None,
    factory: Callable[[str, str, dict[str, Any]], BaseChatModel] | None = None,
) -> None:
    """Register (or update) model-name prefixes and/or an LLM factory for a provider."""

    current_prefixes, current_factory = _PROVIDER_REGISTRY.get(provider, ((), None))
    _PROVIDER_REGISTRY[provider] = (
        prefixes if prefixes is not None else current_prefixes,
        factory if factory is not None else current_factory,
    )


def detect_provider(model_name: str) -> ModelProvider:
    """Infer provider from a model name using registered prefixes."""

    model_lower = model_name.lower()

    for provider, (prefixes, _) in _PROVIDER_REGISTRY.items():
        if prefixes and model_lower.startswith(prefixes):
            return provider

    supported_prefixes: tuple[str, ...] = tuple(
        p for prefixes, _ in _PROVIDER_REGISTRY.values() for p in prefixes
    )
    raise ProviderError(
        f"Cannot auto-detect provider for model '{model_name}'. "
        f"Supported prefixes: {supported_prefixes}. "
        "Please specify the provider explicitly.",
        provider=None,
    )


def create_llm(
    provider: ModelProvider,
    model_name: str,
    api_key: str | None = None,
    **kwargs: Any,
) -> BaseChatModel:
    """Construct a LangChain chat model for the given provider."""

    prefixes, factory = _PROVIDER_REGISTRY.get(provider, ((), None))
    if factory is None:
        raise ProviderError(
            f"Unsupported provider: {provider}",
            provider=str(provider),
        )

    resolved_api_key = _resolve_api_key(provider, api_key)
    return factory(model_name, resolved_api_key, kwargs)


def _create_openai_llm(
    model_name: str, api_key: str, kwargs: dict[str, Any]
) -> BaseChatModel:
    """Provider factory for OpenAI chat models."""

    from langchain_openai import ChatOpenAI

    return ChatOpenAI(model=model_name, api_key=api_key, **kwargs)


def _create_anthropic_llm(
    model_name: str, api_key: str, kwargs: dict[str, Any]
) -> BaseChatModel:
    """Provider factory for Anthropic chat models."""

    from langchain_anthropic import ChatAnthropic

    return ChatAnthropic(model=model_name, api_key=api_key, **kwargs)


def _create_google_llm(
    model_name: str, api_key: str, kwargs: dict[str, Any]
) -> BaseChatModel:
    """Provider factory for Google (Gemini) chat models."""

    from langchain_google_genai import ChatGoogleGenerativeAI

    return ChatGoogleGenerativeAI(model=model_name, google_api_key=api_key, **kwargs)


register_provider(
    ModelProvider.OPENAI, prefixes=("gpt-", "o1-", "o3-"), factory=_create_openai_llm
)
register_provider(
    ModelProvider.ANTHROPIC, prefixes=("claude-",), factory=_create_anthropic_llm
)
register_provider(
    ModelProvider.GOOGLE, prefixes=("gemini-",), factory=_create_google_llm
)


__all__ = [
    "ModelProvider",
    "create_llm",
    "detect_provider",
    "register_provider",
]
