from __future__ import annotations

from functools import lru_cache

from langfuse import Langfuse

from c1gpy.llm_handler.config import LangfuseConfig


@lru_cache(maxsize=4)
def _get_langfuse_client_cached(
    secret_key: str, public_key: str, host: str
) -> Langfuse:
    return Langfuse(secret_key=secret_key, public_key=public_key, host=host)


def get_langfuse_client(config: LangfuseConfig) -> Langfuse:
    """Return a cached Langfuse client for the given configuration."""

    return _get_langfuse_client_cached(
        secret_key=config.secret_key,
        public_key=config.public_key,
        host=config.host,
    )
