"""Coverage-focused tests."""
