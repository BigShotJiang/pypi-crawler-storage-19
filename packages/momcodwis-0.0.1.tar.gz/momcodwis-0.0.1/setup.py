from setuptools import setup, find_packages
setup(
    name="momcodwis",
    version="0.0.1",
    description="Бесконечный генератор оскорблений CodWis и его мамы.",
    packages=find_packages(),
    python_requires=">=3.7",
)
