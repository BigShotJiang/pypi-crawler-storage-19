import random
import itertools

# словарики
subjects = [
    "CodWis", "твоя мама", "твой код", "твой репо",
    "твой коммит", "твой прод", "твой линтер", "твой ПК",
    "твой интерпретатор", "твой GPT", "твой мозг", "твой гит"
]

verbs = [
    "насрал в", "сломал", "съел", "удалил", "засрал",
    "забыл", "переименовал в говно", "задеплоил как", "скомпилил как"
]

objects = [
    "prod", "мой мозг", "PEP8", "Docker", "репозиторий",
    "компилятор", "GPT-4", "твой проект", "твою маму", "README"
]

adjectives = [
    "тупой", "жирный", "безмозглый", "ошибка природы",
    "мертвый", "бесконечно тупой", "слетевший", "сраный"
]

locations = [
    "в проде", "в вакууме", "в моём мозге", "в твоём коде",
    "в твоей маме", "в гите", "в Docker-контейнере", "в линтере"
]

templates = [
    "{subject} {verb} {object} и получился ты",
    "твоя мама такая {adj}, что {verb} {object}",
    "{subject} — это {adj} {object}, который {verb} {location}",
    "когда {subject} {verb} {object}, даже компилятор сказал: 'nah, fuck this'",
    "{subject} настолько {adj}, что когда он {verb} {object} — выдало segmentation fault",
]

def _generate():
    while True:
        yield random.choice(templates).format(
            subject=random.choice(subjects),
            verb=random.choice(verbs),
            object=random.choice(objects),
            adj=random.choice(adjectives),
            location=random.choice(locations),
        )

def infinite_burn():
    return _generate()

