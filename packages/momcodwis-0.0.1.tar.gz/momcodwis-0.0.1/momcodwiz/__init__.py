from ._generator import infinite_burn
__version__ = "0.0.1"
__all__ = ["infinite_burn"]
