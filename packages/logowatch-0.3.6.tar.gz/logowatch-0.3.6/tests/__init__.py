"""Tests for logowatch package."""
