"""
Core log analysis engine for logowatch.

The LogAnalyzer class provides pattern-based log analysis with:
- Regex pattern matching
- Context extraction (lines before/after)
- Value extraction from matches
- Aggregation by extracted values
- Incremental detection (new errors only)
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

from logowatch.config import Config
from logowatch.models import (
    AnalysisCache,
    AnalysisResult,
    JsonParseOptions,
    LogSource,
    Match,
    Rule,
    RuleResult,
    Severity,
)


class LogAnalyzer:
    """
    Main log analysis engine.

    Analyzes log files based on configured rules and produces structured results.
    Supports incremental analysis to show only new errors since last check.
    """

    def __init__(
        self,
        config: Config,
        cache_path: Path | None = None,
        incremental: bool = True,
    ) -> None:
        """
        Initialize the analyzer.

        Args:
            config: Configuration with sources and rules
            cache_path: Path to store incremental cache (default: .logowatch_cache.json)
            incremental: Enable incremental mode (only show new errors)
        """
        self.config = config
        self.cache_path = cache_path or Path(".logowatch_cache.json")
        self.incremental = incremental
        self._cache: AnalysisCache | None = None

    @property
    def cache(self) -> AnalysisCache:
        """Get or load the cache."""
        if self._cache is None:
            self._cache = self._load_cache()
        return self._cache

    def _load_cache(self) -> AnalysisCache:
        """Load cache from file or create new one."""
        if self.cache_path.exists():
            try:
                data = json.loads(self.cache_path.read_text())
                return AnalysisCache.model_validate(data)
            except (json.JSONDecodeError, ValueError):
                pass
        return AnalysisCache()

    def _save_cache(self) -> None:
        """Save cache to file."""
        if self._cache:
            self.cache_path.write_text(
                json.dumps(self._cache.model_dump(mode="json"), indent=2, default=str)
            )

    def _get_file_hash(self, path: Path) -> str:
        """Get file hash for change detection (uses mtime + size)."""
        if not path.exists():
            return "missing"
        stat = path.stat()
        return f"{stat.st_mtime}_{stat.st_size}_{stat.st_ino}"

    def _get_files_for_source(self, source: LogSource) -> Iterator[Path]:
        """Get all files for a log source."""
        path = Path(source.path)

        if source.type == "file":
            if path.exists():
                yield path
        elif source.type == "directory":
            if path.is_dir():
                pattern = source.pattern or "*.log"
                yield from sorted(path.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
        elif source.type == "glob":
            if source.pattern:
                yield from sorted(Path().glob(source.pattern), key=lambda p: p.stat().st_mtime, reverse=True)

    def _read_file_lines(
        self,
        path: Path,
        start_line: int = 0,
        encoding: str = "utf-8",
    ) -> list[str]:
        """Read file lines, optionally starting from a specific line."""
        try:
            with open(path, encoding=encoding, errors="replace") as f:
                lines = f.readlines()
            if start_line > 0:
                return lines[start_line:]
            return lines
        except OSError:
            return []

    def _match_pattern(
        self,
        pattern: str,
        line: str,
        case_insensitive: bool = False,
    ) -> re.Match[str] | None:
        """Match a pattern against a line."""
        flags = re.IGNORECASE if case_insensitive else 0
        try:
            return re.search(pattern, line, flags)
        except re.error:
            return None

    def _extract_value(self, pattern: str, line: str) -> str | None:
        """Extract value using regex with capture group."""
        try:
            match = re.search(pattern, line)
            if match:
                # Return first capture group if exists, else full match
                groups = match.groups()
                return groups[0] if groups else match.group(0)
        except re.error:
            pass
        return None

    def _parse_json_line(self, line: str) -> dict | None:
        """Parse a JSON/JSONL line, returning None if invalid."""
        line = line.strip()
        if not line:
            return None
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            return None

    def _get_nested_value(self, data: dict, key: str) -> Any:
        """
        Get value from nested dict/list using dot notation and array indexing.

        Examples:
            'user.name' -> data['user']['name']
            'items[0]' -> data['items'][0]
            'content[0].text' -> data['content'][0]['text']
            'messages[-1].role' -> data['messages'][-1]['role']
        """
        import re

        # Split by dots but preserve array indices
        # Matches: fieldname or fieldname[index]
        pattern = r'([^.\[\]]+)(?:\[(-?\d+)\])?'
        parts = re.findall(pattern, key)

        current = data
        for field, index in parts:
            if not field:
                continue

            # Access dict field
            if isinstance(current, dict) and field in current:
                current = current[field]
            elif isinstance(current, dict):
                return None
            else:
                return None

            # Access array index if specified
            if index:
                idx = int(index)
                if isinstance(current, list):
                    if -len(current) <= idx < len(current):
                        current = current[idx]
                    else:
                        return None
                else:
                    return None

        return current

    def _evaluate_filter(self, data: dict, filter_expr: str) -> bool:
        """
        Evaluate a filter expression against JSON data.

        Supports:
            .field == "value"
            .field != "value"
            .field in ["a", "b"]
            .field contains "substring"
            .field starts_with "prefix"
            .field not_starts_with "prefix"
            .field exists
            .field > 100 (numeric)
            .field >= 100
            .field < 100
            .field <= 100

        Combining with AND:
            '.type == "user" && .message.content not_starts_with "[{"'
        """
        if not filter_expr:
            return True

        filter_expr = filter_expr.strip()

        # Handle AND (&&) combinations
        if " && " in filter_expr:
            parts = filter_expr.split(" && ")
            return all(self._evaluate_single_filter(data, p.strip()) for p in parts)

        return self._evaluate_single_filter(data, filter_expr)

    def _evaluate_single_filter(self, data: dict, filter_expr: str) -> bool:
        """Evaluate a single filter expression."""
        if not filter_expr:
            return True

        filter_expr = filter_expr.strip()

        # Parse the expression
        # Pattern: .field operator value
        def str_or_empty(val: Any) -> str:
            """Convert value to string, treating None as empty string."""
            return str(val) if val is not None else ""

        patterns = [
            # .field == "value" or .field == 123
            (r'^\.(\S+)\s*==\s*"([^"]*)"$', lambda d, f, v: str_or_empty(self._get_nested_value(d, f)) == v),
            (r'^\.(\S+)\s*==\s*(\d+)$', lambda d, f, v: self._get_nested_value(d, f) == int(v)),
            # .field != "value"
            (r'^\.(\S+)\s*!=\s*"([^"]*)"$', lambda d, f, v: str_or_empty(self._get_nested_value(d, f)) != v),
            # .field in ["a", "b"]
            (r'^\.(\S+)\s+in\s+\[([^\]]+)\]$', lambda d, f, v: str(self._get_nested_value(d, f)) in [x.strip().strip('"\'') for x in v.split(",")]),
            # .field contains "substring"
            (r'^\.(\S+)\s+contains\s+"([^"]*)"$', lambda d, f, v: v in str(self._get_nested_value(d, f) or "")),
            # .field starts_with "prefix"
            (r'^\.(\S+)\s+starts_with\s+"([^"]*)"$', lambda d, f, v: str(self._get_nested_value(d, f) or "").startswith(v)),
            # .field not_starts_with "prefix"
            (r'^\.(\S+)\s+not_starts_with\s+"([^"]*)"$', lambda d, f, v: not str(self._get_nested_value(d, f) or "").startswith(v)),
            # .field exists (not None/empty)
            (r'^\.(\S+)\s+exists$', lambda d, f, v: self._get_nested_value(d, f) is not None and self._get_nested_value(d, f) != ""),
            # Numeric comparisons
            (r'^\.(\S+)\s*>\s*(\d+)$', lambda d, f, v: (self._get_nested_value(d, f) or 0) > int(v)),
            (r'^\.(\S+)\s*>=\s*(\d+)$', lambda d, f, v: (self._get_nested_value(d, f) or 0) >= int(v)),
            (r'^\.(\S+)\s*<\s*(\d+)$', lambda d, f, v: (self._get_nested_value(d, f) or 0) < int(v)),
            (r'^\.(\S+)\s*<=\s*(\d+)$', lambda d, f, v: (self._get_nested_value(d, f) or 0) <= int(v)),
        ]

        for pattern, evaluator in patterns:
            match = re.match(pattern, filter_expr)
            if match:
                field = match.group(1)
                # Some patterns (like 'exists') don't have a value group
                value = match.group(2) if match.lastindex >= 2 else None
                try:
                    return evaluator(data, field, value)
                except (TypeError, ValueError):
                    return False

        # If no pattern matched, return True (pass through)
        return True

    def _format_json_display(
        self,
        data: dict,
        json_opts: JsonParseOptions,
    ) -> str:
        """Format JSON data for display using template or field list."""
        if json_opts.display:
            # Use format template: "{timestamp} [{level}] {msg}"
            result = json_opts.display
            for key in json_opts.fields or data.keys():
                value = self._get_nested_value(data, key)
                result = result.replace(f"{{{key}}}", str(value) if value is not None else "")
            return result
        elif json_opts.fields:
            # Just show extracted fields
            parts = []
            for key in json_opts.fields:
                value = self._get_nested_value(data, key)
                if value is not None:
                    parts.append(f"{key}={value}")
            return " | ".join(parts)
        else:
            # Compact JSON representation
            return json.dumps(data, ensure_ascii=False)

    def _match_json_line(
        self,
        line: str,
        rule: Rule,
    ) -> tuple[bool, dict | None, str | None]:
        """
        Match a JSON line against a rule.

        Returns:
            (matched, json_data, formatted_content)
        """
        data = self._parse_json_line(line)
        if data is None:
            return False, None, None

        json_opts = rule.options.json_parse if rule.options else None

        # Apply filter if specified
        if json_opts and json_opts.filter:
            if not self._evaluate_filter(data, json_opts.filter):
                return False, None, None

        # Apply pattern matching (can match on any field value)
        if rule.pattern != ".":
            # Convert JSON to string for pattern matching
            json_str = json.dumps(data, ensure_ascii=False)
            if not self._match_pattern(rule.pattern, json_str, rule.case_insensitive):
                return False, None, None

        # Format for display
        formatted = None
        if json_opts:
            formatted = self._format_json_display(data, json_opts)

        return True, data, formatted

    def _get_context(
        self,
        all_lines: list[str],
        line_idx: int,
        before: int = 0,
        after: int = 0,
    ) -> tuple[list[str], list[str]]:
        """Get context lines before and after a match."""
        start = max(0, line_idx - before)
        end = min(len(all_lines), line_idx + after + 1)

        context_before = [l.rstrip() for l in all_lines[start:line_idx]]
        context_after = [l.rstrip() for l in all_lines[line_idx + 1:end]]

        return context_before, context_after

    def _find_related(
        self,
        all_lines: list[str],
        line_idx: int,
        pattern: str,
        lines: int = 3,
        direction: str = "after",
    ) -> list[str]:
        """Find related patterns near a match."""
        related: list[str] = []

        if direction in ("before", "both"):
            start = max(0, line_idx - lines)
            for i in range(start, line_idx):
                if re.search(pattern, all_lines[i]):
                    related.append(all_lines[i].rstrip())

        if direction in ("after", "both"):
            end = min(len(all_lines), line_idx + lines + 1)
            for i in range(line_idx + 1, end):
                if re.search(pattern, all_lines[i]):
                    related.append(all_lines[i].rstrip())

        return related

    def _analyze_rule(
        self,
        rule: Rule,
        source: LogSource,
        all_lines: list[str],
        file_path: Path,
        start_line: int = 0,
    ) -> RuleResult:
        """Analyze a single rule against file lines."""
        matches: list[Match] = []
        aggregations: Counter[str] = Counter()
        related_patterns: list[str] = []
        total_count = 0

        # Options
        options = rule.options
        context_before = options.context.before if options and options.context else 0
        context_after = options.context.after if options and options.context else 0

        # Check if JSON format
        is_json_format = rule.format in ("json", "jsonl")

        for idx, line in enumerate(all_lines):
            # Match based on format
            json_data: dict | None = None
            formatted_content: str | None = None

            if is_json_format:
                matched, json_data, formatted_content = self._match_json_line(line, rule)
                if not matched:
                    continue
            else:
                if not self._match_pattern(rule.pattern, line, rule.case_insensitive):
                    continue

            total_count += 1
            actual_line_num = start_line + idx + 1

            # Limit matches stored in memory
            if len(matches) < 100:
                ctx_before, ctx_after = self._get_context(
                    all_lines, idx, context_before, context_after
                )

                # Extract values if configured
                extracted: dict[str, str] = {}
                if options and options.extract:
                    value = self._extract_value(options.extract.pattern, line)
                    if value:
                        extracted[options.extract.name] = value

                # For JSON, also extract from json_opts.fields
                if json_data and options and options.json_parse and options.json_parse.fields:
                    for field in options.json_parse.fields:
                        value = self._get_nested_value(json_data, field)
                        if value is not None:
                            extracted[field] = str(value)

                # Find related patterns
                if options and options.find_related:
                    related = self._find_related(
                        all_lines,
                        idx,
                        options.find_related.pattern,
                        options.find_related.lines,
                        options.find_related.direction,
                    )
                    related_patterns.extend(related)

                matches.append(
                    Match(
                        rule_id=rule.id,
                        line_number=actual_line_num,
                        content=line.rstrip(),
                        formatted_content=formatted_content,
                        source_file=file_path,
                        context_before=ctx_before,
                        context_after=ctx_after,
                        extracted_values=extracted,
                        json_data=json_data,
                    )
                )

            # Aggregate if configured
            if options and options.aggregate:
                if json_data:
                    # For JSON, can aggregate by field value
                    agg_value = self._get_nested_value(json_data, options.aggregate.by.lstrip("."))
                    if agg_value is not None:
                        aggregations[str(agg_value)] += 1
                else:
                    agg_value = self._extract_value(options.aggregate.by, line)
                    if agg_value:
                        aggregations[agg_value] += 1

        return RuleResult(
            rule=rule,
            total_count=total_count,
            new_count=total_count,  # All are "new" relative to start_line
            matches=matches,
            aggregations=dict(aggregations.most_common(50)),
            related_patterns=list(set(related_patterns))[:20],
        )

    def analyze(
        self,
        source_names: list[str] | None = None,
        max_examples: int = 20,
    ) -> AnalysisResult:
        """
        Run the analysis.

        Args:
            source_names: Specific sources to analyze (None = all)
            max_examples: Maximum examples to include per rule

        Returns:
            AnalysisResult with all findings
        """
        result = AnalysisResult(
            timestamp=datetime.now(),
            incremental=self.incremental,
            last_check=self.cache.last_check,
        )

        # Determine which sources to analyze
        sources = self.config.sources
        if source_names:
            sources = [s for s in sources if s.name in source_names]

        for source in sources:
            result.sources_analyzed.append(source.name)
            rules = self.config.get_rules_for_source(source.name)

            for file_path in self._get_files_for_source(source):
                file_hash = self._get_file_hash(file_path)
                cached_lines = 0

                if self.incremental:
                    cached_lines = self.cache.get_cached_line_count(str(file_path), file_hash)

                # Read all lines for context
                all_lines = self._read_file_lines(file_path, encoding=source.encoding)
                result.total_lines += len(all_lines)

                # For incremental, only analyze new lines
                lines_to_analyze = all_lines[cached_lines:] if cached_lines > 0 else all_lines
                start_line = cached_lines

                for rule in rules:
                    rule_result = self._analyze_rule(
                        rule, source, lines_to_analyze, file_path, start_line
                    )

                    if rule_result.total_count > 0:
                        # Limit examples
                        rule_result.matches = rule_result.matches[:max_examples]

                        # Update severity counts
                        if rule.severity == Severity.ERROR:
                            result.total_errors += rule_result.total_count
                        elif rule.severity == Severity.WARNING:
                            result.total_warnings += rule_result.total_count
                        else:
                            result.total_info += rule_result.total_count

                        result.rule_results.append(rule_result)

                # Update cache
                if self.incremental:
                    self.cache.update_entry(str(file_path), len(all_lines), file_hash)

        # Save cache
        if self.incremental:
            self._save_cache()

        return result

    def analyze_file(
        self,
        file_path: Path | str,
        rules: list[Rule] | None = None,
    ) -> AnalysisResult:
        """
        Analyze a single file with specified rules.

        Args:
            file_path: Path to the log file
            rules: Rules to apply (default: all rules)

        Returns:
            AnalysisResult with findings
        """
        file_path = Path(file_path)
        rules = rules or self.config.rules

        result = AnalysisResult(
            timestamp=datetime.now(),
            sources_analyzed=[str(file_path)],
        )

        all_lines = self._read_file_lines(file_path)
        result.total_lines = len(all_lines)

        dummy_source = LogSource(name="direct", path=file_path, type="file")

        for rule in rules:
            rule_result = self._analyze_rule(rule, dummy_source, all_lines, file_path)

            if rule_result.total_count > 0:
                if rule.severity == Severity.ERROR:
                    result.total_errors += rule_result.total_count
                elif rule.severity == Severity.WARNING:
                    result.total_warnings += rule_result.total_count
                else:
                    result.total_info += rule_result.total_count

                result.rule_results.append(rule_result)

        return result
