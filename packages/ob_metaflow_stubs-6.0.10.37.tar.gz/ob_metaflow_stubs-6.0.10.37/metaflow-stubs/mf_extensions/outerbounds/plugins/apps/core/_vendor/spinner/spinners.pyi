######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.2+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-08T22:31:02.788833                                                            #
######################################################################################################

from __future__ import annotations

import enum
import typing
if typing.TYPE_CHECKING:
    import enum


class Spinners(enum.Enum, metaclass=enum.EnumType):
    def __new__(cls, value):
        ...
    ...

