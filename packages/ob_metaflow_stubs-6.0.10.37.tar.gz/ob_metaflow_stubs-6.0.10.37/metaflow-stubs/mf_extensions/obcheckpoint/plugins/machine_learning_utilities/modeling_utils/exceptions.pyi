######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.2+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-08T22:31:02.782787                                                            #
######################################################################################################

from __future__ import annotations

import metaflow
import typing
if typing.TYPE_CHECKING:
    import metaflow.exception

from ......exception import MetaflowException as MetaflowException

class LoadingException(metaflow.exception.MetaflowException, metaclass=type):
    def __init__(self, message):
        ...
    ...

class ModelException(metaflow.exception.MetaflowException, metaclass=type):
    def __init__(self, message):
        ...
    ...

