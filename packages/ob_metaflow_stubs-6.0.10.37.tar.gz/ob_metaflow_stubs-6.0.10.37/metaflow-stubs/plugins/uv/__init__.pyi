######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.2+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-08T22:31:02.736362                                                            #
######################################################################################################

from __future__ import annotations


from . import uv_environment as uv_environment

