######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.2+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-08T22:31:02.736902                                                            #
######################################################################################################

from __future__ import annotations

import metaflow
import typing
if typing.TYPE_CHECKING:
    import metaflow.event_logger


class DebugEventLogger(metaflow.event_logger.NullEventLogger, metaclass=type):
    @classmethod
    def get_worker(cls):
        ...
    ...

class DebugEventLoggerSidecar(object, metaclass=type):
    def __init__(self):
        ...
    def process_message(self, msg):
        ...
    ...

