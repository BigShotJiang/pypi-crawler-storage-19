######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.2+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-08T22:31:02.769721                                                            #
######################################################################################################

from __future__ import annotations


from . import batch_client as batch_client
from . import batch as batch
from . import batch_decorator as batch_decorator

