######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.2+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-08T22:31:02.757937                                                            #
######################################################################################################

from __future__ import annotations

import metaflow
import typing
if typing.TYPE_CHECKING:
    import metaflow.plugins.pypi.conda_environment

from .conda_environment import CondaEnvironment as CondaEnvironment

class PyPIEnvironment(metaflow.plugins.pypi.conda_environment.CondaEnvironment, metaclass=type):
    ...

