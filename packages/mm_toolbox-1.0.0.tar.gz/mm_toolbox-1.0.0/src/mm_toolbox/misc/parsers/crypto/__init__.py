"""Crypto-related parsers."""


