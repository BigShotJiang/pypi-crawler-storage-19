"""
LLM tracking decorator for LLMOps Observability
Direct Langfuse integration for tracking LLM calls
Enhanced with veriskGO-style input/output handling
"""
from __future__ import annotations
import functools
import inspect
import time
import traceback
from typing import Optional, Dict, Any
from .trace_manager import TraceManager


def extract_text(resp: Any) -> str:
    """
    Extract text from various LLM response formats.
    Supports: Bedrock Converse, Bedrock InvokeModel, OpenAI, LangChain, etc.
    """
    if isinstance(resp, str):
        return resp

    if not isinstance(resp, dict):
        return str(resp)

    # Bedrock Converse API
    try:
        return resp["output"]["message"]["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Anthropic Messages API
    try:
        return resp["content"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Amazon Titan
    try:
        return resp["results"][0]["outputText"]
    except (KeyError, IndexError, TypeError):
        pass

    # Cohere
    try:
        return resp["generation"]
    except (KeyError, TypeError):
        pass

    # AI21
    try:
        return resp["outputs"][0]["text"]
    except (KeyError, IndexError, TypeError):
        pass

    # Generic text field
    try:
        return resp["text"]
    except (KeyError, TypeError):
        pass

    # OpenAI format
    try:
        return resp["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        pass

    return str(resp)


def track_llm_call(
    name: Optional[str] = None,
    *,
    tags: Optional[Dict[str, Any]] = None,
    extract_output: bool = True,
):
    """
    Decorator to track LLM calls with Langfuse as generations.
    
    Enhanced version inspired by veriskGO with proper input/output handling.
    
    Usage:
        @track_llm_call()
        def call_bedrock(prompt):
            response = bedrock.converse(...)
            return response
            
        @track_llm_call(name="summarize", tags={"model": "claude-3"})
        async def summarize(text):
            return await chain.ainvoke(...)
    
    Args:
        name: Optional custom name for the generation
        tags: Optional metadata tags
        extract_output: Whether to extract text from LLM response
    """
    def decorator(func):
        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)
        
        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    return await func(*args, **kwargs)

                # Get parent span ID from stack
                with TraceManager._lock:
                    parent_span_id = (
                        TraceManager._active["stack"][-1]["span_id"]
                        if TraceManager._active["stack"]
                        else None
                    )
                    trace_id = TraceManager._active["trace_id"]
                
                span_id = TraceManager._id()
                start_time = time.time()

                # Push current span onto stack BEFORE executing function
                with TraceManager._lock:
                    TraceManager._active["stack"].append({"span_id": span_id, "name": span_name})

                error = None
                result = None
                
                try:
                    result = await func(*args, **kwargs)
                except Exception as e:
                    error = e
                finally:
                    # Pop from stack
                    with TraceManager._lock:
                        if TraceManager._active["stack"] and TraceManager._active["stack"][-1]["span_id"] == span_id:
                            TraceManager._active["stack"].pop()
                    
                    duration_ms = int((time.time() - start_time) * 1000)
                    
                    # Build input - extract prompt if first arg is string
                    if args and isinstance(args[0], str):
                        input_data = {
                            "prompt": args[0],
                            "args": args[1:],
                            "kwargs": kwargs,
                        }
                    else:
                        input_data = {
                            "args": args,
                            "kwargs": kwargs,
                        }
                    
                    # Build output
                    if error:
                        output_data = {
                            "status": "error",
                            "error": str(error),
                            "stacktrace": traceback.format_exc(),
                        }
                    else:
                        # Extract text from response if enabled
                        if extract_output:
                            try:
                                text_output = extract_text(result)
                                output_data = {
                                    "status": "success",
                                    "text": text_output,
                                    "raw": result,
                                }
                            except Exception:
                                output_data = {
                                    "status": "success",
                                    "raw": result,
                                }
                        else:
                            output_data = {
                                "status": "success",
                                "raw": result,
                            }
                    
                    # Send generation to Langfuse immediately
                    TraceManager.send_span_to_langfuse(
                        span_id=span_id,
                        parent_span_id=parent_span_id,
                        span_name=span_name,
                        span_type="generation",
                        start_time=start_time,
                        duration_ms=duration_ms,
                        input_data=input_data,
                        output_data=output_data,
                        metadata=tags or {},
                        error=error,
                    )
                    
                    if error:
                        raise error
                
                return result
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    return func(*args, **kwargs)

                # Get parent span ID from stack
                with TraceManager._lock:
                    parent_span_id = (
                        TraceManager._active["stack"][-1]["span_id"]
                        if TraceManager._active["stack"]
                        else None
                    )
                    trace_id = TraceManager._active["trace_id"]
                
                span_id = TraceManager._id()
                start_time = time.time()

                # Push current span onto stack BEFORE executing function
                with TraceManager._lock:
                    TraceManager._active["stack"].append({"span_id": span_id, "name": span_name})

                error = None
                result = None
                
                try:
                    result = func(*args, **kwargs)
                except Exception as e:
                    error = e
                finally:
                    # Pop from stack
                    with TraceManager._lock:
                        if TraceManager._active["stack"] and TraceManager._active["stack"][-1]["span_id"] == span_id:
                            TraceManager._active["stack"].pop()
                    
                    duration_ms = int((time.time() - start_time) * 1000)
                    
                    # Build input - extract prompt if first arg is string
                    if args and isinstance(args[0], str):
                        input_data = {
                            "prompt": args[0],
                            "args": args[1:],
                            "kwargs": kwargs,
                        }
                    else:
                        input_data = {
                            "args": args,
                            "kwargs": kwargs,
                        }
                    
                    # Build output
                    if error:
                        output_data = {
                            "status": "error",
                            "error": str(error),
                            "stacktrace": traceback.format_exc(),
                        }
                    else:
                        # Extract text from response if enabled
                        if extract_output:
                            try:
                                text_output = extract_text(result)
                                output_data = {
                                    "status": "success",
                                    "text": text_output,
                                    "raw": result,
                                }
                            except Exception:
                                output_data = {
                                    "status": "success",
                                    "raw": result,
                                }
                        else:
                            output_data = {
                                "status": "success",
                                "raw": result,
                            }
                    
                    # Send generation to Langfuse immediately
                    TraceManager.send_span_to_langfuse(
                        span_id=span_id,
                        parent_span_id=parent_span_id,
                        span_name=span_name,
                        span_type="generation",
                        start_time=start_time,
                        duration_ms=duration_ms,
                        input_data=input_data,
                        output_data=output_data,
                        metadata=tags or {},
                        error=error,
                    )
                    
                    if error:
                        raise error
                
                return result
            
            return sync_wrapper
    
    return decorator


