"""
Trace Manager for LLMOps Observability
Handles tracing and tracking of LLM operations with direct Langfuse integration
Inspired by veriskGO's trace_manager with instant span sending to Langfuse
"""
from __future__ import annotations
import uuid
import threading
import time
import traceback
import functools
import inspect
import sys
import json
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Union
from .models import SpanContext
from .config import get_langfuse_client


# ============================================================
# Safe Serialization Helpers (from veriskGO)
# ============================================================

# Maximum size for serialized output (200 KB)
MAX_OUTPUT_SIZE = 200 * 1024  # 200 KB

def serialize_value(value: Any, max_size: int = MAX_OUTPUT_SIZE) -> Any:
    """Serialize value with size limit to prevent large data issues.
    
    Args:
        value: Value to serialize
        max_size: Maximum size in bytes (default 200 KB)
    
    Returns:
        Serialized value, truncated if necessary
    """
    try:
        # First, serialize to JSON
        serialized_str = json.dumps(value, default=str)
        serialized_bytes = serialized_str.encode('utf-8')
        
        # Check size
        if len(serialized_bytes) <= max_size:
            return json.loads(serialized_str)
        
        # Too large - return truncation info instead
        preview_size = min(1000, max_size // 2)  # Show first 1KB as preview
        preview = serialized_str[:preview_size]
        
        print(f"[LLMOps-Observability] Output truncated: {len(serialized_bytes)} bytes → {max_size} bytes limit")
        
        return {
            "_truncated": True,
            "_original_size_bytes": len(serialized_bytes),
            "_original_size_mb": round(len(serialized_bytes) / (1024 * 1024), 2),
            "_preview": preview + "...",
            "_message": f"Output truncated (original: {round(len(serialized_bytes) / (1024 * 1024), 2)} MB, limit: {round(max_size / 1024, 0)} KB)"
        }
    except Exception as e:
        return str(value)


def safe_locals(d: Dict[str, Any]) -> Dict[str, Any]:
    """Safely serialize local variables"""
    return {k: serialize_value(v) for k, v in d.items() if not k.startswith("_")}


# ============================================================
# Core Trace Manager
# ============================================================

class TraceManager:
    _lock = threading.Lock()
    _active: Dict[str, Any] = {
        "trace_id": None,
        "trace_obj": None,  # Langfuse trace object reference
        "spans": [],
        "stack": [],  # Stack of active spans for nesting
        "metadata": {},
    }

    @classmethod
    def has_active_trace(cls) -> bool:
        """Check if there's an active trace"""
        return cls._active["trace_id"] is not None

    @classmethod
    def _id(cls) -> str:
        """Generate a unique ID compatible with Langfuse (32 lowercase hex chars)"""
        return uuid.uuid4().hex

    @classmethod
    def _now(cls) -> str:
        """Get current timestamp in ISO format"""
        return datetime.now(timezone.utc).isoformat()

    @classmethod
    def start_trace(
        cls,
        name: str,
        metadata: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> str:
        """
        Start a new trace (similar to veriskGO API).
        
        Args:
            name: Name of the trace
            metadata: Optional metadata dictionary
            user_id: Optional user ID
            session_id: Optional session ID
            tags: Optional list of tags
            
        Returns:
            str: Trace ID
        """
        with cls._lock:
            if cls._active["trace_id"]:
                print("[LLMOps-Observability] WARNING: Trace already active. Ending previous trace.")
                cls._end_trace_internal()

            trace_id = cls._id()
            
            # Store trace information
            cls._active["trace_id"] = trace_id
            cls._active["trace_obj"] = {
                "name": name,
                "user_id": user_id,
                "session_id": session_id,
                "metadata": metadata or {},
                "tags": tags or [],
                "trace_input": None,
                "trace_output": None,
            }
            cls._active["spans"] = []
            cls._active["stack"] = []  # Initialize stack for nested spans
            cls._active["metadata"] = metadata or {}
            
            print(f"[LLMOps-Observability] Trace started: {name} (ID: {trace_id})")
            return trace_id

    @classmethod
    def _end_trace_internal(cls):
        """Internal method to end trace without lock (already within lock context)"""
        trace_id = cls._active["trace_id"]
        
        if trace_id:
            # Flush to Langfuse immediately
            langfuse = get_langfuse_client()
            langfuse.flush()
            
            # Clear the active trace
            cls._active["trace_id"] = None
            cls._active["trace_obj"] = None
            cls._active["spans"] = []
            cls._active["stack"] = []
            cls._active["metadata"] = {}

    @classmethod
    def end_trace(cls, final_output: Optional[Any] = None) -> Optional[str]:
        """
        End the current trace and flush to Langfuse.
        
        Args:
            final_output: Optional final output for the trace
            
        Returns:
            Optional[str]: Trace ID if successful
        """
        with cls._lock:
            trace_id = cls._active["trace_id"]
            
            if not trace_id:
                return None
            
            if final_output and cls._active["trace_obj"]:
                cls._active["trace_obj"]["trace_output"] = final_output
            
            cls._end_trace_internal()
            
            print(f"[LLMOps-Observability] Trace ended and flushed: {trace_id}")
            return trace_id

    @classmethod
    def finalize_and_send(
        cls,
        *,
        user_id: str,
        session_id: str,
        trace_name: str,
        trace_input: dict,
        trace_output: dict,
        extra_spans: list = [],
    ):
        """
        Finalize and send the trace with input/output (compatible with veriskGO API).
        
        This method provides compatibility with veriskGO's API by accepting
        trace_input and trace_output, then ending the trace.
        
        Args:
            user_id: User ID for the trace
            session_id: Session ID for the trace
            trace_name: Name of the trace
            trace_input: Input data for the trace
            trace_output: Output data for the trace
            extra_spans: Additional spans (not used in this implementation)
        
        Returns:
            bool: True if successful, False otherwise
        """
        with cls._lock:
            trace_id = cls._active.get("trace_id")
            trace_obj = cls._active.get("trace_obj")
            
            if not trace_id or not trace_obj:
                print("[LLMOps-Observability] ERROR: No active trace to finalize.")
                return False
            
            # Update trace object with input/output
            trace_obj["trace_input"] = serialize_value(trace_input)
            trace_obj["trace_output"] = serialize_value(trace_output)
            trace_obj["user_id"] = user_id
            trace_obj["session_id"] = session_id
            trace_obj["name"] = trace_name
            
            # Store updated trace_obj
            cls._active["trace_obj"] = trace_obj
        
        # Send trace-level data to Langfuse using the correct API
        try:
            langfuse = get_langfuse_client()
            
            # Create trace-level observation using start_as_current_observation
            with langfuse.start_as_current_observation(
                as_type="span",
                name=trace_name,
                trace_context={"trace_id": trace_id},
                input=trace_obj["trace_input"],
                output=trace_obj["trace_output"],
            ) as root:
                # Update trace with user_id, session_id, and metadata
                root.update_trace(
                    name=trace_name,
                    user_id=user_id,
                    session_id=session_id,
                    metadata=trace_obj.get("metadata", {}),
                    input=trace_obj["trace_input"],
                    output=trace_obj["trace_output"],
                )
            
            # Flush immediately (no batching)
            langfuse.flush()
            
        except Exception as e:
            print(f"[LLMOps-Observability] Error sending trace to Langfuse: {e}")
            traceback.print_exc()
        
        # End the trace
        with cls._lock:
            cls._end_trace_internal()
        
        print(f"[LLMOps-Observability] Trace finalized and sent: {trace_name} (ID: {trace_id})")
        return True


    @classmethod
    def send_span_to_langfuse(
        cls,
        *,
        span_id: str,
        parent_span_id: Optional[str],
        span_name: str,
        span_type: str,
        start_time: float,
        duration_ms: int,
        input_data: Any,
        output_data: Any,
        metadata: Dict[str, Any],
        error: Optional[Exception] = None,
    ):
        """
        Send a span directly to Langfuse (instant, no batching).
        
        Uses Langfuse's event-based API similar to veriskGO's Lambda processor.
        
        Args:
            span_id: Unique span ID
            parent_span_id: Parent span ID (if nested)
            span_name: Name of the span
            span_type: Type ("span" or "generation")
            start_time: Start time (timestamp)
            duration_ms: Duration in milliseconds
            input_data: Input data for the span
            output_data: Output data for the span
            metadata: Metadata dictionary
            error: Optional exception if span failed
        """
        with cls._lock:
            trace_id = cls._active.get("trace_id")
            trace_obj = cls._active.get("trace_obj")
            
            if not trace_id or not trace_obj:
                print(f"[LLMOps-Observability] WARNING: No active trace for span: {span_name}")
                return
        
        langfuse = get_langfuse_client()
        
        # Calculate timestamps
        start_dt = datetime.fromtimestamp(start_time, tz=timezone.utc)
        end_dt = datetime.fromtimestamp(start_time + (duration_ms / 1000), tz=timezone.utc)
        
        # Serialize input/output
        serialized_input = serialize_value(input_data)
        serialized_output = serialize_value(output_data)
        
        # Create observation using start_as_current_observation and immediately end it
        try:
            trace_context = {"trace_id": trace_id}
            
            # Add user_id and session_id if available
            if trace_obj.get("user_id"):
                trace_context["user_id"] = trace_obj.get("user_id")
            if trace_obj.get("session_id"):
                trace_context["session_id"] = trace_obj.get("session_id")
            
            if span_type == "generation":
                # For LLM calls, create a generation event
                with langfuse.start_as_current_observation(
                    as_type="generation",
                    name=span_name,
                    trace_context=trace_context,
                    input=serialized_input,
                ) as obs:
                    obs.update(
                        output=serialized_output,
                        metadata=metadata,
                        level="ERROR" if error else "DEFAULT",
                        status_message=str(error) if error else None,
                    )
            else:
                # For regular functions, create a span event
                with langfuse.start_as_current_observation(
                    as_type="span",
                    name=span_name,
                    trace_context=trace_context,
                    input=serialized_input,
                ) as obs:
                    obs.update(
                        output=serialized_output,
                        metadata=metadata,
                        level="ERROR" if error else "DEFAULT",
                        status_message=str(error) if error else None,
                    )
            
        except Exception as e:
            print(f"[LLMOps-Observability] ERROR sending span to Langfuse: {e}")
            traceback.print_exc()
            return
        
        # Flush immediately (no batching)
        langfuse.flush()
        
        status_str = " (error)" if error else ""
        print(f"[LLMOps-Observability] Span sent{status_str}: {span_name} ({duration_ms}ms)")


# ============================================================
# Local Capture Utilities (from veriskGO)
# ============================================================

def capture_function_locals(func, capture_locals=True, capture_self=True):
    """
    Capture local variables before and after function execution.
    Uses sys.settrace for frame inspection (similar to veriskGO).
    
    Args:
        func: Function to capture locals from
        capture_locals: Whether to capture locals (True, False, or list of var names)
        capture_self: Whether to capture 'self' variable
    
    Returns:
        Tuple of (tracer, locals_before, locals_after)
    """
    locals_before = {}
    locals_after = {}

    if not capture_locals:
        return None, locals_before, locals_after

    target_code = func.__code__
    target_name = func.__name__
    target_module = func.__module__

    entered = False

    def tracer(frame, event, arg):
        nonlocal entered

        if frame.f_code is target_code and frame.f_globals.get("__name__") == target_module:
            try:
                if not entered:
                    entered = True
                    f_locals = frame.f_locals
                    
                    # Filter specific variables if capture_locals is a list
                    if isinstance(capture_locals, list):
                        f_locals = {k: v for k, v in f_locals.items() if k in capture_locals}

                    if not capture_self and "self" in f_locals:
                        f_locals = {k: v for k, v in f_locals.items() if k != "self"}
                    locals_before.update(safe_locals(f_locals))

                if event == "return":
                    f_locals = frame.f_locals
                    
                    # Filter specific variables if capture_locals is a list
                    if isinstance(capture_locals, list):
                        f_locals = {k: v for k, v in f_locals.items() if k in capture_locals}
                    
                    if not capture_self and "self" in f_locals:
                        f_locals = {k: v for k, v in f_locals.items() if k != "self"}
                    locals_after.update(safe_locals(f_locals))
                    locals_after["_return"] = serialize_value(arg)
            except Exception as e:
                print(f"[LLMOps-Observability] TRACER ERROR: {e}")
                traceback.print_exc()

        return tracer

    return tracer, locals_before, locals_after


# ============================================================
# Decorator: track_function (Enhanced with veriskGO features)
# ============================================================

def track_function(
    name: Optional[str] = None,
    *,
    tags: Optional[Dict[str, Any]] = None,
    capture_locals: Union[bool, List[str]] = False,
    capture_self: bool = False,
):
    """
    Decorator to track function execution with Langfuse (enhanced version from veriskGO).
    
    Features:
    - Captures input arguments and output
    - Optionally captures local variables before/after execution
    - Manages span stack for proper nesting
    - Sends directly to Langfuse (no batching)
    
    Usage:
        @track_function()
        def process_data(input_data):
            # Your code here
            return result
            
        @track_function(name="custom_name", tags={"version": "1.0"}, capture_locals=True)
        def detailed_function(x, y):
            result = x + y
            return result
            
        @track_function(capture_locals=["important_var"])
        async def async_function():
            important_var = "tracked"
            return result
    
    Args:
        name: Optional custom name for the span
        tags: Optional metadata tags
        capture_locals: Capture local variables (True/False or list of var names)
        capture_self: Whether to capture 'self' variable (default False)
    """
    def decorator(func):
        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)
        
        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    return await func(*args, **kwargs)

                # Get parent span ID from stack
                with TraceManager._lock:
                    parent_span_id = (
                        TraceManager._active["stack"][-1]["span_id"]
                        if TraceManager._active["stack"]
                        else None
                    )
                    trace_id = TraceManager._active["trace_id"]
                
                span_id = TraceManager._id()
                start_time = time.time()
                start_timestamp = TraceManager._now()

                # Push current span onto stack BEFORE executing function
                with TraceManager._lock:
                    TraceManager._active["stack"].append({"span_id": span_id, "name": span_name})

                # Setup local variable capture
                tracer, locals_before, locals_after = capture_function_locals(
                    func, capture_locals=capture_locals, capture_self=capture_self
                )
                if tracer:
                    sys.settrace(tracer)

                error = None
                result = None
                
                try:
                    result = await func(*args, **kwargs)
                except Exception as e:
                    error = e
                finally:
                    if tracer:
                        sys.settrace(None)
                    
                    # Pop from stack
                    with TraceManager._lock:
                        if TraceManager._active["stack"] and TraceManager._active["stack"][-1]["span_id"] == span_id:
                            TraceManager._active["stack"].pop()
                    
                    duration_ms = int((time.time() - start_time) * 1000)
                    
                    # Build input/output
                    input_data = {
                        "args": serialize_value(args),
                        "kwargs": serialize_value(kwargs),
                    }
                    
                    if error:
                        output_data = {
                            "status": "error",
                            "error": str(error),
                            "stacktrace": traceback.format_exc(),
                            "locals_before": locals_before,
                            "locals_after": locals_after,
                        }
                    else:
                        output_data = {
                            "status": "success",
                            "latency_ms": duration_ms,
                            "locals_before": locals_before,
                            "locals_after": locals_after,
                            "output": serialize_value(result),
                        }
                    
                    # Send span to Langfuse immediately
                    TraceManager.send_span_to_langfuse(
                        span_id=span_id,
                        parent_span_id=parent_span_id,
                        span_name=span_name,
                        span_type="span",
                        start_time=start_time,
                        duration_ms=duration_ms,
                        input_data=input_data,
                        output_data=output_data,
                        metadata=tags or {},
                        error=error,
                    )
                    
                    if error:
                        raise error
                
                return result
            
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                if not TraceManager.has_active_trace():
                    return func(*args, **kwargs)

                # Get parent span ID from stack
                with TraceManager._lock:
                    parent_span_id = (
                        TraceManager._active["stack"][-1]["span_id"]
                        if TraceManager._active["stack"]
                        else None
                    )
                    trace_id = TraceManager._active["trace_id"]
                
                span_id = TraceManager._id()
                start_time = time.time()
                start_timestamp = TraceManager._now()

                # Push current span onto stack BEFORE executing function
                with TraceManager._lock:
                    TraceManager._active["stack"].append({"span_id": span_id, "name": span_name})

                # Setup local variable capture
                tracer, locals_before, locals_after = capture_function_locals(
                    func, capture_locals=capture_locals, capture_self=capture_self
                )
                if tracer:
                    sys.settrace(tracer)

                error = None
                result = None
                
                try:
                    result = func(*args, **kwargs)
                except Exception as e:
                    error = e
                finally:
                    if tracer:
                        sys.settrace(None)
                    
                    # Pop from stack
                    with TraceManager._lock:
                        if TraceManager._active["stack"] and TraceManager._active["stack"][-1]["span_id"] == span_id:
                            TraceManager._active["stack"].pop()
                    
                    duration_ms = int((time.time() - start_time) * 1000)
                    
                    # Build input/output
                    input_data = {
                        "args": serialize_value(args),
                        "kwargs": serialize_value(kwargs),
                    }
                    
                    if error:
                        output_data = {
                            "status": "error",
                            "error": str(error),
                            "stacktrace": traceback.format_exc(),
                            "locals_before": locals_before,
                            "locals_after": locals_after,
                        }
                    else:
                        output_data = {
                            "status": "success",
                            "latency_ms": duration_ms,
                            "locals_before": locals_before,
                            "locals_after": locals_after,
                            "output": serialize_value(result),
                        }
                    
                    # Send span to Langfuse immediately
                    TraceManager.send_span_to_langfuse(
                        span_id=span_id,
                        parent_span_id=parent_span_id,
                        span_name=span_name,
                        span_type="span",
                        start_time=start_time,
                        duration_ms=duration_ms,
                        input_data=input_data,
                        output_data=output_data,
                        metadata=tags or {},
                        error=error,
                    )
                    
                    if error:
                        raise error
                
                return result
            
            return sync_wrapper
    
    return decorator

