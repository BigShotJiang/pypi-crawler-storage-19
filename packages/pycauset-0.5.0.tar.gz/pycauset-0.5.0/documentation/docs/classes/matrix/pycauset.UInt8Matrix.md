# pycauset.UInt8Matrix

A memory-mapped dense matrix storing 8-bit unsigned integers. Inherits from [MatrixBase](pycauset.MatrixBase.md).

## Constructor

```python
pycauset.UInt8Matrix(n: int)
pycauset.UInt8Matrix(rows: int, cols: int)
pycauset.UInt8Matrix(array: numpy.ndarray)
```

When constructed from a NumPy array, the array must be rank-2 with dtype `uint8`.

## Properties

### `shape`
Returns a tuple `(rows, cols)` representing the dimensions of the matrix.

## Methods

Inherits the common matrix interface from [[pycauset.MatrixBase]].
