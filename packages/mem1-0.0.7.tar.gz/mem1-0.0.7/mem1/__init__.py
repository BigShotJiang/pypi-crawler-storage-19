"""
Mem1 - 基于 Elasticsearch 的用户记忆系统
"""
import logging

__version__ = "0.0.5"

# 屏蔽第三方库的详细日志（必须在导入前设置）
logging.getLogger("elastic_transport").setLevel(logging.WARNING)
logging.getLogger("elastic_transport.transport").setLevel(logging.WARNING)
logging.getLogger("httpx").setLevel(logging.WARNING)

from mem1.memory_es import Mem1Memory
from mem1.config import Mem1Config, LLMConfig

__all__ = ["Mem1Memory", "Mem1Config", "LLMConfig"]
