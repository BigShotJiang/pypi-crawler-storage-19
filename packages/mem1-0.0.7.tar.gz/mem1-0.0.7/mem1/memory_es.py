"""基于 Elasticsearch 的记忆管理系统"""
import re
import shutil
import base64
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from pathlib import Path
from elasticsearch import Elasticsearch
from mem1.config import Mem1Config
from mem1.llm import LLMClient, VLClient
from mem1.prompts import ProfileTemplate, RECALL_DECISION_PROMPT, IMAGE_SEARCH_PROMPT, ASSISTANT_SUMMARY_PROMPT, CONTEXT_SUFFICIENT_PROMPT

logger = logging.getLogger(__name__)

# 用户状态索引名
USER_STATE_INDEX = "mem1_user_state"
# 用户画像索引名
USER_PROFILE_INDEX = "mem1_user_profile"


class Mem1Memory:
    """基于 Elasticsearch 的用户记忆系统
    
    数据存储（全部在 ES）：
    - ES 索引 {index_name}: 历史对话记录 + 图片索引（按 user_id + topic_id 隔离）
    - ES 索引 mem1_user_state: 用户更新状态（轮数、上次更新时间）
    - ES 索引 mem1_user_profile: 用户画像（按 user_id 共享，跨话题）
    - 本地文件: 图片文件存储
    """
    
    def __init__(
        self,
        config: Mem1Config,
        user_id: str,
        topic_id: str = "default",
        memory_dir: Optional[str] = None,
        profile_template: Optional[ProfileTemplate] = None
    ):
        """初始化 ES 记忆系统
        
        Args:
            config: 配置对象
            user_id: 用户ID（必填）
            topic_id: 话题ID（默认 "default"），同一用户可有多个话题
            memory_dir: 记忆文件存储目录
            profile_template: 用户画像模板
        """
        self.config = config
        self.user_id = user_id
        self.topic_id = topic_id
        self.memory_dir = Path(memory_dir or config.memory.memory_dir)
        self.memory_dir.mkdir(parents=True, exist_ok=True)
        
        # 图片存储目录（独立配置）
        self.images_dir = Path(config.images.images_dir)
        self.images_dir.mkdir(parents=True, exist_ok=True)
        
        # ES 连接（从配置读取）
        self.es = Elasticsearch(config.es.hosts)
        self.index_name = config.es.index_name
        
        # LLM 客户端
        self.llm = LLMClient(config.llm)
        
        # VL 客户端（可选）
        self.vl = VLClient(config.vl) if config.vl.enabled else None
        
        # 业务场景模板
        self.profile_template = profile_template or ProfileTemplate()
        
        # 配置参数
        self.max_profile_chars = config.memory.max_profile_chars
        self.auto_update_profile = config.memory.auto_update_profile
        self.update_interval_rounds = config.memory.update_interval_rounds
        self.update_interval_minutes = config.memory.update_interval_minutes
        self.save_assistant_messages = config.memory.save_assistant_messages
        self.max_assistant_chars = config.memory.max_assistant_chars
        
        # 确保索引存在
        self._ensure_state_index()
    
    def _get_user_images_dir(self, user_id: str) -> Path:
        """获取用户图片目录"""
        images_dir = self.images_dir / user_id
        images_dir.mkdir(parents=True, exist_ok=True)
        return images_dir
    
    def _load_images_index(self, user_id: str) -> List[Dict[str, str]]:
        """从对话记录中提取用户所有图片"""
        try:
            response = self.es.search(
                index=self.index_name,
                query={
                    "bool": {
                        "must": [
                            {"term": {"user_id": user_id}},
                            {"exists": {"field": "images"}}
                        ]
                    }
                },
                size=1000,
                sort=[{"timestamp": {"order": "asc"}}]
            )
            
            images = []
            for hit in response["hits"]["hits"]:
                conv_images = hit["_source"].get("images", [])
                images.extend(conv_images)
            return images
        except Exception:
            return []
    
    def _save_image_to_conversation(self, conversation_entry: Dict, image_doc: Dict[str, str]) -> None:
        """将图片信息添加到对话记录"""
        if "images" not in conversation_entry:
            conversation_entry["images"] = []
        conversation_entry["images"].append(image_doc)
    
    def _get_profile(self, user_id: str) -> Optional[str]:
        """从 ES 获取用户画像"""
        try:
            response = self.es.get(index=USER_PROFILE_INDEX, id=user_id)
            return response["_source"]["content"]
        except Exception:
            return None
    
    def _save_profile(self, user_id: str, content: str) -> None:
        """保存用户画像到 ES"""
        self.es.index(
            index=USER_PROFILE_INDEX,
            id=user_id,
            document={
                "user_id": user_id,
                "content": content,
                "updated_at": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            },
            refresh=True
        )
    
    def _init_profile(self, user_id: str) -> str:
        """初始化用户画像（从 ES 读取，不存在则创建）"""
        content = self._get_profile(user_id)
        if content is None:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
            content = self.profile_template.render(user_id, timestamp)
            self._save_profile(user_id, content)
            logger.info(f"✓ 创建用户画像: {user_id}")
        return content
    
    def _ensure_state_index(self) -> None:
        """确保所有索引存在"""
        # 确保对话记录索引存在
        if not self.es.indices.exists(index=self.index_name):
            self.es.indices.create(
                index=self.index_name,
                body={
                    "mappings": {
                        "properties": {
                            "user_id": {"type": "keyword"},
                            "topic_id": {"type": "keyword"},
                            "timestamp": {"type": "date", "format": "yyyy-MM-dd HH:mm:ss||epoch_millis"},
                            "messages": {"type": "nested"},
                            "metadata": {"type": "object"}
                        }
                    }
                }
            )
            logger.info(f"✓ 创建对话记录索引: {self.index_name}")
        
        # 确保用户状态索引存在
        if not self.es.indices.exists(index=USER_STATE_INDEX):
            self.es.indices.create(
                index=USER_STATE_INDEX,
                body={
                    "mappings": {
                        "properties": {
                            "user_id": {"type": "keyword"},
                            "rounds": {"type": "integer"},
                            "last_update": {"type": "date", "format": "yyyy-MM-dd HH:mm:ss||epoch_millis"}
                        }
                    }
                }
            )
            logger.info(f"✓ 创建用户状态索引: {USER_STATE_INDEX}")
        
        # 确保画像索引存在
        if not self.es.indices.exists(index=USER_PROFILE_INDEX):
            self.es.indices.create(
                index=USER_PROFILE_INDEX,
                body={
                    "mappings": {
                        "properties": {
                            "user_id": {"type": "keyword"},
                            "content": {"type": "text"},
                            "updated_at": {"type": "date", "format": "yyyy-MM-dd HH:mm:ss||epoch_millis"}
                        }
                    }
                }
            )
            logger.info(f"✓ 创建用户画像索引: {USER_PROFILE_INDEX}")
    
    def _get_user_state(self, user_id: str) -> Dict[str, Any]:
        """从 ES 获取用户更新状态"""
        try:
            response = self.es.get(index=USER_STATE_INDEX, id=user_id)
            return response["_source"]
        except Exception:
            # 用户状态不存在，返回初始状态
            return {"user_id": user_id, "rounds": 0, "last_update": None}
    
    def _update_user_state(self, user_id: str, rounds: int, last_update: Optional[str] = None) -> None:
        """更新 ES 中的用户状态"""
        doc = {"user_id": user_id, "rounds": rounds}
        if last_update:
            doc["last_update"] = last_update
        
        self.es.index(
            index=USER_STATE_INDEX,
            id=user_id,
            document=doc,
            refresh=True
        )
    
    def _should_trigger_update(self, user_id: str) -> bool:
        """
        判断是否应该触发画像更新（基于 ES 存储的状态）
        
        触发条件（满足任一即触发）：
        1. 累积对话轮数 >= update_interval_rounds
        2. 距上次更新时间 >= update_interval_minutes
        3. 首次（无 last_update）
        """
        state = self._get_user_state(user_id)
        rounds = state.get("rounds", 0) + 1
        last_update_str = state.get("last_update")
        
        should_update = False
        reason = ""
        
        # 条件1：累积轮数达到阈值
        if rounds >= self.update_interval_rounds:
            should_update = True
            reason = f"轮数={rounds} >= {self.update_interval_rounds}"
        
        # 条件2：距上次更新超过时间阈值
        if not should_update and last_update_str:
            try:
                last_update = datetime.strptime(last_update_str, '%Y-%m-%d %H:%M:%S')
                elapsed = (datetime.now() - last_update).total_seconds() / 60
                if elapsed >= self.update_interval_minutes:
                    should_update = True
                    reason = f"时间={elapsed:.1f}分钟 >= {self.update_interval_minutes}"
            except ValueError:
                pass
        
        # 条件3：首次更新
        if not should_update and last_update_str is None:
            should_update = True
            reason = "首次创建画像"
        
        if should_update:
            logger.info(f"📊 触发画像更新（{reason}）: {user_id}")
            # 重置轮数
            self._update_user_state(user_id, 0, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        else:
            # 增加轮数
            self._update_user_state(user_id, rounds, last_update_str)
            logger.debug(f"📊 暂不更新（轮数={rounds}/{self.update_interval_rounds}）: {user_id}")
        
        return should_update
    
    def add_conversation(
        self,
        messages: List[Dict[str, str]],
        images: Optional[List[Dict[str, Any]]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        timestamp: Optional[str] = None
    ) -> Dict[str, Any]:
        """添加对话到 ES（使用实例绑定的 user_id 和 topic_id）"""
        ts = timestamp or datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        user_id = self.user_id
        topic_id = self.topic_id
        
        # 构建对话记录
        conversation_entry = {
            "user_id": user_id,
            "topic_id": topic_id,
            "timestamp": ts,
            "messages": [],
            "metadata": metadata or {}
        }
        
        # 处理图片
        image_refs = []
        if images:
            user_images_dir = self._get_user_images_dir(user_id)
            timestamp_str = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            for img in images:
                filename = f"{timestamp_str}_{img['filename']}"
                img_path = user_images_dir / filename
                
                if 'data' in img:
                    img_data = base64.b64decode(img['data'])
                    img_path.write_bytes(img_data)
                elif 'path' in img:
                    shutil.copy(img['path'], img_path)
                
                image_refs.append(filename)
                
                # 生成图片描述（用户描述 + VL 理解）
                user_desc = ""
                for msg in messages:
                    if msg["role"] == "user":
                        user_desc = msg["content"]
                        break
                
                # 如果启用了 VL 模型，调用视觉理解
                if self.vl:
                    try:
                        vl_result = self.vl.understand_image(str(img_path), user_desc)
                        if user_desc:
                            description = f"【用户描述】{user_desc}\n\n{vl_result}"
                        else:
                            description = vl_result
                        logger.info(f"🖼️ VL 图片理解完成: {filename}")
                    except Exception as e:
                        logger.warning(f"⚠️ VL 图片理解失败: {e}, 使用用户描述")
                        description = user_desc or img['filename']
                else:
                    description = user_desc or img['filename']
                
                # 图片信息存入对话记录
                self._save_image_to_conversation(conversation_entry, {
                    "filename": filename,
                    "description": description,
                    "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    "original_name": img['filename']
                })
        
        # 处理消息
        first_user_msg = True
        for msg in messages:
            if msg["role"] == "user":
                msg_obj = {"role": "user", "content": msg["content"]}
                if first_user_msg and image_refs:
                    msg_obj["image_refs"] = image_refs
                    first_user_msg = False
                conversation_entry["messages"].append(msg_obj)
            elif self.save_assistant_messages and msg["role"] == "assistant":
                content = msg["content"]
                if len(content) > self.max_assistant_chars:
                    content = self._summarize_assistant_response(content)
                conversation_entry["messages"].append({
                    "role": "assistant",
                    "content": content
                })
        
        # 写入 ES（refresh=True 确保立即可搜索）
        response = self.es.index(
            index=self.index_name,
            document=conversation_entry,
            refresh=True
        )
        
        logger.info(f"✓ 对话已存入 ES: user={user_id}, topic={topic_id}, timestamp={ts}, id={response['_id']}")
        
        # 自动更新画像（基于 ES 状态判断）
        if self.auto_update_profile and self._should_trigger_update(user_id):
            try:
                self.update_profile()
            except Exception as e:
                logger.error(f"❌ 画像更新失败: {user_id}, error={e}")
        
        return {"status": "success", "es_id": response['_id']}
    
    def get_conversations(
        self,
        days_limit: Optional[int] = None,
        metadata_filter: Optional[Dict[str, Any]] = None,
        size: int = 1000
    ) -> List[Dict[str, Any]]:
        """从 ES 获取当前话题的对话记录"""
        user_id = self.user_id
        topic_id = self.topic_id
        
        query = {
            "bool": {
                "must": [
                    {"term": {"user_id": user_id}},
                    {"term": {"topic_id": topic_id}}
                ]
            }
        }
        
        # 时间过滤
        if days_limit:
            cutoff_date = (datetime.now() - timedelta(days=days_limit)).strftime('%Y-%m-%d %H:%M:%S')
            query["bool"]["must"].append({
                "range": {
                    "timestamp": {"gte": cutoff_date}
                }
            })
        
        # 元数据过滤
        if metadata_filter:
            for k, v in metadata_filter.items():
                query["bool"]["must"].append({
                    "term": {f"metadata.{k}": v}
                })
        
        # 查询 ES
        response = self.es.search(
            index=self.index_name,
            query=query,
            size=size,
            sort=[{"timestamp": {"order": "asc"}}]
        )
        
        conversations = [hit["_source"] for hit in response["hits"]["hits"]]
        logger.info(f"📖 从 ES 读取对话: user={user_id}, topic={topic_id}, count={len(conversations)}")
        
        return conversations
    
    def get_all_conversations(
        self,
        days_limit: Optional[int] = None,
        size: int = 1000
    ) -> List[Dict[str, Any]]:
        """从 ES 获取用户所有话题的对话记录（用于更新画像）"""
        user_id = self.user_id
        
        query = {
            "bool": {
                "must": [
                    {"term": {"user_id": user_id}}
                ]
            }
        }
        
        if days_limit:
            cutoff_date = (datetime.now() - timedelta(days=days_limit)).strftime('%Y-%m-%d %H:%M:%S')
            query["bool"]["must"].append({
                "range": {
                    "timestamp": {"gte": cutoff_date}
                }
            })
        
        response = self.es.search(
            index=self.index_name,
            query=query,
            size=size,
            sort=[{"timestamp": {"order": "asc"}}]
        )
        
        conversations = [hit["_source"] for hit in response["hits"]["hits"]]
        logger.info(f"📖 从 ES 读取所有对话: user={user_id}, count={len(conversations)}")
        
        return conversations
    
    def update_profile(self) -> Dict[str, Any]:
        """更新用户画像（基于所有话题的对话）"""
        user_id = self.user_id
        self._init_profile(user_id)
        
        # 从 ES 读取所有话题的对话
        conversations = self.get_all_conversations()
        if not conversations:
            return {"status": "success", "updated": False, "reason": "no_conversation"}
        
        history_content = self._format_conversations_for_llm(conversations)
        
        # 从 ES 读取现有画像
        profile_content = self._get_profile(user_id)
        
        # LLM 更新画像
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
        prompt = self.profile_template.get_update_prompt().format(
            user_id=user_id,
            normal_content=history_content,
            import_content=profile_content,
            timestamp=timestamp
        )
        
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": "请整理用户画像"}
        ]
        
        response = self.llm.generate(messages, response_format="text")
        
        # 检查是否需要压缩
        if len(response) > self.max_profile_chars:
            logger.info(f"📦 用户画像超长({len(response)}>{self.max_profile_chars})，触发压缩...")
            response = self._compress_profile(user_id, response)
            logger.info(f"📦 压缩后长度: {len(response)}")
        
        # 保存到 ES
        self._save_profile(user_id, response)
        logger.info(f"✓ 画像已更新到 ES: {user_id}")
        
        return {"status": "success", "updated": True, "length": len(response)}
    
    def get_context(
        self,
        query: str = "",
        days_limit: Optional[int] = None
    ) -> Dict[str, Any]:
        """获取记忆上下文（当前话题）
        
        Args:
            query: 用户问题（保留参数，暂未使用）
            days_limit: 检索最近几天的对话，默认使用配置值
        """
        user_id = self.user_id
        profile_content = self._init_profile(user_id)
        
        now = datetime.now()
        weekdays = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
        current_time = f"{now.strftime('%Y-%m-%d %H:%M')} {weekdays[now.weekday()]}"
        
        # 从 ES 获取画像更新时间
        profile_last_updated = "未更新"
        try:
            response = self.es.get(index=USER_PROFILE_INDEX, id=user_id)
            profile_last_updated = response["_source"].get("updated_at", "未更新")
        except Exception:
            pass
        
        # 强制检索最近 days_limit 天的对话
        if days_limit is None:
            days_limit = self.config.memory.context_days_limit
        conversations = self.get_conversations(days_limit=days_limit)
        normal_content = self._format_conversations_for_llm(conversations) if conversations else ""
        
        return {
            "current_time": current_time,
            "user_id": user_id,
            "topic_id": self.topic_id,
            "import_content": profile_content,
            "normal_content": normal_content,
            "conversations_count": len(conversations),
            "profile_last_updated": profile_last_updated
        }
    
    def get_context_progressive(
        self,
        query: str,
        max_days: int = 31,
        step: int = 7
    ) -> Dict[str, Any]:
        """渐进式检索：每次多查一周，直到 LLM 认为信息足够
        
        Args:
            query: 用户问题
            max_days: 最大检索天数，默认31天
            step: 每步增加的天数，默认7天
        """
        user_id = self.user_id
        profile_content = self._init_profile(user_id)
        
        now = datetime.now()
        weekdays = ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"]
        current_time = f"{now.strftime('%Y-%m-%d %H:%M')} {weekdays[now.weekday()]}"
        
        # 从 ES 获取画像更新时间
        profile_last_updated = "未更新"
        try:
            response = self.es.get(index=USER_PROFILE_INDEX, id=user_id)
            profile_last_updated = response["_source"].get("updated_at", "未更新")
        except Exception:
            pass
        
        # 渐进式检索
        all_conversations = []
        searched_days = 0
        
        for end_day in range(step, max_days + step, step):
            end_day = min(end_day, max_days)
            
            # 检索这个时间段的对话
            new_conversations = self._get_conversations_range(searched_days, end_day)
            all_conversations.extend(new_conversations)
            searched_days = end_day
            
            if not all_conversations:
                logger.info(f"📖 渐进检索: 0-{end_day}天 无对话，继续...")
                continue
            
            # LLM 判断信息是否足够
            normal_content = self._format_conversations_for_llm(all_conversations)
            if self._is_context_sufficient(query, profile_content, normal_content, end_day):
                logger.info(f"✓ 渐进检索完成: 0-{end_day}天，{len(all_conversations)}条对话")
                break
            
            logger.info(f"📖 渐进检索: 0-{end_day}天 信息不足，继续...")
        
        normal_content = self._format_conversations_for_llm(all_conversations) if all_conversations else ""
        
        return {
            "current_time": current_time,
            "user_id": user_id,
            "topic_id": self.topic_id,
            "import_content": profile_content,
            "normal_content": normal_content,
            "conversations_count": len(all_conversations),
            "profile_last_updated": profile_last_updated,
            "searched_days": searched_days
        }
    
    def _get_conversations_range(
        self,
        start_days_ago: int,
        end_days_ago: int
    ) -> List[Dict[str, Any]]:
        """获取指定天数范围内的对话（start_days_ago 到 end_days_ago 天前）"""
        user_id = self.user_id
        topic_id = self.topic_id
        
        now = datetime.now()
        start_date = (now - timedelta(days=end_days_ago)).strftime('%Y-%m-%d %H:%M:%S')
        end_date = (now - timedelta(days=start_days_ago)).strftime('%Y-%m-%d %H:%M:%S')
        
        query = {
            "bool": {
                "must": [
                    {"term": {"user_id": user_id}},
                    {"term": {"topic_id": topic_id}},
                    {"range": {"timestamp": {"gte": start_date, "lt": end_date}}}
                ]
            }
        }
        
        response = self.es.search(
            index=self.index_name,
            query=query,
            size=1000,
            sort=[{"timestamp": {"order": "asc"}}]
        )
        
        return [hit["_source"] for hit in response["hits"]["hits"]]
    
    def _is_context_sufficient(
        self,
        query: str,
        profile: str,
        conversations: str,
        days: int
    ) -> bool:
        """LLM 判断当前上下文是否足够回答问题"""
        prompt = CONTEXT_SUFFICIENT_PROMPT.format(
            query=query,
            profile=profile,
            conversations=conversations or "（无对话记录）",
            days=days
        )
        
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": query}
        ]
        
        response = self.llm.generate(messages, response_format="text")
        is_sufficient = "true" in response.strip().lower()
        
        return is_sufficient
    
    def search_conversations(
        self,
        start_days: int,
        end_days: int
    ) -> List[Dict[str, Any]]:
        """按时间范围检索对话（供外部 LLM 作为 tool 调用）
        
        Args:
            start_days: 起始天数（距今多少天，较近）
            end_days: 结束天数（距今多少天，较远）
        
        Returns:
            对话记录列表
        
        示例:
            search_conversations(0, 7)    # 最近7天
            search_conversations(170, 180) # 约半年前的10天
        """
        return self._get_conversations_range(start_days, end_days)
    
    def _compress_profile(self, user_id: str, profile_content: str) -> str:
        """压缩用户画像"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M')
        prompt = self.profile_template.get_compress_prompt().format(
            user_id=user_id,
            profile_content=profile_content,
            max_chars=self.max_profile_chars,
            timestamp=timestamp
        )
        
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": "请压缩用户画像"}
        ]
        
        response = self.llm.generate(messages, response_format="text")
        return response
    
    def _should_include_history(self, query: str) -> tuple[bool, str]:
        """LLM 判断是否需要加载历史记录"""
        prompt = RECALL_DECISION_PROMPT.format(query=query)
        
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": query}
        ]
        
        response = self.llm.generate(messages, response_format="text")
        response_lower = response.strip().lower()
        need_history = "true" in response_lower or "是" in response_lower or "需要" in response_lower
        
        logger.info(f"🔍 回忆判断: query='{query[:50]}...', need_history={need_history}")
        
        return need_history, response.strip()
    
    def _summarize_assistant_response(self, content: str) -> str:
        """对超长的助手回复生成摘要"""
        prompt = ASSISTANT_SUMMARY_PROMPT.format(
            content=content,
            max_chars=self.max_assistant_chars
        )
        
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": "请生成摘要"}
        ]
        
        summary = self.llm.generate(messages, response_format="text")
        logger.info(f"📝 助手回复摘要: {len(content)} -> {len(summary)} 字符")
        
        return summary
    
    def search_images(self, query: str) -> List[Dict[str, str]]:
        """搜索用户图片"""
        user_id = self.user_id
        images_index = self._load_images_index(user_id)
        if not images_index:
            return []
        
        images_desc = "\n".join([
            f"[{i}] 文件名: {img['original_name']}, 时间: {img['timestamp']}, 描述: {img['description']}"
            for i, img in enumerate(images_index)
        ])
        
        prompt = IMAGE_SEARCH_PROMPT.format(query=query, images_desc=images_desc)
        
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": query}
        ]
        
        response = self.llm.generate(messages, response_format="text")
        
        results = []
        # 提取所有数字（支持多种格式：纯数字、[0]、0. 等）
        import re
        numbers = re.findall(r'\b(\d+)\b', response)
        for num_str in numbers:
            idx = int(num_str)
            if 0 <= idx < len(images_index):
                img = images_index[idx].copy()
                img['abs_path'] = str((self._get_user_images_dir(user_id) / img['filename']).resolve())
                if img not in results:  # 去重
                    results.append(img)
        
        logger.info(f"🖼️ 图片搜索: query='{query}', 找到 {len(results)} 张")
        return results
    
    def _format_conversations_for_llm(self, conversations: List[Dict[str, Any]]) -> str:
        """格式化对话记录为文本"""
        output = []
        for conv in conversations:
            timestamp = conv.get("timestamp", "未知时间")
            metadata = conv.get("metadata", {})
            
            title = f"### {timestamp}"
            if metadata:
                tags = " ".join([f"[{k}:{v}]" for k, v in metadata.items()])
                title += f" {tags}"
            
            output.append(title)
            output.append("")
            
            for msg in conv.get("messages", []):
                role_icon = "👤" if msg["role"] == "user" else "🤖"
                role_name = "用户" if msg["role"] == "user" else "助手"
                output.append(f"**{role_icon} {role_name}**: {msg['content']}")
                if msg.get("images"):
                    for img_path in msg["images"]:
                        output.append(f"![Image]({img_path})")
                output.append("")
            
            output.append("---")
            output.append("")
        
        return "\n".join(output)
    
    def get_user_list(self) -> List[str]:
        """获取所有用户ID列表（从 ES）"""
        response = self.es.search(
            index=self.index_name,
            body={
                "size": 0,
                "aggs": {
                    "users": {
                        "terms": {"field": "user_id", "size": 10000}
                    }
                }
            }
        )
        
        users = [bucket["key"] for bucket in response["aggregations"]["users"]["buckets"]]
        return users
    
    def delete_user(self) -> Dict[str, Any]:
        """删除用户所有记忆（所有话题）"""
        user_id = self.user_id
        
        # 删除 ES 中的对话记录
        try:
            self.es.delete_by_query(
                index=self.index_name,
                query={"term": {"user_id": user_id}},
                refresh=True
            )
        except Exception:
            pass  # 索引可能不存在
        
        # 删除 ES 中的用户状态
        try:
            self.es.delete(index=USER_STATE_INDEX, id=user_id, refresh=True)
        except Exception:
            pass  # 状态可能不存在
        
        # 删除 ES 中的用户画像
        try:
            self.es.delete(index=USER_PROFILE_INDEX, id=user_id, refresh=True)
        except Exception:
            pass  # 画像可能不存在
        
        # 删除本地图片文件
        user_images_dir = self.images_dir / user_id
        if user_images_dir.exists():
            shutil.rmtree(user_images_dir)
        
        logger.info(f"✓ 已删除用户所有数据: {user_id}")
        return {"status": "success", "deleted": user_id}
    
    def delete_topic(self) -> Dict[str, Any]:
        """删除当前话题的对话记录（保留用户画像）"""
        user_id = self.user_id
        topic_id = self.topic_id
        
        try:
            self.es.delete_by_query(
                index=self.index_name,
                query={
                    "bool": {
                        "must": [
                            {"term": {"user_id": user_id}},
                            {"term": {"topic_id": topic_id}}
                        ]
                    }
                },
                refresh=True
            )
        except Exception:
            pass  # 索引可能不存在
        
        logger.info(f"✓ 已删除话题: user={user_id}, topic={topic_id}")
        return {"status": "success", "deleted_topic": topic_id}
    
    def list_topics(self) -> List[Dict[str, Any]]:
        """列出用户的所有话题"""
        user_id = self.user_id
        
        response = self.es.search(
            index=self.index_name,
            body={
                "size": 0,
                "query": {"term": {"user_id": user_id}},
                "aggs": {
                    "topics": {
                        "terms": {"field": "topic_id", "size": 1000},
                        "aggs": {
                            "latest": {"max": {"field": "timestamp"}},
                            "count": {"value_count": {"field": "timestamp"}}
                        }
                    }
                }
            }
        )
        
        topics = []
        for bucket in response["aggregations"]["topics"]["buckets"]:
            topics.append({
                "topic_id": bucket["key"],
                "conversation_count": bucket["doc_count"],
                "last_active": bucket["latest"]["value_as_string"] if bucket["latest"]["value"] else None
            })
        
        return topics
