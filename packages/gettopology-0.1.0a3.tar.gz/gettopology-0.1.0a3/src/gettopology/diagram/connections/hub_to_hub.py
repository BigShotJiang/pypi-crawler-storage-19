"""Hub-to-hub connection logic for diagram generation."""

from xml.etree.ElementTree import Element, SubElement

from gettopology.diagram.config import get_config
from gettopology.diagram.connections.base import (
    ROUTING_WAYPOINT_OFFSET_CLOSE,
    VNET_WIDTH,
)
from gettopology.diagram.elements.edge_elements import create_waypoint

# Get global config instance
_config = get_config()


def create_hub_to_hub_connection(
    root: Element,
    mxGeometry: Element,
    source_x: float,
    target_x: float,
    source_y: float,
    target_y: float,
    source_height: float,
    target_height: float,
) -> None:
    """Create hub-to-hub connection with straight horizontal line.

    Args:
        root: Root XML element (not used, but kept for consistency)
        mxGeometry: Geometry element to add waypoints to
        source_x: Source hub X position (left edge)
        target_x: Target hub X position (left edge)
        source_y: Source hub center Y position
        target_y: Target hub center Y position
        source_height: Source hub height
        target_height: Target hub height
    """
    # Hub-to-Hub: Connect from side middle to side middle with straight horizontal line
    # For hub-to-hub, source_y and target_y are center Y positions (passed from connection code)
    # Calculate actual top Y positions for geometry calculations
    source_y - (source_height / 2)  # Convert center Y to top Y
    target_y - (target_height / 2)  # Convert center Y to top Y
    # Use center Y positions for waypoints (these should be the same for all hubs)
    source_center_y = source_y  # Already center Y
    target_center_y = target_y  # Already center Y

    if target_x > source_x:
        # Target is to the right: source connects from right side, target connects to left side
        mxGeometry.set("exitX", "1.0")  # Right side of source
        mxGeometry.set("exitY", "0.5")  # Middle of right side
        mxGeometry.set("entryX", "0.0")  # Left side of target
        mxGeometry.set("entryY", "0.5")  # Middle of left side
    else:
        # Target is to the left: source connects from left side, target connects to right side
        mxGeometry.set("exitX", "0.0")  # Left side of source
        mxGeometry.set("exitY", "0.5")  # Middle of left side
        mxGeometry.set("entryX", "1.0")  # Right side of target
        mxGeometry.set("entryY", "0.5")  # Middle of right side

    mxGeometry.set("exitDx", "0")
    mxGeometry.set("exitDy", "0")
    mxGeometry.set("exitPerimeter", "1")  # Connect to perimeter edge
    mxGeometry.set("entryDx", "0")
    mxGeometry.set("entryDy", "0")
    mxGeometry.set("entryPerimeter", "1")  # Connect to perimeter edge

    # Add waypoints at the same Y level to ensure straight horizontal line
    array_elem = SubElement(mxGeometry, "Array")
    array_elem.set("as", "points")

    # Waypoint at source side (just outside)
    if target_x > source_x:
        waypoint1_x = source_x + VNET_WIDTH + ROUTING_WAYPOINT_OFFSET_CLOSE  # Just outside right edge
    else:
        waypoint1_x = source_x - ROUTING_WAYPOINT_OFFSET_CLOSE  # Just outside left edge
    create_waypoint(array_elem, waypoint1_x, source_center_y)

    # Waypoint at target side (just outside)
    if target_x > source_x:
        waypoint2_x = target_x - ROUTING_WAYPOINT_OFFSET_CLOSE  # Just outside left edge
    else:
        waypoint2_x = target_x + VNET_WIDTH + ROUTING_WAYPOINT_OFFSET_CLOSE  # Just outside right edge
    create_waypoint(array_elem, waypoint2_x, target_center_y)

