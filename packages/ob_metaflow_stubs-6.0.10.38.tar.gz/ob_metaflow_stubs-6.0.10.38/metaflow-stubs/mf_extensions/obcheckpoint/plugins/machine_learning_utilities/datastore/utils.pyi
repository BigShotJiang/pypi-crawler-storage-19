######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.3+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-09T00:03:33.478842                                                            #
######################################################################################################

from __future__ import annotations



def is_json_serializable(value):
    """
    Check if value is JSON serializable.
    """
    ...

def safe_serialize(data):
    ...

