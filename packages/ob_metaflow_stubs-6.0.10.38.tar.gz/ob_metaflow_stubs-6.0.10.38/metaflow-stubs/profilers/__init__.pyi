######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.15.3+obcheckpoint(0.2.10);ob(v1)                                                  #
# Generated on 2026-01-09T00:03:33.374649                                                            #
######################################################################################################

from __future__ import annotations


from ..mf_extensions.outerbounds.profilers import gpu as gpu
from ..mf_extensions.outerbounds.profilers.gpu import gpu_profile as gpu_profile

