#!/usr/bin/env python3
"""Check all database table schemas"""
import psycopg2
from psycopg2.extras import RealDictCursor
import json

# Database connection
conn = psycopg2.connect(
    host="localhost",
    port=11432,
    database="tps",
    user="esd",
    password="esd"
)

cursor = conn.cursor(cursor_factory=RealDictCursor)

tables = [
    'integration_entity',
    'app_marketplace_entity',
    'credential_entity'
]

for table in tables:
    print(f"\n{'='*80}")
    print(f"Table: {table}")
    print('='*80)

    # Get column information
    cursor.execute("""
        SELECT
            column_name,
            data_type,
            character_maximum_length,
            is_nullable,
            column_default
        FROM information_schema.columns
        WHERE table_name = %s
        ORDER BY ordinal_position
    """, (table,))

    columns = cursor.fetchall()

    for col in columns:
        nullable = "NULL" if col['is_nullable'] == 'YES' else "NOT NULL"
        max_len = f"({col['character_maximum_length']})" if col['character_maximum_length'] else ""
        default = f"DEFAULT {col['column_default']}" if col['column_default'] else ""
        print(f"  {col['column_name']:30} {col['data_type']:20}{max_len:10} {nullable:10} {default}")

    # Get sample row to see actual data
    print(f"\n  Sample row:")
    cursor.execute(f"SELECT * FROM {table} LIMIT 1")
    sample = cursor.fetchone()
    if sample:
        for key, value in sample.items():
            value_str = str(value)
            if len(value_str) > 100:
                value_str = value_str[:100] + "..."
            print(f"    {key}: {value_str}")
    else:
        print(f"    (no data)")

cursor.close()
conn.close()
