"""Integration-specific authentication handlers"""

from .workday import WorkdayOAuthHandler

__all__ = ["WorkdayOAuthHandler"]
