"""
Workday OAuth2 authentication handler

Mirrors: com.atomicwork.thirdpartyappintegration.core.client.handler.install.impl.WorkdayHandler
"""

from typing import Optional
from urllib.parse import urlencode, quote
import jwt

from ..base import (
    AuthHandler,
    InstallSettingsRequest,
    InstallSettingsResponse,
    TokenRequest,
    TokenResponse
)
from ..oauth2 import OAuth2Handler


class WorkdayOAuthHandler(OAuth2Handler):
    """
    Workday-specific OAuth2 handler

    Implements the exact flow from WorkdayHandler.java including:
    - Tenant-specific authorization URLs
    - JWT token parsing for expiration
    - Refresh token rotation handling
    """

    # OAuth paths matching Java constants
    OAUTH_PATH = "/ccx/oauth2/"
    AUTHORIZE_PATH = "/{tenant_name}/authorize"
    TOKEN_PATH = "/{tenant_name}/token"

    def __init__(
        self,
        authorization_base_url: str,
        rest_api_base_url: str,
        tenant_name: str,
        scopes: Optional[list[str]] = None,
        verbose: bool = False
    ):
        """
        Initialize Workday OAuth handler

        Args:
            authorization_base_url: Workday authorization server URL
            rest_api_base_url: Workday REST API base URL
            tenant_name: Workday tenant name
            scopes: OAuth scopes (Workday uses empty scopes by default)
            verbose: Enable verbose logging
        """
        self.authorization_base_url = authorization_base_url.rstrip("/")
        self.rest_api_base_url = rest_api_base_url.rstrip("/")
        self.tenant_name = tenant_name

        # Construct full URLs
        authorize_url = f"{authorization_base_url}{self.AUTHORIZE_PATH.format(tenant_name=tenant_name)}"
        token_url = f"{rest_api_base_url}{self.OAUTH_PATH}{tenant_name}/token"

        super().__init__(
            authorization_url=authorize_url,
            token_url=token_url,
            scopes=scopes or [],
            verbose=verbose
        )

    def generate_install_settings(self, request: InstallSettingsRequest) -> InstallSettingsResponse:
        """
        Generate Workday OAuth authorization URL

        Java equivalent: WorkdayHandler.installAppSettings()

        Constructs URL format:
        {authorizationBaseUrl}/{tenantName}/authorize?client_id=...&scope=...&redirect_uri=...&state=...&response_type=code
        """
        # URL encode tenant name (matching Java implementation)
        encoded_tenant_name = quote(self.tenant_name, safe='')

        # Build authorization path
        authorize_path = self.AUTHORIZE_PATH.format(tenant_name=encoded_tenant_name)

        # Build query parameters
        params = {
            "client_id": quote(request.client_id, safe=''),
            "scope": "+".join(self.scopes),  # Empty by default for Workday
            "redirect_uri": quote(request.redirect_url, safe=''),
            "state": quote(request.state, safe=''),
            "response_type": quote("code", safe='')
        }

        query_string = "&".join([f"{k}={v}" for k, v in params.items()])
        authorization_url = f"{self.authorization_base_url}{authorize_path}?{query_string}"

        if self.verbose:
            print(f"Generated Workday authorization URL for tenant: {self.tenant_name}")
            print(f"Authorization base URL: {self.authorization_base_url}")

        return InstallSettingsResponse(authorization_url=authorization_url)

    def get_token(self, request: TokenRequest) -> TokenResponse:
        """
        Exchange authorization code for Workday access token

        Java equivalent: WorkdayHandler.getToken()

        Makes POST request to:
        {restApiBaseUrl}/ccx/oauth2/{tenantName}/token
        """
        if self.verbose:
            print(f"Getting Workday access token for tenant: {self.tenant_name}")
            print(f"REST API base URL: {self.rest_api_base_url}")
            print(f"OAuth URL: {self.token_url}")

        # Call parent OAuth2 handler
        token_response = super().get_token(request)

        # Extract expiration from JWT (Workday returns JWT tokens)
        if token_response.access_token and not token_response.expires_at:
            token_response.expires_at = self._extract_expiration_from_jwt_token(token_response.access_token)

        if self.verbose:
            print(f"Successfully fetched access token for tenant: {self.tenant_name}")
            if token_response.expires_at:
                print(f"Token expires at: {token_response.expires_at}")

        return token_response

    def refresh_token(
        self,
        refresh_token: str,
        client_id: str,
        client_secret: str,
        **kwargs
    ) -> TokenResponse:
        """
        Refresh Workday access token

        Java equivalent: WorkdayHandler.refreshToken()

        Note: Workday rotates refresh tokens after every access token generation
        """
        if self.verbose:
            print(f"Refreshing Workday token for tenant: {self.tenant_name}")
            print(f"OAuth URL: {self.token_url}")

        # Call parent OAuth2 handler
        token_response = super().refresh_token(
            refresh_token=refresh_token,
            client_id=client_id,
            client_secret=client_secret,
            **kwargs
        )

        # Extract expiration from JWT
        if token_response.access_token and not token_response.expires_at:
            token_response.expires_at = self._extract_expiration_from_jwt_token(token_response.access_token)

        if self.verbose:
            print(f"Successfully refreshed token for tenant: {self.tenant_name}")
            if token_response.expires_at:
                print(f"New token expires at: {token_response.expires_at}")

        return token_response

    def is_cache_enabled(self) -> bool:
        """
        Check if caching is enabled for Workday

        Java equivalent: WorkdayHandler.isCacheEnabled()

        Returns False because Workday rotates refresh tokens after every
        access token generation, so caching should be disabled.
        """
        return False

    def _extract_expiration_from_jwt_token(self, access_token: str) -> Optional[int]:
        """
        Extract expiration time from Workday JWT token

        Java equivalent: WorkdayHandler.extractExpirationFromToken()

        Uses JWT parsing to extract the 'exp' claim directly
        """
        try:
            if self.verbose:
                print("Extracting expiration time from JWT token")

            # Decode JWT without verification (matching Java implementation)
            decoded = jwt.decode(access_token, options={"verify_signature": False})

            # Get expiration time from claims
            if "exp" in decoded:
                expires_at_seconds = int(decoded["exp"])

                if self.verbose:
                    print(f"Successfully extracted expiration time: {expires_at_seconds}")

                return expires_at_seconds

            if self.verbose:
                print("JWT token does not contain expiration claim")

            return None

        except Exception as e:
            error_msg = f"Failed to extract expiration from JWT token: {e}"
            if self.verbose:
                print(f"ERROR: {error_msg}")
            raise ValueError(error_msg)
