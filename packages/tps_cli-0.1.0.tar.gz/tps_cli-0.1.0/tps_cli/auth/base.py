"""Base authentication handler interface"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class InstallSettingsRequest:
    """Request to generate install/authorization URL"""
    client_id: str
    client_secret: str
    redirect_url: str
    state: str
    additional_params: Optional[Dict[str, Any]] = None


@dataclass
class InstallSettingsResponse:
    """Response containing authorization URL"""
    authorization_url: str


@dataclass
class TokenRequest:
    """Request to exchange auth code for token"""
    code: str
    redirect_url: str
    client_id: str
    client_secret: str
    additional_params: Optional[Dict[str, Any]] = None


@dataclass
class TokenResponse:
    """OAuth token response"""
    access_token: str
    refresh_token: Optional[str] = None
    expires_at: Optional[int] = None  # Unix timestamp
    token_type: str = "Bearer"
    additional_data: Optional[Dict[str, Any]] = None


class AuthHandler(ABC):
    """
    Base class for authentication handlers

    Mirrors the IAppInstallHandler interface from TPS Java backend
    """

    @abstractmethod
    def generate_install_settings(self, request: InstallSettingsRequest) -> InstallSettingsResponse:
        """
        Generate OAuth authorization URL for app installation

        Java equivalent: installAppSettings()

        Args:
            request: Installation settings request

        Returns:
            InstallSettingsResponse with authorization URL
        """
        pass

    @abstractmethod
    def get_token(self, request: TokenRequest) -> TokenResponse:
        """
        Exchange authorization code for access token

        Java equivalent: getToken()

        Args:
            request: Token request with auth code

        Returns:
            TokenResponse with access and refresh tokens
        """
        pass

    @abstractmethod
    def refresh_token(self, refresh_token: str, client_id: str, client_secret: str, **kwargs) -> TokenResponse:
        """
        Refresh access token using refresh token

        Java equivalent: refreshToken()

        Args:
            refresh_token: Refresh token
            client_id: OAuth client ID
            client_secret: OAuth client secret
            **kwargs: Additional integration-specific parameters

        Returns:
            TokenResponse with new tokens
        """
        pass

    @abstractmethod
    def is_token_expired(self, expires_at: int, buffer_seconds: int = 20) -> bool:
        """
        Check if token is expired or will expire soon

        Java equivalent: isTokenExpired()

        Args:
            expires_at: Token expiration timestamp (Unix seconds)
            buffer_seconds: Buffer time before expiration (default 20s)

        Returns:
            True if token is expired or will expire within buffer
        """
        pass

    @abstractmethod
    def is_cache_enabled(self) -> bool:
        """
        Check if token caching is enabled for this integration

        Java equivalent: isCacheEnabled()

        Some integrations (like Workday) rotate refresh tokens,
        so caching should be disabled.

        Returns:
            True if caching is enabled
        """
        pass

    def validate_config(self, **config) -> bool:
        """
        Validate integration configuration

        Args:
            **config: Configuration parameters

        Returns:
            True if configuration is valid
        """
        return True
