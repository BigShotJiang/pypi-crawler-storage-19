"""Generic OAuth2 authentication handler"""

import time
from typing import Dict, Any, Optional
from urllib.parse import urlencode
import jwt
from datetime import datetime

from .base import (
    AuthHandler,
    InstallSettingsRequest,
    InstallSettingsResponse,
    TokenRequest,
    TokenResponse
)
from ..client.base import BaseHTTPClient


class OAuth2Handler(AuthHandler):
    """
    Generic OAuth2 authentication handler

    Provides standard OAuth2 authorization code flow implementation
    """

    def __init__(
        self,
        authorization_url: str,
        token_url: str,
        scopes: Optional[list[str]] = None,
        verbose: bool = False
    ):
        """
        Initialize OAuth2 handler

        Args:
            authorization_url: OAuth authorization endpoint
            token_url: OAuth token endpoint
            scopes: List of OAuth scopes
            verbose: Enable verbose logging
        """
        self.authorization_url = authorization_url
        self.token_url = token_url
        self.scopes = scopes or []
        self.verbose = verbose

    def generate_install_settings(self, request: InstallSettingsRequest) -> InstallSettingsResponse:
        """Generate OAuth2 authorization URL"""
        params = {
            "client_id": request.client_id,
            "redirect_uri": request.redirect_url,
            "response_type": "code",
            "state": request.state,
        }

        if self.scopes:
            params["scope"] = " ".join(self.scopes)

        # Add any additional parameters
        if request.additional_params:
            params.update(request.additional_params)

        authorization_url = f"{self.authorization_url}?{urlencode(params)}"

        return InstallSettingsResponse(authorization_url=authorization_url)

    def get_token(self, request: TokenRequest) -> TokenResponse:
        """Exchange authorization code for access token"""
        data = {
            "grant_type": "authorization_code",
            "code": request.code,
            "redirect_uri": request.redirect_url,
            "client_id": request.client_id,
            "client_secret": request.client_secret,
        }

        # Add any additional parameters
        if request.additional_params:
            data.update(request.additional_params)

        with BaseHTTPClient(self.token_url, verbose=self.verbose) as client:
            response = client.post(
                "",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )

            token_data = response.json()

            return self._parse_token_response(token_data)

    def refresh_token(self, refresh_token: str, client_id: str, client_secret: str, **kwargs) -> TokenResponse:
        """Refresh access token"""
        data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            "client_secret": client_secret,
        }

        # Add any additional parameters
        data.update(kwargs)

        with BaseHTTPClient(self.token_url, verbose=self.verbose) as client:
            response = client.post(
                "",
                data=data,
                headers={"Content-Type": "application/x-www-form-urlencoded"}
            )

            token_data = response.json()

            return self._parse_token_response(token_data)

    def is_token_expired(self, expires_at: int, buffer_seconds: int = 20) -> bool:
        """Check if token is expired"""
        current_time_seconds = int(time.time())
        remaining_seconds = expires_at - current_time_seconds
        return remaining_seconds < buffer_seconds

    def is_cache_enabled(self) -> bool:
        """Check if caching is enabled (default: True for generic OAuth2)"""
        return True

    def _parse_token_response(self, token_data: Dict[str, Any]) -> TokenResponse:
        """
        Parse token response and extract expiration time

        Args:
            token_data: Token response from OAuth provider

        Returns:
            TokenResponse with parsed data
        """
        access_token = token_data.get("access_token")
        refresh_token = token_data.get("refresh_token")

        # Try to extract expiration from JWT
        expires_at = None
        if access_token:
            expires_at = self._extract_expiration_from_jwt(access_token)

        # Fallback to expires_in if JWT parsing failed
        if not expires_at and "expires_in" in token_data:
            expires_in = token_data["expires_in"]
            expires_at = int(time.time()) + expires_in

        return TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_at=expires_at,
            token_type=token_data.get("token_type", "Bearer"),
            additional_data={k: v for k, v in token_data.items()
                           if k not in ["access_token", "refresh_token", "expires_in", "token_type"]}
        )

    def _extract_expiration_from_jwt(self, token: str) -> Optional[int]:
        """
        Extract expiration time from JWT token

        Matches Java implementation using nimbusds JWT library

        Args:
            token: JWT access token

        Returns:
            Expiration timestamp in seconds, or None if not found
        """
        try:
            # Decode without verification (we're just reading claims)
            decoded = jwt.decode(token, options={"verify_signature": False})

            if "exp" in decoded:
                return int(decoded["exp"])

        except Exception as e:
            if self.verbose:
                print(f"Failed to extract expiration from JWT: {e}")

        return None
