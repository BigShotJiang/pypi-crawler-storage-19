import typing_extensions

from credential_client.apis.tags import TagValues
from credential_client.apis.tags.credential_api import CredentialApi

TagToApi = typing_extensions.TypedDict(
    'TagToApi',
    {
        TagValues.CREDENTIAL: CredentialApi,
    }
)

tag_to_api = TagToApi(
    {
        TagValues.CREDENTIAL: CredentialApi,
    }
)
