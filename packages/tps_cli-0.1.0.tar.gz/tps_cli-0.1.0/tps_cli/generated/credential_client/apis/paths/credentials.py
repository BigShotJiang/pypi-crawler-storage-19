from credential_client.paths.credentials.get import ApiForget
from credential_client.paths.credentials.post import ApiForpost


class Credentials(
    ApiForget,
    ApiForpost,
):
    pass
