from credential_client.paths.credentials_credential_id.get import ApiForget
from credential_client.paths.credentials_credential_id.put import ApiForput
from credential_client.paths.credentials_credential_id.delete import ApiFordelete


class CredentialsCredentialId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
