import typing_extensions

from action_client.apis.tags import TagValues
from action_client.apis.tags.app_action_api import AppActionApi

TagToApi = typing_extensions.TypedDict(
    'TagToApi',
    {
        TagValues.APP_ACTION: AppActionApi,
    }
)

tag_to_api = TagToApi(
    {
        TagValues.APP_ACTION: AppActionApi,
    }
)
