import typing_extensions

from action_client.paths import PathValues
from action_client.apis.paths.app_actions import AppActions
from action_client.apis.paths.user_app_actions_ import UserAppActions
from action_client.apis.paths.app_actions_app_id import AppActionsAppId
from action_client.apis.paths.app_actions_action_name import AppActionsActionName
from action_client.apis.paths.app_actions_details_ import AppActionsDetails
from action_client.apis.paths.app_actions_execute_ import AppActionsExecute
from action_client.apis.paths.v2_app_actions_execute_ import V2AppActionsExecute
from action_client.apis.paths.user_app_actions_execute_ import UserAppActionsExecute
from action_client.apis.paths.app_actions_execute_action_name_options import AppActionsExecuteActionNameOptions
from action_client.apis.paths.app_actions_fields_action_name import AppActionsFieldsActionName
from action_client.apis.paths.app_actions_sync_ import AppActionsSync
from action_client.apis.paths.app_actions_collections_execute_ import AppActionsCollectionsExecute

PathToApi = typing_extensions.TypedDict(
    'PathToApi',
    {
        PathValues.APPACTIONS: AppActions,
        PathValues.USERAPPACTIONS_: UserAppActions,
        PathValues.APPACTIONS_APP_ID: AppActionsAppId,
        PathValues.APPACTIONS_ACTION_NAME: AppActionsActionName,
        PathValues.APPACTIONS_DETAILS_: AppActionsDetails,
        PathValues.APPACTIONS_EXECUTE_: AppActionsExecute,
        PathValues.V2_APPACTIONS_EXECUTE_: V2AppActionsExecute,
        PathValues.USERAPPACTIONS_EXECUTE_: UserAppActionsExecute,
        PathValues.APPACTIONS_EXECUTE_ACTION_NAME_OPTIONS: AppActionsExecuteActionNameOptions,
        PathValues.APPACTIONS_FIELDS_ACTION_NAME: AppActionsFieldsActionName,
        PathValues.APPACTIONS_SYNC_: AppActionsSync,
        PathValues.APPACTIONS_COLLECTIONS_EXECUTE_: AppActionsCollectionsExecute,
    }
)

path_to_api = PathToApi(
    {
        PathValues.APPACTIONS: AppActions,
        PathValues.USERAPPACTIONS_: UserAppActions,
        PathValues.APPACTIONS_APP_ID: AppActionsAppId,
        PathValues.APPACTIONS_ACTION_NAME: AppActionsActionName,
        PathValues.APPACTIONS_DETAILS_: AppActionsDetails,
        PathValues.APPACTIONS_EXECUTE_: AppActionsExecute,
        PathValues.V2_APPACTIONS_EXECUTE_: V2AppActionsExecute,
        PathValues.USERAPPACTIONS_EXECUTE_: UserAppActionsExecute,
        PathValues.APPACTIONS_EXECUTE_ACTION_NAME_OPTIONS: AppActionsExecuteActionNameOptions,
        PathValues.APPACTIONS_FIELDS_ACTION_NAME: AppActionsFieldsActionName,
        PathValues.APPACTIONS_SYNC_: AppActionsSync,
        PathValues.APPACTIONS_COLLECTIONS_EXECUTE_: AppActionsCollectionsExecute,
    }
)
