from action_client.paths.app_actions_collections_execute_.post import ApiForpost


class AppActionsCollectionsExecute(
    ApiForpost,
):
    pass
