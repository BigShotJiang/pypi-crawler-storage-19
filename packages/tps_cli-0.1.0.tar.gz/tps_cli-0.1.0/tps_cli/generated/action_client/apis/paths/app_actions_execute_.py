from action_client.paths.app_actions_execute_.post import ApiForpost


class AppActionsExecute(
    ApiForpost,
):
    pass
