from action_client.paths.app_actions_details_.get import ApiForget


class AppActionsDetails(
    ApiForget,
):
    pass
