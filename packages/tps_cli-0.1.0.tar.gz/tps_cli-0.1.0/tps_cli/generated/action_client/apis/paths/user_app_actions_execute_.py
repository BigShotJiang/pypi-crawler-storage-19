from action_client.paths.user_app_actions_execute_.post import ApiForpost


class UserAppActionsExecute(
    ApiForpost,
):
    pass
