from action_client.paths.app_actions_fields_action_name.get import ApiForget


class AppActionsFieldsActionName(
    ApiForget,
):
    pass
