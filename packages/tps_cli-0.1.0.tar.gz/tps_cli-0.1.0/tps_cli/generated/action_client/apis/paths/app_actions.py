from action_client.paths.app_actions.get import ApiForget


class AppActions(
    ApiForget,
):
    pass
