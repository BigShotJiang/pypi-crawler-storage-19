from action_client.paths.v2_app_actions_execute_.post import ApiForpost


class V2AppActionsExecute(
    ApiForpost,
):
    pass
