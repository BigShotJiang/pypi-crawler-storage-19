from action_client.paths.app_actions_action_name.get import ApiForget
from action_client.paths.app_actions_action_name.put import ApiForput


class AppActionsActionName(
    ApiForget,
    ApiForput,
):
    pass
