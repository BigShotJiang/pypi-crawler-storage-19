from action_client.paths.user_app_actions_.get import ApiForget


class UserAppActions(
    ApiForget,
):
    pass
