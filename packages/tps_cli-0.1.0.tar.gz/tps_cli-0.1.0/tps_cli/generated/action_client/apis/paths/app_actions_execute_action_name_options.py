from action_client.paths.app_actions_execute_action_name_options.post import ApiForpost


class AppActionsExecuteActionNameOptions(
    ApiForpost,
):
    pass
