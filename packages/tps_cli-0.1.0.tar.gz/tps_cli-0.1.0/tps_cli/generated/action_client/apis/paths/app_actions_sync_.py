from action_client.paths.app_actions_sync_.post import ApiForpost


class AppActionsSync(
    ApiForpost,
):
    pass
