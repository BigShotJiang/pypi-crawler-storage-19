from action_client.paths.app_actions_app_id.post import ApiForpost


class AppActionsAppId(
    ApiForpost,
):
    pass
