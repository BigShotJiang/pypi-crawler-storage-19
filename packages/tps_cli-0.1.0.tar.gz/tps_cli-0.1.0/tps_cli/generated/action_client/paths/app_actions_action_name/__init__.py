# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from action_client.paths.app_actions_action_name import Api

from action_client.paths import PathValues

path = PathValues.APPACTIONS_ACTION_NAME