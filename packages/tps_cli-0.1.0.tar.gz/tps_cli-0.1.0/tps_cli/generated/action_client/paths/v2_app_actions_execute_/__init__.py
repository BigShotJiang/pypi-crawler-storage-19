# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from action_client.paths.v2_app_actions_execute_ import Api

from action_client.paths import PathValues

path = PathValues.V2_APPACTIONS_EXECUTE_