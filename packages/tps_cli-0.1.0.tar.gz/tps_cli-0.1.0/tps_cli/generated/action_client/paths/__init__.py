# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from action_client.apis.path_to_api import path_to_api

import enum


class PathValues(str, enum.Enum):
    APPACTIONS = "/app-actions"
    USERAPPACTIONS_ = "/user-app-actions/"
    APPACTIONS_APP_ID = "/app-actions/{app_id}"
    APPACTIONS_ACTION_NAME = "/app-actions/{action_name}"
    APPACTIONS_DETAILS_ = "/app-actions/details/"
    APPACTIONS_EXECUTE_ = "/app-actions/execute/"
    V2_APPACTIONS_EXECUTE_ = "/v2/app-actions/execute/"
    USERAPPACTIONS_EXECUTE_ = "/user-app-actions/execute/"
    APPACTIONS_EXECUTE_ACTION_NAME_OPTIONS = "/app-actions/execute/{action_name}/options"
    APPACTIONS_FIELDS_ACTION_NAME = "/app-actions/fields/{action_name}"
    APPACTIONS_SYNC_ = "/app-actions/sync/"
    APPACTIONS_COLLECTIONS_EXECUTE_ = "/app-actions/collections/execute/"
