# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from app_marketplace_client.apis.path_to_api import path_to_api

import enum


class PathValues(str, enum.Enum):
    APPMARKETPLACE = "/app-marketplace"
    APPMARKETPLACE_APP_ID = "/app-marketplace/{app_id}"
    APPMARKETPLACE_APPNAME_APP_NAME = "/app-marketplace/app-name/{app_name}"
    APPMARKETPLACE_APP_ID_INSTALL_SETTINGS = "/app-marketplace/{app_id}/install/settings"
    APPMARKETPLACE_APP_PROVIDER_TOKEN = "/app-marketplace/{app_provider}/token"
    APPMARKETPLACE_APP_ID_SETTINGS = "/app-marketplace/{app_id}/settings"
