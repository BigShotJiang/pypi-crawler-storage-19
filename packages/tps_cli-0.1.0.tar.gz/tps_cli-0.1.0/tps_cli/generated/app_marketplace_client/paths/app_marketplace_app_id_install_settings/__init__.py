# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from app_marketplace_client.paths.app_marketplace_app_id_install_settings import Api

from app_marketplace_client.paths import PathValues

path = PathValues.APPMARKETPLACE_APP_ID_INSTALL_SETTINGS