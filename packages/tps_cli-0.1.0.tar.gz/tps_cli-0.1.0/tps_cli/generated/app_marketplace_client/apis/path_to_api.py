import typing_extensions

from app_marketplace_client.paths import PathValues
from app_marketplace_client.apis.paths.app_marketplace import AppMarketplace
from app_marketplace_client.apis.paths.app_marketplace_app_id import AppMarketplaceAppId
from app_marketplace_client.apis.paths.app_marketplace_app_name_app_name import AppMarketplaceAppNameAppName
from app_marketplace_client.apis.paths.app_marketplace_app_id_install_settings import AppMarketplaceAppIdInstallSettings
from app_marketplace_client.apis.paths.app_marketplace_app_provider_token import AppMarketplaceAppProviderToken
from app_marketplace_client.apis.paths.app_marketplace_app_id_settings import AppMarketplaceAppIdSettings

PathToApi = typing_extensions.TypedDict(
    'PathToApi',
    {
        PathValues.APPMARKETPLACE: AppMarketplace,
        PathValues.APPMARKETPLACE_APP_ID: AppMarketplaceAppId,
        PathValues.APPMARKETPLACE_APPNAME_APP_NAME: AppMarketplaceAppNameAppName,
        PathValues.APPMARKETPLACE_APP_ID_INSTALL_SETTINGS: AppMarketplaceAppIdInstallSettings,
        PathValues.APPMARKETPLACE_APP_PROVIDER_TOKEN: AppMarketplaceAppProviderToken,
        PathValues.APPMARKETPLACE_APP_ID_SETTINGS: AppMarketplaceAppIdSettings,
    }
)

path_to_api = PathToApi(
    {
        PathValues.APPMARKETPLACE: AppMarketplace,
        PathValues.APPMARKETPLACE_APP_ID: AppMarketplaceAppId,
        PathValues.APPMARKETPLACE_APPNAME_APP_NAME: AppMarketplaceAppNameAppName,
        PathValues.APPMARKETPLACE_APP_ID_INSTALL_SETTINGS: AppMarketplaceAppIdInstallSettings,
        PathValues.APPMARKETPLACE_APP_PROVIDER_TOKEN: AppMarketplaceAppProviderToken,
        PathValues.APPMARKETPLACE_APP_ID_SETTINGS: AppMarketplaceAppIdSettings,
    }
)
