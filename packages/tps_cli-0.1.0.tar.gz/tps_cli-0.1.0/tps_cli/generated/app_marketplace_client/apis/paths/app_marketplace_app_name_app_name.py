from app_marketplace_client.paths.app_marketplace_app_name_app_name.get import ApiForget


class AppMarketplaceAppNameAppName(
    ApiForget,
):
    pass
