from app_marketplace_client.paths.app_marketplace_app_id_install_settings.post import ApiForpost


class AppMarketplaceAppIdInstallSettings(
    ApiForpost,
):
    pass
