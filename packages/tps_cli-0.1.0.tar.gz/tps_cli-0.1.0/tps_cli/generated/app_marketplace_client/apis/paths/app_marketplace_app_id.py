from app_marketplace_client.paths.app_marketplace_app_id.get import ApiForget


class AppMarketplaceAppId(
    ApiForget,
):
    pass
