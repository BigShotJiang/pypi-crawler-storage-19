from app_marketplace_client.paths.app_marketplace_app_provider_token.post import ApiForpost


class AppMarketplaceAppProviderToken(
    ApiForpost,
):
    pass
