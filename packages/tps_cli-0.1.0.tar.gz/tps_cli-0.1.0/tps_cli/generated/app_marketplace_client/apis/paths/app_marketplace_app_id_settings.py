from app_marketplace_client.paths.app_marketplace_app_id_settings.put import ApiForput


class AppMarketplaceAppIdSettings(
    ApiForput,
):
    pass
