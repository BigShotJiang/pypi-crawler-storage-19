from app_marketplace_client.paths.app_marketplace.get import ApiForget


class AppMarketplace(
    ApiForget,
):
    pass
