import typing_extensions

from app_marketplace_client.apis.tags import TagValues
from app_marketplace_client.apis.tags.app_marketplace_api import AppMarketplaceApi

TagToApi = typing_extensions.TypedDict(
    'TagToApi',
    {
        TagValues.APP_MARKETPLACE: AppMarketplaceApi,
    }
)

tag_to_api = TagToApi(
    {
        TagValues.APP_MARKETPLACE: AppMarketplaceApi,
    }
)
