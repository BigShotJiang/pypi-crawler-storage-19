from webhook_client.paths.webhook_execute.post import ApiForpost


class WebhookExecute(
    ApiForpost,
):
    pass
