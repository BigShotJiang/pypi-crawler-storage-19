from webhook_client.paths.webhook_accept.post import ApiForpost


class WebhookAccept(
    ApiForpost,
):
    pass
