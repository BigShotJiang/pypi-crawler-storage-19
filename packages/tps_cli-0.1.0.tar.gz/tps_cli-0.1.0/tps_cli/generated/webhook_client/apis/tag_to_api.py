import typing_extensions

from webhook_client.apis.tags import TagValues
from webhook_client.apis.tags.webhook_api import WebhookApi

TagToApi = typing_extensions.TypedDict(
    'TagToApi',
    {
        TagValues.WEBHOOK: WebhookApi,
    }
)

tag_to_api = TagToApi(
    {
        TagValues.WEBHOOK: WebhookApi,
    }
)
