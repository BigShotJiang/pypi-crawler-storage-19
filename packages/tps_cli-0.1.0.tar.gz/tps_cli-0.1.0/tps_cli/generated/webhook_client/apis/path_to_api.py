import typing_extensions

from webhook_client.paths import PathValues
from webhook_client.apis.paths.webhook_accept import WebhookAccept
from webhook_client.apis.paths.webhook_execute import WebhookExecute

PathToApi = typing_extensions.TypedDict(
    'PathToApi',
    {
        PathValues.WEBHOOK_ACCEPT: WebhookAccept,
        PathValues.WEBHOOK_EXECUTE: WebhookExecute,
    }
)

path_to_api = PathToApi(
    {
        PathValues.WEBHOOK_ACCEPT: WebhookAccept,
        PathValues.WEBHOOK_EXECUTE: WebhookExecute,
    }
)
