import typing_extensions

from integration_client.apis.tags import TagValues
from integration_client.apis.tags.integration_api import IntegrationApi

TagToApi = typing_extensions.TypedDict(
    'TagToApi',
    {
        TagValues.INTEGRATION: IntegrationApi,
    }
)

tag_to_api = TagToApi(
    {
        TagValues.INTEGRATION: IntegrationApi,
    }
)
