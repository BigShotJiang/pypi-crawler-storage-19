import typing_extensions

from integration_client.paths import PathValues
from integration_client.apis.paths.integrations import Integrations
from integration_client.apis.paths.integrations_internal_ import IntegrationsInternal
from integration_client.apis.paths.integrations_internal_global_identifier import IntegrationsInternalGlobalIdentifier
from integration_client.apis.paths.integrations_integration_id import IntegrationsIntegrationId
from integration_client.apis.paths.integrations_internal_integration_id import IntegrationsInternalIntegrationId
from integration_client.apis.paths.integrations_ping import IntegrationsPing
from integration_client.apis.paths.integrations_integration_id_ping import IntegrationsIntegrationIdPing
from integration_client.apis.paths.integrations_integration_id_children import IntegrationsIntegrationIdChildren
from integration_client.apis.paths.integrations_app_id_install import IntegrationsAppIdInstall
from integration_client.apis.paths.integrations_app_name_permissions import IntegrationsAppNamePermissions
from integration_client.apis.paths.integrations_internal_app_name_auth_config import IntegrationsInternalAppNameAuthConfig

PathToApi = typing_extensions.TypedDict(
    'PathToApi',
    {
        PathValues.INTEGRATIONS: Integrations,
        PathValues.INTEGRATIONS_INTERNAL_: IntegrationsInternal,
        PathValues.INTEGRATIONS_INTERNAL_GLOBAL_IDENTIFIER: IntegrationsInternalGlobalIdentifier,
        PathValues.INTEGRATIONS_INTEGRATION_ID: IntegrationsIntegrationId,
        PathValues.INTEGRATIONS_INTERNAL_INTEGRATION_ID: IntegrationsInternalIntegrationId,
        PathValues.INTEGRATIONS_PING: IntegrationsPing,
        PathValues.INTEGRATIONS_INTEGRATION_ID_PING: IntegrationsIntegrationIdPing,
        PathValues.INTEGRATIONS_INTEGRATION_ID_CHILDREN: IntegrationsIntegrationIdChildren,
        PathValues.INTEGRATIONS_APP_ID_INSTALL: IntegrationsAppIdInstall,
        PathValues.INTEGRATIONS_APP_NAME_PERMISSIONS: IntegrationsAppNamePermissions,
        PathValues.INTEGRATIONS_INTERNAL_APP_NAME_AUTHCONFIG: IntegrationsInternalAppNameAuthConfig,
    }
)

path_to_api = PathToApi(
    {
        PathValues.INTEGRATIONS: Integrations,
        PathValues.INTEGRATIONS_INTERNAL_: IntegrationsInternal,
        PathValues.INTEGRATIONS_INTERNAL_GLOBAL_IDENTIFIER: IntegrationsInternalGlobalIdentifier,
        PathValues.INTEGRATIONS_INTEGRATION_ID: IntegrationsIntegrationId,
        PathValues.INTEGRATIONS_INTERNAL_INTEGRATION_ID: IntegrationsInternalIntegrationId,
        PathValues.INTEGRATIONS_PING: IntegrationsPing,
        PathValues.INTEGRATIONS_INTEGRATION_ID_PING: IntegrationsIntegrationIdPing,
        PathValues.INTEGRATIONS_INTEGRATION_ID_CHILDREN: IntegrationsIntegrationIdChildren,
        PathValues.INTEGRATIONS_APP_ID_INSTALL: IntegrationsAppIdInstall,
        PathValues.INTEGRATIONS_APP_NAME_PERMISSIONS: IntegrationsAppNamePermissions,
        PathValues.INTEGRATIONS_INTERNAL_APP_NAME_AUTHCONFIG: IntegrationsInternalAppNameAuthConfig,
    }
)
