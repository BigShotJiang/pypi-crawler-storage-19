from integration_client.paths.integrations_internal_app_name_auth_config.get import ApiForget


class IntegrationsInternalAppNameAuthConfig(
    ApiForget,
):
    pass
