from integration_client.paths.integrations_internal_global_identifier.get import ApiForget


class IntegrationsInternalGlobalIdentifier(
    ApiForget,
):
    pass
