from integration_client.paths.integrations_integration_id_ping.post import ApiForpost


class IntegrationsIntegrationIdPing(
    ApiForpost,
):
    pass
