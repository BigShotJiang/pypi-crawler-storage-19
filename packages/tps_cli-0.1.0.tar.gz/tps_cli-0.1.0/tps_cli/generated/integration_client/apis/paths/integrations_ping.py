from integration_client.paths.integrations_ping.post import ApiForpost


class IntegrationsPing(
    ApiForpost,
):
    pass
