from integration_client.paths.integrations_integration_id.get import ApiForget
from integration_client.paths.integrations_integration_id.put import ApiForput
from integration_client.paths.integrations_integration_id.delete import ApiFordelete


class IntegrationsIntegrationId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
