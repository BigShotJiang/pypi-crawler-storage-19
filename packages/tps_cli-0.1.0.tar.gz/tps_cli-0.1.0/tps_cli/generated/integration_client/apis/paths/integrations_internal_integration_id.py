from integration_client.paths.integrations_internal_integration_id.get import ApiForget


class IntegrationsInternalIntegrationId(
    ApiForget,
):
    pass
