from integration_client.paths.integrations_app_id_install.post import ApiForpost


class IntegrationsAppIdInstall(
    ApiForpost,
):
    pass
