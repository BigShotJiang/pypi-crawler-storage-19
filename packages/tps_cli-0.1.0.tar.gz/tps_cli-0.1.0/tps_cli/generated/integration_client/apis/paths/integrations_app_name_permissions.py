from integration_client.paths.integrations_app_name_permissions.get import ApiForget


class IntegrationsAppNamePermissions(
    ApiForget,
):
    pass
