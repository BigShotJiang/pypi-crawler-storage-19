from integration_client.paths.integrations_integration_id_children.delete import ApiFordelete


class IntegrationsIntegrationIdChildren(
    ApiFordelete,
):
    pass
