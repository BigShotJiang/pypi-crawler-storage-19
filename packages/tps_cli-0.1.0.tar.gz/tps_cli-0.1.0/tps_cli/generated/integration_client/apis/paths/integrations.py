from integration_client.paths.integrations.get import ApiForget
from integration_client.paths.integrations.post import ApiForpost


class Integrations(
    ApiForget,
    ApiForpost,
):
    pass
