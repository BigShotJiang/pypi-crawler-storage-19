from integration_client.paths.integrations_internal_.get import ApiForget


class IntegrationsInternal(
    ApiForget,
):
    pass
