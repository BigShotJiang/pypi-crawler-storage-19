# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from integration_client.paths.integrations_internal_ import Api

from integration_client.paths import PathValues

path = PathValues.INTEGRATIONS_INTERNAL_