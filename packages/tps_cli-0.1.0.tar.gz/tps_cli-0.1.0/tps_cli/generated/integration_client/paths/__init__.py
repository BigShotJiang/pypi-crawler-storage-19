# do not import all endpoints into this module because that uses a lot of memory and stack frames
# if you need the ability to import all endpoints from this module, import them with
# from integration_client.apis.path_to_api import path_to_api

import enum


class PathValues(str, enum.Enum):
    INTEGRATIONS = "/integrations"
    INTEGRATIONS_INTERNAL_ = "/integrations/internal/"
    INTEGRATIONS_INTERNAL_GLOBAL_IDENTIFIER = "/integrations/internal/global/identifier"
    INTEGRATIONS_INTEGRATION_ID = "/integrations/{integration_id}"
    INTEGRATIONS_INTERNAL_INTEGRATION_ID = "/integrations/internal/{integration_id}"
    INTEGRATIONS_PING = "/integrations/ping"
    INTEGRATIONS_INTEGRATION_ID_PING = "/integrations/{integration_id}/ping"
    INTEGRATIONS_INTEGRATION_ID_CHILDREN = "/integrations/{integration_id}/children"
    INTEGRATIONS_APP_ID_INSTALL = "/integrations/{app_id}/install"
    INTEGRATIONS_APP_NAME_PERMISSIONS = "/integrations/{app_name}/permissions"
    INTEGRATIONS_INTERNAL_APP_NAME_AUTHCONFIG = "/integrations/internal/{app_name}/auth-config"
