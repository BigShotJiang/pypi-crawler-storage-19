"""Base HTTP client for API interactions"""

import httpx
from typing import Optional, Dict, Any
from rich.console import Console


console = Console()


class BaseHTTPClient:
    """Base HTTP client with authentication and error handling"""

    def __init__(
        self,
        base_url: str,
        headers: Optional[Dict[str, Any]] = None,
        timeout: int = 30,
        verbose: bool = False
    ):
        self.base_url = base_url.rstrip("/")
        self.verbose = verbose
        self.console = Console()

        default_headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        if headers:
            default_headers.update(headers)

        self.client = httpx.Client(
            base_url=self.base_url,
            headers=default_headers,
            timeout=timeout,
            follow_redirects=True
        )

    def _log_request(self, method: str, url: str, **kwargs):
        """Log request details if verbose mode is enabled"""
        if self.verbose:
            self.console.print(f"[dim]→ {method} {self.base_url}{url}[/dim]")
            if kwargs.get("params"):
                self.console.print(f"[dim]  Params: {kwargs['params']}[/dim]")
            if kwargs.get("headers"):
                # Hide sensitive headers
                safe_headers = {k: v if k.lower() not in ['authorization', 'x-api-key'] else '***'
                               for k, v in kwargs['headers'].items()}
                self.console.print(f"[dim]  Headers: {safe_headers}[/dim]")

    def _log_response(self, response: httpx.Response):
        """Log response details if verbose mode is enabled"""
        if self.verbose:
            self.console.print(f"[dim]← {response.status_code} {response.reason_phrase}[/dim]")

    def get(self, path: str, params: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """Make GET request"""
        self._log_request("GET", path, params=params, **kwargs)
        response = self.client.get(path, params=params, **kwargs)
        self._log_response(response)
        response.raise_for_status()
        return response

    def post(
        self,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> httpx.Response:
        """Make POST request"""
        self._log_request("POST", path, **kwargs)
        response = self.client.post(path, json=json, data=data, **kwargs)
        self._log_response(response)
        response.raise_for_status()
        return response

    def put(self, path: str, json: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """Make PUT request"""
        self._log_request("PUT", path, **kwargs)
        response = self.client.put(path, json=json, **kwargs)
        self._log_response(response)
        response.raise_for_status()
        return response

    def delete(self, path: str, **kwargs) -> httpx.Response:
        """Make DELETE request"""
        self._log_request("DELETE", path, **kwargs)
        response = self.client.delete(path, **kwargs)
        self._log_response(response)
        response.raise_for_status()
        return response

    def close(self):
        """Close the HTTP client"""
        self.client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
