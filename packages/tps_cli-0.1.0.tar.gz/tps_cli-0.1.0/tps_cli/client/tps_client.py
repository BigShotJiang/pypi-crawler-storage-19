"""
TPS Service API Client (Using Auto-Generated Clients)

This is a thin wrapper around auto-generated OpenAPI clients.
The clients are generated from TPS OpenAPI specs, mirroring the Java approach
where services use tps-app-marketplace-client, tps-integration-client, etc.

Architecture:
    CLI → TPSClient (wrapper) → Generated Clients → TPS Service (8093) → Third-Party APIs
"""

import sys
from pathlib import Path
from typing import Optional, Dict, Any, List

# Add generated clients to path
generated_path = Path(__file__).parent.parent / "generated"
sys.path.insert(0, str(generated_path))

from app_marketplace_client.api_client import ApiClient as AppMarketplaceApiClient
from app_marketplace_client.configuration import Configuration as AppMarketplaceConfiguration
from app_marketplace_client.apis.tags.app_marketplace_api import AppMarketplaceApi

from integration_client.api_client import ApiClient as IntegrationApiClient
from integration_client.configuration import Configuration as IntegrationConfiguration
from integration_client.apis.tags.integration_api import IntegrationApi


class TPSClient:
    """
    TPS Service Client (Wrapper around auto-generated clients)

    This wraps auto-generated OpenAPI clients from TPS specifications.
    Similar to how Java services use:
        - tps-app-marketplace-client
        - tps-integration-client
        - tps-credential-client
        etc.

    We generate Python equivalents locally from the same OpenAPI specs.
    """

    def __init__(
        self,
        base_url: str,
        tenant_id: int,
        user_id: Optional[int] = None,
        verbose: bool = False
    ):
        """
        Initialize TPS client with auto-generated API clients

        Args:
            base_url: TPS service base URL (e.g., "http://localhost:8093")
            tenant_id: Tenant ID for X-Tenant-ID header
            user_id: Optional user ID for X-User-ID header
            verbose: Enable verbose logging
        """
        self.base_url = base_url
        self.tenant_id = tenant_id
        self.user_id = user_id
        self.verbose = verbose

        # Configure and initialize API clients
        self._init_app_marketplace_client()
        self._init_integration_client()

    def _init_app_marketplace_client(self):
        """Initialize App Marketplace API client"""
        # OpenAPI spec has server: http://localhost:8093/api
        # So if base_url is http://localhost:8093, we need to add /api
        api_base = self.base_url
        if not api_base.endswith('/api'):
            api_base = f"{api_base}/api"

        config = AppMarketplaceConfiguration(host=api_base)
        self.app_marketplace_api_client = AppMarketplaceApiClient(configuration=config)
        self.app_marketplace = AppMarketplaceApi(api_client=self.app_marketplace_api_client)

    def _init_integration_client(self):
        """Initialize Integration API client"""
        # OpenAPI spec has server: http://localhost:8093/api
        api_base = self.base_url
        if not api_base.endswith('/api'):
            api_base = f"{api_base}/api"

        config = IntegrationConfiguration(host=api_base)
        self.integration_api_client = IntegrationApiClient(configuration=config)
        self.integration = IntegrationApi(api_client=self.integration_api_client)

    def _get_headers(self) -> Dict[str, Any]:
        """Get common headers for API calls"""
        headers = {"X-Tenant-ID": self.tenant_id}
        if self.user_id:
            headers["X-User-ID"] = self.user_id
        return headers

    # ========== App Marketplace APIs ==========

    def list_apps(
        self,
        category: Optional[str] = None,
        is_internal_app: Optional[bool] = None
    ) -> List[Dict[str, Any]]:
        """
        List available apps from marketplace

        Uses auto-generated client: AppMarketplaceApi.list_apps()
        """
        query_params = {}
        if category:
            query_params["category"] = category
        if is_internal_app is not None:
            query_params["is_internal_app"] = is_internal_app

        response = self.app_marketplace.list_apps(
            query_params=query_params,
            header_params=self._get_headers(),
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def get_app(self, app_id: int) -> Dict[str, Any]:
        """
        Get app details by ID

        Uses auto-generated client: AppMarketplaceApi.find_by_id()
        """
        response = self.app_marketplace.find_by_id(
            path_params={"app_id": app_id},
            header_params=self._get_headers(),
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def get_app_by_name(self, app_name: str) -> Dict[str, Any]:
        """
        Get app details by name

        Uses auto-generated client: AppMarketplaceApi.find_by_app_name()
        """
        response = self.app_marketplace.find_by_app_name(
            path_params={"app_name": app_name},
            header_params=self._get_headers(),
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def generate_install_url(
        self,
        app_id: int,
        redirect_uri: str,
        state: str,
        config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generate OAuth authorization URL for app installation

        Uses auto-generated client: AppMarketplaceApi.get_install_app_settings()

        This calls the TPS service to generate the OAuth URL.
        The TPS service handles all app-specific OAuth logic.
        """
        request_body = {
            "state": state,
            "redirect_uri": redirect_uri
        }
        if config:
            request_body["config"] = config

        response = self.app_marketplace.get_install_app_settings(
            path_params={"app_id": app_id},
            header_params=self._get_headers(),
            body=request_body,
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def exchange_code_for_token(
        self,
        app_provider: str,
        code: str,
        redirect_uri: str,
        created_by: int,
        config: Optional[Dict[str, Any]] = None,
        source_ip: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Exchange authorization code for access token

        Uses auto-generated client: AppMarketplaceApi.get_token_for_app_provider()
        """
        request_body = {
            "created_by": created_by,
            "code": code,
            "redirect_uri": redirect_uri
        }
        if config:
            request_body["config"] = config
        if source_ip:
            request_body["source_ip"] = source_ip

        response = self.app_marketplace.get_token_for_app_provider(
            path_params={"app_provider": app_provider},
            header_params=self._get_headers(),
            body=request_body,
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def refresh_access_token(
        self,
        app_provider: str,
        refresh_token: str,
        created_by: int,
        config: Optional[Dict[str, Any]] = None,
        source_ip: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Refresh access token using refresh token

        Uses auto-generated client: AppMarketplaceApi.get_token_for_app_provider()
        """
        request_body = {
            "created_by": created_by,
            "refresh_token": refresh_token
        }
        if config:
            request_body["config"] = config
        if source_ip:
            request_body["source_ip"] = source_ip

        response = self.app_marketplace.get_token_for_app_provider(
            path_params={"app_provider": app_provider},
            header_params=self._get_headers(),
            body=request_body,
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    # ========== Integration Management APIs ==========

    def list_integrations(
        self,
        app_id: Optional[int] = None,
        app_names: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        List integrations

        Uses auto-generated client: IntegrationApi.list_integrations()

        Note: The OpenAPI spec only defines app_id and app_names parameters.
        limit/offset/status are not in the spec.
        """
        query_params = {}
        if app_id:
            query_params["app_id"] = app_id
        if app_names:
            query_params["app_names"] = app_names

        # Call the generated client
        # Note: Skip deserialization to avoid schema validation issues
        kwargs = {
            "header_params": self._get_headers(),
            "skip_deserialization": True  # Get raw JSON response
        }
        if query_params:
            kwargs["query_params"] = query_params

        response = self.integration.list_integrations(**kwargs)

        # Extract and parse the response
        if hasattr(response, 'response'):
            # HTTPResponse object - read and parse JSON
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def get_integration(self, integration_id: int) -> Dict[str, Any]:
        """
        Get integration by ID

        Uses auto-generated client: IntegrationApi.get_integration()
        """
        response = self.integration.get_integration(
            path_params={"integration_id": integration_id},
            header_params=self._get_headers(),
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def create_integration(self, app_id: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a new integration

        Uses auto-generated client: IntegrationApi.create_integration()
        """
        request_body = {
            "app_id": app_id,
            "config": config
        }

        response = self.integration.create_integration(
            header_params=self._get_headers(),
            body=request_body,
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def install_integration(
        self,
        app_id: int,
        code: str,
        redirect_uri: str,
        config: Dict[str, Any],
        admin_consent: Optional[bool] = None,
        user_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Install an integration using OAuth authorization code

        Uses auto-generated client: IntegrationApi.install_integration()

        Args:
            app_id: Application ID
            code: OAuth authorization code from callback
            redirect_uri: OAuth redirect URI
            config: App-specific configuration (must include app_name)
            admin_consent: Admin consent flag (optional)
            user_id: User ID (optional, uses X-User-ID header if provided)
        """
        request_body = {
            "code": code,
            "redirect_uri": redirect_uri,
            "config": config
        }
        if admin_consent is not None:
            request_body["admin_consent"] = str(admin_consent).lower()

        headers = self._get_headers()
        if user_id:
            headers["X-User-ID"] = user_id

        response = self.integration.install_integration(
            path_params={"app_id": app_id},
            header_params=headers,
            body=request_body,
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def update_integration(
        self,
        integration_id: int,
        config: Dict[str, Any],
        version: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Update integration configuration

        Uses auto-generated client: IntegrationApi.update_integration()
        """
        request_body = {"config": config}
        if version is not None:
            request_body["version"] = version

        response = self.integration.update_integration(
            path_params={"integration_id": integration_id},
            header_params=self._get_headers(),
            body=request_body,
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    def disable_integration(self, integration_id: int) -> None:
        """
        Disable an integration

        Uses auto-generated client: IntegrationApi.disable_integration()
        """
        self.integration.disable_integration(
            path_params={"integration_id": integration_id},
            header_params=self._get_headers()
        )

    def ping_integration(self, integration_id: int) -> Dict[str, Any]:
        """
        Ping an integration to test connectivity

        Uses auto-generated client: IntegrationApi.ping_integration()
        """
        response = self.integration.ping_integration(
            path_params={"integration_id": integration_id},
            header_params=self._get_headers(),
            skip_deserialization=True  # Get raw JSON response
        )

        # Extract and parse the response
        if hasattr(response, 'response'):
            import json
            body_text = response.response.data.decode('utf-8')
            return json.loads(body_text)
        elif hasattr(response, 'body'):
            return response.body
        return response

    # ========== Health Check ==========

    def health_check(self) -> Dict[str, Any]:
        """
        Check TPS service health

        Note: May need to use direct HTTP call as this might not be in OpenAPI spec
        """
        # For now, use a simple check - can be implemented if needed
        try:
            apps = self.list_apps()
            return {"status": "UP", "apps_count": len(apps)}
        except Exception as e:
            return {"status": "DOWN", "error": str(e)}
