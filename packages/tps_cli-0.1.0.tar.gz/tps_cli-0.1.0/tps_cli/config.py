"""Configuration management for TPS CLI"""

import os
from pathlib import Path
from typing import Optional
from pydantic import BaseModel, Field
import yaml
from dotenv import load_dotenv


# Load environment variables
load_dotenv()


class DatabaseConfig(BaseModel):
    """Database connection configuration"""
    host: str = Field(default="localhost")
    port: int = Field(default=5432)
    database: str = Field(default="tps")
    username: str = Field(default="postgres")
    password: str = Field(default="")

    @property
    def connection_string(self) -> str:
        """Get SQLAlchemy connection string"""
        return f"postgresql://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"


class TPSServiceConfig(BaseModel):
    """TPS service configuration"""
    url: str = Field(default="http://localhost:8093")
    timeout: int = Field(default=30)


class SecurityConfig(BaseModel):
    """Security configuration"""
    atomic_secret: Optional[str] = Field(default=None, description="Encryption key for credentials")

    @property
    def encryption_key(self) -> str:
        """Get encryption key from config or environment variable"""
        return self.atomic_secret or os.getenv('ATOMIC_SECRET', 't7w!z%C*F-JaNdRgUjXn2r5u8x/A?D(G')


class ProfileConfig(BaseModel):
    """Configuration profile"""
    name: str
    tps_service: TPSServiceConfig
    database: DatabaseConfig
    security: SecurityConfig = Field(default_factory=SecurityConfig)


class Config(BaseModel):
    """Main configuration"""
    active_profile: str = Field(default="local")
    profiles: dict[str, ProfileConfig] = Field(default_factory=dict)

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> "Config":
        """Load configuration from file or create default"""
        if config_path is None:
            config_path = Path.home() / ".tps-cli" / "config.yaml"

        if config_path.exists():
            with open(config_path, 'r') as f:
                data = yaml.safe_load(f)
                return cls(**data)

        # Create default config
        return cls.create_default()

    @classmethod
    def create_default(cls) -> "Config":
        """Create default configuration"""
        return cls(
            active_profile="local",
            profiles={
                "local": ProfileConfig(
                    name="local",
                    tps_service=TPSServiceConfig(
                        url=os.getenv("TPS_URL", "http://localhost:8093")
                    ),
                    database=DatabaseConfig(
                        host=os.getenv("DB_HOST", "localhost"),
                        port=int(os.getenv("DB_PORT", "5432")),
                        database=os.getenv("DB_NAME", "tps"),
                        username=os.getenv("DB_USER", "postgres"),
                        password=os.getenv("DB_PASSWORD", "")
                    )
                )
            }
        )

    def save(self, config_path: Optional[Path] = None):
        """Save configuration to file"""
        if config_path is None:
            config_path = Path.home() / ".tps-cli" / "config.yaml"

        config_path.parent.mkdir(parents=True, exist_ok=True)

        with open(config_path, 'w') as f:
            yaml.dump(self.model_dump(), f, default_flow_style=False)

    def get_active_profile(self) -> ProfileConfig:
        """Get the active profile configuration"""
        return self.profiles[self.active_profile]


# Global config instance
_config: Optional[Config] = None


def load_config() -> Config:
    """Load or get cached configuration"""
    global _config
    if _config is None:
        _config = Config.load()
    return _config


def reload_config():
    """Force reload configuration"""
    global _config
    _config = None
    return load_config()
