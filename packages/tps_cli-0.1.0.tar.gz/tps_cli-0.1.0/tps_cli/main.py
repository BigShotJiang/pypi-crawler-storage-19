"""Main CLI entry point for TPS CLI"""

import os
import typer
from typing import Optional
from pathlib import Path
from rich.console import Console

from . import __version__
from .config import load_config, Config, ProfileConfig, TPSServiceConfig, DatabaseConfig
from .commands import integration
from .client import TPSClient
from .utils import print_success, print_error, print_info, print_json


app = typer.Typer(
    name="tps",
    help="TPS CLI - Third-Party App Integration Service Testing Tool",
    add_completion=True,
)

# Add command groups
app.add_typer(integration.app, name="integration", help="Integration testing commands")

console = Console()


@app.command()
def version():
    """Show CLI version"""
    console.print(f"TPS CLI v{__version__}")


@app.command()
def init():
    """
    Initialize TPS CLI configuration

    Creates a configuration file at ~/.tps-cli/config.yaml
    Interactively prompts for TPS service and database configuration
    """
    try:
        config_path = Path.home() / ".tps-cli" / "config.yaml"

        if config_path.exists():
            print_info(f"Configuration already exists at {config_path}")
            overwrite = typer.confirm("Do you want to overwrite it?")
            if not overwrite:
                print_info("Keeping existing configuration")
                return

        # Interactive prompts for configuration
        console.print("\n[bold cyan]TPS CLI Configuration Setup[/bold cyan]\n")

        # TPS Service configuration
        console.print("[bold]TPS Service Configuration:[/bold]")
        tps_url = typer.prompt(
            "TPS Service URL",
            default=os.getenv("TPS_URL", "http://localhost:8093")
        )

        # Database configuration
        console.print("\n[bold]Database Configuration:[/bold]")
        db_host = typer.prompt("Database Host", default=os.getenv("DB_HOST", "localhost"))
        db_port = typer.prompt("Database Port", default=os.getenv("DB_PORT", "5432"))
        db_name = typer.prompt("Database Name", default=os.getenv("DB_NAME", "tps"))
        db_user = typer.prompt("Database Username", default=os.getenv("DB_USER", "postgres"))
        db_password = typer.prompt(
            "Database Password",
            default=os.getenv("DB_PASSWORD", ""),
            hide_input=True
        )

        # Encryption configuration (optional)
        console.print("\n[bold]Encryption Configuration (optional):[/bold]")
        atomic_secret = typer.prompt(
            "ATOMIC_SECRET (leave empty for default)",
            default="",
            show_default=False
        )

        # Create configuration with provided values
        config = Config(
            active_profile="local",
            profiles={
                "local": ProfileConfig(
                    name="local",
                    tps_service=TPSServiceConfig(url=tps_url),
                    database=DatabaseConfig(
                        host=db_host,
                        port=int(db_port),
                        database=db_name,
                        username=db_user,
                        password=db_password
                    )
                )
            },
            atomic_secret=atomic_secret if atomic_secret else None
        )

        config.save(config_path)

        print_success(f"\nConfiguration initialized at {config_path}")
        print_info("\nConfiguration summary:")
        console.print(f"[cyan]TPS Service:[/cyan] {tps_url}")
        console.print(f"[cyan]Database:[/cyan] postgresql://{db_user}@{db_host}:{db_port}/{db_name}")
        if atomic_secret:
            console.print(f"[cyan]Encryption:[/cyan] Custom ATOMIC_SECRET configured")
        else:
            console.print(f"[yellow]Encryption:[/yellow] Using default ATOMIC_SECRET (update in config for production)")
        console.print(f"\n[dim]Run 'tps config --show' to view your configuration[/dim]\n")

    except Exception as e:
        print_error(f"Failed to initialize configuration: {str(e)}")
        raise typer.Exit(1)


@app.command()
def config(
    show: bool = typer.Option(False, "--show", "-s", help="Show current configuration"),
    profile: Optional[str] = typer.Option(None, "--profile", "-p", help="Set active profile"),
):
    """
    Manage CLI configuration

    Examples:
        tps config --show
        tps config --profile staging
    """
    try:
        cfg = load_config()

        if profile:
            if profile not in cfg.profiles:
                print_error(f"Profile '{profile}' not found")
                print_info(f"Available profiles: {', '.join(cfg.profiles.keys())}")
                raise typer.Exit(1)

            cfg.active_profile = profile
            cfg.save()
            print_success(f"Active profile set to: {profile}")

        if show:
            active = cfg.get_active_profile()
            print_info(f"Active Profile: {cfg.active_profile}")
            console.print(f"\n[cyan]TPS Service URL:[/cyan] {active.tps_service.url}")
            console.print(f"[cyan]Database:[/cyan] {active.database.host}:{active.database.port}/{active.database.database}\n")

    except Exception as e:
        print_error(f"Failed to manage configuration: {str(e)}")
        raise typer.Exit(1)


@app.command()
def health(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show detailed health information"),
):
    """
    Check TPS service health

    Examples:
        tps health
        tps health --verbose
    """
    try:
        cfg = load_config()
        profile = cfg.get_active_profile()

        # Health check doesn't require specific tenant, use default
        client = TPSClient(profile.tps_service.url, tenant_id=2, verbose=verbose)
        health_data = client.health_check()

        status = health_data.get("status", "UNKNOWN")

        if status == "UP":
            print_success(f"TPS Service is healthy")
            console.print(f"[cyan]URL:[/cyan] {profile.tps_service.url}")

            if verbose:
                print_json(health_data)
        else:
            print_error(f"TPS Service is unhealthy: {status}")
            if verbose:
                print_json(health_data)
            raise typer.Exit(1)

    except Exception as e:
        print_error(f"Failed to check health: {str(e)}")
        raise typer.Exit(1)


def main():
    """Main entry point"""
    app()


if __name__ == "__main__":
    main()
