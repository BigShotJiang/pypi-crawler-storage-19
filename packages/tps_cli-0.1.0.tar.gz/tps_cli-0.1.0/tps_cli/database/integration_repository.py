"""Database repository for querying integration_entity table"""

from typing import Optional, List, Dict, Any, Tuple
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import NullPool

from ..models import (
    IntegrationEntity,
    IntegrationView,
    CredentialEntity,
    CredentialView,
    AppMarketplaceEntity,
    AuthType,
    Apps
)


class IntegrationRepository:
    """Repository for accessing TPS database tables"""

    def __init__(self, connection_string: str):
        """
        Initialize repository with database connection

        Args:
            connection_string: PostgreSQL connection string
        """
        self.engine = create_engine(
            connection_string,
            poolclass=NullPool,  # Disable connection pooling for CLI
            echo=False
        )
        self.SessionLocal = sessionmaker(bind=self.engine)

    def get_session(self) -> Session:
        """Get a new database session"""
        return self.SessionLocal()

    def get_integration_by_id(self, integration_id: int) -> Optional[IntegrationView]:
        """
        Get integration by ID with joined app marketplace data

        Returns:
            IntegrationView: View model combining integration and app marketplace data
        """
        with self.get_session() as session:
            query = text("""
                SELECT
                    ie.id,
                    ie.tenant_id,
                    ie.app_id,
                    ae.apps,
                    ae.auth_type,
                    ie.status,
                    ie.configuration,
                    ie.identifier,
                    ie.user_id,
                    ie.created_at,
                    ie.updated_at,
                    ae.provider,
                    ae.app_key
                FROM integration_entity ie
                LEFT JOIN app_marketplace_entity ae ON ie.app_id = ae.id
                WHERE ie.id = :integration_id
            """)

            result = session.execute(query, {"integration_id": integration_id}).fetchone()

            if result:
                # Get app name from apps enum (result[3])
                app_name = Apps.get_name(result[3]) if result[3] else "Unknown"

                return IntegrationView(
                    id=result[0],
                    tenant_id=result[1],
                    app_id=result[2],
                    app_name=app_name,
                    auth_type=result[4],
                    status=result[5],
                    configuration=result[6],
                    identifier=result[7],
                    user_id=result[8],
                    created_at=result[9],
                    updated_at=result[10],
                    provider=result[11],
                    app_key=result[12]
                )
            return None

    def list_integrations(
        self,
        tenant_id: Optional[int] = None,
        app_id: Optional[int] = None,
        status: Optional[str] = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[IntegrationView]:
        """
        List integrations with filters

        Returns:
            List[IntegrationView]: List of view models combining integration and app marketplace data
        """
        with self.get_session() as session:
            query_str = """
                SELECT
                    ie.id,
                    ie.tenant_id,
                    ie.app_id,
                    ae.apps,
                    ae.auth_type,
                    ie.status,
                    ie.configuration,
                    ie.identifier,
                    ie.user_id,
                    ie.created_at,
                    ie.updated_at,
                    ae.provider,
                    ae.app_key
                FROM integration_entity ie
                LEFT JOIN app_marketplace_entity ae ON ie.app_id = ae.id
                WHERE 1=1
            """
            params = {}

            if tenant_id:
                query_str += " AND ie.tenant_id = :tenant_id"
                params["tenant_id"] = tenant_id

            if app_id:
                query_str += " AND ie.app_id = :app_id"
                params["app_id"] = app_id

            if status:
                query_str += " AND ie.status = :status"
                params["status"] = status

            query_str += " ORDER BY ie.created_at DESC LIMIT :limit OFFSET :offset"
            params["limit"] = limit
            params["offset"] = offset

            results = session.execute(text(query_str), params).fetchall()

            return [
                IntegrationView(
                    id=row[0],
                    tenant_id=row[1],
                    app_id=row[2],
                    app_name=Apps.get_name(row[3]) if row[3] else "Unknown",
                    auth_type=row[4],
                    status=row[5],
                    configuration=row[6],
                    identifier=row[7],
                    user_id=row[8],
                    created_at=row[9],
                    updated_at=row[10],
                    provider=row[11],
                    app_key=row[12]
                )
                for row in results
            ]

    def get_credential_by_id(self, credential_id: int) -> Optional[CredentialView]:
        """
        Get credential by ID and parse the encrypted value field

        Note: credential_entity.value is an encrypted JSON string.
        This method returns a CredentialView with parsed values if decryption is possible.
        In most cases, credentials are encrypted and can only be decrypted by TPS service.

        Returns:
            CredentialView: View model with parsed credential data (if decryption possible)
        """
        with self.get_session() as session:
            query = text("""
                SELECT
                    id,
                    tenant_id,
                    name,
                    status,
                    type,
                    value,
                    created_at,
                    updated_at
                FROM credential_entity
                WHERE id = :credential_id
            """)

            result = session.execute(query, {"credential_id": credential_id}).fetchone()

            if result:
                # Try to parse JSON value field (will fail if encrypted)
                import json
                value_json = {}
                try:
                    value_json = json.loads(result[5]) if result[5] else {}
                except:
                    # Value is encrypted, cannot parse
                    pass

                return CredentialView(
                    id=result[0],
                    tenant_id=result[1],
                    name=result[2],
                    type=result[4],
                    access_token=value_json.get('access_token') or value_json.get('accessToken'),
                    refresh_token=value_json.get('refresh_token') or value_json.get('refreshToken'),
                    expires_at=value_json.get('expires_at') or value_json.get('expiresAt'),
                    client_id=value_json.get('client_id') or value_json.get('clientId'),
                    client_secret=value_json.get('client_secret') or value_json.get('clientSecret'),
                    api_key=value_json.get('api_key') or value_json.get('apiKey'),
                    username=value_json.get('username'),
                    password=value_json.get('password'),
                    additional_config=value_json,
                    created_at=result[6],
                    updated_at=result[7]
                )
            return None

    def get_integration_with_credential(
        self,
        integration_id: int
    ) -> Optional[Tuple[IntegrationView, Optional[CredentialView]]]:
        """
        Get integration with its credential (if credential_entity has data)

        Note: Most integrations store encrypted credentials in integration_entity.configuration
        field, not in separate credential_entity table.

        Returns:
            Tuple of (IntegrationView, CredentialView or None)
        """
        integration = self.get_integration_by_id(integration_id)
        if not integration:
            return None

        # Check if integration has encrypted credentials in configuration field
        if integration.has_encrypted_credentials:
            # Credentials are encrypted in integration.configuration
            # Cannot be decrypted without TPS service
            return (integration, None)

        # Try to find credential in credential_entity table (rarely used)
        # This is a legacy path - most integrations don't use this table
        credential = None

        return (integration, credential)

    def get_app_marketplace_by_id(self, app_id: int) -> Optional[AppMarketplaceEntity]:
        """
        Get app marketplace entity by ID

        Returns:
            AppMarketplaceEntity: App marketplace entity model
        """
        with self.get_session() as session:
            query = text("""
                SELECT
                    id,
                    apps,
                    meta,
                    auth_type,
                    is_install_req,
                    category,
                    provider,
                    is_internal_app,
                    app_key,
                    parent_id,
                    app_group,
                    are_multiple_integrations_allowed,
                    created_at,
                    updated_at
                FROM app_marketplace_entity
                WHERE id = :app_id
            """)

            result = session.execute(query, {"app_id": app_id}).fetchone()

            if result:
                return AppMarketplaceEntity(
                    id=result[0],
                    apps=result[1],
                    meta=result[2],
                    auth_type=result[3],
                    is_install_req=result[4],
                    category=result[5],
                    provider=result[6],
                    is_internal_app=result[7],
                    app_key=result[8],
                    parent_id=result[9],
                    app_group=result[10],
                    are_multiple_integrations_allowed=result[11],
                    created_at=result[12],
                    updated_at=result[13]
                )
            return None

    def get_app_marketplace_by_name(self, app_name: str) -> Optional[AppMarketplaceEntity]:
        """
        Get app marketplace entity by app_key

        Returns:
            AppMarketplaceEntity: App marketplace entity model
        """
        with self.get_session() as session:
            query = text("""
                SELECT
                    id,
                    apps,
                    meta,
                    auth_type,
                    is_install_req,
                    category,
                    provider,
                    is_internal_app,
                    app_key,
                    parent_id,
                    app_group,
                    are_multiple_integrations_allowed,
                    created_at,
                    updated_at
                FROM app_marketplace_entity
                WHERE app_key = :app_name
            """)

            result = session.execute(query, {"app_name": app_name}).fetchone()

            if result:
                return AppMarketplaceEntity(
                    id=result[0],
                    apps=result[1],
                    meta=result[2],
                    auth_type=result[3],
                    is_install_req=result[4],
                    category=result[5],
                    provider=result[6],
                    is_internal_app=result[7],
                    app_key=result[8],
                    parent_id=result[9],
                    app_group=result[10],
                    are_multiple_integrations_allowed=result[11],
                    created_at=result[12],
                    updated_at=result[13]
                )
            return None

    def is_token_expired(self, credential_id: int, buffer_seconds: int = 20) -> bool:
        """
        Check if token is expired

        Args:
            credential_id: Credential ID
            buffer_seconds: Buffer time before expiration (default 20s like Java)

        Returns:
            True if token is expired or will expire soon
        """
        credential = self.get_credential_by_id(credential_id)
        if not credential or not credential.expires_at:
            return True

        import time
        current_time_seconds = int(time.time())
        remaining_seconds = credential.expires_at - current_time_seconds

        return remaining_seconds < buffer_seconds

    def close(self):
        """Close database connection"""
        self.engine.dispose()
