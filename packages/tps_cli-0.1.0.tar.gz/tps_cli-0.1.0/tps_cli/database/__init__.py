"""Database access layer"""

from .integration_repository import IntegrationRepository

__all__ = ["IntegrationRepository"]
