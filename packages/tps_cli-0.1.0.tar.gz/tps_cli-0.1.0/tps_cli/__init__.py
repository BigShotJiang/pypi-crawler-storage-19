"""TPS CLI - Third-Party App Integration Service Testing CLI"""

__version__ = "0.1.0"
