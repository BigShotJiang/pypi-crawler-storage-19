"""
SecretKeeper - Python implementation matching Java SecretKeeper.java

This module provides AES encryption/decryption functionality that matches
the TPS backend implementation in SecretKeeper.java
"""

import os
import base64
import json
from typing import Optional, Dict, Any
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad


class SecretKeeper:
    """
    Handles encryption and decryption of credentials using AES algorithm.

    This matches the Java implementation in:
    com.atomicwork.thirdpartyappintegration.core.misc.SecretKeeper

    Environment Variables:
        ATOMIC_SECRET: The encryption key (32 bytes for AES-256)
                      Falls back to default key if not set
    """

    ALGORITHM = "AES"
    # Default key from Java SecretKeeper.java
    DEFAULT_KEY = "t7w!z%C*F-JaNdRgUjXn2r5u8x/A?D(G"

    def __init__(self, secret_key: Optional[str] = None):
        """
        Initialize SecretKeeper with encryption key

        Args:
            secret_key: Optional encryption key. If not provided, uses ATOMIC_SECRET env var
                       or falls back to default key
        """
        if secret_key:
            self.key = secret_key.encode('utf-8')
        else:
            self.key = os.getenv('ATOMIC_SECRET', self.DEFAULT_KEY).encode('utf-8')

    def encrypt(self, value: str) -> str:
        """
        Encrypt a string value using AES

        Args:
            value: Plain text string to encrypt

        Returns:
            Base64 encoded encrypted string

        Raises:
            Exception: If encryption fails
        """
        try:
            # Create AES cipher in ECB mode (matching Java implementation)
            cipher = AES.new(self.key, AES.MODE_ECB)

            # Pad the value to AES block size (16 bytes)
            padded_value = pad(value.encode('utf-8'), AES.block_size)

            # Encrypt
            encrypted_bytes = cipher.encrypt(padded_value)

            # Encode to base64 (matching Java's DatatypeConverter.printBase64Binary)
            encrypted_base64 = base64.b64encode(encrypted_bytes).decode('utf-8')

            return encrypted_base64
        except Exception as e:
            raise Exception(f"Error while encrypting the value: {str(e)}")

    def decrypt(self, encrypted_value: str) -> str:
        """
        Decrypt a base64 encoded encrypted string

        Args:
            encrypted_value: Base64 encoded encrypted string

        Returns:
            Decrypted plain text string

        Raises:
            Exception: If decryption fails
        """
        try:
            # Decode from base64 (matching Java's DatatypeConverter.parseBase64Binary)
            encrypted_bytes = base64.b64decode(encrypted_value)

            # Create AES cipher in ECB mode (matching Java implementation)
            cipher = AES.new(self.key, AES.MODE_ECB)

            # Decrypt
            decrypted_bytes = cipher.decrypt(encrypted_bytes)

            # Unpad to get original value
            unpadded_value = unpad(decrypted_bytes, AES.block_size)

            # Decode to string
            decrypted_value = unpadded_value.decode('utf-8')

            return decrypted_value
        except Exception as e:
            raise Exception(f"Error while decrypting the value: {str(e)}")

    def decrypt_json(self, encrypted_value: str) -> Dict[str, Any]:
        """
        Decrypt an encrypted JSON string and parse it

        Args:
            encrypted_value: Base64 encoded encrypted JSON string

        Returns:
            Parsed JSON object as dictionary

        Raises:
            Exception: If decryption or JSON parsing fails
        """
        try:
            decrypted_str = self.decrypt(encrypted_value)
            return json.loads(decrypted_str)
        except json.JSONDecodeError as e:
            raise Exception(f"Error parsing decrypted JSON: {str(e)}")
        except Exception as e:
            raise Exception(f"Error decrypting JSON: {str(e)}")

    def encrypt_json(self, value: Dict[str, Any]) -> str:
        """
        Serialize a dictionary to JSON and encrypt it

        Args:
            value: Dictionary to encrypt

        Returns:
            Base64 encoded encrypted JSON string

        Raises:
            Exception: If JSON serialization or encryption fails
        """
        try:
            json_str = json.dumps(value)
            return self.encrypt(json_str)
        except Exception as e:
            raise Exception(f"Error encrypting JSON: {str(e)}")
