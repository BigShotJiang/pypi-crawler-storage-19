"""Output formatting utilities using Rich"""

import json
from typing import Any, List, Dict, Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich.json import JSON


console = Console()


def print_json(data: Any):
    """Print data as formatted JSON"""
    console.print(JSON(json.dumps(data, indent=2, default=str)))


def print_table(
    data: List[Dict[str, Any]],
    title: Optional[str] = None,
    columns: Optional[List[str]] = None
):
    """
    Print data as a formatted table

    Args:
        data: List of dictionaries to display
        title: Optional table title
        columns: Optional list of column names (uses all keys if not provided)
    """
    if not data:
        console.print("[yellow]No data to display[/yellow]")
        return

    # Create table
    table = Table(title=title, show_header=True, header_style="bold cyan")

    # Determine columns
    if columns is None:
        columns = list(data[0].keys())

    # Add columns
    for col in columns:
        table.add_column(col.replace("_", " ").title(), style="white")

    # Add rows
    for item in data:
        row = [str(item.get(col, "")) for col in columns]
        table.add_row(*row)

    console.print(table)


def print_panel(content: str, title: str, border_style: str = "blue"):
    """Print content in a bordered panel"""
    console.print(Panel(content, title=title, border_style=border_style))


def print_success(message: str):
    """Print success message"""
    console.print(f"[green]✓[/green] {message}")


def print_error(message: str):
    """Print error message"""
    console.print(f"[red]✗[/red] {message}")


def print_warning(message: str):
    """Print warning message"""
    console.print(f"[yellow]⚠[/yellow] {message}")


def print_debug(message: str):
    """Print debug message"""
    console.print(f"[dim]{message}[/dim]")


def print_info(message: str):
    """Print info message"""
    console.print(f"[blue]ℹ[/blue] {message}")


def print_integration_details(integration: Dict[str, Any], credential: Optional[Dict[str, Any]] = None):
    """Print detailed integration information"""
    from ..models import AuthType, IntegrationStatus

    # Handle new API response structure
    app_detail = integration.get('app_detail', {})

    # Extract app info
    app_name = app_detail.get('app_name', integration.get('app_name', 'Unknown'))
    app_id = app_detail.get('id', integration.get('app_id', 'N/A'))

    # Format auth type
    auth_type = app_detail.get('auth_type', integration.get('auth_type'))
    if isinstance(auth_type, int):
        try:
            auth_type_name = AuthType(auth_type).name
        except:
            auth_type_name = f"Type {auth_type}"
    else:
        auth_type_name = str(auth_type) if auth_type else 'N/A'

    # Format status (new API uses 'integration_status', old uses 'status')
    status = integration.get('integration_status', integration.get('status'))
    if isinstance(status, int):
        status_text = IntegrationStatus.get_name(status)
    else:
        status_text = str(status) if status else 'N/A'

    # Tenant ID (may not be in API response, default to 2)
    tenant_id = integration.get('tenant_id', 2)

    content = f"""[cyan]ID:[/cyan] {integration.get('id')}
[cyan]Tenant ID:[/cyan] {tenant_id}
[cyan]App:[/cyan] {app_name} (ID: {app_id})
[cyan]Auth Type:[/cyan] {auth_type_name}
[cyan]Status:[/cyan] {status_text}
[cyan]Credential ID:[/cyan] {integration.get('credential_id', 'N/A')}
[cyan]Created:[/cyan] {integration.get('created_at')}
[cyan]Updated:[/cyan] {integration.get('update_at', integration.get('updated_at', 'N/A'))}
"""

    if credential:
        content += f"\n[bold]Credential Details:[/bold]\n"
        content += f"[cyan]Access Token:[/cyan] {'***' + credential.get('access_token', '')[-10:] if credential.get('access_token') else 'N/A'}\n"
        content += f"[cyan]Refresh Token:[/cyan] {'***' if credential.get('refresh_token') else 'N/A'}\n"
        content += f"[cyan]Expires At:[/cyan] {credential.get('expires_at')}\n"

        # Check if expired
        if credential.get('expires_at'):
            import time
            current_time = int(time.time())
            expires_at = credential.get('expires_at')
            is_expired = expires_at < current_time
            remaining = expires_at - current_time

            if is_expired:
                content += f"[red]Token Status:[/red] EXPIRED\n"
            elif remaining < 300:  # Less than 5 minutes
                content += f"[yellow]Token Status:[/yellow] Expiring soon ({remaining}s remaining)\n"
            else:
                content += f"[green]Token Status:[/green] Valid ({remaining}s remaining)\n"

    print_panel(content, title=f"Integration #{integration.get('id')}")
