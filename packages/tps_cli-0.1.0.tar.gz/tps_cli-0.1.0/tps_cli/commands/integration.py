"""Integration testing commands"""

import typer
from typing import Optional
from rich.console import Console

from ..config import load_config
from ..database import IntegrationRepository
from ..client import TPSClient
from ..auth import WorkdayOAuthHandler, InstallSettingsRequest, TokenRequest
from ..models import AuthType, IntegrationStatus
from ..utils import (
    print_json,
    print_table,
    print_success,
    print_error,
    print_info,
    print_warning,
    print_integration_details,
    SecretKeeper
)


app = typer.Typer(help="Integration testing commands")
console = Console()


@app.command("list")
def list_integrations(
    tenant_id: Optional[int] = typer.Option(None, "--tenant-id", "-t", help="Filter by tenant ID"),
    app_id: Optional[int] = typer.Option(None, "--app-id", "-a", help="Filter by app ID"),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status"),
    limit: int = typer.Option(50, "--limit", "-l", help="Number of results"),
    offset: int = typer.Option(0, "--offset", "-o", help="Pagination offset"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    use_db: bool = typer.Option(False, "--db", help="Query database directly (bypass TPS service)"),
):
    """
    List integrations via TPS service (default) or database

    By default, this uses the TPS service API. Use --db to query the database directly.

    Examples:
        tps integration list                          # Via TPS service (default)
        tps integration list --tenant-id 1 --status ACTIVE
        tps integration list --db                     # Direct database query
        tps integration list --api --json
    """
    try:
        config = load_config()
        profile = config.get_active_profile()

        if use_db:
            # Query database directly (bypass TPS service)
            print_info("Querying database directly...")
            repo = IntegrationRepository(profile.database.connection_string)
            integration_views = repo.list_integrations(
                tenant_id=tenant_id,
                app_id=app_id,
                status=status,
                limit=limit,
                offset=offset
            )
            integrations = [i.model_dump() for i in integration_views]
            repo.close()
        else:
            # Use TPS API (default)
            # The API doesn't return tenant_id in response (it's in the request header)
            request_tenant_id = tenant_id or 2
            client = TPSClient(profile.tps_service.url, tenant_id=request_tenant_id)
            # Note: OpenAPI spec only supports app_id parameter
            # status, limit, offset are not in the spec
            result = client.list_integrations(app_id=app_id)
            integrations = result.get('data', result) if isinstance(result, dict) else result

        if json_output:
            print_json(integrations)
        else:
            if integrations:
                # Format for display with human-readable values
                display_data = []
                for integration in integrations:
                    # Convert to dict if it's a model
                    if hasattr(integration, 'model_dump'):
                        int_dict = integration.model_dump()
                    else:
                        int_dict = integration

                    # Handle new API response structure
                    # API returns: {id, config, meta, integration_status, app_detail, created_at, ...}
                    app_detail = int_dict.get('app_detail', {})

                    # Tenant ID: Use from response if available (DB query), otherwise use request tenant_id (API)
                    display_tenant_id = int_dict.get('tenant_id')
                    if display_tenant_id is None and not use_db:
                        # When using API, tenant_id is not in response, use the one from request
                        display_tenant_id = tenant_id or 2

                    display_data.append({
                        'id': int_dict['id'],
                        'tenant_id': display_tenant_id if display_tenant_id is not None else 'N/A',
                        'app_name': app_detail.get('app_name', int_dict.get('app_name', 'Unknown')),
                        'auth_type': app_detail.get('auth_type', int_dict.get('auth_type', 'Unknown')),
                        'status': int_dict.get('integration_status', int_dict.get('status', 'Unknown')),
                        'created_at': str(int_dict.get('created_at', ''))[:19] if int_dict.get('created_at') else ''
                    })

                print_table(
                    display_data,
                    title="Integrations",
                    columns=["id", "tenant_id", "app_name", "auth_type", "status", "created_at"]
                )
                console.print(f"\n[dim]Total: {len(integrations)} integrations[/dim]")
            else:
                print_info("No integrations found")

    except Exception as e:
        print_error(f"Failed to list integrations: {str(e)}")
        if hasattr(e, 'response'):
            print_error(f"Response: {e.response.text}")
        raise typer.Exit(1)


@app.command("get")
def get_integration(
    integration_id: int = typer.Argument(..., help="Integration ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
    show_credential: bool = typer.Option(False, "--with-credential", "-c", help="Include credential details"),
    use_db: bool = typer.Option(False, "--db", help="Query database directly (bypass TPS service)"),
):
    """
    Get integration details by ID via TPS service (default) or database

    By default, this uses the TPS service API which returns decrypted configuration.
    Use --db to query the database directly (credentials will be encrypted).

    Examples:
        tps integration get 123                    # Via TPS service (decrypted)
        tps integration get 123 --with-credential
        tps integration get 123 --db               # Direct database (encrypted)
        tps integration get 123 --json
    """
    try:
        config = load_config()
        profile = config.get_active_profile()

        if use_db:
            # Query database directly (bypass TPS service)
            print_info("Querying database directly...")
            repo = IntegrationRepository(profile.database.connection_string)

            if show_credential:
                result = repo.get_integration_with_credential(integration_id)
                if not result:
                    print_error(f"Integration {integration_id} not found")
                    raise typer.Exit(1)

                integration_view, credential_view = result
                integration = integration_view.model_dump()
                credential = credential_view.model_dump() if credential_view else None
            else:
                integration_view = repo.get_integration_by_id(integration_id)
                if not integration_view:
                    print_error(f"Integration {integration_id} not found")
                    raise typer.Exit(1)

                integration = integration_view.model_dump()
                credential = None

            repo.close()
        else:
            # Use TPS API (default) - returns decrypted configuration
            client = TPSClient(profile.tps_service.url, tenant_id=2)
            integration = client.get_integration(integration_id)
            credential = None

            if show_credential and integration.get('credential_id'):
                try:
                    credential = client.get_credential(integration['credential_id'])
                except:
                    # Credential API might not be available
                    pass

        if json_output:
            data = {"integration": integration}
            if credential:
                data["credential"] = credential
            print_json(data)
        else:
            print_integration_details(integration, credential)

    except Exception as e:
        print_error(f"Failed to get integration: {str(e)}")
        if hasattr(e, 'response'):
            print_error(f"Response: {e.response.text}")
        raise typer.Exit(1)


@app.command("check-token")
def check_token_expiration(
    integration_id: int = typer.Argument(..., help="Integration ID"),
):
    """
    Check if integration token is expired

    NOTE: Credentials are encrypted in the database. This command
    cannot decrypt them directly. Use TPS API to check token status.

    Examples:
        tps integration check-token 123
    """
    try:
        config = load_config()
        profile = config.get_active_profile()

        repo = IntegrationRepository(profile.database.connection_string)
        integration_view = repo.get_integration_by_id(integration_id)

        if not integration_view:
            print_error(f"Integration {integration_id} not found")
            raise typer.Exit(1)

        # Check if configuration exists (encrypted credentials)
        if integration_view.has_encrypted_credentials:
            print_info(f"Integration {integration_id} has encrypted credentials in configuration")
            print_warning("Cannot check token expiration directly (credentials are encrypted)")
            print_info("Suggestion: Use TPS API endpoint to check token status:")
            console.print(f"  [cyan]curl {profile.tps_service.url}/api/management/integrations/{integration_id}[/cyan]")
            repo.close()
            return

        # If no encrypted credentials, integration hasn't completed OAuth flow
        print_error(f"Integration {integration_id} has no credentials")
        print_info("The integration exists but OAuth flow hasn't been completed yet")
        repo.close()
        raise typer.Exit(1)

    except Exception as e:
        print_error(f"Failed to check token: {str(e)}")
        raise typer.Exit(1)


@app.command("generate-auth-url")
def generate_auth_url(
    app_name: str = typer.Argument(..., help="App name (e.g., 'workday', 'slack', 'azure_ad')"),
    redirect_url: str = typer.Option(..., "--redirect-url", help="OAuth redirect URL"),
    state: str = typer.Option("test-state", "--state", help="OAuth state parameter"),
    tenant_name: Optional[str] = typer.Option(None, "--tenant-name", help="Tenant name (for Workday)"),
    authorization_url: Optional[str] = typer.Option(None, "--auth-url", help="Authorization base URL (for Workday)"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL (for Workday)"),
):
    """
    Generate OAuth authorization URL for app installation

    This command calls the TPS service to generate the authorization URL.
    The TPS service handles all app-specific OAuth logic.

    Examples:
        # Workday
        tps integration generate-auth-url workday \\
            --redirect-url "http://localhost:8093/callback" \\
            --tenant-name "my_tenant" \\
            --auth-url "https://wd2-impl-services1.workday.com" \\
            --api-url "https://wd2-impl-services1.workday.com"

        # Slack, Azure AD, etc. (simpler - no extra config needed)
        tps integration generate-auth-url slack \\
            --redirect-url "http://localhost:8093/callback"
    """
    try:
        config = load_config()
        profile = config.get_active_profile()

        # Get app ID from marketplace
        client = TPSClient(profile.tps_service.url, tenant_id=2)

        print_info(f"Looking up app '{app_name}' in marketplace...")
        app = client.get_app_by_name(app_name.upper())
        app_id = app["id"]

        print_info(f"Found app: {app['app_name']} (ID: {app_id})")

        # Build app-specific config
        app_config = {}
        if app_name.lower() == "workday":
            if not tenant_name or not authorization_url or not api_url:
                print_error("Workday requires --tenant-name, --auth-url, and --api-url")
                raise typer.Exit(1)
            app_config = {
                "app_name": app_name.upper(),  # Required by AppSpecificInstallSettings schema
                "tenant_name": tenant_name,
                "authorization_base_url": authorization_url,
                "rest_api_base_url": api_url
            }

        # Call TPS service to generate OAuth URL
        print_info("Generating authorization URL via TPS service...")
        response = client.generate_install_url(
            app_id=app_id,
            redirect_uri=redirect_url,
            state=state,
            config=app_config if app_config else None
        )

        print_success("Generated authorization URL:")
        console.print(f"\n[cyan]{response['full_uri']}[/cyan]\n")
        print_info("Copy this URL and open it in your browser to authorize the app")

    except Exception as e:
        print_error(f"Failed to generate auth URL: {str(e)}")
        if hasattr(e, 'response'):
            print_error(f"Response: {e.response.text}")
        raise typer.Exit(1)


@app.command("exchange-token")
def exchange_token(
    app_name: str = typer.Argument(..., help="App name (e.g., 'workday')"),
    code: str = typer.Option(..., "--code", help="Authorization code from OAuth callback"),
    client_id: str = typer.Option(..., "--client-id", help="OAuth client ID"),
    client_secret: str = typer.Option(..., "--client-secret", help="OAuth client secret"),
    redirect_url: str = typer.Option(..., "--redirect-url", help="OAuth redirect URL"),
    tenant_name: Optional[str] = typer.Option(None, "--tenant-name", help="Tenant name (for Workday)"),
    authorization_url: Optional[str] = typer.Option(None, "--auth-url", help="Authorization base URL"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Exchange authorization code for access token

    Examples:
        tps integration exchange-token workday \\
            --code "auth_code_from_callback" \\
            --client-id "abc123" \\
            --client-secret "secret" \\
            --redirect-url "http://localhost:8093/callback" \\
            --tenant-name "my_tenant" \\
            --auth-url "https://wd2-impl-services1.workday.com" \\
            --api-url "https://wd2-impl-services1.workday.com"
    """
    try:
        config = load_config()
        profile = config.get_active_profile()

        # Build app-specific config
        app_config = {}
        if app_name.lower() == "workday":
            if not tenant_name or not authorization_url or not api_url:
                print_error("Workday requires --tenant-name, --auth-url, and --api-url")
                raise typer.Exit(1)
            app_config = {
                "tenant_name": tenant_name,
                "authorization_base_url": authorization_url,
                "rest_api_base_url": api_url,
                "client_id": client_id,
                "client_secret": client_secret
            }

        # Call TPS service to exchange code for token
        client = TPSClient(profile.tps_service.url, tenant_id=2, user_id=1)

        print_info(f"Exchanging authorization code via TPS service...")
        response = client.exchange_code_for_token(
            app_provider="NATIVE",
            code=code,
            redirect_uri=redirect_url,
            created_by=1,
            config=app_config if app_config else None
        )

        if json_output:
            print_json(response)
        else:
            print_success("Successfully exchanged code for tokens!")
            access_token = response.get("access_token", "")
            console.print(f"\n[cyan]Access Token:[/cyan] {'***' + access_token[-20:] if len(access_token) > 20 else '***'}")
            console.print(f"[cyan]Refresh Token:[/cyan] {'***' if response.get('refresh_token') else 'N/A'}")
            console.print(f"[cyan]Expires At:[/cyan] {response.get('expires_at', 'N/A')}")
            console.print(f"[cyan]Token Type:[/cyan] {response.get('token_type', 'Bearer')}\n")

    except Exception as e:
        print_error(f"Failed to exchange token: {str(e)}")
        if hasattr(e, 'response'):
            print_error(f"Response: {e.response.text}")
        raise typer.Exit(1)


@app.command("refresh-token")
def refresh_token_cmd(
    app_name: str = typer.Argument(..., help="App name (e.g., 'workday')"),
    refresh_token: str = typer.Option(..., "--refresh-token", help="Refresh token"),
    client_id: str = typer.Option(..., "--client-id", help="OAuth client ID"),
    client_secret: str = typer.Option(..., "--client-secret", help="OAuth client secret"),
    tenant_name: Optional[str] = typer.Option(None, "--tenant-name", help="Tenant name (for Workday)"),
    authorization_url: Optional[str] = typer.Option(None, "--auth-url", help="Authorization base URL"),
    api_url: Optional[str] = typer.Option(None, "--api-url", help="API base URL"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Refresh access token using refresh token

    Examples:
        tps integration refresh-token workday \\
            --refresh-token "refresh_token_value" \\
            --client-id "abc123" \\
            --client-secret "secret" \\
            --tenant-name "my_tenant" \\
            --auth-url "https://wd2-impl-services1.workday.com" \\
            --api-url "https://wd2-impl-services1.workday.com"
    """
    try:
        config = load_config()
        profile = config.get_active_profile()

        # Build app-specific config
        app_config = {}
        if app_name.lower() == "workday":
            if not tenant_name or not authorization_url or not api_url:
                print_error("Workday requires --tenant-name, --auth-url, and --api-url")
                raise typer.Exit(1)
            app_config = {
                "tenant_name": tenant_name,
                "authorization_base_url": authorization_url,
                "rest_api_base_url": api_url,
                "client_id": client_id,
                "client_secret": client_secret
            }

        # Call TPS service to refresh token
        client = TPSClient(profile.tps_service.url, tenant_id=2, user_id=1)

        print_info(f"Refreshing access token via TPS service...")
        response = client.refresh_access_token(
            app_provider="NATIVE",
            refresh_token=refresh_token,
            created_by=1,
            config=app_config if app_config else None
        )

        if json_output:
            print_json(response)
        else:
            print_success("Successfully refreshed token!")
            access_token = response.get("access_token", "")
            console.print(f"\n[cyan]New Access Token:[/cyan] {'***' + access_token[-20:] if len(access_token) > 20 else '***'}")
            console.print(f"[cyan]New Refresh Token:[/cyan] {'***' if response.get('refresh_token') else 'N/A'}")
            console.print(f"[cyan]Expires At:[/cyan] {response.get('expires_at', 'N/A')}")
            console.print(f"[cyan]Token Type:[/cyan] {response.get('token_type', 'Bearer')}\n")

    except Exception as e:
        print_error(f"Failed to refresh token: {str(e)}")
        if hasattr(e, 'response'):
            print_error(f"Response: {e.response.text}")
        raise typer.Exit(1)


@app.command("is-cache-enabled")
def is_cache_enabled(
    app_name: str = typer.Argument(..., help="App name (e.g., 'workday')"),
):
    """
    Check if token caching is enabled for an integration

    Examples:
        tps integration is-cache-enabled workday
    """
    try:
        if app_name.lower() == "workday":
            handler = WorkdayOAuthHandler(
                authorization_base_url="",  # Not needed for this check
                rest_api_base_url="",
                tenant_name="",
                verbose=False
            )

            cache_enabled = handler.is_cache_enabled()

            if cache_enabled:
                print_success(f"Token caching is ENABLED for {app_name}")
            else:
                print_info(f"Token caching is DISABLED for {app_name}")
                print_info("(This is expected for Workday due to refresh token rotation)")

        else:
            print_error(f"Unsupported app: {app_name}. Currently only 'workday' is supported.")
            raise typer.Exit(1)

    except Exception as e:
        print_error(f"Failed to check cache status: {str(e)}")
        raise typer.Exit(1)


@app.command("decrypt-config")
def decrypt_config(
    integration_id: int = typer.Argument(..., help="Integration ID"),
    secret_key: Optional[str] = typer.Option(None, "--secret-key", "-k", help="ATOMIC_SECRET encryption key (optional)"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    Decrypt integration configuration field

    This command decrypts the encrypted credentials stored in the configuration field.
    Requires ATOMIC_SECRET environment variable or --secret-key option.

    Examples:
        tps integration decrypt-config 1
        tps integration decrypt-config 1 --secret-key "your-secret-key"
        tps integration decrypt-config 1 --json
    """
    try:
        config = load_config()
        profile = config.get_active_profile()

        # Get encryption key
        if secret_key:
            encryption_key = secret_key
        else:
            encryption_key = profile.security.encryption_key

        # Initialize SecretKeeper
        keeper = SecretKeeper(secret_key=encryption_key)

        # Get integration from database
        repo = IntegrationRepository(profile.database.connection_string)
        integration_view = repo.get_integration_by_id(integration_id)

        if not integration_view:
            print_error(f"Integration {integration_id} not found")
            raise typer.Exit(1)

        if not integration_view.has_encrypted_credentials:
            print_error(f"Integration {integration_id} has no encrypted credentials")
            repo.close()
            raise typer.Exit(1)

        # Decrypt configuration
        try:
            decrypted_config = keeper.decrypt_json(integration_view.configuration)
            repo.close()

            if json_output:
                print_json({
                    "integration_id": integration_id,
                    "app_name": integration_view.app_name,
                    "decrypted_configuration": decrypted_config
                })
            else:
                print_success(f"Successfully decrypted configuration for integration {integration_id}")
                console.print(f"\n[cyan]App:[/cyan] {integration_view.app_name}")
                console.print(f"[cyan]Status:[/cyan] {integration_view.status_text}")
                console.print(f"\n[bold]Decrypted Configuration:[/bold]")
                print_json(decrypted_config)

        except Exception as decrypt_error:
            repo.close()
            print_error(f"Failed to decrypt configuration: {str(decrypt_error)}")
            print_warning("Make sure you have the correct ATOMIC_SECRET key")
            print_info("You can set it via:")
            console.print(f"  [cyan]export ATOMIC_SECRET='your-secret-key'[/cyan]")
            console.print(f"  [cyan]tps integration decrypt-config {integration_id} --secret-key 'your-secret-key'[/cyan]")
            raise typer.Exit(1)

    except Exception as e:
        print_error(f"Failed to decrypt config: {str(e)}")
        raise typer.Exit(1)


@app.command("install")
def install_integration(
    app_id: int = typer.Argument(..., help="App ID from marketplace (e.g., 32 for Workday)"),
    config_json: str = typer.Option(..., "--config", help="App configuration as JSON string"),
    tenant_id: Optional[int] = typer.Option(None, "--tenant-id", "-t", help="Tenant ID (default: 2)"),
    user_id: Optional[int] = typer.Option(None, "--user-id", "-u", help="User ID for X-User-ID header"),
    admin_consent: bool = typer.Option(False, "--admin-consent", help="Admin consent flag"),
    local_port: int = typer.Option(8765, "--port", help="Local port for OAuth callback (default: 8765)"),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't automatically open browser"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """
    End-to-end integration installation with automatic OAuth callback handling

    This command performs the complete OAuth flow:
    1. Starts a local HTTP server to receive OAuth callback
    2. Generates OAuth authorization URL with local redirect
    3. Opens URL in browser for user authentication
    4. Automatically captures authorization code from callback
    5. Creates the integration using the code

    The config JSON must match the app's schema (validated by TPS service).

    Examples:
        # Workday (app_id: 32)
        tps integration install 32 --config '{
            "app_name": "WORKDAY",
            "client_id": "your_client_id",
            "client_secret": "your_client_secret",
            "tenant_name": "ibmsrv_pt1",
            "authorization_base_url": "https://wd2-impl-services1.workday.com",
            "rest_api_base_url": "https://wd2-impl-services1.workday.com"
        }'

        # Azure AD (app_id: 3)
        tps integration install 3 --config '{
            "app_name": "AZURE_AD",
            "client_id": "your_client_id",
            "client_secret": "your_client_secret",
            "resource": "https://graph.microsoft.com"
        }'

        # Custom port and tenant
        tps integration install 32 --config '...' --port 9000 --tenant-id 1
    """
    import webbrowser
    import uuid
    import json
    from http.server import HTTPServer, BaseHTTPRequestHandler
    from urllib.parse import urlparse, parse_qs
    import threading

    # Parse config JSON
    try:
        app_config = json.loads(config_json)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON in --config: {e}")
        raise typer.Exit(1)

    # Shared state for callback
    callback_data = {"code": None, "state": None, "error": None, "received": threading.Event()}

    class CallbackHandler(BaseHTTPRequestHandler):
        def log_message(self, format, *args):
            pass  # Suppress default logging

        def do_GET(self):
            parsed = urlparse(self.path)
            params = parse_qs(parsed.query)

            callback_data["code"] = params.get("code", [None])[0]
            callback_data["state"] = params.get("state", [None])[0]
            callback_data["error"] = params.get("error", [None])[0]
            callback_data["received"].set()

            # Send response to browser
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()

            if callback_data["error"]:
                html = f"""
                <html><body style="font-family: Arial; text-align: center; padding: 50px;">
                    <h1 style="color: #d32f2f;">❌ Authorization Failed</h1>
                    <p>Error: {callback_data["error"]}</p>
                    <p style="color: #666;">You can close this window and check the terminal.</p>
                </body></html>
                """
            else:
                html = """
                <html><body style="font-family: Arial; text-align: center; padding: 50px;">
                    <h1 style="color: #4caf50;">✓ Authorization Successful!</h1>
                    <p>Authorization code received. You can close this window.</p>
                    <p style="color: #666;">The integration is being created...</p>
                </body></html>
                """
            self.wfile.write(html.encode())

    try:
        config = load_config()
        profile = config.get_active_profile()

        if not tenant_id:
            tenant_id = 2

        client = TPSClient(profile.tps_service.url, tenant_id=tenant_id)

        # Get app details
        print_info(f"Looking up app with ID {app_id}...")
        app = client.get_app(app_id)
        app_display_name = app.get("app_name", f"App {app_id}")

        print_success(f"Found app: {app_display_name} (ID: {app_id})")

        # Step 1: Start local callback server
        redirect_uri = f"http://localhost:{local_port}/callback"
        console.print(f"\n[bold cyan]Step 1: Starting local OAuth callback server[/bold cyan]")
        print_info(f"Listening on {redirect_uri}")

        server = HTTPServer(("localhost", local_port), CallbackHandler)
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()

        # Step 2: Generate OAuth authorization URL
        print_info("\nGenerating OAuth authorization URL...")
        state = str(uuid.uuid4())

        install_settings = client.generate_install_url(
            app_id=app_id,
            redirect_uri=redirect_uri,
            state=state,
            config=app_config
        )

        auth_url = install_settings.get("full_uri")
        if not auth_url:
            print_error("Failed to generate authorization URL")
            server.shutdown()
            raise typer.Exit(1)

        # Step 3: Open browser for user authentication
        console.print(f"\n[bold cyan]Step 2: Authorize the app in your browser[/bold cyan]")
        console.print(f"\nAuthorization URL:\n[cyan]{auth_url}[/cyan]\n")

        if not no_browser:
            print_info("Opening browser...")
            webbrowser.open(auth_url)
        else:
            print_info("Copy and paste the URL into your browser")

        console.print(f"\n[yellow]Waiting for OAuth callback...[/yellow]")
        console.print(f"[dim]The browser will redirect to {redirect_uri}[/dim]\n")

        # Step 4: Wait for callback (with timeout)
        received = callback_data["received"].wait(timeout=300)  # 5 minute timeout
        server.shutdown()

        if not received:
            print_error("Timeout waiting for OAuth callback")
            raise typer.Exit(1)

        if callback_data["error"]:
            print_error(f"OAuth error: {callback_data['error']}")
            raise typer.Exit(1)

        if not callback_data["code"]:
            print_error("No authorization code received")
            raise typer.Exit(1)

        auth_code = callback_data["code"]
        print_success(f"✓ Received authorization code: {auth_code[:20]}...")

        # Step 5: Install integration using the code
        console.print(f"\n[bold cyan]Step 3: Creating integration[/bold cyan]")
        print_info("Installing integration via TPS service...")

        integration = client.install_integration(
            app_id=app_id,
            code=auth_code,
            redirect_uri=redirect_uri,
            config=app_config,
            admin_consent=admin_consent,
            user_id=user_id
        )

        # Step 6: Display results
        if json_output:
            print_json(integration)
        else:
            print_success(f"\n✓ Integration created successfully!")
            console.print(f"\n[bold]Integration Details:[/bold]")
            console.print(f"[cyan]Integration ID:[/cyan] {integration.get('id')}")
            console.print(f"[cyan]App:[/cyan] {app_display_name}")
            console.print(f"[cyan]Tenant ID:[/cyan] {integration.get('tenant_id', tenant_id)}")
            console.print(f"[cyan]Status:[/cyan] {integration.get('integration_status', 'Unknown')}")
            console.print(f"[cyan]Created:[/cyan] {integration.get('created_at', 'N/A')}")

            if integration.get('credential_id'):
                console.print(f"[cyan]Credential ID:[/cyan] {integration.get('credential_id')}")

            console.print(f"\n[dim]View details: tps integration get {integration.get('id')}[/dim]")

    except Exception as e:
        print_error(f"Failed to install integration: {str(e)}")
        import traceback
        console.print(f"[dim]{traceback.format_exc()}[/dim]")
        raise typer.Exit(1)
