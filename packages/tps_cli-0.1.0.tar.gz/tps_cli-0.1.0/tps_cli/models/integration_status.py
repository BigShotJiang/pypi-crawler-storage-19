"""Integration status enum matching TPS backend"""

from enum import IntEnum


class IntegrationStatus(IntEnum):
    """
    Integration status enum
    Matches: com.atomicwork.thirdpartyappintegration.core.model.entity.enums.IntegrationStatus
    """
    INACTIVE = 1
    ACTIVE = 2
    DISABLED = 3
    MARKED_FOR_DELETION = 4
    HIDDEN = 5

    @classmethod
    def from_value(cls, value: int) -> "IntegrationStatus":
        """Create IntegrationStatus from integer value"""
        return cls(value)

    @classmethod
    def get_name(cls, value: int) -> str:
        """Get status name from value, or return Unknown"""
        try:
            return cls(value).name
        except ValueError:
            return f"Status_{value}"
