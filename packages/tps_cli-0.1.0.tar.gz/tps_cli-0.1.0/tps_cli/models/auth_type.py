"""Authentication type enum matching TPS backend"""

from enum import IntEnum


class AuthType(IntEnum):
    """
    Authentication types supported by TPS
    Matches: com.atomicwork.thirdpartyappintegration.core.model.entity.enums.AuthType
    """
    API_KEY = 1
    BASIC_AUTH = 2
    OAUTH2 = 3
    FORM_BASED_OAUTH2 = 4

    @classmethod
    def from_value(cls, value: int) -> "AuthType":
        """Create AuthType from integer value"""
        return cls(value)

    @classmethod
    def from_name(cls, name: str) -> "AuthType":
        """Create AuthType from string name"""
        return cls[name.upper()]
