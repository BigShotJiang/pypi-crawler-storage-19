"""Apps enum matching TPS backend"""

from enum import IntEnum


class Apps(IntEnum):
    """
    Apps enum
    Matches: com.atomicwork.thirdpartyappintegration.core.model.entity.enums.Apps
    """
    OKTA = 1
    SLACK = 2
    AZURE_AD = 3
    GOOGLE_WORKSPACE = 4
    CHECKR = 5
    NOTION = 6
    MS_TEAMS = 7
    MS_SHAREPOINT = 8
    AZURE_SSO_OIDC = 9
    HIBOB = 10
    BAMBOOHR = 11
    MS_INTUNE = 12
    GITHUB = 14
    ATOMICWORK = 15
    OKTA_SSO_SAML = 16
    JIRA = 17
    KANDJI = 19
    CONFLUENCE = 21
    SALESFORCE = 22
    O365_EMAIL = 23
    AZURE_DEVOPS = 24
    SPROUT = 25
    ORACLE_HCM = 26
    GOOGLE_DRIVE = 51
    JAMF = 52
    LANSWEEPER = 53
    WORKDAY = 54
    POWERBI = 55
    GOOGLE_SSO_SAML = 57
    DATADOG = 71
    PAGERDUTY = 72
    RIPPLING = 73
    MICROSOFT_SENTINEL = 74
    GOOGLE_SHEETS = 75
    JSM = 76
    ONEDRIVE = 77
    MS_OUTLOOK_CALENDAR = 81
    GOOGLE_CALENDAR = 82
    ZOOM = 83
    RAPID7 = 84

    @classmethod
    def from_value(cls, value: int) -> "Apps":
        """Create Apps from integer value"""
        return cls(value)

    @classmethod
    def get_name(cls, value: int) -> str:
        """Get app name from value, or return Unknown"""
        try:
            return cls(value).name
        except ValueError:
            return f"App_{value}"
