"""Integration models matching TPS database schema"""

from datetime import datetime
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field
from .auth_type import AuthType


class IntegrationEntity(BaseModel):
    """
    Integration entity model
    Matches: integration_entity table in TPS database

    Note: Credentials are stored encrypted in the 'configuration' field
    """
    id: Optional[int] = None
    tenant_id: int
    app_id: Optional[int] = None
    meta: Optional[str] = None  # JSON string or null
    configuration: str  # Encrypted credentials (base64 encoded)
    status: int  # smallint: 1=INACTIVE, 2=ACTIVE, 3=DISABLED, 4=MARKED_FOR_DELETION, 5=HIDDEN
    identifier: Optional[str] = None  # UUID string
    user_id: int = -1  # default -1
    parent_id: Optional[int] = None
    version: int = 0  # default 0
    created_by: Optional[int] = None
    updated_by: Optional[int] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        use_enum_values = True

    @property
    def status_text(self) -> str:
        """Get human-readable status"""
        from .integration_status import IntegrationStatus
        try:
            return IntegrationStatus(self.status).name
        except ValueError:
            return f"UNKNOWN({self.status})"

    @property
    def meta_dict(self) -> Optional[Dict[str, Any]]:
        """Parse meta JSON string to dict"""
        if not self.meta or self.meta == "null":
            return None
        try:
            import json
            return json.loads(self.meta)
        except:
            return None


class CredentialEntity(BaseModel):
    """
    Credential entity model
    Matches: credential_entity table in TPS database

    Note: Actual credentials are stored encrypted in the 'value' field as JSON string
    """
    id: Optional[int] = None
    tenant_id: int
    name: str  # Credential name
    status: int  # smallint: credential status
    type: int  # smallint: auth type (1=API_KEY, 2=BASIC_AUTH, 3=OAUTH2, 4=FORM_BASED_OAUTH2)
    value: str  # Encrypted JSON string containing actual credentials
    version: int = 0  # default 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        use_enum_values = True

    @property
    def value_dict(self) -> Optional[Dict[str, Any]]:
        """Parse value JSON string to dict"""
        if not self.value:
            return None
        try:
            import json
            return json.loads(self.value)
        except:
            return None


class AppMarketplaceEntity(BaseModel):
    """
    App marketplace entity model
    Matches: app_marketplace_entity table in TPS database
    """
    id: int
    apps: int  # smallint: app enum value (e.g., 54=WORKDAY)
    meta: str  # JSON string with app metadata
    auth_type: int  # smallint: auth type
    is_install_req: bool = False
    category: Optional[int] = 1  # default 1
    provider: int = 1  # smallint: 1=NATIVE, 2=INTEGRATION_APP, 3=NANGO
    is_internal_app: bool = False
    app_key: Optional[str] = None  # varchar(255)
    parent_id: Optional[int] = None
    app_group: int  # NOT NULL
    are_multiple_integrations_allowed: bool = False
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        use_enum_values = True

    @property
    def app_name(self) -> str:
        """Get app name from apps enum"""
        from .apps import Apps
        return Apps.get_name(self.apps)

    @property
    def meta_dict(self) -> Optional[Dict[str, Any]]:
        """Parse meta JSON string to dict"""
        if not self.meta:
            return None
        try:
            import json
            return json.loads(self.meta)
        except:
            return None


# View models for joined data (used by CLI)

class IntegrationView(BaseModel):
    """
    View model combining integration_entity and app_marketplace_entity
    This is what the CLI commands actually use
    """
    id: int
    tenant_id: int
    app_id: Optional[int] = None
    app_name: str  # Computed from app_marketplace_entity.apps
    auth_type: int  # From app_marketplace_entity.auth_type
    status: int  # From integration_entity.status
    configuration: str  # Encrypted credentials
    identifier: Optional[str] = None
    user_id: int = -1
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    # App marketplace fields (joined)
    provider: Optional[int] = None
    app_key: Optional[str] = None

    @property
    def status_text(self) -> str:
        """Get human-readable status"""
        from .integration_status import IntegrationStatus
        try:
            return IntegrationStatus(self.status).name
        except ValueError:
            return f"UNKNOWN({self.status})"

    @property
    def auth_type_name(self) -> str:
        """Get auth type name"""
        try:
            return AuthType(self.auth_type).name
        except ValueError:
            return f"TYPE_{self.auth_type}"

    @property
    def has_encrypted_credentials(self) -> bool:
        """Check if integration has encrypted credentials"""
        return bool(self.configuration and len(self.configuration) > 100)


class CredentialView(BaseModel):
    """
    View model for decrypted credentials
    Used when displaying credential details (requires TPS API to decrypt)
    """
    id: int
    tenant_id: int
    name: str
    type: int  # Auth type
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None
    expires_at: Optional[int] = None  # Unix timestamp
    client_id: Optional[str] = None
    client_secret: Optional[str] = None
    api_key: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    additional_config: Optional[Dict[str, Any]] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
