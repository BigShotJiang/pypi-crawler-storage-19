#!/bin/bash
# Build script that explicitly uses system Python (not venv)

set -e

cd "$(dirname "$0")/.."

echo "🔨 Building TPS CLI package..."
echo

# Use absolute path to system Python, not venv
SYSTEM_PYTHON=/usr/bin/python3

if [ ! -f "$SYSTEM_PYTHON" ]; then
    echo "❌ System Python not found at $SYSTEM_PYTHON"
    echo "Searching for Python..."
    SYSTEM_PYTHON=$(which python3)
    if [ -z "$SYSTEM_PYTHON" ]; then
        echo "❌ No Python found!"
        exit 1
    fi
fi

echo "Using: $($SYSTEM_PYTHON --version)"
echo

# Clean
echo "📦 Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info tps_cli.egg-info

# Install build tools
echo "📥 Installing build tools..."
$SYSTEM_PYTHON -m pip install --user build twine

# Build
echo "🏗️  Building package..."
$SYSTEM_PYTHON -m build

echo
echo "✅ Build complete!"
echo
echo "📦 Distribution files:"
ls -lh dist/

echo
echo "📤 Ready to publish!"
echo
echo "To test locally (deactivate venv first):"
echo "  deactivate"
echo "  $SYSTEM_PYTHON -m pip install --user dist/*.whl"
echo "  tps version"
echo
echo "To publish to TestPyPI:"
echo "  $SYSTEM_PYTHON -m twine upload --repository testpypi dist/*"
echo
echo "To publish to PyPI:"
echo "  $SYSTEM_PYTHON -m twine upload dist/*"
