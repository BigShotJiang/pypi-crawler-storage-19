#!/bin/bash
#
# Generate Python clients from TPS OpenAPI specifications
#
# This script mirrors the Java approach where openapi-generator-maven-plugin
# generates tps-*-client artifacts (tps-app-marketplace-client, tps-integration-client, etc.)
#
# Requirements:
#   - Docker (recommended) OR openapi-generator-cli installed
#   - TPS service repository checked out at ../third-party-app-integration
#
# Usage:
#   ./scripts/generate_clients.sh
#

set -e

# Configuration
TPS_SERVICE_PATH="${TPS_SERVICE_PATH:-../third-party-app-integration}"
OPENAPI_BASE="$TPS_SERVICE_PATH/src/main/resources/openApi"
OUTPUT_DIR="tps_cli/generated"
GENERATOR_VERSION="v6.4.0"
USE_DOCKER="${USE_DOCKER:-true}"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Print colored message
print_info() {
    echo -e "${GREEN}$1${NC}"
}

print_warning() {
    echo -e "${YELLOW}$1${NC}"
}

print_error() {
    echo -e "${RED}$1${NC}"
}

# Check if TPS service path exists
if [ ! -d "$TPS_SERVICE_PATH" ]; then
    print_error "❌ TPS service not found at: $TPS_SERVICE_PATH"
    print_info "Please clone third-party-app-integration repository:"
    print_info "  git clone <repo-url> $TPS_SERVICE_PATH"
    exit 1
fi

print_info "TPS CLI Client Generator"
print_info "========================"
print_info ""
print_info "TPS Service Path: $TPS_SERVICE_PATH"
print_info "Output Directory: $OUTPUT_DIR"
print_info "Generator Version: $GENERATOR_VERSION"
print_info ""

# Clean previous generated code
if [ -d "$OUTPUT_DIR" ]; then
    print_info "Cleaning previous generated code..."
    rm -rf "$OUTPUT_DIR"
fi
mkdir -p "$OUTPUT_DIR"

# Function to generate client using Docker
generate_client_docker() {
    local name=$1
    local spec_path=$2

    print_info "Generating $name client (using Docker)..."

    docker run --rm \
        -v "${PWD}:/local" \
        -u "$(id -u):$(id -g)" \
        openapitools/openapi-generator-cli:${GENERATOR_VERSION} generate \
        -i "/local/$spec_path" \
        -g python \
        -o "/local/$OUTPUT_DIR/$name" \
        --package-name "tps_cli.generated.$name" \
        --additional-properties=projectName=tps-$name-client \
        --additional-properties=packageVersion=1.0.0 \
        --skip-validate-spec \
        --global-property=apiTests=false,modelTests=false \
        > /dev/null 2>&1

    if [ $? -eq 0 ]; then
        print_info "  ✓ Generated $name client"
    else
        print_error "  ❌ Failed to generate $name client"
        return 1
    fi
}

# Function to generate client using local openapi-generator
generate_client_local() {
    local name=$1
    local spec_path=$2

    print_info "Generating $name client (using local openapi-generator)..."

    openapi-generator-cli generate \
        -i "$spec_path" \
        -g python \
        -o "$OUTPUT_DIR/$name" \
        --package-name "tps_cli.generated.$name" \
        --additional-properties=projectName=tps-$name-client \
        --additional-properties=packageVersion=1.0.0 \
        --skip-validate-spec \
        --global-property=apiTests=false,modelTests=false \
        > /dev/null 2>&1

    if [ $? -eq 0 ]; then
        print_info "  ✓ Generated $name client"
    else
        print_error "  ❌ Failed to generate $name client"
        return 1
    fi
}

# Function to generate client (auto-select Docker or local)
generate_client() {
    local name=$1
    local spec_path=$2

    # Check if spec exists
    if [ ! -f "$spec_path" ]; then
        print_warning "  ⚠ Skipping $name: OpenAPI spec not found at $spec_path"
        return 0
    fi

    if [ "$USE_DOCKER" = "true" ]; then
        # Check if Docker is available
        if command -v docker &> /dev/null; then
            generate_client_docker "$name" "$spec_path"
        else
            print_warning "  ⚠ Docker not found, falling back to local openapi-generator"
            generate_client_local "$name" "$spec_path"
        fi
    else
        generate_client_local "$name" "$spec_path"
    fi
}

print_info "Generating Management API Clients"
print_info "----------------------------------"
print_info ""

# Generate management API clients (what CLI needs)
generate_client "app_marketplace" "$OPENAPI_BASE/management/v1/app-marketplace.yaml"
generate_client "integration" "$OPENAPI_BASE/management/v1/integration.yaml"
generate_client "credential" "$OPENAPI_BASE/management/v1/credential.yaml"
generate_client "webhook" "$OPENAPI_BASE/management/v1/webhooks.yaml"
generate_client "action" "$OPENAPI_BASE/management/v1/action.yaml"

print_info ""
print_info "Optional: Integration API Clients"
print_info "----------------------------------"
print_info ""
print_info "To generate integration-specific clients (Okta, Slack, Azure AD, etc.),"
print_info "uncomment the lines below in this script."
print_info ""

# Optional: Generate integration API clients (for advanced use cases)
# Uncomment these if you need integration-specific clients
# generate_client "okta" "$OPENAPI_BASE/integrations/v1/okta.yaml"
# generate_client "slack" "$OPENAPI_BASE/integrations/v1/slackfinal.yaml"
# generate_client "azure_ad" "$OPENAPI_BASE/integrations/v1/azure-ad.yaml"
# generate_client "workday" "$OPENAPI_BASE/integrations/v1/workday.yaml"
# generate_client "ms_teams" "$OPENAPI_BASE/integrations/v1/ms-teams.yaml"
# generate_client "github" "$OPENAPI_BASE/integrations/v1/github.yaml"

# Create __init__.py files for Python package structure
print_info ""
print_info "Creating package structure..."

# Root __init__.py
cat > "$OUTPUT_DIR/__init__.py" << 'EOF'
"""
Auto-generated TPS clients from OpenAPI specifications

This package contains auto-generated clients for TPS service APIs,
mirroring the Java approach (tps-app-marketplace-client, tps-integration-client, etc.)

Generated using openapi-generator-cli v6.4.0

Available clients:
- app_marketplace: App Marketplace APIs (OAuth flows, app management)
- integration: Integration Management APIs (list, get, create integrations)
- credential: Credential Management APIs
- webhook: Webhook Management APIs
- action: Action Management APIs
"""

__version__ = "1.0.0"
__all__ = [
    "app_marketplace",
    "integration",
    "credential",
    "webhook",
    "action",
]
EOF

print_info "  ✓ Created package structure"
print_info ""

# Summary
print_info "================================"
print_info "✓ Client Generation Complete"
print_info "================================"
print_info ""
print_info "Generated clients in: $OUTPUT_DIR"
print_info ""
print_info "Next steps:"
print_info "  1. Review generated clients in $OUTPUT_DIR"
print_info "  2. Update tps_cli/client/tps_client.py to use generated clients"
print_info "  3. Test CLI commands with generated clients"
print_info ""
print_info "Usage example:"
print_info "  from tps_cli.generated.app_marketplace import AppMarketplaceApi"
print_info "  from tps_cli.generated.integration import IntegrationApi"
print_info ""
