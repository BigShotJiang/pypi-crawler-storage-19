#!/usr/bin/env python3
"""
Simple local OpenAPI client generator

This copies OpenAPI specs locally and generates Python clients
without complex Docker path mounting.
"""

import shutil
import subprocess
import sys
from pathlib import Path

# Configuration
TPS_PATH = Path("/Users/nandisha/Desktop/Atomicwork/third-party-app-integration")
OPENAPI_BASE = TPS_PATH / "src/main/resources/openApi"
OUTPUT_DIR = Path("tps_cli/generated")
TEMP_SPECS = Path(".openapi_specs_temp")

# Specs to generate
MANAGEMENT_SPECS = {
    "app_marketplace": "management/v1/app-marketplace.yaml",
    "integration": "management/v1/integration.yaml",
    "credential": "management/v1/credential.yaml",
    "webhook": "management/v1/webhooks.yaml",
    "action": "management/v1/action.yaml",
}


def print_info(msg):
    print(f"\033[0;32m{msg}\033[0m")


def print_error(msg):
    print(f"\033[0;31m{msg}\033[0m")


def check_docker():
    """Check if Docker is available"""
    try:
        subprocess.run(["docker", "version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return True
    except:
        return False


def generate_with_docker(name, spec_path_local):
    """Generate using Docker with local spec path"""
    print_info(f"Generating {name} client...")

    cwd = Path.cwd()
    temp_output = Path(f".temp_gen_{name}")

    cmd = [
        "docker", "run", "--rm",
        "-v", f"{cwd}:/local",
        "-w", "/local",
        "openapitools/openapi-generator-cli:v6.4.0",
        "generate",
        "-i", f"{spec_path_local}",
        "-g", "python",
        "-o", f"{temp_output}",
        "--package-name", f"{name}_client",
        "--additional-properties=projectName=tps-{name}-client",
        "--additional-properties=packageVersion=1.0.0",
        "--skip-validate-spec",
        "--global-property=apiTests=false,modelTests=false",
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            print_error(f"  ❌ Failed: {result.stderr[:200]}")
            return False

        # Move generated code to final location
        final_output = OUTPUT_DIR / f"{name}_client"
        generated_package = temp_output / f"{name}_client"

        if generated_package.exists():
            if final_output.exists():
                shutil.rmtree(final_output)
            shutil.move(str(generated_package), str(final_output))

            # Clean up temp directory
            if temp_output.exists():
                shutil.rmtree(temp_output)

            print_info(f"  ✓ Generated {name}")
            return True
        else:
            print_error(f"  ❌ Package not found at {generated_package}")
            return False

    except Exception as e:
        print_error(f"  ❌ Failed: {e}")
        # Cleanup on error
        if temp_output.exists():
            shutil.rmtree(temp_output)
        return False


def main():
    print_info("TPS CLI Client Generator (Simple)")
    print_info("==================================\n")

    # Check TPS service exists
    if not TPS_PATH.exists():
        print_error(f"TPS service not found at: {TPS_PATH}")
        sys.exit(1)

    # Check Docker
    if not check_docker():
        print_error("Docker not found. Please install Docker.")
        sys.exit(1)

    print_info(f"TPS Service: {TPS_PATH}")
    print_info(f"Output: {OUTPUT_DIR}\n")

    # Clean output directory
    if OUTPUT_DIR.exists():
        print_info("Cleaning previous generated code...")
        shutil.rmtree(OUTPUT_DIR)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Create temp directory for specs
    if TEMP_SPECS.exists():
        shutil.rmtree(TEMP_SPECS)
    TEMP_SPECS.mkdir(parents=True, exist_ok=True)

    print_info("Copying OpenAPI specs locally...\n")

    # Copy specs and schema locally
    spec_paths = {}
    for name, spec_rel in MANAGEMENT_SPECS.items():
        src = OPENAPI_BASE / spec_rel
        if not src.exists():
            print_error(f"  ⚠ Spec not found: {src}")
            continue

        # Copy spec
        dst = TEMP_SPECS / f"{name}.yaml"
        shutil.copy(src, dst)
        spec_paths[name] = dst

        # Also copy schema.yaml if referenced
        schema_src = OPENAPI_BASE / "management/v1/schema.yaml"
        schema_dst = TEMP_SPECS / "schema.yaml"
        if schema_src.exists() and not schema_dst.exists():
            shutil.copy(schema_src, schema_dst)

    print_info(f"Copied {len(spec_paths)} specs\n")
    print_info("Generating clients...\n")

    # Generate clients
    success = 0
    failed = 0

    for name, spec_path in spec_paths.items():
        if generate_with_docker(name, spec_path):
            success += 1
        else:
            failed += 1

    # Cleanup temp specs
    shutil.rmtree(TEMP_SPECS)

    # Create package structure
    print_info("\nCreating package structure...")
    init_content = '''"""
Auto-generated TPS clients from OpenAPI specifications

Generated clients:
- app_marketplace: App Marketplace APIs
- integration: Integration Management APIs
- credential: Credential Management APIs
- webhook: Webhook Management APIs
- action: Action Management APIs
"""

__version__ = "1.0.0"
'''
    (OUTPUT_DIR / "__init__.py").write_text(init_content)

    # Summary
    print_info("\n" + "="*50)
    print_info(f"✓ Successfully generated {success} client(s)")
    if failed > 0:
        print_error(f"❌ Failed to generate {failed} client(s)")
    print_info("="*50)

    if success > 0:
        print_info(f"\nGenerated clients in: {OUTPUT_DIR}")
        print_info("\nNext steps:")
        print_info("  1. Check generated code: ls -la tps_cli/generated/")
        print_info("  2. Test import: python -c 'from tps_cli.generated.app_marketplace.api import *'")


if __name__ == "__main__":
    main()
