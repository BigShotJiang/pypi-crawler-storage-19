#!/bin/bash
# Build and test TPS CLI package locally

set -e

echo "🔨 Building TPS CLI package..."
echo

# Get to project root
cd "$(dirname "$0")/.."

# Use system Python (not venv) for building
PYTHON=$(which python3 2>/dev/null || which python)

if [ -z "$PYTHON" ]; then
    echo "❌ Python not found!"
    exit 1
fi

echo "Using Python: $($PYTHON --version)"
echo

# Clean previous builds
echo "📦 Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info tps_cli.egg-info

# Install build tools globally/user (needed for building)
echo "📥 Installing build tools..."
$PYTHON -m pip install --user --quiet build twine 2>/dev/null || {
    echo "⚠️  Installing without --user flag..."
    $PYTHON -m pip install --quiet build twine
}

# Build package
echo "🏗️  Building package..."
$PYTHON -m build

# Check distribution
echo
echo "✅ Build complete!"
echo
echo "📦 Distribution files:"
ls -lh dist/

# Test package in a fresh venv
echo
echo "🧪 Testing package installation..."
TEMP_VENV=$(mktemp -d)
echo "Creating temp venv at: $TEMP_VENV"

$PYTHON -m venv "$TEMP_VENV"

# Ensure pip is available in temp venv
"$TEMP_VENV/bin/python" -m ensurepip --upgrade 2>/dev/null || true

# Install the built package
echo "Installing package..."
"$TEMP_VENV/bin/pip" install --quiet dist/*.whl

echo
echo "✅ Package installed successfully!"
echo
echo "🧪 Testing CLI commands..."
"$TEMP_VENV/bin/tps" version || echo "⚠️  Version command failed"
echo
"$TEMP_VENV/bin/tps" --help | head -10 || echo "⚠️  Help command failed"

# Cleanup
echo
echo "🧹 Cleaning up temp venv..."
rm -rf "$TEMP_VENV"

echo
echo "✅ All tests passed!"
echo
echo "📤 Ready to publish!"
echo
echo "To publish to TestPyPI:"
echo "  $PYTHON -m twine upload --repository testpypi dist/*"
echo
echo "To publish to PyPI:"
echo "  $PYTHON -m twine upload dist/*"
