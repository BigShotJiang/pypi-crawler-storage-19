#!/usr/bin/env python3
"""
Generate Python clients from TPS OpenAPI specifications

This script mirrors the Java approach where openapi-generator-maven-plugin
generates tps-*-client artifacts (tps-app-marketplace-client, tps-integration-client, etc.)

Requirements:
    - Docker installed (recommended)
    - TPS service repository checked out at ../third-party-app-integration

Usage:
    python scripts/generate_clients.py
    python scripts/generate_clients.py --no-docker  # Use local openapi-generator
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List


# Configuration
DEFAULT_TPS_PATH = Path("../third-party-app-integration")
OPENAPI_BASE = "src/main/resources/openApi"
OUTPUT_DIR = Path("tps_cli/generated")
GENERATOR_VERSION = "v6.4.0"

# OpenAPI specs to generate
MANAGEMENT_CLIENTS = {
    "app_marketplace": "management/v1/app-marketplace.yaml",
    "integration": "management/v1/integration.yaml",
    "credential": "management/v1/credential.yaml",
    "webhook": "management/v1/webhooks.yaml",
    "action": "management/v1/action.yaml",
}

INTEGRATION_CLIENTS = {
    "okta": "integrations/v1/okta.yaml",
    "slack": "integrations/v1/slackfinal.yaml",
    "azure_ad": "integrations/v1/azure-ad.yaml",
    "workday": "integrations/v1/workday.yaml",
    "ms_teams": "integrations/v1/ms-teams.yaml",
    "github": "integrations/v1/github.yaml",
    "sharepoint": "integrations/v1/ms-sharepoint.yaml",
    "confluence": "integrations/v1/confluence.yaml",
}


class Colors:
    """ANSI color codes for terminal output"""
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    RED = '\033[0;31m'
    BLUE = '\033[0;34m'
    NC = '\033[0m'  # No Color


def print_info(msg: str):
    """Print info message in green"""
    print(f"{Colors.GREEN}{msg}{Colors.NC}")


def print_warning(msg: str):
    """Print warning message in yellow"""
    print(f"{Colors.YELLOW}{msg}{Colors.NC}")


def print_error(msg: str):
    """Print error message in red"""
    print(f"{Colors.RED}{msg}{Colors.NC}")


def print_section(msg: str):
    """Print section header in blue"""
    print(f"\n{Colors.BLUE}{msg}{Colors.NC}")
    print(f"{Colors.BLUE}{'=' * len(msg)}{Colors.NC}\n")


def check_tps_service(tps_path: Path) -> bool:
    """Check if TPS service repository exists"""
    if not tps_path.exists():
        print_error(f"❌ TPS service not found at: {tps_path}")
        print_info("Please clone third-party-app-integration repository:")
        print_info(f"  git clone <repo-url> {tps_path}")
        return False
    return True


def check_docker() -> bool:
    """Check if Docker is available"""
    try:
        subprocess.run(
            ["docker", "version"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def generate_client_docker(name: str, spec_path: Path) -> bool:
    """Generate client using Docker"""
    print_info(f"Generating {name} client (using Docker)...")

    cwd = Path.cwd()

    # Make spec_path absolute
    spec_path_abs = spec_path.resolve()

    # Get parent directory that contains both CLI and TPS repos
    # This assumes structure like: /Users/.../Desktop/{Cli/TPS, Atomicwork/third-party-app-integration}
    parent_dir = Path("/Users/nandisha/Desktop")

    # Calculate relative paths from parent
    spec_relative = spec_path_abs.relative_to(parent_dir)
    output_relative = (cwd / OUTPUT_DIR / name).relative_to(parent_dir)

    cmd = [
        "docker", "run", "--rm",
        "-v", f"{parent_dir}:/local",
        "-u", f"{os.getuid()}:{os.getgid()}",
        f"openapitools/openapi-generator-cli:{GENERATOR_VERSION}",
        "generate",
        "-i", f"/local/{spec_relative}",
        "-g", "python",
        "-o", f"/local/{output_relative}",
        "--package-name", f"tps_cli.generated.{name}",
        "--additional-properties=projectName=tps-{name}-client",
        "--additional-properties=packageVersion=1.0.0",
        "--skip-validate-spec",
        "--global-property=apiTests=false,modelTests=false",
    ]

    try:
        subprocess.run(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True
        )
        print_info(f"  ✓ Generated {name} client")
        return True
    except subprocess.CalledProcessError as e:
        print_error(f"  ❌ Failed to generate {name} client: {e}")
        return False


def generate_client_local(name: str, spec_path: Path) -> bool:
    """Generate client using local openapi-generator"""
    print_info(f"Generating {name} client (using local openapi-generator)...")

    cmd = [
        "openapi-generator-cli", "generate",
        "-i", str(spec_path),
        "-g", "python",
        "-o", str(OUTPUT_DIR / name),
        "--package-name", f"tps_cli.generated.{name}",
        "--additional-properties=projectName=tps-{name}-client",
        "--additional-properties=packageVersion=1.0.0",
        "--skip-validate-spec",
        "--global-property=apiTests=false,modelTests=false",
    ]

    try:
        subprocess.run(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True
        )
        print_info(f"  ✓ Generated {name} client")
        return True
    except subprocess.CalledProcessError as e:
        print_error(f"  ❌ Failed to generate {name} client: {e}")
        return False
    except FileNotFoundError:
        print_error(f"  ❌ openapi-generator-cli not found")
        print_info("    Install with: npm install -g @openapitools/openapi-generator-cli")
        return False


def generate_client(
    name: str,
    spec_relative_path: str,
    tps_path: Path,
    use_docker: bool
) -> bool:
    """Generate a single client"""
    spec_path = tps_path / OPENAPI_BASE / spec_relative_path

    if not spec_path.exists():
        print_warning(f"  ⚠ Skipping {name}: OpenAPI spec not found at {spec_path}")
        return False

    if use_docker:
        return generate_client_docker(name, spec_path)
    else:
        return generate_client_local(name, spec_path)


def create_package_structure():
    """Create Python package structure"""
    print_info("Creating package structure...")

    # Root __init__.py
    init_content = '''"""
Auto-generated TPS clients from OpenAPI specifications

This package contains auto-generated clients for TPS service APIs,
mirroring the Java approach (tps-app-marketplace-client, tps-integration-client, etc.)

Generated using openapi-generator-cli v6.4.0

Available clients:
- app_marketplace: App Marketplace APIs (OAuth flows, app management)
- integration: Integration Management APIs (list, get, create integrations)
- credential: Credential Management APIs
- webhook: Webhook Management APIs
- action: Action Management APIs
"""

__version__ = "1.0.0"
__all__ = [
    "app_marketplace",
    "integration",
    "credential",
    "webhook",
    "action",
]
'''

    (OUTPUT_DIR / "__init__.py").write_text(init_content)
    print_info("  ✓ Created package structure")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Generate Python clients from TPS OpenAPI specs"
    )
    parser.add_argument(
        "--tps-path",
        type=Path,
        default=DEFAULT_TPS_PATH,
        help=f"Path to TPS service repository (default: {DEFAULT_TPS_PATH})"
    )
    parser.add_argument(
        "--no-docker",
        action="store_true",
        help="Use local openapi-generator instead of Docker"
    )
    parser.add_argument(
        "--include-integrations",
        action="store_true",
        help="Also generate integration-specific clients (Okta, Slack, etc.)"
    )

    args = parser.parse_args()

    print_section("TPS CLI Client Generator")

    print_info(f"TPS Service Path: {args.tps_path}")
    print_info(f"Output Directory: {OUTPUT_DIR}")
    print_info(f"Generator Version: {GENERATOR_VERSION}")
    print()

    # Check TPS service exists
    if not check_tps_service(args.tps_path):
        sys.exit(1)

    # Determine generation method
    use_docker = not args.no_docker
    if use_docker:
        if not check_docker():
            print_warning("⚠ Docker not found, falling back to local openapi-generator")
            use_docker = False

    # Clean previous generated code
    if OUTPUT_DIR.exists():
        print_info("Cleaning previous generated code...")
        shutil.rmtree(OUTPUT_DIR)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Generate management API clients
    print_section("Generating Management API Clients")

    success_count = 0
    fail_count = 0

    for name, spec_path in MANAGEMENT_CLIENTS.items():
        if generate_client(name, spec_path, args.tps_path, use_docker):
            success_count += 1
        else:
            fail_count += 1

    # Optionally generate integration API clients
    if args.include_integrations:
        print_section("Generating Integration API Clients")

        for name, spec_path in INTEGRATION_CLIENTS.items():
            if generate_client(name, spec_path, args.tps_path, use_docker):
                success_count += 1
            else:
                fail_count += 1
    else:
        print()
        print_info("Skipping integration-specific clients")
        print_info("Use --include-integrations to generate Okta, Slack, Azure AD, etc.")
        print()

    # Create package structure
    print()
    create_package_structure()

    # Summary
    print_section("Client Generation Complete")

    print_info(f"✓ Successfully generated {success_count} client(s)")
    if fail_count > 0:
        print_warning(f"⚠ Failed to generate {fail_count} client(s)")

    print()
    print_info(f"Generated clients in: {OUTPUT_DIR}")
    print()
    print_info("Next steps:")
    print_info("  1. Review generated clients in tps_cli/generated/")
    print_info("  2. Update tps_cli/client/tps_client.py to use generated clients")
    print_info("  3. Test CLI commands with generated clients")
    print()
    print_info("Usage example:")
    print_info("  from tps_cli.generated.app_marketplace.api.app_marketplace_api import AppMarketplaceApi")
    print_info("  from tps_cli.generated.integration.api.integration_api import IntegrationApi")
    print()


if __name__ == "__main__":
    main()
