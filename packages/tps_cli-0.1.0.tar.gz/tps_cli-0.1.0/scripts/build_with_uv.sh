#!/bin/bash
# Build TPS CLI package using uv

set -e

cd "$(dirname "$0")/.."

echo "🔨 Building TPS CLI package with uv..."
echo

# Clean previous builds
echo "📦 Cleaning previous builds..."
rm -rf dist/ build/ *.egg-info tps_cli.egg-info

# Build with uv
echo "🏗️  Building package..."
uv build

echo
echo "✅ Build complete!"
echo
echo "📦 Distribution files:"
ls -lh dist/

echo
echo "📤 Ready to publish!"
echo
echo "To test locally:"
echo "  uvx --from ./dist/tps_cli-0.1.0-py3-none-any.whl tps-cli version"
echo
echo "To publish to TestPyPI:"
echo "  uv publish --token <your-token> --publish-url https://test.pypi.org/legacy/ dist/*"
echo
echo "To publish to PyPI:"
echo "  uv publish --token <your-token> dist/*"
