#!/bin/bash
# Simple build script - just builds the package

set -e

cd "$(dirname "$0")/.."

echo "🔨 Building TPS CLI package..."
echo

# Clean
rm -rf dist/ build/ *.egg-info

# Install build (if needed)
python3 -m pip install --user build

# Build
python3 -m build

echo
echo "✅ Build complete!"
ls -lh dist/

echo
echo "To test locally:"
echo "  python3 -m pip install dist/*.whl"
echo "  tps version"
