# TPS Encryption Configuration

## Overview

The TPS CLI now supports decrypting credentials stored in the `integration_entity.configuration` field. This document explains where the encryption key is stored in the TPS backend and how to configure it for the CLI.

## Encryption Details

### Backend Implementation (Java)

**Location**: `com.atomicwork.thirdpartyappintegration.core.misc.SecretKeeper.java`

**Algorithm**: AES (ECB mode)

**Encoding**: Base64

**Key Source** (in order of precedence):
1. `ATOMIC_SECRET` environment variable
2. Default hardcoded key: `t7w!z%C*F-JaNdRgUjXn2r5u8x/A?D(G)` (32 bytes)

**Code Reference**:
```java
@Component
public class SecretKeeper {
  String ALGORITHM = "AES";
  byte[] KEY_VALUE =
      Optional.ofNullable(System.getenv("ATOMIC_SECRET"))
          .map(string -> string.getBytes(StandardCharsets.UTF_8))
          .orElse("t7w!z%C*F-JaNdRgUjXn2r5u8x/A?D(G".getBytes(StandardCharsets.UTF_8));

  public String encrypt(String valueToEnc) { /* ... */ }
  public String decrypt(String encryptedValue) { /* ... */ }
}
```

**Database Field**: `integration_entity.configuration`
- Uses `EncryptedHashMapConverter` JPA converter
- Automatically encrypts on write, decrypts on read
- Stored as base64-encoded encrypted text

## CLI Implementation (Python)

**Location**: `tps_cli/utils/secret_keeper.py`

**Matching Implementation**:
- Same AES algorithm (ECB mode)
- Same base64 encoding
- Same key precedence (env var → default key)

**Usage in CLI**:
```python
from tps_cli.utils import SecretKeeper

# Initialize with env variable or default key
keeper = SecretKeeper()

# Or with explicit key
keeper = SecretKeeper(secret_key="your-secret-key")

# Decrypt configuration
decrypted_config = keeper.decrypt_json(encrypted_config_string)
```

## Configuration

### Environment Variable

Set the `ATOMIC_SECRET` environment variable to match your TPS backend:

```bash
export ATOMIC_SECRET="your-32-character-secret-key"
```

### CLI Config File

Add to `~/.tps-cli/config.yaml`:

```yaml
active_profile: local
profiles:
  local:
    database:
      host: localhost
      port: 11432
      database: tps
      username: esd
      password: esd
    tps_service:
      url: http://localhost:8093
      timeout: 30
    security:
      atomic_secret: "your-32-character-secret-key"  # Optional: can use env var instead
```

### Command Line Option

Pass the secret key directly to commands:

```bash
tps integration decrypt-config 1 --secret-key "your-secret-key"
```

## CLI Commands

### Decrypt Configuration

Decrypt and view the encrypted credentials for an integration:

```bash
# Using environment variable or config file
tps integration decrypt-config 1

# Using command line option
tps integration decrypt-config 1 --secret-key "your-secret-key"

# JSON output
tps integration decrypt-config 1 --json
```

**Example Output**:
```
✓ Successfully decrypted configuration for integration 1

App: WORKDAY
Status: ACTIVE

Decrypted Configuration:
{
  "access_token": "eyJ4NXQjUzI1NiI6...",
  "refresh_token": "bxvis1okfhduos0bjmb1...",
  "expires_at": 1767692894,
  "client_id": "MmFmMGZmNWYtMmUxMy00...",
  "client_secret": "wp5gkwx2pz01ao4zl5lvc22omm1w...",
  "tenant_name": "ibmsrv_pt1",
  "rest_api_base_url": "https://wd2-impl-services1.workday.com",
  "redirect_uri": null
}
```

## Finding the Secret Key

### Development/Local Environment

If you're using the default key, no configuration is needed. The CLI will automatically use:
```
t7w!z%C*F-JaNdRgUjXn2r5u8x/A?D(G
```

### Production/Staging Environment

1. **Check TPS Backend Environment**:
   ```bash
   # On the server running TPS
   echo $ATOMIC_SECRET
   ```

2. **Check Kubernetes/Docker Configuration**:
   ```bash
   # Kubernetes
   kubectl get secret tps-secrets -o yaml
   kubectl describe pod tps-pod-name

   # Docker
   docker inspect tps-container-name
   ```

3. **Check Application Properties**:
   - Look in `application.properties` or environment-specific config files
   - Check CI/CD pipeline secrets
   - Check cloud provider secret management (AWS Secrets Manager, Azure Key Vault, etc.)

4. **Ask DevOps/Infrastructure Team**:
   - The `ATOMIC_SECRET` should be documented in your infrastructure-as-code
   - Check Terraform/CloudFormation templates
   - Check configuration management tools (Ansible, Chef, Puppet)

## Security Considerations

⚠️ **Important Security Notes**:

1. **Never commit the secret key to version control**
   - Use environment variables or secure secret management
   - Add to `.gitignore`: `.env`, `config.yaml` with secrets

2. **Use different keys for different environments**
   - Development: Can use default key
   - Production: Must use unique, strong secret key

3. **Rotate keys periodically**
   - When rotating, you'll need to re-encrypt all existing credentials
   - Plan maintenance window for key rotation

4. **Access Control**
   - Limit who has access to the `ATOMIC_SECRET`
   - Use secret management tools with audit logs
   - Follow principle of least privilege

## Troubleshooting

### Decryption Fails

**Error**: `Error while decrypting the value`

**Causes**:
1. Wrong secret key
2. Corrupted encrypted data
3. Different encryption algorithm version

**Solutions**:
```bash
# Try with default key
tps integration decrypt-config 1 --secret-key "t7w!z%C*F-JaNdRgUjXn2r5u8x/A?D(G"

# Check backend logs for encryption key in use
# Verify database field hasn't been manually edited
```

### Key Length Issues

AES requires specific key lengths:
- AES-128: 16 bytes (16 characters)
- AES-192: 24 bytes (24 characters)
- AES-256: 32 bytes (32 characters)

The default key is 32 characters (AES-256). If using a custom key, ensure it's exactly 32 characters.

## Dependencies

### Python CLI
- `pycryptodome>=3.21.0` - AES encryption/decryption

### Java Backend
- Standard Java Crypto API
- `javax.crypto.Cipher`
- `javax.crypto.spec.SecretKeySpec`

## Related Files

### Backend
- `/src/main/java/com/atomicwork/thirdpartyappintegration/core/misc/SecretKeeper.java`
- `/src/main/java/com/atomicwork/thirdpartyappintegration/core/model/entity/converter/EncryptedHashMapConverter.java`
- `/src/main/java/com/atomicwork/thirdpartyappintegration/core/model/entity/IntegrationEntity.java`

### CLI
- `/tps_cli/utils/secret_keeper.py` - Encryption/decryption implementation
- `/tps_cli/config.py` - SecurityConfig with atomic_secret
- `/tps_cli/commands/integration.py` - decrypt-config command
- `/pyproject.toml` - Dependencies (pycryptodome)

## Testing

### Test Encryption/Decryption

```python
from tps_cli.utils import SecretKeeper

keeper = SecretKeeper()

# Test encryption
plaintext = "test data"
encrypted = keeper.encrypt(plaintext)
print(f"Encrypted: {encrypted}")

# Test decryption
decrypted = keeper.decrypt(encrypted)
print(f"Decrypted: {decrypted}")
assert decrypted == plaintext

# Test JSON encryption/decryption
data = {"access_token": "abc123", "refresh_token": "xyz789"}
encrypted_json = keeper.encrypt_json(data)
decrypted_data = keeper.decrypt_json(encrypted_json)
assert decrypted_data == data
```

### Test with Real Integration

```bash
# List integrations
tps integration list

# Get integration details
tps integration get 1

# Decrypt configuration
tps integration decrypt-config 1

# Verify access_token, refresh_token, expires_at are present
```
