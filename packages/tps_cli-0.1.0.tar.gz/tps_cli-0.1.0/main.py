def main():
    print("Hello from tps-cli!")


if __name__ == "__main__":
    main()
