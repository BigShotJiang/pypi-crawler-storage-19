# Getting Started with TPS CLI

This guide will walk you through setting up and using the TPS CLI for integration testing.

## Quick Start

### 1. Installation

```bash
# Navigate to project directory
cd ~/Desktop/Cli/TPS

# Activate virtual environment
source .venv/bin/activate

# Install CLI (if not already installed)
export PATH="$HOME/.local/bin:$PATH"
uv pip install -e .
```

### 2. Initialize Configuration

The CLI will interactively prompt you for configuration values:

```bash
tps init
```

You'll be asked for:
- **TPS Service URL** (default: http://localhost:8093)
- **Database Host** (default: localhost)
- **Database Port** (default: 5432)
- **Database Name** (default: tps)
- **Database Username** (default: postgres)
- **Database Password** (hidden input)
- **ATOMIC_SECRET** (optional, for encryption)

Example session:
```
TPS CLI Configuration Setup

TPS Service Configuration:
TPS Service URL [http://localhost:8093]: http://localhost:8093

Database Configuration:
Database Host [localhost]: localhost
Database Port [5432]: 11432
Database Name [tps]: tps
Database Username [postgres]: esd
Database Password: ****

Encryption Configuration (optional):
ATOMIC_SECRET (leave empty for default):

✓ Configuration initialized at ~/.tps-cli/config.yaml

Configuration summary:
TPS Service: http://localhost:8093
Database: postgresql://esd@localhost:11432/tps
```

This creates `~/.tps-cli/config.yaml` with your settings.

### 3. Alternative: Use Environment Variables

If you prefer, you can set environment variables before running `tps init` and they'll be used as defaults:

```bash
# Create .env file
cp .env.example .env

# Edit .env with your values
vim .env

# Then run init - it will use these as defaults
tps init
```

The environment variables will be shown as defaults when you're prompted, so you can just press Enter to accept them.

### 4. Verify Installation

```bash
# Check CLI version
tps version

# View configuration
tps config --show

# Check TPS service health (requires TPS service running)
tps health
```

## Common Workflows

### Workflow 1: Query Existing Integrations

```bash
# List all integrations from database
tps integration list

# Filter by tenant ID
tps integration list --tenant-id 1

# Filter by status
tps integration list --status ACTIVE

# Get specific integration with credentials
tps integration get 123 --with-credential

# Check if token is expired
tps integration check-token 123
```

### Workflow 2: Test Workday OAuth Flow

#### Step 1: Prepare Environment Variables

Create a `.env` file or export variables:
```bash
export WORKDAY_CLIENT_ID="your_client_id"
export WORKDAY_CLIENT_SECRET="your_client_secret"
export WORKDAY_TENANT_NAME="your_tenant"
export WORKDAY_AUTH_URL="https://wd2-impl-services1.workday.com"
export WORKDAY_API_URL="https://wd2-impl-services1.workday.com"
```

#### Step 2: Generate Authorization URL

```bash
tps integration generate-auth-url workday \
    --client-id "$WORKDAY_CLIENT_ID" \
    --client-secret "$WORKDAY_CLIENT_SECRET" \
    --redirect-url "http://localhost:8093/callback" \
    --tenant-name "$WORKDAY_TENANT_NAME" \
    --auth-url "$WORKDAY_AUTH_URL" \
    --api-url "$WORKDAY_API_URL"
```

Copy the generated URL and open it in your browser.

#### Step 3: Authorize and Get Code

1. The browser will redirect you to Workday login
2. Log in and authorize the app
3. You'll be redirected to your callback URL with an authorization code
4. Copy the code from the URL parameter

Example callback:
```
http://localhost:8093/callback?code=YOUR_AUTH_CODE&state=test-state
```

#### Step 4: Exchange Code for Tokens

```bash
tps integration exchange-token workday \
    --code "YOUR_AUTH_CODE" \
    --client-id "$WORKDAY_CLIENT_ID" \
    --client-secret "$WORKDAY_CLIENT_SECRET" \
    --redirect-url "http://localhost:8093/callback" \
    --tenant-name "$WORKDAY_TENANT_NAME" \
    --auth-url "$WORKDAY_AUTH_URL" \
    --api-url "$WORKDAY_API_URL" \
    --json > workday_tokens.json
```

#### Step 5: Save Tokens

```bash
# View tokens
cat workday_tokens.json | jq .

# Extract individual tokens
ACCESS_TOKEN=$(cat workday_tokens.json | jq -r .access_token)
REFRESH_TOKEN=$(cat workday_tokens.json | jq -r .refresh_token)
EXPIRES_AT=$(cat workday_tokens.json | jq -r .expires_at)

echo "Access Token: ***${ACCESS_TOKEN: -20}"
echo "Refresh Token: ***"
echo "Expires At: $EXPIRES_AT"
```

#### Step 6: Refresh Token (When Expired)

```bash
tps integration refresh-token workday \
    --refresh-token "$REFRESH_TOKEN" \
    --client-id "$WORKDAY_CLIENT_ID" \
    --client-secret "$WORKDAY_CLIENT_SECRET" \
    --tenant-name "$WORKDAY_TENANT_NAME" \
    --auth-url "$WORKDAY_AUTH_URL" \
    --api-url "$WORKDAY_API_URL" \
    --json > workday_tokens_refreshed.json
```

### Workflow 3: Check Integration Health

```bash
# Check if integration exists
tps integration get 123

# Check token expiration
tps integration check-token 123

# View credential details
tps integration get 123 --with-credential

# Check cache status for integration type
tps integration is-cache-enabled workday
```

## Advanced Usage

### Using API Mode vs Database Mode

By default, the CLI queries the database directly for faster access. Use `--api` flag to query via TPS REST APIs:

```bash
# Query database directly (fast)
tps integration list --tenant-id 1

# Query via TPS API (requires TPS service running)
tps integration list --tenant-id 1 --api
```

### JSON Output for Scripting

All commands support `--json` flag for machine-readable output:

```bash
# Get integrations as JSON
tps integration list --json | jq '.[0]'

# Get integration with credentials
tps integration get 123 --with-credential --json | jq '.credential.expires_at'

# Exchange token and save
tps integration exchange-token workday \
    --code "..." \
    --json > tokens.json
```

### Profile Management

Switch between different environments:

```bash
# Show current profile
tps config --show

# Switch to staging profile
tps config --profile staging

# List integrations in staging
tps integration list
```

## Troubleshooting

### Database Connection Errors

```bash
# Check database configuration
tps config --show

# Test database connection
psql -h localhost -p 5432 -U postgres -d tps

# Update database credentials
vim ~/.tps-cli/config.yaml
```

### TPS Service Connection Errors

```bash
# Check TPS service health
tps health --verbose

# Verify TPS URL
tps config --show

# Update TPS URL
vim ~/.tps-cli/config.yaml
```

### OAuth Flow Issues

**Error: Invalid redirect_uri**
- Ensure redirect URL matches exactly what's configured in Workday
- Use the same URL for all OAuth commands

**Error: Token expired**
- Check token expiration: `tps integration check-token <id>`
- Refresh token: `tps integration refresh-token workday ...`

**Error: Invalid tenant name**
- Verify tenant name is correct
- Check Workday tenant configuration

### Missing Dependencies

```bash
# Reinstall dependencies
cd ~/Desktop/Cli/TPS
uv pip install -e .

# Install dev dependencies
uv pip install -e ".[dev]"
```

## Tips & Tricks

### 1. Use Shell Aliases

Add to your `~/.bashrc` or `~/.zshrc`:
```bash
alias tps-list='tps integration list --tenant-id 1'
alias tps-check='tps integration check-token'
alias tps-get='tps integration get'
```

### 2. Environment-Specific Configurations

Create multiple profiles in `~/.tps-cli/config.yaml`:
```yaml
active_profile: local

profiles:
  local:
    tps_service:
      url: http://localhost:8093
    database:
      host: localhost
      database: tps

  staging:
    tps_service:
      url: https://tps-staging.atomicwork.com
    database:
      host: staging-db.example.com
      database: tps

  prod:
    tps_service:
      url: https://tps.atomicwork.com
    database:
      host: prod-db.example.com
      database: tps
```

### 3. Batch Processing

Process multiple integrations:
```bash
# Check all integrations for a tenant
for id in $(tps integration list --tenant-id 1 --json | jq '.[].id'); do
    echo "Checking integration $id..."
    tps integration check-token $id
done
```

### 4. Export Integration Data

```bash
# Export all integrations
tps integration list --json > integrations_backup.json

# Export with credentials (be careful with sensitive data!)
for id in $(tps integration list --json | jq '.[].id'); do
    tps integration get $id --with-credential --json >> integrations_full_backup.json
done
```

## Next Steps

- Explore all available commands: `tps --help`
- Read the full README for detailed documentation
- Add support for more integrations (see Architecture section)
- Contribute improvements to the CLI

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review logs with `--verbose` flag
3. Contact the TPS development team
