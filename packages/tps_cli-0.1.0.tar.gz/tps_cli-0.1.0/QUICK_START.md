# TPS CLI - Quick Start Guide

## For End Users (After PyPI Publication)

### Installation

**Using uvx (no installation required):**
```bash
# Run commands directly without installing
uvx tps-cli init
uvx tps-cli health
uvx tps-cli integration list
```

**Using pipx (recommended for regular use):**
```bash
# Install once
pipx install tps-cli

# Use anywhere
tps init
tps health
tps integration list

# Upgrade to latest version
pipx upgrade tps-cli

# Uninstall
pipx uninstall tps-cli
```

**Using pip:**
```bash
pip install tps-cli
tps init
```

### First Time Setup

1. **Initialize configuration:**
```bash
tps init
```

You'll be prompted for:
- TPS Service URL (default: http://localhost:8093)
- Database Host (default: localhost)
- Database Port (default: 5432)
- Database Name (default: tps)
- Database Username (default: postgres)
- Database Password (hidden input)
- Encryption Key (optional)

2. **Verify setup:**
```bash
tps config --show
tps health
```

### Common Commands

**Health Check:**
```bash
tps health
tps health --verbose
```

**List Integrations:**
```bash
# Via TPS API
tps integration list

# With filters
tps integration list --tenant-id 1 --app-id 32

# Via database (requires DB access)
tps integration list --use-db
```

**Get Integration Details:**
```bash
tps integration get 123
tps integration get 123 --with-credential
tps integration get 123 --use-db
```

**Install New Integration (End-to-End):**
```bash
# Workday example
tps integration install 32 --config '{
    "app_name": "WORKDAY",
    "client_id": "your_client_id",
    "client_secret": "your_client_secret",
    "tenant_name": "ibmsrv_pt1",
    "authorization_base_url": "https://wd2-impl-services1.workday.com",
    "rest_api_base_url": "https://wd2-impl-services1.workday.com"
}'

# This will:
# 1. Start local OAuth callback server
# 2. Open browser for authentication
# 3. Capture authorization code automatically
# 4. Create the integration
```

**Decrypt Integration Config:**
```bash
tps integration decrypt-config 123
tps integration decrypt-config 123 --secret-key "custom-key"
```

**Generate OAuth URL:**
```bash
tps integration generate-auth-url workday \
    --redirect-url "http://localhost:8093/callback" \
    --tenant-name "ibmsrv_pt1" \
    --auth-url "https://wd2-impl-services1.workday.com" \
    --api-url "https://wd2-impl-services1.workday.com"
```

### Configuration

**View configuration:**
```bash
tps config --show
```

**Switch profile:**
```bash
tps config --profile staging
```

**Edit configuration:**
```bash
vim ~/.tps-cli/config.yaml
```

**Using environment variables:**
```bash
export TPS_URL=http://localhost:8093
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=tps
export DB_USER=postgres
export DB_PASSWORD=your_password
export ATOMIC_SECRET=your_encryption_key

tps health
```

### Help

```bash
# Main help
tps --help

# Command help
tps integration --help
tps integration list --help
tps integration install --help

# Version
tps version
```

### Examples

**Complete Workday Integration Setup:**
```bash
# 1. Initialize CLI
tps init

# 2. Install Workday integration
tps integration install 32 --config '{
    "app_name": "WORKDAY",
    "client_id": "MmFmMGZmNWYtMmUxMy00MzE0LThkNGEtM2VjZWRjZDhkZmM4",
    "client_secret": "wp5gkwx2pz01ao4zl5lvc22omm1w6vzi6zwlctj1q08vpf2qbk6ppzxqafbppfsl4awyrlw337g3djbgohjnom9wnutu17nlhwe",
    "tenant_name": "ibmsrv_pt1",
    "authorization_base_url": "https://wd2-impl-services1.workday.com",
    "rest_api_base_url": "https://wd2-impl-services1.workday.com"
}'
# Browser opens → Authenticate → Code captured automatically → Integration created

# 3. Verify integration
tps integration get <integration_id>

# 4. Decrypt credentials
tps integration decrypt-config <integration_id>
```

### Troubleshooting

**Issue: Command not found**
```bash
# If using pipx, ensure it's in PATH
pipx ensurepath
source ~/.bashrc  # or ~/.zshrc

# If using pip, check installation
pip list | grep tps-cli
```

**Issue: TPS service unreachable**
```bash
# Check TPS service is running
curl http://localhost:8093/actuator/health

# Update TPS URL in config
tps init  # Re-run init with correct URL
```

**Issue: Database connection failed**
```bash
# Verify database credentials
tps config --show

# Test connection
psql -h localhost -p 5432 -U postgres -d tps

# Update config
vim ~/.tps-cli/config.yaml
```

**Issue: OAuth callback timeout**
```bash
# Use custom port
tps integration install 32 --config '...' --port 9000

# Or disable browser and manually copy code
tps integration install 32 --config '...' --no-browser
```

### Tips

1. **Use uvx for one-off commands** - No installation required
2. **Use pipx for regular use** - Isolated environment, always available
3. **Run `tps init` first** - Sets up configuration
4. **Use `--json` flag** - For scripting and automation
5. **Check `--help`** - Comprehensive help for all commands

### Support

- Documentation: https://github.com/atomicwork/tps-cli#readme
- Issues: https://github.com/atomicwork/tps-cli/issues

Built for AtomicWork TPS Team
