# TPS CLI Architecture

## Overview

The TPS CLI is a **thin client** that delegates all business logic to the TPS service running on port 8093. This architecture ensures there is a single source of truth for all integration logic, reducing code duplication and maintenance overhead.

## Architecture Principles

###  Thin Client Pattern

```
┌──────────────┐         ┌──────────────┐         ┌─────────────────┐
│   TPS CLI    │         │ TPS Service  │         │   Third-Party   │
│  (Port N/A)  │ ──HTTP──│  (Port 8093) │ ──HTTP──│   APIs          │
│              │         │              │         │ (Workday/Slack) │
└──────────────┘         └──────────────┘         └─────────────────┘
                                │
                                │ Database
                                ▼
                         ┌──────────────┐
                         │  PostgreSQL  │
                         │  (Port 11432)│
                         └──────────────┘
```

**Key Points**:
- ✅ CLI is a thin HTTP client
- ✅ All business logic lives in TPS service
- ✅ Single source of truth
- ✅ Easy to maintain and test
- ✅ No duplication of OAuth handlers

### What the CLI Does

1. **User Interface** - Command-line interface for developers
2. **HTTP Calls** - Makes REST API calls to TPS service
3. **Display** - Formats and displays responses
4. **Optional DB Access** - Can query database directly for debugging (with `--db` flag)

### What the CLI Does NOT Do

1. ❌ Implement OAuth logic
2. ❌ Handle token exchange/refresh
3. ❌ Store encryption keys or secrets
4. ❌ Implement app-specific integration logic
5. ❌ Make direct calls to third-party APIs

All of the above are handled by the TPS service.

## Command Workflow

### OAuth Flow Commands

#### 1. Generate Authorization URL

**Old (Wrong) Architecture**:
```
CLI → WorkdayOAuthHandler (local) → Builds URL → Returns to user
❌ OAuth logic duplicated in CLI
```

**New (Correct) Architecture**:
```
CLI → TPS Service → WorkdayHandler.java → Builds URL → Returns to user
✅ Single OAuth implementation in TPS
```

**Command**:
```bash
tps integration generate-auth-url workday \
    --redirect-url "http://localhost:8093/callback" \
    --tenant-name "ibmsrv_pt1" \
    --auth-url "https://wd2-impl-services1.workday.com" \
    --api-url "https://wd2-impl-services1.workday.com"
```

**API Call**:
```http
POST /api/app-marketplace/{app_id}/install/settings
Headers: X-Tenant-ID: 2
Body: {
  "state": "test-state",
  "redirect_uri": "http://localhost:8093/callback",
  "config": {
    "tenant_name": "ibmsrv_pt1",
    "authorization_base_url": "https://wd2-impl-services1.workday.com",
    "rest_api_base_url": "https://wd2-impl-services1.workday.com"
  }
}

Response: {
  "app_id": 32,
  "full_uri": "https://wd2-impl-services1.workday.com/ccx/oauth2/ibmsrv_pt1/authorize?...",
  "app_detail": {...}
}
```

#### 2. Exchange Authorization Code

**Command**:
```bash
tps integration exchange-token workday \
    --code "auth_code_from_callback" \
    --redirect-url "http://localhost:8093/callback" \
    --tenant-name "ibmsrv_pt1" \
    --auth-url "https://wd2-impl-services1.workday.com" \
    --api-url "https://wd2-impl-services1.workday.com"
```

**API Call**:
```http
POST /api/app-marketplace/NATIVE/token
Headers: X-Tenant-ID: 2
Body: {
  "created_by": 1,
  "code": "auth_code_from_callback",
  "redirect_uri": "http://localhost:8093/callback",
  "config": {
    "tenant_name": "ibmsrv_pt1",
    "authorization_base_url": "...",
    "rest_api_base_url": "...",
    "client_id": "...",
    "client_secret": "..."
  }
}

Response: {
  "access_token": "eyJ...",
  "refresh_token": "bxvis1ok...",
  "expires_at": 1767692894,
  "token_type": "Bearer"
}
```

#### 3. Refresh Access Token

**Command**:
```bash
tps integration refresh-token workday \
    --refresh-token "bxvis1ok..." \
    --tenant-name "ibmsrv_pt1" \
    --auth-url "https://wd2-impl-services1.workday.com" \
    --api-url "https://wd2-impl-services1.workday.com"
```

**API Call**:
```http
POST /api/app-marketplace/NATIVE/token
Headers: X-Tenant-ID: 2
Body: {
  "created_by": 1,
  "refresh_token": "bxvis1ok...",
  "config": {
    "tenant_name": "ibmsrv_pt1",
    "authorization_base_url": "...",
    "rest_api_base_url": "...",
    "client_id": "...",
    "client_secret": "..."
  }
}
```

### Integration Management Commands

#### List Integrations

**Default (TPS API)**:
```bash
tps integration list
```
- Calls: `GET /api/management/integrations`
- Returns: Decrypted integration data from TPS service

**Direct Database** (for debugging):
```bash
tps integration list --db
```
- Queries: PostgreSQL `integration_entity` table directly
- Returns: Encrypted data (requires `decrypt-config` command)

#### Get Integration

**Default (TPS API)**:
```bash
tps integration get 1
```
- Calls: `GET /api/management/integrations/1`
- Returns: Decrypted configuration from TPS service

**Direct Database** (for debugging):
```bash
tps integration get 1 --db
```
- Queries: PostgreSQL directly
- Returns: Encrypted configuration field

## File Structure

```
tps_cli/
├── generated/                 # Auto-generated OpenAPI clients (see OPENAPI_CLIENT_GENERATION.md)
│   ├── app_marketplace/       # From app-marketplace.yaml
│   ├── integration/           # From integration.yaml
│   ├── credential/            # From credential.yaml
│   ├── webhook/               # From webhooks.yaml
│   └── action/                # From action.yaml
│
├── client/
│   ├── base.py                # Base HTTP client
│   └── tps_client.py          # TPS Service API client (thin wrapper around generated clients)
│
├── commands/
│   └── integration.py         # CLI commands (calls TPS client)
│
├── database/
│   └── integration_repository.py  # Direct DB access (optional, for debugging)
│
├── models/
│   ├── apps.py                # App enum matching Java
│   ├── auth_type.py           # AuthType enum
│   ├── integration_status.py # Status enum
│   └── integration.py         # Data models matching DB schema
│
├── utils/
│   ├── output.py              # Display formatting
│   └── secret_keeper.py       # AES encryption (for decrypt-config only)
│
└── config.py                  # CLI configuration
```

##  Code Organization

### TPSClient (`tps_cli/client/tps_client.py`)

**Purpose**: Thin wrapper around auto-generated OpenAPI clients

**What it contains**:
- Wrapper around generated OpenAPI clients (from `tps_cli/generated/`)
- Configuration of API clients with headers (X-Tenant-ID, X-User-ID)
- Convenience methods for common operations

**What it does NOT contain**:
- Business logic
- OAuth implementations
- Token handling logic
- Encryption/decryption
- Validation rules
- Manual HTTP calls (delegated to generated clients)

**Auto-Generated Clients**:

The CLI uses auto-generated Python clients from TPS OpenAPI specifications, mirroring the Java approach used in esd-app:

```python
# Generated from OpenAPI specs (similar to Java's tps-app-marketplace-client, tps-integration-client, etc.)
from tps_cli.generated.app_marketplace.api.app_marketplace_api import AppMarketplaceApi
from tps_cli.generated.integration.api.integration_api import IntegrationApi

class TPSClient:
    def __init__(self, base_url, tenant_id):
        """Initialize with auto-generated clients"""
        # Configure API clients
        config = Configuration(host=base_url)
        config.default_headers = {"X-Tenant-ID": str(tenant_id)}

        api_client = ApiClient(configuration=config)
        self.app_marketplace = AppMarketplaceApi(api_client=api_client)
        self.integration = IntegrationApi(api_client=api_client)

    def generate_install_url(self, app_id, redirect_uri, state, config=None):
        """Thin wrapper around generated client - no manual HTTP calls"""
        from tps_cli.generated.app_marketplace.models import InstallAppSettingRequestDTO

        request = InstallAppSettingRequestDTO(
            state=state, redirect_uri=redirect_uri, config=config
        )
        return self.app_marketplace.get_install_app_settings(app_id, request)
```

**Generating Clients**:

```bash
# Generate Python clients from TPS OpenAPI specs
python scripts/generate_clients.py

# See OPENAPI_CLIENT_GENERATION.md for details
```

This approach:
- ✅ Mirrors Java services (esd-app uses tps-*-client artifacts)
- ✅ Always stays in sync with TPS OpenAPI specs
- ✅ Reduces manual code from 400+ lines to ~100 lines
- ✅ Provides full type safety and validation
- ✅ Auto-regenerates when TPS APIs change

### Integration Commands (`tps_cli/commands/integration.py`)

**Purpose**: User interface layer

**What it contains**:
- Typer command definitions
- User input parsing
- Display formatting
- Error handling
- Calls to TPSClient

**What it does NOT contain**:
- OAuth logic
- Database queries (except with `--db` flag for debugging)
- Business rules

## Benefits of This Architecture

### 1. Single Source of Truth
- OAuth handlers maintained in one place (TPS service)
- Bug fixes automatically available to CLI
- No version skew between CLI and service

### 2. Easy to Add New Integrations
Adding support for a new app (e.g., Slack, Azure AD):

**In TPS Service** (required):
1. Add `SlackHandler.java`
2. Configure OAuth settings
3. Deploy service

**In CLI** (automatic):
- No changes needed!
- All commands work immediately
- Just use app name: `tps integration generate-auth-url slack`

### 3. Maintainability
- Thin CLI is easy to maintain
- Most development happens in TPS service (Java)
- CLI updates are rare (only for new commands or UI improvements)

### 4. Testability
- Test OAuth logic once in TPS service
- CLI tests are simple (just HTTP call tests)
- Integration tests cover end-to-end flow

### 5. Consistency
- CLI behavior matches web UI behavior
- Both use same TPS service APIs
- Same error messages and responses

## Configuration

### TPS Service URL

**Config file** (`~/.tps-cli/config.yaml`):
```yaml
active_profile: local
profiles:
  local:
    tps_service:
      url: http://localhost:8093
      timeout: 30
    database:
      host: localhost
      port: 11432
      database: tps
      username: esd
      password: esd
```

### Multiple Environments

```yaml
profiles:
  local:
    tps_service:
      url: http://localhost:8093

  dev:
    tps_service:
      url: https://tps-dev.atomicwork.com

  prod:
    tps_service:
      url: https://tps.atomicwork.com
```

Switch environments:
```bash
tps config set-profile dev
```

## Debugging

### Check TPS Service Health

```bash
# Via CLI
tps integration list

# Direct curl
curl http://localhost:8093/actuator/health
```

### Compare API vs Database

```bash
# Via TPS API (decrypted)
tps integration get 1

# Direct database (encrypted)
tps integration get 1 --db

# Decrypt locally (for debugging)
tps integration decrypt-config 1
```

### View Raw API Response

```bash
# JSON output shows raw API response
tps integration get 1 --json
```

## Migration Notes

### Removed Components

The following components were removed/simplified:

1. **Local OAuth Handlers**
   - ~~`tps_cli/auth/handlers/workday.py`~~ → Use TPS service
   - ~~`tps_cli/auth/oauth2.py`~~ → Use TPS service
   - ~~`tps_cli/auth/base.py`~~ → Use TPS service

2. **Direct Third-Party API Calls**
   - CLI no longer calls Workday/Slack/etc. directly
   - All calls go through TPS service

### Kept Components

1. **Database Repository** (`tps_cli/database/`)
   - Kept for debugging with `--db` flag
   - Useful for testing direct database queries
   - Not used by default

2. **SecretKeeper** (`tps_cli/utils/secret_keeper.py`)
   - Only for `decrypt-config` command
   - Helps debug encrypted credentials
   - Not used in normal flow

## Best Practices

### For CLI Development

1. **Keep it thin** - Don't add business logic to CLI
2. **Just HTTP calls** - TPSClient should only make HTTP requests
3. **Display only** - CLI formats and displays data
4. **Defer to service** - When in doubt, add logic to TPS service

### For TPS Service Development

1. **Design APIs first** - Think about how CLI will use them
2. **Return rich responses** - Include all data CLI needs to display
3. **Handle errors well** - CLI just passes error messages to user
4. **Document endpoints** - Keep OpenAPI specs up to date

### For Testing

1. **Test service first** - Most logic is in TPS service
2. **CLI integration tests** - Test that CLI calls right endpoints
3. **Mock TPS service** - Use test server for CI/CD
4. **Database tests** - Test `--db` flag with test database

## Troubleshooting

### "Connection refused" Error

```
Failed to generate auth URL: Connection refused
```

**Solution**: TPS service is not running
```bash
cd /path/to/third-party-app-integration
./mvnw spring-boot:run
```

### "404 Not Found" Error

```
Failed to generate auth URL: 404 Client Error
```

**Solution**: API endpoint doesn't exist in TPS service
- Check TPS service version
- Verify endpoint in OpenAPI spec
- Check CLI is using correct URL

### Encrypted Configuration

```
Integration 1 has encrypted credentials in configuration
```

**Solution**: Use TPS API (default) or decrypt command
```bash
# Via TPS API (decrypted automatically)
tps integration get 1

# Or decrypt locally
tps integration decrypt-config 1
```

## OpenAPI Client Generation

The CLI uses **auto-generated OpenAPI clients** from TPS service specifications, mirroring the approach used in Java services (esd-app, Temporal workflows).

### Benefits

- ✅ Same approach as Java services (tps-app-marketplace-client, tps-integration-client, etc.)
- ✅ Always in sync with TPS OpenAPI specs
- ✅ Full type safety and validation
- ✅ Auto-generated documentation
- ✅ Reduces manual code by ~75%

### Usage

```bash
# Generate all clients from TPS OpenAPI specs
python scripts/generate_clients.py

# Generate with integration-specific clients (Okta, Slack, etc.)
python scripts/generate_clients.py --include-integrations

# See OPENAPI_CLIENT_GENERATION.md for full documentation
```

### Available Clients

**Management APIs** (generated by default):
- `app_marketplace` - OAuth flows, app installation
- `integration` - Integration management
- `credential` - Credential management
- `webhook` - Webhook management
- `action` - Action management

**Integration APIs** (optional, use `--include-integrations`):
- `okta`, `slack`, `azure_ad`, `workday`, `ms_teams`, `github`, `sharepoint`, `confluence`

For detailed information, see [OPENAPI_CLIENT_GENERATION.md](OPENAPI_CLIENT_GENERATION.md).

## Future Enhancements

### Planned Features

1. **Auto-discovery** - CLI discovers available apps from TPS
2. **Webhook testing** - Send test webhooks to TPS
3. **Integration testing** - End-to-end OAuth flow testing
4. **Batch operations** - Create multiple integrations at once
5. **CI/CD Integration** - Auto-regenerate clients when TPS specs change

### Won't Implement in CLI

1. ❌ OAuth handlers - Always in TPS service
2. ❌ Token encryption - Always in TPS service
3. ❌ Business rules - Always in TPS service
4. ❌ Direct third-party API calls - Always through TPS service
5. ❌ Manual HTTP client code - Use auto-generated clients instead

## Summary

| Aspect | Old Architecture | New Architecture |
|--------|------------------|------------------|
| OAuth Logic | ✗ Duplicated in CLI | ✓ Only in TPS service |
| API Calls | ✗ CLI → Third-party | ✓ CLI → TPS → Third-party |
| Maintenance | ✗ Two codebases | ✓ One source of truth |
| Adding Apps | ✗ Update both CLI & TPS | ✓ Update TPS only |
| Testing | ✗ Test OAuth twice | ✓ Test OAuth once |
| Consistency | ✗ CLI may differ from UI | ✓ Same APIs for all clients |

The TPS CLI is now a proper thin client that delegates all business logic to the TPS service, resulting in a cleaner, more maintainable, and more reliable system.
