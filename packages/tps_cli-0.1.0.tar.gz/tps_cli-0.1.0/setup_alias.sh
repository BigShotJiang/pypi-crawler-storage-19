#!/bin/bash

# TPS CLI Alias Setup Script
# This script adds a convenient alias for the TPS CLI

TPS_DIR="$HOME/Desktop/Cli/TPS"
SHELL_RC=""

# Detect shell
if [ -n "$ZSH_VERSION" ]; then
    SHELL_RC="$HOME/.zshrc"
    SHELL_NAME="zsh"
elif [ -n "$BASH_VERSION" ]; then
    SHELL_RC="$HOME/.bashrc"
    SHELL_NAME="bash"
else
    echo "Unsupported shell. Please add the alias manually."
    exit 1
fi

echo "Detected shell: $SHELL_NAME"
echo "Configuration file: $SHELL_RC"

# Check if alias already exists
if grep -q "alias tps=" "$SHELL_RC"; then
    echo "TPS alias already exists in $SHELL_RC"
    echo "Current alias:"
    grep "alias tps=" "$SHELL_RC"
    exit 0
fi

# Add alias
echo "" >> "$SHELL_RC"
echo "# TPS CLI alias" >> "$SHELL_RC"
echo "alias tps='cd $TPS_DIR && source .venv/bin/activate && python -m tps_cli.main'" >> "$SHELL_RC"

echo "✓ Added TPS CLI alias to $SHELL_RC"
echo ""
echo "To use the alias, either:"
echo "  1. Restart your terminal"
echo "  2. Run: source $SHELL_RC"
echo ""
echo "Then you can use: tps <command>"
echo ""
echo "Examples:"
echo "  tps version"
echo "  tps integration list"
echo "  tps integration get 123"
echo ""
