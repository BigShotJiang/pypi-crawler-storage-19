# PyPI Deployment Guide

This guide explains how to build and publish the TPS CLI to PyPI.

## Prerequisites

1. **PyPI Account**: Create account at https://pypi.org/account/register/
2. **API Token**: Generate token at https://pypi.org/manage/account/token/

## Build the Package (Using uv - Recommended)

### Quick Build

```bash
./scripts/build_with_uv.sh
```

Or manually:

### 1. Clean Previous Builds

```bash
rm -rf dist/ build/ *.egg-info
```

### 2. Update Version

Edit `pyproject.toml`:
```toml
version = "0.1.0"  # Update this for each release
```

### 3. Build Distribution with uv

```bash
uv build
```

This creates:
- `dist/tps_cli-0.1.0-py3-none-any.whl` (wheel)
- `dist/tps-cli-0.1.0.tar.gz` (source distribution)

### 4. Verify Build

```bash
ls -lh dist/
```

## Alternative: Build with pip/twine

If you prefer the traditional approach:

```bash
# Install tools
pip install build twine

# Build
python -m build

# Check
ls -lh dist/
```

## Test Locally

Before publishing, test the package locally:

```bash
# Install from local build
pip install dist/tps_cli-0.1.0-py3-none-any.whl

# Or test with uvx
uvx --from dist/tps_cli-0.1.0-py3-none-any.whl tps-cli version
```

## Publish to TestPyPI (Recommended First)

### 1. Create TestPyPI Account

https://test.pypi.org/account/register/

### 2. Generate TestPyPI Token

https://test.pypi.org/manage/account/token/

### 3. Configure Credentials

```bash
# Option 1: Use .pypirc file
cat > ~/.pypirc << EOF
[testpypi]
  username = __token__
  password = pypi-YOUR_TEST_TOKEN_HERE
EOF
```

### 4. Upload to TestPyPI

**Using uv (recommended):**
```bash
uv publish --token <your-testpypi-token> \
  --publish-url https://test.pypi.org/legacy/ \
  dist/*
```

**Using twine:**
```bash
python -m twine upload --repository testpypi dist/*
```

### 5. Test Installation from TestPyPI

```bash
# Using pip
pip install --index-url https://test.pypi.org/simple/ tps-cli

# Using pipx
pipx install --index-url https://test.pypi.org/simple/ tps-cli

# Using uvx
uvx --from https://test.pypi.org/simple/tps-cli tps-cli version
```

## Publish to PyPI (Production)

### 1. Get PyPI Token

https://pypi.org/manage/account/token/

### 2. Configure Credentials

```bash
cat > ~/.pypirc << EOF
[pypi]
  username = __token__
  password = pypi-YOUR_PRODUCTION_TOKEN_HERE
EOF
```

### 3. Upload to PyPI

**Using uv (recommended):**
```bash
uv publish --token <your-pypi-token> dist/*
```

**Using twine:**
```bash
python -m twine upload dist/*
```

### 4. Verify Publication

Check your package at: https://pypi.org/project/tps-cli/

## Install from PyPI

Once published, users can install:

```bash
# Using uvx (no installation)
uvx tps-cli init
uvx tps-cli health

# Using pipx (persistent)
pipx install tps-cli
tps init

# Using pip
pip install tps-cli
tps init
```

## Version Management

### Semantic Versioning

Follow [SemVer](https://semver.org/):
- **MAJOR.MINOR.PATCH** (e.g., 1.2.3)
- **MAJOR**: Breaking changes
- **MINOR**: New features (backward compatible)
- **PATCH**: Bug fixes

### Update Version

```bash
# Edit pyproject.toml
version = "0.2.0"  # Update here

# Rebuild
rm -rf dist/
python -m build

# Upload new version
python -m twine upload dist/*
```

## CI/CD Automation (Optional)

### GitHub Actions Workflow

Create `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: |
          pip install build twine

      - name: Build package
        run: python -m build

      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*
```

Then:
1. Add `PYPI_API_TOKEN` to GitHub Secrets
2. Create a GitHub Release
3. Package automatically publishes to PyPI

## Troubleshooting

### Issue: Module not found after install

**Solution**: Ensure `[project.scripts]` in `pyproject.toml` is correct:
```toml
[project.scripts]
tps = "tps_cli.main:main"
```

### Issue: Missing files in package

**Solution**: Check `MANIFEST.in` includes all necessary files:
```
include README.md
include LICENSE
recursive-include tps_cli/generated *.py
```

### Issue: Import errors

**Solution**: Ensure all dependencies are in `pyproject.toml`:
```toml
dependencies = [
    "typer>=0.21.1",
    # ... all other deps
]
```

### Issue: Upload fails - "File already exists"

**Solution**: You can't re-upload the same version. Increment version in `pyproject.toml`.

## Package Checklist

Before publishing, verify:

- [ ] Version updated in `pyproject.toml`
- [ ] README.md updated with latest features
- [ ] LICENSE file present
- [ ] All dependencies listed in `pyproject.toml`
- [ ] Entry point configured: `tps = "tps_cli.main:main"`
- [ ] Package builds successfully: `python -m build`
- [ ] Package installs locally: `pip install dist/*.whl`
- [ ] CLI commands work: `tps version`, `tps health`
- [ ] Tested on TestPyPI first
- [ ] CHANGELOG updated (if exists)

## Resources

- PyPI: https://pypi.org/
- TestPyPI: https://test.pypi.org/
- Python Packaging Guide: https://packaging.python.org/
- Twine Documentation: https://twine.readthedocs.io/
- Build Documentation: https://build.pypa.io/

## Support

For issues with deployment, check:
- https://github.com/pypa/packaging-problems
- https://packaging.python.org/discussions/

Built for AtomicWork TPS Team
