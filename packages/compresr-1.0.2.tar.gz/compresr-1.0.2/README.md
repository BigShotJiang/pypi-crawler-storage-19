# Compresr Python SDK

Intelligent prompt compression to optimize LLM costs and performance.

## Installation

```bash
pip install compresr
```

## Quick Start

### API Key Setup

Get your API key from [compresr.ai](https://compresr.ai) and set it up:

```python
import os
os.environ["COMPRESR_API_KEY"] = "cmp_your_api_key_here"

# Or pass directly to client
from compresr import CompletionClient
client = CompletionClient(api_key="cmp_your_api_key_here")
```

### Completion Client (Compression + LLM)

Compress your prompts and get LLM responses in one call:

```python
from compresr import CompletionClient

client = CompletionClient(api_key="cmp_your_api_key")

# Generate completion with compression
result = client.generate(
    text="Your very long prompt that needs compression...",
    target_model="gpt-4o-mini",
    compression_model_name="microsoft/DialoGPT-medium"
)

print(result.data.target_model_response)
print(f"Compression ratio: {result.data.compression_ratio}")
print(f"Tokens saved: {result.data.tokens_saved}")
```

### Compression Client (Compression Only)

Get compressed prompts for use with your own LLM:

```python
from compresr import CompressionClient

client = CompressionClient(api_key="cmp_your_api_key")

# Get compressed prompt
result = client.generate(
    prompt="Your very long prompt that needs compression...",
    compression_model_name="microsoft/DialoGPT-medium"
)

compressed_prompt = result.data.compressed_prompt
# Now use with your own LLM: openai.chat(messages=[{"role": "user", "content": compressed_prompt}])
```

## Streaming Support

Both clients support real-time streaming:

```python
# Completion streaming
for chunk in client.generate_stream(
    text="Write a long story about...",
    target_model="gpt-4o-mini",
    compression_model_name="microsoft/DialoGPT-medium"
):
    print(chunk.content, end="", flush=True)

# Compression streaming  
compression_client = CompressionClient(api_key="...")
for chunk in compression_client.generate_stream(
    prompt="Your long prompt...",
    compression_model_name="microsoft/DialoGPT-medium"
):
    print(chunk.content, end="", flush=True)
```

## Async Support

All methods have async variants:

```python
import asyncio
from compresr import CompletionClient

async def main():
    client = CompletionClient(api_key="...")
    
    result = await client.generate_async(
        text="Your prompt...",
        target_model="gpt-4o-mini",
        compression_model_name="microsoft/DialoGPT-medium"
    )
    
    print(result.data.target_model_response)
    await client.close()

asyncio.run(main())
```

## Batch Processing

Process multiple requests efficiently:

```python
client = CompressionClient(api_key="...")
results = client.generate_batch([
    {
        "prompt": "First prompt to compress...",
        "compression_model_name": "microsoft/DialoGPT-medium"
    },
    {
        "prompt": "Second prompt to compress...", 
        "compression_model_name": "microsoft/DialoGPT-medium"
    }
])

for result in results:
    print(f"Compressed: {result.data.compressed_prompt}")
```

## Usage Tracking

Monitor your credits and spending:

```python
usage = client.get_usage()
print(f"Credits remaining: {usage.data.credits_remaining}")
print(f"Current balance: ${usage.data.balance_usd}")
print(f"Monthly budget: ${usage.data.monthly_budget}")
```

## Key Features

- **🗜️ Intelligent Compression**: Reduce prompt lengths while preserving meaning
- **💰 Cost Optimization**: Save up to 50% on LLM API costs
- **⚡ Dual Modes**: Compression-only or Compression + LLM completion
- **🔄 Streaming Support**: Real-time response streaming
- **📊 Usage Tracking**: Monitor credits, costs, and compression ratios
- **🔗 Async Ready**: Full async/await support
- **📦 Batch Processing**: Handle multiple requests efficiently

## Available Models

**Compression Models:**
- `microsoft/DialoGPT-medium` (recommended)
- `microsoft/DialoGPT-large`
- Custom models (contact us)

**Target LLM Models:**
- OpenAI: `gpt-4o`, `gpt-4o-mini`, `gpt-3.5-turbo`
- Anthropic: `claude-3-sonnet`, `claude-3-haiku`
- And many more...

## Error Handling

```python
from compresr import CompletionClient
from compresr.exceptions import CompresrError, AuthenticationError, RateLimitError

client = CompletionClient(api_key="your_key")

try:
    result = client.generate(
        text="Your prompt...",
        target_model="gpt-4o-mini",
        compression_model_name="microsoft/DialoGPT-medium"
    )
except AuthenticationError:
    print("Invalid API key")
except RateLimitError:
    print("Rate limit exceeded")
except CompresrError as e:
    print(f"API error: {e}")
```

## Authentication

The Compresr SDK uses API key authentication. You can get your API key from [compresr.ai](https://compresr.ai):

1. Create an account at [compresr.ai](https://compresr.ai)
2. Navigate to your API Keys section  
3. Generate a new API key
4. Use it with the SDK

## Requirements

- Python 3.9+
- `httpx >= 0.27.0`
- `pydantic >= 2.10.0`

## License

MIT License

## Support

- 📖 Documentation: [docs.compresr.ai](https://docs.compresr.ai)
- 💬 Support: [support@compresr.ai](mailto:support@compresr.ai)
- 🐛 Issues: [GitHub Issues](https://github.com/compresr/sdk/issues)
- 🌐 Website: [compresr.ai](https://compresr.ai)