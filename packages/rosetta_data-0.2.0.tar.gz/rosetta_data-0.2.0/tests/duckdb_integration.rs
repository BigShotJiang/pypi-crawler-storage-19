// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for DuckDB extension functionality
//!
//! These tests verify the DuckDB extension can open and read files.
//! Note: Full DuckDB integration requires building as a C ABI extension.

use arrow::array::{Int32Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use parquet::arrow::ArrowWriter;
use std::sync::Arc;
use tempfile::TempDir;

use rosetta::duckdb::{DuckDbExtension, DuckDbExtensionConfig};

/// Create a test Parquet file
fn create_test_parquet(path: &std::path::Path) {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
    ]));

    let ids = Int32Array::from(vec![1, 2, 3, 4, 5]);
    let names = StringArray::from(vec![
        Some("Alice"),
        Some("Bob"),
        Some("Charlie"),
        Some("Diana"),
        Some("Eve"),
    ]);

    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

    let file = std::fs::File::create(path).unwrap();
    let mut writer = ArrowWriter::try_new(file, schema, None).unwrap();
    writer.write(&batch).unwrap();
    writer.close().unwrap();
}

#[test]
fn test_extension_default_config() {
    let ext = DuckDbExtension::default_config().unwrap();
    let stats = ext.cache_stats();
    assert_eq!(stats.entries, 0);
    assert_eq!(stats.max_bytes, 1024 * 1024 * 1024); // 1GB default
    println!("✓ DuckDB extension created with default config");
}

#[test]
fn test_extension_custom_config() {
    let config = DuckDbExtensionConfig {
        enable_cache: false,
        max_cache_bytes: 100 * 1024 * 1024, // 100MB
        enable_replacement_scan: false,
        ..Default::default()
    };

    let ext = DuckDbExtension::new(config).unwrap();
    let stats = ext.cache_stats();
    assert_eq!(stats.max_bytes, 100 * 1024 * 1024);
    println!("✓ DuckDB extension created with custom config");
}

#[test]
fn test_needs_transcode() {
    let ext = DuckDbExtension::default_config().unwrap();

    // Should transcode
    assert!(ext.needs_transcode("data.vortex"));
    assert!(ext.needs_transcode("/path/to/data.lance"));
    assert!(ext.needs_transcode("s3://bucket/data.f3"));
    assert!(ext.needs_transcode("DATA.VORTEX")); // Case insensitive

    // Should NOT transcode
    assert!(!ext.needs_transcode("data.parquet"));
    assert!(!ext.needs_transcode("data.csv"));
    assert!(!ext.needs_transcode("data"));

    println!("✓ needs_transcode correctly identifies formats");
}

#[test]
fn test_open_parquet_file() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");
    create_test_parquet(&parquet_path);

    let ext = DuckDbExtension::default_config().unwrap();
    let handle = ext.open(parquet_path.to_str().unwrap()).unwrap();

    // File should have content
    assert!(handle.size() > 0);
    println!("✓ Opened Parquet file: {} bytes", handle.size());
}

#[test]
fn test_file_handle_read_seek() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");
    create_test_parquet(&parquet_path);

    let ext = DuckDbExtension::default_config().unwrap();
    let mut handle = ext.open(parquet_path.to_str().unwrap()).unwrap();

    // Initial position is 0
    assert_eq!(handle.tell(), 0);

    // Read Parquet magic bytes (PAR1)
    let mut buf = [0u8; 4];
    let read = handle.read(&mut buf);
    assert_eq!(read, 4);
    assert_eq!(&buf, b"PAR1");
    assert_eq!(handle.tell(), 4);

    // Seek to end - 4 (footer magic)
    let end = handle.size();
    handle.seek(end - 4);
    let mut footer_buf = [0u8; 4];
    handle.read(&mut footer_buf);
    assert_eq!(&footer_buf, b"PAR1");

    // Seek back to start
    handle.seek(0);
    assert_eq!(handle.tell(), 0);

    println!("✓ File handle read/seek works correctly");
}

#[test]
fn test_file_info() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("info_test.parquet");
    create_test_parquet(&parquet_path);

    let ext = DuckDbExtension::default_config().unwrap();
    let info = ext.file_info(parquet_path.to_str().unwrap()).unwrap();

    assert!(info.is_file);
    assert!(!info.is_dir);
    assert!(info.size > 0);

    println!("✓ file_info returns correct metadata: {} bytes", info.size);
}

#[test]
fn test_list_files() {
    let temp_dir = TempDir::new().unwrap();

    // Create multiple files
    create_test_parquet(&temp_dir.path().join("a.parquet"));
    create_test_parquet(&temp_dir.path().join("b.parquet"));
    std::fs::write(temp_dir.path().join("c.csv"), "id,name\n1,test").unwrap();

    let ext = DuckDbExtension::default_config().unwrap();
    let files = ext.list_files(temp_dir.path().to_str().unwrap()).unwrap();

    assert_eq!(files.len(), 3);
    assert!(files.contains(&"a.parquet".to_string()));
    assert!(files.contains(&"b.parquet".to_string()));
    assert!(files.contains(&"c.csv".to_string()));

    println!("✓ list_files returns {} entries", files.len());
}

#[test]
fn test_cache_operations() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("cached.parquet");
    create_test_parquet(&parquet_path);

    let ext = DuckDbExtension::default_config().unwrap();

    // Initial stats
    let stats = ext.cache_stats();
    assert_eq!(stats.entries, 0);

    // Open file (populates cache)
    let _handle = ext.open(parquet_path.to_str().unwrap()).unwrap();

    let stats = ext.cache_stats();
    assert_eq!(stats.entries, 1);
    assert!(stats.total_bytes > 0);

    // Open again (should hit cache)
    let _handle2 = ext.open(parquet_path.to_str().unwrap()).unwrap();
    let stats = ext.cache_stats();
    assert_eq!(stats.entries, 1); // Still 1, not 2

    // Clear cache
    ext.clear_cache();
    let stats = ext.cache_stats();
    assert_eq!(stats.entries, 0);
    assert_eq!(stats.total_bytes, 0);

    println!("✓ Cache operations work correctly");
}

#[test]
fn test_replacement_scan() {
    let ext = DuckDbExtension::default_config().unwrap();

    // Parquet should not trigger replacement scan
    assert!(ext.replacement_scan("data.parquet").is_none());

    // Vortex should trigger (but will fail on non-existent file)
    let result = ext.replacement_scan("data.vortex");
    assert!(result.is_some()); // Should try to transcode
    assert!(result.unwrap().is_err()); // File doesn't exist

    println!("✓ Replacement scan triggers for correct extensions");
}

#[test]
fn test_rosetta_url_scheme() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("url_test.parquet");
    create_test_parquet(&parquet_path);

    let ext = DuckDbExtension::default_config().unwrap();

    // Open with rosetta:// prefix
    let rosetta_url = format!("rosetta://{}", parquet_path.display());
    let handle = ext.open(&rosetta_url).unwrap();

    assert!(handle.size() > 0);
    println!("✓ rosetta:// URL scheme works");
}

#[cfg(feature = "vortex-reader")]
#[test]
fn test_vortex_transcode_via_extension() {
    use vortex::file::VortexWriteOptions;
    use vortex_array::arrays::{StructArray, VarBinArray};
    use vortex_array::IntoArray;
    use vortex_buffer::buffer;

    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("data.vortex");

    // Create Vortex file
    let ids = buffer![1i32, 2, 3, 4, 5].into_array();
    let names = VarBinArray::from(vec!["Alice", "Bob", "Charlie", "Diana", "Eve"]).into_array();
    let st = StructArray::from_fields(&[("id", ids), ("name", names)]).unwrap();
    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .unwrap();
    std::fs::write(&vortex_path, buf).unwrap();

    // Open through DuckDB extension
    let ext = DuckDbExtension::default_config().unwrap();
    let mut handle = ext.open(vortex_path.to_str().unwrap()).unwrap();

    // Should receive Parquet bytes (transcoded)
    let mut magic = [0u8; 4];
    handle.read(&mut magic);
    assert_eq!(&magic, b"PAR1", "Should transcode to Parquet");

    println!("✓ Vortex → Parquet transcode via DuckDB extension");
}

#[cfg(feature = "lance-reader")]
#[test]
fn test_lance_transcode_via_extension() {
    use arrow::record_batch::RecordBatchIterator;
    use lance::Dataset;

    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("data.lance");

    // Create Lance dataset using a separate runtime to avoid conflict
    // with DuckDB extension's internal runtime
    {
        let rt = tokio::runtime::Runtime::new().unwrap();
        rt.block_on(async {
            let schema = Arc::new(Schema::new(vec![
                Field::new("id", DataType::Int32, false),
                Field::new("name", DataType::Utf8, true),
            ]));
            let ids = Int32Array::from(vec![1, 2, 3]);
            let names = StringArray::from(vec![Some("X"), Some("Y"), Some("Z")]);
            let batch =
                RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();
            let reader = RecordBatchIterator::new(vec![Ok(batch)], schema);
            Dataset::write(reader, lance_path.to_str().unwrap(), None)
                .await
                .unwrap();
        });
    } // Runtime dropped here

    // Open through DuckDB extension (uses its own internal runtime)
    let ext = DuckDbExtension::default_config().unwrap();
    let mut handle = ext.open(lance_path.to_str().unwrap()).unwrap();

    // Should receive Parquet bytes (transcoded)
    let mut magic = [0u8; 4];
    handle.read(&mut magic);
    assert_eq!(&magic, b"PAR1", "Should transcode to Parquet");

    println!("✓ Lance → Parquet transcode via DuckDB extension");
}
