// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for S3-compatible proxy server
//!
//! These tests verify that the proxy can serve transcoded files.

use arrow::array::{Int32Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use parquet::arrow::ArrowWriter;
use std::sync::Arc;
use tempfile::TempDir;

use rosetta::proxy::{S3Proxy, S3ProxyConfig};

/// Create a test Parquet file
fn create_test_parquet(path: &std::path::Path) {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
    ]));

    let ids = Int32Array::from(vec![1, 2, 3, 4, 5]);
    let names = StringArray::from(vec![
        Some("Alice"),
        Some("Bob"),
        Some("Charlie"),
        Some("Diana"),
        Some("Eve"),
    ]);

    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

    let file = std::fs::File::create(path).unwrap();
    let mut writer = ArrowWriter::try_new(file, schema, None).unwrap();
    writer.write(&batch).unwrap();
    writer.close().unwrap();
}

#[test]
fn test_proxy_config_default() {
    let config = S3ProxyConfig::default();
    assert_eq!(config.bind_addr.port(), 9000);
    assert!(config.enable_cache);
    println!("✓ Default proxy config created");
}

#[test]
fn test_proxy_config_local() {
    let config = S3ProxyConfig::local(std::path::PathBuf::from("/data"));
    assert_eq!(config.local_root, Some(std::path::PathBuf::from("/data")));
    println!("✓ Local proxy config created");
}

#[test]
fn test_proxy_creation() {
    let temp_dir = TempDir::new().unwrap();
    let config = S3ProxyConfig::local(temp_dir.path().to_path_buf());
    let _proxy = S3Proxy::new(config);
    println!("✓ S3 proxy created successfully");
}

#[tokio::test]
async fn test_proxy_get_object() {
    let temp_dir = TempDir::new().unwrap();
    let bucket_dir = temp_dir.path().join("test-bucket");
    std::fs::create_dir_all(&bucket_dir).unwrap();

    // Create test file
    let parquet_path = bucket_dir.join("test.parquet");
    create_test_parquet(&parquet_path);

    // Create proxy pointing to temp dir
    let config = S3ProxyConfig::local(temp_dir.path().to_path_buf());
    let proxy = S3Proxy::new(config);

    // Get object through proxy API
    let result = proxy.get_object("test-bucket", "test.parquet").await;

    assert!(result.is_ok(), "get_object failed: {:?}", result);
    let bytes = result.unwrap();

    // Verify it's valid Parquet (starts and ends with PAR1)
    assert!(bytes.len() > 8, "Result too small");
    assert_eq!(&bytes[0..4], b"PAR1", "Not a valid Parquet file (header)");
    assert_eq!(
        &bytes[bytes.len() - 4..],
        b"PAR1",
        "Not a valid Parquet file (footer)"
    );

    println!("✓ get_object returned valid Parquet: {} bytes", bytes.len());
}

#[tokio::test]
async fn test_proxy_cache() {
    let temp_dir = TempDir::new().unwrap();
    let bucket_dir = temp_dir.path().join("cache-bucket");
    std::fs::create_dir_all(&bucket_dir).unwrap();

    let parquet_path = bucket_dir.join("cached.parquet");
    create_test_parquet(&parquet_path);

    let mut config = S3ProxyConfig::local(temp_dir.path().to_path_buf());
    config.enable_cache = true;
    let proxy = S3Proxy::new(config);

    // First request (should populate cache)
    let result1 = proxy.get_object("cache-bucket", "cached.parquet").await;
    assert!(result1.is_ok());

    // Second request (should hit cache)
    let result2 = proxy.get_object("cache-bucket", "cached.parquet").await;
    assert!(result2.is_ok());

    // Results should be identical
    assert_eq!(result1.unwrap(), result2.unwrap());
    println!("✓ Cache working - identical results on repeated requests");
}

#[tokio::test]
async fn test_proxy_missing_file() {
    let temp_dir = TempDir::new().unwrap();
    let config = S3ProxyConfig::local(temp_dir.path().to_path_buf());
    let proxy = S3Proxy::new(config);

    // Try to get nonexistent file
    let result = proxy
        .get_object("missing-bucket", "nonexistent.parquet")
        .await;
    assert!(result.is_err());
    println!("✓ Missing file correctly returns error");
}

#[cfg(feature = "vortex-reader")]
#[tokio::test]
async fn test_proxy_transcode_vortex() {
    use vortex::file::VortexWriteOptions;
    use vortex_array::arrays::{StructArray, VarBinArray};
    use vortex_array::IntoArray;
    use vortex_buffer::buffer;

    let temp_dir = TempDir::new().unwrap();
    let bucket_dir = temp_dir.path().join("vortex-bucket");
    std::fs::create_dir_all(&bucket_dir).unwrap();

    // Create Vortex file
    let vortex_path = bucket_dir.join("data.vortex");
    let ids = buffer![1i32, 2, 3, 4, 5].into_array();
    let names = VarBinArray::from(vec!["A", "B", "C", "D", "E"]).into_array();
    let st = StructArray::from_fields(&[("id", ids), ("name", names)]).unwrap();
    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .unwrap();
    std::fs::write(&vortex_path, buf).unwrap();

    // Get through proxy (should transcode to Parquet)
    let config = S3ProxyConfig::local(temp_dir.path().to_path_buf());
    let proxy = S3Proxy::new(config);

    let result = proxy.get_object("vortex-bucket", "data.vortex").await;
    assert!(result.is_ok(), "Transcode failed: {:?}", result);

    let bytes = result.unwrap();
    assert_eq!(&bytes[0..4], b"PAR1", "Result is not Parquet");
    assert_eq!(&bytes[bytes.len() - 4..], b"PAR1");

    println!(
        "✓ Vortex → Parquet transcode via proxy: {} bytes",
        bytes.len()
    );
}

#[cfg(feature = "lance-reader")]
#[tokio::test]
async fn test_proxy_transcode_lance() {
    use arrow::record_batch::RecordBatchIterator;
    use lance::Dataset;

    let temp_dir = TempDir::new().unwrap();
    let bucket_dir = temp_dir.path().join("lance-bucket");
    std::fs::create_dir_all(&bucket_dir).unwrap();

    // Create Lance dataset
    let lance_path = bucket_dir.join("data.lance");
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
    ]));
    let ids = Int32Array::from(vec![1, 2, 3]);
    let names = StringArray::from(vec![Some("X"), Some("Y"), Some("Z")]);
    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();
    let reader = RecordBatchIterator::new(vec![Ok(batch)], schema);
    Dataset::write(reader, lance_path.to_str().unwrap(), None)
        .await
        .unwrap();

    // Get through proxy (should transcode to Parquet)
    let config = S3ProxyConfig::local(temp_dir.path().to_path_buf());
    let proxy = S3Proxy::new(config);

    let result = proxy.get_object("lance-bucket", "data.lance").await;
    assert!(result.is_ok(), "Transcode failed: {:?}", result);

    let bytes = result.unwrap();
    assert_eq!(&bytes[0..4], b"PAR1", "Result is not Parquet");

    println!(
        "✓ Lance → Parquet transcode via proxy: {} bytes",
        bytes.len()
    );
}
