// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for Lance format reading
//!
//! These tests verify that we can read real Lance datasets.

#![cfg(feature = "lance-reader")]

use arrow::array::{Int32Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use arrow::record_batch::RecordBatchIterator;
use lance::Dataset;
use std::sync::Arc;
use tempfile::TempDir;

/// Write a Lance dataset with test data
async fn write_lance_dataset(path: &std::path::Path) {
    // Create Arrow schema
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
    ]));

    // Create Arrow arrays
    let ids = Int32Array::from(vec![1, 2, 3, 4, 5]);
    let names = StringArray::from(vec![
        Some("Alice"),
        Some("Bob"),
        Some("Charlie"),
        Some("Diana"),
        Some("Eve"),
    ]);

    // Create RecordBatch
    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

    // Write to Lance dataset using arrow RecordBatchIterator
    let reader = RecordBatchIterator::new(vec![Ok(batch)], schema);

    Dataset::write(reader, path.to_str().unwrap(), None)
        .await
        .unwrap();
}

#[tokio::test]
async fn test_read_lance_dataset() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("test.lance");

    // Create test dataset
    write_lance_dataset(&lance_path).await;

    // Read it back with Rosetta
    let reader = rosetta::readers::LanceReader::open(&lance_path)
        .await
        .unwrap();

    // Verify schema
    assert_eq!(reader.schema.fields().len(), 2);
    assert_eq!(reader.schema.field(0).name(), "id");
    assert_eq!(reader.schema.field(1).name(), "name");

    // Read data
    let batches = reader.read_all().await.unwrap();
    assert!(!batches.is_empty());

    // Verify row count
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 5);

    println!(
        "✓ Read {} rows from Lance dataset with schema: {:?}",
        total_rows,
        reader
            .schema
            .fields()
            .iter()
            .map(|f| f.name())
            .collect::<Vec<_>>()
    );
}

#[tokio::test]
async fn test_lance_column_projection() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("test_proj.lance");

    write_lance_dataset(&lance_path).await;

    // Read with projection
    let reader = rosetta::readers::LanceReader::open(&lance_path)
        .await
        .unwrap();
    let batches = reader.read_projection(&["id".to_string()]).await.unwrap();

    assert!(!batches.is_empty());
    assert_eq!(batches[0].num_columns(), 1);
    assert_eq!(batches[0].schema().field(0).name(), "id");

    println!("✓ Column projection works - read only 'id' column");
}

#[tokio::test]
async fn test_unified_reader_lance() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("unified_test.lance");

    write_lance_dataset(&lance_path).await;

    // Read through UnifiedReader
    let reader = rosetta::UnifiedReader::open(&lance_path).await.unwrap();

    assert!(matches!(reader.format(), rosetta::FileFormat::Lance));

    let batches = reader.read_all().await.unwrap();
    assert!(!batches.is_empty());

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 5);

    println!("✓ UnifiedReader detected and read Lance format");
}

#[tokio::test]
async fn test_transcode_lance_to_parquet() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("transcode_test.lance");

    write_lance_dataset(&lance_path).await;

    // Transcode to Parquet
    let transcoder = rosetta::Transcoder::new();
    let result = transcoder.transcode_file(&lance_path).await.unwrap();

    // Verify it's valid Parquet
    assert_eq!(&result.bytes[0..4], b"PAR1");
    assert_eq!(&result.bytes[result.bytes.len() - 4..], b"PAR1");
    assert_eq!(result.source_format, rosetta::FileFormat::Lance);
    assert_eq!(result.num_rows, 5);
    assert_eq!(result.num_columns, 2);

    println!(
        "✓ Transcoded Lance → Parquet: {} bytes, {} rows",
        result.bytes.len(),
        result.num_rows
    );
}

#[tokio::test]
async fn test_lance_format_detection() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("detect.lance");

    write_lance_dataset(&lance_path).await;

    // Test format detection (Lance is directory-based)
    let detector = rosetta::FormatDetector::new();
    let format = detector.detect_file(&lance_path).await.unwrap();

    assert_eq!(format, rosetta::FileFormat::Lance);
    println!("✓ Format detection correctly identified Lance dataset");
}

#[tokio::test]
async fn test_lance_count_rows() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("count_test.lance");

    write_lance_dataset(&lance_path).await;

    let reader = rosetta::readers::LanceReader::open(&lance_path)
        .await
        .unwrap();

    let count = reader.count_rows().await.unwrap();
    assert_eq!(count, 5);

    println!("✓ count_rows() returns correct row count");
}

/// Write a larger Lance dataset for filter testing
async fn write_lance_dataset_large(path: &std::path::Path) {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
    ]));

    let ids = Int32Array::from(vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    let names = StringArray::from(vec![
        Some("Alice"),
        Some("Bob"),
        Some("Charlie"),
        Some("Diana"),
        Some("Eve"),
        Some("Frank"),
        Some("Grace"),
        Some("Henry"),
        Some("Ivy"),
        Some("Jack"),
    ]);

    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();
    let reader = RecordBatchIterator::new(vec![Ok(batch)], schema);

    Dataset::write(reader, path.to_str().unwrap(), None)
        .await
        .unwrap();
}

#[tokio::test]
async fn test_lance_filter_pushdown() {
    use rosetta::expr::{col, lit, FilterPushdownResult};

    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("filter_test.lance");

    write_lance_dataset_large(&lance_path).await;

    // Create filter: id > 5
    let filter = col("id").gt(lit(5i32));

    // Open reader and push filter
    let mut reader = rosetta::readers::LanceReader::open(&lance_path)
        .await
        .unwrap();

    let result = reader.push_filter(&filter).unwrap();
    assert!(
        matches!(result, FilterPushdownResult::Pushed),
        "Filter should be pushed to Lance"
    );

    // Read filtered data
    let batches = reader.read_all().await.unwrap();

    // Verify filter was applied
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    // Should have 5 rows where id > 5 (6, 7, 8, 9, 10)
    assert_eq!(
        total_rows, 5,
        "Filter pushdown should return only rows where id > 5"
    );

    println!(
        "✓ Lance filter pushdown works - filtered {} rows",
        total_rows
    );
}

#[tokio::test]
async fn test_lance_filter_pushdown_compound() {
    use rosetta::expr::{col, lit, FilterPushdownResult};

    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("filter_compound.lance");

    write_lance_dataset_large(&lance_path).await;

    // Create compound filter: id > 3 AND id < 8
    let filter = col("id").gt(lit(3i32)).and(col("id").lt(lit(8i32)));

    let mut reader = rosetta::readers::LanceReader::open(&lance_path)
        .await
        .unwrap();

    let result = reader.push_filter(&filter).unwrap();
    assert!(matches!(result, FilterPushdownResult::Pushed));

    let batches = reader.read_all().await.unwrap();
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();

    // Should have 4 rows where 3 < id < 8 (4, 5, 6, 7)
    assert_eq!(total_rows, 4, "Compound filter should return rows 4,5,6,7");

    println!(
        "✓ Lance compound filter works - filtered {} rows",
        total_rows
    );
}

#[tokio::test]
async fn test_lance_statistics() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("stats_test.lance");

    write_lance_dataset(&lance_path).await;

    let reader = rosetta::readers::LanceReader::open(&lance_path)
        .await
        .unwrap();

    let stats = reader.statistics();
    assert!(stats.is_some(), "Lance reader should provide statistics");

    let stats = stats.unwrap();
    // Statistics should have column entries for each field
    assert!(!stats.column_statistics.is_empty());

    println!(
        "✓ Lance statistics available with {} columns",
        stats.column_statistics.len()
    );
}

#[tokio::test]
async fn test_lance_partitions() {
    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("partitions_test.lance");

    write_lance_dataset(&lance_path).await;

    let reader = rosetta::readers::LanceReader::open(&lance_path)
        .await
        .unwrap();

    let partitions = reader.partitions().unwrap();
    assert!(!partitions.is_empty(), "Should have at least one partition");

    let partition = &partitions[0];
    assert_eq!(partition.id, 0);
    assert!(!partition.location.is_empty());

    println!("✓ Lance partitions: {} partition(s)", partitions.len());
}
