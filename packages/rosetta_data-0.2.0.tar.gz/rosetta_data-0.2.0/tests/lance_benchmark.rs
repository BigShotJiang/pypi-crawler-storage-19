// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Benchmark comparing Lance vs Parquet performance
//!
//! This test demonstrates Rosetta's value proposition for Lance:
//! - Read Lance datasets through the same API as Parquet
//! - Compare file sizes and read performance

#![cfg(feature = "lance-reader")]

use arrow::array::{Float64Array, Int64Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use arrow::record_batch::RecordBatchIterator;
use lance::Dataset;
use std::sync::Arc;
use std::time::Instant;
use tempfile::TempDir;

/// Generate test data as Arrow RecordBatch
fn generate_test_data(num_rows: usize) -> RecordBatch {
    let categories = ["Electronics", "Home", "Office", "Outdoor", "Sports"];
    let regions = ["North", "South", "East", "West", "Central"];

    let ids: Vec<i64> = (0..num_rows as i64).collect();
    let customer_ids: Vec<i64> = (0..num_rows).map(|i| (i % 10000) as i64).collect();
    let prices: Vec<f64> = (0..num_rows).map(|i| (i % 1000) as f64 * 0.99).collect();
    let category_values: Vec<&str> = (0..num_rows)
        .map(|i| categories[i % categories.len()])
        .collect();
    let region_values: Vec<&str> = (0..num_rows).map(|i| regions[i % regions.len()]).collect();

    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int64, false),
        Field::new("customer_id", DataType::Int64, false),
        Field::new("price", DataType::Float64, false),
        Field::new("category", DataType::Utf8, false),
        Field::new("region", DataType::Utf8, false),
    ]));

    RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int64Array::from(ids)),
            Arc::new(Int64Array::from(customer_ids)),
            Arc::new(Float64Array::from(prices)),
            Arc::new(StringArray::from(category_values)),
            Arc::new(StringArray::from(region_values)),
        ],
    )
    .unwrap()
}

/// Write data as Lance dataset
async fn write_lance_dataset(path: &std::path::Path, batch: &RecordBatch) {
    let reader = RecordBatchIterator::new(vec![Ok(batch.clone())], batch.schema());
    Dataset::write(reader, path.to_str().unwrap(), None)
        .await
        .unwrap();
}

/// Write data as Parquet file
fn write_parquet_file(path: &std::path::Path, batch: &RecordBatch) {
    use parquet::arrow::ArrowWriter;
    use parquet::basic::Compression;
    use parquet::file::properties::WriterProperties;

    let props = WriterProperties::builder()
        .set_compression(Compression::SNAPPY)
        .build();

    let file = std::fs::File::create(path).unwrap();
    let mut writer = ArrowWriter::try_new(file, batch.schema(), Some(props)).unwrap();
    writer.write(batch).unwrap();
    writer.close().unwrap();
}

/// Calculate directory size recursively
fn dir_size(path: &std::path::Path) -> u64 {
    walkdir::WalkDir::new(path)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .map(|e| e.metadata().map(|m| m.len()).unwrap_or(0))
        .sum()
}

#[tokio::test]
async fn test_lance_vs_parquet_benchmark() {
    let num_rows = 100_000;
    let iterations = 5;

    println!("\n=== Lance vs Parquet Benchmark ===");
    println!("Rows: {}", num_rows);
    println!("Iterations: {}", iterations);

    // Generate test data
    let batch = generate_test_data(num_rows);

    // Create temp directory
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("benchmark.parquet");
    let lance_path = temp_dir.path().join("benchmark.lance");

    // Write both formats
    write_parquet_file(&parquet_path, &batch);
    write_lance_dataset(&lance_path, &batch).await;

    // Get file sizes
    let parquet_size = std::fs::metadata(&parquet_path).unwrap().len();
    let lance_size = dir_size(&lance_path); // Lance is a directory

    println!("\n--- File Sizes ---");
    println!(
        "Parquet: {} bytes ({:.2} MiB)",
        parquet_size,
        parquet_size as f64 / 1024.0 / 1024.0
    );
    println!(
        "Lance:   {} bytes ({:.2} MiB)",
        lance_size,
        lance_size as f64 / 1024.0 / 1024.0
    );
    if lance_size < parquet_size {
        println!(
            "Compression: {:.1}% smaller",
            (1.0 - lance_size as f64 / parquet_size as f64) * 100.0
        );
    } else {
        println!(
            "Compression: {:.1}% larger",
            (lance_size as f64 / parquet_size as f64 - 1.0) * 100.0
        );
    }

    // Benchmark Parquet reading through Rosetta
    println!("\n--- Read Performance ---");

    let mut parquet_times = Vec::new();
    for _ in 0..iterations {
        let start = Instant::now();
        let reader = rosetta::UnifiedReader::open(&parquet_path).await.unwrap();
        let batches = reader.read_all().await.unwrap();
        let _rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        parquet_times.push(start.elapsed());
    }
    parquet_times.sort();
    let parquet_median = parquet_times[iterations / 2];

    // Benchmark Lance reading through Rosetta
    let mut lance_times = Vec::new();
    for _ in 0..iterations {
        let start = Instant::now();
        let reader = rosetta::UnifiedReader::open(&lance_path).await.unwrap();
        let batches = reader.read_all().await.unwrap();
        let _rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        lance_times.push(start.elapsed());
    }
    lance_times.sort();
    let lance_median = lance_times[iterations / 2];

    println!("Parquet read: {:.2?} (median)", parquet_median);
    println!("Lance read:   {:.2?} (median)", lance_median);

    let throughput_parquet = parquet_size as f64 / 1024.0 / 1024.0 / parquet_median.as_secs_f64();
    let throughput_lance = lance_size as f64 / 1024.0 / 1024.0 / lance_median.as_secs_f64();

    println!("Parquet throughput: {:.0} MiB/s", throughput_parquet);
    println!("Lance throughput:   {:.0} MiB/s", throughput_lance);

    // Summary
    println!("\n=== Summary ===");
    if lance_size < parquet_size {
        println!(
            "✓ Lance is {:.1}% smaller than Parquet",
            (1.0 - lance_size as f64 / parquet_size as f64) * 100.0
        );
    } else {
        println!(
            "✗ Lance is {:.1}% larger than Parquet",
            (lance_size as f64 / parquet_size as f64 - 1.0) * 100.0
        );
    }

    if lance_median < parquet_median {
        println!(
            "✓ Lance is {:.1}% faster to read",
            (1.0 - lance_median.as_secs_f64() / parquet_median.as_secs_f64()) * 100.0
        );
    } else {
        println!(
            "✗ Lance is {:.1}% slower to read",
            (lance_median.as_secs_f64() / parquet_median.as_secs_f64() - 1.0) * 100.0
        );
    }

    println!("✓ Both formats read through same Rosetta API!");
}

#[tokio::test]
async fn test_lance_transcoding_roundtrip() {
    println!("\n=== Lance → Parquet Transcoding Test ===");

    let num_rows = 10_000;
    let batch = generate_test_data(num_rows);

    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("source.lance");

    // Write Lance dataset
    write_lance_dataset(&lance_path, &batch).await;
    let lance_size = dir_size(&lance_path);

    // Transcode to Parquet
    let start = Instant::now();
    let transcoder = rosetta::Transcoder::new();
    let result = transcoder.transcode_file(&lance_path).await.unwrap();
    let transcode_time = start.elapsed();

    println!("Source format: {:?}", result.source_format);
    println!("Rows: {}", result.num_rows);
    println!("Columns: {}", result.num_columns);
    println!("Lance size: {} bytes", lance_size);
    println!("Parquet output: {} bytes", result.bytes.len());
    println!("Transcode time: {:.2?}", transcode_time);

    // Verify the transcoded Parquet is valid
    assert_eq!(
        &result.bytes[0..4],
        b"PAR1",
        "Should start with Parquet magic"
    );
    assert_eq!(
        &result.bytes[result.bytes.len() - 4..],
        b"PAR1",
        "Should end with Parquet magic"
    );
    assert_eq!(result.num_rows, num_rows);
    assert_eq!(result.num_columns, 5);

    // Read the transcoded Parquet
    let parquet_reader = rosetta::readers::ParquetReader::from_bytes(result.bytes.clone().into())
        .await
        .unwrap();
    let parquet_batches = parquet_reader.read_all().await.unwrap();
    let parquet_rows: usize = parquet_batches.iter().map(|b| b.num_rows()).sum();

    assert_eq!(parquet_rows, num_rows);
    println!("✓ Transcoded Parquet readable: {} rows", parquet_rows);
    println!("✓ Legacy readers can now read this Lance data as Parquet!");
}
