// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for Iceberg FileIO implementation
//!
//! These tests verify that RosettaFileIO can read and write files,
//! transcoding formats transparently.
//!
//! Note: Cloud storage tests (S3/GCS) require actual credentials.
//! Only local filesystem tests run by default.

use arrow::array::{Int32Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use bytes::Bytes;
use parquet::arrow::ArrowWriter;
use std::collections::HashMap;
use std::sync::Arc;
use tempfile::TempDir;

use rosetta::iceberg::{RosettaFileIO, RosettaFileIOConfig};

/// Create a test Parquet file
fn create_test_parquet(path: &std::path::Path) {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
    ]));

    let ids = Int32Array::from(vec![1, 2, 3, 4, 5]);
    let names = StringArray::from(vec![
        Some("Alice"),
        Some("Bob"),
        Some("Charlie"),
        Some("Diana"),
        Some("Eve"),
    ]);

    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

    let file = std::fs::File::create(path).unwrap();
    let mut writer = ArrowWriter::try_new(file, schema, None).unwrap();
    writer.write(&batch).unwrap();
    writer.close().unwrap();
}

#[test]
fn test_config_default() {
    let config = RosettaFileIOConfig::default();
    assert!(config.enable_cache);
    assert_eq!(config.max_cache_bytes, 2 * 1024 * 1024 * 1024); // 2GB
    assert!(config.transcode_extensions.contains(&"vortex".to_string()));
    assert!(config.transcode_extensions.contains(&"lance".to_string()));
    println!("✓ Default FileIO config created");
}

#[test]
fn test_config_from_properties() {
    let mut props = HashMap::new();
    props.insert("rosetta.cache-enabled".to_string(), "false".to_string());
    props.insert(
        "rosetta.max-cache-bytes".to_string(),
        "500000000".to_string(),
    );
    props.insert(
        "rosetta.transcode-extensions".to_string(),
        "vortex,lance,custom".to_string(),
    );

    let config = RosettaFileIOConfig::from_properties(props);

    assert!(!config.enable_cache);
    assert_eq!(config.max_cache_bytes, 500_000_000);
    assert!(config.transcode_extensions.contains(&"custom".to_string()));
    assert_eq!(config.transcode_extensions.len(), 3);

    println!("✓ Config from properties works");
}

#[test]
fn test_fileio_creation() {
    let file_io = RosettaFileIO::default_config().unwrap();
    assert!(file_io.should_transcode("data.vortex"));
    println!("✓ FileIO created successfully");
}

#[tokio::test]
async fn test_input_file_location() {
    let file_io = RosettaFileIO::default_config().unwrap();
    let input = file_io
        .new_input("s3://bucket/path/to/data.parquet")
        .unwrap();
    assert_eq!(input.location(), "s3://bucket/path/to/data.parquet");
    println!("✓ Input file location preserved");
}

#[tokio::test]
async fn test_output_file_location() {
    let file_io = RosettaFileIO::default_config().unwrap();
    let output = file_io.new_output("gs://bucket/output.parquet").unwrap();
    assert_eq!(output.location(), "gs://bucket/output.parquet");
    println!("✓ Output file location preserved");
}

#[tokio::test]
async fn test_read_local_parquet() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");
    create_test_parquet(&parquet_path);

    let file_io = RosettaFileIO::default_config().unwrap();
    let input = file_io.new_input(parquet_path.to_str().unwrap()).unwrap();

    // Read file
    let data = input.read().await.unwrap();

    // Should be valid Parquet
    assert!(data.len() > 8);
    assert_eq!(&data[0..4], b"PAR1");
    assert_eq!(&data[data.len() - 4..], b"PAR1");

    println!("✓ Read local Parquet file: {} bytes", data.len());
}

#[tokio::test]
async fn test_input_file_exists() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("exists.parquet");
    create_test_parquet(&parquet_path);

    let file_io = RosettaFileIO::default_config().unwrap();

    // Existing file
    let input = file_io.new_input(parquet_path.to_str().unwrap()).unwrap();
    assert!(input.exists().await.unwrap());

    // Non-existing file
    let missing = file_io
        .new_input(temp_dir.path().join("missing.parquet").to_str().unwrap())
        .unwrap();
    assert!(!missing.exists().await.unwrap());

    println!("✓ exists() works correctly");
}

#[tokio::test]
async fn test_input_file_len() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("len_test.parquet");
    create_test_parquet(&parquet_path);

    let file_io = RosettaFileIO::default_config().unwrap();
    let input = file_io.new_input(parquet_path.to_str().unwrap()).unwrap();

    let len = input.len().await.unwrap();
    let fs_len = std::fs::metadata(&parquet_path).unwrap().len();

    assert_eq!(len, fs_len);
    println!("✓ len() returns {} bytes", len);
}

#[tokio::test]
async fn test_write_local_file() {
    let temp_dir = TempDir::new().unwrap();
    let output_path = temp_dir.path().join("output.parquet");

    let file_io = RosettaFileIO::default_config().unwrap();
    let output = file_io.new_output(output_path.to_str().unwrap()).unwrap();

    // Write test data (fake Parquet header for testing)
    let data = Bytes::from(b"PAR1test_data_herePAR1".to_vec());
    output.write(data.clone()).await.unwrap();

    // Verify
    let written = std::fs::read(&output_path).unwrap();
    assert_eq!(written.len(), data.len());
    assert_eq!(&written[0..4], b"PAR1");

    println!("✓ Wrote local file: {} bytes", written.len());
}

#[tokio::test]
async fn test_delete_local_file() {
    let temp_dir = TempDir::new().unwrap();
    let file_path = temp_dir.path().join("to_delete.parquet");
    create_test_parquet(&file_path);

    assert!(file_path.exists());

    let file_io = RosettaFileIO::default_config().unwrap();
    file_io.delete(file_path.to_str().unwrap()).await.unwrap();

    assert!(!file_path.exists());
    println!("✓ Delete local file works");
}

#[tokio::test]
async fn test_cache_behavior() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("cached.parquet");
    create_test_parquet(&parquet_path);

    let file_io = RosettaFileIO::default_config().unwrap();

    // First read (populates cache)
    let input1 = file_io.new_input(parquet_path.to_str().unwrap()).unwrap();
    let data1 = input1.read().await.unwrap();

    // Second read (should use cache)
    let input2 = file_io.new_input(parquet_path.to_str().unwrap()).unwrap();
    let data2 = input2.read().await.unwrap();

    assert_eq!(data1, data2);

    // Clear cache
    file_io.clear_cache().await;

    // Read again (should re-read from disk)
    let input3 = file_io.new_input(parquet_path.to_str().unwrap()).unwrap();
    let data3 = input3.read().await.unwrap();

    assert_eq!(data1, data3);
    println!("✓ Cache behavior works correctly");
}

#[tokio::test]
async fn test_should_transcode() {
    let file_io = RosettaFileIO::default_config().unwrap();

    // Should transcode
    assert!(file_io.should_transcode("data.vortex"));
    assert!(file_io.should_transcode("/path/to/data.lance"));
    assert!(file_io.should_transcode("s3://bucket/data.f3"));

    // Should NOT transcode
    assert!(!file_io.should_transcode("data.parquet"));
    assert!(!file_io.should_transcode("data.csv"));
    assert!(!file_io.should_transcode("gs://bucket/data.parquet"));

    println!("✓ should_transcode identifies formats correctly");
}

#[cfg(feature = "vortex-reader")]
#[tokio::test]
async fn test_transcode_vortex_file() {
    use vortex::file::VortexWriteOptions;
    use vortex_array::arrays::{StructArray, VarBinArray};
    use vortex_array::IntoArray;
    use vortex_buffer::buffer;

    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("data.vortex");

    // Create Vortex file
    let ids = buffer![1i32, 2, 3, 4, 5].into_array();
    let names = VarBinArray::from(vec!["Alice", "Bob", "Charlie", "Diana", "Eve"]).into_array();
    let st = StructArray::from_fields(&[("id", ids), ("name", names)]).unwrap();
    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .unwrap();
    std::fs::write(&vortex_path, buf).unwrap();

    // Read through FileIO (should transcode to Parquet)
    let file_io = RosettaFileIO::default_config().unwrap();
    let input = file_io.new_input(vortex_path.to_str().unwrap()).unwrap();

    let data = input.read().await.unwrap();

    // Should receive Parquet bytes
    assert_eq!(&data[0..4], b"PAR1", "Should transcode to Parquet");
    assert_eq!(&data[data.len() - 4..], b"PAR1");

    println!(
        "✓ Vortex → Parquet transcode via FileIO: {} bytes",
        data.len()
    );
}

#[cfg(feature = "lance-reader")]
#[tokio::test]
async fn test_transcode_lance_file() {
    use arrow::record_batch::RecordBatchIterator;
    use lance::Dataset;

    let temp_dir = TempDir::new().unwrap();
    let lance_path = temp_dir.path().join("data.lance");

    // Create Lance dataset
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
    ]));
    let ids = Int32Array::from(vec![1, 2, 3]);
    let names = StringArray::from(vec![Some("X"), Some("Y"), Some("Z")]);
    let batch = RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();
    let reader = RecordBatchIterator::new(vec![Ok(batch)], schema);
    Dataset::write(reader, lance_path.to_str().unwrap(), None)
        .await
        .unwrap();

    // Read through FileIO (should transcode to Parquet)
    let file_io = RosettaFileIO::default_config().unwrap();
    let input = file_io.new_input(lance_path.to_str().unwrap()).unwrap();

    let data = input.read().await.unwrap();

    // Should receive Parquet bytes
    assert_eq!(&data[0..4], b"PAR1", "Should transcode to Parquet");

    println!(
        "✓ Lance → Parquet transcode via FileIO: {} bytes",
        data.len()
    );
}

// Note: S3/GCS tests require actual credentials
// Uncomment and configure for integration testing with cloud storage:
//
// #[tokio::test]
// #[ignore = "Requires S3 credentials"]
// async fn test_read_s3() {
//     std::env::set_var("AWS_REGION", "us-east-1");
//     std::env::set_var("AWS_ACCESS_KEY_ID", "your-key");
//     std::env::set_var("AWS_SECRET_ACCESS_KEY", "your-secret");
//
//     let file_io = RosettaFileIO::default_config().unwrap();
//     let input = file_io.new_input("s3://your-bucket/test.parquet").unwrap();
//     let data = input.read().await.unwrap();
//     assert!(!data.is_empty());
// }
