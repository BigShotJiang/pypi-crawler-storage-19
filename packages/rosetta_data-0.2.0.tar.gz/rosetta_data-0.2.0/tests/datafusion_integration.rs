// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for DataFusion support

#![cfg(feature = "datafusion-integration")]

use arrow::array::{Int32Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use datafusion::datasource::TableProvider;
use datafusion::prelude::*;
use std::sync::Arc;
use tempfile::TempDir;

/// Create a test Parquet file
fn create_test_parquet(path: &std::path::Path) {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, true),
        Field::new("amount", DataType::Int32, false),
    ]));

    let ids = Int32Array::from(vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    let names = StringArray::from(vec![
        Some("Alice"),
        Some("Bob"),
        Some("Charlie"),
        Some("Diana"),
        Some("Eve"),
        Some("Frank"),
        Some("Grace"),
        Some("Henry"),
        Some("Ivy"),
        Some("Jack"),
    ]);
    let amounts = Int32Array::from(vec![100, 200, 50, 300, 150, 75, 400, 25, 500, 350]);

    let batch = RecordBatch::try_new(
        schema.clone(),
        vec![Arc::new(ids), Arc::new(names), Arc::new(amounts)],
    )
    .unwrap();

    let file = std::fs::File::create(path).unwrap();
    let mut writer = parquet::arrow::ArrowWriter::try_new(file, schema, None).unwrap();
    writer.write(&batch).unwrap();
    writer.close().unwrap();
}

#[tokio::test]
async fn test_rosetta_table_provider_basic() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");

    create_test_parquet(&parquet_path);

    // Create TableProvider
    let provider = rosetta::datafusion::RosettaTableProvider::try_new(&parquet_path)
        .await
        .unwrap();

    // Verify schema
    let schema = provider.schema();
    assert_eq!(schema.fields().len(), 3);
    assert_eq!(schema.field(0).name(), "id");
    assert_eq!(schema.field(1).name(), "name");
    assert_eq!(schema.field(2).name(), "amount");

    println!("✓ RosettaTableProvider created with correct schema");
}

#[tokio::test]
async fn test_rosetta_datafusion_sql_query() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");

    create_test_parquet(&parquet_path);

    // Create DataFusion context
    let ctx = SessionContext::new();

    // Register Rosetta table
    let provider = rosetta::datafusion::RosettaTableProvider::try_new(&parquet_path)
        .await
        .unwrap();
    ctx.register_table("sales", Arc::new(provider)).unwrap();

    // Run SQL query
    let df = ctx.sql("SELECT * FROM sales").await.unwrap();
    let batches = df.collect().await.unwrap();

    // Verify results
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 10);

    println!("✓ DataFusion SQL query returned {} rows", total_rows);
}

#[tokio::test]
async fn test_rosetta_datafusion_filter_pushdown() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");

    create_test_parquet(&parquet_path);

    let ctx = SessionContext::new();

    let provider = rosetta::datafusion::RosettaTableProvider::try_new(&parquet_path)
        .await
        .unwrap();
    ctx.register_table("sales", Arc::new(provider)).unwrap();

    // Query with filter
    let df = ctx
        .sql("SELECT * FROM sales WHERE amount > 200")
        .await
        .unwrap();
    let batches = df.collect().await.unwrap();

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    // Should have rows: Diana(300), Grace(400), Ivy(500), Jack(350) = 4 rows
    assert_eq!(
        total_rows, 4,
        "Filter should return 4 rows where amount > 200"
    );

    println!("✓ Filter pushdown returned {} rows", total_rows);
}

#[tokio::test]
async fn test_rosetta_datafusion_projection() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");

    create_test_parquet(&parquet_path);

    let ctx = SessionContext::new();

    let provider = rosetta::datafusion::RosettaTableProvider::try_new(&parquet_path)
        .await
        .unwrap();
    ctx.register_table("sales", Arc::new(provider)).unwrap();

    // Query with projection
    let df = ctx.sql("SELECT name, amount FROM sales").await.unwrap();
    let batches = df.collect().await.unwrap();

    // Verify only 2 columns returned
    assert_eq!(batches[0].num_columns(), 2);
    assert_eq!(batches[0].schema().field(0).name(), "name");
    assert_eq!(batches[0].schema().field(1).name(), "amount");

    println!("✓ Projection returned only requested columns");
}

#[tokio::test]
async fn test_rosetta_datafusion_aggregation() {
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("test.parquet");

    create_test_parquet(&parquet_path);

    let ctx = SessionContext::new();

    let provider = rosetta::datafusion::RosettaTableProvider::try_new(&parquet_path)
        .await
        .unwrap();
    ctx.register_table("sales", Arc::new(provider)).unwrap();

    // Aggregation query
    let df = ctx
        .sql("SELECT COUNT(*) as cnt, SUM(amount) as total FROM sales")
        .await
        .unwrap();
    let batches = df.collect().await.unwrap();

    assert_eq!(batches.len(), 1);
    assert_eq!(batches[0].num_rows(), 1);

    println!("✓ Aggregation query works through Rosetta");
}

#[cfg(feature = "vortex-reader")]
mod vortex_tests {
    use super::*;
    use vortex::file::VortexWriteOptions;
    use vortex_array::arrays::{StructArray, VarBinArray};
    use vortex_array::IntoArray;
    use vortex_buffer::buffer;

    fn create_test_vortex(path: &std::path::Path) {
        let ids = buffer![1i32, 2, 3, 4, 5].into_array();
        let names = VarBinArray::from(vec!["Alice", "Bob", "Charlie", "Diana", "Eve"]).into_array();
        let amounts = buffer![100i32, 200, 50, 300, 150].into_array();

        let st =
            StructArray::from_fields(&[("id", ids), ("name", names), ("amount", amounts)]).unwrap();

        let buf = VortexWriteOptions::default()
            .write_blocking(Vec::new(), st.to_array_stream())
            .unwrap();

        std::fs::write(path, buf).unwrap();
    }

    #[tokio::test]
    async fn test_rosetta_datafusion_vortex() {
        let temp_dir = TempDir::new().unwrap();
        let vortex_path = temp_dir.path().join("test.vortex");

        create_test_vortex(&vortex_path);

        let ctx = SessionContext::new();

        let provider = rosetta::datafusion::RosettaTableProvider::try_new(&vortex_path)
            .await
            .unwrap();

        // Verify format detection
        assert!(matches!(provider.format(), rosetta::FileFormat::Vortex));

        ctx.register_table("sales", Arc::new(provider)).unwrap();

        let df = ctx
            .sql("SELECT * FROM sales WHERE amount > 100")
            .await
            .unwrap();
        let batches = df.collect().await.unwrap();

        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        // Bob(200), Diana(300), Eve(150) = 3 rows
        assert_eq!(total_rows, 3);

        println!(
            "✓ DataFusion + Vortex integration works with {} rows",
            total_rows
        );
    }
}

#[cfg(feature = "lance-reader")]
mod lance_tests {
    use super::*;
    use arrow::record_batch::RecordBatchIterator;
    use lance::Dataset;

    async fn create_test_lance(path: &std::path::Path) {
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, true),
            Field::new("amount", DataType::Int32, false),
        ]));

        let ids = Int32Array::from(vec![1, 2, 3, 4, 5]);
        let names = StringArray::from(vec![
            Some("Alice"),
            Some("Bob"),
            Some("Charlie"),
            Some("Diana"),
            Some("Eve"),
        ]);
        let amounts = Int32Array::from(vec![100, 200, 50, 300, 150]);

        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![Arc::new(ids), Arc::new(names), Arc::new(amounts)],
        )
        .unwrap();

        let reader = RecordBatchIterator::new(vec![Ok(batch)], schema);

        Dataset::write(reader, path.to_str().unwrap(), None)
            .await
            .unwrap();
    }

    #[tokio::test]
    async fn test_rosetta_datafusion_lance() {
        let temp_dir = TempDir::new().unwrap();
        let lance_path = temp_dir.path().join("test.lance");

        create_test_lance(&lance_path).await;

        let ctx = SessionContext::new();

        let provider = rosetta::datafusion::RosettaTableProvider::try_new(&lance_path)
            .await
            .unwrap();

        // Verify format detection
        assert!(matches!(provider.format(), rosetta::FileFormat::Lance));

        ctx.register_table("sales", Arc::new(provider)).unwrap();

        let df = ctx
            .sql("SELECT * FROM sales WHERE amount > 100")
            .await
            .unwrap();
        let batches = df.collect().await.unwrap();

        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        // Bob(200), Diana(300), Eve(150) = 3 rows
        assert_eq!(total_rows, 3);

        println!(
            "✓ DataFusion + Lance integration works with {} rows",
            total_rows
        );
    }
}
