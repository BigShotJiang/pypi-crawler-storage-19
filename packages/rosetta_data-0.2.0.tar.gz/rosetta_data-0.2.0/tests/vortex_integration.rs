// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for Vortex format reading
//!
//! These tests verify that we can read real Vortex files.

#![cfg(feature = "vortex-reader")]

use arrow::array::{Int32Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use std::sync::Arc;
use tempfile::TempDir;
use vortex::file::{VortexOpenOptions, VortexWriteOptions};
use vortex_array::arrays::{PrimitiveArray, StructArray, VarBinArray};
use vortex_array::stream::ArrayStreamExt;
use vortex_array::IntoArray;
use vortex_buffer::buffer;

/// Write a Vortex file with test data
fn write_vortex_file(path: &std::path::Path) {
    // Create Vortex arrays directly
    let ids = buffer![1i32, 2, 3, 4, 5].into_array();
    let names = VarBinArray::from(vec!["Alice", "Bob", "Charlie", "Diana", "Eve"]).into_array();

    let st = StructArray::from_fields(&[("id", ids), ("name", names)]).unwrap();

    // Write to file
    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .unwrap();

    std::fs::write(path, buf).unwrap();
}

#[tokio::test]
async fn test_read_vortex_file() {
    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("test.vortex");

    // Create test file
    write_vortex_file(&vortex_path);

    // Read it back with Rosetta
    let reader = rosetta::readers::VortexReader::open(&vortex_path)
        .await
        .unwrap();

    // Verify schema
    assert_eq!(reader.schema.fields().len(), 2);
    assert_eq!(reader.schema.field(0).name(), "id");
    assert_eq!(reader.schema.field(1).name(), "name");

    // Read data
    let batches = reader.read_all().await.unwrap();
    assert!(!batches.is_empty());

    // Verify row count
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 5);

    println!(
        "✓ Read {} rows from Vortex file with schema: {:?}",
        total_rows,
        reader
            .schema
            .fields()
            .iter()
            .map(|f| f.name())
            .collect::<Vec<_>>()
    );
}

#[tokio::test]
async fn test_vortex_column_projection() {
    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("test_proj.vortex");

    write_vortex_file(&vortex_path);

    // Read with projection
    let reader = rosetta::readers::VortexReader::open(&vortex_path)
        .await
        .unwrap();
    let batches = reader.read_projection(&["id".to_string()]).await.unwrap();

    assert!(!batches.is_empty());
    assert_eq!(batches[0].num_columns(), 1);
    assert_eq!(batches[0].schema().field(0).name(), "id");

    println!("✓ Column projection works - read only 'id' column");
}

#[tokio::test]
async fn test_unified_reader_vortex() {
    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("unified_test.vortex");

    write_vortex_file(&vortex_path);

    // Read through UnifiedReader
    let reader = rosetta::UnifiedReader::open(&vortex_path).await.unwrap();

    assert!(matches!(reader.format(), rosetta::FileFormat::Vortex));

    let batches = reader.read_all().await.unwrap();
    assert!(!batches.is_empty());

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 5);

    println!("✓ UnifiedReader detected and read Vortex format");
}

#[tokio::test]
async fn test_transcode_vortex_to_parquet() {
    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("transcode_test.vortex");

    write_vortex_file(&vortex_path);

    // Transcode to Parquet
    let transcoder = rosetta::Transcoder::new();
    let result = transcoder.transcode_file(&vortex_path).await.unwrap();

    // Verify it's valid Parquet
    assert_eq!(&result.bytes[0..4], b"PAR1");
    assert_eq!(&result.bytes[result.bytes.len() - 4..], b"PAR1");
    assert_eq!(result.source_format, rosetta::FileFormat::Vortex);
    assert_eq!(result.num_rows, 5);
    assert_eq!(result.num_columns, 2);

    println!(
        "✓ Transcoded Vortex → Parquet: {} bytes, {} rows",
        result.bytes.len(),
        result.num_rows
    );
}

#[tokio::test]
async fn test_vortex_format_detection() {
    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("detect.vortex");

    write_vortex_file(&vortex_path);

    // Test format detection
    let detector = rosetta::FormatDetector::new();
    let format = detector.detect_file(&vortex_path).await.unwrap();

    assert_eq!(format, rosetta::FileFormat::Vortex);
    println!("✓ Format detection correctly identified Vortex file");
}

#[tokio::test]
async fn test_vortex_filter_pushdown() {
    use rosetta::expr::{col, lit, FilterPushdownResult};

    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("filter_test.vortex");

    // Create test file with more data for filtering
    let ids = buffer![1i32, 2, 3, 4, 5, 6, 7, 8, 9, 10].into_array();
    let names = VarBinArray::from(vec![
        "Alice", "Bob", "Charlie", "Diana", "Eve", "Frank", "Grace", "Henry", "Ivy", "Jack",
    ])
    .into_array();

    let st = StructArray::from_fields(&[("id", ids), ("name", names)]).unwrap();
    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .unwrap();
    std::fs::write(&vortex_path, buf).unwrap();

    // Create filter: id > 5 (using i32 to match the data type)
    let filter = col("id").gt(lit(5i32));

    // Open reader and push filter
    let mut reader = rosetta::readers::VortexReader::open(&vortex_path)
        .await
        .unwrap();

    let result = reader.push_filter(&filter).unwrap();
    assert!(
        matches!(result, FilterPushdownResult::Pushed),
        "Filter should be pushed to Vortex"
    );

    // Read filtered data
    let batches = reader.read_all().await.unwrap();

    // Verify filter was applied
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    // Should have 5 rows where id > 5 (6, 7, 8, 9, 10)
    assert_eq!(
        total_rows, 5,
        "Filter pushdown should return only rows where id > 5"
    );

    println!(
        "✓ Vortex filter pushdown works - filtered {} rows",
        total_rows
    );
}

#[tokio::test]
async fn test_vortex_statistics() {
    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("stats_test.vortex");

    write_vortex_file(&vortex_path);

    let reader = rosetta::readers::VortexReader::open(&vortex_path)
        .await
        .unwrap();

    let stats = reader.statistics();
    assert!(stats.is_some(), "Vortex reader should provide statistics");

    let stats = stats.unwrap();
    // Statistics should have column entries for each field
    assert!(!stats.column_statistics.is_empty());

    println!("✓ Vortex statistics: {:?}", stats);
}

#[tokio::test]
async fn test_vortex_partitions() {
    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("partitions_test.vortex");

    write_vortex_file(&vortex_path);

    let reader = rosetta::readers::VortexReader::open(&vortex_path)
        .await
        .unwrap();

    let partitions = reader.partitions().unwrap();
    assert!(!partitions.is_empty(), "Should have at least one partition");

    let partition = &partitions[0];
    assert_eq!(partition.id, 0);
    assert!(!partition.location.is_empty());

    println!("✓ Vortex partitions: {} partition(s)", partitions.len());
}
