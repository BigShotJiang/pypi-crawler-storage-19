// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for FUSE filesystem
//!
//! Note: These tests verify FUSE component logic without actually mounting,
//! because FUSE mount requires:
//! - macFUSE (macOS) or fuse3 (Linux) installed
//! - Mount permissions (root or user namespace)
//! - Blocking mount operation
//!
//! For full mount testing, use: rosetta mount <source> <mount_point>

#![cfg(feature = "fuse-reader")]

use rosetta::fuse::{RosettaFs, RosettaFsConfig};
use std::path::PathBuf;
use tempfile::TempDir;

#[test]
fn test_config_default() {
    let config = RosettaFsConfig::default();
    assert!(config.enable_cache);
    assert_eq!(config.max_cache_bytes, 2 * 1024 * 1024 * 1024); // 2GB
    assert!(config.transcode_extensions.contains(&"vortex".to_string()));
    assert!(config.transcode_extensions.contains(&"lance".to_string()));
    println!("✓ Default FUSE config created");
}

#[test]
fn test_config_new() {
    let config = RosettaFsConfig::new(PathBuf::from("/data/source"), PathBuf::from("/mnt/rosetta"));
    assert_eq!(config.source_dir, PathBuf::from("/data/source"));
    assert_eq!(config.mount_point, PathBuf::from("/mnt/rosetta"));
    println!("✓ Custom FUSE config created");
}

#[test]
fn test_rosettafs_creation() {
    let temp_dir = TempDir::new().unwrap();
    let config = RosettaFsConfig::new(temp_dir.path().to_path_buf(), PathBuf::from("/mnt/test"));
    let fs = RosettaFs::new(config);
    assert!(fs.is_ok());
    println!("✓ RosettaFs instance created successfully");
}

#[test]
fn test_transcode_extensions() {
    let temp_dir = TempDir::new().unwrap();
    let mut config =
        RosettaFsConfig::new(temp_dir.path().to_path_buf(), PathBuf::from("/mnt/test"));
    config.transcode_extensions = vec![
        "vortex".to_string(),
        "lance".to_string(),
        "f3".to_string(),
        "custom".to_string(),
    ];

    assert_eq!(config.transcode_extensions.len(), 4);
    assert!(config.transcode_extensions.contains(&"custom".to_string()));
    println!("✓ Custom transcode extensions configured");
}

#[test]
fn test_cache_configuration() {
    let temp_dir = TempDir::new().unwrap();
    let mut config =
        RosettaFsConfig::new(temp_dir.path().to_path_buf(), PathBuf::from("/mnt/test"));

    // Disable cache
    config.enable_cache = false;
    let fs = RosettaFs::new(config.clone());
    assert!(fs.is_ok());

    // Custom cache size
    config.enable_cache = true;
    config.max_cache_bytes = 500 * 1024 * 1024; // 500MB
    let fs = RosettaFs::new(config);
    assert!(fs.is_ok());

    println!("✓ Cache configuration works");
}

// Note: Actual mount tests require:
// 1. macFUSE installed (macOS): brew install macfuse
// 2. fuse3 installed (Linux): apt install fuse3
// 3. Proper permissions
//
// Manual test command:
// ```
// cargo run --features fuse-reader -- mount ./test_data /tmp/rosetta_mount
// ```
// Then in another terminal:
// ```
// ls /tmp/rosetta_mount
// cat /tmp/rosetta_mount/file.vortex  # Returns Parquet bytes
// ```
