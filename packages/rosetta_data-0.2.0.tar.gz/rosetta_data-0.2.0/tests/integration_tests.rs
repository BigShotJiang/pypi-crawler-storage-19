// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for Rosetta
//!
//! These tests verify end-to-end functionality with real Parquet files
//! and various data types and edge cases.

use arrow::array::{
    Array, BinaryArray, BooleanArray, Date32Array, Float32Array, Float64Array, Int16Array,
    Int32Array, Int64Array, Int8Array, LargeBinaryArray, LargeStringArray, StringArray,
    TimestampMicrosecondArray, UInt32Array, UInt64Array,
};
use arrow::datatypes::{DataType, Field, Schema, TimeUnit};
use arrow::record_batch::RecordBatch;
use parquet::arrow::ArrowWriter;
use parquet::basic::{Compression, Encoding};
use parquet::file::properties::{WriterProperties, WriterVersion};
use rosetta::{FileFormat, FormatDetector, ReadOptions, UnifiedReader};
use std::sync::Arc;
use tempfile::NamedTempFile;

/// Helper to create a Parquet file from a RecordBatch
fn write_parquet(batch: &RecordBatch, props: Option<WriterProperties>) -> NamedTempFile {
    let file = NamedTempFile::new().unwrap();
    let file_writer = std::fs::File::create(file.path()).unwrap();
    let mut writer = ArrowWriter::try_new(file_writer, batch.schema(), props).unwrap();
    writer.write(batch).unwrap();
    writer.close().unwrap();
    file
}

// =============================================================================
// Data Type Tests
// =============================================================================

#[tokio::test]
async fn test_all_integer_types() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("i8", DataType::Int8, false),
        Field::new("i16", DataType::Int16, false),
        Field::new("i32", DataType::Int32, false),
        Field::new("i64", DataType::Int64, false),
        Field::new("u32", DataType::UInt32, false),
        Field::new("u64", DataType::UInt64, false),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int8Array::from(vec![1i8, -1, 127, -128, 0])),
            Arc::new(Int16Array::from(vec![1i16, -1, 32767, -32768, 0])),
            Arc::new(Int32Array::from(vec![1i32, -1, i32::MAX, i32::MIN, 0])),
            Arc::new(Int64Array::from(vec![1i64, -1, i64::MAX, i64::MIN, 0])),
            Arc::new(UInt32Array::from(vec![0u32, 1, u32::MAX, 100, 0])),
            Arc::new(UInt64Array::from(vec![0u64, 1, u64::MAX, 100, 0])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    assert_eq!(batches.len(), 1);
    assert_eq!(batches[0].num_rows(), 5);
    assert_eq!(batches[0].num_columns(), 6);

    // Verify data integrity
    let i64_col = batches[0]
        .column(3)
        .as_any()
        .downcast_ref::<Int64Array>()
        .unwrap();
    assert_eq!(i64_col.value(2), i64::MAX);
    assert_eq!(i64_col.value(3), i64::MIN);
}

#[tokio::test]
async fn test_float_types() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("f32", DataType::Float32, true),
        Field::new("f64", DataType::Float64, true),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Float32Array::from(vec![
                Some(1.0f32),
                Some(-1.0),
                Some(f32::MAX),
                Some(f32::MIN),
                None,
                Some(f32::INFINITY),
                Some(f32::NEG_INFINITY),
            ])),
            Arc::new(Float64Array::from(vec![
                Some(1.0f64),
                Some(-1.0),
                Some(f64::MAX),
                Some(f64::MIN),
                None,
                Some(f64::INFINITY),
                Some(f64::NEG_INFINITY),
            ])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    assert_eq!(batches[0].num_rows(), 7);

    // Verify nulls are preserved
    let f32_col = batches[0]
        .column(0)
        .as_any()
        .downcast_ref::<Float32Array>()
        .unwrap();
    assert!(f32_col.is_null(4));
    assert!(f32_col.value(5).is_infinite());
}

#[tokio::test]
async fn test_string_types() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("str", DataType::Utf8, true),
        Field::new("large_str", DataType::LargeUtf8, true),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(StringArray::from(vec![
                Some("hello"),
                Some(""),
                None,
                Some("unicode: 你好世界 🌍"),
                Some("a".repeat(10000).as_str()),
            ])),
            Arc::new(LargeStringArray::from(vec![
                Some("world"),
                Some(""),
                None,
                Some("more unicode: مرحبا"),
                Some("b".repeat(10000).as_str()),
            ])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let str_col = batches[0]
        .column(0)
        .as_any()
        .downcast_ref::<StringArray>()
        .unwrap();
    assert_eq!(str_col.value(0), "hello");
    assert_eq!(str_col.value(1), "");
    assert!(str_col.is_null(2));
    assert!(str_col.value(3).contains("你好"));
}

#[tokio::test]
async fn test_binary_types() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("bin", DataType::Binary, true),
        Field::new("large_bin", DataType::LargeBinary, true),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(BinaryArray::from(vec![
                Some(b"hello".as_slice()),
                Some(b"\x00\x01\x02".as_slice()),
                None,
                Some(vec![0u8; 1000].as_slice()),
            ])),
            Arc::new(LargeBinaryArray::from(vec![
                Some(b"world".as_slice()),
                Some(b"\xff\xfe\xfd".as_slice()),
                None,
                Some(vec![255u8; 1000].as_slice()),
            ])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    assert_eq!(batches[0].num_rows(), 4);
}

#[tokio::test]
async fn test_boolean_type() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "bool",
        DataType::Boolean,
        true,
    )]));

    let batch = RecordBatch::try_new(
        schema,
        vec![Arc::new(BooleanArray::from(vec![
            Some(true),
            Some(false),
            None,
            Some(true),
        ]))],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let bool_col = batches[0]
        .column(0)
        .as_any()
        .downcast_ref::<BooleanArray>()
        .unwrap();
    assert!(bool_col.value(0));
    assert!(!bool_col.value(1));
    assert!(bool_col.is_null(2));
}

#[tokio::test]
async fn test_date_and_timestamp() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("date", DataType::Date32, true),
        Field::new(
            "timestamp",
            DataType::Timestamp(TimeUnit::Microsecond, None),
            true,
        ),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Date32Array::from(vec![Some(0), Some(18628), None])), // 1970-01-01, 2021-01-01
            Arc::new(TimestampMicrosecondArray::from(vec![
                Some(0),
                Some(1609459200000000), // 2021-01-01 00:00:00
                None,
            ])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    assert_eq!(batches[0].num_rows(), 3);
}

// =============================================================================
// Compression Tests
// =============================================================================

#[tokio::test]
async fn test_compression_snappy() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let data: Vec<i64> = (0..10000).collect();
    let batch =
        RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(data.clone()))]).unwrap();

    let props = WriterProperties::builder()
        .set_compression(Compression::SNAPPY)
        .build();
    let file = write_parquet(&batch, Some(props));

    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 10000);
}

#[tokio::test]
async fn test_compression_zstd() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let data: Vec<i64> = (0..10000).collect();
    let batch =
        RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(data.clone()))]).unwrap();

    let props = WriterProperties::builder()
        .set_compression(Compression::ZSTD(Default::default()))
        .build();
    let file = write_parquet(&batch, Some(props));

    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 10000);
}

#[tokio::test]
#[ignore = "gzip writing disabled - flate2 rust_backend used to avoid libz-rs conflicts"]
async fn test_compression_gzip() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let data: Vec<i64> = (0..10000).collect();
    let batch =
        RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(data.clone()))]).unwrap();

    let props = WriterProperties::builder()
        .set_compression(Compression::GZIP(Default::default()))
        .build();
    let file = write_parquet(&batch, Some(props));

    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 10000);
}

#[tokio::test]
async fn test_compression_lz4() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let data: Vec<i64> = (0..10000).collect();
    let batch =
        RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(data.clone()))]).unwrap();

    let props = WriterProperties::builder()
        .set_compression(Compression::LZ4)
        .build();
    let file = write_parquet(&batch, Some(props));

    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 10000);
}

// =============================================================================
// Parquet Version Tests
// =============================================================================

#[tokio::test]
async fn test_parquet_v1() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let batch = RecordBatch::try_new(
        schema,
        vec![Arc::new(Int64Array::from(vec![1i64, 2, 3, 4, 5]))],
    )
    .unwrap();

    let props = WriterProperties::builder()
        .set_writer_version(WriterVersion::PARQUET_1_0)
        .build();
    let file = write_parquet(&batch, Some(props));

    let detector = FormatDetector::new();
    let format = detector.detect_file(file.path()).await.unwrap();
    assert_eq!(format, FileFormat::ParquetV1);

    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();
    assert_eq!(batches[0].num_rows(), 5);
}

#[tokio::test]
async fn test_parquet_v2() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let batch = RecordBatch::try_new(
        schema,
        vec![Arc::new(Int64Array::from(vec![1i64, 2, 3, 4, 5]))],
    )
    .unwrap();

    let props = WriterProperties::builder()
        .set_writer_version(WriterVersion::PARQUET_2_0)
        .set_encoding(Encoding::DELTA_BINARY_PACKED)
        .build();
    let file = write_parquet(&batch, Some(props));

    let detector = FormatDetector::new();
    let format = detector.detect_file(file.path()).await.unwrap();
    // May be V1 or V2 depending on what encodings were actually used
    assert!(matches!(
        format,
        FileFormat::ParquetV1 | FileFormat::ParquetV2
    ));

    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();
    assert_eq!(batches[0].num_rows(), 5);
}

// =============================================================================
// Edge Cases
// =============================================================================

#[tokio::test]
async fn test_empty_file() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let batch =
        RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(vec![] as Vec<i64>))]).unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    // Should have one batch with 0 rows
    assert!(batches.is_empty() || batches[0].num_rows() == 0);
}

#[tokio::test]
async fn test_large_row_count() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let data: Vec<i64> = (0..1_000_000).collect();
    let batch = RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(data))]).unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(total_rows, 1_000_000);
}

#[tokio::test]
async fn test_wide_table() {
    // Create a table with many columns (common in ML feature stores)
    let num_columns = 100;
    let fields: Vec<Field> = (0..num_columns)
        .map(|i| Field::new(format!("col_{}", i), DataType::Float64, false))
        .collect();
    let schema = Arc::new(Schema::new(fields));

    let columns: Vec<Arc<dyn Array>> = (0..num_columns)
        .map(|i| Arc::new(Float64Array::from(vec![i as f64; 1000])) as Arc<dyn Array>)
        .collect();

    let batch = RecordBatch::try_new(schema, columns).unwrap();
    let file = write_parquet(&batch, None);

    let reader = UnifiedReader::open(file.path()).await.unwrap();
    assert_eq!(reader.schema().fields().len(), 100);

    let batches = reader.read_all().await.unwrap();
    assert_eq!(batches[0].num_columns(), 100);
}

#[tokio::test]
async fn test_all_nulls() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("nullable_int", DataType::Int64, true),
        Field::new("nullable_str", DataType::Utf8, true),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int64Array::from(vec![None, None, None, None, None])),
            Arc::new(StringArray::from(vec![
                None as Option<&str>,
                None,
                None,
                None,
                None,
            ])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();
    let batches = reader.read_all().await.unwrap();

    let int_col = batches[0]
        .column(0)
        .as_any()
        .downcast_ref::<Int64Array>()
        .unwrap();
    assert_eq!(int_col.null_count(), 5);
}

// =============================================================================
// Column Projection Tests
// =============================================================================

#[tokio::test]
async fn test_projection_single_column() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("a", DataType::Int64, false),
        Field::new("b", DataType::Int64, false),
        Field::new("c", DataType::Int64, false),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int64Array::from(vec![1i64, 2, 3])),
            Arc::new(Int64Array::from(vec![4i64, 5, 6])),
            Arc::new(Int64Array::from(vec![7i64, 8, 9])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let options = ReadOptions::new().with_columns(vec!["b".to_string()]);
    let reader = UnifiedReader::open_with_options(file.path(), options)
        .await
        .unwrap();
    let batches = reader.read_all().await.unwrap();

    assert_eq!(batches[0].num_columns(), 1);
    assert_eq!(batches[0].schema().field(0).name(), "b");
}

#[tokio::test]
async fn test_projection_multiple_columns_order() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("a", DataType::Int64, false),
        Field::new("b", DataType::Int64, false),
        Field::new("c", DataType::Int64, false),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int64Array::from(vec![1i64, 2, 3])),
            Arc::new(Int64Array::from(vec![4i64, 5, 6])),
            Arc::new(Int64Array::from(vec![7i64, 8, 9])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    // Request columns in different order
    let options = ReadOptions::new().with_columns(vec!["c".to_string(), "a".to_string()]);
    let reader = UnifiedReader::open_with_options(file.path(), options)
        .await
        .unwrap();
    let batches = reader.read_all().await.unwrap();

    assert_eq!(batches[0].num_columns(), 2);
}

// =============================================================================
// Row Group Tests
// =============================================================================

#[tokio::test]
async fn test_multiple_row_groups() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));

    // Create file with small row group size to force multiple row groups
    let props = WriterProperties::builder()
        .set_max_row_group_size(100)
        .build();

    let data: Vec<i64> = (0..1000).collect();
    let batch = RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(data))]).unwrap();

    let file = write_parquet(&batch, Some(props));
    let reader = UnifiedReader::open(file.path()).await.unwrap();

    assert!(reader.num_row_groups() >= 10);

    // Read specific row group
    let batches = reader.read_row_group(0).await.unwrap();
    assert!(!batches.is_empty());
}

// =============================================================================
// Error Handling Tests
// =============================================================================

#[tokio::test]
async fn test_nonexistent_file() {
    let result = UnifiedReader::open("/nonexistent/path/to/file.parquet").await;
    assert!(result.is_err());
}

#[tokio::test]
async fn test_invalid_column_name() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));
    let batch = RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(vec![1i64]))]).unwrap();

    let file = write_parquet(&batch, None);
    let options = ReadOptions::new().with_columns(vec!["nonexistent".to_string()]);
    let reader = UnifiedReader::open_with_options(file.path(), options)
        .await
        .unwrap();
    let result = reader.read_all().await;

    assert!(result.is_err());
}

#[tokio::test]
async fn test_corrupt_file() {
    let file = NamedTempFile::new().unwrap();
    std::fs::write(file.path(), b"not a parquet file").unwrap();

    let result = UnifiedReader::open(file.path()).await;
    assert!(result.is_err());
}

// =============================================================================
// Lance Format Tests (requires lance-reader feature)
// =============================================================================

#[cfg(feature = "lance-reader")]
mod lance_tests {
    use super::*;
    use tempfile::TempDir;

    /// Helper to create a Lance dataset from a RecordBatch
    async fn write_lance(batch: &RecordBatch) -> TempDir {
        use lance::dataset::WriteParams;
        use lance::Dataset;

        let dir = TempDir::new().unwrap();
        let uri = dir.path().to_str().unwrap();

        // Convert batch to a reader
        let reader =
            arrow::record_batch::RecordBatchIterator::new(vec![Ok(batch.clone())], batch.schema());

        Dataset::write(reader, uri, Some(WriteParams::default()))
            .await
            .unwrap();

        dir
    }

    #[tokio::test]
    async fn test_lance_basic_read() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("value", DataType::Utf8, true),
        ]));

        let batch = RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int64Array::from(vec![1i64, 2, 3, 4, 5])),
                Arc::new(StringArray::from(vec![
                    Some("a"),
                    Some("b"),
                    Some("c"),
                    None,
                    Some("e"),
                ])),
            ],
        )
        .unwrap();

        let dir = write_lance(&batch).await;
        let reader = UnifiedReader::open(dir.path()).await.unwrap();

        assert_eq!(reader.format(), FileFormat::Lance);
        assert_eq!(reader.schema().fields().len(), 2);

        let batches = reader.read_all().await.unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 5);
    }

    #[tokio::test]
    async fn test_lance_projection() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("a", DataType::Int64, false),
            Field::new("b", DataType::Float64, false),
            Field::new("c", DataType::Utf8, false),
        ]));

        let batch = RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int64Array::from(vec![1i64, 2, 3])),
                Arc::new(Float64Array::from(vec![1.0, 2.0, 3.0])),
                Arc::new(StringArray::from(vec!["x", "y", "z"])),
            ],
        )
        .unwrap();

        let dir = write_lance(&batch).await;

        let options = ReadOptions::new().with_columns(vec!["a".to_string(), "c".to_string()]);
        let reader = UnifiedReader::open_with_options(dir.path(), options)
            .await
            .unwrap();

        let batches = reader.read_all().await.unwrap();
        assert_eq!(batches[0].num_columns(), 2);
    }

    #[tokio::test]
    async fn test_lance_format_detection() {
        let schema = Arc::new(Schema::new(vec![Field::new("x", DataType::Int32, false)]));
        let batch =
            RecordBatch::try_new(schema, vec![Arc::new(Int32Array::from(vec![1, 2, 3]))]).unwrap();

        let dir = write_lance(&batch).await;

        let detector = FormatDetector::new();
        let format = detector.detect_file(dir.path()).await.unwrap();
        assert_eq!(format, FileFormat::Lance);
    }

    #[tokio::test]
    async fn test_lance_numeric_types() {
        let schema = Arc::new(Schema::new(vec![
            Field::new("i32", DataType::Int32, false),
            Field::new("i64", DataType::Int64, false),
            Field::new("f32", DataType::Float32, false),
            Field::new("f64", DataType::Float64, false),
        ]));

        let batch = RecordBatch::try_new(
            schema,
            vec![
                Arc::new(Int32Array::from(vec![1, 2, 3])),
                Arc::new(Int64Array::from(vec![100i64, 200, 300])),
                Arc::new(Float32Array::from(vec![1.5f32, 2.5, 3.5])),
                Arc::new(Float64Array::from(vec![10.5, 20.5, 30.5])),
            ],
        )
        .unwrap();

        let dir = write_lance(&batch).await;
        let reader = UnifiedReader::open(dir.path()).await.unwrap();
        let batches = reader.read_all().await.unwrap();

        assert_eq!(batches[0].num_columns(), 4);
        assert_eq!(batches[0].num_rows(), 3);

        // Verify data integrity
        let f64_col = batches[0]
            .column(3)
            .as_any()
            .downcast_ref::<Float64Array>()
            .unwrap();
        assert_eq!(f64_col.value(0), 10.5);
    }
}

// =============================================================================
// WASM Runtime Tests (requires wasm-runtime feature)
// =============================================================================

#[cfg(feature = "wasm-runtime")]
mod wasm_tests {
    use rosetta::wasm::{DecoderId, OutputType, SandboxConfig, SandboxLimits, WasmRuntime};
    use std::time::Duration;

    #[test]
    fn test_sandbox_config_defaults() {
        let config = SandboxConfig::default();
        assert_eq!(config.limits.max_memory_bytes, 16 * 1024 * 1024);
        assert_eq!(config.limits.max_execution_time, Duration::from_secs(5));
        assert!(config.enable_jit);
        assert!(config.cache_modules);
    }

    #[test]
    fn test_sandbox_config_production() {
        let config = SandboxConfig::production();
        assert_eq!(config.limits.max_memory_bytes, 16 * 1024 * 1024);
        assert_eq!(config.pool_size, 8);
    }

    #[test]
    fn test_sandbox_config_testing() {
        let config = SandboxConfig::testing();
        assert_eq!(config.limits.max_memory_bytes, 256 * 1024 * 1024);
        assert!(!config.enable_jit); // Faster compilation for tests
    }

    #[test]
    fn test_sandbox_limits_builder() {
        let limits = SandboxLimits::default()
            .with_max_memory(32 * 1024 * 1024)
            .with_max_time(Duration::from_secs(10))
            .with_max_output(128 * 1024 * 1024);

        assert_eq!(limits.max_memory_bytes, 32 * 1024 * 1024);
        assert_eq!(limits.max_execution_time, Duration::from_secs(10));
        assert_eq!(limits.max_output_bytes, 128 * 1024 * 1024);
    }

    #[test]
    fn test_decoder_id_creation() {
        let id = DecoderId::new("delta_binary_packed", 1);
        assert_eq!(id.name, "delta_binary_packed");
        assert_eq!(id.version, 1);
        assert_eq!(format!("{}", id), "delta_binary_packed:v1");
    }

    #[test]
    fn test_decoder_id_parsing() {
        let id = DecoderId::parse("fsst:2").unwrap();
        assert_eq!(id.name, "fsst");
        assert_eq!(id.version, 2);

        // Invalid formats
        assert!(DecoderId::parse("no_version").is_none());
        assert!(DecoderId::parse("bad:version:format").is_none());
    }

    #[test]
    fn test_output_type_fixed_sizes() {
        assert_eq!(OutputType::Int8.fixed_size(), Some(1));
        assert_eq!(OutputType::Int16.fixed_size(), Some(2));
        assert_eq!(OutputType::Int32.fixed_size(), Some(4));
        assert_eq!(OutputType::Int64.fixed_size(), Some(8));
        assert_eq!(OutputType::Float32.fixed_size(), Some(4));
        assert_eq!(OutputType::Float64.fixed_size(), Some(8));
        assert_eq!(OutputType::FixedSizeBinary(16).fixed_size(), Some(16));
        assert_eq!(OutputType::Utf8.fixed_size(), None);
        assert_eq!(OutputType::Binary.fixed_size(), None);
    }

    #[test]
    fn test_output_type_from_arrow() {
        assert_eq!(
            OutputType::from_arrow_type("Int64"),
            Some(OutputType::Int64)
        );
        assert_eq!(
            OutputType::from_arrow_type("Float32"),
            Some(OutputType::Float32)
        );
        assert_eq!(OutputType::from_arrow_type("Utf8"), Some(OutputType::Utf8));
        assert_eq!(
            OutputType::from_arrow_type("Binary"),
            Some(OutputType::Binary)
        );
        assert_eq!(OutputType::from_arrow_type("UnknownType"), None);
    }

    #[test]
    fn test_wasm_runtime_creation() {
        let runtime = WasmRuntime::testing().unwrap();
        let stats = runtime.stats();
        assert_eq!(stats.pool_stats.cached_modules, 0);
        assert_eq!(stats.pool_stats.available_instances, 0);
    }

    #[test]
    fn test_wasm_runtime_production() {
        let runtime = WasmRuntime::production().unwrap();
        let stats = runtime.stats();
        assert!(stats.pool_stats.max_size > 0);
    }

    #[test]
    fn test_f3_format_detection() {
        use rosetta::FileFormat;

        // F3 format should require WASM runtime
        assert!(FileFormat::F3.requires_wasm());
        assert!(!FileFormat::ParquetV1.requires_wasm());
        assert!(!FileFormat::Vortex.requires_wasm());
        assert!(!FileFormat::Lance.requires_wasm());
    }

    #[test]
    fn test_f3_format_extension() {
        use rosetta::FileFormat;

        assert_eq!(FileFormat::F3.extension(), "f3");
        assert_eq!(FileFormat::F3.name(), "F3");
    }
}

// =============================================================================
// Statistics and Partition Tests
// =============================================================================

#[tokio::test]
async fn test_parquet_statistics() {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int64, false),
        Field::new("name", DataType::Utf8, true),
    ]));

    let batch = RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int64Array::from(vec![1i64, 2, 3, 4, 5])),
            Arc::new(StringArray::from(vec![
                Some("Alice"),
                Some("Bob"),
                None,
                Some("Diana"),
                Some("Eve"),
            ])),
        ],
    )
    .unwrap();

    let file = write_parquet(&batch, None);
    let reader = UnifiedReader::open(file.path()).await.unwrap();

    let stats = reader.statistics();
    assert!(stats.is_some(), "Parquet reader should provide statistics");

    let stats = stats.unwrap();
    // Should have row count
    assert_eq!(stats.num_rows, Some(5));
    // Should have column statistics
    assert!(!stats.column_statistics.is_empty());
}

#[tokio::test]
async fn test_parquet_partitions() {
    let schema = Arc::new(Schema::new(vec![Field::new(
        "data",
        DataType::Int64,
        false,
    )]));

    // Create file with small row group size
    let props = WriterProperties::builder()
        .set_max_row_group_size(100)
        .build();

    let data: Vec<i64> = (0..500).collect();
    let batch = RecordBatch::try_new(schema, vec![Arc::new(Int64Array::from(data))]).unwrap();

    let file = write_parquet(&batch, Some(props));
    let reader = UnifiedReader::open(file.path()).await.unwrap();

    let partitions = reader.partitions().unwrap();
    assert!(!partitions.is_empty(), "Should have at least one partition");

    // With 500 rows and row groups of 100, should have ~5 row groups/partitions
    assert!(
        partitions.len() >= 5,
        "Should have multiple partitions for multiple row groups"
    );

    let partition = &partitions[0];
    assert_eq!(partition.id, 0);
    assert!(!partition.location.is_empty());
}

#[tokio::test]
async fn test_parquet_filter_pushdown() {
    use rosetta::expr::{col, lit, FilterPushdownResult};

    let schema = Arc::new(Schema::new(vec![Field::new("id", DataType::Int64, false)]));
    let batch = RecordBatch::try_new(
        schema,
        vec![Arc::new(Int64Array::from(vec![1i64, 2, 3, 4, 5]))],
    )
    .unwrap();

    let file = write_parquet(&batch, None);

    let filter = col("id").gt(lit(3i64));

    // Open reader as mutable
    let mut reader = rosetta::readers::ParquetReader::open(file.path())
        .await
        .unwrap();

    let result = reader.push_filter(&filter).unwrap();

    // Parquet filter is now fully pushed with ArrowPredicate implementation
    assert!(
        matches!(result, FilterPushdownResult::Pushed),
        "Parquet filter should be pushed (ArrowPredicate implemented)"
    );

    // Verify filter actually works - should return only rows where id > 3 (i.e., 4 and 5)
    let batches = reader.read_all().await.unwrap();
    let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
    assert_eq!(
        total_rows, 2,
        "Filter id > 3 should return 2 rows (4 and 5)"
    );
}

// =============================================================================
// Expression Module Tests
// =============================================================================

mod expr_tests {
    use rosetta::expr::{col, lit, FilterPushdownResult};

    #[test]
    fn test_col_and_lit() {
        let c = col("name");
        let l = lit(42i64);

        // Just verify they can be created
        assert_eq!(c.to_sql(), "\"name\"");
        assert_eq!(l.to_sql(), "42");
    }

    #[test]
    fn test_comparison_operators() {
        let filter = col("age").gt(lit(30i32));
        assert_eq!(filter.to_sql(), "(\"age\" > 30)");

        let filter = col("age").lt_eq(lit(50i32));
        assert_eq!(filter.to_sql(), "(\"age\" <= 50)");

        let filter = col("name").eq(lit("Alice"));
        assert_eq!(filter.to_sql(), "(\"name\" = 'Alice')");
    }

    #[test]
    fn test_logical_operators() {
        let filter = col("age")
            .gt(lit(30i32))
            .and(col("status").eq(lit("active")));
        assert!(filter.to_sql().contains("AND"));

        let filter = col("age").lt(lit(20i32)).or(col("age").gt(lit(60i32)));
        assert!(filter.to_sql().contains("OR"));

        let filter = col("active").not();
        assert!(filter.to_sql().contains("NOT"));
    }

    #[test]
    fn test_null_checks() {
        let filter = col("optional").is_null();
        assert!(filter.to_sql().contains("IS NULL"));

        let filter = col("required").is_not_null();
        assert!(filter.to_sql().contains("IS NOT NULL"));
    }

    #[test]
    fn test_between() {
        let filter = col("value").between(lit(10i32), lit(100i32));
        assert!(filter.to_sql().contains("BETWEEN"));
        assert!(filter.to_sql().contains("10"));
        assert!(filter.to_sql().contains("100"));
    }

    #[test]
    fn test_like_pattern() {
        let filter = col("name").like("John%");
        assert!(filter.to_sql().contains("LIKE"));
        assert!(filter.to_sql().contains("John%"));
    }

    #[test]
    fn test_columns_extraction() {
        let filter = col("a")
            .gt(lit(10i32))
            .and(col("b").lt(lit(20i32)))
            .or(col("c").eq(col("a")));

        let cols = filter.columns();
        assert!(cols.contains(&"a".to_string()));
        assert!(cols.contains(&"b".to_string()));
        assert!(cols.contains(&"c".to_string()));
    }

    #[test]
    fn test_filter_pushdown_result() {
        let pushed = FilterPushdownResult::Pushed;
        assert!(pushed.is_pushed());
        assert!(pushed.any_pushed());
        assert!(pushed.remaining().is_none());

        let not_pushed = FilterPushdownResult::NotPushed(Box::new(col("x").eq(lit(1i64))));
        assert!(!not_pushed.is_pushed());
        assert!(!not_pushed.any_pushed());
        assert!(not_pushed.remaining().is_some());
    }
}
