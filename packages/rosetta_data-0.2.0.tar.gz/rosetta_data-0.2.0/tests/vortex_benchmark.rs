// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Benchmark comparing Vortex vs Parquet performance
//!
//! This test demonstrates Rosetta's value proposition:
//! - Read Vortex files through the same API as Parquet
//! - Compare file sizes and read performance

#![cfg(feature = "vortex-reader")]

use arrow::array::{Float64Array, Int64Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use std::sync::Arc;
use std::time::Instant;
use tempfile::TempDir;
use vortex::file::VortexWriteOptions;
use vortex_array::arrays::{PrimitiveArray, StructArray, VarBinArray};
use vortex_array::stream::ArrayStreamExt;
use vortex_array::IntoArray;

/// Generate test data as Arrow RecordBatch
fn generate_test_data(num_rows: usize) -> RecordBatch {
    let categories = ["Electronics", "Home", "Office", "Outdoor", "Sports"];
    let regions = ["North", "South", "East", "West", "Central"];

    let ids: Vec<i64> = (0..num_rows as i64).collect();
    let customer_ids: Vec<i64> = (0..num_rows).map(|i| (i % 10000) as i64).collect();
    let prices: Vec<f64> = (0..num_rows).map(|i| (i % 1000) as f64 * 0.99).collect();
    let category_values: Vec<&str> = (0..num_rows)
        .map(|i| categories[i % categories.len()])
        .collect();
    let region_values: Vec<&str> = (0..num_rows).map(|i| regions[i % regions.len()]).collect();

    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int64, false),
        Field::new("customer_id", DataType::Int64, false),
        Field::new("price", DataType::Float64, false),
        Field::new("category", DataType::Utf8, false),
        Field::new("region", DataType::Utf8, false),
    ]));

    RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int64Array::from(ids)),
            Arc::new(Int64Array::from(customer_ids)),
            Arc::new(Float64Array::from(prices)),
            Arc::new(StringArray::from(category_values)),
            Arc::new(StringArray::from(region_values)),
        ],
    )
    .unwrap()
}

/// Write data as Vortex file
fn write_vortex_file(path: &std::path::Path, batch: &RecordBatch) {
    // Convert Arrow arrays to Vortex arrays
    let ids: Vec<i64> = batch
        .column(0)
        .as_any()
        .downcast_ref::<Int64Array>()
        .unwrap()
        .values()
        .to_vec();
    let customer_ids: Vec<i64> = batch
        .column(1)
        .as_any()
        .downcast_ref::<Int64Array>()
        .unwrap()
        .values()
        .to_vec();
    let prices: Vec<f64> = batch
        .column(2)
        .as_any()
        .downcast_ref::<Float64Array>()
        .unwrap()
        .values()
        .to_vec();
    let categories: Vec<&str> = (0..batch.num_rows())
        .map(|i| {
            batch
                .column(3)
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap()
                .value(i)
        })
        .collect();
    let regions: Vec<&str> = (0..batch.num_rows())
        .map(|i| {
            batch
                .column(4)
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap()
                .value(i)
        })
        .collect();

    // Create Vortex arrays
    let id_arr = PrimitiveArray::from_iter(ids).into_array();
    let customer_id_arr = PrimitiveArray::from_iter(customer_ids).into_array();
    let price_arr = PrimitiveArray::from_iter(prices).into_array();
    let category_arr = VarBinArray::from(categories).into_array();
    let region_arr = VarBinArray::from(regions).into_array();

    let st = StructArray::from_fields(&[
        ("id", id_arr),
        ("customer_id", customer_id_arr),
        ("price", price_arr),
        ("category", category_arr),
        ("region", region_arr),
    ])
    .unwrap();

    // Write to file
    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .unwrap();

    std::fs::write(path, buf).unwrap();
}

/// Write data as Parquet file
fn write_parquet_file(path: &std::path::Path, batch: &RecordBatch) {
    use parquet::arrow::ArrowWriter;
    use parquet::basic::Compression;
    use parquet::file::properties::WriterProperties;

    let props = WriterProperties::builder()
        .set_compression(Compression::SNAPPY)
        .build();

    let file = std::fs::File::create(path).unwrap();
    let mut writer = ArrowWriter::try_new(file, batch.schema(), Some(props)).unwrap();
    writer.write(batch).unwrap();
    writer.close().unwrap();
}

#[tokio::test]
async fn test_vortex_vs_parquet_benchmark() {
    let num_rows = 100_000;
    let iterations = 5;

    println!("\n=== Vortex vs Parquet Benchmark ===");
    println!("Rows: {}", num_rows);
    println!("Iterations: {}", iterations);

    // Generate test data
    let batch = generate_test_data(num_rows);

    // Create temp directory
    let temp_dir = TempDir::new().unwrap();
    let parquet_path = temp_dir.path().join("benchmark.parquet");
    let vortex_path = temp_dir.path().join("benchmark.vortex");

    // Write both formats
    write_parquet_file(&parquet_path, &batch);
    write_vortex_file(&vortex_path, &batch);

    // Get file sizes
    let parquet_size = std::fs::metadata(&parquet_path).unwrap().len();
    let vortex_size = std::fs::metadata(&vortex_path).unwrap().len();

    println!("\n--- File Sizes ---");
    println!(
        "Parquet: {} bytes ({:.2} MiB)",
        parquet_size,
        parquet_size as f64 / 1024.0 / 1024.0
    );
    println!(
        "Vortex:  {} bytes ({:.2} MiB)",
        vortex_size,
        vortex_size as f64 / 1024.0 / 1024.0
    );
    println!(
        "Compression: {:.1}% smaller",
        (1.0 - vortex_size as f64 / parquet_size as f64) * 100.0
    );

    // Benchmark Parquet reading through Rosetta
    println!("\n--- Read Performance ---");

    let mut parquet_times = Vec::new();
    for _ in 0..iterations {
        let start = Instant::now();
        let reader = rosetta::UnifiedReader::open(&parquet_path).await.unwrap();
        let batches = reader.read_all().await.unwrap();
        let _rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        parquet_times.push(start.elapsed());
    }
    parquet_times.sort();
    let parquet_median = parquet_times[iterations / 2];

    // Benchmark Vortex reading through Rosetta
    let mut vortex_times = Vec::new();
    for _ in 0..iterations {
        let start = Instant::now();
        let reader = rosetta::UnifiedReader::open(&vortex_path).await.unwrap();
        let batches = reader.read_all().await.unwrap();
        let _rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        vortex_times.push(start.elapsed());
    }
    vortex_times.sort();
    let vortex_median = vortex_times[iterations / 2];

    println!("Parquet read: {:.2?} (median)", parquet_median);
    println!("Vortex read:  {:.2?} (median)", vortex_median);

    let throughput_parquet = parquet_size as f64 / 1024.0 / 1024.0 / parquet_median.as_secs_f64();
    let throughput_vortex = vortex_size as f64 / 1024.0 / 1024.0 / vortex_median.as_secs_f64();

    println!("Parquet throughput: {:.0} MiB/s", throughput_parquet);
    println!("Vortex throughput:  {:.0} MiB/s", throughput_vortex);

    // Summary
    println!("\n=== Summary ===");
    if vortex_size < parquet_size {
        println!(
            "✓ Vortex is {:.1}% smaller than Parquet",
            (1.0 - vortex_size as f64 / parquet_size as f64) * 100.0
        );
    } else {
        println!(
            "✗ Vortex is {:.1}% larger than Parquet",
            (vortex_size as f64 / parquet_size as f64 - 1.0) * 100.0
        );
    }

    if vortex_median < parquet_median {
        println!(
            "✓ Vortex is {:.1}% faster to read",
            (1.0 - vortex_median.as_secs_f64() / parquet_median.as_secs_f64()) * 100.0
        );
    } else {
        println!(
            "✗ Vortex is {:.1}% slower to read",
            (vortex_median.as_secs_f64() / parquet_median.as_secs_f64() - 1.0) * 100.0
        );
    }

    println!("✓ Both formats read through same Rosetta API!");
}

#[tokio::test]
async fn test_vortex_transcoding_roundtrip() {
    println!("\n=== Vortex → Parquet Transcoding Test ===");

    let num_rows = 10_000;
    let batch = generate_test_data(num_rows);

    let temp_dir = TempDir::new().unwrap();
    let vortex_path = temp_dir.path().join("source.vortex");

    // Write Vortex file
    write_vortex_file(&vortex_path, &batch);
    let vortex_size = std::fs::metadata(&vortex_path).unwrap().len();

    // Transcode to Parquet
    let start = Instant::now();
    let transcoder = rosetta::Transcoder::new();
    let result = transcoder.transcode_file(&vortex_path).await.unwrap();
    let transcode_time = start.elapsed();

    println!("Source format: {:?}", result.source_format);
    println!("Rows: {}", result.num_rows);
    println!("Columns: {}", result.num_columns);
    println!("Vortex size: {} bytes", vortex_size);
    println!("Parquet output: {} bytes", result.bytes.len());
    println!("Transcode time: {:.2?}", transcode_time);

    // Verify the transcoded Parquet is valid
    assert_eq!(
        &result.bytes[0..4],
        b"PAR1",
        "Should start with Parquet magic"
    );
    assert_eq!(
        &result.bytes[result.bytes.len() - 4..],
        b"PAR1",
        "Should end with Parquet magic"
    );
    assert_eq!(result.num_rows, num_rows);
    assert_eq!(result.num_columns, 5);

    // Read the transcoded Parquet
    let parquet_reader = rosetta::readers::ParquetReader::from_bytes(result.bytes.clone().into())
        .await
        .unwrap();
    let parquet_batches = parquet_reader.read_all().await.unwrap();
    let parquet_rows: usize = parquet_batches.iter().map(|b| b.num_rows()).sum();

    assert_eq!(parquet_rows, num_rows);
    println!("✓ Transcoded Parquet readable: {} rows", parquet_rows);
    println!("✓ Legacy readers can now read this Vortex data as Parquet!");
}
