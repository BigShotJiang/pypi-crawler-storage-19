// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Integration tests for WASM runtime and F3 file format
//!
//! These tests verify that the WASM runtime can execute decoders.

#![cfg(feature = "wasm-runtime")]

use rosetta::wasm::{DecoderId, OutputType, SandboxConfig, WasmRuntime};
use tempfile::TempDir;

/// A minimal identity decoder in WAT (WebAssembly Text) format
/// This decoder just copies input bytes to output
const IDENTITY_DECODER_WAT: &str = r#"
(module
  (memory (export "memory") 1)

  ;; decoder_init(metadata_ptr: i32, metadata_len: i32) -> state_ptr: i32
  ;; Returns a "state pointer" (we just return 0 since we don't need state)
  (func (export "decoder_init") (param $meta_ptr i32) (param $meta_len i32) (result i32)
    i32.const 0  ;; Return 0 as state pointer
  )

  ;; decoder_decode(state: i32, in_ptr: i32, in_len: i32, out_ptr: i32, out_max: i32) -> out_len: i32
  ;; Copies input bytes to output (identity decoder)
  (func (export "decoder_decode")
    (param $state i32) (param $in_ptr i32) (param $in_len i32)
    (param $out_ptr i32) (param $out_max i32) (result i32)
    (local $i i32)

    ;; Check if output buffer is large enough
    (if (i32.gt_u (local.get $in_len) (local.get $out_max))
      (then (return (i32.const -1)))
    )

    ;; Copy loop: copy input to output byte by byte
    (local.set $i (i32.const 0))
    (block $break
      (loop $continue
        ;; if i >= in_len, break
        (br_if $break (i32.ge_u (local.get $i) (local.get $in_len)))

        ;; out[i] = in[i]
        (i32.store8
          (i32.add (local.get $out_ptr) (local.get $i))
          (i32.load8_u (i32.add (local.get $in_ptr) (local.get $i)))
        )

        ;; i++
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $continue)
      )
    )

    ;; Return number of bytes written (= in_len)
    (local.get $in_len)
  )
)
"#;

/// Compile WAT to WASM bytes
fn compile_wat_to_wasm(wat: &str) -> Vec<u8> {
    wat::parse_str(wat).expect("Failed to compile WAT to WASM")
}

#[test]
fn test_wasm_runtime_creation() {
    let runtime = WasmRuntime::testing().expect("Failed to create runtime");
    let stats = runtime.stats();
    assert_eq!(stats.pool_stats.cached_modules, 0);
    println!("✓ WASM runtime created successfully");
}

#[test]
fn test_identity_decoder_compilation() {
    let wasm_bytes = compile_wat_to_wasm(IDENTITY_DECODER_WAT);
    assert!(!wasm_bytes.is_empty());

    // WASM files start with magic bytes \0asm
    assert_eq!(&wasm_bytes[0..4], b"\0asm");
    println!("✓ Identity decoder compiled: {} bytes", wasm_bytes.len());
}

#[test]
fn test_decode_with_identity_decoder() {
    // Create runtime with permissive allowlist for testing
    let config = SandboxConfig::testing();
    let runtime = WasmRuntime::new(config).expect("Failed to create runtime");

    // Compile decoder
    let wasm_bytes = compile_wat_to_wasm(IDENTITY_DECODER_WAT);

    // Test data
    let input = b"Hello, WASM world!";
    let metadata = b"test-metadata";
    let decoder_id = DecoderId::new("identity".to_string(), 1);

    // Decode
    let result = runtime
        .decode_oneshot(&decoder_id, &wasm_bytes, metadata, input)
        .expect("Decode failed");

    // Should get back the same bytes
    assert_eq!(result, input);
    println!(
        "✓ Identity decoder correctly decoded {} bytes",
        result.len()
    );
}

#[test]
fn test_decode_int32_data() {
    let config = SandboxConfig::testing();
    let runtime = WasmRuntime::new(config).expect("Failed to create runtime");

    let wasm_bytes = compile_wat_to_wasm(IDENTITY_DECODER_WAT);
    let decoder_id = DecoderId::new("identity".to_string(), 1);

    // Create some Int32 data as bytes
    let values: Vec<i32> = vec![1, 2, 3, 4, 5, 100, -50, i32::MAX, i32::MIN];
    let input: Vec<u8> = values.iter().flat_map(|v| v.to_le_bytes()).collect();

    let result = runtime
        .decode_oneshot(&decoder_id, &wasm_bytes, b"", &input)
        .expect("Decode failed");

    // Parse back to i32
    let decoded_values: Vec<i32> = result
        .chunks_exact(4)
        .map(|c| i32::from_le_bytes([c[0], c[1], c[2], c[3]]))
        .collect();

    assert_eq!(decoded_values, values);
    println!("✓ Int32 data roundtrip successful: {:?}", decoded_values);
}

#[test]
fn test_decoder_with_large_data() {
    let config = SandboxConfig::testing();
    let runtime = WasmRuntime::new(config).expect("Failed to create runtime");

    let wasm_bytes = compile_wat_to_wasm(IDENTITY_DECODER_WAT);
    let decoder_id = DecoderId::new("identity".to_string(), 1);

    // Create 1MB of test data
    let input: Vec<u8> = (0..1024 * 1024).map(|i| (i % 256) as u8).collect();

    let result = runtime
        .decode_oneshot(&decoder_id, &wasm_bytes, b"", &input)
        .expect("Decode failed");

    assert_eq!(result.len(), input.len());
    assert_eq!(result, input);
    println!("✓ Large data (1MB) decoded successfully");
}

#[test]
fn test_multiple_decodes() {
    // Note: Each decode grows WASM memory without cleanup. To avoid OOM,
    // we create a fresh runtime for each decode in this test.
    let wasm_bytes = compile_wat_to_wasm(IDENTITY_DECODER_WAT);
    let decoder_id = DecoderId::new("identity".to_string(), 1);

    // Run multiple decodes with fresh runtimes
    for i in 0..5 {
        let config = SandboxConfig::testing();
        let runtime = WasmRuntime::new(config).expect("Failed to create runtime");

        let input = format!("Message number {}", i);
        let result = runtime
            .decode_oneshot(&decoder_id, &wasm_bytes, b"", input.as_bytes())
            .expect("Decode failed");

        assert_eq!(String::from_utf8_lossy(&result), input);
    }

    println!("✓ Multiple sequential decodes successful");
}

// ==================== F3 File Format Tests ====================

/// Helper to create a minimal F3 file with embedded WASM decoder
fn create_f3_file(path: &std::path::Path, values: &[i32]) {
    use std::io::Write;

    let wasm_bytes = compile_wat_to_wasm(IDENTITY_DECODER_WAT);

    // Encode the values as bytes
    let encoded_data: Vec<u8> = values.iter().flat_map(|v| v.to_le_bytes()).collect();

    // Create schema JSON
    let schema_json = r#"{"fields":[{"name":"value","type":"Int32","nullable":false}]}"#;

    let mut file = std::fs::File::create(path).unwrap();

    // Write F3 header
    file.write_all(b"F3\x00\x01").unwrap(); // Magic
    file.write_all(&1u16.to_le_bytes()).unwrap(); // Version
    file.write_all(&0u32.to_le_bytes()).unwrap(); // Header length (placeholder)

    // Write schema
    file.write_all(&(schema_json.len() as u32).to_le_bytes())
        .unwrap();
    file.write_all(schema_json.as_bytes()).unwrap();

    // Write decoder section
    file.write_all(&1u32.to_le_bytes()).unwrap(); // 1 decoder

    // Decoder metadata: name
    let decoder_name = "identity";
    file.write_all(&(decoder_name.len() as u16).to_le_bytes())
        .unwrap();
    file.write_all(decoder_name.as_bytes()).unwrap();

    // Decoder version
    file.write_all(&1u32.to_le_bytes()).unwrap();

    // WASM length and bytes
    file.write_all(&(wasm_bytes.len() as u32).to_le_bytes())
        .unwrap();

    // Metadata length (0)
    file.write_all(&0u32.to_le_bytes()).unwrap();

    // WASM bytes
    file.write_all(&wasm_bytes).unwrap();

    // Data section offset (record current position)
    let data_offset = file.metadata().unwrap().len();

    // Write data
    file.write_all(&encoded_data).unwrap();

    // Footer
    let footer_offset = file.metadata().unwrap().len();

    // Number of columns
    file.write_all(&1u32.to_le_bytes()).unwrap();
    // Total rows
    file.write_all(&(values.len() as u64).to_le_bytes())
        .unwrap();
    // Column 0: 1 chunk
    file.write_all(&1u32.to_le_bytes()).unwrap();
    // Chunk info: offset, length, row_count
    file.write_all(&data_offset.to_le_bytes()).unwrap();
    file.write_all(&(encoded_data.len() as u64).to_le_bytes())
        .unwrap();
    file.write_all(&(values.len() as u32).to_le_bytes())
        .unwrap();

    // Footer offset pointer at very end
    file.write_all(&footer_offset.to_le_bytes()).unwrap();

    file.flush().unwrap();
}

// Note: F3Reader tests require the full F3 file format to be properly implemented
// For now, we test the WASM runtime directly which is the critical component
