// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Benchmarks for reading columnar files
//!
//! Compares Rosetta's transcoding overhead against native Parquet reading.
//!
//! Run with: cargo +nightly bench --features "vortex-reader,lance-reader"
//! Note: Uses small datasets (~10MB total) to minimize disk usage.

use arrow::array::{Float64Array, Int64Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use criterion::{black_box, criterion_group, criterion_main, BenchmarkId, Criterion, Throughput};
use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;
use parquet::arrow::ArrowWriter;
use parquet::basic::Compression;
use parquet::file::properties::WriterProperties;
use std::sync::Arc;
use tempfile::NamedTempFile;

/// Generate test data with various column types
fn generate_test_data(num_rows: usize) -> RecordBatch {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int64, false),
        Field::new("value", DataType::Float64, false),
        Field::new("name", DataType::Utf8, true),
        Field::new("category", DataType::Utf8, true),
    ]));

    let ids: Vec<i64> = (0..num_rows as i64).collect();
    let values: Vec<f64> = (0..num_rows).map(|i| (i as f64) * 1.5).collect();
    let names: Vec<Option<&str>> = (0..num_rows)
        .map(|i| {
            if i % 10 == 0 {
                None
            } else {
                Some("test_name_with_some_length")
            }
        })
        .collect();
    let categories: Vec<Option<&str>> = (0..num_rows)
        .map(|i| Some(["alpha", "beta", "gamma", "delta"][i % 4]))
        .collect();

    RecordBatch::try_new(
        schema,
        vec![
            Arc::new(Int64Array::from(ids)),
            Arc::new(Float64Array::from(values)),
            Arc::new(StringArray::from(names)),
            Arc::new(StringArray::from(categories)),
        ],
    )
    .unwrap()
}

/// Create a Parquet file with specified compression
fn create_parquet_file(batch: &RecordBatch, compression: Compression) -> NamedTempFile {
    let file = NamedTempFile::new().unwrap();

    let props = WriterProperties::builder()
        .set_compression(compression)
        .build();

    let file_writer = std::fs::File::create(file.path()).unwrap();
    let mut writer = ArrowWriter::try_new(file_writer, batch.schema(), Some(props)).unwrap();
    writer.write(batch).unwrap();
    writer.close().unwrap();

    file
}

/// Benchmark native Parquet reading (baseline)
fn bench_native_parquet_read(c: &mut Criterion) {
    let mut group = c.benchmark_group("native_parquet_read");

    // Using smaller sizes to save disk space
    for num_rows in [1_000, 10_000, 100_000] {
        let batch = generate_test_data(num_rows);
        let file = create_parquet_file(&batch, Compression::SNAPPY);
        let file_size = std::fs::metadata(file.path()).unwrap().len();

        group.throughput(Throughput::Bytes(file_size));
        group.bench_with_input(BenchmarkId::new("snappy", num_rows), &file, |b, file| {
            b.iter(|| {
                let data = std::fs::read(file.path()).unwrap();
                let builder =
                    ParquetRecordBatchReaderBuilder::try_new(bytes::Bytes::from(data)).unwrap();
                let reader = builder.build().unwrap();
                let batches: Vec<_> = reader.collect();
                black_box(batches)
            });
        });
    }

    group.finish();
}

/// Benchmark Rosetta unified reader (async with format detection)
fn bench_rosetta_read(c: &mut Criterion) {
    use rosetta::UnifiedReader;

    let rt = tokio::runtime::Runtime::new().unwrap();

    let mut group = c.benchmark_group("rosetta_read");

    for num_rows in [1_000, 10_000, 100_000] {
        let batch = generate_test_data(num_rows);
        let file = create_parquet_file(&batch, Compression::SNAPPY);
        let file_size = std::fs::metadata(file.path()).unwrap().len();

        group.throughput(Throughput::Bytes(file_size));
        group.bench_with_input(
            BenchmarkId::new("async_autodetect", num_rows),
            &file,
            |b, file| {
                b.iter(|| {
                    rt.block_on(async {
                        let reader = UnifiedReader::open(file.path()).await.unwrap();
                        let batches = reader.read_all().await.unwrap();
                        black_box(batches)
                    })
                });
            },
        );
    }

    group.finish();
}

/// Benchmark Rosetta sync path - the optimized Parquet passthrough
fn bench_rosetta_sync(c: &mut Criterion) {
    use rosetta::UnifiedReader;

    let mut group = c.benchmark_group("rosetta_sync");

    for num_rows in [1_000, 10_000, 100_000] {
        let batch = generate_test_data(num_rows);
        let file = create_parquet_file(&batch, Compression::SNAPPY);
        let file_size = std::fs::metadata(file.path()).unwrap().len();

        group.throughput(Throughput::Bytes(file_size));
        group.bench_with_input(
            BenchmarkId::new("sync_parquet", num_rows),
            &file,
            |b, file| {
                b.iter(|| {
                    let reader = UnifiedReader::open_parquet_sync(file.path()).unwrap();
                    let batches = reader.read_all_sync().unwrap();
                    black_box(batches)
                });
            },
        );
    }

    group.finish();
}

/// Fair comparison benchmark - all methods read the SAME file
/// This eliminates OS cache bias from benchmark ordering
fn bench_fair_comparison(c: &mut Criterion) {
    use rosetta::UnifiedReader;

    let rt = tokio::runtime::Runtime::new().unwrap();
    let mut group = c.benchmark_group("fair_comparison");

    // Test multiple sizes including 1M rows
    for num_rows in [1_000, 10_000, 100_000, 1_000_000] {
        let batch = generate_test_data(num_rows);
        let file = create_parquet_file(&batch, Compression::SNAPPY);
        let file_size = std::fs::metadata(file.path()).unwrap().len();
        let path = file.path().to_path_buf();

        println!(
            "Testing {} rows, file size: {} KB",
            num_rows,
            file_size / 1024
        );

        group.throughput(Throughput::Bytes(file_size));

        // Warm up the page cache first by reading once
        let _ = std::fs::read(&path);

        // Native Parquet (baseline)
        group.bench_with_input(BenchmarkId::new("native", num_rows), &path, |b, path| {
            b.iter(|| {
                let data = std::fs::read(path).unwrap();
                let builder =
                    ParquetRecordBatchReaderBuilder::try_new(bytes::Bytes::from(data)).unwrap();
                let reader = builder.build().unwrap();
                // Collect and unwrap Results for fair comparison with Rosetta
                let batches: Vec<RecordBatch> =
                    reader.collect::<std::result::Result<Vec<_>, _>>().unwrap();
                black_box(batches)
            });
        });

        // Rosetta async (with format detection)
        group.bench_with_input(
            BenchmarkId::new("rosetta_async", num_rows),
            &path,
            |b, path| {
                b.iter(|| {
                    rt.block_on(async {
                        let reader = UnifiedReader::open(path).await.unwrap();
                        let batches = reader.read_all().await.unwrap();
                        black_box(batches)
                    })
                });
            },
        );

        // Rosetta sync (optimized path)
        group.bench_with_input(
            BenchmarkId::new("rosetta_sync", num_rows),
            &path,
            |b, path| {
                b.iter(|| {
                    let reader = UnifiedReader::open_parquet_sync(path).unwrap();
                    let batches = reader.read_all_sync().unwrap();
                    black_box(batches)
                });
            },
        );
    }

    group.finish();
}

/// Benchmark format detection overhead
fn bench_format_detection(c: &mut Criterion) {
    use rosetta::FormatDetector;

    let rt = tokio::runtime::Runtime::new().unwrap();

    let batch = generate_test_data(10_000);
    let file = create_parquet_file(&batch, Compression::SNAPPY);

    c.bench_function("format_detection", |b| {
        b.iter(|| {
            rt.block_on(async {
                let detector = FormatDetector::new();
                let format = detector.detect_file(file.path()).await.unwrap();
                black_box(format)
            })
        });
    });
}

/// Benchmark column projection
fn bench_column_projection(c: &mut Criterion) {
    use rosetta::{ReadOptions, UnifiedReader};

    let rt = tokio::runtime::Runtime::new().unwrap();

    let batch = generate_test_data(50_000); // Reduced from 100k
    let file = create_parquet_file(&batch, Compression::SNAPPY);

    let mut group = c.benchmark_group("column_projection");

    // Read all columns
    group.bench_function("all_columns", |b| {
        b.iter(|| {
            rt.block_on(async {
                let reader = UnifiedReader::open(file.path()).await.unwrap();
                let batches = reader.read_all().await.unwrap();
                black_box(batches)
            })
        });
    });

    // Read single column
    group.bench_function("single_column", |b| {
        b.iter(|| {
            rt.block_on(async {
                let options = ReadOptions::new().with_columns(vec!["id".to_string()]);
                let reader = UnifiedReader::open_with_options(file.path(), options)
                    .await
                    .unwrap();
                let batches = reader.read_all().await.unwrap();
                black_box(batches)
            })
        });
    });

    // Read two columns
    group.bench_function("two_columns", |b| {
        b.iter(|| {
            rt.block_on(async {
                let options =
                    ReadOptions::new().with_columns(vec!["id".to_string(), "value".to_string()]);
                let reader = UnifiedReader::open_with_options(file.path(), options)
                    .await
                    .unwrap();
                let batches = reader.read_all().await.unwrap();
                black_box(batches)
            })
        });
    });

    group.finish();
}

/// Benchmark different compression codecs
fn bench_compression_codecs(c: &mut Criterion) {
    use rosetta::UnifiedReader;

    let rt = tokio::runtime::Runtime::new().unwrap();

    let batch = generate_test_data(50_000); // Reduced from 100k
    let mut group = c.benchmark_group("compression_codecs");

    for (name, compression) in [
        ("uncompressed", Compression::UNCOMPRESSED),
        ("snappy", Compression::SNAPPY),
        ("zstd", Compression::ZSTD(Default::default())),
        ("lz4", Compression::LZ4),
    ] {
        let file = create_parquet_file(&batch, compression);
        let file_size = std::fs::metadata(file.path()).unwrap().len();

        group.throughput(Throughput::Bytes(file_size));
        group.bench_with_input(BenchmarkId::new("rosetta", name), &file, |b, file| {
            b.iter(|| {
                rt.block_on(async {
                    let reader = UnifiedReader::open(file.path()).await.unwrap();
                    let batches = reader.read_all().await.unwrap();
                    black_box(batches)
                })
            });
        });
    }

    group.finish();
}

/// Benchmark transcoding throughput (Parquet → Arrow → Parquet)
fn bench_transcoder(c: &mut Criterion) {
    use rosetta::transcoder::Transcoder;

    let rt = tokio::runtime::Runtime::new().unwrap();

    let mut group = c.benchmark_group("transcoder");

    for num_rows in [1_000, 10_000, 50_000] {
        let batch = generate_test_data(num_rows);
        let file = create_parquet_file(&batch, Compression::SNAPPY);
        let file_size = std::fs::metadata(file.path()).unwrap().len();

        group.throughput(Throughput::Bytes(file_size));
        group.bench_with_input(
            BenchmarkId::new("parquet_roundtrip", num_rows),
            &file,
            |b, file| {
                b.iter(|| {
                    rt.block_on(async {
                        let transcoder = Transcoder::new();
                        let result = transcoder.transcode_file(file.path()).await.unwrap();
                        black_box(result.bytes.len())
                    })
                });
            },
        );
    }

    group.finish();
}

// Vortex benchmarks (only when feature enabled)
#[cfg(feature = "vortex-reader")]
fn bench_vortex_transcode(c: &mut Criterion) {
    use rosetta::transcoder::Transcoder;
    use tempfile::TempDir;
    use vortex::file::VortexWriteOptions;
    use vortex_array::arrays::{PrimitiveArray, StructArray, VarBinArray};
    use vortex_array::IntoArray;

    let rt = tokio::runtime::Runtime::new().unwrap();
    let mut group = c.benchmark_group("vortex_transcode");

    for num_rows in [1_000, 10_000, 50_000] {
        let temp_dir = TempDir::new().unwrap();
        let vortex_path = temp_dir.path().join("bench.vortex");

        // Create Vortex file with integer and string columns
        let ids_arr: PrimitiveArray = (0..num_rows as i64).collect();
        let names: Vec<&str> = (0..num_rows).map(|_| "benchmark_name").collect();
        let names_arr = VarBinArray::from(names).into_array();
        let st =
            StructArray::from_fields(&[("id", ids_arr.into_array()), ("name", names_arr)]).unwrap();
        let buf = VortexWriteOptions::default()
            .write_blocking(Vec::new(), st.to_array_stream())
            .unwrap();
        std::fs::write(&vortex_path, &buf).unwrap();
        let file_size = buf.len() as u64;

        group.throughput(Throughput::Bytes(file_size));
        group.bench_with_input(
            BenchmarkId::new("to_parquet", num_rows),
            &vortex_path,
            |b, path| {
                b.iter(|| {
                    rt.block_on(async {
                        let transcoder = Transcoder::new();
                        let result = transcoder.transcode_file(path).await.unwrap();
                        black_box(result.bytes.len())
                    })
                });
            },
        );
    }

    group.finish();
}

#[cfg(not(feature = "vortex-reader"))]
fn bench_vortex_transcode(_c: &mut Criterion) {
    // Vortex benchmarks disabled - feature not enabled
}

// Lance benchmarks (only when feature enabled)
#[cfg(feature = "lance-reader")]
fn bench_lance_transcode(c: &mut Criterion) {
    use arrow::record_batch::RecordBatchIterator;
    use lance::Dataset;
    use rosetta::transcoder::Transcoder;
    use tempfile::TempDir;

    let rt = tokio::runtime::Runtime::new().unwrap();
    let mut group = c.benchmark_group("lance_transcode");

    for num_rows in [1_000, 10_000, 50_000] {
        let temp_dir = TempDir::new().unwrap();
        let lance_path = temp_dir.path().join("bench.lance");

        // Create Lance dataset
        let batch = generate_test_data(num_rows);
        let schema = batch.schema();
        let reader = RecordBatchIterator::new(vec![Ok(batch)], schema);

        rt.block_on(async {
            Dataset::write(reader, lance_path.to_str().unwrap(), None)
                .await
                .unwrap();
        });

        // Get directory size
        let file_size: u64 = walkdir::WalkDir::new(&lance_path)
            .into_iter()
            .filter_map(|e| e.ok())
            .filter_map(|e| e.metadata().ok())
            .filter(|m| m.is_file())
            .map(|m| m.len())
            .sum();

        group.throughput(Throughput::Bytes(file_size));
        group.bench_with_input(
            BenchmarkId::new("to_parquet", num_rows),
            &lance_path,
            |b, path| {
                b.iter(|| {
                    rt.block_on(async {
                        let transcoder = Transcoder::new();
                        let result = transcoder.transcode_file(path).await.unwrap();
                        black_box(result.bytes.len())
                    })
                });
            },
        );
    }

    group.finish();
}

#[cfg(not(feature = "lance-reader"))]
fn bench_lance_transcode(_c: &mut Criterion) {
    // Lance benchmarks disabled - feature not enabled
}

criterion_group!(
    benches,
    bench_fair_comparison, // Fair comparison - same file for all methods
    bench_native_parquet_read,
    bench_rosetta_read,
    bench_rosetta_sync,
    bench_format_detection,
    bench_column_projection,
    bench_compression_codecs,
    bench_transcoder,
    bench_vortex_transcode,
    bench_lance_transcode,
);
criterion_main!(benches);
