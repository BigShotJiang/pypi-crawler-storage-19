// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Rosetta: Universal File Format Bridge
//!
//! Rosetta provides transparent reading of multiple columnar file formats
//! (Parquet, Vortex, Lance, F3) through a unified API, outputting Apache Arrow.
//!
//! It also provides **intercept layers** that transcode any format to Parquet v1
//! bytes, enabling legacy readers (Spark 2.x, old Pandas, etc.) to read new
//! formats with ZERO code changes.
//!
//! # Core Reading API
//!
//! ```rust,ignore
//! use rosetta::read_file;
//!
//! // Automatically detects format and returns Arrow RecordBatches
//! let batches = read_file("data.parquet").await?;
//! let batches = read_file("data.vortex").await?;  // Same API!
//! ```
//!
//! # Intercept Layers (for legacy readers)
//!
//! ## S3 Proxy
//! ```bash
//! rosetta proxy --bind 127.0.0.1:9000 --root /data/lake
//! # Configure apps: AWS_ENDPOINT_URL=http://127.0.0.1:9000
//! ```
//!
//! ## FUSE Mount
//! ```bash
//! rosetta mount /data/lake /mnt/rosetta
//! # Now: pandas.read_parquet("/mnt/rosetta/data.vortex") works!
//! ```
//!
//! ## DuckDB Extension
//! ```sql
//! LOAD rosetta;
//! SELECT * FROM read_parquet('rosetta://data.vortex');
//! ```
//!
//! ## Iceberg FileIO
//! ```python
//! from rosetta.iceberg import RosettaFileIO
//! catalog = load_catalog("my_catalog", **{"io-impl": "rosetta.iceberg.RosettaFileIO"})
//! ```

pub mod benchmark;
pub mod duckdb;
pub mod encoding;
pub mod error;
pub mod expr;
pub mod format;
pub mod fuse;
pub mod iceberg;
pub mod object_store_utils;
pub mod partition;
pub mod proxy;
pub mod readers;
pub mod stats;
pub mod transcoder;
pub mod upgrade;
pub mod writers;

#[cfg(feature = "wasm-runtime")]
pub mod wasm;

#[cfg(feature = "python")]
pub mod python;

#[cfg(feature = "python")]
pub mod python_errors;

#[cfg(feature = "datafusion-integration")]
pub mod datafusion;

// C FFI bindings for JVM/native integration
pub mod ffi;

pub use error::{Error, Result};
pub use format::{FileFormat, FormatDetector};
pub use readers::UnifiedReader;

// Core abstractions for the vision
pub use expr::{col, lit, Expr, FilterPushdownResult, Operator};
pub use partition::{Partition, PartitionBuilder, PartitionStrategy};
pub use stats::{ColumnStatistics, ScalarValue, Statistics};

// Re-export key types from new modules
pub use benchmark::{
    generate_benchmark_file, generate_report, run_benchmark_suite, run_benchmark_suite_opts,
    BenchmarkConfig, BenchmarkResult,
};
pub use duckdb::{DuckDbExtension, DuckDbExtensionConfig};
pub use encoding::{ColumnStats, EncodingRecommendation, EncodingSelector, RecommendedEncoding};
pub use fuse::{RosettaFs, RosettaFsConfig};
pub use iceberg::{RosettaFileIO, RosettaFileIOConfig};
pub use proxy::{S3Proxy, S3ProxyConfig};
pub use transcoder::{transcode_to_parquet, TranscodeResult, Transcoder};
pub use upgrade::{FileAnalysis, TargetEncoding, UpgradeOptions, UpgradeReport, Upgrader};
pub use writers::{ParquetWriter, ParquetWriterOptions};

// Re-export enterprise extension traits (interfaces are OSS, implementations are commercial)
pub use proxy::{
    get_auth_provider, set_auth_provider, AuthError, AuthProvider, AuthRequest, Identity,
};
pub use readers::{
    get_reader_hooks, set_reader_hooks, FormatReader, ReaderAcceleration, ReaderHooks,
};
pub use transcoder::{get_transcode_hooks, set_transcode_hooks, TranscodeHooks};

use arrow::record_batch::RecordBatch;
use std::path::Path;

/// Read a file and return Arrow RecordBatches
///
/// Automatically detects the file format and uses the appropriate reader.
pub async fn read_file<P: AsRef<Path>>(path: P) -> Result<Vec<RecordBatch>> {
    let reader = UnifiedReader::open(path).await?;
    reader.read_all().await
}

/// Read a file with options
pub async fn read_file_with_options<P: AsRef<Path>>(
    path: P,
    options: ReadOptions,
) -> Result<Vec<RecordBatch>> {
    let reader = UnifiedReader::open_with_options(path, options).await?;
    reader.read_all().await
}

/// Options for reading files
#[derive(Debug, Clone, Default)]
pub struct ReadOptions {
    /// Columns to read (None = all columns)
    pub columns: Option<Vec<String>>,
    /// Row groups to read (None = all row groups)
    pub row_groups: Option<Vec<usize>>,
    /// Batch size for reading
    pub batch_size: Option<usize>,
    /// Force a specific format (skip auto-detection)
    pub force_format: Option<FileFormat>,
}

impl ReadOptions {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_columns(mut self, columns: Vec<String>) -> Self {
        self.columns = Some(columns);
        self
    }

    pub fn with_batch_size(mut self, batch_size: usize) -> Self {
        self.batch_size = Some(batch_size);
        self
    }

    pub fn with_format(mut self, format: FileFormat) -> Self {
        self.force_format = Some(format);
        self
    }
}
