// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Progressive upgrade module for optimizing columnar files
//!
//! This module provides APIs for upgrading Parquet files to use more efficient
//! encodings without requiring a full migration to a new format.
//!
//! # Overview
//!
//! The progressive upgrade approach allows you to:
//! - Upgrade specific columns while leaving others unchanged
//! - Select optimal encodings based on column statistics
//! - Preview potential savings before committing changes
//!
//! # Example
//!
//! ```ignore
//! use rosetta::upgrade::{Upgrader, UpgradeOptions, TargetEncoding};
//!
//! let upgrader = Upgrader::new();
//!
//! // Analyze a file for potential improvements
//! let analysis = upgrader.analyze("data.parquet").await?;
//! for suggestion in &analysis.suggestions {
//!     println!("{}: {} -> {} ({}% savings)",
//!         suggestion.column_name,
//!         suggestion.current_encoding,
//!         suggestion.recommended_encoding,
//!         suggestion.estimated_savings_percent
//!     );
//! }
//!
//! // Apply upgrades
//! let options = UpgradeOptions::new()
//!     .with_columns(vec!["embedding".to_string()])
//!     .with_encoding(TargetEncoding::Auto);
//!
//! let report = upgrader.upgrade_file("data.parquet", "data_upgraded.parquet", options).await?;
//! println!("Saved {}% ({} bytes)", report.savings_percent, report.bytes_saved);
//! ```

use crate::encoding::{ColumnStats as EncodingColumnStats, EncodingSelector};
use crate::writers::{ParquetWriter, ParquetWriterOptions};
use crate::{Error, FileFormat, FormatDetector, Result, UnifiedReader};
use arrow::datatypes::{DataType, SchemaRef};
use std::path::Path;

/// Target encoding for upgraded columns
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum TargetEncoding {
    /// Auto-select based on column statistics
    #[default]
    Auto,
    /// Use Parquet v2 encodings (DELTA_BINARY_PACKED, BYTE_STREAM_SPLIT, etc.)
    ParquetV2,
    /// Use dictionary encoding with FSST string compression
    DictionaryFSST,
    /// Keep original encoding
    Original,
}

/// Options for column upgrade
#[derive(Debug, Clone)]
pub struct UpgradeOptions {
    /// Columns to upgrade (None = all columns)
    pub columns: Option<Vec<String>>,
    /// Target encoding for upgraded columns
    pub target_encoding: TargetEncoding,
    /// Minimum savings percent to apply upgrade (0-100)
    pub min_savings_percent: f64,
    /// Whether to run in dry-run mode (analyze only)
    pub dry_run: bool,
}

impl Default for UpgradeOptions {
    fn default() -> Self {
        Self {
            columns: None,
            target_encoding: TargetEncoding::Auto,
            min_savings_percent: 5.0,
            dry_run: false,
        }
    }
}

impl UpgradeOptions {
    /// Create new options with defaults
    pub fn new() -> Self {
        Self::default()
    }

    /// Set columns to upgrade
    pub fn with_columns(mut self, columns: Vec<String>) -> Self {
        self.columns = Some(columns);
        self
    }

    /// Set target encoding
    pub fn with_encoding(mut self, encoding: TargetEncoding) -> Self {
        self.target_encoding = encoding;
        self
    }

    /// Set minimum savings threshold
    pub fn with_min_savings(mut self, percent: f64) -> Self {
        self.min_savings_percent = percent;
        self
    }

    /// Enable dry-run mode
    pub fn dry_run(mut self) -> Self {
        self.dry_run = true;
        self
    }
}

/// Analysis of a single column
#[derive(Debug, Clone)]
pub struct ColumnAnalysis {
    /// Column name
    pub name: String,
    /// Column data type
    pub data_type: DataType,
    /// Current encoding (if detectable)
    pub current_encoding: String,
    /// Recommended encoding
    pub recommended_encoding: String,
    /// Current size in bytes
    pub current_size: u64,
    /// Estimated size after upgrade
    pub estimated_new_size: u64,
    /// Estimated savings percentage
    pub estimated_savings_percent: f64,
    /// Whether upgrade is recommended
    pub upgrade_recommended: bool,
    /// Reason for recommendation
    pub reason: String,
}

/// Analysis results for a file
#[derive(Debug, Clone)]
pub struct FileAnalysis {
    /// Path to analyzed file
    pub path: String,
    /// Detected format
    pub format: FileFormat,
    /// Total file size
    pub total_size: u64,
    /// Schema
    pub schema: SchemaRef,
    /// Per-column analysis
    pub columns: Vec<ColumnAnalysis>,
    /// Total estimated savings
    pub total_estimated_savings: u64,
    /// Total estimated savings percentage
    pub total_estimated_savings_percent: f64,
}

/// Result of an upgrade operation
#[derive(Debug, Clone)]
pub struct UpgradeReport {
    /// Input file path
    pub input_path: String,
    /// Output file path
    pub output_path: String,
    /// Input file size
    pub input_size: u64,
    /// Output file size
    pub output_size: u64,
    /// Bytes saved
    pub bytes_saved: i64,
    /// Savings percentage (negative if file grew)
    pub savings_percent: f64,
    /// Per-column upgrade details
    pub column_upgrades: Vec<ColumnUpgrade>,
    /// Number of rows processed
    pub rows_processed: usize,
    /// Duration of upgrade
    pub duration_ms: u64,
}

/// Details of a single column upgrade
#[derive(Debug, Clone)]
pub struct ColumnUpgrade {
    /// Column name
    pub name: String,
    /// Original encoding
    pub original_encoding: String,
    /// New encoding
    pub new_encoding: String,
    /// Original size
    pub original_size: u64,
    /// New size
    pub new_size: u64,
    /// Savings percentage
    pub savings_percent: f64,
}

/// Upgrader for progressive file optimization
pub struct Upgrader {
    /// Writer options for output
    writer_options: ParquetWriterOptions,
}

impl Default for Upgrader {
    fn default() -> Self {
        Self::new()
    }
}

impl Upgrader {
    /// Create a new upgrader
    pub fn new() -> Self {
        Self {
            writer_options: ParquetWriterOptions::default(),
        }
    }

    /// Create with custom writer options
    pub fn with_writer_options(mut self, options: ParquetWriterOptions) -> Self {
        self.writer_options = options;
        self
    }

    /// Analyze a file for potential optimizations
    pub async fn analyze<P: AsRef<Path>>(&self, path: P) -> Result<FileAnalysis> {
        let path = path.as_ref();
        let path_str = path.display().to_string();

        // Get file size
        let total_size = std::fs::metadata(path)?.len();

        // Detect format and read schema
        let detector = FormatDetector::new();
        let format = detector.detect_file(path).await?;
        let reader = UnifiedReader::open(path).await?;
        let schema = reader.schema();

        // Analyze each column
        let mut columns = Vec::new();
        let mut total_estimated_savings: u64 = 0;

        // Estimate size per column (rough approximation)
        let num_columns = schema.fields().len();
        let avg_column_size = total_size / num_columns as u64;

        for field in schema.fields() {
            let analysis = self.analyze_column(field.name(), field.data_type(), avg_column_size);
            if analysis.upgrade_recommended {
                total_estimated_savings += analysis.current_size - analysis.estimated_new_size;
            }
            columns.push(analysis);
        }

        let total_estimated_savings_percent = if total_size > 0 {
            (total_estimated_savings as f64 / total_size as f64) * 100.0
        } else {
            0.0
        };

        Ok(FileAnalysis {
            path: path_str,
            format,
            total_size,
            schema,
            columns,
            total_estimated_savings,
            total_estimated_savings_percent,
        })
    }

    /// Deep analysis that reads actual data to compute statistics
    /// This provides more accurate encoding recommendations than the schema-only analysis
    pub async fn analyze_deep<P: AsRef<Path>>(&self, path: P) -> Result<FileAnalysis> {
        let path = path.as_ref();
        let path_str = path.display().to_string();

        // Get file size
        let total_size = std::fs::metadata(path)?.len();

        // Detect format and read data
        let detector = FormatDetector::new();
        let format = detector.detect_file(path).await?;
        let reader = UnifiedReader::open(path).await?;
        let schema = reader.schema();
        let batches = reader.read_all().await?;

        if batches.is_empty() {
            return self.analyze(path).await; // Fall back to schema-only analysis
        }

        // Use encoding selector to analyze actual data
        let encoding_selector = EncodingSelector::new();

        // Analyze each column with actual data
        let mut columns = Vec::new();
        let mut total_estimated_savings: u64 = 0;
        let num_columns = schema.fields().len();
        let avg_column_size = total_size / num_columns as u64;

        for (col_idx, field) in schema.fields().iter().enumerate() {
            // Get the column data from all batches
            let mut all_stats: Option<EncodingColumnStats> = None;

            for batch in &batches {
                let col = batch.column(col_idx);
                let batch_stats = encoding_selector.analyze_column(col);

                // Merge stats across batches (simplified - just use first batch for now)
                if all_stats.is_none() {
                    all_stats = Some(batch_stats);
                }
            }

            let stats = all_stats.unwrap_or_default();
            let recommendation = encoding_selector.recommend_encoding(field.data_type(), &stats);

            let savings_percent = (1.0 - recommendation.estimated_ratio) * 100.0;
            let estimated_new_size =
                (avg_column_size as f64 * recommendation.estimated_ratio) as u64;

            let analysis = ColumnAnalysis {
                name: field.name().clone(),
                data_type: field.data_type().clone(),
                current_encoding: "PLAIN".to_string(),
                recommended_encoding: format!("{:?}", recommendation.encoding),
                current_size: avg_column_size,
                estimated_new_size,
                estimated_savings_percent: savings_percent,
                upgrade_recommended: savings_percent >= 5.0,
                reason: recommendation.reason,
            };

            if analysis.upgrade_recommended {
                total_estimated_savings += avg_column_size - estimated_new_size;
            }
            columns.push(analysis);
        }

        let total_estimated_savings_percent = if total_size > 0 {
            (total_estimated_savings as f64 / total_size as f64) * 100.0
        } else {
            0.0
        };

        Ok(FileAnalysis {
            path: path_str,
            format,
            total_size,
            schema,
            columns,
            total_estimated_savings,
            total_estimated_savings_percent,
        })
    }

    /// Analyze a single column
    fn analyze_column(
        &self,
        name: &str,
        data_type: &DataType,
        estimated_size: u64,
    ) -> ColumnAnalysis {
        let (recommended, reason, savings) = self.recommend_encoding(data_type);

        let estimated_new_size = if savings > 0.0 {
            (estimated_size as f64 * (1.0 - savings / 100.0)) as u64
        } else {
            estimated_size
        };

        ColumnAnalysis {
            name: name.to_string(),
            data_type: data_type.clone(),
            current_encoding: "PLAIN".to_string(), // Assume PLAIN as baseline
            recommended_encoding: recommended.clone(),
            current_size: estimated_size,
            estimated_new_size,
            estimated_savings_percent: savings,
            upgrade_recommended: savings >= 5.0,
            reason,
        }
    }

    /// Recommend encoding based on data type
    fn recommend_encoding(&self, data_type: &DataType) -> (String, String, f64) {
        match data_type {
            // Integer types benefit from delta encoding
            DataType::Int8
            | DataType::Int16
            | DataType::Int32
            | DataType::Int64
            | DataType::UInt8
            | DataType::UInt16
            | DataType::UInt32
            | DataType::UInt64 => {
                (
                    "DELTA_BINARY_PACKED".to_string(),
                    "Sequential/sorted integers compress well with delta encoding".to_string(),
                    30.0, // Estimated 30% savings
                )
            }
            // Timestamps also benefit from delta
            DataType::Timestamp(_, _) | DataType::Date32 | DataType::Date64 => (
                "DELTA_BINARY_PACKED".to_string(),
                "Timestamps are often sequential, delta encoding is optimal".to_string(),
                40.0,
            ),
            // Floats benefit from byte stream split
            DataType::Float32 | DataType::Float64 => (
                "BYTE_STREAM_SPLIT".to_string(),
                "Floats with repeated patterns compress better with byte stream split".to_string(),
                15.0,
            ),
            // Strings benefit from dictionary + optional FSST
            DataType::Utf8 | DataType::LargeUtf8 => {
                (
                    "DICTIONARY + RLE".to_string(),
                    "Strings with low cardinality benefit from dictionary encoding".to_string(),
                    50.0, // Can be very significant for low-cardinality strings
                )
            }
            // Binary data - keep as is
            DataType::Binary | DataType::LargeBinary | DataType::FixedSizeBinary(_) => (
                "PLAIN".to_string(),
                "Binary data is typically already optimized".to_string(),
                0.0,
            ),
            // Boolean - RLE is typically default
            DataType::Boolean => (
                "RLE".to_string(),
                "Booleans use RLE by default".to_string(),
                0.0,
            ),
            // Lists and structs - handle recursively in future
            _ => (
                "PLAIN".to_string(),
                "Complex type - manual analysis recommended".to_string(),
                0.0,
            ),
        }
    }

    /// Upgrade a file with the given options
    pub async fn upgrade_file<P: AsRef<Path>>(
        &self,
        input: P,
        output: P,
        options: UpgradeOptions,
    ) -> Result<UpgradeReport> {
        let input_path = input.as_ref();
        let output_path = output.as_ref();
        let start = std::time::Instant::now();

        // Get input size
        let input_size = std::fs::metadata(input_path)?.len();

        // Read all data
        let reader = UnifiedReader::open(input_path).await?;
        let schema = reader.schema();
        let batches = reader.read_all().await?;

        if batches.is_empty() {
            return Err(Error::invalid_file("No data in input file"));
        }

        let rows_processed: usize = batches.iter().map(|b| b.num_rows()).sum();

        // For now, we just re-write with better options
        // In a full implementation, we'd apply per-column encoding selection
        let writer_options = self.get_optimized_writer_options(&schema, &options);
        let writer = ParquetWriter::with_options(writer_options);
        let output_bytes = writer.write_batches(&batches)?;

        // Write output
        if !options.dry_run {
            std::fs::write(output_path, &output_bytes)?;
        }

        let output_size = output_bytes.len() as u64;
        let bytes_saved = input_size as i64 - output_size as i64;
        let savings_percent = if input_size > 0 {
            (bytes_saved as f64 / input_size as f64) * 100.0
        } else {
            0.0
        };

        // Build column upgrade details
        let column_upgrades = schema
            .fields()
            .iter()
            .map(|f| {
                ColumnUpgrade {
                    name: f.name().clone(),
                    original_encoding: "PLAIN".to_string(),
                    new_encoding: "V2".to_string(),
                    original_size: 0, // Would need per-column tracking
                    new_size: 0,
                    savings_percent: 0.0,
                }
            })
            .collect();

        Ok(UpgradeReport {
            input_path: input_path.display().to_string(),
            output_path: output_path.display().to_string(),
            input_size,
            output_size,
            bytes_saved,
            savings_percent,
            column_upgrades,
            rows_processed,
            duration_ms: start.elapsed().as_millis() as u64,
        })
    }

    /// Get optimized writer options based on analysis
    fn get_optimized_writer_options(
        &self,
        _schema: &SchemaRef,
        options: &UpgradeOptions,
    ) -> ParquetWriterOptions {
        match options.target_encoding {
            TargetEncoding::Auto | TargetEncoding::ParquetV2 => {
                // Use high compression with Zstd
                ParquetWriterOptions::high_compression()
            }
            TargetEncoding::DictionaryFSST => {
                // Enable dictionary encoding with high compression
                ParquetWriterOptions::high_compression()
            }
            TargetEncoding::Original => {
                // Keep compatible settings
                ParquetWriterOptions::max_compatibility()
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Float64Array, Int64Array, StringArray};
    use arrow::datatypes::{Field, Schema};
    use arrow::record_batch::RecordBatch;
    use parquet::arrow::ArrowWriter;
    use std::sync::Arc;
    use tempfile::NamedTempFile;

    fn create_test_file() -> NamedTempFile {
        let file = NamedTempFile::new().unwrap();

        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int64, false),
            Field::new("name", DataType::Utf8, true),
            Field::new("score", DataType::Float64, true),
        ]));

        // Create data with patterns that benefit from encoding
        let ids: Vec<i64> = (0..10000).collect(); // Sequential - good for delta
        let names: Vec<Option<&str>> = (0..10000)
            .map(|i| Some(if i % 10 == 0 { "Alice" } else { "Bob" }))
            .collect(); // Low cardinality - good for dictionary
        let scores: Vec<Option<f64>> = (0..10000).map(|i| Some((i as f64) * 0.1)).collect();

        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int64Array::from(ids)),
                Arc::new(StringArray::from(names)),
                Arc::new(Float64Array::from(scores)),
            ],
        )
        .unwrap();

        let file_writer = std::fs::File::create(file.path()).unwrap();
        let mut writer = ArrowWriter::try_new(file_writer, schema, None).unwrap();
        writer.write(&batch).unwrap();
        writer.close().unwrap();

        file
    }

    #[tokio::test]
    async fn test_analyze_file() {
        let file = create_test_file();
        let upgrader = Upgrader::new();

        let analysis = upgrader.analyze(file.path()).await.unwrap();

        assert_eq!(analysis.columns.len(), 3);
        assert!(analysis.total_estimated_savings_percent > 0.0);

        // Check column-specific recommendations
        let id_col = analysis.columns.iter().find(|c| c.name == "id").unwrap();
        assert!(id_col.recommended_encoding.contains("DELTA"));

        let name_col = analysis.columns.iter().find(|c| c.name == "name").unwrap();
        assert!(name_col.recommended_encoding.contains("DICTIONARY"));
    }

    #[tokio::test]
    async fn test_upgrade_file() {
        let input_file = create_test_file();
        let output_file = NamedTempFile::new().unwrap();

        let upgrader = Upgrader::new();
        let options = UpgradeOptions::new().with_encoding(TargetEncoding::ParquetV2);

        let report = upgrader
            .upgrade_file(input_file.path(), output_file.path(), options)
            .await
            .unwrap();

        assert_eq!(report.rows_processed, 10000);
        assert!(report.output_size > 0);

        // Verify output file is valid
        let reader = UnifiedReader::open(output_file.path()).await.unwrap();
        let batches = reader.read_all().await.unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 10000);
    }

    #[tokio::test]
    async fn test_dry_run() {
        let input_file = create_test_file();
        let output_path = "/tmp/nonexistent_output.parquet";

        let upgrader = Upgrader::new();
        let options = UpgradeOptions::new().dry_run();

        let report = upgrader
            .upgrade_file(input_file.path(), Path::new(output_path), options)
            .await
            .unwrap();

        assert_eq!(report.rows_processed, 10000);
        // Output file should not exist in dry-run mode
        assert!(!Path::new(output_path).exists());
    }

    #[test]
    fn test_encoding_recommendations() {
        let upgrader = Upgrader::new();

        // Test integer recommendation
        let (enc, _, savings) = upgrader.recommend_encoding(&DataType::Int64);
        assert!(enc.contains("DELTA"));
        assert!(savings > 0.0);

        // Test string recommendation
        let (enc, _, savings) = upgrader.recommend_encoding(&DataType::Utf8);
        assert!(enc.contains("DICTIONARY"));
        assert!(savings > 0.0);

        // Test float recommendation
        let (enc, _, savings) = upgrader.recommend_encoding(&DataType::Float64);
        assert!(enc.contains("BYTE_STREAM_SPLIT"));
        assert!(savings > 0.0);
    }

    #[tokio::test]
    async fn test_analyze_deep() {
        let file = create_test_file();
        let upgrader = Upgrader::new();

        // Test deep analysis
        let analysis = upgrader.analyze_deep(file.path()).await.unwrap();

        assert_eq!(analysis.columns.len(), 3);

        // Deep analysis should detect monotonicity in the id column
        let id_col = analysis.columns.iter().find(|c| c.name == "id").unwrap();
        assert!(id_col.recommended_encoding.contains("Delta"));

        // Deep analysis should detect low cardinality in the name column
        let name_col = analysis.columns.iter().find(|c| c.name == "name").unwrap();
        assert!(
            name_col.recommended_encoding.contains("Dictionary")
                || name_col.recommended_encoding.contains("Rle")
        );
    }
}
