// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Format-specific readers that output Arrow RecordBatches
//!
//! Each reader wraps a format-specific implementation and provides
//! a common interface for reading data as Arrow.
//!
//! # Architecture for Extensibility
//!
//! The [`FormatReader`] trait is the primary extension point for adding new
//! format readers. Enterprise implementations (e.g., GPU-accelerated readers)
//! can implement this trait to integrate seamlessly.
//!
//! The [`ReaderHooks`] trait provides observability extension points for
//! metrics, tracing, and caching in enterprise deployments.
//!
//! # Example: Custom Reader Implementation
//!
//! ```rust,ignore
//! use rosetta::readers::FormatReader;
//!
//! struct GpuParquetReader { /* ... */ }
//!
//! #[async_trait]
//! impl FormatReader for GpuParquetReader {
//!     // GPU-accelerated implementation
//! }
//! ```

mod parquet_reader;
mod unified;

#[cfg(feature = "vortex-reader")]
mod vortex_reader;

#[cfg(feature = "lance-reader")]
mod lance_reader;

#[cfg(feature = "wasm-runtime")]
mod f3_reader;

pub use parquet_reader::ParquetReader;
pub use unified::UnifiedReader;

#[cfg(feature = "vortex-reader")]
pub use vortex_reader::VortexReader;

#[cfg(feature = "vortex-reader")]
pub use vortex_reader::{vortex_dtype_to_arrow_schema, vortex_dtype_to_arrow_type};

#[cfg(feature = "lance-reader")]
pub use lance_reader::LanceReader;

#[cfg(feature = "wasm-runtime")]
pub use f3_reader::F3Reader;

use crate::expr::{Expr, FilterPushdownResult};
use crate::partition::Partition;
use crate::stats::Statistics;
use crate::Result;
use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;
use async_trait::async_trait;
use std::sync::Arc;
use std::time::Duration;

/// Common trait for all format readers.
///
/// This is the primary extension point for adding new format readers.
/// Implementations can be:
/// - CPU-based (default, included in OSS)
/// - GPU-accelerated (enterprise extension point)
/// - Distributed (future extension)
///
/// # Thread Safety
///
/// All implementations must be `Send + Sync` to support concurrent access
/// from multiple threads/tasks.
///
/// # Full Vision Implementation
///
/// This trait implements the complete FormatReader vision:
/// - Schema access
/// - Statistics exposure for query optimization
/// - Filter pushdown for predicate evaluation
/// - Projection pushdown for column pruning
/// - Partition support for distributed execution
#[async_trait]
pub trait FormatReader: Send + Sync {
    /// Get the Arrow schema of the data
    fn schema(&self) -> SchemaRef;

    /// Get statistics for query optimization
    ///
    /// Statistics include row counts, byte sizes, and per-column min/max values.
    /// Query optimizers use this for cost-based optimization and partition pruning.
    fn statistics(&self) -> Option<Statistics> {
        None
    }

    /// Push a filter predicate down to the native reader
    ///
    /// Returns a `FilterPushdownResult` indicating whether the filter was:
    /// - Fully pushed (native reader will apply it)
    /// - Partially pushed (some conditions applied natively, rest post-filter)
    /// - Not pushed (must be applied after reading)
    ///
    /// Default implementation returns NotPushed (filter must be applied post-read).
    fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult> {
        Ok(FilterPushdownResult::NotPushed(Box::new(filter.clone())))
    }

    /// Push column projection down to the native reader
    ///
    /// This tells the reader to only read the specified columns,
    /// reducing I/O and memory usage.
    fn push_projection(&mut self, _columns: &[String]) -> Result<()> {
        Ok(())
    }

    /// Get partition information for distributed execution
    ///
    /// Returns a list of partitions that can be read independently.
    /// Distributed engines (Spark, Trino) use this to parallelize reads.
    fn partitions(&self) -> Result<Vec<Partition>>;

    /// Get the number of row groups (if applicable)
    fn num_row_groups(&self) -> usize;

    /// Read all data as RecordBatches
    async fn read_all(&self) -> Result<Vec<RecordBatch>>;

    /// Read a specific row group
    async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>>;

    /// Read with projection (specific columns)
    async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>>;

    /// Read a specific partition
    ///
    /// Default implementation reads the partition's row groups.
    async fn read_partition(&self, partition: &Partition) -> Result<Vec<RecordBatch>> {
        if let Some(ref row_groups) = partition.row_groups {
            let mut batches = Vec::new();
            for &rg in row_groups {
                let rg_batches = self.read_row_group(rg).await?;
                batches.extend(rg_batches);
            }
            Ok(batches)
        } else {
            self.read_all().await
        }
    }

    /// Returns the reader's acceleration type (CPU, GPU, etc.)
    ///
    /// Default implementation returns CPU. GPU readers should override this.
    fn acceleration(&self) -> ReaderAcceleration {
        ReaderAcceleration::Cpu
    }
}

/// Indicates the acceleration type of a reader.
///
/// Used for telemetry and to select appropriate readers when multiple
/// implementations are available.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReaderAcceleration {
    /// Standard CPU-based reader (default)
    Cpu,
    /// GPU-accelerated reader (enterprise)
    #[cfg(feature = "enterprise")]
    Gpu,
    /// WASM-based fallback reader
    Wasm,
}

/// Hooks for observability and enterprise integrations.
///
/// This trait provides extension points for:
/// - Metrics collection (Prometheus, DataDog, etc.)
/// - Distributed tracing (OpenTelemetry, Jaeger, etc.)
/// - Caching layer integration (Redis, S3 cache, etc.)
///
/// The default implementation is a no-op. Enterprise deployments can
/// provide custom implementations for production observability.
///
/// # Example
///
/// ```rust,ignore
/// use rosetta::readers::ReaderHooks;
///
/// struct PrometheusHooks {
///     read_duration: Histogram,
///     bytes_read: Counter,
/// }
///
/// impl ReaderHooks for PrometheusHooks {
///     fn on_read_start(&self, path: &str, format: &str) {
///         // Start timing
///     }
///
///     fn on_read_complete(&self, path: &str, duration: Duration, bytes: usize, rows: usize) {
///         self.read_duration.observe(duration.as_secs_f64());
///         self.bytes_read.inc_by(bytes as f64);
///     }
/// }
/// ```
pub trait ReaderHooks: Send + Sync {
    /// Called when a read operation starts.
    fn on_read_start(&self, _path: &str, _format: &str) {}

    /// Called when a read operation completes successfully.
    fn on_read_complete(&self, _path: &str, _duration: Duration, _bytes: usize, _rows: usize) {}

    /// Called when a read operation fails.
    fn on_read_error(&self, _path: &str, _error: &str) {}

    /// Called to check if a cached result exists.
    /// Returns cached batches if available, None otherwise.
    fn check_cache(&self, _path: &str, _columns: Option<&[String]>) -> Option<Vec<RecordBatch>> {
        None
    }

    /// Called to store a result in cache.
    fn store_cache(&self, _path: &str, _columns: Option<&[String]>, _batches: &[RecordBatch]) {}
}

/// No-op implementation of ReaderHooks for OSS builds.
#[derive(Debug, Clone, Copy, Default)]
pub struct NoOpHooks;

impl ReaderHooks for NoOpHooks {}

/// Global hooks instance. Enterprise deployments can replace this.
static READER_HOOKS: std::sync::OnceLock<Arc<dyn ReaderHooks>> = std::sync::OnceLock::new();

/// Get the current reader hooks instance.
pub fn get_reader_hooks() -> Arc<dyn ReaderHooks> {
    READER_HOOKS
        .get()
        .cloned()
        .unwrap_or_else(|| Arc::new(NoOpHooks))
}

/// Set custom reader hooks (for enterprise integrations).
///
/// This must be called before any read operations.
/// Returns Err if hooks have already been set.
pub fn set_reader_hooks(hooks: Arc<dyn ReaderHooks>) -> Result<()> {
    READER_HOOKS
        .set(hooks)
        .map_err(|_| crate::Error::config("Reader hooks already initialized"))
}
