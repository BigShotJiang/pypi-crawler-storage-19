// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Parquet format reader
//!
//! Provides passthrough reading of Parquet files using the `parquet` crate,
//! outputting Arrow RecordBatches.
//!
//! ## Performance Optimizations
//!
//! This reader is optimized for minimal overhead:
//! - Synchronous API available (`read_all_sync`) to avoid async runtime overhead
//! - Builder cached to avoid double construction
//! - `Bytes` uses Arc internally, so clones are cheap (ref count only)

use crate::expr::{Expr, FilterPushdownResult, Operator};
use crate::partition::{Partition, PartitionBuilder};
use crate::stats::{ColumnStatistics, ScalarValue, Statistics};
use crate::{Error, FileFormat, Result};
use arrow::array::{
    Array, ArrayRef, BooleanArray, Float32Array, Float64Array, Int32Array, Int64Array, StringArray,
};
use arrow::compute::{and, is_not_null, is_null, not, or};
use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;
use arrow_ord::cmp::{eq, gt, gt_eq, lt, lt_eq, neq};
use bytes::Bytes;
use parquet::arrow::arrow_reader::{ArrowPredicate, ParquetRecordBatchReaderBuilder, RowFilter};
use parquet::arrow::ProjectionMask;
use parquet::file::metadata::ParquetMetaData;
use parquet::file::statistics::Statistics as ParquetStatistics;
use std::path::Path;
use std::sync::Arc;
use tokio::fs::File;
use tokio::io::AsyncReadExt;
use tracing::debug;

/// An ArrowPredicate implementation that evaluates our Expr against Arrow arrays.
///
/// This enables row-level filter pushdown during Parquet reading.
struct ExprPredicate {
    /// The filter expression to evaluate
    filter: Expr,
    /// Projection mask for columns needed by the filter
    projection: ProjectionMask,
}

impl ExprPredicate {
    /// Create a new predicate from an expression
    fn new(
        filter: Expr,
        schema: &SchemaRef,
        parquet_schema: &parquet::schema::types::SchemaDescriptor,
    ) -> Self {
        // Get column names from the expression
        let column_names = filter.columns();

        // Find column indices
        let indices: Vec<usize> = column_names
            .iter()
            .filter_map(|name| schema.index_of(name).ok())
            .collect();

        let projection = ProjectionMask::roots(parquet_schema, indices);

        Self { filter, projection }
    }

    /// Evaluate an expression against a RecordBatch, returning a BooleanArray mask
    fn evaluate_expr(
        &self,
        batch: &RecordBatch,
        expr: &Expr,
    ) -> arrow::error::Result<BooleanArray> {
        match expr {
            Expr::Column(name) => {
                // Column alone as boolean - get the column and interpret as boolean
                let col_idx = batch
                    .schema()
                    .index_of(name)
                    .map_err(|e| arrow::error::ArrowError::ComputeError(e.to_string()))?;
                let array = batch.column(col_idx);

                // If it's already a boolean, return it
                if let Some(bool_arr) = array.as_any().downcast_ref::<BooleanArray>() {
                    Ok(bool_arr.clone())
                } else {
                    // Non-boolean column as predicate means "is not null"
                    is_not_null(array)
                }
            }

            Expr::Literal(scalar) => {
                // A literal boolean value
                let value = match scalar {
                    ScalarValue::Boolean(b) => *b,
                    _ => true, // Non-null literal is truthy
                };
                Ok(BooleanArray::from(vec![value; batch.num_rows()]))
            }

            Expr::BinaryExpr { left, op, right } => {
                self.evaluate_binary_expr(batch, left, op, right)
            }

            Expr::Not(inner) => {
                let inner_result = self.evaluate_expr(batch, inner)?;
                not(&inner_result)
            }

            Expr::IsNull(inner) => {
                let array = self.evaluate_to_array(batch, inner)?;
                is_null(&array)
            }

            Expr::IsNotNull(inner) => {
                let array = self.evaluate_to_array(batch, inner)?;
                is_not_null(&array)
            }

            Expr::InList {
                expr,
                list,
                negated,
            } => {
                // Evaluate expr IN (list) as multiple OR conditions
                let array = self.evaluate_to_array(batch, expr)?;
                let mut result: Option<BooleanArray> = None;

                for item in list {
                    let item_array = self.evaluate_to_array(batch, item)?;
                    let eq_result = eq(&array, &item_array)?;

                    result = Some(match result {
                        Some(prev) => or(&prev, &eq_result)?,
                        None => eq_result,
                    });
                }

                let result =
                    result.unwrap_or_else(|| BooleanArray::from(vec![false; batch.num_rows()]));

                if *negated {
                    not(&result)
                } else {
                    Ok(result)
                }
            }

            Expr::Between {
                expr,
                low,
                high,
                negated,
            } => {
                // expr BETWEEN low AND high = expr >= low AND expr <= high
                let array = self.evaluate_to_array(batch, expr)?;
                let low_array = self.evaluate_to_array(batch, low)?;
                let high_array = self.evaluate_to_array(batch, high)?;

                let ge_low = gt_eq(&array, &low_array)?;
                let le_high = lt_eq(&array, &high_array)?;
                let result = and(&ge_low, &le_high)?;

                if *negated {
                    not(&result)
                } else {
                    Ok(result)
                }
            }

            Expr::Like {
                expr,
                pattern,
                negated,
                ..
            } => {
                // Basic LIKE support using string comparison
                // For now, we'll do a simple contains check for patterns with %
                let array = self.evaluate_to_array(batch, expr)?;

                if let Some(str_arr) = array.as_any().downcast_ref::<StringArray>() {
                    let mut results = Vec::with_capacity(str_arr.len());
                    let search_pattern = pattern.trim_matches('%');

                    for i in 0..str_arr.len() {
                        if str_arr.is_null(i) {
                            results.push(None);
                        } else {
                            let value = str_arr.value(i);
                            let matches = if pattern.starts_with('%') && pattern.ends_with('%') {
                                value.contains(search_pattern)
                            } else if pattern.starts_with('%') {
                                value.ends_with(search_pattern)
                            } else if pattern.ends_with('%') {
                                value.starts_with(search_pattern)
                            } else {
                                value == search_pattern
                            };
                            results.push(Some(if *negated { !matches } else { matches }));
                        }
                    }
                    Ok(BooleanArray::from(results))
                } else {
                    // Non-string type, return all false
                    Ok(BooleanArray::from(vec![false; batch.num_rows()]))
                }
            }

            Expr::Cast { expr, .. } => {
                // For filter pushdown, we pass through the inner expression
                self.evaluate_expr(batch, expr)
            }

            Expr::Alias { expr, .. } => {
                // Aliases are transparent for evaluation
                self.evaluate_expr(batch, expr)
            }
        }
    }

    /// Evaluate a binary expression
    fn evaluate_binary_expr(
        &self,
        batch: &RecordBatch,
        left: &Expr,
        op: &Operator,
        right: &Expr,
    ) -> arrow::error::Result<BooleanArray> {
        match op {
            // Logical operators operate on boolean results
            Operator::And => {
                let left_result = self.evaluate_expr(batch, left)?;
                let right_result = self.evaluate_expr(batch, right)?;
                and(&left_result, &right_result)
            }
            Operator::Or => {
                let left_result = self.evaluate_expr(batch, left)?;
                let right_result = self.evaluate_expr(batch, right)?;
                or(&left_result, &right_result)
            }

            // Comparison operators operate on arrays
            _ => {
                let left_array = self.evaluate_to_array(batch, left)?;
                let right_array = self.evaluate_to_array(batch, right)?;

                match op {
                    Operator::Eq => eq(&left_array, &right_array),
                    Operator::NotEq => neq(&left_array, &right_array),
                    Operator::Lt => lt(&left_array, &right_array),
                    Operator::LtEq => lt_eq(&left_array, &right_array),
                    Operator::Gt => gt(&left_array, &right_array),
                    Operator::GtEq => gt_eq(&left_array, &right_array),
                    _ => {
                        // Arithmetic and other operators not supported for filter predicates
                        Err(arrow::error::ArrowError::ComputeError(format!(
                            "Unsupported operator for filter: {:?}",
                            op
                        )))
                    }
                }
            }
        }
    }

    /// Evaluate an expression to an array (not necessarily boolean)
    fn evaluate_to_array(
        &self,
        batch: &RecordBatch,
        expr: &Expr,
    ) -> arrow::error::Result<ArrayRef> {
        match expr {
            Expr::Column(name) => {
                let col_idx = batch
                    .schema()
                    .index_of(name)
                    .map_err(|e| arrow::error::ArrowError::ComputeError(e.to_string()))?;
                Ok(batch.column(col_idx).clone())
            }

            Expr::Literal(scalar) => self.scalar_to_array(scalar, batch.num_rows()),

            Expr::Alias { expr, .. } => self.evaluate_to_array(batch, expr),

            Expr::Cast { expr, .. } => {
                // For now, just evaluate the inner expression
                self.evaluate_to_array(batch, expr)
            }

            _ => {
                // For complex expressions, evaluate as boolean
                let bool_result = self.evaluate_expr(batch, expr)?;
                Ok(Arc::new(bool_result))
            }
        }
    }

    /// Convert a ScalarValue to an array of the given length
    fn scalar_to_array(&self, scalar: &ScalarValue, len: usize) -> arrow::error::Result<ArrayRef> {
        use arrow::array::{
            Int16Array, Int8Array, UInt16Array, UInt32Array, UInt64Array, UInt8Array,
        };

        Ok(match scalar {
            ScalarValue::Null => Arc::new(BooleanArray::from(vec![None::<bool>; len])),
            ScalarValue::Boolean(v) => Arc::new(BooleanArray::from(vec![*v; len])),
            ScalarValue::Int8(v) => Arc::new(Int8Array::from(vec![*v; len])),
            ScalarValue::Int16(v) => Arc::new(Int16Array::from(vec![*v; len])),
            ScalarValue::Int32(v) => Arc::new(Int32Array::from(vec![*v; len])),
            ScalarValue::Int64(v) => Arc::new(Int64Array::from(vec![*v; len])),
            ScalarValue::UInt8(v) => Arc::new(UInt8Array::from(vec![*v; len])),
            ScalarValue::UInt16(v) => Arc::new(UInt16Array::from(vec![*v; len])),
            ScalarValue::UInt32(v) => Arc::new(UInt32Array::from(vec![*v; len])),
            ScalarValue::UInt64(v) => Arc::new(UInt64Array::from(vec![*v; len])),
            ScalarValue::Float32(v) => Arc::new(Float32Array::from(vec![*v; len])),
            ScalarValue::Float64(v) => Arc::new(Float64Array::from(vec![*v; len])),
            ScalarValue::Utf8(v) => Arc::new(StringArray::from(vec![v.as_str(); len])),
            ScalarValue::LargeUtf8(v) => Arc::new(StringArray::from(vec![v.as_str(); len])),
            _ => {
                // For other types, create a null array
                Arc::new(BooleanArray::from(vec![None::<bool>; len]))
            }
        })
    }
}

impl ArrowPredicate for ExprPredicate {
    fn projection(&self) -> &ProjectionMask {
        &self.projection
    }

    fn evaluate(&mut self, batch: RecordBatch) -> arrow::error::Result<BooleanArray> {
        self.evaluate_expr(&batch, &self.filter)
    }
}

/// Reader for Parquet files (both v1 and v2)
///
/// Optimized for minimal overhead on Parquet passthrough reads.
pub struct ParquetReader {
    /// The underlying file data (Bytes uses Arc, so clone is O(1))
    data: Bytes,
    /// Parquet metadata
    metadata: Arc<ParquetMetaData>,
    /// Arrow schema (public for unified reader access)
    pub schema: SchemaRef,
    /// Detected Parquet version
    version: FileFormat,
    /// Batch size for reading
    batch_size: usize,
    /// File path or URL (for partition location)
    location: String,
    /// Filter to apply during reading via ArrowPredicate.
    /// When set, the filter is pushed down to the Parquet reader for row-level filtering.
    filter: Option<Expr>,
}

impl ParquetReader {
    /// Default batch size (8192 rows)
    const DEFAULT_BATCH_SIZE: usize = 8192;

    /// Open a Parquet file from a local path (async)
    pub async fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        let path = path.as_ref();
        let location = path.display().to_string();
        let mut file = File::open(path).await?;

        let mut data = Vec::new();
        file.read_to_end(&mut data).await?;
        let data = Bytes::from(data);

        Self::from_bytes_with_location(data, location).await
    }

    /// Open a Parquet file synchronously - avoids async runtime overhead
    ///
    /// This is the fastest path for local file reads.
    pub fn open_sync<P: AsRef<Path>>(path: P) -> Result<Self> {
        let location = path.as_ref().display().to_string();
        let data = std::fs::read(path.as_ref())?;
        Self::from_bytes_sync_with_location(Bytes::from(data), location)
    }

    /// Create a reader from raw bytes (async wrapper)
    pub async fn from_bytes(data: Bytes) -> Result<Self> {
        Self::from_bytes_sync_with_location(data, "memory".to_string())
    }

    /// Create a reader from raw bytes with location (async wrapper)
    pub async fn from_bytes_with_location(data: Bytes, location: String) -> Result<Self> {
        Self::from_bytes_sync_with_location(data, location)
    }

    /// Create a reader from raw bytes synchronously
    ///
    /// This is the primary constructor - `from_bytes` just wraps this.
    /// Using this directly avoids async overhead.
    pub fn from_bytes_sync(data: Bytes) -> Result<Self> {
        Self::from_bytes_sync_with_location(data, "memory".to_string())
    }

    /// Create a reader from raw bytes with location synchronously
    pub fn from_bytes_sync_with_location(data: Bytes, location: String) -> Result<Self> {
        // Build the reader to get metadata and schema
        let builder = ParquetRecordBatchReaderBuilder::try_new(data.clone())?;
        let metadata = builder.metadata().clone();
        let schema = builder.schema().clone();

        // Detect version from metadata
        let version = Self::detect_version(&metadata);

        Ok(Self {
            data,
            metadata,
            schema,
            version,
            batch_size: Self::DEFAULT_BATCH_SIZE,
            location,
            filter: None,
        })
    }

    /// Push a filter down to the reader for predicate pushdown.
    ///
    /// The filter will be translated to an ArrowPredicate and applied during
    /// Parquet reading via RowFilter. This enables true row-level filter pushdown,
    /// avoiding reading rows that don't match the filter.
    ///
    /// # Supported Expressions
    ///
    /// - Comparison operators: `=`, `!=`, `<`, `<=`, `>`, `>=`
    /// - Logical operators: `AND`, `OR`, `NOT`
    /// - `IS NULL`, `IS NOT NULL`
    /// - `IN` lists
    /// - `BETWEEN`
    /// - `LIKE` patterns (basic support)
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use rosetta::expr::{col, lit};
    ///
    /// let mut reader = ParquetReader::open("data.parquet").await?;
    /// let result = reader.push_filter(&col("age").gt(lit(30)));
    /// // Returns Pushed - filter is applied during reading
    /// let data = reader.read_all().await?; // Only rows where age > 30
    /// ```
    pub fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult> {
        // Validate that all columns in the filter exist in the schema
        for col_name in filter.columns() {
            if self.schema.index_of(&col_name).is_err() {
                debug!(column = %col_name, "Filter column not found in schema");
                return Ok(FilterPushdownResult::NotPushed(Box::new(filter.clone())));
            }
        }

        // Store the filter for use in read methods
        self.filter = Some(filter.clone());

        debug!(filter = ?filter, "Filter pushed to Parquet reader");
        Ok(FilterPushdownResult::Pushed)
    }

    /// Set the batch size for reading
    pub fn with_batch_size(mut self, batch_size: usize) -> Self {
        self.batch_size = batch_size;
        self
    }

    /// Get the detected Parquet version
    pub fn version(&self) -> FileFormat {
        self.version
    }

    /// Get the Parquet metadata
    pub fn metadata(&self) -> &ParquetMetaData {
        &self.metadata
    }

    /// Detect whether this is Parquet v1 or v2 based on encodings used
    fn detect_version(metadata: &ParquetMetaData) -> FileFormat {
        // Check all row groups for v2 encodings
        for rg in metadata.row_groups() {
            for col in rg.columns() {
                // Check for v2-specific encodings
                let encodings = col.encodings();
                for encoding in encodings {
                    use parquet::basic::Encoding;
                    match encoding {
                        Encoding::DELTA_BINARY_PACKED
                        | Encoding::DELTA_LENGTH_BYTE_ARRAY
                        | Encoding::DELTA_BYTE_ARRAY
                        | Encoding::BYTE_STREAM_SPLIT => {
                            debug!(?encoding, "Found v2 encoding");
                            return FileFormat::ParquetV2;
                        }
                        _ => {}
                    }
                }
            }
        }
        FileFormat::ParquetV1
    }

    /// Read all row groups (async wrapper)
    pub async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        self.read_all_sync()
    }

    /// Read all row groups synchronously - no async overhead
    ///
    /// This is the fastest path for reading all data.
    /// Note: `Bytes::clone()` is O(1) since Bytes uses Arc internally.
    ///
    /// If a filter has been pushed via `push_filter()`, it will be applied
    /// during reading using ArrowPredicate for row-level filtering.
    #[inline]
    pub fn read_all_sync(&self) -> Result<Vec<RecordBatch>> {
        let mut builder = ParquetRecordBatchReaderBuilder::try_new(self.data.clone())?
            .with_batch_size(self.batch_size);

        // Apply filter if set
        if let Some(ref filter) = self.filter {
            let predicate =
                ExprPredicate::new(filter.clone(), &self.schema, builder.parquet_schema());
            let row_filter = RowFilter::new(vec![Box::new(predicate)]);
            builder = builder.with_row_filter(row_filter);
            debug!("Applied row filter to Parquet reader");
        }

        let reader = builder.build()?;

        let batches: Vec<RecordBatch> = reader
            .into_iter()
            .collect::<std::result::Result<Vec<_>, _>>()?;

        Ok(batches)
    }

    /// Read a specific row group
    ///
    /// If a filter has been pushed via `push_filter()`, it will be applied
    /// during reading.
    pub async fn read_row_group(&self, row_group_idx: usize) -> Result<Vec<RecordBatch>> {
        if row_group_idx >= self.metadata.num_row_groups() {
            return Err(Error::invalid_file(format!(
                "Row group {} does not exist (file has {} row groups)",
                row_group_idx,
                self.metadata.num_row_groups()
            )));
        }

        let mut builder = ParquetRecordBatchReaderBuilder::try_new(self.data.clone())?
            .with_batch_size(self.batch_size)
            .with_row_groups(vec![row_group_idx]);

        // Apply filter if set
        if let Some(ref filter) = self.filter {
            let predicate =
                ExprPredicate::new(filter.clone(), &self.schema, builder.parquet_schema());
            let row_filter = RowFilter::new(vec![Box::new(predicate)]);
            builder = builder.with_row_filter(row_filter);
        }

        let reader = builder.build()?;

        let batches: Vec<RecordBatch> = reader
            .into_iter()
            .collect::<std::result::Result<Vec<_>, _>>()?;

        Ok(batches)
    }

    /// Read with column projection
    ///
    /// If a filter has been pushed via `push_filter()`, it will be applied
    /// during reading using ArrowPredicate for row-level filtering.
    pub async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        // Find column indices
        let schema = self.schema.clone();
        let indices: Vec<usize> = columns
            .iter()
            .map(|name| {
                schema
                    .index_of(name)
                    .map_err(|_| Error::column_not_found(name))
            })
            .collect::<Result<Vec<_>>>()?;

        let mut builder = ParquetRecordBatchReaderBuilder::try_new(self.data.clone())?
            .with_batch_size(self.batch_size);

        // Create projection mask
        let projection = ProjectionMask::roots(builder.parquet_schema(), indices);
        builder = builder.with_projection(projection);

        // Apply filter if set (same as read_all_sync)
        if let Some(ref filter) = self.filter {
            let predicate =
                ExprPredicate::new(filter.clone(), &self.schema, builder.parquet_schema());
            let row_filter = RowFilter::new(vec![Box::new(predicate)]);
            builder = builder.with_row_filter(row_filter);
            debug!("Applied row filter to Parquet reader with projection");
        }

        let reader = builder.build()?;

        let batches: Vec<RecordBatch> = reader
            .into_iter()
            .collect::<std::result::Result<Vec<_>, _>>()?;

        Ok(batches)
    }

    /// Get statistics from Parquet metadata for query optimization
    pub fn statistics(&self) -> Option<Statistics> {
        let mut total_rows = 0usize;
        let mut total_bytes = 0usize;
        let mut column_stats: std::collections::HashMap<String, ColumnStatistics> =
            std::collections::HashMap::new();

        // Aggregate statistics from all row groups
        for rg in self.metadata.row_groups() {
            total_rows += rg.num_rows() as usize;
            total_bytes += rg.total_byte_size() as usize;

            for (col_idx, col) in rg.columns().iter().enumerate() {
                let col_name = self.schema.field(col_idx).name().clone();

                let entry = column_stats
                    .entry(col_name)
                    .or_insert_with(|| ColumnStatistics {
                        null_count: Some(0),
                        distinct_count: None,
                        min_value: None,
                        max_value: None,
                    });

                // Add null count
                if let Some(null_count) = entry.null_count.as_mut() {
                    if let Some(stats) = col.statistics() {
                        if let Some(nc) = stats.null_count_opt() {
                            *null_count += nc as usize;
                        }

                        // Extract min/max values
                        if entry.min_value.is_none() {
                            entry.min_value = Self::convert_parquet_stats_min(stats);
                        }
                        if entry.max_value.is_none() {
                            entry.max_value = Self::convert_parquet_stats_max(stats);
                        }
                    }
                }
            }
        }

        Some(Statistics {
            num_rows: Some(total_rows),
            total_byte_size: Some(total_bytes),
            column_statistics: column_stats,
        })
    }

    /// Convert Parquet statistics min value to ScalarValue
    fn convert_parquet_stats_min(stats: &ParquetStatistics) -> Option<ScalarValue> {
        match stats {
            ParquetStatistics::Int32(s) => s.min_opt().map(|v| ScalarValue::Int32(*v)),
            ParquetStatistics::Int64(s) => s.min_opt().map(|v| ScalarValue::Int64(*v)),
            ParquetStatistics::Float(s) => s.min_opt().map(|v| ScalarValue::Float32(*v)),
            ParquetStatistics::Double(s) => s.min_opt().map(|v| ScalarValue::Float64(*v)),
            ParquetStatistics::ByteArray(s) => s.min_opt().map(|v| {
                String::from_utf8(v.data().to_vec())
                    .map(ScalarValue::Utf8)
                    .unwrap_or_else(|_| ScalarValue::Binary(v.data().to_vec()))
            }),
            ParquetStatistics::FixedLenByteArray(s) => {
                s.min_opt().map(|v| ScalarValue::Binary(v.data().to_vec()))
            }
            ParquetStatistics::Boolean(s) => s.min_opt().map(|v| ScalarValue::Boolean(*v)),
            // Int96 is deprecated (legacy Impala timestamp), return None
            ParquetStatistics::Int96(_) => None,
        }
    }

    /// Convert Parquet statistics max value to ScalarValue
    fn convert_parquet_stats_max(stats: &ParquetStatistics) -> Option<ScalarValue> {
        match stats {
            ParquetStatistics::Int32(s) => s.max_opt().map(|v| ScalarValue::Int32(*v)),
            ParquetStatistics::Int64(s) => s.max_opt().map(|v| ScalarValue::Int64(*v)),
            ParquetStatistics::Float(s) => s.max_opt().map(|v| ScalarValue::Float32(*v)),
            ParquetStatistics::Double(s) => s.max_opt().map(|v| ScalarValue::Float64(*v)),
            ParquetStatistics::ByteArray(s) => s.max_opt().map(|v| {
                String::from_utf8(v.data().to_vec())
                    .map(ScalarValue::Utf8)
                    .unwrap_or_else(|_| ScalarValue::Binary(v.data().to_vec()))
            }),
            ParquetStatistics::FixedLenByteArray(s) => {
                s.max_opt().map(|v| ScalarValue::Binary(v.data().to_vec()))
            }
            ParquetStatistics::Boolean(s) => s.max_opt().map(|v| ScalarValue::Boolean(*v)),
            // Int96 is deprecated (legacy Impala timestamp), return None
            ParquetStatistics::Int96(_) => None,
        }
    }

    /// Get partition information for distributed execution
    pub fn partitions(&self) -> Result<Vec<Partition>> {
        let mut builder = PartitionBuilder::default();

        // Get row group sizes
        let row_group_sizes: Vec<usize> = self
            .metadata
            .row_groups()
            .iter()
            .map(|rg| rg.num_rows() as usize)
            .collect();

        let row_group_byte_sizes: Vec<usize> = self
            .metadata
            .row_groups()
            .iter()
            .map(|rg| rg.total_byte_size() as usize)
            .collect();

        Ok(builder.build_for_file(
            &self.location,
            self.metadata.num_row_groups(),
            Some(&row_group_sizes),
            Some(&row_group_byte_sizes),
        ))
    }
}

#[async_trait::async_trait]
impl super::FormatReader for ParquetReader {
    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn statistics(&self) -> Option<Statistics> {
        self.statistics()
    }

    fn partitions(&self) -> Result<Vec<Partition>> {
        self.partitions()
    }

    fn num_row_groups(&self) -> usize {
        self.metadata.num_row_groups()
    }

    async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        ParquetReader::read_all(self).await
    }

    async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>> {
        ParquetReader::read_row_group(self, row_group).await
    }

    async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        ParquetReader::read_projection(self, columns).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::readers::FormatReader;
    use arrow::array::{Int32Array, StringArray};
    use arrow::datatypes::{DataType, Field, Schema};
    use parquet::arrow::ArrowWriter;
    use tempfile::NamedTempFile;

    fn create_test_parquet() -> NamedTempFile {
        let file = NamedTempFile::new().unwrap();

        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, true),
        ]));

        let ids = Int32Array::from(vec![1, 2, 3, 4, 5]);
        let names = StringArray::from(vec![
            Some("Alice"),
            Some("Bob"),
            Some("Charlie"),
            None,
            Some("Eve"),
        ]);

        let batch =
            RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

        let file_writer = std::fs::File::create(file.path()).unwrap();
        let mut writer = ArrowWriter::try_new(file_writer, schema, None).unwrap();
        writer.write(&batch).unwrap();
        writer.close().unwrap();

        file
    }

    #[tokio::test]
    async fn test_read_parquet() {
        let file = create_test_parquet();
        let reader = ParquetReader::open(file.path()).await.unwrap();

        // Use the FormatReader trait methods
        assert_eq!(reader.schema().fields().len(), 2);
        assert_eq!(reader.num_row_groups(), 1);

        let batches = FormatReader::read_all(&reader).await.unwrap();
        assert_eq!(batches.len(), 1);
        assert_eq!(batches[0].num_rows(), 5);
    }

    #[tokio::test]
    async fn test_read_projection() {
        let file = create_test_parquet();
        let reader = ParquetReader::open(file.path()).await.unwrap();

        let batches = FormatReader::read_projection(&reader, &["name".to_string()])
            .await
            .unwrap();

        assert_eq!(batches[0].num_columns(), 1);
        assert_eq!(batches[0].schema().field(0).name(), "name");
    }

    #[tokio::test]
    async fn test_version_detection() {
        let file = create_test_parquet();
        let reader = ParquetReader::open(file.path()).await.unwrap();

        // Default ArrowWriter uses v1 encodings
        assert_eq!(reader.version(), FileFormat::ParquetV1);
    }

    #[tokio::test]
    async fn test_read_specific_row_group() {
        let file = create_test_parquet();
        let reader = ParquetReader::open(file.path()).await.unwrap();

        let batches = FormatReader::read_row_group(&reader, 0).await.unwrap();
        assert!(!batches.is_empty());
        assert_eq!(batches[0].num_rows(), 5);
    }

    #[tokio::test]
    async fn test_invalid_row_group() {
        let file = create_test_parquet();
        let reader = ParquetReader::open(file.path()).await.unwrap();

        let result = FormatReader::read_row_group(&reader, 999).await;
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn test_invalid_column_projection() {
        let file = create_test_parquet();
        let reader = ParquetReader::open(file.path()).await.unwrap();

        let result = FormatReader::read_projection(&reader, &["nonexistent".to_string()]).await;
        assert!(result.is_err());
    }

    #[tokio::test]
    async fn test_filter_pushdown_gt() {
        use crate::expr::{col, lit};

        let file = create_test_parquet();
        let mut reader = ParquetReader::open(file.path()).await.unwrap();

        // Filter: id > 2 should return rows with id 3, 4, 5
        let filter = col("id").gt(lit(2i32));
        let result = reader.push_filter(&filter).unwrap();
        assert!(matches!(result, FilterPushdownResult::Pushed));

        let batches = reader.read_all().await.unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 3); // Should have 3 rows (id = 3, 4, 5)
    }

    #[tokio::test]
    async fn test_filter_pushdown_eq() {
        use crate::expr::{col, lit};

        let file = create_test_parquet();
        let mut reader = ParquetReader::open(file.path()).await.unwrap();

        // Filter: id = 3 should return only one row
        let filter = col("id").eq(lit(3i32));
        let result = reader.push_filter(&filter).unwrap();
        assert!(matches!(result, FilterPushdownResult::Pushed));

        let batches = reader.read_all().await.unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 1);
    }

    #[tokio::test]
    async fn test_filter_pushdown_and() {
        use crate::expr::{col, lit};

        let file = create_test_parquet();
        let mut reader = ParquetReader::open(file.path()).await.unwrap();

        // Filter: id >= 2 AND id <= 4 should return rows with id 2, 3, 4
        let filter = col("id").gt_eq(lit(2i32)).and(col("id").lt_eq(lit(4i32)));
        let result = reader.push_filter(&filter).unwrap();
        assert!(matches!(result, FilterPushdownResult::Pushed));

        let batches = reader.read_all().await.unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 3); // Should have 3 rows (id = 2, 3, 4)
    }

    #[tokio::test]
    async fn test_filter_pushdown_string() {
        use crate::expr::{col, lit};

        let file = create_test_parquet();
        let mut reader = ParquetReader::open(file.path()).await.unwrap();

        // Filter: name = 'Alice' should return only one row
        let filter = col("name").eq(lit("Alice"));
        let result = reader.push_filter(&filter).unwrap();
        assert!(matches!(result, FilterPushdownResult::Pushed));

        let batches = reader.read_all().await.unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 1);
    }

    #[tokio::test]
    async fn test_filter_pushdown_is_not_null() {
        use crate::expr::col;

        let file = create_test_parquet();
        let mut reader = ParquetReader::open(file.path()).await.unwrap();

        // Filter: name IS NOT NULL should return 4 rows (one is null)
        let filter = col("name").is_not_null();
        let result = reader.push_filter(&filter).unwrap();
        assert!(matches!(result, FilterPushdownResult::Pushed));

        let batches = reader.read_all().await.unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 4); // 5 rows - 1 null = 4 rows
    }

    #[tokio::test]
    async fn test_filter_pushdown_invalid_column() {
        use crate::expr::{col, lit};

        let file = create_test_parquet();
        let mut reader = ParquetReader::open(file.path()).await.unwrap();

        // Filter with non-existent column should return NotPushed
        let filter = col("nonexistent").gt(lit(2i32));
        let result = reader.push_filter(&filter).unwrap();
        assert!(matches!(result, FilterPushdownResult::NotPushed(_)));
    }
}
