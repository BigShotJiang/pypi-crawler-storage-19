// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Vortex format reader
//!
//! Provides reading of Vortex files using the `vortex` crate,
//! outputting Arrow RecordBatches.

use crate::partition::{Partition, PartitionBuilder};
use crate::stats::{ColumnStatistics, Statistics};
use crate::{Error, Result};
use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;
use arrow_schema::Schema as ArrowSchema;
use std::path::Path;
use std::sync::Arc;
use tracing::{debug, instrument};
use vortex::dtype::DType;
use vortex::file::{VortexFile, VortexOpenOptions};

/// Reader for Vortex files
pub struct VortexReader {
    /// The underlying Vortex file - public for direct access to scan()
    pub file: VortexFile,
    /// Arrow schema
    pub schema: SchemaRef,
    /// File path (for error messages)
    #[allow(dead_code)]
    path: String,
    /// Temp file handle - kept alive for the reader's lifetime when reading from bytes
    #[allow(dead_code)]
    _temp_file: Option<tempfile::NamedTempFile>,
    /// Filter to apply during reads (for filter pushdown)
    filter: Option<vortex::expr::ExprRef>,
}

impl VortexReader {
    /// Open a Vortex file from a local path
    #[instrument(skip_all, fields(path = %path.as_ref().display()))]
    pub async fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        let path_str = path.as_ref().display().to_string();

        let file = VortexOpenOptions::file()
            .open(&path_str)
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to open Vortex file: {}", e)))?;

        // Get schema from the file
        let vortex_dtype = file.dtype();
        let arrow_schema = vortex_dtype_to_arrow_schema(vortex_dtype)?;

        debug!(?arrow_schema, "Opened Vortex file");

        Ok(Self {
            file,
            schema: Arc::new(arrow_schema),
            path: path_str,
            _temp_file: None,
            filter: None,
        })
    }

    /// Open a Vortex file synchronously - FASTEST PATH for local files
    ///
    /// This method:
    /// - Uses Vortex's built-in `open_blocking()` which has its own internal dispatcher
    /// - Does NOT require any external Tokio runtime
    /// - Achieves near-native performance (no async overhead)
    #[instrument(skip_all, fields(path = %path.as_ref().display()))]
    pub fn open_sync<P: AsRef<Path>>(path: P) -> Result<Self> {
        let path_str = path.as_ref().display().to_string();

        // Use Vortex's blocking API - it manages its own internal Tokio dispatcher
        let file = VortexOpenOptions::file()
            .open_blocking(&path_str)
            .map_err(|e| Error::invalid_file(format!("Failed to open Vortex file: {}", e)))?;

        // Get schema from the file
        let vortex_dtype = file.dtype();
        let arrow_schema = vortex_dtype_to_arrow_schema(vortex_dtype)?;

        debug!(?arrow_schema, "Opened Vortex file (sync)");

        Ok(Self {
            file,
            schema: Arc::new(arrow_schema),
            path: path_str,
            _temp_file: None,
            filter: None,
        })
    }

    /// Open a Vortex file from in-memory bytes (legacy - downloads entire file)
    ///
    /// DEPRECATED: Use `from_object_store` for streaming reads with range requests.
    /// This method downloads the entire file before parsing.
    #[instrument(skip_all)]
    pub async fn from_bytes(data: bytes::Bytes) -> Result<Self> {
        use std::io::Write;

        // Write to temp file - vortex requires file-based access
        let mut temp_file = tempfile::NamedTempFile::new()
            .map_err(|e| Error::invalid_file(format!("Failed to create temp file: {}", e)))?;

        temp_file
            .write_all(&data)
            .map_err(|e| Error::invalid_file(format!("Failed to write temp file: {}", e)))?;

        temp_file
            .flush()
            .map_err(|e| Error::invalid_file(format!("Failed to flush temp file: {}", e)))?;

        let path_str = temp_file.path().display().to_string();

        let file: VortexFile = VortexOpenOptions::file()
            .open(&path_str)
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to open Vortex file: {}", e)))?;

        // Get schema from the file
        let vortex_dtype = file.dtype();
        let arrow_schema = vortex_dtype_to_arrow_schema(vortex_dtype)?;

        debug!(?arrow_schema, "Opened Vortex file from bytes");

        Ok(Self {
            file,
            schema: Arc::new(arrow_schema),
            path: "memory".to_string(),
            _temp_file: Some(temp_file),
            filter: None,
        })
    }

    /// Open a Vortex file from object storage with streaming (range requests)
    ///
    /// This uses Vortex's native object_store integration which:
    /// - Reads only the footer initially (metadata)
    /// - Fetches column chunks on-demand via HTTP range requests
    /// - Supports predicate and projection pushdown
    #[instrument(skip_all, fields(path = %path))]
    pub async fn from_object_store(
        store: Arc<dyn object_store::ObjectStore>,
        path: &str,
    ) -> Result<Self> {
        let file = VortexOpenOptions::file()
            .open_object_store(&store, path)
            .await
            .map_err(|e| {
                Error::invalid_file(format!(
                    "Failed to open Vortex file from object store: {}",
                    e
                ))
            })?;

        // Get schema from the file
        let vortex_dtype = file.dtype();
        let arrow_schema = vortex_dtype_to_arrow_schema(vortex_dtype)?;

        debug!(
            ?arrow_schema,
            "Opened Vortex file from object store (streaming)"
        );

        Ok(Self {
            file,
            schema: Arc::new(arrow_schema),
            path: path.to_string(),
            _temp_file: None,
            filter: None,
        })
    }

    /// Push a filter down to the reader for predicate pushdown
    ///
    /// Converts the Rosetta expression to a Vortex expression and stores it
    /// for use during read operations. The filter is applied when scanning
    /// the file, which allows Vortex to skip data that doesn't match.
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use rosetta::expr::{col, lit};
    ///
    /// let mut reader = VortexReader::open("data.vortex").await?;
    /// reader.push_filter(&col("age").gt(lit(30)))?;
    /// let batches = reader.read_all().await?; // Only rows where age > 30
    /// ```
    pub fn push_filter(
        &mut self,
        filter: &crate::expr::Expr,
    ) -> Result<crate::expr::FilterPushdownResult> {
        use crate::expr::FilterPushdownResult;

        match filter.to_vortex_expr() {
            Some(vortex_filter) => {
                self.filter = Some(vortex_filter);
                Ok(FilterPushdownResult::Pushed)
            }
            None => {
                // Filter cannot be translated to Vortex - return as not pushed
                Ok(FilterPushdownResult::NotPushed(Box::new(filter.clone())))
            }
        }
    }

    /// Read all data as RecordBatches
    pub async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        // Delegate to sync implementation - scan/read is already synchronous
        self.read_all_sync()
    }

    /// Read all data synchronously - FASTEST PATH (no async overhead)
    ///
    /// This is the optimal path for local file reads:
    /// - `file.scan()` is synchronous
    /// - `into_record_batch_reader()` is synchronous
    /// - `RecordBatchReader::into_iter()` is synchronous
    ///
    /// No Tokio runtime needed at all!
    ///
    /// If a filter has been set via `push_filter()`, it will be applied
    /// during the scan, allowing Vortex to skip non-matching data.
    pub fn read_all_sync(&self) -> Result<Vec<RecordBatch>> {
        let arrow_schema = self.schema.clone();

        let mut scanner = self
            .file
            .scan()
            .map_err(|e| Error::invalid_file(format!("Failed to create Vortex scanner: {}", e)))?;

        // Apply filter if one has been set
        if let Some(ref filter) = self.filter {
            scanner = scanner.with_filter(filter.clone());
        }

        let reader = scanner
            .into_record_batch_reader(arrow_schema)
            .map_err(|e| {
                Error::invalid_file(format!("Failed to create record batch reader: {}", e))
            })?;

        let batches: Vec<RecordBatch> = reader
            .into_iter()
            .map(|result| {
                result.map_err(|e| Error::invalid_file(format!("Failed to read batch: {}", e)))
            })
            .collect::<Result<Vec<_>>>()?;

        debug!(
            num_batches = batches.len(),
            has_filter = self.filter.is_some(),
            "Read Vortex file (sync)"
        );
        Ok(batches)
    }

    /// Read with column projection
    pub async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        // Delegate to sync implementation
        self.read_projection_sync(columns)
    }

    /// Read with column projection synchronously - FASTEST PATH
    ///
    /// If a filter has been set via `push_filter()`, it will be applied
    /// during the scan, allowing Vortex to skip non-matching data.
    pub fn read_projection_sync(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        use vortex::dtype::FieldName;
        use vortex::expr::{root, select};

        // Find column indices and validate
        let indices: Vec<usize> = columns
            .iter()
            .map(|name| {
                self.schema
                    .index_of(name)
                    .map_err(|_| Error::column_not_found(name))
            })
            .collect::<Result<Vec<_>>>()?;

        // Create projected schema
        let projected_fields: Vec<_> = indices
            .iter()
            .map(|&i| self.schema.field(i).clone())
            .collect();
        let projected_schema = Arc::new(ArrowSchema::new(projected_fields));

        // Build projection using select expression with root()
        let field_names: Vec<FieldName> = columns.iter().map(|c| c.as_str().into()).collect();

        let mut scanner = self
            .file
            .scan()
            .map_err(|e| Error::invalid_file(format!("Failed to create Vortex scanner: {}", e)))?
            .with_projection(select(field_names, root()));

        // Apply filter if one has been set
        if let Some(ref filter) = self.filter {
            scanner = scanner.with_filter(filter.clone());
        }

        let reader = scanner
            .into_record_batch_reader(projected_schema)
            .map_err(|e| {
                Error::invalid_file(format!("Failed to create record batch reader: {}", e))
            })?;

        let batches: Vec<RecordBatch> = reader
            .into_iter()
            .map(|result| {
                result.map_err(|e| Error::invalid_file(format!("Failed to read batch: {}", e)))
            })
            .collect::<Result<Vec<_>>>()?;

        Ok(batches)
    }

    /// Get number of row groups (Vortex calls them "segments")
    /// For now, return 1 as Vortex handles this internally
    pub fn num_row_groups(&self) -> usize {
        // Vortex manages its own chunking internally
        1
    }

    /// Read a specific row group
    pub async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>> {
        if row_group != 0 {
            return Err(Error::invalid_file(format!(
                "Row group {} does not exist (Vortex manages chunking internally)",
                row_group
            )));
        }
        self.read_all().await
    }

    /// Get statistics for query optimization
    ///
    /// Vortex maintains statistics internally but doesn't expose them via public API yet.
    /// For now, we return basic schema-level statistics.
    pub fn statistics(&self) -> Option<Statistics> {
        // Vortex doesn't expose row count or byte size via public API yet
        // Return minimal statistics based on schema
        let mut column_stats = std::collections::HashMap::new();

        for field in self.schema.fields() {
            column_stats.insert(
                field.name().clone(),
                ColumnStatistics {
                    null_count: None,
                    distinct_count: None,
                    min_value: None,
                    max_value: None,
                },
            );
        }

        Some(Statistics {
            num_rows: None,
            total_byte_size: None,
            column_statistics: column_stats,
        })
    }

    /// Get partition information for distributed execution
    ///
    /// Vortex manages chunking internally, so we return a single partition
    /// representing the entire file.
    pub fn partitions(&self) -> Result<Vec<Partition>> {
        let mut builder = PartitionBuilder::default();
        Ok(vec![builder.build_single(&self.path)])
    }
}

/// Convert Vortex dtype to Arrow schema
///
/// This is a public helper for converting Vortex's DType to an Arrow Schema.
/// Useful for Python bindings and other integrations that need schema conversion.
pub fn vortex_dtype_to_arrow_schema(dtype: &DType) -> Result<ArrowSchema> {
    use arrow::datatypes::Field;

    match dtype {
        DType::Struct(struct_dtype, _nullability) => {
            let fields: Vec<Field> = struct_dtype
                .names()
                .iter()
                .zip(struct_dtype.fields())
                .map(|(name, dt)| {
                    let arrow_type = vortex_dtype_to_arrow_type(&dt)?;
                    let nullable = dt.is_nullable();
                    Ok(Field::new(name.as_ref(), arrow_type, nullable))
                })
                .collect::<Result<Vec<_>>>()?;
            Ok(ArrowSchema::new(fields))
        }
        _ => Err(Error::invalid_file(
            "Vortex file root must be a struct type".to_string(),
        )),
    }
}

/// Convert Vortex dtype to Arrow DataType
///
/// This is a public helper for converting Vortex's DType to an Arrow DataType.
/// Useful for Python bindings and other integrations that need type conversion.
pub fn vortex_dtype_to_arrow_type(dtype: &DType) -> Result<arrow::datatypes::DataType> {
    use arrow::datatypes::DataType;
    use vortex::dtype::PType;

    match dtype {
        DType::Null => Ok(DataType::Null),
        DType::Bool(_) => Ok(DataType::Boolean),
        DType::Primitive(ptype, _) => match ptype {
            PType::I8 => Ok(DataType::Int8),
            PType::I16 => Ok(DataType::Int16),
            PType::I32 => Ok(DataType::Int32),
            PType::I64 => Ok(DataType::Int64),
            PType::U8 => Ok(DataType::UInt8),
            PType::U16 => Ok(DataType::UInt16),
            PType::U32 => Ok(DataType::UInt32),
            PType::U64 => Ok(DataType::UInt64),
            PType::F16 => Ok(DataType::Float16),
            PType::F32 => Ok(DataType::Float32),
            PType::F64 => Ok(DataType::Float64),
        },
        DType::Utf8(_) => Ok(DataType::Utf8),
        DType::Binary(_) => Ok(DataType::Binary),
        DType::List(element_dtype, _) => {
            let element_type = vortex_dtype_to_arrow_type(element_dtype)?;
            Ok(DataType::List(Arc::new(arrow::datatypes::Field::new(
                "item",
                element_type,
                element_dtype.is_nullable(),
            ))))
        }
        DType::FixedSizeList(element_dtype, size, _) => {
            let element_type = vortex_dtype_to_arrow_type(element_dtype)?;
            Ok(DataType::FixedSizeList(
                Arc::new(arrow::datatypes::Field::new(
                    "item",
                    element_type,
                    element_dtype.is_nullable(),
                )),
                *size as i32,
            ))
        }
        DType::Struct(struct_dtype, _) => {
            let fields: Vec<arrow::datatypes::Field> = struct_dtype
                .names()
                .iter()
                .zip(struct_dtype.fields())
                .map(|(name, dt)| {
                    let arrow_type = vortex_dtype_to_arrow_type(&dt)?;
                    Ok(arrow::datatypes::Field::new(
                        name.as_ref(),
                        arrow_type,
                        dt.is_nullable(),
                    ))
                })
                .collect::<Result<Vec<_>>>()?;
            Ok(DataType::Struct(fields.into()))
        }
        DType::Extension(ext) => {
            // Handle extension types
            let ext_id = ext.id().as_ref();
            match ext_id {
                "vortex.timestamp" => {
                    // Decode timestamp metadata: [time_unit, tz_len_lo, tz_len_hi, tz_bytes...]
                    match ext.metadata() {
                        None => {
                            // Default to microseconds with no timezone
                            Ok(DataType::Timestamp(
                                arrow::datatypes::TimeUnit::Microsecond,
                                None,
                            ))
                        }
                        Some(metadata) => {
                            let bytes = metadata.as_ref();
                            if bytes.is_empty() {
                                Ok(DataType::Timestamp(
                                    arrow::datatypes::TimeUnit::Microsecond,
                                    None,
                                ))
                            } else {
                                let time_unit = match bytes[0] {
                                    0 => arrow::datatypes::TimeUnit::Nanosecond,
                                    1 => arrow::datatypes::TimeUnit::Microsecond,
                                    2 => arrow::datatypes::TimeUnit::Millisecond,
                                    3 => arrow::datatypes::TimeUnit::Second,
                                    _ => arrow::datatypes::TimeUnit::Microsecond, // Default fallback
                                };
                                // Check for timezone (bytes 1-2 are length, then tz string)
                                let tz = if bytes.len() > 2 {
                                    let tz_len = (bytes[1] as u16) | ((bytes[2] as u16) << 8);
                                    if tz_len > 0 && bytes.len() >= 3 + tz_len as usize {
                                        let tz_bytes = &bytes[3..3 + tz_len as usize];
                                        String::from_utf8(tz_bytes.to_vec()).ok().map(Arc::from)
                                    } else {
                                        None
                                    }
                                } else {
                                    None
                                };
                                Ok(DataType::Timestamp(time_unit, tz))
                            }
                        }
                    }
                }
                "vortex.date" => {
                    // Date type - use Date32 (days since epoch)
                    Ok(DataType::Date32)
                }
                "vortex.time" => {
                    // Time type - decode time unit from metadata
                    match ext.metadata() {
                        None => Ok(DataType::Time64(arrow::datatypes::TimeUnit::Microsecond)),
                        Some(metadata) => {
                            let bytes = metadata.as_ref();
                            if bytes.is_empty() {
                                Ok(DataType::Time64(arrow::datatypes::TimeUnit::Microsecond))
                            } else {
                                let time_unit = match bytes[0] {
                                    0 => arrow::datatypes::TimeUnit::Nanosecond,
                                    1 => arrow::datatypes::TimeUnit::Microsecond,
                                    2 => arrow::datatypes::TimeUnit::Millisecond,
                                    3 => arrow::datatypes::TimeUnit::Second,
                                    _ => arrow::datatypes::TimeUnit::Microsecond,
                                };
                                match time_unit {
                                    arrow::datatypes::TimeUnit::Second
                                    | arrow::datatypes::TimeUnit::Millisecond => {
                                        Ok(DataType::Time32(time_unit))
                                    }
                                    _ => Ok(DataType::Time64(time_unit)),
                                }
                            }
                        }
                    }
                }
                _ => {
                    // Unknown extension - fall back to storage type
                    vortex_dtype_to_arrow_type(ext.storage_dtype())
                }
            }
        }
        DType::Decimal(decimal_dtype, _) => {
            // Map Vortex decimal to Arrow Decimal128
            Ok(DataType::Decimal128(
                decimal_dtype.precision(),
                decimal_dtype.scale(),
            ))
        }
    }
}

#[async_trait::async_trait]
impl super::FormatReader for VortexReader {
    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn statistics(&self) -> Option<Statistics> {
        VortexReader::statistics(self)
    }

    fn partitions(&self) -> Result<Vec<Partition>> {
        VortexReader::partitions(self)
    }

    fn num_row_groups(&self) -> usize {
        VortexReader::num_row_groups(self)
    }

    async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        VortexReader::read_all(self).await
    }

    async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>> {
        VortexReader::read_row_group(self, row_group).await
    }

    async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        VortexReader::read_projection(self, columns).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dtype_conversion() {
        use vortex::dtype::{DType, Nullability, PType};

        // Test primitive types
        let int32_dtype = DType::Primitive(PType::I32, Nullability::NonNullable);
        let arrow_type = vortex_dtype_to_arrow_type(&int32_dtype).unwrap();
        assert_eq!(arrow_type, arrow::datatypes::DataType::Int32);

        let float64_dtype = DType::Primitive(PType::F64, Nullability::Nullable);
        let arrow_type = vortex_dtype_to_arrow_type(&float64_dtype).unwrap();
        assert_eq!(arrow_type, arrow::datatypes::DataType::Float64);
    }
}
