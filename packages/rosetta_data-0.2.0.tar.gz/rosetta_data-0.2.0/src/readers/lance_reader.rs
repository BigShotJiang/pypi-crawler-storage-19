// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Lance format reader
//!
//! Provides reading of Lance datasets using the `lance` crate,
//! outputting Arrow RecordBatches.

use crate::partition::{Partition, PartitionBuilder, PartitionStrategy};
use crate::stats::{ColumnStatistics, Statistics};
use crate::{Error, Result};
use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;
use futures::TryStreamExt;
use lance::Dataset;
use std::path::Path;
use std::sync::Arc;
use tracing::{debug, instrument};

/// Reader for Lance datasets
///
/// Lance datasets are directory-based, containing a `.lance/` folder
/// with versioned data files.
pub struct LanceReader {
    /// The underlying Lance dataset
    dataset: Dataset,
    /// Arrow schema
    pub schema: SchemaRef,
    /// Dataset path (for error messages)
    #[allow(dead_code)]
    path: String,
    /// SQL filter string for predicate pushdown
    filter_sql: Option<String>,
}

impl LanceReader {
    /// Open a Lance dataset from a local path
    ///
    /// The path should point to a Lance dataset directory (containing `.lance/`)
    #[instrument(skip_all, fields(path = %path.as_ref().display()))]
    pub async fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        let path_str = path.as_ref().display().to_string();

        let dataset = Dataset::open(&path_str)
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to open Lance dataset: {}", e)))?;

        // Get schema from the dataset
        let lance_schema = dataset.schema();
        let arrow_schema: arrow::datatypes::Schema = lance_schema.into();

        debug!(?arrow_schema, "Opened Lance dataset");

        Ok(Self {
            dataset,
            schema: Arc::new(arrow_schema),
            path: path_str,
            filter_sql: None,
        })
    }

    /// Push a filter down to the reader for predicate pushdown
    ///
    /// Converts the Rosetta expression to a SQL filter string and stores it
    /// for use during read operations. Lance supports SQL-style filter syntax.
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use rosetta::expr::{col, lit};
    ///
    /// let mut reader = LanceReader::open("data.lance").await?;
    /// reader.push_filter(&col("age").gt(lit(30)))?;
    /// let batches = reader.read_all().await?; // Only rows where age > 30
    /// ```
    pub fn push_filter(
        &mut self,
        filter: &crate::expr::Expr,
    ) -> crate::Result<crate::expr::FilterPushdownResult> {
        use crate::expr::FilterPushdownResult;

        if filter.can_push_to_lance() {
            let sql = filter.to_lance_sql();
            self.filter_sql = Some(sql);
            Ok(FilterPushdownResult::Pushed)
        } else {
            Ok(FilterPushdownResult::NotPushed(Box::new(filter.clone())))
        }
    }

    /// Read all data as RecordBatches
    ///
    /// If a filter has been set via `push_filter()`, it will be applied
    /// during the scan, allowing Lance to skip non-matching data.
    pub async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        let mut scanner = self.dataset.scan();

        // Apply filter if one has been set
        if let Some(ref filter_sql) = self.filter_sql {
            scanner
                .filter(filter_sql)
                .map_err(|e| Error::invalid_file(format!("Failed to apply filter: {}", e)))?;
        }

        let stream = scanner
            .try_into_stream()
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to create Lance scanner: {}", e)))?;

        let batches: Vec<RecordBatch> = stream
            .try_collect()
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to read Lance batches: {}", e)))?;

        debug!(
            num_batches = batches.len(),
            has_filter = self.filter_sql.is_some(),
            "Read Lance dataset"
        );
        Ok(batches)
    }

    /// Read with column projection
    ///
    /// If a filter has been set via `push_filter()`, it will be applied
    /// during the scan, allowing Lance to skip non-matching data.
    pub async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        // Validate columns exist in schema
        for col in columns {
            self.schema
                .index_of(col)
                .map_err(|_| Error::column_not_found(col))?;
        }

        let mut scanner = self.dataset.scan();
        scanner
            .project(columns)
            .map_err(|e| Error::invalid_file(format!("Failed to set projection: {}", e)))?;

        // Apply filter if one has been set
        if let Some(ref filter_sql) = self.filter_sql {
            scanner
                .filter(filter_sql)
                .map_err(|e| Error::invalid_file(format!("Failed to apply filter: {}", e)))?;
        }

        let stream = scanner
            .try_into_stream()
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to create Lance scanner: {}", e)))?;

        let batches: Vec<RecordBatch> = stream
            .try_collect()
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to read Lance batches: {}", e)))?;

        Ok(batches)
    }

    /// Get number of row groups
    ///
    /// Lance uses fragments instead of row groups. Each fragment is similar
    /// to a row group in Parquet.
    pub fn num_row_groups(&self) -> usize {
        self.dataset.count_fragments()
    }

    /// Read a specific row group (fragment)
    ///
    /// Lance's fragments are similar to Parquet row groups.
    /// If a filter has been set via `push_filter()`, it will be applied.
    pub async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>> {
        let fragments = self.dataset.get_fragments();

        if row_group >= fragments.len() {
            return Err(Error::invalid_file(format!(
                "Fragment {} does not exist (dataset has {} fragments)",
                row_group,
                fragments.len()
            )));
        }

        let fragment = &fragments[row_group];

        let mut scanner = self.dataset.scan();
        scanner.with_fragments(vec![fragment.clone().into()]);

        // Apply filter if one has been set
        if let Some(ref filter_sql) = self.filter_sql {
            scanner
                .filter(filter_sql)
                .map_err(|e| Error::invalid_file(format!("Failed to apply filter: {}", e)))?;
        }

        let stream = scanner
            .try_into_stream()
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to create Lance scanner: {}", e)))?;

        let batches: Vec<RecordBatch> = stream
            .try_collect()
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to read Lance fragment: {}", e)))?;

        Ok(batches)
    }

    /// Get the dataset for advanced operations
    pub fn dataset(&self) -> &Dataset {
        &self.dataset
    }

    /// Get the number of rows in the dataset
    pub async fn count_rows(&self) -> Result<usize> {
        self.dataset
            .count_rows(None)
            .await
            .map_err(|e| Error::invalid_file(format!("Failed to count rows: {}", e)))
    }

    /// Get statistics for query optimization
    ///
    /// Lance maintains statistics at the fragment level. We aggregate them here.
    pub fn statistics(&self) -> Option<Statistics> {
        // Build column statistics from schema (Lance doesn't expose stats via public API yet)
        let mut column_stats = std::collections::HashMap::new();

        for field in self.schema.fields() {
            column_stats.insert(
                field.name().clone(),
                ColumnStatistics {
                    null_count: None,
                    distinct_count: None,
                    min_value: None,
                    max_value: None,
                },
            );
        }

        // Lance provides fragment count but not row count synchronously
        Some(Statistics {
            num_rows: None, // Would require async call to count_rows()
            total_byte_size: None,
            column_statistics: column_stats,
        })
    }

    /// Get partition information for distributed execution
    ///
    /// Lance fragments map directly to partitions for distributed execution.
    pub fn partitions(&self) -> Result<Vec<Partition>> {
        let fragments = self.dataset.get_fragments();
        let num_fragments = fragments.len();

        if num_fragments == 0 {
            // Empty dataset - return single empty partition
            let mut builder = PartitionBuilder::default();
            return Ok(vec![builder.build_single(&self.path)]);
        }

        // Create one partition per fragment (Lance's natural parallelism unit)
        // Note: We don't have access to row counts synchronously, so pass None
        let mut builder = PartitionBuilder::new(PartitionStrategy::PerRowGroup);
        Ok(builder.build_for_file(&self.path, num_fragments, None, None))
    }
}

#[async_trait::async_trait]
impl super::FormatReader for LanceReader {
    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn statistics(&self) -> Option<Statistics> {
        LanceReader::statistics(self)
    }

    fn partitions(&self) -> Result<Vec<Partition>> {
        LanceReader::partitions(self)
    }

    fn num_row_groups(&self) -> usize {
        LanceReader::num_row_groups(self)
    }

    async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        LanceReader::read_all(self).await
    }

    async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>> {
        LanceReader::read_row_group(self, row_group).await
    }

    async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        LanceReader::read_projection(self, columns).await
    }
}

#[cfg(test)]
mod tests {
    // Tests require creating Lance datasets which is complex
    // Integration tests should be added separately
}
