// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! F3 file format reader
//!
//! Reads F3-style self-describing columnar files that embed WASM decoders.
//! Based on the F3 format specification from CMU/Tsinghua (SIGMOD 2026).
//!
//! # File Format
//!
//! ```text
//! ┌─────────────────────────────────────────────────────┐
//! │                    F3 Header                         │
//! │  ┌───────────┬──────────┬────────────────────────┐  │
//! │  │ Magic (4) │ Ver (2)  │ Header Length (4)      │  │
//! │  │ F3\x00\x01│          │                        │  │
//! │  └───────────┴──────────┴────────────────────────┘  │
//! ├─────────────────────────────────────────────────────┤
//! │                 Schema Section                       │
//! │  (Arrow IPC serialized schema)                      │
//! ├─────────────────────────────────────────────────────┤
//! │               Decoder Section                        │
//! │  ┌─────────────────────────────────────────────┐    │
//! │  │ Decoder Count (4)                           │    │
//! │  │ Decoder Metadata (per column)               │    │
//! │  │ WASM Module Bytes (per unique decoder)      │    │
//! │  └─────────────────────────────────────────────┘    │
//! ├─────────────────────────────────────────────────────┤
//! │                 Data Section                         │
//! │  (Encoded column chunks)                            │
//! ├─────────────────────────────────────────────────────┤
//! │                    Footer                            │
//! │  (Chunk offsets, row counts, checksums)             │
//! └─────────────────────────────────────────────────────┘
//! ```

use std::collections::HashMap;
use std::path::Path;
use std::sync::Arc;

use arrow::array::ArrayRef;
use arrow::datatypes::{DataType, Field, Schema, SchemaRef};
use arrow::record_batch::RecordBatch;
use tokio::fs::File;
use tokio::io::{AsyncReadExt, AsyncSeekExt, SeekFrom};
use tracing::{debug, instrument};

use crate::wasm::{DecoderId, OutputType, SandboxConfig, WasmRuntime};
use crate::{Error, Result};

/// F3 file magic bytes
const F3_MAGIC: &[u8; 4] = b"F3\x00\x01";

/// F3 file reader
pub struct F3Reader {
    /// Path to the F3 file
    path: String,
    /// Arrow schema
    pub schema: SchemaRef,
    /// WASM runtime for decoder execution
    runtime: WasmRuntime,
    /// Loaded decoders (one per column)
    decoders: Vec<ColumnDecoder>,
    /// Data chunks (offset, length) for each column
    data_chunks: Vec<Vec<ChunkInfo>>,
    /// Total row count
    row_count: usize,
}

/// Information about a column's decoder
struct ColumnDecoder {
    /// Decoder identifier
    id: DecoderId,
    /// WASM module bytes
    wasm_bytes: Vec<u8>,
    /// Encoder-specific metadata
    metadata: Vec<u8>,
    /// Output data type
    output_type: OutputType,
    /// Arrow data type
    arrow_type: DataType,
}

/// Information about a data chunk
#[derive(Debug, Clone)]
struct ChunkInfo {
    /// Offset in file
    offset: u64,
    /// Compressed length
    length: u64,
    /// Uncompressed row count
    row_count: usize,
}

impl F3Reader {
    /// Open an F3 file
    #[instrument(skip_all, fields(path = %path.as_ref().display()))]
    pub async fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        Self::open_with_config(path, SandboxConfig::default()).await
    }

    /// Open with custom sandbox configuration
    pub async fn open_with_config<P: AsRef<Path>>(path: P, config: SandboxConfig) -> Result<Self> {
        let path_str = path.as_ref().to_string_lossy().to_string();
        let mut file = File::open(&path).await?;

        // Read and validate header
        let header = Self::read_header(&mut file).await?;
        debug!(?header, "Read F3 header");

        // Read schema
        let schema = Self::read_schema(&mut file, &header).await?;
        debug!(num_fields = schema.fields().len(), "Read schema");

        // Read decoder section
        let decoders = Self::read_decoders(&mut file, &header, &schema).await?;
        debug!(num_decoders = decoders.len(), "Read decoders");

        // Read data chunk index from footer
        let (data_chunks, row_count) = Self::read_footer(&mut file, &header).await?;

        // Create runtime
        let runtime = WasmRuntime::new(config)?;

        Ok(Self {
            path: path_str,
            schema: Arc::new(schema),
            runtime,
            decoders,
            data_chunks,
            row_count,
        })
    }

    /// Read and validate F3 header
    async fn read_header(file: &mut File) -> Result<F3Header> {
        let mut magic = [0u8; 4];
        file.read_exact(&mut magic).await?;

        if &magic != F3_MAGIC {
            return Err(Error::invalid_file("Not a valid F3 file (bad magic)"));
        }

        let mut version = [0u8; 2];
        file.read_exact(&mut version).await?;

        let mut header_len = [0u8; 4];
        file.read_exact(&mut header_len).await?;

        Ok(F3Header {
            version: u16::from_le_bytes(version),
            header_length: u32::from_le_bytes(header_len),
            schema_offset: 10, // After magic + version + header_len
            decoder_offset: 0, // Set after reading schema
            data_offset: 0,    // Set after reading decoders
            footer_offset: 0,  // Read from end of file
        })
    }

    /// Read Arrow schema from file
    async fn read_schema(file: &mut File, _header: &F3Header) -> Result<Schema> {
        // Read schema length
        let mut schema_len = [0u8; 4];
        file.read_exact(&mut schema_len).await?;
        let schema_len = u32::from_le_bytes(schema_len) as usize;

        // Read schema JSON
        let mut schema_bytes = vec![0u8; schema_len];
        file.read_exact(&mut schema_bytes).await?;

        // Parse as JSON (MVP - production would use Arrow IPC)
        let schema_json: serde_json::Value = serde_json::from_slice(&schema_bytes)
            .map_err(|e| Error::invalid_file(format!("Invalid schema JSON: {}", e)))?;

        Self::parse_schema_json(&schema_json)
    }

    /// Parse schema from JSON
    fn parse_schema_json(json: &serde_json::Value) -> Result<Schema> {
        let fields = json["fields"]
            .as_array()
            .ok_or_else(|| Error::invalid_file("Schema missing fields array"))?;

        let arrow_fields: Vec<Field> = fields
            .iter()
            .map(|f| {
                let name = f["name"].as_str().unwrap_or("").to_string();
                let type_name = f["type"].as_str().unwrap_or("Utf8");
                let nullable = f["nullable"].as_bool().unwrap_or(true);

                let data_type = match type_name {
                    "Int8" => DataType::Int8,
                    "Int16" => DataType::Int16,
                    "Int32" => DataType::Int32,
                    "Int64" => DataType::Int64,
                    "UInt8" => DataType::UInt8,
                    "UInt16" => DataType::UInt16,
                    "UInt32" => DataType::UInt32,
                    "UInt64" => DataType::UInt64,
                    "Float32" => DataType::Float32,
                    "Float64" => DataType::Float64,
                    "Utf8" => DataType::Utf8,
                    "Binary" => DataType::Binary,
                    "Boolean" => DataType::Boolean,
                    _ => DataType::Utf8, // Default fallback
                };

                Field::new(name, data_type, nullable)
            })
            .collect();

        Ok(Schema::new(arrow_fields))
    }

    /// Read decoder section
    async fn read_decoders(
        file: &mut File,
        _header: &F3Header,
        schema: &Schema,
    ) -> Result<Vec<ColumnDecoder>> {
        // Read decoder count
        let mut count = [0u8; 4];
        file.read_exact(&mut count).await?;
        let decoder_count = u32::from_le_bytes(count) as usize;

        let mut decoders = Vec::with_capacity(decoder_count);
        let mut wasm_cache: HashMap<String, Vec<u8>> = HashMap::new();

        for i in 0..decoder_count {
            // Read decoder metadata
            // Format: name_len(2) + name + version(4) + wasm_len(4) + metadata_len(4)
            let mut name_len = [0u8; 2];
            file.read_exact(&mut name_len).await?;
            let name_len = u16::from_le_bytes(name_len) as usize;

            let mut name_bytes = vec![0u8; name_len];
            file.read_exact(&mut name_bytes).await?;
            let name = String::from_utf8_lossy(&name_bytes).to_string();

            let mut version = [0u8; 4];
            file.read_exact(&mut version).await?;
            let version = u32::from_le_bytes(version);

            let mut wasm_len = [0u8; 4];
            file.read_exact(&mut wasm_len).await?;
            let wasm_len = u32::from_le_bytes(wasm_len) as usize;

            let mut metadata_len = [0u8; 4];
            file.read_exact(&mut metadata_len).await?;
            let metadata_len = u32::from_le_bytes(metadata_len) as usize;

            // Read WASM bytes (or use cached)
            let decoder_key = format!("{}:{}", name, version);
            let wasm_bytes = if let Some(cached) = wasm_cache.get(&decoder_key) {
                // Skip WASM bytes in file
                file.seek(SeekFrom::Current(wasm_len as i64)).await?;
                cached.clone()
            } else {
                let mut wasm = vec![0u8; wasm_len];
                file.read_exact(&mut wasm).await?;
                wasm_cache.insert(decoder_key, wasm.clone());
                wasm
            };

            // Read encoder metadata
            let mut metadata = vec![0u8; metadata_len];
            file.read_exact(&mut metadata).await?;

            // Get Arrow type for this column
            let arrow_type = schema.field(i).data_type().clone();

            let output_type = Self::arrow_to_output_type(&arrow_type);

            decoders.push(ColumnDecoder {
                id: DecoderId::new(name, version),
                wasm_bytes,
                metadata,
                output_type,
                arrow_type,
            });
        }

        Ok(decoders)
    }

    /// Convert Arrow DataType to OutputType
    fn arrow_to_output_type(dt: &DataType) -> OutputType {
        match dt {
            DataType::Int8 => OutputType::Int8,
            DataType::Int16 => OutputType::Int16,
            DataType::Int32 => OutputType::Int32,
            DataType::Int64 => OutputType::Int64,
            DataType::UInt8 => OutputType::UInt8,
            DataType::UInt16 => OutputType::UInt16,
            DataType::UInt32 => OutputType::UInt32,
            DataType::UInt64 => OutputType::UInt64,
            DataType::Float32 => OutputType::Float32,
            DataType::Float64 => OutputType::Float64,
            DataType::Utf8 | DataType::LargeUtf8 => OutputType::Utf8,
            DataType::Binary | DataType::LargeBinary => OutputType::Binary,
            DataType::FixedSizeBinary(n) => OutputType::FixedSizeBinary(*n as usize),
            _ => OutputType::Binary, // Fallback
        }
    }

    /// Read footer with chunk index
    async fn read_footer(
        file: &mut File,
        _header: &F3Header,
    ) -> Result<(Vec<Vec<ChunkInfo>>, usize)> {
        // Seek to end to read footer offset
        file.seek(SeekFrom::End(-8)).await?;

        let mut footer_offset = [0u8; 8];
        file.read_exact(&mut footer_offset).await?;
        let footer_offset = u64::from_le_bytes(footer_offset);

        // Seek to footer
        file.seek(SeekFrom::Start(footer_offset)).await?;

        // Read footer
        let mut num_columns = [0u8; 4];
        file.read_exact(&mut num_columns).await?;
        let num_columns = u32::from_le_bytes(num_columns) as usize;

        let mut total_rows = [0u8; 8];
        file.read_exact(&mut total_rows).await?;
        let total_rows = u64::from_le_bytes(total_rows) as usize;

        let mut data_chunks = Vec::with_capacity(num_columns);

        for _ in 0..num_columns {
            let mut num_chunks = [0u8; 4];
            file.read_exact(&mut num_chunks).await?;
            let num_chunks = u32::from_le_bytes(num_chunks) as usize;

            let mut chunks = Vec::with_capacity(num_chunks);
            for _ in 0..num_chunks {
                let mut offset = [0u8; 8];
                file.read_exact(&mut offset).await?;

                let mut length = [0u8; 8];
                file.read_exact(&mut length).await?;

                let mut row_count = [0u8; 4];
                file.read_exact(&mut row_count).await?;

                chunks.push(ChunkInfo {
                    offset: u64::from_le_bytes(offset),
                    length: u64::from_le_bytes(length),
                    row_count: u32::from_le_bytes(row_count) as usize,
                });
            }
            data_chunks.push(chunks);
        }

        Ok((data_chunks, total_rows))
    }

    /// Read all data as RecordBatches
    pub async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        let mut file = File::open(&self.path).await?;

        // Decode each column
        let mut columns: Vec<ArrayRef> = Vec::with_capacity(self.decoders.len());

        for (col_idx, decoder) in self.decoders.iter().enumerate() {
            let chunks = &self.data_chunks[col_idx];
            let mut all_decoded = Vec::new();

            for chunk in chunks {
                // Read encoded data
                file.seek(SeekFrom::Start(chunk.offset)).await?;
                let mut encoded = vec![0u8; chunk.length as usize];
                file.read_exact(&mut encoded).await?;

                // Decode using WASM
                let decoded = self.runtime.decode_oneshot(
                    &decoder.id,
                    &decoder.wasm_bytes,
                    &decoder.metadata,
                    &encoded,
                )?;

                all_decoded.extend(decoded);
            }

            // Convert to Arrow array
            let array = Self::bytes_to_array(&all_decoded, &decoder.arrow_type, self.row_count)?;
            columns.push(array);
        }

        let batch = RecordBatch::try_new(self.schema.clone(), columns)?;
        Ok(vec![batch])
    }

    /// Read a specific row group (chunk)
    pub async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>> {
        let mut file = File::open(&self.path).await?;

        // Get row count for this chunk
        let chunk_row_count = self
            .data_chunks
            .first()
            .and_then(|chunks| chunks.get(row_group))
            .map(|c| c.row_count)
            .ok_or_else(|| Error::invalid_file(format!("Row group {} not found", row_group)))?;

        let mut columns: Vec<ArrayRef> = Vec::with_capacity(self.decoders.len());

        for (col_idx, decoder) in self.decoders.iter().enumerate() {
            let chunk = self.data_chunks[col_idx]
                .get(row_group)
                .ok_or_else(|| Error::invalid_file("Missing chunk for column"))?;

            // Read and decode
            file.seek(SeekFrom::Start(chunk.offset)).await?;
            let mut encoded = vec![0u8; chunk.length as usize];
            file.read_exact(&mut encoded).await?;

            let decoded = self.runtime.decode_oneshot(
                &decoder.id,
                &decoder.wasm_bytes,
                &decoder.metadata,
                &encoded,
            )?;

            let array = Self::bytes_to_array(&decoded, &decoder.arrow_type, chunk_row_count)?;
            columns.push(array);
        }

        let batch = RecordBatch::try_new(self.schema.clone(), columns)?;
        Ok(vec![batch])
    }

    /// Read with column projection
    pub async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        // Find column indices
        let indices: Vec<usize> = columns
            .iter()
            .filter_map(|name| self.schema.index_of(name).ok())
            .collect();

        if indices.is_empty() {
            return Err(Error::column_not_found(columns.join(", ")));
        }

        let mut file = File::open(&self.path).await?;
        let mut result_columns: Vec<ArrayRef> = Vec::with_capacity(indices.len());

        for &col_idx in &indices {
            let decoder = &self.decoders[col_idx];
            let chunks = &self.data_chunks[col_idx];
            let mut all_decoded = Vec::new();

            for chunk in chunks {
                file.seek(SeekFrom::Start(chunk.offset)).await?;
                let mut encoded = vec![0u8; chunk.length as usize];
                file.read_exact(&mut encoded).await?;

                let decoded = self.runtime.decode_oneshot(
                    &decoder.id,
                    &decoder.wasm_bytes,
                    &decoder.metadata,
                    &encoded,
                )?;

                all_decoded.extend(decoded);
            }

            let array = Self::bytes_to_array(&all_decoded, &decoder.arrow_type, self.row_count)?;
            result_columns.push(array);
        }

        // Build projected schema
        let projected_fields: Vec<Field> = indices
            .iter()
            .map(|&i| self.schema.field(i).clone())
            .collect();
        let projected_schema = Arc::new(Schema::new(projected_fields));

        let batch = RecordBatch::try_new(projected_schema, result_columns)?;
        Ok(vec![batch])
    }

    /// Number of row groups
    pub fn num_row_groups(&self) -> usize {
        self.data_chunks
            .first()
            .map(|chunks| chunks.len())
            .unwrap_or(0)
    }

    /// Convert raw bytes to Arrow array
    fn bytes_to_array(bytes: &[u8], data_type: &DataType, row_count: usize) -> Result<ArrayRef> {
        use arrow::array::*;

        let array: ArrayRef = match data_type {
            DataType::Int8 => {
                let values: Vec<i8> = bytes.iter().map(|&b| b as i8).collect();
                Arc::new(Int8Array::from(values))
            }
            DataType::Int16 => {
                let values: Vec<i16> = bytes
                    .chunks_exact(2)
                    .map(|c| i16::from_le_bytes([c[0], c[1]]))
                    .collect();
                Arc::new(Int16Array::from(values))
            }
            DataType::Int32 => {
                let values: Vec<i32> = bytes
                    .chunks_exact(4)
                    .map(|c| i32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                    .collect();
                Arc::new(Int32Array::from(values))
            }
            DataType::Int64 => {
                let values: Vec<i64> = bytes
                    .chunks_exact(8)
                    .map(|c| i64::from_le_bytes(c.try_into().unwrap()))
                    .collect();
                Arc::new(Int64Array::from(values))
            }
            DataType::UInt8 => Arc::new(UInt8Array::from(bytes.to_vec())),
            DataType::UInt16 => {
                let values: Vec<u16> = bytes
                    .chunks_exact(2)
                    .map(|c| u16::from_le_bytes([c[0], c[1]]))
                    .collect();
                Arc::new(UInt16Array::from(values))
            }
            DataType::UInt32 => {
                let values: Vec<u32> = bytes
                    .chunks_exact(4)
                    .map(|c| u32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                    .collect();
                Arc::new(UInt32Array::from(values))
            }
            DataType::UInt64 => {
                let values: Vec<u64> = bytes
                    .chunks_exact(8)
                    .map(|c| u64::from_le_bytes(c.try_into().unwrap()))
                    .collect();
                Arc::new(UInt64Array::from(values))
            }
            DataType::Float32 => {
                let values: Vec<f32> = bytes
                    .chunks_exact(4)
                    .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
                    .collect();
                Arc::new(Float32Array::from(values))
            }
            DataType::Float64 => {
                let values: Vec<f64> = bytes
                    .chunks_exact(8)
                    .map(|c| f64::from_le_bytes(c.try_into().unwrap()))
                    .collect();
                Arc::new(Float64Array::from(values))
            }
            DataType::Utf8 => {
                // Variable-length: expect length-prefixed strings
                let s = String::from_utf8_lossy(bytes).to_string();
                Arc::new(StringArray::from(vec![s; row_count]))
            }
            DataType::Binary => Arc::new(BinaryArray::from(vec![bytes; row_count])),
            _ => {
                return Err(Error::invalid_file(format!(
                    "Unsupported data type: {:?}",
                    data_type
                )));
            }
        };

        Ok(array)
    }
}

/// F3 file header information
#[derive(Debug)]
struct F3Header {
    version: u16,
    header_length: u32,
    schema_offset: u64,
    decoder_offset: u64,
    data_offset: u64,
    footer_offset: u64,
}
