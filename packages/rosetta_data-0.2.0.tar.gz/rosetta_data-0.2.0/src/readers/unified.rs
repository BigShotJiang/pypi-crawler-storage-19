// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Unified reader that auto-detects format and delegates to format-specific readers
//!
//! ## Performance
//!
//! For maximum performance on Parquet files, use the synchronous API:
//! ```ignore
//! let reader = UnifiedReader::open_parquet_sync(path)?;
//! let batches = reader.read_all_sync()?;
//! ```
//!
//! This avoids:
//! - Format detection overhead (format is known)
//! - Async runtime overhead (no tokio context switching)

use crate::object_store_utils::parse_cloud_url;
use crate::{Error, FileFormat, FormatDetector, ReadOptions, Result};
use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;
use std::path::Path;
use std::sync::Arc;

use super::parquet_reader::ParquetReader;

#[cfg(feature = "vortex-reader")]
use super::vortex_reader::VortexReader;

#[cfg(feature = "lance-reader")]
use super::lance_reader::LanceReader;

#[cfg(feature = "wasm-runtime")]
use super::f3_reader::F3Reader;

/// Unified reader that handles multiple file formats
///
/// Automatically detects the file format and uses the appropriate
/// reader implementation.
///
/// ## Filter Pushdown
///
/// The unified reader supports filter pushdown via the `push_filter()` method.
/// Different formats have different levels of support:
/// - **Vortex**: Full pushdown support via native expressions
/// - **Lance**: Full pushdown support via SQL filters
/// - **Parquet**: Basic support (filter stored but not yet pushed to reader)
///
/// ```rust,ignore
/// use rosetta::expr::{col, lit};
///
/// let mut reader = UnifiedReader::open("data.vortex").await?;
/// reader.push_filter(&col("age").gt(lit(30)))?;
/// let batches = reader.read_all().await?; // Filtered at read time!
/// ```
pub struct UnifiedReader {
    /// The underlying format-specific reader
    inner: ReaderImpl,
    /// The detected or forced format
    format: FileFormat,
    /// Read options
    options: ReadOptions,
}

/// Internal enum for format-specific readers
enum ReaderImpl {
    Parquet(ParquetReader),
    #[cfg(feature = "vortex-reader")]
    Vortex(VortexReader),
    #[cfg(feature = "lance-reader")]
    Lance(LanceReader),
    #[cfg(feature = "wasm-runtime")]
    F3(F3Reader),
}

impl UnifiedReader {
    /// Open a file with auto-detection
    pub async fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        Self::open_with_options(path, ReadOptions::default()).await
    }

    /// Open a Parquet file synchronously - fastest path for Parquet reads
    ///
    /// This method:
    /// - Skips format detection (format is known)
    /// - Avoids async runtime overhead
    /// - Uses synchronous I/O for maximum performance
    ///
    /// Use this when you know the file is Parquet and want maximum read performance.
    #[inline]
    pub fn open_parquet_sync<P: AsRef<Path>>(path: P) -> Result<Self> {
        let reader = ParquetReader::open_sync(path)?;
        let format = reader.version();
        Ok(Self {
            inner: ReaderImpl::Parquet(reader),
            format,
            options: ReadOptions::default(),
        })
    }

    /// Open a file with specific options
    pub async fn open_with_options<P: AsRef<Path>>(path: P, options: ReadOptions) -> Result<Self> {
        let path = path.as_ref();

        // Detect or use forced format
        let format = match options.force_format {
            Some(fmt) => fmt,
            None => {
                let detector = FormatDetector::new();
                detector.detect_file(path).await?
            }
        };

        // Create format-specific reader
        let inner = match format {
            FileFormat::ParquetV1 | FileFormat::ParquetV2 => {
                let mut reader = ParquetReader::open(path).await?;
                if let Some(batch_size) = options.batch_size {
                    reader = reader.with_batch_size(batch_size);
                }
                ReaderImpl::Parquet(reader)
            }
            FileFormat::Vortex => {
                #[cfg(feature = "vortex-reader")]
                {
                    let reader = VortexReader::open(path).await?;
                    ReaderImpl::Vortex(reader)
                }
                #[cfg(not(feature = "vortex-reader"))]
                {
                    return Err(Error::unsupported_format("Vortex", "vortex-reader"));
                }
            }
            FileFormat::Lance => {
                #[cfg(feature = "lance-reader")]
                {
                    let reader = LanceReader::open(path).await?;
                    ReaderImpl::Lance(reader)
                }
                #[cfg(not(feature = "lance-reader"))]
                {
                    return Err(Error::unsupported_format("Lance", "lance-reader"));
                }
            }
            FileFormat::F3 => {
                #[cfg(feature = "wasm-runtime")]
                {
                    let reader = F3Reader::open(path).await?;
                    ReaderImpl::F3(reader)
                }
                #[cfg(not(feature = "wasm-runtime"))]
                {
                    return Err(Error::unsupported_format("F3", "wasm-runtime"));
                }
            }
            FileFormat::FastLanes => {
                return Err(Error::unsupported_format("FastLanes", "fastlanes-reader"));
            }
        };

        Ok(Self {
            inner,
            format,
            options,
        })
    }

    /// Open from a URL (S3, GCS, etc.)
    pub async fn open_url(url: &str) -> Result<Self> {
        Self::open_url_with_options(url, ReadOptions::default()).await
    }

    /// Open from a URL with options
    pub async fn open_url_with_options(url: &str, options: ReadOptions) -> Result<Self> {
        // Detect format
        let format = match options.force_format {
            Some(fmt) => fmt,
            None => {
                let detector = FormatDetector::new();
                detector.detect_url(url).await?
            }
        };

        // Parse URL and get object store using shared utilities
        let (store, path) = parse_cloud_url(url)?;

        // Create reader - use streaming for Vortex, download for others
        let inner = match format {
            #[cfg(feature = "vortex-reader")]
            FileFormat::Vortex => {
                // Use Vortex's native object_store integration for streaming reads
                // This uses HTTP range requests instead of downloading the entire file
                let reader = VortexReader::from_object_store(store, path.as_ref()).await?;
                ReaderImpl::Vortex(reader)
            }
            FileFormat::ParquetV1 | FileFormat::ParquetV2 => {
                // Download entire file for Parquet (TODO: implement streaming for Parquet too)
                use object_store::ObjectStore;
                let data = store.get(&path).await?.bytes().await?;
                let mut reader = ParquetReader::from_bytes(data).await?;
                if let Some(batch_size) = options.batch_size {
                    reader = reader.with_batch_size(batch_size);
                }
                ReaderImpl::Parquet(reader)
            }
            other => {
                return Err(Error::unsupported_format(
                    other.name(),
                    format!("{}-reader", other.extension()),
                ));
            }
        };

        Ok(Self {
            inner,
            format,
            options,
        })
    }

    /// Get the detected file format
    pub fn format(&self) -> FileFormat {
        self.format
    }

    /// Get the Arrow schema
    pub fn schema(&self) -> SchemaRef {
        match &self.inner {
            ReaderImpl::Parquet(r) => r.schema.clone(),
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.schema.clone(),
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.schema.clone(),
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(r) => r.schema.clone(),
        }
    }

    /// Get the number of row groups
    pub fn num_row_groups(&self) -> usize {
        match &self.inner {
            ReaderImpl::Parquet(r) => r.metadata().num_row_groups(),
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.num_row_groups(),
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.num_row_groups(),
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(r) => r.num_row_groups(),
        }
    }

    /// Read all data as RecordBatches
    pub async fn read_all(&self) -> Result<Vec<RecordBatch>> {
        // Apply column projection if specified
        if let Some(ref columns) = self.options.columns {
            return self.read_projection(columns).await;
        }

        // Apply row group filter if specified
        if let Some(ref row_groups) = self.options.row_groups {
            let mut all_batches = Vec::new();
            for &rg in row_groups {
                let batches = self.read_row_group(rg).await?;
                all_batches.extend(batches);
            }
            return Ok(all_batches);
        }

        match &self.inner {
            ReaderImpl::Parquet(r) => r.read_all().await,
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.read_all().await,
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.read_all().await,
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(r) => r.read_all().await,
        }
    }

    /// Read all data synchronously - fastest path for Parquet reads
    ///
    /// This method is only available when the underlying reader is Parquet.
    /// For other formats, use `read_all()` instead.
    #[inline]
    pub fn read_all_sync(&self) -> Result<Vec<RecordBatch>> {
        match &self.inner {
            ReaderImpl::Parquet(r) => r.read_all_sync(),
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(_) => Err(Error::invalid_file(
                "read_all_sync only supported for Parquet files",
            )),
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(_) => Err(Error::invalid_file(
                "read_all_sync only supported for Parquet files",
            )),
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(_) => Err(Error::invalid_file(
                "read_all_sync only supported for Parquet files",
            )),
        }
    }

    /// Read a specific row group
    pub async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>> {
        match &self.inner {
            ReaderImpl::Parquet(r) => r.read_row_group(row_group).await,
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.read_row_group(row_group).await,
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.read_row_group(row_group).await,
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(r) => r.read_row_group(row_group).await,
        }
    }

    /// Read with column projection
    pub async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>> {
        match &self.inner {
            ReaderImpl::Parquet(r) => r.read_projection(columns).await,
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.read_projection(columns).await,
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.read_projection(columns).await,
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(r) => r.read_projection(columns).await,
        }
    }

    /// Stream batches (for large files)
    pub fn stream(&self) -> RecordBatchStream<'_> {
        RecordBatchStream {
            reader: self,
            current_row_group: 0,
            current_batch: 0,
            batches: None,
        }
    }

    /// Get statistics from the file for query optimization
    ///
    /// Returns file-level and column-level statistics including:
    /// - Number of rows
    /// - Total byte size
    /// - Per-column min/max values, null counts, distinct counts
    ///
    /// Statistics availability varies by format:
    /// - **Parquet**: Full statistics from metadata
    /// - **Vortex**: Basic schema-level stats (full stats coming soon)
    /// - **Lance**: Basic schema-level stats (full stats coming soon)
    pub fn statistics(&self) -> Option<crate::stats::Statistics> {
        match &self.inner {
            ReaderImpl::Parquet(r) => r.statistics(),
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.statistics(),
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.statistics(),
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(_) => None,
        }
    }

    /// Get partition information for distributed execution
    ///
    /// Returns partition boundaries that can be used to parallelize
    /// reading across multiple workers in distributed systems like
    /// Spark, Trino, or DataFusion.
    ///
    /// Partition granularity varies by format:
    /// - **Parquet**: One partition per row group
    /// - **Vortex**: Single partition (Vortex manages chunking internally)
    /// - **Lance**: One partition per fragment
    pub fn partitions(&self) -> Result<Vec<crate::partition::Partition>> {
        match &self.inner {
            ReaderImpl::Parquet(r) => r.partitions(),
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.partitions(),
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.partitions(),
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(_) => Ok(vec![]),
        }
    }

    /// Push a filter down to the underlying reader
    ///
    /// This enables predicate pushdown, allowing the reader to skip
    /// data that doesn't match the filter. This can significantly
    /// improve read performance for selective queries.
    ///
    /// Filter pushdown support varies by format:
    /// - **Vortex**: Full support - translates to native Vortex expressions
    /// - **Lance**: Full support - translates to SQL filter strings
    /// - **Parquet**: Basic support - filter stored but not yet applied during read
    ///
    /// Returns `FilterPushdownResult` indicating whether the filter was pushed:
    /// - `Pushed`: Filter fully pushed to native reader
    /// - `Partial`: Some parts pushed, remainder must be applied post-read
    /// - `NotPushed`: Filter must be applied entirely post-read
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use rosetta::expr::{col, lit};
    ///
    /// let mut reader = UnifiedReader::open("data.vortex").await?;
    /// let result = reader.push_filter(&col("age").gt(lit(30)))?;
    ///
    /// if result.is_pushed() {
    ///     println!("Filter will be applied during read!");
    /// }
    ///
    /// let batches = reader.read_all().await?;
    /// ```
    pub fn push_filter(
        &mut self,
        filter: &crate::expr::Expr,
    ) -> Result<crate::expr::FilterPushdownResult> {
        match &mut self.inner {
            ReaderImpl::Parquet(r) => r.push_filter(filter),
            #[cfg(feature = "vortex-reader")]
            ReaderImpl::Vortex(r) => r.push_filter(filter),
            #[cfg(feature = "lance-reader")]
            ReaderImpl::Lance(r) => r.push_filter(filter),
            #[cfg(feature = "wasm-runtime")]
            ReaderImpl::F3(_) => Ok(crate::expr::FilterPushdownResult::NotPushed(Box::new(
                filter.clone(),
            ))),
        }
    }
}

/// Stream of RecordBatches for memory-efficient reading
pub struct RecordBatchStream<'a> {
    reader: &'a UnifiedReader,
    current_row_group: usize,
    current_batch: usize,
    /// Cached batches wrapped in Arc for cheap cloning
    batches: Option<Vec<Arc<RecordBatch>>>,
}

impl<'a> RecordBatchStream<'a> {
    /// Get the next batch
    ///
    /// Returns an `Arc<RecordBatch>` for zero-copy access. If you need ownership,
    /// use `Arc::try_unwrap()` or `Arc::make_mut()`.
    pub async fn next(&mut self) -> Result<Option<Arc<RecordBatch>>> {
        loop {
            // If we have cached batches, return the next one
            if let Some(ref batches) = self.batches {
                if self.current_batch < batches.len() {
                    let batch = batches[self.current_batch].clone(); // Arc clone is O(1)
                    self.current_batch += 1;
                    return Ok(Some(batch));
                }
            }

            // Need to load next row group
            if self.current_row_group >= self.reader.num_row_groups() {
                return Ok(None);
            }

            let batches = self.reader.read_row_group(self.current_row_group).await?;
            self.current_row_group += 1;
            self.current_batch = 0;
            // Wrap in Arc for cheap cloning
            self.batches = Some(batches.into_iter().map(Arc::new).collect());
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Int32Array, StringArray};
    use arrow::datatypes::{DataType, Field, Schema};
    use parquet::arrow::ArrowWriter;
    use std::sync::Arc;
    use tempfile::NamedTempFile;

    fn create_test_parquet() -> NamedTempFile {
        let file = NamedTempFile::new().unwrap();

        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("value", DataType::Utf8, true),
        ]));

        let ids = Int32Array::from(vec![1, 2, 3]);
        let values = StringArray::from(vec![Some("a"), Some("b"), Some("c")]);

        let batch =
            RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(values)]).unwrap();

        let file_writer = std::fs::File::create(file.path()).unwrap();
        let mut writer = ArrowWriter::try_new(file_writer, schema, None).unwrap();
        writer.write(&batch).unwrap();
        writer.close().unwrap();

        file
    }

    #[tokio::test]
    async fn test_unified_reader_auto_detect() {
        let file = create_test_parquet();
        let reader = UnifiedReader::open(file.path()).await.unwrap();

        assert!(matches!(
            reader.format(),
            FileFormat::ParquetV1 | FileFormat::ParquetV2
        ));
        assert_eq!(reader.schema().fields().len(), 2);
    }

    #[tokio::test]
    async fn test_unified_reader_with_options() {
        let file = create_test_parquet();

        let options = ReadOptions::new()
            .with_columns(vec!["id".to_string()])
            .with_batch_size(1024);

        let reader = UnifiedReader::open_with_options(file.path(), options)
            .await
            .unwrap();

        let batches = reader.read_all().await.unwrap();
        assert_eq!(batches[0].num_columns(), 1);
    }

    #[tokio::test]
    async fn test_stream_reading() {
        let file = create_test_parquet();
        let reader = UnifiedReader::open(file.path()).await.unwrap();

        let mut stream = reader.stream();
        let mut total_rows = 0;

        while let Some(batch) = stream.next().await.unwrap() {
            total_rows += batch.num_rows();
        }

        assert_eq!(total_rows, 3);
    }
}
