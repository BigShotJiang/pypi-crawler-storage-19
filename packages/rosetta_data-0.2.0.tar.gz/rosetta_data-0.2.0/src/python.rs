// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Python bindings for Rosetta using PyO3
//!
//! Provides a simple Python API for reading columnar file formats.
//!
//! # Performance Optimization
//!
//! For local Vortex files, we use a completely synchronous path that bypasses
//! the Tokio runtime entirely. This achieves near-native performance by:
//! - Using Vortex's `open_blocking()` which has its own internal dispatcher
//! - Using synchronous `scan()` and `into_record_batch_reader()` APIs
//! - Skipping format detection for `.vortex` extension
//!
//! For S3/GCS paths or other formats, we use a global lazy-initialized runtime
//! to avoid the 10-15ms overhead of creating a new runtime per call.

use crate::expr::Expr;
use crate::partition::Partition;
use crate::stats::{ScalarValue, Statistics};
use crate::{FileFormat, FormatDetector, ReadOptions, UnifiedReader};
use arrow::pyarrow::ToPyArrow;
use arrow::record_batch::RecordBatch;
use once_cell::sync::Lazy;
use pyo3::exceptions::{PyIOError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::PyList;
use std::path::Path;
use tokio::runtime::Runtime;

#[cfg(feature = "vortex-reader")]
use crate::readers::{vortex_dtype_to_arrow_schema as vortex_schema_convert, VortexReader};

/// Global lazy-initialized Tokio runtime
///
/// This is created ONCE on first use and reused for all subsequent calls.
/// Saves 10-15ms per call compared to creating a new runtime each time.
static RUNTIME: Lazy<Runtime> =
    Lazy::new(|| Runtime::new().expect("Failed to create Tokio runtime"));

/// Convert our error type to PyErr (basic, without path context)
fn to_py_err(e: crate::Error) -> PyErr {
    crate::python_errors::to_rich_py_err(e, None)
}

/// Convert our error type to PyErr with path context for better error messages
fn to_py_err_with_path(e: crate::Error, path: &str) -> PyErr {
    crate::python_errors::to_rich_py_err(e, Some(path))
}

/// Check if path has a Vortex extension
fn is_vortex_extension(path: &str) -> bool {
    let p = Path::new(path);
    matches!(
        p.extension().and_then(|e| e.to_str()),
        Some("vortex") | Some("vtx")
    )
}

/// Python wrapper for FileFormat enum
#[pyclass(name = "FileFormat")]
#[derive(Clone)]
pub struct PyFileFormat {
    inner: FileFormat,
}

#[pymethods]
impl PyFileFormat {
    /// Get the format name
    #[getter]
    fn name(&self) -> &str {
        self.inner.name()
    }

    /// Get the file extension
    #[getter]
    fn extension(&self) -> &str {
        self.inner.extension()
    }

    /// Check if format requires WASM runtime
    #[getter]
    fn requires_wasm(&self) -> bool {
        self.inner.requires_wasm()
    }

    fn __repr__(&self) -> String {
        format!("FileFormat({})", self.inner.name())
    }

    fn __str__(&self) -> &str {
        self.inner.name()
    }
}

/// Python wrapper for filter expressions
///
/// Expressions can be built using helper functions like `col()` and `lit()`,
/// then combined with comparison and logical operators.
///
/// # Example
///
/// ```python
/// from rosetta import col, lit
///
/// # Create filter: age > 30 AND status = 'active'
/// filter = col("age").gt(lit(30)).and_(col("status").eq(lit("active")))
/// data = rosetta.read("data.parquet", filter=filter)
/// ```
#[pyclass(name = "Expr")]
#[derive(Clone)]
pub struct PyExpr {
    inner: Expr,
}

#[pymethods]
impl PyExpr {
    /// Create an equality comparison (=)
    fn eq(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().eq(other.inner.clone()),
        }
    }

    /// Create a not-equal comparison (!=)
    fn not_eq(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().not_eq(other.inner.clone()),
        }
    }

    /// Create a less-than comparison (<)
    fn lt(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().lt(other.inner.clone()),
        }
    }

    /// Create a less-than-or-equal comparison (<=)
    fn lt_eq(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().lt_eq(other.inner.clone()),
        }
    }

    /// Create a greater-than comparison (>)
    fn gt(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().gt(other.inner.clone()),
        }
    }

    /// Create a greater-than-or-equal comparison (>=)
    fn gt_eq(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().gt_eq(other.inner.clone()),
        }
    }

    /// Create a logical AND
    #[pyo3(name = "and_")]
    fn and_expr(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().and(other.inner.clone()),
        }
    }

    /// Create a logical OR
    #[pyo3(name = "or_")]
    fn or_expr(&self, other: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().or(other.inner.clone()),
        }
    }

    /// Create a logical NOT
    #[pyo3(name = "not_")]
    fn not_expr(&self) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().not(),
        }
    }

    /// Create an IS NULL check
    fn is_null(&self) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().is_null(),
        }
    }

    /// Create an IS NOT NULL check
    fn is_not_null(&self) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().is_not_null(),
        }
    }

    /// Create a BETWEEN check (inclusive)
    fn between(&self, low: &PyExpr, high: &PyExpr) -> PyExpr {
        PyExpr {
            inner: self
                .inner
                .clone()
                .between(low.inner.clone(), high.inner.clone()),
        }
    }

    /// Create a LIKE pattern match
    fn like(&self, pattern: &str) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().like(pattern),
        }
    }

    /// Create an ILIKE (case-insensitive) pattern match
    fn ilike(&self, pattern: &str) -> PyExpr {
        PyExpr {
            inner: self.inner.clone().ilike(pattern),
        }
    }

    /// Convert expression to SQL string representation
    fn to_sql(&self) -> String {
        self.inner.to_sql()
    }

    /// Get all column names referenced in this expression
    fn columns(&self) -> Vec<String> {
        self.inner.columns()
    }

    fn __repr__(&self) -> String {
        format!("Expr({})", self.inner.to_sql())
    }

    fn __str__(&self) -> String {
        self.inner.to_sql()
    }
}

/// Create a column reference expression
#[pyfunction]
fn col(name: &str) -> PyExpr {
    PyExpr {
        inner: Expr::column(name),
    }
}

/// Create a literal value expression
///
/// Supports: bool, int, float, str, None
#[pyfunction]
fn lit(py: Python<'_>, value: PyObject) -> PyResult<PyExpr> {
    let scalar = python_to_scalar(py, &value)?;
    Ok(PyExpr {
        inner: Expr::literal(scalar),
    })
}

/// Convert a Python value to a ScalarValue
fn python_to_scalar(py: Python<'_>, value: &PyObject) -> PyResult<ScalarValue> {
    // Check for None first
    if value.is_none(py) {
        return Ok(ScalarValue::Null);
    }

    // Try bool first (before int, since bool is subclass of int in Python)
    if let Ok(b) = value.extract::<bool>(py) {
        return Ok(ScalarValue::Boolean(b));
    }

    // Try int
    if let Ok(i) = value.extract::<i64>(py) {
        return Ok(ScalarValue::Int64(i));
    }

    // Try float
    if let Ok(f) = value.extract::<f64>(py) {
        return Ok(ScalarValue::Float64(f));
    }

    // Try string
    if let Ok(s) = value.extract::<String>(py) {
        return Ok(ScalarValue::Utf8(s));
    }

    // Try bytes
    if let Ok(b) = value.extract::<Vec<u8>>(py) {
        return Ok(ScalarValue::Binary(b));
    }

    Err(PyValueError::new_err(format!(
        "Unsupported literal type: {:?}",
        value.bind(py).get_type().name()
    )))
}

/// Convert ScalarValue to Python object
fn scalar_to_python(py: Python<'_>, scalar: &ScalarValue) -> PyResult<PyObject> {
    match scalar {
        ScalarValue::Null => Ok(py.None()),
        ScalarValue::Boolean(v) => Ok(v.into_pyobject(py)?.to_owned().into_any().unbind()),
        ScalarValue::Int8(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Int16(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Int32(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Int64(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::UInt8(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::UInt16(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::UInt32(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::UInt64(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Float32(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Float64(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Utf8(v) | ScalarValue::LargeUtf8(v) => {
            Ok(v.into_pyobject(py)?.into_any().unbind())
        }
        ScalarValue::Binary(v) | ScalarValue::LargeBinary(v) => {
            Ok(v.into_pyobject(py)?.into_any().unbind())
        }
        ScalarValue::Date32(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Date64(v) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::TimestampMicrosecond(v, _)
        | ScalarValue::TimestampNanosecond(v, _)
        | ScalarValue::TimestampMillisecond(v, _)
        | ScalarValue::TimestampSecond(v, _) => Ok(v.into_pyobject(py)?.into_any().unbind()),
        ScalarValue::Decimal128(v, _, _) => Ok(v.into_pyobject(py)?.into_any().unbind()),
    }
}

/// Python wrapper for column statistics
#[pyclass(name = "ColumnStatistics")]
#[derive(Clone)]
pub struct PyColumnStatistics {
    /// Number of null values
    #[pyo3(get)]
    pub null_count: Option<usize>,
    /// Number of distinct values
    #[pyo3(get)]
    pub distinct_count: Option<usize>,
    /// Minimum value (as Python object)
    min_value: Option<ScalarValue>,
    /// Maximum value (as Python object)
    max_value: Option<ScalarValue>,
}

#[pymethods]
impl PyColumnStatistics {
    #[getter]
    fn min_value(&self, py: Python<'_>) -> PyResult<PyObject> {
        match &self.min_value {
            Some(v) => scalar_to_python(py, v),
            None => Ok(py.None()),
        }
    }

    #[getter]
    fn max_value(&self, py: Python<'_>) -> PyResult<PyObject> {
        match &self.max_value {
            Some(v) => scalar_to_python(py, v),
            None => Ok(py.None()),
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "ColumnStatistics(null_count={:?}, distinct_count={:?}, min={:?}, max={:?})",
            self.null_count, self.distinct_count, self.min_value, self.max_value
        )
    }
}

/// Python wrapper for file statistics
#[pyclass(name = "Statistics")]
#[derive(Clone)]
pub struct PyStatistics {
    /// Total number of rows
    #[pyo3(get)]
    pub num_rows: Option<usize>,
    /// Total byte size
    #[pyo3(get)]
    pub total_byte_size: Option<usize>,
    /// Per-column statistics
    column_statistics: std::collections::HashMap<String, PyColumnStatistics>,
}

#[pymethods]
impl PyStatistics {
    /// Get statistics for a specific column
    fn column(&self, name: &str) -> Option<PyColumnStatistics> {
        self.column_statistics.get(name).cloned()
    }

    /// Get all column names with statistics
    fn column_names(&self) -> Vec<String> {
        self.column_statistics.keys().cloned().collect()
    }

    fn __repr__(&self) -> String {
        format!(
            "Statistics(num_rows={:?}, total_byte_size={:?}, columns={})",
            self.num_rows,
            self.total_byte_size,
            self.column_statistics.len()
        )
    }
}

impl From<Statistics> for PyStatistics {
    fn from(stats: Statistics) -> Self {
        let column_statistics = stats
            .column_statistics
            .into_iter()
            .map(|(name, col_stats)| {
                (
                    name,
                    PyColumnStatistics {
                        null_count: col_stats.null_count,
                        distinct_count: col_stats.distinct_count,
                        min_value: col_stats.min_value,
                        max_value: col_stats.max_value,
                    },
                )
            })
            .collect();

        PyStatistics {
            num_rows: stats.num_rows,
            total_byte_size: stats.total_byte_size,
            column_statistics,
        }
    }
}

/// Python wrapper for partition information
#[pyclass(name = "Partition")]
#[derive(Clone)]
pub struct PyPartition {
    /// Partition identifier
    #[pyo3(get)]
    pub id: usize,
    /// File path or URL
    #[pyo3(get)]
    pub location: String,
    /// Estimated row count
    #[pyo3(get)]
    pub row_count: Option<usize>,
    /// Estimated byte size
    #[pyo3(get)]
    pub byte_size: Option<usize>,
    /// Row group indices (if applicable)
    #[pyo3(get)]
    pub row_groups: Option<Vec<usize>>,
}

#[pymethods]
impl PyPartition {
    /// Check if this is a whole-file partition
    fn is_whole_file(&self) -> bool {
        self.row_groups.is_none()
    }

    fn __repr__(&self) -> String {
        format!(
            "Partition(id={}, location='{}', row_count={:?}, byte_size={:?})",
            self.id, self.location, self.row_count, self.byte_size
        )
    }
}

impl From<Partition> for PyPartition {
    fn from(p: Partition) -> Self {
        PyPartition {
            id: p.id,
            location: p.location,
            row_count: p.row_count,
            byte_size: p.byte_size,
            row_groups: p.row_groups,
        }
    }
}

/// Detect the format of a file
#[pyfunction]
#[pyo3(signature = (path))]
fn detect_format(_py: Python<'_>, path: &str) -> PyResult<PyFileFormat> {
    // Fast path: skip detection for known extensions
    if is_vortex_extension(path) {
        return Ok(PyFileFormat {
            inner: FileFormat::Vortex,
        });
    }

    // Use global runtime for format detection
    let format = RUNTIME
        .block_on(async {
            let detector = FormatDetector::new();
            detector.detect_file(path).await
        })
        .map_err(|e| to_py_err_with_path(e, path))?;

    Ok(PyFileFormat { inner: format })
}

/// Check if a path is a URL (s3://, gs://, etc.)
fn is_url(path: &str) -> bool {
    path.starts_with("s3://") || path.starts_with("gs://") || path.starts_with("az://")
}

/// Read a columnar file and return PyArrow Table
///
/// Args:
///     path: Path to the file (local path or S3/GCS URL)
///     columns: Optional list of column names to read (column projection)
///     filter: Optional filter expression for predicate pushdown
///
/// Returns:
///     PyArrow Table containing the data
///
/// # Performance
///
/// For local Vortex files, this uses a completely synchronous path that
/// achieves near-native performance (no Tokio runtime overhead).
///
/// # Example
///
/// ```python
/// import rosetta
///
/// # Read with filter pushdown
/// table = rosetta.read("data.parquet", filter=rosetta.col("age") > rosetta.lit(30))
///
/// # Read with projection and filter
/// table = rosetta.read("data.vortex",
///     columns=["name", "age"],
///     filter=rosetta.col("age").between(rosetta.lit(18), rosetta.lit(65)))
/// ```
#[pyfunction]
#[pyo3(signature = (path, columns=None, filter=None))]
fn read(
    py: Python<'_>,
    path: &str,
    columns: Option<Vec<String>>,
    filter: Option<&PyExpr>,
) -> PyResult<PyObject> {
    // FAST PATH: Local Vortex files - completely synchronous, no runtime needed!
    #[cfg(feature = "vortex-reader")]
    if !is_url(path) && is_vortex_extension(path) {
        return read_vortex_sync(py, path, columns, filter);
    }

    // Standard path: use global runtime for S3/GCS or other formats
    let batches = RUNTIME
        .block_on(async {
            let mut options = ReadOptions::new();
            if let Some(cols) = columns {
                options = options.with_columns(cols);
            }

            // Use URL reader for S3/GCS paths, file reader for local paths
            let mut reader = if is_url(path) {
                UnifiedReader::open_url_with_options(path, options).await?
            } else {
                UnifiedReader::open_with_options(path, options).await?
            };

            // Apply filter pushdown if provided
            if let Some(f) = filter {
                let _ = reader.push_filter(&f.inner)?;
            }

            reader.read_all().await
        })
        .map_err(|e| to_py_err_with_path(e, path))?;

    // Convert to PyArrow
    batches_to_pyarrow(py, batches)
}

/// Ultra-minimal synchronous fast path for local Vortex files
///
/// This uses vortex APIs directly with minimal abstraction:
/// - `VortexOpenOptions::file().open_blocking()` - Vortex's native blocking open
/// - `file.scan().into_record_batch_reader()` - direct to Arrow
/// - FFI transfer to PyArrow (zero-copy!)
#[cfg(feature = "vortex-reader")]
fn read_vortex_sync(
    py: Python<'_>,
    path: &str,
    columns: Option<Vec<String>>,
    filter: Option<&PyExpr>,
) -> PyResult<PyObject> {
    use arrow::pyarrow::IntoPyArrow;
    use arrow::record_batch::RecordBatchReader;
    use std::sync::Arc;
    use vortex::file::VortexOpenOptions;

    // Open directly using vortex's blocking API - minimal overhead
    let file = VortexOpenOptions::file()
        .open_blocking(path)
        .map_err(|e| PyIOError::new_err(format!("Failed to open Vortex file: {}", e)))?;

    // Get Arrow schema from vortex dtype - use shared conversion function
    let vortex_dtype = file.dtype();
    let arrow_schema = vortex_schema_convert(vortex_dtype)
        .map_err(|e| PyIOError::new_err(format!("Failed to convert schema: {}", e)))?;
    let arrow_schema = Arc::new(arrow_schema);

    // Convert filter to Vortex expression if provided
    let vortex_filter = filter.and_then(|f| f.inner.to_vortex_expr());

    // Create RecordBatchReader
    let batch_reader: Box<dyn RecordBatchReader + Send> = match columns {
        Some(cols) => {
            use vortex::dtype::FieldName;
            use vortex::expr::{root, select};

            // Find column indices for projected schema
            let indices: Vec<usize> = cols
                .iter()
                .map(|name| {
                    arrow_schema
                        .index_of(name)
                        .map_err(|_| PyValueError::new_err(format!("Column not found: {}", name)))
                })
                .collect::<PyResult<Vec<_>>>()?;

            let projected_fields: Vec<_> = indices
                .iter()
                .map(|&i| arrow_schema.field(i).clone())
                .collect();
            let projected_schema = Arc::new(arrow::datatypes::Schema::new(projected_fields));

            let field_names: Vec<FieldName> = cols.iter().map(|c| c.as_str().into()).collect();

            let mut scanner = file
                .scan()
                .map_err(|e| PyIOError::new_err(format!("Failed to create scanner: {}", e)))?
                .with_projection(select(field_names, root()));

            // Apply filter if provided
            if let Some(vx_filter) = vortex_filter {
                scanner = scanner.with_filter(vx_filter);
            }

            let rb_reader = scanner
                .into_record_batch_reader(projected_schema)
                .map_err(|e| PyIOError::new_err(format!("Failed to create reader: {}", e)))?;

            Box::new(rb_reader)
        }
        None => {
            let mut scanner = file
                .scan()
                .map_err(|e| PyIOError::new_err(format!("Failed to create scanner: {}", e)))?;

            // Apply filter if provided
            if let Some(vx_filter) = vortex_filter {
                scanner = scanner.with_filter(vx_filter);
            }

            let rb_reader = scanner
                .into_record_batch_reader(arrow_schema)
                .map_err(|e| PyIOError::new_err(format!("Failed to create reader: {}", e)))?;

            Box::new(rb_reader)
        }
    };

    // Convert RecordBatchReader to PyArrow via FFI (zero-copy!)
    let py_reader = batch_reader.into_pyarrow(py)?;

    // Call read_all() on the Python side to get a Table
    let table = py_reader.call_method0(py, "read_all")?;

    Ok(table)
}

/// Read a columnar file and return a list of PyArrow RecordBatches
///
/// Args:
///     path: Path to the file (local path or S3/GCS URL)
///     columns: Optional list of column names to read
///     filter: Optional filter expression for predicate pushdown
///
/// Returns:
///     List of PyArrow RecordBatches
#[pyfunction]
#[pyo3(signature = (path, columns=None, filter=None))]
fn read_batches(
    py: Python<'_>,
    path: &str,
    columns: Option<Vec<String>>,
    filter: Option<&PyExpr>,
) -> PyResult<PyObject> {
    // FAST PATH: Local Vortex files - completely synchronous
    #[cfg(feature = "vortex-reader")]
    if !is_url(path) && is_vortex_extension(path) {
        // Use the sync Vortex path with filter support
        return read_vortex_sync_batches(py, path, columns, filter);
    }

    // Standard path: use global runtime
    let batches = RUNTIME
        .block_on(async {
            let mut options = ReadOptions::new();
            if let Some(cols) = columns {
                options = options.with_columns(cols);
            }

            // Use URL reader for S3/GCS paths, file reader for local paths
            let mut reader = if is_url(path) {
                UnifiedReader::open_url_with_options(path, options).await?
            } else {
                UnifiedReader::open_with_options(path, options).await?
            };

            // Apply filter pushdown if provided
            if let Some(f) = filter {
                let _ = reader.push_filter(&f.inner)?;
            }

            reader.read_all().await
        })
        .map_err(|e| to_py_err_with_path(e, path))?;

    // Convert each batch to PyArrow RecordBatch
    let py_batches: Vec<PyObject> = batches
        .into_iter()
        .map(|batch| batch.to_pyarrow(py))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| PyValueError::new_err(e.to_string()))?;

    Ok(PyList::new(py, py_batches)?.into())
}

/// Sync path for reading Vortex files to batches with filter support
#[cfg(feature = "vortex-reader")]
fn read_vortex_sync_batches(
    py: Python<'_>,
    path: &str,
    columns: Option<Vec<String>>,
    filter: Option<&PyExpr>,
) -> PyResult<PyObject> {
    use arrow::pyarrow::ToPyArrow;
    use std::sync::Arc;
    use vortex::file::VortexOpenOptions;

    // Open directly using vortex's blocking API
    let file = VortexOpenOptions::file()
        .open_blocking(path)
        .map_err(|e| PyIOError::new_err(format!("Failed to open Vortex file: {}", e)))?;

    // Get Arrow schema from vortex dtype
    let vortex_dtype = file.dtype();
    let arrow_schema = vortex_schema_convert(vortex_dtype)
        .map_err(|e| PyIOError::new_err(format!("Failed to convert schema: {}", e)))?;
    let arrow_schema = Arc::new(arrow_schema);

    // Convert filter to Vortex expression if provided
    let vortex_filter = filter.and_then(|f| f.inner.to_vortex_expr());

    // Create scanner with projection and filter
    let (schema_for_reader, mut scanner) = match columns {
        Some(cols) => {
            use vortex::dtype::FieldName;
            use vortex::expr::{root, select};

            // Find column indices for projected schema
            let indices: Vec<usize> = cols
                .iter()
                .map(|name| {
                    arrow_schema
                        .index_of(name)
                        .map_err(|_| PyValueError::new_err(format!("Column not found: {}", name)))
                })
                .collect::<PyResult<Vec<_>>>()?;

            let projected_fields: Vec<_> = indices
                .iter()
                .map(|&i| arrow_schema.field(i).clone())
                .collect();
            let projected_schema = Arc::new(arrow::datatypes::Schema::new(projected_fields));

            let field_names: Vec<FieldName> = cols.iter().map(|c| c.as_str().into()).collect();

            let scanner = file
                .scan()
                .map_err(|e| PyIOError::new_err(format!("Failed to create scanner: {}", e)))?
                .with_projection(select(field_names, root()));

            (projected_schema, scanner)
        }
        None => {
            let scanner = file
                .scan()
                .map_err(|e| PyIOError::new_err(format!("Failed to create scanner: {}", e)))?;

            (arrow_schema, scanner)
        }
    };

    // Apply filter if provided
    if let Some(vx_filter) = vortex_filter {
        scanner = scanner.with_filter(vx_filter);
    }

    let rb_reader = scanner
        .into_record_batch_reader(schema_for_reader)
        .map_err(|e| PyIOError::new_err(format!("Failed to create reader: {}", e)))?;

    // Collect batches
    let batches: Vec<_> = rb_reader
        .into_iter()
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| PyIOError::new_err(format!("Failed to read batches: {}", e)))?;

    let py_batches: Vec<PyObject> = batches
        .into_iter()
        .map(|batch| batch.to_pyarrow(py))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| PyValueError::new_err(e.to_string()))?;

    Ok(PyList::new(py, py_batches)?.into())
}

/// Get file information (schema, row groups, format)
#[pyfunction]
#[pyo3(signature = (path))]
fn file_info(py: Python<'_>, path: &str) -> PyResult<PyObject> {
    // FAST PATH: Local Vortex files - completely synchronous
    #[cfg(feature = "vortex-reader")]
    if !is_url(path) && is_vortex_extension(path) {
        let reader = VortexReader::open_sync(path).map_err(to_py_err)?;

        let dict = pyo3::types::PyDict::new(py);
        dict.set_item(
            "format",
            PyFileFormat {
                inner: FileFormat::Vortex,
            }
            .into_pyobject(py)?,
        )?;
        dict.set_item("num_row_groups", 1)?; // Vortex manages chunking internally

        let py_schema = reader
            .schema
            .to_pyarrow(py)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        dict.set_item("schema", py_schema)?;

        return Ok(dict.into());
    }

    // Standard path: use global runtime
    let (format, schema, num_row_groups) = RUNTIME
        .block_on(async {
            let reader = UnifiedReader::open(path).await?;
            Ok::<_, crate::Error>((reader.format(), reader.schema(), reader.num_row_groups()))
        })
        .map_err(|e| to_py_err_with_path(e, path))?;

    // Build a dict with file info
    let dict = pyo3::types::PyDict::new(py);
    dict.set_item("format", PyFileFormat { inner: format }.into_pyobject(py)?)?;
    dict.set_item("num_row_groups", num_row_groups)?;

    // Convert schema to PyArrow schema
    let py_schema = schema
        .to_pyarrow(py)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    dict.set_item("schema", py_schema)?;

    Ok(dict.into())
}

/// Get statistics for query optimization
///
/// Returns statistics about the file including row counts, byte sizes,
/// and per-column min/max values and null counts.
///
/// Args:
///     path: Path to the file (local path or S3/GCS URL)
///
/// Returns:
///     Statistics object with file and column-level statistics
#[pyfunction]
#[pyo3(signature = (path))]
fn statistics(_py: Python<'_>, path: &str) -> PyResult<Option<PyStatistics>> {
    // FAST PATH: Local Vortex files - completely synchronous
    #[cfg(feature = "vortex-reader")]
    if !is_url(path) && is_vortex_extension(path) {
        let reader = VortexReader::open_sync(path).map_err(to_py_err)?;
        return Ok(reader.statistics().map(PyStatistics::from));
    }

    // Standard path: use global runtime
    let stats = RUNTIME
        .block_on(async {
            let reader = UnifiedReader::open(path).await?;
            Ok::<_, crate::Error>(reader.statistics())
        })
        .map_err(|e| to_py_err_with_path(e, path))?;

    Ok(stats.map(PyStatistics::from))
}

/// Get partition information for distributed execution
///
/// Returns a list of partitions that can be used to split work across
/// multiple workers in a distributed query engine.
///
/// Args:
///     path: Path to the file (local path or S3/GCS URL)
///
/// Returns:
///     List of Partition objects
#[pyfunction]
#[pyo3(signature = (path))]
fn partitions(_py: Python<'_>, path: &str) -> PyResult<Vec<PyPartition>> {
    // FAST PATH: Local Vortex files - completely synchronous
    #[cfg(feature = "vortex-reader")]
    if !is_url(path) && is_vortex_extension(path) {
        let reader = VortexReader::open_sync(path).map_err(to_py_err)?;
        let parts = reader.partitions().map_err(to_py_err)?;
        return Ok(parts.into_iter().map(PyPartition::from).collect());
    }

    // Standard path: use global runtime
    let parts = RUNTIME
        .block_on(async {
            let reader = UnifiedReader::open(path).await?;
            reader.partitions()
        })
        .map_err(|e| to_py_err_with_path(e, path))?;

    Ok(parts.into_iter().map(PyPartition::from).collect())
}

/// Convert RecordBatches to a PyArrow Table
fn batches_to_pyarrow(py: Python<'_>, batches: Vec<RecordBatch>) -> PyResult<PyObject> {
    if batches.is_empty() {
        return Err(PyValueError::new_err("No data in file"));
    }

    // Import pyarrow
    let pyarrow = py.import("pyarrow")?;
    let table_class = pyarrow.getattr("Table")?;

    // Convert batches to PyArrow
    let py_batches: Vec<PyObject> = batches
        .into_iter()
        .map(|batch| batch.to_pyarrow(py))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| PyValueError::new_err(e.to_string()))?;

    // Create table from batches
    let table = table_class.call_method1("from_batches", (py_batches,))?;

    Ok(table.into())
}

/// Rosetta Python module (Rust extension)
///
/// This is the core Rust extension. The Python wrapper in python/rosetta/__init__.py
/// re-exports these functions and adds additional Python-level functionality.
#[pymodule]
pub fn rosetta(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Classes
    m.add_class::<PyFileFormat>()?;
    m.add_class::<PyExpr>()?;
    m.add_class::<PyStatistics>()?;
    m.add_class::<PyColumnStatistics>()?;
    m.add_class::<PyPartition>()?;

    // Core reading functions
    m.add_function(wrap_pyfunction!(detect_format, m)?)?;
    m.add_function(wrap_pyfunction!(read, m)?)?;
    m.add_function(wrap_pyfunction!(read_batches, m)?)?;
    m.add_function(wrap_pyfunction!(file_info, m)?)?;

    // Statistics and partitions
    m.add_function(wrap_pyfunction!(statistics, m)?)?;
    m.add_function(wrap_pyfunction!(partitions, m)?)?;

    // Expression builders
    m.add_function(wrap_pyfunction!(col, m)?)?;
    m.add_function(wrap_pyfunction!(lit, m)?)?;

    // Add version
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_file_format_wrapper() {
        let fmt = PyFileFormat {
            inner: FileFormat::ParquetV1,
        };
        assert_eq!(fmt.name(), "Parquet v1");
        assert_eq!(fmt.extension(), "parquet");
        assert!(!fmt.requires_wasm());
    }
}
