// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Partition support for distributed execution
//!
//! This module provides partition information that enables distributed query
//! engines (Spark, Trino, DataFusion) to split work across multiple executors.
//!
//! # Partition Types
//!
//! - **File-level partitions**: Each file is a separate partition
//! - **Row group partitions**: Each Parquet row group is a partition
//! - **Byte range partitions**: Split large files by byte offsets
//!
//! # Example
//!
//! ```rust,ignore
//! use rosetta::Partition;
//!
//! let reader = UnifiedReader::open("data.parquet").await?;
//! let partitions = reader.partitions()?;
//!
//! // Distribute partitions across workers
//! for partition in partitions {
//!     let data = reader.read_partition(&partition).await?;
//!     // Process data...
//! }
//! ```

use std::ops::Range;

/// A partition of data that can be read independently
///
/// Partitions enable distributed execution by allowing query engines
/// to assign different partitions to different workers.
#[derive(Debug, Clone, PartialEq)]
pub struct Partition {
    /// Unique partition identifier (0-indexed)
    pub id: usize,

    /// File path or URL containing this partition's data
    pub location: String,

    /// Byte range within the file (for sub-file partitioning)
    ///
    /// If None, the entire file is the partition.
    pub byte_range: Option<Range<usize>>,

    /// Row group indices (for Parquet/Vortex)
    ///
    /// If None, read all row groups at the location.
    pub row_groups: Option<Vec<usize>>,

    /// Estimated row count in this partition
    pub row_count: Option<usize>,

    /// Estimated byte size of this partition
    pub byte_size: Option<usize>,

    /// Partition values (for Hive-style partitioning)
    ///
    /// Maps partition column names to their values for this partition.
    pub partition_values: Option<Vec<(String, String)>>,
}

impl Partition {
    /// Create a new partition for a file
    pub fn file(id: usize, location: impl Into<String>) -> Self {
        Self {
            id,
            location: location.into(),
            byte_range: None,
            row_groups: None,
            row_count: None,
            byte_size: None,
            partition_values: None,
        }
    }

    /// Create a partition for specific row groups
    pub fn row_groups(id: usize, location: impl Into<String>, row_groups: Vec<usize>) -> Self {
        Self {
            id,
            location: location.into(),
            byte_range: None,
            row_groups: Some(row_groups),
            row_count: None,
            byte_size: None,
            partition_values: None,
        }
    }

    /// Create a partition for a byte range
    pub fn byte_range(id: usize, location: impl Into<String>, range: Range<usize>) -> Self {
        Self {
            id,
            location: location.into(),
            byte_range: Some(range),
            row_groups: None,
            row_count: None,
            byte_size: None,
            partition_values: None,
        }
    }

    /// Set estimated row count
    pub fn with_row_count(mut self, count: usize) -> Self {
        self.row_count = Some(count);
        self
    }

    /// Set estimated byte size
    pub fn with_byte_size(mut self, size: usize) -> Self {
        self.byte_size = Some(size);
        self
    }

    /// Set partition values (for Hive partitioning)
    pub fn with_partition_values(mut self, values: Vec<(String, String)>) -> Self {
        self.partition_values = Some(values);
        self
    }

    /// Check if this is a whole-file partition
    pub fn is_whole_file(&self) -> bool {
        self.byte_range.is_none() && self.row_groups.is_none()
    }

    /// Get the number of row groups (if specified)
    pub fn num_row_groups(&self) -> Option<usize> {
        self.row_groups.as_ref().map(|rg| rg.len())
    }
}

/// Strategy for partitioning data
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum PartitionStrategy {
    /// One partition per file
    PerFile,
    /// One partition per row group
    #[default]
    PerRowGroup,
    /// Split into approximately N partitions
    Target(usize),
    /// Split by approximate byte size
    BySize(usize),
}

/// Builder for creating partitions from file metadata
pub struct PartitionBuilder {
    strategy: PartitionStrategy,
    next_id: usize,
}

impl PartitionBuilder {
    /// Create a new partition builder
    pub fn new(strategy: PartitionStrategy) -> Self {
        Self {
            strategy,
            next_id: 0,
        }
    }

    /// Build partitions for a single file with row group info
    pub fn build_for_file(
        &mut self,
        location: impl Into<String>,
        num_row_groups: usize,
        row_group_sizes: Option<&[usize]>,
        row_group_byte_sizes: Option<&[usize]>,
    ) -> Vec<Partition> {
        let location = location.into();

        match self.strategy {
            PartitionStrategy::PerFile => {
                let total_rows = row_group_sizes.map(|s| s.iter().sum());
                let total_bytes = row_group_byte_sizes.map(|s| s.iter().sum());

                let mut partition = Partition::file(self.next_id, location);
                if let Some(rows) = total_rows {
                    partition = partition.with_row_count(rows);
                }
                if let Some(bytes) = total_bytes {
                    partition = partition.with_byte_size(bytes);
                }
                self.next_id += 1;
                vec![partition]
            }

            PartitionStrategy::PerRowGroup => {
                let mut partitions = Vec::with_capacity(num_row_groups);
                for rg in 0..num_row_groups {
                    let mut partition =
                        Partition::row_groups(self.next_id, location.clone(), vec![rg]);

                    if let Some(sizes) = row_group_sizes {
                        if rg < sizes.len() {
                            partition = partition.with_row_count(sizes[rg]);
                        }
                    }
                    if let Some(byte_sizes) = row_group_byte_sizes {
                        if rg < byte_sizes.len() {
                            partition = partition.with_byte_size(byte_sizes[rg]);
                        }
                    }

                    partitions.push(partition);
                    self.next_id += 1;
                }
                partitions
            }

            PartitionStrategy::Target(target) => {
                if num_row_groups <= target {
                    // Fewer row groups than target - use per-row-group
                    return self.build_for_file(
                        location,
                        num_row_groups,
                        row_group_sizes,
                        row_group_byte_sizes,
                    );
                }

                // Group row groups to hit target partition count
                let groups_per_partition = num_row_groups.div_ceil(target);
                let mut partitions = Vec::new();

                for chunk_start in (0..num_row_groups).step_by(groups_per_partition) {
                    let chunk_end = (chunk_start + groups_per_partition).min(num_row_groups);
                    let row_groups: Vec<usize> = (chunk_start..chunk_end).collect();

                    let mut partition =
                        Partition::row_groups(self.next_id, location.clone(), row_groups.clone());

                    if let Some(sizes) = row_group_sizes {
                        let total: usize = row_groups
                            .iter()
                            .filter(|&&rg| rg < sizes.len())
                            .map(|&rg| sizes[rg])
                            .sum();
                        partition = partition.with_row_count(total);
                    }
                    if let Some(byte_sizes) = row_group_byte_sizes {
                        let total: usize = row_groups
                            .iter()
                            .filter(|&&rg| rg < byte_sizes.len())
                            .map(|&rg| byte_sizes[rg])
                            .sum();
                        partition = partition.with_byte_size(total);
                    }

                    partitions.push(partition);
                    self.next_id += 1;
                }
                partitions
            }

            PartitionStrategy::BySize(target_size) => {
                let byte_sizes = match row_group_byte_sizes {
                    Some(sizes) => sizes,
                    None => {
                        // Fall back to per-row-group if no size info
                        return self.build_for_file(
                            location,
                            num_row_groups,
                            row_group_sizes,
                            None,
                        );
                    }
                };

                let mut partitions = Vec::new();
                let mut current_groups = Vec::new();
                let mut current_size = 0usize;
                let mut current_rows = 0usize;

                for rg in 0..num_row_groups {
                    let rg_size = byte_sizes.get(rg).copied().unwrap_or(0);
                    let rg_rows = row_group_sizes
                        .and_then(|s| s.get(rg).copied())
                        .unwrap_or(0);

                    // Start a new partition if current would exceed target
                    if !current_groups.is_empty() && current_size + rg_size > target_size {
                        let mut partition = Partition::row_groups(
                            self.next_id,
                            location.clone(),
                            current_groups.clone(),
                        );
                        partition = partition.with_byte_size(current_size);
                        if row_group_sizes.is_some() {
                            partition = partition.with_row_count(current_rows);
                        }
                        partitions.push(partition);
                        self.next_id += 1;

                        current_groups.clear();
                        current_size = 0;
                        current_rows = 0;
                    }

                    current_groups.push(rg);
                    current_size += rg_size;
                    current_rows += rg_rows;
                }

                // Don't forget the last partition
                if !current_groups.is_empty() {
                    let mut partition =
                        Partition::row_groups(self.next_id, location, current_groups);
                    partition = partition.with_byte_size(current_size);
                    if row_group_sizes.is_some() {
                        partition = partition.with_row_count(current_rows);
                    }
                    partitions.push(partition);
                    self.next_id += 1;
                }

                partitions
            }
        }
    }

    /// Build a single partition for a format that doesn't support row groups
    pub fn build_single(&mut self, location: impl Into<String>) -> Partition {
        let partition = Partition::file(self.next_id, location);
        self.next_id += 1;
        partition
    }
}

impl Default for PartitionBuilder {
    fn default() -> Self {
        Self::new(PartitionStrategy::default())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_partition_file() {
        let partition = Partition::file(0, "s3://bucket/data.parquet")
            .with_row_count(1000)
            .with_byte_size(50000);

        assert_eq!(partition.id, 0);
        assert_eq!(partition.location, "s3://bucket/data.parquet");
        assert!(partition.is_whole_file());
        assert_eq!(partition.row_count, Some(1000));
        assert_eq!(partition.byte_size, Some(50000));
    }

    #[test]
    fn test_partition_row_groups() {
        let partition = Partition::row_groups(1, "data.parquet", vec![0, 1, 2]);

        assert_eq!(partition.id, 1);
        assert!(!partition.is_whole_file());
        assert_eq!(partition.num_row_groups(), Some(3));
        assert_eq!(partition.row_groups, Some(vec![0, 1, 2]));
    }

    #[test]
    fn test_partition_builder_per_file() {
        let mut builder = PartitionBuilder::new(PartitionStrategy::PerFile);
        let partitions =
            builder.build_for_file("data.parquet", 10, Some(&[100; 10]), Some(&[1000; 10]));

        assert_eq!(partitions.len(), 1);
        assert_eq!(partitions[0].row_count, Some(1000));
        assert_eq!(partitions[0].byte_size, Some(10000));
    }

    #[test]
    fn test_partition_builder_per_row_group() {
        let mut builder = PartitionBuilder::new(PartitionStrategy::PerRowGroup);
        let partitions = builder.build_for_file(
            "data.parquet",
            4,
            Some(&[100, 200, 150, 250]),
            Some(&[1000, 2000, 1500, 2500]),
        );

        assert_eq!(partitions.len(), 4);
        assert_eq!(partitions[0].row_count, Some(100));
        assert_eq!(partitions[1].row_count, Some(200));
        assert_eq!(partitions[2].row_count, Some(150));
        assert_eq!(partitions[3].row_count, Some(250));
    }

    #[test]
    fn test_partition_builder_target() {
        let mut builder = PartitionBuilder::new(PartitionStrategy::Target(2));
        let partitions = builder.build_for_file("data.parquet", 6, None, None);

        // 6 row groups split into ~2 partitions = 3 row groups each
        assert_eq!(partitions.len(), 2);
        assert_eq!(partitions[0].row_groups, Some(vec![0, 1, 2]));
        assert_eq!(partitions[1].row_groups, Some(vec![3, 4, 5]));
    }

    #[test]
    fn test_partition_builder_by_size() {
        let mut builder = PartitionBuilder::new(PartitionStrategy::BySize(3000));
        let partitions = builder.build_for_file(
            "data.parquet",
            5,
            Some(&[100, 100, 100, 100, 100]),
            Some(&[1000, 1000, 1000, 1000, 1000]),
        );

        // Each partition should be ~3000 bytes (3 row groups)
        assert_eq!(partitions.len(), 2);
        assert_eq!(partitions[0].row_groups, Some(vec![0, 1, 2]));
        assert_eq!(partitions[0].byte_size, Some(3000));
        assert_eq!(partitions[1].row_groups, Some(vec![3, 4]));
        assert_eq!(partitions[1].byte_size, Some(2000));
    }

    #[test]
    fn test_partition_values() {
        let partition = Partition::file(0, "data/year=2024/month=01/data.parquet")
            .with_partition_values(vec![
                ("year".to_string(), "2024".to_string()),
                ("month".to_string(), "01".to_string()),
            ]);

        assert_eq!(
            partition.partition_values,
            Some(vec![
                ("year".to_string(), "2024".to_string()),
                ("month".to_string(), "01".to_string()),
            ])
        );
    }
}
