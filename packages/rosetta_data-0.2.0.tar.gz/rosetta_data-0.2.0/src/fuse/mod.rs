// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! FUSE filesystem for transparent format transcoding
//!
//! This module provides a FUSE filesystem that presents any supported
//! columnar format as Parquet v1 files. Mount it and any app reads Parquet!
//!
//! # How It Works
//!
//! ```text
//! /mnt/rosetta/                    (FUSE mount point)
//!     └── data.vortex              (appears as Parquet to readers)
//!
//! App: open("/mnt/rosetta/data.vortex")
//!        │
//!        ▼
//! ┌─────────────────┐
//! │  RosettaFS      │  Intercepts read()
//! └─────────────────┘
//!        │
//!        │ Read actual Vortex file
//!        ▼
//! ┌─────────────────┐
//! │   Transcoder    │  Vortex → Arrow → Parquet v1
//! └─────────────────┘
//!        │
//!        ▼
//! App receives Parquet bytes (no code changes!)
//! ```
//!
//! # Usage
//!
//! ```bash
//! rosetta mount /data/lake /mnt/rosetta
//!
//! # Now any app can read:
//! pandas.read_parquet("/mnt/rosetta/data.vortex")  # Works!
//! spark.read.parquet("/mnt/rosetta/data.lance")    # Works!
//! ```

mod filesystem;

pub use filesystem::{RosettaFs, RosettaFsConfig};
