// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! FUSE filesystem implementation using fuser crate
//!
//! Note: Requires `fuse-reader` feature and libfuse installed on the system.
//! On macOS, use macFUSE. On Linux, use fuse3.

use bytes::Bytes;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::SystemTime;
use tokio::runtime::Runtime;
use tokio::sync::RwLock;
use tracing::{debug, info};

use crate::transcoder::Transcoder;
use crate::writers::ParquetWriterOptions;
use crate::{Error, Result};

/// Configuration for the FUSE filesystem
#[derive(Debug, Clone)]
pub struct RosettaFsConfig {
    /// Source directory containing actual files
    pub source_dir: PathBuf,
    /// Mount point for the FUSE filesystem
    pub mount_point: PathBuf,
    /// Cache transcoded files
    pub enable_cache: bool,
    /// Max cache size in bytes
    pub max_cache_bytes: usize,
    /// Parquet writer options
    pub writer_options: ParquetWriterOptions,
    /// File extensions to transcode (others pass through)
    pub transcode_extensions: Vec<String>,
}

impl Default for RosettaFsConfig {
    fn default() -> Self {
        Self {
            source_dir: PathBuf::from("."),
            mount_point: PathBuf::from("/mnt/rosetta"),
            enable_cache: true,
            max_cache_bytes: 2 * 1024 * 1024 * 1024, // 2GB
            writer_options: ParquetWriterOptions::max_compatibility(),
            transcode_extensions: vec!["vortex".to_string(), "lance".to_string(), "f3".to_string()],
        }
    }
}

impl RosettaFsConfig {
    /// Create a new config with source and mount paths
    pub fn new(source: PathBuf, mount: PathBuf) -> Self {
        Self {
            source_dir: source,
            mount_point: mount,
            ..Default::default()
        }
    }
}

/// Cache entry for transcoded files
struct CacheEntry {
    data: Bytes,
    mtime: SystemTime,
    size: usize,
}

/// FUSE filesystem that transcodes files on read
pub struct RosettaFs {
    config: RosettaFsConfig,
    cache: Arc<RwLock<HashMap<PathBuf, CacheEntry>>>,
    cache_size: Arc<RwLock<usize>>,
    runtime: Arc<Runtime>,
    transcoder: Transcoder,
}

impl RosettaFs {
    /// Create a new RosettaFs instance
    pub fn new(config: RosettaFsConfig) -> Result<Self> {
        let runtime = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(4)
            .enable_all()
            .build()
            .map_err(|e| Error::io_error(format!("Failed to create runtime: {}", e)))?;

        let transcoder = Transcoder::new().with_writer_options(config.writer_options.clone());

        Ok(Self {
            config,
            cache: Arc::new(RwLock::new(HashMap::new())),
            cache_size: Arc::new(RwLock::new(0)),
            runtime: Arc::new(runtime),
            transcoder,
        })
    }

    /// Mount the filesystem (blocking)
    pub fn mount(self) -> Result<()> {
        info!(
            source = %self.config.source_dir.display(),
            mount = %self.config.mount_point.display(),
            "Mounting RosettaFS"
        );

        // Create mount point if needed
        std::fs::create_dir_all(&self.config.mount_point)
            .map_err(|e| Error::io_error(format!("Failed to create mount point: {}", e)))?;

        #[cfg(feature = "fuse-reader")]
        {
            use fuser::MountOption;
            let options = vec![
                MountOption::RO,
                MountOption::FSName("rosetta".to_string()),
                MountOption::AutoUnmount,
                MountOption::AllowOther,
            ];

            // Clone mount_point before moving self
            let mount_point = self.config.mount_point.clone();
            fuser::mount2(self, &mount_point, &options)
                .map_err(|e| Error::io_error(format!("Mount failed: {}", e)))?;

            Ok(())
        }

        #[cfg(not(feature = "fuse-reader"))]
        {
            Err(Error::unsupported_format("FUSE", "fuse-reader"))
        }
    }

    /// Check if a path should be transcoded
    fn should_transcode(&self, path: &Path) -> bool {
        if let Some(ext) = path.extension() {
            let ext_str = ext.to_string_lossy().to_lowercase();
            self.config.transcode_extensions.contains(&ext_str)
        } else {
            false
        }
    }

    /// Get the real path for a virtual path
    fn real_path(&self, path: &Path) -> PathBuf {
        self.config
            .source_dir
            .join(path.strip_prefix("/").unwrap_or(path))
    }

    /// Read and transcode a file
    fn read_transcoded(&self, path: &Path) -> Result<Bytes> {
        let real_path = self.real_path(path);

        // Check cache
        if self.config.enable_cache {
            let cache = self.runtime.block_on(self.cache.read());
            if let Some(entry) = cache.get(&real_path) {
                // Check if source file changed
                if let Ok(meta) = std::fs::metadata(&real_path) {
                    if let Ok(mtime) = meta.modified() {
                        if mtime <= entry.mtime {
                            debug!(?path, "Cache hit");
                            return Ok(entry.data.clone());
                        }
                    }
                }
            }
        }

        // Transcode
        debug!(?real_path, "Transcoding file");
        let result = self
            .runtime
            .block_on(self.transcoder.transcode_file(&real_path))?;
        let data = result.bytes.clone();

        // Cache result
        if self.config.enable_cache {
            let mut cache = self.runtime.block_on(self.cache.write());
            let mut cache_size = self.runtime.block_on(self.cache_size.write());

            // Evict if necessary
            while *cache_size + data.len() > self.config.max_cache_bytes {
                if let Some(oldest) = cache.keys().next().cloned() {
                    if let Some(entry) = cache.remove(&oldest) {
                        *cache_size -= entry.size;
                    }
                } else {
                    break;
                }
            }

            let mtime = std::fs::metadata(&real_path)
                .and_then(|m| m.modified())
                .unwrap_or(SystemTime::now());

            *cache_size += data.len();
            cache.insert(
                real_path,
                CacheEntry {
                    data: data.clone(),
                    mtime,
                    size: data.len(),
                },
            );
        }

        Ok(data)
    }

    /// Read a file directly (passthrough)
    fn read_passthrough(&self, path: &Path) -> Result<Bytes> {
        let real_path = self.real_path(path);
        let data = std::fs::read(&real_path)
            .map_err(|e| Error::io_error(format!("Read failed: {}", e)))?;
        Ok(Bytes::from(data))
    }
}

// FUSE trait implementation (when feature enabled)
#[cfg(feature = "fuse-reader")]
impl fuser::Filesystem for RosettaFs {
    fn lookup(
        &mut self,
        _req: &fuser::Request<'_>,
        parent: u64,
        name: &OsStr,
        reply: fuser::ReplyEntry,
    ) {
        // Simplified: assume parent is root (inode 1)
        let path = if parent == 1 {
            PathBuf::from("/").join(name)
        } else {
            // Would need inode-to-path mapping for full impl
            reply.error(libc::ENOENT);
            return;
        };

        let real_path = self.real_path(&path);

        match std::fs::metadata(&real_path) {
            Ok(meta) => {
                let attr = self.meta_to_attr(&meta, 2); // Use inode 2 for now
                reply.entry(&Duration::from_secs(1), &attr, 0);
            }
            Err(_) => reply.error(libc::ENOENT),
        }
    }

    fn getattr(&mut self, _req: &fuser::Request<'_>, ino: u64, reply: fuser::ReplyAttr) {
        if ino == 1 {
            // Root directory
            let attr = fuser::FileAttr {
                ino: 1,
                size: 0,
                blocks: 0,
                atime: UNIX_EPOCH,
                mtime: UNIX_EPOCH,
                ctime: UNIX_EPOCH,
                crtime: UNIX_EPOCH,
                kind: fuser::FileType::Directory,
                perm: 0o755,
                nlink: 2,
                uid: 0,
                gid: 0,
                rdev: 0,
                blksize: 512,
                flags: 0,
            };
            reply.attr(&Duration::from_secs(1), &attr);
        } else {
            reply.error(libc::ENOENT);
        }
    }

    fn read(
        &mut self,
        _req: &fuser::Request<'_>,
        ino: u64,
        _fh: u64,
        offset: i64,
        size: u32,
        _flags: i32,
        _lock_owner: Option<u64>,
        reply: fuser::ReplyData,
    ) {
        // Would need inode-to-path mapping
        // For now, this is a simplified implementation
        reply.error(libc::ENOENT);
    }

    fn readdir(
        &mut self,
        _req: &fuser::Request<'_>,
        ino: u64,
        _fh: u64,
        offset: i64,
        mut reply: fuser::ReplyDirectory,
    ) {
        if ino != 1 {
            reply.error(libc::ENOENT);
            return;
        }

        let entries = vec![
            (1, fuser::FileType::Directory, "."),
            (1, fuser::FileType::Directory, ".."),
        ];

        // Add files from source directory
        if let Ok(read_dir) = std::fs::read_dir(&self.config.source_dir) {
            let mut inode = 2u64;
            for entry in read_dir.flatten() {
                let name = entry.file_name();
                let file_type = if entry.path().is_dir() {
                    fuser::FileType::Directory
                } else {
                    fuser::FileType::RegularFile
                };

                if (inode as i64) > offset {
                    let name_str = name.to_string_lossy();
                    if reply.add(inode, inode as i64, file_type, name_str.as_ref()) {
                        break;
                    }
                }
                inode += 1;
            }
        }

        reply.ok();
    }
}

#[cfg(feature = "fuse-reader")]
impl RosettaFs {
    fn meta_to_attr(&self, meta: &std::fs::Metadata, ino: u64) -> fuser::FileAttr {
        let kind = if meta.is_dir() {
            fuser::FileType::Directory
        } else {
            fuser::FileType::RegularFile
        };

        fuser::FileAttr {
            ino,
            size: meta.len(),
            blocks: (meta.len() + 511) / 512,
            atime: meta.accessed().unwrap_or(UNIX_EPOCH),
            mtime: meta.modified().unwrap_or(UNIX_EPOCH),
            ctime: meta.modified().unwrap_or(UNIX_EPOCH),
            crtime: UNIX_EPOCH,
            kind,
            perm: 0o644,
            nlink: 1,
            uid: 0,
            gid: 0,
            rdev: 0,
            blksize: 512,
            flags: 0,
        }
    }
}

// Stub implementations when FUSE is not available
#[cfg(not(feature = "fuse-reader"))]
impl RosettaFs {
    /// Get transcoded content for a file (API for non-FUSE use)
    pub fn get_content(&self, path: &Path) -> Result<Bytes> {
        if self.should_transcode(path) {
            self.read_transcoded(path)
        } else {
            self.read_passthrough(path)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn test_config_default() {
        let config = RosettaFsConfig::default();
        assert!(config.enable_cache);
        assert!(config.transcode_extensions.contains(&"vortex".to_string()));
    }

    #[test]
    fn test_should_transcode() {
        let temp = TempDir::new().unwrap();
        let config = RosettaFsConfig::new(temp.path().to_path_buf(), PathBuf::from("/mnt/test"));
        let fs = RosettaFs::new(config).unwrap();

        assert!(fs.should_transcode(Path::new("data.vortex")));
        assert!(fs.should_transcode(Path::new("data.lance")));
        assert!(!fs.should_transcode(Path::new("data.parquet")));
        assert!(!fs.should_transcode(Path::new("data.csv")));
    }

    #[test]
    fn test_real_path() {
        let config =
            RosettaFsConfig::new(PathBuf::from("/data/lake"), PathBuf::from("/mnt/rosetta"));
        let fs = RosettaFs::new(config).unwrap();

        assert_eq!(
            fs.real_path(Path::new("/subdir/file.vortex")),
            PathBuf::from("/data/lake/subdir/file.vortex")
        );
    }
}
