// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Rich, user-friendly error messages for Python bindings
//!
//! This module transforms cryptic Rust errors into helpful, actionable messages
//! that guide users toward fixing the problem.

use pyo3::exceptions::{PyFileNotFoundError, PyIOError, PyValueError};
use pyo3::PyErr;
use std::path::Path;

/// Convert a Rosetta error to a rich, helpful Python exception
pub fn to_rich_py_err(e: crate::Error, path: Option<&str>) -> PyErr {
    match &e {
        crate::Error::Io(io_err) => io_error_to_py(io_err, path),
        crate::Error::UnknownFormat { path: p } => unknown_format_error(p),
        crate::Error::UnsupportedFormat { format, feature } => {
            unsupported_format_error(format, feature)
        }
        crate::Error::ColumnNotFound { column } => column_not_found_error(column, path),
        crate::Error::FormatDetectionFailed { path: p } => format_detection_error(p),
        crate::Error::InvalidFile { message } => invalid_file_error(message, path),
        crate::Error::ObjectStore(os_err) => object_store_error(os_err, path),
        _ => PyIOError::new_err(format!("{}", e)),
    }
}

/// Rich error for IO errors (file not found, permission denied, etc.)
fn io_error_to_py(io_err: &std::io::Error, path: Option<&str>) -> PyErr {
    use std::io::ErrorKind;

    let path_str = path.unwrap_or("<unknown>");

    match io_err.kind() {
        ErrorKind::NotFound => {
            let mut msg = format!(
                "File not found: '{}'\n\n",
                path_str
            );

            // Try to suggest similar files
            if let Some(p) = path {
                if let Some(suggestions) = find_similar_files(p) {
                    msg.push_str("Did you mean one of these?\n");
                    for suggestion in suggestions.iter().take(3) {
                        msg.push_str(&format!("  - {}\n", suggestion));
                    }
                    msg.push('\n');
                }
            }

            msg.push_str("Hint: Check that the file path is correct and the file exists.\n");
            msg.push_str("      Use an absolute path to avoid working directory issues.");

            PyFileNotFoundError::new_err(msg)
        }
        ErrorKind::PermissionDenied => {
            let msg = format!(
                "Permission denied: '{}'\n\n\
                 Hint: Check file permissions with 'ls -la {}'\n\
                       You may need to run 'chmod +r {}' to make it readable.",
                path_str, path_str, path_str
            );
            PyIOError::new_err(msg)
        }
        ErrorKind::InvalidData => {
            let msg = format!(
                "Invalid data in file: '{}'\n\n\
                 The file appears to be corrupted or not in a supported format.\n\n\
                 Hint: Try detecting the format first:\n\
                       >>> rosetta.detect_format('{}')",
                path_str, path_str
            );
            PyIOError::new_err(msg)
        }
        _ => {
            let msg = format!(
                "IO error reading '{}': {}\n\n\
                 Hint: Check that the file exists and is readable.",
                path_str, io_err
            );
            PyIOError::new_err(msg)
        }
    }
}

/// Rich error for unknown file format
fn unknown_format_error(path: &Path) -> PyErr {
    let path_str = path.display();
    let extension = path
        .extension()
        .and_then(|e| e.to_str())
        .unwrap_or("(none)");

    let msg = format!(
        "Unknown file format: '{}'\n\n\
         Extension '.{}' is not recognized.\n\n\
         Supported formats:\n\
         - .parquet, .pq  → Parquet (v1 and v2)\n\
         - .vortex, .vtx  → Vortex columnar format\n\
         - .lance         → Lance dataset (or directory with _versions/)\n\n\
         Hint: If this is a valid format, try specifying it explicitly:\n\
               >>> rosetta.read('{}', format='parquet')",
        path_str, extension, path_str
    );
    PyValueError::new_err(msg)
}

/// Rich error for unsupported format (feature not enabled)
fn unsupported_format_error(format: &str, feature: &str) -> PyErr {
    let msg = format!(
        "Format '{}' is not available\n\n\
         The '{}' feature was not enabled when this package was built.\n\n\
         If you installed from PyPI:\n\
         - The pre-built wheels should include all formats\n\
         - Try upgrading: pip install --upgrade rosetta\n\n\
         If you built from source:\n\
         - Rebuild with: maturin develop --features \"python,{}\"\n\n\
         Hint: Check which formats are available:\n\
               >>> import rosetta\n\
               >>> print(rosetta.__version__)",
        format, feature, feature
    );
    PyValueError::new_err(msg)
}

/// Rich error for column not found
fn column_not_found_error(column: &str, path: Option<&str>) -> PyErr {
    let path_hint = path
        .map(|p| {
            format!(
                "\nHint: Check available columns with:\n\
                       >>> info = rosetta.file_info('{}')\n\
                       >>> print(info['schema'])",
                p
            )
        })
        .unwrap_or_default();

    let msg = format!(
        "Column not found: '{}'\n\n\
         The requested column does not exist in the file schema.{}",
        column, path_hint
    );
    PyValueError::new_err(msg)
}

/// Rich error for format detection failure
fn format_detection_error(path: &Path) -> PyErr {
    let path_str = path.display();

    let msg = format!(
        "Could not detect file format: '{}'\n\n\
         Failed to read the file's magic bytes for format detection.\n\n\
         Possible causes:\n\
         - File is empty\n\
         - File is too small (less than 4 bytes)\n\
         - File is not a supported columnar format\n\n\
         Hint: Check if the file is valid:\n\
               >>> import os\n\
               >>> os.path.getsize('{}')",
        path_str, path_str
    );
    PyIOError::new_err(msg)
}

/// Rich error for invalid file
fn invalid_file_error(message: &str, path: Option<&str>) -> PyErr {
    let path_info = path
        .map(|p| format!(" ({})", p))
        .unwrap_or_default();

    let msg = format!(
        "Invalid file{}: {}\n\n\
         The file appears to be corrupted or in an unexpected format.\n\n\
         Hint: Try opening the file with the native library to get more details:\n\
               >>> import pyarrow.parquet as pq\n\
               >>> pq.read_table('your_file.parquet')  # For Parquet files",
        path_info, message
    );
    PyValueError::new_err(msg)
}

/// Rich error for object store (S3, GCS, Azure) errors
fn object_store_error(err: &object_store::Error, path: Option<&str>) -> PyErr {
    let path_str = path.unwrap_or("<unknown>");

    // Try to provide specific guidance based on error type
    let (title, hints) = match err {
        object_store::Error::NotFound { .. } => (
            "Object not found",
            "Hint: Check that the bucket and key are correct.\n\
                   Verify the object exists: aws s3 ls <path>",
        ),
        object_store::Error::Generic { source, .. } => {
            let source_str = source.to_string().to_lowercase();
            if source_str.contains("credential") || source_str.contains("access denied") {
                (
                    "Authentication failed",
                    "Hint: Check your credentials are configured:\n\
                           - AWS: Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY\n\
                           - GCS: Set GOOGLE_APPLICATION_CREDENTIALS\n\
                           - Or use: aws configure",
                )
            } else if source_str.contains("timeout") || source_str.contains("connect") {
                (
                    "Connection failed",
                    "Hint: Check your network connection and endpoint URL.\n\
                           For VPC endpoints, ensure proper routing.",
                )
            } else {
                ("Object store error", "Hint: Check your cloud provider configuration.")
            }
        }
        _ => ("Object store error", "Hint: Check your cloud configuration and credentials."),
    };

    let msg = format!(
        "{}: '{}'\n\n\
         {}\n\n\
         {}",
        title, path_str, err, hints
    );
    PyIOError::new_err(msg)
}

/// Find similar files in the same directory (for "did you mean?" suggestions)
fn find_similar_files(path: &str) -> Option<Vec<String>> {
    let path = Path::new(path);

    // Get the parent directory
    let parent = path.parent()?;
    let filename = path.file_name()?.to_str()?;

    // If parent doesn't exist, try current directory
    let search_dir = if parent.exists() {
        parent.to_path_buf()
    } else if Path::new(".").exists() {
        Path::new(".").to_path_buf()
    } else {
        return None;
    };

    // Read directory entries
    let entries: Vec<_> = std::fs::read_dir(&search_dir)
        .ok()?
        .filter_map(|e| e.ok())
        .filter_map(|e| {
            let name = e.file_name().to_str()?.to_string();
            // Only suggest files with similar extensions
            if is_columnar_file(&name) {
                Some(if parent.as_os_str().is_empty() || parent == Path::new(".") {
                    name
                } else {
                    parent.join(&name).display().to_string()
                })
            } else {
                None
            }
        })
        .collect();

    // Sort by similarity to the requested filename
    let mut scored: Vec<_> = entries
        .into_iter()
        .map(|f| {
            let score = string_similarity(filename, Path::new(&f).file_name().and_then(|n| n.to_str()).unwrap_or(""));
            (f, score)
        })
        .filter(|(_, score)| *score > 0.3) // Only suggest reasonably similar files
        .collect();

    scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

    let suggestions: Vec<_> = scored.into_iter().map(|(f, _)| f).take(5).collect();

    if suggestions.is_empty() {
        None
    } else {
        Some(suggestions)
    }
}

/// Check if a filename looks like a columnar data file
fn is_columnar_file(name: &str) -> bool {
    let lower = name.to_lowercase();
    lower.ends_with(".parquet")
        || lower.ends_with(".pq")
        || lower.ends_with(".vortex")
        || lower.ends_with(".vtx")
        || lower.ends_with(".lance")
        || lower.ends_with(".arrow")
        || lower.ends_with(".feather")
        || lower.ends_with(".ipc")
}

/// Simple string similarity score (Jaccard-like on character bigrams)
fn string_similarity(a: &str, b: &str) -> f64 {
    if a.is_empty() || b.is_empty() {
        return 0.0;
    }

    let a_lower = a.to_lowercase();
    let b_lower = b.to_lowercase();

    let a_bigrams: std::collections::HashSet<_> = a_lower
        .chars()
        .collect::<Vec<_>>()
        .windows(2)
        .map(|w| (w[0], w[1]))
        .collect();

    let b_bigrams: std::collections::HashSet<_> = b_lower
        .chars()
        .collect::<Vec<_>>()
        .windows(2)
        .map(|w| (w[0], w[1]))
        .collect();

    if a_bigrams.is_empty() || b_bigrams.is_empty() {
        // Fall back to exact prefix match for short strings
        if a_lower.starts_with(&b_lower) || b_lower.starts_with(&a_lower) {
            return 0.8;
        }
        return 0.0;
    }

    let intersection = a_bigrams.intersection(&b_bigrams).count();
    let union = a_bigrams.union(&b_bigrams).count();

    intersection as f64 / union as f64
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_string_similarity() {
        assert!(string_similarity("data.parquet", "data.parquet") > 0.99);
        assert!(string_similarity("data.parquet", "data2.parquet") > 0.7);
        assert!(string_similarity("data.parquet", "completely_different.csv") < 0.3);
    }

    #[test]
    fn test_is_columnar_file() {
        assert!(is_columnar_file("data.parquet"));
        assert!(is_columnar_file("DATA.PARQUET"));
        assert!(is_columnar_file("file.vortex"));
        assert!(!is_columnar_file("file.csv"));
        assert!(!is_columnar_file("file.txt"));
    }
}
