// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! File format detection via magic numbers and file structure
//!
//! Supports detection of:
//! - Apache Parquet (PAR1 magic)
//! - Vortex (VTX magic + edition info)
//! - Lance (manifest structure)
//! - F3 (F3 magic + embedded WASM)

use crate::{Error, Result};
use std::path::Path;
use tokio::fs::File;
use tokio::io::{AsyncReadExt, AsyncSeekExt, SeekFrom};
use tracing::{debug, instrument};

/// Known columnar file formats
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum FileFormat {
    /// Apache Parquet v1 (legacy encodings only)
    ParquetV1,
    /// Apache Parquet v2 (includes newer encodings like DELTA_BINARY_PACKED)
    ParquetV2,
    /// Vortex columnar format (from SpiralDB/Linux Foundation)
    Vortex,
    /// Lance format (from LanceDB)
    Lance,
    /// F3 format with embedded WASM decoders (from CMU)
    F3,
    /// FastLanes format (from CWI)
    FastLanes,
}

impl FileFormat {
    /// Get the typical file extension for this format
    pub fn extension(&self) -> &'static str {
        match self {
            Self::ParquetV1 | Self::ParquetV2 => "parquet",
            Self::Vortex => "vortex",
            Self::Lance => "lance",
            Self::F3 => "f3",
            Self::FastLanes => "fastlanes",
        }
    }

    /// Get a human-readable name for this format
    pub fn name(&self) -> &'static str {
        match self {
            Self::ParquetV1 => "Parquet v1",
            Self::ParquetV2 => "Parquet v2",
            Self::Vortex => "Vortex",
            Self::Lance => "Lance",
            Self::F3 => "F3",
            Self::FastLanes => "FastLanes",
        }
    }

    /// Check if this format requires WASM runtime for decoding
    pub fn requires_wasm(&self) -> bool {
        matches!(self, Self::F3)
    }
}

impl std::fmt::Display for FileFormat {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.name())
    }
}

/// Magic bytes for format detection
mod magic {
    /// Parquet magic: "PAR1" at start and end of file
    pub const PARQUET: &[u8] = b"PAR1";

    /// Vortex magic: "VTXF" at start and end of file (vortex 0.50+)
    pub const VORTEX: &[u8] = b"VTXF";

    /// Lance manifest marker (placeholder)
    pub const LANCE: &[u8] = b"LANC";

    /// F3 magic with version
    pub const F3: &[u8] = b"F3\x00\x01";

    /// FastLanes magic (placeholder)
    pub const FASTLANES: &[u8] = b"FLNS";
}

/// Format detector that examines file headers/footers
pub struct FormatDetector {
    /// Buffer size for reading magic bytes
    buffer_size: usize,
}

impl Default for FormatDetector {
    fn default() -> Self {
        Self::new()
    }
}

impl FormatDetector {
    /// Create a new format detector
    pub fn new() -> Self {
        Self {
            buffer_size: 64 * 1024, // 64KB default for footer reading
        }
    }

    /// Create with custom buffer size
    pub fn with_buffer_size(mut self, size: usize) -> Self {
        self.buffer_size = size;
        self
    }

    /// Detect format from a local file path
    #[instrument(skip(self), fields(path = %path.as_ref().display()))]
    pub async fn detect_file<P: AsRef<Path>>(&self, path: P) -> Result<FileFormat> {
        let path = path.as_ref();

        // Check if path is a directory (Lance datasets are directories)
        if path.is_dir() {
            // Lance datasets have a _versions directory inside
            let versions_dir = path.join("_versions");
            if versions_dir.exists() && versions_dir.is_dir() {
                debug!("Detected Lance dataset (directory with _versions/)");
                return Ok(FileFormat::Lance);
            }

            // Also check for .lance suffix on directory name
            if path.extension().is_some_and(|ext| ext == "lance") {
                debug!("Detected Lance dataset (directory with .lance extension)");
                return Ok(FileFormat::Lance);
            }

            return Err(Error::invalid_file(format!(
                "Directory '{}' is not a recognized Lance dataset",
                path.display()
            )));
        }

        let mut file = File::open(path).await?;

        // Read header (first 8 bytes)
        let mut header = [0u8; 8];
        file.read_exact(&mut header).await?;

        // Check header-based formats first
        if let Some(format) = self.detect_from_header(&header) {
            debug!(?format, "Detected format from header");
            return Ok(format);
        }

        // For Parquet, we need to check the footer too
        let file_size = file.metadata().await?.len();
        if file_size < 12 {
            return Err(Error::invalid_file(
                "File too small to be a valid columnar format",
            ));
        }

        // Read footer (last 8 bytes for Parquet)
        file.seek(SeekFrom::End(-8)).await?;
        let mut footer = [0u8; 8];
        file.read_exact(&mut footer).await?;

        if let Some(format) = self.detect_parquet(&header, &footer, &mut file).await? {
            debug!(?format, "Detected Parquet format");
            return Ok(format);
        }

        Err(Error::unknown_format(path))
    }

    /// Detect format from raw bytes (header + optional footer)
    pub fn detect_from_bytes(&self, header: &[u8], footer: Option<&[u8]>) -> Option<FileFormat> {
        // Try header-based detection
        if let Some(format) = self.detect_from_header(header) {
            return Some(format);
        }

        // Try Parquet (needs both header and footer)
        if let Some(footer) = footer {
            if header.starts_with(magic::PARQUET) && footer.ends_with(magic::PARQUET) {
                // Default to v1 without deeper inspection
                return Some(FileFormat::ParquetV1);
            }
        }

        None
    }

    /// Detect format from header bytes only
    fn detect_from_header(&self, header: &[u8]) -> Option<FileFormat> {
        if header.starts_with(magic::VORTEX) {
            return Some(FileFormat::Vortex);
        }
        if header.starts_with(magic::LANCE) {
            return Some(FileFormat::Lance);
        }
        if header.starts_with(magic::F3) {
            return Some(FileFormat::F3);
        }
        if header.starts_with(magic::FASTLANES) {
            return Some(FileFormat::FastLanes);
        }
        None
    }

    /// Detect and distinguish Parquet v1 vs v2
    async fn detect_parquet(
        &self,
        header: &[u8],
        footer: &[u8],
        file: &mut File,
    ) -> Result<Option<FileFormat>> {
        // Parquet has "PAR1" at both start and end
        if !header.starts_with(magic::PARQUET) || !footer.ends_with(magic::PARQUET) {
            return Ok(None);
        }

        // Read the footer metadata to determine version
        // Footer structure: [metadata_length: 4 bytes][PAR1: 4 bytes]
        let metadata_len = u32::from_le_bytes([footer[0], footer[1], footer[2], footer[3]]) as i64;

        // Seek to metadata start
        file.seek(SeekFrom::End(-8 - metadata_len)).await?;

        // Read enough of the metadata to check for v2 encodings
        let read_size = std::cmp::min(metadata_len as usize, self.buffer_size);
        let mut metadata_buf = vec![0u8; read_size];
        file.read_exact(&mut metadata_buf).await?;

        // Check for v2-specific encodings in the metadata
        // V2 encodings include: DELTA_BINARY_PACKED, DELTA_LENGTH_BYTE_ARRAY,
        // DELTA_BYTE_ARRAY, BYTE_STREAM_SPLIT
        let has_v2_encodings = self.check_for_v2_encodings(&metadata_buf);

        if has_v2_encodings {
            Ok(Some(FileFormat::ParquetV2))
        } else {
            Ok(Some(FileFormat::ParquetV1))
        }
    }

    /// Check if metadata contains v2 encoding markers
    fn check_for_v2_encodings(&self, metadata: &[u8]) -> bool {
        // Parquet v2 encoding type values (from parquet-format thrift spec):
        // DELTA_BINARY_PACKED = 5
        // DELTA_LENGTH_BYTE_ARRAY = 6
        // DELTA_BYTE_ARRAY = 7
        // BYTE_STREAM_SPLIT = 9

        // This is a simplified heuristic - in production we'd parse the Thrift metadata
        // For now, we look for these encoding bytes in common positions

        // Quick heuristic: search for encoding markers
        // Real implementation would parse the FileMetaData Thrift struct
        for window in metadata.windows(2) {
            // Look for encoding field markers followed by v2 encoding values
            if window[0] == 0x05 || window[0] == 0x06 || window[0] == 0x07 || window[0] == 0x09 {
                // Could be a v2 encoding - need deeper parsing to confirm
                // For MVP, we'll be conservative and check multiple indicators
            }
        }

        // For MVP, default to v1 detection since most files are v1
        // TODO: Implement proper Thrift metadata parsing
        false
    }

    /// Detect format from object store URL
    #[instrument(skip(self))]
    pub async fn detect_url(&self, url: &str) -> Result<FileFormat> {
        use object_store::ObjectStore;

        let parsed = url::Url::parse(url)?;

        let (store, path): (Box<dyn ObjectStore>, object_store::path::Path) = match parsed.scheme()
        {
            "s3" => {
                let bucket = parsed
                    .host_str()
                    .ok_or_else(|| Error::invalid_file("Missing S3 bucket"))?;
                let key = parsed.path().trim_start_matches('/');
                let store = object_store::aws::AmazonS3Builder::from_env()
                    .with_bucket_name(bucket)
                    .build()?;
                (Box::new(store), object_store::path::Path::from(key))
            }
            "gs" => {
                let bucket = parsed
                    .host_str()
                    .ok_or_else(|| Error::invalid_file("Missing GCS bucket"))?;
                let key = parsed.path().trim_start_matches('/');
                let store = object_store::gcp::GoogleCloudStorageBuilder::from_env()
                    .with_bucket_name(bucket)
                    .build()?;
                (Box::new(store), object_store::path::Path::from(key))
            }
            "file" | "" => {
                // Local file
                return self.detect_file(parsed.path()).await;
            }
            scheme => {
                return Err(Error::invalid_file(format!(
                    "Unsupported URL scheme: {}",
                    scheme
                )));
            }
        };

        // Get file metadata for size
        let meta = store.head(&path).await?;
        let file_size = meta.size;

        // Read header
        let header_range = 0..8;
        let header_bytes = store.get_range(&path, header_range).await?;

        // Check header-based formats
        if let Some(format) = self.detect_from_header(&header_bytes) {
            return Ok(format);
        }

        // Read footer for Parquet detection
        let footer_start = file_size.saturating_sub(8);
        let footer_range = footer_start..file_size;
        let footer_bytes = store.get_range(&path, footer_range).await?;

        if let Some(format) = self.detect_from_bytes(&header_bytes, Some(&footer_bytes)) {
            return Ok(format);
        }

        Err(Error::unknown_format(url))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Int32Array, StringArray};
    use arrow::datatypes::{DataType, Field, Schema};
    use arrow::record_batch::RecordBatch;
    use parquet::arrow::ArrowWriter;
    use std::sync::Arc;
    use tempfile::NamedTempFile;
    use tokio::io::AsyncWriteExt;

    /// Create a real Parquet file for testing
    fn create_real_parquet_file() -> NamedTempFile {
        let file = NamedTempFile::new().unwrap();

        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, true),
        ]));

        let ids = Int32Array::from(vec![1, 2, 3]);
        let names = StringArray::from(vec![Some("a"), Some("b"), Some("c")]);

        let batch =
            RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

        let file_writer = std::fs::File::create(file.path()).unwrap();
        let mut writer = ArrowWriter::try_new(file_writer, schema, None).unwrap();
        writer.write(&batch).unwrap();
        writer.close().unwrap();

        file
    }

    #[tokio::test]
    async fn test_detect_real_parquet_file() {
        let file = create_real_parquet_file();
        let detector = FormatDetector::new();
        let format = detector.detect_file(file.path()).await.unwrap();
        assert!(matches!(
            format,
            FileFormat::ParquetV1 | FileFormat::ParquetV2
        ));
    }

    #[tokio::test]
    async fn test_detect_parquet_file_with_magic() {
        // Create a minimal valid Parquet file structure
        let file = NamedTempFile::new().unwrap();
        let path = file.path().to_owned();

        // Write PAR1 header + minimal content + metadata_len + PAR1 footer
        let content = b"PAR1";
        let padding = vec![0u8; 100]; // Some padding
        let metadata_len: u32 = 4;
        let footer = b"PAR1";

        let mut f = tokio::fs::File::create(&path).await.unwrap();
        f.write_all(content).await.unwrap();
        f.write_all(&padding).await.unwrap();
        f.write_all(&metadata_len.to_le_bytes()).await.unwrap();
        f.write_all(footer).await.unwrap();
        f.flush().await.unwrap();
        drop(f);

        let detector = FormatDetector::new();
        let format = detector.detect_file(&path).await.unwrap();
        assert!(matches!(
            format,
            FileFormat::ParquetV1 | FileFormat::ParquetV2
        ));
    }

    #[tokio::test]
    async fn test_detect_unknown_format() {
        let file = NamedTempFile::new().unwrap();
        let path = file.path().to_owned();

        // Write random bytes
        let mut f = tokio::fs::File::create(&path).await.unwrap();
        f.write_all(b"UNKNOWN_FORMAT_DATA_HERE_12345")
            .await
            .unwrap();
        f.flush().await.unwrap();
        drop(f);

        let detector = FormatDetector::new();
        let result = detector.detect_file(&path).await;
        assert!(result.is_err());
    }

    #[test]
    fn test_format_display() {
        assert_eq!(FileFormat::ParquetV1.name(), "Parquet v1");
        assert_eq!(FileFormat::ParquetV2.name(), "Parquet v2");
        assert_eq!(FileFormat::Vortex.name(), "Vortex");
        assert_eq!(FileFormat::Lance.name(), "Lance");
        assert_eq!(FileFormat::F3.name(), "F3");
        assert_eq!(FileFormat::FastLanes.name(), "FastLanes");
    }

    #[test]
    fn test_format_extension() {
        assert_eq!(FileFormat::ParquetV1.extension(), "parquet");
        assert_eq!(FileFormat::ParquetV2.extension(), "parquet");
        assert_eq!(FileFormat::Vortex.extension(), "vortex");
        assert_eq!(FileFormat::Lance.extension(), "lance");
    }

    #[test]
    fn test_format_requires_wasm() {
        assert!(!FileFormat::ParquetV1.requires_wasm());
        assert!(!FileFormat::ParquetV2.requires_wasm());
        assert!(!FileFormat::Vortex.requires_wasm());
        assert!(!FileFormat::Lance.requires_wasm());
        assert!(FileFormat::F3.requires_wasm());
    }

    #[test]
    fn test_detect_from_header() {
        let detector = FormatDetector::new();

        // Test Vortex detection
        let vortex_header = b"VTXF\x00\x00\x00\x00";
        assert_eq!(
            detector.detect_from_header(vortex_header),
            Some(FileFormat::Vortex)
        );

        // Test F3 detection
        let f3_header = b"F3\x00\x01\x00\x00\x00\x00";
        assert_eq!(detector.detect_from_header(f3_header), Some(FileFormat::F3));

        // Test Lance detection
        let lance_header = b"LANC\x00\x00\x00\x00";
        assert_eq!(
            detector.detect_from_header(lance_header),
            Some(FileFormat::Lance)
        );

        // Test FastLanes detection
        let fastlanes_header = b"FLNS\x00\x00\x00\x00";
        assert_eq!(
            detector.detect_from_header(fastlanes_header),
            Some(FileFormat::FastLanes)
        );

        // Test unknown
        let unknown = b"\x00\x00\x00\x00\x00\x00\x00\x00";
        assert_eq!(detector.detect_from_header(unknown), None);

        // Test Parquet header (should return None, needs footer too)
        let parquet_header = b"PAR1\x00\x00\x00\x00";
        assert_eq!(detector.detect_from_header(parquet_header), None);
    }

    #[test]
    fn test_detect_from_bytes_parquet() {
        let detector = FormatDetector::new();

        // Parquet needs both header and footer
        let header = b"PAR1\x00\x00\x00\x00";
        let footer = b"\x00\x00\x00\x00PAR1";

        let format = detector.detect_from_bytes(header, Some(footer));
        assert_eq!(format, Some(FileFormat::ParquetV1));
    }
}
