// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Writers for converting Arrow data to file format bytes
//!
//! This module provides writers that convert Arrow RecordBatches to
//! file format bytes (primarily Parquet v1 for backwards compatibility).

mod parquet_writer;

pub use parquet_writer::{ParquetWriter, ParquetWriterOptions};
