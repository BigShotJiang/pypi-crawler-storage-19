// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Parquet writer for converting Arrow RecordBatches to Parquet bytes
//!
//! This writer produces Parquet v1 compatible files that can be read by
//! any legacy Parquet reader (Spark 2.x, old Pandas, etc.).

use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;
use bytes::Bytes;
use parquet::arrow::ArrowWriter;
use parquet::basic::{Compression, Encoding};
use parquet::file::properties::{WriterProperties, WriterVersion};
use std::io::Cursor;

use crate::{Error, Result};

/// Options for Parquet writing
#[derive(Debug, Clone)]
pub struct ParquetWriterOptions {
    /// Target Parquet version (v1 for max compatibility)
    pub version: ParquetVersion,
    /// Compression codec
    pub compression: ParquetCompression,
    /// Row group size (number of rows per row group)
    pub row_group_size: usize,
    /// Data page size in bytes
    pub data_page_size: usize,
    /// Dictionary page size in bytes
    pub dictionary_page_size: usize,
    /// Enable dictionary encoding
    pub enable_dictionary: bool,
    /// Enable statistics
    pub enable_statistics: bool,
}

impl Default for ParquetWriterOptions {
    fn default() -> Self {
        Self {
            version: ParquetVersion::V1,
            compression: ParquetCompression::Snappy,
            row_group_size: 1024 * 1024,       // 1M rows
            data_page_size: 1024 * 1024,       // 1MB
            dictionary_page_size: 1024 * 1024, // 1MB
            enable_dictionary: true,
            enable_statistics: true,
        }
    }
}

impl ParquetWriterOptions {
    /// Maximum compatibility settings for legacy readers
    pub fn max_compatibility() -> Self {
        Self {
            version: ParquetVersion::V1,
            compression: ParquetCompression::Snappy, // Most widely supported
            row_group_size: 128 * 1024,              // Smaller row groups for better parallelism
            data_page_size: 1024 * 1024,
            dictionary_page_size: 1024 * 1024,
            enable_dictionary: true,
            enable_statistics: true,
        }
    }

    /// Settings optimized for compression ratio
    pub fn high_compression() -> Self {
        Self {
            version: ParquetVersion::V1,
            compression: ParquetCompression::Zstd(3),
            row_group_size: 1024 * 1024,
            data_page_size: 1024 * 1024,
            dictionary_page_size: 2 * 1024 * 1024,
            enable_dictionary: true,
            enable_statistics: true,
        }
    }
}

/// Parquet version to write
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParquetVersion {
    /// Parquet 1.0 - maximum compatibility
    V1,
    /// Parquet 2.0 - newer encodings but less compatible
    V2,
}

/// Compression codec for Parquet
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParquetCompression {
    /// No compression
    None,
    /// Snappy compression (fast, widely supported)
    Snappy,
    /// Gzip compression
    Gzip,
    /// LZ4 compression
    Lz4,
    /// Zstd compression with level
    Zstd(i32),
}

impl From<ParquetCompression> for Compression {
    fn from(c: ParquetCompression) -> Self {
        match c {
            ParquetCompression::None => Compression::UNCOMPRESSED,
            ParquetCompression::Snappy => Compression::SNAPPY,
            ParquetCompression::Gzip => Compression::GZIP(Default::default()),
            ParquetCompression::Lz4 => Compression::LZ4,
            ParquetCompression::Zstd(level) => {
                Compression::ZSTD(parquet::basic::ZstdLevel::try_new(level).unwrap_or_default())
            }
        }
    }
}

/// Parquet writer that produces bytes from Arrow RecordBatches
pub struct ParquetWriter {
    options: ParquetWriterOptions,
}

impl ParquetWriter {
    /// Create a new Parquet writer with default options
    pub fn new() -> Self {
        Self {
            options: ParquetWriterOptions::default(),
        }
    }

    /// Create with specific options
    pub fn with_options(options: ParquetWriterOptions) -> Self {
        Self { options }
    }

    /// Create with maximum compatibility for legacy readers
    pub fn max_compatibility() -> Self {
        Self {
            options: ParquetWriterOptions::max_compatibility(),
        }
    }

    /// Write RecordBatches to Parquet bytes
    pub fn write_batches(&self, batches: &[RecordBatch]) -> Result<Bytes> {
        if batches.is_empty() {
            return Err(Error::invalid_file("No batches to write"));
        }

        let schema = batches[0].schema();
        self.write_batches_with_schema(batches, schema)
    }

    /// Write RecordBatches with explicit schema
    pub fn write_batches_with_schema(
        &self,
        batches: &[RecordBatch],
        schema: SchemaRef,
    ) -> Result<Bytes> {
        let mut buffer = Cursor::new(Vec::new());
        let props = self.build_writer_properties();

        let mut writer = ArrowWriter::try_new(&mut buffer, schema, Some(props))
            .map_err(|e| Error::invalid_file(format!("Failed to create Parquet writer: {}", e)))?;

        for batch in batches {
            writer
                .write(batch)
                .map_err(|e| Error::invalid_file(format!("Failed to write batch: {}", e)))?;
        }

        writer
            .close()
            .map_err(|e| Error::invalid_file(format!("Failed to close Parquet writer: {}", e)))?;

        Ok(Bytes::from(buffer.into_inner()))
    }

    /// Write a single RecordBatch
    pub fn write_batch(&self, batch: &RecordBatch) -> Result<Bytes> {
        self.write_batches(std::slice::from_ref(batch))
    }

    /// Build writer properties from options
    fn build_writer_properties(&self) -> WriterProperties {
        let version = match self.options.version {
            ParquetVersion::V1 => WriterVersion::PARQUET_1_0,
            ParquetVersion::V2 => WriterVersion::PARQUET_2_0,
        };

        let mut builder = WriterProperties::builder()
            .set_writer_version(version)
            .set_compression(self.options.compression.into())
            .set_max_row_group_size(self.options.row_group_size)
            .set_data_page_size_limit(self.options.data_page_size)
            .set_dictionary_page_size_limit(self.options.dictionary_page_size);

        if self.options.enable_dictionary {
            builder = builder.set_dictionary_enabled(true);
        } else {
            builder = builder.set_dictionary_enabled(false);
        }

        // Use only v1 compatible encodings for max compatibility
        if self.options.version == ParquetVersion::V1 {
            builder = builder
                .set_encoding(Encoding::PLAIN)
                .set_dictionary_enabled(self.options.enable_dictionary);
        }

        if self.options.enable_statistics {
            builder =
                builder.set_statistics_enabled(parquet::file::properties::EnabledStatistics::Chunk);
        }

        builder.build()
    }
}

impl Default for ParquetWriter {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Int32Array, StringArray};
    use arrow::datatypes::{DataType, Field, Schema};
    use std::sync::Arc;

    fn create_test_batch() -> RecordBatch {
        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, true),
        ]));

        let ids = Int32Array::from(vec![1, 2, 3, 4, 5]);
        let names = StringArray::from(vec![
            Some("Alice"),
            Some("Bob"),
            Some("Charlie"),
            None,
            Some("Eve"),
        ]);

        RecordBatch::try_new(schema, vec![Arc::new(ids), Arc::new(names)]).unwrap()
    }

    #[test]
    fn test_write_single_batch() {
        let writer = ParquetWriter::new();
        let batch = create_test_batch();
        let bytes = writer.write_batch(&batch).unwrap();

        // Verify it's valid Parquet (magic bytes)
        assert!(bytes.len() > 8);
        assert_eq!(&bytes[0..4], b"PAR1");
        assert_eq!(&bytes[bytes.len() - 4..], b"PAR1");
    }

    #[test]
    fn test_write_multiple_batches() {
        let writer = ParquetWriter::new();
        let batch = create_test_batch();
        let bytes = writer.write_batches(&[batch.clone(), batch]).unwrap();

        assert!(bytes.len() > 8);
        assert_eq!(&bytes[0..4], b"PAR1");
    }

    #[test]
    fn test_max_compatibility_writer() {
        let writer = ParquetWriter::max_compatibility();
        let batch = create_test_batch();
        let bytes = writer.write_batch(&batch).unwrap();

        // Should produce valid Parquet v1
        assert_eq!(&bytes[0..4], b"PAR1");
    }

    #[test]
    fn test_compression_options() {
        let batch = create_test_batch();

        // Test different compression options
        for compression in [
            ParquetCompression::None,
            ParquetCompression::Snappy,
            ParquetCompression::Zstd(3),
        ] {
            let options = ParquetWriterOptions {
                compression,
                ..Default::default()
            };
            let writer = ParquetWriter::with_options(options);
            let bytes = writer.write_batch(&batch).unwrap();
            assert_eq!(&bytes[0..4], b"PAR1");
        }
    }

    #[test]
    fn test_empty_batches_error() {
        let writer = ParquetWriter::new();
        let result = writer.write_batches(&[]);
        assert!(result.is_err());
    }
}
