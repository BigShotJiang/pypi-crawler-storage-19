// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! C FFI bindings for Rosetta
//!
//! This module exposes the core Rosetta functionality through a C-compatible
//! interface, enabling integration with JVM (via JNI), Python (via ctypes/cffi),
//! and other languages.
//!
//! # Thread Safety
//!
//! All functions in this module are thread-safe. The Rosetta runtime uses
//! internal synchronization and can be called from multiple threads.
//!
//! # Memory Management
//!
//! Memory returned by Rosetta functions must be freed using the corresponding
//! `rosetta_free_*` functions. Failure to do so will result in memory leaks.
//!
//! # Error Handling
//!
//! Functions that can fail return a `RosettaResult` struct containing either
//! the result or an error message. Always check `error_message` before using
//! the result.

// JNI bindings (optional, requires jni feature)
#[cfg(feature = "jni")]
pub mod jni;

use std::ffi::{c_char, CStr, CString};
use std::ptr;
use std::slice;
use std::sync::Arc;

use bytes::Bytes;
use once_cell::sync::Lazy;
use tokio::runtime::Runtime;

use crate::format::FormatDetector;
use crate::iceberg::RosettaFileIO;
use crate::transcoder::Transcoder;

// =============================================================================
// Global Runtime
// =============================================================================

/// Global Tokio runtime for async operations
static RUNTIME: Lazy<Runtime> = Lazy::new(|| {
    tokio::runtime::Builder::new_multi_thread()
        .worker_threads(4)
        .enable_all()
        .build()
        .expect("Failed to create Tokio runtime")
});

// =============================================================================
// Result Types
// =============================================================================

/// Result of a Rosetta operation that returns bytes
#[repr(C)]
pub struct RosettaBytesResult {
    /// Pointer to the data (null if error)
    pub data: *mut u8,
    /// Length of the data
    pub len: usize,
    /// Error message (null if success)
    pub error_message: *mut c_char,
}

/// Result of a Rosetta operation that returns a string
#[repr(C)]
pub struct RosettaStringResult {
    /// The string value (null if error)
    pub value: *mut c_char,
    /// Error message (null if success)
    pub error_message: *mut c_char,
}

/// Result of a Rosetta operation that returns a boolean
#[repr(C)]
pub struct RosettaBoolResult {
    /// The boolean value
    pub value: bool,
    /// Error message (null if success)
    pub error_message: *mut c_char,
}

/// Result of a Rosetta operation that returns a size
#[repr(C)]
pub struct RosettaSizeResult {
    /// The size value
    pub value: u64,
    /// Error message (null if success)
    pub error_message: *mut c_char,
}

/// File format enumeration (C-compatible)
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RosettaFormat {
    /// Unknown or undetectable format
    Unknown = 0,
    /// Apache Parquet v1 (legacy encodings)
    ParquetV1 = 1,
    /// Apache Parquet v2 (modern encodings)
    ParquetV2 = 2,
    /// Vortex columnar format
    Vortex = 3,
    /// Lance format
    Lance = 4,
    /// F3 format with embedded WASM
    F3 = 5,
    /// FastLanes format
    FastLanes = 6,
}

impl From<crate::FileFormat> for RosettaFormat {
    fn from(format: crate::FileFormat) -> Self {
        match format {
            crate::FileFormat::ParquetV1 => RosettaFormat::ParquetV1,
            crate::FileFormat::ParquetV2 => RosettaFormat::ParquetV2,
            crate::FileFormat::Vortex => RosettaFormat::Vortex,
            crate::FileFormat::Lance => RosettaFormat::Lance,
            crate::FileFormat::F3 => RosettaFormat::F3,
            crate::FileFormat::FastLanes => RosettaFormat::FastLanes,
        }
    }
}

// =============================================================================
// Opaque Handle Types
// =============================================================================

/// Opaque handle to a RosettaFileIO instance
pub struct RosettaFileIOHandle {
    inner: Arc<RosettaFileIO>,
}

/// Opaque handle to a Transcoder instance
pub struct RosettaTranscoderHandle {
    inner: Transcoder,
}

// =============================================================================
// Helper Functions
// =============================================================================

fn string_to_c(s: String) -> *mut c_char {
    match CString::new(s) {
        Ok(cs) => cs.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

fn c_to_string(ptr: *const c_char) -> Result<String, &'static str> {
    if ptr.is_null() {
        return Err("Null pointer");
    }
    unsafe {
        CStr::from_ptr(ptr)
            .to_str()
            .map(|s| s.to_string())
            .map_err(|_| "Invalid UTF-8")
    }
}

fn error_result_bytes(msg: &str) -> RosettaBytesResult {
    RosettaBytesResult {
        data: ptr::null_mut(),
        len: 0,
        error_message: string_to_c(msg.to_string()),
    }
}

fn error_result_string(msg: &str) -> RosettaStringResult {
    RosettaStringResult {
        value: ptr::null_mut(),
        error_message: string_to_c(msg.to_string()),
    }
}

fn error_result_bool(msg: &str) -> RosettaBoolResult {
    RosettaBoolResult {
        value: false,
        error_message: string_to_c(msg.to_string()),
    }
}

fn error_result_size(msg: &str) -> RosettaSizeResult {
    RosettaSizeResult {
        value: 0,
        error_message: string_to_c(msg.to_string()),
    }
}

// =============================================================================
// FileIO Functions
// =============================================================================

/// Create a new RosettaFileIO with default configuration
///
/// # Returns
/// A pointer to the FileIO handle, or null on error
///
/// # Safety
/// The returned handle must be freed with `rosetta_fileio_free`
#[no_mangle]
pub extern "C" fn rosetta_fileio_new() -> *mut RosettaFileIOHandle {
    match RosettaFileIO::default_config() {
        Ok(fileio) => Box::into_raw(Box::new(RosettaFileIOHandle {
            inner: Arc::new(fileio),
        })),
        Err(_) => ptr::null_mut(),
    }
}

/// Free a RosettaFileIO handle
///
/// # Safety
/// - `handle` must be a valid pointer returned by `rosetta_fileio_new`
/// - `handle` must not be used after this call
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_free(handle: *mut RosettaFileIOHandle) {
    if !handle.is_null() {
        drop(Box::from_raw(handle));
    }
}

/// Check if a file should be transcoded based on its extension
///
/// # Safety
/// - `handle` must be a valid FileIO handle
/// - `path` must be a valid null-terminated UTF-8 string
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_should_transcode(
    handle: *const RosettaFileIOHandle,
    path: *const c_char,
) -> bool {
    if handle.is_null() {
        return false;
    }
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(_) => return false,
    };
    (*handle).inner.should_transcode(&path)
}

/// Read a file, transcoding if necessary
///
/// # Safety
/// - `handle` must be a valid FileIO handle
/// - `path` must be a valid null-terminated UTF-8 string
/// - The returned bytes must be freed with `rosetta_bytes_free`
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_read(
    handle: *const RosettaFileIOHandle,
    path: *const c_char,
) -> RosettaBytesResult {
    if handle.is_null() {
        return error_result_bytes("Null handle");
    }
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_bytes(e),
    };

    let result = RUNTIME.block_on(async {
        let input = (*handle).inner.new_input(&path)?;
        input.read().await
    });

    match result {
        Ok(bytes) => {
            let len = bytes.len();
            let data = bytes.to_vec().into_boxed_slice();
            let ptr = Box::into_raw(data) as *mut u8;
            RosettaBytesResult {
                data: ptr,
                len,
                error_message: ptr::null_mut(),
            }
        }
        Err(e) => error_result_bytes(&e.to_string()),
    }
}

/// Check if a file exists
///
/// # Safety
/// - `handle` must be a valid FileIO handle
/// - `path` must be a valid null-terminated UTF-8 string
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_exists(
    handle: *const RosettaFileIOHandle,
    path: *const c_char,
) -> RosettaBoolResult {
    if handle.is_null() {
        return error_result_bool("Null handle");
    }
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_bool(e),
    };

    let result = RUNTIME.block_on(async {
        let input = (*handle).inner.new_input(&path)?;
        input.exists().await
    });

    match result {
        Ok(exists) => RosettaBoolResult {
            value: exists,
            error_message: ptr::null_mut(),
        },
        Err(e) => error_result_bool(&e.to_string()),
    }
}

/// Get the length of a file
///
/// # Safety
/// - `handle` must be a valid FileIO handle
/// - `path` must be a valid null-terminated UTF-8 string
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_length(
    handle: *const RosettaFileIOHandle,
    path: *const c_char,
) -> RosettaSizeResult {
    if handle.is_null() {
        return error_result_size("Null handle");
    }
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_size(e),
    };

    let result = RUNTIME.block_on(async {
        let input = (*handle).inner.new_input(&path)?;
        input.len().await
    });

    match result {
        Ok(len) => RosettaSizeResult {
            value: len,
            error_message: ptr::null_mut(),
        },
        Err(e) => error_result_size(&e.to_string()),
    }
}

/// Write bytes to a file
///
/// # Safety
/// - `handle` must be a valid FileIO handle
/// - `path` must be a valid null-terminated UTF-8 string
/// - `data` must be a valid pointer to `len` bytes
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_write(
    handle: *const RosettaFileIOHandle,
    path: *const c_char,
    data: *const u8,
    len: usize,
) -> RosettaBoolResult {
    if handle.is_null() {
        return error_result_bool("Null handle");
    }
    if data.is_null() && len > 0 {
        return error_result_bool("Null data pointer");
    }
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_bool(e),
    };

    let bytes = if len == 0 {
        Bytes::new()
    } else {
        Bytes::copy_from_slice(slice::from_raw_parts(data, len))
    };

    let result = RUNTIME.block_on(async {
        let output = (*handle).inner.new_output(&path)?;
        output.write(bytes).await
    });

    match result {
        Ok(()) => RosettaBoolResult {
            value: true,
            error_message: ptr::null_mut(),
        },
        Err(e) => error_result_bool(&e.to_string()),
    }
}

/// Delete a file
///
/// # Safety
/// - `handle` must be a valid FileIO handle
/// - `path` must be a valid null-terminated UTF-8 string
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_delete(
    handle: *const RosettaFileIOHandle,
    path: *const c_char,
) -> RosettaBoolResult {
    if handle.is_null() {
        return error_result_bool("Null handle");
    }
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_bool(e),
    };

    let result = RUNTIME.block_on(async { (*handle).inner.delete(&path).await });

    match result {
        Ok(()) => RosettaBoolResult {
            value: true,
            error_message: ptr::null_mut(),
        },
        Err(e) => error_result_bool(&e.to_string()),
    }
}

/// Clear the FileIO cache
///
/// # Safety
/// - `handle` must be a valid FileIO handle
#[no_mangle]
pub unsafe extern "C" fn rosetta_fileio_clear_cache(handle: *const RosettaFileIOHandle) {
    if !handle.is_null() {
        RUNTIME.block_on(async { (*handle).inner.clear_cache().await });
    }
}

// =============================================================================
// Format Detection Functions
// =============================================================================

/// Detect the format of a file by path
///
/// # Safety
/// - `path` must be a valid null-terminated UTF-8 string
#[no_mangle]
pub unsafe extern "C" fn rosetta_detect_format(path: *const c_char) -> RosettaFormat {
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(_) => return RosettaFormat::Unknown,
    };

    let detector = FormatDetector::new();
    let result = RUNTIME.block_on(async { detector.detect_file(&path).await });

    match result {
        Ok(format) => RosettaFormat::from(format),
        Err(_) => RosettaFormat::Unknown,
    }
}

/// Detect the format of data by examining magic bytes
///
/// This function examines the header bytes to detect format.
/// For Parquet detection, you should also provide footer bytes via
/// `rosetta_detect_format_from_header_footer`.
///
/// # Safety
/// - `data` must be a valid pointer to at least `len` bytes
#[no_mangle]
pub unsafe extern "C" fn rosetta_detect_format_from_bytes(
    data: *const u8,
    len: usize,
) -> RosettaFormat {
    if data.is_null() || len < 4 {
        return RosettaFormat::Unknown;
    }

    let bytes = slice::from_raw_parts(data, len.min(1024));
    let detector = FormatDetector::new();

    // For header-only detection, pass None for footer
    match detector.detect_from_bytes(bytes, None) {
        Some(format) => RosettaFormat::from(format),
        None => RosettaFormat::Unknown,
    }
}

/// Detect the format of data by examining both header and footer bytes
///
/// This is useful for Parquet detection which requires both header and footer.
///
/// # Safety
/// - `header` must be a valid pointer to at least `header_len` bytes
/// - `footer` must be a valid pointer to at least `footer_len` bytes (or null)
#[no_mangle]
pub unsafe extern "C" fn rosetta_detect_format_from_header_footer(
    header: *const u8,
    header_len: usize,
    footer: *const u8,
    footer_len: usize,
) -> RosettaFormat {
    if header.is_null() || header_len < 4 {
        return RosettaFormat::Unknown;
    }

    let header_bytes = slice::from_raw_parts(header, header_len.min(1024));
    let footer_bytes = if !footer.is_null() && footer_len >= 4 {
        Some(slice::from_raw_parts(footer, footer_len.min(1024)))
    } else {
        None
    };

    let detector = FormatDetector::new();

    match detector.detect_from_bytes(header_bytes, footer_bytes) {
        Some(format) => RosettaFormat::from(format),
        None => RosettaFormat::Unknown,
    }
}

// =============================================================================
// Schema Functions
// =============================================================================

/// Get the Arrow schema of a file as JSON
///
/// # Safety
/// - `path` must be a valid null-terminated UTF-8 string
/// - The returned string must be freed with `rosetta_string_free`
#[no_mangle]
pub unsafe extern "C" fn rosetta_get_schema_json(path: *const c_char) -> RosettaStringResult {
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_string(e),
    };

    let result = RUNTIME.block_on(async {
        let reader = crate::UnifiedReader::open(&path).await?;
        let schema = reader.schema();
        // Convert Arrow schema to JSON manually
        let json = arrow_schema_to_json(&schema);
        Ok::<_, crate::Error>(json)
    });

    match result {
        Ok(json) => RosettaStringResult {
            value: string_to_c(json),
            error_message: ptr::null_mut(),
        },
        Err(e) => error_result_string(&e.to_string()),
    }
}

/// Convert an Arrow schema to JSON string
fn arrow_schema_to_json(schema: &arrow::datatypes::Schema) -> String {
    let mut json = String::from("{\"fields\":[");

    for (i, field) in schema.fields().iter().enumerate() {
        if i > 0 {
            json.push(',');
        }

        json.push_str("{\"name\":\"");
        json.push_str(field.name());
        json.push_str("\",\"data_type\":");
        write_arrow_datatype(&mut json, field.data_type());
        json.push_str(",\"nullable\":");
        json.push_str(if field.is_nullable() { "true" } else { "false" });
        json.push('}');
    }

    json.push_str("]}");
    json
}

/// Write an Arrow DataType as JSON
fn write_arrow_datatype(json: &mut String, dt: &arrow::datatypes::DataType) {
    use arrow::datatypes::DataType;

    match dt {
        // Simple types - just write the type name as a string
        DataType::Null => json.push_str("\"Null\""),
        DataType::Boolean => json.push_str("\"Boolean\""),
        DataType::Int8 => json.push_str("\"Int8\""),
        DataType::Int16 => json.push_str("\"Int16\""),
        DataType::Int32 => json.push_str("\"Int32\""),
        DataType::Int64 => json.push_str("\"Int64\""),
        DataType::UInt8 => json.push_str("\"UInt8\""),
        DataType::UInt16 => json.push_str("\"UInt16\""),
        DataType::UInt32 => json.push_str("\"UInt32\""),
        DataType::UInt64 => json.push_str("\"UInt64\""),
        DataType::Float16 => json.push_str("\"Float16\""),
        DataType::Float32 => json.push_str("\"Float32\""),
        DataType::Float64 => json.push_str("\"Float64\""),
        DataType::Utf8 => json.push_str("\"Utf8\""),
        DataType::LargeUtf8 => json.push_str("\"LargeUtf8\""),
        DataType::Binary => json.push_str("\"Binary\""),
        DataType::LargeBinary => json.push_str("\"LargeBinary\""),
        DataType::Date32 => json.push_str("\"Date32\""),
        DataType::Date64 => json.push_str("\"Date64\""),
        DataType::Utf8View => json.push_str("\"Utf8\""),
        DataType::BinaryView => json.push_str("\"Binary\""),

        // Complex types - write as objects
        DataType::Timestamp(unit, tz) => {
            json.push_str("{\"Timestamp\":{\"unit\":\"");
            json.push_str(match unit {
                arrow::datatypes::TimeUnit::Second => "Second",
                arrow::datatypes::TimeUnit::Millisecond => "Millisecond",
                arrow::datatypes::TimeUnit::Microsecond => "Microsecond",
                arrow::datatypes::TimeUnit::Nanosecond => "Nanosecond",
            });
            json.push_str("\",\"timezone\":");
            if let Some(tz) = tz {
                json.push('"');
                json.push_str(tz);
                json.push('"');
            } else {
                json.push_str("null");
            }
            json.push_str("}}");
        }
        DataType::Time32(unit) => {
            json.push_str("{\"Time32\":{\"unit\":\"");
            json.push_str(match unit {
                arrow::datatypes::TimeUnit::Second => "Second",
                arrow::datatypes::TimeUnit::Millisecond => "Millisecond",
                _ => "Second",
            });
            json.push_str("\"}}");
        }
        DataType::Time64(unit) => {
            json.push_str("{\"Time64\":{\"unit\":\"");
            json.push_str(match unit {
                arrow::datatypes::TimeUnit::Microsecond => "Microsecond",
                arrow::datatypes::TimeUnit::Nanosecond => "Nanosecond",
                _ => "Microsecond",
            });
            json.push_str("\"}}");
        }
        DataType::Duration(unit) => {
            json.push_str("{\"Duration\":{\"unit\":\"");
            json.push_str(match unit {
                arrow::datatypes::TimeUnit::Second => "Second",
                arrow::datatypes::TimeUnit::Millisecond => "Millisecond",
                arrow::datatypes::TimeUnit::Microsecond => "Microsecond",
                arrow::datatypes::TimeUnit::Nanosecond => "Nanosecond",
            });
            json.push_str("\"}}");
        }
        DataType::Decimal128(precision, scale) => {
            use std::fmt::Write;
            let _ = write!(
                json,
                "{{\"Decimal128\":{{\"precision\":{},\"scale\":{}}}}}",
                precision, scale
            );
        }
        DataType::Decimal256(precision, scale) => {
            use std::fmt::Write;
            let _ = write!(
                json,
                "{{\"Decimal256\":{{\"precision\":{},\"scale\":{}}}}}",
                precision, scale
            );
        }
        DataType::List(field) => {
            json.push_str("{\"List\":{\"field\":{\"name\":\"");
            json.push_str(field.name());
            json.push_str("\",\"data_type\":");
            write_arrow_datatype(json, field.data_type());
            json.push_str(",\"nullable\":");
            json.push_str(if field.is_nullable() { "true" } else { "false" });
            json.push_str("}}}");
        }
        DataType::LargeList(field) => {
            json.push_str("{\"LargeList\":{\"field\":{\"name\":\"");
            json.push_str(field.name());
            json.push_str("\",\"data_type\":");
            write_arrow_datatype(json, field.data_type());
            json.push_str(",\"nullable\":");
            json.push_str(if field.is_nullable() { "true" } else { "false" });
            json.push_str("}}}");
        }
        DataType::FixedSizeList(field, size) => {
            use std::fmt::Write;
            json.push_str("{\"FixedSizeList\":{\"size\":");
            let _ = write!(json, "{}", size);
            json.push_str(",\"field\":{\"name\":\"");
            json.push_str(field.name());
            json.push_str("\",\"data_type\":");
            write_arrow_datatype(json, field.data_type());
            json.push_str(",\"nullable\":");
            json.push_str(if field.is_nullable() { "true" } else { "false" });
            json.push_str("}}}");
        }
        DataType::Struct(fields) => {
            json.push_str("{\"Struct\":{\"fields\":[");
            for (i, field) in fields.iter().enumerate() {
                if i > 0 {
                    json.push(',');
                }
                json.push_str("{\"name\":\"");
                json.push_str(field.name());
                json.push_str("\",\"data_type\":");
                write_arrow_datatype(json, field.data_type());
                json.push_str(",\"nullable\":");
                json.push_str(if field.is_nullable() { "true" } else { "false" });
                json.push('}');
            }
            json.push_str("]}}");
        }
        DataType::Map(field, _keys_sorted) => {
            json.push_str("{\"Map\":{\"field\":{\"name\":\"");
            json.push_str(field.name());
            json.push_str("\",\"data_type\":");
            write_arrow_datatype(json, field.data_type());
            json.push_str(",\"nullable\":");
            json.push_str(if field.is_nullable() { "true" } else { "false" });
            json.push_str("}}}");
        }
        DataType::FixedSizeBinary(size) => {
            use std::fmt::Write;
            let _ = write!(json, "{{\"FixedSizeBinary\":{}}}", size);
        }
        DataType::Interval(unit) => {
            json.push_str("{\"Interval\":{\"unit\":\"");
            json.push_str(match unit {
                arrow::datatypes::IntervalUnit::YearMonth => "YearMonth",
                arrow::datatypes::IntervalUnit::DayTime => "DayTime",
                arrow::datatypes::IntervalUnit::MonthDayNano => "MonthDayNano",
            });
            json.push_str("\"}}");
        }
        DataType::Dictionary(key_type, value_type) => {
            json.push_str("{\"Dictionary\":{\"key_type\":");
            write_arrow_datatype(json, key_type);
            json.push_str(",\"value_type\":");
            write_arrow_datatype(json, value_type);
            json.push_str("}}");
        }
        DataType::Union(_, _) => {
            // Union types are complex - fall back to Binary
            json.push_str("\"Binary\"");
        }
        DataType::RunEndEncoded(_, _) => {
            json.push_str("\"Binary\"");
        }
        DataType::ListView(_) | DataType::LargeListView(_) => {
            json.push_str("\"Binary\"");
        }
    }
}

// =============================================================================
// Transcoder Functions
// =============================================================================

/// Create a new Transcoder with default options
///
/// # Returns
/// A pointer to the Transcoder handle, or null on error
///
/// # Safety
/// The returned handle must be freed with `rosetta_transcoder_free`
#[no_mangle]
pub extern "C" fn rosetta_transcoder_new() -> *mut RosettaTranscoderHandle {
    Box::into_raw(Box::new(RosettaTranscoderHandle {
        inner: Transcoder::new(),
    }))
}

/// Free a Transcoder handle
///
/// # Safety
/// - `handle` must be a valid pointer returned by `rosetta_transcoder_new`
/// - `handle` must not be used after this call
#[no_mangle]
pub unsafe extern "C" fn rosetta_transcoder_free(handle: *mut RosettaTranscoderHandle) {
    if !handle.is_null() {
        drop(Box::from_raw(handle));
    }
}

/// Transcode a file to Parquet v1 bytes
///
/// # Safety
/// - `handle` must be a valid Transcoder handle
/// - `path` must be a valid null-terminated UTF-8 string
/// - The returned bytes must be freed with `rosetta_bytes_free`
#[no_mangle]
pub unsafe extern "C" fn rosetta_transcoder_transcode_file(
    handle: *const RosettaTranscoderHandle,
    path: *const c_char,
) -> RosettaBytesResult {
    if handle.is_null() {
        return error_result_bytes("Null handle");
    }
    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_bytes(e),
    };

    let result = RUNTIME.block_on(async { (*handle).inner.transcode_file(&path).await });

    match result {
        Ok(transcode_result) => {
            let bytes = transcode_result.bytes;
            let len = bytes.len();
            let data = bytes.to_vec().into_boxed_slice();
            let ptr = Box::into_raw(data) as *mut u8;
            RosettaBytesResult {
                data: ptr,
                len,
                error_message: ptr::null_mut(),
            }
        }
        Err(e) => error_result_bytes(&e.to_string()),
    }
}

/// Transcode a file to Parquet v1 bytes with filter pushdown
///
/// # Arguments
/// * `handle` - Valid Transcoder handle
/// * `path` - Path to the file to transcode
/// * `filter_json` - JSON filter expression (null for no filter)
///
/// # Filter JSON Format
/// The filter is a JSON object representing a Rosetta expression:
/// ```json
/// {
///   "op": "gt",
///   "left": {"column": "age"},
///   "right": {"literal": {"Int64": 30}}
/// }
/// ```
///
/// # Safety
/// - `handle` must be a valid Transcoder handle
/// - `path` must be a valid null-terminated UTF-8 string
/// - `filter_json` must be a valid null-terminated UTF-8 string or null
/// - The returned bytes must be freed with `rosetta_bytes_free`
#[no_mangle]
pub unsafe extern "C" fn rosetta_transcoder_transcode_file_with_filter(
    handle: *const RosettaTranscoderHandle,
    path: *const c_char,
    filter_json: *const c_char,
) -> RosettaBytesResult {
    if handle.is_null() {
        return error_result_bytes("Null handle");
    }

    let path = match c_to_string(path) {
        Ok(p) => p,
        Err(e) => return error_result_bytes(e),
    };

    // Parse filter if provided
    let filter = if !filter_json.is_null() {
        match c_to_string(filter_json) {
            Ok(json_str) => match crate::expr::Expr::from_json(&json_str) {
                Ok(expr) => Some(expr),
                Err(e) => return error_result_bytes(&format!("Invalid filter JSON: {}", e)),
            },
            Err(e) => return error_result_bytes(&format!("Invalid filter string: {}", e)),
        }
    } else {
        None
    };

    // Create transcoder with filter
    let transcoder = if let Some(f) = filter {
        Transcoder::new().with_filter(f)
    } else {
        Transcoder::new()
    };

    let result = RUNTIME.block_on(async { transcoder.transcode_file(&path).await });

    match result {
        Ok(transcode_result) => {
            let bytes = transcode_result.bytes;
            let len = bytes.len();
            let data = bytes.to_vec().into_boxed_slice();
            let ptr = Box::into_raw(data) as *mut u8;
            RosettaBytesResult {
                data: ptr,
                len,
                error_message: ptr::null_mut(),
            }
        }
        Err(e) => error_result_bytes(&e.to_string()),
    }
}

// =============================================================================
// Memory Management Functions
// =============================================================================

/// Free bytes returned by Rosetta functions
///
/// # Safety
/// - `data` must be a valid pointer returned by a Rosetta function
/// - `data` must not be used after this call
#[no_mangle]
pub unsafe extern "C" fn rosetta_bytes_free(data: *mut u8, len: usize) {
    if !data.is_null() && len > 0 {
        let _ = Vec::from_raw_parts(data, len, len);
    }
}

/// Free a string returned by Rosetta functions
///
/// # Safety
/// - `s` must be a valid pointer returned by a Rosetta function
/// - `s` must not be used after this call
#[no_mangle]
pub unsafe extern "C" fn rosetta_string_free(s: *mut c_char) {
    if !s.is_null() {
        let _ = CString::from_raw(s);
    }
}

// =============================================================================
// Version Information
// =============================================================================

/// Get the Rosetta library version
///
/// # Returns
/// A null-terminated string containing the version. Do NOT free this string.
#[no_mangle]
pub extern "C" fn rosetta_version() -> *const c_char {
    static VERSION: Lazy<CString> = Lazy::new(|| CString::new(env!("CARGO_PKG_VERSION")).unwrap());
    VERSION.as_ptr()
}

// =============================================================================
// Tests
// =============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use std::ffi::CString;

    #[test]
    fn test_version() {
        let version = rosetta_version();
        assert!(!version.is_null());
        let version_str = unsafe { CStr::from_ptr(version).to_str().unwrap() };
        assert!(!version_str.is_empty());
    }

    #[test]
    fn test_fileio_lifecycle() {
        let handle = rosetta_fileio_new();
        assert!(!handle.is_null());
        unsafe {
            rosetta_fileio_free(handle);
        }
    }

    #[test]
    fn test_transcoder_lifecycle() {
        let handle = rosetta_transcoder_new();
        assert!(!handle.is_null());
        unsafe {
            rosetta_transcoder_free(handle);
        }
    }

    #[test]
    fn test_detect_format_parquet() {
        // PAR1 magic bytes - header only won't detect Parquet (needs footer too)
        // So we test with header+footer
        let header = b"PAR1\x00\x00\x00\x00";
        let footer = b"\x00\x00\x00\x00PAR1";
        let format = unsafe {
            rosetta_detect_format_from_header_footer(
                header.as_ptr(),
                header.len(),
                footer.as_ptr(),
                footer.len(),
            )
        };
        assert_eq!(format, RosettaFormat::ParquetV1);
    }

    #[test]
    fn test_detect_format_vortex() {
        // VTXF magic bytes
        let data = b"VTXF\x00\x00\x00\x00";
        let format = unsafe { rosetta_detect_format_from_bytes(data.as_ptr(), data.len()) };
        assert_eq!(format, RosettaFormat::Vortex);
    }

    #[test]
    fn test_should_transcode() {
        let handle = rosetta_fileio_new();
        assert!(!handle.is_null());

        let vortex_path = CString::new("test.vortex").unwrap();
        let parquet_path = CString::new("test.parquet").unwrap();

        unsafe {
            assert!(rosetta_fileio_should_transcode(
                handle,
                vortex_path.as_ptr()
            ));
            assert!(!rosetta_fileio_should_transcode(
                handle,
                parquet_path.as_ptr()
            ));
            rosetta_fileio_free(handle);
        }
    }

    #[test]
    fn test_arrow_schema_to_json() {
        use arrow::datatypes::{DataType, Field, Schema};

        let schema = Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, true),
            Field::new("price", DataType::Float64, false),
        ]);

        let json = super::arrow_schema_to_json(&schema);

        // Verify the JSON structure
        assert!(json.contains("\"fields\":["));
        assert!(json.contains("\"name\":\"id\""));
        assert!(json.contains("\"data_type\":\"Int32\""));
        assert!(json.contains("\"nullable\":false"));
        assert!(json.contains("\"name\":\"name\""));
        assert!(json.contains("\"data_type\":\"Utf8\""));
        assert!(json.contains("\"nullable\":true"));
        assert!(json.contains("\"name\":\"price\""));
        assert!(json.contains("\"data_type\":\"Float64\""));
    }

    #[test]
    fn test_arrow_schema_complex_types() {
        use arrow::datatypes::{DataType, Field, Schema, TimeUnit};
        use std::sync::Arc;

        let schema = Schema::new(vec![
            Field::new(
                "ts",
                DataType::Timestamp(TimeUnit::Millisecond, Some("UTC".into())),
                true,
            ),
            Field::new(
                "items",
                DataType::List(Arc::new(Field::new("item", DataType::Int64, true))),
                true,
            ),
            Field::new("amount", DataType::Decimal128(18, 2), false),
        ]);

        let json = super::arrow_schema_to_json(&schema);

        // Verify complex types are serialized correctly
        assert!(json.contains("\"Timestamp\""));
        assert!(json.contains("\"List\""));
        assert!(json.contains("\"Decimal128\""));
        assert!(json.contains("\"precision\":18"));
        assert!(json.contains("\"scale\":2"));
    }
}
