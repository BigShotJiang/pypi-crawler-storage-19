// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! JNI bindings for Rosetta
//!
//! This module provides JNI implementations for the Java `RosettaNative` class.

#![allow(non_snake_case)]

use std::sync::Mutex;

use jni::objects::{JByteArray, JClass, JObject, JString};
use jni::sys::{jboolean, jbyteArray, jint, jlong, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;

use once_cell::sync::Lazy;

use super::{
    rosetta_detect_format, rosetta_detect_format_from_bytes,
    rosetta_detect_format_from_header_footer, rosetta_fileio_clear_cache, rosetta_fileio_delete,
    rosetta_fileio_exists, rosetta_fileio_free, rosetta_fileio_length, rosetta_fileio_new,
    rosetta_fileio_read, rosetta_fileio_should_transcode, rosetta_fileio_write,
    rosetta_transcoder_free, rosetta_transcoder_new, rosetta_transcoder_transcode_file,
    rosetta_version, RosettaFileIOHandle, RosettaFormat, RosettaTranscoderHandle,
};

// Thread-local storage for the last error message
static LAST_ERROR: Lazy<Mutex<Option<String>>> = Lazy::new(|| Mutex::new(None));

fn set_last_error(msg: String) {
    if let Ok(mut guard) = LAST_ERROR.lock() {
        *guard = Some(msg);
    }
}

fn clear_last_error() {
    if let Ok(mut guard) = LAST_ERROR.lock() {
        *guard = None;
    }
}

fn get_last_error() -> Option<String> {
    LAST_ERROR.lock().ok().and_then(|guard| guard.clone())
}

// =============================================================================
// Version
// =============================================================================

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_version<'local>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    let version_ptr = rosetta_version();
    if version_ptr.is_null() {
        return std::ptr::null_mut();
    }

    let version = unsafe { std::ffi::CStr::from_ptr(version_ptr) };
    match env.new_string(version.to_string_lossy()) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}

// =============================================================================
// FileIO Functions
// =============================================================================

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioNew<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jlong {
    clear_last_error();
    let handle = rosetta_fileio_new();
    if handle.is_null() {
        set_last_error("Failed to create FileIO".to_string());
        0
    } else {
        handle as jlong
    }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioFree<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) {
    if handle != 0 {
        unsafe {
            rosetta_fileio_free(handle as *mut RosettaFileIOHandle);
        }
    }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioShouldTranscode<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
) -> jboolean {
    if handle == 0 {
        return JNI_FALSE;
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(_) => return JNI_FALSE,
    };

    let result = unsafe {
        rosetta_fileio_should_transcode(handle as *const RosettaFileIOHandle, c_path.as_ptr())
    };

    if result {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioRead<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
) -> jbyteArray {
    clear_last_error();

    if handle == 0 {
        set_last_error("Null handle".to_string());
        return std::ptr::null_mut();
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    let c_path = match std::ffi::CString::new(path.clone()) {
        Ok(s) => s,
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    let result =
        unsafe { rosetta_fileio_read(handle as *const RosettaFileIOHandle, c_path.as_ptr()) };

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return std::ptr::null_mut();
    }

    if result.data.is_null() || result.len == 0 {
        // Return empty array
        match env.new_byte_array(0) {
            Ok(arr) => return arr.into_raw(),
            Err(_) => return std::ptr::null_mut(),
        }
    }

    // Create Java byte array
    let data = unsafe { std::slice::from_raw_parts(result.data, result.len) };
    let java_array = match env.new_byte_array(result.len as i32) {
        Ok(arr) => arr,
        Err(e) => {
            set_last_error(format!("Failed to create byte array: {}", e));
            unsafe {
                super::rosetta_bytes_free(result.data, result.len);
            }
            return std::ptr::null_mut();
        }
    };

    // Copy data to Java array
    // JNI expects i8, so we need to reinterpret
    let signed_data: &[i8] = unsafe { std::mem::transmute(data) };
    if env
        .set_byte_array_region(&java_array, 0, signed_data)
        .is_err()
    {
        set_last_error("Failed to copy data to Java array".to_string());
        unsafe {
            super::rosetta_bytes_free(result.data, result.len);
        }
        return std::ptr::null_mut();
    }

    // Free the native data
    unsafe {
        super::rosetta_bytes_free(result.data, result.len);
    }

    java_array.into_raw()
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioExists<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
) -> jboolean {
    clear_last_error();

    if handle == 0 {
        return JNI_FALSE;
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(_) => return JNI_FALSE,
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(_) => return JNI_FALSE,
    };

    let result =
        unsafe { rosetta_fileio_exists(handle as *const RosettaFileIOHandle, c_path.as_ptr()) };

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return JNI_FALSE;
    }

    if result.value {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioLength<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
) -> jlong {
    clear_last_error();

    if handle == 0 {
        set_last_error("Null handle".to_string());
        return -1;
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return -1;
        }
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return -1;
        }
    };

    let result =
        unsafe { rosetta_fileio_length(handle as *const RosettaFileIOHandle, c_path.as_ptr()) };

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return -1;
    }

    result.value as jlong
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioWrite<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
    data: JByteArray<'local>,
) -> jboolean {
    clear_last_error();

    if handle == 0 {
        set_last_error("Null handle".to_string());
        return JNI_FALSE;
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return JNI_FALSE;
        }
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return JNI_FALSE;
        }
    };

    // Get the byte array data
    let len = match env.get_array_length(&data) {
        Ok(l) => l as usize,
        Err(e) => {
            set_last_error(format!("Failed to get array length: {}", e));
            return JNI_FALSE;
        }
    };

    let mut buf = vec![0i8; len];
    if len > 0 {
        if env.get_byte_array_region(&data, 0, &mut buf).is_err() {
            set_last_error("Failed to get byte array data".to_string());
            return JNI_FALSE;
        }
    }

    // Convert i8 to u8
    let data_ptr = buf.as_ptr() as *const u8;

    let result = unsafe {
        rosetta_fileio_write(
            handle as *const RosettaFileIOHandle,
            c_path.as_ptr(),
            data_ptr,
            len,
        )
    };

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return JNI_FALSE;
    }

    if result.value {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioDelete<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
) -> jboolean {
    clear_last_error();

    if handle == 0 {
        set_last_error("Null handle".to_string());
        return JNI_FALSE;
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return JNI_FALSE;
        }
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return JNI_FALSE;
        }
    };

    let result =
        unsafe { rosetta_fileio_delete(handle as *const RosettaFileIOHandle, c_path.as_ptr()) };

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return JNI_FALSE;
    }

    if result.value {
        JNI_TRUE
    } else {
        JNI_FALSE
    }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_fileioClearCache<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) {
    if handle != 0 {
        unsafe {
            rosetta_fileio_clear_cache(handle as *const RosettaFileIOHandle);
        }
    }
}

// =============================================================================
// Format Detection
// =============================================================================

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_detectFormat<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    path: JString<'local>,
) -> jint {
    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(_) => return RosettaFormat::Unknown as jint,
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(_) => return RosettaFormat::Unknown as jint,
    };

    unsafe { rosetta_detect_format(c_path.as_ptr()) as jint }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_detectFormatFromBytes<'local>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
    header: JByteArray<'local>,
) -> jint {
    let len = match env.get_array_length(&header) {
        Ok(l) => l as usize,
        Err(_) => return RosettaFormat::Unknown as jint,
    };

    if len < 4 {
        return RosettaFormat::Unknown as jint;
    }

    let mut buf = vec![0i8; len];
    if env.get_byte_array_region(&header, 0, &mut buf).is_err() {
        return RosettaFormat::Unknown as jint;
    }

    let data_ptr = buf.as_ptr() as *const u8;
    unsafe { rosetta_detect_format_from_bytes(data_ptr, len) as jint }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_detectFormatFromHeaderFooter<'local>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
    header: JByteArray<'local>,
    footer: JObject<'local>,
) -> jint {
    // Get header
    let header_len = match env.get_array_length(&header) {
        Ok(l) => l as usize,
        Err(_) => return RosettaFormat::Unknown as jint,
    };

    if header_len < 4 {
        return RosettaFormat::Unknown as jint;
    }

    let mut header_buf = vec![0i8; header_len];
    if env
        .get_byte_array_region(&header, 0, &mut header_buf)
        .is_err()
    {
        return RosettaFormat::Unknown as jint;
    }

    // Get footer if present
    let (footer_ptr, footer_len) = if footer.is_null() {
        (std::ptr::null(), 0)
    } else {
        let footer_array = JByteArray::from(footer);
        let len = match env.get_array_length(&footer_array) {
            Ok(l) => l as usize,
            Err(_) => return RosettaFormat::Unknown as jint,
        };

        if len < 4 {
            (std::ptr::null(), 0)
        } else {
            let mut footer_buf = vec![0i8; len];
            if env
                .get_byte_array_region(&footer_array, 0, &mut footer_buf)
                .is_err()
            {
                return RosettaFormat::Unknown as jint;
            }
            // Note: This leaks memory - in production we'd need to handle this better
            let ptr = footer_buf.as_ptr() as *const u8;
            std::mem::forget(footer_buf);
            (ptr, len)
        }
    };

    let header_ptr = header_buf.as_ptr() as *const u8;

    unsafe {
        rosetta_detect_format_from_header_footer(header_ptr, header_len, footer_ptr, footer_len)
            as jint
    }
}

// =============================================================================
// Schema Functions
// =============================================================================

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_getSchemaJson<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    path: JString<'local>,
) -> jstring {
    clear_last_error();

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    let result = unsafe { super::rosetta_get_schema_json(c_path.as_ptr()) };

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return std::ptr::null_mut();
    }

    if result.value.is_null() {
        set_last_error("Null schema result".to_string());
        return std::ptr::null_mut();
    }

    let schema_json = unsafe { std::ffi::CStr::from_ptr(result.value) };
    let java_string = match env.new_string(schema_json.to_string_lossy()) {
        Ok(s) => s.into_raw(),
        Err(e) => {
            set_last_error(format!("Failed to create Java string: {}", e));
            unsafe {
                super::rosetta_string_free(result.value);
            }
            return std::ptr::null_mut();
        }
    };

    unsafe {
        super::rosetta_string_free(result.value);
    }

    java_string
}

// =============================================================================
// Transcoder Functions
// =============================================================================

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_transcoderNew<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jlong {
    rosetta_transcoder_new() as jlong
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_transcoderFree<'local>(
    _env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
) {
    if handle != 0 {
        unsafe {
            rosetta_transcoder_free(handle as *mut RosettaTranscoderHandle);
        }
    }
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_transcoderTranscodeFile<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
) -> jbyteArray {
    clear_last_error();

    if handle == 0 {
        set_last_error("Null handle".to_string());
        return std::ptr::null_mut();
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    let result = unsafe {
        rosetta_transcoder_transcode_file(handle as *const RosettaTranscoderHandle, c_path.as_ptr())
    };

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return std::ptr::null_mut();
    }

    if result.data.is_null() || result.len == 0 {
        match env.new_byte_array(0) {
            Ok(arr) => return arr.into_raw(),
            Err(_) => return std::ptr::null_mut(),
        }
    }

    // Create Java byte array
    let data = unsafe { std::slice::from_raw_parts(result.data, result.len) };
    let java_array = match env.new_byte_array(result.len as i32) {
        Ok(arr) => arr,
        Err(e) => {
            set_last_error(format!("Failed to create byte array: {}", e));
            unsafe {
                super::rosetta_bytes_free(result.data, result.len);
            }
            return std::ptr::null_mut();
        }
    };

    let signed_data: &[i8] = unsafe { std::mem::transmute(data) };
    if env
        .set_byte_array_region(&java_array, 0, signed_data)
        .is_err()
    {
        set_last_error("Failed to copy data to Java array".to_string());
        unsafe {
            super::rosetta_bytes_free(result.data, result.len);
        }
        return std::ptr::null_mut();
    }

    unsafe {
        super::rosetta_bytes_free(result.data, result.len);
    }

    java_array.into_raw()
}

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_transcoderTranscodeFileWithFilter<
    'local,
>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    handle: jlong,
    path: JString<'local>,
    filter_json: JString<'local>,
) -> jbyteArray {
    clear_last_error();

    if handle == 0 {
        set_last_error("Null handle".to_string());
        return std::ptr::null_mut();
    }

    let path: String = match env.get_string(&path) {
        Ok(s) => s.into(),
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    let c_path = match std::ffi::CString::new(path) {
        Ok(s) => s,
        Err(e) => {
            set_last_error(format!("Invalid path: {}", e));
            return std::ptr::null_mut();
        }
    };

    // Get filter JSON (may be null)
    let filter_json_cstr = if filter_json.is_null() {
        std::ptr::null()
    } else {
        let filter: String = match env.get_string(&filter_json) {
            Ok(s) => s.into(),
            Err(e) => {
                set_last_error(format!("Invalid filter JSON: {}", e));
                return std::ptr::null_mut();
            }
        };
        match std::ffi::CString::new(filter) {
            Ok(s) => s.into_raw(),
            Err(e) => {
                set_last_error(format!("Invalid filter JSON: {}", e));
                return std::ptr::null_mut();
            }
        }
    };

    let result = unsafe {
        super::rosetta_transcoder_transcode_file_with_filter(
            handle as *const RosettaTranscoderHandle,
            c_path.as_ptr(),
            filter_json_cstr,
        )
    };

    // Free the filter JSON CString if we allocated it
    if !filter_json_cstr.is_null() {
        unsafe {
            drop(std::ffi::CString::from_raw(filter_json_cstr as *mut i8));
        }
    }

    if !result.error_message.is_null() {
        let error = unsafe { std::ffi::CStr::from_ptr(result.error_message) };
        set_last_error(error.to_string_lossy().to_string());
        unsafe {
            super::rosetta_string_free(result.error_message);
        }
        return std::ptr::null_mut();
    }

    if result.data.is_null() || result.len == 0 {
        match env.new_byte_array(0) {
            Ok(arr) => return arr.into_raw(),
            Err(_) => return std::ptr::null_mut(),
        }
    }

    // Create Java byte array
    let data = unsafe { std::slice::from_raw_parts(result.data, result.len) };
    let java_array = match env.new_byte_array(result.len as i32) {
        Ok(arr) => arr,
        Err(e) => {
            set_last_error(format!("Failed to create byte array: {}", e));
            unsafe {
                super::rosetta_bytes_free(result.data, result.len);
            }
            return std::ptr::null_mut();
        }
    };

    let signed_data: &[i8] = unsafe { std::mem::transmute(data) };
    if env
        .set_byte_array_region(&java_array, 0, signed_data)
        .is_err()
    {
        set_last_error("Failed to copy data to Java array".to_string());
        unsafe {
            super::rosetta_bytes_free(result.data, result.len);
        }
        return std::ptr::null_mut();
    }

    unsafe {
        super::rosetta_bytes_free(result.data, result.len);
    }

    java_array.into_raw()
}

// =============================================================================
// Error Handling
// =============================================================================

#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_getLastError<'local>(
    env: JNIEnv<'local>,
    _class: JClass<'local>,
) -> jstring {
    match get_last_error() {
        Some(msg) => match env.new_string(&msg) {
            Ok(s) => s.into_raw(),
            Err(_) => std::ptr::null_mut(),
        },
        None => std::ptr::null_mut(),
    }
}
