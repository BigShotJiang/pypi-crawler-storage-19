// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Statistics for query optimization
//!
//! This module provides statistics structures that enable query optimizers
//! to make intelligent decisions about query execution. Statistics include:
//! - Row counts and byte sizes
//! - Per-column min/max values
//! - Null counts and distinct counts
//!
//! # Example
//!
//! ```rust,ignore
//! use rosetta::Statistics;
//!
//! let reader = UnifiedReader::open("data.parquet").await?;
//! if let Some(stats) = reader.statistics() {
//!     println!("Rows: {:?}", stats.num_rows);
//!     for (col, col_stats) in &stats.column_statistics {
//!         println!("  {}: min={:?}, max={:?}", col, col_stats.min_value, col_stats.max_value);
//!     }
//! }
//! ```

use std::collections::HashMap;
use std::fmt;
use std::sync::Arc;

/// Statistics for an entire file or table
#[derive(Debug, Clone, Default)]
pub struct Statistics {
    /// Total number of rows (if known)
    pub num_rows: Option<usize>,
    /// Total byte size of the data (if known)
    pub total_byte_size: Option<usize>,
    /// Per-column statistics
    pub column_statistics: HashMap<String, ColumnStatistics>,
}

impl Statistics {
    /// Create empty statistics
    pub fn new() -> Self {
        Self::default()
    }

    /// Create statistics with row count
    pub fn with_num_rows(mut self, num_rows: usize) -> Self {
        self.num_rows = Some(num_rows);
        self
    }

    /// Create statistics with byte size
    pub fn with_byte_size(mut self, size: usize) -> Self {
        self.total_byte_size = Some(size);
        self
    }

    /// Add column statistics
    pub fn with_column(mut self, name: impl Into<String>, stats: ColumnStatistics) -> Self {
        self.column_statistics.insert(name.into(), stats);
        self
    }

    /// Get statistics for a specific column
    pub fn column(&self, name: &str) -> Option<&ColumnStatistics> {
        self.column_statistics.get(name)
    }

    /// Merge statistics from another source (e.g., multiple row groups)
    pub fn merge(&mut self, other: &Statistics) {
        // Merge row counts
        match (self.num_rows, other.num_rows) {
            (Some(a), Some(b)) => self.num_rows = Some(a + b),
            (None, Some(b)) => self.num_rows = Some(b),
            _ => {}
        }

        // Merge byte sizes
        match (self.total_byte_size, other.total_byte_size) {
            (Some(a), Some(b)) => self.total_byte_size = Some(a + b),
            (None, Some(b)) => self.total_byte_size = Some(b),
            _ => {}
        }

        // Merge column statistics
        for (col, other_stats) in &other.column_statistics {
            if let Some(self_stats) = self.column_statistics.get_mut(col) {
                self_stats.merge(other_stats);
            } else {
                self.column_statistics
                    .insert(col.clone(), other_stats.clone());
            }
        }
    }
}

/// Statistics for a single column
#[derive(Debug, Clone, Default)]
pub struct ColumnStatistics {
    /// Number of null values
    pub null_count: Option<usize>,
    /// Number of distinct values (cardinality estimate)
    pub distinct_count: Option<usize>,
    /// Minimum value
    pub min_value: Option<ScalarValue>,
    /// Maximum value
    pub max_value: Option<ScalarValue>,
}

impl ColumnStatistics {
    /// Create empty column statistics
    pub fn new() -> Self {
        Self::default()
    }

    /// Set null count
    pub fn with_null_count(mut self, count: usize) -> Self {
        self.null_count = Some(count);
        self
    }

    /// Set distinct count
    pub fn with_distinct_count(mut self, count: usize) -> Self {
        self.distinct_count = Some(count);
        self
    }

    /// Set min value
    pub fn with_min(mut self, value: ScalarValue) -> Self {
        self.min_value = Some(value);
        self
    }

    /// Set max value
    pub fn with_max(mut self, value: ScalarValue) -> Self {
        self.max_value = Some(value);
        self
    }

    /// Merge with another column statistics (for combining row groups)
    pub fn merge(&mut self, other: &ColumnStatistics) {
        // Sum null counts
        match (self.null_count, other.null_count) {
            (Some(a), Some(b)) => self.null_count = Some(a + b),
            (None, Some(b)) => self.null_count = Some(b),
            _ => {}
        }

        // For distinct count, we can't simply add them - use max as approximation
        match (self.distinct_count, other.distinct_count) {
            (Some(a), Some(b)) => self.distinct_count = Some(a.max(b)),
            (None, Some(b)) => self.distinct_count = Some(b),
            _ => {}
        }

        // Update min (take the smaller one)
        match (&self.min_value, &other.min_value) {
            (Some(a), Some(b)) => {
                if b < a {
                    self.min_value = Some(b.clone());
                }
            }
            (None, Some(b)) => self.min_value = Some(b.clone()),
            _ => {}
        }

        // Update max (take the larger one)
        match (&self.max_value, &other.max_value) {
            (Some(a), Some(b)) => {
                if b > a {
                    self.max_value = Some(b.clone());
                }
            }
            (None, Some(b)) => self.max_value = Some(b.clone()),
            _ => {}
        }
    }
}

/// A scalar value that can be used in statistics and expressions
#[derive(Debug, Clone, PartialEq)]
pub enum ScalarValue {
    /// Null value
    Null,
    /// Boolean
    Boolean(bool),
    /// Signed 8-bit integer
    Int8(i8),
    /// Signed 16-bit integer
    Int16(i16),
    /// Signed 32-bit integer
    Int32(i32),
    /// Signed 64-bit integer
    Int64(i64),
    /// Unsigned 8-bit integer
    UInt8(u8),
    /// Unsigned 16-bit integer
    UInt16(u16),
    /// Unsigned 32-bit integer
    UInt32(u32),
    /// Unsigned 64-bit integer
    UInt64(u64),
    /// 32-bit floating point
    Float32(f32),
    /// 64-bit floating point
    Float64(f64),
    /// UTF-8 string
    Utf8(String),
    /// Large UTF-8 string
    LargeUtf8(String),
    /// Binary data
    Binary(Vec<u8>),
    /// Large binary data
    LargeBinary(Vec<u8>),
    /// Date (days since epoch)
    Date32(i32),
    /// Date (milliseconds since epoch)
    Date64(i64),
    /// Timestamp with microsecond precision and optional timezone
    TimestampMicrosecond(i64, Option<Arc<str>>),
    /// Timestamp with nanosecond precision and optional timezone
    TimestampNanosecond(i64, Option<Arc<str>>),
    /// Timestamp with millisecond precision and optional timezone
    TimestampMillisecond(i64, Option<Arc<str>>),
    /// Timestamp with second precision and optional timezone
    TimestampSecond(i64, Option<Arc<str>>),
    /// Decimal128 with precision and scale
    Decimal128(i128, u8, i8),
}

impl ScalarValue {
    /// Check if this value is null
    pub fn is_null(&self) -> bool {
        matches!(self, ScalarValue::Null)
    }

    /// Get the data type name
    pub fn data_type_name(&self) -> &'static str {
        match self {
            ScalarValue::Null => "Null",
            ScalarValue::Boolean(_) => "Boolean",
            ScalarValue::Int8(_) => "Int8",
            ScalarValue::Int16(_) => "Int16",
            ScalarValue::Int32(_) => "Int32",
            ScalarValue::Int64(_) => "Int64",
            ScalarValue::UInt8(_) => "UInt8",
            ScalarValue::UInt16(_) => "UInt16",
            ScalarValue::UInt32(_) => "UInt32",
            ScalarValue::UInt64(_) => "UInt64",
            ScalarValue::Float32(_) => "Float32",
            ScalarValue::Float64(_) => "Float64",
            ScalarValue::Utf8(_) => "Utf8",
            ScalarValue::LargeUtf8(_) => "LargeUtf8",
            ScalarValue::Binary(_) => "Binary",
            ScalarValue::LargeBinary(_) => "LargeBinary",
            ScalarValue::Date32(_) => "Date32",
            ScalarValue::Date64(_) => "Date64",
            ScalarValue::TimestampMicrosecond(_, _) => "TimestampMicrosecond",
            ScalarValue::TimestampNanosecond(_, _) => "TimestampNanosecond",
            ScalarValue::TimestampMillisecond(_, _) => "TimestampMillisecond",
            ScalarValue::TimestampSecond(_, _) => "TimestampSecond",
            ScalarValue::Decimal128(_, _, _) => "Decimal128",
        }
    }
}

impl PartialOrd for ScalarValue {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        use std::cmp::Ordering;

        match (self, other) {
            (ScalarValue::Null, ScalarValue::Null) => Some(Ordering::Equal),
            (ScalarValue::Null, _) => Some(Ordering::Less),
            (_, ScalarValue::Null) => Some(Ordering::Greater),

            (ScalarValue::Boolean(a), ScalarValue::Boolean(b)) => a.partial_cmp(b),
            (ScalarValue::Int8(a), ScalarValue::Int8(b)) => a.partial_cmp(b),
            (ScalarValue::Int16(a), ScalarValue::Int16(b)) => a.partial_cmp(b),
            (ScalarValue::Int32(a), ScalarValue::Int32(b)) => a.partial_cmp(b),
            (ScalarValue::Int64(a), ScalarValue::Int64(b)) => a.partial_cmp(b),
            (ScalarValue::UInt8(a), ScalarValue::UInt8(b)) => a.partial_cmp(b),
            (ScalarValue::UInt16(a), ScalarValue::UInt16(b)) => a.partial_cmp(b),
            (ScalarValue::UInt32(a), ScalarValue::UInt32(b)) => a.partial_cmp(b),
            (ScalarValue::UInt64(a), ScalarValue::UInt64(b)) => a.partial_cmp(b),
            (ScalarValue::Float32(a), ScalarValue::Float32(b)) => a.partial_cmp(b),
            (ScalarValue::Float64(a), ScalarValue::Float64(b)) => a.partial_cmp(b),
            (ScalarValue::Utf8(a), ScalarValue::Utf8(b)) => a.partial_cmp(b),
            (ScalarValue::LargeUtf8(a), ScalarValue::LargeUtf8(b)) => a.partial_cmp(b),
            (ScalarValue::Binary(a), ScalarValue::Binary(b)) => a.partial_cmp(b),
            (ScalarValue::LargeBinary(a), ScalarValue::LargeBinary(b)) => a.partial_cmp(b),
            (ScalarValue::Date32(a), ScalarValue::Date32(b)) => a.partial_cmp(b),
            (ScalarValue::Date64(a), ScalarValue::Date64(b)) => a.partial_cmp(b),
            (ScalarValue::TimestampMicrosecond(a, _), ScalarValue::TimestampMicrosecond(b, _)) => {
                a.partial_cmp(b)
            }
            (ScalarValue::TimestampNanosecond(a, _), ScalarValue::TimestampNanosecond(b, _)) => {
                a.partial_cmp(b)
            }
            (ScalarValue::TimestampMillisecond(a, _), ScalarValue::TimestampMillisecond(b, _)) => {
                a.partial_cmp(b)
            }
            (ScalarValue::TimestampSecond(a, _), ScalarValue::TimestampSecond(b, _)) => {
                a.partial_cmp(b)
            }
            (ScalarValue::Decimal128(a, _, _), ScalarValue::Decimal128(b, _, _)) => {
                a.partial_cmp(b)
            }

            // Different types are not comparable
            _ => None,
        }
    }
}

impl fmt::Display for ScalarValue {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ScalarValue::Null => write!(f, "NULL"),
            ScalarValue::Boolean(v) => write!(f, "{}", v),
            ScalarValue::Int8(v) => write!(f, "{}", v),
            ScalarValue::Int16(v) => write!(f, "{}", v),
            ScalarValue::Int32(v) => write!(f, "{}", v),
            ScalarValue::Int64(v) => write!(f, "{}", v),
            ScalarValue::UInt8(v) => write!(f, "{}", v),
            ScalarValue::UInt16(v) => write!(f, "{}", v),
            ScalarValue::UInt32(v) => write!(f, "{}", v),
            ScalarValue::UInt64(v) => write!(f, "{}", v),
            ScalarValue::Float32(v) => write!(f, "{}", v),
            ScalarValue::Float64(v) => write!(f, "{}", v),
            ScalarValue::Utf8(v) => write!(f, "'{}'", v),
            ScalarValue::LargeUtf8(v) => write!(f, "'{}'", v),
            ScalarValue::Binary(v) => write!(f, "0x{}", hex::encode(v)),
            ScalarValue::LargeBinary(v) => write!(f, "0x{}", hex::encode(v)),
            ScalarValue::Date32(v) => write!(f, "DATE({})", v),
            ScalarValue::Date64(v) => write!(f, "DATE({})", v),
            ScalarValue::TimestampMicrosecond(v, tz) => {
                write!(f, "TIMESTAMP({}", v)?;
                if let Some(tz) = tz {
                    write!(f, ", '{}'", tz)?;
                }
                write!(f, ")")
            }
            ScalarValue::TimestampNanosecond(v, tz) => {
                write!(f, "TIMESTAMP_NS({}", v)?;
                if let Some(tz) = tz {
                    write!(f, ", '{}'", tz)?;
                }
                write!(f, ")")
            }
            ScalarValue::TimestampMillisecond(v, tz) => {
                write!(f, "TIMESTAMP_MS({}", v)?;
                if let Some(tz) = tz {
                    write!(f, ", '{}'", tz)?;
                }
                write!(f, ")")
            }
            ScalarValue::TimestampSecond(v, tz) => {
                write!(f, "TIMESTAMP_S({}", v)?;
                if let Some(tz) = tz {
                    write!(f, ", '{}'", tz)?;
                }
                write!(f, ")")
            }
            ScalarValue::Decimal128(v, p, s) => write!(f, "DECIMAL({}, {}, {})", v, p, s),
        }
    }
}

// Helper module for hex encoding in Display
mod hex {
    pub fn encode(bytes: &[u8]) -> String {
        bytes.iter().map(|b| format!("{:02x}", b)).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_statistics_builder() {
        let stats = Statistics::new()
            .with_num_rows(1000)
            .with_byte_size(50000)
            .with_column(
                "id",
                ColumnStatistics::new()
                    .with_null_count(0)
                    .with_min(ScalarValue::Int32(1))
                    .with_max(ScalarValue::Int32(1000)),
            );

        assert_eq!(stats.num_rows, Some(1000));
        assert_eq!(stats.total_byte_size, Some(50000));

        let id_stats = stats.column("id").unwrap();
        assert_eq!(id_stats.null_count, Some(0));
        assert_eq!(id_stats.min_value, Some(ScalarValue::Int32(1)));
        assert_eq!(id_stats.max_value, Some(ScalarValue::Int32(1000)));
    }

    #[test]
    fn test_statistics_merge() {
        let mut stats1 = Statistics::new().with_num_rows(500).with_column(
            "value",
            ColumnStatistics::new()
                .with_min(ScalarValue::Int64(10))
                .with_max(ScalarValue::Int64(100)),
        );

        let stats2 = Statistics::new().with_num_rows(500).with_column(
            "value",
            ColumnStatistics::new()
                .with_min(ScalarValue::Int64(5))
                .with_max(ScalarValue::Int64(200)),
        );

        stats1.merge(&stats2);

        assert_eq!(stats1.num_rows, Some(1000));

        let merged = stats1.column("value").unwrap();
        assert_eq!(merged.min_value, Some(ScalarValue::Int64(5)));
        assert_eq!(merged.max_value, Some(ScalarValue::Int64(200)));
    }

    #[test]
    fn test_scalar_value_comparison() {
        assert!(ScalarValue::Int32(10) < ScalarValue::Int32(20));
        assert!(ScalarValue::Utf8("apple".into()) < ScalarValue::Utf8("banana".into()));
        assert!(ScalarValue::Null < ScalarValue::Int32(0));

        // Different types should not be comparable
        assert!(ScalarValue::Int32(10)
            .partial_cmp(&ScalarValue::Utf8("10".into()))
            .is_none());
    }

    #[test]
    fn test_scalar_value_display() {
        assert_eq!(format!("{}", ScalarValue::Null), "NULL");
        assert_eq!(format!("{}", ScalarValue::Int32(42)), "42");
        assert_eq!(format!("{}", ScalarValue::Utf8("hello".into())), "'hello'");
        assert_eq!(format!("{}", ScalarValue::Boolean(true)), "true");
    }
}
