// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Intelligent encoding selection for columnar data
//!
//! This module provides statistics-based encoding selection to optimize
//! file sizes and query performance based on actual data characteristics.

use arrow::array::{Array, ArrayRef, AsArray};
use arrow::datatypes::{
    DataType, Int16Type, Int32Type, Int64Type, Int8Type, UInt16Type, UInt32Type, UInt64Type,
    UInt8Type,
};
use parquet::basic::Encoding;

/// Statistics computed from column data
#[derive(Debug, Clone, Default)]
pub struct ColumnStats {
    /// Number of rows analyzed
    pub row_count: usize,
    /// Number of distinct values (cardinality)
    pub cardinality: usize,
    /// Number of null values
    pub null_count: usize,
    /// Whether values are monotonically increasing
    pub is_monotonic_increasing: bool,
    /// Whether values are monotonically decreasing
    pub is_monotonic_decreasing: bool,
    /// Average run length (consecutive same values)
    pub avg_run_length: f64,
    /// Ratio of repeated values (for RLE benefit estimation)
    pub repetition_ratio: f64,
}

impl ColumnStats {
    /// Check if column is monotonic (either direction)
    pub fn is_monotonic(&self) -> bool {
        self.is_monotonic_increasing || self.is_monotonic_decreasing
    }

    /// Check if dictionary encoding is likely beneficial
    pub fn benefits_from_dictionary(&self) -> bool {
        // Dictionary is beneficial when cardinality is low relative to row count
        // Rule of thumb: dictionary helps when cardinality < 10% of row count
        // Also cap at 10000 distinct values (larger dictionaries have diminishing returns)
        if self.row_count == 0 {
            return false;
        }
        let threshold = (self.row_count / 10).min(10000);
        self.cardinality < threshold.max(1) // At least 1 to avoid div by zero edge cases
    }

    /// Check if RLE encoding is likely beneficial
    pub fn benefits_from_rle(&self) -> bool {
        self.avg_run_length > 2.0
    }
}

/// Recommended encoding for a column
#[derive(Debug, Clone)]
pub struct EncodingRecommendation {
    /// Primary encoding to use
    pub encoding: RecommendedEncoding,
    /// Whether to enable dictionary
    pub use_dictionary: bool,
    /// Compression codec recommendation
    pub compression: CompressionRecommendation,
    /// Estimated compression ratio (output/input)
    pub estimated_ratio: f64,
    /// Reason for this recommendation
    pub reason: String,
}

/// Encoding types that can be recommended
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RecommendedEncoding {
    /// Plain encoding (Parquet v1 compatible)
    Plain,
    /// Delta binary packed (good for sorted integers)
    DeltaBinaryPacked,
    /// Delta length byte array (good for strings with similar prefixes)
    DeltaLengthByteArray,
    /// Byte stream split (good for floats)
    ByteStreamSplit,
    /// RLE dictionary (good for low cardinality)
    RleDictionary,
}

impl From<RecommendedEncoding> for Encoding {
    fn from(rec: RecommendedEncoding) -> Self {
        match rec {
            RecommendedEncoding::Plain => Encoding::PLAIN,
            RecommendedEncoding::DeltaBinaryPacked => Encoding::DELTA_BINARY_PACKED,
            RecommendedEncoding::DeltaLengthByteArray => Encoding::DELTA_LENGTH_BYTE_ARRAY,
            RecommendedEncoding::ByteStreamSplit => Encoding::BYTE_STREAM_SPLIT,
            RecommendedEncoding::RleDictionary => Encoding::RLE_DICTIONARY,
        }
    }
}

/// Compression recommendations
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CompressionRecommendation {
    /// No compression (data already compressed or random)
    None,
    /// Snappy (fast, moderate ratio)
    Snappy,
    /// Zstd level 1 (balanced)
    ZstdFast,
    /// Zstd level 3 (better ratio)
    ZstdDefault,
    /// Zstd level 6+ (best ratio, slower)
    ZstdHigh,
}

/// Encoding selector that analyzes data and recommends encodings
pub struct EncodingSelector {
    /// Maximum rows to sample for statistics
    sample_size: usize,
}

impl Default for EncodingSelector {
    fn default() -> Self {
        Self::new()
    }
}

impl EncodingSelector {
    /// Create a new encoding selector
    pub fn new() -> Self {
        Self {
            sample_size: 10_000,
        }
    }

    /// Create with custom sample size
    pub fn with_sample_size(mut self, size: usize) -> Self {
        self.sample_size = size;
        self
    }

    /// Analyze a column and compute statistics
    pub fn analyze_column(&self, array: &ArrayRef) -> ColumnStats {
        let row_count = array.len();
        let null_count = array.null_count();

        // For small arrays, analyze everything
        // For large arrays, sample
        let sample_indices: Vec<usize> = if row_count <= self.sample_size {
            (0..row_count).collect()
        } else {
            // Uniform sampling
            let step = row_count / self.sample_size;
            (0..self.sample_size).map(|i| i * step).collect()
        };

        let (cardinality, is_monotonic_inc, is_monotonic_dec, avg_run_length, repetition_ratio) =
            match array.data_type() {
                DataType::Int8 => self.analyze_int_array::<Int8Type>(array, &sample_indices),
                DataType::Int16 => self.analyze_int_array::<Int16Type>(array, &sample_indices),
                DataType::Int32 => self.analyze_int_array::<Int32Type>(array, &sample_indices),
                DataType::Int64 => self.analyze_int_array::<Int64Type>(array, &sample_indices),
                DataType::UInt8 => self.analyze_uint_array::<UInt8Type>(array, &sample_indices),
                DataType::UInt16 => self.analyze_uint_array::<UInt16Type>(array, &sample_indices),
                DataType::UInt32 => self.analyze_uint_array::<UInt32Type>(array, &sample_indices),
                DataType::UInt64 => self.analyze_uint_array::<UInt64Type>(array, &sample_indices),
                DataType::Float32 => self.analyze_float_array(array, &sample_indices),
                DataType::Float64 => self.analyze_float_array(array, &sample_indices),
                DataType::Utf8 => self.analyze_string_array(array, &sample_indices),
                DataType::LargeUtf8 => self.analyze_large_string_array(array, &sample_indices),
                _ => (row_count, false, false, 1.0, 0.0), // Default for unsupported types
            };

        ColumnStats {
            row_count,
            cardinality,
            null_count,
            is_monotonic_increasing: is_monotonic_inc,
            is_monotonic_decreasing: is_monotonic_dec,
            avg_run_length,
            repetition_ratio,
        }
    }

    fn analyze_int_array<T>(
        &self,
        array: &ArrayRef,
        sample_indices: &[usize],
    ) -> (usize, bool, bool, f64, f64)
    where
        T: arrow::datatypes::ArrowPrimitiveType,
        T::Native: Ord + std::hash::Hash + Copy,
    {
        use std::collections::HashSet;

        let typed_array = array.as_primitive::<T>();
        let mut seen = HashSet::new();
        let mut is_mono_inc = true;
        let mut is_mono_dec = true;
        let mut prev_value: Option<T::Native> = None;
        let mut run_length_sum = 0usize;
        let mut run_count = 0usize;
        let mut current_run = 1usize;
        let mut prev_for_run: Option<T::Native> = None;

        for &idx in sample_indices {
            if typed_array.is_null(idx) {
                continue;
            }
            let value = typed_array.value(idx);
            seen.insert(value);

            // Check monotonicity
            if let Some(prev) = prev_value {
                if value < prev {
                    is_mono_inc = false;
                }
                if value > prev {
                    is_mono_dec = false;
                }
            }
            prev_value = Some(value);

            // Track run lengths
            if let Some(prev) = prev_for_run {
                if value == prev {
                    current_run += 1;
                } else {
                    run_length_sum += current_run;
                    run_count += 1;
                    current_run = 1;
                }
            }
            prev_for_run = Some(value);
        }

        // Final run
        if current_run > 1 {
            run_length_sum += current_run;
            run_count += 1;
        }

        let avg_run = if run_count > 0 {
            run_length_sum as f64 / run_count as f64
        } else {
            1.0
        };

        let cardinality = seen.len();
        let repetition = if !sample_indices.is_empty() {
            1.0 - (cardinality as f64 / sample_indices.len() as f64)
        } else {
            0.0
        };

        (
            cardinality,
            is_mono_inc && prev_value.is_some(),
            is_mono_dec && prev_value.is_some(),
            avg_run,
            repetition,
        )
    }

    fn analyze_uint_array<T>(
        &self,
        array: &ArrayRef,
        sample_indices: &[usize],
    ) -> (usize, bool, bool, f64, f64)
    where
        T: arrow::datatypes::ArrowPrimitiveType,
        T::Native: Ord + std::hash::Hash + Copy,
    {
        // Same implementation as int - could be deduplicated
        self.analyze_int_array::<T>(array, sample_indices)
    }

    fn analyze_float_array(
        &self,
        array: &ArrayRef,
        _sample_indices: &[usize],
    ) -> (usize, bool, bool, f64, f64) {
        // Floats typically don't benefit from dictionary or monotonicity
        // Return conservative estimates
        (array.len(), false, false, 1.0, 0.0)
    }

    fn analyze_string_array(
        &self,
        array: &ArrayRef,
        sample_indices: &[usize],
    ) -> (usize, bool, bool, f64, f64) {
        use std::collections::HashSet;

        let typed_array = array.as_string::<i32>();
        let mut seen = HashSet::new();
        let mut run_length_sum = 0usize;
        let mut run_count = 0usize;
        let mut current_run = 1usize;
        let mut prev_value: Option<&str> = None;

        for &idx in sample_indices {
            if typed_array.is_null(idx) {
                continue;
            }
            let value = typed_array.value(idx);
            seen.insert(value.to_string());

            if let Some(prev) = prev_value {
                if value == prev {
                    current_run += 1;
                } else {
                    run_length_sum += current_run;
                    run_count += 1;
                    current_run = 1;
                }
            }
            prev_value = Some(value);
        }

        if current_run > 1 {
            run_length_sum += current_run;
            run_count += 1;
        }

        let avg_run = if run_count > 0 {
            run_length_sum as f64 / run_count as f64
        } else {
            1.0
        };

        let cardinality = seen.len();
        let repetition = if !sample_indices.is_empty() {
            1.0 - (cardinality as f64 / sample_indices.len() as f64)
        } else {
            0.0
        };

        (cardinality, false, false, avg_run, repetition)
    }

    fn analyze_large_string_array(
        &self,
        array: &ArrayRef,
        sample_indices: &[usize],
    ) -> (usize, bool, bool, f64, f64) {
        use std::collections::HashSet;

        let typed_array = array.as_string::<i64>();
        let mut seen = HashSet::new();

        for &idx in sample_indices {
            if typed_array.is_null(idx) {
                continue;
            }
            seen.insert(typed_array.value(idx).to_string());
        }

        let cardinality = seen.len();
        let repetition = if !sample_indices.is_empty() {
            1.0 - (cardinality as f64 / sample_indices.len() as f64)
        } else {
            0.0
        };

        (cardinality, false, false, 1.0, repetition)
    }

    /// Recommend encoding based on data type and statistics
    pub fn recommend_encoding(
        &self,
        data_type: &DataType,
        stats: &ColumnStats,
    ) -> EncodingRecommendation {
        match data_type {
            // Integer types
            DataType::Int8
            | DataType::Int16
            | DataType::Int32
            | DataType::Int64
            | DataType::UInt8
            | DataType::UInt16
            | DataType::UInt32
            | DataType::UInt64 => {
                if stats.is_monotonic() {
                    EncodingRecommendation {
                        encoding: RecommendedEncoding::DeltaBinaryPacked,
                        use_dictionary: false,
                        compression: CompressionRecommendation::ZstdDefault,
                        estimated_ratio: 0.3, // 70% savings for monotonic
                        reason: "Monotonic integers benefit from delta encoding".to_string(),
                    }
                } else if stats.benefits_from_dictionary() {
                    EncodingRecommendation {
                        encoding: RecommendedEncoding::RleDictionary,
                        use_dictionary: true,
                        compression: CompressionRecommendation::ZstdFast,
                        estimated_ratio: 0.4,
                        reason: format!(
                            "Low cardinality ({} distinct values) benefits from dictionary",
                            stats.cardinality
                        ),
                    }
                } else {
                    EncodingRecommendation {
                        encoding: RecommendedEncoding::DeltaBinaryPacked,
                        use_dictionary: false,
                        compression: CompressionRecommendation::ZstdDefault,
                        estimated_ratio: 0.6,
                        reason: "Delta encoding with compression for integers".to_string(),
                    }
                }
            }

            // Timestamp types (usually sequential)
            DataType::Timestamp(_, _) | DataType::Date32 | DataType::Date64 => {
                EncodingRecommendation {
                    encoding: RecommendedEncoding::DeltaBinaryPacked,
                    use_dictionary: false,
                    compression: CompressionRecommendation::ZstdDefault,
                    estimated_ratio: 0.25, // Timestamps compress very well with delta
                    reason: "Timestamps are typically sequential, delta encoding is optimal"
                        .to_string(),
                }
            }

            // Float types
            DataType::Float32 | DataType::Float64 => EncodingRecommendation {
                encoding: RecommendedEncoding::ByteStreamSplit,
                use_dictionary: false,
                compression: CompressionRecommendation::ZstdDefault,
                estimated_ratio: 0.7,
                reason: "Byte stream split groups similar bytes for better compression".to_string(),
            },

            // String types
            DataType::Utf8 | DataType::LargeUtf8 => {
                if stats.benefits_from_dictionary() {
                    EncodingRecommendation {
                        encoding: RecommendedEncoding::RleDictionary,
                        use_dictionary: true,
                        compression: CompressionRecommendation::ZstdDefault,
                        estimated_ratio: 0.2, // Dictionary can be very effective
                        reason: format!(
                            "Low cardinality strings ({} distinct) benefit from dictionary",
                            stats.cardinality
                        ),
                    }
                } else {
                    EncodingRecommendation {
                        encoding: RecommendedEncoding::DeltaLengthByteArray,
                        use_dictionary: false,
                        compression: CompressionRecommendation::ZstdHigh,
                        estimated_ratio: 0.5,
                        reason: "High cardinality strings with compression".to_string(),
                    }
                }
            }

            // Binary types
            DataType::Binary | DataType::LargeBinary => EncodingRecommendation {
                encoding: RecommendedEncoding::Plain,
                use_dictionary: false,
                compression: CompressionRecommendation::ZstdDefault,
                estimated_ratio: 0.8,
                reason: "Binary data uses plain encoding with compression".to_string(),
            },

            // Fixed size binary (often embeddings)
            DataType::FixedSizeBinary(size) if *size >= 256 => {
                EncodingRecommendation {
                    encoding: RecommendedEncoding::Plain,
                    use_dictionary: false,
                    compression: CompressionRecommendation::None, // Embeddings don't compress well
                    estimated_ratio: 1.0,
                    reason: "Large fixed binary (likely embeddings) - minimal compression benefit"
                        .to_string(),
                }
            }

            // Boolean
            DataType::Boolean => {
                EncodingRecommendation {
                    encoding: RecommendedEncoding::RleDictionary,
                    use_dictionary: true,
                    compression: CompressionRecommendation::Snappy,
                    estimated_ratio: 0.1, // Booleans compress extremely well
                    reason: "Booleans use RLE encoding by default".to_string(),
                }
            }

            // Default for other types
            _ => EncodingRecommendation {
                encoding: RecommendedEncoding::Plain,
                use_dictionary: stats.benefits_from_dictionary(),
                compression: CompressionRecommendation::ZstdDefault,
                estimated_ratio: 0.7,
                reason: "Using safe defaults for complex type".to_string(),
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Float64Array, Int64Array, StringArray};
    use std::sync::Arc;

    #[test]
    fn test_monotonic_detection() {
        let selector = EncodingSelector::new();

        // Monotonically increasing
        let array: ArrayRef = Arc::new(Int64Array::from(vec![1, 2, 3, 4, 5, 6, 7, 8, 9, 10]));
        let stats = selector.analyze_column(&array);
        assert!(stats.is_monotonic_increasing);
        assert!(!stats.is_monotonic_decreasing);

        // Monotonically decreasing
        let array: ArrayRef = Arc::new(Int64Array::from(vec![10, 9, 8, 7, 6, 5, 4, 3, 2, 1]));
        let stats = selector.analyze_column(&array);
        assert!(!stats.is_monotonic_increasing);
        assert!(stats.is_monotonic_decreasing);

        // Not monotonic
        let array: ArrayRef = Arc::new(Int64Array::from(vec![1, 3, 2, 4, 3, 5, 4, 6]));
        let stats = selector.analyze_column(&array);
        assert!(!stats.is_monotonic());
    }

    #[test]
    fn test_cardinality_detection() {
        let selector = EncodingSelector::new();

        // Low cardinality
        let values: Vec<&str> = (0..1000)
            .map(|i| if i % 2 == 0 { "A" } else { "B" })
            .collect();
        let array: ArrayRef = Arc::new(StringArray::from(values));
        let stats = selector.analyze_column(&array);
        assert_eq!(stats.cardinality, 2);
        assert!(stats.benefits_from_dictionary());

        // High cardinality
        let values: Vec<i64> = (0..1000).collect();
        let array: ArrayRef = Arc::new(Int64Array::from(values));
        let stats = selector.analyze_column(&array);
        assert_eq!(stats.cardinality, 1000);
        assert!(!stats.benefits_from_dictionary());
    }

    #[test]
    fn test_encoding_recommendations() {
        let selector = EncodingSelector::new();

        // Monotonic integers -> Delta
        let array: ArrayRef = Arc::new(Int64Array::from((0..1000).collect::<Vec<_>>()));
        let stats = selector.analyze_column(&array);
        let rec = selector.recommend_encoding(&DataType::Int64, &stats);
        assert_eq!(rec.encoding, RecommendedEncoding::DeltaBinaryPacked);

        // Low cardinality strings -> Dictionary
        let values: Vec<&str> = (0..1000)
            .map(|i| {
                if i % 3 == 0 {
                    "A"
                } else if i % 3 == 1 {
                    "B"
                } else {
                    "C"
                }
            })
            .collect();
        let array: ArrayRef = Arc::new(StringArray::from(values));
        let stats = selector.analyze_column(&array);
        let rec = selector.recommend_encoding(&DataType::Utf8, &stats);
        assert_eq!(rec.encoding, RecommendedEncoding::RleDictionary);
        assert!(rec.use_dictionary);

        // Floats -> Byte stream split
        let array: ArrayRef = Arc::new(Float64Array::from(vec![1.1, 2.2, 3.3, 4.4, 5.5]));
        let stats = selector.analyze_column(&array);
        let rec = selector.recommend_encoding(&DataType::Float64, &stats);
        assert_eq!(rec.encoding, RecommendedEncoding::ByteStreamSplit);
    }

    #[test]
    fn test_null_handling() {
        let selector = EncodingSelector::new();

        let array: ArrayRef = Arc::new(Int64Array::from(vec![
            Some(1),
            None,
            Some(2),
            None,
            Some(3),
            None,
        ]));
        let stats = selector.analyze_column(&array);
        assert_eq!(stats.null_count, 3);
        assert_eq!(stats.row_count, 6);
    }
}
