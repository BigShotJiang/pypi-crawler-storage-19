// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! DuckDB extension implementation
//!
//! This provides the building blocks for a DuckDB extension.
//! The actual C ABI extension would be built separately.

use bytes::Bytes;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use tokio::runtime::Runtime;
use tokio::sync::RwLock;
use tracing::{debug, info};

use crate::transcoder::Transcoder;
use crate::writers::ParquetWriterOptions;
use crate::{Error, Result};

/// Configuration for the DuckDB extension
#[derive(Debug, Clone)]
pub struct DuckDbExtensionConfig {
    /// Enable caching of transcoded files
    pub enable_cache: bool,
    /// Max cache size in bytes
    pub max_cache_bytes: usize,
    /// Parquet writer options
    pub writer_options: ParquetWriterOptions,
    /// Extensions to auto-transcode
    pub transcode_extensions: Vec<String>,
    /// Enable replacement scans (intercept read_parquet)
    pub enable_replacement_scan: bool,
}

impl Default for DuckDbExtensionConfig {
    fn default() -> Self {
        Self {
            enable_cache: true,
            max_cache_bytes: 1024 * 1024 * 1024, // 1GB
            writer_options: ParquetWriterOptions::max_compatibility(),
            transcode_extensions: vec!["vortex".to_string(), "lance".to_string(), "f3".to_string()],
            enable_replacement_scan: true,
        }
    }
}

/// File handle for DuckDB filesystem
pub struct RosettaFileHandle {
    /// Transcoded data (Parquet bytes)
    data: Bytes,
    /// Current read position
    position: usize,
    /// Original path
    #[allow(dead_code)]
    path: PathBuf,
}

impl RosettaFileHandle {
    /// Get file size
    pub fn size(&self) -> usize {
        self.data.len()
    }

    /// Read bytes from current position
    pub fn read(&mut self, buf: &mut [u8]) -> usize {
        let remaining = self.data.len() - self.position;
        let to_read = buf.len().min(remaining);

        if to_read > 0 {
            buf[..to_read].copy_from_slice(&self.data[self.position..self.position + to_read]);
            self.position += to_read;
        }

        to_read
    }

    /// Seek to position
    pub fn seek(&mut self, position: usize) {
        self.position = position.min(self.data.len());
    }

    /// Get current position
    pub fn tell(&self) -> usize {
        self.position
    }
}

/// Cache entry
struct CacheEntry {
    data: Bytes,
    size: usize,
}

/// DuckDB extension providing custom filesystem and replacement scans
pub struct DuckDbExtension {
    config: DuckDbExtensionConfig,
    cache: Arc<RwLock<HashMap<PathBuf, CacheEntry>>>,
    cache_size: Arc<RwLock<usize>>,
    runtime: Arc<Runtime>,
    transcoder: Transcoder,
}

impl DuckDbExtension {
    /// Create a new extension instance
    pub fn new(config: DuckDbExtensionConfig) -> Result<Self> {
        let runtime = tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .enable_all()
            .build()
            .map_err(|e| Error::io_error(format!("Runtime error: {}", e)))?;

        let transcoder = Transcoder::new().with_writer_options(config.writer_options.clone());

        Ok(Self {
            config,
            cache: Arc::new(RwLock::new(HashMap::new())),
            cache_size: Arc::new(RwLock::new(0)),
            runtime: Arc::new(runtime),
            transcoder,
        })
    }

    /// Create with default config
    pub fn default_config() -> Result<Self> {
        Self::new(DuckDbExtensionConfig::default())
    }

    // ==================== FileSystem Interface ====================

    /// Open a file, transcoding if necessary
    pub fn open(&self, path: &str) -> Result<RosettaFileHandle> {
        let path = self.parse_path(path)?;
        let data = self.get_or_transcode(&path)?;

        Ok(RosettaFileHandle {
            data,
            position: 0,
            path,
        })
    }

    /// Check if a path needs transcoding
    pub fn needs_transcode(&self, path: &str) -> bool {
        let path = Path::new(path);
        if let Some(ext) = path.extension() {
            let ext_str = ext.to_string_lossy().to_lowercase();
            self.config.transcode_extensions.contains(&ext_str)
        } else {
            false
        }
    }

    /// List files (delegates to underlying filesystem)
    pub fn list_files(&self, dir: &str) -> Result<Vec<String>> {
        let path = self.parse_path(dir)?;
        let mut files = Vec::new();

        for entry in std::fs::read_dir(&path)
            .map_err(|e| Error::io_error(format!("Read dir failed: {}", e)))?
            .flatten()
        {
            files.push(entry.file_name().to_string_lossy().to_string());
        }

        Ok(files)
    }

    /// Get file info
    pub fn file_info(&self, path: &str) -> Result<FileInfo> {
        let path = self.parse_path(path)?;

        // If transcoded, return transcoded size
        if self.should_transcode(&path) {
            let data = self.get_or_transcode(&path)?;
            return Ok(FileInfo {
                size: data.len() as u64,
                is_file: true,
                is_dir: false,
            });
        }

        // Otherwise, return real file info
        let meta = std::fs::metadata(&path)
            .map_err(|e| Error::io_error(format!("Metadata failed: {}", e)))?;

        Ok(FileInfo {
            size: meta.len(),
            is_file: meta.is_file(),
            is_dir: meta.is_dir(),
        })
    }

    // ==================== Replacement Scan Interface ====================

    /// Called by DuckDB when read_parquet is invoked
    /// Returns None if we should let DuckDB handle it normally
    pub fn replacement_scan(&self, path: &str) -> Option<Result<Bytes>> {
        if !self.config.enable_replacement_scan {
            return None;
        }

        let path_obj = Path::new(path);
        if !self.should_transcode(path_obj) {
            return None;
        }

        // Transcode and return
        Some(self.get_or_transcode(path_obj))
    }

    // ==================== Internal Methods ====================

    /// Parse a rosetta:// or regular path
    fn parse_path(&self, path: &str) -> Result<PathBuf> {
        let path = path.strip_prefix("rosetta://").unwrap_or(path);

        Ok(PathBuf::from(path))
    }

    /// Check if path should be transcoded
    fn should_transcode(&self, path: &Path) -> bool {
        if let Some(ext) = path.extension() {
            let ext_str = ext.to_string_lossy().to_lowercase();
            self.config.transcode_extensions.contains(&ext_str)
        } else {
            false
        }
    }

    /// Get from cache or transcode
    fn get_or_transcode(&self, path: &Path) -> Result<Bytes> {
        // Check cache
        if self.config.enable_cache {
            let cache = self.runtime.block_on(self.cache.read());
            if let Some(entry) = cache.get(path) {
                debug!(?path, "Cache hit");
                return Ok(entry.data.clone());
            }
        }

        // Need to transcode
        debug!(?path, "Transcoding for DuckDB");

        let data = if self.should_transcode(path) {
            let result = self
                .runtime
                .block_on(self.transcoder.transcode_file(path))?;
            result.bytes
        } else {
            // Passthrough for non-transcoded files
            let bytes =
                std::fs::read(path).map_err(|e| Error::io_error(format!("Read failed: {}", e)))?;
            Bytes::from(bytes)
        };

        // Cache
        if self.config.enable_cache {
            let mut cache = self.runtime.block_on(self.cache.write());
            let mut cache_size = self.runtime.block_on(self.cache_size.write());

            // Evict if needed
            while *cache_size + data.len() > self.config.max_cache_bytes {
                if let Some(oldest) = cache.keys().next().cloned() {
                    if let Some(entry) = cache.remove(&oldest) {
                        *cache_size -= entry.size;
                    }
                } else {
                    break;
                }
            }

            *cache_size += data.len();
            cache.insert(
                path.to_path_buf(),
                CacheEntry {
                    data: data.clone(),
                    size: data.len(),
                },
            );
        }

        Ok(data)
    }

    /// Clear the cache
    pub fn clear_cache(&self) {
        let mut cache = self.runtime.block_on(self.cache.write());
        let mut cache_size = self.runtime.block_on(self.cache_size.write());
        cache.clear();
        *cache_size = 0;
        info!("DuckDB extension cache cleared");
    }

    /// Get cache statistics
    pub fn cache_stats(&self) -> CacheStats {
        let cache = self.runtime.block_on(self.cache.read());
        let cache_size = self.runtime.block_on(self.cache_size.read());

        CacheStats {
            entries: cache.len(),
            total_bytes: *cache_size,
            max_bytes: self.config.max_cache_bytes,
        }
    }
}

/// File information
#[derive(Debug, Clone)]
pub struct FileInfo {
    pub size: u64,
    pub is_file: bool,
    pub is_dir: bool,
}

/// Cache statistics
#[derive(Debug, Clone)]
pub struct CacheStats {
    pub entries: usize,
    pub total_bytes: usize,
    pub max_bytes: usize,
}

// ==================== C ABI for DuckDB Extension ====================
// These would be the actual exported functions for a DuckDB loadable extension

/// Extension version info
#[allow(dead_code)]
pub const EXTENSION_NAME: &str = "rosetta";
#[allow(dead_code)]
pub const EXTENSION_VERSION: &str = env!("CARGO_PKG_VERSION");

/// SQL to register the extension
#[allow(dead_code)]
pub const REGISTER_SQL: &str = r#"
-- Rosetta: Universal Columnar Format Bridge for DuckDB
-- Enables transparent reading of Vortex, Lance, F3, and other formats

-- Example usage:
-- SELECT * FROM read_parquet('rosetta://data.vortex');
-- SELECT * FROM read_parquet('data.lance');  -- With replacement scan

-- The extension automatically:
-- 1. Detects the actual file format
-- 2. Transcodes to Parquet v1 bytes
-- 3. Returns data to DuckDB's Parquet reader
"#;

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Int32Array, StringArray};
    use arrow::datatypes::{DataType, Field, Schema};
    use arrow::record_batch::RecordBatch;
    use parquet::arrow::ArrowWriter;
    use std::sync::Arc;
    use tempfile::NamedTempFile;

    fn create_test_parquet() -> NamedTempFile {
        let file = NamedTempFile::new().unwrap();

        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, true),
        ]));

        let ids = Int32Array::from(vec![1, 2, 3]);
        let names = StringArray::from(vec![Some("a"), Some("b"), Some("c")]);

        let batch =
            RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

        let file_writer = std::fs::File::create(file.path()).unwrap();
        let mut writer = ArrowWriter::try_new(file_writer, schema, None).unwrap();
        writer.write(&batch).unwrap();
        writer.close().unwrap();

        file
    }

    #[test]
    fn test_extension_creation() {
        let ext = DuckDbExtension::default_config().unwrap();
        assert!(ext.config.enable_cache);
    }

    #[test]
    fn test_needs_transcode() {
        let ext = DuckDbExtension::default_config().unwrap();

        assert!(ext.needs_transcode("data.vortex"));
        assert!(ext.needs_transcode("path/to/data.lance"));
        assert!(!ext.needs_transcode("data.parquet"));
        assert!(!ext.needs_transcode("data.csv"));
    }

    #[test]
    fn test_parse_path() {
        let ext = DuckDbExtension::default_config().unwrap();

        let path = ext.parse_path("rosetta://data/file.vortex").unwrap();
        assert_eq!(path, PathBuf::from("data/file.vortex"));

        let path = ext.parse_path("/absolute/path.parquet").unwrap();
        assert_eq!(path, PathBuf::from("/absolute/path.parquet"));
    }

    #[test]
    fn test_open_parquet_file() {
        let file = create_test_parquet();
        let ext = DuckDbExtension::default_config().unwrap();

        let handle = ext.open(file.path().to_str().unwrap()).unwrap();
        assert!(handle.size() > 0);
    }

    #[test]
    fn test_file_handle_read() {
        let file = create_test_parquet();
        let ext = DuckDbExtension::default_config().unwrap();

        let mut handle = ext.open(file.path().to_str().unwrap()).unwrap();

        // Read first 4 bytes (Parquet magic)
        let mut buf = [0u8; 4];
        let read = handle.read(&mut buf);
        assert_eq!(read, 4);
        assert_eq!(&buf, b"PAR1");

        // Check position
        assert_eq!(handle.tell(), 4);

        // Seek back
        handle.seek(0);
        assert_eq!(handle.tell(), 0);
    }

    #[test]
    fn test_cache_stats() {
        let ext = DuckDbExtension::default_config().unwrap();
        let stats = ext.cache_stats();
        assert_eq!(stats.entries, 0);
    }
}
