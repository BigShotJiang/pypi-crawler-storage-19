// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! DuckDB extension for transparent format transcoding
//!
//! This module provides a DuckDB extension that enables reading any
//! supported columnar format through DuckDB's Parquet interface.
//!
//! # How It Works
//!
//! Two integration approaches:
//!
//! ## 1. Custom Filesystem (Recommended)
//!
//! ```sql
//! -- Register the Rosetta filesystem
//! LOAD rosetta;
//!
//! -- Now any path works transparently
//! SELECT * FROM read_parquet('rosetta://data.vortex');
//! SELECT * FROM 'rosetta://bucket/data.lance';
//! ```
//!
//! ## 2. Replacement Scan
//!
//! ```sql
//! -- Rosetta intercepts parquet reads
//! SELECT * FROM read_parquet('data.vortex');  -- Works!
//! ```
//!
//! # Architecture
//!
//! ```text
//! DuckDB Query
//!     │
//!     │ read_parquet('rosetta://data.vortex')
//!     ▼
//! ┌─────────────────┐
//! │ RosettaFS       │  Custom FileSystem implementation
//! └─────────────────┘
//!     │
//!     │ Open file, detect format
//!     ▼
//! ┌─────────────────┐
//! │ Transcoder      │  Vortex → Arrow → Parquet bytes
//! └─────────────────┘
//!     │
//!     ▼
//! DuckDB sees valid Parquet
//! ```

mod extension;

pub use extension::{DuckDbExtension, DuckDbExtensionConfig};
