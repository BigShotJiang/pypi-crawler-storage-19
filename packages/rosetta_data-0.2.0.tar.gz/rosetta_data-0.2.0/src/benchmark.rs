// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Benchmark module for measuring read performance
//!
//! This module provides utilities for generating test data and running
//! performance benchmarks comparing native Parquet reads with Rosetta.

use arrow::array::{
    BooleanArray, Float64Array, Int64Array, StringArray, TimestampMicrosecondArray,
};
use arrow::datatypes::{DataType, Field, Schema, TimeUnit};
use arrow::record_batch::RecordBatch;
use parquet::arrow::ArrowWriter;
use parquet::basic::Compression;
use parquet::file::properties::WriterProperties;
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::{Result, UnifiedReader};

/// Configuration for benchmark data generation
#[derive(Debug, Clone)]
pub struct BenchmarkConfig {
    /// Number of rows to generate
    pub num_rows: usize,
    /// Number of row groups
    pub num_row_groups: usize,
    /// Compression codec
    pub compression: BenchmarkCompression,
    /// Output path
    pub output_path: String,
}

impl Default for BenchmarkConfig {
    fn default() -> Self {
        Self {
            num_rows: 100_000,
            num_row_groups: 1,
            compression: BenchmarkCompression::Snappy,
            output_path: "/tmp/rosetta_benchmark.parquet".to_string(),
        }
    }
}

impl BenchmarkConfig {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_rows(mut self, rows: usize) -> Self {
        self.num_rows = rows;
        self
    }

    pub fn with_path(mut self, path: impl Into<String>) -> Self {
        self.output_path = path.into();
        self
    }
}

/// Compression options for benchmarks
#[derive(Debug, Clone, Copy)]
pub enum BenchmarkCompression {
    None,
    Snappy,
    Zstd,
}

impl From<BenchmarkCompression> for Compression {
    fn from(c: BenchmarkCompression) -> Self {
        match c {
            BenchmarkCompression::None => Compression::UNCOMPRESSED,
            BenchmarkCompression::Snappy => Compression::SNAPPY,
            BenchmarkCompression::Zstd => Compression::ZSTD(Default::default()),
        }
    }
}

/// Results from a benchmark run
#[derive(Debug, Clone)]
pub struct BenchmarkResult {
    /// Name of the benchmark
    pub name: String,
    /// Number of rows read
    pub rows: usize,
    /// File size in bytes
    pub file_size: u64,
    /// Number of iterations
    pub iterations: usize,
    /// Minimum time
    pub min_time: Duration,
    /// Maximum time
    pub max_time: Duration,
    /// Median time
    pub median_time: Duration,
    /// Mean time
    pub mean_time: Duration,
    /// Throughput in MiB/s (based on median)
    pub throughput_mibs: f64,
}

impl BenchmarkResult {
    pub fn report(&self) -> String {
        format!(
            "{}: {} rows, {:.2} MiB\n  Min: {:.2?}, Max: {:.2?}, Median: {:.2?}\n  Throughput: {:.0} MiB/s",
            self.name,
            self.rows,
            self.file_size as f64 / 1024.0 / 1024.0,
            self.min_time,
            self.max_time,
            self.median_time,
            self.throughput_mibs
        )
    }
}

/// Generate benchmark data file
pub fn generate_benchmark_file(config: &BenchmarkConfig) -> Result<String> {
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int64, false),
        Field::new(
            "timestamp",
            DataType::Timestamp(TimeUnit::Microsecond, None),
            false,
        ),
        Field::new("customer_id", DataType::Int64, false),
        Field::new("product_name", DataType::Utf8, true),
        Field::new("quantity", DataType::Int64, false),
        Field::new("price", DataType::Float64, false),
        Field::new("discount", DataType::Float64, true),
        Field::new("is_premium", DataType::Boolean, false),
        Field::new("category", DataType::Utf8, true),
        Field::new("region", DataType::Utf8, true),
    ]));

    let rows_per_batch = config.num_rows / config.num_row_groups.max(1);
    let props = WriterProperties::builder()
        .set_compression(config.compression.into())
        .build();

    let file = std::fs::File::create(&config.output_path)?;
    let mut writer = ArrowWriter::try_new(file, schema.clone(), Some(props))
        .map_err(|e| crate::Error::invalid_file(format!("Failed to create writer: {}", e)))?;

    // Product and category names for variety
    let products = ["Widget A", "Widget B", "Gadget X", "Gadget Y", "Tool Z"];
    let categories = ["Electronics", "Home", "Office", "Outdoor", "Sports"];
    let regions = ["North", "South", "East", "West", "Central"];

    for batch_idx in 0..config.num_row_groups {
        let start_id = batch_idx * rows_per_batch;
        let batch_rows = if batch_idx == config.num_row_groups - 1 {
            config.num_rows - start_id
        } else {
            rows_per_batch
        };

        // Generate data
        let ids: Vec<i64> = (start_id..start_id + batch_rows)
            .map(|i| i as i64)
            .collect();
        let timestamps: Vec<i64> = (0..batch_rows)
            .map(|i| 1704067200000000 + (i * 1000) as i64) // Start from 2024-01-01
            .collect();
        let customer_ids: Vec<i64> = (0..batch_rows).map(|i| (i % 10000) as i64).collect();
        let product_names: Vec<&str> = (0..batch_rows)
            .map(|i| products[i % products.len()])
            .collect();
        let quantities: Vec<i64> = (0..batch_rows).map(|i| ((i % 100) + 1) as i64).collect();
        let prices: Vec<f64> = (0..batch_rows).map(|i| (i % 1000) as f64 * 0.99).collect();
        let discounts: Vec<Option<f64>> = (0..batch_rows)
            .map(|i| {
                if i % 10 == 0 {
                    Some((i % 30) as f64 / 100.0)
                } else {
                    None
                }
            })
            .collect();
        let is_premium: Vec<bool> = (0..batch_rows).map(|i| i % 5 == 0).collect();
        let category_values: Vec<&str> = (0..batch_rows)
            .map(|i| categories[i % categories.len()])
            .collect();
        let region_values: Vec<&str> = (0..batch_rows)
            .map(|i| regions[i % regions.len()])
            .collect();

        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int64Array::from(ids)),
                Arc::new(TimestampMicrosecondArray::from(timestamps)),
                Arc::new(Int64Array::from(customer_ids)),
                Arc::new(StringArray::from(product_names)),
                Arc::new(Int64Array::from(quantities)),
                Arc::new(Float64Array::from(prices)),
                Arc::new(Float64Array::from(discounts)),
                Arc::new(BooleanArray::from(is_premium)),
                Arc::new(StringArray::from(category_values)),
                Arc::new(StringArray::from(region_values)),
            ],
        )
        .map_err(|e| crate::Error::invalid_file(format!("Failed to create batch: {}", e)))?;

        writer
            .write(&batch)
            .map_err(|e| crate::Error::invalid_file(format!("Failed to write batch: {}", e)))?;
    }

    writer
        .close()
        .map_err(|e| crate::Error::invalid_file(format!("Failed to close writer: {}", e)))?;

    Ok(config.output_path.clone())
}

/// Run a read benchmark using Rosetta async API
pub async fn benchmark_rosetta_async(path: &str, iterations: usize) -> Result<BenchmarkResult> {
    benchmark_rosetta_async_opts(path, iterations, true).await
}

/// Run a read benchmark using Rosetta async API with warmup option
pub async fn benchmark_rosetta_async_opts(
    path: &str,
    iterations: usize,
    warmup: bool,
) -> Result<BenchmarkResult> {
    let file_size = std::fs::metadata(path)?.len();
    let mut times = Vec::with_capacity(iterations);

    // Warmup (optional)
    if warmup {
        let reader = UnifiedReader::open(path).await?;
        let _ = reader.read_all().await?;
    }

    // Benchmark runs
    for _ in 0..iterations {
        let start = Instant::now();
        let reader = UnifiedReader::open(path).await?;
        let batches = reader.read_all().await?;
        let _ = batches.iter().map(|b| b.num_rows()).sum::<usize>();
        times.push(start.elapsed());
    }

    calculate_results("Rosetta Async", times, file_size, path)
}

/// Run a read benchmark using Rosetta sync API
pub fn benchmark_rosetta_sync(path: &str, iterations: usize) -> Result<BenchmarkResult> {
    benchmark_rosetta_sync_opts(path, iterations, true)
}

/// Run a read benchmark using Rosetta sync API with warmup option
pub fn benchmark_rosetta_sync_opts(
    path: &str,
    iterations: usize,
    warmup: bool,
) -> Result<BenchmarkResult> {
    let file_size = std::fs::metadata(path)?.len();
    let mut times = Vec::with_capacity(iterations);

    // Warmup (optional)
    if warmup {
        let reader = UnifiedReader::open_parquet_sync(path)?;
        let _ = reader.read_all_sync()?;
    }

    // Benchmark runs
    for _ in 0..iterations {
        let start = Instant::now();
        let reader = UnifiedReader::open_parquet_sync(path)?;
        let batches = reader.read_all_sync()?;
        let _ = batches.iter().map(|b| b.num_rows()).sum::<usize>();
        times.push(start.elapsed());
    }

    calculate_results("Rosetta Sync", times, file_size, path)
}

/// Run a read benchmark using native Parquet API
pub fn benchmark_native_parquet(path: &str, iterations: usize) -> Result<BenchmarkResult> {
    benchmark_native_parquet_opts(path, iterations, true)
}

/// Run a read benchmark using native Parquet API with warmup option
pub fn benchmark_native_parquet_opts(
    path: &str,
    iterations: usize,
    warmup: bool,
) -> Result<BenchmarkResult> {
    use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;

    let file_size = std::fs::metadata(path)?.len();
    let mut times = Vec::with_capacity(iterations);

    // Warmup (optional)
    if warmup {
        let file = std::fs::File::open(path)?;
        let reader = ParquetRecordBatchReaderBuilder::try_new(file)
            .map_err(|e| crate::Error::invalid_file(e.to_string()))?
            .build()
            .map_err(|e| crate::Error::invalid_file(e.to_string()))?;
        let _: Vec<_> = reader.collect();
    }

    // Benchmark runs
    for _ in 0..iterations {
        let start = Instant::now();
        let file = std::fs::File::open(path)?;
        let reader = ParquetRecordBatchReaderBuilder::try_new(file)
            .map_err(|e| crate::Error::invalid_file(e.to_string()))?
            .build()
            .map_err(|e| crate::Error::invalid_file(e.to_string()))?;
        let batches: Vec<_> = reader.collect();
        let _ = batches.len();
        times.push(start.elapsed());
    }

    calculate_results("Native Parquet", times, file_size, path)
}

fn calculate_results(
    name: &str,
    mut times: Vec<Duration>,
    file_size: u64,
    path: &str,
) -> Result<BenchmarkResult> {
    times.sort();
    let iterations = times.len();

    let min_time = *times.first().unwrap();
    let max_time = *times.last().unwrap();
    let median_time = times[iterations / 2];
    let total: Duration = times.iter().sum();
    let mean_time = total / iterations as u32;

    // Get row count from file
    let rows = UnifiedReader::open_parquet_sync(path)
        .ok()
        .and_then(|r| r.read_all_sync().ok())
        .map(|b| b.iter().map(|batch| batch.num_rows()).sum())
        .unwrap_or(0);

    let throughput_mibs = file_size as f64 / 1024.0 / 1024.0 / median_time.as_secs_f64();

    Ok(BenchmarkResult {
        name: name.to_string(),
        rows,
        file_size,
        iterations,
        min_time,
        max_time,
        median_time,
        mean_time,
        throughput_mibs,
    })
}

/// Run a complete benchmark suite and return all results
///
/// Order: Rosetta Sync -> Rosetta Async -> Native Parquet (baseline last to avoid cache bias)
pub async fn run_benchmark_suite(path: &str, iterations: usize) -> Result<Vec<BenchmarkResult>> {
    run_benchmark_suite_opts(path, iterations, true).await
}

/// Run benchmark suite with warmup option
pub async fn run_benchmark_suite_opts(
    path: &str,
    iterations: usize,
    warmup: bool,
) -> Result<Vec<BenchmarkResult>> {
    let mut results = Vec::new();

    // Rosetta sync first (to avoid filesystem cache warming from baseline)
    results.push(benchmark_rosetta_sync_opts(path, iterations, warmup)?);

    // Rosetta async
    results.push(benchmark_rosetta_async_opts(path, iterations, warmup).await?);

    // Native Parquet baseline LAST
    results.push(benchmark_native_parquet_opts(path, iterations, warmup)?);

    Ok(results)
}

/// Generate a markdown report from benchmark results
pub fn generate_report(results: &[BenchmarkResult], file_path: &str) -> String {
    // Find native parquet as baseline (not necessarily first anymore)
    let native = results.iter().find(|r| r.name == "Native Parquet");
    let file_size_mib = native
        .map(|r| r.file_size as f64 / 1024.0 / 1024.0)
        .unwrap_or(0.0);
    let rows = native.map(|r| r.rows).unwrap_or(0);

    let mut report = format!(
        r#"# Rosetta Benchmark Results

## Test Configuration
- **File:** {}
- **Size:** {:.2} MiB
- **Rows:** {}
- **Iterations:** {}

## Results

| Reader | Median Time | Throughput | Overhead |
|--------|-------------|------------|----------|
"#,
        file_path,
        file_size_mib,
        rows,
        native.map(|r| r.iterations).unwrap_or(0)
    );

    let baseline = native.map(|r| r.median_time.as_nanos()).unwrap_or(1);

    for result in results {
        let overhead = if result.name == "Native Parquet" {
            "-".to_string()
        } else {
            let overhead_pct =
                ((result.median_time.as_nanos() as f64 / baseline as f64) - 1.0) * 100.0;
            if overhead_pct < 0.0 {
                format!("{:.1}% faster", -overhead_pct)
            } else {
                format!("+{:.1}%", overhead_pct)
            }
        };

        report.push_str(&format!(
            "| {} | {:.2?} | {:.0} MiB/s | {} |\n",
            result.name, result.median_time, result.throughput_mibs, overhead
        ));
    }

    report.push_str("\n## Analysis\n\n");

    if let Some(sync) = results.iter().find(|r| r.name == "Rosetta Sync") {
        if let Some(native) = results.iter().find(|r| r.name == "Native Parquet") {
            let overhead_pct =
                ((sync.median_time.as_nanos() as f64 / native.median_time.as_nanos() as f64) - 1.0)
                    * 100.0;
            if overhead_pct <= 5.0 {
                report.push_str(&format!(
                    "Rosetta's sync path achieves **near-zero overhead** ({:.1}%) compared to native Parquet reading.\n",
                    overhead_pct
                ));
            } else {
                report.push_str(&format!(
                    "Rosetta's sync path has {:.1}% overhead compared to native Parquet reading.\n",
                    overhead_pct
                ));
            }
        }
    }

    report
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;

    #[test]
    fn test_generate_benchmark_file() {
        let config = BenchmarkConfig::new()
            .with_rows(1000)
            .with_path("/tmp/test_benchmark.parquet");

        let path = generate_benchmark_file(&config).unwrap();
        assert!(Path::new(&path).exists());

        // Verify file is readable
        let reader = UnifiedReader::open_parquet_sync(&path).unwrap();
        let batches = reader.read_all_sync().unwrap();
        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();
        assert_eq!(total_rows, 1000);

        // Cleanup
        std::fs::remove_file(&path).ok();
    }

    #[test]
    fn test_native_benchmark() {
        let config = BenchmarkConfig::new()
            .with_rows(1000)
            .with_path("/tmp/test_bench_native.parquet");

        generate_benchmark_file(&config).unwrap();
        let result = benchmark_native_parquet(&config.output_path, 3).unwrap();

        assert!(result.throughput_mibs > 0.0);
        assert!(result.min_time <= result.max_time);

        std::fs::remove_file(&config.output_path).ok();
    }

    #[test]
    fn test_sync_benchmark() {
        let config = BenchmarkConfig::new()
            .with_rows(1000)
            .with_path("/tmp/test_bench_sync.parquet");

        generate_benchmark_file(&config).unwrap();
        let result = benchmark_rosetta_sync(&config.output_path, 3).unwrap();

        assert!(result.throughput_mibs > 0.0);

        std::fs::remove_file(&config.output_path).ok();
    }

    #[tokio::test]
    async fn test_full_benchmark_suite() {
        let config = BenchmarkConfig::new()
            .with_rows(1000)
            .with_path("/tmp/test_bench_suite.parquet");

        generate_benchmark_file(&config).unwrap();
        let results = run_benchmark_suite(&config.output_path, 3).await.unwrap();

        assert_eq!(results.len(), 3);

        let report = generate_report(&results, &config.output_path);
        assert!(report.contains("Rosetta Benchmark Results"));

        std::fs::remove_file(&config.output_path).ok();
    }
}
