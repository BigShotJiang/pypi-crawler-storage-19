// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! DataFusion integration for Rosetta
//!
//! Provides a `TableProvider` implementation that enables DataFusion queries
//! on any format supported by Rosetta (Parquet, Vortex, Lance).
//!
//! # Example
//!
//! ```rust,ignore
//! use datafusion::prelude::*;
//! use rosetta::datafusion::RosettaTableProvider;
//!
//! #[tokio::main]
//! async fn main() -> Result<()> {
//!     let ctx = SessionContext::new();
//!
//!     // Register a Vortex file as a table
//!     let provider = RosettaTableProvider::try_new("data.vortex").await?;
//!     ctx.register_table("sales", Arc::new(provider))?;
//!
//!     // Query with filter pushdown
//!     let df = ctx.sql("SELECT * FROM sales WHERE amount > 100").await?;
//!     df.show().await?;
//!
//!     Ok(())
//! }
//! ```

mod exec;
mod table_provider;

pub use exec::RosettaExec;
pub use table_provider::RosettaTableProvider;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_module_exports() {
        // Verify types are exported
        let _ = std::any::type_name::<RosettaTableProvider>();
        let _ = std::any::type_name::<RosettaExec>();
    }
}
