// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! DataFusion ExecutionPlan implementation for Rosetta

use std::any::Any;
use std::fmt::{self, Debug, Formatter};
use std::path::PathBuf;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};

use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;
use datafusion::common::stats::Precision;
use datafusion::common::DataFusionError;
use datafusion::common::Result as DFResult;
use datafusion::common::Statistics as DFStatistics;
use datafusion::execution::{SendableRecordBatchStream, TaskContext};
use datafusion::physical_expr::{EquivalenceProperties, Partitioning};
use datafusion::physical_plan::{
    DisplayAs, DisplayFormatType, ExecutionPlan, ExecutionPlanProperties, PlanProperties,
};
use futures::stream::Stream;
use tokio::sync::mpsc;

use crate::expr::Expr as RosettaExpr;
use crate::readers::UnifiedReader;
use crate::ReadOptions;

/// ExecutionPlan for reading data through Rosetta
///
/// Implements DataFusion's ExecutionPlan trait to enable parallel
/// and distributed execution of Rosetta reads.
pub struct RosettaExec {
    /// Path to the data file
    path: PathBuf,
    /// Schema of the output
    schema: SchemaRef,
    /// Projected column names (None = all columns)
    projection: Option<Vec<String>>,
    /// Filter to push down
    filter: Option<RosettaExpr>,
    /// Row limit
    limit: Option<usize>,
    /// Execution plan properties
    properties: PlanProperties,
    /// Cached statistics (optional)
    statistics: Option<crate::stats::Statistics>,
}

impl Debug for RosettaExec {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        f.debug_struct("RosettaExec")
            .field("path", &self.path)
            .field("projection", &self.projection)
            .field("filter", &self.filter.as_ref().map(|f| f.to_sql()))
            .field("limit", &self.limit)
            .finish()
    }
}

impl RosettaExec {
    /// Create a new RosettaExec
    pub fn try_new(
        path: PathBuf,
        schema: SchemaRef,
        projection: Option<Vec<String>>,
        filter: Option<RosettaExpr>,
        limit: Option<usize>,
    ) -> DFResult<Self> {
        Self::try_new_with_stats(path, schema, projection, filter, limit, None)
    }

    /// Create a new RosettaExec with statistics
    pub fn try_new_with_stats(
        path: PathBuf,
        schema: SchemaRef,
        projection: Option<Vec<String>>,
        filter: Option<RosettaExpr>,
        limit: Option<usize>,
        statistics: Option<crate::stats::Statistics>,
    ) -> DFResult<Self> {
        // Calculate output schema based on projection
        let output_schema = if let Some(ref cols) = projection {
            let fields: Vec<_> = cols
                .iter()
                .filter_map(|name| schema.field_with_name(name).ok().cloned())
                .collect();
            Arc::new(arrow::datatypes::Schema::new(fields))
        } else {
            schema.clone()
        };

        // Create plan properties
        let properties = PlanProperties::new(
            EquivalenceProperties::new(output_schema.clone()),
            Partitioning::UnknownPartitioning(1), // Single partition for now
            datafusion::physical_plan::execution_plan::EmissionType::Incremental,
            datafusion::physical_plan::execution_plan::Boundedness::Bounded,
        );

        Ok(Self {
            path,
            schema: output_schema,
            projection,
            filter,
            limit,
            properties,
            statistics,
        })
    }

    /// Get the path being read
    pub fn path(&self) -> &PathBuf {
        &self.path
    }

    /// Get the filter being applied
    pub fn filter(&self) -> Option<&RosettaExpr> {
        self.filter.as_ref()
    }

    /// Get the statistics
    pub fn statistics_opt(&self) -> Option<&crate::stats::Statistics> {
        self.statistics.as_ref()
    }

    /// Convert Rosetta column statistics to DataFusion column statistics
    fn convert_column_statistics(
        &self,
        stats: &crate::stats::Statistics,
    ) -> Vec<datafusion::common::ColumnStatistics> {
        self.schema
            .fields()
            .iter()
            .map(|field| {
                stats
                    .column_statistics
                    .get(field.name())
                    .map(|col_stats| datafusion::common::ColumnStatistics {
                        null_count: col_stats
                            .null_count
                            .map(Precision::Exact)
                            .unwrap_or(Precision::Absent),
                        max_value: col_stats
                            .max_value
                            .as_ref()
                            .and_then(Self::rosetta_scalar_to_datafusion)
                            .map(Precision::Exact)
                            .unwrap_or(Precision::Absent),
                        min_value: col_stats
                            .min_value
                            .as_ref()
                            .and_then(Self::rosetta_scalar_to_datafusion)
                            .map(Precision::Exact)
                            .unwrap_or(Precision::Absent),
                        sum_value: Precision::Absent,
                        distinct_count: col_stats
                            .distinct_count
                            .map(Precision::Exact)
                            .unwrap_or(Precision::Absent),
                    })
                    .unwrap_or_default()
            })
            .collect()
    }

    /// Convert a Rosetta scalar value to a DataFusion scalar value
    fn rosetta_scalar_to_datafusion(
        value: &crate::stats::ScalarValue,
    ) -> Option<datafusion::common::ScalarValue> {
        use crate::stats::ScalarValue;
        use datafusion::common::ScalarValue as DFScalar;

        match value {
            ScalarValue::Boolean(v) => Some(DFScalar::Boolean(Some(*v))),
            ScalarValue::Int8(v) => Some(DFScalar::Int8(Some(*v))),
            ScalarValue::Int16(v) => Some(DFScalar::Int16(Some(*v))),
            ScalarValue::Int32(v) => Some(DFScalar::Int32(Some(*v))),
            ScalarValue::Int64(v) => Some(DFScalar::Int64(Some(*v))),
            ScalarValue::UInt8(v) => Some(DFScalar::UInt8(Some(*v))),
            ScalarValue::UInt16(v) => Some(DFScalar::UInt16(Some(*v))),
            ScalarValue::UInt32(v) => Some(DFScalar::UInt32(Some(*v))),
            ScalarValue::UInt64(v) => Some(DFScalar::UInt64(Some(*v))),
            ScalarValue::Float32(v) => Some(DFScalar::Float32(Some(*v))),
            ScalarValue::Float64(v) => Some(DFScalar::Float64(Some(*v))),
            ScalarValue::Utf8(v) => Some(DFScalar::Utf8(Some(v.clone()))),
            ScalarValue::Null => Some(DFScalar::Null),
            _ => None,
        }
    }
}

impl DisplayAs for RosettaExec {
    fn fmt_as(&self, t: DisplayFormatType, f: &mut Formatter) -> fmt::Result {
        match t {
            DisplayFormatType::Default
            | DisplayFormatType::Verbose
            | DisplayFormatType::TreeRender => {
                write!(f, "RosettaExec: path={}", self.path.display())?;
                if let Some(ref cols) = self.projection {
                    write!(f, ", projection=[{}]", cols.join(", "))?;
                }
                if let Some(ref filter) = self.filter {
                    write!(f, ", filter={}", filter.to_sql())?;
                }
                if let Some(limit) = self.limit {
                    write!(f, ", limit={}", limit)?;
                }
                Ok(())
            }
        }
    }
}

impl ExecutionPlanProperties for RosettaExec {
    fn output_partitioning(&self) -> &Partitioning {
        self.properties.output_partitioning()
    }

    fn output_ordering(&self) -> Option<&datafusion::physical_expr::LexOrdering> {
        self.properties.output_ordering()
    }

    fn boundedness(&self) -> datafusion::physical_plan::execution_plan::Boundedness {
        self.properties.boundedness
    }

    fn pipeline_behavior(&self) -> datafusion::physical_plan::execution_plan::EmissionType {
        self.properties.emission_type
    }

    fn equivalence_properties(&self) -> &EquivalenceProperties {
        self.properties.equivalence_properties()
    }
}

impl ExecutionPlan for RosettaExec {
    fn properties(&self) -> &PlanProperties {
        &self.properties
    }

    fn name(&self) -> &str {
        "RosettaExec"
    }

    fn as_any(&self) -> &dyn Any {
        self
    }

    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn children(&self) -> Vec<&Arc<dyn ExecutionPlan>> {
        // Leaf node - no children
        vec![]
    }

    fn with_new_children(
        self: Arc<Self>,
        _children: Vec<Arc<dyn ExecutionPlan>>,
    ) -> DFResult<Arc<dyn ExecutionPlan>> {
        // No children to replace
        Ok(self)
    }

    fn statistics(&self) -> DFResult<DFStatistics> {
        // Return real statistics if available, otherwise unknown
        match &self.statistics {
            Some(stats) => Ok(DFStatistics {
                num_rows: stats
                    .num_rows
                    .map(Precision::Exact)
                    .unwrap_or(Precision::Absent),
                total_byte_size: stats
                    .total_byte_size
                    .map(Precision::Exact)
                    .unwrap_or(Precision::Absent),
                column_statistics: self.convert_column_statistics(stats),
            }),
            None => Ok(DFStatistics {
                num_rows: Precision::Absent,
                total_byte_size: Precision::Absent,
                column_statistics: vec![],
            }),
        }
    }

    fn execute(
        &self,
        _partition: usize,
        _context: Arc<TaskContext>,
    ) -> DFResult<SendableRecordBatchStream> {
        let path = self.path.clone();
        let projection = self.projection.clone();
        let filter = self.filter.clone();
        let limit = self.limit;
        let schema = self.schema.clone();

        // Create the stream
        let stream = RosettaStream::new(path, projection, filter, limit, schema);

        Ok(Box::pin(stream))
    }
}

/// Stream that reads data through Rosetta
struct RosettaStream {
    /// Schema of the output
    schema: SchemaRef,
    /// Receiver for record batches
    receiver: mpsc::Receiver<DFResult<RecordBatch>>,
    /// Background task handle
    _handle: tokio::task::JoinHandle<()>,
}

impl RosettaStream {
    fn new(
        path: PathBuf,
        projection: Option<Vec<String>>,
        filter: Option<RosettaExpr>,
        limit: Option<usize>,
        schema: SchemaRef,
    ) -> Self {
        let (sender, receiver) = mpsc::channel(16);

        // Spawn background task to read data
        let handle = tokio::spawn(async move {
            let result = Self::read_data(path, projection, filter, limit, sender.clone()).await;
            if let Err(e) = result {
                let df_err = DataFusionError::External(Box::new(e));
                let _ = sender.send(Err(df_err)).await;
            }
        });

        Self {
            schema,
            receiver,
            _handle: handle,
        }
    }

    async fn read_data(
        path: PathBuf,
        projection: Option<Vec<String>>,
        filter: Option<RosettaExpr>,
        limit: Option<usize>,
        sender: mpsc::Sender<DFResult<RecordBatch>>,
    ) -> crate::Result<()> {
        // Build read options
        let options = ReadOptions {
            columns: projection,
            row_groups: None,
            batch_size: Some(8192),
            force_format: None,
        };

        // Open the reader
        let mut reader = UnifiedReader::open_with_options(&path, options).await?;

        // Push filter if provided
        if let Some(ref f) = filter {
            let _ = reader.push_filter(f);
        }

        // Read all batches
        let batches = reader.read_all().await?;

        // Apply limit if specified
        let mut rows_sent = 0usize;
        for batch in batches {
            if let Some(limit) = limit {
                if rows_sent >= limit {
                    break;
                }

                // Truncate batch if it would exceed limit
                let remaining = limit - rows_sent;
                let batch = if batch.num_rows() > remaining {
                    batch.slice(0, remaining)
                } else {
                    batch
                };

                rows_sent += batch.num_rows();
                if sender.send(Ok(batch)).await.is_err() {
                    break; // Receiver dropped
                }
            } else {
                if sender.send(Ok(batch)).await.is_err() {
                    break;
                }
            }
        }

        Ok(())
    }
}

impl Stream for RosettaStream {
    type Item = DFResult<RecordBatch>;

    fn poll_next(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        Pin::new(&mut self.receiver).poll_recv(cx)
    }
}

impl datafusion::physical_plan::RecordBatchStream for RosettaStream {
    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_exec_debug() {
        let exec = RosettaExec::try_new(
            PathBuf::from("test.parquet"),
            Arc::new(arrow::datatypes::Schema::empty()),
            Some(vec!["col1".to_string()]),
            None,
            Some(100),
        )
        .unwrap();

        let debug = format!("{:?}", exec);
        assert!(debug.contains("test.parquet"));
        assert!(debug.contains("col1"));
        assert!(debug.contains("100"));
    }

    #[test]
    fn test_exec_schema_projection() {
        let schema = Arc::new(arrow::datatypes::Schema::new(vec![
            arrow::datatypes::Field::new("a", arrow::datatypes::DataType::Int32, false),
            arrow::datatypes::Field::new("b", arrow::datatypes::DataType::Utf8, true),
            arrow::datatypes::Field::new("c", arrow::datatypes::DataType::Float64, false),
        ]));

        // Project only columns a and c
        let exec = RosettaExec::try_new(
            PathBuf::from("test.parquet"),
            schema,
            Some(vec!["a".to_string(), "c".to_string()]),
            None,
            None,
        )
        .unwrap();

        let output_schema = exec.schema();
        assert_eq!(output_schema.fields().len(), 2);
        assert_eq!(output_schema.field(0).name(), "a");
        assert_eq!(output_schema.field(1).name(), "c");
    }
}
