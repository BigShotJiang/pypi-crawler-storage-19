// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! DataFusion TableProvider implementation for Rosetta

use std::any::Any;
use std::fmt::{self, Debug, Formatter};
use std::path::PathBuf;
use std::sync::Arc;

use arrow::datatypes::SchemaRef;
use async_trait::async_trait;
use datafusion::catalog::Session;
use datafusion::common::stats::Precision;
use datafusion::common::Result as DFResult;
use datafusion::common::Statistics as DFStatistics;
use datafusion::datasource::{TableProvider, TableType};
use datafusion::logical_expr::{Expr as DFExpr, TableProviderFilterPushDown};
use datafusion::physical_plan::ExecutionPlan;

use crate::expr::{Expr as RosettaExpr, Operator};
use crate::readers::UnifiedReader;
use crate::stats::ScalarValue;
use crate::FileFormat;

use super::exec::RosettaExec;

/// DataFusion TableProvider that reads any Rosetta-supported format
///
/// This enables DataFusion SQL queries on Parquet, Vortex, Lance, and other
/// formats supported by Rosetta.
pub struct RosettaTableProvider {
    /// Path to the data file/directory
    path: PathBuf,
    /// Arrow schema
    schema: SchemaRef,
    /// Detected file format
    format: FileFormat,
    /// Cached statistics
    statistics: Option<crate::stats::Statistics>,
}

impl Debug for RosettaTableProvider {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        f.debug_struct("RosettaTableProvider")
            .field("path", &self.path)
            .field("format", &self.format)
            .field("schema", &self.schema)
            .field("statistics", &self.statistics)
            .finish()
    }
}

impl RosettaTableProvider {
    /// Create a new RosettaTableProvider from a file path
    ///
    /// # Arguments
    /// * `path` - Path to the data file (Parquet, Vortex, Lance, etc.)
    ///
    /// # Example
    /// ```rust,ignore
    /// let provider = RosettaTableProvider::try_new("data.vortex").await?;
    /// ```
    pub async fn try_new<P: Into<PathBuf>>(path: P) -> crate::Result<Self> {
        let path = path.into();

        // Open with UnifiedReader to get schema, format, and statistics
        let reader = UnifiedReader::open(&path).await?;
        let schema = reader.schema();
        let format = reader.format();
        let statistics = reader.statistics();

        Ok(Self {
            path,
            schema,
            format,
            statistics,
        })
    }

    /// Get the path to the data
    pub fn path(&self) -> &PathBuf {
        &self.path
    }

    /// Get the detected file format
    pub fn format(&self) -> FileFormat {
        self.format
    }

    /// Convert a DataFusion expression to a Rosetta expression
    ///
    /// Returns None if the expression cannot be translated
    fn datafusion_expr_to_rosetta(expr: &DFExpr) -> Option<RosettaExpr> {
        match expr {
            DFExpr::Column(col) => Some(RosettaExpr::column(&col.name)),
            DFExpr::Literal(scalar, _metadata) => Self::scalar_to_rosetta(scalar),
            DFExpr::BinaryExpr(binary) => {
                let left = Self::datafusion_expr_to_rosetta(&binary.left)?;
                let right = Self::datafusion_expr_to_rosetta(&binary.right)?;
                let op = Self::datafusion_op_to_rosetta(&binary.op)?;

                Some(RosettaExpr::BinaryExpr {
                    left: Box::new(left),
                    op,
                    right: Box::new(right),
                })
            }
            DFExpr::Not(inner) => {
                let inner = Self::datafusion_expr_to_rosetta(inner)?;
                Some(RosettaExpr::Not(Box::new(inner)))
            }
            DFExpr::IsNull(inner) => {
                let inner = Self::datafusion_expr_to_rosetta(inner)?;
                Some(RosettaExpr::IsNull(Box::new(inner)))
            }
            DFExpr::IsNotNull(inner) => {
                let inner = Self::datafusion_expr_to_rosetta(inner)?;
                Some(RosettaExpr::IsNotNull(Box::new(inner)))
            }
            DFExpr::Between(between) => {
                let expr = Self::datafusion_expr_to_rosetta(&between.expr)?;
                let low = Self::datafusion_expr_to_rosetta(&between.low)?;
                let high = Self::datafusion_expr_to_rosetta(&between.high)?;

                Some(RosettaExpr::Between {
                    expr: Box::new(expr),
                    low: Box::new(low),
                    high: Box::new(high),
                    negated: between.negated,
                })
            }
            DFExpr::InList(in_list) => {
                let expr = Self::datafusion_expr_to_rosetta(&in_list.expr)?;
                let list: Option<Vec<RosettaExpr>> = in_list
                    .list
                    .iter()
                    .map(Self::datafusion_expr_to_rosetta)
                    .collect();
                let list = list?;

                let in_expr = RosettaExpr::InList {
                    expr: Box::new(expr),
                    list,
                    negated: in_list.negated,
                };

                Some(in_expr)
            }
            // For other expression types, return None (not pushable)
            _ => None,
        }
    }

    /// Convert a DataFusion scalar value to a Rosetta scalar value
    fn scalar_to_rosetta(scalar: &datafusion::common::ScalarValue) -> Option<RosettaExpr> {
        use datafusion::common::ScalarValue as DFScalar;

        let value = match scalar {
            DFScalar::Boolean(Some(v)) => ScalarValue::Boolean(*v),
            DFScalar::Int8(Some(v)) => ScalarValue::Int8(*v),
            DFScalar::Int16(Some(v)) => ScalarValue::Int16(*v),
            DFScalar::Int32(Some(v)) => ScalarValue::Int32(*v),
            DFScalar::Int64(Some(v)) => ScalarValue::Int64(*v),
            DFScalar::UInt8(Some(v)) => ScalarValue::UInt8(*v),
            DFScalar::UInt16(Some(v)) => ScalarValue::UInt16(*v),
            DFScalar::UInt32(Some(v)) => ScalarValue::UInt32(*v),
            DFScalar::UInt64(Some(v)) => ScalarValue::UInt64(*v),
            DFScalar::Float32(Some(v)) => ScalarValue::Float32(*v),
            DFScalar::Float64(Some(v)) => ScalarValue::Float64(*v),
            DFScalar::Utf8(Some(v)) | DFScalar::LargeUtf8(Some(v)) => ScalarValue::Utf8(v.clone()),
            DFScalar::Null => ScalarValue::Null,
            // For other types, return None
            _ => return None,
        };

        Some(RosettaExpr::Literal(value))
    }

    /// Convert a DataFusion operator to a Rosetta operator
    fn datafusion_op_to_rosetta(op: &datafusion::logical_expr::Operator) -> Option<Operator> {
        use datafusion::logical_expr::Operator as DFOp;

        match op {
            DFOp::Eq => Some(Operator::Eq),
            DFOp::NotEq => Some(Operator::NotEq),
            DFOp::Lt => Some(Operator::Lt),
            DFOp::LtEq => Some(Operator::LtEq),
            DFOp::Gt => Some(Operator::Gt),
            DFOp::GtEq => Some(Operator::GtEq),
            DFOp::And => Some(Operator::And),
            DFOp::Or => Some(Operator::Or),
            // Arithmetic operators
            DFOp::Plus => Some(Operator::Plus),
            DFOp::Minus => Some(Operator::Minus),
            DFOp::Multiply => Some(Operator::Multiply),
            DFOp::Divide => Some(Operator::Divide),
            DFOp::Modulo => Some(Operator::Modulo),
            // Other operators not supported
            _ => None,
        }
    }
}

#[async_trait]
impl TableProvider for RosettaTableProvider {
    fn as_any(&self) -> &dyn Any {
        self
    }

    fn schema(&self) -> SchemaRef {
        self.schema.clone()
    }

    fn table_type(&self) -> TableType {
        TableType::Base
    }

    async fn scan(
        &self,
        _state: &dyn Session,
        projection: Option<&Vec<usize>>,
        filters: &[DFExpr],
        limit: Option<usize>,
    ) -> DFResult<Arc<dyn ExecutionPlan>> {
        // Convert column indices to column names for projection
        let projected_columns: Option<Vec<String>> = projection.map(|indices| {
            indices
                .iter()
                .filter_map(|&i| self.schema.field(i).name().to_string().into())
                .collect()
        });

        // Convert DataFusion filters to Rosetta expressions
        let rosetta_filters: Vec<RosettaExpr> = filters
            .iter()
            .filter_map(Self::datafusion_expr_to_rosetta)
            .collect();

        // Combine all filters with AND
        let combined_filter = if rosetta_filters.is_empty() {
            None
        } else {
            let mut iter = rosetta_filters.into_iter();
            let first = iter.next().unwrap();
            Some(iter.fold(first, |acc, f| RosettaExpr::BinaryExpr {
                left: Box::new(acc),
                op: Operator::And,
                right: Box::new(f),
            }))
        };

        // Create the execution plan with statistics
        let exec = RosettaExec::try_new_with_stats(
            self.path.clone(),
            self.schema.clone(),
            projected_columns,
            combined_filter,
            limit,
            self.statistics.clone(),
        )?;

        Ok(Arc::new(exec))
    }

    fn supports_filters_pushdown(
        &self,
        filters: &[&DFExpr],
    ) -> DFResult<Vec<TableProviderFilterPushDown>> {
        // Check each filter to see if we can push it down
        let results: Vec<TableProviderFilterPushDown> = filters
            .iter()
            .map(|filter| {
                if Self::datafusion_expr_to_rosetta(filter).is_some() {
                    // We can translate this filter
                    match self.format {
                        FileFormat::Vortex | FileFormat::Lance => {
                            // These formats support native filter pushdown
                            TableProviderFilterPushDown::Exact
                        }
                        FileFormat::ParquetV1 | FileFormat::ParquetV2 => {
                            // Parquet has limited pushdown (row group pruning)
                            TableProviderFilterPushDown::Inexact
                        }
                        _ => {
                            // Other formats - filter after read
                            TableProviderFilterPushDown::Unsupported
                        }
                    }
                } else {
                    // Cannot translate this filter
                    TableProviderFilterPushDown::Unsupported
                }
            })
            .collect();

        Ok(results)
    }

    /// Returns the statistics for this table
    fn statistics(&self) -> Option<DFStatistics> {
        // Convert Rosetta statistics to DataFusion statistics
        self.statistics.as_ref().map(|stats| DFStatistics {
            num_rows: stats
                .num_rows
                .map(Precision::Exact)
                .unwrap_or(Precision::Absent),
            total_byte_size: stats
                .total_byte_size
                .map(Precision::Exact)
                .unwrap_or(Precision::Absent),
            column_statistics: self.convert_column_statistics(stats),
        })
    }
}

impl RosettaTableProvider {
    /// Convert Rosetta column statistics to DataFusion column statistics
    fn convert_column_statistics(
        &self,
        stats: &crate::stats::Statistics,
    ) -> Vec<datafusion::common::ColumnStatistics> {
        self.schema
            .fields()
            .iter()
            .map(|field| {
                stats
                    .column_statistics
                    .get(field.name())
                    .map(|col_stats| {
                        datafusion::common::ColumnStatistics {
                            null_count: col_stats
                                .null_count
                                .map(Precision::Exact)
                                .unwrap_or(Precision::Absent),
                            max_value: col_stats
                                .max_value
                                .as_ref()
                                .and_then(Self::rosetta_scalar_to_datafusion)
                                .map(Precision::Exact)
                                .unwrap_or(Precision::Absent),
                            min_value: col_stats
                                .min_value
                                .as_ref()
                                .and_then(Self::rosetta_scalar_to_datafusion)
                                .map(Precision::Exact)
                                .unwrap_or(Precision::Absent),
                            sum_value: Precision::Absent, // Not tracked by Rosetta
                            distinct_count: col_stats
                                .distinct_count
                                .map(Precision::Exact)
                                .unwrap_or(Precision::Absent),
                        }
                    })
                    .unwrap_or_default()
            })
            .collect()
    }

    /// Convert a Rosetta scalar value to a DataFusion scalar value
    fn rosetta_scalar_to_datafusion(
        value: &ScalarValue,
    ) -> Option<datafusion::common::ScalarValue> {
        use datafusion::common::ScalarValue as DFScalar;

        match value {
            ScalarValue::Boolean(v) => Some(DFScalar::Boolean(Some(*v))),
            ScalarValue::Int8(v) => Some(DFScalar::Int8(Some(*v))),
            ScalarValue::Int16(v) => Some(DFScalar::Int16(Some(*v))),
            ScalarValue::Int32(v) => Some(DFScalar::Int32(Some(*v))),
            ScalarValue::Int64(v) => Some(DFScalar::Int64(Some(*v))),
            ScalarValue::UInt8(v) => Some(DFScalar::UInt8(Some(*v))),
            ScalarValue::UInt16(v) => Some(DFScalar::UInt16(Some(*v))),
            ScalarValue::UInt32(v) => Some(DFScalar::UInt32(Some(*v))),
            ScalarValue::UInt64(v) => Some(DFScalar::UInt64(Some(*v))),
            ScalarValue::Float32(v) => Some(DFScalar::Float32(Some(*v))),
            ScalarValue::Float64(v) => Some(DFScalar::Float64(Some(*v))),
            ScalarValue::Utf8(v) => Some(DFScalar::Utf8(Some(v.clone()))),
            ScalarValue::Null => Some(DFScalar::Null),
            _ => None, // Other types not converted
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use datafusion::common::ScalarValue as DFScalar;
    use datafusion::logical_expr::{col, lit, BinaryExpr, Operator as DFOp};

    #[test]
    fn test_simple_column_translation() {
        let df_expr = DFExpr::Column(datafusion::common::Column::from_name("age"));
        let rosetta = RosettaTableProvider::datafusion_expr_to_rosetta(&df_expr);

        assert!(rosetta.is_some());
        match rosetta.unwrap() {
            RosettaExpr::Column(name) => assert_eq!(name, "age"),
            _ => panic!("Expected Column expression"),
        }
    }

    #[test]
    fn test_literal_translation() {
        let df_expr = DFExpr::Literal(DFScalar::Int32(Some(42)), None);
        let rosetta = RosettaTableProvider::datafusion_expr_to_rosetta(&df_expr);

        assert!(rosetta.is_some());
        match rosetta.unwrap() {
            RosettaExpr::Literal(ScalarValue::Int32(v)) => assert_eq!(v, 42),
            _ => panic!("Expected Int32 literal"),
        }
    }

    #[test]
    fn test_comparison_translation() {
        // age > 30
        let df_expr = DFExpr::BinaryExpr(BinaryExpr::new(
            Box::new(col("age")),
            DFOp::Gt,
            Box::new(lit(30i32)),
        ));

        let rosetta = RosettaTableProvider::datafusion_expr_to_rosetta(&df_expr);
        assert!(rosetta.is_some());

        let rosetta = rosetta.unwrap();
        match &rosetta {
            RosettaExpr::BinaryExpr { left, op, right } => {
                assert!(matches!(op, Operator::Gt));
                assert!(matches!(left.as_ref(), RosettaExpr::Column(_)));
                assert!(matches!(right.as_ref(), RosettaExpr::Literal(_)));
            }
            _ => panic!("Expected BinaryExpr"),
        }
    }

    #[test]
    fn test_operator_translations() {
        use datafusion::logical_expr::Operator as DFOp;

        assert_eq!(
            RosettaTableProvider::datafusion_op_to_rosetta(&DFOp::Eq),
            Some(Operator::Eq)
        );
        assert_eq!(
            RosettaTableProvider::datafusion_op_to_rosetta(&DFOp::Lt),
            Some(Operator::Lt)
        );
        assert_eq!(
            RosettaTableProvider::datafusion_op_to_rosetta(&DFOp::And),
            Some(Operator::And)
        );
    }
}
