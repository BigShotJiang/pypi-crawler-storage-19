// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! S3-compatible proxy server implementation
//!
//! This implements enough of the S3 API to serve transcoded files:
//! - GetObject (reads file, transcodes, returns Parquet)
//! - HeadObject (returns metadata)
//! - ListObjectsV2 (for directory listing)

use bytes::Bytes;
use std::collections::HashMap;
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use tokio::net::TcpListener;
use tokio::sync::RwLock;
use tracing::{debug, error, info, instrument, warn};

use crate::transcoder::{TranscodeResult, Transcoder};
use crate::writers::ParquetWriterOptions;
use crate::{Error, Result};

/// Configuration for the S3 proxy
#[derive(Debug, Clone)]
pub struct S3ProxyConfig {
    /// Address to bind to
    pub bind_addr: SocketAddr,
    /// Upstream S3 endpoint (if proxying to real S3)
    pub upstream_endpoint: Option<String>,
    /// Local directory to serve files from (for testing)
    pub local_root: Option<PathBuf>,
    /// Cache transcoded results
    pub enable_cache: bool,
    /// Max cache size in bytes
    pub max_cache_bytes: usize,
    /// Parquet writer options
    pub writer_options: ParquetWriterOptions,
}

impl Default for S3ProxyConfig {
    fn default() -> Self {
        Self {
            bind_addr: "127.0.0.1:9000".parse().unwrap(),
            upstream_endpoint: None,
            local_root: None,
            enable_cache: true,
            max_cache_bytes: 1024 * 1024 * 1024, // 1GB cache
            writer_options: ParquetWriterOptions::max_compatibility(),
        }
    }
}

impl S3ProxyConfig {
    /// Create config for local filesystem mode
    pub fn local(root: PathBuf) -> Self {
        Self {
            local_root: Some(root),
            ..Default::default()
        }
    }

    /// Create config for proxying to real S3
    pub fn s3_proxy(upstream: &str) -> Self {
        Self {
            upstream_endpoint: Some(upstream.to_string()),
            ..Default::default()
        }
    }

    /// Set bind address
    pub fn with_bind_addr(mut self, addr: SocketAddr) -> Self {
        self.bind_addr = addr;
        self
    }
}

/// Cache entry for transcoded files
#[allow(dead_code)]
struct CacheEntry {
    bytes: Bytes,
    size: usize,
    source_path: String,
}

/// S3-compatible proxy server
pub struct S3Proxy {
    config: S3ProxyConfig,
    transcoder: Transcoder,
    cache: Arc<RwLock<HashMap<String, CacheEntry>>>,
    cache_size: Arc<RwLock<usize>>,
}

impl S3Proxy {
    /// Create a new S3 proxy with the given config
    pub fn new(config: S3ProxyConfig) -> Self {
        let transcoder = Transcoder::new().with_writer_options(config.writer_options.clone());

        Self {
            config,
            transcoder,
            cache: Arc::new(RwLock::new(HashMap::new())),
            cache_size: Arc::new(RwLock::new(0)),
        }
    }

    /// Create with default config
    pub fn default_config() -> Self {
        Self::new(S3ProxyConfig::default())
    }

    /// Start the proxy server
    #[instrument(skip(self))]
    pub async fn start(&self) -> Result<()> {
        let listener = TcpListener::bind(self.config.bind_addr)
            .await
            .map_err(|e| Error::io_error(format!("Failed to bind: {}", e)))?;

        info!(addr = %self.config.bind_addr, "S3 proxy started");

        loop {
            match listener.accept().await {
                Ok((stream, addr)) => {
                    debug!(?addr, "Accepted connection");
                    let proxy = self.clone_for_handler();
                    tokio::spawn(async move {
                        if let Err(e) = proxy.handle_connection(stream).await {
                            error!(?e, "Connection handler error");
                        }
                    });
                }
                Err(e) => {
                    error!(?e, "Accept error");
                }
            }
        }
    }

    /// Clone for spawning handlers
    fn clone_for_handler(&self) -> S3ProxyHandler {
        S3ProxyHandler {
            config: self.config.clone(),
            transcoder: Transcoder::new().with_writer_options(self.config.writer_options.clone()),
            cache: self.cache.clone(),
            cache_size: self.cache_size.clone(),
        }
    }

    /// Get a file (for direct API use)
    #[instrument(skip(self))]
    pub async fn get_object(&self, bucket: &str, key: &str) -> Result<Bytes> {
        let cache_key = format!("{}/{}", bucket, key);

        // Check cache
        if self.config.enable_cache {
            let cache = self.cache.read().await;
            if let Some(entry) = cache.get(&cache_key) {
                debug!("Cache hit for {}", cache_key);
                return Ok(entry.bytes.clone());
            }
        }

        // Resolve path
        let path = self.resolve_path(bucket, key)?;

        // Transcode
        let result = self.transcoder.transcode_file(&path).await?;
        let bytes = result.bytes.clone();

        // Cache result
        if self.config.enable_cache {
            self.cache_result(&cache_key, result).await;
        }

        Ok(bytes)
    }

    /// Resolve bucket/key to filesystem path
    fn resolve_path(&self, bucket: &str, key: &str) -> Result<PathBuf> {
        if let Some(ref root) = self.config.local_root {
            Ok(root.join(bucket).join(key))
        } else {
            Err(Error::invalid_file(
                "S3 proxy requires local_root or upstream_endpoint",
            ))
        }
    }

    /// Cache a transcode result
    async fn cache_result(&self, key: &str, result: TranscodeResult) {
        let size = result.bytes.len();
        let mut current_size = self.cache_size.write().await;

        // Evict if necessary
        while *current_size + size > self.config.max_cache_bytes {
            let mut cache = self.cache.write().await;
            if let Some(oldest_key) = cache.keys().next().cloned() {
                if let Some(entry) = cache.remove(&oldest_key) {
                    *current_size -= entry.size;
                }
            } else {
                break;
            }
        }

        // Insert
        let mut cache = self.cache.write().await;
        *current_size += size;
        cache.insert(
            key.to_string(),
            CacheEntry {
                bytes: result.bytes,
                size,
                source_path: key.to_string(),
            },
        );
    }
}

/// Handler for individual connections
#[allow(dead_code)]
struct S3ProxyHandler {
    config: S3ProxyConfig,
    transcoder: Transcoder,
    cache: Arc<RwLock<HashMap<String, CacheEntry>>>,
    cache_size: Arc<RwLock<usize>>,
}

impl S3ProxyHandler {
    /// Handle a TCP connection
    async fn handle_connection(&self, stream: tokio::net::TcpStream) -> Result<()> {
        use tokio::io::{AsyncBufReadExt, BufReader};

        let mut reader = BufReader::new(stream);
        let mut request_line = String::new();
        reader
            .read_line(&mut request_line)
            .await
            .map_err(|e| Error::io_error(format!("Read error: {}", e)))?;

        // Parse HTTP request line
        let parts: Vec<&str> = request_line.split_whitespace().collect();
        if parts.len() < 3 {
            return self.send_error(&mut reader, 400, "Bad Request").await;
        }

        let method = parts[0];
        let path = parts[1];

        // Read headers
        let mut headers = HashMap::new();
        loop {
            let mut line = String::new();
            reader
                .read_line(&mut line)
                .await
                .map_err(|e| Error::io_error(format!("Read error: {}", e)))?;
            let line = line.trim();
            if line.is_empty() {
                break;
            }
            if let Some((key, value)) = line.split_once(':') {
                headers.insert(key.trim().to_lowercase(), value.trim().to_string());
            }
        }

        info!(method, path, "Handling request");

        // Route request
        match method {
            "GET" => self.handle_get(&mut reader, path, &headers).await,
            "HEAD" => self.handle_head(&mut reader, path, &headers).await,
            _ => {
                self.send_error(&mut reader, 405, "Method Not Allowed")
                    .await
            }
        }
    }

    /// Handle GET request (GetObject)
    async fn handle_get(
        &self,
        stream: &mut tokio::io::BufReader<tokio::net::TcpStream>,
        path: &str,
        _headers: &HashMap<String, String>,
    ) -> Result<()> {
        // Parse bucket and key from path: /bucket/key
        let (bucket, key) = self.parse_s3_path(path)?;

        // Check cache
        let cache_key = format!("{}/{}", bucket, key);
        if self.config.enable_cache {
            let cache = self.cache.read().await;
            if let Some(entry) = cache.get(&cache_key) {
                debug!("Cache hit for {}", cache_key);
                return self.send_response(stream, 200, &entry.bytes).await;
            }
        }

        // Resolve and transcode
        let file_path = self.resolve_path(&bucket, &key)?;

        match self.transcoder.transcode_file(&file_path).await {
            Ok(result) => {
                let bytes = result.bytes.clone();

                // Cache
                if self.config.enable_cache {
                    let size = result.bytes.len();
                    let mut cache = self.cache.write().await;
                    cache.insert(
                        cache_key,
                        CacheEntry {
                            bytes: result.bytes,
                            size,
                            source_path: file_path.to_string_lossy().to_string(),
                        },
                    );
                }

                self.send_response(stream, 200, &bytes).await
            }
            Err(e) => {
                warn!(?e, "Transcode failed");
                self.send_error(stream, 404, "Not Found").await
            }
        }
    }

    /// Handle HEAD request (HeadObject)
    async fn handle_head(
        &self,
        stream: &mut tokio::io::BufReader<tokio::net::TcpStream>,
        path: &str,
        _headers: &HashMap<String, String>,
    ) -> Result<()> {
        #[allow(unused_imports)]
        use tokio::io::AsyncWriteExt;

        let (bucket, key) = self.parse_s3_path(path)?;
        let file_path = self.resolve_path(&bucket, &key)?;

        // Check if file exists
        if tokio::fs::metadata(&file_path).await.is_ok() {
            let response = "HTTP/1.1 200 OK\r\n\
                 Content-Type: application/octet-stream\r\n\
                 x-amz-request-id: rosetta\r\n\
                 \r\n"
                .to_string();
            stream
                .get_mut()
                .write_all(response.as_bytes())
                .await
                .map_err(|e| Error::io_error(format!("Write error: {}", e)))?;
            Ok(())
        } else {
            self.send_error(stream, 404, "Not Found").await
        }
    }

    /// Parse S3-style path: /bucket/key/path
    fn parse_s3_path(&self, path: &str) -> Result<(String, String)> {
        let path = path.trim_start_matches('/');
        let parts: Vec<&str> = path.splitn(2, '/').collect();

        if parts.len() < 2 {
            return Err(Error::invalid_file("Invalid S3 path"));
        }

        Ok((parts[0].to_string(), parts[1].to_string()))
    }

    /// Resolve bucket/key to filesystem path
    fn resolve_path(&self, bucket: &str, key: &str) -> Result<PathBuf> {
        if let Some(ref root) = self.config.local_root {
            Ok(root.join(bucket).join(key))
        } else {
            // For real S3 proxy, we'd download from upstream here
            Err(Error::invalid_file("No local_root configured"))
        }
    }

    /// Send HTTP response with body
    async fn send_response(
        &self,
        stream: &mut tokio::io::BufReader<tokio::net::TcpStream>,
        status: u16,
        body: &[u8],
    ) -> Result<()> {
        use tokio::io::AsyncWriteExt;

        let response = format!(
            "HTTP/1.1 {} OK\r\n\
             Content-Type: application/octet-stream\r\n\
             Content-Length: {}\r\n\
             x-amz-request-id: rosetta\r\n\
             \r\n",
            status,
            body.len()
        );

        stream
            .get_mut()
            .write_all(response.as_bytes())
            .await
            .map_err(|e| Error::io_error(format!("Write error: {}", e)))?;
        stream
            .get_mut()
            .write_all(body)
            .await
            .map_err(|e| Error::io_error(format!("Write error: {}", e)))?;

        Ok(())
    }

    /// Send HTTP error response
    async fn send_error(
        &self,
        stream: &mut tokio::io::BufReader<tokio::net::TcpStream>,
        status: u16,
        message: &str,
    ) -> Result<()> {
        use tokio::io::AsyncWriteExt;

        let body = format!(
            r#"<?xml version="1.0" encoding="UTF-8"?>
<Error>
    <Code>{}</Code>
    <Message>{}</Message>
    <RequestId>rosetta</RequestId>
</Error>"#,
            status, message
        );

        let response = format!(
            "HTTP/1.1 {} {}\r\n\
             Content-Type: application/xml\r\n\
             Content-Length: {}\r\n\
             \r\n{}",
            status,
            message,
            body.len(),
            body
        );

        stream
            .get_mut()
            .write_all(response.as_bytes())
            .await
            .map_err(|e| Error::io_error(format!("Write error: {}", e)))?;

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::TempDir;

    #[test]
    fn test_config_default() {
        let config = S3ProxyConfig::default();
        assert_eq!(config.bind_addr.port(), 9000);
        assert!(config.enable_cache);
    }

    #[test]
    fn test_config_local() {
        let config = S3ProxyConfig::local(PathBuf::from("/data"));
        assert_eq!(config.local_root, Some(PathBuf::from("/data")));
    }

    #[test]
    fn test_parse_s3_path() {
        let handler = S3ProxyHandler {
            config: S3ProxyConfig::default(),
            transcoder: Transcoder::new(),
            cache: Arc::new(RwLock::new(HashMap::new())),
            cache_size: Arc::new(RwLock::new(0)),
        };

        let (bucket, key) = handler
            .parse_s3_path("/mybucket/path/to/file.parquet")
            .unwrap();
        assert_eq!(bucket, "mybucket");
        assert_eq!(key, "path/to/file.parquet");
    }

    #[tokio::test]
    async fn test_proxy_creation() {
        let temp_dir = TempDir::new().unwrap();
        let config = S3ProxyConfig::local(temp_dir.path().to_path_buf());
        let _proxy = S3Proxy::new(config);
    }
}
