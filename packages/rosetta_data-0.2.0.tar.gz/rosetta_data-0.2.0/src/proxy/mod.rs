// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! S3 Proxy server for transparent format transcoding
//!
//! This module provides an S3-compatible proxy that intercepts requests,
//! reads files in any supported format, and returns Parquet v1 bytes.
//!
//! # How It Works
//!
//! ```text
//! Client (Spark/Pandas/DuckDB)
//!        │
//!        │ GET s3://bucket/data.vortex
//!        ▼
//! ┌─────────────────┐
//! │  Rosetta Proxy  │  Intercepts S3 requests
//! └─────────────────┘
//!        │
//!        │ Fetch actual file from S3
//!        ▼
//! ┌─────────────────┐
//! │   Transcoder    │  Read Vortex → Arrow → Parquet v1
//! └─────────────────┘
//!        │
//!        │ Returns Parquet v1 bytes
//!        ▼
//! Client receives valid Parquet (no code changes!)
//! ```
//!
//! # Usage
//!
//! ```rust,ignore
//! use rosetta::proxy::S3Proxy;
//!
//! let proxy = S3Proxy::new("127.0.0.1:9000")?;
//! proxy.start().await?;
//!
//! // Configure your app to use the proxy:
//! // AWS_ENDPOINT_URL=http://127.0.0.1:9000
//! ```
//!
//! # Enterprise Extension Points
//!
//! The [`AuthProvider`] trait allows enterprise deployments to add:
//! - OAuth/OIDC authentication
//! - SAML SSO integration
//! - API key management
//! - RBAC (Role-Based Access Control)
//!
//! See [`set_auth_provider`] for configuring custom authentication.

mod server;

use async_trait::async_trait;
use std::sync::Arc;

pub use server::{S3Proxy, S3ProxyConfig};

/// Identity information for an authenticated request.
#[derive(Debug, Clone)]
pub struct Identity {
    /// User or service account ID
    pub user_id: String,
    /// Display name (optional)
    pub display_name: Option<String>,
    /// Roles/groups for authorization
    pub roles: Vec<String>,
    /// Additional claims/attributes
    pub claims: std::collections::HashMap<String, String>,
}

impl Identity {
    /// Create a new identity with just a user ID.
    pub fn new(user_id: impl Into<String>) -> Self {
        Self {
            user_id: user_id.into(),
            display_name: None,
            roles: Vec::new(),
            claims: std::collections::HashMap::new(),
        }
    }

    /// Add a display name.
    pub fn with_display_name(mut self, name: impl Into<String>) -> Self {
        self.display_name = Some(name.into());
        self
    }

    /// Add roles.
    pub fn with_roles(mut self, roles: Vec<String>) -> Self {
        self.roles = roles;
        self
    }

    /// Check if identity has a specific role.
    pub fn has_role(&self, role: &str) -> bool {
        self.roles.iter().any(|r| r == role)
    }
}

/// Authentication provider trait for enterprise deployments.
///
/// This trait enables integration with enterprise identity providers:
/// - OAuth 2.0 / OIDC (Okta, Auth0, Azure AD)
/// - SAML (Ping, ADFS)
/// - API Keys
/// - Custom authentication schemes
///
/// The default implementation allows all requests (no auth).
/// Enterprise deployments should provide a custom implementation.
///
/// # Example
///
/// ```rust,ignore
/// use rosetta::proxy::{AuthProvider, Identity, AuthRequest};
///
/// struct OktaAuthProvider {
///     client: OktaClient,
/// }
///
/// #[async_trait]
/// impl AuthProvider for OktaAuthProvider {
///     async fn authenticate(&self, request: &AuthRequest) -> Result<Identity, AuthError> {
///         // Extract Bearer token from Authorization header
///         let token = request.authorization.as_ref()
///             .and_then(|h| h.strip_prefix("Bearer "))
///             .ok_or(AuthError::MissingToken)?;
///
///         // Validate with Okta
///         let claims = self.client.verify_token(token).await?;
///
///         Ok(Identity {
///             user_id: claims.sub,
///             display_name: Some(claims.name),
///             roles: claims.groups,
///             claims: claims.custom,
///         })
///     }
///
///     async fn authorize(&self, identity: &Identity, resource: &str, action: &str) -> bool {
///         // Check RBAC rules
///         identity.has_role("data-reader") || identity.has_role("admin")
///     }
/// }
/// ```
#[async_trait]
pub trait AuthProvider: Send + Sync {
    /// Authenticate a request and return the identity.
    ///
    /// Returns `Ok(Identity)` if authentication succeeds.
    /// Returns `Err(AuthError)` if authentication fails.
    async fn authenticate(&self, request: &AuthRequest) -> Result<Identity, AuthError>;

    /// Check if an identity is authorized to perform an action on a resource.
    ///
    /// Default implementation allows all actions (no authorization).
    async fn authorize(&self, _identity: &Identity, _resource: &str, _action: &str) -> bool {
        true
    }

    /// Called when authentication is skipped (for metrics).
    fn on_auth_skipped(&self, _reason: &str) {}

    /// Called when authentication succeeds (for metrics/audit).
    fn on_auth_success(&self, _identity: &Identity) {}

    /// Called when authentication fails (for metrics/audit).
    fn on_auth_failure(&self, _error: &AuthError) {}
}

/// Request information for authentication.
#[derive(Debug, Clone)]
pub struct AuthRequest {
    /// Authorization header value (e.g., "Bearer <token>")
    pub authorization: Option<String>,
    /// X-API-Key header value
    pub api_key: Option<String>,
    /// Request path
    pub path: String,
    /// HTTP method
    pub method: String,
    /// Source IP address
    pub source_ip: Option<String>,
    /// Additional headers that may be relevant for auth
    pub headers: std::collections::HashMap<String, String>,
}

/// Authentication error types.
#[derive(Debug, Clone)]
pub enum AuthError {
    /// No credentials provided
    MissingCredentials,
    /// Invalid credentials (wrong password, expired token, etc.)
    InvalidCredentials(String),
    /// Token has expired
    TokenExpired,
    /// User/service account is disabled
    AccountDisabled,
    /// Rate limit exceeded
    RateLimitExceeded,
    /// Internal authentication error
    InternalError(String),
}

impl std::fmt::Display for AuthError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::MissingCredentials => write!(f, "Missing credentials"),
            Self::InvalidCredentials(msg) => write!(f, "Invalid credentials: {}", msg),
            Self::TokenExpired => write!(f, "Token expired"),
            Self::AccountDisabled => write!(f, "Account disabled"),
            Self::RateLimitExceeded => write!(f, "Rate limit exceeded"),
            Self::InternalError(msg) => write!(f, "Internal error: {}", msg),
        }
    }
}

impl std::error::Error for AuthError {}

/// No-op authentication provider (allows all requests).
///
/// This is the default for OSS builds. Enterprise deployments should
/// replace this with a proper authentication provider.
#[derive(Debug, Clone, Copy, Default)]
pub struct NoOpAuthProvider;

#[async_trait]
impl AuthProvider for NoOpAuthProvider {
    async fn authenticate(&self, _request: &AuthRequest) -> Result<Identity, AuthError> {
        // Allow all requests with anonymous identity
        Ok(Identity::new("anonymous"))
    }
}

/// Global auth provider instance. Enterprise deployments can replace this.
static AUTH_PROVIDER: std::sync::OnceLock<Arc<dyn AuthProvider>> = std::sync::OnceLock::new();

/// Get the current auth provider instance.
pub fn get_auth_provider() -> Arc<dyn AuthProvider> {
    AUTH_PROVIDER
        .get()
        .cloned()
        .unwrap_or_else(|| Arc::new(NoOpAuthProvider))
}

/// Set custom auth provider (for enterprise integrations).
///
/// This must be called before starting the proxy server.
/// Returns Err if auth provider has already been set.
pub fn set_auth_provider(provider: Arc<dyn AuthProvider>) -> crate::Result<()> {
    AUTH_PROVIDER
        .set(provider)
        .map_err(|_| crate::Error::config("Auth provider already initialized"))
}
