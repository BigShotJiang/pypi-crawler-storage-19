// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Iceberg FileIO implementation
//!
//! This implements the FileIO trait from iceberg-rust, providing
//! transparent transcoding for any file format.

use bytes::Bytes;
use lru::LruCache;
use std::collections::HashMap;
use std::num::NonZeroUsize;
use std::path::Path;
use std::sync::Arc;
use tokio::sync::Mutex;
use tracing::{debug, info};

use crate::expr::Expr;
use crate::object_store_utils::{build_gcs_store, build_s3_store, is_cloud_url};
use crate::transcoder::Transcoder;
use crate::writers::ParquetWriterOptions;
use crate::{Error, Result};

/// Configuration for RosettaFileIO
#[derive(Debug, Clone)]
pub struct RosettaFileIOConfig {
    /// Enable caching of transcoded files
    pub enable_cache: bool,
    /// Max cache entries (LRU eviction)
    pub max_cache_entries: usize,
    /// Max cache size in bytes (soft limit)
    pub max_cache_bytes: usize,
    /// Parquet writer options
    pub writer_options: ParquetWriterOptions,
    /// Extensions to auto-transcode
    pub transcode_extensions: Vec<String>,
    /// Properties passed from Iceberg catalog
    pub properties: HashMap<String, String>,
}

impl Default for RosettaFileIOConfig {
    fn default() -> Self {
        Self {
            enable_cache: true,
            max_cache_entries: 1000,
            max_cache_bytes: 2 * 1024 * 1024 * 1024, // 2GB
            writer_options: ParquetWriterOptions::max_compatibility(),
            transcode_extensions: vec!["vortex".to_string(), "lance".to_string(), "f3".to_string()],
            properties: HashMap::new(),
        }
    }
}

impl RosettaFileIOConfig {
    /// Create from Iceberg catalog properties
    pub fn from_properties(props: HashMap<String, String>) -> Self {
        let mut config = Self::default();

        if let Some(cache) = props.get("rosetta.cache-enabled") {
            config.enable_cache = cache.parse().unwrap_or(true);
        }

        if let Some(max_entries) = props.get("rosetta.max-cache-entries") {
            config.max_cache_entries = max_entries.parse().unwrap_or(config.max_cache_entries);
        }

        if let Some(max_cache) = props.get("rosetta.max-cache-bytes") {
            config.max_cache_bytes = max_cache.parse().unwrap_or(config.max_cache_bytes);
        }

        if let Some(exts) = props.get("rosetta.transcode-extensions") {
            config.transcode_extensions = exts.split(',').map(|s| s.trim().to_string()).collect();
        }

        config.properties = props;
        config
    }
}

/// Cache entry with size tracking
struct CacheEntry {
    data: Bytes,
    size: usize,
}

/// LRU cache wrapper with size tracking
struct SizedLruCache {
    cache: LruCache<String, CacheEntry>,
    current_size: usize,
    max_size: usize,
}

impl SizedLruCache {
    fn new(max_entries: usize, max_size: usize) -> Self {
        Self {
            cache: LruCache::new(NonZeroUsize::new(max_entries).unwrap_or(NonZeroUsize::MIN)),
            current_size: 0,
            max_size,
        }
    }

    fn get(&mut self, key: &str) -> Option<Bytes> {
        self.cache.get(key).map(|e| e.data.clone())
    }

    fn put(&mut self, key: String, data: Bytes) {
        let size = data.len();

        // Evict entries until we have space (both count and size limits)
        while self.current_size + size > self.max_size && !self.cache.is_empty() {
            if let Some((_, evicted)) = self.cache.pop_lru() {
                self.current_size = self.current_size.saturating_sub(evicted.size);
                debug!(
                    evicted_size = evicted.size,
                    current_size = self.current_size,
                    "LRU evicted cache entry"
                );
            }
        }

        // If entry already exists, update size tracking
        if let Some(existing) = self.cache.peek(&key) {
            self.current_size = self.current_size.saturating_sub(existing.size);
        }

        self.current_size += size;
        self.cache.put(key, CacheEntry { data, size });
    }

    fn clear(&mut self) {
        self.cache.clear();
        self.current_size = 0;
    }

    fn len(&self) -> usize {
        self.cache.len()
    }

    fn size(&self) -> usize {
        self.current_size
    }
}

/// Rosetta FileIO implementation for Iceberg
///
/// This FileIO implementation intercepts file reads and transcodes
/// non-Parquet formats to Parquet v1 bytes.
pub struct RosettaFileIO {
    config: RosettaFileIOConfig,
    cache: Arc<Mutex<SizedLruCache>>,
    /// Reserved for future optimization: reuse transcoder instance with pre-configured options.
    /// Currently, `read_file_with_filter` creates per-request transcoders to support custom filters.
    #[allow(dead_code)]
    transcoder: Transcoder,
}

impl RosettaFileIO {
    /// Create a new RosettaFileIO
    pub fn new(config: RosettaFileIOConfig) -> Result<Self> {
        let transcoder = Transcoder::new().with_writer_options(config.writer_options.clone());

        let cache = SizedLruCache::new(config.max_cache_entries, config.max_cache_bytes);

        Ok(Self {
            config,
            cache: Arc::new(Mutex::new(cache)),
            transcoder,
        })
    }

    /// Create from Iceberg catalog properties
    pub fn from_properties(props: HashMap<String, String>) -> Result<Self> {
        Self::new(RosettaFileIOConfig::from_properties(props))
    }

    /// Create with default config
    pub fn default_config() -> Result<Self> {
        Self::new(RosettaFileIOConfig::default())
    }

    /// Create a new input file
    pub fn new_input(&self, location: &str) -> Result<RosettaInputFile<'_>> {
        Ok(RosettaInputFile {
            location: location.to_string(),
            file_io: self,
            filter: None,
        })
    }

    /// Create a new output file
    pub fn new_output(&self, location: &str) -> Result<RosettaOutputFile<'_>> {
        Ok(RosettaOutputFile {
            location: location.to_string(),
            file_io: self,
        })
    }

    /// Delete a file
    pub async fn delete(&self, location: &str) -> Result<()> {
        // Parse location and delete
        if is_cloud_url(location) {
            self.delete_object_store(location).await
        } else {
            tokio::fs::remove_file(location)
                .await
                .map_err(|e| Error::io_error(format!("Delete failed for '{}': {}", location, e)))
        }
    }

    /// Check if location exists
    pub async fn exists(&self, location: &str) -> Result<bool> {
        if is_cloud_url(location) {
            self.exists_object_store(location).await
        } else {
            Ok(Path::new(location).exists())
        }
    }

    /// Check if path should be transcoded based on extension
    pub fn should_transcode(&self, location: &str) -> bool {
        let path = Path::new(location);
        if let Some(ext) = path.extension() {
            let ext_str = ext.to_string_lossy().to_lowercase();
            self.config.transcode_extensions.contains(&ext_str)
        } else {
            false
        }
    }

    /// Read file, transcoding if necessary.
    ///
    /// This is a convenience method for reads without filter pushdown.
    /// Currently all callers use `read_file_with_filter` directly for explicit filter handling.
    #[allow(dead_code)]
    async fn read_file(&self, location: &str) -> Result<Bytes> {
        self.read_file_with_filter(location, None).await
    }

    /// Read file with optional filter pushdown
    ///
    /// If a filter is provided, it will be pushed down to the underlying
    /// format reader during transcoding, potentially reducing the amount
    /// of data that needs to be processed.
    async fn read_file_with_filter(&self, location: &str, filter: Option<Expr>) -> Result<Bytes> {
        // For filtered reads, we generate a cache key that includes the filter
        // This ensures different filters get separate cache entries
        let cache_key = if let Some(ref f) = filter {
            format!("{}::{:?}", location, f)
        } else {
            location.to_string()
        };

        // Check cache
        if self.config.enable_cache {
            let mut cache = self.cache.lock().await;
            if let Some(data) = cache.get(&cache_key) {
                debug!(location, has_filter = filter.is_some(), "Cache hit");
                return Ok(data);
            }
        }

        // Read and possibly transcode
        let data = if self.should_transcode(location) {
            debug!(location, has_filter = filter.is_some(), "Transcoding file");

            // Create transcoder with filter if provided
            let transcoder = if let Some(f) = filter {
                Transcoder::new()
                    .with_writer_options(self.config.writer_options.clone())
                    .with_filter(f)
            } else {
                Transcoder::new().with_writer_options(self.config.writer_options.clone())
            };

            let result = if is_cloud_url(location) {
                transcoder.transcode_url(location).await?
            } else {
                transcoder.transcode_file(location).await?
            };
            result.bytes
        } else {
            // Direct read (filters can't be applied to non-transcoded reads)
            self.read_raw(location).await?
        };

        // Cache
        if self.config.enable_cache {
            let mut cache = self.cache.lock().await;
            cache.put(cache_key, data.clone());
        }

        Ok(data)
    }

    /// Read raw bytes without transcoding
    async fn read_raw(&self, location: &str) -> Result<Bytes> {
        if is_cloud_url(location) {
            self.read_object_store(location).await
        } else {
            let data = tokio::fs::read(location)
                .await
                .map_err(|e| Error::io_error(format!("Read failed for '{}': {}", location, e)))?;
            Ok(Bytes::from(data))
        }
    }

    /// Read from object store using shared utilities
    async fn read_object_store(&self, location: &str) -> Result<Bytes> {
        use object_store::ObjectStore;

        let parsed = url::Url::parse(location)
            .map_err(|e| Error::invalid_file(format!("Invalid URL '{}': {}", location, e)))?;

        let bucket = parsed
            .host_str()
            .ok_or_else(|| Error::invalid_file(format!("Missing bucket in URL: {}", location)))?;
        let key = parsed.path().trim_start_matches('/');
        let path = object_store::path::Path::from(key);

        let store = match parsed.scheme() {
            "s3" => build_s3_store(bucket)?,
            "gs" => build_gcs_store(bucket)?,
            scheme => {
                return Err(Error::invalid_file(format!(
                    "Unsupported URL scheme '{}' in: {}",
                    scheme, location
                )));
            }
        };

        let data = store
            .get(&path)
            .await
            .map_err(|e| Error::io_error(format!("Failed to get '{}': {}", location, e)))?
            .bytes()
            .await
            .map_err(|e| {
                Error::io_error(format!("Failed to read bytes from '{}': {}", location, e))
            })?;

        Ok(data)
    }

    /// Delete from object store using shared utilities
    async fn delete_object_store(&self, location: &str) -> Result<()> {
        use object_store::ObjectStore;

        let parsed = url::Url::parse(location)
            .map_err(|e| Error::invalid_file(format!("Invalid URL '{}': {}", location, e)))?;

        let bucket = parsed
            .host_str()
            .ok_or_else(|| Error::invalid_file(format!("Missing bucket in URL: {}", location)))?;
        let key = parsed.path().trim_start_matches('/');
        let path = object_store::path::Path::from(key);

        let store = match parsed.scheme() {
            "s3" => build_s3_store(bucket)?,
            "gs" => build_gcs_store(bucket)?,
            scheme => {
                return Err(Error::invalid_file(format!(
                    "Unsupported URL scheme '{}' in: {}",
                    scheme, location
                )));
            }
        };

        store
            .delete(&path)
            .await
            .map_err(|e| Error::io_error(format!("Failed to delete '{}': {}", location, e)))?;

        Ok(())
    }

    /// Check existence in object store using shared utilities
    async fn exists_object_store(&self, location: &str) -> Result<bool> {
        use object_store::ObjectStore;

        let parsed = url::Url::parse(location)
            .map_err(|e| Error::invalid_file(format!("Invalid URL '{}': {}", location, e)))?;

        let bucket = parsed
            .host_str()
            .ok_or_else(|| Error::invalid_file(format!("Missing bucket in URL: {}", location)))?;
        let key = parsed.path().trim_start_matches('/');
        let path = object_store::path::Path::from(key);

        let store = match parsed.scheme() {
            "s3" => build_s3_store(bucket)?,
            "gs" => build_gcs_store(bucket)?,
            scheme => {
                return Err(Error::invalid_file(format!(
                    "Unsupported URL scheme '{}' in: {}",
                    scheme, location
                )));
            }
        };

        match store.head(&path).await {
            Ok(_) => Ok(true),
            Err(object_store::Error::NotFound { .. }) => Ok(false),
            Err(e) => Err(Error::io_error(format!(
                "Failed to check existence of '{}': {}",
                location, e
            ))),
        }
    }

    /// Clear the cache
    pub async fn clear_cache(&self) {
        let mut cache = self.cache.lock().await;
        cache.clear();
        info!("FileIO cache cleared");
    }

    /// Get cache statistics
    pub async fn cache_stats(&self) -> (usize, usize) {
        let cache = self.cache.lock().await;
        (cache.len(), cache.size())
    }
}

/// Input file for reading
pub struct RosettaInputFile<'a> {
    location: String,
    file_io: &'a RosettaFileIO,
    filter: Option<Expr>,
}

impl<'a> RosettaInputFile<'a> {
    /// Get file location
    pub fn location(&self) -> &str {
        &self.location
    }

    /// Set a filter to push down during read.
    ///
    /// The filter will be pushed to the underlying format reader
    /// during transcoding, reducing the amount of data processed.
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// use rosetta::expr::{col, lit};
    ///
    /// let filter = col("age").gt(lit(30i64));
    /// let input = file_io
    ///     .new_input("data.vortex")?
    ///     .with_filter(filter);
    /// let data = input.read().await?;
    /// ```
    pub fn with_filter(mut self, filter: Expr) -> Self {
        self.filter = Some(filter);
        self
    }

    /// Read file contents (transcoded if necessary)
    pub async fn read(&self) -> Result<Bytes> {
        self.file_io
            .read_file_with_filter(&self.location, self.filter.clone())
            .await
    }

    /// Check if file exists
    pub async fn exists(&self) -> Result<bool> {
        self.file_io.exists(&self.location).await
    }

    /// Get file length (after transcoding if applicable)
    pub async fn len(&self) -> Result<u64> {
        let data = self.read().await?;
        Ok(data.len() as u64)
    }
}

/// Output file for writing
pub struct RosettaOutputFile<'a> {
    location: String,
    file_io: &'a RosettaFileIO,
}

impl<'a> RosettaOutputFile<'a> {
    /// Get file location
    pub fn location(&self) -> &str {
        &self.location
    }

    /// Write data to file
    pub async fn write(&self, data: Bytes) -> Result<()> {
        if is_cloud_url(&self.location) {
            self.write_object_store(data).await
        } else {
            tokio::fs::write(&self.location, &data).await.map_err(|e| {
                Error::io_error(format!("Write failed for '{}': {}", self.location, e))
            })
        }
    }

    /// Write to object store using shared utilities
    async fn write_object_store(&self, data: Bytes) -> Result<()> {
        use object_store::{ObjectStore, PutPayload};

        let parsed = url::Url::parse(&self.location)
            .map_err(|e| Error::invalid_file(format!("Invalid URL '{}': {}", self.location, e)))?;

        let bucket = parsed.host_str().ok_or_else(|| {
            Error::invalid_file(format!("Missing bucket in URL: {}", self.location))
        })?;
        let key = parsed.path().trim_start_matches('/');
        let path = object_store::path::Path::from(key);

        let store = match parsed.scheme() {
            "s3" => build_s3_store(bucket)?,
            "gs" => build_gcs_store(bucket)?,
            scheme => {
                return Err(Error::invalid_file(format!(
                    "Unsupported URL scheme '{}' in: {}",
                    scheme, self.location
                )));
            }
        };

        store
            .put(&path, PutPayload::from_bytes(data))
            .await
            .map_err(|e| Error::io_error(format!("Failed to write '{}': {}", self.location, e)))?;

        Ok(())
    }

    /// Check if file exists
    pub async fn exists(&self) -> Result<bool> {
        self.file_io.exists(&self.location).await
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_config_default() {
        let config = RosettaFileIOConfig::default();
        assert!(config.enable_cache);
        assert!(config.transcode_extensions.contains(&"vortex".to_string()));
    }

    #[test]
    fn test_config_from_properties() {
        let mut props = HashMap::new();
        props.insert("rosetta.cache-enabled".to_string(), "false".to_string());
        props.insert(
            "rosetta.transcode-extensions".to_string(),
            "vortex,custom".to_string(),
        );

        let config = RosettaFileIOConfig::from_properties(props);
        assert!(!config.enable_cache);
        assert!(config.transcode_extensions.contains(&"custom".to_string()));
    }

    #[test]
    fn test_should_transcode() {
        let file_io = RosettaFileIO::default_config().unwrap();

        assert!(file_io.should_transcode("data.vortex"));
        assert!(file_io.should_transcode("s3://bucket/data.lance"));
        assert!(!file_io.should_transcode("data.parquet"));
        assert!(!file_io.should_transcode("gs://bucket/data.parquet"));
    }

    #[tokio::test]
    async fn test_new_input() {
        let file_io = RosettaFileIO::default_config().unwrap();
        let input = file_io.new_input("test.parquet").unwrap();
        assert_eq!(input.location(), "test.parquet");
    }

    #[tokio::test]
    async fn test_new_output() {
        let file_io = RosettaFileIO::default_config().unwrap();
        let output = file_io.new_output("output.parquet").unwrap();
        assert_eq!(output.location(), "output.parquet");
    }

    #[tokio::test]
    async fn test_lru_cache() {
        let mut cache = SizedLruCache::new(3, 1000);

        // Add some entries
        cache.put("a".to_string(), Bytes::from(vec![0u8; 100]));
        cache.put("b".to_string(), Bytes::from(vec![0u8; 200]));
        cache.put("c".to_string(), Bytes::from(vec![0u8; 300]));

        assert_eq!(cache.len(), 3);
        assert_eq!(cache.size(), 600);

        // Access "a" to make it recently used
        assert!(cache.get("a").is_some());

        // Add more entries to trigger eviction
        cache.put("d".to_string(), Bytes::from(vec![0u8; 400]));

        // "b" should be evicted (least recently used)
        assert!(cache.get("a").is_some()); // Still there
        assert!(cache.get("c").is_some()); // Still there
        assert!(cache.get("d").is_some()); // Just added
    }

    #[tokio::test]
    async fn test_cache_stats() {
        let file_io = RosettaFileIO::default_config().unwrap();
        let (entries, size) = file_io.cache_stats().await;
        assert_eq!(entries, 0);
        assert_eq!(size, 0);
    }
}
