// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Iceberg FileIO integration for transparent format transcoding
//!
//! This module provides an Iceberg FileIO implementation that transcodes
//! any supported format to Parquet v1 on read.
//!
//! # How It Works
//!
//! ```text
//! Iceberg Catalog
//!     │
//!     │ Table scan
//!     ▼
//! ┌─────────────────┐
//! │ RosettaFileIO   │  Custom FileIO
//! └─────────────────┘
//!     │
//!     │ Read data file (might be Vortex/Lance/F3)
//!     ▼
//! ┌─────────────────┐
//! │ Transcoder      │  Any format → Parquet v1
//! └─────────────────┘
//!     │
//!     ▼
//! Iceberg receives Parquet bytes
//! ```
//!
//! # Usage (Python)
//!
//! ```python
//! from pyiceberg.catalog import load_catalog
//! from rosetta.iceberg import RosettaFileIO
//!
//! catalog = load_catalog("my_catalog", **{
//!     "io-impl": "rosetta.iceberg.RosettaFileIO",
//!     "rosetta.cache-enabled": "true",
//! })
//!
//! # Now table scans transparently read any format
//! table = catalog.load_table("db.table")
//! df = table.scan().to_arrow()
//! ```
//!
//! # Usage (Rust)
//!
//! ```rust,ignore
//! use rosetta::iceberg::RosettaFileIO;
//!
//! let file_io = RosettaFileIO::new(config)?;
//! let input_file = file_io.new_input("s3://bucket/data.vortex")?;
//! let bytes = input_file.read().await?;  // Returns Parquet bytes!
//! ```

mod fileio;

pub use fileio::{RosettaFileIO, RosettaFileIOConfig, RosettaInputFile, RosettaOutputFile};
