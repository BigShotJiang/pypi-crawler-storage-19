// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Expression language for filter pushdown
//!
//! This module provides a unified expression language that can be translated
//! to native format-specific filters:
//! - Parquet: arrow-rs RowFilter / ArrowPredicate
//! - Vortex: vortex::expr::Expr
//! - Lance: SQL filter strings
//!
//! # Example
//!
//! ```rust,ignore
//! use rosetta::expr::{col, lit, Expr};
//!
//! // Create filter: age > 30 AND status = 'active'
//! let filter = col("age").gt(lit(30)).and(col("status").eq(lit("active")));
//!
//! // Apply to reader
//! reader.push_filter(&filter)?;
//! let data = reader.read_all().await?;
//! ```

use crate::stats::ScalarValue;
use std::fmt;

/// A filter expression that can be pushed down to format readers
#[derive(Debug, Clone, PartialEq)]
pub enum Expr {
    /// Reference to a column by name
    Column(String),

    /// A literal/constant value
    Literal(ScalarValue),

    /// Binary expression: left op right
    BinaryExpr {
        left: Box<Expr>,
        op: Operator,
        right: Box<Expr>,
    },

    /// Unary NOT expression
    Not(Box<Expr>),

    /// IS NULL check
    IsNull(Box<Expr>),

    /// IS NOT NULL check
    IsNotNull(Box<Expr>),

    /// IN list check
    InList {
        expr: Box<Expr>,
        list: Vec<Expr>,
        negated: bool,
    },

    /// BETWEEN check (inclusive)
    Between {
        expr: Box<Expr>,
        low: Box<Expr>,
        high: Box<Expr>,
        negated: bool,
    },

    /// LIKE pattern matching
    Like {
        expr: Box<Expr>,
        pattern: String,
        negated: bool,
        case_insensitive: bool,
    },

    /// CAST expression
    Cast { expr: Box<Expr>, data_type: String },

    /// Alias expression (for output naming)
    Alias { expr: Box<Expr>, name: String },
}

/// Operators for binary expressions
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Operator {
    // Comparison operators
    /// Equal (=)
    Eq,
    /// Not equal (!=, <>)
    NotEq,
    /// Less than (<)
    Lt,
    /// Less than or equal (<=)
    LtEq,
    /// Greater than (>)
    Gt,
    /// Greater than or equal (>=)
    GtEq,

    // Logical operators
    /// Logical AND
    And,
    /// Logical OR
    Or,

    // Arithmetic operators
    /// Addition (+)
    Plus,
    /// Subtraction (-)
    Minus,
    /// Multiplication (*)
    Multiply,
    /// Division (/)
    Divide,
    /// Modulo (%)
    Modulo,

    // String operators
    /// String concatenation (||)
    StringConcat,

    // Bitwise operators
    /// Bitwise AND (&)
    BitwiseAnd,
    /// Bitwise OR (|)
    BitwiseOr,
    /// Bitwise XOR (^)
    BitwiseXor,
    /// Bitwise shift left (<<)
    BitwiseShiftLeft,
    /// Bitwise shift right (>>)
    BitwiseShiftRight,
}

impl Operator {
    /// Get SQL representation of operator
    pub fn to_sql(&self) -> &'static str {
        match self {
            Operator::Eq => "=",
            Operator::NotEq => "!=",
            Operator::Lt => "<",
            Operator::LtEq => "<=",
            Operator::Gt => ">",
            Operator::GtEq => ">=",
            Operator::And => "AND",
            Operator::Or => "OR",
            Operator::Plus => "+",
            Operator::Minus => "-",
            Operator::Multiply => "*",
            Operator::Divide => "/",
            Operator::Modulo => "%",
            Operator::StringConcat => "||",
            Operator::BitwiseAnd => "&",
            Operator::BitwiseOr => "|",
            Operator::BitwiseXor => "^",
            Operator::BitwiseShiftLeft => "<<",
            Operator::BitwiseShiftRight => ">>",
        }
    }

    /// Check if this is a comparison operator
    pub fn is_comparison(&self) -> bool {
        matches!(
            self,
            Operator::Eq
                | Operator::NotEq
                | Operator::Lt
                | Operator::LtEq
                | Operator::Gt
                | Operator::GtEq
        )
    }

    /// Check if this is a logical operator
    pub fn is_logical(&self) -> bool {
        matches!(self, Operator::And | Operator::Or)
    }

    /// Check if this is an arithmetic operator
    pub fn is_arithmetic(&self) -> bool {
        matches!(
            self,
            Operator::Plus
                | Operator::Minus
                | Operator::Multiply
                | Operator::Divide
                | Operator::Modulo
        )
    }
}

impl fmt::Display for Operator {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.to_sql())
    }
}

// Expression builder functions
impl Expr {
    /// Create a column reference
    pub fn column(name: impl Into<String>) -> Self {
        Expr::Column(name.into())
    }

    /// Create a literal value
    pub fn literal(value: impl Into<ScalarValue>) -> Self {
        Expr::Literal(value.into())
    }

    /// Create an equality comparison
    pub fn eq(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::Eq,
            right: Box::new(other),
        }
    }

    /// Create a not-equal comparison
    pub fn not_eq(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::NotEq,
            right: Box::new(other),
        }
    }

    /// Create a less-than comparison
    pub fn lt(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::Lt,
            right: Box::new(other),
        }
    }

    /// Create a less-than-or-equal comparison
    pub fn lt_eq(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::LtEq,
            right: Box::new(other),
        }
    }

    /// Create a greater-than comparison
    pub fn gt(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::Gt,
            right: Box::new(other),
        }
    }

    /// Create a greater-than-or-equal comparison
    pub fn gt_eq(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::GtEq,
            right: Box::new(other),
        }
    }

    /// Create a logical AND
    pub fn and(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::And,
            right: Box::new(other),
        }
    }

    /// Create a logical OR
    pub fn or(self, other: Expr) -> Expr {
        Expr::BinaryExpr {
            left: Box::new(self),
            op: Operator::Or,
            right: Box::new(other),
        }
    }

    /// Create a logical NOT
    #[allow(clippy::should_implement_trait)]
    pub fn not(self) -> Expr {
        Expr::Not(Box::new(self))
    }

    /// Create an IS NULL check
    pub fn is_null(self) -> Expr {
        Expr::IsNull(Box::new(self))
    }

    /// Create an IS NOT NULL check
    pub fn is_not_null(self) -> Expr {
        Expr::IsNotNull(Box::new(self))
    }

    /// Create an IN list check
    pub fn in_list(self, list: Vec<Expr>) -> Expr {
        Expr::InList {
            expr: Box::new(self),
            list,
            negated: false,
        }
    }

    /// Create a NOT IN list check
    pub fn not_in_list(self, list: Vec<Expr>) -> Expr {
        Expr::InList {
            expr: Box::new(self),
            list,
            negated: true,
        }
    }

    /// Create a BETWEEN check
    pub fn between(self, low: Expr, high: Expr) -> Expr {
        Expr::Between {
            expr: Box::new(self),
            low: Box::new(low),
            high: Box::new(high),
            negated: false,
        }
    }

    /// Create a NOT BETWEEN check
    pub fn not_between(self, low: Expr, high: Expr) -> Expr {
        Expr::Between {
            expr: Box::new(self),
            low: Box::new(low),
            high: Box::new(high),
            negated: true,
        }
    }

    /// Create a LIKE pattern match
    pub fn like(self, pattern: impl Into<String>) -> Expr {
        Expr::Like {
            expr: Box::new(self),
            pattern: pattern.into(),
            negated: false,
            case_insensitive: false,
        }
    }

    /// Create an ILIKE (case-insensitive) pattern match
    pub fn ilike(self, pattern: impl Into<String>) -> Expr {
        Expr::Like {
            expr: Box::new(self),
            pattern: pattern.into(),
            negated: false,
            case_insensitive: true,
        }
    }

    /// Create an alias for output naming
    pub fn alias(self, name: impl Into<String>) -> Expr {
        Expr::Alias {
            expr: Box::new(self),
            name: name.into(),
        }
    }

    /// Convert expression to SQL string representation
    pub fn to_sql(&self) -> String {
        match self {
            Expr::Column(name) => format!("\"{}\"", name),
            Expr::Literal(value) => format!("{}", value),
            Expr::BinaryExpr { left, op, right } => {
                format!("({} {} {})", left.to_sql(), op, right.to_sql())
            }
            Expr::Not(expr) => format!("(NOT {})", expr.to_sql()),
            Expr::IsNull(expr) => format!("({} IS NULL)", expr.to_sql()),
            Expr::IsNotNull(expr) => format!("({} IS NOT NULL)", expr.to_sql()),
            Expr::InList {
                expr,
                list,
                negated,
            } => {
                let items: Vec<String> = list.iter().map(|e| e.to_sql()).collect();
                let neg = if *negated { "NOT " } else { "" };
                format!("({} {}IN ({}))", expr.to_sql(), neg, items.join(", "))
            }
            Expr::Between {
                expr,
                low,
                high,
                negated,
            } => {
                let neg = if *negated { "NOT " } else { "" };
                format!(
                    "({} {}BETWEEN {} AND {})",
                    expr.to_sql(),
                    neg,
                    low.to_sql(),
                    high.to_sql()
                )
            }
            Expr::Like {
                expr,
                pattern,
                negated,
                case_insensitive,
            } => {
                let op = if *case_insensitive { "ILIKE" } else { "LIKE" };
                let neg = if *negated { "NOT " } else { "" };
                format!("({} {}{} '{}')", expr.to_sql(), neg, op, pattern)
            }
            Expr::Cast { expr, data_type } => {
                format!("CAST({} AS {})", expr.to_sql(), data_type)
            }
            Expr::Alias { expr, name } => {
                format!("{} AS \"{}\"", expr.to_sql(), name)
            }
        }
    }

    /// Get all column names referenced in this expression
    pub fn columns(&self) -> Vec<String> {
        let mut cols = Vec::new();
        self.collect_columns(&mut cols);
        cols
    }

    /// Convert expression to Lance SQL filter string
    ///
    /// Lance uses SQL-style filter strings for predicate pushdown.
    /// This differs from `to_sql()` in that column names are not quoted.
    pub fn to_lance_sql(&self) -> String {
        match self {
            Expr::Column(name) => name.clone(), // Lance: unquoted column names
            Expr::Literal(value) => format!("{}", value),
            Expr::BinaryExpr { left, op, right } => {
                format!("{} {} {}", left.to_lance_sql(), op, right.to_lance_sql())
            }
            Expr::Not(expr) => format!("NOT {}", expr.to_lance_sql()),
            Expr::IsNull(expr) => format!("{} IS NULL", expr.to_lance_sql()),
            Expr::IsNotNull(expr) => format!("{} IS NOT NULL", expr.to_lance_sql()),
            Expr::InList {
                expr,
                list,
                negated,
            } => {
                let items: Vec<String> = list.iter().map(|e| e.to_lance_sql()).collect();
                let neg = if *negated { "NOT " } else { "" };
                format!("{} {}IN ({})", expr.to_lance_sql(), neg, items.join(", "))
            }
            Expr::Between {
                expr,
                low,
                high,
                negated,
            } => {
                let neg = if *negated { "NOT " } else { "" };
                format!(
                    "{} {}BETWEEN {} AND {}",
                    expr.to_lance_sql(),
                    neg,
                    low.to_lance_sql(),
                    high.to_lance_sql()
                )
            }
            Expr::Like {
                expr,
                pattern,
                negated,
                case_insensitive,
            } => {
                let op = if *case_insensitive { "ILIKE" } else { "LIKE" };
                let neg = if *negated { "NOT " } else { "" };
                format!("{} {}{} '{}'", expr.to_lance_sql(), neg, op, pattern)
            }
            Expr::Cast { expr, data_type } => {
                format!("CAST({} AS {})", expr.to_lance_sql(), data_type)
            }
            Expr::Alias { expr, name } => {
                format!("{} AS {}", expr.to_lance_sql(), name)
            }
        }
    }

    /// Convert expression to Vortex expression
    ///
    /// Returns None if the expression cannot be translated to Vortex format.
    /// Vortex uses a function-based API with ExprRef = Arc<dyn VortexExpr>.
    #[cfg(feature = "vortex-reader")]
    pub fn to_vortex_expr(&self) -> Option<vortex::expr::ExprRef> {
        use vortex::compute::{BetweenOptions, StrictComparison};
        use vortex::expr as vx;
        use vortex::scalar::Scalar as VortexScalar;

        match self {
            Expr::Column(name) => Some(vx::col(name.as_str())),

            Expr::Literal(scalar) => {
                // Vortex requires matching types for comparisons.
                // Use the specific type, not promoted types.
                let vortex_scalar: VortexScalar = match scalar {
                    ScalarValue::Boolean(v) => (*v).into(),
                    ScalarValue::Int8(v) => (*v).into(),
                    ScalarValue::Int16(v) => (*v).into(),
                    ScalarValue::Int32(v) => (*v).into(),
                    ScalarValue::Int64(v) => (*v).into(),
                    ScalarValue::UInt8(v) => (*v).into(),
                    ScalarValue::UInt16(v) => (*v).into(),
                    ScalarValue::UInt32(v) => (*v).into(),
                    ScalarValue::UInt64(v) => (*v).into(),
                    ScalarValue::Float32(v) => (*v).into(),
                    ScalarValue::Float64(v) => (*v).into(),
                    ScalarValue::Utf8(v) => v.as_str().into(),
                    // Binary, Date, Timestamp, Decimal not directly supported
                    _ => return None,
                };
                Some(vx::lit(vortex_scalar))
            }

            Expr::BinaryExpr { left, op, right } => {
                let left_expr = left.to_vortex_expr()?;
                let right_expr = right.to_vortex_expr()?;

                match op {
                    Operator::Eq => Some(vx::eq(left_expr, right_expr)),
                    Operator::NotEq => Some(vx::not_eq(left_expr, right_expr)),
                    Operator::Lt => Some(vx::lt(left_expr, right_expr)),
                    Operator::LtEq => Some(vx::lt_eq(left_expr, right_expr)),
                    Operator::Gt => Some(vx::gt(left_expr, right_expr)),
                    Operator::GtEq => Some(vx::gt_eq(left_expr, right_expr)),
                    Operator::And => Some(vx::and(left_expr, right_expr)),
                    Operator::Or => Some(vx::or(left_expr, right_expr)),
                    // Arithmetic operators not typically used in filter predicates
                    _ => None,
                }
            }

            Expr::Not(inner) => {
                let inner_expr = inner.to_vortex_expr()?;
                Some(vx::not(inner_expr))
            }

            Expr::IsNull(inner) => {
                let inner_expr = inner.to_vortex_expr()?;
                Some(vx::is_null(inner_expr))
            }

            Expr::IsNotNull(inner) => {
                // Vortex doesn't have is_not_null, use not(is_null(...))
                let inner_expr = inner.to_vortex_expr()?;
                Some(vx::not(vx::is_null(inner_expr)))
            }

            Expr::InList { .. } => {
                // Vortex doesn't have native IN support - would need to expand to OR chain
                None
            }

            Expr::Between {
                expr,
                low,
                high,
                negated,
            } => {
                // BETWEEN is inclusive on both ends
                let expr_vx = expr.to_vortex_expr()?;
                let low_vx = low.to_vortex_expr()?;
                let high_vx = high.to_vortex_expr()?;

                let options = BetweenOptions {
                    lower_strict: StrictComparison::NonStrict,
                    upper_strict: StrictComparison::NonStrict,
                };
                let between = vx::between(expr_vx, low_vx, high_vx, options);

                if *negated {
                    Some(vx::not(between))
                } else {
                    Some(between)
                }
            }

            // LIKE, CAST, ALIAS not supported in Vortex filter pushdown
            Expr::Like { .. } | Expr::Cast { .. } | Expr::Alias { .. } => None,
        }
    }

    /// Check if this expression can be fully translated to Vortex
    #[cfg(feature = "vortex-reader")]
    pub fn can_push_to_vortex(&self) -> bool {
        self.to_vortex_expr().is_some()
    }

    /// Check if this expression can be fully translated to Lance SQL
    pub fn can_push_to_lance(&self) -> bool {
        // Lance supports SQL-style filters, so most expressions work
        // CAST and LIKE may have limited support depending on Lance version
        match self {
            Expr::Cast { .. } => false, // Lance may not support all CAST types
            _ => true,
        }
    }

    fn collect_columns(&self, cols: &mut Vec<String>) {
        match self {
            Expr::Column(name) => {
                if !cols.contains(name) {
                    cols.push(name.clone());
                }
            }
            Expr::Literal(_) => {}
            Expr::BinaryExpr { left, right, .. } => {
                left.collect_columns(cols);
                right.collect_columns(cols);
            }
            Expr::Not(expr) => expr.collect_columns(cols),
            Expr::IsNull(expr) => expr.collect_columns(cols),
            Expr::IsNotNull(expr) => expr.collect_columns(cols),
            Expr::InList { expr, list, .. } => {
                expr.collect_columns(cols);
                for item in list {
                    item.collect_columns(cols);
                }
            }
            Expr::Between {
                expr, low, high, ..
            } => {
                expr.collect_columns(cols);
                low.collect_columns(cols);
                high.collect_columns(cols);
            }
            Expr::Like { expr, .. } => expr.collect_columns(cols),
            Expr::Cast { expr, .. } => expr.collect_columns(cols),
            Expr::Alias { expr, .. } => expr.collect_columns(cols),
        }
    }

    /// Parse an expression from JSON
    ///
    /// # JSON Format
    ///
    /// Column: `{"column": "field_name"}`
    /// Literal: `{"literal": {"Int64": 30}}` or `{"literal": {"Utf8": "hello"}}`
    /// Binary: `{"op": "gt", "left": {...}, "right": {...}}`
    /// Not: `{"not": {...}}`
    /// IsNull: `{"is_null": {...}}`
    /// IsNotNull: `{"is_not_null": {...}}`
    ///
    /// # Example
    ///
    /// ```rust,ignore
    /// let json = r#"{"op": "gt", "left": {"column": "age"}, "right": {"literal": {"Int64": 30}}}"#;
    /// let expr = Expr::from_json(json)?;
    /// ```
    pub fn from_json(json: &str) -> Result<Self, String> {
        let value: serde_json::Value =
            serde_json::from_str(json).map_err(|e| format!("Invalid JSON: {}", e))?;
        Self::from_json_value(&value)
    }

    fn from_json_value(value: &serde_json::Value) -> Result<Self, String> {
        let obj = value
            .as_object()
            .ok_or_else(|| "Expected JSON object".to_string())?;

        // Column reference
        if let Some(col_name) = obj.get("column") {
            let name = col_name
                .as_str()
                .ok_or_else(|| "Column name must be a string".to_string())?;
            return Ok(Expr::Column(name.to_string()));
        }

        // Literal value
        if let Some(lit_value) = obj.get("literal") {
            let scalar = Self::scalar_from_json(lit_value)?;
            return Ok(Expr::Literal(scalar));
        }

        // Binary expression
        if let Some(op_value) = obj.get("op") {
            let op_str = op_value
                .as_str()
                .ok_or_else(|| "Operator must be a string".to_string())?;
            let op = Self::operator_from_str(op_str)?;

            let left = obj
                .get("left")
                .ok_or_else(|| "Binary expression missing 'left'".to_string())?;
            let right = obj
                .get("right")
                .ok_or_else(|| "Binary expression missing 'right'".to_string())?;

            return Ok(Expr::BinaryExpr {
                left: Box::new(Self::from_json_value(left)?),
                op,
                right: Box::new(Self::from_json_value(right)?),
            });
        }

        // NOT expression
        if let Some(inner) = obj.get("not") {
            return Ok(Expr::Not(Box::new(Self::from_json_value(inner)?)));
        }

        // IS NULL
        if let Some(inner) = obj.get("is_null") {
            return Ok(Expr::IsNull(Box::new(Self::from_json_value(inner)?)));
        }

        // IS NOT NULL
        if let Some(inner) = obj.get("is_not_null") {
            return Ok(Expr::IsNotNull(Box::new(Self::from_json_value(inner)?)));
        }

        // IN list
        if let Some(in_obj) = obj.get("in_list") {
            let in_obj = in_obj
                .as_object()
                .ok_or_else(|| "in_list must be an object".to_string())?;
            let expr = in_obj
                .get("expr")
                .ok_or_else(|| "in_list missing 'expr'".to_string())?;
            let list = in_obj
                .get("list")
                .and_then(|v| v.as_array())
                .ok_or_else(|| "in_list missing 'list' array".to_string())?;
            let negated = in_obj
                .get("negated")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);

            let list_exprs: Result<Vec<_>, _> = list.iter().map(Self::from_json_value).collect();

            return Ok(Expr::InList {
                expr: Box::new(Self::from_json_value(expr)?),
                list: list_exprs?,
                negated,
            });
        }

        // BETWEEN
        if let Some(between_obj) = obj.get("between") {
            let between_obj = between_obj
                .as_object()
                .ok_or_else(|| "between must be an object".to_string())?;
            let expr = between_obj
                .get("expr")
                .ok_or_else(|| "between missing 'expr'".to_string())?;
            let low = between_obj
                .get("low")
                .ok_or_else(|| "between missing 'low'".to_string())?;
            let high = between_obj
                .get("high")
                .ok_or_else(|| "between missing 'high'".to_string())?;
            let negated = between_obj
                .get("negated")
                .and_then(|v| v.as_bool())
                .unwrap_or(false);

            return Ok(Expr::Between {
                expr: Box::new(Self::from_json_value(expr)?),
                low: Box::new(Self::from_json_value(low)?),
                high: Box::new(Self::from_json_value(high)?),
                negated,
            });
        }

        Err(format!("Unknown expression format: {}", value))
    }

    fn scalar_from_json(value: &serde_json::Value) -> Result<ScalarValue, String> {
        let obj = value
            .as_object()
            .ok_or_else(|| "Literal must be an object".to_string())?;

        // Try each type
        if obj.contains_key("Null") {
            return Ok(ScalarValue::Null);
        }
        if let Some(v) = obj.get("Boolean") {
            return Ok(ScalarValue::Boolean(
                v.as_bool()
                    .ok_or_else(|| "Boolean value expected".to_string())?,
            ));
        }
        if let Some(v) = obj.get("Int8") {
            return Ok(ScalarValue::Int8(
                v.as_i64()
                    .ok_or_else(|| "Int8 value expected".to_string())? as i8,
            ));
        }
        if let Some(v) = obj.get("Int16") {
            return Ok(ScalarValue::Int16(
                v.as_i64()
                    .ok_or_else(|| "Int16 value expected".to_string())? as i16,
            ));
        }
        if let Some(v) = obj.get("Int32") {
            return Ok(ScalarValue::Int32(
                v.as_i64()
                    .ok_or_else(|| "Int32 value expected".to_string())? as i32,
            ));
        }
        if let Some(v) = obj.get("Int64") {
            return Ok(ScalarValue::Int64(
                v.as_i64()
                    .ok_or_else(|| "Int64 value expected".to_string())?,
            ));
        }
        if let Some(v) = obj.get("UInt8") {
            return Ok(ScalarValue::UInt8(
                v.as_u64()
                    .ok_or_else(|| "UInt8 value expected".to_string())? as u8,
            ));
        }
        if let Some(v) = obj.get("UInt16") {
            return Ok(ScalarValue::UInt16(
                v.as_u64()
                    .ok_or_else(|| "UInt16 value expected".to_string())? as u16,
            ));
        }
        if let Some(v) = obj.get("UInt32") {
            return Ok(ScalarValue::UInt32(
                v.as_u64()
                    .ok_or_else(|| "UInt32 value expected".to_string())? as u32,
            ));
        }
        if let Some(v) = obj.get("UInt64") {
            return Ok(ScalarValue::UInt64(
                v.as_u64()
                    .ok_or_else(|| "UInt64 value expected".to_string())?,
            ));
        }
        if let Some(v) = obj.get("Float32") {
            return Ok(ScalarValue::Float32(
                v.as_f64()
                    .ok_or_else(|| "Float32 value expected".to_string())? as f32,
            ));
        }
        if let Some(v) = obj.get("Float64") {
            return Ok(ScalarValue::Float64(
                v.as_f64()
                    .ok_or_else(|| "Float64 value expected".to_string())?,
            ));
        }
        if let Some(v) = obj.get("Utf8") {
            return Ok(ScalarValue::Utf8(
                v.as_str()
                    .ok_or_else(|| "Utf8 value expected".to_string())?
                    .to_string(),
            ));
        }
        if let Some(v) = obj.get("Date32") {
            return Ok(ScalarValue::Date32(
                v.as_i64()
                    .ok_or_else(|| "Date32 value expected".to_string())? as i32,
            ));
        }
        if let Some(v) = obj.get("Date64") {
            return Ok(ScalarValue::Date64(
                v.as_i64()
                    .ok_or_else(|| "Date64 value expected".to_string())?,
            ));
        }

        Err(format!("Unknown literal type: {}", value))
    }

    fn operator_from_str(s: &str) -> Result<Operator, String> {
        match s.to_lowercase().as_str() {
            "eq" | "=" | "==" => Ok(Operator::Eq),
            "neq" | "not_eq" | "!=" | "<>" => Ok(Operator::NotEq),
            "lt" | "<" => Ok(Operator::Lt),
            "lte" | "lt_eq" | "<=" => Ok(Operator::LtEq),
            "gt" | ">" => Ok(Operator::Gt),
            "gte" | "gt_eq" | ">=" => Ok(Operator::GtEq),
            "and" | "&&" => Ok(Operator::And),
            "or" | "||" => Ok(Operator::Or),
            "plus" | "+" => Ok(Operator::Plus),
            "minus" | "-" => Ok(Operator::Minus),
            "multiply" | "*" => Ok(Operator::Multiply),
            "divide" | "/" => Ok(Operator::Divide),
            "modulo" | "%" => Ok(Operator::Modulo),
            _ => Err(format!("Unknown operator: {}", s)),
        }
    }

    /// Convert expression to JSON
    pub fn to_json(&self) -> String {
        self.to_json_value().to_string()
    }

    fn to_json_value(&self) -> serde_json::Value {
        use serde_json::json;

        match self {
            Expr::Column(name) => json!({"column": name}),
            Expr::Literal(scalar) => json!({"literal": Self::scalar_to_json(scalar)}),
            Expr::BinaryExpr { left, op, right } => json!({
                "op": op.to_json_str(),
                "left": left.to_json_value(),
                "right": right.to_json_value()
            }),
            Expr::Not(inner) => json!({"not": inner.to_json_value()}),
            Expr::IsNull(inner) => json!({"is_null": inner.to_json_value()}),
            Expr::IsNotNull(inner) => json!({"is_not_null": inner.to_json_value()}),
            Expr::InList {
                expr,
                list,
                negated,
            } => json!({
                "in_list": {
                    "expr": expr.to_json_value(),
                    "list": list.iter().map(|e| e.to_json_value()).collect::<Vec<_>>(),
                    "negated": negated
                }
            }),
            Expr::Between {
                expr,
                low,
                high,
                negated,
            } => json!({
                "between": {
                    "expr": expr.to_json_value(),
                    "low": low.to_json_value(),
                    "high": high.to_json_value(),
                    "negated": negated
                }
            }),
            Expr::Like {
                expr,
                pattern,
                negated,
                case_insensitive,
            } => json!({
                "like": {
                    "expr": expr.to_json_value(),
                    "pattern": pattern,
                    "negated": negated,
                    "case_insensitive": case_insensitive
                }
            }),
            Expr::Cast { expr, data_type } => json!({
                "cast": {
                    "expr": expr.to_json_value(),
                    "data_type": data_type
                }
            }),
            Expr::Alias { expr, name } => json!({
                "alias": {
                    "expr": expr.to_json_value(),
                    "name": name
                }
            }),
        }
    }

    fn scalar_to_json(scalar: &ScalarValue) -> serde_json::Value {
        use serde_json::json;

        match scalar {
            ScalarValue::Null => json!({"Null": null}),
            ScalarValue::Boolean(v) => json!({"Boolean": v}),
            ScalarValue::Int8(v) => json!({"Int8": v}),
            ScalarValue::Int16(v) => json!({"Int16": v}),
            ScalarValue::Int32(v) => json!({"Int32": v}),
            ScalarValue::Int64(v) => json!({"Int64": v}),
            ScalarValue::UInt8(v) => json!({"UInt8": v}),
            ScalarValue::UInt16(v) => json!({"UInt16": v}),
            ScalarValue::UInt32(v) => json!({"UInt32": v}),
            ScalarValue::UInt64(v) => json!({"UInt64": v}),
            ScalarValue::Float32(v) => json!({"Float32": v}),
            ScalarValue::Float64(v) => json!({"Float64": v}),
            ScalarValue::Utf8(v) => json!({"Utf8": v}),
            ScalarValue::LargeUtf8(v) => json!({"LargeUtf8": v}),
            ScalarValue::Binary(v) => json!({"Binary": v}),
            ScalarValue::LargeBinary(v) => json!({"LargeBinary": v}),
            ScalarValue::Date32(v) => json!({"Date32": v}),
            ScalarValue::Date64(v) => json!({"Date64": v}),
            ScalarValue::TimestampMicrosecond(v, tz) => json!({
                "TimestampMicrosecond": {"value": v, "tz": tz.as_ref().map(|t| t.as_ref())}
            }),
            ScalarValue::TimestampNanosecond(v, tz) => json!({
                "TimestampNanosecond": {"value": v, "tz": tz.as_ref().map(|t| t.as_ref())}
            }),
            ScalarValue::TimestampMillisecond(v, tz) => json!({
                "TimestampMillisecond": {"value": v, "tz": tz.as_ref().map(|t| t.as_ref())}
            }),
            ScalarValue::TimestampSecond(v, tz) => json!({
                "TimestampSecond": {"value": v, "tz": tz.as_ref().map(|t| t.as_ref())}
            }),
            ScalarValue::Decimal128(v, precision, scale) => json!({
                "Decimal128": {"value": v.to_string(), "precision": precision, "scale": scale}
            }),
        }
    }
}

impl Operator {
    /// Get JSON representation of operator
    fn to_json_str(self) -> &'static str {
        match self {
            Operator::Eq => "eq",
            Operator::NotEq => "neq",
            Operator::Lt => "lt",
            Operator::LtEq => "lte",
            Operator::Gt => "gt",
            Operator::GtEq => "gte",
            Operator::And => "and",
            Operator::Or => "or",
            Operator::Plus => "plus",
            Operator::Minus => "minus",
            Operator::Multiply => "multiply",
            Operator::Divide => "divide",
            Operator::Modulo => "modulo",
            Operator::StringConcat => "string_concat",
            Operator::BitwiseAnd => "bitwise_and",
            Operator::BitwiseOr => "bitwise_or",
            Operator::BitwiseXor => "bitwise_xor",
            Operator::BitwiseShiftLeft => "bitwise_shift_left",
            Operator::BitwiseShiftRight => "bitwise_shift_right",
        }
    }
}

impl fmt::Display for Expr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.to_sql())
    }
}

// Convenience functions for creating expressions
/// Create a column reference
pub fn col(name: impl Into<String>) -> Expr {
    Expr::column(name)
}

/// Create a literal value
pub fn lit<T: Into<ScalarValue>>(value: T) -> Expr {
    Expr::literal(value)
}

// Implement Into<ScalarValue> for common types
impl From<bool> for ScalarValue {
    fn from(v: bool) -> Self {
        ScalarValue::Boolean(v)
    }
}

impl From<i8> for ScalarValue {
    fn from(v: i8) -> Self {
        ScalarValue::Int8(v)
    }
}

impl From<i16> for ScalarValue {
    fn from(v: i16) -> Self {
        ScalarValue::Int16(v)
    }
}

impl From<i32> for ScalarValue {
    fn from(v: i32) -> Self {
        ScalarValue::Int32(v)
    }
}

impl From<i64> for ScalarValue {
    fn from(v: i64) -> Self {
        ScalarValue::Int64(v)
    }
}

impl From<u8> for ScalarValue {
    fn from(v: u8) -> Self {
        ScalarValue::UInt8(v)
    }
}

impl From<u16> for ScalarValue {
    fn from(v: u16) -> Self {
        ScalarValue::UInt16(v)
    }
}

impl From<u32> for ScalarValue {
    fn from(v: u32) -> Self {
        ScalarValue::UInt32(v)
    }
}

impl From<u64> for ScalarValue {
    fn from(v: u64) -> Self {
        ScalarValue::UInt64(v)
    }
}

impl From<f32> for ScalarValue {
    fn from(v: f32) -> Self {
        ScalarValue::Float32(v)
    }
}

impl From<f64> for ScalarValue {
    fn from(v: f64) -> Self {
        ScalarValue::Float64(v)
    }
}

impl From<&str> for ScalarValue {
    fn from(v: &str) -> Self {
        ScalarValue::Utf8(v.to_string())
    }
}

impl From<String> for ScalarValue {
    fn from(v: String) -> Self {
        ScalarValue::Utf8(v)
    }
}

impl From<Vec<u8>> for ScalarValue {
    fn from(v: Vec<u8>) -> Self {
        ScalarValue::Binary(v)
    }
}

/// Result of attempting to push down a filter
#[derive(Debug, Clone, PartialEq)]
pub enum FilterPushdownResult {
    /// Filter was fully pushed down to the native reader
    Pushed,
    /// Filter was partially pushed down; remaining filter must be applied post-read
    Partial {
        /// The portion of the filter that was pushed down
        pushed: Option<Box<Expr>>,
        /// The portion that must be applied after reading
        remaining: Box<Expr>,
    },
    /// Filter could not be pushed down at all
    NotPushed(Box<Expr>),
}

impl FilterPushdownResult {
    /// Check if filter was fully pushed
    pub fn is_pushed(&self) -> bool {
        matches!(self, FilterPushdownResult::Pushed)
    }

    /// Check if any part of the filter was pushed
    pub fn any_pushed(&self) -> bool {
        matches!(
            self,
            FilterPushdownResult::Pushed | FilterPushdownResult::Partial { .. }
        )
    }

    /// Get the remaining filter that must be applied post-read
    pub fn remaining(&self) -> Option<&Expr> {
        match self {
            FilterPushdownResult::Pushed => None,
            FilterPushdownResult::Partial { remaining, .. } => Some(remaining),
            FilterPushdownResult::NotPushed(expr) => Some(expr),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_simple_comparison() {
        let expr = col("age").gt(lit(30));
        assert_eq!(expr.to_sql(), "(\"age\" > 30)");
    }

    #[test]
    fn test_compound_expression() {
        let expr = col("age").gt(lit(30)).and(col("status").eq(lit("active")));
        assert_eq!(
            expr.to_sql(),
            "((\"age\" > 30) AND (\"status\" = 'active'))"
        );
    }

    #[test]
    fn test_in_list() {
        let expr = col("category").in_list(vec![lit("A"), lit("B"), lit("C")]);
        assert_eq!(expr.to_sql(), "(\"category\" IN ('A', 'B', 'C'))");
    }

    #[test]
    fn test_between() {
        let expr = col("value").between(lit(10), lit(100));
        assert_eq!(expr.to_sql(), "(\"value\" BETWEEN 10 AND 100)");
    }

    #[test]
    fn test_like() {
        let expr = col("name").like("John%");
        assert_eq!(expr.to_sql(), "(\"name\" LIKE 'John%')");
    }

    #[test]
    fn test_is_null() {
        let expr = col("optional_field").is_null();
        assert_eq!(expr.to_sql(), "(\"optional_field\" IS NULL)");
    }

    #[test]
    fn test_not() {
        let expr = col("active").eq(lit(true)).not();
        assert_eq!(expr.to_sql(), "(NOT (\"active\" = true))");
    }

    #[test]
    fn test_collect_columns() {
        let expr = col("a")
            .gt(lit(10))
            .and(col("b").lt(lit(20)))
            .or(col("a").eq(col("c")));

        let cols = expr.columns();
        assert!(cols.contains(&"a".to_string()));
        assert!(cols.contains(&"b".to_string()));
        assert!(cols.contains(&"c".to_string()));
    }

    #[test]
    fn test_filter_pushdown_result() {
        let pushed = FilterPushdownResult::Pushed;
        assert!(pushed.is_pushed());
        assert!(pushed.any_pushed());
        assert!(pushed.remaining().is_none());

        let not_pushed = FilterPushdownResult::NotPushed(Box::new(col("x").eq(lit(1))));
        assert!(!not_pushed.is_pushed());
        assert!(!not_pushed.any_pushed());
        assert!(not_pushed.remaining().is_some());
    }

    #[test]
    fn test_json_column() {
        let json = r#"{"column": "age"}"#;
        let expr = Expr::from_json(json).unwrap();
        assert_eq!(expr, col("age"));
    }

    #[test]
    fn test_json_literal() {
        let json = r#"{"literal": {"Int64": 30}}"#;
        let expr = Expr::from_json(json).unwrap();
        assert_eq!(expr, lit(30i64));
    }

    #[test]
    fn test_json_binary_expr() {
        let json =
            r#"{"op": "gt", "left": {"column": "age"}, "right": {"literal": {"Int64": 30}}}"#;
        let expr = Expr::from_json(json).unwrap();
        assert_eq!(expr, col("age").gt(lit(30i64)));
    }

    #[test]
    fn test_json_complex_expr() {
        let json = r#"{"op": "and", "left": {"op": "gt", "left": {"column": "age"}, "right": {"literal": {"Int64": 18}}}, "right": {"op": "eq", "left": {"column": "status"}, "right": {"literal": {"Utf8": "active"}}}}"#;
        let expr = Expr::from_json(json).unwrap();
        let expected = col("age")
            .gt(lit(18i64))
            .and(col("status").eq(lit("active")));
        assert_eq!(expr, expected);
    }

    #[test]
    fn test_json_roundtrip() {
        let original = col("age")
            .gt(lit(30i64))
            .and(col("status").eq(lit("active")));
        let json = original.to_json();
        let parsed = Expr::from_json(&json).unwrap();
        assert_eq!(original, parsed);
    }

    #[test]
    fn test_json_is_null() {
        let json = r#"{"is_null": {"column": "field"}}"#;
        let expr = Expr::from_json(json).unwrap();
        assert_eq!(expr, col("field").is_null());
    }

    #[test]
    fn test_json_not() {
        let json = r#"{"not": {"column": "active"}}"#;
        let expr = Expr::from_json(json).unwrap();
        assert_eq!(expr, Expr::Not(Box::new(col("active"))));
    }
}
