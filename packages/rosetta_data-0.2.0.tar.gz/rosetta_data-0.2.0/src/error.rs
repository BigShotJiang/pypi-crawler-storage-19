// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Error types for Rosetta

use std::path::PathBuf;
use thiserror::Error;

/// Result type for Rosetta operations
pub type Result<T> = std::result::Result<T, Error>;

/// Errors that can occur during Rosetta operations
#[derive(Error, Debug)]
pub enum Error {
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("Arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),

    #[error("Parquet error: {0}")]
    Parquet(#[from] parquet::errors::ParquetError),

    #[error("Unknown file format for path: {path}")]
    UnknownFormat { path: PathBuf },

    #[error("Format detection failed: could not read magic bytes from {path}")]
    FormatDetectionFailed { path: PathBuf },

    #[error("Unsupported format: {format} (enable the '{feature}' feature)")]
    UnsupportedFormat { format: String, feature: String },

    #[error("Invalid file: {message}")]
    InvalidFile { message: String },

    #[error("Column not found: {column}")]
    ColumnNotFound { column: String },

    #[error("Object store error: {0}")]
    ObjectStore(#[from] object_store::Error),

    #[error("URL parse error: {0}")]
    UrlParse(#[from] url::ParseError),

    #[cfg(feature = "wasm-runtime")]
    #[error("WASM runtime error: {message}")]
    WasmRuntime { message: String },

    #[error("Configuration error: {message}")]
    Config { message: String },

    #[error("{0}")]
    Other(String),
}

impl Error {
    pub fn unknown_format(path: impl Into<PathBuf>) -> Self {
        Self::UnknownFormat { path: path.into() }
    }

    pub fn unsupported_format(format: impl Into<String>, feature: impl Into<String>) -> Self {
        Self::UnsupportedFormat {
            format: format.into(),
            feature: feature.into(),
        }
    }

    pub fn invalid_file(message: impl Into<String>) -> Self {
        Self::InvalidFile {
            message: message.into(),
        }
    }

    pub fn column_not_found(column: impl Into<String>) -> Self {
        Self::ColumnNotFound {
            column: column.into(),
        }
    }

    pub fn io_error(message: impl Into<String>) -> Self {
        Self::Other(message.into())
    }

    pub fn config(message: impl Into<String>) -> Self {
        Self::Config {
            message: message.into(),
        }
    }
}
