// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! WASM runtime for F3-style self-describing columnar files
//!
//! This module provides a sandboxed WASM runtime for executing embedded
//! decoders found in F3 files. The F3 format (from CMU/Tsinghua SIGMOD 2026)
//! embeds WASM decoders alongside encoded data, enabling forward compatibility
//! without reader updates.
//!
//! # Architecture
//!
//! ```text
//! ┌─────────────────────────────────────────────────────────┐
//! │                     F3 File                              │
//! │  ┌──────────┬────────────────┬──────────────┬────────┐  │
//! │  │  Header  │  WASM Decoders │  Encoded Data │ Footer │  │
//! │  │  (magic) │  (per-column)  │  (columns)    │(schema)│  │
//! │  └──────────┴────────────────┴──────────────┴────────┘  │
//! └─────────────────────────────────────────────────────────┘
//!                        │
//!                        ▼
//! ┌─────────────────────────────────────────────────────────┐
//! │                  WASM Runtime                            │
//! │  ┌─────────────┐  ┌──────────────┐  ┌────────────────┐  │
//! │  │   Engine    │  │   Instance   │  │    Sandbox     │  │
//! │  │  (compile)  │  │    Pool      │  │   (limits)     │  │
//! │  └─────────────┘  └──────────────┘  └────────────────┘  │
//! └─────────────────────────────────────────────────────────┘
//!                        │
//!                        ▼
//!                  Arrow RecordBatch
//! ```
//!
//! # Security
//!
//! All WASM execution is sandboxed with:
//! - Memory limits (default 16MB)
//! - Execution time limits (default 5s)
//! - Output size validation
//! - Optional encoder allowlists with checksum verification
//!
//! # Example
//!
//! ```rust,ignore
//! use rosetta::wasm::{WasmRuntime, SandboxConfig};
//!
//! let config = SandboxConfig::default();
//! let runtime = WasmRuntime::new(config)?;
//!
//! // Decode F3 column data
//! let decoded = runtime.decode(&wasm_bytes, &encoded_data, &metadata)?;
//! ```

mod decoder;
mod pool;
mod runtime;
mod sandbox;

pub use decoder::{Decoder, DecoderApi, DecoderId, DecoderState, OutputType};
pub use pool::InstancePool;
pub use runtime::WasmRuntime;
pub use sandbox::{SandboxConfig, SandboxLimits};

use crate::Error;

/// Error helper for WASM runtime errors
impl Error {
    pub fn wasm_runtime(message: impl Into<String>) -> Self {
        Self::WasmRuntime {
            message: message.into(),
        }
    }
}
