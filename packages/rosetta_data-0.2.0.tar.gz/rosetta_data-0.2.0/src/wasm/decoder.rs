// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Decoder interface for F3 WASM decoders
//!
//! Defines the standard API that all F3-embedded decoders must implement.
//! Based on the F3 paper (SIGMOD 2026) decoder interface specification.

use crate::Result;

/// Unique identifier for a decoder implementation
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct DecoderId {
    /// Encoder/decoder name (e.g., "delta_binary_packed", "fsst")
    pub name: String,
    /// Version of the encoder
    pub version: u32,
}

impl DecoderId {
    pub fn new(name: impl Into<String>, version: u32) -> Self {
        Self {
            name: name.into(),
            version,
        }
    }

    /// Parse from F3 header format: "name:version"
    pub fn parse(s: &str) -> Option<Self> {
        let (name, version_str) = s.rsplit_once(':')?;
        let version = version_str.parse().ok()?;
        Some(Self::new(name, version))
    }
}

impl std::fmt::Display for DecoderId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}:v{}", self.name, self.version)
    }
}

/// State maintained by a decoder across decode calls
#[derive(Debug, Clone)]
pub struct DecoderState {
    /// Decoder-specific state bytes
    pub state_bytes: Vec<u8>,
    /// Expected output type information
    pub output_type: OutputType,
    /// Number of values decoded so far
    pub values_decoded: u64,
}

impl DecoderState {
    pub fn new(output_type: OutputType) -> Self {
        Self {
            state_bytes: Vec::new(),
            output_type,
            values_decoded: 0,
        }
    }
}

/// Output type information for decoded data
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OutputType {
    /// Fixed-width primitive types
    Int8,
    Int16,
    Int32,
    Int64,
    UInt8,
    UInt16,
    UInt32,
    UInt64,
    Float32,
    Float64,
    /// Variable-width types
    Binary,
    Utf8,
    /// Fixed-size binary
    FixedSizeBinary(usize),
}

impl OutputType {
    /// Get the fixed size in bytes for fixed-width types
    pub fn fixed_size(&self) -> Option<usize> {
        match self {
            Self::Int8 | Self::UInt8 => Some(1),
            Self::Int16 | Self::UInt16 => Some(2),
            Self::Int32 | Self::UInt32 | Self::Float32 => Some(4),
            Self::Int64 | Self::UInt64 | Self::Float64 => Some(8),
            Self::FixedSizeBinary(n) => Some(*n),
            Self::Binary | Self::Utf8 => None,
        }
    }

    /// Convert from Arrow DataType name
    pub fn from_arrow_type(type_name: &str) -> Option<Self> {
        match type_name {
            "Int8" => Some(Self::Int8),
            "Int16" => Some(Self::Int16),
            "Int32" => Some(Self::Int32),
            "Int64" => Some(Self::Int64),
            "UInt8" => Some(Self::UInt8),
            "UInt16" => Some(Self::UInt16),
            "UInt32" => Some(Self::UInt32),
            "UInt64" => Some(Self::UInt64),
            "Float32" => Some(Self::Float32),
            "Float64" => Some(Self::Float64),
            "Binary" | "LargeBinary" => Some(Self::Binary),
            "Utf8" | "LargeUtf8" => Some(Self::Utf8),
            _ => None,
        }
    }
}

/// The standard decoder API that all F3 WASM decoders must implement
///
/// This maps to WASM exports:
/// - `decoder_init(metadata_ptr, metadata_len) -> state_ptr`
/// - `decoder_decode(state_ptr, data_ptr, data_len, out_ptr, out_len) -> decoded_len`
/// - `decoder_check(state_ptr) -> status`
/// - `decoder_free(state_ptr)`
pub trait DecoderApi {
    /// Initialize the decoder with column metadata
    ///
    /// # Arguments
    /// * `metadata` - Encoder-specific metadata (from file header)
    ///
    /// # Returns
    /// * `DecoderState` - Initialized decoder state
    fn init(&self, metadata: &[u8]) -> Result<DecoderState>;

    /// Decode a chunk of encoded data
    ///
    /// # Arguments
    /// * `state` - Decoder state from init or previous decode
    /// * `encoded` - Encoded data bytes
    ///
    /// # Returns
    /// * Tuple of (decoded bytes, updated state)
    fn decode(&self, state: &DecoderState, encoded: &[u8]) -> Result<(Vec<u8>, DecoderState)>;

    /// Check decoder state validity
    ///
    /// # Arguments
    /// * `state` - Current decoder state
    ///
    /// # Returns
    /// * `true` if state is valid, `false` otherwise
    fn check(&self, state: &DecoderState) -> Result<bool>;

    /// Get the decoder identifier
    fn id(&self) -> &DecoderId;
}

/// A compiled WASM decoder ready for execution
pub struct Decoder {
    /// Decoder identifier
    pub id: DecoderId,

    /// Compiled WASM module bytes
    pub wasm_bytes: Vec<u8>,

    /// Decoder metadata (from file)
    pub metadata: Vec<u8>,

    /// Expected output type
    pub output_type: OutputType,
}

impl Decoder {
    pub fn new(
        id: DecoderId,
        wasm_bytes: Vec<u8>,
        metadata: Vec<u8>,
        output_type: OutputType,
    ) -> Self {
        Self {
            id,
            wasm_bytes,
            metadata,
            output_type,
        }
    }
}

/// Decoder metadata as stored in F3 file headers
#[derive(Debug, Clone)]
pub struct DecoderMetadata {
    /// Decoder identifier
    pub id: DecoderId,

    /// Offset to WASM bytes in file
    pub wasm_offset: u64,

    /// Length of WASM bytes
    pub wasm_length: u64,

    /// Encoder-specific metadata
    pub encoder_metadata: Vec<u8>,

    /// Output Arrow type name
    pub output_type_name: String,

    /// Checksum of WASM bytes (for verification)
    pub checksum: Option<[u8; 32]>,
}

impl DecoderMetadata {
    /// Parse from F3 header bytes
    pub fn parse(bytes: &[u8]) -> Result<Self> {
        // MVP: Simple fixed-format parsing
        // Production: Use proper serialization (flatbuffers, protobuf, etc.)
        if bytes.len() < 32 {
            return Err(crate::Error::wasm_runtime("Decoder metadata too short"));
        }

        // Format:
        // [0..16]  - decoder name (null-padded)
        // [16..20] - version (u32 le)
        // [20..28] - wasm_offset (u64 le)
        // [28..36] - wasm_length (u64 le)
        // [36..40] - metadata_length (u32 le)
        // [40..40+metadata_length] - encoder metadata
        // Remaining: output type name (null-terminated)

        let name = std::str::from_utf8(&bytes[0..16])
            .map_err(|_| crate::Error::wasm_runtime("Invalid decoder name"))?
            .trim_end_matches('\0')
            .to_string();

        let version = u32::from_le_bytes(bytes[16..20].try_into().unwrap());
        let wasm_offset = u64::from_le_bytes(bytes[20..28].try_into().unwrap());
        let wasm_length = u64::from_le_bytes(bytes[28..36].try_into().unwrap());

        // For MVP, use defaults for optional fields
        Ok(Self {
            id: DecoderId::new(name, version),
            wasm_offset,
            wasm_length,
            encoder_metadata: Vec::new(),
            output_type_name: "Int64".to_string(),
            checksum: None,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_decoder_id_parse() {
        let id = DecoderId::parse("delta_binary_packed:1").unwrap();
        assert_eq!(id.name, "delta_binary_packed");
        assert_eq!(id.version, 1);
    }

    #[test]
    fn test_decoder_id_display() {
        let id = DecoderId::new("fsst", 2);
        assert_eq!(format!("{}", id), "fsst:v2");
    }

    #[test]
    fn test_output_type_fixed_size() {
        assert_eq!(OutputType::Int32.fixed_size(), Some(4));
        assert_eq!(OutputType::Int64.fixed_size(), Some(8));
        assert_eq!(OutputType::Utf8.fixed_size(), None);
        assert_eq!(OutputType::FixedSizeBinary(16).fixed_size(), Some(16));
    }

    #[test]
    fn test_output_type_from_arrow() {
        assert_eq!(
            OutputType::from_arrow_type("Int64"),
            Some(OutputType::Int64)
        );
        assert_eq!(OutputType::from_arrow_type("Utf8"), Some(OutputType::Utf8));
        assert_eq!(OutputType::from_arrow_type("Unknown"), None);
    }
}
