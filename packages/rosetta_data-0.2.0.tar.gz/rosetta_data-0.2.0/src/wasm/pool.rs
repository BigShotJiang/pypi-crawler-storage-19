// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Instance pool for reusing WASM instances
//!
//! WASM compilation is expensive. This module provides instance pooling
//! to reuse compiled modules and reduce overhead for repeated decodes.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use wasmtime::{Engine, Instance, Linker, Module, Store};

use super::decoder::DecoderId;
use super::sandbox::SandboxConfig;
use crate::{Error, Result};

/// Host state for WASM instances
#[derive(Default)]
pub struct HostState {
    /// Allocated memory regions for data transfer
    pub memory_regions: Vec<Vec<u8>>,
}

/// A pooled WASM instance ready for decode operations
pub struct PooledInstance {
    /// The WASM store (owns instance state)
    pub store: Store<HostState>,
    /// The WASM instance
    pub instance: Instance,
    /// Decoder ID this instance is for
    pub decoder_id: DecoderId,
}

/// Pool of compiled modules and instances for efficient reuse
pub struct InstancePool {
    /// Wasmtime engine (shared across all instances)
    engine: Engine,
    /// Linker for creating instances
    linker: Linker<HostState>,
    /// Cached compiled modules by decoder ID
    modules: Mutex<HashMap<DecoderId, Arc<Module>>>,
    /// Pool of available instances
    available: Mutex<Vec<PooledInstance>>,
    /// Maximum pool size
    max_size: usize,
    /// Sandbox configuration
    config: SandboxConfig,
}

impl InstancePool {
    /// Create a new instance pool
    pub fn new(config: SandboxConfig) -> Result<Self> {
        let mut engine_config = wasmtime::Config::new();

        // Configure based on sandbox settings
        if config.enable_jit {
            engine_config.cranelift_opt_level(wasmtime::OptLevel::Speed);
        } else {
            engine_config.cranelift_opt_level(wasmtime::OptLevel::None);
        }

        // Enable fuel metering for execution limits
        engine_config.consume_fuel(true);

        // Memory limits
        engine_config.max_wasm_stack(config.limits.max_memory_bytes / 4);

        let engine =
            Engine::new(&engine_config).map_err(|e| Error::wasm_runtime(format!("{}", e)))?;

        let mut linker = Linker::new(&engine);

        // Add host functions that decoders can call
        Self::add_host_functions(&mut linker)?;

        Ok(Self {
            engine,
            linker,
            modules: Mutex::new(HashMap::new()),
            available: Mutex::new(Vec::new()),
            max_size: config.pool_size,
            config,
        })
    }

    /// Add host functions available to WASM decoders
    fn add_host_functions(linker: &mut Linker<HostState>) -> Result<()> {
        // Add logging function for debugging
        linker
            .func_wrap(
                "env",
                "log_debug",
                |_caller: wasmtime::Caller<'_, HostState>, ptr: i32, len: i32| {
                    tracing::debug!(ptr, len, "WASM debug log");
                },
            )
            .map_err(|e| Error::wasm_runtime(format!("Failed to add log_debug: {}", e)))?;

        // Add abort function for error handling
        linker
            .func_wrap(
                "env",
                "abort",
                |_caller: wasmtime::Caller<'_, HostState>, code: i32| {
                    tracing::error!(code, "WASM abort called");
                },
            )
            .map_err(|e| Error::wasm_runtime(format!("Failed to add abort: {}", e)))?;

        Ok(())
    }

    /// Get or compile a module for the given decoder
    pub fn get_module(&self, decoder_id: &DecoderId, wasm_bytes: &[u8]) -> Result<Arc<Module>> {
        let mut modules = self.modules.lock().unwrap();

        if let Some(module) = modules.get(decoder_id) {
            return Ok(module.clone());
        }

        // Compile new module
        let module = Module::new(&self.engine, wasm_bytes)
            .map_err(|e| Error::wasm_runtime(format!("Failed to compile WASM: {}", e)))?;

        let module = Arc::new(module);

        if self.config.cache_modules {
            modules.insert(decoder_id.clone(), module.clone());
        }

        Ok(module)
    }

    /// Acquire an instance for decoding
    pub fn acquire(&self, decoder_id: &DecoderId, wasm_bytes: &[u8]) -> Result<PooledInstance> {
        // Try to get from pool first
        {
            let mut available = self.available.lock().unwrap();
            if let Some(pos) = available.iter().position(|i| &i.decoder_id == decoder_id) {
                return Ok(available.remove(pos));
            }
        }

        // Create new instance
        self.create_instance(decoder_id, wasm_bytes)
    }

    /// Release an instance back to the pool
    pub fn release(&self, instance: PooledInstance) {
        let mut available = self.available.lock().unwrap();
        if available.len() < self.max_size {
            available.push(instance);
        }
        // Otherwise, drop the instance
    }

    /// Create a new WASM instance
    fn create_instance(&self, decoder_id: &DecoderId, wasm_bytes: &[u8]) -> Result<PooledInstance> {
        let module = self.get_module(decoder_id, wasm_bytes)?;

        let mut store = Store::new(&self.engine, HostState::default());

        // Set fuel limit
        store
            .set_fuel(self.config.limits.max_fuel)
            .map_err(|e| Error::wasm_runtime(format!("Failed to set fuel: {}", e)))?;

        let instance = self
            .linker
            .instantiate(&mut store, &module)
            .map_err(|e| Error::wasm_runtime(format!("Failed to instantiate: {}", e)))?;

        Ok(PooledInstance {
            store,
            instance,
            decoder_id: decoder_id.clone(),
        })
    }

    /// Get pool statistics
    pub fn stats(&self) -> PoolStats {
        let modules = self.modules.lock().unwrap();
        let available = self.available.lock().unwrap();
        PoolStats {
            cached_modules: modules.len(),
            available_instances: available.len(),
            max_size: self.max_size,
        }
    }

    /// Clear all cached modules and instances
    pub fn clear(&self) {
        self.modules.lock().unwrap().clear();
        self.available.lock().unwrap().clear();
    }
}

/// Statistics about the instance pool
#[derive(Debug, Clone)]
pub struct PoolStats {
    /// Number of cached compiled modules
    pub cached_modules: usize,
    /// Number of instances available in pool
    pub available_instances: usize,
    /// Maximum pool size
    pub max_size: usize,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_pool_creation() {
        let config = SandboxConfig::testing();
        let pool = InstancePool::new(config).unwrap();
        let stats = pool.stats();
        assert_eq!(stats.cached_modules, 0);
        assert_eq!(stats.available_instances, 0);
    }
}
