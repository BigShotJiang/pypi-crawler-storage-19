// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Sandbox configuration for secure WASM execution
//!
//! Defines resource limits and security policies for running untrusted
//! WASM decoders from F3 files.

use std::collections::{HashMap, HashSet};
use std::time::Duration;

/// Security limits for WASM execution
#[derive(Debug, Clone)]
pub struct SandboxLimits {
    /// Maximum memory a WASM instance can allocate (bytes)
    pub max_memory_bytes: usize,

    /// Maximum execution time for a single decode operation
    pub max_execution_time: Duration,

    /// Maximum output size from a decode operation (bytes)
    pub max_output_bytes: usize,

    /// Maximum number of WASM function calls per decode
    pub max_fuel: u64,
}

impl Default for SandboxLimits {
    fn default() -> Self {
        Self {
            max_memory_bytes: 16 * 1024 * 1024, // 16 MB
            max_execution_time: Duration::from_secs(5),
            max_output_bytes: 64 * 1024 * 1024, // 64 MB (large for wide tables)
            max_fuel: 100_000_000,              // ~100M instructions
        }
    }
}

impl SandboxLimits {
    /// Create limits suitable for production workloads
    pub fn production() -> Self {
        Self::default()
    }

    /// Create permissive limits for testing
    pub fn testing() -> Self {
        Self {
            max_memory_bytes: 256 * 1024 * 1024, // 256 MB
            max_execution_time: Duration::from_secs(30),
            max_output_bytes: 256 * 1024 * 1024,
            max_fuel: 1_000_000_000,
        }
    }

    /// Create restrictive limits for untrusted decoders
    pub fn restrictive() -> Self {
        Self {
            max_memory_bytes: 4 * 1024 * 1024, // 4 MB
            max_execution_time: Duration::from_secs(1),
            max_output_bytes: 16 * 1024 * 1024,
            max_fuel: 10_000_000,
        }
    }

    /// Set maximum memory
    pub fn with_max_memory(mut self, bytes: usize) -> Self {
        self.max_memory_bytes = bytes;
        self
    }

    /// Set maximum execution time
    pub fn with_max_time(mut self, duration: Duration) -> Self {
        self.max_execution_time = duration;
        self
    }

    /// Set maximum output size
    pub fn with_max_output(mut self, bytes: usize) -> Self {
        self.max_output_bytes = bytes;
        self
    }
}

/// SHA-256 checksum for encoder verification
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct EncoderChecksum(pub [u8; 32]);

impl EncoderChecksum {
    /// Create from hex string
    pub fn from_hex(hex: &str) -> Option<Self> {
        if hex.len() != 64 {
            return None;
        }
        let mut bytes = [0u8; 32];
        for (i, chunk) in hex.as_bytes().chunks(2).enumerate() {
            let hex_byte = std::str::from_utf8(chunk).ok()?;
            bytes[i] = u8::from_str_radix(hex_byte, 16).ok()?;
        }
        Some(Self(bytes))
    }

    /// Create from bytes
    pub fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }

    /// Compute checksum of WASM bytes
    pub fn compute(wasm_bytes: &[u8]) -> Self {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        // Simple hash for MVP - production should use SHA-256
        let mut hasher = DefaultHasher::new();
        wasm_bytes.hash(&mut hasher);
        let hash = hasher.finish();

        let mut bytes = [0u8; 32];
        bytes[0..8].copy_from_slice(&hash.to_le_bytes());
        // Repeat for more bytes (MVP only - use proper SHA-256 in production)
        bytes[8..16].copy_from_slice(&hash.to_be_bytes());
        Self(bytes)
    }
}

/// Encoder ID used to identify decoder implementations
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct EncoderId(pub String);

impl EncoderId {
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }
}

impl std::fmt::Display for EncoderId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

/// Allowlist policy for which encoders can be executed
#[derive(Debug, Clone)]
pub enum AllowlistPolicy {
    /// Allow all encoders (not recommended for production)
    AllowAll,

    /// Only allow encoders in the allowlist
    Strict(HashSet<EncoderId>),

    /// Allow encoders in allowlist OR with matching checksums
    ChecksumVerified {
        known_encoders: HashSet<EncoderId>,
        checksums: HashMap<EncoderId, EncoderChecksum>,
    },
}

impl Default for AllowlistPolicy {
    fn default() -> Self {
        // Default to AllowAll for MVP - production should use Strict or ChecksumVerified
        Self::AllowAll
    }
}

impl AllowlistPolicy {
    /// Create a strict allowlist
    pub fn strict(encoders: impl IntoIterator<Item = EncoderId>) -> Self {
        Self::Strict(encoders.into_iter().collect())
    }

    /// Check if an encoder is allowed
    pub fn is_allowed(&self, encoder_id: &EncoderId, checksum: Option<&EncoderChecksum>) -> bool {
        match self {
            Self::AllowAll => true,
            Self::Strict(allowed) => allowed.contains(encoder_id),
            Self::ChecksumVerified {
                known_encoders,
                checksums,
            } => {
                if known_encoders.contains(encoder_id) {
                    return true;
                }
                // Check if checksum matches known good checksum
                if let (Some(actual), Some(expected)) = (checksum, checksums.get(encoder_id)) {
                    return actual == expected;
                }
                false
            }
        }
    }
}

/// Complete sandbox configuration
#[derive(Debug, Clone)]
pub struct SandboxConfig {
    /// Resource limits
    pub limits: SandboxLimits,

    /// Encoder allowlist policy
    pub allowlist: AllowlistPolicy,

    /// Enable JIT compilation (faster but uses more memory)
    pub enable_jit: bool,

    /// Cache compiled modules
    pub cache_modules: bool,

    /// Number of instances to keep in pool
    pub pool_size: usize,
}

impl Default for SandboxConfig {
    fn default() -> Self {
        Self {
            limits: SandboxLimits::default(),
            allowlist: AllowlistPolicy::default(),
            enable_jit: true,
            cache_modules: true,
            pool_size: 4,
        }
    }
}

impl SandboxConfig {
    /// Create production-ready configuration
    pub fn production() -> Self {
        Self {
            limits: SandboxLimits::production(),
            allowlist: AllowlistPolicy::default(), // Should be Strict in real production
            enable_jit: true,
            cache_modules: true,
            pool_size: 8,
        }
    }

    /// Create testing configuration
    pub fn testing() -> Self {
        Self {
            limits: SandboxLimits::testing(),
            allowlist: AllowlistPolicy::AllowAll,
            enable_jit: false, // Faster compilation for tests
            cache_modules: false,
            pool_size: 2,
        }
    }

    /// Set limits
    pub fn with_limits(mut self, limits: SandboxLimits) -> Self {
        self.limits = limits;
        self
    }

    /// Set allowlist policy
    pub fn with_allowlist(mut self, policy: AllowlistPolicy) -> Self {
        self.allowlist = policy;
        self
    }

    /// Set pool size
    pub fn with_pool_size(mut self, size: usize) -> Self {
        self.pool_size = size;
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sandbox_limits_defaults() {
        let limits = SandboxLimits::default();
        assert_eq!(limits.max_memory_bytes, 16 * 1024 * 1024);
        assert_eq!(limits.max_execution_time, Duration::from_secs(5));
    }

    #[test]
    fn test_encoder_checksum() {
        let data = b"test wasm module bytes";
        let checksum = EncoderChecksum::compute(data);
        assert_eq!(checksum.0.len(), 32);
    }

    #[test]
    fn test_allowlist_policy_allow_all() {
        let policy = AllowlistPolicy::AllowAll;
        let encoder = EncoderId::new("test_encoder");
        assert!(policy.is_allowed(&encoder, None));
    }

    #[test]
    fn test_allowlist_policy_strict() {
        let allowed = EncoderId::new("allowed_encoder");
        let denied = EncoderId::new("denied_encoder");
        let policy = AllowlistPolicy::strict(vec![allowed.clone()]);

        assert!(policy.is_allowed(&allowed, None));
        assert!(!policy.is_allowed(&denied, None));
    }
}
