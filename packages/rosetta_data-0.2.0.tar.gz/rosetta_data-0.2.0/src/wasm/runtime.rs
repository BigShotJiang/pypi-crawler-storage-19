// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! WASM runtime for executing F3 decoders
//!
//! This is the main entry point for WASM decoder execution. It manages
//! the Wasmtime engine, instance pooling, and decoder execution.

use std::sync::Arc;

use wasmtime::{Memory, TypedFunc};

use super::decoder::{Decoder, DecoderApi, DecoderId, DecoderState, OutputType};
use super::pool::InstancePool;
use super::sandbox::{EncoderChecksum, SandboxConfig};
use crate::{Error, Result};

/// Main WASM runtime for F3 decoder execution
pub struct WasmRuntime {
    /// Instance pool for efficient reuse
    pool: Arc<InstancePool>,
    /// Sandbox configuration
    config: SandboxConfig,
}

impl WasmRuntime {
    /// Create a new WASM runtime with the given configuration
    pub fn new(config: SandboxConfig) -> Result<Self> {
        let pool = Arc::new(InstancePool::new(config.clone())?);
        Ok(Self { pool, config })
    }

    /// Create with default production configuration
    pub fn production() -> Result<Self> {
        Self::new(SandboxConfig::production())
    }

    /// Create with testing configuration
    pub fn testing() -> Result<Self> {
        Self::new(SandboxConfig::testing())
    }

    /// Load a decoder from WASM bytes
    pub fn load_decoder(
        &self,
        id: DecoderId,
        wasm_bytes: Vec<u8>,
        metadata: Vec<u8>,
        output_type: OutputType,
    ) -> Result<WasmDecoder> {
        // Verify against allowlist
        let checksum = EncoderChecksum::compute(&wasm_bytes);
        let encoder_id = super::sandbox::EncoderId::new(&id.name);

        if !self
            .config
            .allowlist
            .is_allowed(&encoder_id, Some(&checksum))
        {
            return Err(Error::wasm_runtime(format!(
                "Decoder '{}' not in allowlist",
                id
            )));
        }

        let decoder = Decoder::new(id, wasm_bytes, metadata, output_type);
        Ok(WasmDecoder {
            decoder,
            runtime: self.pool.clone(),
        })
    }

    /// Decode data using a one-shot decoder (no instance reuse)
    pub fn decode_oneshot(
        &self,
        decoder_id: &DecoderId,
        wasm_bytes: &[u8],
        metadata: &[u8],
        encoded: &[u8],
    ) -> Result<Vec<u8>> {
        // Verify against allowlist
        let checksum = EncoderChecksum::compute(wasm_bytes);
        let encoder_id = super::sandbox::EncoderId::new(&decoder_id.name);

        if !self
            .config
            .allowlist
            .is_allowed(&encoder_id, Some(&checksum))
        {
            return Err(Error::wasm_runtime(format!(
                "Decoder '{}' not in allowlist",
                decoder_id
            )));
        }

        // Acquire instance
        let mut instance = self.pool.acquire(decoder_id, wasm_bytes)?;

        // Get WASM memory
        let memory = instance
            .instance
            .get_memory(&mut instance.store, "memory")
            .ok_or_else(|| Error::wasm_runtime("No memory export"))?;

        // Call init
        let init_fn: TypedFunc<(i32, i32), i32> = instance
            .instance
            .get_typed_func(&mut instance.store, "decoder_init")
            .map_err(|e| Error::wasm_runtime(format!("No decoder_init export: {}", e)))?;

        let state_ptr = self.call_init(&mut instance, &memory, init_fn, metadata)?;

        // Call decode
        let decode_fn: TypedFunc<(i32, i32, i32, i32, i32), i32> = instance
            .instance
            .get_typed_func(&mut instance.store, "decoder_decode")
            .map_err(|e| Error::wasm_runtime(format!("No decoder_decode export: {}", e)))?;

        let result = self.call_decode(&mut instance, &memory, decode_fn, state_ptr, encoded)?;

        // Release instance back to pool
        self.pool.release(instance);

        Ok(result)
    }

    /// Call the decoder_init function
    fn call_init(
        &self,
        instance: &mut super::pool::PooledInstance,
        memory: &Memory,
        init_fn: TypedFunc<(i32, i32), i32>,
        metadata: &[u8],
    ) -> Result<i32> {
        // Allocate and write metadata to WASM memory
        let metadata_ptr = self.write_to_memory(instance, memory, metadata)?;

        // Call init
        let state_ptr = init_fn
            .call(&mut instance.store, (metadata_ptr, metadata.len() as i32))
            .map_err(|e| Error::wasm_runtime(format!("decoder_init failed: {}", e)))?;

        Ok(state_ptr)
    }

    /// Call the decoder_decode function
    fn call_decode(
        &self,
        instance: &mut super::pool::PooledInstance,
        memory: &Memory,
        decode_fn: TypedFunc<(i32, i32, i32, i32, i32), i32>,
        state_ptr: i32,
        encoded: &[u8],
    ) -> Result<Vec<u8>> {
        // Write encoded data to memory
        let data_ptr = self.write_to_memory(instance, memory, encoded)?;

        // Allocate output buffer
        let max_output = self.config.limits.max_output_bytes;
        let out_ptr = self.allocate_memory(instance, memory, max_output)?;

        // Call decode
        let decoded_len = decode_fn
            .call(
                &mut instance.store,
                (
                    state_ptr,
                    data_ptr,
                    encoded.len() as i32,
                    out_ptr,
                    max_output as i32,
                ),
            )
            .map_err(|e| Error::wasm_runtime(format!("decoder_decode failed: {}", e)))?;

        if decoded_len < 0 {
            return Err(Error::wasm_runtime(format!(
                "Decoder returned error code: {}",
                decoded_len
            )));
        }

        // Read output from memory
        let result = self.read_from_memory(instance, memory, out_ptr, decoded_len as usize)?;

        Ok(result)
    }

    /// Write data to WASM memory
    fn write_to_memory(
        &self,
        instance: &mut super::pool::PooledInstance,
        memory: &Memory,
        data: &[u8],
    ) -> Result<i32> {
        // Get malloc if available, otherwise use simple bump allocation
        let ptr = if let Ok(malloc) = instance
            .instance
            .get_typed_func::<i32, i32>(&mut instance.store, "malloc")
        {
            malloc
                .call(&mut instance.store, data.len() as i32)
                .map_err(|e| Error::wasm_runtime(format!("malloc failed: {}", e)))?
        } else {
            // Simple allocation from end of current memory
            let current_size = memory.data_size(&instance.store);
            let needed = current_size + data.len();
            let pages_needed = (needed / 65536) + 1;
            memory
                .grow(&mut instance.store, pages_needed as u64)
                .map_err(|e| Error::wasm_runtime(format!("Memory grow failed: {}", e)))?;
            current_size as i32
        };

        // Write data
        memory
            .write(&mut instance.store, ptr as usize, data)
            .map_err(|e| Error::wasm_runtime(format!("Memory write failed: {}", e)))?;

        Ok(ptr)
    }

    /// Allocate memory in WASM
    fn allocate_memory(
        &self,
        instance: &mut super::pool::PooledInstance,
        memory: &Memory,
        size: usize,
    ) -> Result<i32> {
        if let Ok(malloc) = instance
            .instance
            .get_typed_func::<i32, i32>(&mut instance.store, "malloc")
        {
            malloc
                .call(&mut instance.store, size as i32)
                .map_err(|e| Error::wasm_runtime(format!("malloc failed: {}", e)))
        } else {
            let current_size = memory.data_size(&instance.store);
            let needed = current_size + size;
            let pages_needed = (needed / 65536) + 1;
            memory
                .grow(&mut instance.store, pages_needed as u64)
                .map_err(|e| Error::wasm_runtime(format!("Memory grow failed: {}", e)))?;
            Ok(current_size as i32)
        }
    }

    /// Read data from WASM memory
    fn read_from_memory(
        &self,
        instance: &mut super::pool::PooledInstance,
        memory: &Memory,
        ptr: i32,
        len: usize,
    ) -> Result<Vec<u8>> {
        let mut buffer = vec![0u8; len];
        memory
            .read(&instance.store, ptr as usize, &mut buffer)
            .map_err(|e| Error::wasm_runtime(format!("Memory read failed: {}", e)))?;
        Ok(buffer)
    }

    /// Get runtime statistics
    pub fn stats(&self) -> RuntimeStats {
        let pool_stats = self.pool.stats();
        RuntimeStats {
            pool_stats,
            allowlist_policy: format!("{:?}", self.config.allowlist),
        }
    }
}

/// A loaded WASM decoder ready for repeated use
pub struct WasmDecoder {
    decoder: Decoder,
    runtime: Arc<InstancePool>,
}

impl DecoderApi for WasmDecoder {
    fn init(&self, metadata: &[u8]) -> Result<DecoderState> {
        // Initialize state with output type
        let mut state = DecoderState::new(self.decoder.output_type.clone());

        // Store metadata in state for decode calls
        state.state_bytes = metadata.to_vec();

        Ok(state)
    }

    fn decode(&self, state: &DecoderState, encoded: &[u8]) -> Result<(Vec<u8>, DecoderState)> {
        let mut instance = self
            .runtime
            .acquire(&self.decoder.id, &self.decoder.wasm_bytes)?;

        // Get memory and functions
        let memory = instance
            .instance
            .get_memory(&mut instance.store, "memory")
            .ok_or_else(|| Error::wasm_runtime("No memory export"))?;

        // Call init with stored metadata
        let init_fn: TypedFunc<(i32, i32), i32> = instance
            .instance
            .get_typed_func(&mut instance.store, "decoder_init")
            .map_err(|e| Error::wasm_runtime(format!("No decoder_init: {}", e)))?;

        let metadata_ptr = write_bytes_to_memory(&mut instance, &memory, &state.state_bytes)?;
        let state_ptr = init_fn
            .call(
                &mut instance.store,
                (metadata_ptr, state.state_bytes.len() as i32),
            )
            .map_err(|e| Error::wasm_runtime(format!("init failed: {}", e)))?;

        // Call decode
        let decode_fn: TypedFunc<(i32, i32, i32, i32, i32), i32> = instance
            .instance
            .get_typed_func(&mut instance.store, "decoder_decode")
            .map_err(|e| Error::wasm_runtime(format!("No decoder_decode: {}", e)))?;

        let data_ptr = write_bytes_to_memory(&mut instance, &memory, encoded)?;
        let max_output = 64 * 1024 * 1024; // 64MB
        let out_ptr = allocate_in_memory(&mut instance, &memory, max_output)?;

        let decoded_len = decode_fn
            .call(
                &mut instance.store,
                (
                    state_ptr,
                    data_ptr,
                    encoded.len() as i32,
                    out_ptr,
                    max_output as i32,
                ),
            )
            .map_err(|e| Error::wasm_runtime(format!("decode failed: {}", e)))?;

        if decoded_len < 0 {
            return Err(Error::wasm_runtime(format!(
                "Decode error: {}",
                decoded_len
            )));
        }

        // Read result
        let mut result = vec![0u8; decoded_len as usize];
        memory
            .read(&instance.store, out_ptr as usize, &mut result)
            .map_err(|e| Error::wasm_runtime(format!("Read failed: {}", e)))?;

        // Update state
        let mut new_state = state.clone();
        new_state.values_decoded +=
            (decoded_len as u64) / state.output_type.fixed_size().unwrap_or(1) as u64;

        self.runtime.release(instance);

        Ok((result, new_state))
    }

    fn check(&self, state: &DecoderState) -> Result<bool> {
        // Basic validation: state should have been initialized
        Ok(!state.state_bytes.is_empty())
    }

    fn id(&self) -> &DecoderId {
        &self.decoder.id
    }
}

/// Helper to write bytes to WASM memory
fn write_bytes_to_memory(
    instance: &mut super::pool::PooledInstance,
    memory: &Memory,
    data: &[u8],
) -> Result<i32> {
    let current_size = memory.data_size(&instance.store);
    let needed = current_size + data.len();
    let pages_needed = (needed / 65536) + 1;
    memory
        .grow(&mut instance.store, pages_needed as u64)
        .map_err(|e| Error::wasm_runtime(format!("Grow failed: {}", e)))?;

    let ptr = current_size as i32;
    memory
        .write(&mut instance.store, ptr as usize, data)
        .map_err(|e| Error::wasm_runtime(format!("Write failed: {}", e)))?;

    Ok(ptr)
}

/// Helper to allocate memory
fn allocate_in_memory(
    instance: &mut super::pool::PooledInstance,
    memory: &Memory,
    size: usize,
) -> Result<i32> {
    let current_size = memory.data_size(&instance.store);
    let needed = current_size + size;
    let pages_needed = (needed / 65536) + 1;
    memory
        .grow(&mut instance.store, pages_needed as u64)
        .map_err(|e| Error::wasm_runtime(format!("Grow failed: {}", e)))?;
    Ok(current_size as i32)
}

/// Runtime statistics
#[derive(Debug, Clone)]
pub struct RuntimeStats {
    pub pool_stats: super::pool::PoolStats,
    pub allowlist_policy: String,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_runtime_creation() {
        let runtime = WasmRuntime::testing().unwrap();
        let stats = runtime.stats();
        assert_eq!(stats.pool_stats.cached_modules, 0);
    }
}
