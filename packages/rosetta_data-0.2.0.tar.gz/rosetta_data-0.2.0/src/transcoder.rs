// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Transcoder module for converting any supported format to Parquet bytes
//!
//! This is the core of Rosetta's backwards compatibility story. It reads
//! any supported format (Vortex, Lance, F3, Parquet) and outputs Parquet v1
//! bytes that any legacy reader can consume.
//!
//! # Architecture
//!
//! ```text
//! Input File (any format)
//!        │
//!        ▼
//! ┌─────────────────┐
//! │ FormatDetector  │  Detect actual format
//! └─────────────────┘
//!        │
//!        ▼
//! ┌─────────────────┐
//! │ UnifiedReader   │  Read → Arrow RecordBatches
//! └─────────────────┘
//!        │
//!        ▼
//! ┌─────────────────┐
//! │ ParquetWriter   │  Arrow → Parquet v1 bytes
//! └─────────────────┘
//!        │
//!        ▼
//! Parquet v1 bytes (legacy compatible)
//! ```
//!
//! # Enterprise Extension Points
//!
//! The [`TranscodeHooks`] trait provides extension points for:
//! - Caching transcoded results (Redis, S3, etc.)
//! - Metrics collection (transcodes/sec, bytes/sec, etc.)
//! - Cost tracking (compute time, storage savings)
//!
//! See [`set_transcode_hooks`] for configuring custom hooks.

use bytes::Bytes;
use std::path::Path;
use std::sync::Arc;
use std::time::Duration;
use tracing::{debug, info, instrument};

use crate::writers::{ParquetWriter, ParquetWriterOptions};
use crate::{Error, FileFormat, FormatDetector, ReadOptions, Result, UnifiedReader};

/// Hooks for transcode observability and caching.
///
/// This trait provides extension points for enterprise integrations:
/// - **Caching**: Store/retrieve transcoded results to avoid re-processing
/// - **Metrics**: Track transcoding performance and throughput
/// - **Cost tracking**: Monitor compute usage for billing
///
/// The default implementation is a no-op. Enterprise deployments can
/// provide custom implementations.
///
/// # Example
///
/// ```rust,ignore
/// use rosetta::transcoder::{TranscodeHooks, TranscodeResult};
///
/// struct RedisCacheHooks {
///     client: redis::Client,
///     metrics: PrometheusRegistry,
/// }
///
/// impl TranscodeHooks for RedisCacheHooks {
///     fn check_cache(&self, source_path: &str, format: FileFormat) -> Option<Bytes> {
///         // Check Redis for cached result
///     }
///
///     fn store_cache(&self, source_path: &str, result: &TranscodeResult) {
///         // Store in Redis with TTL
///     }
///
///     fn on_transcode_complete(&self, source: &str, result: &TranscodeResult, duration: Duration) {
///         self.metrics.transcode_duration.observe(duration.as_secs_f64());
///         self.metrics.bytes_transcoded.inc_by(result.byte_size() as f64);
///     }
/// }
/// ```
pub trait TranscodeHooks: Send + Sync {
    /// Check if a transcoded result exists in cache.
    ///
    /// Returns the cached Parquet bytes if available.
    fn check_cache(&self, _source_path: &str, _source_format: FileFormat) -> Option<Bytes> {
        None
    }

    /// Store a transcoded result in cache.
    fn store_cache(&self, _source_path: &str, _result: &TranscodeResult) {}

    /// Called when a transcode operation starts.
    fn on_transcode_start(&self, _source_path: &str, _source_format: FileFormat) {}

    /// Called when a transcode operation completes successfully.
    fn on_transcode_complete(
        &self,
        _source_path: &str,
        _result: &TranscodeResult,
        _duration: Duration,
    ) {
    }

    /// Called when a transcode operation fails.
    fn on_transcode_error(&self, _source_path: &str, _error: &str) {}

    /// Called when a cache hit occurs (skipped transcoding).
    fn on_cache_hit(&self, _source_path: &str, _cached_size: usize) {}
}

/// No-op implementation of TranscodeHooks for OSS builds.
#[derive(Debug, Clone, Copy, Default)]
pub struct NoOpTranscodeHooks;

impl TranscodeHooks for NoOpTranscodeHooks {}

/// Global hooks instance. Enterprise deployments can replace this.
static TRANSCODE_HOOKS: std::sync::OnceLock<Arc<dyn TranscodeHooks>> = std::sync::OnceLock::new();

/// Get the current transcode hooks instance.
pub fn get_transcode_hooks() -> Arc<dyn TranscodeHooks> {
    TRANSCODE_HOOKS
        .get()
        .cloned()
        .unwrap_or_else(|| Arc::new(NoOpTranscodeHooks))
}

/// Set custom transcode hooks (for enterprise integrations).
///
/// This must be called before any transcode operations.
/// Returns Err if hooks have already been set.
pub fn set_transcode_hooks(hooks: Arc<dyn TranscodeHooks>) -> Result<()> {
    TRANSCODE_HOOKS
        .set(hooks)
        .map_err(|_| Error::config("Transcode hooks already initialized"))
}

/// Transcoder for converting any format to Parquet bytes
pub struct Transcoder {
    /// Writer options for Parquet output
    writer_options: ParquetWriterOptions,
    /// Read options for input
    read_options: ReadOptions,
    /// Filter to push down during read
    filter: Option<crate::expr::Expr>,
}

impl Transcoder {
    /// Create a new transcoder with default options
    pub fn new() -> Self {
        Self {
            writer_options: ParquetWriterOptions::max_compatibility(),
            read_options: ReadOptions::default(),
            filter: None,
        }
    }

    /// Create with custom writer options
    pub fn with_writer_options(mut self, options: ParquetWriterOptions) -> Self {
        self.writer_options = options;
        self
    }

    /// Create with custom read options
    pub fn with_read_options(mut self, options: ReadOptions) -> Self {
        self.read_options = options;
        self
    }

    /// Set a filter to push down during transcoding.
    ///
    /// The filter will be pushed to the underlying format reader,
    /// reducing the amount of data that needs to be transcoded.
    pub fn with_filter(mut self, filter: crate::expr::Expr) -> Self {
        self.filter = Some(filter);
        self
    }

    /// Transcode a file to Parquet bytes
    #[instrument(skip(self), fields(path = %path.as_ref().display()))]
    pub async fn transcode_file<P: AsRef<Path>>(&self, path: P) -> Result<TranscodeResult> {
        let path = path.as_ref();

        // Detect format
        let detector = FormatDetector::new();
        let source_format = detector.detect_file(path).await?;
        info!(?source_format, "Detected source format");

        // If already Parquet v1, we might just pass through
        if matches!(source_format, FileFormat::ParquetV1) && self.read_options.columns.is_none() {
            debug!("Source is Parquet v1, considering passthrough");
            // For now, still transcode to ensure consistent output
            // Could optimize to return original bytes in future
        }

        // Read the file
        let mut reader = UnifiedReader::open_with_options(path, self.read_options.clone()).await?;

        // Push filter to the reader if set
        if let Some(filter) = &self.filter {
            let push_result = reader.push_filter(filter);
            debug!(?push_result, "Filter pushdown result");
        }

        let batches = reader.read_all().await?;

        if batches.is_empty() {
            return Err(Error::invalid_file("No data in source file"));
        }

        // Write to Parquet bytes
        let writer = ParquetWriter::with_options(self.writer_options.clone());
        let parquet_bytes = writer.write_batches(&batches)?;

        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();

        Ok(TranscodeResult {
            bytes: parquet_bytes,
            source_format,
            target_format: FileFormat::ParquetV1,
            num_rows: total_rows,
            num_columns: batches[0].num_columns(),
        })
    }

    /// Transcode from a URL (S3, GCS, etc.)
    #[instrument(skip(self))]
    pub async fn transcode_url(&self, url: &str) -> Result<TranscodeResult> {
        // Detect format
        let detector = FormatDetector::new();
        let source_format = detector.detect_url(url).await?;
        info!(?source_format, "Detected source format from URL");

        // Read the file
        let mut reader =
            UnifiedReader::open_url_with_options(url, self.read_options.clone()).await?;

        // Push filter to the reader if set
        if let Some(filter) = &self.filter {
            let push_result = reader.push_filter(filter);
            debug!(?push_result, "Filter pushdown result");
        }

        let batches = reader.read_all().await?;

        if batches.is_empty() {
            return Err(Error::invalid_file("No data in source file"));
        }

        // Write to Parquet bytes
        let writer = ParquetWriter::with_options(self.writer_options.clone());
        let parquet_bytes = writer.write_batches(&batches)?;

        let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();

        Ok(TranscodeResult {
            bytes: parquet_bytes,
            source_format,
            target_format: FileFormat::ParquetV1,
            num_rows: total_rows,
            num_columns: batches[0].num_columns(),
        })
    }

    /// Transcode from bytes with known format
    #[instrument(skip(self, data))]
    pub async fn transcode_bytes(
        &self,
        data: Bytes,
        source_format: FileFormat,
    ) -> Result<TranscodeResult> {
        // For now, only Parquet bytes-based reading is supported
        // Vortex/Lance require file paths
        match source_format {
            FileFormat::ParquetV1 | FileFormat::ParquetV2 => {
                let reader = crate::readers::ParquetReader::from_bytes(data).await?;
                let batches = reader.read_all().await?;

                if batches.is_empty() {
                    return Err(Error::invalid_file("No data in source"));
                }

                let writer = ParquetWriter::with_options(self.writer_options.clone());
                let parquet_bytes = writer.write_batches(&batches)?;

                let total_rows: usize = batches.iter().map(|b| b.num_rows()).sum();

                Ok(TranscodeResult {
                    bytes: parquet_bytes,
                    source_format,
                    target_format: FileFormat::ParquetV1,
                    num_rows: total_rows,
                    num_columns: batches[0].num_columns(),
                })
            }
            _ => Err(Error::unsupported_format(
                source_format.name(),
                "bytes-based transcoding",
            )),
        }
    }
}

impl Default for Transcoder {
    fn default() -> Self {
        Self::new()
    }
}

/// Result of a transcode operation
#[derive(Debug)]
pub struct TranscodeResult {
    /// The transcoded Parquet bytes
    pub bytes: Bytes,
    /// Source format that was read
    pub source_format: FileFormat,
    /// Target format (always Parquet v1 for now)
    pub target_format: FileFormat,
    /// Number of rows transcoded
    pub num_rows: usize,
    /// Number of columns
    pub num_columns: usize,
}

impl TranscodeResult {
    /// Get the transcoded bytes
    pub fn into_bytes(self) -> Bytes {
        self.bytes
    }

    /// Get byte size of the output
    pub fn byte_size(&self) -> usize {
        self.bytes.len()
    }
}

/// Check if a path needs transcoding (is not already Parquet v1)
pub async fn needs_transcoding<P: AsRef<Path>>(path: P) -> Result<bool> {
    let detector = FormatDetector::new();
    let format = detector.detect_file(path).await?;
    Ok(!matches!(format, FileFormat::ParquetV1))
}

/// Quick transcode function for convenience
pub async fn transcode_to_parquet<P: AsRef<Path>>(path: P) -> Result<Bytes> {
    let transcoder = Transcoder::new();
    let result = transcoder.transcode_file(path).await?;
    Ok(result.bytes)
}

#[cfg(test)]
mod tests {
    use super::*;
    use arrow::array::{Int32Array, StringArray};
    use arrow::datatypes::{DataType, Field, Schema};
    use arrow::record_batch::RecordBatch;
    use parquet::arrow::ArrowWriter;
    use std::sync::Arc;
    use tempfile::NamedTempFile;

    fn create_test_parquet() -> NamedTempFile {
        let file = NamedTempFile::new().unwrap();

        let schema = Arc::new(Schema::new(vec![
            Field::new("id", DataType::Int32, false),
            Field::new("name", DataType::Utf8, true),
        ]));

        let ids = Int32Array::from(vec![1, 2, 3]);
        let names = StringArray::from(vec![Some("a"), Some("b"), Some("c")]);

        let batch =
            RecordBatch::try_new(schema.clone(), vec![Arc::new(ids), Arc::new(names)]).unwrap();

        let file_writer = std::fs::File::create(file.path()).unwrap();
        let mut writer = ArrowWriter::try_new(file_writer, schema, None).unwrap();
        writer.write(&batch).unwrap();
        writer.close().unwrap();

        file
    }

    #[tokio::test]
    async fn test_transcode_parquet_file() {
        let file = create_test_parquet();
        let transcoder = Transcoder::new();
        let result = transcoder.transcode_file(file.path()).await.unwrap();

        assert_eq!(result.num_rows, 3);
        assert_eq!(result.num_columns, 2);
        assert!(matches!(
            result.source_format,
            FileFormat::ParquetV1 | FileFormat::ParquetV2
        ));
        assert!(matches!(result.target_format, FileFormat::ParquetV1));

        // Verify output is valid Parquet
        assert_eq!(&result.bytes[0..4], b"PAR1");
    }

    #[tokio::test]
    async fn test_needs_transcoding() {
        let file = create_test_parquet();
        // Parquet files may or may not need transcoding depending on version
        let _needs = needs_transcoding(file.path()).await.unwrap();
        // Just verify it doesn't error
    }

    #[tokio::test]
    async fn test_quick_transcode() {
        let file = create_test_parquet();
        let bytes = transcode_to_parquet(file.path()).await.unwrap();
        assert_eq!(&bytes[0..4], b"PAR1");
    }
}
