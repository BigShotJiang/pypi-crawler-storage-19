// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Shared utilities for object store (S3, GCS, Azure) operations
//!
//! This module provides consistent credential handling and object store
//! construction across all Rosetta components.

use crate::{Error, Result};
use object_store::aws::AmazonS3Builder;
use object_store::gcp::GoogleCloudStorageBuilder;
use object_store::ObjectStore;
use std::sync::Arc;
use tracing::debug;

/// AWS credentials resolved from environment or config files
#[derive(Debug, Clone)]
pub struct AwsCredentials {
    pub access_key_id: String,
    pub secret_access_key: String,
    pub region: Option<String>,
    pub session_token: Option<String>,
}

/// Resolve AWS credentials from environment variables and ~/.aws config files.
///
/// Order of precedence:
/// 1. Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION)
/// 2. ~/.aws/credentials file (default profile)
/// 3. ~/.aws/config file (for region)
///
/// This function intentionally does NOT use IMDS (EC2 metadata service) to avoid
/// 1-second timeouts on non-EC2 environments.
pub fn resolve_aws_credentials() -> Result<AwsCredentials> {
    // Try environment variables first
    let access_key = std::env::var("AWS_ACCESS_KEY_ID").ok();
    let secret_key = std::env::var("AWS_SECRET_ACCESS_KEY").ok();
    let session_token = std::env::var("AWS_SESSION_TOKEN").ok();
    let region = std::env::var("AWS_REGION")
        .or_else(|_| std::env::var("AWS_DEFAULT_REGION"))
        .ok();

    // If environment has credentials, use them
    if let (Some(ak), Some(sk)) = (access_key.clone(), secret_key.clone()) {
        debug!("Using AWS credentials from environment variables");
        return Ok(AwsCredentials {
            access_key_id: ak,
            secret_access_key: sk,
            region,
            session_token,
        });
    }

    // Otherwise, try ~/.aws/credentials and ~/.aws/config
    let home =
        std::env::var("HOME").map_err(|_| Error::config("HOME environment variable not set"))?;

    let mut ak = access_key;
    let mut sk = secret_key;
    let mut rg = region;

    // Parse ~/.aws/credentials
    let creds_path = format!("{}/.aws/credentials", home);
    if let Ok(contents) = std::fs::read_to_string(&creds_path) {
        debug!("Reading AWS credentials from {}", creds_path);
        parse_aws_credentials_file(&contents, &mut ak, &mut sk);
    }

    // Parse ~/.aws/config for region
    if rg.is_none() {
        let config_path = format!("{}/.aws/config", home);
        if let Ok(contents) = std::fs::read_to_string(&config_path) {
            debug!("Reading AWS config from {}", config_path);
            parse_aws_config_file(&contents, &mut rg);
        }
    }

    match (ak, sk) {
        (Some(access_key_id), Some(secret_access_key)) => Ok(AwsCredentials {
            access_key_id,
            secret_access_key,
            region: rg,
            session_token,
        }),
        _ => Err(Error::config(
            "AWS credentials not found. Set AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY \
             environment variables or configure ~/.aws/credentials",
        )),
    }
}

/// Parse ~/.aws/credentials file for access key and secret key
fn parse_aws_credentials_file(contents: &str, ak: &mut Option<String>, sk: &mut Option<String>) {
    let mut in_default = false;
    for line in contents.lines() {
        let line = line.trim();
        if line == "[default]" {
            in_default = true;
        } else if line.starts_with('[') {
            in_default = false;
        } else if in_default {
            if let Some(value) = line.strip_prefix("aws_access_key_id") {
                if ak.is_none() {
                    *ak = value.trim().strip_prefix('=').map(|s| s.trim().to_string());
                }
            } else if let Some(value) = line.strip_prefix("aws_secret_access_key") {
                if sk.is_none() {
                    *sk = value.trim().strip_prefix('=').map(|s| s.trim().to_string());
                }
            }
        }
    }
}

/// Parse ~/.aws/config file for region
fn parse_aws_config_file(contents: &str, region: &mut Option<String>) {
    let mut in_default = false;
    for line in contents.lines() {
        let line = line.trim();
        // Config file uses [default] or [profile default]
        if line == "[default]" || line == "[profile default]" {
            in_default = true;
        } else if line.starts_with('[') {
            in_default = false;
        } else if in_default && region.is_none() {
            if let Some(value) = line.strip_prefix("region") {
                *region = value.trim().strip_prefix('=').map(|s| s.trim().to_string());
            }
        }
    }
}

/// Build an S3 object store for the given bucket.
///
/// Uses [`resolve_aws_credentials`] for credential resolution, avoiding IMDS timeouts.
pub fn build_s3_store(bucket: &str) -> Result<Arc<dyn ObjectStore>> {
    let creds = resolve_aws_credentials()?;

    let mut builder = AmazonS3Builder::new()
        .with_bucket_name(bucket)
        .with_access_key_id(&creds.access_key_id)
        .with_secret_access_key(&creds.secret_access_key);

    if let Some(token) = &creds.session_token {
        builder = builder.with_token(token);
    }

    if let Some(region) = &creds.region {
        builder = builder.with_region(region);
    } else {
        // Default to us-east-1 if no region specified
        builder = builder.with_region("us-east-1");
    }

    let store = builder.build()?;
    Ok(Arc::new(store))
}

/// Build a GCS object store for the given bucket.
///
/// Uses environment-based credentials (GOOGLE_APPLICATION_CREDENTIALS).
pub fn build_gcs_store(bucket: &str) -> Result<Arc<dyn ObjectStore>> {
    let store = GoogleCloudStorageBuilder::from_env()
        .with_bucket_name(bucket)
        .build()?;
    Ok(Arc::new(store))
}

/// Parse an S3 or GCS URL and return (store, path).
///
/// Supported URL schemes:
/// - `s3://bucket/key/path`
/// - `gs://bucket/key/path`
pub fn parse_cloud_url(url: &str) -> Result<(Arc<dyn ObjectStore>, object_store::path::Path)> {
    let parsed = url::Url::parse(url)?;

    let bucket = parsed
        .host_str()
        .ok_or_else(|| Error::invalid_file(format!("Missing bucket in URL: {}", url)))?;
    let key = parsed.path().trim_start_matches('/');
    let path = object_store::path::Path::from(key);

    match parsed.scheme() {
        "s3" => {
            let store = build_s3_store(bucket)?;
            Ok((store, path))
        }
        "gs" => {
            let store = build_gcs_store(bucket)?;
            Ok((store, path))
        }
        scheme => Err(Error::invalid_file(format!(
            "Unsupported URL scheme: {}. Supported: s3://, gs://",
            scheme
        ))),
    }
}

/// Check if a URL points to cloud storage
pub fn is_cloud_url(url: &str) -> bool {
    url.starts_with("s3://") || url.starts_with("gs://") || url.starts_with("az://")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_credentials_file() {
        let contents = r#"
[default]
aws_access_key_id = AKIAIOSFODNN7EXAMPLE
aws_secret_access_key = wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY

[other-profile]
aws_access_key_id = OTHER_KEY
aws_secret_access_key = OTHER_SECRET
"#;
        let mut ak = None;
        let mut sk = None;
        parse_aws_credentials_file(contents, &mut ak, &mut sk);

        assert_eq!(ak, Some("AKIAIOSFODNN7EXAMPLE".to_string()));
        assert_eq!(
            sk,
            Some("wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY".to_string())
        );
    }

    #[test]
    fn test_parse_config_file() {
        let contents = r#"
[default]
region = us-west-2
output = json

[profile other]
region = eu-west-1
"#;
        let mut region = None;
        parse_aws_config_file(contents, &mut region);

        assert_eq!(region, Some("us-west-2".to_string()));
    }

    #[test]
    fn test_is_cloud_url() {
        assert!(is_cloud_url("s3://bucket/key"));
        assert!(is_cloud_url("gs://bucket/key"));
        assert!(is_cloud_url("az://container/blob"));
        assert!(!is_cloud_url("/local/path"));
        assert!(!is_cloud_url("file:///local/path"));
    }
}
