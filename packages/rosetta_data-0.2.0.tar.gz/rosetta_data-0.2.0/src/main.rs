// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Rosetta CLI - Universal File Format Bridge
//!
//! A command-line tool for reading and converting columnar file formats.

use rosetta::{
    generate_benchmark_file, generate_report, run_benchmark_suite_opts, BenchmarkConfig,
    FileFormat, FormatDetector, ReadOptions, TargetEncoding, Transcoder, UnifiedReader,
    UpgradeOptions, Upgrader,
};
use std::time::Instant;
use tracing_subscriber::{layer::SubscriberExt, util::SubscriberInitExt};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // Initialize logging
    tracing_subscriber::registry()
        .with(tracing_subscriber::fmt::layer())
        .with(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    let args: Vec<String> = std::env::args().collect();

    if args.len() < 2 {
        print_usage(&args[0]);
        return Ok(());
    }

    match args[1].as_str() {
        "detect" => {
            if args.len() < 3 {
                eprintln!("Usage: {} detect <file>", args[0]);
                std::process::exit(1);
            }
            detect_format(&args[2]).await?;
        }
        "info" => {
            if args.len() < 3 {
                eprintln!("Usage: {} info <file>", args[0]);
                std::process::exit(1);
            }
            show_info(&args[2]).await?;
        }
        "read" => {
            if args.len() < 3 {
                eprintln!("Usage: {} read <file> [--columns col1,col2]", args[0]);
                std::process::exit(1);
            }
            read_and_print(&args[2..]).await?;
        }
        "convert" => {
            if args.len() < 4 {
                eprintln!("Usage: {} convert <input> <output>", args[0]);
                std::process::exit(1);
            }
            convert_file(&args[2], &args[3]).await?;
        }
        "bench" => {
            if args.len() < 3 {
                eprintln!("Usage: {} bench <file> [--iterations N]", args[0]);
                std::process::exit(1);
            }
            benchmark_file(&args[2..]).await?;
        }
        "analyze" => {
            if args.len() < 3 {
                eprintln!("Usage: {} analyze <file> [--deep]", args[0]);
                std::process::exit(1);
            }
            analyze_file(&args[2..]).await?;
        }
        "upgrade" => {
            if args.len() < 4 {
                eprintln!(
                    "Usage: {} upgrade <input> <output> [--encoding auto|v2|original]",
                    args[0]
                );
                std::process::exit(1);
            }
            upgrade_file(&args[2..]).await?;
        }
        "benchmark" => {
            run_benchmark(&args[2..]).await?;
        }
        "help" | "--help" | "-h" => {
            print_usage(&args[0]);
        }
        "version" | "--version" | "-V" => {
            println!("rosetta {}", env!("CARGO_PKG_VERSION"));
        }
        _ => {
            eprintln!("Unknown command: {}", args[1]);
            print_usage(&args[0]);
            std::process::exit(1);
        }
    }

    Ok(())
}

fn print_usage(program: &str) {
    println!(
        r#"Rosetta - Universal File Format Bridge

USAGE:
    {} <COMMAND> [OPTIONS]

COMMANDS:
    detect <file>              Detect the format of a file
    info <file>                Show file information (schema, row groups, etc.)
    read <file>                Read and display file contents
    convert <input> <output>   Convert file to another format
    bench <file>               Run performance benchmark on file
    benchmark                  Generate test data and run comparative benchmark suite
    analyze <file>             Analyze file for encoding optimizations
    upgrade <input> <output>   Upgrade file with optimized encodings
    help                       Show this help message
    version                    Show version information

READ OPTIONS:
    --columns, -c <cols>   Comma-separated list of columns to read
    --limit, -n <N>        Limit output to N rows

BENCH OPTIONS:
    --iterations, -i <N>   Number of iterations (default: 10)

BENCHMARK OPTIONS:
    --rows, -r <N>         Number of rows in test data (default: 100000)
    --iterations, -i <N>   Number of benchmark iterations (default: 10)
    --output, -o <file>    Write results to markdown file
    --json                 Output results in JSON format
    --no-warmup            Skip warmup iterations (test cold cache performance)

ANALYZE OPTIONS:
    --deep                 Read data to compute actual statistics (slower but more accurate)

UPGRADE OPTIONS:
    --encoding, -e <enc>   Target encoding: auto, v2, original (default: auto)
    --dry-run              Analyze only, don't write output file
    --min-savings <N>      Minimum savings % to apply (default: 5)

SUPPORTED FORMATS:
    - Apache Parquet (v1 and v2)
    - Vortex (requires --features vortex-reader)
    - Lance (requires --features lance-reader)

EXAMPLES:
    {} detect data.parquet
    {} info data.parquet
    {} read data.parquet --columns id,name --limit 10
    {} convert data.vortex data.parquet
    {} bench data.parquet --iterations 100
    {} analyze data.parquet
    {} upgrade data.parquet optimized.parquet --encoding v2

For more information, visit: https://github.com/rosetta-data/rosetta
"#,
        program, program, program, program, program, program, program, program
    );
}

async fn detect_format(path: &str) -> anyhow::Result<()> {
    let detector = FormatDetector::new();
    let format = detector.detect_file(path).await?;

    println!("File: {}", path);
    println!("Format: {}", format.name());
    println!("Extension: .{}", format.extension());
    println!("Requires WASM: {}", format.requires_wasm());

    Ok(())
}

async fn show_info(path: &str) -> anyhow::Result<()> {
    let reader = UnifiedReader::open(path).await?;

    println!("File: {}", path);
    println!("Format: {}", reader.format().name());
    println!("Row Groups: {}", reader.num_row_groups());
    println!();
    println!("Schema:");
    println!("-------");

    for field in reader.schema().fields() {
        println!(
            "  {} : {} {}",
            field.name(),
            field.data_type(),
            if field.is_nullable() {
                "(nullable)"
            } else {
                "(not null)"
            }
        );
    }

    Ok(())
}

async fn read_and_print(args: &[String]) -> anyhow::Result<()> {
    let path = &args[0];
    let mut columns: Option<Vec<String>> = None;
    let mut limit: Option<usize> = None;

    // Parse arguments
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--columns" | "-c" => {
                if i + 1 < args.len() {
                    columns = Some(args[i + 1].split(',').map(|s| s.to_string()).collect());
                    i += 2;
                } else {
                    eprintln!("--columns requires a value");
                    std::process::exit(1);
                }
            }
            "--limit" | "-n" => {
                if i + 1 < args.len() {
                    limit = Some(args[i + 1].parse()?);
                    i += 2;
                } else {
                    eprintln!("--limit requires a value");
                    std::process::exit(1);
                }
            }
            _ => {
                eprintln!("Unknown option: {}", args[i]);
                std::process::exit(1);
            }
        }
    }

    let mut options = ReadOptions::new();
    if let Some(cols) = columns {
        options = options.with_columns(cols);
    }

    let reader = UnifiedReader::open_with_options(path, options).await?;
    let batches = reader.read_all().await?;

    // Print batches
    let mut total_rows = 0;
    for batch in &batches {
        if let Some(max) = limit {
            if total_rows >= max {
                break;
            }
        }

        // Simple table printing
        let num_rows = if let Some(max) = limit {
            std::cmp::min(batch.num_rows(), max - total_rows)
        } else {
            batch.num_rows()
        };

        // Print header
        if total_rows == 0 {
            let headers: Vec<_> = batch
                .schema()
                .fields()
                .iter()
                .map(|f| f.name().clone())
                .collect();
            println!("{}", headers.join("\t"));
            println!("{}", "-".repeat(headers.join("\t").len()));
        }

        // Print rows
        for row in 0..num_rows {
            let values: Vec<String> = (0..batch.num_columns())
                .map(|col| {
                    let array = batch.column(col);
                    arrow::util::display::array_value_to_string(array, row).unwrap_or_default()
                })
                .collect();
            println!("{}", values.join("\t"));
        }

        total_rows += num_rows;
    }

    println!();
    println!("Total rows: {}", total_rows);

    Ok(())
}

async fn convert_file(input: &str, output: &str) -> anyhow::Result<()> {
    println!("Converting: {} -> {}", input, output);

    let start = Instant::now();

    // Detect input format
    let detector = FormatDetector::new();
    let input_format = detector.detect_file(input).await?;
    println!("Input format: {}", input_format.name());

    // Determine output format from extension
    if !output.ends_with(".parquet") {
        anyhow::bail!("Output format not supported. Currently only .parquet output is supported.");
    };
    println!("Output format: Parquet v1");

    let input_size = std::fs::metadata(input)?.len();

    // Transcode
    let transcoder = Transcoder::new();
    let result = transcoder.transcode_file(input).await?;

    // Write output
    std::fs::write(output, &result.bytes)?;

    let elapsed = start.elapsed();
    let output_size = result.bytes.len() as u64;

    println!();
    println!("Conversion complete:");
    println!("  Input size:  {} bytes", input_size);
    println!("  Output size: {} bytes", output_size);
    println!("  Rows:        {}", result.num_rows);
    println!("  Columns:     {}", result.num_columns);
    println!(
        "  Ratio:       {:.2}x",
        output_size as f64 / input_size as f64
    );
    println!("  Time:        {:.2?}", elapsed);
    println!(
        "  Throughput:  {:.2} MiB/s",
        input_size as f64 / 1024.0 / 1024.0 / elapsed.as_secs_f64()
    );

    Ok(())
}

async fn benchmark_file(args: &[String]) -> anyhow::Result<()> {
    let path = &args[0];
    let mut iterations = 10usize;

    // Parse arguments
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "--iterations" | "-i" => {
                if i + 1 < args.len() {
                    iterations = args[i + 1].parse()?;
                    i += 2;
                } else {
                    eprintln!("--iterations requires a value");
                    std::process::exit(1);
                }
            }
            _ => {
                eprintln!("Unknown option: {}", args[i]);
                std::process::exit(1);
            }
        }
    }

    println!("Benchmarking: {}", path);
    println!("Iterations: {}", iterations);
    println!();

    // Get file info
    let file_size = std::fs::metadata(path)?.len();
    let detector = FormatDetector::new();
    let format = detector.detect_file(path).await?;
    println!("Format: {}", format.name());
    println!(
        "File size: {} bytes ({:.2} MiB)",
        file_size,
        file_size as f64 / 1024.0 / 1024.0
    );

    // Warm up
    println!();
    println!("Warming up...");
    let reader = UnifiedReader::open(path).await?;
    let _ = reader.read_all().await?;

    // Run benchmark
    println!("Running {} iterations...", iterations);
    let mut times = Vec::with_capacity(iterations);

    for _ in 0..iterations {
        let start = Instant::now();
        let reader = UnifiedReader::open(path).await?;
        let batches = reader.read_all().await?;
        let _ = batches.iter().map(|b| b.num_rows()).sum::<usize>();
        times.push(start.elapsed());
    }

    // Calculate statistics
    times.sort();
    let min = times.first().unwrap();
    let max = times.last().unwrap();
    let median = &times[iterations / 2];
    let total: std::time::Duration = times.iter().sum();
    let mean = total / iterations as u32;

    println!();
    println!("Results:");
    println!("  Min:    {:>10.2?}", min);
    println!("  Max:    {:>10.2?}", max);
    println!("  Mean:   {:>10.2?}", mean);
    println!("  Median: {:>10.2?}", median);
    println!();
    println!(
        "Throughput (median): {:.2} MiB/s",
        file_size as f64 / 1024.0 / 1024.0 / median.as_secs_f64()
    );

    // Try sync path for Parquet
    if matches!(format, FileFormat::ParquetV1 | FileFormat::ParquetV2) {
        println!();
        println!("Sync path benchmark (Parquet only):");
        let mut sync_times = Vec::with_capacity(iterations);

        for _ in 0..iterations {
            let start = Instant::now();
            let reader = UnifiedReader::open_parquet_sync(path)?;
            let batches = reader.read_all_sync()?;
            let _ = batches.iter().map(|b| b.num_rows()).sum::<usize>();
            sync_times.push(start.elapsed());
        }

        sync_times.sort();
        let sync_median = &sync_times[iterations / 2];
        println!("  Median: {:>10.2?}", sync_median);
        println!(
            "  Throughput: {:.2} MiB/s",
            file_size as f64 / 1024.0 / 1024.0 / sync_median.as_secs_f64()
        );
    }

    Ok(())
}

async fn analyze_file(args: &[String]) -> anyhow::Result<()> {
    let path = &args[0];
    let deep = args.iter().any(|a| a == "--deep");

    println!("Analyzing: {}", path);
    if deep {
        println!("Mode: Deep analysis (reading actual data)");
    }
    println!();

    let upgrader = Upgrader::new();
    let analysis = if deep {
        upgrader.analyze_deep(path).await?
    } else {
        upgrader.analyze(path).await?
    };

    println!("Format: {}", analysis.format.name());
    println!(
        "Total size: {} bytes ({:.2} MiB)",
        analysis.total_size,
        analysis.total_size as f64 / 1024.0 / 1024.0
    );
    println!("Columns: {}", analysis.columns.len());
    println!();

    println!("Column Analysis:");
    println!("{:-<80}", "");
    println!(
        "{:<20} {:<15} {:<25} {:>10} {:>8}",
        "Column", "Type", "Recommended Encoding", "Est. Size", "Savings"
    );
    println!("{:-<80}", "");

    for col in &analysis.columns {
        let type_name = format!("{:?}", col.data_type);
        let type_short = if type_name.len() > 12 {
            &type_name[..12]
        } else {
            &type_name
        };
        println!(
            "{:<20} {:<15} {:<25} {:>10} {:>7.1}%",
            col.name.chars().take(18).collect::<String>(),
            type_short,
            col.recommended_encoding,
            format_size(col.estimated_new_size),
            col.estimated_savings_percent
        );
    }

    println!("{:-<80}", "");
    println!();
    println!(
        "Total estimated savings: {} ({:.1}%)",
        format_size(analysis.total_estimated_savings),
        analysis.total_estimated_savings_percent
    );

    if analysis.total_estimated_savings_percent >= 5.0 {
        println!();
        println!(
            "Recommendation: Run 'rosetta upgrade {} <output>' to apply optimizations",
            path
        );
    }

    Ok(())
}

async fn upgrade_file(args: &[String]) -> anyhow::Result<()> {
    let input = &args[0];
    let output = &args[1];
    let mut encoding = TargetEncoding::Auto;
    let mut dry_run = false;
    let mut min_savings = 5.0f64;

    // Parse arguments
    let mut i = 2;
    while i < args.len() {
        match args[i].as_str() {
            "--encoding" | "-e" => {
                if i + 1 < args.len() {
                    encoding = match args[i + 1].as_str() {
                        "auto" => TargetEncoding::Auto,
                        "v2" | "parquet-v2" => TargetEncoding::ParquetV2,
                        "original" => TargetEncoding::Original,
                        "dictionary" | "fsst" => TargetEncoding::DictionaryFSST,
                        _ => {
                            eprintln!("Unknown encoding: {}. Using 'auto'", args[i + 1]);
                            TargetEncoding::Auto
                        }
                    };
                    i += 2;
                } else {
                    eprintln!("--encoding requires a value");
                    std::process::exit(1);
                }
            }
            "--dry-run" => {
                dry_run = true;
                i += 1;
            }
            "--min-savings" => {
                if i + 1 < args.len() {
                    min_savings = args[i + 1].parse()?;
                    i += 2;
                } else {
                    eprintln!("--min-savings requires a value");
                    std::process::exit(1);
                }
            }
            _ => {
                eprintln!("Unknown option: {}", args[i]);
                std::process::exit(1);
            }
        }
    }

    println!("Upgrading: {} -> {}", input, output);
    println!("Encoding: {:?}", encoding);
    if dry_run {
        println!("Mode: Dry run (no output will be written)");
    }
    println!();

    let upgrader = Upgrader::new();
    let mut options = UpgradeOptions::new()
        .with_encoding(encoding)
        .with_min_savings(min_savings);

    if dry_run {
        options = options.dry_run();
    }

    let report = upgrader.upgrade_file(input, output, options).await?;

    println!("Results:");
    println!(
        "  Input size:  {} ({:.2} MiB)",
        report.input_size,
        report.input_size as f64 / 1024.0 / 1024.0
    );
    println!(
        "  Output size: {} ({:.2} MiB)",
        report.output_size,
        report.output_size as f64 / 1024.0 / 1024.0
    );
    println!("  Rows:        {}", report.rows_processed);
    println!("  Duration:    {} ms", report.duration_ms);
    println!();

    if report.bytes_saved > 0 {
        println!(
            "Savings: {} bytes ({:.1}%)",
            report.bytes_saved, report.savings_percent
        );
    } else {
        println!(
            "File size increased by {} bytes ({:.1}%)",
            -report.bytes_saved, -report.savings_percent
        );
    }

    if !dry_run {
        println!();
        println!("Output written to: {}", output);
    }

    Ok(())
}

fn format_size(bytes: u64) -> String {
    if bytes >= 1024 * 1024 {
        format!("{:.1} MiB", bytes as f64 / 1024.0 / 1024.0)
    } else if bytes >= 1024 {
        format!("{:.1} KiB", bytes as f64 / 1024.0)
    } else {
        format!("{} B", bytes)
    }
}

async fn run_benchmark(args: &[String]) -> anyhow::Result<()> {
    let mut rows = 100_000usize;
    let mut iterations = 10usize;
    let mut output_file: Option<String> = None;
    let mut json_output = false;
    let mut warmup = true;

    // Parse arguments
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--rows" | "-r" => {
                if i + 1 < args.len() {
                    rows = args[i + 1].parse()?;
                    i += 2;
                } else {
                    eprintln!("--rows requires a value");
                    std::process::exit(1);
                }
            }
            "--iterations" | "-i" => {
                if i + 1 < args.len() {
                    iterations = args[i + 1].parse()?;
                    i += 2;
                } else {
                    eprintln!("--iterations requires a value");
                    std::process::exit(1);
                }
            }
            "--output" | "-o" => {
                if i + 1 < args.len() {
                    output_file = Some(args[i + 1].clone());
                    i += 2;
                } else {
                    eprintln!("--output requires a value");
                    std::process::exit(1);
                }
            }
            "--json" => {
                json_output = true;
                i += 1;
            }
            "--no-warmup" => {
                warmup = false;
                i += 1;
            }
            _ => {
                eprintln!("Unknown option: {}", args[i]);
                std::process::exit(1);
            }
        }
    }

    println!("Rosetta Benchmark Suite");
    println!("=======================");
    println!();
    println!("Configuration:");
    println!("  Rows: {}", rows);
    println!("  Iterations: {}", iterations);
    println!("  Warmup: {}", if warmup { "yes" } else { "no" });
    println!();

    // Generate test data
    println!("Generating test data...");
    let config = BenchmarkConfig::new()
        .with_rows(rows)
        .with_path("/tmp/rosetta_benchmark_suite.parquet");

    let path = generate_benchmark_file(&config)?;
    let file_size = std::fs::metadata(&path)?.len();
    println!(
        "  Generated: {} ({:.2} MiB)",
        path,
        file_size as f64 / 1024.0 / 1024.0
    );
    println!();

    // Run benchmark suite
    println!("Running benchmarks...");
    let results = run_benchmark_suite_opts(&path, iterations, warmup).await?;
    println!();

    if json_output {
        // Output JSON format
        let json = serde_json::json!({
            "file": path,
            "rows": rows,
            "file_size_bytes": file_size,
            "iterations": iterations,
            "results": results.iter().map(|r| {
                serde_json::json!({
                    "name": r.name,
                    "median_ms": r.median_time.as_secs_f64() * 1000.0,
                    "min_ms": r.min_time.as_secs_f64() * 1000.0,
                    "max_ms": r.max_time.as_secs_f64() * 1000.0,
                    "throughput_mibs": r.throughput_mibs
                })
            }).collect::<Vec<_>>()
        });
        println!("{}", serde_json::to_string_pretty(&json)?);
    } else {
        // Generate markdown report
        let report = generate_report(&results, &path);
        println!("{}", report);

        // Write to file if requested
        if let Some(output) = output_file {
            std::fs::write(&output, &report)?;
            println!();
            println!("Report written to: {}", output);
        }
    }

    // Cleanup
    std::fs::remove_file(&path).ok();

    Ok(())
}
