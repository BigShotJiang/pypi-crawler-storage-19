#!/usr/bin/env python3
"""
Rosetta Demo: DuckDB reading Vortex files through the universal bridge.

This demo shows how Rosetta enables DuckDB (which doesn't natively support Vortex)
to seamlessly query Vortex files - getting the compression benefits of Vortex
while using DuckDB's powerful SQL engine.

Workflow:
1. Generate realistic "sales" data (1M rows)
2. Save as Parquet (baseline)
3. Convert to Vortex (compressed columnar format)
4. Query both formats with DuckDB through Rosetta
5. Compare file sizes and query performance
"""

import tempfile
import time
from pathlib import Path

import duckdb
import pyarrow as pa
import pyarrow.parquet as pq


def generate_sales_data(num_rows: int = 1_000_000) -> pa.Table:
    """Generate realistic sales transaction data."""
    import random
    random.seed(42)

    # Realistic product categories (good for dictionary encoding in Vortex)
    categories = ['Electronics', 'Clothing', 'Home & Garden', 'Sports', 'Books',
                  'Toys', 'Food & Beverage', 'Health & Beauty', 'Automotive', 'Office']

    # Realistic store regions (also good for dictionary encoding)
    regions = ['Northeast', 'Southeast', 'Midwest', 'Southwest', 'West', 'Northwest']

    # Payment methods
    payment_methods = ['Credit Card', 'Debit Card', 'Cash', 'Digital Wallet', 'Gift Card']

    print(f"Generating {num_rows:,} sales transactions...")

    return pa.table({
        'transaction_id': list(range(1, num_rows + 1)),
        'category': [random.choice(categories) for _ in range(num_rows)],
        'region': [random.choice(regions) for _ in range(num_rows)],
        'payment_method': [random.choice(payment_methods) for _ in range(num_rows)],
        'quantity': [random.randint(1, 10) for _ in range(num_rows)],
        'unit_price': [round(random.uniform(5.0, 500.0), 2) for _ in range(num_rows)],
        'discount_pct': [round(random.uniform(0, 0.3), 2) for _ in range(num_rows)],
        'year': [random.choice([2022, 2023, 2024]) for _ in range(num_rows)],
        'month': [random.randint(1, 12) for _ in range(num_rows)],
    })


def format_size(bytes_size: int) -> str:
    """Format bytes as human-readable size."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.1f} TB"


def main():
    print("=" * 70)
    print("ROSETTA DEMO: DuckDB + Vortex Integration")
    print("=" * 70)
    print()

    # Create temp directory for demo files
    tmpdir = tempfile.mkdtemp(prefix="rosetta_demo_")
    parquet_path = Path(tmpdir) / "sales.parquet"
    vortex_path = Path(tmpdir) / "sales.vortex"

    # =========================================================================
    # STEP 1: Generate and save data
    # =========================================================================
    print("STEP 1: Generate Sales Data")
    print("-" * 40)

    data = generate_sales_data(1_000_000)
    print(f"  Rows: {data.num_rows:,}")
    print(f"  Columns: {data.num_columns}")
    print()

    # Save as Parquet
    print("  Saving as Parquet (snappy compression)...")
    pq.write_table(data, parquet_path, compression='snappy')
    parquet_size = parquet_path.stat().st_size
    print(f"  Parquet file: {format_size(parquet_size)}")

    # Save as Vortex
    print("  Saving as Vortex (automatic compression)...")
    import vortex as vx
    vx.io.write(data, str(vortex_path))
    vortex_size = vortex_path.stat().st_size
    print(f"  Vortex file: {format_size(vortex_size)}")

    compression_ratio = parquet_size / vortex_size
    print()
    print(f"  Vortex is {compression_ratio:.1f}x smaller than Parquet!")
    print()

    # =========================================================================
    # STEP 2: DuckDB reading Parquet (native)
    # =========================================================================
    print("STEP 2: DuckDB Reading Parquet (Native)")
    print("-" * 40)

    con = duckdb.connect()

    # Query 1: Aggregation
    query1 = """
        SELECT
            category,
            region,
            COUNT(*) as num_transactions,
            ROUND(SUM(quantity * unit_price * (1 - discount_pct)), 2) as total_revenue
        FROM read_parquet(?)
        GROUP BY category, region
        ORDER BY total_revenue DESC
        LIMIT 10
    """

    start = time.perf_counter()
    result_parquet = con.execute(query1, [str(parquet_path)]).fetchdf()
    parquet_time = time.perf_counter() - start

    print(f"  Query: Top 10 category/region by revenue")
    print(f"  Time: {parquet_time*1000:.1f}ms")
    print()
    print(result_parquet.to_string(index=False))
    print()

    # =========================================================================
    # STEP 3: Show that DuckDB CANNOT read Vortex natively
    # =========================================================================
    print("STEP 3: DuckDB Trying to Read Vortex (Native)")
    print("-" * 40)
    print("  Attempting: SELECT * FROM read_parquet('sales.vortex')...")
    try:
        con.execute(f"SELECT * FROM read_parquet('{vortex_path}') LIMIT 1").fetchdf()
        print("  Unexpected success!")
    except Exception as e:
        print(f"  FAILED: {type(e).__name__}")
        print("  DuckDB cannot read Vortex files natively!")
    print()

    # =========================================================================
    # STEP 4: DuckDB reading Vortex through Rosetta (THE BRIDGE!)
    # =========================================================================
    print("STEP 4: DuckDB Reading Vortex (via Rosetta Bridge)")
    print("-" * 40)

    import rosetta

    # Read Vortex file through Rosetta -> returns PyArrow Table
    # Then DuckDB can query it directly!
    start = time.perf_counter()
    vortex_table = rosetta.read(str(vortex_path))
    rosetta_read_time = time.perf_counter() - start

    print(f"  Rosetta read time: {rosetta_read_time*1000:.1f}ms")

    # DuckDB can query PyArrow tables directly
    query2 = """
        SELECT
            category,
            region,
            COUNT(*) as num_transactions,
            ROUND(SUM(quantity * unit_price * (1 - discount_pct)), 2) as total_revenue
        FROM vortex_table
        GROUP BY category, region
        ORDER BY total_revenue DESC
        LIMIT 10
    """

    start = time.perf_counter()
    result_vortex = con.execute(query2).fetchdf()
    duckdb_query_time = time.perf_counter() - start

    vortex_total_time = rosetta_read_time + duckdb_query_time

    print(f"  DuckDB query time: {duckdb_query_time*1000:.1f}ms")
    print(f"  Total time: {vortex_total_time*1000:.1f}ms")
    print()
    print(result_vortex.to_string(index=False))
    print()

    # =========================================================================
    # STEP 5: Verify results match
    # =========================================================================
    print("STEP 5: Verify Results Match")
    print("-" * 40)

    # Compare the two result sets
    match = result_parquet.equals(result_vortex)
    print(f"  Results identical: {match}")
    print()

    # =========================================================================
    # SUMMARY
    # =========================================================================
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print()
    print("File Sizes:")
    print(f"  Parquet: {format_size(parquet_size)}")
    print(f"  Vortex:  {format_size(vortex_size)} ({compression_ratio:.1f}x smaller)")
    print()
    print("Query Performance (aggregation over 1M rows):")
    print(f"  Parquet (native):      {parquet_time*1000:.1f}ms")
    print(f"  Vortex (via Rosetta):  {vortex_total_time*1000:.1f}ms")
    print()
    print("Key Insight:")
    print("  DuckDB CANNOT read Vortex natively - but Rosetta bridges the gap!")
    print("  You get Vortex's superior compression while using DuckDB's SQL engine.")
    print()
    print("The Bridge Value:")
    print("  Rosetta converts: Vortex -> PyArrow Table -> DuckDB query")
    print("  Same API works for: Parquet, Vortex, Lance")
    print()

    # =========================================================================
    # BONUS: Show predicate pushdown through Rosetta
    # =========================================================================
    print("=" * 70)
    print("BONUS: Filter Pushdown through Rosetta")
    print("=" * 70)
    print()

    # Read with filter pushdown
    print("Query: Electronics sales in 2024 with >15% discount")
    print()

    start = time.perf_counter()
    filtered = rosetta.read(
        str(vortex_path),
        columns=['transaction_id', 'category', 'region', 'unit_price', 'discount_pct'],
        filters=[
            ('category', '==', 'Electronics'),
            ('year', '==', 2024),
            ('discount_pct', '>', 0.15)
        ]
    )
    filter_time = time.perf_counter() - start

    print(f"  Rosetta filter pushdown time: {filter_time*1000:.1f}ms")
    print(f"  Rows matching filter: {filtered.num_rows:,}")
    print(f"  Columns returned: {filtered.column_names}")
    print()

    # Show sample of filtered data
    result_df = filtered.to_pandas().head(5)
    print("Sample results:")
    print(result_df.to_string(index=False))
    print()

    # Cleanup
    import shutil
    shutil.rmtree(tmpdir)

    print("Demo complete!")


if __name__ == "__main__":
    main()
