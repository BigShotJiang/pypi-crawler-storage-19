# Rosetta: Implementation Roadmap to 100%

This document outlines the remaining work to achieve 100% of the VISION.md goals.

---

## Gap Summary

| # | Gap | Current | Target | Complexity | Priority |
|---|-----|---------|--------|------------|----------|
| 1 | DataFusion TableProvider | 0% | 100% | Medium | P1 |
| 2 | Spark Schema Inference | Broken | Working | Low | P1 |
| 3 | Filter Pushdown Through Integrations | Not wired | Working | Medium | P1 |
| 4 | DuckDB Native Extension | 10% | 100% | High | P2 |
| 5 | Parquet Filter Pushdown | Deferred | Working | Medium | P2 |
| 6 | Performance Validation | 20% | 100% | Low | P3 |

---

## Implementation Plan

### 1. DataFusion TableProvider

**Goal**: Enable `SELECT * FROM rosetta('file.vortex')` in DataFusion queries.

**Files to create**:
- `src/datafusion/mod.rs` - Module root
- `src/datafusion/table_provider.rs` - TableProvider implementation
- `src/datafusion/exec.rs` - ExecutionPlan implementation

**Architecture**:
```rust
pub struct RosettaTableProvider {
    path: String,
    schema: SchemaRef,
    reader: Arc<UnifiedReader>,
}

impl TableProvider for RosettaTableProvider {
    fn schema(&self) -> SchemaRef;
    fn table_type(&self) -> TableType;
    fn scan(&self, ...) -> Result<Arc<dyn ExecutionPlan>>;
    fn supports_filters_pushdown(&self, filters: &[&Expr]) -> Result<Vec<TableProviderFilterPushDown>>;
}
```

**Key features**:
- Schema exposure from UnifiedReader
- Filter pushdown translation (DataFusion Expr → Rosetta Expr)
- Projection pushdown
- Partition-aware execution planning

---

### 2. Spark Schema Inference Fix

**Goal**: `RosettaDataSource.inferSchema()` returns actual schema, not null.

**File to modify**:
- `java/rosetta-spark/src/main/java/io/rosetta/spark/RosettaDataSource.java`

**Implementation**:
```java
@Override
public StructType inferSchema(CaseInsensitiveStringMap options) {
    String path = options.get("path");
    // Call JNI to get schema from Rosetta
    byte[] schemaBytes = RosettaNative.getSchema(path);
    // Convert Arrow schema to Spark StructType
    return ArrowSchemaConverter.toSparkSchema(schemaBytes);
}
```

**Required JNI additions**:
- `RosettaNative.getSchema(path)` → returns Arrow IPC schema bytes

---

### 3. Filter Pushdown Through Integrations

**Goal**: Filters from Spark/Iceberg actually reach format readers.

**Files to modify**:
- `java/rosetta-spark/src/main/java/io/rosetta/spark/RosettaScanBuilder.java`
- `java/rosetta-iceberg/src/main/java/io/rosetta/iceberg/RosettaInputFile.java`
- `src/ffi/jni.rs` - Add filter parameter to read functions

**Spark Implementation**:
```java
public class RosettaScanBuilder implements SupportsPushDownFilters {
    private Filter[] pushedFilters;

    @Override
    public Filter[] pushFilters(Filter[] filters) {
        // Convert Spark filters to Rosetta expression JSON
        this.pushedFilters = filters;
        return new Filter[0]; // All pushed
    }
}
```

**JNI Addition**:
```rust
#[no_mangle]
pub extern "system" fn Java_io_rosetta_jni_RosettaNative_readWithFilter(
    env: JNIEnv,
    _class: JClass,
    path: JString,
    filter_json: JString,  // New parameter
    columns: JObjectArray,
) -> jbyteArray
```

---

### 4. DuckDB Native Extension

**Goal**: `SELECT * FROM 'file.vortex'` works directly in DuckDB.

**Files to create**:
- `src/duckdb/scanner.rs` - Table function implementation
- `src/duckdb/replacement_scan.rs` - File extension replacement scan
- C header: `include/rosetta_duckdb.h`

**Architecture**:
```rust
// Register replacement scan for .vortex, .lance extensions
pub fn register_replacement_scan(db: &DuckDB) {
    db.register_replacement_scan("rosetta_scan", |path| {
        if is_rosetta_format(path) {
            Some(RosettaTableFunction::new(path))
        } else {
            None
        }
    });
}

// Table function that returns Arrow batches
pub struct RosettaTableFunction {
    reader: UnifiedReader,
    current_batch: Option<RecordBatch>,
}
```

**DuckDB C API Integration**:
```c
// rosetta_duckdb.h
DUCKDB_EXTENSION_API void rosetta_init(duckdb_database db);
DUCKDB_EXTENSION_API const char* rosetta_version();
```

---

### 5. Parquet Filter Pushdown

**Goal**: Filters actually skip row groups in Parquet files.

**File to modify**:
- `src/readers/parquet_reader.rs`

**Implementation**:
```rust
impl ParquetReader {
    pub fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult> {
        // Convert Rosetta Expr to Arrow RowFilter
        let arrow_filter = self.expr_to_arrow_filter(filter)?;

        // Store for use during read
        self.row_filter = Some(arrow_filter);

        Ok(FilterPushdownResult::Pushed)
    }

    fn expr_to_arrow_filter(&self, expr: &Expr) -> Result<ArrowPredicate> {
        // Build ArrowPredicate from expression
        match expr {
            Expr::BinaryExpr { left, op, right } => {
                // Create column projection + comparison
            }
            // ... other cases
        }
    }
}
```

**Arrow Filter API**:
```rust
use parquet::arrow::arrow_reader::{ArrowPredicate, RowFilter};

// Create predicate that evaluates on Arrow arrays
let predicate = ArrowPredicate::new(projection, filter_fn);
let row_filter = RowFilter::new(vec![predicate]);

// Apply during read
builder.with_row_filter(row_filter);
```

---

### 6. Performance Validation

**Goal**: Prove <5% overhead claim with published benchmarks.

**Files to create/modify**:
- `benches/native_comparison.rs` - Compare Rosetta vs native
- `BENCHMARKS.md` - Published results

**Benchmark scenarios**:
1. Full table scan (no pushdown)
2. Filtered scan (with pushdown)
3. Projected scan (column subset)
4. Large file (100MB+)

**Metrics to capture**:
- Throughput (rows/sec, MB/sec)
- Latency (p50, p99)
- Memory usage
- CPU utilization

---

## Implementation Order

### Phase 1: Core Gaps (High Impact)
1. ✅ DataFusion TableProvider
2. ✅ Spark Schema Inference
3. ✅ Filter Pushdown Wiring

### Phase 2: Advanced Features
4. ✅ Parquet Filter Pushdown
5. ✅ DuckDB Extension (basic)

### Phase 3: Validation
6. ✅ Performance Benchmarks

---

## Success Criteria

- [ ] All 6 gaps closed
- [ ] All existing tests pass (211+)
- [ ] New integration tests for each feature
- [ ] Benchmarks show <5% overhead
- [ ] Demo: Mixed-format query through DataFusion
- [ ] Demo: DuckDB reading Vortex natively

---

*Implementation starts below this line*
