#!/usr/bin/env python3
"""
Rosetta CLI: Swiss Army Knife for Columnar Formats

Real-world use cases:
1. Format migration (Parquet → Vortex)
2. Data validation (compare before/after)
3. Performance benchmarking
4. Data lake inventory
"""

import argparse
import sys
import time
from pathlib import Path
from typing import List, Optional

import pyarrow as pa
import pyarrow.parquet as pq

import rosetta


def cmd_info(args):
    """Show detailed information about a file."""
    path = args.path

    print(f"File: {path}")
    print("=" * 60)

    # Format detection
    fmt = rosetta.detect_format(path)
    print(f"Format: {fmt.value}")

    # File size
    p = Path(path)
    if p.exists():
        size = p.stat().st_size
        print(f"Size: {format_size(size)}")

    # Metadata
    info = rosetta.file_info(path)
    print(f"Rows: {info.get('num_rows', 'N/A'):,}")
    print(f"Columns: {info.get('num_columns', 'N/A')}")

    if 'num_row_groups' in info:
        print(f"Row Groups: {info['num_row_groups']}")
    if 'num_fragments' in info:
        print(f"Fragments: {info['num_fragments']}")

    # Schema
    print("\nSchema:")
    schema = info.get('schema')
    if schema:
        for field in schema:
            print(f"  {field.name}: {field.type}")


def cmd_convert(args):
    """Convert between formats."""
    src, dst = args.source, args.destination

    print(f"Converting: {src} → {dst}")

    # Detect formats
    src_fmt = rosetta.detect_format(src)
    dst_fmt = infer_format_from_extension(dst)

    print(f"  Source format: {src_fmt.value}")
    print(f"  Target format: {dst_fmt}")

    # Read source
    start = time.perf_counter()
    table = rosetta.read(src)
    read_time = time.perf_counter() - start
    print(f"  Read time: {read_time*1000:.1f}ms ({table.num_rows:,} rows)")

    # Write destination
    start = time.perf_counter()
    if dst_fmt == 'vortex':
        import vortex as vx
        vx.io.write(table, dst)
    elif dst_fmt == 'parquet':
        compression = args.compression or 'snappy'
        pq.write_table(table, dst, compression=compression)
    elif dst_fmt == 'lance':
        import lance
        lance.write_dataset(table, dst)
    else:
        print(f"Error: Unknown destination format: {dst_fmt}")
        return 1
    write_time = time.perf_counter() - start
    print(f"  Write time: {write_time*1000:.1f}ms")

    # Compare sizes
    src_size = Path(src).stat().st_size
    dst_path = Path(dst)
    if dst_path.is_dir():
        # Lance datasets are directories
        dst_size = sum(f.stat().st_size for f in dst_path.rglob('*') if f.is_file())
    else:
        dst_size = dst_path.stat().st_size

    ratio = src_size / dst_size if dst_size > 0 else 0
    print(f"\nSize comparison:")
    print(f"  Source: {format_size(src_size)}")
    print(f"  Target: {format_size(dst_size)}")
    if ratio > 1:
        print(f"  Compression: {ratio:.2f}x smaller")
    elif ratio < 1:
        print(f"  Expansion: {1/ratio:.2f}x larger")

    print("\nConversion complete!")
    return 0


def cmd_diff(args):
    """Compare two files for equality."""
    path1, path2 = args.file1, args.file2

    print(f"Comparing:")
    print(f"  File 1: {path1} ({rosetta.detect_format(path1).value})")
    print(f"  File 2: {path2} ({rosetta.detect_format(path2).value})")
    print()

    # Read both
    t1 = rosetta.read(path1)
    t2 = rosetta.read(path2)

    # Compare metadata
    print("Metadata:")
    print(f"  Rows:    {t1.num_rows:,} vs {t2.num_rows:,}", end="")
    print(" ✓" if t1.num_rows == t2.num_rows else " ✗ MISMATCH")

    print(f"  Columns: {t1.num_columns} vs {t2.num_columns}", end="")
    print(" ✓" if t1.num_columns == t2.num_columns else " ✗ MISMATCH")

    # Compare schemas
    schema_match = t1.schema.equals(t2.schema)
    print(f"  Schema:  ", end="")
    print("✓ Match" if schema_match else "✗ MISMATCH")

    if not schema_match:
        print("\n  Schema differences:")
        for f1, f2 in zip(t1.schema, t2.schema):
            if f1 != f2:
                print(f"    {f1.name}: {f1.type} vs {f2.type}")

    # Compare data
    print("\nData:")
    if t1.num_rows != t2.num_rows:
        print("  ✗ Cannot compare - row counts differ")
        return 1

    # Check each column
    all_match = True
    for col_name in t1.column_names:
        if col_name not in t2.column_names:
            print(f"  ✗ Column '{col_name}' missing in file 2")
            all_match = False
            continue

        col1 = t1.column(col_name)
        col2 = t2.column(col_name)

        if col1.equals(col2):
            if args.verbose:
                print(f"  ✓ {col_name}")
        else:
            print(f"  ✗ {col_name} - values differ")
            all_match = False

            # Show sample differences
            if args.verbose:
                arr1 = col1.to_pylist()
                arr2 = col2.to_pylist()
                diffs = [(i, a, b) for i, (a, b) in enumerate(zip(arr1, arr2)) if a != b]
                for i, a, b in diffs[:3]:
                    print(f"      Row {i}: {a} vs {b}")
                if len(diffs) > 3:
                    print(f"      ... and {len(diffs)-3} more differences")

    if all_match:
        print("  ✓ All columns match!")
        print("\nResult: FILES ARE IDENTICAL")
        return 0
    else:
        print("\nResult: FILES DIFFER")
        return 1


def cmd_bench(args):
    """Benchmark read performance across formats."""
    paths = args.files
    iterations = args.iterations

    print("Benchmark: Read Performance")
    print("=" * 60)

    results = []

    for path in paths:
        fmt = rosetta.detect_format(path)
        size = Path(path).stat().st_size

        # Warmup
        _ = rosetta.read(path)

        # Benchmark
        times = []
        for _ in range(iterations):
            start = time.perf_counter()
            table = rosetta.read(path)
            elapsed = time.perf_counter() - start
            times.append(elapsed)

        avg_time = sum(times) / len(times)
        min_time = min(times)
        throughput = (size / 1024 / 1024) / avg_time  # MB/s

        results.append({
            'path': path,
            'format': fmt.value,
            'size': size,
            'rows': table.num_rows,
            'avg_ms': avg_time * 1000,
            'min_ms': min_time * 1000,
            'throughput': throughput,
        })

        print(f"\n{Path(path).name} ({fmt.value})")
        print(f"  Size: {format_size(size)}")
        print(f"  Rows: {table.num_rows:,}")
        print(f"  Avg time: {avg_time*1000:.2f}ms")
        print(f"  Min time: {min_time*1000:.2f}ms")
        print(f"  Throughput: {throughput:.1f} MB/s")

    # Summary comparison
    if len(results) > 1:
        print("\n" + "=" * 60)
        print("COMPARISON SUMMARY")
        print("=" * 60)

        baseline = results[0]
        print(f"\nBaseline: {baseline['path']} ({baseline['format']})")

        for r in results[1:]:
            speedup = baseline['avg_ms'] / r['avg_ms']
            size_ratio = baseline['size'] / r['size']
            print(f"\nvs {r['path']} ({r['format']}):")
            print(f"  Speed: {speedup:.2f}x {'faster' if speedup > 1 else 'slower'}")
            print(f"  Size:  {size_ratio:.2f}x {'smaller' if size_ratio > 1 else 'larger'}")


def cmd_scan(args):
    """Scan a directory and inventory file formats."""
    path = Path(args.path)

    print(f"Scanning: {path}")
    print("=" * 60)

    formats = {
        'parquet': [],
        'vortex': [],
        'lance': [],
        'unknown': [],
    }

    total_size = 0

    for f in path.rglob('*'):
        if f.is_file():
            fmt = rosetta.detect_format(str(f))
            size = f.stat().st_size
            total_size += size

            if fmt == rosetta.FileFormat.PARQUET:
                formats['parquet'].append((f, size))
            elif fmt == rosetta.FileFormat.VORTEX:
                formats['vortex'].append((f, size))
            elif fmt == rosetta.FileFormat.LANCE:
                formats['lance'].append((f, size))
            # Skip unknown files
        elif f.is_dir():
            # Check for Lance datasets (directories with _versions/)
            if (f / '_versions').exists():
                size = sum(x.stat().st_size for x in f.rglob('*') if x.is_file())
                total_size += size
                formats['lance'].append((f, size))

    print(f"\nInventory:")
    for fmt_name, files in formats.items():
        if files:
            count = len(files)
            size = sum(s for _, s in files)
            print(f"  {fmt_name.upper():10} {count:5} files  {format_size(size):>10}")

    print(f"\n  {'TOTAL':10} {sum(len(f) for f in formats.values()):5} files  {format_size(total_size):>10}")

    if args.verbose:
        print("\nDetails:")
        for fmt_name, files in formats.items():
            if files:
                print(f"\n  {fmt_name.upper()}:")
                for f, size in sorted(files, key=lambda x: -x[1])[:10]:
                    print(f"    {format_size(size):>10}  {f}")
                if len(files) > 10:
                    print(f"    ... and {len(files) - 10} more")


def format_size(bytes_size: int) -> str:
    """Format bytes as human-readable size."""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.1f} TB"


def infer_format_from_extension(path: str) -> str:
    """Infer format from file extension."""
    p = Path(path)
    ext = p.suffix.lower()
    if ext in ('.parquet', '.pq'):
        return 'parquet'
    elif ext in ('.vortex', '.vtx'):
        return 'vortex'
    elif ext == '.lance' or path.endswith('.lance'):
        return 'lance'
    return 'unknown'


def main():
    parser = argparse.ArgumentParser(
        prog='rosetta',
        description='Swiss Army Knife for Columnar Formats',
    )
    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # info
    p_info = subparsers.add_parser('info', help='Show file information')
    p_info.add_argument('path', help='Path to file')

    # convert
    p_convert = subparsers.add_parser('convert', help='Convert between formats')
    p_convert.add_argument('source', help='Source file')
    p_convert.add_argument('destination', help='Destination file')
    p_convert.add_argument('--compression', '-c', help='Compression codec (parquet only)')

    # diff
    p_diff = subparsers.add_parser('diff', help='Compare two files')
    p_diff.add_argument('file1', help='First file')
    p_diff.add_argument('file2', help='Second file')
    p_diff.add_argument('--verbose', '-v', action='store_true', help='Show details')

    # bench
    p_bench = subparsers.add_parser('bench', help='Benchmark read performance')
    p_bench.add_argument('files', nargs='+', help='Files to benchmark')
    p_bench.add_argument('--iterations', '-n', type=int, default=5, help='Number of iterations')

    # scan
    p_scan = subparsers.add_parser('scan', help='Scan directory for columnar files')
    p_scan.add_argument('path', help='Directory to scan')
    p_scan.add_argument('--verbose', '-v', action='store_true', help='Show file details')

    args = parser.parse_args()

    if args.command == 'info':
        return cmd_info(args)
    elif args.command == 'convert':
        return cmd_convert(args)
    elif args.command == 'diff':
        return cmd_diff(args)
    elif args.command == 'bench':
        return cmd_bench(args)
    elif args.command == 'scan':
        return cmd_scan(args)
    else:
        parser.print_help()
        return 0


if __name__ == '__main__':
    sys.exit(main() or 0)
