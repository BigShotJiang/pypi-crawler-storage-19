/* SPDX-License-Identifier: Apache-2.0 */
/* Copyright 2026 Rosetta Contributors */

/**
 * @file rosetta.h
 * @brief C FFI bindings for Rosetta - Universal File Format Bridge
 *
 * This header provides the C interface for Rosetta, enabling integration
 * with JVM (via JNI), Python (via ctypes/cffi), and other languages.
 *
 * Thread Safety:
 *   All functions are thread-safe. The Rosetta runtime uses internal
 *   synchronization and can be called from multiple threads.
 *
 * Memory Management:
 *   Memory returned by Rosetta functions must be freed using the
 *   corresponding rosetta_free_* functions.
 *
 * Error Handling:
 *   Functions that can fail return a result struct containing either
 *   the result or an error message. Always check error_message before
 *   using the result.
 */

#ifndef ROSETTA_H
#define ROSETTA_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ==========================================================================
 * Result Types
 * ========================================================================== */

/**
 * Result of a Rosetta operation that returns bytes
 */
typedef struct {
    /** Pointer to the data (NULL if error) */
    uint8_t* data;
    /** Length of the data */
    size_t len;
    /** Error message (NULL if success). Must be freed with rosetta_string_free() */
    char* error_message;
} RosettaBytesResult;

/**
 * Result of a Rosetta operation that returns a string
 */
typedef struct {
    /** The string value (NULL if error). Must be freed with rosetta_string_free() */
    char* value;
    /** Error message (NULL if success). Must be freed with rosetta_string_free() */
    char* error_message;
} RosettaStringResult;

/**
 * Result of a Rosetta operation that returns a boolean
 */
typedef struct {
    /** The boolean value */
    bool value;
    /** Error message (NULL if success). Must be freed with rosetta_string_free() */
    char* error_message;
} RosettaBoolResult;

/**
 * Result of a Rosetta operation that returns a size
 */
typedef struct {
    /** The size value */
    uint64_t value;
    /** Error message (NULL if success). Must be freed with rosetta_string_free() */
    char* error_message;
} RosettaSizeResult;

/* ==========================================================================
 * Enumerations
 * ========================================================================== */

/**
 * File format enumeration
 */
typedef enum {
    /** Unknown or undetectable format */
    ROSETTA_FORMAT_UNKNOWN = 0,
    /** Apache Parquet v1 (legacy encodings) */
    ROSETTA_FORMAT_PARQUET_V1 = 1,
    /** Apache Parquet v2 (modern encodings) */
    ROSETTA_FORMAT_PARQUET_V2 = 2,
    /** Vortex columnar format */
    ROSETTA_FORMAT_VORTEX = 3,
    /** Lance format */
    ROSETTA_FORMAT_LANCE = 4,
    /** F3 format with embedded WASM */
    ROSETTA_FORMAT_F3 = 5,
    /** FastLanes format */
    ROSETTA_FORMAT_FASTLANES = 6,
} RosettaFormat;

/* ==========================================================================
 * Opaque Handle Types
 * ========================================================================== */

/** Opaque handle to a RosettaFileIO instance */
typedef struct RosettaFileIOHandle RosettaFileIOHandle;

/** Opaque handle to a Transcoder instance */
typedef struct RosettaTranscoderHandle RosettaTranscoderHandle;

/* ==========================================================================
 * Version Information
 * ========================================================================== */

/**
 * Get the Rosetta library version
 *
 * @return A null-terminated string containing the version. Do NOT free this string.
 */
const char* rosetta_version(void);

/* ==========================================================================
 * FileIO Functions
 * ========================================================================== */

/**
 * Create a new RosettaFileIO with default configuration
 *
 * @return Pointer to the FileIO handle, or NULL on error.
 *         Must be freed with rosetta_fileio_free()
 */
RosettaFileIOHandle* rosetta_fileio_new(void);

/**
 * Free a RosettaFileIO handle
 *
 * @param handle Valid pointer returned by rosetta_fileio_new(), or NULL (no-op)
 * @post handle must not be used after this call
 */
void rosetta_fileio_free(RosettaFileIOHandle* handle);

/**
 * Check if a file should be transcoded based on its extension
 *
 * @param handle Valid FileIO handle
 * @param path Null-terminated UTF-8 file path
 * @return true if the file should be transcoded, false otherwise
 */
bool rosetta_fileio_should_transcode(
    const RosettaFileIOHandle* handle,
    const char* path
);

/**
 * Read a file, transcoding to Parquet v1 if necessary
 *
 * This is the main entry point for reading files. If the file is in a
 * non-Parquet format (Vortex, Lance, F3), it will be automatically
 * transcoded to Parquet v1 bytes.
 *
 * @param handle Valid FileIO handle
 * @param path Null-terminated UTF-8 file path
 * @return Result containing file bytes or error.
 *         Bytes must be freed with rosetta_bytes_free()
 */
RosettaBytesResult rosetta_fileio_read(
    const RosettaFileIOHandle* handle,
    const char* path
);

/**
 * Check if a file exists
 *
 * @param handle Valid FileIO handle
 * @param path Null-terminated UTF-8 file path
 * @return Result containing existence status or error
 */
RosettaBoolResult rosetta_fileio_exists(
    const RosettaFileIOHandle* handle,
    const char* path
);

/**
 * Get the length of a file
 *
 * @param handle Valid FileIO handle
 * @param path Null-terminated UTF-8 file path
 * @return Result containing file length or error
 */
RosettaSizeResult rosetta_fileio_length(
    const RosettaFileIOHandle* handle,
    const char* path
);

/**
 * Write bytes to a file
 *
 * @param handle Valid FileIO handle
 * @param path Null-terminated UTF-8 file path
 * @param data Pointer to bytes to write (may be NULL if len is 0)
 * @param len Number of bytes to write
 * @return Result containing success status or error
 */
RosettaBoolResult rosetta_fileio_write(
    const RosettaFileIOHandle* handle,
    const char* path,
    const uint8_t* data,
    size_t len
);

/**
 * Delete a file
 *
 * @param handle Valid FileIO handle
 * @param path Null-terminated UTF-8 file path
 * @return Result containing success status or error
 */
RosettaBoolResult rosetta_fileio_delete(
    const RosettaFileIOHandle* handle,
    const char* path
);

/**
 * Clear the FileIO cache
 *
 * @param handle Valid FileIO handle
 */
void rosetta_fileio_clear_cache(const RosettaFileIOHandle* handle);

/* ==========================================================================
 * Format Detection Functions
 * ========================================================================== */

/**
 * Detect the format of a file by path
 *
 * This function reads the file header/footer to determine the format.
 *
 * @param path Null-terminated UTF-8 file path
 * @return Detected format, or ROSETTA_FORMAT_UNKNOWN if unrecognized
 */
RosettaFormat rosetta_detect_format(const char* path);

/**
 * Detect the format of data by examining header bytes
 *
 * For Parquet detection (which requires both header and footer),
 * use rosetta_detect_format_from_header_footer() instead.
 *
 * @param data Pointer to header bytes
 * @param len Length of header bytes (minimum 4)
 * @return Detected format, or ROSETTA_FORMAT_UNKNOWN if unrecognized
 */
RosettaFormat rosetta_detect_format_from_bytes(
    const uint8_t* data,
    size_t len
);

/**
 * Detect the format of data by examining both header and footer bytes
 *
 * This is useful for Parquet detection which requires both header and footer.
 *
 * @param header Pointer to header bytes
 * @param header_len Length of header bytes (minimum 4)
 * @param footer Pointer to footer bytes (may be NULL)
 * @param footer_len Length of footer bytes
 * @return Detected format, or ROSETTA_FORMAT_UNKNOWN if unrecognized
 */
RosettaFormat rosetta_detect_format_from_header_footer(
    const uint8_t* header,
    size_t header_len,
    const uint8_t* footer,
    size_t footer_len
);

/* ==========================================================================
 * Transcoder Functions
 * ========================================================================== */

/**
 * Create a new Transcoder with default options
 *
 * @return Pointer to the Transcoder handle.
 *         Must be freed with rosetta_transcoder_free()
 */
RosettaTranscoderHandle* rosetta_transcoder_new(void);

/**
 * Free a Transcoder handle
 *
 * @param handle Valid pointer returned by rosetta_transcoder_new(), or NULL (no-op)
 * @post handle must not be used after this call
 */
void rosetta_transcoder_free(RosettaTranscoderHandle* handle);

/**
 * Transcode a file to Parquet v1 bytes
 *
 * @param handle Valid Transcoder handle
 * @param path Null-terminated UTF-8 file path
 * @return Result containing Parquet v1 bytes or error.
 *         Bytes must be freed with rosetta_bytes_free()
 */
RosettaBytesResult rosetta_transcoder_transcode_file(
    const RosettaTranscoderHandle* handle,
    const char* path
);

/**
 * Transcode a file to Parquet v1 bytes with optional filter
 *
 * @param handle Valid Transcoder handle
 * @param path Null-terminated UTF-8 file path
 * @param filter_json Null-terminated JSON expression string (or NULL for no filter)
 * @return Result containing Parquet v1 bytes or error.
 *         Bytes must be freed with rosetta_bytes_free()
 */
RosettaBytesResult rosetta_transcoder_transcode_file_with_filter(
    const RosettaTranscoderHandle* handle,
    const char* path,
    const char* filter_json
);

/* ==========================================================================
 * Schema Functions
 * ========================================================================== */

/**
 * Get the Arrow schema of a file as JSON
 *
 * @param path Null-terminated UTF-8 file path
 * @return Result containing JSON schema string or error.
 *         String must be freed with rosetta_string_free()
 */
RosettaStringResult rosetta_get_schema_json(const char* path);

/**
 * Get statistics for a file as JSON
 *
 * @param path Null-terminated UTF-8 file path
 * @return Result containing JSON statistics string or error.
 *         String must be freed with rosetta_string_free()
 */
RosettaStringResult rosetta_get_statistics_json(const char* path);

/* ==========================================================================
 * Memory Management Functions
 * ========================================================================== */

/**
 * Free bytes returned by Rosetta functions
 *
 * @param data Pointer to bytes returned by a Rosetta function, or NULL (no-op)
 * @param len Length of the bytes
 * @post data must not be used after this call
 */
void rosetta_bytes_free(uint8_t* data, size_t len);

/**
 * Free a string returned by Rosetta functions
 *
 * @param s Pointer to string returned by a Rosetta function, or NULL (no-op)
 * @post s must not be used after this call
 */
void rosetta_string_free(char* s);

#ifdef __cplusplus
}
#endif

#endif /* ROSETTA_H */
