# Rosetta Implementation Gaps Analysis

> **Last Updated**: 2026-01-08
> **Status**: Active implementation in progress

This document tracks the gap between VISION.md and actual implementation.

---

## Executive Summary

**Overall Completion: ~45%**

We built the skeleton (trait definitions, struct layouts) but not the muscle (actual pushdown, translation, statistics extraction).

---

## Critical Gaps

### 1. Filter Pushdown - NOT IMPLEMENTED (0%)

**Problem**: All readers use the default implementation that returns `NotPushed`:

```rust
// Current state - ALL readers use this default:
fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult> {
    Ok(FilterPushdownResult::NotPushed(Box::new(filter.clone())))
}
```

**Required**:
- [ ] ParquetReader: Translate `Expr` → `arrow_rs::parquet::arrow::arrow_reader::RowFilter`
- [ ] VortexReader: Translate `Expr` → `vortex::expr::Expr`, call `.with_filter()`
- [ ] LanceReader: Translate `Expr` → SQL string, call `.filter()`

**Files to create/modify**:
- `src/expr/to_parquet.rs` - Expr → Parquet predicate
- `src/expr/to_vortex.rs` - Expr → Vortex expression
- `src/expr/to_lance.rs` - Expr → SQL string
- `src/readers/parquet_reader.rs` - Override push_filter()
- `src/readers/vortex_reader.rs` - Override push_filter()
- `src/readers/lance_reader.rs` - Override push_filter()

---

### 2. Expression Translation - NOT IMPLEMENTED (0%)

**Problem**: We have `Expr` enum but no code to translate to native formats.

**VISION.md promises**:
```rust
let filter = col("age").gt(lit(30)).and(col("status").eq(lit("active")));

// → Parquet (arrow-rs): RowFilter
// → Vortex: vortex::expr::Expr
// → Lance: SQL string "age > 30 AND status = 'active'"
```

**Required translations**:

| Source | Target | Status |
|--------|--------|--------|
| `Expr` | `parquet::arrow::RowFilter` | NOT DONE |
| `Expr` | `vortex::expr::Expr` | NOT DONE |
| `Expr` | SQL String | NOT DONE |

---

### 3. Statistics Extraction - INCOMPLETE (30%)

| Reader | Status | Notes |
|--------|--------|-------|
| ParquetReader | ✅ 100% | Extracts from Parquet metadata |
| VortexReader | ❌ 10% | Returns `None` for all values - Vortex HAS stats internally |
| LanceReader | ❌ 10% | Returns `None` for all values - Lance HAS fragment stats |

**Required**:
- [ ] VortexReader: Extract stats from Vortex file metadata
- [ ] LanceReader: Extract stats from Lance fragment metadata

---

### 4. UnifiedReader - INCOMPLETE (50%)

**Missing methods**:
```rust
// NOT EXPOSED in UnifiedReader:
pub fn statistics(&self) -> Option<Statistics>
pub fn partitions(&self) -> Result<Vec<Partition>>
pub fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult>
pub fn push_projection(&mut self, columns: &[String]) -> Result<()>
```

**File**: `src/readers/unified.rs`

---

### 5. Python Bindings - INCOMPLETE (40%)

**Missing from Python API**:
```python
# NOT EXPOSED:
rosetta.statistics(path)                    # Get file statistics
rosetta.partitions(path)                    # Get partition info
rosetta.read(path, filter="age > 30")       # Filter pushdown
rosetta.Expr                                # Expression builder class
```

**File**: `src/python.rs`

---

### 6. Object Store Streaming - INCOMPLETE

| Reader | Local Files | Object Store (S3/GCS) |
|--------|-------------|----------------------|
| ParquetReader | ✅ | ❌ Downloads entire file |
| VortexReader | ✅ | ✅ Streaming with range requests |
| LanceReader | ✅ | ❌ Local only |

**Required**:
- [ ] ParquetReader: Add `from_object_store()` with range request support
- [ ] LanceReader: Add object store support

---

### 7. Tests - NOT WRITTEN (0%)

**Missing test coverage**:
- [ ] Filter pushdown actually reduces bytes read
- [ ] Expression translation correctness
- [ ] Statistics accuracy vs manual calculation
- [ ] Partition information correctness

---

### 8. Benchmarks - NOT WRITTEN (0%)

**Missing benchmarks**:
- [ ] Filter pushdown vs full scan
- [ ] Projection pushdown vs full read
- [ ] Statistics retrieval overhead

---

## Implementation Checklist

### Phase 1: Expression Translation (CRITICAL)
- [ ] Create `src/expr/mod.rs` as module with translations
- [ ] Implement `Expr::to_parquet_predicate()`
- [ ] Implement `Expr::to_vortex_expr()`
- [ ] Implement `Expr::to_lance_sql()`
- [ ] Add tests for each translation

### Phase 2: Reader Push Filter Implementation
- [ ] ParquetReader: Store filter, apply via RowFilter in read methods
- [ ] VortexReader: Translate filter, use scanner.with_filter()
- [ ] LanceReader: Translate filter, use scanner.filter()
- [ ] Update FormatReader impl blocks to call actual implementations

### Phase 3: Complete Statistics
- [ ] VortexReader: Extract real statistics from Vortex metadata
- [ ] LanceReader: Extract real statistics from Lance fragments

### Phase 4: UnifiedReader Completion
- [ ] Add statistics() method
- [ ] Add partitions() method
- [ ] Add push_filter() method (requires making inner mutable)
- [ ] Add push_projection() method

### Phase 5: Python Bindings
- [ ] Add statistics() function
- [ ] Add partitions() function
- [ ] Add filter parameter to read()
- [ ] Consider PyExpr class for expression building

### Phase 6: Tests & Benchmarks
- [ ] Integration tests for filter pushdown
- [ ] Benchmarks comparing pushdown vs no pushdown
- [ ] Test that filtered reads return fewer bytes

---

## Detailed Implementation Notes

### Parquet Filter Pushdown

```rust
// In parquet_reader.rs
use parquet::arrow::arrow_reader::{ArrowPredicate, RowFilter};

impl ParquetReader {
    pub fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult> {
        // Store the filter for use in read methods
        self.filter = Some(filter.clone());

        // Convert to ArrowPredicate
        let predicate = expr_to_arrow_predicate(filter, &self.schema)?;
        self.row_filter = Some(RowFilter::new(vec![predicate]));

        Ok(FilterPushdownResult::Pushed)
    }
}
```

### Vortex Filter Pushdown

```rust
// In vortex_reader.rs
use vortex::expr::{BinaryExpr, Column, Literal, Operator as VortexOp};

impl VortexReader {
    pub fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult> {
        let vortex_expr = expr_to_vortex(filter)?;
        self.filter = Some(vortex_expr);
        Ok(FilterPushdownResult::Pushed)
    }

    // Then in read methods:
    // scanner.with_filter(self.filter.clone())
}
```

### Lance Filter Pushdown

```rust
// In lance_reader.rs
impl LanceReader {
    pub fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult> {
        let sql = expr_to_sql(filter);
        self.filter_sql = Some(sql);
        Ok(FilterPushdownResult::Pushed)
    }

    // Then in read methods:
    // scanner.filter(&self.filter_sql.unwrap())
}
```

---

## Priority Order

1. **Expression Translation** - Without this, nothing else works
2. **Reader push_filter()** - Core value proposition
3. **UnifiedReader methods** - User-facing API
4. **Python bindings** - User accessibility
5. **Statistics completion** - Query optimization
6. **Tests & Benchmarks** - Validation

---

## References

- [VISION.md](./VISION.md) - The north star
- [CLAUDE.md](./CLAUDE.md) - Development guidelines
- [src/expr.rs](./src/expr.rs) - Expression types (exists, needs translation)
- [src/readers/mod.rs](./src/readers/mod.rs) - FormatReader trait
