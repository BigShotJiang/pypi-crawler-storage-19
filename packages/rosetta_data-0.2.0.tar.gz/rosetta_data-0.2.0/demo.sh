#!/bin/bash
# Rosetta Demo Script
# Demonstrates the core capabilities of Rosetta

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}     Rosetta - Universal File Bridge    ${NC}"
echo -e "${BLUE}========================================${NC}"
echo

# Check for rosetta binary
if [ ! -f "./target/release/rosetta" ]; then
    echo -e "${YELLOW}Building rosetta in release mode...${NC}"
    cargo build --release --quiet
fi

ROSETTA="./target/release/rosetta"

# Use venv Python if available
if [ -f ".venv/bin/python" ]; then
    PYTHON=".venv/bin/python"
else
    PYTHON="python3"
fi

# Create demo directory
DEMO_DIR=$(mktemp -d)
trap "rm -rf $DEMO_DIR" EXIT

echo -e "${GREEN}1. Creating sample data...${NC}"
echo

# Create sample Parquet file using Python
$PYTHON -c "
import pyarrow as pa
import pyarrow.parquet as pq
import os
table = pa.table({
    'id': list(range(10000)),
    'name': [f'user_{i}' for i in range(10000)],
    'email': [f'user_{i}@example.com' for i in range(10000)],
    'score': [float(i % 100) for i in range(10000)],
    'active': [i % 2 == 0 for i in range(10000)],
})
pq.write_table(table, '$DEMO_DIR/users.parquet')
print('Created $DEMO_DIR/users.parquet with 10000 rows')
"

echo
echo -e "${GREEN}2. Format Detection${NC}"
echo -e "${YELLOW}rosetta detect users.parquet${NC}"
echo
$ROSETTA detect $DEMO_DIR/users.parquet

echo
echo -e "${GREEN}3. File Information${NC}"
echo -e "${YELLOW}rosetta info users.parquet${NC}"
echo
$ROSETTA info $DEMO_DIR/users.parquet

echo
echo -e "${GREEN}4. Reading Data with Column Projection${NC}"
echo -e "${YELLOW}rosetta read users.parquet --columns id,name,score --limit 5${NC}"
echo
$ROSETTA read $DEMO_DIR/users.parquet --columns id,name,score --limit 5

echo
echo -e "${GREEN}5. File Conversion${NC}"
echo -e "${YELLOW}rosetta convert users.parquet users_copy.parquet${NC}"
echo
$ROSETTA convert $DEMO_DIR/users.parquet $DEMO_DIR/users_copy.parquet

echo
echo -e "${GREEN}6. Performance Benchmark${NC}"
echo -e "${YELLOW}rosetta bench users.parquet --iterations 10${NC}"
echo
$ROSETTA bench $DEMO_DIR/users.parquet --iterations 10

echo
echo -e "${GREEN}7. Python API Demo${NC}"
echo -e "${YELLOW}Using rosetta from Python...${NC}"
echo
$PYTHON << EOF
import rosetta

# Detect format
print("Detecting format...")
fmt = rosetta.detect_format("$DEMO_DIR/users.parquet")
print(f"  Format: {fmt.name}")
print(f"  Extension: .{fmt.extension}")
print()

# Get file info
print("Getting file info...")
info = rosetta.file_info("$DEMO_DIR/users.parquet")
print(f"  Row groups: {info['num_row_groups']}")
print(f"  Schema: {info['schema'].names}")
print()

# Read full table
print("Reading full table...")
table = rosetta.read("$DEMO_DIR/users.parquet")
print(f"  Rows: {table.num_rows}")
print(f"  Columns: {table.num_columns}")
print()

# Read with projection
print("Reading with projection (id, name)...")
table = rosetta.read("$DEMO_DIR/users.parquet", columns=["id", "name"])
print(f"  Columns: {table.column_names}")
print()

# Read as batches
print("Reading as batches...")
batches = rosetta.read_batches("$DEMO_DIR/users.parquet")
print(f"  Number of batches: {len(batches)}")
print(f"  Total rows: {sum(b.num_rows for b in batches)}")
print()

print("Python API demo complete!")
EOF

echo
echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}           Demo Complete!               ${NC}"
echo -e "${BLUE}========================================${NC}"
echo
echo "Rosetta provides:"
echo "  - Unified API for multiple columnar formats"
echo "  - Near-zero overhead Parquet passthrough"
echo "  - Column projection for efficient reads"
echo "  - Easy format detection and conversion"
echo "  - Both Rust and Python interfaces"
echo
echo "For more information, see README.md"
