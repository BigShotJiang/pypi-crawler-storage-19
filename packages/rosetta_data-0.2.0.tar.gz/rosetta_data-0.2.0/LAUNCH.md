# Rosetta Launch Plan

> **Goal**: A data engineer finds the repo and has working code in 5 minutes.

---

## The Brutal Truth

**You only launch once.**

- First HN post? One shot.
- First tweet? One shot.
- Someone tries it, fails, tweets "this is broken"? Damage done forever.

The difference between "cool project that never got traction" and "essential infrastructure" is the **first 5 minutes of user experience**.

---

## The 5-Minute Test

If someone can't go from "found your repo" to "working code" in 5 minutes, they leave and never come back.

**What they'll try:**
```bash
pip install rosetta
```

```python
import rosetta
df = rosetta.read("data.vortex")
print(df)
```

**This must work. On the first try. On any machine.**

---

## Minimum Viable DevEx Checklist

### Tier 1: Absolute Minimum (Week 1)

These are **non-negotiable** before any public mention:

| Task | Status | Owner | Notes |
|------|--------|-------|-------|
| `pip install rosetta` works on Mac ARM | ☐ | | M1/M2/M3 Macs |
| `pip install rosetta` works on Mac Intel | ☐ | | Older Macs |
| `pip install rosetta` works on Linux | ☐ | | manylinux wheels |
| `pip install rosetta` works on Windows | ☐ | | Optional for v1 |
| `import rosetta` has no errors | ☐ | | Clean import |
| `rosetta.read("test.parquet")` returns data | ☐ | | Core functionality |
| `rosetta.read("test.vortex")` returns data | ☐ | | Key differentiator |
| README has working copy-paste example | ☐ | | First impression |
| Error messages are helpful, not stack traces | ☐ | | User trust |

### Tier 2: Credibility (Week 2)

These make people trust the project is real:

| Task | Status | Owner | Notes |
|------|--------|-------|-------|
| `cargo add rosetta` works (crates.io) | ☐ | | Rust ecosystem |
| CI badges in README (build passing) | ☐ | | Trust signal |
| LICENSE file (Apache 2.0) | ☐ | | Legal clarity |
| CONTRIBUTING.md | ☐ | | Contributor onboarding |
| `examples/` directory with runnable code | ☐ | | Learning path |
| Benchmark results linked in README | ☐ | | Proof of value |
| GitHub releases with changelogs | ☐ | | Version tracking |

### Tier 3: Ecosystem (Week 3)

These expand reach beyond Python:

| Task | Status | Owner | Notes |
|------|--------|-------|-------|
| DuckDB extension installable | ☐ | | Or clear build docs |
| Spark JAR on Maven Central | ☐ | | Or GitHub releases |
| Integration guide: DuckDB | ☐ | | Step-by-step |
| Integration guide: Spark | ☐ | | Step-by-step |
| Integration guide: Iceberg | ☐ | | Step-by-step |
| Integration guide: DataFusion | ☐ | | Step-by-step |
| Quickstart tutorial (10 min) | ☐ | | End-to-end guide |

---

## Week 1 Execution Plan

### Day 1-2: Python Package (Critical Path)

**Goal**: This works on a fresh machine:
```bash
pip install rosetta
python -c "import rosetta; print(rosetta.read('test.parquet'))"
```

**Tasks**:

1. **GitHub Actions Workflow**
   - [ ] Create `.github/workflows/python-wheels.yml`
   - [ ] Set up maturin for cross-platform builds
   - [ ] Configure cibuildwheel for maximum compatibility

2. **Build Wheels**
   - [ ] manylinux_2_28 wheels (Linux x86_64)
   - [ ] macos-arm64 wheels (Apple Silicon)
   - [ ] macos-x86_64 wheels (Intel Macs)
   - [ ] (Optional) Windows wheels

3. **PyPI Publishing**
   - [ ] Create PyPI account / get credentials
   - [ ] Test on TestPyPI first
   - [ ] Publish to PyPI
   - [ ] Verify `pip install rosetta` works

4. **Smoke Test**
   - [ ] Test on fresh Mac (ARM)
   - [ ] Test on fresh Mac (Intel)
   - [ ] Test on fresh Linux (Ubuntu)
   - [ ] Test on fresh Linux (Amazon Linux)

### Day 3: README Rewrite

**Current state**: Developer-focused, assumes context.

**Target state**: User-focused, zero assumptions.

```markdown
# Rosetta

**Read any columnar format from any tool.**

Vortex, Lance, Parquet — one API.

## Install

```bash
pip install rosetta
```

## Quick Start

```python
import rosetta

# Read any format - Rosetta auto-detects
df = rosetta.read("data.parquet")
df = rosetta.read("data.vortex")   # Same API!
df = rosetta.read("data.lance")    # Same API!

# Convert to pandas
pandas_df = df.to_pandas()
```

## Why Rosetta?

| Format | Scan Speed | Point Lookup | Your Tools Support It? |
|--------|------------|--------------|------------------------|
| Parquet | Baseline | Slow | Yes |
| Vortex | 10-20x faster | Slow | No |
| Lance | Fast | 2000x faster | No |

**The problem**: New formats are faster, but your tools only speak Parquet.

**The solution**: Rosetta bridges the gap. Your code doesn't change.

## Filter Pushdown

Rosetta pushes filters to native readers for maximum performance:

```python
from rosetta import col, lit

# This filter runs IN the Vortex reader, not after
df = rosetta.read(
    "data.vortex",
    filter=col("status").eq(lit("active"))
)
```

## Integrations

Rosetta works with your existing tools:

- **DuckDB**: `SELECT * FROM 'data.vortex'`
- **Spark**: `spark.read.format("rosetta").load(...)`
- **Iceberg**: Mixed Parquet + Vortex tables
- **DataFusion**: Native TableProvider

See [Integration Guides](docs/integrations/) for details.

## Performance

Rosetta has <5% overhead vs native format libraries:

| Operation | Native | Rosetta | Overhead |
|-----------|--------|---------|----------|
| Parquet read (1M rows) | 28ms | 23ms | -18% (faster) |
| Vortex read (1M rows) | 15ms | 16ms | +7% |

See [Benchmarks](BENCHMARKS.md) for methodology.

## License

Apache 2.0
```

### Day 4: Error Messages Audit

**Goal**: Every error helps the user fix the problem.

**Bad**:
```
RosettaError: Failed to open file
```

**Good**:
```
RosettaError: Cannot read 'data.vortex'

  File not found: /Users/you/project/data.vortex

  Did you mean one of these?
    - /Users/you/project/data.parquet
    - /Users/you/project/test.vortex

  Hint: Use an absolute path or check the file exists.
```

**Audit checklist**:
- [ ] File not found errors
- [ ] Permission denied errors
- [ ] Invalid format errors
- [ ] Unsupported feature errors
- [ ] Network/S3 errors
- [ ] Import errors (missing dependencies)

### Day 5: Integration Smoke Tests

**Goal**: CI proves the README examples work.

```python
# tests/test_quickstart.py
"""Tests that verify README examples work exactly as shown."""

import pytest
import rosetta

class TestReadmeExamples:
    """The README code blocks must work."""

    def test_basic_read_parquet(self, sample_parquet):
        """Quick Start example: read parquet."""
        df = rosetta.read(sample_parquet)
        assert len(df) > 0

    def test_basic_read_vortex(self, sample_vortex):
        """Quick Start example: read vortex."""
        df = rosetta.read(sample_vortex)
        assert len(df) > 0

    def test_filter_pushdown(self, sample_parquet):
        """Filter Pushdown example."""
        from rosetta import col, lit

        df = rosetta.read(
            sample_parquet,
            filter=col("id").gt(lit(5))
        )
        assert len(df) > 0

    def test_to_pandas(self, sample_parquet):
        """Pandas conversion example."""
        df = rosetta.read(sample_parquet)
        pandas_df = df.to_pandas()
        assert len(pandas_df) > 0
```

---

## Launch Sequence

### Phase 1: Soft Launch (After Week 1)

- [x] GitHub repo public
- [ ] `pip install rosetta` works
- [ ] README is user-focused
- [ ] No promotion yet
- [ ] Gather feedback from early discoverers

### Phase 2: Community Seeding (Week 2)

- [ ] Post in relevant Discord servers (Data Engineering, Rust)
- [ ] Tweet from personal account (not official launch)
- [ ] Share with 5-10 trusted data engineers for feedback
- [ ] Fix issues they find

### Phase 3: Hard Launch (Week 3)

- [ ] Blog post published
- [ ] Hacker News submission
- [ ] Reddit r/dataengineering post
- [ ] Twitter/X announcement thread
- [ ] LinkedIn post
- [ ] Reach out to data influencers

---

## Success Metrics

### Week 1 (Soft Launch)
- [ ] 10+ GitHub stars (organic)
- [ ] 0 "installation failed" issues
- [ ] 5+ successful pip installs (from logs)

### Week 2 (Community Seeding)
- [ ] 50+ GitHub stars
- [ ] 3+ external contributors
- [ ] 10+ issues filed (engagement signal)

### Week 3 (Hard Launch)
- [ ] 500+ GitHub stars
- [ ] HN front page (ideally)
- [ ] 100+ pip installs/day
- [ ] 5+ blog posts/tweets mentioning Rosetta

---

## Risk Mitigation

| Risk | Likelihood | Mitigation |
|------|------------|------------|
| pip install fails on some platform | High | Test on fresh VMs before launch |
| README example doesn't work | Medium | CI test that runs README code |
| HN post gets buried | Medium | Have backup launch channels ready |
| Negative feedback on architecture | Low | Engage thoughtfully, iterate |
| Name collision (another "rosetta") | Medium | Check PyPI, crates.io before publish |

---

## The Question to Ask Every Day

> "If I were a data engineer who found this repo right now, would I use it?"

Keep asking until the answer is "Yes, obviously."

---

## Current Status

**Last updated**: January 2026

| Milestone | Status | ETA |
|-----------|--------|-----|
| Tier 1 complete | 🔴 Not started | Week 1 |
| Tier 2 complete | 🔴 Not started | Week 2 |
| Tier 3 complete | 🔴 Not started | Week 3 |
| Soft launch | 🔴 Blocked on Tier 1 | After Tier 1 |
| Hard launch | 🔴 Blocked on Tier 2 | After Tier 2 |

---

*This is a living document. Update status as tasks complete.*
