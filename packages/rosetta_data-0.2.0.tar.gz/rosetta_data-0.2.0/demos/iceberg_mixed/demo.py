#!/usr/bin/env python3
"""
Rosetta Iceberg Demo: Mixed Format Tables

This demo creates three Iceberg tables:
1. sales_parquet - All Parquet files (baseline)
2. sales_vortex  - All Vortex files (via RosettaFileIO)
3. sales_mixed   - Mixed Parquet + Vortex (gradual migration scenario)

Then runs identical queries on all three and compares performance.

Requirements:
    pip install pyiceberg pyarrow pandas vortex-data

Usage:
    python demo.py
"""

import os
import sys
import time
import shutil
import tempfile
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import uuid

# Add parent to path for rosetta import
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

import pyarrow as pa
import pyarrow.parquet as pq
import pandas as pd
import numpy as np

# Check for vortex
try:
    import vortex as vx
    import vortex.io as vio
    HAS_VORTEX = True
except ImportError:
    HAS_VORTEX = False
    print("WARNING: vortex not installed. Install with: pip install vortex-data")
    sys.exit(1)

# Check for rosetta
try:
    import rosetta
    HAS_ROSETTA = True
except ImportError:
    HAS_ROSETTA = False
    print("WARNING: rosetta not installed")


def generate_sales_data(
    num_rows: int,
    start_date: datetime,
    num_days: int,
    seed: int = 42
) -> pa.Table:
    """Generate realistic sales data."""
    np.random.seed(seed)

    # Generate dates spread across the period
    dates = [start_date + timedelta(days=np.random.randint(0, num_days))
             for _ in range(num_rows)]

    data = {
        "order_id": pa.array([str(uuid.uuid4()) for _ in range(num_rows)], type=pa.string()),
        "customer_id": pa.array(np.random.randint(1, 100000, num_rows), type=pa.int64()),
        "product_id": pa.array(np.random.randint(1, 10000, num_rows), type=pa.int64()),
        "quantity": pa.array(np.random.randint(1, 20, num_rows), type=pa.int32()),
        "unit_price": pa.array(np.random.uniform(5.0, 500.0, num_rows), type=pa.float64()),
        "discount": pa.array(np.random.uniform(0.0, 0.3, num_rows), type=pa.float64()),
        "category": pa.array(
            np.random.choice(
                ["Electronics", "Clothing", "Food", "Books", "Home", "Sports", "Beauty", "Toys"],
                num_rows
            ),
            type=pa.string()
        ),
        "region": pa.array(
            np.random.choice(["North", "South", "East", "West", "Central"], num_rows),
            type=pa.string()
        ),
        "order_date": pa.array([d.strftime("%Y-%m-%d") for d in dates], type=pa.string()),
        "is_prime": pa.array(np.random.choice([True, False], num_rows, p=[0.3, 0.7]), type=pa.bool_()),
    }

    return pa.table(data)


def normalize_string_types(table: pa.Table) -> pa.Table:
    """Convert string_view columns to string for schema consistency."""
    new_columns = []
    new_fields = []

    for i, field in enumerate(table.schema):
        col = table.column(i)
        if pa.types.is_large_string(field.type) or str(field.type) == "string_view":
            # Cast to regular string
            col = col.cast(pa.string())
            new_fields.append(pa.field(field.name, pa.string()))
        else:
            new_fields.append(field)
        new_columns.append(col)

    return pa.table(dict(zip([f.name for f in new_fields], new_columns)))


def write_parquet_file(table: pa.Table, path: str) -> int:
    """Write table as Parquet, return file size."""
    pq.write_table(table, path, compression="snappy")
    return os.path.getsize(path)


def write_vortex_file(table: pa.Table, path: str) -> int:
    """Write table as Vortex, return file size."""
    vio.write(table, path)
    return os.path.getsize(path)


class SimpleIcebergTable:
    """
    Simplified Iceberg-like table for demo purposes.

    This mimics Iceberg's structure without requiring a full catalog:
    - metadata.json tracks snapshots
    - manifests list data files
    - Supports mixed file formats
    """

    def __init__(self, location: str, name: str):
        self.location = Path(location)
        self.name = name
        self.data_dir = self.location / "data"
        self.metadata_dir = self.location / "metadata"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_dir.mkdir(parents=True, exist_ok=True)

        self.files: List[Dict] = []
        self.schema = None

    def add_data_file(
        self,
        table: pa.Table,
        file_format: str = "parquet",
        partition_value: Optional[str] = None
    ) -> Dict:
        """Add a data file to the table."""
        file_id = str(uuid.uuid4())[:8]

        if file_format == "parquet":
            filename = f"part-{file_id}.parquet"
            filepath = self.data_dir / filename
            size = write_parquet_file(table, str(filepath))
        elif file_format == "vortex":
            filename = f"part-{file_id}.vortex"
            filepath = self.data_dir / filename
            size = write_vortex_file(table, str(filepath))
        else:
            raise ValueError(f"Unknown format: {file_format}")

        file_entry = {
            "file_path": str(filepath),
            "file_format": file_format,
            "record_count": table.num_rows,
            "file_size_bytes": size,
            "partition_value": partition_value,
        }

        self.files.append(file_entry)
        self.schema = table.schema

        return file_entry

    def get_all_files(self) -> List[Dict]:
        """Get all data files."""
        return self.files

    def get_parquet_files(self) -> List[str]:
        """Get paths to Parquet files only."""
        return [f["file_path"] for f in self.files if f["file_format"] == "parquet"]

    def get_vortex_files(self) -> List[str]:
        """Get paths to Vortex files only."""
        return [f["file_path"] for f in self.files if f["file_format"] == "vortex"]

    def total_rows(self) -> int:
        """Get total row count."""
        return sum(f["record_count"] for f in self.files)

    def total_size(self) -> int:
        """Get total size in bytes."""
        return sum(f["file_size_bytes"] for f in self.files)

    def read_native(self) -> pa.Table:
        """Read all files using native readers (Parquet only, skip Vortex)."""
        tables = []
        for f in self.files:
            if f["file_format"] == "parquet":
                tables.append(pq.read_table(f["file_path"]))

        if not tables:
            return None
        return pa.concat_tables(tables)

    def read_with_vortex_native(self) -> pa.Table:
        """Read all files using native readers for both formats."""
        tables = []
        for f in self.files:
            if f["file_format"] == "parquet":
                tables.append(pq.read_table(f["file_path"]))
            elif f["file_format"] == "vortex":
                vf = vx.open(f["file_path"])
                tables.append(pa.Table.from_batches(vf.to_arrow()))

        if not tables:
            return None
        return pa.concat_tables(tables)

    def read_with_rosetta(self) -> pa.Table:
        """Read all files using Rosetta (transcodes Vortex to Parquet)."""
        if not HAS_ROSETTA:
            raise ImportError("Rosetta not available")

        tables = []
        for f in self.files:
            # Rosetta handles both formats transparently
            t = rosetta.read(f["file_path"])
            # Normalize string_view to string for consistent schema
            t = normalize_string_types(t)
            tables.append(t)

        if not tables:
            return None
        return pa.concat_tables(tables)

    def summary(self) -> str:
        """Get table summary."""
        parquet_files = [f for f in self.files if f["file_format"] == "parquet"]
        vortex_files = [f for f in self.files if f["file_format"] == "vortex"]

        parquet_size = sum(f["file_size_bytes"] for f in parquet_files)
        vortex_size = sum(f["file_size_bytes"] for f in vortex_files)

        return (
            f"Table: {self.name}\n"
            f"  Parquet files: {len(parquet_files)} ({parquet_size / 1024 / 1024:.1f} MB)\n"
            f"  Vortex files:  {len(vortex_files)} ({vortex_size / 1024 / 1024:.1f} MB)\n"
            f"  Total rows:    {self.total_rows():,}\n"
            f"  Total size:    {self.total_size() / 1024 / 1024:.1f} MB"
        )


def benchmark_query(
    table: SimpleIcebergTable,
    query_func,
    read_method: str,
    num_runs: int = 3,
    drop_cache: bool = True
) -> Dict:
    """
    Benchmark a query on a table.

    Args:
        table: The table to query
        query_func: Function that takes a pa.Table and returns result
        read_method: "native", "vortex_native", or "rosetta"
        num_runs: Number of benchmark runs
        drop_cache: Whether to drop page cache between runs
    """
    times = []
    result = None

    for i in range(num_runs):
        if drop_cache:
            drop_page_cache()
            time.sleep(0.1)

        start = time.perf_counter()

        # Read data
        if read_method == "native":
            data = table.read_native()
        elif read_method == "vortex_native":
            data = table.read_with_vortex_native()
        elif read_method == "rosetta":
            data = table.read_with_rosetta()
        else:
            raise ValueError(f"Unknown read method: {read_method}")

        # Execute query
        if data is not None:
            result = query_func(data)

        elapsed = time.perf_counter() - start
        times.append(elapsed)

    return {
        "method": read_method,
        "times": times,
        "avg_ms": np.mean(times) * 1000,
        "std_ms": np.std(times) * 1000,
        "result": result,
    }


def drop_page_cache():
    """Attempt to drop OS page cache."""
    import subprocess
    import platform

    if platform.system() == "Darwin":
        try:
            subprocess.run(["sudo", "-n", "purge"], capture_output=True, timeout=5)
            return True
        except Exception:
            return False
    elif platform.system() == "Linux":
        try:
            subprocess.run(["sync"], capture_output=True)
            with open("/proc/sys/vm/drop_caches", "w") as f:
                f.write("3")
            return True
        except Exception:
            return False
    return False


# ============================================================================
# QUERIES
# ============================================================================

def query_total_revenue(table: pa.Table) -> float:
    """Calculate total revenue."""
    df = table.to_pandas()
    df["revenue"] = df["quantity"] * df["unit_price"] * (1 - df["discount"])
    return df["revenue"].sum()


def query_revenue_by_category(table: pa.Table) -> pd.DataFrame:
    """Calculate revenue by category."""
    df = table.to_pandas()
    df["revenue"] = df["quantity"] * df["unit_price"] * (1 - df["discount"])
    return df.groupby("category")["revenue"].sum().sort_values(ascending=False)


def query_top_customers(table: pa.Table, top_n: int = 10) -> pd.DataFrame:
    """Find top customers by revenue."""
    df = table.to_pandas()
    df["revenue"] = df["quantity"] * df["unit_price"] * (1 - df["discount"])
    return df.groupby("customer_id")["revenue"].sum().nlargest(top_n)


def query_regional_summary(table: pa.Table) -> pd.DataFrame:
    """Get regional summary statistics."""
    df = table.to_pandas()
    df["revenue"] = df["quantity"] * df["unit_price"] * (1 - df["discount"])
    return df.groupby("region").agg({
        "order_id": "count",
        "revenue": "sum",
        "quantity": "sum",
    }).rename(columns={"order_id": "num_orders"})


def query_filter_category(table: pa.Table, category: str = "Electronics") -> int:
    """Count orders in a specific category."""
    df = table.to_pandas()
    return len(df[df["category"] == category])


# ============================================================================
# MAIN DEMO
# ============================================================================

def main():
    print("=" * 70)
    print("ROSETTA ICEBERG DEMO: Mixed Format Tables")
    print("=" * 70)
    print()

    # Create temp directory for demo
    demo_dir = tempfile.mkdtemp(prefix="rosetta_iceberg_demo_")
    print(f"Demo directory: {demo_dir}")
    print()

    try:
        # Configuration
        rows_per_file = 200_000  # 200K rows per file
        num_files = 5            # 5 files per table = 1M rows total

        print("=" * 70)
        print("STEP 1: Creating Tables")
        print("=" * 70)
        print()
        print(f"Generating {num_files} files x {rows_per_file:,} rows = {num_files * rows_per_file:,} rows per table")
        print()

        # Create three tables
        table_parquet = SimpleIcebergTable(f"{demo_dir}/sales_parquet", "sales_parquet")
        table_vortex = SimpleIcebergTable(f"{demo_dir}/sales_vortex", "sales_vortex")
        table_mixed = SimpleIcebergTable(f"{demo_dir}/sales_mixed", "sales_mixed")

        # Generate data and populate tables
        base_date = datetime(2024, 1, 1)

        for i in range(num_files):
            print(f"  Generating file {i+1}/{num_files}...", end=" ", flush=True)

            # Generate data for this partition
            data = generate_sales_data(
                num_rows=rows_per_file,
                start_date=base_date + timedelta(days=i * 30),
                num_days=30,
                seed=42 + i
            )

            # Add to parquet-only table
            pq_entry = table_parquet.add_data_file(data, "parquet", f"month_{i+1}")

            # Add to vortex-only table
            vx_entry = table_vortex.add_data_file(data, "vortex", f"month_{i+1}")

            # Add to mixed table (first 2 files as Parquet, rest as Vortex)
            if i < 2:
                table_mixed.add_data_file(data, "parquet", f"month_{i+1}")
            else:
                table_mixed.add_data_file(data, "vortex", f"month_{i+1}")

            print(f"Parquet: {pq_entry['file_size_bytes']/1024/1024:.1f}MB, "
                  f"Vortex: {vx_entry['file_size_bytes']/1024/1024:.1f}MB")

        print()
        print("-" * 70)
        print("Table Summaries:")
        print("-" * 70)
        print()
        print(table_parquet.summary())
        print()
        print(table_vortex.summary())
        print()
        print(table_mixed.summary())
        print()

        # Calculate storage savings
        parquet_size = table_parquet.total_size()
        vortex_size = table_vortex.total_size()
        savings = (1 - vortex_size / parquet_size) * 100

        print("-" * 70)
        print("Storage Comparison:")
        print(f"  Parquet total: {parquet_size / 1024 / 1024:.1f} MB")
        print(f"  Vortex total:  {vortex_size / 1024 / 1024:.1f} MB")
        print(f"  Savings:       {savings:.1f}%")
        print("-" * 70)
        print()

        # ====================================================================
        # BENCHMARKS
        # ====================================================================

        print("=" * 70)
        print("STEP 2: Running Benchmarks")
        print("=" * 70)
        print()

        queries = [
            ("Total Revenue", query_total_revenue),
            ("Revenue by Category", query_revenue_by_category),
            ("Top 10 Customers", lambda t: query_top_customers(t, 10)),
            ("Regional Summary", query_regional_summary),
            ("Filter: Electronics", lambda t: query_filter_category(t, "Electronics")),
        ]

        results = {}

        for query_name, query_func in queries:
            print(f"\nQuery: {query_name}")
            print("-" * 50)

            results[query_name] = {}

            # Benchmark on parquet-only table (native)
            print("  [1/4] Parquet table (native reader)...", end=" ", flush=True)
            r1 = benchmark_query(table_parquet, query_func, "native", num_runs=3)
            print(f"{r1['avg_ms']:.1f}ms")
            results[query_name]["parquet_native"] = r1

            # Benchmark on vortex-only table (native vortex reader)
            print("  [2/4] Vortex table (native reader)...", end=" ", flush=True)
            r2 = benchmark_query(table_vortex, query_func, "vortex_native", num_runs=3)
            print(f"{r2['avg_ms']:.1f}ms")
            results[query_name]["vortex_native"] = r2

            # Benchmark on vortex-only table (via Rosetta)
            if HAS_ROSETTA:
                print("  [3/4] Vortex table (via Rosetta)...", end=" ", flush=True)
                r3 = benchmark_query(table_vortex, query_func, "rosetta", num_runs=3)
                print(f"{r3['avg_ms']:.1f}ms")
                results[query_name]["vortex_rosetta"] = r3

            # Benchmark on mixed table (via Rosetta - handles both formats)
            if HAS_ROSETTA:
                print("  [4/4] Mixed table (via Rosetta)...", end=" ", flush=True)
                r4 = benchmark_query(table_mixed, query_func, "rosetta", num_runs=3)
                print(f"{r4['avg_ms']:.1f}ms")
                results[query_name]["mixed_rosetta"] = r4

        # ====================================================================
        # RESULTS SUMMARY
        # ====================================================================

        print()
        print("=" * 70)
        print("RESULTS SUMMARY")
        print("=" * 70)
        print()

        print(f"{'Query':<25} {'Parquet':<12} {'Vortex':<12} {'Rosetta':<12} {'Mixed':<12}")
        print(f"{'':25} {'(native)':<12} {'(native)':<12} {'(Vortex)':<12} {'(P+V)':<12}")
        print("-" * 70)

        for query_name in results:
            r = results[query_name]
            parquet_ms = r.get("parquet_native", {}).get("avg_ms", 0)
            vortex_ms = r.get("vortex_native", {}).get("avg_ms", 0)
            rosetta_ms = r.get("vortex_rosetta", {}).get("avg_ms", 0)
            mixed_ms = r.get("mixed_rosetta", {}).get("avg_ms", 0)

            print(f"{query_name:<25} {parquet_ms:>8.1f}ms   {vortex_ms:>8.1f}ms   "
                  f"{rosetta_ms:>8.1f}ms   {mixed_ms:>8.1f}ms")

        print()
        print("-" * 70)
        print("Key Insights:")
        print("-" * 70)

        # Calculate averages
        avg_parquet = np.mean([r["parquet_native"]["avg_ms"] for r in results.values() if "parquet_native" in r])
        avg_vortex = np.mean([r["vortex_native"]["avg_ms"] for r in results.values() if "vortex_native" in r])
        avg_rosetta = np.mean([r["vortex_rosetta"]["avg_ms"] for r in results.values() if "vortex_rosetta" in r]) if HAS_ROSETTA else 0
        avg_mixed = np.mean([r["mixed_rosetta"]["avg_ms"] for r in results.values() if "mixed_rosetta" in r]) if HAS_ROSETTA else 0

        print(f"  Average query time (Parquet native):  {avg_parquet:.1f}ms")
        print(f"  Average query time (Vortex native):   {avg_vortex:.1f}ms ({avg_parquet/avg_vortex:.1f}x faster)")
        if HAS_ROSETTA:
            print(f"  Average query time (Rosetta):         {avg_rosetta:.1f}ms ({avg_parquet/avg_rosetta:.1f}x faster)")
            print(f"  Average query time (Mixed via Rosetta): {avg_mixed:.1f}ms ({avg_parquet/avg_mixed:.1f}x faster)")

        print()
        print(f"  Storage savings (Vortex vs Parquet): {savings:.1f}%")
        print()

        # ====================================================================
        # VERIFY DATA CONSISTENCY
        # ====================================================================

        print("=" * 70)
        print("STEP 3: Verifying Data Consistency")
        print("=" * 70)
        print()

        # Read all tables and verify they have the same data
        print("  Reading all tables to verify consistency...")

        parquet_data = table_parquet.read_native()
        vortex_data = table_vortex.read_with_vortex_native()

        if HAS_ROSETTA:
            mixed_data = table_mixed.read_with_rosetta()

            # Compare row counts
            print(f"  Parquet table rows: {parquet_data.num_rows:,}")
            print(f"  Vortex table rows:  {vortex_data.num_rows:,}")
            print(f"  Mixed table rows:   {mixed_data.num_rows:,}")

            # Verify totals match
            total_parquet = query_total_revenue(parquet_data)
            total_vortex = query_total_revenue(vortex_data)
            total_mixed = query_total_revenue(mixed_data)

            print()
            print(f"  Total revenue (Parquet): ${total_parquet:,.2f}")
            print(f"  Total revenue (Vortex):  ${total_vortex:,.2f}")
            print(f"  Total revenue (Mixed):   ${total_mixed:,.2f}")

            if abs(total_parquet - total_vortex) < 0.01 and abs(total_parquet - total_mixed) < 0.01:
                print()
                print("  ✓ All tables return consistent results!")
            else:
                print()
                print("  ✗ WARNING: Results differ between tables!")

        print()
        print("=" * 70)
        print("DEMO COMPLETE")
        print("=" * 70)
        print()
        print("This demo showed:")
        print("  1. Vortex files are significantly smaller than Parquet")
        print("  2. Native Vortex reads are faster than Parquet")
        print("  3. Rosetta enables transparent reading of Vortex files")
        print("  4. Mixed Parquet+Vortex tables work seamlessly via Rosetta")
        print()
        print("For production Iceberg integration:")
        print("  - Configure: io-impl = io.rosetta.iceberg.RosettaFileIO")
        print("  - All queries work unchanged")
        print("  - Mix old Parquet and new Vortex files in the same table")
        print()

    finally:
        # Cleanup
        print(f"Cleaning up: {demo_dir}")
        shutil.rmtree(demo_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
