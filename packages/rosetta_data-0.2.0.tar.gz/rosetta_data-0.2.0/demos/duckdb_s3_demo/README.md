# Rosetta DuckDB + S3 Demo

**The Value Proposition**: Store data in Vortex format (30-40% smaller), query with DuckDB using the same SQL - zero code changes.

## Quick Start

```bash
# 1. Setup
cd demos/duckdb_s3_demo
pip install -r requirements.txt

# 2. Generate 1GB of realistic IoT sensor data
python generate_data.py

# 3. Upload to S3 (both Parquet and Vortex)
python upload_to_s3.py --bucket your-bucket-name

# 4. Run the comparison demo
python run_demo.py --bucket your-bucket-name
```

## What This Demo Shows

### Storage Savings
```
Parquet:  1,024 MB  ($0.023/month on S3)
Vortex:     680 MB  ($0.015/month on S3)
Savings:     34%    ($0.008/month per GB)
```

At scale (100TB data lake): **$800/month savings** just from format change.

### Query Performance
```sql
-- Same SQL, same results, different underlying format
SELECT
    device_id,
    DATE_TRUNC('hour', timestamp) as hour,
    AVG(temperature) as avg_temp
FROM read_parquet('s3://bucket/data.vortex')  -- Rosetta handles this!
GROUP BY 1, 2;
```

### Zero Code Changes
```sql
-- Before (Parquet)
LOAD rosetta;  -- One-time setup
SELECT * FROM read_parquet('s3://bucket/sensors.parquet');

-- After (Vortex) - SAME QUERY!
SELECT * FROM read_parquet('s3://bucket/sensors.vortex');
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Your Analytics Query (unchanged)                            │
│  SELECT ... FROM read_parquet('s3://bucket/*.vortex')       │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  DuckDB + Rosetta Extension                                  │
│  - Detects Vortex format automatically                       │
│  - Reads natively (no transcoding overhead!)                 │
│  - Returns Arrow data to DuckDB                              │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│  S3 Storage                                                  │
│  sensors.vortex (680 MB) vs sensors.parquet (1,024 MB)      │
└─────────────────────────────────────────────────────────────┘
```

## Data Schema

Realistic IoT sensor data with 10M rows:

| Column | Type | Description |
|--------|------|-------------|
| device_id | STRING | Device identifier (10K unique devices) |
| timestamp | TIMESTAMP | Event time (1 year range) |
| temperature | FLOAT | Temperature reading (-40 to 120°F) |
| humidity | FLOAT | Humidity percentage (0-100%) |
| pressure | FLOAT | Barometric pressure (hPa) |
| battery_level | FLOAT | Battery percentage (0-100%) |
| signal_strength | INT | RSSI value (-100 to 0 dBm) |
| location_lat | FLOAT | Latitude |
| location_lon | FLOAT | Longitude |
| status | STRING | Device status (5 categories) |

## Cost Analysis

| Data Size | Parquet S3 Cost | Vortex S3 Cost | Monthly Savings |
|-----------|-----------------|----------------|-----------------|
| 1 GB | $0.023 | $0.015 | $0.008 |
| 100 GB | $2.30 | $1.52 | $0.78 |
| 1 TB | $23.00 | $15.18 | $7.82 |
| 100 TB | $2,300 | $1,518 | $782 |

*Based on S3 Standard pricing ($0.023/GB/month) and 34% Vortex compression*
