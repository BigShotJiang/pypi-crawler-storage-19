#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""
Generate realistic IoT sensor data for the Rosetta demo.

Generates ~1GB of data representing IoT sensor readings from 10,000 devices
over a 1-year period. The data is designed to showcase Vortex's encoding
advantages:
- High cardinality strings (device_id) → Dictionary encoding
- Timestamps → Delta encoding
- Floats with patterns → Byte stream split
- Low cardinality strings (status) → Dictionary + FSST
"""

import os
import time
import argparse
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
from datetime import datetime, timedelta
from tqdm import tqdm

# Target ~1GB of data
TARGET_ROWS = 10_000_000  # 10M rows ≈ 1GB
NUM_DEVICES = 10_000
BATCH_SIZE = 500_000  # Write in batches to manage memory

# Device statuses (low cardinality - good for dictionary encoding)
STATUSES = ['active', 'idle', 'maintenance', 'error', 'offline']

# Schema matching realistic IoT data
SCHEMA = pa.schema([
    ('device_id', pa.string()),
    ('timestamp', pa.timestamp('us')),
    ('temperature', pa.float32()),
    ('humidity', pa.float32()),
    ('pressure', pa.float32()),
    ('battery_level', pa.float32()),
    ('signal_strength', pa.int16()),
    ('location_lat', pa.float64()),
    ('location_lon', pa.float64()),
    ('status', pa.string()),
])


def generate_device_ids(n_devices: int) -> list:
    """Generate realistic device IDs."""
    return [f"sensor_{i:05d}" for i in range(n_devices)]


def generate_batch(
    batch_size: int,
    device_ids: list,
    start_ts: datetime,
    rng: np.random.Generator
) -> pa.RecordBatch:
    """Generate a batch of sensor readings."""

    # Random device selection (some devices report more than others)
    device_weights = rng.pareto(2, len(device_ids)) + 1
    device_weights /= device_weights.sum()
    device_indices = rng.choice(len(device_ids), size=batch_size, p=device_weights)
    devices = [device_ids[i] for i in device_indices]

    # Timestamps spread over time period with some clustering
    time_offsets = rng.exponential(scale=3600, size=batch_size)  # Cluster around certain times
    timestamps = [start_ts + timedelta(seconds=float(offset)) for offset in np.cumsum(time_offsets)]

    # Temperature: seasonal pattern + noise (good for delta + compression)
    base_temp = 60 + 30 * np.sin(np.linspace(0, 2*np.pi, batch_size))  # Seasonal
    temperature = base_temp + rng.normal(0, 5, batch_size)
    temperature = np.clip(temperature, -40, 120).astype(np.float32)

    # Humidity: inversely correlated with temperature
    humidity = 80 - 0.3 * temperature + rng.normal(0, 10, batch_size)
    humidity = np.clip(humidity, 0, 100).astype(np.float32)

    # Pressure: small variations around standard (good for byte stream split)
    pressure = 1013.25 + rng.normal(0, 20, batch_size)
    pressure = pressure.astype(np.float32)

    # Battery: slowly decreasing with occasional recharges
    battery = 100 - rng.exponential(30, batch_size)
    battery = np.clip(battery, 0, 100).astype(np.float32)

    # Signal strength: mostly good, some weak
    signal = -50 + rng.normal(0, 15, batch_size)
    signal = np.clip(signal, -100, 0).astype(np.int16)

    # Locations: clustered around a few geographic areas
    n_clusters = 20
    cluster_centers_lat = rng.uniform(25, 48, n_clusters)  # US latitude range
    cluster_centers_lon = rng.uniform(-125, -70, n_clusters)  # US longitude range
    cluster_indices = rng.choice(n_clusters, size=batch_size)
    location_lat = cluster_centers_lat[cluster_indices] + rng.normal(0, 0.5, batch_size)
    location_lon = cluster_centers_lon[cluster_indices] + rng.normal(0, 0.5, batch_size)

    # Status: mostly active (good for dictionary encoding)
    status_weights = [0.7, 0.15, 0.08, 0.05, 0.02]  # active, idle, maintenance, error, offline
    status = rng.choice(STATUSES, size=batch_size, p=status_weights).tolist()

    return pa.RecordBatch.from_pydict({
        'device_id': devices,
        'timestamp': timestamps,
        'temperature': temperature,
        'humidity': humidity,
        'pressure': pressure,
        'battery_level': battery,
        'signal_strength': signal,
        'location_lat': location_lat,
        'location_lon': location_lon,
        'status': status,
    }, schema=SCHEMA)


def generate_parquet(output_path: str, num_rows: int = TARGET_ROWS):
    """Generate the Parquet file."""
    print(f"\nGenerating {num_rows:,} rows of IoT sensor data...")
    print(f"Output: {output_path}")

    device_ids = generate_device_ids(NUM_DEVICES)
    rng = np.random.default_rng(42)  # Reproducible
    start_ts = datetime(2025, 1, 1)

    # Write in batches
    writer = None
    rows_written = 0

    with tqdm(total=num_rows, unit='rows', unit_scale=True) as pbar:
        while rows_written < num_rows:
            batch_size = min(BATCH_SIZE, num_rows - rows_written)
            batch = generate_batch(batch_size, device_ids, start_ts, rng)

            if writer is None:
                writer = pq.ParquetWriter(output_path, SCHEMA, compression='snappy')

            writer.write_batch(batch)
            rows_written += batch_size
            start_ts += timedelta(hours=batch_size / 1000)  # Advance time
            pbar.update(batch_size)

    if writer:
        writer.close()

    file_size = os.path.getsize(output_path)
    print(f"\nGenerated: {output_path}")
    print(f"  Rows: {num_rows:,}")
    print(f"  Size: {file_size / 1e6:.1f} MB")
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Generate IoT sensor data for Rosetta demo')
    parser.add_argument('--rows', type=int, default=TARGET_ROWS,
                        help=f'Number of rows to generate (default: {TARGET_ROWS:,})')
    parser.add_argument('--output', type=str, default='data/sensors.parquet',
                        help='Output path for Parquet file')
    args = parser.parse_args()

    # Create output directory
    os.makedirs(os.path.dirname(args.output) or '.', exist_ok=True)

    start = time.time()
    generate_parquet(args.output, args.rows)
    elapsed = time.time() - start

    print(f"\nGeneration completed in {elapsed:.1f}s")
    print("\nNext step: Convert to Vortex and upload to S3")
    print("  python upload_to_s3.py --bucket YOUR_BUCKET")


if __name__ == '__main__':
    main()
