#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""
Upload IoT sensor data to S3 in both Parquet and Vortex formats.

This script:
1. Reads the generated Parquet file
2. Converts it to Vortex format (if vortex-py is available)
3. Uploads both to S3
4. Reports size comparison
"""

import os
import sys
import argparse
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
import pyarrow.parquet as pq

# Try to import vortex - it's optional
try:
    import vortex
    VORTEX_AVAILABLE = True
except ImportError:
    VORTEX_AVAILABLE = False
    print("Note: vortex-py not installed. Will upload Parquet only.")
    print("Install with: pip install vortex")


def check_aws_credentials():
    """Verify AWS credentials are configured."""
    try:
        sts = boto3.client('sts')
        identity = sts.get_caller_identity()
        print(f"AWS Identity: {identity['Arn']}")
        return True
    except NoCredentialsError:
        print("ERROR: No AWS credentials found.")
        print("Configure credentials in ~/.aws/credentials or environment variables.")
        return False
    except ClientError as e:
        print(f"ERROR: AWS credentials invalid: {e}")
        return False


def get_file_size_mb(path: str) -> float:
    """Get file size in MB."""
    return os.path.getsize(path) / (1024 * 1024)


def convert_to_vortex(parquet_path: str, vortex_path: str) -> bool:
    """Convert Parquet file to Vortex format."""
    if not VORTEX_AVAILABLE:
        return False

    print("\nConverting to Vortex format...")
    try:
        # Read Parquet as Arrow table
        table = pq.read_table(parquet_path)

        # Convert to Vortex and write
        # The vortex Python API uses compress() to create a vortex array
        vortex_array = vortex.compress(table)

        # Write to file
        with open(vortex_path, 'wb') as f:
            vortex_array.write(f)

        print(f"  Converted: {vortex_path}")
        return True
    except Exception as e:
        print(f"  Warning: Vortex conversion failed: {e}")
        print("  Continuing with Parquet only.")
        return False


def upload_to_s3(local_path: str, bucket: str, s3_key: str) -> bool:
    """Upload a file to S3."""
    s3 = boto3.client('s3')
    file_size = get_file_size_mb(local_path)

    print(f"  Uploading {s3_key} ({file_size:.1f} MB)...")

    try:
        s3.upload_file(local_path, bucket, s3_key)
        print(f"  ✓ Uploaded to s3://{bucket}/{s3_key}")
        return True
    except ClientError as e:
        print(f"  ✗ Upload failed: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description='Upload sensor data to S3')
    parser.add_argument('--bucket', type=str, required=True,
                        help='S3 bucket name')
    parser.add_argument('--prefix', type=str, default='rosetta-demo',
                        help='S3 key prefix (default: rosetta-demo)')
    parser.add_argument('--input', type=str, default='data/sensors.parquet',
                        help='Input Parquet file path')
    args = parser.parse_args()

    # Check prerequisites
    if not os.path.exists(args.input):
        print(f"ERROR: Input file not found: {args.input}")
        print("Run generate_data.py first to create the data.")
        sys.exit(1)

    if not check_aws_credentials():
        sys.exit(1)

    # Paths
    parquet_path = args.input
    vortex_path = args.input.replace('.parquet', '.vortex')

    parquet_key = f"{args.prefix}/sensors.parquet"
    vortex_key = f"{args.prefix}/sensors.vortex"

    # Get Parquet size
    parquet_size = get_file_size_mb(parquet_path)
    print(f"\nSource file: {parquet_path}")
    print(f"  Size: {parquet_size:.1f} MB")

    # Convert to Vortex
    vortex_converted = convert_to_vortex(parquet_path, vortex_path)

    if vortex_converted:
        vortex_size = get_file_size_mb(vortex_path)
        savings = (1 - vortex_size / parquet_size) * 100
        print("\nSize comparison:")
        print(f"  Parquet: {parquet_size:.1f} MB")
        print(f"  Vortex:  {vortex_size:.1f} MB")
        print(f"  Savings: {savings:.1f}%")

    # Upload to S3
    print(f"\nUploading to s3://{args.bucket}/{args.prefix}/")

    success = True
    success &= upload_to_s3(parquet_path, args.bucket, parquet_key)

    if vortex_converted:
        success &= upload_to_s3(vortex_path, args.bucket, vortex_key)

    if success:
        print("\n✓ Upload complete!")
        print("\nS3 URIs:")
        print(f"  Parquet: s3://{args.bucket}/{parquet_key}")
        if vortex_converted:
            print(f"  Vortex:  s3://{args.bucket}/{vortex_key}")
        print("\nNext step: Run the comparison demo")
        print(f"  python run_demo.py --bucket {args.bucket}")
    else:
        print("\n✗ Upload failed")
        sys.exit(1)


if __name__ == '__main__':
    main()
