#!/usr/bin/env python3
"""
Rosetta Iceberg S3 Demo: Real Cloud Performance

This demo uploads data to S3 and measures REAL I/O performance differences
between Parquet and Vortex formats.

Usage:
    python demo.py
"""

import os
import sys
import time
import tempfile
import subprocess
from pathlib import Path
from typing import Dict, List
import uuid

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

import pyarrow as pa
import pyarrow.parquet as pq
import numpy as np

import vortex as vx
import vortex.io as vio

try:
    import rosetta
    HAS_ROSETTA = True
except ImportError:
    HAS_ROSETTA = False
    print("WARNING: rosetta not available")

# S3 Configuration
S3_BUCKET = "rosetta-demo-tchopra"
S3_PREFIX = "iceberg-benchmark"


def run_aws_cmd(cmd: List[str], capture=True) -> subprocess.CompletedProcess:
    """Run AWS CLI command."""
    full_cmd = ["aws"] + cmd
    return subprocess.run(full_cmd, capture_output=capture, text=True)


def s3_upload(local_path: str, s3_key: str) -> float:
    """Upload file to S3, return upload time."""
    s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
    start = time.perf_counter()
    result = run_aws_cmd(["s3", "cp", local_path, s3_uri, "--quiet"])
    elapsed = time.perf_counter() - start
    if result.returncode != 0:
        raise RuntimeError(f"S3 upload failed: {result.stderr}")
    return elapsed


def s3_download(s3_key: str, local_path: str) -> float:
    """Download file from S3, return download time."""
    s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
    start = time.perf_counter()
    result = run_aws_cmd(["s3", "cp", s3_uri, local_path, "--quiet"])
    elapsed = time.perf_counter() - start
    if result.returncode != 0:
        raise RuntimeError(f"S3 download failed: {result.stderr}")
    return elapsed


def s3_delete_prefix(prefix: str):
    """Delete all objects under a prefix."""
    s3_uri = f"s3://{S3_BUCKET}/{prefix}"
    run_aws_cmd(["s3", "rm", s3_uri, "--recursive", "--quiet"])


def s3_get_size(s3_key: str) -> int:
    """Get size of S3 object."""
    result = run_aws_cmd(["s3api", "head-object", "--bucket", S3_BUCKET, "--key", s3_key])
    if result.returncode == 0:
        import json
        data = json.loads(result.stdout)
        return data.get("ContentLength", 0)
    return 0


def generate_sales_data(num_rows: int, seed: int = 42) -> pa.Table:
    """Generate sample sales data."""
    np.random.seed(seed)

    data = {
        "order_id": pa.array([str(uuid.uuid4()) for _ in range(num_rows)], type=pa.string()),
        "customer_id": pa.array(np.random.randint(1, 100000, num_rows), type=pa.int64()),
        "product_id": pa.array(np.random.randint(1, 10000, num_rows), type=pa.int64()),
        "quantity": pa.array(np.random.randint(1, 20, num_rows), type=pa.int32()),
        "unit_price": pa.array(np.random.uniform(5.0, 500.0, num_rows), type=pa.float64()),
        "discount": pa.array(np.random.uniform(0.0, 0.3, num_rows), type=pa.float64()),
        "category": pa.array(
            np.random.choice(["Electronics", "Clothing", "Food", "Books", "Home", "Sports"], num_rows),
            type=pa.string()
        ),
        "region": pa.array(
            np.random.choice(["North", "South", "East", "West", "Central"], num_rows),
            type=pa.string()
        ),
    }

    return pa.table(data)


def benchmark_s3_read_parquet(s3_key: str, num_runs: int = 3) -> Dict:
    """Benchmark reading Parquet from S3."""
    times = []
    rows = 0

    for _ in range(num_runs):
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=True) as tmp:
            # Time the full download + read
            start = time.perf_counter()
            s3_download(s3_key, tmp.name)
            table = pq.read_table(tmp.name)
            total_time = time.perf_counter() - start

            times.append(total_time)
            rows = table.num_rows

    return {
        "method": "Parquet (S3)",
        "avg_ms": np.mean(times) * 1000,
        "std_ms": np.std(times) * 1000,
        "rows": rows,
        "times": times,
    }


def benchmark_s3_read_vortex_native(s3_key: str, num_runs: int = 3) -> Dict:
    """Benchmark reading Vortex from S3 using native reader."""
    times = []
    rows = 0

    for _ in range(num_runs):
        with tempfile.NamedTemporaryFile(suffix=".vortex", delete=True) as tmp:
            start = time.perf_counter()
            s3_download(s3_key, tmp.name)
            vf = vx.open(tmp.name)
            table = pa.Table.from_batches(vf.to_arrow())
            total_time = time.perf_counter() - start

            times.append(total_time)
            rows = table.num_rows

    return {
        "method": "Vortex Native (S3)",
        "avg_ms": np.mean(times) * 1000,
        "std_ms": np.std(times) * 1000,
        "rows": rows,
        "times": times,
    }


def benchmark_s3_read_vortex_rosetta(s3_key: str, num_runs: int = 3) -> Dict:
    """Benchmark reading Vortex from S3 using Rosetta."""
    if not HAS_ROSETTA:
        return {"method": "Rosetta (S3)", "error": "not available"}

    times = []
    rows = 0

    for _ in range(num_runs):
        with tempfile.NamedTemporaryFile(suffix=".vortex", delete=True) as tmp:
            start = time.perf_counter()
            s3_download(s3_key, tmp.name)
            table = rosetta.read(tmp.name)
            total_time = time.perf_counter() - start

            times.append(total_time)
            rows = table.num_rows

    return {
        "method": "Rosetta (S3)",
        "avg_ms": np.mean(times) * 1000,
        "std_ms": np.std(times) * 1000,
        "rows": rows,
        "times": times,
    }


def main():
    print("=" * 70)
    print("ROSETTA S3 DEMO: Real Cloud I/O Performance")
    print("=" * 70)
    print()
    print(f"S3 Bucket: s3://{S3_BUCKET}/{S3_PREFIX}/")
    print()

    # Configuration
    rows_per_file = 500_000  # 500K rows per file
    num_files = 3            # 3 files

    # Clean up any previous data
    print("Cleaning up previous demo data...")
    s3_delete_prefix(S3_PREFIX)
    print()

    # ========================================================================
    # STEP 1: Generate and upload data
    # ========================================================================
    print("=" * 70)
    print("STEP 1: Generating and Uploading Data to S3")
    print("=" * 70)
    print()

    parquet_files = []
    vortex_files = []
    total_parquet_size = 0
    total_vortex_size = 0

    with tempfile.TemporaryDirectory() as tmpdir:
        for i in range(num_files):
            print(f"  File {i+1}/{num_files}:")

            # Generate data
            data = generate_sales_data(rows_per_file, seed=42 + i)
            print(f"    Generated {data.num_rows:,} rows")

            # Write and upload Parquet
            parquet_local = f"{tmpdir}/part-{i}.parquet"
            pq.write_table(data, parquet_local, compression="snappy")
            parquet_size = os.path.getsize(parquet_local)
            total_parquet_size += parquet_size

            parquet_s3_key = f"{S3_PREFIX}/parquet/part-{i}.parquet"
            upload_time = s3_upload(parquet_local, parquet_s3_key)
            parquet_files.append(parquet_s3_key)
            print(f"    Parquet: {parquet_size/1024/1024:.1f} MB, uploaded in {upload_time:.1f}s")

            # Write and upload Vortex
            vortex_local = f"{tmpdir}/part-{i}.vortex"
            vio.write(data, vortex_local)
            vortex_size = os.path.getsize(vortex_local)
            total_vortex_size += vortex_size

            vortex_s3_key = f"{S3_PREFIX}/vortex/part-{i}.vortex"
            upload_time = s3_upload(vortex_local, vortex_s3_key)
            vortex_files.append(vortex_s3_key)
            print(f"    Vortex:  {vortex_size/1024/1024:.1f} MB, uploaded in {upload_time:.1f}s")
            print()

    print("-" * 70)
    print("Storage Summary:")
    print(f"  Total Parquet: {total_parquet_size/1024/1024:.1f} MB")
    print(f"  Total Vortex:  {total_vortex_size/1024/1024:.1f} MB")
    print(f"  Savings:       {(1 - total_vortex_size/total_parquet_size)*100:.1f}%")
    print("-" * 70)
    print()

    # ========================================================================
    # STEP 2: Benchmark S3 reads
    # ========================================================================
    print("=" * 70)
    print("STEP 2: Benchmarking S3 Read Performance")
    print("=" * 70)
    print()
    print("Reading files directly from S3 (no local caching)...")
    print()

    results = {
        "parquet": [],
        "vortex_native": [],
        "vortex_rosetta": [],
    }

    for i, (pq_key, vx_key) in enumerate(zip(parquet_files, vortex_files)):
        print(f"  File {i+1}/{num_files}:")

        # Parquet from S3
        print("    Reading Parquet from S3...", end=" ", flush=True)
        r1 = benchmark_s3_read_parquet(pq_key, num_runs=3)
        print(f"{r1['avg_ms']:.0f}ms")
        results["parquet"].append(r1)

        # Vortex native from S3
        print("    Reading Vortex (native) from S3...", end=" ", flush=True)
        r2 = benchmark_s3_read_vortex_native(vx_key, num_runs=3)
        print(f"{r2['avg_ms']:.0f}ms")
        results["vortex_native"].append(r2)

        # Vortex via Rosetta from S3
        if HAS_ROSETTA:
            print("    Reading Vortex (Rosetta) from S3...", end=" ", flush=True)
            r3 = benchmark_s3_read_vortex_rosetta(vx_key, num_runs=3)
            print(f"{r3['avg_ms']:.0f}ms")
            results["vortex_rosetta"].append(r3)

        print()

    # ========================================================================
    # RESULTS
    # ========================================================================
    print("=" * 70)
    print("RESULTS: S3 Read Performance")
    print("=" * 70)
    print()

    avg_parquet = np.mean([r["avg_ms"] for r in results["parquet"]])
    avg_vortex_native = np.mean([r["avg_ms"] for r in results["vortex_native"]])
    avg_vortex_rosetta = np.mean([r["avg_ms"] for r in results["vortex_rosetta"]]) if results["vortex_rosetta"] else 0

    print(f"{'Method':<30} {'Avg Time':<15} {'vs Parquet':<15}")
    print("-" * 60)
    print(f"{'Parquet (S3)':<30} {avg_parquet:>8.0f}ms      {'baseline':<15}")
    print(f"{'Vortex Native (S3)':<30} {avg_vortex_native:>8.0f}ms      {avg_parquet/avg_vortex_native:.2f}x faster")
    if avg_vortex_rosetta:
        print(f"{'Vortex via Rosetta (S3)':<30} {avg_vortex_rosetta:>8.0f}ms      {avg_parquet/avg_vortex_rosetta:.2f}x faster")
    print()

    print("-" * 70)
    print("Analysis:")
    print("-" * 70)
    print(f"  Data size reduction:  {(1 - total_vortex_size/total_parquet_size)*100:.0f}% smaller")
    print(f"  S3 download speedup:  {avg_parquet/avg_vortex_native:.1f}x faster (native Vortex)")
    if avg_vortex_rosetta:
        print(f"  Rosetta overhead:     {(avg_vortex_rosetta/avg_vortex_native - 1)*100:.0f}% vs native")
    print()
    print("  Key insight: Smaller files = less network transfer = faster queries!")
    print()

    # ========================================================================
    # CLEANUP
    # ========================================================================
    print("=" * 70)
    print("Cleanup")
    print("=" * 70)
    print()
    cleanup = input("Delete S3 demo data? [y/N]: ").strip().lower()
    if cleanup == 'y':
        print("Cleaning up S3 data...")
        s3_delete_prefix(S3_PREFIX)
        print("Done!")
    else:
        print(f"Data preserved at s3://{S3_BUCKET}/{S3_PREFIX}/")
        print("Run: aws s3 rm s3://{S3_BUCKET}/{S3_PREFIX}/ --recursive")


if __name__ == "__main__":
    main()
