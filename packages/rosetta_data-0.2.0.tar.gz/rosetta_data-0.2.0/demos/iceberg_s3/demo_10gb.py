#!/usr/bin/env python3
"""
Rosetta S3 Demo: 10GB Scale Test

Compares Parquet vs Rosetta (Vortex) performance on S3 at 10GB scale.
Rosetta runs FIRST to avoid any caching bias.

Usage:
    python demo_10gb.py
"""

import os
import sys
import time
import tempfile
import subprocess
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

import pyarrow as pa
import pyarrow.parquet as pq
import numpy as np

import vortex.io as vio

try:
    import rosetta
    HAS_ROSETTA = True
except ImportError:
    HAS_ROSETTA = False
    print("ERROR: rosetta not available")
    sys.exit(1)

# S3 Configuration
S3_BUCKET = "rosetta-demo-tchopra"
S3_PREFIX = "iceberg-10gb"


def run_aws_cmd(cmd: List[str], capture=True) -> subprocess.CompletedProcess:
    """Run AWS CLI command."""
    return subprocess.run(["aws"] + cmd, capture_output=capture, text=True)


def s3_upload(local_path: str, s3_key: str) -> float:
    """Upload file to S3, return upload time."""
    s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
    start = time.perf_counter()
    result = run_aws_cmd(["s3", "cp", local_path, s3_uri, "--quiet"])
    elapsed = time.perf_counter() - start
    if result.returncode != 0:
        raise RuntimeError(f"S3 upload failed: {result.stderr}")
    return elapsed


def s3_download(s3_key: str, local_path: str) -> float:
    """Download file from S3, return download time."""
    s3_uri = f"s3://{S3_BUCKET}/{s3_key}"
    start = time.perf_counter()
    result = run_aws_cmd(["s3", "cp", s3_uri, local_path, "--quiet"])
    elapsed = time.perf_counter() - start
    if result.returncode != 0:
        raise RuntimeError(f"S3 download failed: {result.stderr}")
    return elapsed


def s3_delete_prefix(prefix: str):
    """Delete all objects under a prefix."""
    s3_uri = f"s3://{S3_BUCKET}/{prefix}"
    run_aws_cmd(["s3", "rm", s3_uri, "--recursive", "--quiet"])


def generate_sales_data(num_rows: int, seed: int = 42, file_id: int = 0) -> pa.Table:
    """Generate sample sales data - optimized for speed."""
    np.random.seed(seed)

    print(f"      Generating {num_rows:,} rows...", end=" ", flush=True)
    start = time.perf_counter()

    # Use numeric order_id (much faster than UUID strings)
    base_id = file_id * num_rows

    # Pre-generate category/region arrays (faster than per-row choice)
    categories = ["Electronics", "Clothing", "Food", "Books", "Home", "Sports"]
    regions = ["North", "South", "East", "West", "Central"]

    data = {
        "order_id": pa.array(np.arange(base_id, base_id + num_rows), type=pa.int64()),
        "customer_id": pa.array(np.random.randint(1, 100000, num_rows), type=pa.int64()),
        "product_id": pa.array(np.random.randint(1, 10000, num_rows), type=pa.int64()),
        "quantity": pa.array(np.random.randint(1, 20, num_rows), type=pa.int32()),
        "unit_price": pa.array(np.random.uniform(5.0, 500.0, num_rows), type=pa.float64()),
        "discount": pa.array(np.random.uniform(0.0, 0.3, num_rows), type=pa.float64()),
        "category": pa.array(
            np.array(categories)[np.random.randint(0, len(categories), num_rows)],
            type=pa.string()
        ),
        "region": pa.array(
            np.array(regions)[np.random.randint(0, len(regions), num_rows)],
            type=pa.string()
        ),
    }

    table = pa.table(data)
    print(f"done in {time.perf_counter() - start:.1f}s")
    return table


def benchmark_s3_read(s3_key: str, method: str, num_runs: int = 1) -> Dict:
    """Benchmark reading from S3."""
    times = []
    rows = 0
    suffix = ".vortex" if "vortex" in s3_key else ".parquet"

    for run in range(num_runs):
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=True) as tmp:
            # Time full download + read
            start = time.perf_counter()

            download_start = time.perf_counter()
            s3_download(s3_key, tmp.name)
            download_time = time.perf_counter() - download_start

            read_start = time.perf_counter()
            if method == "parquet":
                table = pq.read_table(tmp.name)
            elif method == "rosetta":
                table = rosetta.read(tmp.name)
            read_time = time.perf_counter() - read_start

            total_time = time.perf_counter() - start
            times.append({
                "total": total_time,
                "download": download_time,
                "read": read_time,
            })
            rows = table.num_rows

    return {
        "method": method,
        "avg_total_ms": np.mean([t["total"] for t in times]) * 1000,
        "avg_download_ms": np.mean([t["download"] for t in times]) * 1000,
        "avg_read_ms": np.mean([t["read"] for t in times]) * 1000,
        "rows": rows,
    }


def main():
    print("=" * 70)
    print("ROSETTA S3 DEMO: 10GB Scale Test")
    print("=" * 70)
    print()
    print(f"S3 Bucket: s3://{S3_BUCKET}/{S3_PREFIX}/")
    print()

    # Configuration for ~10GB total
    # 500K rows = ~28MB Parquet, so 18M rows = ~1GB
    rows_per_file = 2_000_000   # 2M rows per file = ~112MB Parquet
    num_files = 10              # 10 files = ~1.1GB (adjust for 10GB)

    # For true 10GB: rows_per_file = 18_000_000, num_files = 10
    # But that takes forever to generate, so let's do a scaled version

    # Actually let's do: 10 files x 2M rows = 20M rows = ~1.1GB
    # For 10GB: we need ~180M rows total
    # Let's do 20 files x 9M rows = 180M rows

    rows_per_file = 9_000_000   # 9M rows = ~500MB per file
    num_files = 20              # 20 files = ~10GB total

    print(f"Target: {num_files} files x {rows_per_file:,} rows = {num_files * rows_per_file:,} total rows")
    print(f"Estimated size: ~{num_files * rows_per_file * 56 / 1_000_000 / 1024:.1f} GB Parquet")
    print()

    # Check if data already exists
    print("Checking for existing data...")
    result = run_aws_cmd(["s3", "ls", f"s3://{S3_BUCKET}/{S3_PREFIX}/parquet/"])
    if result.returncode == 0 and result.stdout.strip():
        print("  Found existing data in S3!")
        use_existing = input("  Use existing data? [Y/n]: ").strip().lower()
        if use_existing != 'n':
            # Count existing files
            parquet_files = [line.split()[-1] for line in result.stdout.strip().split('\n') if line.endswith('.parquet')]
            vortex_result = run_aws_cmd(["s3", "ls", f"s3://{S3_BUCKET}/{S3_PREFIX}/vortex/"])
            vortex_files = [line.split()[-1] for line in vortex_result.stdout.strip().split('\n') if line.endswith('.vortex')]

            print(f"  Found {len(parquet_files)} Parquet files, {len(vortex_files)} Vortex files")

            parquet_keys = [f"{S3_PREFIX}/parquet/{f}" for f in parquet_files]
            vortex_keys = [f"{S3_PREFIX}/vortex/{f}" for f in vortex_files]

            # Skip to benchmark
            total_parquet_size = 0
            total_vortex_size = 0

            # Get sizes
            for key in parquet_keys[:3]:  # Sample first 3
                result = run_aws_cmd(["s3api", "head-object", "--bucket", S3_BUCKET, "--key", key])
                if result.returncode == 0:
                    import json
                    total_parquet_size += json.loads(result.stdout).get("ContentLength", 0)
            total_parquet_size = total_parquet_size / 3 * len(parquet_keys)

            for key in vortex_keys[:3]:
                result = run_aws_cmd(["s3api", "head-object", "--bucket", S3_BUCKET, "--key", key])
                if result.returncode == 0:
                    import json
                    total_vortex_size += json.loads(result.stdout).get("ContentLength", 0)
            total_vortex_size = total_vortex_size / 3 * len(vortex_keys)

            print(f"  Estimated Parquet: {total_parquet_size/1024/1024/1024:.1f} GB")
            print(f"  Estimated Vortex: {total_vortex_size/1024/1024/1024:.1f} GB")

            # Jump to benchmark
            run_benchmark(parquet_keys, vortex_keys, total_parquet_size, total_vortex_size)
            return

    # Clean up and generate fresh data
    print("Cleaning up previous demo data...")
    s3_delete_prefix(S3_PREFIX)
    print()

    # ========================================================================
    # STEP 1: Generate and upload data
    # ========================================================================
    print("=" * 70)
    print("STEP 1: Generating and Uploading 10GB to S3")
    print("=" * 70)
    print()
    print("This will take a while... (generating 180M rows)")
    print()

    parquet_keys = []
    vortex_keys = []
    total_parquet_size = 0
    total_vortex_size = 0

    with tempfile.TemporaryDirectory() as tmpdir:
        for i in range(num_files):
            print(f"  File {i+1}/{num_files}:")

            # Generate data
            data = generate_sales_data(rows_per_file, seed=42 + i, file_id=i)

            # Write and upload Parquet
            parquet_local = f"{tmpdir}/part-{i:04d}.parquet"
            print("      Writing Parquet...", end=" ", flush=True)
            start = time.perf_counter()
            pq.write_table(data, parquet_local, compression="snappy")
            parquet_size = os.path.getsize(parquet_local)
            print(f"{parquet_size/1024/1024:.0f}MB in {time.perf_counter()-start:.1f}s")
            total_parquet_size += parquet_size

            parquet_s3_key = f"{S3_PREFIX}/parquet/part-{i:04d}.parquet"
            print("      Uploading Parquet...", end=" ", flush=True)
            upload_time = s3_upload(parquet_local, parquet_s3_key)
            print(f"done in {upload_time:.1f}s")
            parquet_keys.append(parquet_s3_key)

            # Remove local parquet to save space
            os.remove(parquet_local)

            # Write and upload Vortex
            vortex_local = f"{tmpdir}/part-{i:04d}.vortex"
            print("      Writing Vortex...", end=" ", flush=True)
            start = time.perf_counter()
            vio.write(data, vortex_local)
            vortex_size = os.path.getsize(vortex_local)
            print(f"{vortex_size/1024/1024:.0f}MB in {time.perf_counter()-start:.1f}s")
            total_vortex_size += vortex_size

            vortex_s3_key = f"{S3_PREFIX}/vortex/part-{i:04d}.vortex"
            print("      Uploading Vortex...", end=" ", flush=True)
            upload_time = s3_upload(vortex_local, vortex_s3_key)
            print(f"done in {upload_time:.1f}s")
            vortex_keys.append(vortex_s3_key)

            # Remove local vortex
            os.remove(vortex_local)

            # Free memory
            del data

            print()

    run_benchmark(parquet_keys, vortex_keys, total_parquet_size, total_vortex_size)


def run_benchmark(parquet_keys, vortex_keys, total_parquet_size, total_vortex_size):
    """Run the S3 read benchmark."""

    print()
    print("-" * 70)
    print("Storage Summary:")
    print(f"  Total Parquet: {total_parquet_size/1024/1024/1024:.2f} GB")
    print(f"  Total Vortex:  {total_vortex_size/1024/1024/1024:.2f} GB")
    print(f"  Savings:       {(1 - total_vortex_size/total_parquet_size)*100:.1f}%")
    print("-" * 70)
    print()

    # ========================================================================
    # STEP 2: Benchmark S3 reads
    # ========================================================================
    print("=" * 70)
    print("STEP 2: Benchmarking S3 Read Performance")
    print("=" * 70)
    print()
    print("ROSETTA RUNS FIRST (cold cache)")
    print()

    # Select files to benchmark (every Nth file to sample across dataset)
    num_benchmark_files = min(5, len(parquet_keys))
    step = len(parquet_keys) // num_benchmark_files
    benchmark_indices = [i * step for i in range(num_benchmark_files)]

    rosetta_results = []
    parquet_results = []

    # ROSETTA FIRST
    print("Phase 1: Reading Vortex via ROSETTA")
    print("-" * 50)
    for idx, i in enumerate(benchmark_indices):
        vx_key = vortex_keys[i]
        print(f"  [{idx+1}/{num_benchmark_files}] {vx_key.split('/')[-1]}...", end=" ", flush=True)
        r = benchmark_s3_read(vx_key, "rosetta", num_runs=1)
        print(f"Total: {r['avg_total_ms']/1000:.1f}s (download: {r['avg_download_ms']/1000:.1f}s, read: {r['avg_read_ms']/1000:.1f}s)")
        rosetta_results.append(r)
    print()

    # PARQUET SECOND
    print("Phase 2: Reading PARQUET (native)")
    print("-" * 50)
    for idx, i in enumerate(benchmark_indices):
        pq_key = parquet_keys[i]
        print(f"  [{idx+1}/{num_benchmark_files}] {pq_key.split('/')[-1]}...", end=" ", flush=True)
        r = benchmark_s3_read(pq_key, "parquet", num_runs=1)
        print(f"Total: {r['avg_total_ms']/1000:.1f}s (download: {r['avg_download_ms']/1000:.1f}s, read: {r['avg_read_ms']/1000:.1f}s)")
        parquet_results.append(r)
    print()

    # ========================================================================
    # RESULTS
    # ========================================================================
    print("=" * 70)
    print("RESULTS: S3 Read Performance (10GB Scale)")
    print("=" * 70)
    print()

    avg_rosetta_total = np.mean([r["avg_total_ms"] for r in rosetta_results])
    avg_rosetta_download = np.mean([r["avg_download_ms"] for r in rosetta_results])
    avg_rosetta_read = np.mean([r["avg_read_ms"] for r in rosetta_results])

    avg_parquet_total = np.mean([r["avg_total_ms"] for r in parquet_results])
    avg_parquet_download = np.mean([r["avg_download_ms"] for r in parquet_results])
    avg_parquet_read = np.mean([r["avg_read_ms"] for r in parquet_results])

    print(f"{'Method':<25} {'Download':<15} {'Read':<15} {'Total':<15} {'vs Parquet':<12}")
    print("-" * 82)
    print(f"{'Parquet (baseline)':<25} {avg_parquet_download/1000:>8.1f}s      {avg_parquet_read/1000:>8.1f}s      {avg_parquet_total/1000:>8.1f}s      {'--':<12}")
    print(f"{'Rosetta (Vortex)':<25} {avg_rosetta_download/1000:>8.1f}s      {avg_rosetta_read/1000:>8.1f}s      {avg_rosetta_total/1000:>8.1f}s      {avg_parquet_total/avg_rosetta_total:.2f}x faster")
    print()

    speedup = avg_parquet_total / avg_rosetta_total
    download_speedup = avg_parquet_download / avg_rosetta_download
    size_ratio = total_vortex_size / total_parquet_size

    print("-" * 70)
    print("Analysis:")
    print("-" * 70)
    print(f"  Storage reduction:     {(1-size_ratio)*100:.0f}% smaller ({total_vortex_size/1024/1024/1024:.1f}GB vs {total_parquet_size/1024/1024/1024:.1f}GB)")
    print(f"  Download speedup:      {download_speedup:.2f}x faster")
    print(f"  Overall speedup:       {speedup:.2f}x faster")
    print()
    print(f"  Time saved per file:   {(avg_parquet_total - avg_rosetta_total)/1000:.1f}s")
    print(f"  Time saved for 10GB:   {(avg_parquet_total - avg_rosetta_total)/1000 * len(parquet_keys):.0f}s")
    print()

    # Cost analysis
    s3_cost_per_gb = 0.09  # S3 GET request + transfer
    parquet_cost = total_parquet_size / 1024 / 1024 / 1024 * s3_cost_per_gb
    vortex_cost = total_vortex_size / 1024 / 1024 / 1024 * s3_cost_per_gb

    print("-" * 70)
    print("Cost Implications (at scale):")
    print("-" * 70)
    print(f"  S3 transfer cost (Parquet): ${parquet_cost:.4f} per full scan")
    print(f"  S3 transfer cost (Vortex):  ${vortex_cost:.4f} per full scan")
    print(f"  Savings per scan:           ${parquet_cost - vortex_cost:.4f} ({(1-size_ratio)*100:.0f}%)")
    print()
    print("  At 1000 scans/day:")
    print(f"    Parquet: ${parquet_cost * 1000 * 30:.0f}/month")
    print(f"    Vortex:  ${vortex_cost * 1000 * 30:.0f}/month")
    print(f"    Savings: ${(parquet_cost - vortex_cost) * 1000 * 30:.0f}/month")
    print()

    print("=" * 70)
    print("CONCLUSION")
    print("=" * 70)
    print()
    print(f"  Rosetta + Vortex delivers {speedup:.1f}x faster queries on S3")
    print(f"  with {(1-size_ratio)*100:.0f}% storage savings")
    print()
    print("  Your existing Parquet-only tools work unchanged!")
    print()


if __name__ == "__main__":
    main()
