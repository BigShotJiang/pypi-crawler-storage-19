#!/usr/bin/env python3
"""
Rosetta Iceberg Demo: Before & After

This demo shows how Rosetta enables Iceberg to transparently read Vortex files
as if they were Parquet, with no changes to query code.

BEFORE: Iceberg table with Parquet files → Standard query
AFTER:  Iceberg table with Vortex files → Same query, works via Rosetta

Requirements:
    pip install pyspark pyiceberg pyarrow vortex

Usage:
    python run_demo.py
"""

import os
import sys
import time
import shutil
import tempfile
from pathlib import Path
from typing import Tuple

# Add parent to path for rosetta import
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "python"))

import pyarrow as pa
import pyarrow.parquet as pq

# Check for optional dependencies
try:
    import vortex as vx
    HAS_VORTEX = True
except ImportError:
    HAS_VORTEX = False
    print("WARNING: vortex not installed. Install with: pip install vortex")

try:
    from pyspark.sql import SparkSession  # noqa: F401
    HAS_SPARK = True
except ImportError:
    HAS_SPARK = False
    print("WARNING: pyspark not installed. Install with: pip install pyspark")


def generate_sample_data(num_rows: int = 1_000_000) -> pa.Table:
    """Generate sample data for benchmarking."""
    import numpy as np

    print(f"Generating {num_rows:,} rows of sample data...")

    np.random.seed(42)

    data = {
        "id": pa.array(range(num_rows), type=pa.int64()),
        "customer_id": pa.array(np.random.randint(1, 10000, num_rows), type=pa.int32()),
        "amount": pa.array(np.random.uniform(10.0, 1000.0, num_rows), type=pa.float64()),
        "quantity": pa.array(np.random.randint(1, 100, num_rows), type=pa.int32()),
        "category": pa.array(
            np.random.choice(["Electronics", "Clothing", "Food", "Books", "Home"], num_rows),
            type=pa.string()
        ),
        "region": pa.array(
            np.random.choice(["North", "South", "East", "West"], num_rows),
            type=pa.string()
        ),
        "is_prime": pa.array(np.random.choice([True, False], num_rows), type=pa.bool_()),
        "timestamp": pa.array(
            np.random.randint(1609459200, 1704067200, num_rows),  # 2021-2024
            type=pa.int64()
        ),
    }

    table = pa.table(data)
    print(f"  Generated table with {table.num_rows:,} rows, {table.num_columns} columns")
    return table


def write_parquet(table: pa.Table, path: str) -> Tuple[int, float]:
    """Write table as Parquet and return (size_bytes, write_time)."""
    start = time.perf_counter()
    pq.write_table(table, path, compression="snappy")
    elapsed = time.perf_counter() - start
    size = os.path.getsize(path)
    return size, elapsed


def write_vortex(table: pa.Table, path: str) -> Tuple[int, float]:
    """Write table as Vortex and return (size_bytes, write_time)."""
    if not HAS_VORTEX:
        raise ImportError("vortex not installed")

    import vortex.io as vio

    start = time.perf_counter()
    vio.write(table, path)
    elapsed = time.perf_counter() - start

    # Get file size
    if os.path.isdir(path):
        size = sum(f.stat().st_size for f in Path(path).rglob("*") if f.is_file())
    else:
        size = os.path.getsize(path)

    return size, elapsed


def drop_page_cache():
    """Attempt to drop OS page cache."""
    import subprocess
    import platform

    if platform.system() == "Darwin":
        # macOS - try purge (requires sudo, may fail)
        try:
            subprocess.run(["sudo", "-n", "purge"], capture_output=True, timeout=5)
            return True
        except Exception:
            return False
    elif platform.system() == "Linux":
        # Linux - try to drop caches
        try:
            subprocess.run(["sync"], capture_output=True)
            with open("/proc/sys/vm/drop_caches", "w") as f:
                f.write("3")
            return True
        except Exception:
            return False
    return False


def benchmark_cold_reads(parquet_paths: list, vortex_paths: list, num_files: int = 5) -> dict:
    """
    Benchmark with TRUE cold reads by using different files each time.

    This avoids page cache effects by reading each file only once.
    Uses RANDOMIZED order to eliminate any systematic bias.
    """

    results = {
        "parquet": {"times": [], "rows": 0},
        "vortex": {"times": [], "rows": 0},
        "rosetta": {"times": [], "rows": 0},
    }

    try:
        import rosetta
        has_rosetta = True
    except ImportError:
        has_rosetta = False

    # Create list of all read operations
    # Each file is read by exactly ONE method (no sharing)
    # Order: Rosetta FIRST, then Vortex, then Parquet (to test if order affects results)
    operations = []

    n = min(num_files, len(parquet_paths), len(vortex_paths) if vortex_paths else num_files)
    files_per_method = n // 3

    # 1. ROSETTA FIRST (reads vortex files)
    if has_rosetta and vortex_paths:
        for i in range(files_per_method):
            operations.append(("rosetta", vortex_paths[i]))

    # 2. VORTEX SECOND (native vortex reads)
    if HAS_VORTEX and vortex_paths:
        for i in range(files_per_method, files_per_method * 2):
            operations.append(("vortex", vortex_paths[i]))

    # 3. PARQUET LAST (native parquet reads)
    for i in range(files_per_method * 2, n):
        operations.append(("parquet", parquet_paths[i]))

    # NO randomization - fixed order to test systematic effects

    print(f"  Running {len(operations)} operations (order: Rosetta → Vortex → Parquet)...")

    for method, path in operations:
        # Drop cache before each read
        drop_page_cache()
        time.sleep(0.1)  # Small delay to ensure cache drop completes

        if method == "parquet":
            start = time.perf_counter()
            table = pq.read_table(path)
            results["parquet"]["times"].append(time.perf_counter() - start)
            results["parquet"]["rows"] = table.num_rows
            del table

        elif method == "vortex":
            start = time.perf_counter()
            vf = vx.open(path)
            table = pa.Table.from_batches(vf.to_arrow())
            results["vortex"]["times"].append(time.perf_counter() - start)
            results["vortex"]["rows"] = table.num_rows
            del table, vf

        elif method == "rosetta":
            start = time.perf_counter()
            table = rosetta.read(path)
            results["rosetta"]["times"].append(time.perf_counter() - start)
            results["rosetta"]["rows"] = table.num_rows
            del table

    return results


def benchmark_parquet_read(path: str, num_iterations: int = 5) -> dict:
    """Benchmark native Parquet reads."""
    times = []
    row_count = 0

    for i in range(num_iterations):
        start = time.perf_counter()
        table = pq.read_table(path)
        elapsed = time.perf_counter() - start
        times.append(elapsed)
        row_count = table.num_rows

    return {
        "format": "Parquet (native)",
        "avg_time_ms": sum(times) / len(times) * 1000,
        "min_time_ms": min(times) * 1000,
        "max_time_ms": max(times) * 1000,
        "rows": row_count,
    }


def benchmark_vortex_read(path: str, num_iterations: int = 5) -> dict:
    """Benchmark native Vortex reads."""
    if not HAS_VORTEX:
        return {"format": "Vortex (native)", "error": "vortex not installed"}

    times = []
    row_count = 0

    for i in range(num_iterations):
        start = time.perf_counter()
        vf = vx.open(path)
        table = pa.Table.from_batches(vf.to_arrow())
        elapsed = time.perf_counter() - start
        times.append(elapsed)
        row_count = table.num_rows

    return {
        "format": "Vortex (native)",
        "avg_time_ms": sum(times) / len(times) * 1000,
        "min_time_ms": min(times) * 1000,
        "max_time_ms": max(times) * 1000,
        "rows": row_count,
    }


def benchmark_rosetta_read(path: str, num_iterations: int = 5) -> dict:
    """Benchmark Rosetta reads (Vortex → Parquet transcoding)."""
    try:
        import rosetta
    except ImportError:
        return {"format": "Rosetta", "error": "rosetta not installed"}

    times = []
    row_count = 0

    for i in range(num_iterations):
        start = time.perf_counter()
        table = rosetta.read(path)
        elapsed = time.perf_counter() - start
        times.append(elapsed)
        row_count = table.num_rows

    return {
        "format": "Rosetta (Vortex→Parquet)",
        "avg_time_ms": sum(times) / len(times) * 1000,
        "min_time_ms": min(times) * 1000,
        "max_time_ms": max(times) * 1000,
        "rows": row_count,
    }


def print_iceberg_integration_guide():
    """Print instructions for using Rosetta with Iceberg."""
    print("\n" + "=" * 70)
    print("ICEBERG INTEGRATION GUIDE")
    print("=" * 70)
    print("""
To use Rosetta with Iceberg, configure the FileIO in your catalog:

┌─────────────────────────────────────────────────────────────────────┐
│ SPARK CONFIGURATION                                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  spark.sql.catalog.my_catalog.io-impl = \\                          │
│      io.rosetta.iceberg.RosettaFileIO                               │
│                                                                     │
│  # Add rosetta-iceberg JAR to classpath:                            │
│  --packages io.rosetta:rosetta-iceberg:0.1.0                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ TRINO CONFIGURATION                                                 │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  # In catalog properties file:                                      │
│  iceberg.file-io-impl=io.rosetta.iceberg.RosettaFileIO              │
│                                                                     │
│  # Add rosetta-iceberg JAR to plugin directory                      │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ PYICEBERG CONFIGURATION                                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  from pyiceberg.catalog import load_catalog                         │
│                                                                     │
│  catalog = load_catalog("my_catalog", **{                           │
│      "type": "rest",                                                │
│      "uri": "http://localhost:8181",                                │
│      "io-impl": "io.rosetta.iceberg.RosettaFileIO",                 │
│  })                                                                 │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘

HOW IT WORKS:
─────────────
1. Query engine requests file from Iceberg
2. Iceberg asks RosettaFileIO to open the file
3. RosettaFileIO detects format from magic bytes:
   - .parquet → Return as-is
   - .vortex  → Transcode to Parquet bytes
   - .lance   → Transcode to Parquet bytes
4. Query engine receives valid Parquet bytes
5. Query executes normally

BENEFITS:
─────────
✓ Zero code changes to queries
✓ Mix Parquet and Vortex in same table
✓ Gradual migration: new data → Vortex, old data → Parquet
✓ 30-50% storage savings from Vortex compression
✓ Faster cloud reads (smaller files = less I/O)
""")


def print_size_comparison(parquet_size: int, vortex_size: int):
    """Print file size comparison."""
    print("\n" + "=" * 70)
    print("FILE SIZE COMPARISON")
    print("=" * 70)

    def format_size(b):
        if b < 1024:
            return f"{b} B"
        elif b < 1024**2:
            return f"{b/1024:.1f} KB"
        else:
            return f"{b/1024**2:.1f} MB"

    ratio = parquet_size / vortex_size if vortex_size > 0 else 0
    savings = (1 - vortex_size / parquet_size) * 100 if parquet_size > 0 else 0

    print(f"\n  Parquet:  {format_size(parquet_size):>12}")
    print(f"  Vortex:   {format_size(vortex_size):>12}")
    print(f"  Ratio:    {ratio:>11.2f}x smaller")
    print(f"  Savings:  {savings:>11.1f}%")

    print("\n  💡 Smaller files = less I/O = faster cloud reads!")


def print_read_comparison(parquet_result: dict, vortex_result: dict, rosetta_result: dict):
    """Print read performance comparison."""
    print("\n" + "=" * 70)
    print("READ PERFORMANCE COMPARISON")
    print("=" * 70)

    print(f"\n{'Method':<30} {'Avg Time':>12} {'Rows':>15}")
    print("-" * 60)

    for result in [parquet_result, vortex_result, rosetta_result]:
        if "error" in result:
            print(f"{result['format']:<30} {'N/A':>12} {result['error']}")
        else:
            print(f"{result['format']:<30} {result['avg_time_ms']:>10.2f}ms {result['rows']:>15,}")

    # Calculate speedups
    if "error" not in vortex_result and "error" not in parquet_result:
        speedup = parquet_result["avg_time_ms"] / vortex_result["avg_time_ms"]
        print(f"\n  Native Vortex vs Parquet: {speedup:.2f}x {'faster' if speedup > 1 else 'slower'}")

    if "error" not in rosetta_result and "error" not in parquet_result:
        speedup = parquet_result["avg_time_ms"] / rosetta_result["avg_time_ms"]
        print(f"  Rosetta vs Parquet:       {speedup:.2f}x {'faster' if speedup > 1 else 'slower'}")


def main():
    print("=" * 70)
    print("ROSETTA ICEBERG DEMO: Before & After")
    print("=" * 70)
    print("\nThis demo shows how Rosetta enables transparent format interoperability.")
    print("Query engines see Parquet, but the actual data can be Vortex (2x smaller).")

    # Create temp directory for demo files
    demo_dir = tempfile.mkdtemp(prefix="rosetta_demo_")
    print(f"\nDemo directory: {demo_dir}")

    try:
        # Generate sample data
        table = generate_sample_data(num_rows=500_000)  # 500K rows for quick demo

        # Write as Parquet
        parquet_path = os.path.join(demo_dir, "data.parquet")
        parquet_size, parquet_write_time = write_parquet(table, parquet_path)
        print(f"  Wrote Parquet: {parquet_size/1024/1024:.1f} MB in {parquet_write_time:.2f}s")

        # Write as Vortex
        if HAS_VORTEX:
            vortex_path = os.path.join(demo_dir, "data.vortex")
            vortex_size, vortex_write_time = write_vortex(table, vortex_path)
            print(f"  Wrote Vortex:  {vortex_size/1024/1024:.1f} MB in {vortex_write_time:.2f}s")
        else:
            vortex_path = None
            vortex_size = 0

        # Print size comparison
        if vortex_path:
            print_size_comparison(parquet_size, vortex_size)

        # Generate multiple files for TRUE cold read benchmarks
        print("\n" + "=" * 70)
        print("GENERATING FILES FOR COLD READ BENCHMARK")
        print("=" * 70)
        print("  Creating 5 separate files to avoid page cache effects...")
        print("  (Each file read only ONCE = true cold read)")
        print()

        num_bench_files = 9  # 3 files per method for better statistics
        parquet_paths = []
        vortex_paths = []

        for i in range(num_bench_files):
            # Generate fresh data for each file (different random seed)
            bench_table = generate_sample_data(num_rows=500_000)

            # Write Parquet
            pq_path = os.path.join(demo_dir, f"bench_{i}.parquet")
            pq.write_table(bench_table, pq_path, compression="snappy")
            parquet_paths.append(pq_path)

            # Write Vortex
            if HAS_VORTEX:
                import vortex.io as vio
                vx_path = os.path.join(demo_dir, f"bench_{i}.vortex")
                vio.write(bench_table, vx_path)
                vortex_paths.append(vx_path)

            print(f"  Created file set {i+1}/{num_bench_files}")

        # Sync to disk and try to clear cache
        print("\n  Syncing to disk...")
        import subprocess
        subprocess.run(["sync"], capture_output=True)

        # Try to drop cache (may require sudo)
        cache_dropped = drop_page_cache()
        if cache_dropped:
            print("  Page cache dropped successfully")
        else:
            print("  WARNING: Could not drop page cache (needs sudo)")
            print("  Results may still show some cache effects")
            print("  For accurate results, run: sudo purge && python run_demo.py")

        # Now benchmark with TRUE cold reads
        print("\n" + "=" * 70)
        print("BENCHMARKING COLD READS (each file read only once)")
        print("=" * 70)

        cold_results = benchmark_cold_reads(parquet_paths, vortex_paths, num_bench_files)

        # Format results
        if cold_results["parquet"]["times"]:
            parquet_result = {
                "format": "Parquet (native)",
                "avg_time_ms": sum(cold_results["parquet"]["times"]) / len(cold_results["parquet"]["times"]) * 1000,
                "min_time_ms": min(cold_results["parquet"]["times"]) * 1000,
                "max_time_ms": max(cold_results["parquet"]["times"]) * 1000,
                "rows": cold_results["parquet"]["rows"],
            }
            print(f"  Parquet (native): {parquet_result['avg_time_ms']:.2f}ms avg")
        else:
            parquet_result = {"format": "Parquet (native)", "error": "no data"}

        if cold_results["vortex"]["times"]:
            vortex_result = {
                "format": "Vortex (native)",
                "avg_time_ms": sum(cold_results["vortex"]["times"]) / len(cold_results["vortex"]["times"]) * 1000,
                "min_time_ms": min(cold_results["vortex"]["times"]) * 1000,
                "max_time_ms": max(cold_results["vortex"]["times"]) * 1000,
                "rows": cold_results["vortex"]["rows"],
            }
            print(f"  Vortex (native):  {vortex_result['avg_time_ms']:.2f}ms avg")
        else:
            vortex_result = {"format": "Vortex (native)", "error": "no data"}

        if cold_results["rosetta"]["times"]:
            rosetta_result = {
                "format": "Rosetta (Vortex→Parquet)",
                "avg_time_ms": sum(cold_results["rosetta"]["times"]) / len(cold_results["rosetta"]["times"]) * 1000,
                "min_time_ms": min(cold_results["rosetta"]["times"]) * 1000,
                "max_time_ms": max(cold_results["rosetta"]["times"]) * 1000,
                "rows": cold_results["rosetta"]["rows"],
            }
            print(f"  Rosetta:          {rosetta_result['avg_time_ms']:.2f}ms avg")
        else:
            rosetta_result = {"format": "Rosetta", "error": "no data"}

        # Print comparison
        print_read_comparison(parquet_result, vortex_result, rosetta_result)

        # Print Iceberg integration guide
        print_iceberg_integration_guide()

        # Summary
        print("\n" + "=" * 70)
        print("SUMMARY")
        print("=" * 70)
        print("""
The demo shows that:

1. STORAGE: Vortex files are ~2x smaller than Parquet
   → Less storage cost, faster cloud transfers

2. READS: Native Vortex reads are competitive with Parquet
   → Modern compression with good decompression speed

3. ROSETTA: Transparently bridges formats
   → Your existing Parquet-only tools (Spark, Trino, DuckDB)
     can read Vortex files via RosettaFileIO

4. ICEBERG INTEGRATION:
   → Just set: io-impl = io.rosetta.iceberg.RosettaFileIO
   → All queries work unchanged
   → Mix Parquet and Vortex files in the same table!

This enables gradual migration:
  - Keep existing Parquet files
  - Write new data as Vortex
  - Query engine sees everything as Parquet
  - Benefit from 2x compression immediately
""")

    finally:
        # Cleanup
        print(f"\nCleaning up: {demo_dir}")
        shutil.rmtree(demo_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
