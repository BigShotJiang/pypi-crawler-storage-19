# Rosetta Development Guidelines

## Vision

**READ FIRST**: [VISION.md](./VISION.md) - The north star for all development.

**IMPLEMENTATION GAPS**: [GAPS.md](./GAPS.md) - Tracks what's missing vs vision.

**One-liner**: Rosetta is the universal bridge that enables any data tool to read any columnar format.

---

## Implementation Status (Updated 2026-01-08)

### Scorecard

| Component | Status | File Location | Notes |
|-----------|--------|---------------|-------|
| FormatReader trait | ✅ 100% | `src/readers/mod.rs` | Trait complete |
| Statistics structs | ✅ 100% | `src/stats.rs` | Types complete |
| Expression language | ✅ 100% | `src/expr.rs` | Expr enum complete |
| Partition support | ✅ 100% | `src/partition.rs` | Types complete |
| **Expr → Parquet** | 🔄 In Progress | `src/expr/to_parquet.rs` | Translation code |
| **Expr → Vortex** | 🔄 In Progress | `src/expr/to_vortex.rs` | Translation code |
| **Expr → Lance** | 🔄 In Progress | `src/expr/to_lance.rs` | Translation code |
| **ParquetReader pushdown** | 🔄 In Progress | `src/readers/parquet_reader.rs` | Actually push filters |
| **VortexReader pushdown** | 🔄 In Progress | `src/readers/vortex_reader.rs` | Actually push filters |
| **LanceReader pushdown** | 🔄 In Progress | `src/readers/lance_reader.rs` | Actually push filters |
| **UnifiedReader methods** | 🔄 In Progress | `src/readers/unified.rs` | Expose new methods |
| **Python new features** | 🔄 In Progress | `src/python.rs` | Statistics, filters |
| Iceberg FileIO | ✅ 100% | `src/iceberg/fileio.rs` | |
| Object store | ✅ 100% | `src/object_store_utils.rs` | |
| Transcoding | ✅ 100% | `src/transcoder.rs` | |
| Enterprise hooks | ✅ 100% | `src/readers/mod.rs`, `src/transcoder.rs` | |

### Critical Path to 100%

1. **Expression Translation** - `src/expr/*.rs` - Convert Expr to native formats
2. **Reader push_filter()** - Override default in each reader
3. **UnifiedReader** - Expose statistics(), partitions(), push_filter()
4. **Python** - Add statistics(), partitions(), filter support

---

## Core Abstractions

### 1. FormatReader Trait (`src/readers/mod.rs`)

The primary abstraction for reading columnar formats:

```rust
#[async_trait]
pub trait FormatReader: Send + Sync {
    /// Get the Arrow schema
    fn schema(&self) -> SchemaRef;

    /// Get statistics for query optimization
    fn statistics(&self) -> Option<Statistics>;

    /// Push a filter predicate down to the reader
    fn push_filter(&mut self, filter: &Expr) -> Result<FilterPushdownResult>;

    /// Push column projection down to the reader
    fn push_projection(&mut self, columns: &[String]) -> Result<()>;

    /// Get partition information for distributed execution
    fn partitions(&self) -> Result<Vec<Partition>>;

    /// Read all data as RecordBatches
    async fn read_all(&self) -> Result<Vec<RecordBatch>>;

    /// Read a specific partition
    async fn read_partition(&self, partition: &Partition) -> Result<Vec<RecordBatch>>;
}
```

### 2. Statistics (`src/stats.rs`)

Statistics for query optimization:

```rust
pub struct Statistics {
    /// Total number of rows
    pub num_rows: Option<usize>,
    /// Total byte size
    pub total_byte_size: Option<usize>,
    /// Per-column statistics
    pub column_statistics: HashMap<String, ColumnStatistics>,
}

pub struct ColumnStatistics {
    pub null_count: Option<usize>,
    pub distinct_count: Option<usize>,
    pub min_value: Option<ScalarValue>,
    pub max_value: Option<ScalarValue>,
}
```

### 3. Expression Language (`src/expr.rs`)

Unified filter expressions that translate to native format filters:

```rust
pub enum Expr {
    /// Column reference
    Column(String),
    /// Literal value
    Literal(ScalarValue),
    /// Binary expression (left op right)
    BinaryExpr { left: Box<Expr>, op: Operator, right: Box<Expr> },
    /// NOT expression
    Not(Box<Expr>),
    /// IS NULL
    IsNull(Box<Expr>),
    /// IS NOT NULL
    IsNotNull(Box<Expr>),
    /// IN list
    InList { expr: Box<Expr>, list: Vec<Expr>, negated: bool },
}

pub enum Operator {
    Eq, NotEq, Lt, LtEq, Gt, GtEq, And, Or,
    Plus, Minus, Multiply, Divide, Modulo,
}

pub enum ScalarValue {
    Null, Boolean(bool), Int8(i8), Int16(i16), Int32(i32), Int64(i64),
    UInt8(u8), UInt16(u16), UInt32(u32), UInt64(u64),
    Float32(f32), Float64(f64), Utf8(String), Binary(Vec<u8>),
    Date32(i32), Date64(i64),
    TimestampMicrosecond(i64, Option<Arc<str>>),
    // ... more types
}
```

### 4. Partitions (`src/partition.rs`)

Support for distributed execution:

```rust
pub struct Partition {
    /// Unique partition identifier
    pub id: usize,
    /// File path or URL
    pub location: String,
    /// Byte range within file (for row group-level partitioning)
    pub byte_range: Option<Range<usize>>,
    /// Row group indices (for Parquet)
    pub row_groups: Option<Vec<usize>>,
    /// Estimated row count
    pub row_count: Option<usize>,
    /// Estimated byte size
    pub byte_size: Option<usize>,
}
```

---

## Expression Translation

Each reader translates Rosetta expressions to native format:

### Parquet → arrow-rs RowFilter
```rust
impl ParquetReader {
    fn translate_to_row_filter(&self, expr: &Expr) -> Option<RowFilter> {
        // Convert to ArrowPredicateFn
    }
}
```

### Vortex → vortex::expr::Expr
```rust
impl VortexReader {
    fn translate_to_vortex_expr(&self, expr: &Expr) -> Option<vortex::expr::Expr> {
        // Convert to Vortex native filter
    }
}
```

### Lance → SQL String
```rust
impl LanceReader {
    fn translate_to_sql(&self, expr: &Expr) -> Option<String> {
        // Convert to "column > value AND ..."
    }
}
```

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Tool Integrations                         │
│  rosetta-spark │ rosetta-iceberg │ rosetta-duckdb │ etc.   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    rosetta-core (Rust)                       │
│  FormatReader trait │ Expression language │ Statistics      │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Format Readers                            │
│  ParquetReader │ VortexReader │ LanceReader │ F3Reader      │
└─────────────────────────────────────────────────────────────┘
```

---

## Key Design Principles

1. **Native Performance**: <5% overhead vs calling native libraries directly
2. **Full Pushdown**: Filters and projections MUST be pushed to native readers
3. **Statistics Exposure**: Query optimizers need statistics - expose them
4. **Partition-Aware**: Support distributed execution from day one
5. **Cloud-Native**: S3/GCS as first-class citizens

---

## Development Workflow

### Building

```bash
# Build Rust components (requires nightly for vortex)
cargo +nightly build --features "vortex-reader,lance-reader"

# Build with all features
cargo +nightly build --all-features

# Build Python bindings
RUSTUP_TOOLCHAIN=nightly maturin develop --features "vortex-reader,lance-reader,python"

# Build release
cargo +nightly build --release --features "vortex-reader,lance-reader"
```

### Testing

```bash
# Run all tests
cargo +nightly test --features "vortex-reader,lance-reader"

# Run specific test
cargo +nightly test test_statistics --features "vortex-reader"

# Run with output
cargo +nightly test --features "vortex-reader,lance-reader" -- --nocapture

# Run benchmarks
cargo +nightly bench --features "vortex-reader,lance-reader"
```

### Code Style

```bash
cargo fmt
cargo clippy --features "vortex-reader,lance-reader"
```

---

## File Structure

```
src/
├── lib.rs                 # Main library exports
├── error.rs               # Error types
├── format.rs              # FileFormat enum and detection
├── stats.rs               # Statistics structs          [NEW]
├── expr.rs                # Expression language         [NEW]
├── partition.rs           # Partition structs           [NEW]
├── transcoder.rs          # Format transcoding
├── object_store_utils.rs  # Cloud storage utilities
├── python.rs              # Python bindings
│
├── readers/
│   ├── mod.rs             # FormatReader trait
│   ├── unified.rs         # UnifiedReader facade
│   ├── parquet_reader.rs  # Parquet with pushdown
│   ├── vortex_reader.rs   # Vortex with pushdown
│   ├── lance_reader.rs    # Lance with pushdown
│   └── f3_reader.rs       # F3/WASM reader
│
├── writers/
│   └── mod.rs             # Parquet writer
│
├── iceberg/
│   └── fileio.rs          # Iceberg FileIO impl
│
├── fuse/
│   └── filesystem.rs      # FUSE filesystem (optional)
│
└── proxy/
    └── mod.rs             # S3 proxy (optional)
```

---

## Performance Targets

| Operation | Target | Measurement |
|-----------|--------|-------------|
| Full table read | <5% overhead vs native | `cargo bench` |
| With filter pushdown | <10% overhead vs native | `cargo bench` |
| Format detection | <1ms | `cargo bench` |
| Schema retrieval | <100μs | `cargo bench` |

---

## Enterprise Extension Points

### Reader Hooks (`src/readers/mod.rs`)
```rust
pub trait ReaderHooks: Send + Sync {
    fn on_read_start(&self, path: &str, format: &str);
    fn on_read_complete(&self, path: &str, duration: Duration, bytes: usize, rows: usize);
    fn on_read_error(&self, path: &str, error: &str);
    fn check_cache(&self, path: &str, columns: Option<&[String]>) -> Option<Vec<RecordBatch>>;
    fn store_cache(&self, path: &str, columns: Option<&[String]>, batches: &[RecordBatch]);
}
```

### Transcode Hooks (`src/transcoder.rs`)
```rust
pub trait TranscodeHooks: Send + Sync {
    fn check_cache(&self, source_path: &str, source_format: FileFormat) -> Option<Bytes>;
    fn store_cache(&self, source_path: &str, result: &TranscodeResult);
    fn on_transcode_complete(&self, source: &str, result: &TranscodeResult, duration: Duration);
}
```

---

## References

- [VISION.md](./VISION.md) - Full project vision and roadmap
- [Apache Arrow](https://arrow.apache.org/) - In-memory format
- [Vortex](https://github.com/spiraldb/vortex) - Next-gen columnar format
- [Lance](https://github.com/lancedb/lance) - ML-optimized format
- [Apache Iceberg](https://iceberg.apache.org/) - Table format specification
