# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors
"""
Type stubs for the Rosetta native Rust module.

These type hints provide IDE autocomplete and type checking support
for the rosetta package.
"""

from typing import Any, Optional, Sequence

import pyarrow as pa

__version__: str

# =============================================================================
# Classes
# =============================================================================

class FileFormat:
    """File format information."""

    @property
    def name(self) -> str:
        """Format name (e.g., 'Parquet v1', 'Vortex', 'Lance')."""
        ...

    @property
    def extension(self) -> str:
        """File extension (e.g., 'parquet', 'vortex', 'lance')."""
        ...

    @property
    def requires_wasm(self) -> bool:
        """Whether this format requires WASM runtime."""
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...


class Expr:
    """
    Filter expression for predicate pushdown.

    Build expressions using col() and lit() functions, then combine
    with comparison and logical operators.

    Example:
        >>> from rosetta import col, lit
        >>> filter = col("age").gt(lit(30)).and_(col("status").eq(lit("active")))
        >>> table = rosetta.read("data.parquet", filter=filter)
    """

    def eq(self, other: Expr) -> Expr:
        """Equality comparison (=)."""
        ...

    def not_eq(self, other: Expr) -> Expr:
        """Not-equal comparison (!=)."""
        ...

    def lt(self, other: Expr) -> Expr:
        """Less-than comparison (<)."""
        ...

    def lt_eq(self, other: Expr) -> Expr:
        """Less-than-or-equal comparison (<=)."""
        ...

    def gt(self, other: Expr) -> Expr:
        """Greater-than comparison (>)."""
        ...

    def gt_eq(self, other: Expr) -> Expr:
        """Greater-than-or-equal comparison (>=)."""
        ...

    def and_(self, other: Expr) -> Expr:
        """Logical AND."""
        ...

    def or_(self, other: Expr) -> Expr:
        """Logical OR."""
        ...

    def not_(self) -> Expr:
        """Logical NOT."""
        ...

    def is_null(self) -> Expr:
        """IS NULL check."""
        ...

    def is_not_null(self) -> Expr:
        """IS NOT NULL check."""
        ...

    def between(self, low: Expr, high: Expr) -> Expr:
        """BETWEEN check (inclusive)."""
        ...

    def like(self, pattern: str) -> Expr:
        """LIKE pattern match."""
        ...

    def ilike(self, pattern: str) -> Expr:
        """ILIKE (case-insensitive) pattern match."""
        ...

    def to_sql(self) -> str:
        """Convert expression to SQL string representation."""
        ...

    def columns(self) -> list[str]:
        """Get all column names referenced in this expression."""
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...


class ColumnStatistics:
    """Statistics for a single column."""

    @property
    def null_count(self) -> Optional[int]:
        """Number of null values."""
        ...

    @property
    def distinct_count(self) -> Optional[int]:
        """Number of distinct values."""
        ...

    @property
    def min_value(self) -> Any:
        """Minimum value (type depends on column type)."""
        ...

    @property
    def max_value(self) -> Any:
        """Maximum value (type depends on column type)."""
        ...

    def __repr__(self) -> str: ...


class Statistics:
    """
    File statistics for query optimization.

    Provides row counts, byte sizes, and per-column statistics
    that query optimizers can use to prune files or row groups.

    Example:
        >>> stats = rosetta.statistics("data.parquet")
        >>> print(stats.num_rows)
        >>> print(stats.column("age").min_value)
    """

    @property
    def num_rows(self) -> Optional[int]:
        """Total number of rows."""
        ...

    @property
    def total_byte_size(self) -> Optional[int]:
        """Total byte size."""
        ...

    def column(self, name: str) -> Optional[ColumnStatistics]:
        """Get statistics for a specific column."""
        ...

    def column_names(self) -> list[str]:
        """Get all column names with statistics."""
        ...

    def __repr__(self) -> str: ...


class Partition:
    """
    Partition information for distributed execution.

    Partitions represent units of work that can be distributed
    across multiple workers in a distributed query engine.
    """

    @property
    def id(self) -> int:
        """Partition identifier."""
        ...

    @property
    def location(self) -> str:
        """File path or URL."""
        ...

    @property
    def row_count(self) -> Optional[int]:
        """Estimated row count."""
        ...

    @property
    def byte_size(self) -> Optional[int]:
        """Estimated byte size."""
        ...

    @property
    def row_groups(self) -> Optional[list[int]]:
        """Row group indices (if applicable)."""
        ...

    def is_whole_file(self) -> bool:
        """Check if this is a whole-file partition."""
        ...

    def __repr__(self) -> str: ...


# =============================================================================
# Functions
# =============================================================================

def detect_format(path: str) -> FileFormat:
    """
    Detect the format of a file.

    Args:
        path: Path to the file (local or S3/GCS URL)

    Returns:
        FileFormat object with format information

    Example:
        >>> fmt = rosetta.detect_format("data.parquet")
        >>> print(fmt.name)  # "Parquet v1"
    """
    ...


def read(
    path: str,
    columns: Optional[Sequence[str]] = None,
    filter: Optional[Expr] = None,
) -> pa.Table:
    """
    Read a columnar file and return a PyArrow Table.

    Supports Parquet, Vortex, and Lance formats. Format is auto-detected.
    Both column projection and filter pushdown are pushed to the native
    reader for optimal performance.

    Args:
        path: Path to the file (local path or S3/GCS URL)
        columns: Optional list of column names to read (column projection)
        filter: Optional filter expression for predicate pushdown

    Returns:
        PyArrow Table containing the data

    Example:
        >>> import rosetta
        >>> from rosetta import col, lit
        >>>
        >>> # Basic read
        >>> table = rosetta.read("data.parquet")
        >>>
        >>> # With column projection
        >>> table = rosetta.read("data.parquet", columns=["id", "name"])
        >>>
        >>> # With filter pushdown
        >>> table = rosetta.read(
        ...     "data.parquet",
        ...     filter=col("age").gt(lit(30))
        ... )
        >>>
        >>> # With both
        >>> table = rosetta.read(
        ...     "data.parquet",
        ...     columns=["id", "name", "age"],
        ...     filter=col("age").gt(lit(30)).and_(col("status").eq(lit("active")))
        ... )
    """
    ...


def read_batches(
    path: str,
    columns: Optional[Sequence[str]] = None,
    filter: Optional[Expr] = None,
) -> list[pa.RecordBatch]:
    """
    Read a columnar file and return a list of PyArrow RecordBatches.

    Useful for processing large files in chunks without loading
    everything into memory at once.

    Args:
        path: Path to the file (local path or S3/GCS URL)
        columns: Optional list of column names to read
        filter: Optional filter expression for predicate pushdown

    Returns:
        List of PyArrow RecordBatches

    Example:
        >>> batches = rosetta.read_batches("large_file.parquet")
        >>> for batch in batches:
        ...     process(batch)
    """
    ...


def file_info(path: str) -> dict[str, Any]:
    """
    Get file information (schema, row groups, format).

    Args:
        path: Path to the file (local path or S3/GCS URL)

    Returns:
        Dictionary with keys:
        - 'format': FileFormat object
        - 'schema': PyArrow Schema
        - 'num_row_groups': Number of row groups

    Example:
        >>> info = rosetta.file_info("data.parquet")
        >>> print(info["schema"])
        >>> print(info["num_row_groups"])
    """
    ...


def statistics(path: str) -> Optional[Statistics]:
    """
    Get statistics for query optimization.

    Returns statistics about the file including row counts, byte sizes,
    and per-column min/max values and null counts.

    Args:
        path: Path to the file (local path or S3/GCS URL)

    Returns:
        Statistics object, or None if statistics are not available

    Example:
        >>> stats = rosetta.statistics("data.parquet")
        >>> print(stats.num_rows)
        >>> print(stats.column("age").min_value)
    """
    ...


def partitions(path: str) -> list[Partition]:
    """
    Get partition information for distributed execution.

    Returns a list of partitions that can be used to split work across
    multiple workers in a distributed query engine.

    Args:
        path: Path to the file (local path or S3/GCS URL)

    Returns:
        List of Partition objects

    Example:
        >>> parts = rosetta.partitions("data.parquet")
        >>> for part in parts:
        ...     # Schedule work for this partition
        ...     process_partition(part.id, part.location)
    """
    ...


def col(name: str) -> Expr:
    """
    Create a column reference expression.

    Args:
        name: Column name

    Returns:
        Expression referencing the column

    Example:
        >>> from rosetta import col, lit
        >>> expr = col("age").gt(lit(30))
    """
    ...


def lit(value: bool | int | float | str | bytes | None) -> Expr:
    """
    Create a literal value expression.

    Args:
        value: Literal value (bool, int, float, str, bytes, or None)

    Returns:
        Expression containing the literal value

    Example:
        >>> from rosetta import col, lit
        >>> expr = col("age").gt(lit(30))
        >>> expr = col("status").eq(lit("active"))
    """
    ...
