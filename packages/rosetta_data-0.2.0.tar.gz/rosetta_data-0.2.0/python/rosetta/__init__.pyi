# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors
"""
Type stubs for the rosetta package.

This provides IDE autocomplete and type checking for the rosetta module.
"""

from typing import Any, Optional, Sequence

import pyarrow as pa

# Re-export everything from the native module
from rosetta.rosetta import (
    FileFormat as FileFormat,
    Expr as Expr,
    Statistics as Statistics,
    ColumnStatistics as ColumnStatistics,
    Partition as Partition,
    read as read,
    read_batches as read_batches,
    detect_format as detect_format,
    file_info as file_info,
    statistics as statistics,
    partitions as partitions,
    col as col,
    lit as lit,
    __version__ as __version__,
)

# Additional functions defined in __init__.py

def open(path: str, **kwargs: Any) -> dict[str, Any]:
    """
    Open a file and return file info. For full data, use read().

    Args:
        path: Path to the file

    Returns:
        Dictionary with file metadata (format, schema, num_row_groups)
    """
    ...


def scan(
    path: str,
    columns: Optional[Sequence[str]] = None,
    filter: Optional[Expr] = None,
) -> pa.Table:
    """
    Scan a file with optional projection and filter.
    Alias for read() with explicit parameters.

    Args:
        path: Path to the file
        columns: Optional list of columns to read
        filter: Optional filter expression (use col() and lit() to build)

    Returns:
        PyArrow Table
    """
    ...


__all__: list[str]
