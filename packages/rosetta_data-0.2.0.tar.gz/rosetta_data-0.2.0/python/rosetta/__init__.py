# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""
Rosetta: Universal columnar format bridge.

Read Parquet, Vortex, and Lance files with a single unified API.
Rosetta is built on a high-performance Rust core with native format readers.

Key features:
- Automatic format detection (magic bytes + extensions)
- Filter pushdown to native readers (Parquet, Vortex, Lance)
- Column projection for efficient I/O
- Unified statistics API for query optimization
- Partition information for distributed execution
- Near-native performance via Rust core

Basic Usage:
    import rosetta

    # Reads ANY format, returns PyArrow Table
    table = rosetta.read("data.parquet")
    table = rosetta.read("data.vortex")
    table = rosetta.read("data.lance")

    # Column projection (pushed to native reader)
    table = rosetta.read("data.vortex", columns=["col1", "col2"])

    # Filter pushdown
    from rosetta import col, lit
    table = rosetta.read(
        "data.parquet",
        filter=col("age").gt(lit(30))
    )

Advanced Usage:
    # Get file metadata without reading data
    info = rosetta.file_info("data.vortex")
    print(info["schema"])

    # Get statistics for query optimization
    stats = rosetta.statistics("data.parquet")
    print(stats.num_rows, stats.column("age").min_value)

    # Read as batches (returns list of RecordBatches)
    batches = rosetta.read_batches("large.parquet")
    for batch in batches:
        process(batch)

    # Get partitions for distributed execution
    parts = rosetta.partitions("data.parquet")
    for part in parts:
        print(f"Partition {part.id}: {part.row_count} rows")
"""

from __future__ import annotations

# Import everything from the native Rust module
# The module is named "rosetta" (from Cargo.toml [lib] name)
# PyO3 builds it as a native extension
try:
    from rosetta.rosetta import (
        # Core read functions
        read,
        read_batches,
        # Format detection
        detect_format,
        FileFormat,
        # Metadata
        file_info,
        statistics,
        partitions,
        # Expression API
        col,
        lit,
        Expr,  # Already named Expr via #[pyclass(name = "Expr")]
        # Statistics classes (named via #[pyclass(name = "...")])
        Statistics,
        ColumnStatistics,
        Partition,
        # Version
        __version__,
    )
except ImportError as e:
    # Provide helpful error message if native module not built
    import sys
    raise ImportError(
        f"Failed to import rosetta native module: {e}\n\n"
        "This usually means the Rust extension wasn't built. Try:\n"
        "  1. pip install rosetta  (from PyPI, includes pre-built wheels)\n"
        "  2. maturin develop      (for local development)\n"
        "  3. pip install maturin && maturin build\n\n"
        f"Python: {sys.version}\n"
        f"Platform: {sys.platform}"
    ) from e

# For convenience: expose common operations at module level
def open(path: str, **kwargs):
    """
    Open a file and return file info. For full data, use read().

    Args:
        path: Path to the file

    Returns:
        FileInfo object with metadata
    """
    return file_info(path)


def scan(path: str, columns=None, filter=None):
    """
    Scan a file with optional projection and filter.
    Alias for read() with explicit parameters.

    Args:
        path: Path to the file
        columns: Optional list of columns to read
        filter: Optional filter expression (use col() and lit() to build)

    Returns:
        PyArrow Table
    """
    return read(path, columns=columns, filter=filter)


__all__ = [
    # Core functions
    "read",
    "read_batches",
    "open",
    "scan",
    "detect_format",
    "file_info",
    "statistics",
    "partitions",
    # Expression building
    "col",
    "lit",
    "Expr",
    # Types
    "FileFormat",
    "Statistics",
    "ColumnStatistics",
    "Partition",
    "__version__",
]
