"""Type stubs for rosetta Python bindings."""

from typing import Dict, List, Optional, Any

import pyarrow as pa

__version__: str

class FileFormat:
    """File format information.

    Attributes:
        name: Human-readable format name (e.g., "Parquet v1", "Vortex")
        extension: File extension (e.g., "parquet", "vortex")
        requires_wasm: Whether format requires WASM runtime for decoding
    """

    @property
    def name(self) -> str: ...

    @property
    def extension(self) -> str: ...

    @property
    def requires_wasm(self) -> bool: ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

def detect_format(path: str) -> FileFormat:
    """Detect the format of a file.

    Args:
        path: Path to the file to detect

    Returns:
        FileFormat object describing the detected format

    Raises:
        IOError: If the file cannot be read or format cannot be detected
    """
    ...

def read(path: str, columns: Optional[List[str]] = None) -> pa.Table:
    """Read a columnar file and return a PyArrow Table.

    Supports Parquet (v1/v2), Vortex, and Lance formats with automatic
    format detection.

    Args:
        path: Path to the file to read
        columns: Optional list of column names to read (column projection).
            If None, all columns are read.

    Returns:
        PyArrow Table containing the data

    Raises:
        IOError: If the file cannot be read
        ValueError: If a specified column does not exist

    Example:
        >>> import rosetta
        >>> table = rosetta.read("data.parquet")
        >>> table.num_rows
        1000
        >>>
        >>> # With column projection
        >>> table = rosetta.read("data.parquet", columns=["id", "name"])
        >>> table.column_names
        ['id', 'name']
    """
    ...

def read_batches(path: str, columns: Optional[List[str]] = None) -> List[pa.RecordBatch]:
    """Read a columnar file and return a list of PyArrow RecordBatches.

    This is useful for streaming processing of large files as it preserves
    the original batch structure from the file.

    Args:
        path: Path to the file to read
        columns: Optional list of column names to read (column projection).
            If None, all columns are read.

    Returns:
        List of PyArrow RecordBatches

    Raises:
        IOError: If the file cannot be read
        ValueError: If a specified column does not exist

    Example:
        >>> import rosetta
        >>> batches = rosetta.read_batches("data.parquet")
        >>> total_rows = sum(b.num_rows for b in batches)
    """
    ...

def file_info(path: str) -> Dict[str, Any]:
    """Get information about a columnar file.

    Returns metadata including format, schema, and row group count without
    reading the full file data.

    Args:
        path: Path to the file

    Returns:
        Dictionary containing:
            - "format": FileFormat object
            - "schema": PyArrow Schema
            - "num_row_groups": Number of row groups in the file

    Raises:
        IOError: If the file cannot be read

    Example:
        >>> import rosetta
        >>> info = rosetta.file_info("data.parquet")
        >>> info["format"].name
        'Parquet v1'
        >>> info["schema"].names
        ['id', 'name', 'value']
        >>> info["num_row_groups"]
        1
    """
    ...
