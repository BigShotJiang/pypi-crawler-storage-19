# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""Comprehensive benchmarks for Rosetta vs native readers.

Benchmarks compare:
- rosetta.read() vs native readers for each format
- Various data sizes (small, medium, large)
- Operations: full read, projection, filtering
- All supported formats: Parquet, Vortex, Lance
"""

import tempfile
import shutil
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
import pytest

import rosetta


# ============================================================================
# Test Data Generators
# ============================================================================

def generate_test_data(num_rows: int) -> pa.Table:
    """Generate test data with various column types."""
    import random
    random.seed(42)

    return pa.table({
        'id': list(range(num_rows)),
        'int_col': [random.randint(-1000, 1000) for _ in range(num_rows)],
        'float_col': [random.random() * 1000 for _ in range(num_rows)],
        'str_col': [f'value_{i % 100}' for i in range(num_rows)],
        'bool_col': [i % 2 == 0 for i in range(num_rows)],
    })


# ============================================================================
# Fixtures for Benchmark Data
# ============================================================================

@pytest.fixture(scope='module')
def small_data():
    """Small dataset (1K rows)."""
    return generate_test_data(1_000)


@pytest.fixture(scope='module')
def medium_data():
    """Medium dataset (100K rows)."""
    return generate_test_data(100_000)


@pytest.fixture(scope='module')
def large_data():
    """Large dataset (1M rows)."""
    return generate_test_data(1_000_000)


@pytest.fixture(scope='module')
def parquet_files(small_data, medium_data, large_data):
    """Create Parquet files for benchmarking."""
    tmpdir = tempfile.mkdtemp()

    files = {}
    for name, data in [('small', small_data), ('medium', medium_data), ('large', large_data)]:
        path = Path(tmpdir) / f'{name}.parquet'
        pq.write_table(data, path, compression='snappy')
        files[name] = str(path)

    yield files
    shutil.rmtree(tmpdir)


@pytest.fixture(scope='module')
def vortex_files(small_data, medium_data, large_data):
    """Create Vortex files for benchmarking."""
    try:
        import vortex as vx
    except ImportError:
        pytest.skip("vortex-data not installed")

    tmpdir = tempfile.mkdtemp()

    files = {}
    for name, data in [('small', small_data), ('medium', medium_data), ('large', large_data)]:
        path = Path(tmpdir) / f'{name}.vortex'
        vx.io.write(data, str(path))
        files[name] = str(path)

    yield files
    shutil.rmtree(tmpdir)


@pytest.fixture(scope='module')
def lance_files(small_data, medium_data, large_data):
    """Create Lance datasets for benchmarking."""
    try:
        import lance
    except ImportError:
        pytest.skip("pylance not installed")

    tmpdir = tempfile.mkdtemp()

    files = {}
    for name, data in [('small', small_data), ('medium', medium_data), ('large', large_data)]:
        path = Path(tmpdir) / f'{name}.lance'
        lance.write_dataset(data, str(path))
        files[name] = str(path)

    yield files
    shutil.rmtree(tmpdir)


# ============================================================================
# Parquet Benchmarks
# ============================================================================

class TestParquetBenchmarks:
    """Benchmarks for Parquet format."""

    # --- Full Read ---

    def test_parquet_small_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow read (1K rows)."""
        path = parquet_files['small']
        result = benchmark(pq.read_table, path)
        assert result.num_rows == 1_000

    def test_parquet_small_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta read (1K rows)."""
        path = parquet_files['small']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 1_000

    def test_parquet_medium_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow read (100K rows)."""
        path = parquet_files['medium']
        result = benchmark(pq.read_table, path)
        assert result.num_rows == 100_000

    def test_parquet_medium_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta read (100K rows)."""
        path = parquet_files['medium']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 100_000

    def test_parquet_large_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow read (1M rows)."""
        path = parquet_files['large']
        result = benchmark(pq.read_table, path)
        assert result.num_rows == 1_000_000

    def test_parquet_large_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta read (1M rows)."""
        path = parquet_files['large']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 1_000_000

    # --- Column Projection ---

    def test_parquet_projection_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow read with projection."""
        path = parquet_files['medium']
        result = benchmark(pq.read_table, path, columns=['id', 'str_col'])
        assert result.num_columns == 2

    def test_parquet_projection_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta read with projection."""
        path = parquet_files['medium']
        result = benchmark(rosetta.read, path, columns=['id', 'str_col'])
        assert result.num_columns == 2

    # --- Filter Pushdown ---

    def test_parquet_filter_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow read with filter."""
        path = parquet_files['medium']
        result = benchmark(pq.read_table, path, filters=[('int_col', '>', 500)])
        assert result.num_rows > 0

    def test_parquet_filter_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta read with filter."""
        path = parquet_files['medium']
        result = benchmark(rosetta.read, path, filters=[('int_col', '>', 500)])
        assert result.num_rows > 0

    # --- Combined Projection + Filter ---

    def test_parquet_combined_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow with projection + filter."""
        path = parquet_files['medium']
        result = benchmark(
            pq.read_table, path,
            columns=['id', 'int_col'],
            filters=[('int_col', '>', 0)]
        )
        assert result.num_columns == 2

    def test_parquet_combined_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta with projection + filter."""
        path = parquet_files['medium']
        result = benchmark(
            rosetta.read, path,
            columns=['id', 'int_col'],
            filters=[('int_col', '>', 0)]
        )
        assert result.num_columns == 2


# ============================================================================
# Vortex Benchmarks
# ============================================================================

class TestVortexBenchmarks:
    """Benchmarks for Vortex format."""

    # --- Full Read ---

    def test_vortex_small_native(self, benchmark, vortex_files):
        """Benchmark: Native Vortex read (1K rows)."""
        import vortex as vx
        import pyarrow as pa
        path = vortex_files['small']

        def native_read():
            vf = vx.open(path)
            return pa.Table.from_batches(vf.to_arrow())

        result = benchmark(native_read)
        assert result.num_rows == 1_000

    def test_vortex_small_rosetta(self, benchmark, vortex_files):
        """Benchmark: Rosetta read (1K rows)."""
        path = vortex_files['small']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 1_000

    def test_vortex_medium_native(self, benchmark, vortex_files):
        """Benchmark: Native Vortex read (100K rows)."""
        import vortex as vx
        import pyarrow as pa
        path = vortex_files['medium']

        def native_read():
            vf = vx.open(path)
            return pa.Table.from_batches(vf.to_arrow())

        result = benchmark(native_read)
        assert result.num_rows == 100_000

    def test_vortex_medium_rosetta(self, benchmark, vortex_files):
        """Benchmark: Rosetta read (100K rows)."""
        path = vortex_files['medium']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 100_000

    def test_vortex_large_native(self, benchmark, vortex_files):
        """Benchmark: Native Vortex read (1M rows)."""
        import vortex as vx
        import pyarrow as pa
        path = vortex_files['large']

        def native_read():
            vf = vx.open(path)
            return pa.Table.from_batches(vf.to_arrow())

        result = benchmark(native_read)
        assert result.num_rows == 1_000_000

    def test_vortex_large_rosetta(self, benchmark, vortex_files):
        """Benchmark: Rosetta read (1M rows)."""
        path = vortex_files['large']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 1_000_000

    # --- Column Projection ---

    def test_vortex_projection_native(self, benchmark, vortex_files):
        """Benchmark: Native Vortex read with projection."""
        import vortex as vx
        path = vortex_files['medium']

        def native_read():
            vf = vx.open(path)
            return vf.scan(projection=['id', 'str_col']).read_all().to_arrow_table()

        result = benchmark(native_read)
        assert result.num_columns == 2

    def test_vortex_projection_rosetta(self, benchmark, vortex_files):
        """Benchmark: Rosetta read with projection."""
        path = vortex_files['medium']
        result = benchmark(rosetta.read, path, columns=['id', 'str_col'])
        assert result.num_columns == 2

    # --- Filter Pushdown ---

    def test_vortex_filter_native(self, benchmark, vortex_files):
        """Benchmark: Native Vortex read with filter."""
        import vortex as vx
        import vortex.expr as ve
        path = vortex_files['medium']

        def native_read():
            vf = vx.open(path)
            return vf.scan(expr=ve.column('int_col') > 500).read_all().to_arrow_table()

        result = benchmark(native_read)
        assert result.num_rows > 0

    def test_vortex_filter_rosetta(self, benchmark, vortex_files):
        """Benchmark: Rosetta read with filter."""
        path = vortex_files['medium']
        result = benchmark(rosetta.read, path, filters=[('int_col', '>', 500)])
        assert result.num_rows > 0


# ============================================================================
# Lance Benchmarks
# ============================================================================

class TestLanceBenchmarks:
    """Benchmarks for Lance format."""

    # --- Full Read ---

    def test_lance_small_native(self, benchmark, lance_files):
        """Benchmark: Native Lance read (1K rows)."""
        import lance
        path = lance_files['small']

        def native_read():
            ds = lance.dataset(path)
            return ds.to_table()

        result = benchmark(native_read)
        assert result.num_rows == 1_000

    def test_lance_small_rosetta(self, benchmark, lance_files):
        """Benchmark: Rosetta read (1K rows)."""
        path = lance_files['small']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 1_000

    def test_lance_medium_native(self, benchmark, lance_files):
        """Benchmark: Native Lance read (100K rows)."""
        import lance
        path = lance_files['medium']

        def native_read():
            ds = lance.dataset(path)
            return ds.to_table()

        result = benchmark(native_read)
        assert result.num_rows == 100_000

    def test_lance_medium_rosetta(self, benchmark, lance_files):
        """Benchmark: Rosetta read (100K rows)."""
        path = lance_files['medium']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 100_000

    def test_lance_large_native(self, benchmark, lance_files):
        """Benchmark: Native Lance read (1M rows)."""
        import lance
        path = lance_files['large']

        def native_read():
            ds = lance.dataset(path)
            return ds.to_table()

        result = benchmark(native_read)
        assert result.num_rows == 1_000_000

    def test_lance_large_rosetta(self, benchmark, lance_files):
        """Benchmark: Rosetta read (1M rows)."""
        path = lance_files['large']
        result = benchmark(rosetta.read, path)
        assert result.num_rows == 1_000_000

    # --- Column Projection ---

    def test_lance_projection_native(self, benchmark, lance_files):
        """Benchmark: Native Lance read with projection."""
        import lance
        path = lance_files['medium']

        def native_read():
            ds = lance.dataset(path)
            return ds.to_table(columns=['id', 'str_col'])

        result = benchmark(native_read)
        assert result.num_columns == 2

    def test_lance_projection_rosetta(self, benchmark, lance_files):
        """Benchmark: Rosetta read with projection."""
        path = lance_files['medium']
        result = benchmark(rosetta.read, path, columns=['id', 'str_col'])
        assert result.num_columns == 2

    # --- Filter Pushdown ---

    def test_lance_filter_native(self, benchmark, lance_files):
        """Benchmark: Native Lance read with filter."""
        import lance
        path = lance_files['medium']

        def native_read():
            ds = lance.dataset(path)
            return ds.to_table(filter="int_col > 500")

        result = benchmark(native_read)
        assert result.num_rows > 0

    def test_lance_filter_rosetta(self, benchmark, lance_files):
        """Benchmark: Rosetta read with filter."""
        path = lance_files['medium']
        result = benchmark(rosetta.read, path, filters=[('int_col', '>', 500)])
        assert result.num_rows > 0


# ============================================================================
# Format Detection Benchmarks
# ============================================================================

class TestFormatDetectionBenchmarks:
    """Benchmarks for format detection."""

    def test_detect_by_extension_parquet(self, benchmark, parquet_files):
        """Benchmark: Format detection by extension (.parquet)."""
        path = parquet_files['small']
        result = benchmark(rosetta.detect_format, path)
        assert result == rosetta.FileFormat.PARQUET

    def test_detect_by_magic_bytes(self, benchmark, parquet_files):
        """Benchmark: Format detection by magic bytes."""
        # Create a file without extension
        import tempfile

        # Create temp file without extension, copy parquet content
        fd, no_ext_path = tempfile.mkstemp(suffix='')
        import os
        os.close(fd)
        shutil.copy(parquet_files['small'], no_ext_path)

        try:
            result = benchmark(rosetta.detect_format, no_ext_path)
            assert result == rosetta.FileFormat.PARQUET
        finally:
            Path(no_ext_path).unlink()


# ============================================================================
# Streaming Read Benchmarks (read_batches)
# ============================================================================

class TestStreamingBenchmarks:
    """Benchmarks for streaming/batch reads."""

    def test_parquet_batches_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow batch iteration."""
        path = parquet_files['medium']

        def read_all_batches():
            pf = pq.ParquetFile(path)
            batches = list(pf.iter_batches())
            return sum(b.num_rows for b in batches)

        total = benchmark(read_all_batches)
        assert total == 100_000

    def test_parquet_batches_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta batch iteration."""
        path = parquet_files['medium']

        def read_all_batches():
            batches = list(rosetta.read_batches(path))
            return sum(b.num_rows for b in batches)

        total = benchmark(read_all_batches)
        assert total == 100_000


# ============================================================================
# File Info Benchmarks
# ============================================================================

class TestFileInfoBenchmarks:
    """Benchmarks for metadata operations."""

    def test_parquet_info_native(self, benchmark, parquet_files):
        """Benchmark: Native PyArrow metadata read."""
        path = parquet_files['medium']

        def get_info():
            pf = pq.ParquetFile(path)
            return pf.metadata

        result = benchmark(get_info)
        assert result.num_rows == 100_000

    def test_parquet_info_rosetta(self, benchmark, parquet_files):
        """Benchmark: Rosetta file_info."""
        path = parquet_files['medium']
        result = benchmark(rosetta.file_info, path)
        assert result['num_rows'] == 100_000
