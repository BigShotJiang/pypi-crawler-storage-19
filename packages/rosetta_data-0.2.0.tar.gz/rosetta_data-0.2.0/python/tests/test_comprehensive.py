# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""Comprehensive tests for Rosetta thin wrapper.

Tests cover:
- All formats: Parquet, Vortex, Lance
- Predicate pushdown with all operators
- Partial reads (column projection)
- Combined projection + filters
- Multiple filters (AND logic)
- Different data types
- Streaming reads (read_batches)
- Metadata access (file_info)
- Native reader access (open)
"""

import pytest
import tempfile
import os
import shutil

import pyarrow as pa
import pyarrow.parquet as pq

# Optional imports
try:
    import vortex as vx  # noqa: F401
    import vortex.io as vio
    HAS_VORTEX = True
except ImportError:
    HAS_VORTEX = False

try:
    import lance
    HAS_LANCE = True
except ImportError:
    HAS_LANCE = False

import rosetta
from rosetta import FileFormat


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def sample_table():
    """Create a sample PyArrow table with various data types."""
    return pa.table({
        'id': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'name': ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve',
                 'Frank', 'Grace', 'Henry', 'Ivy', 'Jack'],
        'age': [25, 30, 35, 28, 42, 19, 55, 33, 27, 45],
        'score': [85.5, 92.3, 78.9, 95.1, 88.0, 72.5, 99.2, 81.4, 90.0, 76.8],
        'active': [True, True, False, True, False, True, True, False, True, False],
        'category': ['A', 'B', 'A', 'C', 'B', 'A', 'C', 'B', 'A', 'C'],
    })


@pytest.fixture
def parquet_file(sample_table):
    """Create a temporary Parquet file."""
    path = tempfile.mktemp(suffix='.parquet')
    pq.write_table(sample_table, path)
    yield path
    if os.path.exists(path):
        os.unlink(path)


@pytest.fixture
def vortex_file(sample_table):
    """Create a temporary Vortex file."""
    if not HAS_VORTEX:
        pytest.skip("vortex-data not installed")
    path = tempfile.mktemp(suffix='.vortex')
    vio.write(sample_table, path)
    yield path
    if os.path.exists(path):
        os.unlink(path)


@pytest.fixture
def lance_dataset(sample_table):
    """Create a temporary Lance dataset."""
    if not HAS_LANCE:
        pytest.skip("lance not installed")
    path = tempfile.mkdtemp(suffix='.lance')
    lance.write_dataset(sample_table, path)
    yield path
    if os.path.exists(path):
        shutil.rmtree(path)


# =============================================================================
# Format Detection Tests
# =============================================================================

class TestFormatDetection:
    """Test format detection from magic bytes and extensions."""

    def test_detect_parquet_by_extension(self, parquet_file):
        assert rosetta.detect_format(parquet_file) == FileFormat.PARQUET

    def test_detect_vortex_by_extension(self, vortex_file):
        assert rosetta.detect_format(vortex_file) == FileFormat.VORTEX

    def test_detect_lance_by_directory(self, lance_dataset):
        assert rosetta.detect_format(lance_dataset) == FileFormat.LANCE

    def test_detect_unknown_extension(self):
        assert rosetta.detect_format('/fake/path/file.xyz') == FileFormat.UNKNOWN


# =============================================================================
# Basic Read Tests
# =============================================================================

class TestBasicRead:
    """Test basic read functionality for all formats."""

    def test_read_parquet(self, parquet_file, sample_table):
        result = rosetta.read(parquet_file)
        assert result.num_rows == sample_table.num_rows
        assert result.num_columns == sample_table.num_columns
        assert result.column_names == sample_table.column_names

    def test_read_vortex(self, vortex_file, sample_table):
        result = rosetta.read(vortex_file)
        assert result.num_rows == sample_table.num_rows
        assert result.num_columns == sample_table.num_columns

    def test_read_lance(self, lance_dataset, sample_table):
        result = rosetta.read(lance_dataset)
        assert result.num_rows == sample_table.num_rows
        assert result.num_columns == sample_table.num_columns


# =============================================================================
# Column Projection (Partial Reads) Tests
# =============================================================================

class TestColumnProjection:
    """Test column projection (reading subset of columns)."""

    @pytest.mark.parametrize("columns", [
        ['id'],
        ['name', 'age'],
        ['id', 'name', 'score'],
        ['active', 'category'],
    ])
    def test_parquet_projection(self, parquet_file, columns):
        result = rosetta.read(parquet_file, columns=columns)
        assert result.num_columns == len(columns)
        assert set(result.column_names) == set(columns)

    @pytest.mark.parametrize("columns", [
        ['id'],
        ['name', 'age'],
        ['id', 'name', 'score'],
    ])
    def test_vortex_projection(self, vortex_file, columns):
        result = rosetta.read(vortex_file, columns=columns)
        assert result.num_columns == len(columns)

    @pytest.mark.parametrize("columns", [
        ['id'],
        ['name', 'age'],
        ['id', 'name', 'score'],
    ])
    def test_lance_projection(self, lance_dataset, columns):
        result = rosetta.read(lance_dataset, columns=columns)
        assert result.num_columns == len(columns)


# =============================================================================
# Predicate Pushdown Tests
# =============================================================================

class TestPredicatePushdown:
    """Test filter/predicate pushdown for all formats and operators."""

    # --- Equality (==) ---
    def test_parquet_filter_eq(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('category', '==', 'A')])
        df = result.to_pandas()
        assert len(df) == 4  # Alice, Charlie, Frank, Ivy
        assert all(df['category'] == 'A')

    def test_vortex_filter_eq(self, vortex_file):
        result = rosetta.read(vortex_file, filters=[('category', '==', 'A')])
        df = result.to_pandas()
        assert len(df) == 4
        assert all(df['category'] == 'A')

    def test_lance_filter_eq(self, lance_dataset):
        result = rosetta.read(lance_dataset, filters=[('category', '==', 'A')])
        df = result.to_pandas()
        assert len(df) == 4
        assert all(df['category'] == 'A')

    # --- Not Equal (!=) ---
    def test_parquet_filter_neq(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('category', '!=', 'A')])
        df = result.to_pandas()
        assert len(df) == 6  # B and C categories
        assert all(df['category'] != 'A')

    def test_vortex_filter_neq(self, vortex_file):
        result = rosetta.read(vortex_file, filters=[('category', '!=', 'A')])
        df = result.to_pandas()
        assert len(df) == 6

    def test_lance_filter_neq(self, lance_dataset):
        result = rosetta.read(lance_dataset, filters=[('category', '!=', 'A')])
        df = result.to_pandas()
        assert len(df) == 6

    # --- Greater Than (>) ---
    def test_parquet_filter_gt(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('age', '>', 35)])
        df = result.to_pandas()
        assert len(df) == 3  # Eve(42), Grace(55), Jack(45)
        assert all(df['age'] > 35)

    def test_vortex_filter_gt(self, vortex_file):
        result = rosetta.read(vortex_file, filters=[('age', '>', 35)])
        df = result.to_pandas()
        assert len(df) == 3
        assert all(df['age'] > 35)

    def test_lance_filter_gt(self, lance_dataset):
        result = rosetta.read(lance_dataset, filters=[('age', '>', 35)])
        df = result.to_pandas()
        assert len(df) == 3

    # --- Greater Than or Equal (>=) ---
    def test_parquet_filter_gte(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('age', '>=', 35)])
        df = result.to_pandas()
        assert len(df) == 4  # Charlie(35), Eve(42), Grace(55), Jack(45)
        assert all(df['age'] >= 35)

    def test_vortex_filter_gte(self, vortex_file):
        result = rosetta.read(vortex_file, filters=[('age', '>=', 35)])
        df = result.to_pandas()
        assert len(df) == 4

    def test_lance_filter_gte(self, lance_dataset):
        result = rosetta.read(lance_dataset, filters=[('age', '>=', 35)])
        df = result.to_pandas()
        assert len(df) == 4

    # --- Less Than (<) ---
    def test_parquet_filter_lt(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('score', '<', 80.0)])
        df = result.to_pandas()
        assert len(df) == 3  # Charlie(78.9), Frank(72.5), Jack(76.8)
        assert all(df['score'] < 80.0)

    def test_vortex_filter_lt(self, vortex_file):
        result = rosetta.read(vortex_file, filters=[('score', '<', 80.0)])
        df = result.to_pandas()
        assert len(df) == 3

    def test_lance_filter_lt(self, lance_dataset):
        result = rosetta.read(lance_dataset, filters=[('score', '<', 80.0)])
        df = result.to_pandas()
        assert len(df) == 3

    # --- Less Than or Equal (<=) ---
    def test_parquet_filter_lte(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('score', '<=', 80.0)])
        df = result.to_pandas()
        assert len(df) == 3  # Charlie(78.9), Frank(72.5), Jack(76.8)
        assert all(df['score'] <= 80.0)

    def test_vortex_filter_lte(self, vortex_file):
        result = rosetta.read(vortex_file, filters=[('score', '<=', 80.0)])
        df = result.to_pandas()
        assert all(df['score'] <= 80.0)

    def test_lance_filter_lte(self, lance_dataset):
        result = rosetta.read(lance_dataset, filters=[('score', '<=', 80.0)])
        df = result.to_pandas()
        assert all(df['score'] <= 80.0)


# =============================================================================
# Multiple Filters (AND Logic) Tests
# =============================================================================

class TestMultipleFilters:
    """Test multiple filters combined with AND logic."""

    def test_parquet_multiple_filters(self, parquet_file):
        # age > 25 AND score > 85
        result = rosetta.read(parquet_file, filters=[
            ('age', '>', 25),
            ('score', '>', 85.0)
        ])
        df = result.to_pandas()
        assert all(df['age'] > 25)
        assert all(df['score'] > 85.0)

    def test_vortex_multiple_filters(self, vortex_file):
        result = rosetta.read(vortex_file, filters=[
            ('age', '>', 25),
            ('score', '>', 85.0)
        ])
        df = result.to_pandas()
        assert all(df['age'] > 25)
        assert all(df['score'] > 85.0)

    def test_lance_multiple_filters(self, lance_dataset):
        result = rosetta.read(lance_dataset, filters=[
            ('age', '>', 25),
            ('score', '>', 85.0)
        ])
        df = result.to_pandas()
        assert all(df['age'] > 25)
        assert all(df['score'] > 85.0)

    def test_parquet_three_filters(self, parquet_file):
        # category == 'A' AND age < 30 AND active == True
        result = rosetta.read(parquet_file, filters=[
            ('category', '==', 'A'),
            ('age', '<', 30),
            ('active', '==', True)
        ])
        df = result.to_pandas()
        # Should be Alice(25), Frank(19), and Ivy(27)
        assert len(df) == 3
        assert all(df['category'] == 'A')
        assert all(df['age'] < 30)
        assert all(df['active'])


# =============================================================================
# Combined Projection + Filter Tests
# =============================================================================

class TestProjectionAndFilter:
    """Test combining column projection with filters."""

    def test_parquet_projection_and_filter(self, parquet_file):
        result = rosetta.read(
            parquet_file,
            columns=['name', 'age'],
            filters=[('age', '>', 30)]
        )
        assert result.num_columns == 2
        assert 'name' in result.column_names
        assert 'age' in result.column_names
        df = result.to_pandas()
        assert all(df['age'] > 30)

    def test_vortex_projection_and_filter(self, vortex_file):
        result = rosetta.read(
            vortex_file,
            columns=['name', 'score'],
            filters=[('score', '>=', 90.0)]
        )
        assert result.num_columns == 2
        df = result.to_pandas()
        assert all(df['score'] >= 90.0)

    def test_lance_projection_and_filter(self, lance_dataset):
        result = rosetta.read(
            lance_dataset,
            columns=['id', 'category'],
            filters=[('category', '==', 'B')]
        )
        assert result.num_columns == 2
        df = result.to_pandas()
        assert all(df['category'] == 'B')


# =============================================================================
# Edge Cases Tests
# =============================================================================

class TestEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_filter_returns_empty(self, parquet_file):
        """Filter that matches no rows."""
        result = rosetta.read(parquet_file, filters=[('age', '>', 100)])
        assert result.num_rows == 0

    def test_filter_returns_all(self, parquet_file):
        """Filter that matches all rows."""
        result = rosetta.read(parquet_file, filters=[('age', '>', 0)])
        assert result.num_rows == 10

    def test_single_column_projection(self, parquet_file):
        """Read only one column."""
        result = rosetta.read(parquet_file, columns=['id'])
        assert result.num_columns == 1
        assert result.column_names == ['id']

    def test_all_columns_projection(self, parquet_file, sample_table):
        """Explicitly request all columns."""
        all_cols = sample_table.column_names
        result = rosetta.read(parquet_file, columns=all_cols)
        assert result.num_columns == len(all_cols)


# =============================================================================
# File Info (Metadata) Tests
# =============================================================================

class TestFileInfo:
    """Test file_info metadata retrieval."""

    def test_parquet_file_info(self, parquet_file):
        info = rosetta.file_info(parquet_file)
        assert info['format'] == 'parquet'
        assert info['num_rows'] == 10
        assert info['num_columns'] == 6
        assert 'schema' in info
        assert 'num_row_groups' in info

    def test_vortex_file_info(self, vortex_file):
        info = rosetta.file_info(vortex_file)
        assert info['format'] == 'vortex'
        assert info['num_rows'] == 10
        assert info['num_columns'] == 6
        assert 'schema' in info

    def test_lance_file_info(self, lance_dataset):
        info = rosetta.file_info(lance_dataset)
        assert info['format'] == 'lance'
        assert info['num_rows'] == 10
        assert info['num_columns'] == 6
        assert 'schema' in info


# =============================================================================
# Native Reader Access Tests
# =============================================================================

class TestNativeReaderAccess:
    """Test open() returns native reader objects."""

    def test_open_parquet(self, parquet_file):
        reader = rosetta.open(parquet_file)
        assert type(reader).__name__ == 'ParquetFile'
        # Can use native API
        assert reader.metadata.num_rows == 10

    def test_open_vortex(self, vortex_file):
        reader = rosetta.open(vortex_file)
        assert type(reader).__name__ == 'VortexFile'
        # Can use native API
        assert len(reader) == 10

    def test_open_lance(self, lance_dataset):
        reader = rosetta.open(lance_dataset)
        assert type(reader).__name__ == 'LanceDataset'
        # Can use native API
        assert reader.count_rows() == 10


# =============================================================================
# Streaming Read (read_batches) Tests
# =============================================================================

class TestStreamingRead:
    """Test read_batches for streaming/lazy reads."""

    def test_parquet_read_batches(self, parquet_file):
        batches = list(rosetta.read_batches(parquet_file))
        assert len(batches) > 0
        total_rows = sum(b.num_rows for b in batches)
        assert total_rows == 10

    def test_parquet_read_batches_with_projection(self, parquet_file):
        batches = list(rosetta.read_batches(parquet_file, columns=['id', 'name']))
        assert len(batches) > 0
        for batch in batches:
            assert batch.num_columns == 2

    def test_lance_read_batches(self, lance_dataset):
        batches = list(rosetta.read_batches(lance_dataset))
        assert len(batches) > 0
        total_rows = sum(b.num_rows for b in batches)
        assert total_rows == 10


# =============================================================================
# Data Type Tests
# =============================================================================

class TestDataTypes:
    """Test handling of various data types."""

    def test_integer_filter(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('id', '==', 5)])
        df = result.to_pandas()
        assert len(df) == 1
        assert df.iloc[0]['name'] == 'Eve'

    def test_float_filter(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('score', '>=', 95.0)])
        df = result.to_pandas()
        assert len(df) == 2  # Diana(95.1), Grace(99.2)

    def test_string_filter(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('name', '==', 'Alice')])
        df = result.to_pandas()
        assert len(df) == 1
        assert df.iloc[0]['age'] == 25

    def test_boolean_filter_parquet(self, parquet_file):
        result = rosetta.read(parquet_file, filters=[('active', '==', True)])
        df = result.to_pandas()
        assert all(df['active'])


# =============================================================================
# Run tests if executed directly
# =============================================================================

if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
