# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""
Integration tests that verify README examples work exactly as shown.

These tests are the last line of defense before launch - if a user copies
code from the README, it MUST work on the first try.

Run with: pytest python/tests/test_readme_examples.py -v
"""

import pytest
import tempfile
import os

import pyarrow as pa
import pyarrow.parquet as pq


@pytest.fixture
def sample_parquet_file():
    """Create a sample Parquet file for testing."""
    # Create test data with various column types
    table = pa.table({
        'id': pa.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]),
        'name': pa.array(['Alice', 'Bob', 'Charlie', 'Diana', 'Eve',
                          'Frank', 'Grace', 'Henry', 'Ivy', 'Jack']),
        'age': pa.array([25, 30, 35, 40, 45, 28, 33, 50, 22, 60]),
        'status': pa.array(['active', 'inactive', 'active', 'active', 'inactive',
                           'active', 'active', 'inactive', 'active', 'active']),
        'score': pa.array([85.5, 92.0, 78.5, 88.0, 95.5, 82.0, 90.0, 75.0, 98.0, 70.0]),
    })

    with tempfile.NamedTemporaryFile(suffix='.parquet', delete=False) as f:
        pq.write_table(table, f.name)
        yield f.name

    # Cleanup
    os.unlink(f.name)


class TestReadmeQuickStart:
    """Tests that verify the Quick Start section works."""

    def test_basic_read(self, sample_parquet_file):
        """
        README example:

            import rosetta
            table = rosetta.read("data.parquet")
        """
        import rosetta

        table = rosetta.read(sample_parquet_file)

        assert table is not None
        assert table.num_rows == 10
        assert table.num_columns == 5

    def test_column_projection(self, sample_parquet_file):
        """
        README example:

            table = rosetta.read("data.parquet", columns=["id", "name"])
        """
        import rosetta

        table = rosetta.read(sample_parquet_file, columns=["id", "name"])

        assert table.num_columns == 2
        assert "id" in table.schema.names
        assert "name" in table.schema.names
        assert "age" not in table.schema.names

    def test_filter_pushdown(self, sample_parquet_file):
        """
        README example:

            from rosetta import col, lit
            table = rosetta.read(
                "data.parquet",
                filter=col("age").gt(lit(30)).and_(col("status").eq(lit("active")))
            )
        """
        import rosetta
        from rosetta import col, lit

        table = rosetta.read(
            sample_parquet_file,
            filter=col("age").gt(lit(30)).and_(col("status").eq(lit("active")))
        )

        # Should filter to rows where age > 30 AND status = 'active'
        assert table.num_rows > 0
        assert table.num_rows < 10  # Should have filtered some rows


class TestReadmeFormatDetection:
    """Tests for format detection examples."""

    def test_detect_format_parquet(self, sample_parquet_file):
        """
        README example:

            fmt = rosetta.detect_format("data.parquet")
            print(fmt.name)  # "Parquet v1"
        """
        import rosetta

        fmt = rosetta.detect_format(sample_parquet_file)

        assert "Parquet" in fmt.name

    def test_detect_format_by_extension(self):
        """
        Format detection should work by extension even if file doesn't exist.
        """
        import rosetta

        # Vortex detection by extension (fast path)
        fmt = rosetta.detect_format("test.vortex")
        assert fmt.name == "Vortex"


class TestReadmeFileInfo:
    """Tests for file_info examples."""

    def test_file_info(self, sample_parquet_file):
        """
        README example:

            info = rosetta.file_info("data.parquet")
            print(info["schema"])
            print(info["num_row_groups"])
        """
        import rosetta

        info = rosetta.file_info(sample_parquet_file)

        assert "schema" in info
        assert "num_row_groups" in info
        assert "format" in info
        assert info["num_row_groups"] >= 1


class TestReadmeStatistics:
    """Tests for statistics examples."""

    def test_statistics(self, sample_parquet_file):
        """
        README example:

            stats = rosetta.statistics("data.parquet")
            print(stats.num_rows)
            print(stats.column("age").min_value)
        """
        import rosetta

        stats = rosetta.statistics(sample_parquet_file)

        assert stats is not None
        assert stats.num_rows == 10

        # Test column statistics
        age_stats = stats.column("age")
        if age_stats is not None:
            # min_value should be 22 (Ivy's age)
            assert age_stats.min_value is not None


class TestReadmeExpressionAPI:
    """Tests for the expression API examples."""

    def test_col_and_lit(self):
        """
        README example:

            from rosetta import col, lit
            expr = col("age").gt(lit(30))
        """
        from rosetta import col, lit

        expr = col("age").gt(lit(30))

        assert "age" in expr.to_sql()
        assert "30" in expr.to_sql()

    def test_compound_expression(self):
        """
        README example:

            filter = col("age").gt(lit(30)).and_(col("status").eq(lit("active")))
        """
        from rosetta import col, lit

        filter_expr = col("age").gt(lit(30)).and_(col("status").eq(lit("active")))

        sql = filter_expr.to_sql()
        assert "age" in sql
        assert "status" in sql
        assert "30" in sql
        assert "active" in sql

    def test_between_expression(self):
        """
        Test BETWEEN expression from README example.
        """
        from rosetta import col, lit

        expr = col("age").between(lit(18), lit(65))

        sql = expr.to_sql()
        assert "age" in sql
        assert "18" in sql
        assert "65" in sql


class TestReadmeBatchReading:
    """Tests for batch reading examples."""

    def test_read_batches(self, sample_parquet_file):
        """
        README example:

            batches = rosetta.read_batches("data.parquet")
        """
        import rosetta

        batches = rosetta.read_batches(sample_parquet_file)

        assert batches is not None
        assert len(batches) > 0

        # Each batch should be a RecordBatch
        total_rows = sum(batch.num_rows for batch in batches)
        assert total_rows == 10


class TestErrorMessages:
    """Tests that verify error messages are helpful."""

    def test_file_not_found_error(self):
        """Error should include helpful hints."""
        import rosetta

        with pytest.raises(FileNotFoundError) as exc_info:
            rosetta.read("nonexistent_file.parquet")

        error_msg = str(exc_info.value)
        assert "File not found" in error_msg
        assert "Hint" in error_msg

    def test_column_not_found_error(self, sample_parquet_file):
        """Error should suggest checking schema."""
        import rosetta

        with pytest.raises(ValueError) as exc_info:
            rosetta.read(sample_parquet_file, columns=["nonexistent"])

        error_msg = str(exc_info.value)
        assert "Column not found" in error_msg
        assert "file_info" in error_msg.lower() or "schema" in error_msg.lower()


class TestImportAndVersion:
    """Tests for basic import and version."""

    def test_import(self):
        """
        README example:

            import rosetta
        """
        import rosetta
        assert rosetta is not None

    def test_version(self):
        """
        Version should be accessible.
        """
        import rosetta

        assert hasattr(rosetta, '__version__')
        assert rosetta.__version__ is not None
        assert len(rosetta.__version__) > 0

    def test_all_exports(self):
        """
        All documented exports should be available.
        """
        import rosetta

        # Core functions
        assert hasattr(rosetta, 'read')
        assert hasattr(rosetta, 'read_batches')
        assert hasattr(rosetta, 'detect_format')
        assert hasattr(rosetta, 'file_info')
        assert hasattr(rosetta, 'statistics')
        assert hasattr(rosetta, 'partitions')

        # Expression API
        assert hasattr(rosetta, 'col')
        assert hasattr(rosetta, 'lit')
        assert hasattr(rosetta, 'Expr')

        # Types
        assert hasattr(rosetta, 'FileFormat')


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
