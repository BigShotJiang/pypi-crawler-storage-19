# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""Edge case tests for Rosetta thin wrapper.

Tests cover boundary conditions, special cases, and unusual data patterns
across all supported formats (Parquet, Vortex, Lance).
"""

import pytest
import tempfile
import os
import shutil

import pyarrow as pa
import pyarrow.parquet as pq

try:
    import vortex as vx  # noqa: F401
    import vortex.io as vio
    HAS_VORTEX = True
except ImportError:
    HAS_VORTEX = False

try:
    import lance
    HAS_LANCE = True
except ImportError:
    HAS_LANCE = False

import rosetta
from rosetta import FileFormat


# =============================================================================
# Fixtures for Edge Case Data
# =============================================================================

@pytest.fixture
def empty_table():
    """Create an empty table (0 rows)."""
    return pa.table({
        'id': pa.array([], type=pa.int64()),
        'name': pa.array([], type=pa.string()),
    })


@pytest.fixture
def single_row_table():
    """Create a single-row table."""
    return pa.table({
        'id': [1],
        'name': ['single'],
        'value': [42.0],
    })


@pytest.fixture
def null_heavy_table():
    """Create a table with many nulls."""
    return pa.table({
        'id': [1, 2, None, 4, None, 6, None, None, 9, 10],
        'name': ['a', None, 'c', None, 'e', None, 'g', None, None, 'j'],
        'value': [None, None, None, None, None, 6.0, 7.0, 8.0, 9.0, 10.0],
    })


@pytest.fixture
def all_nulls_table():
    """Create a table where one column is entirely null."""
    return pa.table({
        'id': [1, 2, 3, 4, 5],
        'all_null': pa.array([None, None, None, None, None], type=pa.int64()),
        'some_data': ['a', 'b', 'c', 'd', 'e'],
    })


@pytest.fixture
def wide_table():
    """Create a wide table (100 columns)."""
    data = {f'col_{i}': list(range(10)) for i in range(100)}
    return pa.table(data)


@pytest.fixture
def unicode_table():
    """Create a table with unicode characters."""
    return pa.table({
        'id': [1, 2, 3, 4, 5],
        'name': ['日本語', 'émojis: 🎉🚀', 'Ελληνικά', 'العربية', 'עברית'],
        'mixed': ['hello', 'こんにちは', 'مرحبا', '🌍🌎🌏', 'नमस्ते'],
    })


@pytest.fixture
def special_chars_table():
    """Create a table with special characters."""
    return pa.table({
        'id': [1, 2, 3, 4, 5],
        'text': [
            "line1\nline2",  # newline
            "tab\there",     # tab
            "quote\"here",   # quote
            "back\\slash",   # backslash
            "null\x00char",  # null char
        ],
    })


@pytest.fixture
def boundary_values_table():
    """Create a table with boundary values."""
    return pa.table({
        'tiny_int': pa.array([-128, 0, 127], type=pa.int8()),
        'small_int': pa.array([-32768, 0, 32767], type=pa.int16()),
        'regular_int': pa.array([-2147483648, 0, 2147483647], type=pa.int32()),
        'big_int': pa.array([-9223372036854775808, 0, 9223372036854775807], type=pa.int64()),
        'float_special': [float('-inf'), 0.0, float('inf')],
    })


# =============================================================================
# Helper to create files in each format
# =============================================================================

def create_parquet(table):
    """Create a temp parquet file from table."""
    path = tempfile.mktemp(suffix='.parquet')
    pq.write_table(table, path)
    return path


def create_vortex(table):
    """Create a temp vortex file from table."""
    if not HAS_VORTEX:
        pytest.skip("vortex-data not installed")
    path = tempfile.mktemp(suffix='.vortex')
    vio.write(table, path)
    return path


def create_lance(table):
    """Create a temp lance dataset from table."""
    if not HAS_LANCE:
        pytest.skip("lance not installed")
    path = tempfile.mkdtemp(suffix='.lance')
    lance.write_dataset(table, path)
    return path


def cleanup(path):
    """Clean up temp file or directory."""
    if os.path.isdir(path):
        shutil.rmtree(path)
    elif os.path.exists(path):
        os.unlink(path)


# =============================================================================
# Empty Table Tests
# =============================================================================

class TestEmptyTable:
    """Test handling of empty tables (0 rows)."""

    def test_parquet_empty(self, empty_table):
        path = create_parquet(empty_table)
        try:
            result = rosetta.read(path)
            assert result.num_rows == 0
            assert result.num_columns == 2
        finally:
            cleanup(path)

    def test_vortex_empty(self, empty_table):
        path = create_vortex(empty_table)
        try:
            result = rosetta.read(path)
            assert result.num_rows == 0
        finally:
            cleanup(path)

    def test_lance_empty(self, empty_table):
        path = create_lance(empty_table)
        try:
            result = rosetta.read(path)
            assert result.num_rows == 0
        finally:
            cleanup(path)


# =============================================================================
# Single Row Tests
# =============================================================================

class TestSingleRow:
    """Test handling of single-row tables."""

    def test_parquet_single_row(self, single_row_table):
        path = create_parquet(single_row_table)
        try:
            result = rosetta.read(path)
            assert result.num_rows == 1
            assert result.column('id').to_pylist() == [1]
        finally:
            cleanup(path)

    def test_vortex_single_row(self, single_row_table):
        path = create_vortex(single_row_table)
        try:
            result = rosetta.read(path)
            assert result.num_rows == 1
        finally:
            cleanup(path)

    def test_lance_single_row(self, single_row_table):
        path = create_lance(single_row_table)
        try:
            result = rosetta.read(path)
            assert result.num_rows == 1
        finally:
            cleanup(path)

    def test_parquet_single_row_filter_match(self, single_row_table):
        path = create_parquet(single_row_table)
        try:
            result = rosetta.read(path, filters=[('id', '==', 1)])
            assert result.num_rows == 1
        finally:
            cleanup(path)

    def test_parquet_single_row_filter_no_match(self, single_row_table):
        path = create_parquet(single_row_table)
        try:
            result = rosetta.read(path, filters=[('id', '==', 999)])
            assert result.num_rows == 0
        finally:
            cleanup(path)


# =============================================================================
# Null Handling Tests
# =============================================================================

class TestNullHandling:
    """Test handling of null values."""

    def test_parquet_nulls_preserved(self, null_heavy_table):
        path = create_parquet(null_heavy_table)
        try:
            result = rosetta.read(path)
            id_list = result.column('id').to_pylist()
            assert None in id_list
            assert id_list.count(None) == 4  # indices 2, 4, 6, 7
        finally:
            cleanup(path)

    def test_vortex_nulls_preserved(self, null_heavy_table):
        path = create_vortex(null_heavy_table)
        try:
            result = rosetta.read(path)
            id_list = result.column('id').to_pylist()
            assert None in id_list
        finally:
            cleanup(path)

    def test_lance_nulls_preserved(self, null_heavy_table):
        path = create_lance(null_heavy_table)
        try:
            result = rosetta.read(path)
            id_list = result.column('id').to_pylist()
            assert None in id_list
        finally:
            cleanup(path)

    def test_parquet_all_null_column(self, all_nulls_table):
        path = create_parquet(all_nulls_table)
        try:
            result = rosetta.read(path)
            all_null_col = result.column('all_null').to_pylist()
            assert all(v is None for v in all_null_col)
        finally:
            cleanup(path)

    def test_parquet_project_null_column(self, all_nulls_table):
        path = create_parquet(all_nulls_table)
        try:
            result = rosetta.read(path, columns=['all_null'])
            assert result.num_columns == 1
        finally:
            cleanup(path)


# =============================================================================
# Wide Table Tests (Many Columns)
# =============================================================================

class TestWideTable:
    """Test handling of wide tables (many columns)."""

    def test_parquet_wide_read_all(self, wide_table):
        path = create_parquet(wide_table)
        try:
            result = rosetta.read(path)
            assert result.num_columns == 100
            assert result.num_rows == 10
        finally:
            cleanup(path)

    def test_parquet_wide_projection(self, wide_table):
        path = create_parquet(wide_table)
        try:
            # Read only 3 of 100 columns
            result = rosetta.read(path, columns=['col_0', 'col_50', 'col_99'])
            assert result.num_columns == 3
        finally:
            cleanup(path)

    def test_vortex_wide_projection(self, wide_table):
        path = create_vortex(wide_table)
        try:
            result = rosetta.read(path, columns=['col_0', 'col_99'])
            assert result.num_columns == 2
        finally:
            cleanup(path)


# =============================================================================
# Unicode and Special Characters Tests
# =============================================================================

class TestUnicode:
    """Test handling of unicode characters."""

    def test_parquet_unicode(self, unicode_table):
        path = create_parquet(unicode_table)
        try:
            result = rosetta.read(path)
            names = result.column('name').to_pylist()
            assert '日本語' in names
            assert any('🎉' in n for n in names)
        finally:
            cleanup(path)

    def test_vortex_unicode(self, unicode_table):
        path = create_vortex(unicode_table)
        try:
            result = rosetta.read(path)
            names = result.column('name').to_pylist()
            assert '日本語' in names
        finally:
            cleanup(path)

    def test_lance_unicode(self, unicode_table):
        path = create_lance(unicode_table)
        try:
            result = rosetta.read(path)
            names = result.column('name').to_pylist()
            assert '日本語' in names
        finally:
            cleanup(path)

    def test_parquet_unicode_filter(self, unicode_table):
        path = create_parquet(unicode_table)
        try:
            result = rosetta.read(path, filters=[('name', '==', '日本語')])
            assert result.num_rows == 1
        finally:
            cleanup(path)


class TestSpecialCharacters:
    """Test handling of special characters."""

    def test_parquet_special_chars(self, special_chars_table):
        path = create_parquet(special_chars_table)
        try:
            result = rosetta.read(path)
            texts = result.column('text').to_pylist()
            assert any('\n' in t for t in texts)
            assert any('\t' in t for t in texts)
        finally:
            cleanup(path)


# =============================================================================
# Boundary Value Tests
# =============================================================================

class TestBoundaryValues:
    """Test handling of boundary values."""

    def test_parquet_int_boundaries(self, boundary_values_table):
        path = create_parquet(boundary_values_table)
        try:
            result = rosetta.read(path)
            big_ints = result.column('big_int').to_pylist()
            assert -9223372036854775808 in big_ints
            assert 9223372036854775807 in big_ints
        finally:
            cleanup(path)

    def test_parquet_float_special_values(self, boundary_values_table):
        path = create_parquet(boundary_values_table)
        try:
            result = rosetta.read(path)
            floats = result.column('float_special').to_pylist()
            import math
            assert math.isinf(floats[0]) and floats[0] < 0  # -inf
            assert math.isinf(floats[2]) and floats[2] > 0  # +inf
        finally:
            cleanup(path)

    def test_parquet_filter_at_boundary(self, boundary_values_table):
        path = create_parquet(boundary_values_table)
        try:
            result = rosetta.read(path, filters=[('tiny_int', '>=', 127)])
            assert result.num_rows == 1
        finally:
            cleanup(path)


# =============================================================================
# Large Data Tests
# =============================================================================

class TestLargeData:
    """Test handling of larger datasets."""

    @pytest.fixture
    def large_table(self):
        """Create a 1M row table."""
        N = 1_000_000
        return pa.table({
            'id': list(range(N)),
            'category': [f'cat_{i % 100}' for i in range(N)],
            'value': [float(i) for i in range(N)],
        })

    def test_parquet_large_read(self, large_table):
        path = create_parquet(large_table)
        try:
            result = rosetta.read(path)
            assert result.num_rows == 1_000_000
        finally:
            cleanup(path)

    def test_parquet_large_filter(self, large_table):
        path = create_parquet(large_table)
        try:
            # Filter should return ~10000 rows (1% of data)
            result = rosetta.read(path, filters=[('category', '==', 'cat_0')])
            assert result.num_rows == 10_000
        finally:
            cleanup(path)

    def test_parquet_large_projection(self, large_table):
        path = create_parquet(large_table)
        try:
            result = rosetta.read(path, columns=['id'])
            assert result.num_columns == 1
            assert result.num_rows == 1_000_000
        finally:
            cleanup(path)


# =============================================================================
# Filter Edge Cases
# =============================================================================

class TestFilterEdgeCases:
    """Test filter edge cases."""

    @pytest.fixture
    def filter_test_table(self):
        return pa.table({
            'id': [1, 2, 3, 4, 5],
            'zero': [0, 0, 0, 0, 0],
            'negative': [-5, -4, -3, -2, -1],
            'mixed': [-2, -1, 0, 1, 2],
        })

    def test_parquet_filter_zero_value(self, filter_test_table):
        """Filter on zero value."""
        path = create_parquet(filter_test_table)
        try:
            result = rosetta.read(path, filters=[('mixed', '==', 0)])
            assert result.num_rows == 1
        finally:
            cleanup(path)

    def test_parquet_filter_negative(self, filter_test_table):
        """Filter on negative values."""
        path = create_parquet(filter_test_table)
        try:
            result = rosetta.read(path, filters=[('mixed', '<', 0)])
            assert result.num_rows == 2
        finally:
            cleanup(path)

    def test_parquet_filter_all_same_value(self, filter_test_table):
        """Filter on column where all values are same."""
        path = create_parquet(filter_test_table)
        try:
            result = rosetta.read(path, filters=[('zero', '==', 0)])
            assert result.num_rows == 5
        finally:
            cleanup(path)

    def test_parquet_filter_impossible(self, filter_test_table):
        """Filter that cannot match any row."""
        path = create_parquet(filter_test_table)
        try:
            result = rosetta.read(path, filters=[('zero', '>', 0)])
            assert result.num_rows == 0
        finally:
            cleanup(path)


# =============================================================================
# Multiple Row Groups (Parquet-specific)
# =============================================================================

class TestRowGroups:
    """Test handling of multiple row groups."""

    def test_parquet_multiple_row_groups(self):
        """Test reading parquet with multiple row groups."""
        # Create parquet with small row group size to force multiple groups
        table = pa.table({
            'id': list(range(10000)),
            'value': [float(i) for i in range(10000)],
        })
        path = tempfile.mktemp(suffix='.parquet')
        try:
            pq.write_table(table, path, row_group_size=1000)  # 10 row groups

            info = rosetta.file_info(path)
            assert info['num_row_groups'] == 10

            result = rosetta.read(path)
            assert result.num_rows == 10000
        finally:
            cleanup(path)

    def test_parquet_row_group_with_filter(self):
        """Test filter can skip row groups."""
        table = pa.table({
            'id': list(range(10000)),
            'value': [float(i) for i in range(10000)],
        })
        path = tempfile.mktemp(suffix='.parquet')
        try:
            pq.write_table(table, path, row_group_size=1000)

            # This filter should only need to read last row group
            result = rosetta.read(path, filters=[('id', '>=', 9000)])
            assert result.num_rows == 1000
        finally:
            cleanup(path)


# =============================================================================
# Format Detection Edge Cases
# =============================================================================

class TestFormatDetectionEdgeCases:
    """Test format detection edge cases."""

    def test_detect_by_extension_parquet(self):
        """Test detection by .parquet extension."""
        assert rosetta.detect_format('file.parquet') == FileFormat.PARQUET

    def test_detect_by_extension_pq(self):
        """Test detection by .pq extension."""
        assert rosetta.detect_format('file.pq') == FileFormat.PARQUET

    def test_detect_by_extension_vortex(self):
        """Test detection by .vortex extension."""
        assert rosetta.detect_format('file.vortex') == FileFormat.VORTEX

    def test_detect_by_extension_vtx(self):
        """Test detection by .vtx extension."""
        assert rosetta.detect_format('file.vtx') == FileFormat.VORTEX

    def test_detect_unknown_extension(self):
        """Test unknown extension returns UNKNOWN."""
        assert rosetta.detect_format('file.xyz') == FileFormat.UNKNOWN

    def test_detect_no_extension(self):
        """Test file with no extension."""
        assert rosetta.detect_format('somefile') == FileFormat.UNKNOWN


# =============================================================================
# Run if executed directly
# =============================================================================

if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
