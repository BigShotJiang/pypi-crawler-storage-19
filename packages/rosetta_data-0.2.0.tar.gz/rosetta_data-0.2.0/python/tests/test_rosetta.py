# SPDX-License-Identifier: Apache-2.0
# Copyright 2026 Rosetta Contributors

"""Tests for rosetta Python bindings - basic functionality."""

import tempfile
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
import pytest

import rosetta
from rosetta import FileFormat


class TestDetectFormat:
    """Tests for format detection."""

    def test_detect_parquet(self, parquet_v1_file):
        """Test detecting Parquet format."""
        fmt = rosetta.detect_format(str(parquet_v1_file))
        assert "Parquet" in fmt.name

    def test_detect_nonexistent_file(self):
        """Test detection on nonexistent file raises error."""
        with pytest.raises(FileNotFoundError):
            rosetta.detect_format("/nonexistent/path/file.xyz")

    def test_format_repr(self, parquet_v1_file):
        """Test format string representation."""
        fmt = rosetta.detect_format(str(parquet_v1_file))
        assert "Parquet" in repr(fmt)


class TestRead:
    """Tests for reading files."""

    def test_read_parquet(self, parquet_v1_file):
        """Test reading a Parquet file."""
        table = rosetta.read(str(parquet_v1_file))
        assert isinstance(table, pa.Table)
        assert table.num_rows == 100
        assert table.num_columns == 3

    def test_read_with_column_projection(self, parquet_v1_file):
        """Test reading with column projection."""
        table = rosetta.read(str(parquet_v1_file), columns=["id", "name"])
        assert table.num_columns == 2
        assert "id" in table.column_names
        assert "name" in table.column_names
        assert "value" not in table.column_names

    def test_read_single_column(self, parquet_v1_file):
        """Test reading a single column."""
        table = rosetta.read(str(parquet_v1_file), columns=["id"])
        assert table.num_columns == 1
        assert table.column_names == ["id"]

    def test_read_invalid_column(self, parquet_v1_file):
        """Test error on invalid column name."""
        with pytest.raises((IOError, ValueError, KeyError, pa.ArrowInvalid)):
            rosetta.read(str(parquet_v1_file), columns=["nonexistent"])

    def test_read_nonexistent_file(self):
        """Test error on nonexistent file."""
        with pytest.raises((IOError, FileNotFoundError, pa.ArrowInvalid)):
            rosetta.read("/nonexistent/path/file.parquet")

    def test_read_with_filter_and_projection(self):
        """Test filter + projection combination (regression test for filter being ignored)."""
        from rosetta import col, lit

        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
            table = pa.table({
                "id": [1, 2, 3, 4, 5],
                "name": ["Alice", "Bob", "Charlie", "Diana", "Eve"],
                "age": [25, 30, 55, 60, 45],  # 2 over 50: Charlie (55), Diana (60)
            })
            pq.write_table(table, f.name)

            # Filter alone should return 2 rows
            result = rosetta.read(f.name, filter=col("age").gt(lit(50)))
            assert result.num_rows == 2

            # Projection alone should return all 5 rows
            result = rosetta.read(f.name, columns=["name", "age"])
            assert result.num_rows == 5

            # Filter + projection must BOTH apply (this was a bug!)
            result = rosetta.read(
                f.name,
                columns=["name", "age"],
                filter=col("age").gt(lit(50))
            )
            assert result.num_rows == 2, "Filter must apply with projection"
            assert result.column_names == ["name", "age"]


class TestReadBatches:
    """Tests for reading as batches."""

    def test_read_batches(self, parquet_v1_file):
        """Test reading as batches (returns iterator/generator)."""
        batches = rosetta.read_batches(str(parquet_v1_file))
        # read_batches returns an iterator/generator, not a list
        batch_list = list(batches)
        assert len(batch_list) > 0
        assert all(isinstance(b, pa.RecordBatch) for b in batch_list)

        # Total rows should match
        total_rows = sum(b.num_rows for b in batch_list)
        assert total_rows == 100

    def test_read_batches_with_projection(self, parquet_v1_file):
        """Test reading batches with column projection."""
        batches = list(rosetta.read_batches(str(parquet_v1_file), columns=["id"]))
        assert all(b.num_columns == 1 for b in batches)


class TestFileInfo:
    """Tests for file info."""

    def test_file_info(self, parquet_v1_file):
        """Test getting file info."""
        info = rosetta.file_info(str(parquet_v1_file))

        assert "format" in info
        assert "schema" in info
        assert "num_row_groups" in info

        assert "Parquet" in info["format"].name
        assert isinstance(info["schema"], pa.Schema)
        assert info["num_row_groups"] >= 1

    def test_file_info_schema(self, parquet_v1_file):
        """Test schema in file info."""
        info = rosetta.file_info(str(parquet_v1_file))
        schema = info["schema"]

        assert "id" in schema.names
        assert "name" in schema.names
        assert "value" in schema.names


class TestDataTypes:
    """Tests for various data types."""

    def test_integer_types(self):
        """Test integer data types."""
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
            table = pa.table({
                "int8": pa.array([1, 2, 3], type=pa.int8()),
                "int16": pa.array([1, 2, 3], type=pa.int16()),
                "int32": pa.array([1, 2, 3], type=pa.int32()),
                "int64": pa.array([1, 2, 3], type=pa.int64()),
            })
            pq.write_table(table, f.name)

            result = rosetta.read(f.name)
            assert result.num_rows == 3
            assert result.num_columns == 4

    def test_float_types(self):
        """Test float data types."""
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
            table = pa.table({
                "float32": pa.array([1.0, 2.0, 3.0], type=pa.float32()),
                "float64": pa.array([1.0, 2.0, 3.0], type=pa.float64()),
            })
            pq.write_table(table, f.name)

            result = rosetta.read(f.name)
            assert result.num_rows == 3

    def test_string_type(self):
        """Test string data type."""
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
            table = pa.table({
                "name": ["Alice", "Bob", "Charlie"],
            })
            pq.write_table(table, f.name)

            result = rosetta.read(f.name)
            assert result.column("name").to_pylist() == ["Alice", "Bob", "Charlie"]

    def test_nullable_values(self):
        """Test nullable values."""
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
            table = pa.table({
                "value": [1, None, 3, None, 5],
            })
            pq.write_table(table, f.name)

            result = rosetta.read(f.name)
            assert result.column("value").to_pylist() == [1, None, 3, None, 5]


class TestCompression:
    """Tests for compression codecs."""

    @pytest.mark.parametrize("compression", ["snappy", "gzip", "zstd", "lz4"])
    def test_compression_codec(self, compression):
        """Test various compression codecs."""
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
            table = pa.table({
                "id": list(range(1000)),
                "data": ["x" * 100] * 1000,
            })
            pq.write_table(table, f.name, compression=compression)

            result = rosetta.read(f.name)
            assert result.num_rows == 1000


class TestVersion:
    """Tests for version info."""

    def test_version_exists(self):
        """Test that version is exposed."""
        assert hasattr(rosetta, "__version__")
        assert isinstance(rosetta.__version__, str)
        assert len(rosetta.__version__) > 0


# Fixtures

@pytest.fixture
def parquet_v1_file():
    """Create a test Parquet v1 file."""
    with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
        table = pa.table({
            "id": list(range(100)),
            "name": [f"name_{i}" for i in range(100)],
            "value": [float(i) * 1.5 for i in range(100)],
        })
        pq.write_table(table, f.name, version="1.0")
        yield Path(f.name)


@pytest.fixture
def large_parquet_file():
    """Create a large test Parquet file."""
    with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
        table = pa.table({
            "id": list(range(100000)),
            "value": [float(i) for i in range(100000)],
        })
        pq.write_table(table, f.name)
        yield Path(f.name)
