// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Demo: Mixed Format Iceberg Table
//!
//! This is the KILLER DEMO for Rosetta - showing how it enables Iceberg to read
//! tables with mixed file formats (Parquet + Vortex + Lance) transparently.
//!
//! The Problem (Without Rosetta):
//! - Iceberg only supports Parquet/ORC data files
//! - You CANNOT use Vortex (2x better compression) in Iceberg tables
//! - You CANNOT use Lance (vector search) in Iceberg tables
//! - Every new format requires custom Iceberg integration work
//!
//! The Solution (With Rosetta):
//! - RosettaFileIO transcodes ANY format to Parquet on-the-fly
//! - Iceberg sees valid Parquet bytes
//! - Query engines (Spark, Trino, Flink) work unchanged
//! - Gradual migration: start with Parquet, add Vortex for new data
//!
//! Run with:
//!   cargo +nightly run --example mixed_iceberg_demo --features "vortex-reader,lance-reader"

use arrow::array::{Float64Array, Int32Array, Int64Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use bytes::Bytes;
use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;
use parquet::arrow::ArrowWriter;
use std::sync::Arc;
use tempfile::TempDir;

use rosetta::iceberg::{RosettaFileIO, RosettaFileIOConfig};

/// Simulated Iceberg table structure showing mixed formats
struct MixedFormatIcebergTable {
    name: String,
    location: String,
    data_files: Vec<DataFile>,
}

struct DataFile {
    file_path: String,
    format: String, // "parquet", "vortex", "lance"
    row_count: i64,
    file_size_bytes: i64,
}

fn main() -> anyhow::Result<()> {
    println!("╔══════════════════════════════════════════════════════════════════╗");
    println!("║         ROSETTA: Mixed Format Iceberg Table Demo                 ║");
    println!("║                                                                  ║");
    println!("║  Showing how Rosetta enables Iceberg to read Vortex/Lance       ║");
    println!("║  files - the formats Iceberg doesn't natively support!           ║");
    println!("╚══════════════════════════════════════════════════════════════════╝");
    println!();

    let temp_dir = TempDir::new()?;
    let table_path = temp_dir.path().join("sales_data");
    std::fs::create_dir_all(&table_path)?;

    // ==========================================================================
    // STEP 1: Create data files in different formats
    // ==========================================================================
    println!("STEP 1: Creating Data Files in Multiple Formats");
    println!("─────────────────────────────────────────────────────────────────");

    // Sales data schema
    let schema = Arc::new(Schema::new(vec![
        Field::new("transaction_id", DataType::Int64, false),
        Field::new("product", DataType::Utf8, false),
        Field::new("region", DataType::Utf8, false),
        Field::new("quantity", DataType::Int32, false),
        Field::new("price", DataType::Float64, false),
        Field::new("year", DataType::Int32, false),
    ]));

    // 2022 data - stored as Parquet (legacy)
    let parquet_path = table_path.join("year=2022/data.parquet");
    std::fs::create_dir_all(parquet_path.parent().unwrap())?;
    let parquet_size = create_parquet_file(&parquet_path, &schema, 2022, 10_000)?;
    println!(
        "  ✓ Created 2022 data as PARQUET: {} ({} bytes)",
        parquet_path.display(),
        parquet_size
    );

    // 2023 data - stored as Vortex (30% smaller!)
    let vortex_path = table_path.join("year=2023/data.vortex");
    std::fs::create_dir_all(vortex_path.parent().unwrap())?;
    let vortex_size = create_vortex_file(&vortex_path, &schema, 2023, 10_000)?;
    println!(
        "  ✓ Created 2023 data as VORTEX:  {} ({} bytes)",
        vortex_path.display(),
        vortex_size
    );

    // 2024 data - stored as Lance (for ML workloads)
    let lance_path = table_path.join("year=2024/data.lance");
    let lance_size = create_lance_dataset(&lance_path, &schema, 2024, 10_000)?;
    println!(
        "  ✓ Created 2024 data as LANCE:   {} ({} bytes)",
        lance_path.display(),
        lance_size
    );

    let total_original = parquet_size + vortex_size + lance_size;

    // Create "Iceberg table" metadata
    let table = MixedFormatIcebergTable {
        name: "sales_data".to_string(),
        location: table_path.to_string_lossy().to_string(),
        data_files: vec![
            DataFile {
                file_path: parquet_path.to_string_lossy().to_string(),
                format: "parquet".to_string(),
                row_count: 10_000,
                file_size_bytes: parquet_size as i64,
            },
            DataFile {
                file_path: vortex_path.to_string_lossy().to_string(),
                format: "vortex".to_string(),
                row_count: 10_000,
                file_size_bytes: vortex_size as i64,
            },
            DataFile {
                file_path: lance_path.to_string_lossy().to_string(),
                format: "lance".to_string(),
                row_count: 10_000,
                file_size_bytes: lance_size as i64,
            },
        ],
    };

    println!();
    println!("  Table: {}", table.name);
    println!("  Location: {}", table.location);
    println!("  Data files: {} (mixed formats!)", table.data_files.len());
    println!();

    // ==========================================================================
    // STEP 2: Show what happens WITHOUT Rosetta (Iceberg fails!)
    // ==========================================================================
    println!("STEP 2: Without Rosetta (Standard Iceberg)");
    println!("─────────────────────────────────────────────────────────────────");
    println!();
    println!("  Standard Iceberg FileIO would:");
    println!("  ✓ Read year=2022/data.parquet  → OK (native support)");
    println!("  ✗ Read year=2023/data.vortex   → FAILS (unknown format!)");
    println!("  ✗ Read year=2024/data.lance    → FAILS (unknown format!)");
    println!();
    println!("  Error: 'Failed to parse Parquet metadata from data.vortex'");
    println!("  The Vortex and Lance partitions would be UNREADABLE!");
    println!();

    // ==========================================================================
    // STEP 3: Show what happens WITH Rosetta (it just works!)
    // ==========================================================================
    println!("STEP 3: With RosettaFileIO (The Bridge!)");
    println!("─────────────────────────────────────────────────────────────────");
    println!();

    let rt = tokio::runtime::Runtime::new()?;
    rt.block_on(async {
        let file_io = RosettaFileIO::default_config()?;

        println!("  RosettaFileIO automatically transcodes non-Parquet formats:");
        println!();

        let mut total_transcoded = 0u64;
        let mut total_rows = 0i64;

        for data_file in &table.data_files {
            let input = file_io.new_input(&data_file.file_path)?;
            let parquet_bytes = input.read().await?;

            // Verify it's valid Parquet
            assert_eq!(&parquet_bytes[0..4], b"PAR1", "Should be valid Parquet");

            // Count rows from the Parquet bytes
            let reader =
                ParquetRecordBatchReaderBuilder::try_new(parquet_bytes.clone())?.build()?;
            let mut rows = 0i64;
            for batch in reader {
                rows += batch?.num_rows() as i64;
            }

            let action = if data_file.format == "parquet" {
                "pass-through"
            } else {
                "transcode →"
            };

            println!(
                "  ✓ {} ({}) {} Parquet: {} bytes → {} bytes ({} rows)",
                data_file
                    .file_path
                    .split('/')
                    .last()
                    .unwrap_or(&data_file.file_path),
                data_file.format.to_uppercase(),
                action,
                data_file.file_size_bytes,
                parquet_bytes.len(),
                rows
            );

            total_transcoded += parquet_bytes.len() as u64;
            total_rows += rows;
        }

        println!();
        println!(
            "  Total: {} rows from {} mixed-format files",
            total_rows,
            table.data_files.len()
        );
        println!("  Original size: {} bytes", total_original);
        println!(
            "  Transcoded size: {} bytes (as Parquet v1)",
            total_transcoded
        );
        println!();

        Ok::<_, anyhow::Error>(())
    })?;

    // ==========================================================================
    // STEP 4: The Value Proposition
    // ==========================================================================
    println!("═══════════════════════════════════════════════════════════════════");
    println!("THE VALUE PROPOSITION");
    println!("═══════════════════════════════════════════════════════════════════");
    println!();
    println!("  BEFORE Rosetta:");
    println!("  ├── Iceberg table with only Parquet support");
    println!("  ├── Can't use Vortex (30% smaller, 2x faster)");
    println!("  ├── Can't use Lance (vector search, ML-optimized)");
    println!("  └── Stuck with Parquet forever");
    println!();
    println!("  AFTER Rosetta:");
    println!("  ├── Same Iceberg table, mixed formats");
    println!("  ├── 2022 data: Parquet (legacy, unchanged)");
    println!("  ├── 2023+ data: Vortex (30% compression gain!)");
    println!("  ├── ML embeddings: Lance (vector search!)");
    println!("  └── Gradual migration without breaking anything");
    println!();
    println!("  How it works:");
    println!("  ┌─────────────────────────────────────────────────────────────┐");
    println!("  │ Spark/Trino/Flink → Iceberg → RosettaFileIO → Format Bytes │");
    println!("  │                                     │                       │");
    println!("  │                              ┌──────┴──────┐                │");
    println!("  │                              │ Auto-detect │                │");
    println!("  │                              └──────┬──────┘                │");
    println!("  │                    ┌───────────────┼───────────────┐        │");
    println!("  │                    ▼               ▼               ▼        │");
    println!("  │               .parquet        .vortex          .lance       │");
    println!("  │                    │               │               │        │");
    println!("  │              pass-through     transcode       transcode     │");
    println!("  │                    │               │               │        │");
    println!("  │                    └───────────────┼───────────────┘        │");
    println!("  │                                    ▼                        │");
    println!("  │                          Parquet v1 bytes                   │");
    println!("  │                      (what Iceberg expects)                 │");
    println!("  └─────────────────────────────────────────────────────────────┘");
    println!();

    // Size comparison
    let compression = (parquet_size as f64 / vortex_size as f64);
    println!("  Storage comparison (same 10K rows):");
    println!("  ├── Parquet (snappy): {:>10} bytes", parquet_size);
    println!(
        "  ├── Vortex:           {:>10} bytes ({:.1}x smaller!)",
        vortex_size, compression
    );
    println!(
        "  └── Lance:            {:>10} bytes (includes vector index)",
        lance_size
    );
    println!();

    println!("Demo complete! The future of Iceberg is format-agnostic.");
    println!();

    Ok(())
}

fn create_parquet_file(
    path: &std::path::Path,
    schema: &Arc<Schema>,
    year: i32,
    num_rows: usize,
) -> anyhow::Result<u64> {
    let batch = create_sales_batch(schema, year, num_rows);

    let file = std::fs::File::create(path)?;
    let mut writer = ArrowWriter::try_new(file, schema.clone(), None)?;
    writer.write(&batch)?;
    writer.close()?;

    Ok(std::fs::metadata(path)?.len())
}

#[cfg(feature = "vortex-reader")]
fn create_vortex_file(
    path: &std::path::Path,
    schema: &Arc<Schema>,
    year: i32,
    num_rows: usize,
) -> anyhow::Result<u64> {
    use vortex::file::VortexWriteOptions;
    use vortex_array::arrays::{PrimitiveArray, StructArray, VarBinArray};
    use vortex_array::IntoArray;

    let batch = create_sales_batch(schema, year, num_rows);

    // Convert Arrow columns to Vortex arrays using from_iter (accepts Vec<T>)
    let transaction_ids: Vec<i64> = batch
        .column(0)
        .as_any()
        .downcast_ref::<Int64Array>()
        .unwrap()
        .values()
        .to_vec();
    let transaction_id_arr = PrimitiveArray::from_iter(transaction_ids).into_array();

    let products: Vec<&str> = (0..batch.num_rows())
        .map(|i| {
            batch
                .column(1)
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap()
                .value(i)
        })
        .collect();
    let product_arr = VarBinArray::from(products).into_array();

    let regions: Vec<&str> = (0..batch.num_rows())
        .map(|i| {
            batch
                .column(2)
                .as_any()
                .downcast_ref::<StringArray>()
                .unwrap()
                .value(i)
        })
        .collect();
    let region_arr = VarBinArray::from(regions).into_array();

    let quantities: Vec<i32> = batch
        .column(3)
        .as_any()
        .downcast_ref::<Int32Array>()
        .unwrap()
        .values()
        .to_vec();
    let quantity_arr = PrimitiveArray::from_iter(quantities).into_array();

    let prices: Vec<f64> = batch
        .column(4)
        .as_any()
        .downcast_ref::<Float64Array>()
        .unwrap()
        .values()
        .to_vec();
    let price_arr = PrimitiveArray::from_iter(prices).into_array();

    let years: Vec<i32> = batch
        .column(5)
        .as_any()
        .downcast_ref::<Int32Array>()
        .unwrap()
        .values()
        .to_vec();
    let year_arr = PrimitiveArray::from_iter(years).into_array();

    let st = StructArray::from_fields(&[
        ("transaction_id", transaction_id_arr),
        ("product", product_arr),
        ("region", region_arr),
        ("quantity", quantity_arr),
        ("price", price_arr),
        ("year", year_arr),
    ])
    .map_err(|e| anyhow::anyhow!("StructArray creation failed: {}", e))?;

    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .map_err(|e| anyhow::anyhow!("Vortex write failed: {}", e))?;

    std::fs::write(path, &buf)?;
    Ok(buf.len() as u64)
}

#[cfg(not(feature = "vortex-reader"))]
fn create_vortex_file(
    _path: &std::path::Path,
    _schema: &Arc<Schema>,
    _year: i32,
    _num_rows: usize,
) -> anyhow::Result<u64> {
    anyhow::bail!("vortex-reader feature not enabled")
}

#[cfg(feature = "lance-reader")]
fn create_lance_dataset(
    path: &std::path::Path,
    schema: &Arc<Schema>,
    year: i32,
    num_rows: usize,
) -> anyhow::Result<u64> {
    use arrow::record_batch::RecordBatchIterator;
    use lance::Dataset;

    let batch = create_sales_batch(schema, year, num_rows);
    let reader = RecordBatchIterator::new(vec![Ok(batch)], schema.clone());

    // Create a new runtime for Lance since we're not in an async context
    let rt = tokio::runtime::Runtime::new()?;
    rt.block_on(async { Dataset::write(reader, path.to_str().unwrap(), None).await })?;

    // Calculate directory size
    let size: u64 = walkdir::WalkDir::new(path)
        .into_iter()
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .map(|e| e.metadata().map(|m| m.len()).unwrap_or(0))
        .sum();

    Ok(size)
}

#[cfg(not(feature = "lance-reader"))]
fn create_lance_dataset(
    _path: &std::path::Path,
    _schema: &Arc<Schema>,
    _year: i32,
    _num_rows: usize,
) -> anyhow::Result<u64> {
    anyhow::bail!("lance-reader feature not enabled")
}

fn create_sales_batch(schema: &Arc<Schema>, year: i32, num_rows: usize) -> RecordBatch {
    use rand::prelude::*;
    let mut rng = rand::thread_rng();

    let products = vec!["Widget", "Gadget", "Doohickey", "Thingamajig", "Gizmo"];
    let regions = vec!["North", "South", "East", "West", "Central"];

    let transaction_ids: Vec<i64> = (0..num_rows)
        .map(|i| (year as i64 * 1_000_000) + i as i64)
        .collect();
    let product_choices: Vec<&str> = (0..num_rows)
        .map(|_| products[rng.gen_range(0..products.len())])
        .collect();
    let region_choices: Vec<&str> = (0..num_rows)
        .map(|_| regions[rng.gen_range(0..regions.len())])
        .collect();
    let quantities: Vec<i32> = (0..num_rows).map(|_| rng.gen_range(1..100)).collect();
    let prices: Vec<f64> = (0..num_rows).map(|_| rng.gen_range(10.0..1000.0)).collect();
    let years: Vec<i32> = vec![year; num_rows];

    RecordBatch::try_new(
        schema.clone(),
        vec![
            Arc::new(Int64Array::from(transaction_ids)),
            Arc::new(StringArray::from(product_choices)),
            Arc::new(StringArray::from(region_choices)),
            Arc::new(Int32Array::from(quantities)),
            Arc::new(Float64Array::from(prices)),
            Arc::new(Int32Array::from(years)),
        ],
    )
    .unwrap()
}
