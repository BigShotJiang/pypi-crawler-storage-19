#!/usr/bin/env python3
"""
Basic Usage Example - Rosetta Universal Format Bridge

This example shows how to read columnar files with Rosetta.
Rosetta auto-detects the format and returns PyArrow Tables.

Run with: python examples/python/01_basic_usage.py
"""

import tempfile
import pyarrow as pa
import pyarrow.parquet as pq


def create_sample_data():
    """Create a sample Parquet file for demonstration."""
    table = pa.table({
        'id': [1, 2, 3, 4, 5],
        'name': ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve'],
        'age': [25, 30, 35, 40, 45],
        'score': [85.5, 92.0, 78.5, 88.0, 95.5],
    })

    path = tempfile.mktemp(suffix='.parquet')
    pq.write_table(table, path)
    return path


def main():
    import rosetta

    print("=" * 60)
    print("Rosetta Basic Usage Example")
    print("=" * 60)
    print(f"Version: {rosetta.__version__}")
    print()

    # Create sample data
    parquet_file = create_sample_data()
    print(f"Created sample file: {parquet_file}")
    print()

    # 1. Basic read - returns PyArrow Table
    print("1. Basic Read")
    print("-" * 40)
    table = rosetta.read(parquet_file)
    print(f"   Rows: {table.num_rows}")
    print(f"   Columns: {table.num_columns}")
    print(f"   Schema: {table.schema.names}")
    print()

    # 2. Column projection - only read specific columns
    print("2. Column Projection")
    print("-" * 40)
    table = rosetta.read(parquet_file, columns=['id', 'name'])
    print(f"   Requested columns: ['id', 'name']")
    print(f"   Result columns: {table.schema.names}")
    print()

    # 3. Convert to pandas
    print("3. Convert to Pandas")
    print("-" * 40)
    df = table.to_pandas()
    print(df.to_string(index=False))
    print()

    # 4. Read as batches (for large files)
    print("4. Read as Batches")
    print("-" * 40)
    batches = rosetta.read_batches(parquet_file)
    print(f"   Number of batches: {len(batches)}")
    total_rows = sum(b.num_rows for b in batches)
    print(f"   Total rows: {total_rows}")
    print()

    # Cleanup
    import os
    os.unlink(parquet_file)

    print("=" * 60)
    print("Example complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
