#!/usr/bin/env python3
"""
S3 Integration Example - Rosetta Universal Format Bridge

This example shows how to read files directly from S3.
Rosetta uses the object_store crate for cloud storage.

Run with: python examples/python/05_s3_integration.py

Note: Requires valid AWS credentials (via env vars or ~/.aws/credentials)
"""

import os


def main():
    import rosetta

    print("=" * 60)
    print("Rosetta S3 Integration Example")
    print("=" * 60)
    print()

    # Check for AWS credentials
    has_creds = (
        os.environ.get("AWS_ACCESS_KEY_ID") or
        os.path.exists(os.path.expanduser("~/.aws/credentials"))
    )

    if not has_creds:
        print("Note: No AWS credentials found.")
        print("Set AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY or configure ~/.aws/credentials")
        print()
        print("Example S3 URLs that Rosetta supports:")
        print("  - s3://bucket/path/to/file.parquet")
        print("  - s3://bucket/path/to/file.vortex")
        print("  - s3://bucket/path/to/file.lance")
        print()
        return

    # Example S3 paths (replace with your own)
    example_bucket = os.environ.get("ROSETTA_TEST_BUCKET", "your-bucket")
    example_key = os.environ.get("ROSETTA_TEST_KEY", "data/sample.parquet")
    s3_path = f"s3://{example_bucket}/{example_key}"

    print(f"Reading from: {s3_path}")
    print()

    try:
        # 1. Read from S3 (format auto-detected)
        print("1. Read from S3")
        print("-" * 40)
        table = rosetta.read(s3_path)
        print(f"   Rows: {table.num_rows}")
        print(f"   Columns: {table.schema.names}")
        print()

        # 2. Column projection (only fetch needed columns)
        print("2. Column Projection (Network Optimization)")
        print("-" * 40)
        print("   Only fetching 'id' column from S3...")
        table = rosetta.read(s3_path, columns=["id"])
        print(f"   Fetched {table.num_rows} rows, {table.num_columns} column(s)")
        print()

        # 3. Filter pushdown (minimize data transfer)
        print("3. Filter Pushdown")
        print("-" * 40)
        from rosetta import col, lit
        table = rosetta.read(s3_path, filter=col("id").lt(lit(100)))
        print(f"   Filtered rows: {table.num_rows}")
        print()

    except Exception as e:
        print(f"Error reading from S3: {e}")
        print()
        print("Make sure the bucket and key exist and you have access.")

    print("=" * 60)
    print("S3 integration example complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
