#!/usr/bin/env python3
"""
Format Detection Example - Rosetta Universal Format Bridge

This example shows how Rosetta auto-detects file formats using
magic bytes and directory structure inspection.

Run with: python examples/python/03_format_detection.py
"""

import tempfile
import pyarrow as pa
import pyarrow.parquet as pq


def create_sample_parquet():
    """Create a sample Parquet file."""
    table = pa.table({
        'id': [1, 2, 3],
        'value': ['a', 'b', 'c'],
    })
    path = tempfile.mktemp(suffix='.parquet')
    pq.write_table(table, path)
    return path


def main():
    import rosetta

    print("=" * 60)
    print("Rosetta Format Detection Example")
    print("=" * 60)
    print()

    # Create sample file
    parquet_file = create_sample_parquet()

    # 1. Detect format from file
    print("1. Detect Format from File")
    print("-" * 40)
    fmt = rosetta.detect_format(parquet_file)
    print(f"   File: {parquet_file}")
    print(f"   Format name: {fmt.name}")
    print(f"   Extension: {fmt.extension}")
    print()

    # 2. FileFormat attributes
    print("2. FileFormat Attributes")
    print("-" * 40)
    print(f"   name: {fmt.name}")
    print(f"   extension: {fmt.extension}")
    print()

    # 3. Format names for different file types
    print("3. Supported Format Types")
    print("-" * 40)
    print("   Rosetta auto-detects these formats:")
    print("   - Parquet v1/v2 (.parquet)")
    print("   - Vortex (.vortex)")
    print("   - Lance (.lance/)")
    print()

    # 4. Get file info (schema, row groups)
    print("4. File Info")
    print("-" * 40)
    info = rosetta.file_info(parquet_file)
    print(f"   Format: {info['format']}")
    print(f"   Row groups: {info['num_row_groups']}")
    print(f"   Schema fields: {[f.name for f in info['schema']]}")
    print()

    # Cleanup
    import os
    os.unlink(parquet_file)

    print("=" * 60)
    print("Format detection complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
