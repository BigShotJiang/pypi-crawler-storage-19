#!/usr/bin/env python3
"""
Statistics API Example - Rosetta Universal Format Bridge

This example demonstrates how to access file statistics for
query optimization without reading the full data.

Run with: python examples/python/04_statistics_api.py
"""

import tempfile
import pyarrow as pa
import pyarrow.parquet as pq


def create_sample_data():
    """Create a sample Parquet file with known statistics."""
    import random
    random.seed(42)

    # Create data with predictable min/max values
    ids = list(range(1, 101))  # 1 to 100
    ages = [random.randint(18, 65) for _ in ids]
    scores = [round(random.uniform(0.0, 100.0), 2) for _ in ids]
    names = [f"Person_{i}" for i in ids]

    table = pa.table({
        'id': ids,
        'name': names,
        'age': ages,
        'score': scores,
    })

    path = tempfile.mktemp(suffix='.parquet')
    pq.write_table(table, path)
    return path


def main():
    import rosetta

    print("=" * 60)
    print("Rosetta Statistics API Example")
    print("=" * 60)
    print()

    # Create sample data
    parquet_file = create_sample_data()
    print(f"Created sample file with 100 rows")
    print()

    # 1. Get basic statistics
    print("1. Basic Statistics")
    print("-" * 40)
    stats = rosetta.statistics(parquet_file)
    print(f"   Total rows: {stats.num_rows}")
    print(f"   Columns: {stats.column_names()}")
    print()

    # 2. Column-level statistics
    print("2. Column Statistics")
    print("-" * 40)

    # Integer column (id)
    id_stats = stats.column("id")
    if id_stats:
        print(f"   Column 'id':")
        print(f"      Min: {id_stats.min_value}")
        print(f"      Max: {id_stats.max_value}")
        print(f"      Null count: {id_stats.null_count}")
    print()

    # Float column (score)
    score_stats = stats.column("score")
    if score_stats:
        print(f"   Column 'score':")
        print(f"      Min: {score_stats.min_value}")
        print(f"      Max: {score_stats.max_value}")
        print(f"      Null count: {score_stats.null_count}")
    print()

    # 3. Use statistics for query optimization
    print("3. Query Optimization with Statistics")
    print("-" * 40)
    print("   Use case: Skip files that can't contain matching rows")
    print()

    # Example: Find rows where id > 50
    id_stats = stats.column("id")
    if id_stats and id_stats.max_value is not None:
        if id_stats.max_value < 50:
            print("   File can be skipped: max(id) < 50")
        else:
            print(f"   File may contain matches: max(id) = {id_stats.max_value}")
    print()

    # 4. Partition information
    print("4. Partition Information")
    print("-" * 40)
    partitions = rosetta.partitions(parquet_file)
    print(f"   Number of partitions: {len(partitions)}")
    for i, partition in enumerate(partitions):
        print(f"   Partition {i}: id={partition.id}, byte_size={partition.byte_size}")
    print()

    # Cleanup
    import os
    os.unlink(parquet_file)

    print("=" * 60)
    print("Statistics example complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
