#!/usr/bin/env python3
"""
Filter Pushdown Example - Rosetta Universal Format Bridge

This example demonstrates Rosetta's filter pushdown capability.
Filters are pushed to the native reader (Parquet, Vortex, Lance),
so only matching rows are read from disk.

Run with: python examples/python/02_filter_pushdown.py
"""

import tempfile
import pyarrow as pa
import pyarrow.parquet as pq


def create_sample_data():
    """Create a larger sample file for filter demonstration."""
    # Create 1000 rows of test data
    import random
    random.seed(42)

    ids = list(range(1, 1001))
    names = [f"User_{i}" for i in ids]
    ages = [random.randint(18, 80) for _ in ids]
    statuses = [random.choice(['active', 'inactive', 'pending']) for _ in ids]
    scores = [round(random.uniform(50.0, 100.0), 1) for _ in ids]

    table = pa.table({
        'id': ids,
        'name': names,
        'age': ages,
        'status': statuses,
        'score': scores,
    })

    path = tempfile.mktemp(suffix='.parquet')
    pq.write_table(table, path)
    return path


def main():
    import rosetta
    from rosetta import col, lit

    print("=" * 60)
    print("Rosetta Filter Pushdown Example")
    print("=" * 60)
    print()

    # Create sample data
    parquet_file = create_sample_data()
    print(f"Created sample file with 1000 rows")
    print()

    # 1. Simple comparison filter
    print("1. Simple Filter: age > 60")
    print("-" * 40)
    table = rosetta.read(parquet_file, filter=col('age').gt(lit(60)))
    print(f"   Matching rows: {table.num_rows}")
    print()

    # 2. Equality filter
    print("2. Equality Filter: status = 'active'")
    print("-" * 40)
    table = rosetta.read(parquet_file, filter=col('status').eq(lit('active')))
    print(f"   Matching rows: {table.num_rows}")
    print()

    # 3. Compound filter (AND)
    print("3. Compound Filter: age > 30 AND status = 'active'")
    print("-" * 40)
    filter_expr = col('age').gt(lit(30)).and_(col('status').eq(lit('active')))
    print(f"   SQL: {filter_expr.to_sql()}")
    table = rosetta.read(parquet_file, filter=filter_expr)
    print(f"   Matching rows: {table.num_rows}")
    print()

    # 4. Compound filter (OR)
    print("4. Compound Filter: status = 'active' OR score > 90")
    print("-" * 40)
    filter_expr = col('status').eq(lit('active')).or_(col('score').gt(lit(90.0)))
    print(f"   SQL: {filter_expr.to_sql()}")
    table = rosetta.read(parquet_file, filter=filter_expr)
    print(f"   Matching rows: {table.num_rows}")
    print()

    # 5. BETWEEN filter
    print("5. Between Filter: age BETWEEN 25 AND 35")
    print("-" * 40)
    filter_expr = col('age').between(lit(25), lit(35))
    print(f"   SQL: {filter_expr.to_sql()}")
    table = rosetta.read(parquet_file, filter=filter_expr)
    print(f"   Matching rows: {table.num_rows}")
    print()

    # 6. Combined with projection
    print("6. Filter + Projection: age > 50, columns=['name', 'age']")
    print("-" * 40)
    table = rosetta.read(
        parquet_file,
        columns=['name', 'age'],
        filter=col('age').gt(lit(50))
    )
    print(f"   Matching rows: {table.num_rows}")
    print(f"   Columns: {table.schema.names}")
    print()
    print("   Sample results:")
    df = table.to_pandas().head(5)
    print(df.to_string(index=False))
    print()

    # Cleanup
    import os
    os.unlink(parquet_file)

    print("=" * 60)
    print("Filter pushdown complete!")
    print("=" * 60)


if __name__ == "__main__":
    main()
