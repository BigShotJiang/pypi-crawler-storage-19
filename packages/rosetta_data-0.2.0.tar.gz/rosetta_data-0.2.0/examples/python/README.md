# Rosetta Python Examples

Runnable examples demonstrating Rosetta's Python API.

## Prerequisites

```bash
# Install rosetta (from PyPI)
pip install rosetta

# Or build from source
pip install maturin
maturin develop --features "python,vortex-reader,lance-reader"
```

## Examples

| File | Description |
|------|-------------|
| `01_basic_usage.py` | Read files, column projection, convert to pandas |
| `02_filter_pushdown.py` | Push filters to native readers for performance |
| `03_format_detection.py` | Auto-detect file formats, inspect metadata |
| `04_statistics_api.py` | Access statistics for query optimization |
| `05_s3_integration.py` | Read files directly from S3 |

## Running Examples

```bash
# Run any example
python examples/python/01_basic_usage.py

# Run all examples
for f in examples/python/0*.py; do python "$f"; done
```

## Quick Reference

```python
import rosetta
from rosetta import col, lit

# Read any format
table = rosetta.read("data.parquet")
table = rosetta.read("data.vortex")
table = rosetta.read("data.lance")

# Column projection
table = rosetta.read("data.parquet", columns=["id", "name"])

# Filter pushdown
table = rosetta.read(
    "data.parquet",
    filter=col("age").gt(lit(30)).and_(col("status").eq(lit("active")))
)

# Format detection
fmt = rosetta.detect_format("data.parquet")
print(fmt.name)  # "Parquet v1"

# File metadata
info = rosetta.file_info("data.parquet")
print(info["schema"])
print(info["num_row_groups"])

# Statistics
stats = rosetta.statistics("data.parquet")
print(stats.num_rows)
print(stats.column("age").min_value)

# Batch reading (for large files)
batches = rosetta.read_batches("data.parquet")
```

## Expression API

```python
from rosetta import col, lit

# Comparison operators
col("age").gt(lit(30))       # age > 30
col("age").lt(lit(65))       # age < 65
col("age").eq(lit(30))       # age = 30
col("age").not_eq(lit(30))   # age != 30
col("age").gt_eq(lit(30))    # age >= 30
col("age").lt_eq(lit(65))    # age <= 65

# Logical operators
expr1.and_(expr2)            # expr1 AND expr2
expr1.or_(expr2)             # expr1 OR expr2
expr.not_()                  # NOT expr

# Null checks
col("name").is_null()        # name IS NULL
col("name").is_not_null()    # name IS NOT NULL

# Range and pattern operators
col("age").between(lit(18), lit(65))  # age BETWEEN 18 AND 65
col("name").like("A%")                # name LIKE 'A%'
col("name").ilike("a%")               # name ILIKE 'a%' (case-insensitive)

# Get SQL representation
expr = col("age").gt(lit(30))
print(expr.to_sql())  # "age > 30"
```
