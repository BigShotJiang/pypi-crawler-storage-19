// Run this with: cargo +nightly run --release --features vortex-reader,lance-reader --example run_benchmarks

use rosetta::benchmark::{
    generate_benchmark_file, generate_report, run_benchmark_suite, BenchmarkConfig,
};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    println!("=== Rosetta Performance Benchmarks ===\n");

    // Test multiple sizes
    for &rows in &[10_000, 100_000, 1_000_000] {
        println!("Benchmarking {} rows...", rows);

        let config = BenchmarkConfig::new()
            .with_rows(rows)
            .with_path(format!("/tmp/rosetta_bench_{}.parquet", rows));

        // Generate test file
        let path = generate_benchmark_file(&config)?;
        let file_size = std::fs::metadata(&path)?.len();
        println!("  Generated: {} ({} KB)", path, file_size / 1024);

        // Run benchmarks (10 iterations)
        let results = run_benchmark_suite(&path, 10).await?;

        // Print results
        println!("{}\n", generate_report(&results, &path));

        // Cleanup
        std::fs::remove_file(&path).ok();
    }

    Ok(())
}
