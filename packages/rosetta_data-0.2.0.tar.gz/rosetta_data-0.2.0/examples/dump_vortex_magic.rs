// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

//! Example: Create a Vortex file and examine its magic bytes

use vortex::file::VortexWriteOptions;
use vortex_array::arrays::{StructArray, VarBinArray};
use vortex_array::IntoArray;
use vortex_buffer::buffer;

fn main() {
    // Create a small Vortex file
    let ids = buffer![1i32, 2, 3].into_array();
    let names = VarBinArray::from(vec!["A", "B", "C"]).into_array();
    let st = StructArray::from_fields(&[("id", ids), ("name", names)]).unwrap();

    let buf = VortexWriteOptions::default()
        .write_blocking(Vec::new(), st.to_array_stream())
        .unwrap();

    println!("First 32 bytes of Vortex file:");
    for (i, &b) in buf.iter().take(32).enumerate() {
        print!("{:02x} ", b);
        if (i + 1) % 16 == 0 {
            println!();
        }
    }
    println!("\n\nAs ASCII:");
    for &b in buf.iter().take(32) {
        if b.is_ascii_graphic() || b == b' ' {
            print!("{}", b as char);
        } else {
            print!(".");
        }
    }
    println!();

    println!("\nLast 32 bytes:");
    let len = buf.len();
    for (i, &b) in buf.iter().skip(len.saturating_sub(32)).enumerate() {
        print!("{:02x} ", b);
        if (i + 1) % 16 == 0 {
            println!();
        }
    }
    println!();
}
