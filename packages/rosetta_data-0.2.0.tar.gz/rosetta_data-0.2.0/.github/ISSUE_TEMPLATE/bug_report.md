---
name: Bug report
about: Report a bug in Rosetta
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description

A clear and concise description of the bug.

## Steps to Reproduce

1. ...
2. ...
3. ...

## Expected Behavior

What you expected to happen.

## Actual Behavior

What actually happened.

## Environment

- OS: [e.g., macOS 14.0, Ubuntu 22.04]
- Rust version: [e.g., nightly-2025-01-01]
- Rosetta version: [e.g., 0.1.0]
- Features enabled: [e.g., vortex-reader, lance-reader]

## Sample Data (if applicable)

If possible, provide a minimal example to reproduce the issue:

```rust
// Code to reproduce
```

## Additional Context

Add any other context about the problem here (logs, screenshots, etc.).
