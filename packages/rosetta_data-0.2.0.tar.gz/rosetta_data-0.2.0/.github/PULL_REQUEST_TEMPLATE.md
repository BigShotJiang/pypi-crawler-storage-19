## Summary

Brief description of the changes in this PR.

## Related Issue

Fixes #(issue number)

## Changes Made

- Change 1
- Change 2
- Change 3

## Type of Change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to change)
- [ ] Documentation update
- [ ] Performance improvement
- [ ] Code refactoring (no functional changes)

## Testing

- [ ] I have added tests that prove my fix is effective or that my feature works
- [ ] New and existing unit tests pass locally with my changes
- [ ] I have run `cargo clippy` and addressed any warnings
- [ ] I have run `cargo fmt` to format my code

### Test Commands Run

```bash
cargo test --features "vortex-reader,lance-reader"
cargo clippy --features "vortex-reader,lance-reader"
```

## Checklist

- [ ] My code follows the project's code style
- [ ] I have updated documentation as needed
- [ ] I have added an entry to CHANGELOG.md (if applicable)
- [ ] My changes generate no new warnings
- [ ] Any dependent changes have been merged and published
