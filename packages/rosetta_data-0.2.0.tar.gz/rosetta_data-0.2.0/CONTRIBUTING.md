# Contributing to Rosetta

Thank you for your interest in contributing to Rosetta! This document provides guidelines and instructions for contributing.

## Code of Conduct

This project adheres to a code of conduct. By participating, you are expected to uphold this code. Please be respectful and constructive in all interactions.

## Getting Started

### Prerequisites

- **Rust** (nightly toolchain required for Vortex support)
  ```bash
  rustup install nightly
  rustup default nightly
  ```

- **Python 3.8+** (for Python bindings)
  ```bash
  python3 -m venv .venv
  source .venv/bin/activate
  pip install maturin pytest pyarrow
  ```

### Building from Source

```bash
# Clone the repository
git clone https://github.com/rosetta-data/rosetta
cd rosetta

# Build with default features (Parquet only)
cargo build

# Build with all features
cargo build --features "vortex-reader,lance-reader,wasm-runtime"

# Build Python bindings
maturin develop --features python
```

### Running Tests

```bash
# Run Rust tests
cargo test

# Run with all features
cargo test --features "vortex-reader,lance-reader"

# Run Python tests
pytest python/tests/

# Run benchmarks
cargo bench --bench read_benchmark
```

## How to Contribute

### Reporting Bugs

1. **Search existing issues** to avoid duplicates
2. **Create a new issue** with:
   - Clear, descriptive title
   - Steps to reproduce
   - Expected vs actual behavior
   - Environment details (OS, Rust version, features enabled)
   - Sample data if possible (or instructions to generate)

### Suggesting Features

1. **Check the roadmap** in [ROADMAP.md](ROADMAP.md)
2. **Open a discussion** or issue describing:
   - The use case / problem
   - Proposed solution
   - Alternatives considered

### Submitting Code

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes**
4. **Add tests** for new functionality
5. **Run the test suite**
   ```bash
   cargo test --features "vortex-reader,lance-reader"
   cargo clippy --features "vortex-reader,lance-reader"
   cargo fmt --check
   ```
6. **Commit with clear messages**
   ```bash
   git commit -m "Add support for XYZ format detection"
   ```
7. **Push and create a Pull Request**

## Code Style

### Rust

- Follow the [Rust API Guidelines](https://rust-lang.github.io/api-guidelines/)
- Use `cargo fmt` for formatting
- Use `cargo clippy` for linting
- Document public APIs with doc comments
- Include examples in doc comments where helpful

### Documentation

- Keep README.md up to date
- Document new features in appropriate places
- Use clear, concise language
- Include code examples

### Commit Messages

- Use present tense ("Add feature" not "Added feature")
- Use imperative mood ("Move cursor to..." not "Moves cursor to...")
- Keep first line under 72 characters
- Reference issues when relevant

## Project Structure

```
rosetta/
├── src/
│   ├── lib.rs              # Library entry point
│   ├── main.rs             # CLI entry point
│   ├── error.rs            # Error types
│   ├── format.rs           # Format detection
│   ├── readers/            # Format-specific readers
│   │   ├── mod.rs          # Reader traits and exports
│   │   ├── parquet_reader.rs
│   │   ├── vortex_reader.rs
│   │   └── lance_reader.rs
│   ├── writers/            # Format writers
│   ├── transcoder.rs       # Format conversion
│   ├── upgrade.rs          # Progressive upgrade
│   ├── encoding.rs         # Encoding selection
│   └── python.rs           # Python bindings
├── tests/                  # Integration tests
├── benches/                # Benchmarks
├── python/tests/           # Python tests
└── examples/               # Example code
```

## Adding a New Format

1. **Create reader module** in `src/readers/`
   ```rust
   // src/readers/newformat_reader.rs
   use crate::{Result, readers::FormatReader};

   pub struct NewFormatReader { /* ... */ }

   #[async_trait]
   impl FormatReader for NewFormatReader {
       // Implement required methods
   }
   ```

2. **Add format detection** in `src/format.rs`
   ```rust
   // Add magic bytes detection
   const NEWFORMAT_MAGIC: &[u8] = b"NFMT";
   ```

3. **Update UnifiedReader** in `src/readers/unified.rs`

4. **Add feature flag** in `Cargo.toml`
   ```toml
   newformat-reader = ["newformat-dep"]
   ```

5. **Add tests** in `tests/newformat_integration.rs`

6. **Update documentation**

## Pull Request Process

1. Ensure all tests pass
2. Update documentation as needed
3. Add entry to CHANGELOG.md (if applicable)
4. Request review from maintainers
5. Address review feedback
6. Squash commits if requested

## Release Process

Releases follow [Semantic Versioning](https://semver.org/):
- **MAJOR**: Breaking API changes
- **MINOR**: New features, backward compatible
- **PATCH**: Bug fixes, backward compatible

## Getting Help

- **GitHub Issues**: Bug reports and feature requests
- **GitHub Discussions**: Questions and general discussion
- **Documentation**: [docs/](docs/) directory

## License

By contributing to Rosetta, you agree that your contributions will be licensed under the Apache License 2.0.
