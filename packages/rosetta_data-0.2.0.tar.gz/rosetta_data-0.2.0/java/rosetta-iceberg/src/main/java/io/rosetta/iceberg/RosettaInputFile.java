// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.iceberg;

import io.rosetta.jni.RosettaException;
import org.apache.iceberg.io.InputFile;
import org.apache.iceberg.io.SeekableInputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;

/**
 * InputFile implementation that reads and transcodes files via Rosetta.
 *
 * <p>When reading non-Parquet formats (Vortex, Lance, etc.), this class
 * transcodes them to Parquet v1 bytes on first read and caches the result.
 */
public class RosettaInputFile implements InputFile {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaInputFile.class);

    private final RosettaFileIO fileIO;
    private final String path;
    private volatile byte[] cachedContent;
    private volatile Long cachedLength;

    RosettaInputFile(RosettaFileIO fileIO, String path) {
        this.fileIO = fileIO;
        this.path = path;
    }

    @Override
    public long getLength() {
        if (cachedLength != null) {
            return cachedLength;
        }

        // For transcoded files, we need to read to know the transcoded size
        if (fileIO.shouldTranscode(path)) {
            ensureContentLoaded();
            cachedLength = (long) cachedContent.length;
            return cachedLength;
        }

        // For pass-through files, get actual length
        cachedLength = fileIO.fileLength(path);
        return cachedLength;
    }

    @Override
    public SeekableInputStream newStream() {
        ensureContentLoaded();
        LOG.debug("Creating stream for {} ({} bytes)", path, cachedContent.length);
        return new ByteArraySeekableInputStream(cachedContent);
    }

    @Override
    public String location() {
        return path;
    }

    @Override
    public boolean exists() {
        return fileIO.fileExists(path);
    }

    private void ensureContentLoaded() {
        if (cachedContent != null) {
            return;
        }

        synchronized (this) {
            if (cachedContent != null) {
                return;
            }

            try {
                LOG.debug("Loading content for: {}", path);
                cachedContent = fileIO.readFile(path);
                cachedLength = (long) cachedContent.length;
                LOG.debug("Loaded {} bytes for: {}", cachedContent.length, path);
            } catch (RosettaException e) {
                throw new RuntimeException("Failed to read file: " + path, e);
            }
        }
    }

    /**
     * SeekableInputStream implementation backed by a byte array.
     *
     * <p>This implementation supports files up to Integer.MAX_VALUE bytes (2GB).
     * For larger files, the position tracking uses long arithmetic internally
     * but array access is still limited by Java array size constraints.
     */
    private static class ByteArraySeekableInputStream extends SeekableInputStream {

        private final byte[] data;
        private long position = 0;
        private long markPosition = -1;

        ByteArraySeekableInputStream(byte[] data) {
            this.data = data;
        }

        @Override
        public long getPos() throws IOException {
            return position;
        }

        @Override
        public void seek(long newPos) throws IOException {
            if (newPos < 0 || newPos > data.length) {
                throw new IOException("Invalid seek position: " + newPos +
                    " (length=" + data.length + ")");
            }
            position = newPos;
        }

        @Override
        public int read() throws IOException {
            if (position >= data.length) {
                return -1;
            }
            return data[(int) position++] & 0xFF;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (position >= data.length) {
                return -1;
            }
            long available = data.length - position;
            int toRead = (int) Math.min(len, available);
            System.arraycopy(data, (int) position, b, off, toRead);
            position += toRead;
            return toRead;
        }

        @Override
        public long skip(long n) throws IOException {
            if (n <= 0) {
                return 0;
            }
            long available = data.length - position;
            long toSkip = Math.min(n, available);
            position += toSkip;
            return toSkip;
        }

        @Override
        public int available() throws IOException {
            long avail = data.length - position;
            // Cap at Integer.MAX_VALUE for available() return type
            return (int) Math.min(avail, Integer.MAX_VALUE);
        }

        @Override
        public boolean markSupported() {
            return true;
        }

        @Override
        public synchronized void mark(int readlimit) {
            markPosition = position;
        }

        @Override
        public synchronized void reset() throws IOException {
            if (markPosition < 0) {
                throw new IOException("Stream not marked");
            }
            position = markPosition;
        }

        @Override
        public void close() throws IOException {
            // Nothing to close, but reset mark
            markPosition = -1;
        }
    }
}
