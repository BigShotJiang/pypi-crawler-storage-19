// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.iceberg;

import io.rosetta.jni.RosettaException;
import org.apache.iceberg.io.InputFile;
import org.apache.iceberg.io.OutputFile;
import org.apache.iceberg.io.PositionOutputStream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * OutputFile implementation that writes files via Rosetta.
 *
 * <p>This implementation buffers all writes in memory and flushes to the
 * underlying storage when the stream is closed.
 */
public class RosettaOutputFile implements OutputFile {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaOutputFile.class);

    private final RosettaFileIO fileIO;
    private final String path;

    RosettaOutputFile(RosettaFileIO fileIO, String path) {
        this.fileIO = fileIO;
        this.path = path;
    }

    @Override
    public PositionOutputStream create() {
        LOG.debug("Creating output stream for: {}", path);
        return new BufferedPositionOutputStream(this);
    }

    @Override
    public PositionOutputStream createOrOverwrite() {
        LOG.debug("Creating/overwriting output stream for: {}", path);
        return new BufferedPositionOutputStream(this);
    }

    @Override
    public String location() {
        return path;
    }

    @Override
    public InputFile toInputFile() {
        return new RosettaInputFile(fileIO, path);
    }

    /**
     * Write buffered content to the file.
     */
    void writeContent(byte[] content) throws IOException {
        try {
            fileIO.writeFile(path, content);
            LOG.debug("Wrote {} bytes to: {}", content.length, path);
        } catch (RosettaException e) {
            throw new IOException("Failed to write file: " + path, e);
        }
    }

    /**
     * PositionOutputStream implementation that buffers writes in memory.
     */
    private static class BufferedPositionOutputStream extends PositionOutputStream {

        private final RosettaOutputFile outputFile;
        private final ByteArrayOutputStream buffer;
        private long position = 0;
        private boolean closed = false;

        BufferedPositionOutputStream(RosettaOutputFile outputFile) {
            this.outputFile = outputFile;
            this.buffer = new ByteArrayOutputStream(64 * 1024); // 64KB initial buffer
        }

        @Override
        public long getPos() throws IOException {
            return position;
        }

        @Override
        public void write(int b) throws IOException {
            checkNotClosed();
            buffer.write(b);
            position++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            checkNotClosed();
            buffer.write(b, off, len);
            position += len;
        }

        @Override
        public void flush() throws IOException {
            // Buffered - nothing to flush until close
        }

        @Override
        public void close() throws IOException {
            if (closed) {
                return;
            }
            closed = true;

            // Write buffered content
            outputFile.writeContent(buffer.toByteArray());
        }

        private void checkNotClosed() throws IOException {
            if (closed) {
                throw new IOException("Stream is closed");
            }
        }
    }
}
