// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.iceberg;

import io.rosetta.jni.FileFormat;
import io.rosetta.jni.RosettaNative;
import io.rosetta.jni.RosettaException;
import org.apache.iceberg.io.FileIO;
import org.apache.iceberg.io.InputFile;
import org.apache.iceberg.io.OutputFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Iceberg FileIO implementation that transparently transcodes non-Parquet formats.
 *
 * <p>This FileIO intercepts reads of Vortex, Lance, and other columnar formats,
 * transcoding them to Parquet v1 on-the-fly. This enables legacy Parquet-only
 * tools (Spark 2.x, old Pandas, etc.) to read next-generation formats with
 * ZERO code changes.
 *
 * <h2>Usage with Iceberg Catalogs</h2>
 * <pre>{@code
 * // Configure Spark to use RosettaFileIO
 * spark.sql("CREATE TABLE mydb.mytable ... USING iceberg " +
 *           "TBLPROPERTIES ('io-impl' = 'io.rosetta.iceberg.RosettaFileIO')");
 *
 * // Or configure via catalog properties
 * spark.conf.set("spark.sql.catalog.mycatalog.io-impl", "io.rosetta.iceberg.RosettaFileIO");
 * }</pre>
 *
 * <h2>Supported Formats</h2>
 * <ul>
 *   <li>Parquet v1/v2 - passed through unchanged</li>
 *   <li>Vortex (.vortex) - transcoded to Parquet v1</li>
 *   <li>Lance (.lance) - transcoded to Parquet v1</li>
 *   <li>F3 (.f3) - transcoded to Parquet v1 (requires WASM runtime)</li>
 * </ul>
 *
 * <h2>Configuration Properties</h2>
 * <ul>
 *   <li>{@code rosetta.delegate.io-impl} - Underlying FileIO for actual file operations</li>
 *   <li>{@code rosetta.cache.enabled} - Enable/disable transcoding cache (default: true)</li>
 *   <li>{@code rosetta.cache.max-size-mb} - Maximum cache size in MB (default: 1024)</li>
 * </ul>
 *
 * <p>Thread Safety: All methods are thread-safe.
 */
public class RosettaFileIO implements FileIO {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaFileIO.class);

    /** Property key for delegate FileIO implementation */
    public static final String DELEGATE_IO_IMPL = "rosetta.delegate.io-impl";

    /** Property key to enable/disable caching */
    public static final String CACHE_ENABLED = "rosetta.cache.enabled";

    /** Property key for maximum cache size in MB */
    public static final String CACHE_MAX_SIZE_MB = "rosetta.cache.max-size-mb";

    /** File extensions that should be transcoded */
    private static final Set<String> TRANSCODE_EXTENSIONS = Set.of(
        ".vortex", ".lance", ".f3", ".fastlanes"
    );

    private volatile long nativeHandle;
    private final Object handleLock = new Object();
    private Map<String, String> properties;
    private FileIO delegateIO;
    private boolean cacheEnabled = true;
    private long cacheMaxSizeMb = 1024;

    /**
     * Default constructor required by Iceberg.
     */
    public RosettaFileIO() {
        // Native handle created lazily in initialize()
    }

    @Override
    public void initialize(Map<String, String> properties) {
        this.properties = new ConcurrentHashMap<>(properties);

        // Initialize native library
        RosettaNative.load();

        // Create native FileIO handle
        synchronized (handleLock) {
            this.nativeHandle = RosettaNative.fileioNew();
            if (this.nativeHandle == 0) {
                throw new RuntimeException("Failed to create native FileIO: " +
                    RosettaNative.getLastError());
            }
        }

        // Parse configuration
        if (properties.containsKey(CACHE_ENABLED)) {
            this.cacheEnabled = Boolean.parseBoolean(properties.get(CACHE_ENABLED));
        }
        if (properties.containsKey(CACHE_MAX_SIZE_MB)) {
            this.cacheMaxSizeMb = Long.parseLong(properties.get(CACHE_MAX_SIZE_MB));
        }

        LOG.info("Initialized RosettaFileIO (cache={}, maxSize={}MB)",
            cacheEnabled, cacheMaxSizeMb);
    }

    @Override
    public InputFile newInputFile(String path) {
        ensureInitialized();

        if (shouldTranscode(path)) {
            LOG.debug("Creating transcoding InputFile for: {}", path);
            return new RosettaInputFile(this, path);
        }

        // Pass through to native or delegate
        LOG.debug("Creating pass-through InputFile for: {}", path);
        return new RosettaInputFile(this, path);
    }

    @Override
    public OutputFile newOutputFile(String path) {
        ensureInitialized();
        return new RosettaOutputFile(this, path);
    }

    @Override
    public void deleteFile(String path) {
        ensureInitialized();

        LOG.debug("Deleting file: {}", path);
        if (!RosettaNative.fileioDelete(nativeHandle, path)) {
            String error = RosettaNative.getLastError();
            throw new RuntimeException("Failed to delete file: " + path +
                (error != null ? " - " + error : ""));
        }
    }

    @Override
    public Map<String, String> properties() {
        return properties != null ? properties : Map.of();
    }

    @Override
    public void close() {
        synchronized (handleLock) {
            if (nativeHandle != 0) {
                RosettaNative.fileioFree(nativeHandle);
                nativeHandle = 0;
                LOG.info("Closed RosettaFileIO");
            }
        }
    }

    /**
     * Check if a file should be transcoded based on its extension.
     *
     * @param path File path
     * @return true if the file should be transcoded
     */
    public boolean shouldTranscode(String path) {
        if (path == null) {
            return false;
        }

        String lowerPath = path.toLowerCase();
        for (String ext : TRANSCODE_EXTENSIONS) {
            if (lowerPath.endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Read a file, transcoding if necessary.
     *
     * @param path File path
     * @return File bytes (Parquet v1 format if transcoded)
     * @throws RosettaException if read fails
     */
    byte[] readFile(String path) throws RosettaException {
        ensureInitialized();

        byte[] data = RosettaNative.fileioRead(nativeHandle, path);
        if (data == null) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to read file: " + path +
                (error != null ? " - " + error : ""));
        }
        return data;
    }

    /**
     * Check if a file exists.
     *
     * @param path File path
     * @return true if file exists
     */
    boolean fileExists(String path) {
        ensureInitialized();
        return RosettaNative.fileioExists(nativeHandle, path);
    }

    /**
     * Get the length of a file.
     *
     * @param path File path
     * @return File length in bytes
     */
    long fileLength(String path) {
        ensureInitialized();
        return RosettaNative.fileioLength(nativeHandle, path);
    }

    /**
     * Write bytes to a file.
     *
     * @param path File path
     * @param data Bytes to write
     * @throws RosettaException if write fails
     */
    void writeFile(String path, byte[] data) throws RosettaException {
        ensureInitialized();

        if (!RosettaNative.fileioWrite(nativeHandle, path, data)) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to write file: " + path +
                (error != null ? " - " + error : ""));
        }
    }

    /**
     * Detect the format of a file.
     *
     * @param path File path
     * @return Detected format
     */
    public FileFormat detectFormat(String path) {
        return FileFormat.detect(path);
    }

    /**
     * Clear the transcoding cache.
     */
    public void clearCache() {
        if (nativeHandle != 0) {
            RosettaNative.fileioClearCache(nativeHandle);
            LOG.debug("Cleared transcoding cache");
        }
    }

    /**
     * Get the native handle for advanced operations.
     *
     * @return Native handle
     */
    long getNativeHandle() {
        return nativeHandle;
    }

    private void ensureInitialized() {
        if (nativeHandle == 0) {
            throw new IllegalStateException("RosettaFileIO not initialized. " +
                "Call initialize() first or use with Iceberg catalog.");
        }
    }
}
