// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.benchmark;

import io.rosetta.iceberg.RosettaFileIO;
import org.apache.iceberg.io.FileIO;
import org.apache.iceberg.io.InputFile;
import org.apache.iceberg.io.SeekableInputStream;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * JMH benchmarks for Iceberg FileIO performance.
 *
 * <p>These benchmarks measure the performance of Rosetta's Iceberg FileIO
 * implementation, which transparently transcodes files when reading.
 *
 * <p>Run with:
 * <pre>
 *   java -jar rosetta-benchmarks.jar IcebergBenchmark -p dataDir=/path/to/test/data
 * </pre>
 */
@BenchmarkMode({Mode.Throughput, Mode.AverageTime})
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Benchmark)
@Warmup(iterations = 3, time = 2)
@Measurement(iterations = 5, time = 2)
@Fork(2)
public class IcebergBenchmark {

    /**
     * Directory containing test data files.
     */
    @Param({"./benchmark-data"})
    private String dataDir;

    /**
     * File size category to benchmark.
     */
    @Param({"small", "medium", "large"})
    private String size;

    /**
     * Buffer size for streaming reads.
     */
    @Param({"4096", "65536", "1048576"})
    private int bufferSize;

    private RosettaFileIO rosettaIO;
    private String parquetPath;
    private String vortexPath;
    private boolean hasVortex;

    @Setup(Level.Trial)
    public void setup() {
        Map<String, String> props = new HashMap<>();
        props.put("rosetta.cache.enabled", "false"); // Disable caching for accurate measurements

        rosettaIO = new RosettaFileIO();
        rosettaIO.initialize(props);

        parquetPath = dataDir + "/" + size + ".parquet";
        vortexPath = dataDir + "/" + size + ".vortex";
        hasVortex = Files.exists(Path.of(vortexPath));
    }

    @TearDown(Level.Trial)
    public void teardown() {
        if (rosettaIO != null) {
            rosettaIO.close();
        }
    }

    // ========================================================================
    // InputFile Creation Benchmarks
    // ========================================================================

    /**
     * Measure InputFile creation overhead.
     */
    @Benchmark
    public void inputFile_creation(Blackhole bh) {
        InputFile inputFile = rosettaIO.newInputFile(parquetPath);
        bh.consume(inputFile);
    }

    /**
     * Measure file length check.
     */
    @Benchmark
    public void inputFile_length(Blackhole bh) {
        InputFile inputFile = rosettaIO.newInputFile(parquetPath);
        bh.consume(inputFile.getLength());
    }

    /**
     * Measure file existence check.
     */
    @Benchmark
    public void inputFile_exists(Blackhole bh) {
        InputFile inputFile = rosettaIO.newInputFile(parquetPath);
        bh.consume(inputFile.exists());
    }

    // ========================================================================
    // Streaming Read Benchmarks
    // ========================================================================

    /**
     * Read Parquet file as stream (no transcoding).
     */
    @Benchmark
    public void streamRead_parquet(Blackhole bh) throws IOException {
        InputFile inputFile = rosettaIO.newInputFile(parquetPath);
        try (SeekableInputStream stream = inputFile.newStream()) {
            byte[] buffer = new byte[bufferSize];
            int read;
            while ((read = stream.read(buffer)) != -1) {
                bh.consume(read);
            }
        }
    }

    /**
     * Read Vortex file as stream (with transcoding).
     */
    @Benchmark
    public void streamRead_vortex(Blackhole bh) throws IOException {
        if (!hasVortex) return;

        InputFile inputFile = rosettaIO.newInputFile(vortexPath);
        try (SeekableInputStream stream = inputFile.newStream()) {
            byte[] buffer = new byte[bufferSize];
            int read;
            while ((read = stream.read(buffer)) != -1) {
                bh.consume(read);
            }
        }
    }

    // ========================================================================
    // Full Read Benchmarks
    // ========================================================================

    /**
     * Read entire Parquet file into memory.
     */
    @Benchmark
    public void fullRead_parquet(Blackhole bh) throws IOException {
        InputFile inputFile = rosettaIO.newInputFile(parquetPath);
        long length = inputFile.getLength();
        byte[] data = new byte[(int) length];

        try (SeekableInputStream stream = inputFile.newStream()) {
            int offset = 0;
            int read;
            while (offset < length && (read = stream.read(data, offset, (int) length - offset)) != -1) {
                offset += read;
            }
        }
        bh.consume(data);
    }

    /**
     * Read entire Vortex file into memory (with transcoding).
     */
    @Benchmark
    public void fullRead_vortex(Blackhole bh) throws IOException {
        if (!hasVortex) return;

        InputFile inputFile = rosettaIO.newInputFile(vortexPath);
        long length = inputFile.getLength();
        byte[] data = new byte[(int) length];

        try (SeekableInputStream stream = inputFile.newStream()) {
            int offset = 0;
            int read;
            while (offset < length && (read = stream.read(data, offset, (int) length - offset)) != -1) {
                offset += read;
            }
        }
        bh.consume(data);
    }

    // ========================================================================
    // Seek Benchmarks
    // ========================================================================

    /**
     * Measure seek performance on Parquet.
     */
    @Benchmark
    public void seek_parquet(Blackhole bh) throws IOException {
        InputFile inputFile = rosettaIO.newInputFile(parquetPath);
        try (SeekableInputStream stream = inputFile.newStream()) {
            long length = inputFile.getLength();

            // Seek to various positions
            stream.seek(0);
            bh.consume(stream.read());

            stream.seek(length / 4);
            bh.consume(stream.read());

            stream.seek(length / 2);
            bh.consume(stream.read());

            stream.seek(3 * length / 4);
            bh.consume(stream.read());

            stream.seek(length - 1);
            bh.consume(stream.read());
        }
    }

    /**
     * Measure seek performance on transcoded Vortex.
     */
    @Benchmark
    public void seek_vortex(Blackhole bh) throws IOException {
        if (!hasVortex) return;

        InputFile inputFile = rosettaIO.newInputFile(vortexPath);
        try (SeekableInputStream stream = inputFile.newStream()) {
            long length = inputFile.getLength();

            // Seek to various positions
            stream.seek(0);
            bh.consume(stream.read());

            stream.seek(length / 4);
            bh.consume(stream.read());

            stream.seek(length / 2);
            bh.consume(stream.read());

            stream.seek(3 * length / 4);
            bh.consume(stream.read());

            stream.seek(length - 1);
            bh.consume(stream.read());
        }
    }
}
