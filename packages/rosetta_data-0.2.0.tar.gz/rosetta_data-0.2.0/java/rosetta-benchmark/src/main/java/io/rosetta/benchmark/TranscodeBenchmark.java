// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.benchmark;

import io.rosetta.jni.RosettaNative;
import io.rosetta.jni.RosettaFileIO;
import io.rosetta.jni.RosettaException;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

/**
 * JMH benchmarks for file transcoding performance.
 *
 * <p>These benchmarks measure end-to-end transcoding throughput for
 * different file formats and sizes. They help identify performance
 * characteristics and compare against native readers.
 *
 * <p>Run with:
 * <pre>
 *   java -jar rosetta-benchmarks.jar TranscodeBenchmark -p dataDir=/path/to/test/data
 * </pre>
 */
@BenchmarkMode({Mode.Throughput, Mode.AverageTime})
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Benchmark)
@Warmup(iterations = 3, time = 2)
@Measurement(iterations = 5, time = 2)
@Fork(2)
public class TranscodeBenchmark {

    /**
     * Directory containing test data files.
     * Should contain: small.parquet, medium.parquet, large.parquet,
     * small.vortex, medium.vortex, large.vortex, etc.
     */
    @Param({"./benchmark-data"})
    private String dataDir;

    /**
     * File size category to benchmark.
     */
    @Param({"small", "medium", "large"})
    private String size;

    private RosettaFileIO fileIO;
    private String parquetPath;
    private String vortexPath;
    private String lancePath;
    private boolean hasVortex;
    private boolean hasLance;

    @Setup(Level.Trial)
    public void setup() throws IOException, RosettaException {
        fileIO = new RosettaFileIO();

        // Build paths
        parquetPath = dataDir + "/" + size + ".parquet";
        vortexPath = dataDir + "/" + size + ".vortex";
        lancePath = dataDir + "/" + size + ".lance";

        // Check which files exist
        hasVortex = Files.exists(Path.of(vortexPath));
        hasLance = Files.isDirectory(Path.of(lancePath));

        // Validate at least parquet exists
        if (!Files.exists(Path.of(parquetPath))) {
            System.err.println("WARNING: Test data not found at " + parquetPath);
            System.err.println("Generate test data with: java -cp rosetta-benchmarks.jar " +
                "io.rosetta.benchmark.TestDataGenerator " + dataDir);
        }
    }

    @TearDown(Level.Trial)
    public void teardown() {
        if (fileIO != null) {
            fileIO.close();
        }
    }

    /**
     * Baseline: Read a native Parquet file (no transcoding).
     */
    @Benchmark
    public void readParquet_native(Blackhole bh) throws IOException, RosettaException {
        if (Files.exists(Path.of(parquetPath))) {
            byte[] data = fileIO.read(parquetPath);
            bh.consume(data);
        }
    }

    /**
     * Read and transcode a Vortex file to Parquet.
     */
    @Benchmark
    public void readVortex_transcode(Blackhole bh) throws IOException, RosettaException {
        if (hasVortex) {
            byte[] data = fileIO.read(vortexPath);
            bh.consume(data);
        }
    }

    /**
     * Read and transcode a Lance file to Parquet.
     */
    @Benchmark
    public void readLance_transcode(Blackhole bh) throws IOException, RosettaException {
        if (hasLance) {
            byte[] data = fileIO.read(lancePath);
            bh.consume(data);
        }
    }

    /**
     * Measure raw file read (Java NIO) as baseline.
     */
    @Benchmark
    public void readParquet_javaIO(Blackhole bh) throws IOException {
        if (Files.exists(Path.of(parquetPath))) {
            byte[] data = Files.readAllBytes(Path.of(parquetPath));
            bh.consume(data);
        }
    }
}
