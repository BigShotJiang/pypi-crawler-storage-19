// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.benchmark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generates test data files for benchmarking.
 *
 * <p>Creates Parquet files of various sizes. For Vortex and Lance files,
 * use the Rosetta CLI or Python scripts.
 *
 * <p>Usage:
 * <pre>
 *   java -cp rosetta-benchmarks.jar io.rosetta.benchmark.TestDataGenerator [output-dir]
 * </pre>
 *
 * <p>File sizes:
 * <ul>
 *   <li>small: 10,000 rows (~1 MB)</li>
 *   <li>medium: 100,000 rows (~10 MB)</li>
 *   <li>large: 1,000,000 rows (~100 MB)</li>
 * </ul>
 */
public class TestDataGenerator {

    // Row counts for each size category
    private static final int SMALL_ROWS = 10_000;
    private static final int MEDIUM_ROWS = 100_000;
    private static final int LARGE_ROWS = 1_000_000;

    private final String outputDir;
    private final SparkSession spark;
    private final Random random;

    public TestDataGenerator(String outputDir) {
        this.outputDir = outputDir;
        this.random = new Random(42); // Fixed seed for reproducibility

        this.spark = SparkSession.builder()
            .appName("TestDataGenerator")
            .master("local[*]")
            .config("spark.ui.enabled", "false")
            .config("spark.driver.memory", "4g")
            .getOrCreate();
    }

    public void generate() throws IOException {
        System.out.println("Generating benchmark test data in: " + outputDir);
        Files.createDirectories(Path.of(outputDir));

        // Generate each size
        generateSize("small", SMALL_ROWS);
        generateSize("medium", MEDIUM_ROWS);
        generateSize("large", LARGE_ROWS);

        // Print conversion instructions
        printConversionInstructions();
    }

    private void generateSize(String name, int rowCount) {
        System.out.println("Generating " + name + " dataset (" + rowCount + " rows)...");

        List<Row> rows = new ArrayList<>(rowCount);
        for (int i = 0; i < rowCount; i++) {
            rows.add(org.apache.spark.sql.RowFactory.create(
                (long) i,                                    // id
                "name_" + i,                                 // name
                random.nextDouble() * 1000,                  // value
                random.nextInt(100),                         // category
                randomString(50),                            // description
                System.currentTimeMillis() - random.nextInt(86400000), // timestamp
                random.nextBoolean(),                        // active
                randomBytes(100)                             // data
            ));
        }

        StructType schema = DataTypes.createStructType(new StructField[]{
            DataTypes.createStructField("id", DataTypes.LongType, false),
            DataTypes.createStructField("name", DataTypes.StringType, false),
            DataTypes.createStructField("value", DataTypes.DoubleType, false),
            DataTypes.createStructField("category", DataTypes.IntegerType, false),
            DataTypes.createStructField("description", DataTypes.StringType, true),
            DataTypes.createStructField("timestamp", DataTypes.LongType, false),
            DataTypes.createStructField("active", DataTypes.BooleanType, false),
            DataTypes.createStructField("data", DataTypes.BinaryType, true)
        });

        Dataset<Row> df = spark.createDataFrame(rows, schema);

        // Write Parquet
        String parquetPath = outputDir + "/" + name + ".parquet";
        df.write()
            .mode(SaveMode.Overwrite)
            .option("compression", "snappy")
            .parquet(parquetPath);
        System.out.println("  -> " + parquetPath);

        // Show file size
        try {
            long size = getDirectorySize(Path.of(parquetPath));
            System.out.println("     Size: " + formatSize(size));
        } catch (IOException e) {
            // Ignore
        }
    }

    private String randomString(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            sb.append((char) ('a' + random.nextInt(26)));
        }
        return sb.toString();
    }

    private byte[] randomBytes(int length) {
        byte[] bytes = new byte[length];
        random.nextBytes(bytes);
        return bytes;
    }

    private long getDirectorySize(Path path) throws IOException {
        if (Files.isDirectory(path)) {
            return Files.walk(path)
                .filter(Files::isRegularFile)
                .mapToLong(p -> {
                    try {
                        return Files.size(p);
                    } catch (IOException e) {
                        return 0;
                    }
                })
                .sum();
        }
        return Files.size(path);
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024));
    }

    private void printConversionInstructions() {
        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println("Parquet files generated successfully!");
        System.out.println();
        System.out.println("To create Vortex files for benchmarking, use the Rosetta CLI:");
        System.out.println();
        System.out.println("  # Using rosetta CLI");
        System.out.println("  rosetta convert " + outputDir + "/small.parquet " + outputDir + "/small.vortex --format vortex");
        System.out.println("  rosetta convert " + outputDir + "/medium.parquet " + outputDir + "/medium.vortex --format vortex");
        System.out.println("  rosetta convert " + outputDir + "/large.parquet " + outputDir + "/large.vortex --format vortex");
        System.out.println();
        System.out.println("Or using Python:");
        System.out.println();
        System.out.println("  import vortex as vx");
        System.out.println("  import pyarrow.parquet as pq");
        System.out.println("  for size in ['small', 'medium', 'large']:");
        System.out.println("      table = pq.read_table(f'" + outputDir + "/{size}.parquet')");
        System.out.println("      vx.Array.from_arrow(table).write(f'" + outputDir + "/{size}.vortex')");
        System.out.println();
        System.out.println("=".repeat(70));
    }

    public void close() {
        if (spark != null) {
            spark.stop();
        }
    }

    public static void main(String[] args) {
        String outputDir = args.length > 0 ? args[0] : "./benchmark-data";

        TestDataGenerator generator = new TestDataGenerator(outputDir);
        try {
            generator.generate();
        } catch (IOException e) {
            System.err.println("Error generating test data: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } finally {
            generator.close();
        }
    }
}
