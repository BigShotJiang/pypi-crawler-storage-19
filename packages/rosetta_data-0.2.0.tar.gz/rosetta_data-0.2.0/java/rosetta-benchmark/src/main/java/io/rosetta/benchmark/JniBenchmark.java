// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.benchmark;

import io.rosetta.jni.RosettaNative;
import io.rosetta.jni.RosettaFileIO;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.util.concurrent.TimeUnit;

/**
 * JMH benchmarks for measuring JNI call overhead.
 *
 * <p>These benchmarks measure the raw cost of crossing the JNI boundary
 * and help identify performance bottlenecks in the native integration.
 *
 * <p>Run with:
 * <pre>
 *   java -jar rosetta-benchmarks.jar JniBenchmark
 * </pre>
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.NANOSECONDS)
@State(Scope.Thread)
@Warmup(iterations = 3, time = 1)
@Measurement(iterations = 5, time = 1)
@Fork(2)
public class JniBenchmark {

    private long fileioHandle;

    @Setup(Level.Trial)
    public void setup() {
        // Create a FileIO handle for reuse
        fileioHandle = RosettaNative.fileioNew();
        if (fileioHandle == 0) {
            throw new RuntimeException("Failed to create FileIO: " + RosettaNative.getLastError());
        }
    }

    @TearDown(Level.Trial)
    public void teardown() {
        if (fileioHandle != 0) {
            RosettaNative.fileioFree(fileioHandle);
        }
    }

    /**
     * Baseline: measure the cost of a simple native call (version string).
     * This is the minimum JNI overhead.
     */
    @Benchmark
    public void jniCallOverhead_version(Blackhole bh) {
        bh.consume(RosettaNative.version());
    }

    /**
     * Measure format detection from a Parquet magic header.
     */
    @Benchmark
    public void formatDetection_parquetHeader(Blackhole bh) {
        // PAR1 magic bytes
        byte[] header = new byte[] { 'P', 'A', 'R', '1' };
        bh.consume(RosettaNative.detectFormatFromBytes(header));
    }

    /**
     * Measure format detection from a Vortex magic header.
     */
    @Benchmark
    public void formatDetection_vortexHeader(Blackhole bh) {
        // VTXF magic bytes (Vortex)
        byte[] header = new byte[] { 'V', 'T', 'X', 'F' };
        bh.consume(RosettaNative.detectFormatFromBytes(header));
    }

    /**
     * Measure format detection from a Lance magic header.
     */
    @Benchmark
    public void formatDetection_lanceHeader(Blackhole bh) {
        // LANC magic bytes (Lance)
        byte[] header = new byte[] { 'L', 'A', 'N', 'C' };
        bh.consume(RosettaNative.detectFormatFromBytes(header));
    }

    /**
     * Measure FileIO handle creation and destruction.
     * This is useful for understanding per-operation setup costs.
     */
    @Benchmark
    public void fileioLifecycle(Blackhole bh) {
        long handle = RosettaNative.fileioNew();
        bh.consume(handle);
        if (handle != 0) {
            RosettaNative.fileioFree(handle);
        }
    }

    /**
     * Measure error retrieval (no error case).
     */
    @Benchmark
    public void getLastError_noError(Blackhole bh) {
        bh.consume(RosettaNative.getLastError());
    }
}
