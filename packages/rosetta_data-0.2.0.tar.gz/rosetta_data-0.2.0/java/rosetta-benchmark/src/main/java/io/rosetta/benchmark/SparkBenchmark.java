// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.benchmark;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.Blackhole;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

/**
 * JMH benchmarks for Spark DataSource V2 performance.
 *
 * <p>These benchmarks compare Rosetta's Spark integration against
 * native Spark Parquet reading. They measure:
 * <ul>
 *   <li>Full table scan performance</li>
 *   <li>Column projection pushdown</li>
 *   <li>Filter pushdown (when supported)</li>
 *   <li>Row count operations</li>
 * </ul>
 *
 * <p>Run with:
 * <pre>
 *   java -jar rosetta-benchmarks.jar SparkBenchmark -p dataDir=/path/to/test/data
 * </pre>
 */
@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Benchmark)
@Warmup(iterations = 2, time = 5)
@Measurement(iterations = 3, time = 5)
@Fork(1)  // Spark is heavy, single fork is usually sufficient
public class SparkBenchmark {

    /**
     * Directory containing test data files.
     */
    @Param({"./benchmark-data"})
    private String dataDir;

    /**
     * File size category to benchmark.
     */
    @Param({"medium", "large"})
    private String size;

    private SparkSession spark;
    private String parquetPath;
    private String vortexPath;
    private boolean hasVortex;

    @Setup(Level.Trial)
    public void setup() {
        // Create local Spark session
        spark = SparkSession.builder()
            .appName("RosettaBenchmark")
            .master("local[*]")
            .config("spark.ui.enabled", "false")
            .config("spark.sql.shuffle.partitions", "4")
            .config("spark.driver.memory", "2g")
            .getOrCreate();

        // Build paths
        parquetPath = dataDir + "/" + size + ".parquet";
        vortexPath = dataDir + "/" + size + ".vortex";
        hasVortex = Files.exists(Path.of(vortexPath));
    }

    @TearDown(Level.Trial)
    public void teardown() {
        if (spark != null) {
            spark.stop();
        }
    }

    // ========================================================================
    // Full Table Scan Benchmarks
    // ========================================================================

    /**
     * Baseline: Read Parquet with native Spark reader.
     */
    @Benchmark
    public void fullScan_parquet_native(Blackhole bh) {
        Dataset<Row> df = spark.read()
            .format("parquet")
            .load(parquetPath);
        bh.consume(df.count());
    }

    /**
     * Read Parquet with Rosetta DataSource (should be similar to native).
     */
    @Benchmark
    public void fullScan_parquet_rosetta(Blackhole bh) {
        Dataset<Row> df = spark.read()
            .format("rosetta")
            .load(parquetPath);
        bh.consume(df.count());
    }

    /**
     * Read Vortex with Rosetta DataSource (transcodes to Parquet).
     */
    @Benchmark
    public void fullScan_vortex_rosetta(Blackhole bh) {
        if (hasVortex) {
            Dataset<Row> df = spark.read()
                .format("rosetta")
                .load(vortexPath);
            bh.consume(df.count());
        }
    }

    // ========================================================================
    // Column Projection Benchmarks
    // ========================================================================

    /**
     * Read single column from Parquet (native).
     */
    @Benchmark
    public void projection_single_parquet_native(Blackhole bh) {
        Dataset<Row> df = spark.read()
            .format("parquet")
            .load(parquetPath)
            .select("id");
        bh.consume(df.count());
    }

    /**
     * Read single column with Rosetta.
     */
    @Benchmark
    public void projection_single_rosetta(Blackhole bh) {
        if (hasVortex) {
            Dataset<Row> df = spark.read()
                .format("rosetta")
                .load(vortexPath)
                .select("id");
            bh.consume(df.count());
        }
    }

    /**
     * Read multiple columns from Parquet (native).
     */
    @Benchmark
    public void projection_multi_parquet_native(Blackhole bh) {
        Dataset<Row> df = spark.read()
            .format("parquet")
            .load(parquetPath)
            .select("id", "name", "value");
        bh.consume(df.count());
    }

    /**
     * Read multiple columns with Rosetta.
     */
    @Benchmark
    public void projection_multi_rosetta(Blackhole bh) {
        if (hasVortex) {
            Dataset<Row> df = spark.read()
                .format("rosetta")
                .load(vortexPath)
                .select("id", "name", "value");
            bh.consume(df.count());
        }
    }

    // ========================================================================
    // Filter Pushdown Benchmarks
    // ========================================================================

    /**
     * Filter on Parquet with native reader.
     */
    @Benchmark
    public void filter_parquet_native(Blackhole bh) {
        Dataset<Row> df = spark.read()
            .format("parquet")
            .load(parquetPath)
            .filter("id < 1000");
        bh.consume(df.count());
    }

    /**
     * Filter with Rosetta DataSource.
     */
    @Benchmark
    public void filter_rosetta(Blackhole bh) {
        if (hasVortex) {
            Dataset<Row> df = spark.read()
                .format("rosetta")
                .load(vortexPath)
                .filter("id < 1000");
            bh.consume(df.count());
        }
    }

    // ========================================================================
    // Data Collection Benchmarks (actual row materialization)
    // ========================================================================

    /**
     * Collect all rows from Parquet (native).
     */
    @Benchmark
    public void collect_parquet_native(Blackhole bh) {
        Dataset<Row> df = spark.read()
            .format("parquet")
            .load(parquetPath);
        bh.consume(df.collectAsList());
    }

    /**
     * Collect all rows with Rosetta.
     */
    @Benchmark
    public void collect_rosetta(Blackhole bh) {
        if (hasVortex) {
            Dataset<Row> df = spark.read()
                .format("rosetta")
                .load(vortexPath);
            bh.consume(df.collectAsList());
        }
    }
}
