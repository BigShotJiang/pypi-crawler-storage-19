# Rosetta Performance Benchmarks

JMH-based benchmarks for measuring Rosetta's JVM integration performance.

## Quick Start

```bash
# From the java/ directory
mvn package -DskipTests

# Generate test data
java -cp rosetta-benchmark/target/rosetta-benchmarks.jar \
    io.rosetta.benchmark.TestDataGenerator ./benchmark-data

# Run all benchmarks (takes ~30 minutes)
java -jar rosetta-benchmark/target/rosetta-benchmarks.jar

# Run quick benchmarks (development)
java -jar rosetta-benchmark/target/rosetta-benchmarks.jar \
    -wi 1 -i 3 -f 1
```

## Benchmark Categories

### 1. JNI Overhead (`JniBenchmark`)

Measures the raw cost of crossing the JNI boundary:
- `jniCallOverhead_version` - Baseline native call latency
- `formatDetection_*` - Format detection from magic bytes
- `fileioLifecycle` - Handle creation/destruction cost

```bash
java -jar rosetta-benchmarks.jar "JniBenchmark.*"
```

### 2. Transcoding Performance (`TranscodeBenchmark`)

Measures file read and transcoding throughput:
- `readParquet_native` - Baseline Parquet read (no transcoding)
- `readVortex_transcode` - Vortex → Parquet transcoding
- `readLance_transcode` - Lance → Parquet transcoding

```bash
java -jar rosetta-benchmarks.jar "TranscodeBenchmark.*" \
    -p dataDir=./benchmark-data -p size=large
```

### 3. Iceberg FileIO (`IcebergBenchmark`)

Measures Iceberg FileIO integration performance:
- `inputFile_*` - InputFile creation and metadata
- `streamRead_*` - Streaming read with various buffer sizes
- `fullRead_*` - Full file read into memory
- `seek_*` - Random access / seek performance

```bash
java -jar rosetta-benchmarks.jar "IcebergBenchmark.*" \
    -p dataDir=./benchmark-data -p size=medium -p bufferSize=65536
```

### 4. Spark DataSource V2 (`SparkBenchmark`)

Measures Spark integration performance:
- `fullScan_*` - Full table scan (count)
- `projection_*` - Column projection pushdown
- `filter_*` - Filter pushdown
- `collect_*` - Full row materialization

```bash
java -jar rosetta-benchmarks.jar "SparkBenchmark.*" \
    -p dataDir=./benchmark-data -p size=large
```

## Generating Test Data

### Parquet Files

Use the built-in generator:

```bash
java -cp rosetta-benchmarks.jar \
    io.rosetta.benchmark.TestDataGenerator ./benchmark-data
```

This creates:
- `small.parquet` - 10,000 rows (~1 MB)
- `medium.parquet` - 100,000 rows (~10 MB)
- `large.parquet` - 1,000,000 rows (~100 MB)

### Vortex Files

Convert Parquet to Vortex using Python:

```python
import vortex as vx
import pyarrow.parquet as pq

for size in ['small', 'medium', 'large']:
    table = pq.read_table(f'benchmark-data/{size}.parquet')
    vx.Array.from_arrow(table).write(f'benchmark-data/{size}.vortex')
```

Or using the Rosetta CLI:

```bash
rosetta convert benchmark-data/large.parquet benchmark-data/large.vortex
```

## JMH Options

Common options for running benchmarks:

| Option | Description | Default |
|--------|-------------|---------|
| `-wi N` | Warmup iterations | 3 |
| `-i N` | Measurement iterations | 5 |
| `-f N` | Forks | 2 |
| `-t N` | Threads | 1 |
| `-p key=value` | Benchmark parameter | - |
| `-rf json` | Results format | text |
| `-rff file.json` | Results file | - |

### Example: Full benchmark with JSON output

```bash
java -jar rosetta-benchmarks.jar \
    -rf json -rff results.json \
    -wi 5 -i 10 -f 3 \
    -p dataDir=./benchmark-data
```

## Interpreting Results

### Key Metrics

1. **JNI Call Overhead**: Should be < 100ns per call
2. **Format Detection**: Should be < 1μs per detection
3. **Transcoding Throughput**: Compare against native Parquet read
   - Target: < 2x overhead for transcoding
4. **Spark Performance**: Compare `rosetta` vs `parquet` format
   - Target: < 1.5x overhead for scans

### Expected Results (Apple M2, 1M rows)

| Benchmark | Native Parquet | Rosetta Vortex | Overhead |
|-----------|----------------|----------------|----------|
| Full scan | 50ms | 80ms | 1.6x |
| Projection (1 col) | 20ms | 35ms | 1.75x |
| Filter | 15ms | 30ms | 2x |

## Troubleshooting

### Native Library Not Found

Ensure the native library is built and packaged:

```bash
cd ..  # project root
make native-libs
cd java
mvn package -DskipTests
```

### Out of Memory

Increase JVM heap for large benchmarks:

```bash
java -Xmx8g -jar rosetta-benchmarks.jar "SparkBenchmark.*"
```

### Spark Initialization Slow

First run includes Spark initialization. Use more warmup iterations:

```bash
java -jar rosetta-benchmarks.jar "SparkBenchmark.*" -wi 5
```
