// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.spark;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.rosetta.jni.FileFormat;
import io.rosetta.jni.RosettaNative;
import org.apache.spark.sql.connector.catalog.Table;
import org.apache.spark.sql.connector.catalog.TableProvider;
import org.apache.spark.sql.connector.expressions.Transform;
import org.apache.spark.sql.sources.DataSourceRegister;
import org.apache.spark.sql.types.*;
import org.apache.spark.sql.util.CaseInsensitiveStringMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Spark DataSource V2 for reading columnar formats with transparent transcoding.
 *
 * <p>This data source reads Vortex, Lance, and other columnar formats by
 * transcoding them to Parquet on-the-fly, enabling Spark to process next-gen
 * formats without native support.
 *
 * <h2>Usage</h2>
 * <pre>{@code
 * // Read Vortex files directly
 * spark.read()
 *     .format("rosetta")
 *     .load("path/to/data.vortex")
 *
 * // Or use the short name
 * spark.read()
 *     .format("rosetta")
 *     .option("path", "path/to/data.lance")
 *     .load()
 * }</pre>
 *
 * <h2>Configuration Options</h2>
 * <ul>
 *   <li>{@code path} - Path to the file or directory</li>
 *   <li>{@code rosetta.format} - Force specific format (auto-detected if not set)</li>
 *   <li>{@code rosetta.cache.enabled} - Enable transcoding cache (default: true)</li>
 * </ul>
 */
public class RosettaDataSource implements TableProvider, DataSourceRegister {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaDataSource.class);

    public static final String NAME = "rosetta";
    public static final String PATH_OPTION = "path";
    public static final String FORMAT_OPTION = "rosetta.format";
    public static final String CACHE_ENABLED_OPTION = "rosetta.cache.enabled";

    static {
        // Ensure native library is loaded
        RosettaNative.load();
    }

    @Override
    public String shortName() {
        return NAME;
    }

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Override
    public StructType inferSchema(CaseInsensitiveStringMap options) {
        String path = options.get(PATH_OPTION);
        if (path == null || path.isEmpty()) {
            throw new IllegalArgumentException("'path' option is required");
        }

        LOG.debug("Inferring schema for: {}", path);

        // Detect format
        FileFormat format = FileFormat.detect(path);
        LOG.debug("Detected format: {}", format);

        // Get schema from native library
        String schemaJson = RosettaNative.getSchemaJson(path);
        if (schemaJson == null) {
            String error = RosettaNative.getLastError();
            throw new RuntimeException("Failed to get schema: " + (error != null ? error : "unknown error"));
        }

        LOG.debug("Got schema JSON: {}", schemaJson);

        try {
            return parseArrowSchemaJson(schemaJson);
        } catch (Exception e) {
            LOG.error("Failed to parse schema JSON", e);
            throw new RuntimeException("Failed to parse schema: " + e.getMessage(), e);
        }
    }

    /**
     * Parse Arrow schema JSON and convert to Spark StructType.
     */
    private StructType parseArrowSchemaJson(String json) throws Exception {
        JsonNode root = MAPPER.readTree(json);
        JsonNode fields = root.get("fields");

        if (fields == null || !fields.isArray()) {
            throw new IllegalArgumentException("Invalid schema JSON: missing 'fields' array");
        }

        List<StructField> sparkFields = new ArrayList<>();
        for (JsonNode field : fields) {
            String name = field.get("name").asText();
            boolean nullable = field.get("nullable").asBoolean(true);
            DataType dataType = parseArrowDataType(field);
            sparkFields.add(new StructField(name, dataType, nullable, Metadata.empty()));
        }

        return new StructType(sparkFields.toArray(new StructField[0]));
    }

    /**
     * Convert Arrow data type to Spark DataType.
     */
    private DataType parseArrowDataType(JsonNode field) {
        JsonNode dataTypeNode = field.get("data_type");
        if (dataTypeNode == null) {
            return DataTypes.BinaryType; // fallback
        }

        // Handle simple string types like "Int32", "Utf8", etc.
        if (dataTypeNode.isTextual()) {
            return parseSimpleArrowType(dataTypeNode.asText());
        }

        // Handle complex types like {"Timestamp": {...}} or {"List": {...}}
        if (dataTypeNode.isObject()) {
            var iter = dataTypeNode.fieldNames();
            if (iter.hasNext()) {
                String typeName = iter.next();
                JsonNode typeParams = dataTypeNode.get(typeName);
                return parseComplexArrowType(typeName, typeParams);
            }
        }

        return DataTypes.BinaryType; // fallback
    }

    /**
     * Parse simple Arrow type names to Spark DataTypes.
     */
    private DataType parseSimpleArrowType(String typeName) {
        switch (typeName) {
            case "Boolean": return DataTypes.BooleanType;
            case "Int8": return DataTypes.ByteType;
            case "Int16": return DataTypes.ShortType;
            case "Int32": return DataTypes.IntegerType;
            case "Int64": return DataTypes.LongType;
            case "UInt8": return DataTypes.ShortType; // Spark doesn't have unsigned
            case "UInt16": return DataTypes.IntegerType;
            case "UInt32": return DataTypes.LongType;
            case "UInt64": return DataTypes.createDecimalType(20, 0); // UInt64 overflows Long
            case "Float16": return DataTypes.FloatType;
            case "Float32": return DataTypes.FloatType;
            case "Float64": return DataTypes.DoubleType;
            case "Utf8": return DataTypes.StringType;
            case "LargeUtf8": return DataTypes.StringType;
            case "Binary": return DataTypes.BinaryType;
            case "LargeBinary": return DataTypes.BinaryType;
            case "Date32": return DataTypes.DateType;
            case "Date64": return DataTypes.DateType;
            case "Null": return DataTypes.NullType;
            default:
                LOG.warn("Unknown Arrow type: {}, using BinaryType", typeName);
                return DataTypes.BinaryType;
        }
    }

    /**
     * Parse complex Arrow types (Timestamp, List, Struct, etc.) to Spark DataTypes.
     */
    private DataType parseComplexArrowType(String typeName, JsonNode params) {
        switch (typeName) {
            case "Timestamp":
                // Timestamp has unit and timezone
                return DataTypes.TimestampType;
            case "Time32":
            case "Time64":
                return DataTypes.LongType; // Spark doesn't have native Time type
            case "Duration":
                return DataTypes.LongType;
            case "Decimal":
            case "Decimal128":
            case "Decimal256":
                int precision = params.has("precision") ? params.get("precision").asInt(38) : 38;
                int scale = params.has("scale") ? params.get("scale").asInt(18) : 18;
                return DataTypes.createDecimalType(precision, scale);
            case "List":
            case "LargeList":
                // List has a child field
                if (params.has("field")) {
                    DataType elementType = parseArrowDataType(params.get("field"));
                    return DataTypes.createArrayType(elementType, true);
                }
                return DataTypes.createArrayType(DataTypes.BinaryType, true);
            case "FixedSizeList":
                if (params.has("field")) {
                    DataType elementType = parseArrowDataType(params.get("field"));
                    return DataTypes.createArrayType(elementType, true);
                }
                return DataTypes.createArrayType(DataTypes.BinaryType, true);
            case "Struct":
                // Struct has a list of fields
                if (params.has("fields") && params.get("fields").isArray()) {
                    List<StructField> structFields = new ArrayList<>();
                    for (JsonNode f : params.get("fields")) {
                        String name = f.get("name").asText();
                        boolean nullable = f.get("nullable").asBoolean(true);
                        DataType dataType = parseArrowDataType(f);
                        structFields.add(new StructField(name, dataType, nullable, Metadata.empty()));
                    }
                    return new StructType(structFields.toArray(new StructField[0]));
                }
                return new StructType();
            case "Map":
                // Map has key and value fields
                DataType keyType = DataTypes.StringType;
                DataType valueType = DataTypes.BinaryType;
                if (params.has("keys")) {
                    keyType = parseArrowDataType(params.get("keys"));
                }
                if (params.has("values")) {
                    valueType = parseArrowDataType(params.get("values"));
                }
                return DataTypes.createMapType(keyType, valueType, true);
            case "FixedSizeBinary":
                return DataTypes.BinaryType;
            case "Interval":
                return DataTypes.CalendarIntervalType;
            default:
                LOG.warn("Unknown complex Arrow type: {}, using BinaryType", typeName);
                return DataTypes.BinaryType;
        }
    }

    @Override
    public Table getTable(StructType schema, Transform[] partitioning, Map<String, String> properties) {
        String path = properties.get(PATH_OPTION);
        if (path == null || path.isEmpty()) {
            throw new IllegalArgumentException("'path' option is required");
        }

        LOG.info("Creating RosettaTable for: {}", path);
        return new RosettaTable(path, schema, properties);
    }

    @Override
    public boolean supportsExternalMetadata() {
        return true;
    }
}
