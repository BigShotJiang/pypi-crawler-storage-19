// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.spark;

import org.apache.spark.sql.connector.read.Scan;
import org.apache.spark.sql.connector.read.ScanBuilder;
import org.apache.spark.sql.connector.read.SupportsPushDownFilters;
import org.apache.spark.sql.connector.read.SupportsPushDownRequiredColumns;
import org.apache.spark.sql.sources.Filter;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * ScanBuilder for Rosetta data sources.
 */
public class RosettaScanBuilder implements ScanBuilder,
    SupportsPushDownRequiredColumns, SupportsPushDownFilters {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaScanBuilder.class);

    private final String path;
    private StructType schema;
    private final Map<String, String> properties;
    private StructType requiredSchema;
    private Filter[] pushedFilters = new Filter[0];

    public RosettaScanBuilder(String path, StructType schema, Map<String, String> properties) {
        this.path = path;
        this.schema = schema;
        this.properties = properties;
        this.requiredSchema = schema;
    }

    @Override
    public Scan build() {
        LOG.debug("Building scan for: {} with schema: {}", path, requiredSchema);
        return new RosettaScan(path, requiredSchema, properties, pushedFilters);
    }

    @Override
    public void pruneColumns(StructType requiredSchema) {
        LOG.debug("Pruning columns to: {}", requiredSchema);
        this.requiredSchema = requiredSchema;
    }

    @Override
    public Filter[] pushFilters(Filter[] filters) {
        LOG.debug("Attempting to push {} filters", filters.length);

        // Track which filters we can push down to the native layer
        java.util.List<Filter> pushed = new java.util.ArrayList<>();
        java.util.List<Filter> unpushed = new java.util.ArrayList<>();

        for (Filter filter : filters) {
            if (canPushDown(filter)) {
                pushed.add(filter);
                LOG.debug("  Pushed: {}", filter);
            } else {
                unpushed.add(filter);
                LOG.debug("  Not pushed: {}", filter);
            }
        }

        // Store pushed filters for pushedFilters() and passing to RosettaScan
        this.pushedFilters = pushed.toArray(new Filter[0]);
        LOG.info("Pushed {}/{} filters to Rosetta", pushed.size(), filters.length);

        // Return filters that couldn't be pushed (Spark will apply them post-read)
        return unpushed.toArray(new Filter[0]);
    }

    /**
     * Determines if a filter can be pushed down to the native Rosetta layer.
     *
     * <p>Rosetta supports common comparison operators, logical operators,
     * and predicates like IN, IS NULL, BETWEEN.
     */
    private boolean canPushDown(Filter filter) {
        // Check filter type using class name matching
        // (avoids instanceof for each specific filter type)
        String filterClass = filter.getClass().getSimpleName();

        switch (filterClass) {
            // Comparison operators
            case "EqualTo":
            case "EqualNullSafe":
            case "GreaterThan":
            case "GreaterThanOrEqual":
            case "LessThan":
            case "LessThanOrEqual":
                return true;

            // Logical operators (check children recursively)
            case "And":
            case "Or":
                // These have child filters - for now, accept them and let
                // the native layer handle what it can
                return true;

            case "Not":
                return true;

            // Predicates
            case "In":
            case "IsNull":
            case "IsNotNull":
                return true;

            // String predicates - limited support
            case "StringStartsWith":
            case "StringEndsWith":
            case "StringContains":
                // Rosetta has LIKE support which can handle these
                return true;

            default:
                // Unknown filter - don't push
                return false;
        }
    }

    @Override
    public Filter[] pushedFilters() {
        return pushedFilters;
    }
}
