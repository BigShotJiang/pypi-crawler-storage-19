// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.spark;

import org.apache.spark.sql.connector.read.Batch;
import org.apache.spark.sql.connector.read.Scan;
import org.apache.spark.sql.sources.Filter;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * Scan implementation for Rosetta data sources.
 */
public class RosettaScan implements Scan {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaScan.class);

    private final String path;
    private final StructType schema;
    private final Map<String, String> properties;
    private final Filter[] filters;

    public RosettaScan(String path, StructType schema, Map<String, String> properties, Filter[] filters) {
        this.path = path;
        this.schema = schema;
        this.properties = properties;
        this.filters = filters;
    }

    @Override
    public StructType readSchema() {
        return schema;
    }

    @Override
    public String description() {
        return "RosettaScan[" + path + "]";
    }

    @Override
    public Batch toBatch() {
        LOG.debug("Creating batch for: {} with {} filters", path, filters.length);
        return new RosettaBatch(path, schema, properties, filters);
    }

    /**
     * Returns the filters that were pushed down to this scan.
     */
    public Filter[] filters() {
        return filters;
    }
}
