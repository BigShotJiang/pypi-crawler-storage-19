// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.spark;

import io.rosetta.jni.RosettaNative;
import io.rosetta.jni.RosettaException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.hadoop.ParquetFileReader;
import org.apache.parquet.hadoop.metadata.ParquetMetadata;
import org.apache.parquet.hadoop.util.HadoopInputFile;
import org.apache.parquet.io.ColumnIOFactory;
import org.apache.parquet.io.MessageColumnIO;
import org.apache.parquet.io.RecordReader;
import org.apache.parquet.column.page.PageReadStore;
import org.apache.parquet.schema.MessageType;
import org.apache.spark.sql.catalyst.InternalRow;
import org.apache.spark.sql.catalyst.expressions.GenericInternalRow;
import org.apache.spark.sql.connector.read.PartitionReader;
import org.apache.spark.sql.sources.Filter;
import org.apache.spark.sql.sources.EqualTo;
import org.apache.spark.sql.sources.GreaterThan;
import org.apache.spark.sql.sources.GreaterThanOrEqual;
import org.apache.spark.sql.sources.LessThan;
import org.apache.spark.sql.sources.LessThanOrEqual;
import org.apache.spark.sql.sources.And;
import org.apache.spark.sql.sources.Or;
import org.apache.spark.sql.sources.Not;
import org.apache.spark.sql.sources.In;
import org.apache.spark.sql.sources.IsNull;
import org.apache.spark.sql.sources.IsNotNull;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.unsafe.types.UTF8String;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;

/**
 * Partition reader that reads and transcodes files via Rosetta.
 *
 * <p>This reader transcodes non-Parquet files to Parquet v1 bytes,
 * writes them to a temporary file, and uses Spark's native Parquet
 * reader to process the data.
 */
public class RosettaPartitionReader implements PartitionReader<InternalRow> {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaPartitionReader.class);

    private final String path;
    private final StructType schema;
    private final Map<String, String> properties;
    private final Filter[] filters;

    private long nativeHandle;
    private byte[] transcodedData;
    private File tempFile;
    private InternalRow currentRow;
    private boolean initialized = false;

    // Parquet reading state
    private ParquetFileReader parquetReader;
    private MessageType parquetSchema;
    private Deque<InternalRow> rowBuffer;
    private long totalRowsRead = 0;

    public RosettaPartitionReader(String path, StructType schema, Map<String, String> properties) {
        this(path, schema, properties, new Filter[0]);
    }

    public RosettaPartitionReader(String path, StructType schema, Map<String, String> properties, Filter[] filters) {
        this.path = path;
        this.schema = schema;
        this.properties = properties;
        this.filters = filters;
        this.rowBuffer = new ArrayDeque<>();
    }

    @Override
    public boolean next() throws IOException {
        if (!initialized) {
            initialize();
        }

        // Return buffered row if available
        if (!rowBuffer.isEmpty()) {
            currentRow = rowBuffer.poll();
            return true;
        }

        // Try to read more rows from the current row group
        if (readNextRowGroup()) {
            if (!rowBuffer.isEmpty()) {
                currentRow = rowBuffer.poll();
                return true;
            }
        }

        return false;
    }

    @Override
    public InternalRow get() {
        return currentRow;
    }

    @Override
    public void close() throws IOException {
        // Close Parquet reader
        if (parquetReader != null) {
            parquetReader.close();
            parquetReader = null;
        }

        // Clean up native handle
        if (nativeHandle != 0) {
            RosettaNative.fileioFree(nativeHandle);
            nativeHandle = 0;
        }

        // Clean up temp file
        if (tempFile != null && tempFile.exists()) {
            tempFile.delete();
        }

        LOG.debug("Closed reader for: {} (read {} rows)", path, totalRowsRead);
    }

    private void initialize() throws IOException {
        initialized = true;

        // Create native FileIO handle
        nativeHandle = RosettaNative.fileioNew();
        if (nativeHandle == 0) {
            throw new IOException("Failed to create native FileIO: " +
                RosettaNative.getLastError());
        }

        // Log filters being applied
        if (filters.length > 0) {
            LOG.info("Applying {} filters for: {}", filters.length, path);
            for (Filter f : filters) {
                LOG.debug("  Filter: {}", f);
            }
            // Convert filters to Rosetta expression string for JNI
            String filterExpr = convertFiltersToExpression(filters);
            if (filterExpr != null) {
                LOG.debug("  Rosetta filter expression: {}", filterExpr);
                // TODO: Pass filterExpr to JNI when supported
            }
        }

        // Read and transcode the file
        LOG.debug("Reading and transcoding: {}", path);
        transcodedData = RosettaNative.fileioRead(nativeHandle, path);
        if (transcodedData == null) {
            String error = RosettaNative.getLastError();
            throw new IOException("Failed to read file: " + path +
                (error != null ? " - " + error : ""));
        }

        LOG.debug("Transcoded {} to {} bytes of Parquet v1", path, transcodedData.length);

        // Write to temp file for Parquet reader
        tempFile = Files.createTempFile("rosetta-", ".parquet").toFile();
        tempFile.deleteOnExit();

        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            fos.write(transcodedData);
        }

        // Open Parquet file for reading
        Configuration hadoopConf = new Configuration();
        HadoopInputFile inputFile = HadoopInputFile.fromPath(
            new Path(tempFile.getAbsolutePath()), hadoopConf);
        parquetReader = ParquetFileReader.open(inputFile);
        parquetSchema = parquetReader.getFileMetaData().getSchema();

        LOG.info("Initialized reader for: {} (transcoded to {} bytes, {} columns)",
            path, transcodedData.length, parquetSchema.getFieldCount());
    }

    /**
     * Reads the next row group and buffers all rows from it.
     *
     * @return true if rows were read, false if no more row groups
     */
    private boolean readNextRowGroup() throws IOException {
        if (parquetReader == null) {
            return false;
        }

        PageReadStore rowGroup = parquetReader.readNextRowGroup();
        if (rowGroup == null) {
            return false;
        }

        long rowCount = rowGroup.getRowCount();
        LOG.debug("Reading row group with {} rows", rowCount);

        // Use simple record reader to convert Parquet rows to Spark InternalRows
        MessageColumnIO columnIO = new ColumnIOFactory().getColumnIO(parquetSchema);

        // Create record reader with a materializer that produces Object[]
        RecordReader<Object[]> recordReader = columnIO.getRecordReader(
            rowGroup, new SimpleRecordMaterializer(parquetSchema));

        // Read all rows from this row group
        for (int i = 0; i < rowCount; i++) {
            Object[] values = recordReader.read();
            if (values == null) {
                break;
            }

            // Convert to Spark InternalRow
            InternalRow row = convertToInternalRow(values);
            rowBuffer.add(row);
            totalRowsRead++;
        }

        return !rowBuffer.isEmpty();
    }

    /**
     * Converts an Object[] to Spark InternalRow.
     * Handles type conversion for common types.
     */
    private InternalRow convertToInternalRow(Object[] values) {
        Object[] sparkValues = new Object[values.length];

        for (int i = 0; i < values.length; i++) {
            Object value = values[i];
            if (value == null) {
                sparkValues[i] = null;
            } else if (value instanceof String) {
                // Spark uses UTF8String for strings
                sparkValues[i] = UTF8String.fromString((String) value);
            } else if (value instanceof byte[]) {
                // Binary data - wrap as is
                sparkValues[i] = value;
            } else if (value instanceof org.apache.parquet.io.api.Binary) {
                // Parquet Binary - convert to UTF8String or byte[]
                org.apache.parquet.io.api.Binary binary = (org.apache.parquet.io.api.Binary) value;
                sparkValues[i] = UTF8String.fromBytes(binary.getBytes());
            } else {
                // Numbers and other primitives pass through
                sparkValues[i] = value;
            }
        }

        return new GenericInternalRow(sparkValues);
    }

    /**
     * Simple record materializer that produces Object[] from Parquet records.
     */
    private static class SimpleRecordMaterializer
            extends org.apache.parquet.io.api.RecordMaterializer<Object[]> {

        private final SimpleGroupConverter root;

        SimpleRecordMaterializer(MessageType schema) {
            this.root = new SimpleGroupConverter(schema.getFieldCount());
        }

        @Override
        public Object[] getCurrentRecord() {
            return root.getValues();
        }

        @Override
        public org.apache.parquet.io.api.GroupConverter getRootConverter() {
            return root;
        }
    }

    /**
     * Simple group converter that collects field values into Object[].
     */
    private static class SimpleGroupConverter extends org.apache.parquet.io.api.GroupConverter {

        private final Object[] values;
        private final org.apache.parquet.io.api.PrimitiveConverter[] converters;

        SimpleGroupConverter(int fieldCount) {
            this.values = new Object[fieldCount];
            this.converters = new org.apache.parquet.io.api.PrimitiveConverter[fieldCount];
            for (int i = 0; i < fieldCount; i++) {
                final int idx = i;
                converters[i] = new org.apache.parquet.io.api.PrimitiveConverter() {
                    @Override
                    public void addInt(int value) {
                        values[idx] = value;
                    }

                    @Override
                    public void addLong(long value) {
                        values[idx] = value;
                    }

                    @Override
                    public void addFloat(float value) {
                        values[idx] = value;
                    }

                    @Override
                    public void addDouble(double value) {
                        values[idx] = value;
                    }

                    @Override
                    public void addBoolean(boolean value) {
                        values[idx] = value;
                    }

                    @Override
                    public void addBinary(org.apache.parquet.io.api.Binary value) {
                        values[idx] = value;
                    }
                };
            }
        }

        @Override
        public org.apache.parquet.io.api.Converter getConverter(int fieldIndex) {
            return converters[fieldIndex];
        }

        @Override
        public void start() {
            java.util.Arrays.fill(values, null);
        }

        @Override
        public void end() {
            // Values are ready
        }

        Object[] getValues() {
            return values.clone();
        }
    }

    /**
     * Converts Spark filters to a Rosetta expression string.
     *
     * <p>This produces an expression that can be passed to the Rosetta JNI layer
     * for filter pushdown. The format matches Rosetta's expression DSL.
     *
     * @param filters Array of Spark filters
     * @return Expression string, or null if conversion fails
     */
    private String convertFiltersToExpression(Filter[] filters) {
        if (filters == null || filters.length == 0) {
            return null;
        }

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < filters.length; i++) {
            if (i > 0) {
                sb.append(" AND ");
            }
            String filterExpr = convertFilter(filters[i]);
            if (filterExpr == null) {
                // If any filter fails to convert, return null
                return null;
            }
            sb.append("(").append(filterExpr).append(")");
        }
        return sb.toString();
    }

    /**
     * Converts a single Spark filter to a Rosetta expression string.
     */
    private String convertFilter(Filter filter) {
        if (filter instanceof EqualTo) {
            EqualTo eq = (EqualTo) filter;
            return String.format("%s = %s", eq.attribute(), formatValue(eq.value()));
        } else if (filter instanceof GreaterThan) {
            GreaterThan gt = (GreaterThan) filter;
            return String.format("%s > %s", gt.attribute(), formatValue(gt.value()));
        } else if (filter instanceof GreaterThanOrEqual) {
            GreaterThanOrEqual gte = (GreaterThanOrEqual) filter;
            return String.format("%s >= %s", gte.attribute(), formatValue(gte.value()));
        } else if (filter instanceof LessThan) {
            LessThan lt = (LessThan) filter;
            return String.format("%s < %s", lt.attribute(), formatValue(lt.value()));
        } else if (filter instanceof LessThanOrEqual) {
            LessThanOrEqual lte = (LessThanOrEqual) filter;
            return String.format("%s <= %s", lte.attribute(), formatValue(lte.value()));
        } else if (filter instanceof And) {
            And and = (And) filter;
            String left = convertFilter(and.left());
            String right = convertFilter(and.right());
            if (left == null || right == null) return null;
            return String.format("(%s) AND (%s)", left, right);
        } else if (filter instanceof Or) {
            Or or = (Or) filter;
            String left = convertFilter(or.left());
            String right = convertFilter(or.right());
            if (left == null || right == null) return null;
            return String.format("(%s) OR (%s)", left, right);
        } else if (filter instanceof Not) {
            Not not = (Not) filter;
            String child = convertFilter(not.child());
            if (child == null) return null;
            return String.format("NOT (%s)", child);
        } else if (filter instanceof IsNull) {
            IsNull isNull = (IsNull) filter;
            return String.format("%s IS NULL", isNull.attribute());
        } else if (filter instanceof IsNotNull) {
            IsNotNull isNotNull = (IsNotNull) filter;
            return String.format("%s IS NOT NULL", isNotNull.attribute());
        } else if (filter instanceof In) {
            In in = (In) filter;
            Object[] values = in.values();
            StringBuilder sb = new StringBuilder();
            sb.append(in.attribute()).append(" IN (");
            for (int i = 0; i < values.length; i++) {
                if (i > 0) sb.append(", ");
                sb.append(formatValue(values[i]));
            }
            sb.append(")");
            return sb.toString();
        }

        // Unknown filter type
        LOG.warn("Cannot convert filter to Rosetta expression: {}", filter);
        return null;
    }

    /**
     * Formats a value for use in an expression string.
     */
    private String formatValue(Object value) {
        if (value == null) {
            return "NULL";
        } else if (value instanceof String) {
            // Escape single quotes in strings
            String escaped = ((String) value).replace("'", "''");
            return "'" + escaped + "'";
        } else if (value instanceof Number) {
            return value.toString();
        } else if (value instanceof Boolean) {
            return value.toString().toUpperCase();
        } else {
            // Fall back to string representation
            return "'" + value.toString().replace("'", "''") + "'";
        }
    }
}
