// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.spark;

import org.apache.spark.sql.catalyst.InternalRow;
import org.apache.spark.sql.connector.read.InputPartition;
import org.apache.spark.sql.connector.read.PartitionReader;
import org.apache.spark.sql.connector.read.PartitionReaderFactory;
import org.apache.spark.sql.sources.Filter;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * Factory for creating partition readers.
 */
public class RosettaPartitionReaderFactory implements PartitionReaderFactory {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaPartitionReaderFactory.class);

    private final StructType schema;
    private final Map<String, String> properties;
    private final Filter[] filters;

    public RosettaPartitionReaderFactory(StructType schema, Map<String, String> properties, Filter[] filters) {
        this.schema = schema;
        this.properties = properties;
        this.filters = filters;
    }

    @Override
    public PartitionReader<InternalRow> createReader(InputPartition partition) {
        RosettaBatch.RosettaInputPartition rosettaPartition =
            (RosettaBatch.RosettaInputPartition) partition;

        LOG.debug("Creating reader for: {} with {} filters",
            rosettaPartition.getFilePath(), filters.length);
        return new RosettaPartitionReader(rosettaPartition.getFilePath(), schema, properties, filters);
    }
}
