// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.spark;

import org.apache.spark.sql.connector.read.Batch;
import org.apache.spark.sql.connector.read.InputPartition;
import org.apache.spark.sql.connector.read.PartitionReaderFactory;
import org.apache.spark.sql.sources.Filter;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Batch implementation for Rosetta data sources.
 */
public class RosettaBatch implements Batch {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaBatch.class);

    private final String path;
    private final StructType schema;
    private final Map<String, String> properties;
    private final Filter[] filters;

    public RosettaBatch(String path, StructType schema, Map<String, String> properties, Filter[] filters) {
        this.path = path;
        this.schema = schema;
        this.properties = properties;
        this.filters = filters;
    }

    @Override
    public InputPartition[] planInputPartitions() {
        LOG.debug("Planning partitions for: {}", path);

        List<InputPartition> partitions = new ArrayList<>();
        File file = new File(path);

        if (file.isDirectory()) {
            // Directory - create partition for each file
            File[] files = file.listFiles((dir, name) ->
                name.endsWith(".vortex") ||
                name.endsWith(".lance") ||
                name.endsWith(".parquet") ||
                name.endsWith(".f3")
            );

            if (files != null) {
                for (File f : files) {
                    partitions.add(new RosettaInputPartition(f.getAbsolutePath()));
                }
            }
        } else {
            // Single file
            partitions.add(new RosettaInputPartition(path));
        }

        LOG.info("Created {} partitions for: {}", partitions.size(), path);
        return partitions.toArray(new InputPartition[0]);
    }

    @Override
    public PartitionReaderFactory createReaderFactory() {
        return new RosettaPartitionReaderFactory(schema, properties, filters);
    }

    /**
     * Input partition representing a single file.
     */
    public static class RosettaInputPartition implements InputPartition {

        private final String filePath;

        public RosettaInputPartition(String filePath) {
            this.filePath = filePath;
        }

        public String getFilePath() {
            return filePath;
        }
    }
}
