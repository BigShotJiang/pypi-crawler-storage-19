// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.spark;

import org.apache.spark.sql.connector.catalog.SupportsRead;
import org.apache.spark.sql.connector.catalog.Table;
import org.apache.spark.sql.connector.catalog.TableCapability;
import org.apache.spark.sql.connector.read.ScanBuilder;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.util.CaseInsensitiveStringMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Spark Table implementation for Rosetta data sources.
 */
public class RosettaTable implements Table, SupportsRead {

    private static final Logger LOG = LoggerFactory.getLogger(RosettaTable.class);

    private final String path;
    private final StructType schema;
    private final Map<String, String> properties;

    public RosettaTable(String path, StructType schema, Map<String, String> properties) {
        this.path = path;
        this.schema = schema;
        this.properties = properties;
    }

    @Override
    public String name() {
        return "rosetta:" + path;
    }

    @Override
    public StructType schema() {
        return schema;
    }

    @Override
    public Set<TableCapability> capabilities() {
        Set<TableCapability> caps = new HashSet<>();
        caps.add(TableCapability.BATCH_READ);
        return caps;
    }

    @Override
    public ScanBuilder newScanBuilder(CaseInsensitiveStringMap options) {
        LOG.debug("Creating scan builder for: {}", path);
        return new RosettaScanBuilder(path, schema, properties);
    }
}
