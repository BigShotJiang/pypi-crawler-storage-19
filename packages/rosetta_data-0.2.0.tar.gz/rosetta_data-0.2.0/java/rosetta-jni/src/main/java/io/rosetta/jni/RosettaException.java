// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.jni;

/**
 * Exception thrown by Rosetta operations.
 */
public class RosettaException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * Create a new RosettaException with a message.
     *
     * @param message Error message
     */
    public RosettaException(String message) {
        super(message);
    }

    /**
     * Create a new RosettaException with a message and cause.
     *
     * @param message Error message
     * @param cause Underlying cause
     */
    public RosettaException(String message, Throwable cause) {
        super(message, cause);
    }
}
