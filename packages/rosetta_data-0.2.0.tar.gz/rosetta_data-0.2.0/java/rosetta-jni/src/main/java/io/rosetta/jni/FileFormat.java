// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.jni;

/**
 * File format enumeration.
 */
public enum FileFormat {
    /** Unknown or undetectable format */
    UNKNOWN(RosettaNative.FORMAT_UNKNOWN),
    /** Apache Parquet v1 (legacy encodings) */
    PARQUET_V1(RosettaNative.FORMAT_PARQUET_V1),
    /** Apache Parquet v2 (modern encodings) */
    PARQUET_V2(RosettaNative.FORMAT_PARQUET_V2),
    /** Vortex columnar format */
    VORTEX(RosettaNative.FORMAT_VORTEX),
    /** Lance format */
    LANCE(RosettaNative.FORMAT_LANCE),
    /** F3 format with embedded WASM */
    F3(RosettaNative.FORMAT_F3),
    /** FastLanes format */
    FASTLANES(RosettaNative.FORMAT_FASTLANES);

    private final int nativeValue;

    FileFormat(int nativeValue) {
        this.nativeValue = nativeValue;
    }

    /**
     * Get the native value for this format.
     *
     * @return Native format constant
     */
    public int getNativeValue() {
        return nativeValue;
    }

    /**
     * Convert a native format value to an enum.
     *
     * @param nativeValue Native format constant
     * @return Corresponding FileFormat
     */
    public static FileFormat fromNative(int nativeValue) {
        for (FileFormat format : values()) {
            if (format.nativeValue == nativeValue) {
                return format;
            }
        }
        return UNKNOWN;
    }

    /**
     * Detect the format of a file.
     *
     * @param path File path
     * @return Detected format
     */
    public static FileFormat detect(String path) {
        return fromNative(RosettaNative.detectFormat(path));
    }

    /**
     * Detect the format from header bytes.
     *
     * @param header Header bytes (at least 4)
     * @return Detected format
     */
    public static FileFormat detectFromBytes(byte[] header) {
        return fromNative(RosettaNative.detectFormatFromBytes(header));
    }

    /**
     * Detect the format from header and footer bytes.
     *
     * @param header Header bytes
     * @param footer Footer bytes (may be null)
     * @return Detected format
     */
    public static FileFormat detectFromHeaderFooter(byte[] header, byte[] footer) {
        return fromNative(RosettaNative.detectFormatFromHeaderFooter(header, footer));
    }

    /**
     * Check if this format requires transcoding to Parquet.
     *
     * @return true if this format is not Parquet
     */
    public boolean requiresTranscoding() {
        return this != PARQUET_V1 && this != PARQUET_V2;
    }

    /**
     * Check if this is a Parquet format.
     *
     * @return true if this is PARQUET_V1 or PARQUET_V2
     */
    public boolean isParquet() {
        return this == PARQUET_V1 || this == PARQUET_V2;
    }
}
