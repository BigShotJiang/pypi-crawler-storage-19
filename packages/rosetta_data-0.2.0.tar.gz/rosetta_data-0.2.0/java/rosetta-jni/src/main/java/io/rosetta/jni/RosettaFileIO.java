// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.jni;

import java.io.Closeable;
import java.io.IOException;

/**
 * High-level FileIO wrapper that automatically transcodes non-Parquet formats.
 *
 * <p>This class provides the primary interface for reading files through Rosetta.
 * It automatically detects file formats and transcodes Vortex, Lance, and other
 * formats to Parquet v1 bytes for compatibility with legacy readers.
 *
 * <p>Example usage:
 * <pre>{@code
 * try (RosettaFileIO fileio = new RosettaFileIO()) {
 *     // Read a Vortex file as Parquet bytes
 *     byte[] parquetBytes = fileio.read("data.vortex");
 *
 *     // Check if transcoding is needed
 *     if (fileio.shouldTranscode("data.lance")) {
 *         System.out.println("Lance file will be transcoded to Parquet");
 *     }
 * }
 * }</pre>
 *
 * <p>Thread Safety: All methods are thread-safe.
 */
public class RosettaFileIO implements Closeable {

    private volatile long handle;
    private final Object lock = new Object();

    /**
     * Create a new RosettaFileIO with default configuration.
     *
     * @throws RosettaException if the native library cannot be initialized
     */
    public RosettaFileIO() throws RosettaException {
        this.handle = RosettaNative.fileioNew();
        if (this.handle == 0) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to create FileIO: " +
                (error != null ? error : "unknown error"));
        }
    }

    /**
     * Check if a file should be transcoded based on its format.
     *
     * @param path File path
     * @return true if the file will be transcoded to Parquet
     * @throws IllegalStateException if the FileIO has been closed
     */
    public boolean shouldTranscode(String path) {
        checkOpen();
        return RosettaNative.fileioShouldTranscode(handle, path);
    }

    /**
     * Read a file, transcoding to Parquet v1 if necessary.
     *
     * <p>If the file is already in Parquet format, it is returned as-is.
     * Otherwise, it is transcoded to Parquet v1 bytes.
     *
     * @param path File path
     * @return File bytes (Parquet v1 format)
     * @throws RosettaException if the file cannot be read or transcoded
     * @throws IllegalStateException if the FileIO has been closed
     */
    public byte[] read(String path) throws RosettaException {
        checkOpen();
        byte[] result = RosettaNative.fileioRead(handle, path);
        if (result == null) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to read file: " + path +
                (error != null ? " - " + error : ""));
        }
        return result;
    }

    /**
     * Check if a file exists.
     *
     * @param path File path
     * @return true if the file exists
     * @throws IllegalStateException if the FileIO has been closed
     */
    public boolean exists(String path) {
        checkOpen();
        return RosettaNative.fileioExists(handle, path);
    }

    /**
     * Get the length of a file.
     *
     * @param path File path
     * @return File length in bytes
     * @throws RosettaException if the file length cannot be determined
     * @throws IllegalStateException if the FileIO has been closed
     */
    public long length(String path) throws RosettaException {
        checkOpen();
        long len = RosettaNative.fileioLength(handle, path);
        if (len < 0) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to get file length: " + path +
                (error != null ? " - " + error : ""));
        }
        return len;
    }

    /**
     * Write bytes to a file.
     *
     * @param path File path
     * @param data Bytes to write
     * @throws RosettaException if the file cannot be written
     * @throws IllegalStateException if the FileIO has been closed
     */
    public void write(String path, byte[] data) throws RosettaException {
        checkOpen();
        if (!RosettaNative.fileioWrite(handle, path, data)) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to write file: " + path +
                (error != null ? " - " + error : ""));
        }
    }

    /**
     * Delete a file.
     *
     * @param path File path
     * @throws RosettaException if the file cannot be deleted
     * @throws IllegalStateException if the FileIO has been closed
     */
    public void delete(String path) throws RosettaException {
        checkOpen();
        if (!RosettaNative.fileioDelete(handle, path)) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to delete file: " + path +
                (error != null ? " - " + error : ""));
        }
    }

    /**
     * Clear the internal cache.
     *
     * <p>This frees memory used for caching transcoded files.
     *
     * @throws IllegalStateException if the FileIO has been closed
     */
    public void clearCache() {
        checkOpen();
        RosettaNative.fileioClearCache(handle);
    }

    /**
     * Close the FileIO and release native resources.
     */
    @Override
    public void close() {
        synchronized (lock) {
            if (handle != 0) {
                RosettaNative.fileioFree(handle);
                handle = 0;
            }
        }
    }

    /**
     * Check if the FileIO is open.
     *
     * @return true if open
     */
    public boolean isOpen() {
        return handle != 0;
    }

    private void checkOpen() {
        if (handle == 0) {
            throw new IllegalStateException("RosettaFileIO has been closed");
        }
    }
}
