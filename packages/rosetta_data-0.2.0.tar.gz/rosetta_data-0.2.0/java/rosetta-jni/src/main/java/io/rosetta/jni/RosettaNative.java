// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.jni;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * Low-level JNI bindings for Rosetta native library.
 *
 * <p>This class provides direct access to the Rosetta C FFI functions.
 * Most users should use the higher-level {@link RosettaFileIO} or
 * {@link RosettaTranscoder} classes instead.
 *
 * <p>Thread Safety: All methods are thread-safe.
 */
public final class RosettaNative {

    private static final String LIBRARY_NAME = "rosetta";
    private static volatile boolean loaded = false;
    private static volatile Throwable loadError = null;

    // Private constructor - all methods are static
    private RosettaNative() {}

    /**
     * Load the native library.
     *
     * <p>This method is idempotent - calling it multiple times has no effect.
     *
     * @throws UnsatisfiedLinkError if the native library cannot be loaded
     */
    public static synchronized void load() {
        if (loaded) {
            return;
        }
        if (loadError != null) {
            throw new UnsatisfiedLinkError("Native library failed to load previously: " + loadError);
        }

        try {
            // Try to load from java.library.path first
            try {
                System.loadLibrary(LIBRARY_NAME);
                loaded = true;
                return;
            } catch (UnsatisfiedLinkError e) {
                // Fall through to resource extraction
            }

            // Extract from JAR resources
            String os = System.getProperty("os.name").toLowerCase();
            String arch = System.getProperty("os.arch").toLowerCase();

            String libName;
            if (os.contains("mac") || os.contains("darwin")) {
                libName = "librosetta.dylib";
            } else if (os.contains("linux")) {
                libName = "librosetta.so";
            } else if (os.contains("win")) {
                libName = "rosetta.dll";
            } else {
                throw new UnsatisfiedLinkError("Unsupported OS: " + os);
            }

            String resourcePath = "/native/" + arch + "/" + libName;
            try (InputStream is = RosettaNative.class.getResourceAsStream(resourcePath)) {
                if (is == null) {
                    throw new UnsatisfiedLinkError(
                        "Native library not found in JAR: " + resourcePath +
                        ". Set java.library.path to include directory with " + libName);
                }

                Path tempDir = Files.createTempDirectory("rosetta-native");
                Path tempLib = tempDir.resolve(libName);
                Files.copy(is, tempLib, StandardCopyOption.REPLACE_EXISTING);
                tempLib.toFile().deleteOnExit();
                tempDir.toFile().deleteOnExit();

                System.load(tempLib.toString());
            }

            loaded = true;
        } catch (IOException | UnsatisfiedLinkError e) {
            loadError = e;
            throw new UnsatisfiedLinkError("Failed to load native library: " + e.getMessage());
        }
    }

    /**
     * Ensure the native library is loaded.
     */
    static {
        load();
    }

    // =========================================================================
    // Version
    // =========================================================================

    /**
     * Get the Rosetta library version.
     *
     * @return Version string
     */
    public static native String version();

    // =========================================================================
    // FileIO Functions
    // =========================================================================

    /**
     * Create a new FileIO handle.
     *
     * @return Native handle pointer, or 0 on error
     */
    public static native long fileioNew();

    /**
     * Free a FileIO handle.
     *
     * @param handle Native handle pointer
     */
    public static native void fileioFree(long handle);

    /**
     * Check if a file should be transcoded.
     *
     * @param handle Native handle pointer
     * @param path File path
     * @return true if the file should be transcoded
     */
    public static native boolean fileioShouldTranscode(long handle, String path);

    /**
     * Read a file, transcoding if necessary.
     *
     * @param handle Native handle pointer
     * @param path File path
     * @return File bytes, or null on error (check getLastError)
     */
    public static native byte[] fileioRead(long handle, String path);

    /**
     * Check if a file exists.
     *
     * @param handle Native handle pointer
     * @param path File path
     * @return true if file exists, false otherwise or on error
     */
    public static native boolean fileioExists(long handle, String path);

    /**
     * Get file length.
     *
     * @param handle Native handle pointer
     * @param path File path
     * @return File length, or -1 on error
     */
    public static native long fileioLength(long handle, String path);

    /**
     * Write bytes to a file.
     *
     * @param handle Native handle pointer
     * @param path File path
     * @param data Bytes to write
     * @return true on success
     */
    public static native boolean fileioWrite(long handle, String path, byte[] data);

    /**
     * Delete a file.
     *
     * @param handle Native handle pointer
     * @param path File path
     * @return true on success
     */
    public static native boolean fileioDelete(long handle, String path);

    /**
     * Clear the FileIO cache.
     *
     * @param handle Native handle pointer
     */
    public static native void fileioClearCache(long handle);

    // =========================================================================
    // Schema Functions
    // =========================================================================

    /**
     * Get the Arrow schema of a file as JSON.
     *
     * @param path File path
     * @return JSON string representing the Arrow schema, or null on error (check getLastError)
     */
    public static native String getSchemaJson(String path);

    // =========================================================================
    // Format Detection
    // =========================================================================

    /** Unknown format */
    public static final int FORMAT_UNKNOWN = 0;
    /** Parquet v1 */
    public static final int FORMAT_PARQUET_V1 = 1;
    /** Parquet v2 */
    public static final int FORMAT_PARQUET_V2 = 2;
    /** Vortex */
    public static final int FORMAT_VORTEX = 3;
    /** Lance */
    public static final int FORMAT_LANCE = 4;
    /** F3 */
    public static final int FORMAT_F3 = 5;
    /** FastLanes */
    public static final int FORMAT_FASTLANES = 6;

    /**
     * Detect file format from path.
     *
     * @param path File path
     * @return Format constant (FORMAT_*)
     */
    public static native int detectFormat(String path);

    /**
     * Detect file format from header bytes.
     *
     * @param header Header bytes (at least 4)
     * @return Format constant (FORMAT_*)
     */
    public static native int detectFormatFromBytes(byte[] header);

    /**
     * Detect file format from header and footer bytes.
     *
     * @param header Header bytes
     * @param footer Footer bytes (may be null)
     * @return Format constant (FORMAT_*)
     */
    public static native int detectFormatFromHeaderFooter(byte[] header, byte[] footer);

    // =========================================================================
    // Transcoder Functions
    // =========================================================================

    /**
     * Create a new Transcoder handle.
     *
     * @return Native handle pointer
     */
    public static native long transcoderNew();

    /**
     * Free a Transcoder handle.
     *
     * @param handle Native handle pointer
     */
    public static native void transcoderFree(long handle);

    /**
     * Transcode a file to Parquet v1 bytes.
     *
     * @param handle Native handle pointer
     * @param path File path
     * @return Parquet v1 bytes, or null on error
     */
    public static native byte[] transcoderTranscodeFile(long handle, String path);

    /**
     * Transcode a file to Parquet v1 bytes with filter pushdown.
     *
     * <p>The filter is a JSON string representing a Rosetta expression.
     * Format: {"op": "gt", "left": {"col": "age"}, "right": {"lit": 30}}
     *
     * @param handle Native handle pointer
     * @param path File path
     * @param filterJson JSON filter expression (may be null for no filter)
     * @return Parquet v1 bytes, or null on error
     */
    public static native byte[] transcoderTranscodeFileWithFilter(long handle, String path, String filterJson);

    // =========================================================================
    // Error Handling
    // =========================================================================

    /**
     * Get the last error message from the most recent operation.
     *
     * @return Error message, or null if no error
     */
    public static native String getLastError();
}
