// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

package io.rosetta.jni;

import java.io.Closeable;

/**
 * Transcoder for converting files to Parquet v1 format.
 *
 * <p>This class provides direct access to the transcoding functionality.
 * For most use cases, {@link RosettaFileIO} is more convenient as it
 * handles transcoding automatically.
 *
 * <p>Example usage:
 * <pre>{@code
 * try (RosettaTranscoder transcoder = new RosettaTranscoder()) {
 *     byte[] parquetBytes = transcoder.transcode("data.vortex");
 *     // parquetBytes now contains Parquet v1 data
 * }
 * }</pre>
 *
 * <p>Thread Safety: All methods are thread-safe.
 */
public class RosettaTranscoder implements Closeable {

    private volatile long handle;
    private final Object lock = new Object();

    /**
     * Create a new Transcoder.
     */
    public RosettaTranscoder() {
        this.handle = RosettaNative.transcoderNew();
    }

    /**
     * Transcode a file to Parquet v1 bytes.
     *
     * @param path File path
     * @return Parquet v1 bytes
     * @throws RosettaException if transcoding fails
     * @throws IllegalStateException if the Transcoder has been closed
     */
    public byte[] transcode(String path) throws RosettaException {
        checkOpen();
        byte[] result = RosettaNative.transcoderTranscodeFile(handle, path);
        if (result == null) {
            String error = RosettaNative.getLastError();
            throw new RosettaException("Failed to transcode file: " + path +
                (error != null ? " - " + error : ""));
        }
        return result;
    }

    /**
     * Close the Transcoder and release native resources.
     */
    @Override
    public void close() {
        synchronized (lock) {
            if (handle != 0) {
                RosettaNative.transcoderFree(handle);
                handle = 0;
            }
        }
    }

    /**
     * Check if the Transcoder is open.
     *
     * @return true if open
     */
    public boolean isOpen() {
        return handle != 0;
    }

    private void checkOpen() {
        if (handle == 0) {
            throw new IllegalStateException("RosettaTranscoder has been closed");
        }
    }
}
