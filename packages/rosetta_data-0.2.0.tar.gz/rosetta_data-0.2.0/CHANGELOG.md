# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial public release
- Core format readers: Parquet v1/v2, Vortex, Lance
- Automatic format detection via magic bytes and file structure
- Unified reader API for transparent format access
- Python bindings via PyO3 with PyArrow integration
- CLI tool for format detection, reading, and conversion
- Transcoder for converting any format to Parquet v1
- Progressive upgrade system for existing Parquet files
- Intelligent encoding selector based on column statistics
- S3-compatible proxy for transparent transcoding
- FUSE filesystem for transparent file access
- DuckDB extension for SQL access to any format
- Iceberg FileIO integration
- WASM runtime for F3-style self-describing files
- Comprehensive benchmark suite
- Extension points for observability (ReaderHooks, TranscodeHooks)
- Extension points for authentication (AuthProvider)

### Performance
- Near-zero overhead for Parquet passthrough (~0%)
- Vortex: 32% smaller files, 43% faster reads vs Parquet
- Lance: 35% faster reads (optimized for ML workloads)
- Format detection: ~150µs per file

### Documentation
- README with quick start guides
- Architecture documentation
- Contributing guidelines
- API documentation

## [0.1.0] - 2026-01-07

### Added
- Initial release

[Unreleased]: https://github.com/rosetta-data/rosetta/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/rosetta-data/rosetta/releases/tag/v0.1.0
