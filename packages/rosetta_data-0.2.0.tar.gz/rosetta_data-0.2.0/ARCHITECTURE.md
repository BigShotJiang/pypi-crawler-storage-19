# Rosetta Architecture

This document describes the internal architecture of Rosetta, the universal file format bridge for columnar data.

## Overview

Rosetta provides a unified interface for reading multiple columnar file formats (Parquet, Vortex, Lance) and outputting Apache Arrow RecordBatches. The core design principle is **transparency**: applications can read any supported format without knowing the underlying storage format.

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Application Layer                             │
│      (Spark, DuckDB, Polars, Pandas, DataFusion, Custom Apps)       │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      Rosetta Bridge Layer                            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │
│  │   Format    │  │   Unified   │  │  Transcoder │  │   WASM     │ │
│  │  Detector   │  │   Reader    │  │   Engine    │  │  Runtime   │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    ▼               ▼               ▼
             ┌──────────┐    ┌──────────┐    ┌──────────┐
             │ Parquet  │    │  Vortex  │    │  Lance   │
             │ Reader   │    │  Reader  │    │  Reader  │
             └──────────┘    └──────────┘    └──────────┘
                                    │
                                    ▼
                           Arrow RecordBatches
```

## Core Components

### 1. Format Detector (`src/format.rs`)

Automatically identifies file formats using magic bytes and file structure analysis.

**Detection Methods:**
- **Magic bytes**: First 4-8 bytes identify most formats
  - Parquet: `PAR1` at start and end
  - Vortex: `VTXF` magic
  - Lance: Directory structure with `_latest.manifest`
- **File extension**: Fallback when magic detection is ambiguous
- **Content analysis**: For formats without clear magic bytes

```rust
pub struct FormatDetector {
    // Configuration for detection
}

impl FormatDetector {
    pub async fn detect_file(&self, path: &Path) -> Result<FileFormat>;
    pub async fn detect_bytes(&self, bytes: &[u8]) -> Result<FileFormat>;
    pub async fn detect_url(&self, url: &str) -> Result<FileFormat>;
}
```

**Supported Formats:**
| Format | Magic Bytes | Extension |
|--------|-------------|-----------|
| Parquet v1 | `PAR1` | `.parquet` |
| Parquet v2 | `PAR1` + v2 features | `.parquet` |
| Vortex | `VTXF` | `.vortex` |
| Lance | Directory structure | `.lance/` |
| F3 | `F3` + WASM | `.f3` |

### 2. Unified Reader (`src/readers/unified.rs`)

The primary entry point for reading any supported format. Routes to appropriate format-specific readers.

```rust
pub struct UnifiedReader {
    inner: Box<dyn FormatReader>,
    format: FileFormat,
    schema: SchemaRef,
}

impl UnifiedReader {
    /// Auto-detect format and open file
    pub async fn open(path: impl AsRef<Path>) -> Result<Self>;

    /// Open with explicit options
    pub async fn open_with_options(path: impl AsRef<Path>, options: ReadOptions) -> Result<Self>;

    /// Read all data
    pub async fn read_all(&self) -> Result<Vec<RecordBatch>>;

    /// Read specific columns only
    pub async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>>;
}
```

### 3. Format Reader Trait (`src/readers/mod.rs`)

All format-specific readers implement this trait, enabling polymorphic reading.

```rust
#[async_trait]
pub trait FormatReader: Send + Sync {
    /// Get the schema
    fn schema(&self) -> SchemaRef;

    /// Number of row groups (if applicable)
    fn num_row_groups(&self) -> usize;

    /// Read all data
    async fn read_all(&self) -> Result<Vec<RecordBatch>>;

    /// Read specific row group
    async fn read_row_group(&self, row_group: usize) -> Result<Vec<RecordBatch>>;

    /// Read with column projection
    async fn read_projection(&self, columns: &[String]) -> Result<Vec<RecordBatch>>;

    /// Acceleration type (CPU, GPU, WASM)
    fn acceleration(&self) -> ReaderAcceleration { ReaderAcceleration::Cpu }
}
```

### 4. Transcoder (`src/transcoder.rs`)

Converts any supported format to Parquet v1 bytes for legacy reader compatibility.

```rust
pub struct Transcoder {
    writer_options: ParquetWriterOptions,
    read_options: ReadOptions,
}

impl Transcoder {
    /// Transcode file to Parquet bytes
    pub async fn transcode_file(&self, path: &Path) -> Result<TranscodeResult>;

    /// Transcode from URL
    pub async fn transcode_url(&self, url: &str) -> Result<TranscodeResult>;
}

pub struct TranscodeResult {
    pub bytes: Bytes,
    pub source_format: FileFormat,
    pub target_format: FileFormat,
    pub num_rows: usize,
    pub num_columns: usize,
}
```

### 5. Encoding Selector (`src/encoding.rs`)

Intelligent selection of optimal encodings based on column statistics.

```rust
pub struct EncodingSelector;

impl EncodingSelector {
    /// Analyze column and recommend encoding
    pub fn recommend(&self, stats: &ColumnStats) -> EncodingRecommendation;
}

pub struct ColumnStats {
    pub data_type: DataType,
    pub null_count: usize,
    pub distinct_count: usize,
    pub min: Option<ScalarValue>,
    pub max: Option<ScalarValue>,
    pub is_sorted: bool,
}
```

**Encoding Selection Logic:**
| Data Pattern | Recommended Encoding |
|--------------|---------------------|
| Sequential integers | Delta encoding |
| Low cardinality strings | Dictionary + FSST |
| High cardinality strings | Plain + compression |
| Floats with patterns | Byte stream split |
| Embeddings (256+ bytes) | Lance blob format |

### 6. Progressive Upgrader (`src/upgrade.rs`)

Upgrade existing Parquet files to use modern encodings without full rewrites.

```rust
pub struct Upgrader {
    options: UpgradeOptions,
}

impl Upgrader {
    /// Analyze file for upgrade opportunities
    pub async fn analyze(&self, path: &Path) -> Result<FileAnalysis>;

    /// Perform upgrade
    pub async fn upgrade(&self, path: &Path) -> Result<UpgradeReport>;
}
```

## Extension Points

### Reader Hooks (`src/readers/mod.rs`)

Extension point for observability and caching:

```rust
pub trait ReaderHooks: Send + Sync {
    fn on_read_start(&self, path: &str, format: &str);
    fn on_read_complete(&self, path: &str, duration: Duration, bytes: usize, rows: usize);
    fn on_read_error(&self, path: &str, error: &str);
    fn check_cache(&self, path: &str, columns: Option<&[String]>) -> Option<Vec<RecordBatch>>;
    fn store_cache(&self, path: &str, columns: Option<&[String]>, batches: &[RecordBatch]);
}
```

### Transcode Hooks (`src/transcoder.rs`)

Extension point for transcode metrics and caching:

```rust
pub trait TranscodeHooks: Send + Sync {
    fn check_cache(&self, source_path: &str, source_format: FileFormat) -> Option<Bytes>;
    fn store_cache(&self, source_path: &str, result: &TranscodeResult);
    fn on_transcode_start(&self, source_path: &str, source_format: FileFormat);
    fn on_transcode_complete(&self, source_path: &str, result: &TranscodeResult, duration: Duration);
}
```

### Auth Provider (`src/proxy/mod.rs`)

Extension point for authentication in the S3 proxy:

```rust
#[async_trait]
pub trait AuthProvider: Send + Sync {
    async fn authenticate(&self, request: &AuthRequest) -> Result<Identity, AuthError>;
    async fn authorize(&self, identity: &Identity, resource: &str, action: &str) -> bool;
}
```

## Integration Points

### S3 Proxy (`src/proxy/`)

S3-compatible proxy that transparently transcodes files:

```
Client Request (GET s3://bucket/data.vortex)
         │
         ▼
┌─────────────────┐
│  S3 Proxy       │ ← Intercepts request
└─────────────────┘
         │
         ▼
┌─────────────────┐
│  Transcoder     │ ← Vortex → Parquet
└─────────────────┘
         │
         ▼
Client receives Parquet bytes
```

### FUSE Filesystem (`src/fuse/`)

Mount any directory and transparently serve transcoded files:

```bash
rosetta mount /data/lake /mnt/rosetta
# Reading /mnt/rosetta/data.vortex returns Parquet bytes
```

### DuckDB Extension (`src/duckdb/`)

```sql
LOAD rosetta;
SELECT * FROM read_parquet('data.vortex');
```

### Iceberg FileIO (`src/iceberg/`)

```python
catalog = load_catalog("catalog", **{"io-impl": "rosetta.iceberg.RosettaFileIO"})
```

## Data Flow

### Read Path

```
1. UnifiedReader::open(path)
   │
   ├─► FormatDetector::detect_file(path)
   │   └─► Returns FileFormat
   │
   ├─► Create format-specific reader
   │   ├── ParquetReader (if Parquet)
   │   ├── VortexReader (if Vortex)
   │   └── LanceReader (if Lance)
   │
   └─► Return UnifiedReader

2. reader.read_all()
   │
   ├─► Format-specific read implementation
   │   └─► Returns Arrow RecordBatches
   │
   └─► Return batches to caller
```

### Transcode Path

```
1. Transcoder::transcode_file(path)
   │
   ├─► FormatDetector::detect_file(path)
   │
   ├─► UnifiedReader::open(path)
   │
   ├─► reader.read_all()
   │   └─► Returns Arrow RecordBatches
   │
   ├─► ParquetWriter::write_batches(batches)
   │   └─► Returns Parquet v1 bytes
   │
   └─► Return TranscodeResult
```

## Performance Considerations

### Zero-Copy Where Possible

- Arrow RecordBatches use zero-copy slicing
- Memory-mapped file access for large files
- Buffer pooling for repeated operations

### Async I/O

- All file operations are async (tokio)
- Concurrent row group reading
- Non-blocking format detection

### Caching

- Format detection results cached
- Schema cached after first read
- Extension point for result caching

## Feature Flags

```toml
[features]
default = ["parquet-reader"]
parquet-reader = []              # Always available
vortex-reader = [...]            # Vortex format support
lance-reader = ["lance"]         # Lance format support
wasm-runtime = ["wasmtime"]      # F3 self-describing files
fuse-reader = ["fuser", "libc"]  # FUSE filesystem
python = ["pyo3", "arrow/pyarrow"]  # Python bindings
enterprise = []                  # Enterprise extension flag
```

## Error Handling

All errors use the `Error` enum in `src/error.rs`:

```rust
pub enum Error {
    Io(std::io::Error),
    Arrow(arrow::error::ArrowError),
    Parquet(parquet::errors::ParquetError),
    UnknownFormat { path: PathBuf },
    UnsupportedFormat { format: String, feature: String },
    InvalidFile { message: String },
    ColumnNotFound { column: String },
    Config { message: String },
    // ...
}
```

## Testing Strategy

- **Unit tests**: In-module tests for individual components
- **Integration tests**: `tests/` directory for cross-component testing
- **Benchmark tests**: `benches/` for performance regression testing
- **Python tests**: `python/tests/` for binding validation

## Future Considerations

- **GPU acceleration**: CUDA/ROCm readers implementing `FormatReader`
- **Distributed reading**: Partition-aware reading for large datasets
- **Write path**: Full write support for all formats
- **Streaming**: Incremental reading for very large files
