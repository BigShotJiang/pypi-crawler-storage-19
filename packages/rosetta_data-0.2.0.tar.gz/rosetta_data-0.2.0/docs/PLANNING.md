# Rosetta: Universal File Format Bridge - Critical Evaluation & MVP Spec

## Executive Summary

**Verdict: Technically Sound, Go-to-Market Challenging**

The Rosetta concept addresses a real problem validated by academic research and industry momentum. However, this is a **"chronic infrastructure pain"** not a **"hair on fire problem"**. Success depends heavily on execution strategy and timing relative to format consolidation in the market.

---

## Critical Evaluation Against Your Criteria

### 1. Profitable? ⚠️ MIXED

**Positive signals:**
- Data lake market: $19-26B in 2025, growing 22-25% CAGR
- Data lakehouse market: $14B → $106B by 2034
- Clear acquisition path: Databricks bought Tabular ($1-2B), Neon ($1B) in 2024-2025

**Concerns:**
- Infrastructure companies need massive scale before profitability
- No existing commercial market for "format transcoding as a service"
- Likely to be commoditized quickly if successful

**Revenue model options:**
1. **SaaS transcoding service** - Pay per TB processed
2. **Enterprise license** - Self-hosted with support contracts
3. **Open core** - OSS with commercial features (progressive upgrade, GPU path)

**Realistic path:** 2-3 years to meaningful revenue, acquisition is the primary exit.

---

### 2. Solves Hair on Fire Pain? ⚠️ MIXED

**The problem is validated:**
- Andy Pavlo's research: 94% of Parquet files use v1 features from 2013
- DuckDB disabled v2 encodings by default due to compatibility issues
- Real-world case: Polar Signals achieved 70% query improvement switching to Vortex

**But it's chronic pain, not acute:**
- Nobody's production system is breaking today
- Workarounds exist (just use older encodings)
- Performance gains are nice-to-have, not must-have for most

**Who actually has hair on fire:**
1. **ML/AI teams** - Need 100x faster random access for training (Lance's market)
2. **GPU processing teams** - Parquet doesn't parallelize on GPUs (Vortex's market)
3. **Wide table teams** - Metadata overhead kills 1000+ column workloads

**Recommendation:** Target ML/AI teams specifically, not general analytics users.

---

### 3. Is Whitespace? ⚠️ PARTIAL WHITESPACE

**What already exists:**
- **F3** (CMU/Tsinghua) - Academic implementation of WASM-embedded decoders
- **AnyBlox** (TUM) - Won VLDB 2025 Best Paper for same concept
- **Apache Arrow** - Already the interoperability standard, 700+ contributors

**What doesn't exist (the actual whitespace):**
- Commercial product combining these research ideas
- Transparent bridge layer that requires no app changes
- Progressive upgrade tooling for existing Parquet data
- GPU-accelerated transcoding path

**Risk:** F3 or AnyBlox teams could commercialize. CMU has spun out successful database companies (OtterTune, Peloton → CockroachDB).

---

### 4. Better than State of the Art? ✅ YES (if executed well)

**Current state of the art:**
| Component | Existing Solution | Rosetta Advantage |
|-----------|-------------------|-------------------|
| WASM fallback | F3, AnyBlox | Commercialized, production-ready |
| Format bridge | None | First mover |
| Progressive upgrade | Manual rewrites | Automated, column-level |
| GPU path | Vortex only | Multi-format GPU support |

**Key differentiators:**
1. **Transparent integration** - Works with existing Spark/DuckDB/Polars code
2. **Multi-format support** - Not just Vortex or just Lance, but all
3. **Progressive upgrade** - Critical for enterprise adoption (no big bang migration)

---

### 5. Easy to Sell? ❌ DIFFICULT

**Sales challenges:**
- **Long enterprise sales cycles** - 6-12 months for infrastructure
- **Conservative data teams** - "If it ain't broke..."
- **Difficult ROI quantification** - "10% faster queries" doesn't drive purchase orders
- **Multi-vendor politics** - Touches Databricks, Snowflake, Spark, Iceberg...

**What makes it easier:**
- Performance benchmarks are compelling (10-100x improvements possible)
- Cost savings quantifiable (smaller files = less S3 costs)
- No migration required (drop-in layer)

**Recommended approach:**
1. Start with OSS community adoption
2. Target specific pain point: ML feature stores with wide tables
3. Build case studies with design partners before monetizing
4. Let acquisition interest drive enterprise sales

---

## Market Analysis

### Total Addressable Market

```
Data Lake Market (2025)         $19-26B
├── Analytics Workloads         ~60%
├── ML/AI Workloads             ~25%
└── Other (Archive, etc.)       ~15%

Relevant Segment (ML/AI + Analytics on Object Storage)
├── Parquet-based workloads     ~$8-10B
├── Needs format optimization   ~30% (pain point exists)
└── Would pay for solution      ~$2.5-3B TAM
```

### Key Market Trends

1. **Format Fragmentation** - 5 new formats in 2024-2025: Vortex, Lance, F3, FastLanes, AnyBlox
2. **GPU Acceleration** - NVIDIA pushing data processing to GPU; Vortex explicitly designed for this
3. **Lakehouse Convergence** - Iceberg adoption accelerating (Databricks bought Tabular)
4. **AI Workloads Driving Change** - Lance's 100x random access matters for training

---

## Competitive Landscape

### Direct Competition

| Player | Approach | Threat Level |
|--------|----------|--------------|
| **Apache Arrow** | Interop standard, not format bridge | Low - complementary |
| **F3 Project** | Academic WASM implementation | Medium - could commercialize |
| **AnyBlox** | VLDB 2025 best paper | Medium - TUM could spin out |
| **AWS/GCP/Azure** | Managed conversion services | High - could build this |

### Format Vendors (Potential Partners or Acquirers)

| Vendor | Format | Status | Acquisition Interest |
|--------|--------|--------|---------------------|
| **SpiralDB** | Vortex | $22M raised, donated to Linux Foundation | High - needs Parquet compat |
| **LanceDB** | Lance | $30M Series A (June 2025) | Medium - focused on vector search |
| **Databricks** | Delta Lake | $100B+ valuation | High - always acquiring infra |
| **Snowflake** | Proprietary | Backing Vortex project | Medium |

### Technology Stack Comparison

```
                    Native Perf    WASM Fallback    GPU Support    Production Ready
Rosetta (proposed)       ✅             ✅              ✅              ❌
F3                      ✅             ✅              ❌              ❌
AnyBlox                 ✅             ✅              ❌              ❌
Vortex                  ✅             ❌              ✅              ⚠️
Lance                   ✅             ❌              ⚠️              ✅
```

---

## MVP Specification

### Phase 1: Core Read Path (Months 1-3)

**Goal:** Read Vortex and Lance files through Parquet API

**Components:**
```
rosetta/
├── src/
│   ├── format_detect.rs      # Magic number detection
│   ├── codec_registry.rs     # Encoding → decoder mapping
│   ├── transcoder.rs         # Format → Arrow conversion
│   ├── readers/
│   │   ├── parquet_v1.rs
│   │   ├── parquet_v2.rs
│   │   ├── vortex.rs         # Use vortex-rs crate
│   │   └── lance.rs          # Use lance crate
│   └── integrations/
│       ├── duckdb/           # DuckDB extension
│       └── python/           # PyO3 bindings
├── benches/                  # Performance benchmarks
└── tests/                    # Compatibility tests
```

**Key Dependencies:**
- `vortex-rs` - Vortex format reader
- `lance` - Lance format reader
- `arrow-rs` - Arrow columnar format
- `parquet` - Parquet reader/writer
- `pyo3` - Python bindings

**Success Metrics:**
- Read Vortex files through `rosetta.read_parquet()` API
- <20% overhead vs native Vortex reads
- Pass DuckDB TPC-H queries with transcoded data

### Phase 2: WASM Runtime (Months 4-5)

**Goal:** Enable reading any F3-style self-describing file

**Components:**
```
src/
├── wasm/
│   ├── runtime.rs            # Wasmtime integration
│   ├── decoder_api.rs        # Init/Decode/Check interface
│   ├── sandbox.rs            # Resource limits, security
│   └── instance_pool.rs      # Reuse WASM instances
```

**Key Dependencies:**
- `wasmtime` - Bytecode Alliance WASM runtime (same as F3 uses)

**Security Model:**
```rust
struct WasmLimits {
    max_memory_bytes: usize,      // Default: 16MB
    max_execution_ms: u64,        // Default: 5000ms
    max_output_size: usize,       // Must match schema
}

struct DecoderAllowlist {
    allowed_encoder_ids: HashSet<EncoderId>,
    checksum_registry: HashMap<EncoderId, Sha256>,
}
```

**Success Metrics:**
- Read F3 files with embedded WASM decoders
- <30% overhead vs native (matching F3 paper's benchmarks)
- No security escapes in fuzzing

### Phase 3: Write Path + Encoding Selection (Month 6)

**Goal:** Intelligent format selection based on column characteristics

**Encoding Selection Logic:**
```rust
fn select_encoding(column: &Column, stats: &ColumnStats) -> Encoding {
    match column.data_type() {
        DataType::Int64 if stats.is_sequential() =>
            Encoding::FastLanesDelta,
        DataType::Utf8 if stats.cardinality < 10000 =>
            Encoding::DictionaryFSST,
        DataType::Float32 if stats.variance.is_high() =>
            Encoding::ByteStreamSplit,
        DataType::FixedSizeBinary(n) if *n >= 256 =>
            Encoding::LanceBlob,  // Embeddings
        _ => Encoding::ParquetV1Plain,  // Safe fallback
    }
}
```

**Success Metrics:**
- 30% smaller files than Parquet v1 on TPC-H
- Readable by native Parquet readers (fallback mode)

### Phase 4: Integration & Progressive Upgrade (Months 7-9)

**Goal:** Production integrations and upgrade tooling

**DuckDB Integration:**
```sql
-- Register Rosetta filesystem
LOAD rosetta;

-- Transparent reading
SELECT * FROM read_parquet('s3://bucket/data.vortex');

-- Progressive upgrade
CALL rosetta_upgrade('s3://bucket/old_parquet/',
    target_encoding := 'vortex',
    columns := ['embedding_col', 'feature_col']);
```

**Iceberg Integration:**
```python
from rosetta.iceberg import RosettaFileIO

catalog = load_catalog("my_catalog",
    **{
        "io-impl": "rosetta.iceberg.RosettaFileIO"
    })
```

---

## Technical Architecture

### System Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Application Layer                             │
│  (Spark, DuckDB, Polars, Pandas, DataFusion, Custom Apps)           │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      Rosetta Bridge Layer                            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌────────────┐ │
│  │   Format    │  │   Codec     │  │  Transcoder │  │   WASM     │ │
│  │  Detector   │  │  Registry   │  │   Engine    │  │  Runtime   │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └────────────┘ │
└─────────────────────────────────────────────────────────────────────┘
                                    │
                    ┌───────────────┼───────────────┐
                    ▼               ▼               ▼
            ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
            │  Parquet    │ │   Vortex    │ │    Lance    │
            │  Reader     │ │   Reader    │ │   Reader    │
            └─────────────┘ └─────────────┘ └─────────────┘
                    │               │               │
                    └───────────────┼───────────────┘
                                    ▼
                            Apache Arrow
                        (In-Memory Format)
```

### Performance Budget

| Operation | Target | Rationale |
|-----------|--------|-----------|
| Passthrough (Parquet v1) | <1% overhead | Just format detection |
| Native transcode | <15% overhead | Arrow conversion cost |
| WASM fallback | <30% overhead | Matches F3 benchmarks |
| Progressive upgrade | 10-50% of full rewrite time | Column-selective |

---

## Go-to-Market Strategy

### Phase 1: Open Source Foundation (Months 1-6)

1. **Launch OSS project** with permissive license (Apache 2.0)
2. **Target DuckDB community** - Most receptive to new formats
3. **Publish benchmarks** - TPC-H, ML workloads, wide tables
4. **Content marketing** - Technical blog posts, conference talks

**Key metrics:**
- 1,000+ GitHub stars
- 100+ weekly downloads
- 3+ production users providing case studies

### Phase 2: Design Partners (Months 6-9)

1. **Identify 3-5 design partners** with specific pain points:
   - ML platform teams with embedding-heavy workloads
   - Data platform teams managing wide tables (feature stores)
   - Teams evaluating Vortex/Lance but blocked by migration

2. **Free deployment** in exchange for:
   - Case study rights
   - Feature feedback
   - Reference calls for future customers

### Phase 3: Commercial Launch (Months 9-12)

1. **Launch paid offering:**
   - Cloud service: Pay per TB processed
   - Enterprise license: Self-hosted with support

2. **Pricing model:**
   ```
   Free tier:        <100 GB/month
   Pro:              $0.10/GB transcoded
   Enterprise:       Custom (includes GPU path, priority support)
   ```

---

## Acquisition-Optimized MVP Strategy

**Selected path:** Build for acquisition (6-18 month horizon)

### What Acquirers Care About

| Acquirer | What They'll Evaluate | Must-Have Demos |
|----------|----------------------|-----------------|
| **Databricks** | Spark integration, Delta Lake compat, GPU path | TPC-H on Spark with Vortex files |
| **Snowflake** | Performance gains, Parquet compat | Benchmark suite showing 10x improvement |
| **LanceDB/SpiralDB** | Backwards compat story for their format | Seamless Parquet→Lance/Vortex reads |
| **NVIDIA** | GPU decode path, RAPIDS integration | CUDA kernel benchmarks |

### Acquisition-Focused Build Order

**Month 1-2: Core that demos well**
- Parquet v1/v2 + Vortex read path
- DuckDB extension (easiest to demo)
- Benchmark suite with compelling numbers

**Month 3-4: Strategic integrations**
- Spark integration (for Databricks)
- Lance support (for LanceDB partnership)
- Python API (broad adoption)

**Month 5-6: Differentiation**
- WASM fallback (unique capability)
- Progressive upgrade tooling (enterprise story)
- GPU path prototype (NVIDIA interest)

### Acquisition Timing

1. **Months 1-3:** Build MVP, launch OSS
2. **Months 3-6:** Build community, publish benchmarks, get case studies
3. **Month 6:** Start conversations with corp dev at target acquirers
4. **Months 6-12:** Formal acquisition process (if interest) or continue building

### Key Relationships to Build

- **SpiralDB** - They need Parquet compat for Vortex adoption
- **LanceDB** - Same story for Lance
- **Databricks corp dev** - They're acquisitive (Tabular, Neon, Tecton)
- **Voltron Data** - Arrow company, potential acquirer or partner

---

## Risk Assessment

### Technical Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| WASM performance worse than expected | Medium | High | Fallback to native-only; optimize hot paths |
| Format spec changes break compatibility | Medium | Medium | Active participation in format communities |
| Security vulnerability in WASM sandbox | Low | High | Use battle-tested Wasmtime; fuzzing; audits |
| GPU path complexity underestimated | High | Medium | Defer to Phase 2; partner with NVIDIA |

### Market Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Cloud vendors build this themselves | High | High | Move fast; build community moat |
| Format landscape consolidates (only Vortex wins) | Medium | Medium | Support multiple formats; pivot if needed |
| F3/AnyBlox teams commercialize | Medium | Medium | Differentiate on production-readiness |
| Enterprise sales too slow | High | High | Focus on OSS adoption; acquisition exit |

### Execution Risks

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Scope creep (too many formats) | High | Medium | Strict MVP scope: Parquet + Vortex + Lance only |
| Integration complexity | Medium | Medium | Start with DuckDB (simplest); expand carefully |
| Team hiring challenges | Medium | High | Open source attracts contributors |

---

## Next Steps

1. [ ] **Week 1:** Set up Rust project structure with Vortex/Lance dependencies
2. [ ] **Week 2:** Implement format detection + Vortex read path
3. [ ] **Week 3:** Build DuckDB extension for demos
4. [ ] **Week 4:** Benchmark suite + publish results
5. [ ] **Month 2:** Launch OSS, start community building
6. [ ] **Month 3:** Reach out to SpiralDB/LanceDB for partnership conversations

---

## Sources

**Market Research:**
- [Mordor Intelligence - Data Lake Market](https://www.mordorintelligence.com/industry-reports/data-lakes-market)
- [GMInsights - Data Lakehouse Market](https://www.gminsights.com/industry-analysis/data-lakehouse-market)

**Technical Research:**
- [Andy Pavlo - 2025 Database Retrospective](https://www.cs.cmu.edu/~pavlo/blog/2026/01/2025-databases-retrospective.html)
- [DuckDB - Parquet Encodings](https://duckdb.org/2025/01/22/parquet-encodings)
- [F3 Paper - SIGMOD 2026](https://db.cs.cmu.edu/papers/2025/zeng-sigmod2025.pdf)
- [AnyBlox - VLDB 2025 Best Paper](https://gienieczko.com/anyblox-paper)
- [FastLanes File Format - DuckDB](https://duckdb.org/science/fastlanes/)

**Industry News:**
- [LF AI - Vortex Announcement](https://www.linuxfoundation.org/press/lf-ai-data-foundation-hosts-vortex-project-to-power-high-performance-data-access-for-ai-and-analytics)
- [LanceDB - $30M Series A](https://lancedb.com/blog/newsletter-june-2025/)
- [Polar Signals - Vortex Case Study](https://www.polarsignals.com/blog/posts/2025/11/25/interface-parquet-vortex)
- [Databricks - Tabular Acquisition](https://www.databricks.com/company/newsroom/press-releases/databricks-agrees-acquire-tabular-company-founded-original-creators)
