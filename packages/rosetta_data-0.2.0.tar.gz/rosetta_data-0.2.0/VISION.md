# Rosetta: The Universal Columnar Format Bridge

> **Mission**: Enable seamless adoption of next-generation columnar formats (Vortex, Lance) without rewriting the data stack.

---

## The Problem: N×M Integration Hell

Every columnar file format needs integrations with every data tool:

```
                    Spark  Iceberg  DuckDB  Trino  Flink  DataFusion
    Parquet           ✓       ✓       ✓       ✓      ✓        ✓
    Vortex            ~       ✗       ✗       ✗      ✗        ?
    Lance             ✓       ✗       ✗       ✗      ✗        ✗
    ORC               ✓       ✓       ✓       ✓      ✓        ✓
    Future Format     ✗       ✗       ✗       ✗      ✗        ✗

    = N formats × M tools = explosion of integration work
```

**The consequences:**
- New formats (Vortex, Lance) can't get adoption without massive integration effort
- Organizations stuck on Parquet even when better options exist
- Each format team duplicates the same integration work
- Tools lag behind on format support

---

## The Solution: Rosetta Bridge

Rosetta inverts the problem:

```
    Formats integrate         Tools integrate
    with Rosetta ONCE         with Rosetta ONCE
           │                         │
           ▼                         ▼
    ┌──────────┐             ┌──────────────┐
    │ Parquet  │─────┐       │    Spark     │
    │ Vortex   │─────┼──────▶│   Iceberg    │
    │ Lance    │─────┤       │    DuckDB    │
    │ ORC      │─────┤       │    Trino     │
    │ Future   │─────┘       │  DataFusion  │
    └──────────┘             └──────────────┘
          │                         │
          └────── ROSETTA ──────────┘
                  BRIDGE

    = N format readers + M tool integrations
    = Linear scaling, not quadratic
```

---

## Why Now?

1. **Vortex is emerging**: LF AI & Data incubation, Microsoft showed 30% Spark speedup
2. **Lance is growing**: AI/ML workloads need vector-optimized storage
3. **Iceberg is exploding**: Universal adoption, but only supports Parquet/ORC
4. **The window is open**: No one else is building this bridge

---

## Architecture

### Layer 1: Rosetta Core (Rust)

The heart of Rosetta - a unified interface for reading columnar formats.

```rust
/// The core abstraction: every format implements this trait
pub trait FormatReader: Send + Sync {
    /// Schema of the data
    fn schema(&self) -> &Schema;

    /// Statistics for query optimization (row counts, min/max, null counts)
    fn statistics(&self) -> Option<Statistics>;

    /// Push a filter down to the reader (predicate pushdown)
    fn push_filter(&mut self, filter: &Expr) -> Result<()>;

    /// Push column projection down to the reader
    fn push_projection(&mut self, columns: &[&str]) -> Result<()>;

    /// Read data as Arrow RecordBatches
    fn read(&self) -> Result<RecordBatchStream>;

    /// Partition information for distributed reads
    fn partitions(&self) -> Result<Vec<Partition>>;
}
```

**Key design principles:**
- **Native performance**: Each reader calls native format libraries (vortex, lance, parquet)
- **Full pushdown**: Filters and projections pushed to native readers
- **Statistics exposure**: Enable query optimizers to make smart decisions
- **Partition-aware**: Support distributed execution (Spark, Trino)

### Layer 2: Format Readers

Native readers for each supported format:

```
rosetta-core/src/readers/
├── parquet.rs    # Wraps arrow-rs parquet
├── vortex.rs     # Wraps vortex crate (NATIVE Vortex performance)
├── lance.rs      # Wraps lance crate
├── orc.rs        # Wraps orc-rust
└── mod.rs        # Format detection, reader factory
```

Each reader:
- Implements `FormatReader` trait
- Translates Rosetta expressions to native format expressions
- Exposes native statistics
- Supports partitioned reads

### Layer 3: Object Store Abstraction

Cloud-native from day one:

```rust
pub trait ObjectStore: Send + Sync {
    async fn get(&self, path: &Path) -> Result<Bytes>;
    async fn get_range(&self, path: &Path, range: Range<usize>) -> Result<Bytes>;
    async fn head(&self, path: &Path) -> Result<ObjectMeta>;
    async fn list(&self, prefix: &Path) -> Result<BoxStream<ObjectMeta>>;
}
```

Supported backends:
- Local filesystem
- Amazon S3
- Google Cloud Storage
- Azure Blob Storage
- HTTP/HTTPS

### Layer 4: Tool Integrations

```
rosetta-spark/        # JNI-based Spark DataSource V2
rosetta-iceberg/      # Iceberg FileIO implementation
rosetta-duckdb/       # DuckDB extension (C FFI)
rosetta-trino/        # Trino connector
rosetta-datafusion/   # DataFusion TableProvider (Rust native)
rosetta-py/           # Python bindings (PyO3)
```

---

## The Killer Feature: Iceberg + Vortex

The most valuable integration - enabling Vortex files in Iceberg tables:

```
BEFORE (Iceberg today):
┌─────────────────────────────────┐
│ Iceberg Table: sales           │
├─────────────────────────────────┤
│ metadata/                       │
│   └── v1.metadata.json         │
│ data/                          │
│   ├── 0001.parquet  ← Only     │
│   ├── 0002.parquet  ← Parquet  │
│   └── 0003.parquet  ← Allowed! │
└─────────────────────────────────┘

AFTER (Iceberg + Rosetta):
┌─────────────────────────────────┐
│ Iceberg Table: sales           │
├─────────────────────────────────┤
│ metadata/                       │
│   └── v1.metadata.json         │
│ data/                          │
│   ├── 0001.parquet  ← Legacy   │
│   ├── 0002.vortex   ← 2x smaller│
│   ├── 0003.vortex   ← 30% faster│
│   └── embeddings.lance ← Vectors│
└─────────────────────────────────┘

Same table, mixed formats, gradual migration!
```

**Implementation: `rosetta-iceberg`**

```java
public class RosettaFileIO implements FileIO {
    // Rosetta handles reading ANY format
    // Iceberg just sees Arrow RecordBatches

    @Override
    public InputFile newInputFile(String path) {
        // Detect format, return appropriate reader
        return new RosettaInputFile(path, rosettaBridge);
    }
}
```

---

## Supported Formats

| Format | Status | Native Library | Key Benefit |
|--------|--------|----------------|-------------|
| **Parquet** | Priority 1 | arrow-rs | Baseline, universal support |
| **Vortex** | Priority 1 | vortex | 2x compression, 30% faster, GPU support |
| **Lance** | Priority 1 | lance | Vector search, versioning, ML-optimized |
| **ORC** | Priority 2 | orc-rust | Hive ecosystem compatibility |
| **Avro** | Priority 3 | apache-avro | Schema evolution, Kafka ecosystem |

---

## Supported Tools

| Tool | Integration | Priority | Value |
|------|-------------|----------|-------|
| **Iceberg** | FileIO | P0 | Mixed-format tables, gradual migration |
| **Spark** | DataSource V2 | P0 | Distributed processing |
| **DuckDB** | Extension | P1 | Single-node analytics |
| **DataFusion** | TableProvider | P1 | Rust-native query engine |
| **Trino** | Connector | P2 | Federated queries |
| **Flink** | TableSource | P2 | Streaming |
| **Python** | PyO3 bindings | P0 | Data science, notebooks |

---

## Expression Language

Unified filter expressions that translate to native format filters:

```rust
pub enum Expr {
    Column(String),
    Literal(ScalarValue),
    BinaryExpr {
        left: Box<Expr>,
        op: Operator,
        right: Box<Expr>,
    },
    // ... AND, OR, NOT, IN, IS NULL, etc.
}

pub enum Operator {
    Eq, NotEq, Lt, LtEq, Gt, GtEq,
    And, Or, Not,
    // ...
}
```

**Translation to native formats:**

```rust
// Rosetta expression
let filter = col("age").gt(lit(30)).and(col("status").eq(lit("active")));

// → Parquet (arrow-rs): RowFilter
// → Vortex: vortex::expr::Expr
// → Lance: SQL string "age > 30 AND status = 'active'"
```

---

## Project Structure

```
rosetta/
├── VISION.md                    # This document
├── CLAUDE.md                    # Development guidelines
├── Cargo.toml                   # Workspace root
│
├── rosetta-core/                # Rust: Core abstractions
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── reader.rs            # FormatReader trait
│       ├── expr.rs              # Expression language
│       ├── stats.rs             # Statistics
│       ├── partition.rs         # Partition planning
│       └── readers/
│           ├── mod.rs           # Format detection
│           ├── parquet.rs
│           ├── vortex.rs
│           └── lance.rs
│
├── rosetta-object-store/        # Rust: Cloud storage
│   ├── Cargo.toml
│   └── src/
│       ├── lib.rs
│       ├── s3.rs
│       ├── gcs.rs
│       └── local.rs
│
├── rosetta-iceberg/             # Java: Iceberg FileIO
│   ├── pom.xml
│   └── src/main/java/
│       └── io/rosetta/iceberg/
│           ├── RosettaFileIO.java
│           └── RosettaInputFile.java
│
├── rosetta-spark/               # Scala: Spark DataSource
│   ├── pom.xml
│   ├── jni/                     # JNI bridge
│   └── src/main/scala/
│       └── io/rosetta/spark/
│           ├── RosettaDataSource.scala
│           └── RosettaPartitionReader.scala
│
├── rosetta-duckdb/              # C++: DuckDB extension
│   ├── CMakeLists.txt
│   └── src/
│       └── rosetta_extension.cpp
│
├── rosetta-datafusion/          # Rust: DataFusion integration
│   ├── Cargo.toml
│   └── src/
│       └── lib.rs
│
├── rosetta-py/                  # Python: PyO3 bindings
│   ├── Cargo.toml
│   ├── pyproject.toml
│   └── src/
│       └── lib.rs
│
└── examples/
    ├── iceberg-vortex/          # Demo: Iceberg with Vortex
    ├── spark-mixed-formats/     # Demo: Spark reading mixed data
    └── migration-tool/          # Demo: Parquet → Vortex migration
```

---

## Current State (What Already Exists!)

The Rust foundation is **already substantial** (30 source files, compiles with all features):

```
src/
├── readers/
│   ├── mod.rs              ✅ FormatReader trait defined
│   ├── parquet_reader.rs   ✅ Parquet reader with pushdown
│   ├── vortex_reader.rs    ✅ Vortex reader (native vortex crate)
│   ├── lance_reader.rs     ✅ Lance reader (native lance crate)
│   ├── f3_reader.rs        ✅ F3/WASM reader
│   └── unified.rs          ✅ UnifiedReader (format detection + routing)
├── iceberg/
│   └── fileio.rs           🚧 RosettaFileIO (started, needs completion)
├── duckdb/
│   └── mod.rs              🚧 DuckDB extension (started)
├── fuse/
│   └── mod.rs              🚧 FUSE filesystem (started)
├── proxy/
│   └── mod.rs              ✅ S3 proxy for legacy tools
├── transcoder.rs           ✅ Any format → Parquet v1 transcoding
├── python.rs               ✅ PyO3 bindings
├── benchmark.rs            ✅ Criterion benchmarks
└── main.rs                 ✅ CLI tool
```

**What's working:**
- `cargo +nightly check --features "vortex-reader,lance-reader"` ✅ COMPILES
- ParquetReader, VortexReader, LanceReader all implemented
- Format detection and unified API
- S3 proxy for legacy tool compatibility

---

## Roadmap

### Phase 1: Complete Foundation
**Goal**: Production-ready Rust core

- [x] `FormatReader` trait - DONE
- [x] `ParquetReader` with pushdown - DONE
- [x] `VortexReader` with native performance - DONE
- [x] `LanceReader` - DONE
- [x] `Transcoder` (any format → Parquet v1) - DONE
- [ ] **Update dependencies** - Vortex and Lance to latest versions
- [ ] **Add expression pushdown** - Unified filter language that translates to native
- [ ] **Add statistics exposure** - Enable query optimization
- [ ] **Benchmarks** - Prove <5% overhead vs native

### Phase 2: Iceberg Integration
**Goal**: The killer demo - Vortex in Iceberg

- [x] `RosettaFileIO` started - DONE
- [ ] **Complete FileIO** - Full read path working
- [ ] **Demo**: Mixed Parquet + Vortex Iceberg table
- [ ] **Demo**: Gradual migration (new writes as Vortex)
- [ ] **Partner with SpiralDB** for validation

### Phase 3: Spark & Production
**Goal**: Distributed processing support

- [ ] `rosetta-spark`: DataSource V2 with JNI bridge
- [ ] Object store integration (S3/GCS) for cloud-native
- [ ] Performance validation at 1TB+ scale
- [ ] Find lighthouse customer

### Phase 4: Ecosystem
**Goal**: Become the standard

- [x] DuckDB extension started - DONE
- [ ] **Complete DuckDB extension** - Full integration
- [ ] `rosetta-trino`: Trino connector
- [ ] Submit to LF AI & Data Foundation
- [ ] Documentation, tutorials, community

---

## Success Metrics

| Metric | Target | Why |
|--------|--------|-----|
| **Performance overhead** | <5% vs native | Must not slow things down |
| **Format coverage** | Parquet, Vortex, Lance | Core formats |
| **Tool coverage** | Iceberg, Spark, Python | Critical integrations |
| **Lighthouse customers** | 1 Fortune 500 | Validation |
| **Community** | 100+ GitHub stars, 5+ contributors | Adoption signal |

---

## Non-Goals (What Rosetta is NOT)

1. **Not a query engine**: Rosetta reads data, doesn't execute queries
2. **Not a table format**: Not competing with Iceberg/Delta/Hudi
3. **Not a storage layer**: Not competing with S3/GCS
4. **Not format-specific optimizations**: Each format keeps its native optimizations
5. **Not a data transformation tool**: Read-only (writes are format-specific)

---

## Governance & Sustainability

**Recommended path**: LF AI & Data Foundation

- Vortex is already at LF AI & Data
- Natural home for Rosetta alongside Vortex
- Neutral governance, multi-company support
- Sustainable funding model

**Potential sponsors**:
- SpiralDB (Vortex creators) - most to gain from adoption
- LanceDB - Lance ecosystem expansion
- Databricks/Snowflake - lakehouse format support
- Cloud providers - managed service opportunity

---

## Getting Started

```bash
# Clone the repository
git clone https://github.com/your-org/rosetta.git
cd rosetta

# Build the Rust core
cargo build --release

# Run tests
cargo test

# Build Python bindings
cd rosetta-py && maturin develop

# Try it out
python -c "import rosetta; print(rosetta.read('data.vortex'))"
```

---

## References

- [Vortex](https://github.com/vortex-data/vortex) - Next-gen columnar format
- [Lance](https://github.com/lancedb/lance) - ML-optimized columnar format
- [Apache Iceberg](https://iceberg.apache.org/) - Open table format
- [Apache Arrow](https://arrow.apache.org/) - In-memory columnar format
- [DataFusion](https://github.com/apache/datafusion) - Rust query engine

---

*This document is the north star for Rosetta development. All design decisions should align with this vision.*
