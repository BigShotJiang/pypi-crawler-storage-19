// SPDX-License-Identifier: Apache-2.0
// Copyright 2026 Rosetta Contributors

/**
 * @file rosetta_extension.cpp
 * @brief DuckDB extension entry point for Rosetta
 *
 * This extension enables DuckDB to transparently read any columnar format
 * (Vortex, Lance, F3) by transcoding them to Parquet on-the-fly.
 *
 * Usage:
 *   LOAD rosetta;
 *   SELECT * FROM 'rosetta://data.vortex';
 *   SELECT * FROM rosetta_read('data.lance');
 */

#define DUCKDB_EXTENSION_MAIN

#include "rosetta_extension.hpp"
#include "duckdb/main/extension_util.hpp"
#include "duckdb/common/file_system.hpp"

extern "C" {
#include "rosetta.h"
}

namespace duckdb {

// Extension load function
static void LoadInternal(DatabaseInstance &instance) {
    // Register custom filesystem for rosetta:// URLs
    rosetta::RegisterRosettaFileSystem(instance);

    // Register SQL functions
    rosetta::RegisterRosettaFunctions(instance);
}

// Extension entry point
void RosettaExtension::Load(DuckDB &db) {
    LoadInternal(*db.instance);
}

std::string RosettaExtension::Name() {
    return "rosetta";
}

std::string RosettaExtension::Version() const {
#ifdef ROSETTA_VERSION
    return ROSETTA_VERSION;
#else
    return ::rosetta_version();
#endif
}

} // namespace duckdb

// C API entry points required by DuckDB
extern "C" {

DUCKDB_EXTENSION_API void rosetta_init(duckdb::DatabaseInstance &db) {
    duckdb::DuckDB db_wrapper(db);
    db_wrapper.LoadExtension<duckdb::RosettaExtension>();
}

DUCKDB_EXTENSION_API const char *rosetta_ext_version() {
    return ::rosetta_version();
}

} // extern "C"

#ifndef DUCKDB_EXTENSION_MAIN
#error "This file should only be compiled as part of the extension"
#endif
